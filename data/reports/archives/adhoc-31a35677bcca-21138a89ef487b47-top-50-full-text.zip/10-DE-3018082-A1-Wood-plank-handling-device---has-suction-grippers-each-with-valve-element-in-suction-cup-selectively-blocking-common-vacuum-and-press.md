# 10. Wood plank handling device - has suction grippers each with valve element in suction cup selectively blocking common vacuum and pressure medium line

- **Archive rank:** 10 of 50
- **Publication:** [DE-3018082-A1](https://patents.google.com/patent/DE3018082A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/006102168/publication/DE3018082A1?q=pn%3DDE3018082A1)
- **Publication date:** 1981-11-19
- **Filing date:** 1980-05-12
- **Earliest priority:** 1980-05-12
- **Family:** 6102168
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** LEWECKE ERNST FA
- **Inventors:** OTTO PETER

## Abstract

The device has a suction unit with a large number of suction grippers adjusted in height and driven along horizontal guide rails. Each suction gripper is cardanically suspended from a height guide coupled to the centralised vacuum source and a press medium supply. The cup of each suction gripper has a movable valve element which blocks the suction line when the gripper is in complete contact with the surface of the plank and moved into an open position when the suction line is coupled to the press medium supply.S When the gripper is in complete contact with the surface of the plank the valve element is maintained in the open position to ensure a vacuum in the suction cup.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-3018082-A1/ops000.png)

![Sketch 1 for DE-3018082-A1](https://nimo.iptorch.com/refdrawing/DE-3018082-A1/ops000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-3018082-A1/ops001.png)

![Sketch 2 for DE-3018082-A1](https://nimo.iptorch.com/refdrawing/DE-3018082-A1/ops001.png)

## Claims

### Claim 1

Patent ansprüche 1, Vorrichtung zum Heben und Verfahren von flächigen Werkstücken, insbesondere Holzbohlen, mit einer eine Vielzahl an die Bohlen unter Vakuum haltenden Saugern aufweisenden Saugeinheit, welche in Höhenrichtung und in waagerechter Ebene an Führungen motorisch bewegbar gelagert ist, d a d u r c h g e k e n n z e i c h n e t, daß jeder Sauger (11) an einer druckbelasteten, mit einer zentralen Vakuumerzeugereinrichtung (17,18) und einer Druckmediumeinrichtung (19,20) mittelbar verbundenen Höhenführung (21) kardanisch aufgehängt ist und ein in eine zum Sauger-Saugelement (16) geführte Saug-und Druckleitung (22) eingesetztes, durch ein Druckmedium in die Druck- und Saugleitung-Offnungsstellung bewegbares, bei vollflächiger Saugerauflage auf einer Bohle (12) bei anschließend erfolgender Saugwirkung in der Öffnungsstellung verbleibendes und zwischen Sauger-Saugelement (16) und Bohle (12) eine Vakuumbildung ermöglichendes und bei nicht vollflächiger Saugerauflage auf einer Bohle (12) durch die Saugwirkung in die keine Vakuumbildung zulassendes Druck- und Saugleitung-Schließstellung bewegbares Dichtelement (36) aufweist. Patent claims 1, device for lifting and moving flat Workpieces, especially wooden planks, with a large number of the planks underneath Vacuum holding suction cups having suction unit, which in the height direction and in horizontal plane is mounted on guides so that it can be moved by a motor, d a d u r c h g It is not noted that each suction cup (11) is attached to a pressure-loaded, with a central vacuum generating device (17, 18) and a pressure medium device (19, 20) indirectly connected height guide (21) is gimbaled and one in a suction and pressure line (22) inserted through to the sucker-suction element (16) a pressure medium that can be moved into the pressure and suction line open position, with full-surface Suction pad on a plank (12) with subsequent suction in the Open position remaining between the suction element (16) and the screed (12) which enables a vacuum to be formed and if the suction cup is not supported over the entire surface a plank (12) through the suction effect into which the pressure does not allow the formation of a vacuum and the suction line closed position has movable sealing element (36).

### Claim 2

Vorrichtung nach Anspruch 1, d a d u r c h g e k e n n z e i c h n e t , daß jeder Sauger (11) als Höhenführung (21) ein Rohr oder hohlen Holm aufweist, dessen Innenraum den Druck-und Saugkanal (22)und an das bzw. den untenendig über ein kardanisches Verbindungsorgan (29, 33,34) das elastische und/oder flexible Saugelement (16) gegenüber dem in sich starren Rohr bzw. Holm (21) nach allen Seiten hin beweglich angesetzt ist.2. Apparatus according to claim 1, d a d u r c h g e k e n n z e i c h n e t that each sucker (11) as a height guide (21) a tube or hollow spar has, the interior of which the pressure and suction channel (22) and to the bottom end Via a cardanic connecting element (29, 33, 34) the elastic and / or flexible Suction element (16) opposite the inherently rigid tube or spar (21) on all sides is set to be movable.

### Claim 3

Vorrichtung nach den Ansprüchen 1 und 2, d a -d u r c h g e k e n n z e i c h n e t , daß jede Smuger-Höhenführung (21) mittels eines Halters (25) verstellbar an einem Trägerholm (26) der Saugeinheit (10) gelagert und gegenüber dem Halter (25) höhenverschiebbar vorgesehen ist, wobei um die Höhenführung (21) ober- und unterhalb des Halters (25) jeweils eine sich einends am Halter (25) und anderenends an einem Widerlager (29, 30) abstützende, den Sauger (11) gegen die Bohle (12) drückende und die Sauger-Höhenverschiebung zulassende Druckfeder (31), wie Schraubenfeder, vorgesehen ist.3. Device according to claims 1 and 2, d a -d u r c h g e k e n n n z e i n e t that each Smuger height guide (21) by means of a holder (25) adjustably mounted on a support bar (26) of the suction unit (10) and opposite the holder (25) is provided so that it can be moved in height, with the height guide (21) above and below the holder (25) each one at one end on the holder (25) and the other end on an abutment (29, 30) supporting the suction cup (11) against the Plank (12) pressing and compression spring (31) that allows the suction cup height shift, like coil spring, is provided.

### Claim 4

Vorrichtung nach den Ansprüchen 1 bis 3, d a -d u r c h g e k e n n z e i c h n e t , daß das kardanische Verbindungsorgan von einer an dem unteren Ende der Höhenführung (21) lösbar angebrachten, vorzugsweise angeschraubten und gleichzeitig ein Widerlager für eine Druckfeder (31) bildenden Verbindungshülse (29), einer zweiten im Abstand darunter liegenden und den Druck- und Saugkanal (22) koaxial zum Führungskanal (22) weiterführenden Verbindungshülse (33) sowie einem beide Hülsen (29, 33) miteinander verbindenden, die untere mittelbar mit dem Saugelement (16) verbundene Hülse (33) in Höhenrichtung und nach allen Seiten hin bewegbar gegenüber der oberen Hülse (29) haltenden, elastischen und/oder flexiblen Glied, vorzugsweise einer Gummi- oder Kunststoffmanschette, einer Druckfeder od. dgl. gebildet ist.4. Device according to claims 1 to 3, d a -d u r c h g e k e It is noted that the cardanic connecting element is connected by one to the lower End of the height guide (21) detachably attached, preferably screwed on and at the same time an abutment for a compression spring (31) forming the connecting sleeve (29), a second at a distance below and the pressure and suction channel (22) connecting sleeve extending coaxially to the guide channel (22) (33) as well as one connecting the two sleeves (29, 33) to one another, the lower one indirectly with the suction element (16) connected sleeve (33) in the vertical direction and on all sides movable towards the upper sleeve (29) holding, elastic and / or flexible Link, preferably a rubber or plastic sleeve, a compression spring od. Like. Is formed.

### Claim 5

Vorrichtung nach den Ansprüchen 1 bis 4, d a -d u r c h g e k e n n z e i c h n e t , daß an der unteren Verbindungshülse (33) eine topfartige Haltehülse (32) lösbar angebracht, vorzugsweise angeschraubt, ist, an der das aus einem flexiblen und/oder elastischen Material, wie Gummi, Kunststoff od. dgl., bestehende Saugelement (16) auswechselbar gehalten ist.5. Device according to claims 1 to 4, d a -d u r c h g e k e n n z e i c h n e t that a pot-like holding sleeve on the lower connecting sleeve (33) (32) is releasably attached, preferably screwed, to which the flexible and / or elastic material, such as rubber, plastic or the like. Existing suction element (16) is kept replaceable.

### Claim 6

Vorrichtung nach den Ansprüchen 1 bis 5, d a -d u r c h g e k e n n z e i c h n e t , daß der Druck-und Saugkanal (22) in der unteren Verbindungshülse (33) untenendig zu einem Schließsitz (35), wie Kegelfläche, ausgebildet ist, in dessen Bereich das von einer Kugel, einem Kegel, einem Teller od. dgl.6. Device according to claims 1 to 5, d a -d u r c h g e k e n n z e i c h n e t that the pressure and suction channel (22) in the lower connecting sleeve (33) is designed at the bottom to form a closing seat (35), such as a conical surface, in whose area is that of a ball, a cone, a plate or the like. gebildete Dichtelement (36) in Höhenrichtung frei beweglich angeordnet ist. formed sealing element (36) arranged freely movable in the height direction is.

### Claim 7

Vorrichtung nach den Ansprüchen 1 bis 5, d a -d u r c h g e k e n n z e i c h n e t, daR der obere Längenendbereich der Höhenführung (21) einen sich an den Druck- und Saugkanal (22) anschließenden Schließsitz (35) aufweist, in dessen Bereich das auf der gesamten Länge des Druck- und Saugkanales (22) frei bewegliche Dichtelement (36) für die Schließung des Kanales (22) hineinbewegbar ist.7. Device according to claims 1 to 5, d a -d u r c h g e k e It is not indicated that the upper end of the length of the height guide (21) is one has a closing seat (35) adjoining the pressure and suction channel (22), in its area that is free over the entire length of the pressure and suction channel (22) movable sealing element (36) for closing the channel (22) can be moved in is.

### Claim 8

Vorrichtung nach den Ansprüchen 1 bis 7, d a -durch g e k e n n 2 e i c h n e t , daß im Boden der topfförmigen Haltehülse (32) mehrere loch- oder schlitzförmige Durchbrüche (37) vorgesehen sind, die eine Verbindung zwischen Druck- und Saugkanal (22) und der von dem Saugelement (16) gebildeten Vakuumkammer (16a) herstellen. 8. Device according to claims 1 to 7, d a -by g e k e n n 2 e i c h n e t that in the bottom of the cup-shaped holding sleeve (32) several perforated or slot-shaped openings (37) are provided, which connect between Pressure and suction channel (22) and the vacuum chamber formed by the suction element (16) (16a).

### Claim 9

Vorrichtung nach den Ansprüchen 1 bis 8, d a -d u r c h g e k e n n z e i c h n e t , daß unter dem Boden der topfförmigen Haltehülse (32) ein die Durchbrüche (37) überdeckendes Sieb (38) lösbar befestigt ist. 9. Device according to claims 1 to 8, d a -d u r c h g e k It is noted that under the bottom of the cup-shaped holding sleeve (32) a the perforations (37) covering the sieve (38) is releasably attached.

### Claim 10

Vorrichtung nach den Ansprüchen 1 bis 9, d a -d u r c h g e k e n n z e i c h n e t , daß das Volumen der Vakuumkammer (16b) im Saugelement (16) und das Gewicht des Dichtelementes (36) derart aufeinander abgestellt sind, daß bei vollflächiger Auflage des Saugelementes (16) auf einer Bohle (12) der Saugstrom derart gering ist, daß durch die entstehende Strömung das Dichtelement (36) nicht in die Schließstellung gebracht wird.10. Device according to claims 1 to 9, d a -d u r c h g e k It is noted that the volume of the vacuum chamber (16b) in the suction element (16) and the weight of the sealing element (36) are placed on one another in such a way that the suction flow when the suction element (16) rests on a plank (12) over the entire surface is so small that the sealing element (36) is not due to the resulting flow is brought into the closed position.

### Claim 11

Vorrichtung nach den Ansprüchen 1 bis 11, d a -d u r c h g e k e n n z e i c h n e t , daß das Saugelement (16) napfförmig ausgebildet ist und eine kreisförmige, eckige, ovale oder längliche Grundform aufweist.11. Device according to claims 1 to 11, d a -d u r c h g e k It is noted that the suction element (16) is cup-shaped and has a circular, angular, oval or elongated basic shape.

### Claim 12

Vorrichtung nach den Ansprüchen 1 bis 11, d a -d u r c h g e k e n n z e i c h n e t , daß die Vakuumerzeugungseinrichtung von einer Saugpumpe (17) und einem Vakuumbehälter (18) gebil det ist, wobei als Vakuumbehälter (18) die von hohlen Säulen gebildeten und die Saugeinheit (10) höhenverfahrenden Führungen (13) vorgesehen sind.12. Device according to claims 1 to 11, d a -d u r c h g e k It is noted that the vacuum generating device is operated by a suction pump (17) and a vacuum container (18) is gebil det, the vacuum container (18) the guides, which are formed by hollow columns and move the suction unit (10) in height (13) are provided.

### Claim 13

Vorrichtung nach den Ansprüchen 1 bis 12, d a -d u r c h g e k e n n z e i c h n e t , daß die Druckmediumerzeugereinrichtung, mit welcher Druckluft in den Saug- und Druckkanal (22) jedes Saugers (11) eingebracht wird, von einer Druckpumpe (19) und einem Druckluftbehälter (20) gebildet ist.13. Device according to claims 1 to 12, d a -d u r c h g e k It is noted that the pressure medium generating device with which compressed air is introduced into the suction and pressure channel (22) of each suction cup (11) by one Pressure pump (19) and a compressed air tank (20) is formed.

### Claim 14

Vorrichtung nach den Ansprüchen 1 bis 13, d a -d u r c h g e k e n n z e i c h n e t , daß in die von der Vakuumerzeugereinrichtung (17, 18) und von der Drucklufterzeugereinrichtung (19,20) zentral zu allen Saugern (11) geführten Leitungen (23, 24) je ein Ventil (39, 40) eingesetzt ist, wobei beide Ventile (39, 40) wechselweise über elektrische Schalt-und Steuereinrichtungen in die Sperr- und Freigabestellung steuerbar sind.14. Device according to claims 1 to 13, d a -d u r c h g e k e n n z e i c h n e t that in the of the vacuum generating device (17, 18) and from the compressed air generator device (19, 20) centrally to all suction devices (11) Lines (23, 24) each have a valve (39, 40) inserted, both valves (39, 40) alternately via electrical switching and control devices in the locking and Release position are controllable.

### Claim 15

Vorrichtung nach den Ansprüchen 1 bis 14, d a -d u r c h g e k e n n z e i c h n e t , daß die jeweils eine Vielzahl an Saugern (11) haltenden Trägerholme (26) über bügelförmige Träger (27) an quer dazu verlaufenden Trägern (28) verstellbar gelagert und die Träger (28) mit den unteren Enden der über Zahnstangen und motorisch angetriebene Zahnräder höhenverschiebbaren Säulen (13) befestigt sind.15. Device according to claims 1 to 14, d a -d u r c h g e k It is noted that they each hold a large number of suckers (11) Support spars (26) via bow-shaped supports (27) on supports running transversely thereto (28) adjustable and the carrier (28) with the lower ends of the gear racks and motor-driven gears are attached to vertically displaceable columns (13).

## Full description

PERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippersDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippers with at least two picking-up headsPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansCircular shapePERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansMultiple lifting units; More than one suction areaSeparate cups

Description

Translated from German

Vorrichtung zum Heben und Verfahren von flÃ¤chigen Device for lifting and moving flat

WerkstÃ¼cken, insbesondere Holzbohlen Die Erfindung bezieht sich auf

eine Vorrichtung zum Heben und Verfahren (Abstapeln) von flÃ¤chigen WerkstÃ¼cken,

insbesondere Holzbohlen, mit einer eine Vielzahl an die Bohlen unter Vakuum haltenden

Saugern aufweisenden Saugeinheit, welche in HÃ¶henrichtung und in waagerechter Ebene

motorisch bewegbar gelagert ist. Workpieces, especially wooden planks The invention relates to

a device for lifting and moving (stacking) flat workpieces,

especially wooden planks, with a large number of the planks holding the planks under vacuum

Suckers having suction unit, which in the vertical direction and in the horizontal plane

Is mounted so that it can be moved by a motor.

Derartige, in verschiedenen AusfÃ¼hrungen bekanntgewordene Vorrichtungen

eignen sich Ã¼berwiegend nur zum Heben und Verfahren von weitestgehend ebenen und

keine Risse, AstlÃ¶cher, Verunreinigungen od. dgl. aufweisenden Brettern, die dabei

noch in der waagerechten Aufnahmeebene ausgerichtet sein sollen, da sonst die Wirksamkeit

der einzelnen Saugelemente nicht voll erreicht wird und dadurch ein hoher Energiebedarf

fÃ¼r die Vakuumschaffung entsteht. Bei unebenen, Rissen, LÃ¶chern und Warunreinigungen

aufweisenden und ggf. noch teilweise Ã¼bereinanderliegenden Bohlen treten aufgrund

Saugerausbildung und lagorung Schwierigkeiten auf, da nÃ¤mlich eine Anpassung der

Saugelemente an die gegebenen und stÃ¤ndig sich verÃ¤ndernden BohlenoberflÃ¤chen nicht

mÃ¶glich ist und deshalb diese Vorrichtungen unzureichend arbeiten bzw. fÃ¼r den Bohlentransport

nicht geeignet sind.Such devices, which have become known in various designs

are mainly only suitable for lifting and moving largely flat and

no cracks, knotholes, impurities or the like. Boards having that

should still be aligned in the horizontal recording plane, otherwise the effectiveness

of the individual suction elements is not fully achieved and therefore a high energy requirement

for creating a vacuum. For uneven, cracks, holes and dirt

having and possibly still partially superimposed planks occur due to

Sucker training and lagorung difficulties, there namely an adaptation of the

No suction elements on the given and constantly changing screed surfaces

is possible and therefore these devices work inadequately or for screed transport

are not suitable.

Aufgabe der Erfindung ist es, eine nach dem Oberbegriff des Patentanspruches

1 aufgebaute Vorrichtung dahingehend zu verbessern, daÃ ihre einzelnen Saugelemente

individuell an die gegebenen WerkstÃ¼ckoberflÃ¤chen und -lagen automatisch anpaÃbar

sind, dabei die Saugelemente automatisch entsprechend ihrer Stellung zur BohlenflÃ¤che

in die Wirk- oder

AuÃerwirkstellung gelangen und mit geringerem

Energieaufwand als bei den herkÃ¶mmlichen Vorrichtungen eine Vakuumbildung fÃ¼r einen

sicheren, stÃ¶rungsfreien und rationellen Hub, Transport und Abstapelung gewÃ¤hrleisten.The object of the invention is to provide one according to the preamble of the patent claim

1 constructed device to the effect that its individual suction elements

automatically adaptable to the given workpiece surfaces and positions

are, the suction elements automatically according to their position in relation to the plank surface

in the active or

Get ineffective and with lesser

Energy expenditure than with the conventional devices creating a vacuum for one

Ensure safe, trouble-free and efficient lifting, transport and stacking.

Diese Aufgabe wird erfindungsgemÃ¤Ã durch die im kennzeichnenden Teil

des Patentanspruches 1 aufgefÃ¼hrten Merkmale gelÃ¶st, wobei noch die in den UnteransprÃ¼chen

aufgefÃ¼hrten Gestaltungsmerkmale vorteilhafte Weiterbildungen der AufgabenlÃ¶sung

darstellen.This object is achieved according to the invention by the in the characterizing part

of the patent claim 1 listed features solved, with still those in the subclaims

listed design features advantageous developments of the task solution

represent.

Der Gegenstand der Erfindung erstreckt sich nicht nur auf die Merkmale

der einzelnen AnsprÃ¼che, sondern auch auf deren Kombination.The subject matter of the invention extends not only to the features

of the individual claims, but also on their combination.

Die erfindungsgemÃ¤Ãe Vorrichtung ermÃ¶glicht in einfacher, sicherer,

stÃ¶rungsfreier und rationeller Weise das Heben, Verfahren und Absetzen von Holzbohlen,

wobei durch die gÃ¼nstige Ausbildung, Anordnung und Wirkungsweise der einzelnen Sauger

problemlos Holzbohlen mit unebenen OberflÃ¤chen, AstlÃ¶chern, Rissen, Verunreinigungen

und auch unterschiedlichen StÃ¤rken sowie teilweise Ã¼bereinanderliegender Anordnung

erfaÃt werden kÃ¶nnen.The device according to the invention enables in a simple, safer,

trouble-free and efficient lifting, moving and lowering of wooden planks,

due to the favorable design, arrangement and mode of operation of the individual suction cups

problem-free wooden planks with uneven surfaces, knotholes, cracks, dirt

and also different strengths as well as partially superimposed arrangement

can be detected.

Da die einzelnen Sauger entsprechend der BohlenstÃ¤rke in sich hÃ¶henbeweglich

und durch eine kardanische AufhÃ¤ngung auch nach allen Seiten beweglich vorgesehen

sind, kÃ¶nnen sich diese Sauger an jede BohlenoberflÃ¤che fÃ¼r die Bildung eines wirksamen

Vakuums automatisch anpassen.Since the individual suction cups can be moved in height according to the plank thickness

and by means of a cardanic suspension, it is also designed to be movable in all directions

These suction cups can be applied to any plank surface for the formation of an effective one

Adjust vacuum automatically.

Weiterhin sind die Sauger mit einem Dichtelement ausgestattet>

welches nur bei vollflÃ¤chiger Auflage der einzelnen Sauger auf einer Bohle die Vakuumbildung

zulÃ¤Ãt und welches bei nicht vollflÃ¤chiger Saugerauflage kein Vakuum entstehen lÃ¤Ãt,

so daÃ dadurch die einzelnen Sauger entsprechend

ihrer Lage zur

Bohle wirksam oder nicht wirksam werden.The suction cups are also equipped with a sealing element>

which can only be achieved when the individual suction cups are fully supported on a plank

and which does not allow a vacuum to be created if the suction cup is not supported over the entire surface,

so that thereby the individual suckers accordingly

their location to

Bohle effective or ineffective.

Dieses Dichtelement ist in einem gÃ¼nstigen VerhÃ¤ltnis zur Vakuumkammer

jedes Saugelementes ausgerichtet, so daÃ durch den Saugstrom bei vollflÃ¤chiger Auflage

die Bewegung in die SchlieÃstellung ausgeschlossen und bei nicht vollflÃ¤chiger Auflage

durch die zusÃ¤tzlich angesaugte Fremdluft eine Bewegung in die SchlieÃstellung bewirkt

wird.This sealing element is in a favorable relationship to the vacuum chamber

each suction element aligned so that by the suction flow with full-surface contact

the movement into the closed position is excluded and when the surface is not supported over the entire surface

causes a movement into the closed position due to the additionally sucked in external air

will.

FÃ¼r die Bewegung der Dichtelemente in die Offnungsstellung wird der

Saugkanal mit einer Druckluft beaufschlagt, durch die die Dichtelemente plÃ¶tzlich

in die Kanal-Freigabesteilung zurÃ¼ckbewegt werden und fÃ¼r eine neue Vakuumbildung

in der erforderlichen Lage liegen. Gleichzeitig bewirkt diese Druckluft einen Reinigungseffekt,

da die Luft einerseits Verunreinigungen von den Bohlen wegblÃ¤st und gleichzeitig

ein den Saugkanal zur Bohlenseite hin Ã¼berdeckendes, Verunreinigungen bei der Vakuumbildung

nicht in den Saugkanal hineinlassendes Sieb reinigt.To move the sealing elements into the open position, the

Compressed air is applied to the suction channel, through which the sealing elements suddenly

be moved back into the channel release division and for a new vacuum formation

are in the required position. At the same time, this compressed air has a cleaning effect,

because on the one hand the air blows away impurities from the planks and at the same time

an impurities that covers the suction channel on the screed side during vacuum formation

cleans the sieve that does not let into the suction channel.

Das Vakuum wird in vorteilhafter Weise durch den Einsatz einer Vakuumpumpe

geschaffen, die gegenÃ¼ber den herkÃ¶mmlichen Einrichtungen eine hÃ¶here Vakuumleistung

erbringt und in Verbindung mit der SaugerausfÃ¼hrung einen verbesserten Nutzwert

schafft. Die Vakuumleistung liegt etwa bei 0,7 bis 0,8 kp/cm2.The vacuum is created in an advantageous manner through the use of a vacuum pump

created, which compared to the conventional devices a higher vacuum performance

provides and in connection with the suction cup design an improved utility

creates. The vacuum output is around 0.7 to 0.8 kp / cm2.

Weiterhin werden die die Saugeinheit hÃ¶henbewegenden FÃ¼hrungssÃ¤ulen

in gÃ¼nstiger Weise als Vakuumkammern ausgenutzt, so daÃ zusÃ¤tzliche VakuumbehÃ¤lter

entfallen.Furthermore, the guide columns which move the suction unit in height are used

exploited in a favorable manner as vacuum chambers, so that additional vacuum containers

omitted.

Aufgrund der Zeichnungen wird nachfolgend ein AusfÃ¼hrungsbeispiel

gemÃ¤Ã der Erfindung nÃ¤her erlÃ¤utert. Dabei zeigen: Fig. 1 eine perspektivische Ansicht

einer Vorrichtung zum Heben und Verfahren von Bohlen mit einer aus Saugern gebildeten

Saugeinheit; Fig. 2 einen teilweisen LÃ¤ngsschnitt durch einen Sauger; Fig. 3 eine

schematische Darstellung einer Vakuum-und einer Druckmediumeinrichtung, welche Ã¼ber

Leitungen unter Zwischenschaltung von Ventilen an die Saugeinheit angeschlossen

sind.Based on the drawings, an exemplary embodiment is shown below

explained in more detail according to the invention. They show: FIG. 1 a perspective view

a device for lifting and moving planks with one formed from suction cups

Suction unit; 2 shows a partial longitudinal section through a suction device; Fig. 3 a

schematic representation of a vacuum and a pressure medium device, which via

Lines connected to the suction unit with the interposition of valves

are.

Mit 10 ist eine aus einer Vielzahl an Saugern 11 gebildete Saugeinheit

einer Vorrichtung (Anlage) zum Heben und Verfahren von flÃ¤chigen WerkstÃ¼cken, insbesondere

Holzbohlen 12, bezeichnet. Diese Saugeinheit 10 ist an FÃ¼hrungen 13 motorisch hÃ¶henbewegbar

und an weiteren FÃ¼hrungen 14 mittels eines Wagens (einer Laufkatze) 15 motorisch

in waagerechter Ebene verfahrbar.10 is a suction unit formed from a plurality of suckers 11

a device (system) for lifting and moving flat workpieces, in particular

Wooden planks 12, designated. This suction unit 10 can be moved in height on guides 13 by a motor

and on further guides 14 by means of a carriage (a trolley) 15 by motor

can be moved in a horizontal plane.

Jeder Sauger 11 besitzt ein Saugelement 16 aus einem flexiblen und/oder

elastischen Material, wie Gummi, Kunststoff od. dgl., und ist an einer druckbelasteten,

mit einer zentralen Vakuumerzeugereinrichtung 17, 18 und einer Druckmediumeinrichtung

19, 20 mittelbar verbundenen HÃ¶henfÃ¼hrung 21 kardanisch aufgehÃ¤ngt.Each teat 11 has a suction element 16 made of a flexible and / or

elastic material, such as rubber, plastic or the like, and is on a pressure-loaded,

with a central vacuum generating device 17, 18 and a pressure medium device

19, 20 indirectly connected height guide 21 gimbaled.

Die HÃ¶henfÃ¼hrung 21 ist von einer Hohlstange oder einem Rohr gebildet,

so daÃ durch die-gesamte LÃ¤nge der HÃ¶henfÃ¼hrung 21 ein Kanal 22 (Leitung) fÃ¼r das

Druck- und Saugmedium vorhanden ist, welcher Ã¼ber Schlauchleitungen 23, 24 an die

gemeinsame Vakuumerzeuger- und Druckmediumeinrichtung 18, 20 angeschlossen ist.The height guide 21 is formed by a hollow rod or a tube,

so that through the entire length of the height guide 21 a channel 22 (line) for the

Pressure and suction medium is present, which via hose lines 23, 24 to the

common vacuum generator and pressure medium device 18, 20 is connected.

Jede rohrfÃ¶rmige HÃ¶henfÃ¼hrung 21 ist in einem Halter 25 hÃ¶henverschiebbar

gefÃ¼hrt und mit diesem Halter 25 ist jede HÃ¶henfÃ¼hrung 21 an TrÃ¤gerholmen 26 gelagert.

Dabei nimmt jeder TrÃ¤gerholm 26 mehrere Halter 25 mit je einem Sauger 11 in Holm-LÃ¤ngsrichtung

verstellbar auf und jeder TrÃ¤gerholm 26 lagert in einem bÃ¼gelfÃ¶rmigen TrÃ¤ger 27.

Zu der Saugeinheit 10 gehÃ¶ren mehrere TrÃ¤ger 27, die wiederum quer zur LÃ¤ngsrichtung

des Holmes 26 verstellbar an TrÃ¤gern 28 lagern, welche an den aufrechten, von SÃ¤ulen

gebildeten HÃ¶henfÃ¼hrungen 13 befestigt sind. Die Verstellung der Halter 25 und der

TrÃ¤ger 27 erfolgt stufenlos.Each tubular height guide 21 is vertically displaceable in a holder 25

out and with this holder 25 each height guide 21 is mounted on support bars 26.

Each support spar 26 takes a plurality of holders 25, each with a suction device 11 in the longitudinal direction of the spar

adjustable on and each support spar 26 is supported in a bow-shaped support 27.

The suction unit 10 includes several supports 27, which in turn are transverse to the longitudinal direction

of the spar 26 adjustable on supports 28, which on the upright, of columns

formed height guides 13 are attached. The adjustment of the holder 25 and the

Carrier 27 takes place continuously.

Am unteren Ende der HÃ¶henfÃ¼hrung 21 ist eine VerbindungshÃ¼lse 29 durch

Schrauben befestigt und am oberen Ende der HÃ¶henfÃ¼hrung 21 lagert ein Widerlager-

und Schlauchleitungs-AnschluÃstÃ¼ck 30. Zwischen Halter 25 und Widerlager 30 und

zwischen Halter 25 und VerbindungshÃ¼lse 29 ist um die HÃ¶henfÃ¼hrung 21 jeweils eine

Druckfeder (Schraubenfeder) 31 angeordnet, die sich an den zugehÃ¶rigen Teilen 25

und 30 bzw. 25 und 29 abstÃ¼tzen und die Druckbelastung auf die HÃ¶henfÃ¼hrung 21 ausÃ¼ben

sowie deren HÃ¶henverschiebung nach oben und unten zulassen.At the lower end of the height guide 21, a connecting sleeve 29 is through

Screws fastened and at the upper end of the height guide 21 supports an abutment

and hose line connector 30. Between holder 25 and abutment 30 and

between the holder 25 and the connecting sleeve 29 is in each case one around the height guide 21

Compression spring (coil spring) 31 is arranged, which is attached to the associated parts 25

and 30 or 25 and 29 and apply the pressure load to the height guide 21

as well as their height shift up and down.

Das Saugelement 16, welches eine beliebige Grundform haben kann, vorzugsweise

von einem Saugnapf gebildet ist, ist an einer HaltehÃ¼lse 32 auswechselbar festgelegt

und diese HaltehÃ¼lse -32 ist wiederum auf eine VerbindungshÃ¼lse 33 aufgeschraubt,

die koaxial zu der VerbindungshÃ¼lse 29 unterhalb derselben liegt. Beide VerbindungshÃ¼lsen

29, 33 werden von einer elastischen Manschette 34 aus Gummis Kunststoff od. dgl.

umfaÃt und mit Abstand zueinander (Ã¼bereinander) verbunden. Diese beiden HÃ¼lsen

29, 33 bilden mit der Maschette 34 die kardanische AufhÃ¤ngung fÃ¼r das Saugelement

16, welches sich durch diese kardanische Halterung nach allen Seiten hin und auch

in HÃ¶henrichtung gegenÃ¼ber der HÃ¶henfÃ¼hrung 21 bewegen und auf die jeweilige Bohle

12 einstellen kann. Der Kanal 22 der HÃ¶henfÃ¼hrung 21 setzt sich auch in der unteren

VerbindungshÃ¼lse 33 fort und ist an seinem unteren Ende zu einem SchlieÃsitz 35

erweitert, mit dem ein in den Saug- und Druckmediumkanal 22 eingesetztes Dichtelement

36 zusammenwirkt.The suction element 16, which can have any basic shape, preferably

is formed by a suction cup, is fixed on a holding sleeve 32 so as to be exchangeable

and this holding sleeve -32 is in turn screwed onto a connecting sleeve 33,

which is coaxial with the connecting sleeve 29 below the same. Both connecting sleeves

29, 33 are od by an elastic sleeve 34 made of rubber plastic.

includes and connected at a distance from one another (one above the other). These two pods

29, 33 together with the mesh 34 form the cardanic suspension for the suction element

16, which is through this gimbal bracket on all sides and also

Move in the height direction with respect to the height guide 21 and onto the respective screed

12 can set. The channel 22 of the height guide 21 is also in the lower one

Connecting sleeve 33 continues and is at its lower end to a locking seat 35

expanded, with which a sealing element inserted into the suction and pressure medium channel 22

36 cooperates.

Anstelle der Manschette 34 als elastisches Kardanglied kann auch eine

Feder vorgesehen sein> die den Sauger 16 mit den beiden HÃ¼lsen 32, 33 gegenÃ¼ber

der oberen VerbindungshÃ¼lse 22 und dem Holm 21 nach allen Seiten hin beweglich und

auf die BohlenflÃ¤che einrichtbar hÃ¤lt.Instead of the cuff 34 as an elastic cardan member, a

Spring should be provided> the suction cup 16 with the two sleeves 32, 33 opposite

the upper connecting sleeve 22 and the spar 21 movable in all directions and

can be set up on the plank surface.

Das Dichtelement 36 ist in bevorzugter Weise von einer Kugel gebildet.

Bei weiteren nicht dargestellten Ausfthrungen ist das Dichtelement 36 auch als Kegel,

Teller od. dgl. ausfÃ¼hrbar. Der SchlieÃsitz 35 wird von einer sich nach unten hin

erweiternden KegelflÃ¤che gebildet, gegen die die Kugel 36 abdichtend anliegt bzw.

mit Abstand dazu unter Bildung eines DurchfluÃ-Ringraumes liegt.The sealing element 36 is preferably formed by a ball.

In other embodiments, not shown, the sealing element 36 is also available as a cone,

Plate or the like. Executable. The closing seat 35 is moved downwards by one

widening conical surface against which the ball 36 rests in a sealing manner or

is at a distance to form an annular flow-through space.

Bei der AusfÃ¼hrung des Dichtelementes 36 als Kegel oder Teller ist

der SchlieÃsitz 35 entsprechend als im Kegelwinkel abweichende KegelflÃ¤che oder

als plane AnlageflÃ¤che ausgefÃ¼hrt.When the sealing element 36 is designed as a cone or plate

the closing seat 35 correspondingly as a conical surface deviating in the cone angle or

designed as a flat contact surface.

Auch besteht die MÃ¶glichkeit, den SchlieÃsitz 35 im oberen Endbereich

des Holmes 21 vorzusehen, so daÃ dann das Dichtelement 35 im oberen Endbereich des

Holmes 21 zur Wirkung kommt und somit einen grÃ¶Ãeren, in HÃ¶henrichtung verlaufenden

Bewegungsweg fÃ¼r das VerschlieÃen und Freigeben des Kanales 22 hat. Dieses weitere

AusfÃ¼hrungsbeispiel ist in Fig. 2 in strich-punktierten Linien dargestellt. Hierbei

verlÃ¤uft dann der Kanal 22 auf der gesamten LÃ¤nge und auch innerhalb der HÃ¼lse 33

mit gleich groÃem Querschnitt, der etwas grÃ¶Ãer ist als der grÃ¶Ãte Durchmesser des

Dichtelementes 35.There is also the possibility of the closing seat 35 in the upper end area

of the spar 21 to be provided so that the sealing element 35 in the upper end of the

Holmes 21 comes into play and thus a larger one running in the vertical direction

Movement path for closing and releasing the channel 22 has. This further

Embodiment is shown in Fig. 2 in dash-dotted lines. Here

The channel 22 then runs along the entire length and also within the sleeve 33

with the same cross-section, which is slightly larger than the largest diameter of the

Sealing element 35.

Die Verbindung zwischen Kanal 22 und dem vom Saugelement 16 gebildeten

Vakuumraum 16a wird durch mehrere LÃ¶cher 37 (Bohrungen, Schlitze od. dgl.) im Boden

der topfartigen HaltehÃ¼lse 32 geschaffen und diese LÃ¶cher 37 sind von einem unter

dem Boden liegenden und an der HaltehÃ¼lse 32 auswechselbar befestigten Sieb 38 Ã¼berdeckt.The connection between channel 22 and that formed by suction element 16

Vacuum space 16a is created by several holes 37 (bores, slots or the like) in the floor

the pot-like holding sleeve 32 created and these holes 37 are from one below

The sieve 38 lying on the ground and exchangeably fastened to the holding sleeve 32 is covered.

Die Vakuumerzeugungseinrichtung ist von einer Saugpumpe 17 und einem

VakuumbehÃ¤lter 18 gebildet, wobei in vorteilhafter Weise als VakuumbehÃ¤lter 18 die

von innen hohlen SÃ¤ulen gebildeten FÃ¼hrungen 13 benutzt werden, so daÃ an diese

SÃ¤ulen 13 die Vakuumpumpe 17 angeschlossen wird. Die Druckmediumerzeugereinrichtung

ist von einer Druckpumpe 19 und einem DruckbehÃ¤lter 20 gebildet. Als Drudkmedium

wird durch die Pumpe 19 in den BehÃ¤lter 20 Druckluft hineingebracht. In beide von

den SÃ¤ulen 13 bzw. von dem DruckluftbehÃ¤lter 20 zu der Saugeinheit 10 verlaufenden

Leitungen 23, 24 ist jeweils ein Ventil 39, 40 eingesetzt.The vacuum generating device is a suction pump 17 and a

Vacuum container 18 formed, advantageously as the vacuum container 18

Guides 13 formed by hollow pillars inside are used, so that at these

Columns 13 the vacuum pump 17 is connected. The pressure medium generating device

is formed by a pressure pump 19 and a pressure vessel 20. As a print medium

compressed air is introduced into the container 20 by the pump 19. In both of

the columns 13 or from the compressed air tank 20 to the suction unit 10

Lines 23, 24 each have a valve 39, 40 inserted.

Beide Ventile 39>40 sind Ã¼ber elektrische Schalt-und Steuereinrichtungen

wechselweise und in AbhÃ¤ngigkeit voneinander in ihrer Wirkstellung steuerbar.Both valves 39> 40 are via electrical switching and control devices

alternately and depending on one another in their operative position controllable.

An den SÃ¤ulen 13 sind Zahnstangen (nicht dargestellt) befestigt, mit

denen motorisch angetriebene, im Bereich-der FÃ¼hrungen 14 gelagerte ZahnrÃ¤der zusammenwirken,

so daÃ durch diesen Zahnrad-Zahnstangen-Antrieb die HÃ¶henverfahrbarkeit der SÃ¤ulen

13 mit Saugeinheit 10 erfolgt.To the columns 13 racks (not shown) are attached, with

which motor-driven gears mounted in the area of the guides 14 interact,

so that this rack-and-pinion drive allows the columns to be moved in height

13 with suction unit 10 takes place.

Die Funktion der erfindungsgemÃ¤Ãen Vorrichtung ist folgende: Die Saugeinheit

10 wird durch den Laufwagen 15 Ã¼ber einen Bohlenstapel gefahren. Der Bohlenstapel

setzt sich aus mehreren Ã¼bereinanderliegenden Schichten aus jeweils mehreren nebeneinander-liegenden

Bohlen 12 zusammen. Danach wird die Saugeinheit 10 durch die SÃ¤ulen 13 nach unten

verfahren, und zwar soweit, bis sich die Saugelemente 16 auf die Bohlen 12 aufsetzen.

Hierbei werden die HÃ¶henfÃ¼hrungen 21 der Saugelemente 16, die sich auf einer Bohle

12 abstÃ¼tzen, entgegen der Federkraft 31 um ein geringes MaÃ nach oben verfahren,

so daÃ bei Bohlenunebenheiten auch alle Sauger 16, die im Bereich einer Bohle 12

bzw. der Bohlen 12 liegen, auf die Bohlen 12 aufgedrÃ¼ckt werden. Es ist somit durch

die federnde HÃ¶henverschiebbÃ¦barkeit der Saugelemente 16 ein automatischer HÃ¶henausgleich

mÃ¶glich, was bei unterschiedlich dicken Bohlen 12, bei Unebenheiten in den Bohlen

12, bei in sich verzogenen Bohlen 12 und auch bei Ã¼berlappt liegenden (teilweise

Ã¼bereinanderliegenden) Bohlen 12 eine Anlage der Saugelemente 16 an der BohlenflÃ¤che

gewÃ¤hrleistet.

Gleichzeitig wird durch die kardanischen AufhÃ¤ngung der einzelnen Saugelemente 16

eine zusÃ¤tzliche Feineinstellung der Saugelementanlage an der BohlenflÃ¤che erreicht,

da durch die kardanische AufhÃ¤ngung eine zusÃ¤tzliche HÃ¶heneinstellung und auch eine

Anpassung an SchrÃ¤gflÃ¤chen der Bohlen mÃ¶glich ist, da sich dann die Saugelemente

16 entsprechend der BohlenstÃ¤rke oder -flÃ¤chenform hÃ¶henmÃ¤Ãig anpassen und schrÃ¤gsetzen.The function of the device according to the invention is as follows: The suction unit

10 is driven by the carriage 15 over a pile of planks. The pile of planks

is made up of several superimposed layers of several adjacent to each other

Planks 12 together. Thereafter, the suction unit 10 is down through the columns 13

proceed until the suction elements 16 sit on the planks 12.

Here, the height guides 21 of the suction elements 16, which are located on a plank

Support 12, move upwards by a small amount against the spring force 31,

so that in the case of uneven planks, all suction pads 16 that are in the area of a plank 12

or the planks 12 are on the planks 12 are pressed. So it's done

the resilient HÃ¶henverschiebbÃ¦barkeit the suction elements 16 an automatic height compensation

possible, which is possible with planks of different thicknesses 12, with unevenness in the planks

12, with contorted planks 12 and also with overlapping (partially

superimposed) planks 12 an abutment of the suction elements 16 on the plank surface

guaranteed.

At the same time, the cardanic suspension of the individual suction elements 16

an additional fine adjustment of the suction element system on the screed surface is achieved,

because of the cardanic suspension an additional height adjustment and also a

Adaptation to inclined surfaces of the planks is possible, since then the suction elements

16 adjust the height according to the thickness or shape of the plank and set it at an angle.

Nun wird durch die Saugpumpe 17 und die VakuumbehÃ¤lter (13) 18 in

jedem Holmkanal 22 ein Saugstrom erzeugt.Now the suction pump 17 and the vacuum container (13) 18 in

each spar channel 22 generates a suction flow.

Hierbei ist das Ventil 39 geÃ¶ffnet und das Ventil 40 geschlossen worden.Here, the valve 39 has been opened and the valve 40 has been closed.

Durch den Saugstrom wird nun die in der Saugelementkammer 16a zwischen

Saugelement 16 und BohlenflÃ¤che befindliche Luft durch das Sieb 38, die LÃ¶cher 37

in den Kanal 22 gesogen. Liegt nun das Saugelement 16 vollflÃ¤chig auf einer Bohle

12 auf, d.h., das Saugelement 16 erstreckt sich mit seinem gesamten Umfang im Bereich

der BohlenflÃ¤che, dann kann keine Fremdluft in den Kanal 22 mit angesaugt werden

und es entsteht in der Kammer 16a ein Vakuum. Bei allen Saugelementen 16, die vollflÃ¤chig

auf einer in sich geschlossenen BohlenflÃ¤che aufliegen,wird ein Vakuum erzeugt und

bei allen anderen Saugelementen 16, die nur teilweise auf einer Bohlen flÃ¤che aufliegen

oder aber auf zwei benachbarten, zwischen sich einen Schlitz bildenden Bohlen 12

aufliegen, kann kein Vakuum erzeugt werden, da Fremdluft mit angesaugt wird und

somit diese Saugelemente wirkungslos bleiben.By the suction flow is now in the suction element chamber 16a between

Air located in the suction element 16 and the plank surface through the sieve 38, the holes 37

sucked into the channel 22. If the suction element 16 is now lying over its entire surface on a plank

12, i.e. the suction element 16 extends with its entire circumference in the area

the plank surface, then no external air can be sucked into the channel 22

and a vacuum is created in the chamber 16a. With all suction elements 16 that cover the entire surface

rest on a self-contained plank surface, a vacuum is generated and

in all other suction elements 16, which only partially rest on a plank surface

or on two adjacent planks 12 that form a slot between them

no vacuum can be created because external air is sucked in and

thus these suction elements remain ineffective.

Die Schaffung des Vakuums bzw. die Nichtschaffung des Vakuums wird

nunmehr genauer erlÃ¤utert.The creation of the vacuum or the non-creation of the vacuum will

now explained in more detail.

Bei vollflÃ¤chiger Saugelementauflage auf einer Bohle 12 wird also

durch den Saugstrom die Luft aus der Kammer 16 herausgezogen, da keine Fremdluft

mit angesaugt wird.With full-surface suction element support on a screed 12, so

the air is drawn out of the chamber 16 by the suction flow, since there is no external air

is sucked in.

Hierbei liegt das Dichtelement 36 in der in Fig. 2 im unteren Bereich

gezeigten Offnungsstellung, so daÃ der Saugstrom zwischen Dichtelement 36 und SchlieÃsitz

35 hindurch in den KanaL 22 strÃ¶men kann. Die Dichtkugel 36 verbleibt wÃ¤hrend der

gesamten Dauer des Vakuums in der Uffnungsstellung. Um das Vakuum schaffen zu kÃ¶nnen

und um zu vermeiden, daÃ die Dichtkugel 36 durch den Saugstrom in die SchlieÃstellung

bewegt wird, muÃ das Volumen in der Kammer 16a und das Gewicht des Dichtelementes

36 so aufeinander abgestellt werden, daÃ bei voller Auflage des Saugelementes 16

auf der BohlenflÃ¤che der Saugstrom in seiner StrÃ¶mungsstÃ¤rke und -geschwindigkeit

so gering ist, daÃ er das Dichtelement 36 nicht in die SchlieÃstellung mitnehmen

kann. Somit darf der zwischen Dichtelement 36 und SchlieÃsitz 35 hindurchstrÃ¶mende

Saugstrom durch seine StÃ¤rke und 6Ã©schwindigkeit nicht das Gewicht des Dichtelementes

36 Ã¼bertreffen - er muÃ also immer kleiner als das Dichtelementgewicht sein.Here, the sealing element 36 is in the lower area in FIG. 2

shown open position, so that the suction flow between the sealing element 36 and the closing seat

35 can flow through into the channel 22. The sealing ball 36 remains during the

entire duration of the vacuum in the opening position. To be able to create the vacuum

and to avoid that the sealing ball 36 is in the closed position by the suction flow

is moved, the volume in the chamber 16a and the weight of the sealing element

36 are placed on one another in such a way that when the suction element 16

on the screed surface the suction flow in its flow strength and speed

is so small that it does not take the sealing element 36 into the closed position

can. Thus, the flowing through between the sealing element 36 and the closing seat 35 is allowed

Suction flow due to its strength and speed does not affect the weight of the sealing element

36 - it must therefore always be smaller than the weight of the sealing element.

Bei nicht vollflÃ¤chiger Auflage des Saugelementes 16 auf der BohlenflÃ¤che

wird durch die mitangesogene Bemdluft, die zwischen Bohlenkante und Saugelementrand

von unten in die Kammer 16a stÃ¤ndig mit angesogen wird, der Saugstrom in seiner

Kraft und Geschwindigkeit grÃ¶Ãer als das Gewicht des Dichtelementes 36 und somit

wird dieses Dichtelement 36 durch den Saugstrom mit nach oben in die SchlieÃstellung

mitgenommen- Das Dichtelement 36 legt sich dann abdichtend an den SchlieÃsitz 35

aN und wird durch den Saugstrom im Kanal 22 in dieser Schliestellung gehalten, so

daÃ in der Kammer 16a kein Vakuum erzeugt wird und dieses Saugelement

wirkungslos

bleibt.If the suction element 16 is not fully supported on the plank surface

is caused by the foreign air that is sucked in between the edge of the plank and the edge of the suction element

is constantly sucked in from below into the chamber 16a, the suction flow in its

Force and speed greater than the weight of the sealing element 36 and thus

this sealing element 36 is moved upwards into the closed position by the suction flow

taken along - The sealing element 36 then lies against the closing seat 35 in a sealing manner

aN and is held in this closed position by the suction flow in channel 22, see above

that no vacuum is generated in the chamber 16a and this suction element

ineffective

remain.

Da die Saugeinheit 10 mit einer Vielzahl an Saugelementen 16 ausgestattet

ist, wird gewÃ¤hrleistet, daÃ immer eine ausreichende Zahl als Sauger 16 wirksam

werden, d.h. unter Vakuum stehen und somit die Bohlen 12 fÃ¼r das Anheben und den

Transport halten. Die Saugeinheit 10 hat beim Ausfall einzelner Sauger 16 praktisch

bzw. ca. 50 % an Saugern 16 immer noch ihre voll Wirsamkeit.Since the suction unit 10 is equipped with a large number of suction elements 16

is, it is ensured that there is always a sufficient number as suction cups 16 effective

are, i.e. are under vacuum and thus the planks 12 for lifting and the

Hold transport. The suction unit 10 is practical in the event of failure of individual suction cups 16

or about 50% of suckers 16 are still fully effective.

Nachdem das Vakuum in den wirksamen Saugern 16 geschaffen worden ist,

fÃ¤hrt die Saugeinheit 10 durch die SÃ¤ulen 13 nach oben in die erforderliche HÃ¶he

und wird dann durch die Laufkatze 15 an den gewÃ¼nschten Ablageort verfahren. Nun

erfolgt das Ablegen der Bohlen 12, indem das Vakuum aufgehoben wird. Dieses geschieht

dadurch, daÃ das Saugleitungsventil 39 geschlossen wird, dadurch der Saugstrom in

den KanÃ¤len 22 in seiner Kraft vermindert wird und danndie Bohlen 12 durch ihr Gewicht

von den Saugelementen 16 nach unten abfallen kÃ¶nnen. Hierbei wird durch den in den

KanÃ¤len 22 noch vorhandenen Saugstrom jede bisher in Ã¶ffnungsstellung befindliche

Dichtkugel 36 in die SchlieÃstellung gebracht. Nun verfÃ¤hrt die Saugeinheit 10 wieder

zu dem Bohlenstapel zurÃ¼ck, um neue Bohlen 12 aufzunehmen.After the vacuum has been created in the effective suction cups 16,

the suction unit 10 moves up through the columns 13 to the required height

and is then moved by the trolley 15 to the desired storage location. so

the planks 12 are deposited by releasing the vacuum. This happens

in that the suction line valve 39 is closed, thereby the suction flow in

the channels 22 is reduced in strength and then the planks 12 by their weight

can fall down from the suction elements 16. The in the

Channels 22 still existing suction flow each previously in the open position

Sealing ball 36 brought into the closed position. Now the suction unit 10 moves again

back to the pile of planks to pick up new planks 12.

Nunmehr wird das Druckleitungsventil 40 geÃ¶ffnet, so daÃ Druckluft

in die KanÃ¤le 22 einstrÃ¶mt. Durch die Druckluft werden die Dichtkugeln 16 ruckartig

in die Uffnungsstellung gedrÃ¼ckt. Die dann nach unten aus den Saugern 16 ausstrÃ¶mende

Druckluft bewirkt einerseits eine Reinigung des Siebes 38 und andererseits werden

durch diese Druckluft

Verunreinigungen von der BohlenflÃ¤che weggeblasen,

so daÃ im Bereich jedes Saugers 16 die Bohlen 12 von Schmutz, SpÃ¤nen, Rindenteilen

od. dgl. weitestgehend automatisch beim Aufsetzen der Sauger 16 auf die Bohlen 12

gesÃ¤ubert werden. Doch noch verbleibende Unreinigungen werden durch das Sieb 38

beim nachfolgenden Vakuumbilden gegen Eindringen in den Kanal 22 gehindert und die

sich daran bzw. darin festsetzenden Verunreinigungen beim nachfolgenden Druckluftausblasen

wieder weggespÃ¼lt.Now the pressure line valve 40 is opened so that compressed air

flows into the channels 22. The sealing balls 16 are jerky due to the compressed air

pressed into the open position. The then flowing down from the suction cups 16

Compressed air causes on the one hand a cleaning of the sieve 38 and on the other hand

through this compressed air

Impurities blown away from the plank surface,

so that in the area of each suction cup 16 the planks 12 of dirt, chips, bark parts

or the like largely automatically when the suction cups 16 are placed on the planks 12

to be cleaned. However, any remaining impurities are passed through the sieve 38

in the subsequent vacuum formation prevented from penetrating into the channel 22 and the

Contaminants attached to them or in them when the compressed air is subsequently blown out

washed away again.

Sind die Kugeln 36 durch die Druckluft in die offnungsstellung gebracht

worden und haben die Sauger 16 auf den Bohlen 12 aufgesetzt, erfolgt automatisch

die Umschaltung der Ventile 40, 39, indem das Druckventil 40 geschlossen und das

Saugventil 39 geÃ¶ffnet wird, so daÃ ein neues Vakuum fÃ¼r das Anheben der Bohlen

12 erzeugt wird.Are the balls 36 brought into the open position by the compressed air

and if the suction cups 16 have been placed on the planks 12, this takes place automatically

the switching of the valves 40, 39 by the pressure valve 40 being closed and the

Suction valve 39 is opened, so that a new vacuum for lifting the planks

12 is generated.

Die Saugelement 16 kÃ¶nnen neben der kreisrunden Grundform auch eine

ovale, eine rechteckige oder quadratische, polygonale oder lÃ¤nglich (insbeeondere

fÃ¼r Leisten) Grundform haben.In addition to the circular basic shape, the suction element 16 can also have a

oval, a rectangular or square, polygonal or oblong (in particular

for strips) have a basic shape.

## Classifications

- B65G47/918
- B65G47/91
- B66C1/02
- B66C1/0212
- B66C1/0243

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
