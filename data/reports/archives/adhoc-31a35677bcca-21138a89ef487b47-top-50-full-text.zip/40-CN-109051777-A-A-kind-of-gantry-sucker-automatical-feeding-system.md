# 40. A kind of gantry sucker automatical feeding system

- **Archive rank:** 40 of 50
- **Publication:** [CN-109051777-A](https://patents.google.com/patent/CN109051777A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/064816539/publication/CN109051777A?q=pn%3DCN109051777A)
- **Publication date:** 2018-12-21
- **Filing date:** 2018-07-16
- **Earliest priority:** 2018-07-16
- **Family:** 64816539
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** JIANGSU LEEV INTELLIGENT EQUIPMENT CO LTD
- **Inventors:** YANG WANGUO

## Abstract

The invention discloses a kind of gantry sucker automatical feeding systems, it is related to furniture board manufacture field, including planer-type sucker transfer machine, belt roller combined type vertical-and-horizontal translation machine, two hydraulic lifting roller machines and control system, belt roller combined type vertical-and-horizontal translation machine is set to centre, hydraulic lifting roller machine is respectively in belt roller combined type vertical-and-horizontal translation machine two sides, planer-type sucker transfer machine is across above belt roller combined type vertical-and-horizontal translation machine and hydraulic lifting roller machine, planer-type sucker transfer machine, belt roller combined type vertical-and-horizontal translation machine and hydraulic lifting roller machine are controlled by control system.The present invention solves the problems, such as that artificial loading large labor intensity, work are uninteresting cumbersome.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf000.png)

![Sketch 1 for CN-109051777-A](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf001.png)

![Sketch 2 for CN-109051777-A](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf002.png)

![Sketch 3 for CN-109051777-A](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf003.png)

![Sketch 4 for CN-109051777-A](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf004.png)

![Sketch 5 for CN-109051777-A](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf005.png)

![Sketch 6 for CN-109051777-A](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf006.png)

![Sketch 7 for CN-109051777-A](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf007.png)

![Sketch 8 for CN-109051777-A](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf008.png)

![Sketch 9 for CN-109051777-A](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf009.png)

![Sketch 10 for CN-109051777-A](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf009.png)

[Sketch 11](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf010.png)

![Sketch 11 for CN-109051777-A](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf010.png)

[Sketch 12](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf011.png)

![Sketch 12 for CN-109051777-A](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf011.png)

[Sketch 13](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf012.png)

![Sketch 13 for CN-109051777-A](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf012.png)

[Sketch 14](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf013.png)

![Sketch 14 for CN-109051777-A](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf013.png)

[Sketch 15](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf014.png)

![Sketch 15 for CN-109051777-A](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf014.png)

[Sketch 16](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf015.png)

![Sketch 16 for CN-109051777-A](https://nimo.iptorch.com/refdrawing/CN-109051777-A/pdf015.png)

## Claims

### Claim 1 (independent)

a kind of gantry sucker automatical feeding system, it is characterised in that: including planer-type sucker transfer machine (1), belt roller group Box-like vertical-and-horizontal translation machine (2), two hydraulic lifting roller machines (3) and control system (4), the belt roller combined type are put down in length and breadth Telephone-moving (2) is set to centre, and the hydraulic lifting roller machine (3) is respectively in the belt roller combined type vertical-and-horizontal translation machine (2) two Side, the planer-type sucker transfer machine (1) are across the belt roller combined type vertical-and-horizontal translation machine (2) and the hydraulic lifting Above roller machine (3), the planer-type sucker transfer machine (1), the belt roller combined type vertical-and-horizontal translation machine (2) and described Hydraulic lifting roller machine (3) is controlled by the control system (4)； The planer-type sucker transfer machine (1) includes gantry stand (1-1), lateral walking mechanism (1-2), vertical lifting mechanism (1-3) and Suction cup assembly (1-4), the transverse direction walking mechanism (1-2) are installed on the gantry stand (1-1), described vertical Elevating mechanism (1-3) is installed on the lateral walking mechanism (1-2), and the Suction cup assembly (1-4) is installed on the vertical liter It can move up and down on descending mechanism (1-3) and with the vertical lifting mechanism (1-3)； The belt roller combined type vertical-and-horizontal translation machine (2) includes the power drum machine (2-1) that can be moved along longitudinal direction, can be transversely Movement and narrowband conveyer (2-2) with elevating function and plate can be made to put together the aligning device of snap along specific position (2-3), the narrowband conveyer (2-2) are rolled in the cylinder gap of the power drum machine (2-1) and lower than the power Cylinder machine (2-1), the aligning device (2-3) are set to the side of the power drum machine (2-1) and perpendicular to the power drums The cylinder axis of machine (2-1)； The hydraulic lifting roller machine (3) includes fork Jian's formula hydraulic elevator (3-1) and the roller conveying with positive and negative rotating function Machine (3-2).

### Claim 2

a kind of gantry sucker automatical feeding system according to claim 1, it is characterised in that: The transverse direction walking mechanism (1-2) includes lateral straight-line guide rail slide block (1-201), cross connecting plate (1-202), lateral line It walks synchronous pulley (1-203), laterally walking synchronous belt (1-204), lateral speed reducer for servo motor (1-205) and laterally walks to drag Chain (1-206), the transverse direction straight-line guide rail slide block (1-201) are installed on the side the gantry stand (1-1), the lateral connection Plate (1-202) and the lateral straight-line guide rail slide block (1-201) are fixed, the transverse direction speed reducer for servo motor (1-205), described Laterally walking synchronous pulley (1-203) is installed on the cross connecting plate (1-202) and the two links, and the laterally walking is same Step band both ends (1-204) are fixed on the gantry stand (1-1), and laterally walking drag chain (1-206) is set to described gantry In rack (1-1) and one end and the cross connecting plate (1-202) are fixed； The vertical lifting mechanism (1-3) includes vertical beam (1-301), vertical line guide rail slide block (1-302), vertical center web (1-303), vertical lift synchronous pulley are vertically moved up or down synchronous belt (1-304), vertical servo motor reducer (1-305) and hang down Drop drag chain (1-306) is gone straight up to, the vertical beam (1-301) is installed on the lateral walking mechanism (1-2), the vertical line Guide rail slide block (1-302) is installed on the vertical beam (1-301), the vertical center web (1-303) and the vertical line Guide rail slide block (1-302) is fixed, and the vertical servo motor reducer (1-305), the vertical lift synchronous pulley are installed on On the vertical center web (1-303) and the two links, and vertical lift synchronous belt (1-304) both ends are fixed on described vertical On beam (1-301), the vertical lift drag chain (1-306) be set to the vertical beam (1-301) on and one end with it is described vertical Connecting plate (1-303) is fixed； The Suction cup assembly (1-4) includes suction cup carrier (1-401), rectangular tube mounting rack (1-402), vacuum branch line (1- 403) it is installed on the vertical lifting mechanism (1-3) with vacuum chuck (1-404), the rectangular tube mounting rack (1-402), institute Vacuum branch line (1-403) is stated in the rectangular tube mounting rack (1-402), the suction cup carrier (1-401) is set to described Below rectangular tube mounting rack (1-402), the vacuum chuck (1-404) is installed on the suction cup carrier (1-401).

### Claim 3

a kind of gantry sucker automatical feeding system according to claim 2, it is characterised in that: the planer-type sucker moves Carrier aircraft (1) further includes planar inverted mechanism (1-5), and the planar inverted mechanism (1-5) includes fixed connecting base (1-501), turns over Rotating motor seat (1-502), overturning speed reducer for servo motor (1-503) and two Plane Rotation seats (1-504) are described to be fixedly connected Seat (1-501) is installed on the vertical beam (1-301), and the overturning motor cabinet (1-502) is set to the fixed connecting base (1- 501) below and one end is connect with the flange face of overturning speed reducer for servo motor (1-503), and the other end passes through bearing and turns Axis is connected with another Plane Rotation seat (1-504), it is described overturning speed reducer for servo motor (1-503) output end with it is described The flange face of Plane Rotation seat (1-504) connects, and the rectangular tube mounting rack (1-402) is installed on the Plane Rotation seat (1- 504) on.

### Claim 4

a kind of gantry sucker automatical feeding system according to claim 1, it is characterised in that: The power drum machine (2-1) includes roller rack (2-101), several power drums (2-102), drum drive line shaft (2-103), Rolling motor speed reducer (2-104), drum belt (2-105), the power drum (2-102) are installed on the rolling In cylinder rack (2-101), the drum drive line shaft (2-103), the Rolling motor speed reducer (2-104) are installed on the rolling Cylinder rack (2-101) inner sidewall, the drum drive line shaft (2-103) and the Rolling motor speed reducer (2-104) pass through chain Transmission connection, the every power drum (2-102) pass through the drum belt (2-105) and the drum drive line shaft respectively (2-103) connection； The narrowband conveyer (2-2) includes narrowband rack (2-211), several narrowband active synchronization belt wheels (2-212), several narrow With driven synchronous pulley (2-213), several narrow band sync belts (2-214), several narrowband universal driving shafts (2-215) and several belts Tensioning block (2-216), the narrowband active synchronization belt wheel (2-212), the narrowband driven synchronous pulley (2-213) are installed on institute It states on narrowband rack (2-211) and the two is connected by the narrow band sync belt (2-214), the belt tension block (2- 216) it is installed on the narrow band sync belt (2-214), the narrowband universal driving shaft (2-215) is by the narrowband active synchronization band Wheel (2-212) mutually concatenates and forms narrowband transmission line shaft； The narrowband conveyer (2-2) further includes narrowband elevating mechanism (2-22) and the narrowband transmission line shaft can be made in lifting The rotation driving belt mechanism (2-23) of rotation, the narrowband elevating mechanism (2-22) include elevator platform (2-221), lifting frame Frame (2-222), several lifting cylinders (2-223), four lifting rotation seats (2-224), four pieces of eccentric wobble plates (2-225), two Go up and down universal driving shaft (2-226), two lifting joining beams (2-227) and four lifter drawing bars (2-228), the elevator platform (2- 221) it is installed on the roller rack (2-101), the lifting cylinder (2-223), the lifting rotation seat (2-224) installation In on the elevator platform (2-221), the output end of the lifting cylinder (2-223) is connected with the lifting frame (2-222), The narrowband rack (2-211) is fixed on the lifting frame (2-222), positioned at two ipsilateral lifting rotation seats It is connected between (2-224) by the lifting universal driving shaft (2-226), the bias wobble plate (2-225) is linked set on the lifting On axis (2-226), it is located between the eccentric wobble plate (2-225) on two liftings universal driving shaft (2-226) and passes through The lifting joining beam (2-227) is connected, and one end of the lifter drawing bar (2-228) is fixed on the lifting frame (2-222), The other end is fixed on the eccentric wobble plate (2-225).

### Claim 5

a kind of gantry sucker automatical feeding system according to claim 4, it is characterised in that: the rotation driving belt Mechanism (2-23) includes upper swinging mechanism (2-231), bottom mechanism (2-232) and rotation motor reducer (2-233), the rotation Motor reducer (2-233) is installed on the roller rack (2-101), The upper swinging mechanism (2-231) includes upper wobble plate one (2-2311), upper wobble plate two (2-2312), upper swing connecting plate (2- 2313), synchronous pulley (2-2314), biserial synchronous pulley (2-2315), rotation universal driving shaft (2-2316), upper balance staff are moved in upper swing (2-2317), expansion set (2-2318) and upper pendulum synchronous belt (2-2319) are held, the upper wobble plate one (2-2311) passes through the upper pendulum Bearing (2-2317) is installed on the narrowband transmission line shaft, and the upper swing moves synchronous pulley (2-2314) and passes through the expansion set (2-2318) is fastened on the narrowband transmission line shaft, and the upper wobble plate one (2-2311) and the upper wobble plate two (2-2312) are logical It crosses the upper swing connecting plate (2-2313) to be connected, the rotation universal driving shaft (2-2316) is installed on the two (2- of upper wobble plate 2312) on, the biserial synchronous pulley (2-2315) is installed on the rotation universal driving shaft (2-2316), the upper pendulum synchronous belt (2-2319) connects the upper swing and moves synchronous pulley (2-2314) and the biserial synchronous pulley (2-2315)； The bottom mechanism (2-232) by the rotation universal driving shaft (2-2316) and the upper swinging mechanism (2-231) hingedly, institute State bottom mechanism (2-232) include lower wobble plate one (2-2321), lower wobble plate two (2-2322), lower swing connecting plate (2-2323), Bottom active synchronization belt wheel (2-2324), lower pendulum bearing (2-2325) and bottom synchronous belt (2-2326), the bottom are actively same Step belt wheel (2-2324) and the lower pendulum bearing (2-2325) are mounted on the motor shaft of the rotation motor reducer (2-233) Head, the lower wobble plate two (2-2322) are sleeved on the lower pendulum bearing (2-2325), the lower wobble plate one (2-2321) and institute It states lower wobble plate two (2-2322) to be connected by the lower swing connecting plate (2-2323), bottom synchronous belt (2-2326) connection The bottom active synchronization belt wheel (2-2324) and the biserial synchronous pulley (2-2315), lower wobble plate one (2-2321) peace On the rotation universal driving shaft (2-2316).

### Claim 6

a kind of gantry sucker automatical feeding system according to claim 1, it is characterised in that: Fork Jian's formula hydraulic elevator (3-1) include pedestal (3-101), several hydraulic cylinders (3-102), hydraulic station (3-103), Upper table surface (3-104) and Cha Jian mechanism (3-105), the Cha Jian mechanism (3-105) include interior fork, outer fork, the interior fork and institute State it is outer fork by intermediate rotary shaft it is hinged, the interior fork bottom is mounted on the pedestal (3-101) by shaft, the outer fork bottom It is connected on the pedestal (3-101) and the upper table surface (3-104) by roller-coaster respectively at the top of portion and the interior fork, institute It states the bottom hydraulic cylinder (3-102) and is articulated with the outer fork bottom, be articulated among the interior fork at the top of the hydraulic cylinder (3-102) Position； The roller conveyor (3-2) includes several conveying cylinders (3-201), feeder motor (3-202) and safety by shelves (3- 203) it, is connected with each other between every two conveying cylinders (3-201) by chain, the feeder motor (3-202) is installed on The side in the Roller conveyor middle position, the safety are arranged by shelves (3-203) higher than Roller conveyor two sides.

### Claim 7

a kind of gantry sucker automatical feeding system according to claim 1, it is characterised in that: the hydraulic lifting roller Independent photoelectric detection system is arranged in machine (3) both ends, and the photoelectric detection system detects on the hydraulic lifting roller machine (3) Do not have to send a signal to when material the control system (4), the control system (4) controls the hydraulic lifting roller machine (3) Position is minimized, artificial supplied materials is waited.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippersDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippers with at least two picking-up heads

Description

A kind of gantry sucker automatical feeding system

Technical field

The present invention relates to furniture board manufacture fields, more particularly to a kind of gantry sucker automatical feeding system.

Background technique

In the plate process of furniture industry, to be sent to some processing work for one piece one piece of whole stacking sheet supplied materials

Sequence is usually all manually piecemeal to move station to be added, artificial loading large labor intensity, is worked uninteresting cumbersome.

Summary of the invention

The present invention in view of the above technical problems, the shortcomings that overcoming the prior art, provides a kind of gantry sucker automatic charging system

System solves the demand that woodwork industry is fed to whole stacking sheet supplied materials piecemeal processing stations, reduces labor intensity.

In order to solve the above technical problems, the present invention provides a kind of gantry sucker automatical feeding system, including planer-type is inhaled

Disk transfer machine, belt roller combined type vertical-and-horizontal translation machine, two hydraulic lifting roller machines and control system, belt roller combined type

Vertical-and-horizontal translation machine is set to centre, and hydraulic lifting roller machine is respectively in belt roller combined type vertical-and-horizontal translation machine two sides, and planer-type is inhaled

Disk transfer machine is across above belt roller combined type vertical-and-horizontal translation machine and hydraulic lifting roller machine, planer-type sucker transfer machine,

Belt roller combined type vertical-and-horizontal translation machine and hydraulic lifting roller machine are controlled by control systemï¼

Planer-type sucker transfer machine includes gantry stand, lateral walking mechanism, vertical lifting mechanism and Suction cup assembly, is laterally walked

Mechanism is installed on gantry stand, and vertical lifting mechanism is installed in lateral walking mechanism, and Suction cup assembly is installed on vertical lift

It can move up and down in mechanism and with vertical lifting mechanismï¼

Belt roller combined type vertical-and-horizontal translation machine, which includes the power drum machine that can be moved along longitudinal direction, can transversely move and has, to be risen

It drops the narrowband conveyer of function and plate can be made to put together the aligning device of snap along specific position, narrowband conveyer is embedded in power

In the cylinder gap of roller machine and it is lower than power drum machine, aligning device is set to the side of power drum machine and rolls perpendicular to power

The cylinder axis of cylinder machineï¼

Hydraulic lifting roller machine includes fork Jian's formula hydraulic elevator and the roller conveyor with positive and negative rotating function.

Technical effect: the invention proposes one kind can substitute manually-operated automatic charging scheme, is inhaled using planer-type

Two station of disk transfer machine or so adsorbs the stacking sheet on hydraulic lifting roller machine, takes the transfer of one block to middle position

Belt roller combined type vertical-and-horizontal translation machine on, belt roller combined type vertical-and-horizontal translation machine to side run, by plate keep to the side to

Aligning device, then belt roller combined type vertical-and-horizontal translation machine is jacked and is moved forwards, the power drum being fed into front of gang drill

Plate is conveyed to pipeline on conveyer.Hydraulic lifting roller machine band function of auto-lift, when the plate for siphoning away a plane, liquid

Pressure lifting roller machine rises a panel thickness automatically, after hydraulic lifting roller machine rises to highest order, drops to automatically minimum

Position waits supplied materials, and planer-type sucker transfer machine starts to draw the plate on the elevator of the other side, and so on realizes continuous automatic

Feeding.The present invention solves the problems, such as that artificial loading large labor intensity, work are uninteresting cumbersome.

The technical solution that the present invention further limits is:

Further, lateral walking mechanism includes lateral straight-line guide rail slide block, cross connecting plate, laterally walking synchronous pulley, cross

Gantry stand is installed on to walking synchronous belt, lateral speed reducer for servo motor and lateral walking drag chain, lateral straight-line guide rail slide block

Side, cross connecting plate are fixed with lateral straight-line guide rail slide block, lateral speed reducer for servo motor, the laterally installation of walking synchronous pulley

It is fixed on gantry stand on cross connecting plate and the two linkage, synchronous belt both ends of laterally walking, drag chain of laterally walking is set to

On gantry stand and one end is fixed with cross connecting plateï¼

Vertical lifting mechanism includes vertical beam, vertical line guide rail slide block, vertical center web, is vertically moved up or down synchronous pulley, is vertical

Synchronous belt, vertical servo motor reducer and vertical lift drag chain, vertical beam is gone up and down to be installed in lateral walking mechanism, it is vertical straight

Line guide rail slide block is installed on vertical beam, and vertical center web is fixed with vertical line guide rail slide block, vertical servo motor reducer,

Vertical lift synchronous pulley is installed on vertical center web and the two links, and vertical beam is fixed at vertical lift synchronous belt both ends

On, vertical lift drag chain is set on vertical beam and one end is fixed with vertical center webï¼

Suction cup assembly includes suction cup carrier, rectangular tube mounting rack, vacuum branch line and vacuum chuck, and rectangular tube mounting rack is installed on

On vertical lifting mechanism, vacuum branch line is set in rectangular tube mounting rack, and suction cup carrier is set to below rectangular tube mounting rack, vacuum

Sucker is installed in suction cup carrier.

A kind of preceding gantry sucker automatical feeding system, planer-type sucker transfer machine further includes planar inverted mechanism,

Planar inverted mechanism includes fixed connecting base, overturning motor cabinet, overturning speed reducer for servo motor and two Plane Rotation seats, is fixed

Attachment base is installed on vertical beam, and overturning motor cabinet is set on fixed connecting base lower section and one end and overturning speed reducer for servo motor

Flange face connection, the other end is connected by bearing shaft with another Plane Rotation seat, and the output of speed reducer for servo motor is overturn

End is connect with the flange face of Plane Rotation seat, and rectangular tube mounting rack is installed on Plane Rotation seat.

A kind of preceding gantry sucker automatical feeding system, power drum machine include roller rack, several power drums,

Drum drive line shaft, Rolling motor speed reducer, drum belt, power drum are installed in roller rack, drum drive line shaft, rolling

Cylinder motor reducer is installed on roller rack inner sidewall, and drum drive line shaft is connect with Rolling motor speed reducer by chain conveyer,

Every power drum passes through drum belt and the total axis connection of drum drive respectivelyï¼

Narrowband conveyer includes narrowband rack, several narrowband active synchronization belt wheels, the driven synchronous pulley in several narrowbands, several narrowbands

Synchronous belt, several narrowband universal driving shafts and several belt tension blocks, the driven synchronous pulley installation in narrowband active synchronization belt wheel, narrowband

In in narrowband rack and the two is connected by narrow band sync belt, belt tension block is installed on narrow band sync belt, narrowband connection

Narrowband active synchronization belt wheel is mutually concatenated and forms narrowband transmission line shaft by moving axisï¼

Narrowband conveyer further includes narrowband elevating mechanism and narrowband can be made to be driven the rotation driving belt that line shaft is rotated in lifting

Mechanism, narrowband elevating mechanism include elevator platform, lifting frame, several lifting cylinders, four lifting rotation seats, four pieces of eccentric pendulum

Plate, two lifting universal driving shafts, two lifting joining beams and four lifter drawing bars, elevator platform are installed in roller rack, lifting air

Cylinder, lifting rotation seat are installed on elevator platform, and the output end of lifting cylinder is connected with lifting frame, and narrowband rack is fixed on liter

It drops on frame, is connected between two ipsilateral lifting rotation seats by lifting universal driving shaft, eccentric wobble plate is set to lifting linkage

It on axis, is located between the eccentric wobble plate that two go up and down on universal driving shaft and is connected by lifting joining beam, one end of lifter drawing bar is solid

Due on lifting frame, the other end is fixed in eccentric wobble plate.

A kind of preceding gantry sucker automatical feeding system, rotation driving belt mechanism includes upper swinging mechanism, downswing machine

Structure and rotation motor reducer, rotation motor reducer are installed in roller rack,

Upper swinging mechanism include upper wobble plate one, upper wobble plate two, upper swing connecting plate, upper swing move synchronous pulley, biserial synchronous pulley,

Rotation universal driving shaft, upper pendulum bearing, expansion set and upper pendulum synchronous belt, upper wobble plate one are installed on narrowband by upper pendulum bearing and are driven line shaft

On, upper swing is moved synchronous pulley and is fastened on narrowband transmission line shaft by expansion set, and upper wobble plate one and upper wobble plate two pass through upper swing

Connecting plate is connected, and rotation universal driving shaft is installed in wobble plate two, and biserial synchronous pulley is installed on rotation universal driving shaft, and upper pendulum synchronizes

Synchronous pulley and biserial synchronous pulley are moved in swing in band connectionï¼

Bottom mechanism is hinged by rotation universal driving shaft and upper swinging mechanism, and bottom mechanism includes lower wobble plate one, lower wobble plate two, lower swing

Connecting plate, bottom active synchronization belt wheel, lower pendulum bearing and bottom synchronous belt, bottom active synchronization belt wheel and lower pendulum bearing are mounted on

The motor shaft head of rotation motor reducer, lower wobble plate two are sleeved on lower pendulum bearing, and lower wobble plate one and lower wobble plate two-way cross the bottom

Dynamic connecting plate is connected, and the synchronous band connection bottom active synchronization belt wheel of the bottom and biserial synchronous pulley, lower wobble plate one are mounted on rotation

On universal driving shaft.

A kind of preceding gantry sucker automatical feeding system, fork Jian's formula hydraulic elevator include pedestal, several hydraulic cylinders,

Hydraulic station, upper table surface and Cha Jian mechanism, Cha Jian mechanism include interior fork, outer fork, and interior fork and outer fork are hinged by intermediate rotary shaft, interior fork

Bottom is mounted on the base by shaft, is connected to pedestal and upper table surface by roller-coaster respectively at the top of outer fork bottom and interior fork

On, hydraulic cylinder bottom is articulated with outer fork bottom, and position among interior fork is articulated at the top of hydraulic cylinderï¼

Roller conveyor includes that several conveying cylinders, feeder motor and safety pass through chain between shelves, every two conveying cylinders

It is connected with each other, feeder motor is installed on the side in Roller conveyor middle position, and safety is arranged by shelves higher than Roller conveyor two sides.

Independent Photoelectric Detection is arranged in a kind of preceding gantry sucker automatical feeding system, hydraulic lifting roller machine both ends

Device, photoelectric detection system, which detects, not to be had to send a signal to control system, control system when material on hydraulic lifting roller machine

Control hydraulic lifting roller machine minimizes position, waits artificial supplied materials.

The beneficial effects of the present invention are:

(1) the motor shaft rotation opposite with bottom mechanism that the present invention realizes rotation motor reducer by rotation driving belt mechanism

Turn, the relative rotation between bottom mechanism and upper swinging mechanism between relative rotation and upper swinging mechanism and narrowband transmission line shaft, and

And power is transferred to by narrowband by upper pendulum synchronous belt, bottom synchronous belt and is driven line shaft, when realizing the lifting of narrowband conveyer with this

Power continues and followsï¼

(2) present invention realizes vacuum breaker when Suction cup assembly draws plate by planar inverted mechanism, prevents that multilayer plates are suckedï¼

(3) present invention uses double-station feeding system, realizes continuous production, reduces downtime, improves production efficiency, increases

Production capacity.

Detailed description of the invention

Fig. 1 is overall schematic of the inventionï¼

Fig. 2 is planer-type sucker transfer machine schematic diagram in the present inventionï¼

Fig. 3 is structural scheme of mechanism of laterally walking in the present inventionï¼

Fig. 4 is vertical lifting mechanism schematic diagram in the present inventionï¼

Fig. 5 is planar inverted structural scheme of mechanism in the present inventionï¼

Fig. 6 is Suction cup assembly schematic diagram in the present inventionï¼

Fig. 7 is belt roller combined type vertical-and-horizontal translation machine schematic diagram in the present inventionï¼

Fig. 8 is belt roller combined type vertical-and-horizontal translation machine explosive view in the present inventionï¼

Fig. 9 is power drum machine schematic diagram in the present inventionï¼

Figure 10 is narrowband conveyer schematic diagram in the present inventionï¼

Figure 11 is rotation driving belt structural scheme of mechanism in the present inventionï¼

Figure 12 is upper swinging mechanism schematic diagram in the present inventionï¼

Figure 13 is bottom structural scheme of mechanism in the present inventionï¼

Figure 14 is narrowband elevating mechanism schematic diagram in the present inventionï¼

Figure 15 is hydraulic lifting roller machine schematic diagram in the present inventionï¼

Figure 16 is that Jian's formula hydraulic elevator schematic diagram is pitched in the present inventionï¼

Figure 17 is roller conveyor schematic diagram in the present inventionï¼

Wherein: 1, planer-type sucker transfer machineï¼2, belt roller combined type vertical-and-horizontal translation machineï¼3, hydraulic lifting roller machineï¼4, it controls

System processedï¼1-1 gantry standï¼1-2, lateral walking mechanismï¼1-201, lateral straight-line guide rail slide blockï¼1-202, cross connecting plateï¼

1-203, laterally walking synchronous pulleyï¼1-204, laterally walking synchronous beltï¼1-205, lateral speed reducer for servo motorï¼1-206, cross

To walking drag chainï¼1-3, vertical lifting mechanismï¼1-301, vertical beamï¼1-302, vertical line guide rail slide blockï¼1-303, vertically connect

Fishplate barï¼1-304, vertical lift synchronous beltï¼1-305, vertical servo motor reducerï¼1-306, vertical lift drag chainï¼1-4, suction

Disk componentï¼1-401, suction cup carrierï¼1-402, rectangular tube mounting rackï¼1-403, vacuum branch lineï¼1-404, vacuum chuckï¼1-5,

Planar inverted mechanismï¼1-501, fixed connecting baseï¼1-502, overturning motor cabinetï¼1-503, overturning speed reducer for servo motorï¼1-

504, Plane Rotation seatï¼2-1, power drum machineï¼2-101, roller rackï¼2-102, power drumï¼2-103, drum drive are total

Axisï¼2-104, Rolling motor speed reducerï¼2-105, drum beltï¼2-2, narrowband conveyerï¼2-211, narrowband rackï¼It is 2-212, narrow

Band active synchronization belt wheelï¼The driven synchronous pulley in 2-213, narrowbandï¼2-214, narrow band sync beltï¼2-215, narrowband universal driving shaftï¼2-

216, belt tension blockï¼2-22, narrowband elevating mechanismï¼2-221, elevator platformï¼2-222, lifting frameï¼2-223, lifting air

Cylinderï¼2-224, lifting rotation seatï¼2-225, eccentric wobble plateï¼2-226, lifting universal driving shaftï¼2-227, lifting joining beamï¼2-228, lifting

Pull rodï¼2-23, rotation driving belt mechanismï¼2-231, upper swinging mechanismï¼2-2311, upper wobble plate oneï¼2-2312, upper wobble plate twoï¼2-

2313, upper swing connecting plateï¼Synchronous pulley is moved in 2-2314, upper swingï¼2-2315, biserial synchronous pulleyï¼2-2316, rotation linkage

Axisï¼2-2317, upper pendulum bearingï¼2-2318, expansion setï¼2-2319, upper pendulum synchronous beltï¼2-232, bottom mechanismï¼2-2321, lower wobble plate

Oneï¼2-2322, lower wobble plate twoï¼2-2323, lower swing connecting plateï¼2-2324, bottom active synchronization belt wheelï¼2-2325, lower balance staff

It holdsï¼2-2326, bottom synchronous beltï¼2-233, rotation motor reducerï¼2-3, aligning deviceï¼3-1, fork Jian's formula hydraulic elevatorï¼

3-101, pedestalï¼3-102, hydraulic cylinderï¼3-103, hydraulic stationï¼3-104, upper table surfaceï¼3-105, Cha Jian mechanismï¼3-2, roller conveying

Machineï¼3-201, conveying cylinderï¼3-202, feeder motorï¼3-203, safety lean on shelves.

Specific embodiment

A kind of gantry sucker automatical feeding system provided in this embodiment, structure is as shown in Figure 1, include that planer-type sucker moves

Carrier aircraft 1,2, two hydraulic lifting roller machines 3 of belt roller combined type vertical-and-horizontal translation machine and control system 4, belt roller combined type

Vertical-and-horizontal translation machine 2 is set to centre, and hydraulic lifting roller machine 3 is respectively in 2 two sides of belt roller combined type vertical-and-horizontal translation machine, planer-type

Sucker transfer machine 1 is across 3 top of belt roller combined type vertical-and-horizontal translation machine 2 and hydraulic lifting roller machine, and planer-type sucker moves

Carrier aircraft 1, belt roller combined type vertical-and-horizontal translation machine 2 and hydraulic lifting roller machine 3 are controlled by control system 4.

As shown in Fig. 2, planer-type sucker transfer machine 1 includes gantry stand 1-1, lateral walking mechanism 1-2, vertical conveyor

Structure 1-3 and Suction cup assembly 1-4, lateral walking mechanism 1-2 are installed on gantry stand 1-1, and vertical lifting mechanism 1-3 is installed on cross

To on walking mechanism 1-2, Suction cup assembly 1-4 is installed on vertical lifting mechanism 1-3 and can be with moving down on vertical lifting mechanism 1-3

It is dynamic.

As shown in figure 3, transverse direction walking mechanism 1-2 includes lateral straight-line guide rail slide block 1-201, cross connecting plate 1-202, cross

To walking synchronous pulley 1-203, lateral walking synchronous belt 1-204, transverse direction speed reducer for servo motor 1-205 and lateral walking drag chain

1-206, lateral straight-line guide rail slide block 1-201 are installed on the side gantry stand 1-1, and cross connecting plate 1-202 is led with lateral straight line

Rail sliding block 1-201 is fixed, and lateral speed reducer for servo motor 1-205, laterally walking synchronous pulley 1-203 is installed on cross connecting plate

1-202 is upper and the two links, and the both ends synchronous belt 1-204 of laterally walking are fixed on gantry stand 1-1, and laterally walk drag chain 1-

206 on gantry stand 1-1 and one end is fixed with cross connecting plate 1-202.

As shown in figure 4, vertical lifting mechanism 1-3 includes vertical beam 1-301, vertical line guide rail slide block 1-302, vertically connects

Fishplate bar 1-303, vertical lift synchronous pulley, vertical lift synchronous belt 1-304, vertical servo motor reducer 1-305 and vertical

Drag chain 1-306 is gone up and down, vertical beam 1-301 is installed on lateral walking mechanism 1-2, and vertical line guide rail slide block 1-302 is installed on

On vertical beam 1-301, vertical center web 1-303 is fixed with vertical line guide rail slide block 1-302, vertical servo motor reducer 1-

305, vertical lift synchronous pulley is installed on vertical center web 1-303 and the two links, and is vertically moved up or down the both ends synchronous belt 1-304

It is fixed on vertical beam 1-301, vertical lift drag chain 1-306 is set to vertical beam 1-301 upper and one end and vertical center web 1-

303 is fixed.

As shown in fig. 6, Suction cup assembly 1-4 includes suction cup carrier 1-401, rectangular tube mounting rack 1-402, vacuum branch line 1-

403 and vacuum chuck 1-404, rectangular tube mounting rack 1-402 are installed on vertical lifting mechanism 1-3, vacuum branch line 1-403

In rectangular tube mounting rack 1-402, suction cup carrier 1-401 is set to below rectangular tube mounting rack 1-402, vacuum chuck 1-404 peace

Loaded on suction cup carrier 1-401.

As shown in figure 5, planer-type sucker transfer machine 1 further includes planar inverted mechanism 1-5, planar inverted mechanism 1-5 includes

Fixed connecting base 1-501, overturning motor cabinet 1-502, overturning speed reducer for servo motor 1-503 and two Plane Rotation seat 1-504,

Fixed connecting base 1-501 is installed on vertical beam 1-301, and overturning motor cabinet 1-502 is set to below fixed connecting base 1-501 and it

One end is connect with the flange face of overturning speed reducer for servo motor 1-503, and the other end passes through bearing shaft and another Plane Rotation seat

1-504 is connected, and the output end of overturning speed reducer for servo motor 1-503 is connect with the flange face of Plane Rotation seat 1-504, rectangular tube

Mounting rack 1-402 is installed on Plane Rotation seat 1-504.

As shown in Figure 7,8, belt roller combined type vertical-and-horizontal translation machine 2 include can move along longitudinal direction power drum machine 2-1,

Can transversely move and with elevating function narrowband conveyer 2-2 and can make plate along specific position put together snap to just

Device 2-3, narrowband conveyer 2-2 are in the cylinder gap of power drum machine 2-1 and are lower than power drum machine 2-1, to formal dress

2-3 is set set on the side of power drum machine 2-1 and perpendicular to the cylinder axis of power drum machine 2-1.

As shown in figure 9, power drum machine 2-1 includes that roller rack 2-101, several power drum 2-102, drum drive are total

Axis 2-103, Rolling motor speed reducer 2-104, drum belt 2-105, power drum 2-102 are installed on roller rack 2-101,

Drum drive line shaft 2-103, Rolling motor speed reducer 2-104 are installed on roller rack 2-101 inner sidewall, drum drive line shaft 2-

103 are connect with Rolling motor speed reducer 2-104 by chain conveyer, and every power drum 2-102 passes through drum belt 2-105 respectively

It is connect with drum drive line shaft 2-103.

As shown in Figure 10, narrowband conveyer 2-2 include narrowband rack 2-211, several narrowband active synchronization belt wheel 2-212,

The driven synchronous pulley 2-213 in several narrowbands, several narrow band sync belt 2-214, several narrowband universal driving shaft 2-215 and several belts

Tensioning block 2-216, the driven synchronous pulley 2-213 in narrowband active synchronization belt wheel 2-212, narrowband are installed on narrowband rack 2-211

And the two, by narrow band sync belt 2-214 connection, belt tension block 2-216 is installed on narrow band sync belt 2-214, narrowband

Narrowband active synchronization belt wheel 2-212 is mutually concatenated and is formed narrowband transmission line shaft by universal driving shaft 2-215.

As shown in figure 14, conveyer 2-2 in narrowband further includes narrowband elevating mechanism 2-22 and narrowband transmission line shaft can be made to rise

The rotation driving belt mechanism 2-23 rotated when drop, narrowband elevating mechanism 2-22 include elevator platform 2-221, lifting frame 2-

222, several lifting cylinder 2-223, four lifting rotation seat 2-224, four pieces of eccentric wobble plate 2-225, two lifting universal driving shaft 2-

226, two lifting joining beam 2-227 and four lifter drawing bar 2-228, elevator platform 2-221 are installed on roller rack 2-101,

Lifting cylinder 2-223, lifting rotation seat 2-224 are installed on elevator platform 2-221, the output end and liter of lifting cylinder 2-223

It drops frame 2-222 to be connected, narrowband rack 2-211 is fixed on lifting frame 2-222, positioned at two ipsilateral lifting rotation seat 2-

It is connected between 224 by lifting universal driving shaft 2-226, eccentric wobble plate 2-225 is set on lifting universal driving shaft 2-226, is located at two

Root, which is gone up and down, to be connected between the eccentric wobble plate 2-225 on universal driving shaft 2-226 by lifting joining beam 2-227, and the one of lifter drawing bar 2-228

End is fixed on lifting frame 2-222, and the other end is fixed on eccentric wobble plate 2-225.

As shown in Figure 11,12,13, rotation driving belt mechanism 2-23 includes upper swinging mechanism 2-231, bottom mechanism 2-232

It is installed on roller rack 2-101 with rotation motor reducer 2-233, rotation motor reducer 2-233, upper swinging mechanism 2-231

Including upper one 2-2311 of wobble plate, two 2-2312 of upper wobble plate, upper swing connecting plate 2-2313, upper swing move synchronous pulley 2-2314,

Biserial synchronous pulley 2-2315, rotation universal driving shaft 2-2316, upper pendulum bearing 2-2317, expansion set 2-2318 and upper pendulum synchronous belt 2-

2319, upper one 2-2311 of wobble plate are installed on narrowband by upper pendulum bearing 2-2317 and are driven on line shaft, and synchronous pulley 2- is moved in upper swing

2314, which are fastened on narrowband by expansion set 2-2318, is driven on line shaft, and upper one 2-2311 of wobble plate and two 2-2312 of upper wobble plate pass through upper pendulum

Dynamic connecting plate 2-2313 is connected, and rotation universal driving shaft 2-2316 is installed on two 2-2312 of wobble plate, biserial synchronous pulley 2-2315

It is installed on rotation universal driving shaft 2-2316, it is synchronous with biserial to move synchronous pulley 2-2314 for swing in upper pendulum synchronous belt 2-2319 connection

Belt wheel 2-2315ï¼Bottom mechanism 2-232 is hinged by rotation universal driving shaft 2-2316 and upper swinging mechanism 2-231, bottom mechanism 2-232

Including lower one 2-2321 of wobble plate, two 2-2322 of lower wobble plate, lower swing connecting plate 2-2323, bottom active synchronization belt wheel 2-2324,

Lower pendulum bearing 2-2325 and the bottom synchronous belt 2-2326, bottom active synchronization belt wheel 2-2324 and lower pendulum bearing 2-2325 are mounted on

The motor shaft head of rotation motor reducer 2-233, lower two 2-2322 of wobble plate are sleeved on lower pendulum bearing 2-2325, lower one 2- of wobble plate

2321 are connected with lower two 2-2322 of wobble plate by lower swing connecting plate 2-2323, and the bottom synchronous belt 2-2326 connection bottom is actively same

Belt wheel 2-2324 and biserial synchronous pulley 2-2315 is walked, lower one 2-2321 of wobble plate is mounted on rotation universal driving shaft 2-2316.

As shown in figure 15, hydraulic lifting roller machine 3 includes fork Jian's formula hydraulic elevator 3-1 and the rolling with positive and negative rotating function

Cylinder conveyer 3-2.

As shown in figure 16, fork Jian's formula hydraulic elevator 3-1 includes pedestal 3-101, several hydraulic cylinder 3-102, hydraulic station 3-

103, upper table surface 3-104 and Cha Jian mechanism 3-105, Cha Jian mechanism 3-105 includes interior fork, outer fork, and interior fork and outer fork pass through centre

Shaft is hinged, and interior fork bottom is mounted on pedestal 3-101 by shaft, passes through roller-coaster respectively at the top of outer fork bottom and interior fork

It is connected on pedestal 3-101 and upper table surface 3-104, the bottom hydraulic cylinder 3-102 is articulated with outer fork bottom, the top hydraulic cylinder 3-102

It is articulated with position among interior fork.

As shown in figure 17, roller conveyor 3-2 includes several conveying cylinder 3-201, feeder motor 3-202 and safety by shelves

It is connected with each other between 3-203, every two conveying cylinder 3-201 by chain, feeder motor 3-202 is installed on Roller conveyor interposition

The side set, safety are arranged by shelves 3-203 higher than Roller conveyor two sides.Independent photoelectricity inspection is arranged in 3 both ends of hydraulic lifting roller machine

Device is surveyed, photoelectric detection system, which detects, does not have to send a signal to control system 4 when material on hydraulic lifting roller machine 3, control

System 4 controls hydraulic lifting roller machine 3 and minimizes position, waits artificial supplied materials.

The course of work: whole lamination material is manually pushed to hydraulic lifting roller machine by no-power drum equipment such as vehicle of vacillating

On 3, photoelectric detection system sends a signal to control system 4 after detecting supplied materials, and control system 4 controls hydraulic lifting roller machine 3

The height that planer-type sucker transfer machine 1 can grab is risen to, it is standbyï¼When control system 4 has feeding order, planer-type sucker

Transfer machine 1 is moved to corresponding 3 top of hydraulic lifting roller machine along the x axis, then moves down along Y-axis, passes through sucker group

Part 1-4 draws a laminate part, and planar inverted mechanism 1-5 rotates an angle along Z axis and returns again justï¼Planer-type sucker transfer machine

1 rises to highest order along Y-axis, then returns to above belt roller combined type vertical-and-horizontal translation machine 2 along X-axis, under Y-axis, by plate

It is placed on belt roller combined type vertical-and-horizontal translation machine 2, discharges vacuum.

After planer-type sucker transfer machine 1 grabs a laminate part, hydraulic liter is controlled by photoelectric detection system and control system 4

The height that roller machine 3 rises laminate thickness drops, and standby, planer-type sucker transfer machine 1 goes to grab next laminate part again.It is placed on belt

Plate on roller combined type vertical-and-horizontal translation machine 2 is transported ahead to processing stations, snap side and jacks.Photoelectric detection system inspection

It measures after there is no material on hydraulic lifting roller machine 3, which is reduced to lowest order to wait artificial supplied materials, dragon

Gate-type sucker transfer machine 1 moves to operation on other side hydraulic lifting roller machine 3.And so on.

The present invention is gang drill automatic feed scheme, but is not limited only to gang drill feeding.

In addition to the implementation, the present invention can also have other embodiments.It is all to use equivalent substitution or equivalent transformation shape

At technical solution, fall within the scope of protection required by the present invention.

## Classifications

- B65G47/918
- B65G47/91

## Cited patent documents

- [CN-104876025-A](https://patents.google.com/patent/CN104876025A/en) — SEA
- [CN-105397872-A](https://patents.google.com/patent/CN105397872A/en) — SEA
- [CN-108045674-A](https://patents.google.com/patent/CN108045674A/en) — SEA
- [CN-204999261-U](https://patents.google.com/patent/CN204999261U/en) — SEA
- [CN-205328521-U](https://patents.google.com/patent/CN205328521U/en) — SEA
- [CN-207046438-U](https://patents.google.com/patent/CN207046438U/en) — SEA
- [CN-207273223-U](https://patents.google.com/patent/CN207273223U/en) — SEA
- [CN-208948347-U](https://patents.google.com/patent/CN208948347U/en) — SEA
- [JP-H11171334-A](https://patents.google.com/patent/JPH11171334A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
