# 50. Control device in vacuum hoist means

- **Archive rank:** 50 of 50
- **Publication:** [EP-0447384-A3](https://patents.google.com/patent/EP0447384A3/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/020378852/publication/EP0447384A3?q=pn%3DEP0447384A3)
- **Publication date:** 1992-03-04
- **Filing date:** 1991-03-13
- **Earliest priority:** 1990-03-14
- **Family:** 20378852
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Abstract

_No abstract was available from the queried sources._

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/EP-0447384-A3/pdf000.png)

![Sketch 1 for EP-0447384-A3](https://nimo.iptorch.com/refdrawing/EP-0447384-A3/pdf000.png)

## Claims

### Claim 1 (independent)

Control device in vacuum hoist means ( 1 - 11 ) for goods or other objets, which can be connected to a stationary or movable anchoring point (6) and is provided with a member to grip said goods (3), said member being vertically movable in relation to said anchoring point (6), said means (1-11) . comprising a tubular container (1) closed at both ends, the upper end of which is connectable to said anchoring point (6) and the lower end of which is intended via a suction body (3) connected thereto to cooperate with the goods to be moved, and wherein the wall material between the ends of which container (1) is partially or entirely compressible in axial direction, and wherein a connection is provided on the container, preferably at its upper end, for connection to a vacuum-generating means (5), said means ( 1 - 11 ) being provided with control and valve means (4 and 11) to control the vacuum in the tubular container (1) so that its length in axial direction can be altered, which control and valve means (4 and 11 ) are preferably arranged close to the lower end of the container (1) and so designed that the valve means (11) can be brought by means of said control means (4) into a fully open state either steplessly or in two steps, and which means (1-11) is preferably provided at the lower end of the container (1) with an additional valve to openor close a channel between the lower end of the container (1) and the suction body (3), which valve consists of a spring-loaded sealing body which is displaced by the goods when the suction body (3) approaches the goods, thereby opening the channel so that the goods can be adhered by means of suction, characterised in that the vacuum-generating means (5) is connected via an operable valve (7) to the surroundings or to a blast air source, which valve (7)is preferably steplessly adjustable so that the hoisting speed of the hoist means ( 1-11 ) is reduced when air is supplied from the last-mentioned valve (7).

## Full description

**[0001]**

The present invention relates to a control device in vacuum hoist means. This may be of the type described in US Patent 4 413 853 granted 8 November, 1983, for instance. In known hoist means the speed of the lowering movement can be controlled but it is impossible to control the speed of the hoisting movement. This is a considerable drawback.

**[0002]**

The object of the present invention is to eliminate this drawback and this is achieved by supplying the vacuum-generating means with air from outside with the aid of a valve and a control device. The air supplied can be regulated from a value O up to a predetermined maximum amount. Usually the vacuum-generating means will cease to draw air out of the vacuum-generating means when the maximum amount of air is supplied in parallel with air from the hoist means. In the latter case a non-return valve provided on the hoist means will close and the hoist means will stop its movement. The air supplied from the outside thus supplies the vacuum-generating means with air in parallel with air from the actual hoist means.

**[0003]**

During lowering movements the hoist means can be controlled by means of a valve which valve can be caused by a control device to steplessly open very slightly and thereafter open to its fullest extent.

**[0004]**

In known hoist means air is withdrawn from the upper end of the container. However, air can also be withdrawn from the lower end of the container. The present invention will be described more fully with reference to the accompany drawings in which

### Figure 1 shows schematically a hoist means seen from the side and

**[0005]**

Figure 2 shows the said hoist means seen from below.

**[0005]**

The drawings show an anchoring point 6, the container 1 of a vacuum hoist means, and a suction foot 3 arranged at the lower end 2. Said lower end is provided with manual control 4 and a vacuum-generating means is also also connected to the lower end 2. The vacuum-generating means 5 is provided with a non-return valve 10 which closes the connection to the container 1 when no suction prevails. The manual control 4 is connected to a steplessly variable valve which is connected both to an air intake 8 and to an air intake 9 on the vacuum-generating means 5. The control 4 also influences a second valve 11 which can be steplessly varied from a fully closed position to a position in which it is open to a predetermined extent.

**[0006]**

The vacuum-generating means described functions in the following manner: It is assumed that the valve 11 is closed and that the vacuum-generating member has been activated to withdraw air from the container 1. A suction foot with load or closed valve will then move upwards at a specific speed. If increased speed is desired, the stepless valve 7 is influenced so that air from the intake 8 is supplied to the air intake 9 of the vacuum-generating means. The air coming from the air intake 9 will thus be drawn off by the vacuum-generating means in parallel with air from the container 1. All air supplied to the cacuum- generation means 5 from the air intake 8 will reduce the upward speed until the vacuumgenerating means 5 is only able to pass on air from the intake 8 but not from the container 1.

**[0007]**

If the raised hoist means is now to be lowered, the manual control 4 must be utilized to influence the stepless valve 11, whereupon the suction foot 3 will move downwards at a speed which is dependent on the opening of the valve 11.

**[0008]**

A vacuum hoist means has thus been created in which both the upward speed and the downward speed can be controlled steplessly with the aid of two valve systems 7 and 11.

## Classifications

- B66C1/0256
- B66C1/02
- B66C1/0212
- B66C1/0293
- B66F3/24
- B66F3/242

## Cited patent documents

- [CH-526461-A](https://patents.google.com/patent/CH526461A/en) — SEA
- [DE-1431936-A1](https://patents.google.com/patent/DE1431936A1/en) — SEA
- [FR-1474799-A](https://patents.google.com/patent/FR1474799A/en) — SEA
- [FR-2370660-A1](https://patents.google.com/patent/FR2370660A1/en) — SEA
- [GB-2200615-A](https://patents.google.com/patent/GB2200615A/en) — SEA
- [GB-376110-A](https://patents.google.com/patent/GB376110A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
