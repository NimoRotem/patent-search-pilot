# 49. A lifting device and a method of lifting

- **Archive rank:** 49 of 50
- **Publication:** [WO-2025073328-A1](https://patents.google.com/patent/WO2025073328A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/093100435/publication/WO2025073328A1?q=pn%3DWO2025073328A1)
- **Publication date:** 2025-04-10
- **Filing date:** 2024-10-02
- **Earliest priority:** 2023-10-02
- **Family:** 93100435
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** COBOT LIFT APS
- **Inventors:** TRUELSEN FLEMMING BISCHOFF

## Abstract

A The invention relates to a lifting system for baggage comprising a hoisting tube attached or fixed to a suction pad (5). A vacuum source subjects an inner volume of the hoisting tube (12) to a low pressure such that the hoisting tube provides a lifting force. A longitudinal member (11) comprising a sliding member (10) is connected to the hoisting tube (12), the sliding member is configured to slide in two directions between a first and a second end position along the longitudinal member (11), the longitudinal member (11) is provided with a valve opening (13) extending in the longitudinal direction of the wall of the longitudinal member (11) such that the valve opening (13) allows air to flow between the inner volume of the hoisting tube and the 10 surroundings, the valve opening (13) and sliding member (11) being mutually adapted such that the valve opening (13) may be covered or partly covered by the sliding member (11) when the sliding member is at the first end position whereas the valve opening (13) becomes gradually more exposed when the sliding member is moved from the first end position and towards the second end position, wherein, the system comprises a position sensor capable of measuring the position of the sliding member on the longitudinal member, which position sensor is connected to the electronic controller so that during lifting operations the electronic controller adjust the vacuum source depending on the sliding members (11) position on the longitudinal member (11).

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/WO-2025073328-A1/ops000.png)

![Sketch 1 for WO-2025073328-A1](https://nimo.iptorch.com/refdrawing/WO-2025073328-A1/ops000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/WO-2025073328-A1/ops001.png)

![Sketch 2 for WO-2025073328-A1](https://nimo.iptorch.com/refdrawing/WO-2025073328-A1/ops001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/WO-2025073328-A1/ops002.png)

![Sketch 3 for WO-2025073328-A1](https://nimo.iptorch.com/refdrawing/WO-2025073328-A1/ops002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/WO-2025073328-A1/ops003.png)

![Sketch 4 for WO-2025073328-A1](https://nimo.iptorch.com/refdrawing/WO-2025073328-A1/ops003.png)

## Claims

### Claim 1

Claims 1. A lifting system for baggage comprising a hoisting tube (12) connected to an adjustable vacuum source being controllable via an electronic controller, the hoisting tube (12) is attached or fixed to a suction pad (5) comprising an inner volume and an edge providing an essentially air-tight closure when it is in contact with a baggage-object during lifting operation, the vacuum source subjects an inner volume of the hoisting tube (12) to a low pressure and the inner volume of the hoisting tube (12) is connected to the inner volume of the suction pad (5) such that air flow from one to the other, the hoisting tube provides a lifting force when the air pressure outside the hoisting tube is higher than the air pressure inside the hoisting tubes inner volume, a longitudinal member (11) comprising a sliding member (10) is connected to the hoisting tube (12), the sliding member is configured to slide in two directions between a first and a second end position along the longitudinal member (11), the longitudinal member (11) is provided with a valve opening (13) extending in the longitudinal direction of the wall of the longitudinal member (11) such that the valve opening (13) allows air to flow between the inner volume of the hoisting tube and the surroundings, the valve opening (13) and sliding member (11) being mutually adapted such that the valve opening (13) may be covered or partly covered by the sliding member (11) when the sliding member is at the first end position whereas the valve opening (13) becomes gradually more exposed when the sliding member is moved from the first end position and towards the second end position, wherein, the system comprises a position sensor capable of measuring the position of the sliding member on the longitudinal member, which position sensor is connected to the electronic controller so that during lifting operations the electronic controller adjust the vacuum source depending on the sliding members (11) position on the longitudinal member (11). 2. A lifting system for baggage according to claim 1, wherein the position sensor is situated on the sliding member and measures the distance between it and a point preferably being a point being near to the upper end or the lower end of the longitudinal member. 3. A lifting system for baggage according to claim 1 or 2, wherein the position sensor is situated on the sliding member and measures the distance between it and a point/location on the longitudinal member. 4. A lifting system for baggage according to claim 1, wherein the position sensor is situated near to or on the longitudinal member and measures the distance between it and a point/location on the sliding member. 5. A lifting system for baggage according to any of the claims 1-4, wherein, the position sensor is an ultrasonic sensor. 6. A lifting system for baggage according to any of the claims 1-5, wherein, the position sensor is an optical positioning sensor. 7. A lifting system for baggage according to any of the claims 1-6, wherein, the position sensor is an optical laser positioning sensor. 8. A lifting system for baggage according to any of the claims 1-7, wherein the electronic controller during lifting operations continuously adjusts the vacuum source such that the pressure inside the hoisting tube decreases (increases the vacuum) when the position sensor measures that the sliding member is positioned above a given point on the longitudinal member. 9. A lifting system for baggage according to any of the claims 1-8, wherein the electronic controller during lifting operations continuously adjusts the vacuum source such that the pressure inside the hoisting tube increases (decrease the vacuum) when the position sensor measures that the sliding member is positioned below a given point on the longitudinal member. 10. A lifting system for baggage according to any of the claims 1-9, wherein the electronic controller during lifting operations continuously adjusts the vacuum source such that the sliding member is kept at or moved towards a position close the middle of the valve opening extending in the longitudinal direction of the wall of the longitudinal member. 11. A method of lifting a piece of luggage with a system according to clam 1-10, said method comprising the steps of: identifying the position of a piece of luggage; controlling the position of the suction pad by use of an robotic arm connected to the sliding member; moving the suction pad into a position above the object (luggage) to be lifted; controlling the pressure inside the hoisting tube such that the suction pad is lowered onto the object to be lifted; attaching the luggage to the suction pad; lifting the luggage by moving the sliding member connected to the suction pad; adjusting the vacuum source depending on the sliding members (11) position on the longitudinal member (11).

## Full description

**[0001]**

A lifting device and a method of lifting

**[0002]**

TECHNICAL FIELD

**[0003]**

This invention relates to a method of lifting and a lifting device for luggage comprising a hoisting tube connected to an adjustable vacuum source, the hoisting tube is attached or fixed to a suction pad comprising an inner volume and an edge providing an essentially air-tight closure when it is in contact with a luggage-object during lifting operation, the vacuum source subjects the hoisting tube to a low pressure, and the inner volume of the hoisting tube is connected to the inner volume of the suction pad in such a way that air may flow from one to the other, the hoisting tube provides a lifting force when the air pressure outside the hoisting tube is higher than the air pressure inside the hoisting tube, a longitudinal member comprising a sliding member is connected to the hoisting tube, the sliding member is configured to slide in two directions between a first and a second end position along the longitudinal member, the longitudinal member is provided with a valve opening extending in the longitudinal direction of the wall of the longitudinal member such that the valve opening allows air to flow to and from the inner volume of the hoisting tube and the surroundings, the valve opening and sliding member are mutually adapted such that the valve opening may be covered or partly covered by the sliding member when the sliding member is at the first end position whereas the valve opening becomes gradually more exposed when the sliding member is moved from the first end position and towards the second end position.

**[0004]**

The system is useful for loading travel luggage into containers for loading onto passenger aircraft. The system is also for loading travel luggage onto to wagons with or without sides.

**[0005]**

BACKGROUND

**[0006]**

With today's increase in passenger airline travel, there is increased pressure on airlines and airports to move baggage/luggage through the airports as quickly and efficiently as possible.

**[0007]**

Following check-in and security screening, each piece of luggage is routed, and further sorted and gathered. The sorted bags are then loaded into movable containers, such as e.g., unit load devices (ULDs), which may be transferable onto the airplane. Where it is not possible or efficient to use ULDs, other means such as wagons with baskets and/or trays are used to transfer the sorted luggage for loading into an airplane.

**[0008]**

Even in the most sophisticated and automated luggage handling systems, at several places between luggage check-in and loading/unloading of the airplane, luggage must be manually handled by operators for various reasons and purposes.

**[0008]**

The typical airport luggage is extremely varied and for example comes in many nonstandardised shapes and sizes (even if there are some upper size or dimension limits, at least for normal airport luggage). Furthermore, the weight of respective pieces of luggage often vary from piece to piece, and the various pieces of luggage consists of quite different materials (hard or semi-hard plastic, soft fabric, etc.) making it hard to handle consistently and efficiently. Additionally, the weight distribution is often irregular and may even shift during transportation and handling by the equipment of the airport. For example, items within a piece of luggage like a sports bag or similar will typically shift around unless very tightly packed. Additionally, sports bags or similar may change shape during handling.

**[0009]**

In prior art systems comprising a hoisting tube, the lifting force is controlled via a longitudinal member and a slider, the very different luggage designs cause the slider to sometimes stay close to its outer positions at the first or second end of the longitudinal member. This situation may e.g., occurs when the adjustable vacuum source is providing a very high vacuum (low pressure) while the hoisting tube via suction pad is connected airtight to a light piece of luggage.

**[0010]**

When the slider is moved to an outer position disadvantages as unnecessary and loud noise may be experienced due to unnecessarily high suction and thereby unnecessary air flow through the system valves. Furthermore, the actual control of the pressure in the suction hose/hoisting tube via the slider also becomes inaccurate.

**[0011]**

This make it challenging to design a system that can handle airport luggage, in particular in a fast, reliable, and efficient manner.

**[0012]**

To address some of these challenges, some present luggage handling and sorting solutions include very large-scale automated solutions or facilities that are very costly and additionally take even years to construct, test, and fully implement. Additionally, construction delays also happen due to the great scale and complexity of such solutions. Furthermore, such facilities have a relatively large footprint and have operational areas where humans are prohibited from entering due to safety concerns.

**[0014]**

Maintenance of such large-scale solutions or facilities are also complex and expensive and a break-down may close down a significant portion, if not the whole, of the facility.

**[0013]**

Summary of the invention

**[0014]**

Thus, there is a need for devices and methods that would solve or improve on the difficulties and disadvantages.

**[0015]**

It has been realized with the invention that disadvantages can be remedied by that, the system further comprises a position sensor capable of measuring the position of the sliding member on the longitudinal member, which position sensor is connected to the electronic controller or the systems computer so that during lifting operations the electronic controller adjust the vacuum source depending on the measured position of the sliding member.

**[0016]**

Embodiments of the invention are recited in the dependent claims.

**[0017]**

In another aspect, the invention relates to a method as recited in claim 11.

**[0018]**

To assist those of skilled in the art in making and using embodiments of the present disclosure, reference is made to the accompanying figures, wherein elements are not to scale so as to more clearly show the details, and wherein like reference numbers indicate like elements throughout the several views.

**[0019]**

Dictionary

**[0020]**

In general - features described by these words in the context of the present document may be used in one or all embodiments of the invention as defined in the specification or in the claims.

**[0021]**

Fix, fixed, fixedly - two parts being fixed to each other means that the two parts cannot be released from each other without destroying the parts, the parts may be considered permanently attached to each other.

**[0022]**

Air - the word "air" may generally be replaced with the word "gas" i.e. it is the functionality of air as a gas i.e. a fluid tending to expand indefinitely, which is relevant in connection with the present document, not the composition as such.

**[0023]**

Brief description of the figures

**[0024]**

Figure 1 discloses an embodiment of lifting part according to prior art as disclosed in WO 21/110843.

**[0027]**

Figure 2 discloses a system for use in a cargo terminal.

**[0025]**

Figure 3 discloses an embodiment of an airport system.

**[0026]**

Figure 4 discloses an embodiment of an airport system comprising a rail-system

**[0027]**

Detailed description of the invention

**[0028]**

In the detailed description of the invention units having same or similar function in different embodiments have same reference number.

**[0029]**

In general, the present invention relates to a lifting device or hoisting device with similar functionality as described in respect of the prior art, where a vacuum lifting tube during operation is subjected to a continuous low pressure by a pump, and an opening in the lifting tube determines the pressure inside the lifting tube and whether an object is lifted, lowered or kept at a constant height.

**[0030]**

In the known technique, as described in WO19110843 Al such a system contribute power to vertical lifts in a system that includes a so-called collaborative robot. Such robots are developed to function near humans. In the known systems, the collaborative robot's "arm" is attached to the slider, which sits on the longitudinal member placed at the lower end of a hoisting tube that is attached at its upper end.

**[0031]**

At the end of the longitudinal member, in the known technique, a suction cup is placed, and when the pressure drops in the hoisting tube, the lower pressure will be propagated to the suction cup, so that it is attached to the objects to be lifted.

**[0032]**

The hoisting tube contracts when the pressure on its inside is less than the pressure on its outside, thereby lifting the suction cup with the workpiece attached to it.

**[0033]**

When the robot moves the slider in the vertical direction, it will cause the slider to slide on the longitudinal member and thereby the exposed area of the longitudinal opening will increase or decrease. Normally, the longitudinal opening and slider are adapted so that the longitudinal opening is reduced when the slider slides from a lower end point towards an upper end point and this will cause that the pressure drops inside the hoisting tube, whereby it will contract and lift the object. In other words, when the robot moves the slider upwards, the system will contribute with lifting force. Thus, when the robot has moved the suction cup to an object and this

**[0037]**

has been attached to it, the robot lifts the object by simply moving the robot arm upwards and as long as the robot arm performs an upward movement, the object will move upwards. Typically, hoisting tubes are suspended in a rail system (see figure 3) so that it can be moved/slides in all directions in the horizontal plane and thereby the robot can also move the lifted objects horizontally by simply pushing the hoisting tube around. Such rail systems are well known to the person skilled in the art, and they will therefore not be described further.

**[0034]**

A lifting device according to the present invention may be applied for lifting all kind of objects comprising a smooth surface to which a suction pad may engage with a vacuum, e.g. the objects may be bags, sacks, buckets, barrels, packages, boxes or the like. The lifting device according to the present invention may be advantageously applied when lifting objects having a softer or more flexible outer surface such as bags or sacks or the like.

**[0035]**

Fig. 1 shows an enlargement of a part of a lifting device known from prior art. This lifting device comprises a suction pad 5 (with a suction soft underside 17) attached to a longitudinal member 11 comprising a central opening 24. The lifting device also comprise a valve 14 which may provide a separation between an inner space and a vacuum of the hoisting tube 12 and the inner space or vacuum of the suction pad 5. The valve 14 in fig. 1 is shaped as a box positioned between a sliding member 10 and the suction pad 5 and when the valve 14 is closed it is possible to maintain a low pressure inside the hoisting tube 12 without an object being attached to the suction pad 5. The valve 14 is located just above the suction cup 5. The valve 14 comprises a so-called drop-off valve (not shown in Figure 1). The drop-off valve, can equalize the pressure between the interior of the suction cup and the surrounding atmosphere. When this happens, the suction cup 5 will lose its load-bearing capacity and accordingly, the drop-off valve is therefore used to release products from the suction cup. A disadvantage of this is that when a product is released, the pressure in both the longitudinal member 12 and the hoisting tube 12 will fall correspondingly, and thus the hoisting tube 11 will lose its lifting capacity. Typically, the hosting tube will fall (collapse) down on the just released product. To prevent this, the valve 14 comprises a socalled throttle valve which can cover the opening of the valve towards the lower part of the longitudinal member 11.

**[0036]**

In figure 2, is shown an embodiment of a system for use when filling or emptying carts 71 in an airport. The system comprises a suction pad; a sliding member; a robot and one or more cameras 50; a computer 52 for controlling a robotic arm 51 being connected to said suction pad via a sliding member 11; the one or more cameras 50

**[0041]**

being capable of recording the robotic arm and the area reachable by the robotic arm, said computer having image recognizing software being capable of identifying an object and the position of said object to be lifted, said computer being connected to said one or more camaras, the method comprising the steps of: identifying the position of a piece of luggage; generating a pressure in the hoisting tube that is lower than the ambient pressure; controlling the hight of the suction pad by regulating the pressure inside the hoisting tube; moving the suction pad into a position above the object (luggage) to be lifted; controlling the pressure inside the hoisting tube such that the suction pad is lowered onto the object/luggage to be lifted; controlling the pressure inside the hoisting tube such that the suction pad is lowered onto the object to be lifted; attaching the luggage to the suction pad; lifting the luggage by moving the sliding member connected to the suction pad; adjusting the vacuum source depending on the sliding members (11) position on the longitudinal member (11).

**[0037]**

The system shown in figure 2 differs from prior art systems in that it includes a sensor 100 that can detect whether the luggage is being lifted free of the belt. Thereby, the computer can interrupt a lifting task if, for example, it is registered that the luggage is not lifted. The computer can also increase the vacuum (lower the pressure) in order to try to overcome the problem. When the lifting is unsuccessful, the computer will stop the lifting process and the luggage will be sent on to a so-called buffer area 102. From here, an operator can manually handle the luggage by possibly simply turning it so that a more airtight side is exposed against the suction cup, after which a lift can be attempted again by sending the luggage back to the robot by reversing the belt's 110 direction D or he/she can choose to move the luggage manually to the cage/carriage/wagon 71.

**[0038]**

Since the safety of using the system according to the invention is high and that unsuccessful lifts happens relatively rarely (few or no times per carriage/wagon 71), a single operator can operate several belts/systems at the same time.

**[0039]**

The cameras 50 can see the buffer zone 102 in the system and thus the system can also stop the advancement of the conveyor belt if/before the buffer zone becomes overfilled. To avoid unnecessary stops, the system is provided with one or more light towers 103, which are connected to the cameras and a central computer connected thereto and thereby these light towers can be used to visually indicate the degree of filling of buffer zones or other zones to an operator, such that he/she can interfere and e.g. change the position of a piece of luggage, reverse the direction of the luggage transporting band 110 and thereby prevent unnecessary stops by .eg. overfilling of e.g a buffer zone.

**[0045]**

The light towers are normally changing color and/or gradually being "filled up" by only letting the bottom of the light tower lighting up when the buffer zone is almost empty, after which more and more of the length of the light tower lights up as the buffer zone is filled. The purpose of the light towers is thus that they are strong visual instruments from which an operator can easily view the information and thereby also intervene in an ongoing lifting operation by, for example, emptying a buffer zone before it is full.

**[0040]**

Any numbers of light towers can be combined with weight sensors 102 or optically luggage sensors 100. The baggage/luggage 100 sensor (s) may be ultrasonic sensor (s), a weight sensor (s) or optical sensor (s) or a combination of these. The location of light towers depends on the current conditions and typically these will be placed so that an operator can see light towers from several lifting systems/units and thereby also operate several lifting systems at the same time.

**[0041]**

On top of the hoisting tube 51, a weight sensor 101 may be provided. The weight sensor measures the weight of the hoisting tube and the lifted object. This sensor can be used as a safety feature as the system can be programmed such that an excessively large weight e.g. may cause the system computer to stop or reject a lift operation. Only one light tower is shown in the figure, but of course the system can include several of this kind and they may be used to indicate additional/other features than just the degree of filling of a buffer zone. For example, there can also be light towers that visually indicate the degree of filling of wagons, the size of the vacuum, the speed of the belt, etc., etc.

**[0042]**

In figure 3 is shown a system comprising a rail system 105 on which the hoisting tube 51 can be moved.

**[0043]**

In figure 4 is shown a sliding member 10 comprising an attachment arm 9 for attachment of a robot arm to the sliding member 10. The attachment arm is attached to a longitudinal member 11 which normally is connected to the hoisting tube (not shown). The sliding member 10 is configured to slide in two directions between a first and a second end position along the longitudinal member 11. The longitudinal member 11 is provided with a valve opening 13 extending in the longitudinal direction of the wall of the longitudinal member 11. The valve opening 13 allows air to flow between the inner volume of the longitudinal member and the outside of same. Thereby the valve opening also allows air to flow between the inner volume of hoisting tube and the surroundings. The valve opening 13 and the sliding member 11 are mutually adapted such that the valve opening 13 may be covered or partly covered by the sliding member 11 when the sliding member is moving up or down on the

**[0050]**

longitudinal member 11. The valve opening 13 becomes gradually more exposed when the sliding member is moved from the first end (in the figure it is the lower end) position and towards the second (upper) end position. The system comprises a position sensor 91 capable of measuring the position of the sliding member 10 on the longitudinal member 11. The position sensor 91 is connected to the electronic controller (or the systems computer) so that during lifting operations the electronic controller adjust the vacuum source depending on the sliding members 11 position on the longitudinal member 11.

**[0044]**

In the embodiment shown, the distance sensor 91 is located on an arm 9, but it can of course be located in many other places. It can, for example, sit on the slider 11 itself as well as it can sit on the lower plate 111 or the upper plate 112 and measure the distance to a point on the slider and thus give the system's computer an indication of where on the longitudinal member the slider sits, preferably the distance sensor will measure the distance from the arm 9 and to (wards) the upper plate 112, but it can of course also measure distances from and to other points. As stated in the claims, the distance sensor can be of the type that works using an optical or a light-based sensor, but other measurement methods known to the person skilled in the art can also be used.

## Classifications

- B66C1/0287
- B25J13/08
- B25J15/06
- B25J18/00
- B66C1/02
- B66C1/0293
- B66C1/68
- B66C23/00
- B66C23/02
- B66C23/027
- B66C23/08
- B66D3/18

## Cited patent documents

- [US-5967739-A](https://patents.google.com/patent/US5967739A/en) — ISR
- [WO-2019110843-A1](https://patents.google.com/patent/WO2019110843A1/en) — APP,ISR
- [WO-2021110843-A1](https://patents.google.com/patent/WO2021110843A1/en) — APP

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
