# 20. Vacuum lifting apparatus

- **Archive rank:** 20 of 50
- **Publication:** [DE-4416859-A1](https://patents.google.com/patent/DE4416859A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/006893280/publication/DE4416859A1?q=pn%3DDE4416859A1)
- **Publication date:** 1994-11-24
- **Filing date:** 1994-05-13
- **Earliest priority:** 1993-05-17
- **Family:** 6893280
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** LEWECKE GMBH MASCHBAU
- **Inventors:** LEWECKE ERNST; RIESENBERG MANFRED

## Abstract

The vacuum lifting apparatus for flat workpieces (1), such as boards, planks, panels or the like of wood or wooden material, has a supporting frame (2) movable in the vertical and horizontal direction. A multiplicity of suction plates (3) are held on the supporting frame (2). The suction plates (3) are each connected to a vacuum distributor (6) via a line (4) with inserted control valve (5) for forming and releasing a vacuum and are connected from this vacuum distributor (6) to a vacuum reservoir (9) with vacuum pump (10) via a suction line (7) with inserted vacuum manipulating valve (8). A blast-air line (12) coming from a warm-air heater (11) and having an inserted control valve (13) is attached to the vacuum distributor (6), and this control valve (13) can here be controlled alternately with the vacuum manipulating valve (8) for shutting off blast air to the vacuum distributor (6) and for releasing blast air into the vacuum distributor (6). &lt;IMAGE&gt;

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-4416859-A1/ops000.png)

![Sketch 1 for DE-4416859-A1](https://nimo.iptorch.com/refdrawing/DE-4416859-A1/ops000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-4416859-A1/ops001.png)

![Sketch 2 for DE-4416859-A1](https://nimo.iptorch.com/refdrawing/DE-4416859-A1/ops001.png)

## Claims

### Claim 1 (independent)

Vakuum-Hebevorrichtung für flächige Werkstücke, wie Bretter, Bohlen, Platten, od. dgl., aus Holz oder Holzwerkstoff, mit einem in Höhen- und Horizontalrichtung verfahrbaren Tragrahmen, an dem eine Vielzahl an Saugplatten gehalten ist, welche jeweils über eine Leitung mit eingesetztem Steuerventil zur Vakuumbildung und -auflösung an einen Vakuumverteiler und von diesem aus über eine Saugleitung mit eingesetztem Vakuum-Schaltventil an einen Vakuumspeicher mit Vakuumpumpe angeschlossen sind, dadurch gekennzeichnet, daß an den Vakuumverteiler (6) eine von einem Warmlufterzeuger (11) kommende Blasluftleitung (12) mit eingesetztem Steuerventil (13) angeschlossen ist und dabei dieses Steuerventil (13) zur Blasluftabsperrung zu dem und zur Blasluftfreigabe in den Vakuumverteiler (6) wechselweise mit dem Vakuum-Schaltventil (8) steuerbar ist.1. Vacuum lifting device for flat workpieces, such as boards, planks, plates, or the like, made of wood or wood-based material, with a vertically and horizontally movable support frame on which a plurality of suction plates is held, each via a line with an inserted control valve for vacuum formation and dissolution to a vacuum distributor and from there via a suction line with inserted vacuum switching valve to a vacuum accumulator with a vacuum pump, characterized in that a blowing air line coming from a warm air generator ( 11 ) comes to the vacuum distributor ( 6 ) ( 12 ) with inserted control valve ( 13 ) and this control valve ( 13 ) for blowing air shut-off to and for blowing air release into the vacuum distributor ( 6 ) can be controlled alternately with the vacuum switching valve ( 8 ).

### Claim 2

Vakuum-Hebevorrichtung nach Anspruch 1, dadurch gekennzeichnet, daß der Warmlufterzeuger (11) von einem Warmluftgebläse gebildet ist.2. Vacuum lifting device according to claim 1, characterized in that the warm air generator ( 11 ) is formed by a warm air blower.

### Claim 3

Vakuum-Hebevorrichtung nach Anspruch 1 oder 2, dadurch gekennzeichnet, daß an dem Hubrahmen (2) mehrere Baugruppen (A, B, C) aus jeweils einer Vielzahl an Saugplatten (3) angeordnet sind, jede Saugplattengruppe (A, B, C) an einen Vakuumverteiler (6) angeschlossen ist und die Blasluftleitung (12) mit eingesetztem Steuerventil (13) zu einem Blasluftverteiler (14) geführt ist, von dem aus zu jedem Vakuumverteiler (6) eine Zuführleitung (15) abgeht.3. Vacuum lifting device according to claim 1 or 2, characterized in that on the lifting frame ( 2 ) a plurality of assemblies (A, B, C) each arranged from a plurality of suction plates ( 3 ), each suction plate group (A, B, C ) is connected to a vacuum distributor ( 6 ) and the blown air line ( 12 ) with inserted control valve ( 13 ) is led to a blown air distributor ( 14 ) from which a supply line ( 15 ) leads to each vacuum distributor ( 6 ).

### Claim 4

Vakuum-Hebevorrichtung nach einem der Ansprüche 1 bis 3, dadurch gekennzeichnet, daß die Steuerventile (5) von eine Aktivsteuerung für die Luftströmung und Saugkrafteinstellung bewirkenden Kugelventilen gebildet sind. Vacuum lifting device according to one of claims 1 to 3, characterized in that the control valves ( 5 ) are formed by an active control for the air flow and suction force setting ball valves.

### Claim 5

Vakuum-Hebevorrichtung nach einem der Ansprüche 1 bis 4, dadurch gekennzeichnet, daß das Steuerventil (5) eine mit einem Längenende über die Saugleitung (4) an den Vakuumverteiler (6) anschließbare Ventilhülse (22) mit abgestuftem, eine Kugel (20) als Steuerkörper freibeweglich aufnehmenden Saugkanal (21) und eine am anderen Ventilhülsen-Längenende aufgeschraubte, gegenüber der Ventilhülse (22) in der Axiallänge verstellbare Einstellhülse (23) mit darin angeordnetem, eine kalottenförmige Kugelauflage (30) und Durchströmlöcher (29) besitzenden Ventilteller (24) und an der Einstellhülse (23) anschließbarer Anschlußtülle (25) für die zur Saugplatte (3) führende Saugleitung (4) aufweist, wobei die Einstellhülse (23) in der eingestellten Stellung durch eine Anschlagmutter (26) und eine Kontermutter (27) fixierbar ist.5. Vacuum lifting device according to one of claims 1 to 4, characterized in that the control valve ( 5 ) with a length end via the suction line ( 4 ) to the vacuum distributor ( 6 ) connectable valve sleeve ( 22 ) with stepped, a ball ( 20 ) as a control body freely accommodating suction channel ( 21 ) and an adjusting sleeve ( 23 ) screwed onto the other end of the valve sleeve and adjustable in axial length with respect to the valve sleeve ( 22 ), with a valve plate ( 24 ) arranged therein, which has a spherical support ( 30 ) and flow-through holes ( 29 ), and can be connected to the adjusting sleeve ( 23 ) Has connecting sleeve ( 25 ) for the suction line ( 4 ) leading to the suction plate ( 3 ), the adjusting sleeve ( 23 ) being fixable in the set position by a stop nut ( 26 ) and a lock nut ( 27 ).

## Full description

PERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansMultiple lifting units; More than one suction areaSeparate cupsPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippersPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippersDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippers control arrangementsPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippersDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippers with at least two picking-up heads

Description

Translated from German

Die Erfindung bezieht sich auf eine Vakuum-Hebevorrichtung

fÃ¼r flÃ¤chige WerkstÃ¼cke, wie Bretter, Bohlen, Platten, od.

dgl., aus Holz oder Holzwerkstoff, mit einem in HÃ¶hen- und

Horizontalrichtung verfahrbaren Tragrahmen, an dem eine

Vielzahl an Saugplatten gehalten ist, welche jeweils Ã¼ber

eine Leitung mit eingesetztem Steuerventil zur Vakuumbildung

und -auflÃ¶sung an einen Vakuumverteiler und von diesem aus

Ã¼ber eine Saugleitung mit eingesetztem Vakuum-Schaltventil

an einen Vakuumspeicher mit Vakuumpumpe angeschlossen sind.The invention relates to a vacuum lifting device

for flat workpieces, such as boards, planks, plates, or

Like., Made of wood or wood-based material, with one in height and

Horizontal direction movable support frame, on one

Variety of suction plates is held, each over

a line with an inserted control valve for vacuum formation

and dissolution to and from a vacuum distributor

via a suction line with a vacuum switching valve inserted

are connected to a vacuum accumulator with a vacuum pump.

Eine derartige Vakuum-Hebevorrichtung ist beispielsweise aus

der DE-PS 38 34 866 bekannt geworden.Such a vacuum lifting device is, for example, from

DE-PS 38 34 866 become known.

Die in dieser Vorrichtung fÃ¼r die Aktivsteuerung

eingesetzten Kugelventile haben sich in der Praxis bewÃ¤hrt,

jedoch kÃ¶nnen FunktionsstÃ¶rungen auftreten, da bei den

stÃ¤ndig vorkommenden Vakuumbildungen aus den HolzwerkstÃ¼cken

Feuchtigkeit mit angesaugt wird, die sich dann in den

Kugelventilen absetzt und dadurch die Hubbewegung der Kugeln

beeintrÃ¤chtigen kann.The in this device for active control

ball valves used have proven themselves in practice,

however, malfunctions can occur because the

constantly occurring vacuum formations from the wooden workpieces

Moisture is sucked in, which then in the

Ball valves and thereby the stroke movement of the balls

can affect.

Bei niedrigen Temperaturen im Arbeitsbereich der Vorrichtung

ist dabei ein Einfrieren der Steuerventile nicht

ausgeschlossen.At low temperatures in the working area of the device

is not a freeze of the control valves

locked out.

Aufgabe der Erfindung ist es deshalb, die Steuerventile der

nach der eingangs genannten Art aufgebauten Vakuum-

Hebevorrichtung in einfacher und sicherer Weise gegen

FunktionsbeeintrÃ¤chtigungen und Einfrieren durch die aus den

HolzwerkstÃ¼cken bei jeder Vakuumbildung angesaugte

Feuchtigkeit zu schÃ¼tzen.The object of the invention is therefore the control valves

vacuum built according to the type mentioned at the beginning

Lifting device in a simple and safe way against

Functional impairments and freezing through from the

Wood workpieces sucked in every vacuum

To protect moisture.

Diese Aufgabe wird erfindungsgemÃ¤Ã durch die kennzeichnenden

Merkmale des Patentanspruches 1 gelÃ¶st.This object is achieved by the characterizing

Features of claim 1 solved.

Die sich daran anschlieÃenden UnteransprÃ¼che beinhalten

Gestaltungsmerkmale, welche vorteilhafte und fÃ¶rderliche

Weiterbildungen der AufgabenlÃ¶sung darstellen.The subsequent sub-claims contain

Design features, which are advantageous and beneficial

Represent further training in task solving.

Die Steuerventile der erfindungsgemÃ¤Ãen Vakuum-

Hebevorrichtung sind in einfacher und sicherer Weise gegen

FunktionsbeeintrÃ¤chtigungen und Einfrieren durch die aus den

HolzwerkstÃ¼cken bei jeder Vakuumbildung angesaugten

Feuchtigkeit geschÃ¼tzt, indem nach jeder VakuumauslÃ¶sung

durch die Steuerventile Warmluft geblasen wird, die die

Feuchtigkeit aus den Steuerventilen nach unten und aus den

Saugplatten herausblÃ¤st und gleichzeitig die Steuerventile

und die darin angeordneten Kugeln trocknet.The control valves of the vacuum

Lifting devices are against in a simple and safe manner

Functional impairments and freezing through from the

Wood workpieces sucked in every vacuum

Moisture protected by after every vacuum release

warm air is blown through the control valves, which the

Moisture from the control valves down and from the

Blows out suction plates and at the same time the control valves

and dries the balls inside.

Hierdurch wird nach jeder Vakuumbildung jedes Steuerventil

hundertprozentig von Feuchtigkeit befreit und dadurch kann

ein Einfrieren nicht erfolgen und die stÃ¤ndig getrockneten

Ventile behalten ihre einwandfreie Funktion.As a result, each control valve is activated after every vacuum

100% free of moisture and therefore can

freezing does not take place and the constantly dried

Valves retain their perfect function.

Diese BlasluftzufÃ¼hrung erfolgt automatisch und im Wechsel

mit der Vakuumbildung, d. h., bei der Vakuumbildung wird die

Blasluftzufuhr abgesperrt und nach VakuumauflÃ¶sung

automatisch die Blasluftzufuhr freigegeben.This blown air supply takes place automatically and alternately

with vacuum formation, d. that is, in vacuum formation

Blown air supply shut off and after vacuum dissolution

the blown air supply is automatically released.

Diese wechselweise Steuerung der Blasluftzufuhr

und -absperrung erfolgt Ã¼ber ein Blasluft-Steuerventil, welches

in eine von einem WarmluftgeblÃ¤se kommende Blasluftleitung

eingesetzt ist. Diese Blasluftleitung ist zu einem

Blasluftverteiler gefÃ¼hrt, von dem aus jeweils eine

ZufÃ¼hrleitung zu den Vakuumverteilern der in Gruppen

angeordneten Saugplatten fÃ¼hrt.This alternate control of the blown air supply

Â and shut-off takes place via a blown air control valve, which

into a blown air line coming from a warm air blower

is inserted. This blown air line is one

Blown air distributor led, one of each

Supply line to the vacuum manifolds in groups

arranged suction plates leads.

Durch geringen technischen Aufwand, d. h., der zusÃ¤tzlichen

Anordnung eines Warmlufterzeugers, einer Blasluftleitung und

eines Steuerventiles, wird in kostengÃ¼nstiger und sicherer

Weise die Gesamtfunktion der Vakuum-Hebevorrichtung

erheblich verbessert und dauerhaft wirksam gestaltet.With little technical effort, d. that is, the additional

Arrangement of a warm air generator, a blown air line and

a control valve, will be cheaper and safer

Way the overall function of the vacuum lifting device

significantly improved and designed to be effective over the long term.

Auf den Zeichnungen ist ein AusfÃ¼hrungsbeispiel der

Erfindung dargestellt, welches nachfolgend nÃ¤her erlÃ¤utert

wird. Es zeigt:In the drawings, an embodiment of the

Invention shown, which is explained in more detail below

becomes. It shows:

Fig. 1 eine schematische Vorderansicht einer Vakuum-

Hebevorrichtung, Fig. 1 is a schematic front view of a vacuum lifting device,

Fig. 2 einen LÃ¤ngsschnitt durch ein Steuerventil der

Hebevorrichtung. Fig. 2 shows a longitudinal section through a control valve of the lifting device.

Die Vakuum-Hebevorrichtung fÃ¼r flÃ¤chige WerkstÃ¼cke (1), wie

Bretter, Bohlen, Platten, od. dgl., aus Holz oder

Holzwerkstoff, weist einen in HÃ¶hen- und Horizontalrichtung

verfahrbaren Tragrahmen (2) auf, an dem eine Vielzahl an

Saugplatten (3) gehalten ist, welche jeweils Ã¼ber eine

Leitung (4) mit eingesetztem Steuerventil (5) zur

Vakuumbildung und -auflÃ¶sung an einen Vakuumverteiler (6)

und von diesem aus Ã¼ber eine Saugleitung (7) mit

eingesetztem Vakuum-Schaltventil (8) an einen Vakuumspeicher

(9) mit Vakuumpumpe (10) angeschlossen sind.The vacuum lifting device for flat workpieces ( 1 ), such as boards, planks, plates or the like, made of wood or wooden material, has a support frame ( 2 ) which can be moved in the vertical and horizontal directions and on which a large number of suction plates ( 3 ) is held, each via a line ( 4 ) with an inserted control valve ( 5 ) for vacuum formation and release to a vacuum distributor ( 6 ) and from there via a suction line ( 7 ) with an inserted vacuum switching valve ( 8 ) to a vacuum accumulator ( 9 ) are connected to a vacuum pump ( 10 ).

Die Vakuumpumpe (10) ist durch eine Saugleitung (10a) an den

Vakuumspeicher (9) angeschlossen.The vacuum pump ( 10 ) is connected to the vacuum accumulator ( 9 ) by a suction line ( 10 a).

An den Vakuumverteiler (6) ist eine von einem

Warmlufterzeuger (11) kommende Blasluftleitung (12) mit

eingesetztem Steuerventil (13) angeschlossen; dieses

Blasluft-Steuerventil (13) ist zur Blasluftabsperrung zu dem

und zur Blasluftfreigabe in den Vakuumverteiler (6)

wechselweise mit dem Vakuum-Schaltventil (8) steuerbar.A blowing air line ( 12 ) coming from a warm air generator ( 11 ) with an inserted control valve ( 13 ) is connected to the vacuum distributor ( 6 ); This blowing-air control valve (13) is controllable to Blasluftabsperrung to the Blasluftfreigabe and into the vacuum manifold (6) alternately to the vacuum switching valve (8).

Der Warmlufterzeuger (11) ist von einem WarmluftgeblÃ¤se

gebildet.The warm air generator ( 11 ) is formed by a warm air blower.

An dem Hubrahmen (2) sind mehrere Baugruppen (A, B, C) aus

jeweils einer Vielzahl an Saugplatten (3) angeordnet; jede

Saugplatten-Gruppe (A, B, C) ist dabei an einen

Vakuumverteiler (6) angeschlossen und die Blasluftleitung

(12) mit eingesetztem Steuerventil (13) ist zu einem

Blasluftverteiler (14) gefÃ¼hrt, von dem aus zu jedem

Vakuumverteiler (6) eine ZufÃ¼hrleitung (15) abgeht.Several assemblies (A, B, C), each consisting of a plurality of suction plates ( 3 ), are arranged on the lifting frame ( 2 ); Each suction plate group (A, B, C) is connected to a vacuum distributor ( 6 ) and the blown air line ( 12 ) with the control valve ( 13 ) inserted is guided to a blown air distributor ( 14 ), from which each vacuum distributor ( 6 ) a supply line ( 15 ) goes out.

Der Hubrahmen (2) trÃ¤gt die Vakuumpumpe (10), den

Warmlufterzeuger (11), die Vakuumverteiler (6), die

Leitungen (7, 12, 15), die Ventile (8, 13) und den

Blasluftverteiler (14).The lifting frame ( 2 ) carries the vacuum pump ( 10 ), the warm air generator ( 11 ), the vacuum distributor ( 6 ), the lines ( 7 , 12 , 15 ), the valves ( 8 , 13 ) and the blown air distributor ( 14 ).

Die Saugplatten (3) jeder Gruppe (A, B, C) sind Ã¼ber nicht

dargestellte Halteorgane an dem ihnen zugeordneten

Vakuumverteiler (6) aufgehÃ¤ngt und dabei zur selbsttÃ¤tigen

Anpassung an die WerkstÃ¼cke beweglich (gelenkig) an den

Halteorganen angebracht.The suction plates ( 3 ) of each group (A, B, C) are suspended from the vacuum distributor ( 6 ) assigned to them via holding members, not shown, and are attached to the holding members so that they can be flexibly and flexibly adapted to the workpieces.

Von dem Vakuumverteiler (6) geht zu jeder Saugplatte (3)

eine flexible Schlauchleitung (4) ab und in diese ist ein

Steuerventil (5) eingesetzt. Die Steuerventile (5) sind in

bevorzugter Weise von Kugelventilen gebildet, wie in Fig. 2

dargestellt.A flexible hose line ( 4 ) goes from the vacuum distributor ( 6 ) to each suction plate ( 3 ) and a control valve ( 5 ) is inserted into this. The control valves ( 5 ) are preferably formed by ball valves, as shown in Fig. 2.

In dem Steuerventil (5) ist eine Kugel (20) als SteuerkÃ¶rper

in einem in seiner LÃ¤nge stufenlos verÃ¤nderbaren und in der

eingestellten GrÃ¶Ãe arretierbaren Saugkanal (21) frei

beweglich untergebracht; durch diesen einstellbaren

Saugkanal (21) wird der Kugel-Hubweg und somit der Luft-

DurchstrÃ¶mquerschnitt bestimmt, welches die SaugkraftgrÃ¶Ãe

ergibt.In the control valve ( 5 ), a ball ( 20 ) as the control body is accommodated in a freely movable manner in a suction channel ( 21 ) which is infinitely variable in length and lockable in the set size; this adjustable suction channel ( 21 ) determines the ball stroke and thus the air flow cross section, which gives the suction force size.

Das Steuerventil (5) hat eine mit einem LÃ¤ngenende Ã¼ber die

Saugleitung (4) an den Vakuumverteiler (6) anschlieÃbare

VentilhÃ¼lse (22) mit abgestuftem Saugkanal (21) und eine am

anderen VentilhÃ¼lsen-LÃ¤ngenende aufgeschraubte, gegenÃ¼ber

der VentilhÃ¼lse (22) in der AxiallÃ¤nge verstellbare

EinstellhÃ¼lse (23) mit darin angeordnetem Ventilteller (24)

und an der EinstellhÃ¼lse (23) anschlieÃbarer AnschluÃtÃ¼lle

(25) fÃ¼r die zur Saugplatte (3) fÃ¼hrende Saugleitung (4);

die EinstellhÃ¼lse (23) ist in der eingestellten Stellung

durch eine Anschlagmutter (26) und eine Kontermutter (27)

fixierbar.The control valve ( 5 ) has a valve sleeve ( 22 ) with a graduated suction channel ( 21 ) that can be connected to the vacuum manifold ( 6 ) with a length end via the suction line ( 4 ) and a screwed end that is screwed onto the other valve sleeve length end opposite the valve sleeve ( 22 ) axial length-adjustable adjusting sleeve (23) connectable with disposed therein valve plate (24) and on the adjusting sleeve (23) hose connector (25) for leading to the suction plate (3), suction pipe (4); the adjusting sleeve ( 23 ) can be fixed in the set position by a stop nut ( 26 ) and a lock nut ( 27 ).

Der Saugkanal (21) ist von einem an der EinstellhÃ¼lse (23)

benachbarten LÃ¤ngenende liegenden, im Querschnitt grÃ¶Ãer als

der Kugel-Durchmesser ausgefÃ¼hrten Kanalteil (21a) mit

freiendseitiger Senkerweiterung (21c) und einem sich daran

anschlieÃenden, im Querschnitt kleiner als der Kugel-

Durchmesser ausgefÃ¼hrten und einen SchlieÃsitz (28) fÃ¼r die

Kugel (20) ergebenden Kanalteil (21b) gebildet, wobei der

Kanalteil (21a) mit der EinstellhÃ¼lse (23) den in der LÃ¤nge

einstellbaren Saugkanal (21) und Hubbereich der Kugel (20)

ergibt.The suction channel ( 21 ) is of a channel end ( 21 a) lying on the adjusting sleeve ( 23 ) adjacent to the end of the length, which is larger in cross-section than the ball diameter, with a lower end widening extension ( 21 c) and an adjoining one, in cross-section smaller than that Ball diameter executed and a closing seat ( 28 ) for the ball ( 20 ) resulting channel part ( 21 b) is formed, the channel part ( 21 a) with the adjusting sleeve ( 23 ) the length-adjustable suction channel ( 21 ) and stroke range of the ball ( 20 ) results.

In der topffÃ¶rmigen EinstellhÃ¼lse (25) ist der mehrere

DurchstromlÃ¶cher (29) und eine kalottenfÃ¶rmige Kugelauflage

(30) besitzende Ventilteller (24) eingepreÃt.The valve plate ( 24 ), which has a plurality of flow-through holes ( 29 ) and a spherical spherical support ( 30 ), is pressed into the cup-shaped adjusting sleeve ( 25 ).

Der oberhalb des Kugeltellers (24) befindliche HÃ¼lsenraum

(23a) geht in das Kanalteil (21a) Ã¼ber und seine axiale

GrÃ¶Ãe verÃ¤ndert sich beim Einstellen der EinstellhÃ¼lse (23)

gegenÃ¼ber der VentilhÃ¼lse (22), so daÃ auch dieser

HÃ¼lsenraum (23a) einen Teil des Saugkanales (21) ergibt und

den Luft-DurchstrÃ¶mquerschnitt mit bestimmt.The sleeve space located above the ball disc (24) (23 a) passes into the channel portion (21 a) and its axial size changed when adjusting the adjusting sleeve (23) relative to the valve sleeve (22), so that this sleeve chamber (23 a ) results in part of the suction channel ( 21 ) and also determines the air flow cross section.

In die VentilhÃ¼lse (22) ist in Saugrichtung (S) hinter dem

Hubweg (21a) der Kugel (20) eine quer zum Saugkanal (21)

gerichtete, eine stufenlose Einstellung der

QuerschnittsgrÃ¶Ãe des Saugkanales (21) und somit der

LuftstrÃ¶mung bewirkende Stellschraube (31) eingeschraubt.

In the valve sleeve ( 22 ) in the suction direction (S) behind the stroke ( 21 a) of the ball ( 20 ) there is an adjusting screw (transversely to the suction channel ( 21 )) that allows the cross-sectional size of the suction channel ( 21 ) and thus the air flow to be adjusted continuously ( 31 ) screwed in.

Dieses Kugelventil (5) ergibt eine Aktivsteuerung fÃ¼r die

Saugluft und lÃ¤Ãt sich stufenlos in der Saugkraft durch

Verstellen der EinstellhÃ¼lse (23) gegenÃ¼ber der VentilhÃ¼lse

(22) einstellen.This ball valve ( 5 ) provides active control for the suction air and can be adjusted continuously in the suction force by adjusting the adjusting sleeve ( 23 ) relative to the valve sleeve ( 22 ).

Beide HÃ¼lsen (22, 23) bestehen aus Kunststoff und zeigen ein

durchsichtiges Fenster im Bereich des Saugkanales (21),

wodurch die Hub- und Senkbewegung von auÃen beobachtet

werden kann.Both sleeves ( 22 , 23 ) are made of plastic and show a transparent window in the area of the suction channel ( 21 ), so that the lifting and lowering movement can be observed from the outside.

Zur Erzeugung eines Vakuums in den Saugplatten (3) wird Ã¼ber

das Blasluft-Steuerventil (13) die Blasluftleitung (12) und

somit die Blasluftzufuhr zu den Steuerventilen (5) und

Saugplatten (3) abgesperrt und es werden die Vakuum-

Schaltventile (8) geÃ¶ffnet, so daÃ in den Saugplatten (3)

Ã¼ber die Steuerventile (5) ein Vakuum vom Vakuumspeicher (9)

aus erzeugt wird.To create a vacuum in the suction plates ( 3 ), the blown air line ( 12 ) and thus the blown air supply to the control valves ( 5 ) and suction plates ( 3 ) is shut off via the blown air control valve ( 13 ) and the vacuum switching valves ( 8 ) opened so that a vacuum from the vacuum accumulator ( 9 ) is generated in the suction plates ( 3 ) via the control valves ( 5 ).

Die Saugplatten (3) kÃ¶nnen dann unter Vakuum die WerkstÃ¼cke

(1) anheben und transportieren und wieder ablegen, wobei

hierbei die Vakuum-Schaltventile (8) geschlossen werden und

das Vakuum dadurch in den Saugplatten (3) aufgelÃ¶st wird.The suction plates ( 3 ) can then lift and transport the workpieces ( 1 ) and put them down again under vacuum, in which case the vacuum switching valves ( 8 ) are closed and the vacuum is thereby released in the suction plates ( 3 ).

Da durch das Vakuum aus den Holz-WerkstÃ¼cken (1)

Feuchtigkeit in die Steuerventile (5) angesaugt wird, sich

dann darin Wasser bildet, wird die Steuerfunktion der

Steuerventile (5) beeintrÃ¤chtigt, indem die Steuerkugeln

(20) auf dem Wasser schwimmen und dann keinen einwandfreien

Hub zum Bilden und AuflÃ¶sen des Vakuums durchfÃ¼hren kÃ¶nnen.Since moisture is sucked into the control valves ( 5 ) by the vacuum from the wooden workpieces ( 1 ), water then forms therein, the control function of the control valves ( 5 ) is impaired by the control balls ( 20 ) floating on the water and then cannot carry out a perfect stroke to form and break the vacuum.

Um dieses Problem zu lÃ¶sen, wird nach dem SchlieÃen der

Vakuum-Schaltventile (8) automatisch das Blasluft-

Steuerventil (13) geÃ¶ffnet und Ã¼ber vom gleichzeitig

eingeschalteten oder stÃ¤ndig laufenden WarmluftgeblÃ¤se (11)

durch die Blasluftleitung (12), den Verteiler (14) und die

ZufÃ¼hrleitungen (15) sowie die Verteiler (5) warme Blasluft

durch die Leitungen (4) und Ventile (5) geblasen, die dann

unten aus den Saugplatten (3) austritt. Durch diese warme

Blasluft wird die Feuchtigkeit (Wasser) aus den Ventilen (5)

herausgeblasen und die Ventile (5) sowie Kugeln (20) werden

gleichzeitig getrocknet, so daÃ die Ventile (5) und Kugeln

(20) eine einwandfreie Funktion beibehalten; dieser

Blasluftvorgang erfolgt nach jedem Vakuumhub der Saugplatten

(3).To solve this problem, the vacuum switching valves (8) is automatically opened, the blast-air control valve (13) and by simultaneously turned on or constantly running hot air blower (11) through the compressed air line (12) after closing, the manifold (14) and the supply lines ( 15 ) and the distributors ( 5 ) are blown with warm blown air through the lines ( 4 ) and valves ( 5 ), which then emerges from the suction plates ( 3 ) below. This warm blown air blows the moisture (water) out of the valves ( 5 ) and the valves ( 5 ) and balls ( 20 ) are dried at the same time, so that the valves ( 5 ) and balls ( 20 ) maintain perfect functioning; this blowing air process takes place after each vacuum stroke of the suction plates ( 3 ).

Durch die Blasluft wird weiterhin bei niedrigen Temperaturen

im Arbeitsbereich der Vorrichtung ein Einfrieren der Kugeln

(20) durch die Feuchtigkeit in den Ventilen (5)

ausgeschlossen.The blowing air also prevents the balls ( 20 ) from freezing due to the moisture in the valves ( 5 ) at low temperatures in the working area of the device.

## Classifications

- B66C1/0243
- B65G47/91
- B65G47/91
- B65G47/917
- B65G47/918
- B66C1/02

## Cited patent documents

- [DE-4123063-A1](https://patents.google.com/patent/DE4123063A1/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
