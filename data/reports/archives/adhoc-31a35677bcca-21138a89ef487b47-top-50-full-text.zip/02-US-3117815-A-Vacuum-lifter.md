# 02. Vacuum lifter

- **Archive rank:** 2 of 50
- **Publication:** [US-3117815-A](https://patents.google.com/patent/US3117815A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/022974626/publication/US3117815A?q=pn%3DUS3117815A)
- **Publication date:** 1964-01-14
- **Filing date:** 1963-02-07
- **Earliest priority:** 1963-02-07
- **Family:** 22974626
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** VACUUM CONCRETE CORP OF AMERIC
- **Inventors:** CRESKOFF JACOB J

## Abstract

_No abstract was available from the queried sources._

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-3117815-A/000.png)

![Sketch 1 for US-3117815-A](https://nimo.iptorch.com/refdrawing/US-3117815-A/000.png)

## Claims

### Claim 1 (independent)

A VACUUM LIFTER COMPRISING A FRAME HAVING OPPOSED SURFACES, A FIRST DEFORMABLE RESILIENT GASKET SECURED TO ONE OF SAID SURFACES DEFINING AN OPEN INNER CHAMBER WITH SAID FRAME, MEANS DEFINING A PORT FOR CONNECTING SAID INNER CHAMBER WITH A SOURCE OF REDUCED PRESSURE, A SECOND DEFORMABLE RESILIENT GASKET SURROUNDING SAID FIRST GASKET AND SPACED THEREFROM DEFINING AN OPEN OUTER CHAMBER WITH SAID FRAME AND FIRST GASKET, AND MEANS DEFINING FLUID PASSAGE MEANS INTERCONNECTING SAID CHAMBERS, SAID PASSAGE MEANS BEING SMALLER IN AREA THAN SAID PORT.

## Full description

**[p0001]**

Jan. 14, 1964 J, CRESKQFF 3,117,815 VACUUM LIFTER Filed Feb. 7, 1963 4 PIC-3.3 FIG.4 INVENTOR. JACOB J. CRESKOFF ATTORNEY United States Patent C) 3,117,815 VACUUM LIFTER Jacob J. Creshoif, Wynnewood, Pa., assignor to Vacuum Concrete Corporation of America, Philadelphia, &#39;Pa., a corporation of Pennsylvania Filed Feb. 7, 1963, Ser. No. 257,035 9 Claims. (Cl. 294-64) This invention relates to a vacuum lifter capable of {apd engagement and disengagement with respect to a In connection with vacuum lifters heretofore known, difiiculty has been enocuntered in achieving the initial attachment of the lifter to a load, particularly where the surface of the load is rough or otherwise non-planar. Various expedients have been proposed in the past to compensate for such conditions, but for one reason or another they have left much to be desired. In order to satisfy the problems heretofore encountered along these lines, it is among the objects of the present invention to provide a vacuum lifter comprising a frame having opposed surfaces, a first deformable resilient gasket secured to one of the surfaces defining an open inner chamber with the frame, means defining a port for connecting the inner chamber with a source of reduced pressure, a second deformable resilient gasket surrounding the first gasket and spaced therefrom defining an open outer chamber with the frame nad first gasket, and means defining fluid passage means smaller in area than the port interconnecting the chambers.

**[p0002]**

The ratio of the area of the port to the area of the fluid passage means should be between 1.1:1 and 96.0:1, the preferred range being between 25.0:1 and 50.0:1, an eminently satisfactory value having been found to be of the order of 36.0:1. The gaskets are preferably compressible and may be suitably composed of a cellular elastomer in which the cells may be unconnected or interconnected depending upon the application contemplated for the lifter. The ratio of the area within the second gasket to the area within the first gasket should be between 2.5 :1 and 16.0:1, a preferred range being between 4.0:1 and 13.0: 1, and an eminently satisfactory ratio being of the order of 5.0:1. A more complete understanding of the invention will follow from a description of the accompanying drawings wherein: FIG. 1 is a somewhat diagrammatic representation in side elevation of a lifter applied to a load and connected with a vacuum pump through a reservoir; FIG. 2 is a perspective view of a lifter conforming to the present invention;

**[p0003]**

FIG. 3 is a bottom plan view of a lifter embodying the invention; FIG. 4 is a section taken along line 4-4 of FIG. 3; and FIG. 5 is a section, on an enlarged scale taken along line 5-5 of FIG. 3. A lifter 19 illustrated in the drawings comprises a frame or plate 12 to one surface of which are secured by means of adhesive, or in other suitable fashion, an inner gasket 14 and an outer gasket 16. Referring to FIG. 3 it will be observed that the inner gasket 14 defines with the frame or plate 12 an open chamber 18 containing a port 20 for communication with a source of reduced pressure. A nipple 22 serves to connect the port 20 through a hose 24 with a reservoir 26 connected to the suction side of a vacuum pump 28. The outer gasket 16 defines a chamber 30 with the frame or plate 12 and the inner gasket 14. The inner chamber 18 is connected with the outer chamber 30 by passage means, which may assume the form of small diameter tubes 34, extending through the inner gasket 14 and having an aggregate cross sectional area less than the cross sectional area of the port 20 through which the inner chamber 18 communicates with the vacuum pump 28.

**[p0004]**

The surface of the frame or plate 12 opposed to that bearing the gaskets is provided with a pair of lugs 36, Welded or otherwise secured to the plate 12, containing openings 38 for the reception of hooks or cables 40 for cooperation with a crane or other lifting device for elevating the lifter together with its load 42. Among the lifters that have been constructed in accordance With the present invention, is one having a lifting capacity of 5 tons wherein the volume within the inner gasket is 0.28 cubic feet and the volume within the outer gasket is 1.18 cubic feet. For this lifter, a vacuum pump having a capacity of one-third horsepower is employed and the diameter of the port 20 is one and one-half inches. Each of the four tubes 34 shown as providing communication between the inner and outer chambers has an inside diameter of one-eighth inch. With this equipment, a vacuum corresponding to twenty inches of mercury is established within a few seconds in both the inner and outer chambers. To release the lifter from the load, atmospheric pressure is admitted to the inner chamber 18 whereby release of the load is also effected within a few seconds.

**[p0005]**

As will be observed from FIG. 4, the inner and outer gaskets project substantially the same distance from the frame or plate and their composition may be similar. Experimental work has indicated that the ratio of the area of the port 20 to the aggregrate area of the fluid passage means may be between 1.1:1 and 96.0: 1. However, for the more practical applications of the invention requiring quick response, the preferred range of such a ratio is between 25.0:1 and 50.0:1. A ratio of 36.0:1 has been found to be eminently satisfactory in conjunction with the lifter specifically described above. Satisfactory results have been achieved with lifters conforming to the present invention wherein the ratio of the area within the second gasket to the area within the first gasket is between 25:1 and 16.0:1, a preferred range being between 4.0:1 and 13.0:1. With respect to the lifter specifically described above, this ratio is 5.0:1 and produces highly acceptable results. In using the lifter, it will be moved into contact with the work 42 until the proximate surface of the inner gasket 14 contacts the surface of the work, whereupon the vacuum connection will be effected by manipulating a valve 44 to remove air from the inner chamber 18 very rapidly through the relatively large port 20. Inasmuch as the port 20 has an area exceeding the aggregate areas of the passages between the inner and outer chambers, the inner chamber 18 will become evacuated so that atmospheric pressure acting on the outer surface of the plate or frame 12 will cause the gasket 14 to become deformed so as to effect a

**[p0005]**

relatively tight seal with the surface of the work. When the pressure within the chamber 18 becomes suificiently reduced, air will be drawn through the passages 34, and since the inner gasket 14 has become deformed so as to permit the lifter as an entirety to move closer to the work, a seal will also be effected between the outer gasket 16 and the work. Accordingly, when the outer chamber 30 has also been evacuated, the lifting operation can be effected. When it is desired to release the load from the lifter, it is merely necessary to admit atmospheric pressure to the inner chamber 18, which may also be achieved by operation of the valve 44 which may assume the form of a conventional three-way valve.

**[p0006]**

Whereas only one example of the invention has been described with reference to the drawings, such variations as will occur to those skilled in the art are contemplated as coming within the scope of the appended claims. I claim: 1. A vacuum lifter comprising a frame having opposed surfaces, 21 first deformable resilient gasket secured to one of said surfaces defining an open inner chamber with said frame, means defining a port for connecting said inner chamber with a source of reduced pressure, a second deformable resilient gasket surrounding said first gasket and spaced therefrom defining an open outer chamber with said frame and first gasket, and means defining fluid passage means interconnecting said chambers, said passage means being smaller in area than said port. 2. A vacuum lifter according to claim 1 wherein the ratio of the area of said port to the area of said fluid passage means is between 1.1:1 and 96.0: 1. 3. A vacuum lifter according to claim 1 wherein the ratio of the area of said port to the area of said fluid passage means is between 25.0:1 and 50.0:1.

**[p0007]**

4. A vacuum lifter according to claim 1 wherein the ratio of the area of said port to the area of said fluid passage means is of the order of 36.0: 1. 5. A vacuum lifter according to claim 1 wherein said gaskets are compressible. 6. A vacuum lifter according to claim 1 wherein said gaskets are composed of a cellular elastomer. 7. A vacuum lifter according to claim 1 wherein the ratio of the area within said second gasket to the area Within said first gasket is between 2.531 and 16.021. 8. A vacuum lifter according to claim 1 wherein the ratio or&#34; the area within said second gasket to the area Within said first gasket is between 4.0:1 and 13.0: 1. 9. A vacuum lifter according to claim l wherein the ratio of the area within said second gasket to the area within said first gasket is of the order of 5.021. References Cited in the file of this patent UNITED STATES PATENTS 3,055,694 Billner Sept. 25, 1962 3,063,746 Dakes Nov. 13, 1962 3,089,723 Fartson May 14, 1963

## Figure captions

- **Figure 4:** VACUUM LIFTER Filed Feb. 7, 1963 4 PIC-3.3 FIG.4
- **Figure 1:** FIG. 1 is a somewhat diagrammatic representation in side elevation of a lifter applied to a load and connected with a vacuum pump through a reservoir;
- **Figure 2:** FIG. 2 is a perspective view of a lifter conforming to the present invention;
- **Figure 3:** FIG. 3 is a bottom plan view of a lifter embodying the invention;
- **Figure 4:** FIG. 4 is a section taken along line 4-4 of FIG. 3; and
- **Figure 5:** FIG. 5 is a section, on an enlarged scale taken along line 5-5 of FIG. 3.
- **Figure 4:** As will be observed from FIG. 4, the inner and outer gaskets project substantially the same distance from the frame or plate and their composition may be similar.

## Classifications

- B66C1/0281
- B66C1/0281
- B66C1/02
- B66C1/0231
- B66C1/0231
- B66C1/0293
- B66C1/0293

## Cited patent documents

- [US-3055694-A](https://patents.google.com/patent/US3055694A/en) — SEA
- [US-3063746-A](https://patents.google.com/patent/US3063746A/en) — SEA
- [US-3089723-A](https://patents.google.com/patent/US3089723A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
