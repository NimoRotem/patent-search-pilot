# 16. Vacuum lifting appliance

- **Archive rank:** 16 of 50
- **Publication:** [DE-3834866-A1](https://patents.google.com/patent/DE3834866A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/006365027/publication/DE3834866A1?q=pn%3DDE3834866A1)
- **Publication date:** 1990-04-19
- **Filing date:** 1988-10-13
- **Earliest priority:** 1988-10-13
- **Family:** 6365027
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** LEWECKE GMBH MASCHBAU
- **Inventors:** LEWECKE ERNST

## Abstract

The vacuum lifting appliance for flat workpieces, such as boards, plates, planks of wood or wooden material, has in a known manner at least one suction plate (2) having one or more suction chambers (3) and a valve control (6) for forming and releasing the vacuum in each suction chamber (3). Here, according to the invention, each suction chamber (3) of the suction plate (2) is connected via a suction line (4) to a separate control valve (6) which is arranged separately from the suction plate (2) on the lifting appliance, is adjustable in its suction force, preferably infinitely adjustable, and can be locked at the suction-force setting. Each suction line (4) is formed by a flexible hose line attached with one end to a connection piece (7) of the suction-plate chamber (3) and with its other end to a straight or angular connection socket (8) of the control valve (6). Each control valve (6) is preferably constructed as a ball valve whose suction passage accommodating the ball is infinitely variable in its length and thus in ball travel and in air-passage cross-section and can be locked in its set size, this valve (6) exhibiting a valve sleeve (12) forming the suction passage and a setting sleeve (13) which can be screwed with respect to the valve sleeve (12). &lt;IMAGE&gt;

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-3834866-A1/ops000.png)

![Sketch 1 for DE-3834866-A1](https://nimo.iptorch.com/refdrawing/DE-3834866-A1/ops000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-3834866-A1/ops001.png)

![Sketch 2 for DE-3834866-A1](https://nimo.iptorch.com/refdrawing/DE-3834866-A1/ops001.png)

## Claims

### Claim 1 (independent)

Vakuum-Hebevorrichtung für flächige Werkstücke, wie Bretter, Platten Bohlen aus Holz oder Holzwerkstoff, mit mindestens einer eine oder mehrere Saugkammern aufweisenden Saugplatte mit Ventilsteuerung für die Vakuumbildung und -auflösung in jeder Saugkammer, dadurch gekennzeichnet, daß jede Saugkammer (3) der Saugplatte (2) über eine Saugleitung (4) mit einem eigenen, separat zur Saugplatte (2) an der Hebevorrichtung angeordnetem Steuerventil (6) verbunden ist, welches in seiner Saugkraft einstellbar und in der Saugkrafteinstellung arretierbar ist.1. Vacuum lifting device for flat workpieces, such as boards, boards, planks made of wood or wood material, with at least one suction plate having one or more suction chambers with valve control for vacuum formation and dissolution in each suction chamber, characterized in that each suction chamber ( 3 ) Suction plate ( 2 ) is connected via a suction line ( 4 ) to its own control valve ( 6 ) which is arranged separately from the suction plate ( 2 ) on the lifting device and which can be adjusted in its suction force and locked in the suction force setting.

### Claim 2

Vakuum-Hebevorrichtung nach Anspruch 1, dadurch gekennzeichnet, daß jedes Steuerventil (6) in seiner Saugwirkung stufenlos einstellbar ausgebildet ist.2. Vacuum lifting device according to claim 1, characterized in that each control valve ( 6 ) is infinitely adjustable in its suction effect.

### Claim 3

Vakuum-Hebevorrichtung nach Anspruch 1 und 2, dadurch gekennzeichnet, daß jede Saugleitung (4) von einer flexiblen Schlauchleitung gebildet ist, die mit einem Ende an ein Anschlußstück (7) der Saugplattenkammer (3) und mit ihrem anderen Ende an eine geradlinige oder winklige Anschlußtülle (8) des Steuerventiles (6) angeschlossen ist.3. Vacuum lifting device according to claim 1 and 2, characterized in that each suction line ( 4 ) is formed by a flexible hose which has one end to a connector ( 7 ) of the suction plate chamber ( 3 ) and with its other end to a straight line or angled connecting sleeve ( 8 ) of the control valve ( 6 ) is connected.

### Claim 4

Vakuum-Hebevorrichtung nach den Ansprüchen 1 bis 3, dadurch gekennzeichnet, daß jedes Steuerventil (6) von einem Kugelventil gebildet ist, dessen die Kugel (9) aufnehmender Saugkanal (10) in seiner Länge und somit im Kugel-Hubweg und im Luft-Durchströmquerschnitt stufenlos veränderbar und in seiner eingestellten Größe arretierbar ist. Vacuum lifting device according to claims 1 to 3, characterized in that each control valve ( 6 ) is formed by a ball valve, the ball ( 9 ) receiving suction channel ( 10 ) in its length and thus in the ball stroke and in the air -The flow cross-section is infinitely variable and can be locked in its set size.

### Claim 5

Vakuum-Hebevorrichtung nach den Ansprüchen 1 bis 4, dadurch gekennzeichnet, daß das Steuerventil (6) eine mit einem Längenende an einen Vakuumverteiler (11) anschließbare Ventilhülse (12) mit mehrfach abgestuftem Saugkanal (10) und eine auf das andere Längenende der Ventilhülse (12) aufgeschraubte, gegenüber der Ventilhülse (12) in der Axiallänge verstellbare Einstellhülse (13) mit darin eingesetztem Ventilteller (14) und an der Einstellhülse (13) lösbar gehaltener Anschlußtülle (8) aufweist und die Einstellhülse (13) gegenüber der Ventilhülse (12) in der eingestellten Stellung durch eine Anschlagmutter (15 a) und eine Kontermutter (15 b) fixiert ist.5. Vacuum lifting device according to claims 1 to 4, characterized in that the control valve ( 6 ) with a length end to a vacuum distributor ( 11 ) connectable valve sleeve ( 12 ) with multi-graded suction channel ( 10 ) and one on the other length of the Has valve sleeve ( 12 ) screwed on, with respect to the valve sleeve ( 12 ) adjustable in axial length adjusting sleeve ( 13 ) with a valve disc ( 14 ) inserted therein and on the adjusting sleeve ( 13 ) detachably held connecting sleeve ( 8 ) and the adjusting sleeve ( 13 ) opposite the valve sleeve (12) (15 b) is fixed in the adjusted position by a stop nut (15 a) and a lock nut.

### Claim 6

Vakuum-Hebevorrichtung nach den Ansprüchen 1 bis 5, dadurch gekennzeichnet, daß der Saugkanal (10) von einem an dem der Einstellhülse (13) benachbarten Längenende liegenden, im Querschnitt größer als der Durchmesser der Kugel (9) ausgeführten, durch die Einstellhülse (13) in seiner Länge veränderbaren Kanalteil (10 a), einem sich daran anschließenden, im Querschnitt kleiner als das Kanalteil (10 a) jedoch geringfügig größer als der Kugel-Durchmesser ausgebildeten mittleren Kanalteil (10 b) und einem sich daran anschließenden, im Querschnitt kleiner als der Durchmesser der Kugel (9) ausgeführten und einen Schließsitz (16) für die Kugel (9) bildenden Kanalteil (10 c) gebildet ist. Vacuum lifting device according to claims 1 to 5, characterized in that the suction channel ( 10 ) from one at which the adjusting sleeve ( 13 ) adjacent length end, larger in cross section than the diameter of the ball ( 9 ), through the adjusting sleeve ( 13 ) length-adjustable channel part ( 10 a ), an adjoining, in cross-section smaller than the channel part ( 10 a ) but slightly larger than the ball diameter formed middle channel part ( 10 b ) and an adjoining, in Cross section smaller than the diameter of the ball ( 9 ) and a closing seat ( 16 ) for the ball ( 9 ) forming channel part ( 10 c ) is formed.

### Claim 7

Vakuum-Hebevorrichtung nach den Ansprüchen 1 bis 6, dadurch gekennzeichnet, daß das mittlere Kanalteil (10 b) des Saugkanales (10) in Längsrichtung zylindrisch oder zum Kugel-Schließsitz (16) hin konisch verengt ausgebildet ist.7. Vacuum lifting device according to claims 1 to 6, characterized in that the central channel part ( 10 b ) of the suction channel ( 10 ) is cylindrical in the longitudinal direction or conically narrowed towards the ball-closing seat ( 16 ).

### Claim 8

Vakuum-Hebevorrichtung nach den Ansprüchen 1 bis 7, dadurch gekennzeichnet, daß in die Einstellhülse (13) ein Ventilteller (14), vorzugsweise aus Kunststoff, mit mehreren Luft-Durchströmbohrungen (17) und einer kalottenförmigen Kugelauflage (18) eingepreßt ist.8. Vacuum lifting device according to claims 1 to 7, characterized in that in the adjusting sleeve ( 13 ), a valve plate ( 14 ), preferably made of plastic, with a plurality of air flow-through holes ( 17 ) and a spherical spherical support ( 18 ) is pressed.

### Claim 9

Vakuum-Hebevorrichtung nach den Ansprüchen 1 bis 8, dadurch gekennzeichnet, daß die Ventilhülse (12), vorzugsweise aus Kunststoff, bis auf einen Ansatzbund (19) für ein Werkzeug auf ihrer gesamten Länge mit einem Außengewinde (20) ausgestattet ist und dabei der Ansatzbund (19) außerhalb der Ventilhülsen- Längenhalbierenden und nahe dem der Einstellhülse (13) abgewandten Ventilhülsenende angeordnet ist.9. Vacuum lifting device according to claims 1 to 8, characterized in that the valve sleeve ( 12 ), preferably made of plastic, except for a shoulder collar ( 19 ) for a tool along its entire length is equipped with an external thread ( 20 ) and thereby the shoulder collar ( 19 ) is arranged outside the valve sleeve length bisector and near the valve sleeve end facing away from the adjusting sleeve ( 13 ).

### Claim 10

Vakuum-Hebevorrichtung nach den Ansprüchen 1 bis 9, dadurch gekennzeichnet, daß die Einstellhülse (13) topfartig ausgebildet ist, mit ihrem Innenraum (13 a) einen verstellbaren Saugbereich mit dem Saugkanal (10) ergibt und im Innenraum (13 a) ein Innengewinde (21) zum Aufschrauben auf die Ventilhülse (12) hat sowie im Anschluß an den den Innenraumboden bildenden Ventilteller (14) eine innenliegende, gleichzeitig einen Luft-Durchflußkanal bildende Werkzeugaufnahme (23), vorzugsweise Mehrkantaufnahme, und ein Außengewinde (22) für die lösbare Befestigung der Anschlußtülle (8) zeigt. Vacuum lifting device according to claims 1 to 9, characterized in that the adjusting sleeve ( 13 ) is pot-shaped, with its interior ( 13 a ) gives an adjustable suction area with the suction channel ( 10 ) and in the interior ( 13 a ) Has internal thread ( 21 ) for screwing onto the valve sleeve ( 12 ) and, following the valve disc ( 14 ) forming the interior floor, an internal tool holder ( 23 ), preferably a multi-edge holder, which also forms an air flow channel, and an external thread ( 22 ) for the releasable attachment of the connecting sleeve ( 8 ) shows.

### Claim 11

Vakuum-Hebevorrichtung nach den Ansprüchen 1 bis 10, dadurch gekennzeichnet, daß jedes Steuerventil (6) mit seiner Ventilhülse (12) direkt an den Vakuumverteiler (11) angeschlossen ist.11. Vacuum lifting device according to claims 1 to 10, characterized in that each control valve ( 6 ) with its valve sleeve ( 12 ) is connected directly to the vacuum distributor ( 11 ).

### Claim 12

Vakuum-Hebevorrichtung nach den Ansprüchen 1 bis 10, dadurch gekennzeichnet, daß jedes Steuerventil (6) mit seiner Ventilhülse (12) an ein T-Stück (24) angeschlossen ist, welches in eine mit dem Vakuumverteiler (11) verbundene Rohrleitung (25) für den Anschluß mehrerer Steuerventile (6) eingesetzt ist.12. Vacuum lifting device according to claims 1 to 10, characterized in that each control valve ( 6 ) with its valve sleeve ( 12 ) is connected to a T-piece ( 24 ) which in a pipeline connected to the vacuum distributor ( 11 ) ( 25 ) is used for connecting several control valves ( 6 ).

### Claim 13

Vakuum-Hebevorrichtung nach den Ansprüchen 1 bis 12, dadurch gekennzeichnet, daß jede Saugplatte (2) mittels Gelenkorganen (27) an einen Hubrahmen (5) mit Hubführungen (31) aufgehängt ist und dabei der Hubrahmen (5) aus Hohlprofilen gebildet ist, die den oder die Vakuumverteiler (11) und mindestens einen Vakuumspeicher (28) bilden.13. Vacuum lifting device according to claims 1 to 12, characterized in that each suction plate ( 2 ) by means of articulated members ( 27 ) on a lifting frame ( 5 ) with lifting guides ( 31 ) is suspended and the lifting frame ( 5 ) is formed from hollow profiles Which form the vacuum distributor (s) ( 11 ) and at least one vacuum accumulator ( 28 ).

### Claim 14

Vakuum-Hebevorrichtung nach den Ansprüchen 1 bis 13, dadurch gekennzeichnet, daß jeder Vakuumverteiler (11) über eine Rohrleitung (29) und einen darin eingesetzten Filter (30) mit dem Vakuumspeicher (28) verbunden ist, der über eine Saugleitung (32) mit Hauptventil an einen Vakuumerzeuger angeschlossen ist. Vacuum lifting device according to claims 1 to 13, characterized in that each vacuum distributor ( 11 ) via a pipe ( 29 ) and a filter ( 30 ) inserted therein is connected to the vacuum accumulator ( 28 ), which via a suction line ( 32 ) is connected to a vacuum generator with the main valve.

### Claim 15

Vakuum-Hebevorrichtung nach einem oder mehreren der vorhergehenden Ansprüche 1 bis 14, dadurch gekennzeichnet, daß jede Saugplatte (2) als haubenartiges Metallgußteil ausgebildet ist, deren umlaufende Haubenwandung (2 a) und dazwischenliegende, angeformte Stege (2 b) die Saugkammern (3) begrenzen und um jede Saugkammer (3) eine in der Saugplatte (2) festgelegte Dichtung (26), vorzugsweise Gummidichtung, angeordnet ist.15. Vacuum lifting device according to one or more of the preceding claims 1 to 14, characterized in that each suction plate ( 2 ) is designed as a hood-like metal casting, the circumferential hood wall ( 2 a ) and intermediate, molded webs ( 2 b ), the suction chambers ( 3 ) limit and around each suction chamber ( 3 ) a seal ( 26 ), preferably a rubber seal, is arranged in the suction plate ( 2 ).

## Full description

PERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippers

Description

Translated from German

Die Erfindung bezieht sich auf eine Vakuum-Hebevorrichtung

fÃ¼r flÃ¤chige WerkstÃ¼cke, wie Bretter, Platten, Bohlen oder

dergleichen, aus Holz oder Holzwerkstoff, mit mindestens

einer eine oder mehrere Saugkammern aufweisenden

Saugplatte mit Ventilsteuerung fÃ¼r die Vakuumbildung und

-auflÃ¶sung in jeder Saugkammer.The invention relates to a vacuum lifting device

for flat workpieces such as boards, boards, planks or

the like, of wood or wood-based material, with at least

one having one or more suction chambers

Suction plate with valve control for vacuum formation and

-resolution in each suction chamber.

Bei derartigen bekannten Vakuum-Hebevorrichtungen ist die

Ventilsteuerung in Form eines Kugel- oder Scheibenventiles

in Saugrichtung unmittelbar hinter den Saugkammern

angeordnet, so daÃ der auf den WerkstÃ¼cken liegende

Schmutz, wie Staub, SpÃ¤ne od. dgl., in die Ventile

eindringen kann, dadurch die Ventile in ihrer Saugwirkung

stark beeintrÃ¤chtigt und die verschmutzten Ventile hÃ¤ufig

gesÃ¤ubert werden mÃ¼ssen.In such known vacuum lifting devices

Valve control in the form of a ball or disc valve

in the suction direction immediately behind the suction chambers

arranged so that the lying on the workpieces

Dirt, such as dust, chips or the like, in the valves

can penetrate, thereby the valves in their suction

badly affected and the dirty valves frequently

need to be cleaned.

Auch die am und im Holz vorhandenen aggressiven LÃ¶sungen

gelangen direkt in die Ventile und erqeben zusÃ¤tzliche

BeeintrÃ¤chtigungen in der Ventilsteuerung.

Also the aggressive solutions on and in the wood

get directly into the valves and generate additional ones

Impairments in valve control.

Â

Sofern die Saugplatten an ihrer Saugseite mit einer

Schaumstoffschicht ausgestattet sind, bewirken diese

aggressiven LÃ¶sungen ein VerhÃ¤rten und ZerstÃ¶ren der

Schaumstoffschicht, was einerseits die Saugwirkung

unzureichend macht und andererseits die Standzeit stark

reduziert und ein hÃ¤ufiges Auswechseln der SchaumstoffÂ­

schichten erfordert.If the suction plates on their suction side with a

Foam layer are equipped, cause this

aggressive solutions a hardening and destruction of the

Foam layer, on the one hand, the suction effect

insufficient and on the other hand the service life is strong

reduced and a frequent replacement of the foam

stratification requires.

Aufgabe der Erfindung ist es, eine nach der eingangs

genannten Art aufgebaute Vakuum-Hebevorrichtung mit einer

Ventilsteuerung auszustatten, die gegenÃ¼ber Schmutz- und

FeuchtigkeitseinflÃ¼ssen der zu hebenden WerkstÃ¼cke

geschÃ¼tzt und in ihrer Saugwirkung individuell einstellbar

ist, wobei auch beim eventuellen SÃ¤ubern der

Ventilsteuerung die eingestellte Saugwirkung beibehalten

und immer wieder erreicht wird.The object of the invention is one after the beginning

mentioned type constructed vacuum lifting device with a

Equip valve control that is against dirt and

Influence of moisture on the workpieces to be lifted

protected and individually adjustable in suction

is, even when cleaning the

Valve control maintain the set suction effect

and is always achieved.

Diese Aufgabe wird erfindungsgemÃ¤Ã durch die

kennzeichnenden Merkmale des Patentanspruches 1 gelÃ¶st,

wobei noch die in den einzelnen UnteransprÃ¼chen

aufgefÃ¼hrten Gestaltungsmerkmale vorteilhafte

Weiterbildungen der AufgabenlÃ¶sung darstellen.This object is achieved by the

characterizing features of claim 1 solved,

with those in the individual subclaims

design features listed advantageous

Represent further training in task solving.

Durch die Erfindung ist die Vakuum-Hebevorrichtung fÃ¼r

jede Saugkammer ihrer Saugplatten mit einer im groÃen

Abstand zu den Saugkammern angeordneten Ventilsteuerung

ausgestattet worden, so daÃ der bei der Saugwirkung

mitgenommene Schmutz (Staub, SpÃ¤ne, aggressive LÃ¶sungen)

nicht bis in die Ventilsteuerungen gelangen und somit

keine BeeintrÃ¤chtigungen auf die Ventilsteuerungen

ausÃ¼ben kÃ¶nnen.

By the invention, the vacuum lifting device for

each suction chamber of their suction plates with one in large

Distance to the suction chamber arranged valve control

been equipped so that the suction

entrained dirt (dust, chips, aggressive solutions)

not get into the valve controls and thus

no impairments on the valve controls

can exercise.

Â

Zwischen Saugkammer und Steuerventil ist jeweils eine

lÃ¤ngere Schlauchleitung verlegt, aus der dann der Schmutz

und die Feuchtigkeit nach unten wieder herausfallen bzw.

abflieÃen kann.There is one between the suction chamber and the control valve

longer hose line from which the dirt then

and the moisture falls out downwards or

can drain off.

Weiterhin ist jedes Steuerventil bei einfachem Aufbau in

seiner Saugkraft individuell einstellbar und diese

eingestellte Lage wird auch bei eventuellen Reinigungen

der Steuerventile bei erforderlicher teilweiser Demontage

beibehalten, so daÃ nach dem Zusammensetzen der

Steuerventile diese wieder ihre eingestellte Lage erhalten.Furthermore, each control valve is simple in construction

its suction power individually adjustable and this

The position will also be set for any cleaning

the control valves when partial disassembly is required

maintained so that after assembling the

Control valves get their set position again.

Die Einstellung der Saugwirkung erfolgt durch

LÃ¤ngenverÃ¤nderung des Saugkanales und somit

QuerschnittsverÃ¤nderung des Saugluftdurchstromes und diese

Einstellung ist stufenlos genau auf die Erfordernisse

durchfÃ¼hrbar und wird durch AnschlÃ¤ge arretiert, die auch

bei einer spÃ¤teren Demontage des Steuerventiles ihre Lage

beibehalten.The suction effect is set by

Change in length of the suction channel and thus

Change in cross section of the suction air flow and this

Adjustment is continuously precise to the requirements

feasible and is locked by stops that also

their position when the control valve is dismantled later

maintained.

Die besonderen Merkmale der Saugplattenausbildung nach

Anspruch 15 lÃ¶st die Aufgabenstellung nach einer einfachen,

sicher wirkenden und dauerhaft haltbaren Saugplatte.

The special features of the suction plate formation after

Claim 15 solves the task according to a simple,

safe acting and durable suction plate.

Â

Auf den Zeichnungen ist ein AusfÃ¼hrungsbeispiel der

Erfindung dargestellt, welches nachfolgend nÃ¤her erlÃ¤utert

wird. Es zeigt:In the drawings, an embodiment of the

Invention shown, which is explained in more detail below

becomes. It shows:

Fig. 1 eine perspektivische Darstellung einer Vakuum-

Hebevorrichtung mit einer Vielzahl an Hubrahmen

angeordneter Saugplatten, Fig. 1 is a perspective view of a vacuum lifter with a plurality of lifting frame arranged suction plates,

Fig. 2 eine Vorderansicht im teilweisen Schnitt einer

an dem Hubrahmen beweglich aufgehÃ¤ngten

Saugplatte mit Saugleitungen und Steuerventilen, Fig. 2 is a front view in partial section of a movably suspended on the lifting frame suction plate with suction pipes and control valves,

Fig. 3 einen senkrechten Schnitt durch ein in seiner

Saugkraft einstellbares Steuerventil in einer

eingestellten Stellung, Fig. 3 is a vertical section through an adjustable in its suction control valve in a set position,

Fig. 4 einen senkrechten Schnitt durch dasselbe

Steuerventil in einer zweiten eingestellten

Stellung, Fig. 4 is a vertical section through the same control valve in a second adjusted position,

Fig. 5 eine Vorderansicht in Explosionsdarstellung der

Einzelteile des Steuerventiles. Fig. 5 is an exploded front view of the individual parts of the control valve.

Die Vakuum-Hebevorrichtung (Vakuum-HebegerÃ¤t) fÃ¼r flÃ¤chige

WerkstÃ¼cke (1), wie Bretter, Platten, Bohlen aus Holz oder

Holzwerkstoff, weist mindestens eine, vorzugsweise mehrere,

jeweils eine oder mehrere Saugkammern (3) besitzende

Saugplatten (2) mit Ventilsteuerung fÃ¼r die Vakuumbildung

und -auflÃ¶sung in jeder Saugkammer (3) auf.

The vacuum lifting device (vacuum lifting device) for flat workpieces ( 1 ), such as boards, plates, planks made of wood or wooden material, has at least one, preferably several suction plates ( 2 ) with one or more suction chambers ( 3 ) with valve control for the vacuum formation and dissolution in each suction chamber ( 3 ).

Jede Saugkammer (3) jeder Saugplatte (2) ist Ã¼ber eine

Saugleitung (4) mit einem eigenen, separat zur Saugplatte

(2) an der Vorrichtung, vorzugsweise einem Hubrahmen (5) ,

angeordneten Steuerventil (6) verbunden, welches in seiner

SÃ¤ugkraft einstellbar und in der Saugkrafteinstellung

arretierbar ist; die Ventileinstellung erfolgt in

bevorzugter Weise stufenlos in einem gewissen Bereich.Each suction chamber ( 3 ) of each suction plate ( 2 ) is connected via a suction line ( 4 ) to its own control valve ( 6 ), which is arranged separately from the suction plate ( 2 ) on the device, preferably a lifting frame ( 5 ), and which can be adjusted in terms of its suckling power and can be locked in the suction power setting; the valve setting is preferably carried out continuously in a certain range.

Jede Saugleitung (4) ist von einer flexiblen Schlauchleitung

gebildet, die mit einem Ende an ein AnschluÃstÃ¼ck (7) der

Saugplattenkammer (3) und mit ihrem anderen Ende an eine

geradlinige oder winklige AnschluÃtÃ¼lle (8) des

Steuerventiles (6) angeschlossen ist.Each suction line ( 4 ) is formed by a flexible hose line, which is connected at one end to a connection piece ( 7 ) of the suction plate chamber ( 3 ) and at the other end to a straight or angled connection nozzle ( 8 ) of the control valve ( 6 ).

In bevorzugter Weise ist jedes Steuerventil (6) von einem

Kugelventil gebildet, dessen Kugel (9) als SteuerkÃ¶rper in

einem in seiner LÃ¤nge stufenlos verÃ¤nderbaren und in der

eingestellten GrÃ¶Ãe arretierbaren Saugkanal (10) frei

beweglich untergebracht ist; durch diesen einstellbaren

Saugkanal (10) wird der Kugel-Hubweg und somit der Luft-

DurchstrÃ¶mquerschnitt bestimmt, welches die SaugkraftgrÃ¶Ãe

ergibt.Each control valve ( 6 ) is preferably formed by a ball valve, the ball ( 9 ) of which is housed as a control body in a freely movable suction channel ( 10 ) which can be changed in length and locked in the set size; This adjustable suction channel ( 10 ) determines the ball stroke and thus the air flow cross-section, which gives the suction force size.

Das Steuerventil (6) hat eine mit einem LÃ¤ngenende an einen

Vakuumverteiler (11) anschlieÃbare VentilhÃ¼lse (12) mit

mehrfach abgestuftem Saugkanal (10) und eine am anderen

VentilhÃ¼lsen-LÃ¤ngenende aufgeschraubte, gegenÃ¼ber der

VentilhÃ¼lse (12) in der AxiallÃ¤nge verstellbare

EinstellhÃ¼lse (13) mit darin angeordnetem Ventilteller

(14) und an der EinstellhÃ¼lse (13) anschlieÃbarer

AnschluÃtÃ¼lle (8); die EinstellhÃ¼lse (13) ist in der

eingestellten Stellung durch eine Anschlagmutter (15 a)

und eine Kontermutter (15 b) fixierbar.

The control valve ( 6 ) has a valve sleeve ( 12 ) with a length end that can be connected to a vacuum distributor ( 11 ) with a multi-step suction channel ( 10 ) and an adjusting sleeve ( 13 ) that is screwed onto the other valve sleeve length end and that is adjustable in axial length relative to the valve sleeve ( 12 ) ) with a valve plate ( 14 ) arranged therein and a connecting sleeve ( 8 ) which can be connected to the adjusting sleeve ( 13 ); the adjustment sleeve (13) is fixable in the adjusted position by a stop nut (15 a) and a lock nut (15 b).

Der Saugkanal (10) ist von einem an dem der EinstellhÃ¼lse

(13) benachbarten LÃ¤ngenende liegenden, im Querschnitt

grÃ¶Ãer als der Kugel-Durchmesser ausgefÃ¼hrten

Kanalteil (10 a), einem sich daran anschlieÃenden, im

Querschnitt gegenÃ¼ber dem Kanalteil (10 a) verkleinerten,

jedoch gegenÃ¼ber dem Durchmesser der Kugel (9) geringfÃ¼gig

grÃ¶Ãer ausgebildeten mittleren Kanalteil (10 b) und

einem sich daran anschlieÃenden, im Querschnitt kleiner

als der Kugel-Durchmesser ausgefÃ¼hrten und einen

SchlieÃsitz (16) fÃ¼r die Kugel (9) ergebenden Kanalteil

(10 c) gebildet, wobei die beiden Kanalteile (10 a, 10 b)

mit der EinstellhÃ¼lse (13) den in der LÃ¤nge einstellbaren

Saugkanal (10) und Hubbereich der Kugel (9) ergeben.The suction channel ( 10 ) is from a channel part ( 10 a ) which is larger in cross-section than the ball diameter and which is located at the length end adjacent to the adjusting sleeve ( 13 ), and an adjoining section with a smaller cross-section than the channel part ( 10 a ). however, compared to the diameter of the ball ( 9 ) slightly larger middle channel part ( 10 b ) and an adjoining, smaller in cross section than the ball diameter and a closing seat ( 16 ) for the ball ( 9 ) resulting channel part ( 10 c ) formed, the two channel parts ( 10 a , 10 b ) with the adjusting sleeve ( 13 ) giving the length-adjustable suction channel ( 10 ) and stroke range of the ball ( 9 ).

Der mittlere Kanalteil (10 b) lÃ¤Ãt sich auf seiner gesamten

LÃ¤nge zylindrisch ausbilden oder aber er verengt sich vom

Kanalteil (10 a) aus bis zum SchlieÃsitz (16) allmÃ¤hlich

konisch.The middle channel part ( 10 b ) can be cylindrical over its entire length or it narrows gradually from the channel part ( 10 a ) to the closing seat ( 16 ) conically.

In der topffÃ¶rmigen EinstellhÃ¼lse (13) ist der vorzugsweise

aus Kunststoff bestehende Ventilteller (14) eingepreÃt und

dieser Ventilteller (14) hat mehrere, vorzugsweise vier,

DurchstrÃ¶mlÃ¶cher (17) und eine kalottenfÃ¶rmige

Kugelauflage (18).The valve plate ( 14 ), which is preferably made of plastic, is pressed into the cup-shaped adjusting sleeve ( 13 ) and this valve plate ( 14 ) has several, preferably four, through-flow holes ( 17 ) and a spherical spherical support ( 18 ).

Der oberhalb des Kugeltellers (14) befindliche HÃ¼lsenraum

(13 a) geht in das Kanalteil (10 a) Ã¼ber und seine axiale

GrÃ¶Ãe verÃ¤ndert sich beim Einstellen der EinstellhÃ¼lse (13)

gegenÃ¼ber der VentilhÃ¼lse (12), so daÃ auch dieser

HÃ¼lsenraum (13 a) einen Teil des Saugkanales (10) ergibt

und den Luft-DurchstrÃ¶mquerschnitt mit bestimmt.

The sleeve space located above the ball disc (14) (13 a) passes into the channel portion (10 a) and its axial size changed when adjusting the adjusting sleeve (13) relative to the valve sleeve (12), so that this sleeve chamber (13 a ) results in part of the suction channel ( 10 ) and also determines the air flow cross section.

Die VentilhÃ¼lse (12), vorzugsweise aus Kunststoff, ist bis

auf einen Ansatzbund (19) fÃ¼r ein Werkzeug auf ihrer

gesamten LÃ¤nge mit einem AuÃengewinde (20) ausgestattet.

Der Ansatzbund (19) liegt auÃerhalb der LÃ¤ngenhalbierenden

der VentilhÃ¼lse (12) und auf den lÃ¤ngeren mit AuÃengewinde

(20) versehenen Ventilbereich sind die Muttern (15 a, 15 b)

und die EinstellhÃ¼lse (13) aufgeschraubt.The valve sleeve ( 12 ), preferably made of plastic, is provided with an external thread ( 20 ) over its entire length apart from a shoulder collar ( 19 ) for a tool. The shoulder collar ( 19 ) lies outside the length bisector of the valve sleeve ( 12 ) and the nuts ( 15 a , 15 b ) and the adjusting sleeve ( 13 ) are screwed onto the longer valve area provided with an external thread ( 20 ).

Die EinstellhÃ¼lse (13) ist mit ihrem im HÃ¼lsenraum (14 a)

vorgesehenen Innengewinde (21), das sich an den

eingepreÃten Kugelteller (14) anschlieÃt, auf die

VentilhÃ¼lse (12) aufgeschraubt und zeigt ein AuÃengewinde

(22) fÃ¼r die lÃ¶sbare Befestigung der SchlauchtÃ¼lle (8)

sowie besitzt im AnschluÃ an den Kugelteller (14) eine

innenliegende Werkzeugaufnahme (23), wie Innenmehrkant,

in die ein Werkzeug zum Verdrehen der EinstellhÃ¼lse (13)

nach Abnahme der SchlauchtÃ¼lle (8) eingesetzt werden kann;

diese Werkzeugaufnahme (23) bildet gleichzeitig einen

Luft-DurchstrÃ¶mkanal.The adjusting sleeve ( 13 ) is screwed onto the valve sleeve ( 12 ) with its internal thread ( 21 ) provided in the sleeve space ( 14 a ), which adjoins the pressed-in ball plate ( 14 ), and shows an external thread ( 22 ) for the releasable fastening of the Hose nozzle ( 8 ) as well as following the ball plate ( 14 ) has an internal tool holder ( 23 ), such as an internal polygon, into which a tool for rotating the adjusting sleeve ( 13 ) can be inserted after removing the hose nozzle ( 8 ); this tool holder ( 23 ) simultaneously forms an air flow channel.

Jedes Steuerventil (6) ist mit seiner VentilhÃ¼lse (12),

und zwar dem oberen AuÃengewinde (20), direkt an den

Vakuumverteiler (11) oder aber an ein T-StÃ¼ck (24)

angeschlossen, welches in eine Rohrleitung (25) eingesetzt

ist, die mit dem Vakuumverteiler (11) in Verbindung steht

und an die sich mehrere Steuerventile (6) Ã¼ber T-StÃ¼cke

(24) anschlieÃen lassen.Each control valve ( 6 ) is connected with its valve sleeve ( 12 ), namely the upper external thread ( 20 ), directly to the vacuum distributor ( 11 ) or to a T-piece ( 24 ) which is inserted into a pipeline ( 25 ) , which is connected to the vacuum distributor ( 11 ) and to which several control valves ( 6 ) can be connected via T-pieces ( 24 ).

Jede Saugplatte (2) ist als haubenartiges MetallguÃteil

ausgefÃ¼hrt, wobei die umlaufende Haubenwandung (2 a) und

dazwischenliegende angeformte Stege (2 b) die Saugkammern (3)

begrenzen. Um jede Saugkammer (3) ist eine in der Saugplatte

(2) festgelegte Dichtung (26), vorzugsweise Gummidichtung

angeordnet.

Each suction plate ( 2 ) is designed as a hood-like metal casting, the circumferential hood wall ( 2 a ) and molded webs ( 2 b ) therebetween delimiting the suction chambers ( 3 ). Around each suction chamber ( 3 ) a seal ( 26 ), preferably a rubber seal, is arranged in the suction plate ( 2 ).

Die Saugplatten (2) sind mittels Gelenkorgane (27) an dem

Hubrahmen (5) beweglich und somit sich an die WerkstÃ¼cke

(1) lagemÃ¤Ãig anpassend aufgehÃ¤ngt. Der Hubrahmen (5) ist

aus Hohlprofilen gebildet, die den Vakuumverteiler (11)

und einen Vakuumspeicher (28) bilden.The suction plates ( 2 ) can be moved on the lifting frame ( 5 ) by means of articulated members ( 27 ) and are thus suspended in a positionally adapting manner to the workpieces ( 1 ). The lifting frame ( 5 ) is formed from hollow profiles which form the vacuum distributor ( 11 ) and a vacuum accumulator ( 28 ).

Dabei ist der Vakuumverteiler (11) Ã¼ber eine Rohrleitung

(29) und einen dazwischengeschalteten Filter (30) mit dem

Vakuumspeicher (28) verbunden und der Vakuumspeicher (28)

steht mit einem Vakuumerzeuger und einem Hauptventil in

Verbindung.The vacuum distributor ( 11 ) is connected to the vacuum accumulator ( 28 ) via a pipe ( 29 ) and an interposed filter ( 30 ), and the vacuum accumulator ( 28 ) is connected to a vacuum generator and a main valve.

In Fig. 3 ist das Steuerventil (6) in einer eingestellten

Stellung dargestellt, bei der die EinstellhÃ¼lse (13) mit

ihrem Kugelteller (14) dicht an das untere Stirnende der

VentilhÃ¼lse (12) herangeschraubt ist und somit der Luft-

DurchstrÃ¶mquerschnitt verringert ist.In Fig. 3, the control valve ( 6 ) is shown in a set position, in which the adjusting sleeve ( 13 ) with its ball plate ( 14 ) is screwed close to the lower end of the valve sleeve ( 12 ) and thus the air flow cross section is reduced.

GemÃ¤Ã Fig. 4 ist die EinstellhÃ¼lse (13) gegenÃ¼ber der

VentilhÃ¼lse (12) verstellt und der Abstand zwischen

VentilhÃ¼lsen-StirnflÃ¤che und Ventilteller (14) vergrÃ¶Ãert,

was auch einen vergrÃ¶Ãerten Luft-DurchstrÃ¶mquerschnitt

ergibt und einen grÃ¶Ãeren Hubweg der Kugel (9)

ermÃ¶glicht; in dieser Stellung ist die Saugkraft grÃ¶Ãer

als in Fig. 3.According to FIG. 4, the adjusting sleeve ( 13 ) is adjusted relative to the valve sleeve ( 12 ) and the distance between the valve sleeve end face and the valve plate ( 14 ) is increased, which also results in an enlarged air flow cross section and enables a longer stroke of the ball ( 9 ); in this position the suction force is greater than in FIG. 3.

Diese Verstellung lÃ¤Ãt sich stufenlos auf die jeweilige

Saugwirkung und deren GrÃ¶Ãe durch Verschrauben der

EinstellhÃ¼lse (13) vornehmen und durch die Muttern (15 a,

15 b) fixieren. Bei einer eventuellen SÃ¤uberung des

Steuerventiles (6) wird die Saugleitung (4) mit ihrer

AnschluÃtÃ¼lle (8) von der EinstellhÃ¼lse (13) gelÃ¶st und

dann kann die EinstellhÃ¼lse (13) von der VentilhÃ¼lse (12)

abgeschraubt werden. Die Muttern (15 a, 15 b) behalten ihre

Lage bei, so daÃ die einmalige Einstellung der Saugkraft

nicht verÃ¤ndert wird und beim anschlieÃenden Anbringen

der EinstellhÃ¼lse (13) diese wieder dieselbe Stellung

einnimmt.This adjustment can be made continuously to the respective suction effect and its size by screwing the adjusting sleeve ( 13 ) and fixing it with the nuts ( 15 a , 15 b ). If the control valve ( 6 ) is cleaned, the suction line ( 4 ) with its connecting sleeve ( 8 ) is loosened from the adjusting sleeve ( 13 ) and then the adjusting sleeve ( 13 ) can be unscrewed from the valve sleeve ( 12 ). The nuts ( 15 a , 15 b ) maintain their position so that the one-time setting of the suction power is not changed and when the adjusting sleeve ( 13 ) is subsequently attached, it again assumes the same position.

Bei nicht vorhandener Saugwirkung liegt die Kugel (9),

wie in Fig. 3 und 4 gezeigt, auf dem Ventilteller (14) auf.

Ist die oder sind die Saugplatten (2) vollflÃ¤chig auf zu

hebende WerkstÃ¼cke (1) abgesenkt und die Saugluft ist

eingeschaltet, dann bewegt sich die Kugel (9) in dem

Saugkanal (13 a, 10 a, 10 b) je nach Einstellung der

SaugkanallÃ¤nge und somit SaugkraftgrÃ¶Ãe und dem

Falschluftanteil in eine schwebende Lage (strich-punktierte

Darstellung in Fig. 4) und das eingestellte Vakuum ist

erreicht.If there is no suction effect, the ball ( 9 ), as shown in FIGS. 3 and 4, rests on the valve plate ( 14 ). If the suction plates ( 2 ) have been completely lowered onto workpieces ( 1 ) to be lifted and the suction air is switched on, then the ball ( 9 ) moves in the suction channel ( 13 a , 10 a , 10 b ) depending on the setting of the suction channel length and thus the magnitude of the suction force and the proportion of false air in a floating position (dash-dotted representation in FIG. 4) and the set vacuum is reached.

Bei nicht vollflÃ¤chiger Auflage des oder der Saugplatten

(2) auf den WerkstÃ¼cken (1) ist der Falschluftanteil

grÃ¶Ãer als die Saugwirkung, so daÃ die Kugel (9) nach

oben gegen den SchlieÃsitz (16) gezogen wird und keine

Saugwirkung (kein Vakuum) entsteht.If the suction plate (s) ( 2 ) are not fully supported on the workpieces ( 1 ), the proportion of false air is greater than the suction effect, so that the ball ( 9 ) is pulled upwards against the closing seat ( 16 ) and no suction effect (no vacuum) is created .

Durch die Verstellung der EinstellhÃ¼lse (13) gegenÃ¼ber

der VentilhÃ¼lse (12) wird die LÃ¤nge des Saugkanales (10)

verÃ¤ndert und dadurch das Luftvolumen, welches zwischen

Kugel (9) und Saugkanal (10) durchstrÃ¶men kann, grÃ¶Ãer

oder kleiner und dementsprechend auch die Saugkraft

grÃ¶Ãer oder kleiner, was individuell auf die erforderliche

Tragkraft stufenlos eingestellt werden kann.

By adjusting the adjusting sleeve ( 13 ) in relation to the valve sleeve ( 12 ), the length of the suction channel ( 10 ) is changed and, as a result, the air volume that can flow between the ball ( 9 ) and suction channel ( 10 ) is larger or smaller and, accordingly, the suction force larger or smaller, which can be continuously adjusted to the required load capacity.

Die Anzahl der Saugplatten (2) an einer Vakuum-

Hebevorrichtung lÃ¤Ãt sich beliebig wÃ¤hlen bzw. den

gewÃ¼nschten Anforderungen nachrÃ¼sten. Auch kÃ¶nnen die

Saugplatten (2) mit den verschiedenen Anzahlen an

Saugkammern (3) ausgestattet und eingesetzt werden.The number of suction plates ( 2 ) on a vacuum lifting device can be chosen as desired or retrofitted to the desired requirements. The suction plates ( 2 ) can also be equipped and used with the different numbers of suction chambers ( 3 ).

Es liegt im Rahmen der Erfindung, anstelle von Kugelventilen

auch andere einstellbare Ventile, z. B. anstelle der Kugeln

(9) als SteuerkÃ¶rper Ventilscheiben oder Ventilkegel

einzusetzen.It is within the scope of the invention, instead of ball valves, other adjustable valves, for. B. instead of the balls ( 9 ) as a control body valve disks or valve cones.

Die SchlauchtÃ¼lle (8) ist in bekannter Weise von einem

Rohr- oder Winkelstutzen mit Ãberwurfmutter (8 a) gebildet.The hose nozzle ( 8 ) is formed in a known manner from a pipe or elbow with a union nut ( 8 a ).

Mit (31) sind HÃ¶henfÃ¼hrungen der Vorrichtung und mit (32)

die von einem Vakuumerzeuger zu dem Vakuumspeicher (28)

verlegten Saugluftleitungen bezeichnet.( 31 ) designates height guides of the device and (32) the suction air lines laid from a vacuum generator to the vacuum accumulator ( 28 ).

## Classifications

- B65G47/91
- B65G47/91

## Cited patent documents

- [DE-1186597-B](https://patents.google.com/patent/DE1186597B/en) — SEA
- [DE-3018082-A1](https://patents.google.com/patent/DE3018082A1/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
