# 28. Gantry type plate feeding and discharging manipulator for woodworking

- **Archive rank:** 28 of 50
- **Publication:** [CN-105397872-A](https://patents.google.com/patent/CN105397872A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/055463789/publication/CN105397872A?q=pn%3DCN105397872A)
- **Publication date:** 2016-03-16
- **Filing date:** 2015-11-30
- **Earliest priority:** 2015-11-30
- **Family:** 55463789
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** DONGGUAN NANXING FURNITURE MACHINERY & EQUIPMENT CO LTD
- **Inventors:** HAN MINGUO; HUANG DAQING; LI JUNQIANG; LI ZHONGDU; QI BO; ZHAO LILI; ZHOU SHUJUN

## Abstract

The invention discloses a gantry type plate feeding and discharging mechanical arm for woodworking, which comprises a composite conveying platform, a feeding device, a main body support, a horizontal moving device, a material grabbing device and a vertical moving device, wherein the composite conveying platform is arranged on the upper surface of the composite conveying platform; the material grabbing device comprises a stand column, a base, an opening and closing mechanism, a shaking anti-adhesion mechanism and at least two pressure-maintaining sucker groups; the feeding device is adopted for automatic feeding, so that the movement distance of the grabbing device in the vertical direction is reduced, the machine does not need to be stopped in the feeding process, and the production efficiency can be effectively improved; the material grabbing device adopts an automatic opening and closing mechanism, and the distance between the pressure-maintaining type sucker groups can be automatically adjusted according to the size of a plate, so that the sucker groups have a good stress state, and the abrasion of the suckers is reduced; the shaking anti-adhesion mechanism generates shaking action after grabbing materials, so that the adhesion of plates is effectively prevented; and make the grabbing device firmly hold panel under the power supply stop condition, avoid panel to drop to equipment, prevent simultaneously that the operating personnel from getting into the workspace after having a power failure, causing unnecessary injury.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-105397872-A/pdf000.png)

![Sketch 1 for CN-105397872-A](https://nimo.iptorch.com/refdrawing/CN-105397872-A/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-105397872-A/pdf001.png)

![Sketch 2 for CN-105397872-A](https://nimo.iptorch.com/refdrawing/CN-105397872-A/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/CN-105397872-A/pdf002.png)

![Sketch 3 for CN-105397872-A](https://nimo.iptorch.com/refdrawing/CN-105397872-A/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/CN-105397872-A/pdf003.png)

![Sketch 4 for CN-105397872-A](https://nimo.iptorch.com/refdrawing/CN-105397872-A/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/CN-105397872-A/pdf004.png)

![Sketch 5 for CN-105397872-A](https://nimo.iptorch.com/refdrawing/CN-105397872-A/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/CN-105397872-A/pdf005.png)

![Sketch 6 for CN-105397872-A](https://nimo.iptorch.com/refdrawing/CN-105397872-A/pdf005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/CN-105397872-A/pdf006.png)

![Sketch 7 for CN-105397872-A](https://nimo.iptorch.com/refdrawing/CN-105397872-A/pdf006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/CN-105397872-A/pdf007.png)

![Sketch 8 for CN-105397872-A](https://nimo.iptorch.com/refdrawing/CN-105397872-A/pdf007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/CN-105397872-A/pdf008.png)

![Sketch 9 for CN-105397872-A](https://nimo.iptorch.com/refdrawing/CN-105397872-A/pdf008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/CN-105397872-A/pdf009.png)

![Sketch 10 for CN-105397872-A](https://nimo.iptorch.com/refdrawing/CN-105397872-A/pdf009.png)

[Sketch 11](https://nimo.iptorch.com/refdrawing/CN-105397872-A/pdf010.png)

![Sketch 11 for CN-105397872-A](https://nimo.iptorch.com/refdrawing/CN-105397872-A/pdf010.png)

## Claims

### Claim 1 (independent)

A carpentry gantry type plate loading and unloading manipulator is characterized in that: it includes a compound conveying platform, a feeding device, a main body support, a horizontal moving device, a material grabbing device and a vertical moving device; the feeding device is arranged on a compound The side of the conveying platform; the main frame straddles the feeding device and the composite conveying platform, and the main frame is provided with a sliding seat that can move back and forth horizontally and horizontally; the horizontal moving device is arranged between the main frame and the sliding seat, and moves horizontally The device drives the sliding seat to move back and forth horizontally and horizontally; the material grabbing device can be vertically moved up and down and set on the sliding seat, and the material grabbing device is located above the composite conveying platform and the feeding device. Seat, opening and closing mechanism, vibration anti-adhesion mechanism and at least two pressure-maintaining suction cup groups. The column can be mounted on the slide seat up and down. They are placed side by side on the base, and the opening and closing mechanism drives the two pressure-maintaining suction cup groups to move back and forth. The shaking anti-adhesion mechanism is arranged on one of the pressure-maintaining suction cup groups; Between the material grabbing device and the material grabbing device, the vertical moving device drives the material grabbing device to move up and down vertically. 2.根据权利要求1所述的木工龙门式板料上下料机械手，其特征在于：所述复合输送台包括有支撑架以及多个输送滚筒，该多个输送滚筒彼此按一定角度安装于支撑架上。

### Claim 2

The woodworking gantry type plate loading and unloading manipulator according to claim 1, characterized in that: the composite conveying platform includes a support frame and a plurality of conveying rollers, and the plurality of conveying rollers are installed on the support frame at a certain angle superior. 3.根据权利要求1所述的木工龙门式板料上下料机械手，其特征在于：所述供料装置为两个，两供料装置分别设置于复合输送台的两侧，每一供料装置均具有一升降台。

### Claim 3

The woodworking gantry type plate loading and unloading manipulator according to claim 1, characterized in that: there are two feeding devices, and the two feeding devices are respectively arranged on both sides of the compound conveying platform, and each feeding device Each has a lifting platform. 4.根据权利要求1所述的木工龙门式板料上下料机械手，其特征在于：所述主体支架之横梁的侧面上设置有两导轨，该两导轨上下间隔平行设置，每一导轨均水平延伸，该滑座沿两导轨水平横向来回移动。

### Claim 4

The woodworking gantry-type plate loading and unloading manipulator according to claim 1, characterized in that: two guide rails are arranged on the side of the beam of the main body bracket, the two guide rails are arranged in parallel at intervals up and down, and each guide rail extends horizontally , the slider moves back and forth horizontally along the two guide rails. 5.根据权利要求1所述的木工龙门式板料上下料机械手，其特征在于：所述水平移动装置包括有第一齿条、第一伺服电机以及第一齿轮，该第一齿条固定于主体支架的横梁上并横向延伸，该第一伺服电机安装于滑座上，该第一齿轮安装于第一伺服电机的输出轴上，该第一齿轮与第一齿条啮合。

### Claim 5

The woodworking gantry type plate loading and unloading manipulator according to claim 1, characterized in that: the horizontal moving device includes a first rack, a first servo motor and a first gear, and the first rack is fixed on The first servo motor is installed on the slide seat, the first gear is installed on the output shaft of the first servo motor, and the first gear meshes with the first rack. 6.根据权利要求1所述的木工龙门式板料上下料机械手，其特征在于：所述基座的前后两侧均具有一固定杆，每一保压式吸盘组的两端均分别安装于对应的固定杆上。

### Claim 6

The woodworking gantry type plate loading and unloading manipulator according to claim 1, characterized in that: the front and rear sides of the base have a fixed rod, and the two ends of each pressure-maintaining suction cup group are respectively installed on the on the corresponding mounting rod. 7.根据权利要求6所述的木工龙门式板料上下料机械手，其特征在于：所述开合机构包括有转轴以及电机，转轴的两端分别与两固定杆的一端转动连接，且转轴的两端均安装有主动皮带轮，两固定杆的另一端均安装有从动皮带轮，主动皮带轮与对应的从动皮带轮之间连接有传动皮带，两保压式吸盘组分别与传动皮带的上部和下部连接，该电机带动转轴转动。

### Claim 7

The woodworking gantry type plate loading and unloading manipulator according to claim 6, characterized in that: the opening and closing mechanism includes a rotating shaft and a motor, the two ends of the rotating shaft are respectively connected to one end of the two fixed rods in rotation, and the ends of the rotating shaft Drive pulleys are installed at both ends, and driven pulleys are installed at the other ends of the two fixed rods. A transmission belt is connected between the drive pulley and the corresponding driven pulley. Connected, the motor drives the rotating shaft to rotate. 8.根据权利要求6所述的木工龙门式板料上下料机械手，其特征在于：每一保压式吸盘组包括有安装架以及多个吸盘，该安装架上具有滑块，该固定杆上设置有滑轨，该滑块可滑动地安装于滑轨上；该多个吸盘前后并排间隔地设置于安装架上。

### Claim 8

The woodworking gantry type plate loading and unloading manipulator according to claim 6, characterized in that: each pressure-holding type suction cup group includes a mounting frame and a plurality of suction cups, the mounting frame has a slider, and the fixing rod A slide rail is provided, and the slide block is slidably installed on the slide rail; the plurality of suction cups are arranged side by side and spaced apart on the mounting frame. 9.根据权利要求6所述的木工龙门式板料上下料机械手，其特征在于：其中一保压式吸盘组上设置有用于检测竖直方向下降高度的高度检测开关。

### Claim 9

The woodworking gantry type plate loading and unloading manipulator according to claim 6, characterized in that: one of the pressure-holding suction cup sets is provided with a height detection switch for detecting the vertical drop height. 10.根据权利要求1所述的木工龙门式板料上下料机械手，其特征在于：进一步包括有安全护栏，该安全护栏包围住复合输送台和供料装置，安全护栏具有两个进出料门。

### Claim 10

The woodworking gantry-type sheet material loading and unloading manipulator according to claim 1, characterized in that it further includes a safety guardrail, the safety guardrail surrounds the compound conveying platform and the feeding device, and the safety guardrail has two material inlet and outlet doors.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGWORKING OR PRESERVING WOOD OR SIMILAR MATERIAL; NAILING OR STAPLING MACHINES IN GENERALPLANING, DRILLING, MILLING, TURNING OR UNIVERSAL MACHINES FOR WOOD OR SIMILAR MATERIALMulti-purpose machines; Universal machines; Equipment thereforPERFORMING OPERATIONS; TRANSPORTINGHAND TOOLS; PORTABLE POWER-DRIVEN TOOLS; MANIPULATORSMANIPULATORS; CHAMBERS PROVIDED WITH MANIPULATION DEVICESGripping heads and other end effectorsGripping heads and other end effectors with vacuum or magnetic holding meansGripping heads and other end effectors with vacuum or magnetic holding means with vacuum

Description

Translated from Chinese

æ¨å·¥é¾é¨å¼æ¿æä¸ä¸ææºæ¢°æWoodworking gantry type plate loading and unloading manipulator

ææ¯é¢å

technical field

æ¬åææ¶åæ¨å·¥æºæ¢°è®¾å¤é¢åææ¯ï¼å°¤å

¶æ¯æä¸ç§æ¨å·¥é¾é¨å¼æ¿æä¸ä¸ææºæ¢°æã

The invention relates to the technology in the field of woodworking machinery and equipment, in particular to a woodworking gantry-type plate loading and unloading manipulator.

èæ¯ææ¯

Background technique

è¿å¹´æ¥éçå®¶å±

çäº§è¡ä¸èªå¨åæ°´å¹³çæ¥çæé«ï¼åç§åæ ·çä¸ä¸ææºä¸æ­åºç°ãä½å¸åºä¸ç®æçä¸ä¸ææºï¼æçè¾ä½ä¸ä¸ä¸ææ¿æå°ºå¯¸èå´è¾å°ãç°æçé¾é¨å¼ä¸ä¸ææºç«ç´æ¹åè¡ç¨è¾é¿ï¼è´ä½¿çäº§æçéä½ï¼ææç»æä¸è½æ ¹æ®æ¿æå°ºå¯¸èªå¨è°æ´ï¼é ææ¿æä¸æå°ºå¯¸åå°éå¶ä¸å¸çç£¨æå å§ï¼ææç»ææ èªå¨æå¨è£

ç½®ï¼æ¿æè¾èæ¶å®¹æé ææ¿æç²è¿ï¼æ çµæºåæ­¢é²æè½è£

ç½®ï¼æ å½¢ä¸­å¢å äºå®å

¨éæ£ãåæ¶ï¼å¸åºä¸æ²¡æä¸æ¨æå å·¥ä¸­å¿ç¸é

å¥çæ¨å·¥é¾é¨å¼æ¿æä¸ä¸ææºãéå¯¹å¸åºä¸ç®æä¸ä¸ææºåé¾é¨å¼ä¸ä¸ææºå­å¨çä¸ç³»åé®é¢ï¼è®¾è®¡äºä¸ç§å¯ç¨äºæé»ãå°è¾¹æºãæ¨æå å·¥ä¸­å¿ä¸ä¸æçé¾é¨å¼æ¿æä¸ä¸ææºæ¢°æã

In recent years, with the increasing automation level of the home furnishing industry, various loading and unloading machines continue to appear. However, the simple loading and unloading machines on the market have low efficiency and a small size range for loading and unloading plates. The existing gantry-type loading and unloading machine has a long vertical stroke, which reduces the production efficiency; the material grabbing structure cannot be automatically adjusted according to the size of the plate, resulting in the limitation of the material feeding size of the plate and increased wear of the suction cup; the material grabbing structure has no automatic shaking device, When the board is thin, it is easy to cause the board to stick; there is no power supply to stop the anti-drop device, which virtually increases the safety hazard. Simultaneously, there is no carpentry gantry type plate loading and unloading machine matched with the wood processing center on the market. Aiming at a series of problems existing in simple loading and unloading machines and gantry-type loading and unloading machines in the market, a gantry-type plate loading and unloading manipulator that can be used for loading and unloading of row drills, edge banding machines, and wood processing centers is designed.

åæå

å®¹

Contents of the invention

æé´äºæ­¤ï¼æ¬åæéå¯¹ç°æææ¯å­å¨ä¹ç¼ºå¤±ï¼å

¶ä¸»è¦ç®çæ¯æä¾ä¸ç§æ¨å·¥é¾é¨å¼æ¿æä¸ä¸ææºæ¢°æï¼å

¶å

·æé«æãèªå¨ä¾æãèªå¨å¼åãé²ç²è¿åé²æè½ç­ç¹ç¹ã

In view of this, the present invention aims at the deficiencies in the prior art, and its main purpose is to provide a woodworking gantry-type plate loading and unloading manipulator, which has the characteristics of high efficiency, automatic feeding, automatic opening and closing, anti-adhesion and anti-dropping, etc. .

ä¸ºå®ç°ä¸è¿°ç®çï¼æ¬åæéç¨å¦ä¸ä¹ææ¯æ¹æ¡ï¼

To achieve the above object, the present invention adopts the following technical solutions:

ä¸ç§æ¨å·¥é¾é¨å¼æ¿æä¸ä¸ææºæ¢°æï¼å

æ¬æå¤åè¾éå°ãä¾æè£

ç½®ãä¸»ä½æ¯æ¶ãæ°´å¹³ç§»å¨è£

ç½®ãææè£

ç½®ä»¥åç«ç´ç§»å¨è£

ç½®ï¼è¯¥ä¾æè£

ç½®è®¾ç½®äºå¤åè¾éå°çæä¾§ï¼è¯¥ä¸»ä½æ¯æ¶æ¨ªè·¨ä¾æè£

ç½®åå¤åè¾éå°ï¼è¯¥ä¸»ä½æ¯æ¶ä¸è®¾ç½®æå¯æ°´å¹³æ¨ªåæ¥åç§»å¨çæ»åº§ï¼è¯¥æ°´å¹³ç§»å¨è£

ç½®è®¾ç½®äºä¸»ä½æ¯æ¶åæ»åº§ä¹é´ï¼æ°´å¹³ç§»å¨è£

ç½®å¸¦å¨æ»åº§æ°´å¹³æ¨ªåæ¥åç§»å¨ï¼è¯¥ææè£

ç½®å¯ç«ç´ä¸ä¸æ¥åç§»å¨å°è®¾ç½®äºæ»åº§ä¸ï¼è¯¥ææè£

ç½®ä½äºå¤åè¾éå°åä¾æè£

ç½®çä¸æ¹ï¼ææè£

ç½®å

æ¬æç«æ±ãåºåº§ãå¼åæºæãæå¨é²ç²è¿æºæä»¥åè³å°ä¸¤ä¿åå¼å¸çç»ï¼è¯¥ç«æ±å¯ä¸ä¸æ´»å¨å°å®è£

äºæ»åº§ä¸ï¼è¯¥åºåº§åºå®äºç«æ±çä¸ç«¯ï¼è¯¥ä¸¤ä¿åå¼å¸çç»å¯å½¼æ­¤å¼åå°å¹¶æè®¾ç½®äºåºåº§ä¸ï¼è¯¥å¼åæºæå¸¦å¨ä¸¤ä¿åå¼å¸çç»æ¥åå¼åç§»å¨ï¼è¯¥æå¨é²ç²è¿æºæè®¾ç½®äºå

¶ä¸­ä¸ä¿åå¼å¸çç»ä¸ï¼è¯¥ç«ç´ç§»å¨è£

ç½®è®¾ç½®äºæ»åº§åææè£

ç½®ä¹é´ï¼ç«ç´ç§»å¨è£

ç½®å¸¦å¨ææè£

ç½®ç«ç´ä¸ä¸æ¥åç§»å¨ã

A carpentry gantry-type board material loading and unloading manipulator, including a compound conveying platform, a feeding device, a main body support, a horizontal moving device, a material grabbing device and a vertical moving device; the feeding device is arranged on the side of the compound conveying platform; The main body bracket straddles the feeding device and the composite conveying platform, and the main body bracket is provided with a sliding seat that can move back and forth horizontally and horizontally; the horizontal moving device is arranged between the main body bracket and the sliding seat, and the horizontal moving device drives the sliding seat horizontally Move back and forth; the material grabbing device can be vertically moved up and down on the sliding seat, the material grabbing device is located above the compound conveying platform and the feeding device, and the material grabbing device includes a column, a base, an opening and closing mechanism, Shake anti-adhesion mechanism and at least two pressure-maintaining suction cup groups. The column can be mounted on the sliding seat up and down. The base is fixed on the lower end of the column. On the seat, the opening and closing mechanism drives the two pressure-maintaining suction cup groups to move back and forth, and the shaking anti-adhesion mechanism is set on one of the pressure-maintaining suction cup groups; , the vertical moving device drives the grabbing device to move up and down vertically.

ä½ä¸ºä¸ç§ä¼éæ¹æ¡ï¼æè¿°å¤åè¾éå°å

æ¬ææ¯ææ¶ä»¥åå¤ä¸ªè¾éæ»ç­ï¼è¯¥å¤ä¸ªè¾éæ»ç­å½¼æ­¤æä¸å®è§åº¦å®è£

äºæ¯ææ¶ä¸ã

As a preferred solution, the compound conveying platform includes a support frame and a plurality of conveying rollers, and the plurality of conveying rollers are installed on the support frame at a certain angle to each other.

ä½ä¸ºä¸ç§ä¼éæ¹æ¡ï¼æè¿°ä¾æè£

ç½®ä¸ºä¸¤ä¸ªï¼ä¸¤ä¾æè£

ç½®åå«è®¾ç½®äºå¤åè¾éå°çä¸¤ä¾§ï¼æ¯ä¸ä¾æè£

ç½®åå

·æä¸åéå°ã

As a preferred solution, there are two feeding devices, and the two feeding devices are respectively arranged on both sides of the compound conveying platform, and each feeding device has a lifting platform.

ä½ä¸ºä¸ç§ä¼éæ¹æ¡ï¼æè¿°ä¸»ä½æ¯æ¶ä¹æ¨ªæ¢çä¾§é¢ä¸è®¾ç½®æä¸¤å¯¼è½¨ï¼è¯¥ä¸¤å¯¼è½¨ä¸ä¸é´éå¹³è¡è®¾ç½®ï¼æ¯ä¸å¯¼è½¨åæ°´å¹³å»¶ä¼¸ï¼è¯¥æ»åº§æ²¿ä¸¤å¯¼è½¨æ°´å¹³æ¨ªåæ¥åç§»å¨ã

As a preferred solution, two guide rails are arranged on the side of the crossbeam of the main body bracket, the two guide rails are arranged in parallel at intervals up and down, each guide rail extends horizontally, and the sliding seat moves back and forth horizontally along the two guide rails.

ä½ä¸ºä¸ç§ä¼éæ¹æ¡ï¼æè¿°æ°´å¹³ç§»å¨è£

ç½®å

æ¬æç¬¬ä¸é½¿æ¡ãç¬¬ä¸ä¼ºæçµæºä»¥åç¬¬ä¸é½¿è½®ï¼è¯¥ç¬¬ä¸é½¿æ¡åºå®äºä¸»ä½æ¯æ¶çæ¨ªæ¢ä¸å¹¶æ¨ªåå»¶ä¼¸ï¼è¯¥ç¬¬ä¸ä¼ºæçµæºå®è£

äºæ»åº§ä¸ï¼è¯¥ç¬¬ä¸é½¿è½®å®è£

äºç¬¬ä¸ä¼ºæçµæºçè¾åºè½´ä¸ï¼è¯¥ç¬¬ä¸é½¿è½®ä¸ç¬¬ä¸é½¿æ¡å®åã

As a preferred solution, the horizontal moving device includes a first rack, a first servo motor and a first gear, the first rack is fixed on the beam of the main frame and extends laterally, and the first servo motor is installed on On the sliding seat, the first gear is installed on the output shaft of the first servo motor, and the first gear meshes with the first rack.

ä½ä¸ºä¸ç§ä¼éæ¹æ¡ï¼æè¿°åºåº§çååä¸¤ä¾§åå

·æä¸åºå®æï¼æ¯ä¸ä¿åå¼å¸çç»çä¸¤ç«¯ååå«å®è£

äºå¯¹åºçåºå®æä¸ã

As a preferred solution, there are fixed rods on the front and rear sides of the base, and the two ends of each pressure-maintaining suction cup group are respectively installed on the corresponding fixed rods.

ä½ä¸ºä¸ç§ä¼éæ¹æ¡ï¼æè¿°å¼åæºæå

æ¬æè½¬è½´ä»¥åçµæºï¼è½¬è½´çä¸¤ç«¯åå«ä¸ä¸¤åºå®æçä¸ç«¯è½¬å¨è¿æ¥ï¼ä¸è½¬è½´çä¸¤ç«¯åå®è£

æä¸»å¨ç®å¸¦è½®ï¼ä¸¤åºå®æçå¦ä¸ç«¯åå®è£

æä»å¨ç®å¸¦è½®ï¼ä¸»å¨ç®å¸¦è½®ä¸å¯¹åºçä»å¨ç®å¸¦è½®ä¹é´è¿æ¥æä¼ å¨ç®å¸¦ï¼ä¸¤ä¿åå¼å¸çç»åå«ä¸ä¼ å¨ç®å¸¦çä¸é¨åä¸é¨è¿æ¥ï¼è¯¥çµæºå¸¦å¨è½¬è½´è½¬å¨ã

As a preferred solution, the opening and closing mechanism includes a rotating shaft and a motor. The two ends of the rotating shaft are respectively connected to one end of the two fixed rods in rotation, and the two ends of the rotating shaft are equipped with driving pulleys, and the other ends of the two fixed rods are installed. There is a driven pulley, a transmission belt is connected between the driving pulley and the corresponding driven pulley, two pressure-maintaining suction cup groups are respectively connected with the upper part and the lower part of the transmission belt, and the motor drives the rotating shaft to rotate.

ä½ä¸ºä¸ç§ä¼éæ¹æ¡ï¼æ¯ä¸ä¿åå¼å¸çç»å

æ¬æå®è£

æ¶ä»¥åå¤ä¸ªå¸çï¼è¯¥å®è£

æ¶ä¸å

·ææ»åï¼è¯¥åºå®æä¸è®¾ç½®ææ»è½¨ï¼è¯¥æ»åå¯æ»å¨å°å®è£

äºæ»è½¨ä¸ï¼è¯¥å¤ä¸ªå¸çååå¹¶æé´éå°è®¾ç½®äºå®è£

æ¶ä¸ã

As a preferred solution, each pressure-maintaining suction cup group includes a mounting frame and a plurality of suction cups, the mounting frame has a slide block, the fixed rod is provided with a slide rail, and the slide block is slidably installed on the slide rail ; The plurality of suction cups are arranged side by side and spaced on the mounting frame.

ä½ä¸ºä¸ç§ä¼éæ¹æ¡ï¼å

¶ä¸­ä¸ä¿åå¼å¸çç»ä¸è®¾ç½®æç¨äºæ£æµç«ç´æ¹åä¸éé«åº¦çé«åº¦æ£æµå¼å

³ã

As a preferred solution, one of the pressure-maintaining suction cup groups is provided with a height detection switch for detecting the vertical drop height.

ä½ä¸ºä¸ç§ä¼éæ¹æ¡ï¼è¿ä¸æ­¥å

æ¬æå®å

¨æ¤æ ï¼è¯¥å®å

¨æ¤æ å

å´ä½å¤åè¾éå°åä¾æè£

ç½®ï¼å®å

¨æ¤æ å

·æä¸¤ä¸ªè¿åºæé¨ã

As a preferred solution, it further includes a safety guardrail, the safety guardrail surrounds the composite conveying platform and the feeding device, and the safety guardrail has two material inlet and outlet doors.

æ¬åæä¸ç°æææ¯ç¸æ¯å

·æææ¾çä¼ç¹åæçææï¼å

·ä½èè¨ï¼ç±ä¸è¿°ææ¯æ¹æ¡å¯ç¥ï¼

Compared with the prior art, the present invention has obvious advantages and beneficial effects. Specifically, it can be known from the above technical solutions:

éè¿éç¨ä¾æè£

ç½®èªå¨ä¾æï¼åå°ææè£

ç½®å¨ç«ç´æ¹åä¸çè¿å¨è·ç¦»ï¼ä¸ä¸æè¿ç¨æ éåæºï¼å¯æææé«çäº§æçï¼ææè£

ç½®éç¨èªå¨å¼åæºæï¼å¯æ ¹æ®æ¿æå°ºå¯¸èªå¨è°æ´ä¿åå¼å¸çç»ä¹é´çè·ç¦»ï¼ä½¿å¸çç»å

·æè¯å¥½çååç¶æè¿èåå°å¸ççç£¨æï¼æå¨é²ç²è¿æºæå¨ææåäº§çæå¨å¨ä½ï¼ææé²æ­¢æ¿æç²è¿ï¼å¹¶ä¸å¨çµæºåæ­¢æ

åµä¸ä½¿ææè£

ç½®ç¢åºå°å¸ä½æ¿æï¼é¿å

æ¿ææè½è³è®¾å¤ä¸ï¼åæ¶é²æ­¢åçµåæä½äººåè¿å

¥å·¥ä½åºå

ï¼é æä¸å¿

è¦ä¸ä¼¤å®³ã

By adopting the automatic feeding of the feeding device, the movement distance of the grabbing device in the vertical direction is reduced, and the feeding process does not need to stop, which can effectively improve the production efficiency; the grabbing device adopts an automatic opening and closing mechanism, which can automatically Adjust the distance between the pressure-holding suction cups so that the suction cups have a good stress state and reduce the wear of the suction cups; the anti-adhesion mechanism will vibrate after grabbing the material to effectively prevent the plate from sticking; and when the power is stopped Make the grabbing device firmly hold the plate to prevent the plate from falling onto the equipment, and at the same time prevent the operator from entering the work area after a power failure, causing unnecessary injuries.

ä¸ºæ´æ¸

æ¥å°éè¿°æ¬åæçç»æç¹å¾ååæï¼ä¸é¢ç»åéå¾ä¸å

·ä½å®æ½ä¾æ¥å¯¹æ¬åæè¿è¡è¯¦ç»è¯´æã

In order to more clearly illustrate the structural features and functions of the present invention, the present invention will be described in detail below in conjunction with the accompanying drawings and specific embodiments.

éå¾è¯´æ

Description of drawings

å¾1æ¯æ¬åæä¹è¾ä½³å®æ½ä¾çç«ä½ç¤ºæå¾ï¼

Fig. 1 is the three-dimensional schematic diagram of the preferred embodiment of the present invention;

å¾2æ¯æ¬åæä¹è¾ä½³å®æ½ä¾ä¸­æ å®å

¨æ¤æ ç¶æä¸çç«ä½å¾ï¼

Fig. 2 is a perspective view without a safety guardrail state in a preferred embodiment of the present invention;

å¾3æ¯æ¬åæä¹è¾ä½³å®æ½ä¾çææè£

ç½®çæ¾å¤§ç¤ºæå¾ï¼

Fig. 3 is the enlarged schematic view of the grasping device of the preferred embodiment of the present invention;

å¾4æ¯æ¬åæä¹è¾ä½³å®æ½ä¾çææè£

ç½®å¦ä¸è§åº¦çæ¾å¤§ç¤ºæå¾ã

Fig. 4 is an enlarged schematic view from another angle of the grabbing device of the preferred embodiment of the present invention.

éå¾æ è¯è¯´æï¼

Explanation of the accompanying drawings:

10ãå¤åè¾éå°11ãæ¯ææ¶

10. Composite conveyor table 11. Support frame

12ãè¾éæ»ç­20ãä¾æè£

ç½®

12. Conveying roller 20. Feeding device

21ãåéå°30ãä¸»ä½æ¯æ¶

21. Elevating platform 30. Main support

31ãæ¨ªæ¢40ãæ°´å¹³ç§»å¨è£

ç½®

31. Beam 40. Horizontal moving device

41ãç¬¬ä¸é½¿æ¡42ãç¬¬ä¸ä¼ºæçµæº

41. The first rack 42. The first servo motor

50ãææè£

ç½®51ãç«æ±

50. Grabbing device 51. Column

52ãåºåº§521ãåºå®æ

52, base 521, fixed rod

522ãæ»è½¨53ãå¼åæºæ

522, slide rail 53, opening and closing mechanism

531ãè½¬è½´532ãçµæº

531, rotating shaft 532, motor

533ãä¸»å¨ç®å¸¦è½®534ãä»å¨ç®å¸¦è½®

533, driving pulley 534, driven pulley

535ãä¼ å¨ç®å¸¦54ãæå¨é²ç²è¿æºæ

535, transmission belt 54, shaking anti-adhesion mechanism

55ãä¿åå¼å¸çç»551ãå®è£

æ¶

55. Pressure-holding suction cup group 551. Mounting frame

552ãå¸ç553ãæ»å

552, sucker 553, slider

56ãé«åº¦æ£æµå¼å

³60ãç«ç´ç§»å¨è£

ç½®

56. Height detection switch 60. Vertical moving device

61ãç¬¬äºé½¿æ¡62ãç¬¬äºä¼ºæçµæº

61. The second rack 62. The second servo motor

63ãç¬¬äºé½¿è½®70ãæ¿æ

63, second gear 70, plate

81ãæ»åº§82ãå¯¼è½¨

81, sliding seat 82, guide rail

90ãå®å

¨æ¤æ 91ãåé¨æ¤æ 

90. Safety guardrail 91. Front guardrail

92ãå³ä¾§æ¤æ 93ãå·¦ä¾§æ¤æ 

92. Right guardrail 93. Left guardrail

94ãåé¨æ¤æ 901ãè¿åºæé¨ã

94. Rear guardrail 901. Material inlet and outlet door.

å

·ä½å®æ½æ¹å¼

detailed description

è¯·åç

§å¾1è³å¾4æç¤ºï¼å

¶æ¾ç¤ºåºäºæ¬åæä¹è¾ä½³å®æ½ä¾çå

·ä½ç»æï¼å

æ¬æå¤åè¾éå°10ãä¾æè£

ç½®20ãä¸»ä½æ¯æ¶30ãæ°´å¹³ç§»å¨è£

ç½®40ãææè£

ç½®50ä»¥åç«ç´ç§»å¨è£

ç½®60ã

Please refer to Fig. 1 to Fig. 4, which shows the specific structure of a preferred embodiment of the present invention, including a compound conveying platform 10, a feeding device 20, a main body support 30, a horizontal moving device 40, and a grabbing device 50 And the vertical moving device 60 .

è¯¥å¤åè¾éå°10å

æ¬ææ¯ææ¶11ä»¥åå¤ä¸ªè¾éæ»ç­12ï¼è¯¥å¤ä¸ªè¾éæ»ç­12å½¼æ­¤æä¸å®è§åº¦å®è£

äºæ¯ææ¶11ä¸ï¼å½è¾éæ¿æ70æ¶ï¼æ¿æ70ä¼èªå¨é è¾¹å¹¶è¿å

¥å å·¥è®¾å¤ã

The composite conveying platform 10 includes a supporting frame 11 and a plurality of conveying rollers 12, and the conveying rollers 12 are installed on the supporting frame 11 at a certain angle to each other. When conveying the plate 70, the plate 70 will automatically pull over and enter the processing equipment.

è¯¥ä¾æè£

ç½®20è®¾ç½®äºå¤åè¾éå°10çæä¾§ï¼å¨æ¬å®æ½ä¾ä¸­ï¼æè¿°ä¾æè£

ç½®20ä¸ºä¸¤ä¸ªï¼ä¸¤ä¾æè£

ç½®20åå«è®¾ç½®äºå¤åè¾éå°10çä¸¤ä¾§ï¼æ¯ä¸ä¾æè£

ç½®20åå

·æä¸åéå°21ï¼éç¨åå·¥ä½å¾ªç¯ä¾ææ§å¶æ¹å¼ï¼å¨ä¸æè¿ç¨ä¸­æ éåæºï¼åå°ä¸å¿

è¦çæ¶é´æ¶èã

The feeding device 20 is arranged on the side of the compound conveying platform 10; The feeding device 20 has a lifting table 21, adopts a single-station cycle feeding control mode, no need to stop during the feeding process, and reduces unnecessary time consumption.

è¯¥ä¸»ä½æ¯æ¶30æ¨ªè·¨ä¾æè£

ç½®20åå¤åè¾éå°10ï¼è¯¥ä¸»ä½æ¯æ¶30ä¸è®¾ç½®æå¯æ°´å¹³æ¨ªåæ¥åç§»å¨çæ»åº§81ï¼å¨æ¬å®æ½ä¾ä¸­ï¼æè¿°ä¸»ä½æ¯æ¶30ä¹æ¨ªæ¢31çä¾§é¢ä¸è®¾ç½®æä¸¤å¯¼è½¨82ï¼è¯¥ä¸¤å¯¼è½¨82ä¸ä¸é´éå¹³è¡è®¾ç½®ï¼æ¯ä¸å¯¼è½¨82åæ°´å¹³å»¶ä¼¸ï¼è¯¥æ»åº§81æ²¿ä¸¤å¯¼è½¨82æ°´å¹³æ¨ªåæ¥åç§»å¨ã

The main body support 30 straddles the feeding device 20 and the compound conveying platform 10, and the main body support 30 is provided with a sliding seat 81 that can move back and forth horizontally and horizontally; Two guide rails 82 are provided, and the two guide rails 82 are set up and down in parallel, each guide rail 82 extends horizontally, and the sliding seat 81 moves back and forth along the two guide rails 82 horizontally and laterally.

è¯¥æ°´å¹³ç§»å¨è£

ç½®40è®¾ç½®äºä¸»ä½æ¯æ¶30åæ»åº§81ä¹é´ï¼æ°´å¹³ç§»å¨è£

ç½®40å¸¦å¨æ»åº§81æ°´å¹³æ¨ªåæ¥åç§»å¨ï¼å

·ä½èè¨ï¼å¨æ¬å®æ½ä¾ä¸­ï¼æè¿°æ°´å¹³ç§»å¨è£

ç½®40å

æ¬æç¬¬ä¸é½¿æ¡41ãç¬¬ä¸ä¼ºæçµæº42ä»¥åç¬¬ä¸é½¿è½®ï¼å¾ä¸­æªç¤ºï¼ï¼è¯¥ç¬¬ä¸é½¿æ¡41åºå®äºä¸»ä½æ¯æ¶30çæ¨ªæ¢31ä¸å¹¶æ¨ªåå»¶ä¼¸ï¼è¯¥ç¬¬ä¸ä¼ºæçµæº42å®è£

äºæ»åº§81ä¸ï¼è¯¥ç¬¬ä¸é½¿è½®å®è£

äºç¬¬ä¸ä¼ºæçµæº42çè¾åºè½´ä¸ï¼è¯¥ç¬¬ä¸é½¿è½®ä¸ç¬¬ä¸é½¿æ¡41å®åã

The horizontal moving device 40 is arranged between the main body support 30 and the sliding seat 81, and the horizontal moving device 40 drives the sliding seat 81 to move back and forth horizontally and laterally; specifically, in this embodiment, the horizontal moving device 40 includes a first The rack 41, the first servo motor 42 and the first gear (not shown in the figure), the first rack 41 is fixed on the beam 31 of the main body support 30 and extends laterally, the first servo motor 42 is installed on the sliding seat 81 , the first gear is installed on the output shaft of the first servo motor 42 , and the first gear meshes with the first rack 41 .

è¯¥ææè£

ç½®50å¯ç«ç´ä¸ä¸æ¥åç§»å¨å°è®¾ç½®äºæ»åº§81ä¸ï¼è¯¥ææè£

ç½®50ä½äºå¤åè¾éå°10åä¾æè£

ç½®20çä¸æ¹ï¼ææè£

ç½®50å

æ¬æç«æ±51ãåºåº§52ãå¼åæºæ53ãæå¨é²ç²è¿æºæ54ä»¥åè³å°ä¸¤ä¿åå¼å¸çç»55ï¼è¯¥ç«æ±51å¯ä¸ä¸æ´»å¨å°å®è£

äºæ»åº§81ä¸ï¼è¯¥åºåº§52åºå®äºç«æ±51çä¸ç«¯ï¼è¯¥ä¸¤ä¿åå¼å¸çç»55å¯å½¼æ­¤å¼åå°å¹¶æè®¾ç½®äºåºåº§52ä¸ï¼è¯¥å¼åæºæ53å¸¦å¨ä¸¤ä¿åå¼å¸çç»55æ¥åå¼åç§»å¨ï¼è¯¥æå¨é²ç²è¿æºæ54è®¾ç½®äºå

¶ä¸­ä¸ä¿åå¼å¸çç»55ä¸ãå

·ä½èè¨ï¼å¨æ¬å®æ½ä¾ä¸­ï¼æè¿°åºåº§52çååä¸¤ä¾§åå

·æä¸åºå®æ521ï¼æ¯ä¸ä¿åå¼å¸çç»55çä¸¤ç«¯ååå«å®è£

äºå¯¹åºçåºå®æ521ä¸ï¼æè¿°å¼åæºæ53å

æ¬æè½¬è½´531ä»¥åçµæº532ï¼è½¬è½´531çä¸¤ç«¯åå«ä¸ä¸¤åºå®æ521çä¸ç«¯è½¬å¨è¿æ¥ï¼ä¸è½¬è½´531çä¸¤ç«¯åå®è£

æä¸»å¨ç®å¸¦è½®533ï¼ä¸¤åºå®æ521çå¦ä¸ç«¯åå®è£

æä»å¨ç®å¸¦è½®534ï¼ä¸»å¨ç®å¸¦è½®533ä¸å¯¹åºçä»å¨ç®å¸¦è½®534ä¹é´è¿æ¥æä¼ å¨ç®å¸¦535ï¼ä¸¤ä¿åå¼å¸çç»55åå«ä¸ä¼ å¨ç®å¸¦535çä¸é¨åä¸é¨è¿æ¥ï¼è¯¥çµæº532å¸¦å¨è½¬è½´531è½¬å¨ï¼æ¯ä¸ä¿åå¼å¸çç»55å

æ¬æå®è£

æ¶551ä»¥åå¤ä¸ªå¸ç552ï¼è¯¥å®è£

æ¶551ä¸å

·ææ»å553ï¼è¯¥åºå®æ521ä¸è®¾ç½®ææ»è½¨522ï¼è¯¥æ»å553å¯æ»å¨å°å®è£

äºæ»è½¨522ä¸ï¼è¯¥å¤ä¸ªå¸ç552ååå¹¶æé´éå°è®¾ç½®äºå®è£

æ¶551ä¸ï¼è¯¥æå¨é²ç²è¿æºæ54ä¸ºæ°ç¼¸ï¼è¯¥æ°ç¼¸å¸¦å¨å

¶ä¸­ä¸å¸ç552ä¸ä¸ç§»å¨ï¼æ­¤å¤ï¼å

¶ä¸­ä¸ä¿åå¼å¸çç»55ä¸è®¾ç½®æç¨äºæ£æµç«ç´æ¹åä¸éé«åº¦çé«åº¦æ£æµå¼å

³56ã

The material grabbing device 50 can be vertically moved up and down on the sliding seat 81, the material grabbing device 50 is located above the compound conveying platform 10 and the feeding device 20, and the material grabbing device 50 includes a column 51, a base 52 , an opening and closing mechanism 53, a shaking anti-adhesion mechanism 54, and at least two pressure-holding suction cup groups 55, the column 51 can be mounted on the sliding seat 81 up and down, the base 52 is fixed on the lower end of the column 51, and the two pressure-holding Type suction cup sets 55 can be opened and closed side by side on the base 52, the opening and closing mechanism 53 drives the two pressure-holding type suction cup sets 55 to move back and forth, and the shaking anti-adhesion mechanism 54 is arranged on one of the pressure-holding type suction cup sets 55 on. Specifically, in this embodiment, the front and rear sides of the base 52 are provided with a fixed rod 521, and the two ends of each pressure-maintaining suction cup group 55 are respectively installed on the corresponding fixed rod 521; The opening and closing mechanism 53 includes a rotating shaft 531 and a motor 532. The two ends of the rotating shaft 531 are respectively connected to one end of the two fixed rods 521 in rotation, and the two ends of the rotating shaft 531 are equipped with a driving pulley 533, and the other ends of the two fixed rods 521 are installed. Driven pulley 534 is arranged, driving belt 535 is connected between driving pulley 533 and corresponding driven pulley 534, and two pressure-maintaining type sucker groups 55 are connected with the top and the bottom of driving belt 535 respectively, and this motor 532 drives rotating shaft 531 to rotate; Each pressure maintaining type suction cup group 55 includes a mounting frame 551 and a plurality of suction cups 552, the mounting frame 551 has a slide block 553, the fixed rod 521 is provided with a slide rail 522, and the slide block 553 is slidably installed on the slide on the rail 522; the plurality of suction cups 552 are arranged side by side on the mounting frame 551; A height detection switch 56 for detecting the height of the vertical drop is provided.

è¯¥ç«ç´ç§»å¨è£

ç½®60è®¾ç½®äºæ»åº§81åææè£

ç½®50ä¹é´ï¼ç«ç´ç§»å¨è£

ç½®60å¸¦å¨ææè£

ç½®50ç«ç´ä¸ä¸æ¥åç§»å¨ãå

·ä½èè¨ï¼å¨æ¬å®æ½ä¾ä¸­ï¼è¯¥ç«ç´ç§»å¨è£

ç½®60å

æ¬æç¬¬äºé½¿æ¡61ãç¬¬äºä¼ºæçµæº62ä»¥åç¬¬äºé½¿è½®63ï¼è¯¥ç¬¬äºé½¿æ¡61åºå®äºç«æ±51ä¸å¹¶ç«ç´å»¶ä¼¸ï¼è¯¥ç¬¬äºä¼ºæçµæº62å®è£

äºæ»åº§81ä¸ï¼è¯¥ç¬¬äºé½¿è½®63å®è£

äºç¬¬äºä¼ºæçµæº62çè¾åºè½´ä¸ï¼è¯¥ç¬¬äºé½¿è½®63ä¸ç¬¬äºé½¿æ¡61å®åã

The vertical moving device 60 is arranged between the sliding seat 81 and the grabbing device 50 , and the vertical moving device 60 drives the grabbing device 50 to move vertically up and down. Specifically, in this embodiment, the vertical moving device 60 includes a second rack 61, a second servo motor 62 and a second gear 63, the second rack 61 is fixed on the column 51 and extends vertically , the second servo motor 62 is installed on the sliding seat 81 , the second gear 63 is installed on the output shaft of the second servo motor 62 , and the second gear 63 meshes with the second rack 61 .

æ­¤å¤ï¼è¿ä¸æ­¥å

æ¬æå®å

¨æ¤æ 90ï¼è¯¥å®å

¨æ¤æ 90å

å´ä½å¤åè¾éå°10åä¾æè£

ç½®20ï¼å®å

¨æ¤æ 90å

·æä¸¤ä¸ªè¿åºæé¨901ï¼è¯¥å®å

¨æ¤æ 90ç±åé¨æ¤æ 91ãå³ä¾§æ¤æ 92ãå·¦ä¾§æ¤æ 93ååé¨æ¤æ 94å´æå½¢æãå®å

¨æ¤æ 90ç¨äºé²æ­¢å·¥ä½è¿ç¨ä¸­æä½äººåè¯¯å

¥å·¥ä½åºåé æä¸å¿

è¦çä¼¤å®³ï¼æ­£å¸¸ç¶æä¸ä¸¤è¿åºæé¨901å¤äºå

³é­ç¶æï¼å½æ¿æè¿åºææ¶åè¾¹è¿åºæé¨901æå¼ï¼å®å

¨èµ·è§ä¸¤è¿åºæé¨901åæ¶æå¼æ¶æºå¨åæ­¢å·¥ä½ãå¨çµæºåæ­¢æ

åµä¸ä½¿ææè£

ç½®50ç¢åºå°å¸ä½æ¿æï¼é¿å

æ¿ææè½è³è®¾å¤ä¸ï¼åæ¶é²æ­¢åçµåæä½äººåè¿å

¥å·¥ä½åºå

ï¼é æä¸å¿

è¦ä¸ä¼¤å®³ã

In addition, it further includes a safety guardrail 90, the safety guardrail 90 surrounds the compound conveying platform 10 and the feeding device 20, the safety guardrail 90 has two inlet and outlet doors 901, and the safety guardrail 90 consists of a front guardrail 91 and a right guardrail 92. , The left guardrail 93 and the rear guardrail 94 are surrounded by a structure. The safety guardrail 90 is used to prevent the operator from entering the work area by mistake during the working process and causing unnecessary injuries. Under normal conditions, the two-in and out-feed doors 901 are closed. The machine stopped working when material door 901 was opened simultaneously. When the power supply is stopped, the grasping device 50 can firmly hold the plate to prevent the plate from falling onto the equipment, and at the same time prevent the operator from entering the work area after the power failure, causing unnecessary injuries.

è¯¦è¿°æ¬å®æ½ä¾çå·¥ä½è¿ç¨å¦ä¸ï¼

The working process of present embodiment is described in detail as follows:

å·¥ä½åï¼å°å¾

å å·¥æ¿æ70ä»è¿åºæé¨901è¿å

¥ä¸¤ä¾æè£

ç½®20çåéå°21ä¸ï¼æä½äººåæ ¹æ®å¾

å å·¥æ¿æ70å°ºå¯¸å¨æ§å¶çµæè§¦æ¸å±ä¸éæ©åéçæ¿æå®½åº¦ï¼ææè£

ç½®50çå¼åæºæ53å°ä¸¤ä¿åå¼å¸çç»55è°æ´è³åéè·ç¦»ï¼ä¸¤ä¾æè£

ç½®20ä¸ä¸ªå¤äºå·¥ä½ç¶æï¼ä¸ä¸ªå¤äºå·¥ä½ç­å¾

ç¶æï¼æ°´å¹³ç§»å¨è£

ç½®40å°ææè£

ç½®50ç§»è³å·¥ä½ç¶æçåéå°21ä¸æ¹ï¼ç«ç´ç§»å¨è£

ç½®60å°ææè£

ç½®50ä¸ç§»æ¥è§¦æ¿æ70ï¼å½é«åº¦æ£æµå¼å

³56æ¥è§¦å°æ¿æ70æ¶ï¼ææè£

ç½®50åæ­¢ä¸éå¹¶ä¸åè³ä¸å®è·ç¦»åï¼æå¨é²ç²è¿æºæ54åè¾¹æå¨ï¼é²æ­¢æ¿æ70ç²è¿ï¼æ°´å¹³ç§»å¨è£

ç½®40å°ææè£

ç½®50ç§»è³å¤åè¾éå°10ä¸æ¹ï¼åæ¶ä¾æè£

ç½®20çåéå°21ä¸åè³è®¾å®é«åº¦ï¼ç«ç´ç§»å¨è£

ç½®60å°ææè£

ç½®50ä¸ç§»å¤åè¾éå°10ä¸æ¹ï¼å½ä¸éä½æåºå¼å

³è§¦åä¿¡å·åï¼å¸ç552åæ­¢å¸æ¿å°æ¿æ70æ¾ç½®å¨å¤åè¾éå°10çå·¥ä½é¢ä¸ãæ¿æ70ç»è¿èªå¨é è¾¹å¤åè¾éå°10è¿å

¥æ¿æå å·¥è®¾å¤ï¼ä¸æå¨ä½å®æãç¶åéå¤ä¸è¿°å¨ä½ï¼å½å·¥ä½ç¶æä¾æè£

ç½®20ä¹åéå°21ä¾æå®æ¯åï¼å¤äºç­å¾

ç¶æçåéå°21å¼å§å·¥ä½ï¼æä½äººåå¯ä»¥å¨ä¸åæºæ

åµä¸å®æä¸æãæ¨å·¥é¾é¨å¼æ¿æä¸ä¸ææºæ¢°æåä¸ææºç¨æ¶ï¼æ´ä¸ªå·¥ä½è¿ç¨ä¸ä¸è¿°è¿ç¨ç¸åã

Before work, enter the plate 70 to be processed into the lifting table 21 of the two feeding devices 20 from the material inlet and outlet door 901, the operator selects the appropriate plate width on the touch screen of the control electric cabinet according to the size of the plate 70 to be processed, and the material grabbing device 50 The opening and closing mechanism 53 adjusts the two pressure-maintaining suction cup groups 55 to an appropriate distance; one of the two feeding devices 20 is in the working state, and the other is in the working waiting state; the horizontal moving device 40 moves the grabbing device 50 to the lifting platform 21 in the working state Above, the vertical moving device 60 moves the grasping device 50 down to contact the plate 70. When the height detection switch 56 touches the plate 70, the grasping device 50 stops falling and rises to a certain distance, and the shaking anti-adhesion mechanism 54 unilaterally shakes , to prevent the plate 70 from sticking; the horizontal moving device 40 moves the grabbing device 50 to the top of the compound conveying platform 10, and at the same time, the lifting platform 21 of the feeding device 20 rises to a set height, and the vertical moving device 60 moves the grabbing device 50 down Above the compound conveying platform 10 , after the trigger signal of the lower limit sensor switch, the suction cup 552 stops the suction plate and places the plate 70 on the working surface of the compound conveying platform 10 . The sheet material 70 enters the sheet material processing equipment through the automatic side-by-side compound conveying platform 10, and the feeding action is completed. Then repeat above-mentioned action, after the lifting platform 21 of working state feeding device 20 is finished feeding, the lifting platform 21 that is in waiting state starts to work, and the operator can finish loading under the situation of not shutting down. When the woodworking gantry type plate loading and unloading manipulator is used as a blanking machine, the whole working process is opposite to the above process.

æ¬åæçè®¾è®¡éç¹å¨äºï¼éè¿éç¨ä¾æè£

ç½®èªå¨ä¾æï¼åå°ææè£

ç½®å¨ç«ç´æ¹åä¸çè¿å¨è·ç¦»ï¼ä¸ä¸æè¿ç¨æ éåæºï¼å¯æææé«çäº§æçï¼ææè£

ç½®éç¨èªå¨å¼åæºæï¼å¯æ ¹æ®æ¿æå°ºå¯¸èªå¨è°æ´ä¿åå¼å¸çç»ä¹é´çè·ç¦»ï¼ä½¿å¸çç»å

·æè¯å¥½çååç¶æè¿èåå°å¸ççç£¨æï¼æå¨é²ç²è¿æºæå¨ææåäº§çæå¨å¨ä½ï¼ææé²æ­¢æ¿æç²è¿ï¼å¹¶ä¸å¨çµæºåæ­¢æ

åµä¸ä½¿ææè£

ç½®ç¢åºå°å¸ä½æ¿æï¼é¿å

æ¿ææè½è³è®¾å¤ä¸ï¼åæ¶é²æ­¢åçµåæä½äººåè¿å

¥å·¥ä½åºå

ï¼é æä¸å¿

è¦ä¸ä¼¤å®³ã

The key point of the design of the present invention is: by adopting the automatic feeding of the feeding device, the movement distance of the grabbing device in the vertical direction is reduced, and the feeding process does not need to be stopped, which can effectively improve the production efficiency; the grabbing device adopts automatic opening and closing The mechanism can automatically adjust the distance between the pressure-holding suction cups according to the size of the plate, so that the suction cups have a good stress state and reduce the wear of the suction cups; the shaking anti-adhesion mechanism produces a shaking action after grabbing the material, effectively preventing the plate from sticking ; And when the power supply is stopped, the grabbing device can firmly hold the plate to prevent the plate from falling onto the equipment, and at the same time prevent the operator from entering the work area after a power failure, causing unnecessary injuries.

ä»¥ä¸æè¿°ï¼ä»

æ¯æ¬åæçè¾ä½³å®æ½ä¾èå·²ï¼å¹¶éå¯¹æ¬åæçææ¯èå´ä½ä»»ä½éå¶ï¼æ

å¡æ¯ä¾æ®æ¬åæçææ¯å®è´¨å¯¹ä»¥ä¸å®æ½ä¾æä½çä»»ä½ç»å¾®ä¿®æ¹ãç­åååä¸ä¿®é¥°ï¼åä»å±äºæ¬åæææ¯æ¹æ¡çèå´å

ã

The above descriptions are only preferred embodiments of the present invention, and do not limit the technical scope of the present invention in any way, so any minor modifications, equivalent changes and modifications made to the above embodiments according to the technical essence of the present invention are still valid. It belongs to the scope of the technical solutions of the present invention.

## Classifications

- B27C9/00
- B25J15/06
- B25J15/0616
- B27C9/00

## Cited patent documents

- [CN-105499421-A](https://patents.google.com/patent/CN105499421A/en) — SEA
- [CN-202729281-U](https://patents.google.com/patent/CN202729281U/en) — SEA
- [CN-203109041-U](https://patents.google.com/patent/CN203109041U/en) — SEA
- [CN-203622578-U](https://patents.google.com/patent/CN203622578U/en) — SEA
- [CN-203779492-U](https://patents.google.com/patent/CN203779492U/en) — SEA
- [CN-203843043-U](https://patents.google.com/patent/CN203843043U/en) — SEA
- [CN-203959340-U](https://patents.google.com/patent/CN203959340U/en) — SEA
- [CN-204487707-U](https://patents.google.com/patent/CN204487707U/en) — SEA
- [CN-204688915-U](https://patents.google.com/patent/CN204688915U/en) — SEA
- [CN-204711669-U](https://patents.google.com/patent/CN204711669U/en) — SEA
- [CN-204777352-U](https://patents.google.com/patent/CN204777352U/en) — SEA
- [CN-205291178-U](https://patents.google.com/patent/CN205291178U/en) — SEA
- [EP-1164098-A1](https://patents.google.com/patent/EP1164098A1/en) — SEA
- [GB-558661-A](https://patents.google.com/patent/GB558661A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
