# 23. Vacuum lifting device

- **Archive rank:** 23 of 50
- **Publication:** [EP-4385931-A1](https://patents.google.com/patent/EP4385931A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/089121927/publication/EP4385931A1?q=pn%3DEP4385931A1)
- **Publication date:** 2024-06-19
- **Filing date:** 2023-12-07
- **Earliest priority:** 2022-12-12
- **Family:** 89121927
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** TIMMER GMBH
- **Inventors:** TIMMER HERBERT

## Abstract

Die Erfindung betrifft eine Vakuum-Hebevorrichtung (10), umfassend: 
- einen evakuierbaren Saugschlauch (11), 
- ein mit dem Saugschlauch (11) wirkverbundenes Hebeelement (12), welches mit einem zu bewegenden Lastelement mit Hilfe eines im Saugschlauch (11) anliegenden Unterdrucks verbindbar ist, und 
- eine Bedieneinrichtung (13) zur Steuerung des Unterdrucks im Saugschlauch (11), 
• wobei die Bedieneinrichtung (13) ein Gehäuse (14) aufweist, in welchem ein Ventil (15) zur Steuerung des Unterdrucks aufgenommen ist, 
• wobei das Ventil (15) mit Hilfe eines Steuerhebels (16) bedienbar ist, 
• wobei der Steuerhebel (16) relativ zum Gehäuse (14) bewegbar ist, 
• und wobei die Bedieneinrichtung weiterhin mit einem Anschlagselement (18) zur Begrenzung eines Bedienwegs (20) des Steuerhebels (16) versehen ist, 
• und wobei das Anschlagselement (18) an dem Gehäuse (14) verstellbar angeordnet ist. 
  
  
     Erfindungsgemäß weist das Gehäuse (14) eine Erstreckungsachse (19) auf, in deren Richtung der Steuerhebel (16) bewegbar ausgebildet ist, wobei das Anschlagselement (18) zur Begrenzung des Bedienwegs (20) um die Erstreckungsachse (19) verdrehbar und/oder entlang der Erstreckungsachse (19) verschiebbar ausgebildet ist.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/EP-4385931-A1/000.png)

![Sketch 1 for EP-4385931-A1](https://nimo.iptorch.com/refdrawing/EP-4385931-A1/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/EP-4385931-A1/001.png)

![Sketch 2 for EP-4385931-A1](https://nimo.iptorch.com/refdrawing/EP-4385931-A1/001.png)

[Sketch 3](https://patentimages.storage.googleapis.com/19/8c/b7/d7135fe1ee2f6b/imgf0001.png)

![Sketch 3 for EP-4385931-A1](https://patentimages.storage.googleapis.com/19/8c/b7/d7135fe1ee2f6b/imgf0001.png)

[Sketch 4](https://patentimages.storage.googleapis.com/17/b6/3d/e3f5163a786137/imgf0002.png)

![Sketch 4 for EP-4385931-A1](https://patentimages.storage.googleapis.com/17/b6/3d/e3f5163a786137/imgf0002.png)

## Claims

### Claim 1 (independent)

Vakuum-Hebevorrichtung (10), umfassend: - einen evakuierbaren Saugschlauch (11), - eine Vakuumpumpe, welche durchströmbar mit dem Saugschlauch (11) verbunden ist, - ein mit dem Saugschlauch (11) wirkverbundenes Hebeelement (12), welches mit einem zu bewegenden Lastelement mit Hilfe eines im Saugschlauch (11) anliegenden Unterdrucks verbindbar ist, und - eine Bedieneinrichtung (13) zur Steuerung des Unterdrucks im Saugschlauch (11), • wobei die Bedieneinrichtung (13) ein Gehäuse (14) aufweist, in welchem ein Ventil (15) zur Steuerung des Unterdrucks aufgenommen ist, • wobei das Ventil (15) mit Hilfe eines Steuerhebels (16) bedienbar ist, • wobei der Steuerhebel (16) relativ bewegbar ist, • und wobei die Bedieneinrichtung weiterhin mit einem Anschlagselement (18) zur Begrenzung eines Bedienwegs (20) des Steuerhebels (16) versehen ist, • und wobei das Anschlagselement (18) an dem Gehäuse (14) verstellbar angeordnet ist, dadurch gekennzeichnet, dass das Gehäuse (14) eine Erstreckungsachse (19) aufweist, in deren Richtung der Steuerhebel (16) bewegbar ausgebildet ist, wobei das Anschlagselement (18) zur Begrenzung des Bedienwegs (20) um die Erstreckungsachse (19) verdrehbar und/oder entlang der Erstreckungsachse (19) verschiebbar ausgebildet ist.Vacuum lifting device (10), comprising: - an evacuatable suction hose (11), - a vacuum pump which is connected to the suction hose (11) in a flow-through manner, - a lifting element (12) operatively connected to the suction hose (11), which can be connected to a load element to be moved by means of a negative pressure in the suction hose (11), and - an operating device (13) for controlling the negative pressure in the suction hose (11), • wherein the operating device (13) has a housing (14) in which a valve (15) for controlling the negative pressure is accommodated, • wherein the valve (15) can be operated by means of a control lever (16), • wherein the control lever (16) is relatively movable, • and wherein the operating device is further provided with a stop element (18) for limiting an operating path (20) of the control lever (16), • and wherein the stop element (18) is adjustably arranged on the housing (14), characterized in that the housing (14) has an extension axis (19) in the direction of which the control lever (16) is designed to be movable, wherein the stop element (18) for limiting the operating path (20) is designed to be rotatable about the extension axis (19) and/or displaceable along the extension axis (19).

### Claim 2

Vakuum-Hebevorrichtung (10) nach Anspruch 1, dadurch gekennzeichnet, dass das Anschlagselement (18) mit Hilfe eines Arretierelementes (21) am Gehäuse (14) fixierbar ist.Vacuum lifting device (10) according to claim 1, characterized in that the stop element (18) can be fixed to the housing (14) by means of a locking element (21).

### Claim 3

Vakuum-Hebevorrichtung (10) nach Anspruch 2, dadurch gekennzeichnet, dass das Arretierelement (21) zur Herbeiführung eines Form- und/oder Kraftschlusses zwischen dem Anschlagselement (18) und dem Gehäuse (14) ausgebildet ist.Vacuum lifting device (10) according to claim 2, characterized in that the locking element (21) is designed to bring about a positive and/or non-positive connection between the stop element (18) and the housing (14).

### Claim 4

Vakuum-Hebevorrichtung (10) nach Anspruch 2 oder 3, dadurch gekennzeichnet, dass das Arretierelement (21) federbelastet ausgebildet ist.Vacuum lifting device (10) according to claim 2 or 3, characterized in that the locking element (21) is spring-loaded.

### Claim 5

Vakuum-Hebevorrichtung (10) nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass das Anschlagselement (18) in Form einer exzenterförmigen Scheibe ausgebildet ist, welche um die Erstreckungsachse (19) verdrehbar ist.Vacuum lifting device (10) according to one of the preceding claims, characterized in that the stop element (18) is designed in the form of an eccentric disc which is rotatable about the extension axis (19).

### Claim 6

Vakuum-Hebevorrichtung (10) nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass das Anschlagselement (18) hülsenförmig ausgeführt ist.Vacuum lifting device (10) according to one of the preceding claims, characterized in that the stop element (18) is sleeve-shaped.

### Claim 7

Vakuum-Hebevorrichtung (10) nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass das Ventil (15) mechanisch mit dem Steuerhebel (16) verbunden ist.Vacuum lifting device (10) according to one of the preceding claims, characterized in that the valve (15) is mechanically connected to the control lever (16).

### Claim 8

Vakuum-Hebevorrichtung (10) nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass das Ventil (15) in Form eines Tellerhubventils ausgebildet ist.Vacuum lifting device (10) according to one of the preceding claims, characterized in that the valve (15) is designed in the form of a plate lift valve.

### Claim 9

Vakuum-Hebevorrichtung (10) nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass am Gehäuse (14) ein Handgriff (17) angeordnet ist.Vacuum lifting device (10) according to one of the preceding claims, characterized in that a handle (17) is arranged on the housing (14).

### Claim 10

Vakuum-Hebevorrichtung (10) nach Anspruch 9, dadurch gekennzeichnet, dass der Handgriff (17) eine Längsachse (22) aufweist, welche koaxial mit der Erstreckungsachse (19) ausgebildet ist.Vacuum lifting device (10) according to claim 9, characterized in that the handle (17) has a longitudinal axis (22) which is coaxial with the extension axis (19).

### Claim 11

Vakuum-Hebevorrichtung (10) nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass die Vakuum-Hebevorrichtung (10) einen weiteren Handgriff (23) aufweist, welcher zur Bewegung des Saugschlauches (11) ausgebildet ist.Vacuum lifting device (10) according to one of the preceding claims, characterized in that the vacuum lifting device (10) has a further handle (23) which is designed to move the suction hose (11).

### Claim 12

Vakuum-Hebevorrichtung (10) nach Anspruch 11, dadurch gekennzeichnet, dass der weitere Handgriff (23) einstellbar ist.Vacuum lifting device (10) according to claim 11, characterized in that the further handle (23) is adjustable.

### Claim 13

Vakuum-Hebevorrichtung (10) nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass der Saugschlauch (11) in Form eines Faltenschlauchs ausgebildet ist.Vacuum lifting device (10) according to one of the preceding claims, characterized in that the suction hose (11) is designed in the form of a corrugated hose.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansOperating and control devices

Description

Translated from German

Die Erfindung betrifft eine Vakuum-Hebevorrichtung nach dem Oberbegriff des Patentanspruchs 1.The invention relates to a vacuum lifting device according to the preamble of patent claim 1.

Derartige Vakuum-Hebevorrichtungen sind bekannt. Sie ermÃ¶glichen Lastelemente, wie beispielsweise Sackware, Kartonage, Kisten, Platten, MÃ¶bel und vieles mehr, effizient und ohne groÃen Kraftaufwand ergonomisch zu heben und zu bewegen. Die Vakuum-Hebevorrichtung umfasst einen evakuierbaren Saugschlauch, eine Bedieneinrichtung mit einem Ventil zur Steuerung des Vakuums im Saugschlauch sowie ein mit dem Saugschlauch wirkverbundenes Hebeelement. Dieses Hebeelement legt sich mit Hilfe des im Saugschlauch anliegenden Unterdrucks abdichtend an die zu hebenden Lastelemente an und baut auf der gesamten FlÃ¤che des Hebeelementes ein Vakuum auf. Eine weitere Komponente der Vakuum- Hebeeinrichtung ist die Vakuumpumpe, welche zur HerbeifÃ¼hrung des Unterdrucks im Saugschlauch ausgebildet und mit dem Saugschlauch durchstrÃ¶mbar verbunden ist.Such vacuum lifting devices are well known. They enable load elements such as bagged goods, cardboard boxes, crates, panels, furniture and much more to be lifted and moved ergonomically and efficiently without great effort. The vacuum lifting device comprises an evacuatable suction hose, an operating device with a valve for controlling the vacuum in the suction hose and a lifting element that is operatively connected to the suction hose. This lifting element seals against the load elements to be lifted with the help of the negative pressure in the suction hose and builds up a vacuum over the entire surface of the lifting element. Another component of the vacuum lifting device is the vacuum pump, which is designed to create the negative pressure in the suction hose and is connected to the suction hose so that it can flow through.

Im Arbeitseinsatz ist die Handhabung der Lastelemente, oder mit anderen Worten: des Hebegutes, davon abhÃ¤ngig, wie empfindlich das Hebegut ist. Ist beispielsweise bei unempfindlichen HebegÃ¼tern ein schnelles Absetzen und Arbeiten durchaus erwÃ¼nscht, so ist bei empfindlichen HebegÃ¼tern eine feinfÃ¼hlige BetÃ¤tigung des den Hebeprozess steuernden Ventils unerlÃ¤sslich. Durch eine unachtsame BetÃ¤tigung des Ventils und ein dadurch verursachtes zu schnelles BelÃ¼ften des Schlauches erfolgt ein zu schnelles Absenken des Hebegutes. Daher besteht bei empfindlichen HebegÃ¼tern, wie z.B. MÃ¶beln, die Gefahr, dass diese beim Aufsetzen beschÃ¤digt werden.When working, the handling of the load elements, or in other words the lifting goods, depends on how sensitive the lifting goods are. For example, if it is desirable to set down and work quickly with insensitive lifting goods, sensitive operation of the valve controlling the lifting process is essential with sensitive lifting goods. Careless operation of the valve and a This causes the hose to be ventilated too quickly, which results in the lifting item being lowered too quickly. This means that sensitive lifting items, such as furniture, are at risk of being damaged when they are set down.

Aus der Offenlegungsschrift WO2007/094720 A1 ist ein Schlauchheber bekannt, welcher einen Handgriff mit einem daran angeordneten Steuerhebel zur BetÃ¤tigung eines BelÃ¼ftungsventils aufweist. Durch das BetÃ¤tigen des Steuerhebels wird das BelÃ¼ftungsventil geÃ¶ffnet und damit eine Schwebestellung des Saugschlauches beeinflusst. Der Steuerhebel kann so weit betÃ¤tigt werden, dass das BelÃ¼ftungsventil vollstÃ¤ndig Ã¶ffnet. In dieser Stellung schlÃ¤gt der Steuerhebel am Handgriff an. Das vollstÃ¤ndige Ãffnen des BelÃ¼ftungsventils fÃ¼hrt jedoch dazu, dass der Saugschlauch schnell befÃ¼llt wird und sich das Hebegut mit maximaler Geschwindigkeit absenkt. Da die StrÃ¶mungswiderstÃ¤nde sich exponentiell mit einem Ãffnungsweg des Ventils verringern, fÃ¼hrt ein etwas zu weit geÃ¶ffnetes Ventil bereits zu einer erheblichen ErhÃ¶hung von Zuluft und damit zu einem sehr schnellen Absenken des Hebegutes. Es ist somit immer eine besondere Aufmerksamkeit beim Umgang mit dem Schlauchheber notwendig, damit nicht bei unachtsamer Handhabung das Hebegut beschÃ¤digt wird.From the disclosure document WO2007/094720 A1 A hose lifter is known which has a handle with a control lever attached to it for operating a ventilation valve. Operating the control lever opens the ventilation valve and thus influences the floating position of the suction hose. The control lever can be operated so far that the ventilation valve opens completely. In this position, the control lever hits the handle. However, fully opening the ventilation valve leads to the suction hose being filled quickly and the lifting item being lowered at maximum speed. Since the flow resistance decreases exponentially with the opening path of the valve, a valve that is opened a little too far already leads to a considerable increase in supply air and thus to the lifting item being lowered very quickly. It is therefore always necessary to pay particular attention when handling the hose lifter so that the lifting item is not damaged by careless handling.

Somit ist es die Aufgabe der Erfindung, die beschriebenen Nachteile zu beseitigen und eine verbesserte Vakuum-Hebevorrichtung bereitzustellen, welche eine einfache und sichere Begrenzung einer BetÃ¤tigung des Ventils erlaubt.Therefore, it is the object of the invention to eliminate the described disadvantages and to provide an improved vacuum lifting device which allows a simple and safe limitation of an actuation of the valve.

Diese Aufgabe wird gelÃ¶st durch eine Vakuum-Hebevorrichtung mit den Merkmalen des Patentanspruchs 1.This object is achieved by a vacuum lifting device with the features of patent claim 1.

Eine erfindungsgemÃ¤Ãe Vakuum-Hebevorrichtung umfasst

einen evakuierbaren Saugschlauch,

eine Vakuumpumpe, welche durchstrÃ¶mbar mit dem Saugschlauch verbunden ist,

ein mit dem Saugschlauch wirkverbundenes Hebeelement, welches mit einem zu bewegenden Lastelement mit Hilfe eines im Saugschlauch anliegenden Unterdrucks verbindbar ist, und

eine Bedieneinrichtung zur Steuerung des Unterdrucks im Saugschlauch,

wobei die Bedieneinrichtung ein GehÃ¤use aufweist, in welchem ein Ventil zur Steuerung des Unterdrucks aufgenommen ist,

wobei das Ventil mit Hilfe eines Steuerhebels bedienbar ist,

wobei der Steuerhebel relativ zum GehÃ¤use bewegbar ist,

und wobei die Bedieneinrichtung weiterhin mit einem Anschlagselement zur Begrenzung eines Bedienwegs des Steuerhebels versehen ist,

und wobei das Anschlagselement an dem GehÃ¤use verstellbar angeordnet ist.

A vacuum lifting device according to the invention comprises

an evacuatable suction hose,

a vacuum pump which is connected to the suction hose in a flow-through manner,

a lifting element which is operatively connected to the suction hose and which can be connected to a load element to be moved by means of a negative pressure in the suction hose, and

an operating device for controlling the negative pressure in the suction hose,

wherein the operating device comprises a housing in which a valve for controlling the negative pressure is accommodated,

the valve can be operated by means of a control lever,

wherein the control lever is movable relative to the housing,

and wherein the operating device is further provided with a stop element for limiting an operating path of the control lever,

and wherein the stop element is adjustably arranged on the housing.

ErfindungsgemÃ¤Ã weist das GehÃ¤use eine Erstreckungsachse auf, in deren Richtung der Steuerhebel bewegbar ausgebildet ist, wobei das Anschlagselement zur Begrenzung des Bedienwegs um die Erstreckungsachse verdrehbar und/oder entlang der Erstreckungsachse verschiebbar ausgebildet ist. Der Vorteil der Erfindung ist darin zu sehen, dass der Bedienweg auf einfache Weise, und somit schnell, nÃ¤mlich nur durch ein Verdrehen oder Verschieben des Anschlagselementes am GehÃ¤use dem Hebegut anzupassen ist. Somit kann eine maximale Zuluft je nach Hebegut und Aufgabe individuell begrenzt werden. Es kann des Weiteren aufgrund der erfindungsgemÃ¤Ãen Ausgestaltung eine einfache Bedienbarkeit des Anschlagselementes realisiert werden, damit eine einfache und sichere Begrenzung der BetÃ¤tigung des Ventils herbeigefÃ¼hrt ist.According to the invention, the housing has an extension axis in the direction of which the control lever is designed to be movable, wherein the stop element is designed to be rotatable about the extension axis and/or displaceable along the extension axis to limit the operating path. The advantage of the invention is that the operating path can be adapted to the lifting item in a simple and therefore quick manner, namely just by rotating or displacing the stop element on the housing. The maximum air supply can thus be individually limited depending on the lifting item and the task. Furthermore, due to the design according to the invention, the stop element can be easily operated, so that the actuation of the valve can be easily and safely limited.

In einer bevorzugten AusfÃ¼hrungsform ist das Anschlagelement mit Hilfe eines Arretierelementes am GehÃ¤use der Bedieneinrichtung fixierbar. Hierdurch wird eine Verstellung des Anschlagselementes wÃ¤hrend der Bedienung der Vakuum-Hebevorrichtung vermieden. Das heiÃt mit anderen Worten, dass die Verdrehung und/oder Verschiebung des Anschlagselementes mit Hilfe des Arretierelementes unterbunden ist.In a preferred embodiment, the stop element can be fixed to the housing of the operating device using a locking element. This prevents the stop element from being adjusted during operation of the vacuum lifting device. In other words, this means that the rotation and/or displacement of the stop element is prevented using the locking element.

Vorzugsweise ist hierzu das Arretierelement zur HerbeifÃ¼hrung eines Form- und/oder Kraftschlusses zwischen dem Anschlagselement und dem GehÃ¤use ausgebildet. Eine solche Ausgestaltung bietet sicheren Halt und ist bei Bedarf einfach demontierbar.Preferably, the locking element is designed to create a positive and/or force fit between the stop element and the housing. Such a design offers secure hold and can be easily removed if necessary.

Das Arretierelement kann federbelastet ausgebildet sein. Hierdurch wird die Bedienung des Arretierelements vereinfacht und eine schnelle Anpassung des Luftstroms an unterschiedliche HebegÃ¼ter ermÃ¶glicht.The locking element can be spring-loaded. This simplifies the operation of the locking element and enables the air flow to be quickly adjusted to different lifting goods.

In einer weiteren Ausgestaltung der erfindungsgemÃ¤Ãen Vakuum-Hebevorrichtung ist das Anschlagselement in Form einer exzenterfÃ¶rmigen Scheibe ausgebildet, welche um die Erstreckungsachse verdrehbar ist. Die exzenterfÃ¶rmige Scheibe besitzt eine AuÃenkontur eines Steuernockens. Die exzenterfÃ¶rmige Scheibe hat den wesentlichen Vorteil, dass der Bedienweg stufenlos einstellbar und somit in hohem MaÃe individuell an die Anforderungen des Hebegutes anpassbar ist.In a further embodiment of the vacuum lifting device according to the invention, the stop element is designed in the form of an eccentric disk which can be rotated about the axis of extension. The eccentric disk has an outer contour of a control cam. The eccentric disk has the significant advantage that the operating path is continuously adjustable and thus highly individually adaptable to the requirements of the item being lifted.

Alternativ zur oder in Kombination mit der exzenterfÃ¶rmigen Scheibe ist das Anschlagselement hÃ¼lsenfÃ¶rmig ausgefÃ¼hrt. Die HÃ¼lse ist zur VerÃ¤nderung des Bedienwegs einfach entlang der Erstreckungsachse zu verschieben, damit die gewÃ¼nschte Begrenzung des Bedienwegs eingestellt werden kann.As an alternative to or in combination with the eccentric disc, the stop element is designed in the form of a sleeve. To change the operating path, the sleeve can simply be moved along the extension axis so that the desired limitation of the operating path can be set.

Eine einfache und kostengÃ¼nstige Vakuum-Hebevorrichtung kann erzielt werden, indem das Ventil mechanisch mit dem Steuerhebel verbunden ist. Die mechanische Verbindung kann des Weiteren vorteilhaft zu einer BetÃ¤tigung des Ventils in Echtzeit fÃ¼hren. So kann beispielsweise der Steuerhebel in eine am Ventil ausgebildete Nut eingreifend ausgefÃ¼hrt sein, wodurch das Ventil unmittelbar bei BetÃ¤tigung des Steuerhebels ebenfalls betÃ¤tigt wird.A simple and cost-effective vacuum lifting device can be achieved by mechanically connecting the valve to the control lever. The mechanical connection can also advantageously lead to real-time actuation of the valve. For example, the control lever can be designed to engage in a groove formed on the valve, whereby the valve is also actuated immediately when the control lever is actuated.

Das Ventil kann grundsÃ¤tzlich in jeder Form ausgebildet sein, welche eine BetÃ¤tigung des Ventils mit dem Steuerhebel erlaubt. Bevorzugt ist das Ventil in Form eines Tellerhubventils ausgebildet. Das Tellerhubventil bietet den Vorteil einer sicheren BetÃ¤tigung entlang seiner LÃ¤ngsachse. Ein weiterer Vorteil ist die MÃ¶glichkeit eines gesteuerten EinstrÃ¶mens von Zuluft in das GehÃ¤use mit Hilfe eines Ventilkopfes des Tellerventils, welcher in seiner Kontur entsprechenden BedÃ¼rfnissen angepasst werden kann. So kÃ¶nnte beispielsweise ein lÃ¤ngerer kegelstumpffÃ¶rmiger oder kegelfÃ¶rmiger Ventilkopf ein differenzierteres EinstrÃ¶men von Zuluft aufweisen als ein im Vergleich dazu kÃ¼rzerer kegelstumpffÃ¶rmiger oder kegelfÃ¶rmiger Ventilkopf.The valve can basically be designed in any shape that allows the valve to be operated with the control lever. The valve is preferably designed in the form of a poppet valve. The poppet valve offers the advantage of safe operation along its longitudinal axis. A further advantage is the possibility of a controlled inflow of supply air into the housing with the help of a valve head of the poppet valve, the contour of which can be adapted to suit requirements. For example, a longer truncated cone-shaped or conical valve head could have a more differentiated inflow of supply air than a comparatively shorter truncated cone-shaped or conical valve head.

Zur verbesserten Bedienbarkeit des Steuerhebels ist am GehÃ¤use ein Handgriff angeordnet. Damit kann auf einfache Weise eine sogenannte Einhand-Bedienung realisiert werden.To improve the usability of the control lever, a handle is arranged on the housing. This makes it easy to operate it with one hand.

Diese wird weiter verbessert, sofern der Handgriff eine LÃ¤ngsachse aufweist, welche koaxial mit der Erstreckungsachse ausgebildet ist.This is further improved if the handle has a longitudinal axis which is coaxial with the extension axis.

In einer weiteren Ausgestaltung der erfindungsgemÃ¤Ãen Vakuum-Hebevorrichtung weist diese einen weiteren Handgriff auf, welcher zur Bewegung des Saugschlauches ausgebildet ist. Somit kann vorteilhaft durch eine so genannte Zweihand-Bedienung mit der einen Hand der Saugschlauch bewegt werden, wÃ¤hrend die andere Hand zur Steuerung des Unterdrucks den Steuerhebel betÃ¤tigen kann.In a further embodiment of the vacuum lifting device according to the invention, it has a further handle which is designed to move the suction hose. This allows the suction hose to be moved with one hand using what is known as two-handed operation, while the other hand can operate the control lever to control the negative pressure.

Eine individuelle Einstellung und somit eine verbesserte Handhabung der Vakuum-Hebevorrichtung kann mit Hilfe eines einstellbaren weiteren Handgriffes erzielt werden, da dieser personenbezogen ausgerichtet werden kann.An individual adjustment and thus an improved handling of the vacuum lifting device can be achieved with the help of an additional adjustable handle, as this can be aligned to suit the individual.

Ein in Form eines Faltenschlauchs ausgebildeter Saugschlauch fÃ¼hrt zu einer besonders flexiblen Vakuum-Hebevorrichtung, da der Faltenschlauch sowohl in seiner axialen und radialen Ausdehnung verÃ¤nderbar ist.A suction hose designed in the form of a corrugated hose results in a particularly flexible vacuum lifting device, since the corrugated hose can be changed in both its axial and radial extension.

Weitere, die Erfindung verbessernde MaÃnahmen, werden nachstehend mit der Beschreibung von bevorzugten AusfÃ¼hrungsbeispielen der Erfindung anhand der Figuren nÃ¤her dargestellt.Further measures improving the invention are presented in more detail below with the description of preferred embodiments of the invention with reference to the figures.

Gleiche oder Ã¤hnliche Elemente kÃ¶nnen in den nachfolgenden Figuren mit gleichen oder Ã¤hnlichen Bezugszeichen versehen sein. Ferner enthalten die Figuren der Zeichnung, deren Beschreibung sowie die AnsprÃ¼che zahlreiche Merkmale in Kombination. Einem Fachmann ist dabei klar, dass diese Merkmale auch einzeln betrachtet werden oder sie zu weiteren, hier nicht nÃ¤her beschriebenen Kombinationen, zusammengefÃ¼hrt werden kÃ¶nnen. Die Erfindung erstreckt sich ausdrÃ¼cklich auch auf solche AusfÃ¼hrungsformen, welche nicht durch Merkmalskombinationen aus expliziten RÃ¼ckbezÃ¼gen der AnsprÃ¼che gegeben sind, womit die offenbarten Merkmale der Erfindung, soweit dies technisch sinnvoll ist, beliebig miteinander kombiniert sein kÃ¶nnen. Die in den Figuren dargestellten AusfÃ¼hrungsbeispiele haben somit nur beschreibenden Charakter und sind nicht dazu gedacht, die Erfindung in irgendeiner Form einzuschrÃ¤nken.Identical or similar elements can be provided with identical or similar reference symbols in the following figures. Furthermore, the figures of the drawing, their description and the claims contain numerous features in combination. It is clear to a person skilled in the art that these features can also be considered individually or combined to form further combinations not described in detail here. The invention expressly also extends to those embodiments which are not given by feature combinations from explicit references to the claims, whereby the disclosed features of the invention can be combined with one another as desired, as long as this is technically reasonable. The exemplary embodiments shown in the figures are therefore only descriptive in nature and are not intended to limit the invention in any way.

Die Figuren zeigen:

Fig. 1 zeigt in einer perspektivischen Ansicht eine erfindungsgemÃ¤Ãe Vakuum-Hebevorrichtung in einem Ausschnitt, Fig. 2 zeigt in einer perspektivischen Ansicht eine Bedieneinrichtung der Vakuum-Hebevorrichtung gemÃ¤Ã Fig. 1, und Fig. 3 zeigt in einem Schnitt die Bedieneinrichtung gemÃ¤Ã Fig. 2. The figures show: Fig.1 shows a perspective view of a vacuum lifting device according to the invention in a detail, Fig.2 shows in a perspective view an operating device of the vacuum lifting device according to Fig.1 , and Fig.3 shows in a section the operating device according to Fig.2 .

Eine erfindungsgemÃ¤Ãe Vakuum-Hebevorrichtung 10 ist beispielhaft gemÃ¤Ã Fig. 1 aufgebaut. Sie umfasst einen evakuierbaren Saugschlauch 11, welcher mit Hilfe einer durchstrÃ¶mbaren Druckregeleinrichtung 24 verbunden ist. Die Druckregeleinrichtung 24 umfasst ein RohrgestÃ¤nge 32 und eine Schlauchleitung 33. Zwischen dem Handgriff 23 und dem Saugschlauch 11 kann eine weitere Schlauchleitung 34 zur SchnellentlÃ¼ftung des Saugschlauchs 11 vorgesehen sein. Im dargestellten AusfÃ¼hrungsbeispiel ist die Schlauchleitung 34 lediglich in Form einer Strichpunktlinie angedeutet..A vacuum lifting device 10 according to the invention is exemplary according to Fig.1 It comprises an evacuatable suction hose 11, which is connected to a flow-through pressure control device 24. The pressure control device 24 comprises a pipe rod 32 and a hose line 33. Between the handle 23 and the suction hose 11, a further hose line 34 can be connected for quick ventilation of the suction hose 11. In the illustrated embodiment, the hose line 34 is only indicated in the form of a dash-dot line.

Das RohrgestÃ¤nge 32 dient der mechanischen FÃ¼hrung der Druckregeleinrichtung 24. Die Schlauchleitung 33 ist an den Saugschlauch 11 gekoppelt. Der Saugschlauch 11 ist in Form eines so genannten Faltenschlauchs ausgebildet. An einem Ende des Saugschlauchs 11 ist ein Hebeelement 12 angeordnet, welches mit dem Saugschlauch 11 wirkverbunden ausgebildet und mit einem zu bewegenden, nicht nÃ¤her abgebildeten Lastelement mit Hilfe eines im Saugschlauch 11 anliegenden Unterdrucks verbindbar ist. Eine ErhÃ¶hung des Unterdruckes fÃ¼hrt zu einem Kontakt des Lastelementes mit dem Hebeelement 12, wohingegen eine Reduzierung des Unterdruckes eine Aufhebung des Kontaktes herbeifÃ¼hrt, welche bevorzugt nach Positionierung des Lastelementes an einem gewÃ¼nschten Ablageort erfolgt. Das heiÃt mit anderen Worten, dass das mit dem Saugschlauch 11 wirkverbundene Hebeelement 12 mit dem zu bewegenden Lastelement mit Hilfe des im Saugschlauch 11 anliegenden Unterdrucks, verbindbar ist.The pipe rod 32 serves to mechanically guide the pressure control device 24. The hose line 33 is coupled to the suction hose 11. The suction hose 11 is designed in the form of a so-called corrugated hose. At one end of the suction hose 11 there is a lifting element 12 which is operatively connected to the suction hose 11 and can be connected to a load element to be moved (not shown in detail) with the aid of a negative pressure in the suction hose 11. An increase in the negative pressure leads to contact between the load element and the lifting element 12, whereas a reduction in the negative pressure causes the contact to be broken, which preferably takes place after the load element has been positioned at a desired storage location. In other words, this means that the lifting element 12 operatively connected to the suction hose 11 can be connected to the load element to be moved with the aid of the negative pressure in the suction hose 11.

Die Druckregeleinrichtung 24 weist eine Bedieneinrichtung 13 auf, mit deren Hilfe der Unterdruck, und somit respektive der Druck im Saugschlauch 11, steuerbar ist. Ebenso kÃ¶nnte die Bedieneinrichtung 13 auch unmittelbar am Saugschlauch 11 ausgebildet sein, jedoch hat sich die ErgÃ¤nzung der Druckregeleinrichtung 24 zur verbesserten Handhabung des Lastelementes mit Hilfe des Saugschlauches 11 besonders bedienfreundlich erwiesen.The pressure control device 24 has an operating device 13 with the aid of which the negative pressure, and thus the pressure in the suction hose 11, can be controlled. The operating device 13 could also be formed directly on the suction hose 11, but the addition of the pressure control device 24 to improve handling of the load element with the aid of the suction hose 11 has proven to be particularly user-friendly.

In Fig. 2 ist die Bedieneinrichtung 13, welche zur Steuerung des Unterdrucks im Saugschlauch 11 ausgebildet ist, in einer perspektivischen Darstellung abgebildet. Sie weist ein GehÃ¤use 14 auf, in welchem ein Ventil 15 zur Steuerung des Unterdrucks aufgenommen ist. Dieses Ventil 15 ist in Fig. 3 erkennbar. Das Ventil 15 ist im vorliegenden AusfÃ¼hrungsbeispiel in Form eines federbelasteten Tellerhubventils ausgebildet. Das Ventil 15 umfasst einen Ventilkopf 26, der kegelstumpffÃ¶rmig ausgefÃ¼hrt ist. Mittels des kegelstumpffÃ¶rmigen Ventilkopfs 26 kann die Schlauchleitung 33 geÃ¶ffnet beziehungsweise geschlossen werden. Bei teilweise oder auch ganz geÃ¶ffneten Ventil 15 kann somit Umgebungsluft Ã¼ber am GehÃ¤use 14 vorgesehene DurchstrÃ¶mÃ¶ffnungen 25 in die Schlauchleitung 33 gelangen und den dort vorhandenen Unterdruck reduzieren. Der auf das Hebeelement 12 einwirkende Unterdruck ist somit mittels des Ventils 15 feinfÃ¼hlig variierbar.In Fig.2 the operating device 13, which is designed to control the negative pressure in the suction hose 11, is shown in a perspective view. It has a housing 14 in which a valve 15 for controlling the negative pressure is accommodated. This valve 15 is in Fig.3 recognizable. In the present embodiment, the valve 15 is designed in the form of a spring-loaded plate lift valve. The valve 15 comprises a valve head 26 which is designed in the shape of a truncated cone. The hose line 33 can be opened or closed by means of the truncated cone-shaped valve head 26. When the valve 15 is partially or completely open, ambient air can thus enter the hose line 33 via flow openings 25 provided on the housing 14 and reduce the negative pressure present there. The negative pressure acting on the lifting element 12 can thus be finely varied by means of the valve 15.

Alternativ zu einer Steuerung des Unterdrucks Ã¼ber das Ventil 15 kÃ¶nnten auch die DurchstrÃ¶mÃ¶ffnungen 25 selbst mit Ventilen versehen sein. Dabei wÃ¤re es grundsÃ¤tzlich schon ausreichend, wenn lediglich eine DurchstrÃ¶mÃ¶ffnung 25 vorgesehen und diese mit einem Ventil ausgestattet ist.As an alternative to controlling the negative pressure via the valve 15, the flow openings 25 themselves could also be provided with valves. In principle, it would be It is sufficient if only one flow opening 25 is provided and this is equipped with a valve.

Eine weitere Komponente der Vakuum-Hebevorrichtung 10 ist eine nicht nÃ¤her abgebildete Vakuumpumpe. Die Vakuumpumpe ist an dem Saugschlauch 11 mit diesem durchstrÃ¶mbar aufgenommen und Ã¼blicherweise an einem vom Hebeelement 12 abgewandt ausgebildeten Ende des Saugschlauches 11 angeordnet. Die Vakuum-Pumpe ist zur HerbeifÃ¼hrung des Vakuums im Saugschlauch 11 ausgebildet und saugt Luft aus dem bevorzugt in Form eines Faltenschlauchs ausgebildeten Saugschlauchs 11, wodurch der erforderliche, zur Anhebung des Hebegutes notwendige Unterdruck herbeigefÃ¼hrt wird. Der so herbeigefÃ¼hrte Unterdruck im Saugschlauch 11 fÃ¼hrt zu einem Zusammenziehen des Saugschlauches 11 und somit zu einem Anheben des mit dem Hebeelement 12 wirkverbundenen Hebegutes. Es sei erwÃ¤hnt, dass eine WirkflÃ¤che des Hebeelementes 12 vorteilhaft grÃ¶Ãer ausgebildet ist als eine QuerschnittsflÃ¤che des Saugschlauches 11, damit bei einer Reduzierung des Vakuums das Hebegut gesichert abgesenkt werden kann, bevor ein Haftungsverlust des Hebeelementes 12 eintritt, welcher zu einem LÃ¶sen des Hebegutes vom Hebeelement 12 fÃ¼hrt und infolgedessen das Hebegut herabfÃ¤llt.Another component of the vacuum lifting device 10 is a vacuum pump (not shown in detail). The vacuum pump is attached to the suction hose 11 so that it can flow through it and is usually arranged at an end of the suction hose 11 facing away from the lifting element 12. The vacuum pump is designed to create a vacuum in the suction hose 11 and sucks air out of the suction hose 11, which is preferably designed in the form of a corrugated hose, thereby creating the negative pressure required to lift the item being lifted. The negative pressure thus created in the suction hose 11 leads to a contraction of the suction hose 11 and thus to a lifting of the item being lifted that is operatively connected to the lifting element 12. It should be mentioned that an effective surface of the lifting element 12 is advantageously designed to be larger than a cross-sectional area of the suction hose 11 so that when the vacuum is reduced, the lifting item can be lowered safely before a loss of adhesion of the lifting element 12 occurs, which leads to a release of the lifting item from the lifting element 12 and, as a result, the lifting item falls down.

Das Ventil 15 ist mit Hilfe eines Steuerhebels 16 bedienbar, insbesondere manuell bedienbar. Ein Ventilschaft 27 des Ventils 15 ist mechanisch mit dem Steuerhebel 16 verbunden, wobei ein Hebelarm 28 des Steuerhebels 16 an seinem ersten Armende 29 mit dem Ventilschaft 27 verbunden ist. An seinem vom ersten Armende 29 abgewandt ausgebildeten zweiten Armende 30 besitzt der Steuerhebel 16 einen Hebelgriff 31, welcher zur verbesserten Handhabung bevorzugt ergonomisch ausgebildet ist. An dieser Stelle sei erwÃ¤hnt, dass des Ventil 15 nicht zwingend in der beispielhaft illustrierten Form ausgefÃ¼hrt sein muss, sondern jede mÃ¶gliche Form eines SchlieÃventils aufweisen kann, welches mit dem Steuerhebel 16 bedienbar ist.The valve 15 can be operated with the aid of a control lever 16, in particular manually. A valve stem 27 of the valve 15 is mechanically connected to the control lever 16, with a lever arm 28 of the control lever 16 being connected to the valve stem 27 at its first arm end 29. At its second arm end 30, which faces away from the first arm end 29, the control lever 16 has a lever handle 31, which is preferably ergonomically designed for improved handling. At this point, it should be mentioned that the valve 15 does not necessarily have to be designed in the form illustrated as an example, but can have any possible form of a closing valve that can be operated with the control lever 16.

Die Bedieneinrichtung 13 ermÃ¶glicht eine Beeinflussung der Hubbewegung der Vakuum-Hebevorrichtung 10. Des Ventil 15 wird mit Hilfe des Steuerhebels 16 beaufschlagt, wobei eine Auslenkung des Steuerhebels 16 die Ãffnung des Ventils 16 und damit eine Absenkgeschwindigkeit des Hebegutes herbeifÃ¼hrt.The operating device 13 makes it possible to influence the lifting movement of the vacuum lifting device 10. The valve 15 is actuated by means of the control lever 16, whereby a deflection of the control lever 16 causes the opening of the valve 16 and thus a lowering speed of the lifting object.

Das GehÃ¤use 14 besitzt eine Erstreckungsachse 19 entlang derer das Ventil 15 axial bewegbar angeordnet ist. Diese axiale Bewegung des Ventils 15 wird mit einer Schwenkbewegung des Hebelarms 28 um einen Drehpunkt, welcher am Ventilschaft 27 ausgebildet ist, herbeigefÃ¼hrt. Mit BetÃ¤tigung des Steuerhebels 16 legt dieser einen Bedienweg 20 zurÃ¼ck, wobei der Bedienweg 20 auf die Erstreckungsachse 19 zu oder von dieser weg fÃ¼hrt. Der Steuerhebel 16 ist somit in Richtung der Erstreckungsachse 19 bewegbar ausgefÃ¼hrt. Das heiÃt mit anderen Worten, dass er sich in die Richtung auf die Erstreckungsachse 19 oder von dieser abgewandt bewegen lÃ¤sst.The housing 14 has an extension axis 19 along which the valve 15 is arranged to be axially movable. This axial movement of the valve 15 is achieved with a Pivoting movement of the lever arm 28 about a pivot point which is formed on the valve stem 27. When the control lever 16 is actuated, it covers an operating path 20, whereby the operating path 20 leads towards or away from the extension axis 19. The control lever 16 is thus designed to be movable in the direction of the extension axis 19. In other words, this means that it can be moved in the direction of the extension axis 19 or away from it.

Der Steuerhebel 16 ist mit dem Ventil 15 wirkverbunden und ist relativ zum GehÃ¤use 14 bewegbar. Am GehÃ¤use 14 ist ein fest mit dem GehÃ¤use 14 verbundener Handgriff 17 angeordnet. Somit ist der Steuerhebel 16 im vorliegenden AusfÃ¼hrungsbeispiel auch relativ zum Handgriff 17 bewegbar. Der Handgriff 17 dient einer verbesserten Handhabung der Bedieneinrichtung 13. Der Handgriff 17 ist im vorliegenden AusfÃ¼hrungsbeispiel derart angeordnet, dass seine LÃ¤ngsachse 22 koaxial mit der Erstreckungsachse 19 ausgebildet ist.The control lever 16 is operatively connected to the valve 15 and is movable relative to the housing 14. A handle 17 that is firmly connected to the housing 14 is arranged on the housing 14. Thus, the control lever 16 in the present embodiment is also movable relative to the handle 17. The handle 17 serves to improve the handling of the operating device 13. In the present embodiment, the handle 17 is arranged such that its longitudinal axis 22 is coaxial with the extension axis 19.

Die Vakuum-Hebevorrichtung 10 besitzt im dargestellten AusfÃ¼hrungsbeispiel einen weiteren Handgriff 23, welcher zur bevorzugten Bewegung des Saugschlauches 11 ausgebildet ist. Er ist im vorliegenden beispielhaften AusfÃ¼hrungsbeispiel, wie in Fig. 1 illustriert, an der Druckregeleinrichtung 24 einstellbar angeordnet. Er kann vorteilhaft verschwenkt und in axialer Richtung verstellt werden.In the embodiment shown, the vacuum lifting device 10 has a further handle 23, which is designed for the preferred movement of the suction hose 11. In the present exemplary embodiment, as in Fig.1 illustrated, is arranged adjustably on the pressure control device 24. It can advantageously be pivoted and adjusted in the axial direction.

Die Bedieneinrichtung 13 ist mit einem Anschlagselement 18 versehen, welches zur Begrenzung des Bedienwegs 20 des Steuerhebels 16 ausgebildet ist, wobei das Anschlagselement 18 an dem GehÃ¤use 14 verstellbar angeordnet ist. ErfindungsgemÃ¤Ã ist das Anschlagselement 18 um die Erstreckungsachse 19 verdrehbar und/oder entlang der Erstreckungsachse 19 verschiebbar ausgebildet.The operating device 13 is provided with a stop element 18 which is designed to limit the operating path 20 of the control lever 16, wherein the stop element 18 is adjustably arranged on the housing 14. According to the invention, the stop element 18 is designed to be rotatable about the extension axis 19 and/or displaceable along the extension axis 19.

Das Anschlagselement 18 ist gemÃ¤Ã dem vorliegenden AusfÃ¼hrungsbeispiel in Form einer exzenterfÃ¶rmigen Scheibe realisiert, wie sie in den Figuren 1 bis 3 illustriert ist. Diese exzenterfÃ¶rmige Scheibe 18 ist drehbar um die Erstreckungsachse 19 am GehÃ¤use 14 gelagert. In AbhÃ¤ngigkeit von einer Positionierung der exzenterfÃ¶rmigen Scheibe 18, das heiÃt in AbhÃ¤ngigkeit von einem Drehwinkel um die Erstreckungsachse 19, kÃ¶nnen verschieden groÃe Bedienwege 20 realisiert werden. Ebenso kÃ¶nnte das Anschlagselement 18 auch hÃ¼lsenfÃ¶rmig ausgebildet sein und somit eine HÃ¼lse aufweisen, welche entlang der Erstreckungsachse 19 axial verschiebbar ist. Somit stellt das Anschlagselement 18 einen variablen, oder mit anderen Worten gesagt, einen variierbaren Anschlag dar, mittels dessen auf einfache Weise in AbhÃ¤ngigkeit von einem zu bewegenden Hebegut der erforderlichen Bedienweg 20 des Steuerhebels 16 einstellbar ausgebildet ist.The stop element 18 is realized according to the present embodiment in the form of an eccentric disk, as shown in the Figures 1 to 3 This eccentric disk 18 is mounted on the housing 14 so that it can rotate about the axis of extension 19. Depending on the positioning of the eccentric disk 18, i.e. depending on the angle of rotation about the axis of extension 19, different operating paths 20 can be realized. Likewise, the stop element 18 could also be designed in the form of a sleeve and thus have a sleeve which is axially displaceable along the axis of extension 19. The stop element 18 thus represents a variable, or in other words, a variable stop, by means of which The required operating path 20 of the control lever 16 is designed to be adjustable in a simple manner depending on the lifting item to be moved.

Vorzugsweise besitzt das Anschlagselement 18 ein Arretierelement 21, damit es am GehÃ¤use 14 fixierbar ist, und somit wÃ¤hrend einer Bedienung der Vakuum-Hebevorrichtung 10 nicht unbeabsichtigt in seiner Position verÃ¤ndert wird. Das heiÃt mit anderen Worten, dass das Anschlagselement 18 mit Hilfe eines Arretierelementes 21 am GehÃ¤use 14 fixierbar ist. Das Arretierelement 21 kann beispielsweise in Form einer so genannten Madenschraube ausgebildet sein. Ebenso kÃ¶nnen auch andere Formen einer Fixierung, beispielsweise in Form einer Klemmung, realisiert werden, damit ein versehentliches Verstellen wÃ¤hrend des Betriebs ausgeschlossen ist.The stop element 18 preferably has a locking element 21 so that it can be fixed to the housing 14 and thus its position is not inadvertently changed during operation of the vacuum lifting device 10. In other words, this means that the stop element 18 can be fixed to the housing 14 with the aid of a locking element 21. The locking element 21 can, for example, be designed in the form of a so-called grub screw. Other forms of fixation, for example in the form of a clamp, can also be implemented so that accidental adjustment during operation is excluded.

In einem weiteren, nicht nÃ¤her abgebildeten AusfÃ¼hrungsbeispiel, ist das Anschlagselement 18 durch eine insbesondere zahnfÃ¶rmige Rastung gegen Verdrehen gesichert. Dabei ist an einer FlÃ¤che des Anschlagselementes 18 ein Zahnkranz ausgebildet, welcher in einen gegenÃ¼berliegend angeordneten weiteren Zahnkranz, welcher am GehÃ¤use 14 angeordnet ist, eingreifbar ausgefÃ¼hrt ist. Wird das Anschlagselement 18 in axialer Richtung, und somit entlang der Erstreckungsachse 19, durch Ziehen bewegt, lÃ¶sen sich die beiden ZahnkrÃ¤nze voneinander, wobei ein Bewegungsspalt zwischen ihnen ausgebildet wird. In dieser Position kann eine Verdrehung des Anschlagselementes 18 vorgenommen werden. Eine SchlieÃung der beiden ZahnkrÃ¤nze kann durch ein manuelles DrÃ¼cken erfolgen, ebenso durch ein Loslassen des Anschlagselementes 18, sofern zumindest einer der beiden ZahnkrÃ¤nze federbeaufschlagt und/oder magnetisch ausgefÃ¼hrt ist. Die Rastung kÃ¶nnte auch durch Ausnehmungen, bspw. in Form von Bohrungen oder Aussparungen mit entsprechenden komplementÃ¤r ausgefÃ¼hrten Gegenelementen, bspw. Gegenstiften, realisiert sein.In a further embodiment, not shown in detail, the stop element 18 is secured against rotation by a particularly tooth-shaped locking mechanism. A toothed ring is formed on one surface of the stop element 18, which is designed to engage with another toothed ring arranged opposite, which is arranged on the housing 14. If the stop element 18 is moved in the axial direction, and thus along the extension axis 19, by pulling, the two toothed rings separate from one another, forming a movement gap between them. In this position, the stop element 18 can be rotated. The two toothed rings can be closed by manually pressing, or by releasing the stop element 18, provided that at least one of the two toothed rings is spring-loaded and/or magnetic. The locking mechanism could also be implemented by recesses, for example in the form of holes or recesses with corresponding complementary counter elements, for example counter pins.

In einem weiteren, nicht nÃ¤her abgebildeten AusfÃ¼hrungsbeispiel ist das Anschlagselement 18 mit Hilfe des Arretierelementes 21 in Form eines federkraftbeaufschlagten Druckelementes, beispielsweise in Form einer Kugel, gegen eine versehentliche Verstellung gesichert. Die Positionierung des Anschlagselementes 18 erfolgt dann durch Ãberwindung der Federkraft, wobei die Federkraft so groÃ zu wÃ¤hlen ist, dass ein versehentliches Verstellen verhindert werden kann. Das bedeutet, dass das Arretierelement 21 federbelastet ausgebildet ist.In a further embodiment, not shown in detail, the stop element 18 is secured against accidental adjustment by means of the locking element 21 in the form of a spring-loaded pressure element, for example in the form of a ball. The positioning of the stop element 18 is then carried out by overcoming the spring force, whereby the spring force must be selected to be large enough to prevent accidental adjustment. This means that the locking element 21 is designed to be spring-loaded.

Ebenso kÃ¶nnte das DruckstÃ¼ck in Form eines bolzenartigen Stiftes ausgebildet sein. Es mÃ¼sste dann das DruckstÃ¼ck durch Ziehen oder DrÃ¼cken gelÃ¶st werden um die Sicherung zu entsperren und ein Verdrehen des Anschlagselementes 18 zu ermÃ¶glichen.The pressure piece could also be designed in the form of a bolt-like pin. The pressure piece would then have to be released by pulling or pushing in order to unlock the safety device and enable the stop element 18 to be rotated.

SÃ¤mtliche vorstehend beispielhaft genannten Arretierelemente 21 sind zur HerbeifÃ¼hrung eines Form- und/oder Kraftschlusses zwischen dem Anschlagselement 18 und dem GehÃ¤use 14 ausgebildet.All of the locking elements 21 mentioned above as examples are designed to bring about a positive and/or force-locking connection between the stop element 18 and the housing 14.

BezugszeichenlisteList of reference symbols

1010

Vakuum-HebevorrichtungVacuum lifting device

1111

SaugschlauchSuction hose

1212

HebeelementLifting element

1313

BedieneinrichtungControl device

1414

GehÃ¤useHousing

1515

VentilValve

1616

SteuerhebelControl lever

1717

HandgriffHandle

1818

AnschlagselementStop element

1919

ErstreckungsachseExtension axis

2020

BedienwegOperating path

2121

ArretierelementLocking element

2222

LÃ¤ngsachseLongitudinal axis

2323

Weiterer HandgriffFurther handling

2424

DruckregeleinrichtungPressure control device

2525

DurchstrÃ¶mÃ¶ffnungFlow opening

2626

VentilkopfValve head

2727

VentilschaftValve stem

2828

Hebelarm (von 16)Lever arm (of 16)

2929

Erstes ArmendeFirst end of the poor

3030

Zweites ArmendeSecond arm end

3131

Hebelgriff (von 16)Lever handle (of 16)

3232

RohrgestÃ¤ngePipe rods

3333

SchlauchleitungHose line

3434

SchlauchleitungHose line

## Classifications

- B66C1/0256
- B66C1/02

## Cited patent documents

- [CH-656599-A5](https://patents.google.com/patent/CH656599A5/en) — SEA
- [DE-10038013-A1](https://patents.google.com/patent/DE10038013A1/en) — SEA
- [DE-2249044-A1](https://patents.google.com/patent/DE2249044A1/en) — SEA
- [DE-3618704-C1](https://patents.google.com/patent/DE3618704C1/en) — SEA
- [US-2247787-A](https://patents.google.com/patent/US2247787A/en) — SEA
- [US-5035456-A](https://patents.google.com/patent/US5035456A/en) — SEA
- [US-9061868-B1](https://patents.google.com/patent/US9061868B1/en) — SEA
- [WO-2007094720-A1](https://patents.google.com/patent/WO2007094720A1/en) — APP

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
