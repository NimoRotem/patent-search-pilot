# 48. Apparatus for handling layers of palletised goods

- **Archive rank:** 48 of 50
- **Publication:** [US-2009324377-A1](https://patents.google.com/patent/US20090324377A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/039081964/publication/US20090324377A1?q=pn%3DUS20090324377A1)
- **Publication date:** 2009-12-31
- **Filing date:** 2007-08-17
- **Earliest priority:** 2006-08-18
- **Family:** 39081964
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** CHRISTENSEN TORBEN; HANSEN HENRIK KJELDGAARD
- **Inventors:** CHRISTENSEN TORBEN; HANSEN HENRIK KJELDGAARD

## Abstract

An apparatus for handling layers of palletised goods, including a vertically displaceable lift head ( 2 ) with a mainly horizontal suction face which is substantially adjusted in size for a pallet, and which comprises downwardly open suction chambers ( 8 ) which via individual ball valves and an air distribution chamber are connected to a centrifugal blower ( 4 ), which is incorporated in the lift head ( 2 ) and constitutes the vacuum source of the apparatus. The suction face moves downwards against the upper side of an upper layer of individually or groupwise packed goods on a pallet. The ball valves are light, thin-walled spherical valve bodies ( 10 ). The ball valves are closed if the associated suction chamber ( 8 ) is not blocked downwardly by contacting the upper side of the goods on the uppermost pallet layer. The lift head ( 2 ) along the outer sides of the suction face comprises a vertically adjustable skirt with inflatable squeezing pads arranged for exerting an inwardly directed pressure on the outer sides of the goods of the upper pallet layer. Each valve has provided arresting means to prevent the valve balls ( 10 ) from shutting off the valves.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-2009324377-A1/000.png)

![Sketch 1 for US-2009324377-A1](https://nimo.iptorch.com/refdrawing/US-2009324377-A1/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/US-2009324377-A1/001.png)

![Sketch 2 for US-2009324377-A1](https://nimo.iptorch.com/refdrawing/US-2009324377-A1/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/US-2009324377-A1/002.png)

![Sketch 3 for US-2009324377-A1](https://nimo.iptorch.com/refdrawing/US-2009324377-A1/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/US-2009324377-A1/003.png)

![Sketch 4 for US-2009324377-A1](https://nimo.iptorch.com/refdrawing/US-2009324377-A1/003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/US-2009324377-A1/004.png)

![Sketch 5 for US-2009324377-A1](https://nimo.iptorch.com/refdrawing/US-2009324377-A1/004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/US-2009324377-A1/005.png)

![Sketch 6 for US-2009324377-A1](https://nimo.iptorch.com/refdrawing/US-2009324377-A1/005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/US-2009324377-A1/006.png)

![Sketch 7 for US-2009324377-A1](https://nimo.iptorch.com/refdrawing/US-2009324377-A1/006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/US-2009324377-A1/007.png)

![Sketch 8 for US-2009324377-A1](https://nimo.iptorch.com/refdrawing/US-2009324377-A1/007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/US-2009324377-A1/008.png)

![Sketch 9 for US-2009324377-A1](https://nimo.iptorch.com/refdrawing/US-2009324377-A1/008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/US-2009324377-A1/009.png)

![Sketch 10 for US-2009324377-A1](https://nimo.iptorch.com/refdrawing/US-2009324377-A1/009.png)

## Claims

### Claim 11 (independent)

An apparatus for handling layers of palletized goods, comprising a vertically displaceable lift head with a mainly horizontal suction face formed for a pallet, including downwardly opening suction chambers, individual ball valves and an air distribution chamber connected to a centrifugal blower for providing a vacuum source, the suction face being movable downwards against an upper side of an upper layer of individual or group packed goods on a pallet, the ball valves including walled spherical valve bodies, the ball valves being closed when an associated suction chamber is not blocked downwards by contacting an upper side of the goods on an uppermost pallet layer, the lift head along outer sides of the horizontal suction face comprising a vertically adjustable skirt with inflatable squeezing pads for exerting an inwardly directed pressure on outer sides of goods of the upper pallet layer, each of the valves including arresting means for preventing the valve balls from shutting off the valves, the arresting means actuating valve balls for individual suction chambers and comprising downwardly extending blunt bodies which are resiliently suspended for yielding to valve balls which are already in closing abutment with a valve seat of the associated suction chamber for preventing valve balls from contacting the valve seats of valves that have not been closed.

### Claim 12

An apparatus according to claim 11 wherein the arresting means comprises downwardly blunt bodies which are vertically displaceable in height in relation to valve balls which are already in closing abutment with the valve seat of an associated suction chamber for preventing valve balls from contacting the valve seats of valves that have not been closed.

### Claim 13

An apparatus according to claim 11 , wherein each of the valves includes a valve seat comprising an elastic material for releasing the valve balls automatically by venting a vacuum from the air distribution chamber.

### Claim 14

An apparatus according to claim 11 , wherein the valve balls of each of the valves are supported at the bottom on inwardly projecting edge parts comprising elastic material.

### Claim 15

An apparatus according to claim 14 , comprising a blower for operating the inflatable squeezing pads, and a changeover valve located between the blower and the inflatable squeezing pads for connecting the inflatable squeezing pads either to a suction side or to a pressure side of the blower.

### Claim 16

An apparatus according to claim 15 wherein the blower comprises a side channel blower.

### Claim 17

An apparatus according to claim 14 , comprising a pressure regulation valve between the changeover valve and the inflatable squeezing pads.

### Claim 18

An apparatus according to claim 17 , wherein the pressure regulating valve includes an upper venting valve with a valve ball which is actuated by at least one upper lever arm with regulating slides.

### Claim 19

An apparatus according to claim 17 , wherein the pressure regulating valve includes a cylinder or a bellows with a piston for lifting at least one of the lever arms for opening the venting valve.

## Full description

### Background Of The Invention

**[p0001]**

1. Field of the Invention The present invention concerns an apparatus for handling layers of palletized goods. 2. Description of the Prior Art In order to make effective and cheap and to simplify distribution of goods, most goods are sold on pallets, preferably the so-called EU pallets (800×1200 mm). Anyway, a widespread need has appeared for also dispatching orders comprising lesser amounts of goods in a correspondingly effective way. Statistically it appears that many orders for small shops actually consist of consignments of goods most often consisting of very few layers or maybe just a single layer of palletized goods. U.S. Pat. Nos. 3,406,938 and 3,229,953 describe a lifting device and an item holder using relatively complicated lifting or holding faces which have a large number of lesser chambers that are open toward the lifting face and the holding face, respectively. For lifting or holding of by way of example plate shaped items with different outer shape or size in the printing industry, it is known to use lifting or holding faces with a differentiated vacuum chamber system, that is with a number of uniform, but individually connected chambers, which by means of a valve system may be connected with one or more vacuum sources in such a way that sheets or plates with individual shape or size may be lifted or held fast with one and the same lifting or holding face.

**[p0002]**

WO-97/45355-A1 discloses an apparatus for lifting and moving of articles, comprising at least one arrangement with a cavity, hereafter called vacuum chamber, which is connected to an arrangement which is capable of producing negative pressure in said vacuum chamber, the underside of said lower plate being provided with an elastic airtight bottom and also being provided with a number of first through-passages to said vacuum chamber. The invention is characterized in that each first passage is of cylindrical design with a diameter reduction in the part which is connected to the vacuum chamber, forming a shoulder in the passage, in that the passage contains a body arranged moveably in said passage, in that said body, in planes which are at right angles to the centre line of the passage, has a greatest diameter which is only slightly smaller than the diameter of said first passage, and in that said first passage is provided with a second passage with a considerably smaller diameter that the first passage, said body being capable of essentially blocking said first passage when a negative pressure is obtained in the vacuum chamber with exception of a given air flow in said second passage.

**[p0003]**

WO-00/64790-A1 discloses an apparatus for handling layers of palletized goods, the apparatus comprising a vertically displaceable lift head with a horizontal suction face which in size is adapted to a pallet and has a large number of downwards open suction chambers. The suction face is arranged to be moved downwards against the top side of an upper layer of individually or groupwise packed goods on a pallet, where the suction chambers via individual valves are connected with a source of vacuum incorporated in the lift head, where the apparatus is intended for interacting with a depalletising system. The valves between the suction chambers and the source of vacuum are designed as ball valves with very light thin-walled valve bodies that are enclosed in the suction chamber by means of lateral projections or by means of a retainer net, and which interact with upper round valve openings with spherical valve seats at the bottom if the actual suction chamber is not blocked at the bottom by contacting the top side of the goods in an upper pallet layer. Along the outer sides of the suction face, the lift head comprises squeezing means for exerting an inwardly pressure at the outer sides of the goods in the uppermost pallet layer. The description of the previous invention is incorporated in the present application by reference.

### Summary Of The Invention

**[p0004]**

The invention is a new and improved apparatus for handling layers of palletized goods, and which enables mechanising layerwise destacking of individual articles from a pallet with greater certainty, even if the individual pallet layers include openings between the articles or include articles that are film-covered in such a way that openings in the pallet layer are formed upwards so that the shut-off valves of the suction face close where there is a hole or openings in the pallet layer, and is forced open where there is contact on the articles. The apparatus according to the invention is characterised in that the arresting means are adapted to actuate valve balls for individual suction chambers as the arresting means are constituted by downwards bluntly designed bodies which are resiliently suspended for yielding to valve balls which are already in closing abutment with the valve seat of the associated suction chamber, and for preventing valve balls from getting in contact with valve seats of valves that have not been closed. By means of simple measures there is hereby achieved a new and improved apparatus that enables handling of many different types of palletised goods in layers with great certainty.

**[p0005]**

Alternatively, the apparatus according to the invention has the arresting means constituted by bodies bluntly designed at the bottom and which are arranged to be vertically displaceable in order to be displaced in height in relation to valve balls which are already in closing abutment with the valve seat of the associated suction chamber, and for preventing valve balls from getting in contact with valve seats of valves that have not been closed. In order to ensure automatic release of the valve balls, the apparatus according to the invention may advantageously be designed so that each of the valves includes a valve seat having an elastic material which is for releasing the valve balls automatically by venting a vacuum from the air distribution chamber. With an object of achieving easier replacement of valve balls, the apparatus according to the invention may advantageously have the valve balls of each of the valves supported at the bottom on inwards projecting edge parts of elastic material.

**[p0006]**

In addition, the apparatus according to the invention includes a separate blower for operating inflatable squeezing pads, and that between the blower and the inflatable squeezing pads is a changeover valve for connecting the inflatable squeezing pads either to the suction side or to the pressure side of the blower which is preferably constituted by a side channel blower. With regard to optimizing the functions of the apparatus according to the invention, the invention may advantageously be designed so that it includes a pressure regulating valve between the changeover valve and the inflatable squeezing pads. In order to achieve an additionally simple and reliable action, the apparatus according to the invention may be designed so that the pressure regulating valve includes an upper venting valve with a valve ball which is actuated by one or more upper lever arms with regulating slides. The apparatus according to the invention is suitably further designed so that the pressure regulating valve includes a cylinder or a bellows arrangement with a piston arranged to lift one or more of the lever arms for opening the venting valve.

### Brief Description Of The Drawings

**[p0007]**

The invention is explained more closely in the following in connection with the drawing, on which: FIG. 1 shows a perspective view of an embodiment of a lift head for an apparatus according to the invention; FIG. 2 shows a perspective view of the lift head shown in FIG. 1 , seen from another angle and with a partly open side; FIG. 3 shows a side view of a separate side channel blower with a pressure regulating valve for operating the inflatable pads in an apparatus according to the invention; FIG. 4 shows a side view, partly in section, of an embodiment of a pressure regulating valve for an apparatus according to the invention and shown with a setting corresponding to reduced pressure in the inflatable pads; FIG. 5 shows a side view, partly in section, of an embodiment shown in FIG. 4 of a pressure regulating valve for an apparatus according to the invention and shown with a setting corresponding to high pressure in the inflatable pads; FIG. 6 shows a side view, partly in section, of an embodiment shown in FIG. 4 of a pressure regulating valve for an apparatus according to the invention and shown with a setting corresponding to emptying the inflatable pads;

**[p0008]**

FIG. 7 shows a perspective view of an embodiment of a side channel blower with associated changeover valve and pressure regulating valve according to the invention for an apparatus according to the invention; FIG. 8 shows a perspective view of a pallet layer for illustrating a pallet layer with holes in the pallet layer which will require forced opening of the suction chambers of the suction sole; FIG. 9 shows a side view of an embodiment of arresting means for an apparatus according to the invention, shown in initial position; FIG. 10 shows a side view of arresting means, shown in FIG. 9 , for an apparatus according to the invention, shown with activated vacuum; FIG. 11 shows a side view of arresting means, shown in FIG. 9 , for an apparatus according to the invention, shown with activated vacuum and lowered frame; FIG. 12 shows a side view of arresting means, shown in FIG. 9 , for an apparatus according to the invention, shown with activated vacuum, lowered frame and locked pins;

**[p0009]**

FIG. 13 shows a side view of arresting means, shown in FIG. 9 , for an apparatus according to the invention, shown with activated vacuum, lowered frame and actively fixed pins; FIG. 14 shows a side view of a second embodiment of arresting means for an apparatus according to the invention, shown without activity; FIG. 15 shows a side view of arresting means, shown in FIG. 14 , for an apparatus according to the invention, shown with activated vacuum; FIG. 16 shows a side view of arresting means, shown in FIG. 14 , for an apparatus according to the invention, shown with activated vacuum and displaced arresting means that yield where valve balls close the valves; FIG. 17 shows a side view of arresting means, shown in FIG. 14 , for an apparatus according to the invention, shown with activated vacuum and with forced opening of valve balls; FIG. 18 shows a side view of arresting means, shown in FIG. 14 , for an apparatus according to the invention, shown without vacuum and release of possibly stuck valve balls;

**[p0010]**

FIG. 19 shows a side view of arresting means, shown in FIG. 14 , for an apparatus according to the invention, shown in initial position; FIG. 20 shows a partial perspective view of an embodiment for a common activation system for arresting means, shown in inactive position; FIG. 21 shows a partial perspective view, of the embodiment shown in FIG. 20 , of a common activation system for arresting means, shown in active position; FIG. 22 shows a plan view of an embodiment for a common rotary valve between suction face and air distribution chamber by an apparatus according to the invention, shown in open position; FIG. 23 shows a plan view of an embodiment shown in FIG. 22 , of a common rotary valve between suction face and air distribution chamber in an apparatus according to the invention, shown in closed position; FIG. 24 shows a perspective view of a common rotary valve shown in FIG. 22 , combined with an embodiment of a vacuum venting system, shown with open rotary valve and closed vacuum venting connection, respectively; and

**[p0011]**

FIG. 25 shows a perspective view of a common rotary valve shown in FIG. 23 , combined with an embodiment of a vacuum venting system, shown with closed rotary valve and open vacuum venting connection, respectively. Like reference numerals identify like parts throughout the drawings.

### Detailed Description Of The Invention

**[p0012]**

The lift head 2 shown in FIGS. 1-2 is adapted for destacking by layers of articles from a filled pallet that for example is taken from a rollerway. The lift head 2 includes a vacuum source in the form of a strong centrifugal blower 4 , the central suction opening of which being connected to a rectangular air distribution chamber which via a special rotary valve 6 ( FIGS. 22-25 ) is connected with a large number of suction chambers 8 that are open at the bottom and together form a suction face. The suction chambers 8 ( FIGS. 8 et. seq.) are connected at the top with the front of the rotary valve 6 via round valve openings with spherical edges or valve seats at the bottom that fit to the outer spherical surface of rather light, thin-walled, spherical valve bodies 10 ( FIG. 9 , et. seq.) which are enclosed in each their suction chamber 8 . Combined, the suction chambers 8 constitute a rectangular lower suction face 12 which in size is adapted to a standard pallet, e.g. an EU pallet or a UK pallet.

**[p0013]**

The lift head 2 includes, as with WO-00/64790 mentioned in the introduction, a special vertically adjustable, outer squeezing arrangement which at each of the outer sides of the suction face comprises a number of inflatable pads as well as an inner skirt and outer skirt. The squeezing arrangement is surrounded by an outer skirt or a casing arranged for absorbing the reaction pressure of the squeezing pads when these are inflated and exert an inwardly directed squeeze pressure on the outer sides of the pallet layer. Vertical adjustment and thereby adjusting the squeezing arrangement in height to the actual goods in the pallet layer occurs by means of a preferably motor driven winch and lift slings at each side of the lift head 2 . The squeezing pads are inflated via a pressure regulation valve 18 and a changeover valve 20 by means of air from a side channel blower 22 ( FIGS. 3-7 ) so that the pallet layer is clamped between the squeezing pads simultaneously with activating the suction face 12 . When the squeezing pressure is to be relieved subsequently, this occurs rapidly by shifting the changeover valve 20 so that the side channel blower 22 provides for rapid emptying of the squeezing pads.

**[p0014]**

The pressure regulating valve 18 includes an upper pressure regulating system 24 with two lever arms 26 that actuate a valve ball 28 in a ball valve with a valve seat 30 with a permanent downwards pressure which can be set by means of slides on the lever arms 26 , as the use of one of the lever arms 26 corresponds to low pressure in the squeezing pads. At high pressure in the squeezing pads, both lever arms 26 are used. In FIG. 5 , corresponding to high pressure in the inflatable pads 16 , the ball valve with the valve seat 30 is closed while the ball valve in FIG. 4 is open, corresponding to low pressure in the pads 16 . Opening the ball valve with the valve seat 30 in FIG. 4 by upward movement of the lever arms 26 is effected by means of a piston 34 and a bellows arrangement 36 , as a solenoid valve (not illustrated) is opened and feeds air to the bellows arrangement 36 , as shown by the arrow 35 . In FIG. 6 , corresponding to emptying the pads 16 , the ball valve with the valve seat 30 is closed while a lower ball valve 32 is open so that air is also sucked in from the surroundings with the object of preventing the side channel blower 22 from being blocked when the squeezing pads are without air.

**[p0015]**

If the actual pallet layer to be lifted by means of the lift head 2 is relatively light and fragile packing items that do not stand up to lateral pressure, and which do not require very great suction pressure either, the overall suction pressure may be lowered by reducing the rotational speed of the centrifugal blower 4 . Whether the valve balls 10 are closing or not is only determined by the combination of actual opening in the pallet layer and the rotational speed of the centrifugal blower 4 . In FIG. 8 is shown a pallet with an uppermost pallet layer 38 in which there is a hole or opening which is larger than 300 cm 2 . This implies that to achieve a secure and rapid depalletizing, it is necessary to apply forced action downwards on the valve balls 10 in order to avoid that the valve balls 10 close the associated suction chambers 8 due to false air in the pallet layer 38 . In FIGS. 9-13 is shown an embodiment of an arresting system according to the invention, where a common frame 40 opposite each valve opening in the suction chambers 8 is provided with individually loose pins 42 , which, however, can be locked in relation to the frame 40 .

**[p0016]**

In FIG. 9 , the suction face has been moved down upon a pallet layer 38 with openings so that the three left Suction chambers 8 are placed upon an object that block the suction chambers 8 at the bottom, while the three right suction chambers 8 are not blocked at the bottom by an object or an article. In FIG. 10 , the suction face is also moved down upon the pallet layer 38 and vacuum is activated. The situation is changed, as the valve balls 10 to the right are now closed. That is, the three left suction chambers 8 are communicating with the source of vacuum while the three right suction chambers 8 are now closed, because the suction face 12 is not in contact with objects or articles. In FIG. 11 , the suction face is also moved down upon the pallet layer 38 and vacuum is activated. That is, the situation is unchanged, as the three left suction chambers 8 are communicating with the source of vacuum while the three right suction chambers 8 are still closed, because the suction face 12 is not in contact with objects or articles. The frame 40 is now moved down so that three pins 42 to the left are in contact with the valve balls 10 in the open suction chambers 8 , while three pins 42 to the right are in contact with valve balls 10 in the blocked suction chambers 8 . That is, the pins 42 to the left are farther down compared with the other three pins 42 to the right.

**[p0017]**

In FIG. 12 the situation is almost unchanged as the pins 42 are here locked in the frame 40 only. In FIG. 13 , the situation is still unchanged as vacuum is activated. Where the suction face previously had contact to an article or an object, by plucking a film-enveloped product there will arise a certain airflow due to forced opening by means of the pins 42 , where the airflow would normally make the valve balls close, but due to the forced opening in this area the suction face will have contact to the article or the object anyway. In FIGS. 14-19 is shown a second embodiment of an arresting system according to the invention, where a common frame 44 opposite each valve opening in the suction chambers 8 is provided with individually rubber suspended arresting bodies 46 . In FIG. 14 , the common frame 44 is in its initial position. No activity, that is no vacuum is activated. Vacuum is active in FIG. 15 . Valve balls 10 close where there is airflow, namely at the two middle suction chambers 8 , while the outermost suction chambers are active because the suction chambers 8 are blocked at the bottom by abutting against article or object.

**[p0018]**

In FIG. 16 , vacuum is still active, but here the frame 44 is displaced to the right so that the two middle arresting bodies 46 hit the valve balls 10 and are deflected to the left, as the arresting bodies 46 are rubber suspended at 48 . Vacuum is active in FIG. 17 . Where the suction face previously had contact to the product, now by plucking a film enveloped product there will arise a certain airflow which normally would make the valve balls close, but due to the partitioned suction face there is now achieved a forced opening of the area of the suction face previously having contact with the product. In FIG. 18 is shown how the frame 44 after finished plucking is advanced further and presses possible stuck valve balls 10 free of the valve seat, and in FIG. 19 we are again back to the initial position. In FIGS. 20-21 is shown how a common arresting system for the entire suction face can be operated by an electric gear motor 50 which via a number of eccentric discs 52 and turning arms 54 may lift and lower a large number of arresting bodies 56 opposite each suction chamber 8 . In FIG. 20 , the arresting bodies 56 are lifted off the suction chambers 8 , while the arresting bodies 56 in FIG. 21 are lowered into each their valve opening.

**[p0019]**

The above-mentioned rotary valve 6 , which is shown in FIGS. 22-23 , has a circle of mutually separate valve openings 60 which are formed in the lower wall of the air distribution chamber, and a valve plate 62 arranged rotatably in relation thereto with a corresponding circle of valve openings 64 . The valve plate 62 is arranged to be turned for opening and closing the rotary valve 6 by means of arms 66 , an eccentric 68 and an electric motor. In FIGS. 24 and 25 is additionally shown that the rotary valve 6 interacts with a vacuum valve 72 which is disposed in open air and spaced apart from the rotary valve 6 , namely at the end of a vertical pipe 74 , however interacting with the rotary valve 6 via an actuation plate 76 and an actuation rod 78 which is connected with the vacuum valve 72 . FIG. 24 shows the rotary valve 6 in open condition and the vacuum valve 72 in closed condition, while FIG. 25 shows the rotary valve 6 in closed condition and the vacuum valve 72 in open condition.

**[p0020]**

Alternatively, the arresting means may be comprised of a common plate or frame on which opposite the individual valve seats for the suction chambers 8 there are mounted on individually resilient fingers which by means of the common plate or frame may be displaced across the valve openings in such a way that the resilient fingers, where the valve balls 10 are in contact with the valve seat already and shut off the suction chambers 8 , will yield to the valve balls 10 and be moved down along the top side of the valve balls 10 without pressing the latter downwards, while the resilient fingers—where the valve balls 10 are not in contact against the valve seat—will be moved in under the opposite side of the valve seat and prevent the valve balls 10 from subsequently shutting off the suction chambers 8 . The advantage of this alternative arrangement is that there may be attained greater distance between the valve balls 10 and their associated valve seats. That is there may be attained greater airflow by arrested valve balls 10 .

**[p0021]**

Finally, it is to be mentioned that the suction face 12 may advantageously be built up from individual suction chambers of flexible material, for example, in the form of loose suction chambers 8 moulded in plastic. Hereby, a significant reduction in maintenance costs may be achieved. To this is added that if the suction chambers 8 are made of flexible material with lower inwards projecting retainer members for the valve balls 10 , it will be much easier to replace damaged valve balls with new valve balls, which in that case may just be pressed up into the suction chamber from below through the said inwards projecting flexible retainer members for the valve balls 10 .

## Figure captions

- **Figure 1:** FIG. 1 shows a perspective view of an embodiment of a lift head for an apparatus according to the invention;
- **Figure 2:** FIG. 2 shows a perspective view of the lift head shown in FIG. 1 , seen from another angle and with a partly open side;
- **Figure 3:** FIG. 3 shows a side view of a separate side channel blower with a pressure regulating valve for operating the inflatable pads in an apparatus according to the invention;
- **Figure 4:** FIG. 4 shows a side view, partly in section, of an embodiment of a pressure regulating valve for an apparatus according to the invention and shown with a setting corresponding to reduced pressure in the inflatable pads;
- **Figure 5:** FIG. 5 shows a side view, partly in section, of an embodiment shown in FIG. 4 of a pressure regulating valve for an apparatus according to the invention and shown with a setting corresponding to high pressure in the inflatable pads;
- **Figure 6:** FIG. 6 shows a side view, partly in section, of an embodiment shown in FIG. 4 of a pressure regulating valve for an apparatus according to the invention and shown with a setting corresponding to emptying the inflatable pads;
- **Figure 7:** FIG. 7 shows a perspective view of an embodiment of a side channel blower with associated changeover valve and pressure regulating valve according to the invention for an apparatus according to the invention;
- **Figure 8:** FIG. 8 shows a perspective view of a pallet layer for illustrating a pallet layer with holes in the pallet layer which will require forced opening of the suction chambers of the suction sole;
- **Figure 9:** FIG. 9 shows a side view of an embodiment of arresting means for an apparatus according to the invention, shown in initial position;
- **Figure 10:** FIG. 10 shows a side view of arresting means, shown in FIG. 9 , for an apparatus according to the invention, shown with activated vacuum;
- **Figure 11:** FIG. 11 shows a side view of arresting means, shown in FIG. 9 , for an apparatus according to the invention, shown with activated vacuum and lowered frame;
- **Figure 12:** FIG. 12 shows a side view of arresting means, shown in FIG. 9 , for an apparatus according to the invention, shown with activated vacuum, lowered frame and locked pins;
- **Figure 13:** FIG. 13 shows a side view of arresting means, shown in FIG. 9 , for an apparatus according to the invention, shown with activated vacuum, lowered frame and actively fixed pins;
- **Figure 14:** FIG. 14 shows a side view of a second embodiment of arresting means for an apparatus according to the invention, shown without activity;
- **Figure 15:** FIG. 15 shows a side view of arresting means, shown in FIG. 14 , for an apparatus according to the invention, shown with activated vacuum;
- **Figure 16:** FIG. 16 shows a side view of arresting means, shown in FIG. 14 , for an apparatus according to the invention, shown with activated vacuum and displaced arresting means that yield where valve balls close the valves;
- **Figure 17:** FIG. 17 shows a side view of arresting means, shown in FIG. 14 , for an apparatus according to the invention, shown with activated vacuum and with forced opening of valve balls;
- **Figure 18:** FIG. 18 shows a side view of arresting means, shown in FIG. 14 , for an apparatus according to the invention, shown without vacuum and release of possibly stuck valve balls;
- **Figure 19:** FIG. 19 shows a side view of arresting means, shown in FIG. 14 , for an apparatus according to the invention, shown in initial position;
- **Figure 20:** FIG. 20 shows a partial perspective view of an embodiment for a common activation system for arresting means, shown in inactive position;
- **Figure 21:** FIG. 21 shows a partial perspective view, of the embodiment shown in FIG. 20 , of a common activation system for arresting means, shown in active position;
- **Figure 22:** FIG. 22 shows a plan view of an embodiment for a common rotary valve between suction face and air distribution chamber by an apparatus according to the invention, shown in open position;
- **Figure 23:** FIG. 23 shows a plan view of an embodiment shown in FIG. 22 , of a common rotary valve between suction face and air distribution chamber in an apparatus according to the invention, shown in closed position;
- **Figure 24:** FIG. 24 shows a perspective view of a common rotary valve shown in FIG. 22 , combined with an embodiment of a vacuum venting system, shown with open rotary valve and closed vacuum venting connection, respectively; and
- **Figure 25:** FIG. 25 shows a perspective view of a common rotary valve shown in FIG. 23 , combined with an embodiment of a vacuum venting system, shown with closed rotary valve and open vacuum venting connection, respectively.
- **Figure 6:** In FIG. 6 , corresponding to emptying the pads 16 , the ball valve with the valve seat 30 is closed while a lower ball valve 32 is open so that air is also sucked in from the surroundings with the object of preventing the side channel blower 22 from being blocked when the squeezing pads are without air.
- **Figure 8:** In FIG. 8 is shown a pallet with an uppermost pallet layer 38 in which there is a hole or opening which is larger than 300 cm 2 . This implies that to achieve a secure and rapid depalletizing, it is necessary to apply forced action downwards on the valve balls 10 in order to avoid that the valve balls 10 close the associated suction chambers 8 due to false air in the pallet layer 38 .
- **Figure 9:** In FIGS. 9-13 is shown an embodiment of an arresting system according to the invention, where a common frame 40 opposite each valve opening in the suction chambers 8 is provided with individually loose pins 42 , which, however, can be locked in relation to the frame 40 .
- **Figure 9:** In FIG. 9 , the suction face has been moved down upon a pallet layer 38 with openings so that the three left Suction chambers 8 are placed upon an object that block the suction chambers 8 at the bottom, while the three right suction chambers 8 are not blocked at the bottom by an object or an article.
- **Figure 10:** In FIG. 10 , the suction face is also moved down upon the pallet layer 38 and vacuum is activated. The situation is changed, as the valve balls 10 to the right are now closed. That is, the three left suction chambers 8 are communicating with the source of vacuum while the three right suction chambers 8 are now closed, because the suction face 12 is not in contact with objects or articles.
- **Figure 12:** In FIG. 12 the situation is almost unchanged as the pins 42 are here locked in the frame 40 only.
- **Figure 14:** In FIGS. 14-19 is shown a second embodiment of an arresting system according to the invention, where a common frame 44 opposite each valve opening in the suction chambers 8 is provided with individually rubber suspended arresting bodies 46 .
- **Figure 14:** In FIG. 14 , the common frame 44 is in its initial position. No activity, that is no vacuum is activated.
- **Figure 15:** Vacuum is active in FIG. 15 . Valve balls 10 close where there is airflow, namely at the two middle suction chambers 8 , while the outermost suction chambers are active because the suction chambers 8 are blocked at the bottom by abutting against article or object.
- **Figure 16:** In FIG. 16 , vacuum is still active, but here the frame 44 is displaced to the right so that the two middle arresting bodies 46 hit the valve balls 10 and are deflected to the left, as the arresting bodies 46 are rubber suspended at 48 .
- **Figure 17:** Vacuum is active in FIG. 17 . Where the suction face previously had contact to the product, now by plucking a film enveloped product there will arise a certain airflow which normally would make the valve balls close, but due to the partitioned suction face there is now achieved a forced opening of the area of the suction face previously having contact with the product.
- **Figure 18:** In FIG. 18 is shown how the frame 44 after finished plucking is advanced further and presses possible stuck valve balls 10 free of the valve seat, and in FIG. 19 we are again back to the initial position.

## Classifications

- B65G47/91
- B65G47/91
- B65G47/91
- B65G47/91
- B65G47/917
- B65G47/917
- B65G47/917
- B65G59/04
- B65G59/04
- B65G59/04

## Cited patent documents

- [US-3229953-A](https://patents.google.com/patent/US3229953A/en) — PRS
- [US-3307818-A](https://patents.google.com/patent/US3307818A/en) — PRS
- [US-3387718-A](https://patents.google.com/patent/US3387718A/en) — PRS
- [US-3406938-A](https://patents.google.com/patent/US3406938A/en) — PRS
- [US-3523707-A](https://patents.google.com/patent/US3523707A/en) — PRS
- [US-4185814-A](https://patents.google.com/patent/US4185814A/en) — PRS
- [US-5207467-A](https://patents.google.com/patent/US5207467A/en) — PRS
- [US-5297830-A](https://patents.google.com/patent/US5297830A/en) — PRS
- [US-5813713-A](https://patents.google.com/patent/US5813713A/en) — PRS
- [US-6517050-B1](https://patents.google.com/patent/US6517050B1/en) — PRS
- [US-6802688-B1](https://patents.google.com/patent/US6802688B1/en) — PRS

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
