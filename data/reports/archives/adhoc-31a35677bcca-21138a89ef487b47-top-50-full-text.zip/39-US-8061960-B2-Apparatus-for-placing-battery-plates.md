# 39. Apparatus for placing battery plates

- **Archive rank:** 39 of 50
- **Publication:** [US-8061960-B2](https://patents.google.com/patent/US8061960B2/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/038093423/publication/US8061960B2?q=pn%3DUS8061960B2)
- **Publication date:** 2011-11-22
- **Filing date:** 2007-03-09
- **Earliest priority:** 2006-03-10
- **Family:** 38093423
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** BARGE CHRISTOPHER S; HOPWOOD ROBERT T; TBS ENG LTD
- **Inventors:** BARGE CHRISTOPHER S; HOPWOOD ROBERT T

## Abstract

This invention relates to apparatus for placing battery plates in a line from a stack of plates including an elevator for receiving a stack of plates and sequentially elevating the stack to maintain, in use, the uppermost plate in the stack in a datum region lying between two parallel generally horizontal planes and a plurality of vacuum heads arranged in a closed loop for sequentially passing over the elevator with a fixed gap from the upper plane of the datum range for picking up the uppermost plate and for subsequently releasing the plate at a release position.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-8061960-B2/000.png)

![Sketch 1 for US-8061960-B2](https://nimo.iptorch.com/refdrawing/US-8061960-B2/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/US-8061960-B2/001.png)

![Sketch 2 for US-8061960-B2](https://nimo.iptorch.com/refdrawing/US-8061960-B2/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/US-8061960-B2/002.png)

![Sketch 3 for US-8061960-B2](https://nimo.iptorch.com/refdrawing/US-8061960-B2/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/US-8061960-B2/003.png)

![Sketch 4 for US-8061960-B2](https://nimo.iptorch.com/refdrawing/US-8061960-B2/003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/US-8061960-B2/004.png)

![Sketch 5 for US-8061960-B2](https://nimo.iptorch.com/refdrawing/US-8061960-B2/004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/US-8061960-B2/005.png)

![Sketch 6 for US-8061960-B2](https://nimo.iptorch.com/refdrawing/US-8061960-B2/005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/US-8061960-B2/006.png)

![Sketch 7 for US-8061960-B2](https://nimo.iptorch.com/refdrawing/US-8061960-B2/006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/US-8061960-B2/007.png)

![Sketch 8 for US-8061960-B2](https://nimo.iptorch.com/refdrawing/US-8061960-B2/007.png)

## Claims

### Claim 1 (independent)

Apparatus for placing battery plates in a line from a stack of plates including an elevator for receiving a stack of plates and sequentially elevating the stack to maintain, in use, the uppermost plate in the stack in a datum region lying between two parallel generally horizontal planes and a plurality of vacuum heads arranged in a closed loop for sequentially passing over the elevator with a fixed gap from the upper plane of the datum range for picking up the uppermost plate and for subsequently releasing the plate at a release position, wherein the elevator is one of a plurality of elevators moveable between an inactive position and an active position, and further comprising at least one buffer elevator for temporarily halting travel of a stack along an input conveyor.

### Claim 2

Apparatus as claimed in claim 1 further including a carrier rotatable about a generally vertical axis and wherein the vacuum heads are mounted on the carrier and spaced around the axis.

### Claim 3

Apparatus as claimed in claim 2 further including an evacuable plenum and wherein each vacuum head is connectable to the plenum by a respective valve.

### Claim 4

Apparatus as claimed in claim 3 further including a control for opening a valve, associated with a head, as the head approaches the elevator and for closing the valve when the head is the release position.

### Claim 5

Apparatus as claimed in claim 1 including an output conveyor extending beneath the release position.

### Claim 6

Apparatus as claimed in claim 1 including an input conveyor for delivering stacks of plates to the elevator.

### Claim 7

Apparatus as claimed in claim 1 wherein only one elevator can be in an active position at any one time.

### Claim 8

Apparatus as claimed in claim 2 wherein there are two elevators moveable between an inactive position and an active position, the two elevators arranged diametrically relative to the axis and the apparatus including an input conveyor extending along the diameter of the carrier.

### Claim 9

Apparatus as claimed in claim 1 wherein two elevators can be active during an overlap period.

### Claim 10

Apparatus as claimed in claim 9 wherein there are two input elevators arranged diametrically relative to a vertical axis and the apparatus including an input conveyor extending along the axis.

### Claim 11

Apparatus as claimed in claim 1 further including a turntable for rotating a stack.

### Claim 12

Apparatus as claimed in claim 11 wherein the turntable is an elevator.

### Claim 13

Apparatus as claimed in claim 9 wherein the one conveyor is the most downstream conveyor.

### Claim 14 (independent)

Apparatus for placing battery plates in a line from a stack of plates including an elevator for receiving a stack of plates and sequentially elevating the stack to maintain, in use, the uppermost plate in the stack in a datum region lying between two parallel generally horizontal planes, a plurality of vacuum heads arranged in a closed loop for sequentially passing over the elevator with a fixed gap from the upper plane of the datum range for picking up the uppermost plate and for subsequently releasing the plate at a release position, and a turntable for rotating a stack.

### Claim 15

Apparatus as claimed in claim 14 further including a carrier rotatable about a generally vertical axis and wherein the vacuum heads are mounted on the carrier and spaced around the axis.

### Claim 16

Apparatus as claimed in claim 15 further including an evacuable plenum and wherein each vacuum head is connectable to the plenum by a respective valve.

### Claim 17

Apparatus as claimed in claim 16 further including a control for opening a valve, associated with a head, as the head approaches the elevator and for closing the valve when the head is the release position.

### Claim 18

Apparatus as claimed in claim 14 including an output conveyor extending beneath the release position.

### Claim 19

Apparatus as claimed in claim 14 including an input conveyor for delivering stacks of plates to the elevator.

### Claim 20

Apparatus as claimed in claim 14 including a plurality of elevators movable between an inactive position and an active position.

### Claim 21

Apparatus as claimed in claim 20 wherein only one elevator can be in an active position at any one time.

### Claim 22

Apparatus as claimed in claim 15 wherein there are two elevators moveable between an inactive position and an active position, the two elevators arranged diametrically relative to the axis and the apparatus including an input conveyor extending along the diameter of the carrier.

### Claim 23

Apparatus as claimed in claim 20 wherein two elevators can be active during an overlap period.

### Claim 24

Apparatus as claimed in claim 23 wherein there are two input elevators arranged diametrically relative to a vertical axis and the apparatus including an input conveyor extending along the axis.

### Claim 25

Apparatus as claimed in claim 20 wherein including at least one buffer elevator for temporarily halting travel of a stack along an input conveyor.

### Claim 26

Apparatus as claimed in claim 14 wherein the turntable is an elevator.

### Claim 27

Apparatus as claimed in claim 23 wherein the one conveyor is the most downstream conveyor.

## Full description

**[p0001]**

This invention relates to apparatus for placing battery plates in a line from one or more stacks of plates. It is well known, during the manufacture of batteries containing battery plates to have to take battery plates from stacks, formed when the batteries are moulded, and to lay them into a line for subsequent handling, when they are formed into groups with separators and properly orientated terminals. In recent years many parts of the assembly line have been speeded up and there is a need for apparatus which can perform this function at high speed. With this in mind, arrangements such as are illustrated in U.S. Pat. Nos. 4,784,380 and 6,971,838 have been developed where multiple in line heads pick up battery plates from respective stacks and then deliver them onto a conveyor. By mounting these heads in line on a rocking or translatable carrier five or so plates can be deposited simultaneously, in line, on a conveyor. These systems have been found to have speed limitations, which do not enable them to meet the requirements of a modern line.

**[p0002]**

A further problem, which is recognised in U.S. Pat. No. 6,971,838, arises from the porous nature of many plates which now need to be handled and the need to ensure that only one plate is being picked up at a time. From one aspect the invention consists in apparatus for placing battery plates in a line from a stack of plates, including an elevator for receiving a stack of plates and sequentially elevating the stack to maintain, in use, the uppermost plate in the stack in a datum range lying between two parallel generally horizontal planes and a plurality of vacuum heads for sequentially passing over the elevator with a fixed gap from the upper plane of the datum range for picking up the uppermost plate and for subsequently releasing the plate at a release position. The applicants have realised that, surprisingly, they can create apparatus capable of much higher speeds from a single stack, rather than taking the plates from a multiplicity of in line stacks. This is because with the vacuum heads arranged in a loop there is not the same requirement for acceleration and deceleration as occurs in the earlier design. Further, by having an elevator which places the uppermost plate in a predetermined datum region, the geometry of the relationship between the position of the plate and the vacuum head can be particularly simply designed, with the result that no contact is required between the plate and the vacuum head. This prevents damage to the plates which can occur if a plate is drawn across the top of the one beneath it as has been seen with other plate handling systems that wipe

**[p0002]**

the plates from the stack.

**[p0003]**

In a preferred embodiment the apparatus further includes a carrier rotatable about a generally vertical axis, in which case the vacuum heads may be mounted on the carrier and spaced around the axis. There may be an evacuable plenum, which may also be mounted on the carrier, and in this case each vacuum head may be connectable to the plenum by a respective valve. A control may be provided for opening a valve associated with a head as the head approaches the elevator and for closing the valve when the head is in the release position. Conveniently an output conveyor extends beneath the release position for receiving the release plates. An input conveyor for delivering stacks of plates to the elevator may also be provided. There may be a plurality of elevators moveable between an inactive position where a stack can be received and an active position. Conveniently there can be two elevators arranged diametrically relative to the axis, in which case the apparatus includes an input conveyor extending along the diameter. The apparatus may further include a turntable for rotating a stack before it is fed to one of the conveyors and preferably that one conveyor is the most downstream conveyor. Conveniently an elevator can perform the role of a turntable.

**[p0004]**

This turntable enables the stacks to be orientated in an appropriate position for their elevator so that, when released, the plates in the line have a common orientation. From another aspect the invention consists in apparatus for placing battery plates in a line from stacks of plates including a plurality of vacuum heads for picking up, in a pick-up position a top most plate from a stack and subsequently releasing it at a release position and a carrier for carrying the heads and moving them between the pick-up and release positions, wherein in the pick-up position there is a space, in use, between the uppermost plate and the associated vacuum head, whereby the plates moves to the head. Although the invention has been defined above it is to be understood that it includes any inventive combination of the features set out above or in the following description. The invention may be performed in various ways and a specific embodiment will now be described, by way of example with reference to the accompanying drawings in which:

**[p0005]**

FIG. 1 is a plan view of apparatus for placing battery plates in a line from a stack of plates: FIG. 2 is a view of the apparatus of FIG. 1 on the Arrow A; and FIG. 3 is an end view of the apparatus in the direction B; FIG. 4 is a schematic view from above of the carrier of the apparatus of FIG. 1 ; FIG. 5( a ) to ( o ) indicate a supply sequence to the carrier of FIG. 4 and; FIGS. 6( a ) and ( b ) are respective side and front views of an elevator location. Referring to FIGS. 1 to 3 , apparatus generally indicated at 10 , is provided for taking plates 11 from a stack 12 and depositing them sequentially in line on a conveyor 13 . The apparatus 10 includes a carrier 14 rotatable about a vertically extending axis 15 , which carries a number of vacuum heads 16 , which are spaced circumferentially around the carrier 14 . The carrier also carries a box 17 that defines an evacuable plenum 18 , which is on the one hand connected to a vacuum source (not shown) and on the other hand communicates with respective heads 16 via tubes 19 that are open and closed by respective butterfly valves, one of which is shown at 20 . The valves 20 can be moved between open and closed positions, for example by the ram 21 and toggle actuator 22 . A motor 24 , is provided for rotating the carrier on a shaft 23 in the direction of the Arrow C by means of a pulley 24 a and belt 25 .

**[p0006]**

As can be seen in FIG. 3 the stack 12 is mounted on an elevator 26 , which can be raised and lowered by means of a rack and pinion arrangement indicated at 27 . In its simplest form of operation, the carrier 14 is rotated and as a particular head 16 approaches the elevator 26 , its butterfly valve 20 is opened connecting the head 16 to the source of vacuum by means of the plenum 18 . As the “on” head 16 passes over the uppermost plate 11 in the stack it lifts the plate onto the vacuum head 16 whereupon it is carried, from this pick-up position over the elevator 26 to a release position over the conveyor 13 . At that point the butterfly valve 20 is closed, removing the vacuum and releasing the plate 11 to drop onto the conveyor 13 . It is preferred, particularly when porous plates have been handled, that the mouth 28 is relatively large and the vacuum source and plenum are arranged so as to encourage fairly high air flow, but low vacuum. This is because as ingressing air sweeps across the surface of the uppermost plate it tends to cause an aerodynamic lift separating the uppermost plate from the stack, and enabling it to be captured by a low vacuum and reducing the chance of more than one plate 11 being picked up at once.

**[p0007]**

Because the carrier 14 is constantly rotating, without any need for deceleration, it can be rotated at high speeds, with the result that, even though only one plate is being picked up at a time, plates can be delivered onto the conveyor at rates at least up to 200 plates per minute. It will be understood that in order to benefit significantly from such high delivery rates, it is desirable to have a system for replenishing the stack as quickly as possible. The applicants have arranged for this conveniently by providing a second elevator 29 , which is located diametrically opposite the first elevator 12 , so that whilst one elevator is in an active position from which plates can be picked up, the other elevator can be in an inactive position in which it can receive a fresh stack of plates. Because the elevators 26 and 29 are opposite each other, it is necessary to ensure that the stacks provided are orientated so that the stacks provided to one elevator are 180° rotated as compared with those provide to the other elevator. This can be achieved in a number of ways one of which is illustrated in the drawings. Here a conveyor system generally indicated at 31 brings stacks 12 sequentially to a turntable 32 that can be elevated through the plane of the conveyor system 31 to temporarily retain a stack 12 and, if necessary rotate it.

**[p0008]**

If elevator 12 is in the active position and plates are being removed from it, then elevator 30 should be in its inactive lowered position beneath the plane of the conveyor system 31 . The turntable 32 will then rotate through 180° a first stack that it has received, lower those back onto the conveyor system 31 so that they are fed into a buffer position 33 , beneath the shaft 23 . As it will be noted that the conveyor system 31 is formed by two aligned conveyors 34 and 35 . It will be understood that the rotated stack 12 a can be retained in the buffer position by pausing the conveyor 34 . The turntable 32 can then either stay lowered and simply allow the next stack to pass onto the elevator 30 , which can capture the stack by passing up through the plane of the conveyor system 31 or it can retain it temporarily so that it can release the stack with position timing to meet the elevator 32 as it rises. When the elevator 26 has been emptied, the elevator 30 then rises up into its active position and plates are picked up from there so that there is no gap in the provision of the plates. It may be desirable to adjust the rotational speed of the carrier at least momentarily, because the elevator 30 is a shorter distance from the conveyor 13 than the elevator 12 and it will usually be desirable for there to be equal spacing between the plates 11 . A similar effect could be achieved by varying the speed of the conveyor 13 .

**[p0009]**

A control 36 is provided for controlling the motor, the valves and the various conveyors and elevators in accordance with the operational protocol described above. A means of controlling such elements would be well understood by one skilled in the art. Variations on this design are described with reference FIGS. 4 to 6 . FIGS. 4 and 5 show an arrangement, which deals with a problem that can arise using the previously described apparatus. As proposed in that apparatus plates are initially picked up by the nozzle 16 which is in pick up position A and when the associated stack 12 is used up the pick up or nozzle at 16 at position B begins to lift plates 11 from its associated stack 12 . It has been found that if one waits until the last plate is lifted from elevator 26 before lifting elevator 29 , then a space tends to occur between plates laid on out feed conveyor 13 because the nozzle instantaneously lying between A and B, which has passed over an empty stack, arrives at B before a plate is ready to pick up.

**[p0010]**

FIGS. 5( a ) to ( o ) show a sequence of plate feeding, which overcomes this problem and introduces a slightly different approach to the alignment of lugs issue. Looking at FIG. 5( a ) first, it will be noted that pick up positions A and B have respective sensors 37 , 38 for detecting the presence or absence of a plate 11 in the datum region from which a plate is picked up. The sensors 37 , 38 , which are typically lasers that can be reflected in the absence of a plate in the datum region, are connected to the control 36 and in particular are used to control respective elevators 26 and 29 . A further, double sized, elevator 40 is provided upstream of the elevator 29 in association with the feed conveyor 31 . Thus in FIG. 5( a ) stacks 1 and 2 have been moved onto the elevator 40 by the in feed conveyor 31 and can be retained in that position by the elevator 40 lifting them clear of the conveyor 31 . In FIG. 5( b ) the stacks have been released by the conveyor 40 and moved downstream. Stack 2 lies above the elevator 29 and can be captured in that position by the elevator 29 lifting it clear of the conveyor bed. This can be seen in FIG. 5( c ). The stack 1 has now reached elevator 26 , which in this embodiment is configured as a turntable. Elevator 26 rotates the stack so that the lugs on the plates 11 will be suitably orientated and in the meantime further stacks 3 and 4 are delivered onto the elevator 40 . In FIG. 5( d ) elevator 26 lifts stack 1 so that plates are removed one by one, as previously described from stack 1 , and released onto the conveyor 13 . The sensor 37 d

**[p0010]**

etects the presence or absence of the top plate and controls the advancement of the elevator 26 . In the meantime stack 2 has been released by elevator 29 to move into a buffer position intermediate elevators 26 and 29 and stack 3 has moved to a position in which it can be captured by the elevator 29 .

**[p0011]**

It can be seen in FIG. 5( e ) that the majority of the plates have now been removed from stack 1 , but at this time stack 3 is elevated so that plates can be taken from it by a pick up in position B. In this way that stack is ready for having plates removed before stack 1 is finished, ie. both elevators are in an active position for an overlap period. By suitably controlling the valves on the pick up heads or nozzles 16 , a continuous stream of plates can be achieved. In Figure (f) stack 3 is now producing all of the plates to be passed on to the conveyor 13 , whilst empty elevator 26 descends and returns to its original rotational orientation. As can be seen in FIG. 5( i ) stack 2 then feeds onto elevator 26 and is rotated at (j). In FIG. 5( k ) stack 2 is now elevated by elevator 26 , because it is detected that stack 3 has been substantially used up. At (l) stack 2 has taken over as the feed stack and at (m) stacks 4 and 5 are being used to replenish. By FIG. 5( o ) the apparatus has sequenced so that it corresponds with FIG. 5( e ).

**[p0012]**

It will thus be seen that this approach handles both the issue of lug orientation and providing a continuous uninterrupted supply of plates to the conveyor 13 . FIG. 6 shows an additional improvement which can be made. This is the provision of a stop plate 41 which can retain the stack 12 against any wiping drag, as the top plate 11 is removed. A vertical partial notch 42 is provided to allow the sensor to detect the presence or absence of plates. Finally, it has been found, from the control point of view, that it is particularly efficacious to control the valves via one or more server motors. It will be appreciated that the design could be varied in a number of other ways while still achieving the broad benefits of the invention. Thus the vacuum heads could be mounted on a chain conveyor or the like and do not necessarily have to follow a circular path. However, the use of a circular carrier enables the applicant to achieve a particularly small foot-point compared, for example, with the in-line machines mentioned in the acknowledged prior art. The elevators could be individually fed laterally and the turntable could be in the buffer position, rather than the position in which it is described. The invention thus covers any such variations or others clear to a person skilled in the art which fall within the scope of the attached claims.

## Figure captions

- **Figure 1:** FIG. 1 is a plan view of apparatus for placing battery plates in a line from a stack of plates:
- **Figure 2:** FIG. 2 is a view of the apparatus of FIG. 1 on the Arrow A; and
- **Figure 3:** FIG. 3 is an end view of the apparatus in the direction B;
- **Figure 4:** FIG. 4 is a schematic view from above of the carrier of the apparatus of FIG. 1 ;
- **Figure 5:** FIG. 5( a ) to ( o ) indicate a supply sequence to the carrier of FIG. 4 and;
- **Figure 6:** FIGS. 6( a ) and ( b ) are respective side and front views of an elevator location.
- **Figure 3:** As can be seen in FIG. 3 the stack 12 is mounted on an elevator 26 , which can be raised and lowered by means of a rack and pinion arrangement indicated at 27 .
- **Figure 6:** FIG. 6 shows an additional improvement which can be made. This is the provision of a stop plate 41 which can retain the stack 12 against any wiping drag, as the top plate 11 is removed. A vertical partial notch 42 is provided to allow the sensor to detect the presence or absence of plates.

## Classifications

- B65G59/04
- B65G59/04
- B65G59/04
- B65G47/84
- B65G47/848
- B65G47/848
- B65G47/91
- B65G59/00
- B65H3/08
- Y02E60/10
- Y02P70/50

## Cited patent documents

- [DE-1923441-A1](https://patents.google.com/patent/DE1923441A1/en) — APP
- [DE-3806419-A1](https://patents.google.com/patent/DE3806419A1/en) — APP
- [EP-0018057-A2](https://patents.google.com/patent/EP0018057A2/en) — APP
- [EP-0860259-A2](https://patents.google.com/patent/EP0860259A2/en) — SEA
- [EP-0950624-A2](https://patents.google.com/patent/EP0950624A2/en) — APP
- [EP-1031523-A2](https://patents.google.com/patent/EP1031523A2/en) — APP
- [EP-1295823-A1](https://patents.google.com/patent/EP1295823A1/en) — APP
- [EP-1608574-A1](https://patents.google.com/patent/EP1608574A1/en) — APP
- [FR-1546148-A](https://patents.google.com/patent/FR1546148A/en) — APP
- [GB-2092117-A](https://patents.google.com/patent/GB2092117A/en) — APP,SEA
- [US-2003012636-A1](https://patents.google.com/patent/US20030012636A1/en) — SEA
- [US-2004081544-A1](https://patents.google.com/patent/US20040081544A1/en) — SEA
- [US-2008253867-A1](https://patents.google.com/patent/US20080253867A1/en) — APP
- [US-2652161-A](https://patents.google.com/patent/US2652161A/en) — SEA
- [US-2897950-A](https://patents.google.com/patent/US2897950A/en) — SEA
- [US-3198348-A](https://patents.google.com/patent/US3198348A/en) — SEA
- [US-3305233-A](https://patents.google.com/patent/US3305233A/en) — APP
- [US-3334891-A](https://patents.google.com/patent/US3334891A/en) — SEA
- [US-3463483-A](https://patents.google.com/patent/US3463483A/en) — APP
- [US-3476241-A](https://patents.google.com/patent/US3476241A/en) — APP
- [US-3480160-A](https://patents.google.com/patent/US3480160A/en) — APP
- [US-3830489-A](https://patents.google.com/patent/US3830489A/en) — APP
- [US-3858709-A](https://patents.google.com/patent/US3858709A/en) — SEA
- [US-4024963-A](https://patents.google.com/patent/US4024963A/en) — SEA
- [US-4067458-A](https://patents.google.com/patent/US4067458A/en) — APP
- [US-4211398-A](https://patents.google.com/patent/US4211398A/en) — APP
- [US-4281452-A](https://patents.google.com/patent/US4281452A/en) — SEA
- [US-4381596-A](https://patents.google.com/patent/US4381596A/en) — SEA
- [US-4412738-A](https://patents.google.com/patent/US4412738A/en) — APP
- [US-4635921-A](https://patents.google.com/patent/US4635921A/en) — APP
- [US-4784380-A](https://patents.google.com/patent/US4784380A/en) — APP
- [US-4869489-A](https://patents.google.com/patent/US4869489A/en) — SEA
- [US-4871348-A](https://patents.google.com/patent/US4871348A/en) — APP
- [US-4997178-A](https://patents.google.com/patent/US4997178A/en) — APP
- [US-5470195-A](https://patents.google.com/patent/US5470195A/en) — SEA
- [US-5671920-A](https://patents.google.com/patent/US5671920A/en) — APP
- [US-5899341-A](https://patents.google.com/patent/US5899341A/en) — APP
- [US-6030171-A](https://patents.google.com/patent/US6030171A/en) — APP
- [US-6419217-B1](https://patents.google.com/patent/US6419217B1/en) — APP
- [US-6558109-B2](https://patents.google.com/patent/US6558109B2/en) — SEA
- [US-6736589-B2](https://patents.google.com/patent/US6736589B2/en) — SEA
- [US-6971838-B2](https://patents.google.com/patent/US6971838B2/en) — APP
- [US-7007940-B2](https://patents.google.com/patent/US7007940B2/en) — APP
- [US-7007942-B1](https://patents.google.com/patent/US7007942B1/en) — APP

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
