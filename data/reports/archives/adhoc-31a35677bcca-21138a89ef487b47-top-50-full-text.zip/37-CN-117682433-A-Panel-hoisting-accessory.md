# 37. Panel hoisting accessory

- **Archive rank:** 37 of 50
- **Publication:** [CN-117682433-A](https://patents.google.com/patent/CN117682433A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/090125593/publication/CN117682433A?q=pn%3DCN117682433A)
- **Publication date:** 2024-03-12
- **Filing date:** 2023-11-24
- **Earliest priority:** 2023-11-24
- **Family:** 90125593
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** NANJING ABOUDEN AUTOMATION EQUIPMENT CO LTD
- **Inventors:** LI JIANGCHUAN; PAN MIAOFENG; WU WENXIU

## Abstract

The application provides a panel hoisting accessory relates to panel transport field. The lifting mechanism is arranged on the support cross rod, one end of the support cross rod is hinged with the support cross rod, the other end of the support cross rod rotates around the support cross rod, and the lifting mechanism can slide back and forth along the extending direction of the support cross rod; the lifting mechanism comprises an electric hoist arranged on the supporting cross rod and a hanging bracket which is hung by the electric hoist, wherein a plurality of fixed suckers are arranged at the bottom of the hanging bracket, and the fixed suckers suck the plates after generating negative pressure by a vacuum pump; the hanger is provided with a negative pressure bracket, the vacuum pump forms a negative pressure area in the negative pressure bracket, and a plurality of fixed suckers are communicated with the negative pressure area of the negative pressure bracket through air pipes. The application has the effects of being capable of lifting and transferring the plate rapidly, stably and highly accurately in a short distance and effectively improving economic benefit.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-117682433-A/pdf000.png)

![Sketch 1 for CN-117682433-A](https://nimo.iptorch.com/refdrawing/CN-117682433-A/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-117682433-A/pdf001.png)

![Sketch 2 for CN-117682433-A](https://nimo.iptorch.com/refdrawing/CN-117682433-A/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/CN-117682433-A/pdf002.png)

![Sketch 3 for CN-117682433-A](https://nimo.iptorch.com/refdrawing/CN-117682433-A/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/CN-117682433-A/pdf003.png)

![Sketch 4 for CN-117682433-A](https://nimo.iptorch.com/refdrawing/CN-117682433-A/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/CN-117682433-A/pdf004.png)

![Sketch 5 for CN-117682433-A](https://nimo.iptorch.com/refdrawing/CN-117682433-A/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/CN-117682433-A/pdf005.png)

![Sketch 6 for CN-117682433-A](https://nimo.iptorch.com/refdrawing/CN-117682433-A/pdf005.png)

## Claims

### Claim 1 (independent)

The plate hoisting device is characterized by comprising a support longitudinal rod (1) and a support cross rod (2), wherein a hoisting mechanism (3) is arranged on the support cross rod (2), one end of the support cross rod (2) is hinged with the support longitudinal rod (1), the other end of the support cross rod rotates around the support cross rod (2), and the hoisting mechanism (3) can slide back and forth along the extending direction of the support cross rod (2); the lifting mechanism (3) comprises an electric hoist (31) arranged on a supporting cross rod (2) and a hanging bracket (32) hung by the electric hoist (31), wherein a plurality of fixed suckers (4) are arranged at the bottom of the hanging bracket (32), and the fixed suckers (4) absorb plates after generating negative pressure by a vacuum pump (33).

### Claim 2

A plate lifting device according to claim 1, characterized in that the lifting frame (32) is provided with a negative pressure bracket (34), the vacuum pump (33) forms a negative pressure area in the negative pressure bracket (34), and the plurality of fixed suckers (4) are communicated with the negative pressure area of the negative pressure bracket (34) through air pipes.

### Claim 3

A plate lifting device according to claim 1, characterized in that the hanger (32) comprises a main rod (321) and a plurality of auxiliary rods (322) arranged at the bottom of the main rod (321), the auxiliary rods (322) are provided with a movable clamping piece (5) and a fixed clamping piece (6) in an adapting way, the movable clamping piece (5) and the fixed clamping piece (6) are respectively arranged at two ends of the auxiliary rods (322), and the movable clamping piece (5) and the fixed clamping piece (6) are connected with a fixed sucker (4) through connecting rods (51).

### Claim 4

A plate lifting device according to claim 3, characterized in that the movable clamping piece (5) and the fixed clamping piece (6) are both in a shape of a mouth and sleeved on the outer wall of the auxiliary rod (322), the fixed clamping piece (6) is fixedly connected with the auxiliary rod (322), the movable clamping piece (5) slides between the end part of the auxiliary rod (322) and the connection part of the main rod (321) and the auxiliary rod (322), a threaded hole (52) is formed in the outer wall of the movable clamping piece (5), a screw rod (53) is screwed in the threaded hole (52) in a matched mode, one end of the screw rod (53) is located on the outer side of the movable clamping piece (5), and the other end of the screw rod (53) abuts against the auxiliary rod (322).

### Claim 5

A plate lifting device according to claim 3, wherein a movable sucker (7) is arranged at the bottom of the outer wall of the auxiliary rod (322), a supporting rod (71) is arranged at the top of the movable sucker (7), one end of the supporting rod (71) is connected with the movable sucker (7), and the other end of the supporting rod (71) passes through the auxiliary rod (322) along the vertical direction; be equipped with slide hole (710) on bracing piece (71), be equipped with wedge (8) and actuating mechanism (9) in auxiliary rod (322), wedge (8) wear to establish in slide hole (710), the inner wall top of slide hole (710) with the laminating of the inclined plane of wedge (8), actuating mechanism (9) push-and-pull wedge (8) along the direction of stretching of auxiliary rod (322), the height of slide hole (710) is greater than the minimum thickness of wedge (8) and be less than the maximum thickness of wedge (8).

### Claim 6

A plate lifting device according to claim 5, wherein the driving mechanism (9) comprises a sleeve (91) and a screw rod (92), the sleeve (91) is fixedly arranged in the auxiliary rod (322), and the sleeve (91) is connected with the screw rod (92) through thread fit; one end of the screw rod (92) is located on the outer side of the auxiliary rod (322), the other end of the screw rod (92) penetrates through the sleeve (91) and is close to the wedge block (8), a connecting block (93) is arranged on the outer wall of the wedge block (8), a bearing (94) is arranged on one side, facing the screw rod (92), of the connecting block (93), an outer ring of the bearing (94) is connected with the connecting block (93), and the screw rod (92) penetrates through an inner ring of the bearing (94) in an adaptive mode.

### Claim 7

The plate lifting device according to claim 6, wherein a top plate (95) is arranged at the top of the outer side of the auxiliary rod (322), the supporting rod (71) passes through the auxiliary rod (322) and then is connected with the bottom of the top plate (95), a plurality of springs (96) are arranged between the bottom of the top plate (95) and the top of the outer wall of the auxiliary rod (322), and the springs (96) push the top plate (95) upwards.

### Claim 8

A plate lifting device according to claim 6, wherein the screw rod (92) is coaxially arranged with the auxiliary rod (322), and the bottom of the wedge block (8) is attached to the bottom of the inner wall of the auxiliary rod (322).

### Claim 9

The plate lifting device according to claim 7, wherein one end of the screw rod (92) located at the outer side of the auxiliary rod (322) is provided with a rotary disc (97), one side of the rotary disc (97) facing the screw rod (92) is provided with an annular clamping groove (971), a sliding block (972) is clamped in the clamping groove (971), the sliding block (972) can slide in the clamping groove (971), and the movable clamping piece (5) is connected with the sliding block (972) through a pull rod (54).

### Claim 10

The plate lifting device according to claim 9, wherein the radial cross section of the clamping groove (971) is in a convex shape, the side with smaller inner diameter of the clamping groove (971) is communicated with the end face of the turntable (97), and the side with larger inner diameter of the clamping groove (971) is located inside the turntable (97).

## Full description

PERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESCranes comprising essentially a beam, boom, or triangular structure acting as a cantilever and mounted for translatory of swinging movements in vertical or horizontal planes or a combination of such movements, e.g. jib-cranes, derricks, tower cranesCranes comprising essentially a beam, boom, or triangular structure acting as a cantilever and mounted for translatory of swinging movements in vertical or horizontal planes or a combination of such movements, e.g. jib-cranes, derricks, tower cranes with non-adjustable and non-inclinable jibs mounted solely for slewing movementsPivot axis separated from column axisPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansMultiple lifting units; More than one suction areaSeparate cupsPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansOperating and control devicesPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESTrolleys or crabs, e.g. operating above runwaysTrolleys or crabs, e.g. operating above runways with operating gear or operator's cabin suspended, or laterally offset, from runway or trackUnderhung trolleysUnderhung trolleys running on monorailsPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESOther constructional features or detailsAuxiliary devices for controlling movements of suspended loads, or preventing cable slackAuxiliary devices for controlling movements of suspended loads, or preventing cable slack for minimising or preventing longitudinal or transverse swinging of loadsPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESCranes comprising essentially a beam, boom, or triangular structure acting as a cantilever and mounted for translatory of swinging movements in vertical or horizontal planes or a combination of such movements, e.g. jib-cranes, derricks, tower cranesCranes comprising essentially a beam, boom, or triangular structure acting as a cantilever and mounted for translatory of swinging movements in vertical or horizontal planes or a combination of such movements, e.g. jib-cranes, derricks, tower cranes with jibs supported by columns, e.g. towers having their lower end mounted for slewing movements

Description

Translated from Chinese

ä¸ç§æ¿æèµ·åè£

ç½®A plate lifting device

ææ¯é¢åTechnical field

æ¬ç³è¯·æ¶åæ¿ææ¬è¿é¢åï¼å°¤å

¶æ¯æ¶åä¸ç§æ¿æèµ·åè£

ç½®ãThe present application relates to the field of plate transport, and in particular to a plate lifting device.

èæ¯ææ¯Background technique

æ¿æè¡¨é¢å

æ»å¹³æ´ï¼å°ºå¯¸å¤§å°ä¸ä¸ï¼å½æ¿ææå¨ä¸èµ·æå¹³éºå¨å°é¢ä¸æ¶ï¼å¨å¤§æ°ååæ¿æèªèº«éåçä½ç¨ä¸ï¼æ¿æä¸æ¿æä¹é´ä¼ç´§å¯å¸åï¼å°¤å

¶æ¯éå±æ¿æï¼è¿æ ·ï¼å½éè¦ç§»å¨æ¿ææ¶ï¼è¥éç¨äººå·¥è¿è¡æ¬å¨åä¼éè¦æ¶èå¤§éçäººåï¼èä¸å¨äººå·¥æ¬è¿çè¿ç¨ä¸­ï¼å¦ææ¿æçåè¾¹ååä¸åçè³å®¹æåºç°åæãæè½ï¼å¼åå±é©ãThe surface of the plates is smooth and flat, and the sizes are different. When the plates are stacked together or laid flat on the ground, under the action of atmospheric pressure and the plate's own gravity, the plates will be tightly attracted to each other, especially the metal plates. In this way, When the board needs to be moved, it will consume a lot of manpower if done manually. Moreover, during the manual handling process, if the force on each side of the board is uneven, it may even easily deflect or fall, causing danger.

ç®åï¼ä¸ºäºæé«å¯¹æ¿æçæ¬è¿æçå¹¶ç¡®ä¿å¨æ¬è¿è¿ç¨ä¸­äººåçå®å

¨æ§ï¼ä¼éç¨è¡åç­è®¾å¤å¯¹æ¿æè¿è¡æåä¸è½¬ç§»ï¼å

·ä½çï¼æ¯éè¿å¨è¡åçæé©ä¸è®¾ç½®æ¯æ¶ï¼èæ¯æ¶çåºé¨è®¾æè¥å¹²çç©ºå¸çï¼å½çç©ºå¸çä¸æ¿æè´´ååï¼åéè¿çç©ºæ³µæ½åºçç©ºå¸çå

çç©ºæ°ï¼ä½¿å¾æ¿æä¸çç©ºå¸çä¹é´è½å¤å¯é è¿æ¥ï¼è¿èåææ§è¡åå¯¹æ¿æè¿è¡ç§»å¨ãAt present, in order to improve the efficiency of transporting plates and ensure the safety of personnel during the transportation process, equipment such as cranes are used to lift and transfer the plates. Specifically, brackets are set on the hooks of the cranes, and the brackets There are a number of vacuum suction cups at the bottom. When the vacuum suction cup is attached to the plate, the air in the vacuum suction cup is extracted through the vacuum pump, so that the plate and the vacuum suction cup can be reliably connected, and then the crane is controlled to move the plate.

ç¶èè¡åè®¾å¤çå®è£

åä½¿ç¨ææ¬è¾é«ï¼ä¸å½åªéè¦å°æ¿æç±å æ¾åºåè¿è³é è¿çä¸æåºæ¶ï¼æ¿æå®é

ç§»å¨çè·ç¦»è¾ç­ï¼èè¡åçæ´ä½æä½ä¼æ´å å¤æï¼å¯¹æ¿æä½ç§»éçæ§å¶ç²¾åº¦è¾å·®ï¼å®¹æé ææ¿æçæå¨ï¼è¿èéä½æ´ä½çå·¥ä½æçãHowever, the installation and use costs of the traveling crane equipment are relatively high, and when the panels only need to be lifted from the stacking area to the nearby unloading area, the actual moving distance of the panels is shorter, and the overall operation of the traveling crane will be more complicated, which is detrimental to The control accuracy of plate displacement is poor, which can easily cause the plate to shake, thus reducing the overall work efficiency.

åæå

å®¹Contents of the invention

ä¸ºäºæ¹åä½¿å¾è¡åç­å¤§åè®¾å¤åè¿æ¿ææ¶å­å¨çä½ç§»ç²¾åº¦å·®ãæä½å¤æä¸ç»æµæçä½çé®é¢ï¼æ¬ç³è¯·æä¾ä¸ç§æ¿æèµ·åè£

ç½®ãIn order to improve the problems of poor displacement accuracy, complicated operation and low economic benefits when large equipment such as traveling cranes lifts plates, this application provides a plate lifting device.

æ¬ç³è¯·æä¾ä¸ç§æ¿æèµ·åè£

ç½®ï¼éç¨å¦ä¸çææ¯æ¹æ¡ï¼This application provides a plate lifting device, which adopts the following technical solution:

ä¸ç§æ¿æèµ·åè£

ç½®ï¼å

æ¬æ¯æçºµæåæ¯ææ¨ªæï¼æè¿°æ¯ææ¨ªæä¸è®¾æèµ·åæºæï¼æè¿°æ¯ææ¨ªæçä¸ç«¯ä¸æ¯æçºµæé°æ¥ãå¦ä¸ç«¯å´ç»æ¯ææ¨ªæè½¬å¨ï¼æè¿°èµ·åæºæå¯æ²¿æ¯ææ¨ªæçä¼¸å±æ¹åå¾å¤æ»å¨ï¼A plate lifting device includes a supporting vertical bar and a supporting horizontal bar. A lifting mechanism is provided on the supporting horizontal bar. One end of the supporting horizontal bar is hinged with the supporting vertical bar, and the other end rotates around the supporting horizontal bar. The lifting device The mechanism can slide back and forth along the extension direction of the support crossbar;

æè¿°èµ·åæºæå

æ¬è®¾äºæ¯ææ¨ªæä¸ççµå¨è«è¦åéè¿çµå¨è«è¦åå¨çåæ¶ï¼æè¿°åæ¶çåºé¨è®¾æè¥å¹²åºå®å¸çï¼æè¿°åºå®å¸çéè¿çç©ºæ³µäº§çè´ååå¸åæ¿æãThe lifting mechanism includes an electric hoist installed on the supporting crossbar and a hanger lifted by the electric hoist. The bottom of the hanger is provided with a number of fixed suction cups. The fixed suction cups generate negative pressure through a vacuum pump and then suck the plate.

éè¿éç¨ä¸è¿°ææ¯æ¹æ¡ï¼å¨æ¹åçµå¨è«è¦å¨æ¯ææ¨ªæä¸çä½ç½®åå¨è½¬å¨æ¯ææ¨ªæåï¼å°±è½å¤å®ç°åæ¶å¨æ°´å¹³é¢å

çç§»å¨ï¼å¨åæ¶ç§»å¨è³æ¿æçä¸æ¹åï¼æå¨çµå¨è«è¦ï¼ä½¿å¾åæ¶åä¸ç§»å¨ï¼å½åºå®å¸çä¸æ¿æè´´åãçµå¨è«è¦çé¾æ¡å¤äºæ¾å¼ç¶æåï¼çç©ºæ³µå¼å§å·¥ä½ï¼ä»èå¨åºå®å¸çå¤äº§çè´åï¼ä½¿å¾åºå®å¸çä¸æ¿æä¹é´ç´§å¯è¿æ¥ï¼åæå¨çµå¨è«è¦ï¼å³å¯å¨åäººä½¿ç¨è¾å°çåéçæ

åµä¸å®ç°åæ¶åæ¿æçå¹³ç¨³æåï¼åéè¿æ¨å¨åæ¶èå¸¦å¨æ¯ææ¨ªæå´ç»æ¯æçºµæçè½¬å¨ï¼å®ææ¿æçç§»å¨ï¼èä¸æ¯æçºµæçé«åº¦è¿ä½äºä¸è¬åæ¿è£

é

çè¡åè®¾å¤çé«åº¦ï¼å¯¹åºçç¨äºè¿æ¥åæ¶çç»³ç¼çé¿åº¦ä¹è¾ç­ï¼è½å¤éä½åæ¶ç§»å¨è¿ç¨ä¸­äº§ççæå¨ï¼ä¹å°±æ¯è¯´ï¼éè¿æ¯ææ¨ªæçè½¬å¨æ¥å®ç°æ¿æçç§»å¨è½å¤æé«æ¿æç§»å¨è¿ç¨çç¨³å®æ§ï¼æ¯ææé«æ¿æçä½ç§»ç²¾åº¦ï¼æ´ä½ç»æç´§åï¼æä½ç®åï¼è½å¤æ»¡è¶³æ¿æçç­è·ç¦»å

çé«ç²¾åº¦çè¾éï¼æåäºç»æµæçãBy adopting the above technical solution, after changing the position of the electric hoist on the support crossbar and rotating the support crossbar, the hanger can be moved in the horizontal plane. After the hanger moves above the plate, the electric hoist is pulled. Make the hanger move downward. When the fixed suction cup is attached to the plate and the chain of the electric hoist is in a relaxed state, the vacuum pump starts to work, thereby generating negative pressure at the fixed suction cup, making the fixed suction cup and the plate tightly connected, and then pulling the electric hoist The hoist can realize the smooth lifting of the hanger and the plate by a single person using a small amount of force. Then, by pushing the hanger, the support cross bar is driven to rotate around the support vertical bar, completing the movement of the plate and supporting the vertical bar. The height is much lower than the height of the lifting equipment assembled in general factories, and the length of the corresponding ropes used to connect the hanger is also shorter, which can reduce the shaking generated during the movement of the hanger. That is to say, by supporting the cross bar The rotation of the plate to realize the movement of the plate can improve the stability of the plate movement process, and the support improves the displacement accuracy of the plate. The overall structure is compact and the operation is simple. It can meet the high-precision transportation of the plate within a short distance and improve the economic benefits.

å¯éçï¼æè¿°åæ¶ä¸è®¾æè´åæ¯æ¶ï¼æè¿°çç©ºæ³µå¨è´åæ¯æ¶å

å½¢æè´ååºï¼è¥å¹²åºå®å¸çéè¿æ°ç®¡ä¸è´åæ¯æ¶çè´ååºè¿éãOptionally, the hanger is provided with a negative pressure bracket, the vacuum pump forms a negative pressure area in the negative pressure bracket, and a number of fixed suction cups are connected to the negative pressure area of the negative pressure bracket through tracheas.

éè¿éç¨ä¸è¿°ææ¯æ¹æ¡ï¼è´åæ¯æ¶è½å¤èµ·å°ä¸ä¸ªçç©ºæ³µä¸å¤ä¸ªåºå®å¸ççè¿æ¥ä½ç¨ï¼è½å¤åå°æ°ç®¡çä½¿ç¨éï¼éä½æ°ç®¡ç ´æçæ¦çï¼ä¹å°±ç¡®ä¿çç©ºæ³µè½å¤å¨åºå®å¸çå¤å½¢æè´åï¼å®ç°åºå®å¸çå¯¹æ¿æçå¸éä¸æåãBy adopting the above technical solution, the negative pressure bracket can serve as a connection between a vacuum pump and multiple fixed suction cups, which can reduce the use of trachea and reduce the probability of tracheal damage, thereby ensuring that the vacuum pump can form negative pressure at the fixed suction cup, achieving The fixed suction cup adsorbs and grabs the board.

å¯éçï¼æè¿°åæ¶å

æ¬ä¸æ ¹ä¸»æåå¤æ ¹è®¾äºä¸»æåºé¨çå¯æï¼æè¿°å¯æä¸éé

å°è®¾æä¸ä¸ªæ´»å¨å¡ä»¶åä¸ä¸ªåºå®å¡ä»¶ï¼æè¿°æ´»å¨å¡ä»¶åæè¿°åºå®å¡ä»¶åå«ä½äºæè¿°å¯æçä¸¤ç«¯ï¼æè¿°æ´»å¨å¡ä»¶åæè¿°åºå®å¡ä»¶åéè¿è¿æ¥æè¿æ¥æä¸ä¸ªåºå®å¸çãOptionally, the hanger includes a main rod and a plurality of auxiliary rods located at the bottom of the main rod. The auxiliary rods are adaptively provided with a movable clamp and a fixed clamp. The movable clamp is The movable clamping piece and the fixed clamping piece are respectively located at both ends of the auxiliary rod. Both the movable clamping piece and the fixed clamping piece are connected to a fixed suction cup through a connecting rod.

éè¿éç¨ä¸è¿°ææ¯æ¹æ¡ï¼ä¸»æè½å¤èµ·å°å¯¹å¯æçè¿æ¥ä½ç¨ï¼ç¡®ä¿å¤ä¸ªå¯æå¨è¢«å¯é åºå®çæ

åµä¸è½å¤å®ç°å¤ä¸ªåºå®å¸çå¨åæ¶ä¸çåå¸è®¾ç½®ï¼ä»èä½¿å¾å¤ä¸ªåºå®å¸çå¯¹æ¿æçå¸éåæ´å ååï¼ä¹å°±ä½¿å¾æ¿æè½å¤åå¹³ç´çç¶æè¿è¡æåãè¿æ¥æä¸åºå®å¡ä»¶ãè¿æ¥æä¸æ´»å¨å¡ä»¶ä¹é´åä¸ºåºå®è¿æ¥ï¼è¿æ¥æèµ·å°å¯¹åºå®å¸ççè¿æ¥ä½ç¨ï¼åºå®å¡ä»¶å¨å¯æä¸åºå®è¿æ¥ï¼ä½¿å¾åºå®å¡ä»¶ä¸è£

é

çåºå®å¸ççä½ç½®åºå®ï¼æ´»å¨å¡ä»¶å¨å¯æä¸æ´»å¨è¿æ¥ï¼ä½¿å¾æ´»å¨å¡ä»¶ä¸è£

é

çåºå®å¸ççä½ç½®å¯è°ï¼ä»èéè¿è°èæ´»å¨å¡ä»¶çä½ç½®å¯¹ç¸åºçåºå®å¸ççä½ç½®è¿è¡è°æ´ï¼è¿è¡å¢å¤§å¤ä¸ªåºå®å¸ççæ£å¸é¢ç§¯ï¼ä»èè½å¤éåºæ´å¤§å°ºå¯¸çæ¿æãBy adopting the above technical solution, the main rod can play a connecting role to the auxiliary rods, ensuring that multiple auxiliary rods can be distributed and arranged on the hanger when multiple auxiliary rods are reliably fixed, thereby allowing multiple fixed suction cups to be distributed The adsorption force on the board is more uniform, which allows the board to be lifted in a straight state. The connecting rod and the fixed clamping piece, the connecting rod and the movable clamping piece are all fixedly connected. The connecting rod plays a role in connecting the fixed suction cup. The fixed clamping piece is fixedly connected on the auxiliary rod, so that the fixed sucking cup assembled on the fixed clamping piece The position is fixed, and the movable clamping piece is movably connected on the auxiliary rod, so that the position of the fixed suction cup assembled on the movable clamping piece is adjustable, so that the position of the corresponding fixed suction cup can be adjusted by adjusting the position of the movable clamping piece, thereby increasing the number of Fixed suction cup spread area to accommodate larger board sizes.

å¯éçï¼æè¿°æ´»å¨å¡ä»¶åæè¿°åºå®å¡ä»¶ååå£å­åä¸å¥è®¾å¨å¯æçå¤å£ä¸ï¼æè¿°åºå®å¡ä»¶ä¸å¯æä¹é´åºå®è¿æ¥ï¼æè¿°æ´»å¨å¡ä»¶å¨æè¿°å¯æçç«¯é¨åä¸»æä¸å¯æçè¿æ¥å¤ä¹é´æ»å¨ï¼æè¿°æ´»å¨å¡ä»¶çå¤å£ä¸è®¾æèºçº¹å­ï¼æè¿°èºçº¹å­å

éé

å°æè®¾æèºæï¼æè¿°èºæçä¸ç«¯ä½äºæ´»å¨å¡ä»¶çå¤ä¾§ï¼æè¿°èºæçå¦ä¸ç«¯æµè§¦æè¿°å¯æãOptionally, the movable clamping piece and the fixed clamping piece are both in the shape of a mouth and are sleeved on the outer wall of the auxiliary pole. The fixed clamping piece and the auxiliary pole are fixedly connected, and the movable clamping piece is in the The end of the auxiliary rod slides between the connection between the main rod and the auxiliary rod. A threaded hole is provided on the outer wall of the movable clamping member. A screw rod is adaptedly screwed in the threaded hole. One end of the screw rod Located outside the movable clamping member, the other end of the screw rod resists the auxiliary rod.

éè¿éç¨ä¸è¿°ææ¯æ¹æ¡ï¼åºå®å¡ä»¶å¨å¯æä¸æ»å¨å°ä½åï¼å¯ä»¥çæ¥å¨å¯æä¸å®ç°ä½ç½®çåºå®ï¼æ´»å¨å¡ä»¶å¨å¯æä¸æ»å¨å°ä½åï¼å¯ä»¥å°èºææå

¥å°æ´»å¨å¡ä»¶çèºçº¹å­å

ï¼ä½¿å¾èºæä¸æ´»å¨å¡ä»¶ä¹é´çç¸å¯¹ä½ç½®å¯è°ä¸å¨è°æ´å®æ¯åè½å¤éæ­¢ï¼è¿æ ·ï¼å½èºææå

¥è¶³å¤æ·±åº¦åï¼èºæçç«¯é¨å°±ä¼æ¤åå¯æçå¤å£ï¼ä»èå®ç°æ´»å¨å¡ä»¶ä½ç½®çåºå®ãBy adopting the above technical solution, after the fixed clamp slides in place on the auxiliary rod, it can be welded on the auxiliary rod to achieve position fixation. After the movable clamp slides in place on the auxiliary rod, the screw can be screwed into the thread of the movable clamp. hole, so that the relative position between the screw and the movable clamp is adjustable and can be locked after the adjustment is completed. In this way, when the screw is screwed in to a sufficient depth, the end of the screw will squeeze the outer wall of the auxiliary rod, thereby achieving Fixed position of movable cards.

å¯éçï¼æè¿°å¯æçå¤å£åºé¨è®¾æä¸ä¸ªæ´»å¨å¸çï¼æè¿°æ´»å¨å¸ççé¡¶é¨è®¾ææ¯ææï¼æè¿°æ¯ææçä¸ç«¯ä¸æ´»å¨å¸çè¿æ¥ï¼æè¿°æ¯ææçå¦ä¸ç«¯æ²¿ç«ç´æ¹åç©¿è¿æè¿°å¯æï¼Optionally, a movable suction cup is provided at the bottom of the outer wall of the auxiliary rod, and a support rod is provided at the top of the movable suction cup. One end of the support rod is connected to the movable suction cup, and the other end of the support rod is connected in the vertical direction. Pass through said secondary rod;

æè¿°æ¯ææä¸è®¾ææ»å­ï¼æè¿°å¯æå

è®¾ææ¥å½¢ååé©±å¨æºæï¼æè¿°æ¥å½¢åç©¿è®¾å¨æè¿°æ»å­å

ï¼æè¿°æ»å­çå

å£é¡¶é¨ä¸æè¿°æ¥å½¢åçæé¢è´´åï¼æè¿°é©±å¨æºææ²¿å¯æçä¼¸å±æ¹åæ¨ææ¥å½¢åï¼æè¿°æ»å­çé«åº¦å¤§äºæè¿°æ¥å½¢åçæå°ååº¦ä¸å°äºæè¿°æ¥å½¢åçæå¤§ååº¦ãThe support rod is provided with a sliding hole, and the auxiliary rod is provided with a wedge block and a driving mechanism. The wedge block is inserted into the sliding hole, and the top of the inner wall of the sliding hole is in contact with the slope of the wedge block. The driving mechanism pushes and pulls the wedge block along the extension direction of the auxiliary rod, and the height of the sliding hole is greater than the minimum thickness of the wedge block and less than the maximum thickness of the wedge block.

éè¿éç¨ä¸è¿°ææ¯æ¹æ¡ï¼å¤ä¸ªåºå®å¸ççæå¨é«åº¦ä¸è´ï¼èæ´»å¨å¸ççåå§ä½ç½®ä¼é«äºåºå®å¸çï¼è¿æ ·ï¼å¨æ¿æçå°ºå¯¸è¾å°æ¶ï¼ä»

éè¿åºå®å¸çå°±è½å¤å®ç°å¯¹æ¿æçæåï¼èæ´»å¨å¸çå¤äºæ¬ç©ºç¶æãå¨æ¿æçå°ºå¯¸è¾å¤§ï¼éè¦å¢å å¸ççæ°éæ¶ï¼é©±å¨æºæå¨ä½ï¼ä½¿å¾æ¥å½¢åæåå

¶ååº¦è¾å¤§çä¸ä¾§è¿å¨ï¼å³å°æ¥å½¢åä»æ»å­å

æ½åºï¼èå¨è¿ä¸è¿ç¨ä¸­ï¼æ»å­çå

å£é¡¶é¨ä¸æ¥å½¢åçæé¢ä¹é´çè·ç¦»æ©å¤§ï¼è¿æ ·ï¼æ¯ææå°±ä¼å¨éåçä½ç¨ä¸æ²¿ç«ç´æ¹ååä¸è¿å¨ï¼ä¹å°±ä¼å¸¦å¨æ´»å¨å¸çåä¸è¿å¨ï¼ç´å°æ´»å¨å¸ççé«åº¦ä¸åºå®å¸ççé«åº¦ä¸è´ï¼æ­¤æ¶ï¼åä¸æ¾åæ¶ï¼å³å¯å®ç°æ´»å¨å¸çä¸åºå®å¸çåæ¶å¯¹æ¿æè¿è¡å¸éï¼æé«äºå¯¹æ¿ææåçå¯é æ§ãBy adopting the above technical solution, multiple fixed suction cups are at the same height, and the initial position of the movable suction cup will be higher than the fixed suction cup. In this way, when the size of the board is small, the board can be lifted only by the fixed suction cup, and the movable suction cup can be lifted. The suction cup is in a suspended state. When the size of the plate is large and the number of suction cups needs to be increased, the driving mechanism acts to make the wedge block move toward the side with larger thickness, that is, the wedge block is pulled out of the sliding hole, and in this process, the sliding hole The distance between the top of the inner wall and the slope of the wedge block is enlarged, so that the support rod will move downward in the vertical direction under the action of gravity, which will also drive the movable suction cup to move downward until the height of the movable suction cup is equal to that of the fixed suction cup. At this time, by lowering the hanger, the movable suction cup and the fixed suction cup can adsorb the plate at the same time, which improves the reliability of grabbing the plate.

å¯éçï¼æè¿°é©±å¨æºæå

æ¬å¥ç®¡åä¸æï¼æè¿°å¥ç®¡åºå®è®¾äºæè¿°å¯æå

ï¼æè¿°å¥ç®¡ä¸æè¿°ä¸æä¹é´éè¿èºçº¹éé

è¿æ¥ï¼Optionally, the driving mechanism includes a sleeve and a screw rod, the sleeve is fixed in the auxiliary rod, and the sleeve and the screw are connected through a threaded fit;

æè¿°ä¸æçä¸ç«¯ä½äºæè¿°å¯æçå¤ä¾§ï¼æè¿°ä¸æçå¦ä¸ç«¯ç©¿è¿æè¿°å¥ç®¡å¹¶é è¿æè¿°æ¥å½¢åï¼æè¿°æ¥å½¢åçå¤å£ä¸è®¾æè¿æ¥åï¼æè¿°è¿æ¥åæåä¸æçä¸ä¾§è®¾æè½´æ¿ï¼æè¿°è½´æ¿çå¤åä¸è¿æ¥åè¿æ¥ï¼æè¿°ä¸æéé

å°ç©¿è®¾å¨æè¿°è½´æ¿çå

åãOne end of the screw rod is located outside the auxiliary rod, and the other end of the screw rod passes through the casing and is close to the wedge-shaped block. A connecting block is provided on the outer wall of the wedge-shaped block. The connecting block A bearing is provided on the side facing the screw rod, the outer ring of the bearing is connected to the connecting block, and the screw rod is adapted to pass through the inner ring of the bearing.

éè¿éç¨ä¸è¿°ææ¯æ¹æ¡ï¼å¯æä¸ºç©ºå¿çæ¹ç®¡ç»æï¼ç±äºå¥ç®¡ä¸å¯æä¹é´ç¸äºè¿æ¥ï¼å¨è½¬å¨ä¸æåï¼ä¸æå°±ä¼æåå¯æçå¤ä¾§ç§»å¨ï¼èä¸æä¸æ¥å½¢åä¹é´éè¿è¿æ¥åä¸è½´æ¿è¿æ¥ï¼è¿æ ·ï¼å¨ä¸æè½¬å¨å¹¶äº§çæ°´å¹³æ¹åçä½ç§»åï¼åæ¶å¨è½´æ¿çé

åä¸ï¼è¿æ¥åä¸æ¥å½¢åä¼äº§çæ°´å¹³æ¹åçä½ç§»å¹¶å¨æ»å­å

ç§»å¨ï¼ä¸ä¸ä¼äº§çè½¬å¨ï¼ä¹å°±æ¯è¯´ï¼å¨æ­£åæååè½¬å¨ä¸æå³å¯å®ç°æ¥å½¢åå¨æ°´å¹³æ¹åä¸çå¾å¤è¿å¨ãBy adopting the above technical solution, the auxiliary rod has a hollow square tube structure. Since the casing and the auxiliary rod are connected to each other, after the screw rod is rotated, the screw rod will move toward the outside of the auxiliary rod, and the gap between the screw rod and the wedge block are connected to the bearings through the connecting block. In this way, after the screw rotates and generates horizontal displacement, and at the same time with the cooperation of the bearing, the connecting block and the wedge block will generate horizontal displacement and move in the sliding hole, and will not Producing rotation, that is to say, rotating the screw rod in the forward or reverse direction can realize the reciprocating motion of the wedge block in the horizontal direction.

å¯éçï¼æè¿°å¯æçå¤ä¾§é¡¶é¨è®¾æé¡¶æ¿ï¼æè¿°æ¯ææç©¿è¿å¯æåä¸æè¿°é¡¶æ¿çåºé¨è¿æ¥ï¼æè¿°é¡¶æ¿çåºé¨ä¸æè¿°å¯æçå¤å£é¡¶é¨ä¹é´è®¾æå¤ä¸ªå¼¹ç°§ï¼æè¿°å¼¹ç°§åä¸é¡¶æ¨é¡¶æ¿ãOptionally, a top plate is provided on the outer top of the auxiliary rod, and the support rod is connected to the bottom of the top plate after passing through the auxiliary rod. There are multiple support rods between the bottom of the top plate and the top of the outer wall of the auxiliary rod. A spring pushes the top plate upward.

éè¿éç¨ä¸è¿°ææ¯æ¹æ¡ï¼å¨æ´»å¨å¸çå¤äºä¸åºå®å¸çåç­é«åº¦æ¶ï¼æ¥å½¢ååæ»å­çå¤ä¾§æåºï¼æ»åçå

å£é¡¶é¨ä¸æ¥å½¢åçæé¢ä¹é´çè·ç¦»åå¤§ï¼ä»èä½¿å¾æ¯ææå¸¦å¨æ´»å¨å¸çåä¸ç§»å¨ï¼æ­¤æ¶ï¼å¼¹ç°§å¤äºèªç¶ä¼¸é¿ç¶æï¼å¨æ´»å¨å¸ççé«åº¦é«äºåºå®å¸ççé«åº¦æ¶ï¼éè¦åå¯æçå

ä¾§æå

¥ä¸æï¼ä»èæ¨å¨æ¥å½¢ååæ»å­å

æè®¾ï¼æ»åçå

å£é¡¶é¨ä¸æ¥å½¢åçæé¢ä¹é´çè·ç¦»åå°ï¼ä»èä¼ä½¿å¾æ¯ææå¸¦å¨é¡¶æ¿åä¸ç§»å¨ï¼æ­¤æ¶å¼¹ç°§å¤äºæä¼¸ç¶æãèå¨æ´»å¨å¸çéè¦åæ¬¡ä¸è½æ¶ï¼å¼¹ç°§ä¼åä¸æå¨é¡¶æ¿ï¼å®ç°å¯¹æ¯ææåæ´»å¨å¸çä¸ç§»çè¾

å©é©±å¨ä½ç¨ï¼ç¡®ä¿æ´»å¨å¸çè½å¤é è¿æ¿æå¹¶å¸åæ¿æãBy adopting the above technical solution, when the movable suction cup is at the same height as the fixed suction cup, the wedge block is pulled out to the outside of the sliding hole, and the distance between the top of the inner wall of the slide block and the slope of the wedge block becomes larger, so that the support rod drives the movable suction cup. The suction cup moves downward. At this time, the spring is in a state of natural extension; when the height of the movable suction cup is higher than the height of the fixed suction cup, it is necessary to screw the screw rod into the inside of the auxiliary rod to push the wedge block into the sliding hole. The distance between the top of the inner wall of the slide block and the slope of the wedge block becomes smaller, which causes the support rod to drive the top plate to move upward, and at this time the spring is in a stretched state. When the movable suction cup needs to fall again, the spring will pull the top plate downward to assist in driving the support rod and the movable suction cup downward, ensuring that the movable suction cup can get close to the plate and absorb the plate.

å¯éçï¼æè¿°ä¸æä¸æè¿°å¯æåè½´è®¾ç½®ï¼æè¿°æ¥å½¢åçåºé¨ä¸å¯æçå

å£åºé¨è´´åãOptionally, the screw rod and the auxiliary rod are coaxially arranged, and the bottom of the wedge block fits the bottom of the inner wall of the auxiliary rod.

éè¿éç¨ä¸è¿°ææ¯æ¹æ¡ï¼å¨ä¸æè½¬å¨åï¼è½å¤å¯é å°å®ç°æ¥å½¢åçç§»å¨ï¼ä»èé©±å¨æ¯ææåæ´»å¨å¸çåä¸ç§»å¨ãBy adopting the above technical solution, after the screw rod rotates, the movement of the wedge block can be reliably realized, thereby driving the support rod and the movable suction cup to move downward.

å¯éçï¼æè¿°ä¸æä½äºå¯æå¤ä¾§çä¸ç«¯è®¾æè½¬çï¼æè¿°è½¬çæåä¸æçä¸ä¾§è®¾æç¯ç¶çå¡æ§½ï¼æè¿°å¡æ§½å

å¡è®¾ææ»åï¼æè¿°æ»åå¯å¨æè¿°å¡æ§½å

æ»å¨ï¼æè¿°æ´»å¨å¡ä»¶åæè¿°æ»åä¹é´éè¿ææè¿æ¥ãOptionally, the end of the screw rod located outside the auxiliary rod is provided with a turntable, and the turntable is provided with an annular slot on the side facing the screw rod, and a slider is installed in the slot. It can slide in the slot, and the movable clamping piece and the slider are connected through a pull rod.

éè¿éç¨ä¸è¿°ææ¯æ¹æ¡ï¼æ»åå¯ä»¥å¨å¡æ§½å

è½¬å¨ï¼èæ æ³è¿è¡è½´åçç§»å¨ï¼è¿æ ·ï¼å¨æ»åä¸ææè¿æ¥åï¼ææå¯ä»¥åè½¬çä¹é´åçç¸å¯¹è½¬å¨ï¼ä¹å°±æ¯è¯´ï¼å¨è½¬å¨è½¬çåï¼ä¸æä¼åçè½¬å¨åæ¶äº§çè½´åçä½ç§»ï¼èææçä¸ç«¯ä¸æ´»å¨å¡ä»¶è¿æ¥ãå¦ä¸ç«¯ä¸æ»åè¿æ¥ï¼èæ»ååå¯ä»¥å¨å¡æ§½å

æ»å¨ï¼ä½¿å¾å¨è½¬çè½¬å¨çè¿ç¨ä¸­ï¼ææå¯ä»¥åä¸æäº§çç¸åæ¹ååç¸åéçä½ç§»ï¼ä»èå®ç°æ´»å¨å¸çææ´»å¨å¡ä»¶ä¸åºå®å¸ççåæ­¥è°æ´ï¼å³å¨è½¬å¨è½¬çåï¼æ´»å¨å¸çä¼ä¸éè³ä¸åºå®å¸çç­é«çç¶æï¼èæ´»å¨å¡ä»¶ä¸çåºå®å¸çåä¼äº§çæ°´å¹³æ¹åçä½ç§»ï¼è¿æ ·ï¼è½å¤æå¤§ç¨åº¦ä¸å°æé«å¯¹å¤§å°ºå¯¸æ¿æçå¸éä¸æåææãBy adopting the above technical solution, the slider can rotate in the slot but cannot move axially. In this way, after the slider is connected to the pull rod, the pull rod can rotate relative to the turntable, that is to say, when the turntable is rotated Finally, the screw rod will rotate and produce axial displacement, and one end of the pull rod is connected to the movable clamping piece, and the other end is connected to the slider, and the slider can slide in the slot, so that during the rotation of the turntable, The pull rod can produce the same direction and amount of displacement as the screw rod, thereby realizing the synchronous adjustment of the movable suction cup or the fixed suction cup on the movable card. That is, after turning the turntable, the movable suction cup will drop to the same height as the fixed suction cup, and the movable suction cup will be lowered to the same height as the fixed suction cup. The fixed suction cup on the card will produce horizontal displacement, which can maximize the adsorption and grabbing effect on large-sized plates.

å¯éçï¼æè¿°å¡æ§½çå¾åæªé¢åå¸å­å½¢ï¼æè¿°å¡æ§½å

å¾è¾å°çä¸ä¾§ä¸æè¿°è½¬ççç«¯é¢è¿éï¼æè¿°å¡æ§½å

å¾è¾å¤§çä¸ä¾§ä½äºæè¿°è½¬ççå

é¨ãOptionally, the radial cross section of the slot is convex, the side with the smaller inner diameter of the slot is connected to the end face of the turntable, and the side with the larger inner diameter of the slot is located inside the turntable. .

éè¿éç¨ä¸è¿°ææ¯æ¹æ¡ï¼æ»åå

å¯é å°éå®å¨å¡æ§½çå

ä¾§ï¼èææçç«¯é¨å¯ä»¥ç©¿å

¥å°å¡æ§½å

å¹¶ä¸æ´»å¨åè¿æ¥ï¼è¿æ ·ï¼ç¡®ä¿å¨è½¬çè½¬å¨çè¿ç¨ä¸­ï¼ææä¸ä¼äº§çè·è½¬ï¼åæ¶ï¼ææè¿è½åå¤æå¨æ´»å¨å¡ä»¶åæ´»å¨å¡ä»¶ä¸çåºå®å¸çãBy adopting the above technical solution, the inside of the slider is reliably limited to the inside of the slot, and the end of the pull rod can penetrate into the slot and be connected with the movable block. This ensures that during the rotation of the turntable, the pull rod will not generate At the same time, the pull rod can also pull the movable card and the fixed suction cup on the movable card outward.

ç»¼ä¸æè¿°ï¼æ¬ç³è¯·å

æ¬ä»¥ä¸æçææï¼To sum up, this application includes the following beneficial effects:

1ãéè¿æ¯ææ¨ªæå¨æ¯æçºµæä¸çè½¬å¨ï¼éè¿çµå¨è«è¦å¨æ¯ææ¨ªæä¸çæ»å¨ï¼å®ç°äºåæ¶å¨æ¯ææ¨ªæçè½¬å¨èå´å

çä»»ææ¬åï¼åéè¿åæ¶åºé¨çåºå®å¸çåæ´»å¨å¸çå¯¹ä¸åå°ºå¯¸çæ¿æè¿è¡é«ç²¾åº¦é«æççè½¬å¨ã1. Through the rotation of the support crossbar on the support vertical bar, and through the sliding of the electric hoist on the support crossbar, the hanger can hover anywhere within the rotation range of the support crossbar, and then through the fixed suction cup at the bottom of the hanger and movable suction cups to rotate plates of different sizes with high precision and efficiency.

2ãéè¿ææä¸è½¬çåæ»åçé

åï¼ä½¿å¾å¨è½¬å¨è½¬çå¯¹æ´»å¨å¸çé«åº¦è¿è¡è°æ´çåæ¶ï¼è¿è½å¤å®ç°æ´»å¨å¡ä»¶ä¸çåºå®å¸ççæ°´å¹³ä½ç½®çè°æ´ï¼è¿ä¸æ­¥éä½æä½ä¾¿å©æ§ï¼ä¸æ¹é¢ä½¿å¾åæ¶è½å¤åèµ·ä¸åå°ºå¯¸çæ¿æï¼å¦ä¸æ¹é¢ä½¿å¾æ¿æçæ¬è¿æçæ´é«ãæ´ä½çç»æµæçä¹æ´é«ã2. Through the cooperation of the pull rod, the turntable and the slider, while turning the turntable to adjust the height of the movable suction cup, the horizontal position of the fixed suction cup on the movable card can also be adjusted, further reducing the convenience of operation. On the one hand, it makes The hanger can lift plates of different sizes. On the other hand, it makes the handling efficiency of the plates higher and the overall economic benefits higher.

éå¾è¯´æDescription of the drawings

å¾1æ¯æ¬ç³è¯·çç¤ºææ§ç«ä½å¾ï¼Figure 1 is a schematic perspective view of the present application;

å¾2æ¯åæ¶çç¤ºææ§ç«ä½å¾ï¼Figure 2 is a schematic perspective view of the hanger;

å¾3æ¯æ´»å¨å¸ççè£

é

ç¶æç¤ºæå¾ï¼Figure 3 is a schematic diagram of the assembly state of the movable suction cup;

å¾4æ¯å¯æçå

é¨ç»æåè§å¾ï¼Figure 4 is a cross-sectional view of the internal structure of the auxiliary rod;

å¾5æ¯è½¬çä¸ä¸æçè£

é

ç¶æç¤ºæå¾ï¼Figure 5 is a schematic diagram of the assembly state of the turntable and screw rod;

å¾6æ¯è½¬ççå

é¨ç»æåè§å¾ï¼Figure 6 is a cross-sectional view of the internal structure of the turntable;

å¾ä¸­ï¼1ãæ¯æçºµæï¼2ãæ¯ææ¨ªæï¼In the picture: 1. Support vertical bar; 2. Support horizontal bar;

3ãèµ·åæºæï¼31ãçµå¨è«è¦ï¼32ãåæ¶ï¼321ãä¸»æï¼322ãå¯æï¼33ãçç©ºæ³µï¼34ãè´åæ¯æ¶ï¼3. Lifting mechanism; 31. Electric hoist; 32. Hanger; 321. Main rod; 322. Auxiliary rod; 33. Vacuum pump; 34. Negative pressure bracket;

4ãåºå®å¸çï¼4. Fixed suction cup;

5ãæ´»å¨å¡ä»¶ï¼51ãè¿æ¥æï¼52ãèºçº¹å­ï¼53ãèºæï¼54ãææï¼5. Movable clamps; 51. Connecting rod; 52. Threaded hole; 53. Screw; 54. Tie rod;

6ãåºå®å¡ä»¶ï¼6. Fixed card;

7ãæ´»å¨å¸çï¼71ãæ¯ææï¼710ãæ»å­ï¼7. Movable suction cup; 71. Support rod; 710. Sliding hole;

8ãæ¥å½¢åï¼8. Wedge block;

9ãé©±å¨æºæï¼91ãå¥ç®¡ï¼92ãä¸æï¼93ãè¿æ¥åï¼94ãè½´æ¿ï¼95ãé¡¶æ¿ï¼96ãå¼¹ç°§ï¼97ãè½¬çï¼971ãå¡æ§½ï¼972ãæ»åã9. Driving mechanism; 91. Bushing; 92. Screw; 93. Connecting block; 94. Bearing; 95. Top plate; 96. Spring; 97. Turntable; 971. Card slot; 972. Slider.

å

·ä½å®æ½æ¹å¼Detailed ways

ä»¥ä¸ç»åéå¾1-6å¯¹æ¬ç³è¯·ä½è¿ä¸æ­¥è¯¦ç»è¯´æãThe present application will be further described in detail below in conjunction with Figures 1-6.

å¾1æ¯æ¬ç³è¯·çç¤ºææ§ç«ä½å¾ãåè§å¾1ï¼ä¸ç§æ¿æèµ·åè£

ç½®ï¼å

æ¬æ¯æçºµæ1ãæ¯ææ¨ªæ2åèµ·åæºæ3ï¼æ¯æçºµæ1åºå®è®¾äºå°é¢ä¸ï¼æ¯ææ¨ªæ2çä¸ç«¯é°æ¥å¨æ¯æçºµæ1çé¡¶é¨ï¼æ¯ææ¨ªæ2çå¦ä¸ç«¯å´ç»æ¯æçºµæ1è½¬å¨ï¼èµ·åæºæ3å

æ¬çµå¨è«è¦31ååæ¶32ï¼çµå¨è«è¦31å¯ä»¥æ²¿æ¯ææ¨ªæ2çä¼¸å±æ¹åå¨æ¯ææ¨ªæ2ä¸å¾å¤ç§»å¨ï¼çµå¨è«è¦31ä¸ç»è®¾æå¸¦æé©çç¼ç»³ï¼åæ¶32åè®¾å¨æé©ä¸ï¼å¨çµå¨è«è¦31ççµå¼ä¸ï¼åæ¶32å¯ä»¥å¨ç«ç´æ¹åå¾å¤è¿å¨ï¼æ ¹æ®æ¿æçééåçäº§é¢ç®ï¼å¯ä»¥éç¨çµå¨è«è¦31ä»¥å¤çè®¾å¤å¯¹åæ¶32è¿è¡çµå¼ï¼å¦ææè«è¦æå·æ¬æºç­ï¼ï¼åæ¶32ä¸è®¾æææï¼å¨åæ¶32å¤äºæ¬ç©ºç¶ææ¶ï¼æ¡æææå¹¶å¨æ°´å¹³é¢å

æ¨å¨åæ¶32ï¼å³å¯å¨æ¯ææ¨ªæ2è½¬å¨ãçµå¨è«è¦31æ»å¨çä½ç¨ä¸ï¼å®ç°åæ¶32å¨å¹³é¢å

çå¯é ç§»å¨ãFigure 1 is a schematic perspective view of the present application. Referring to Figure 1, a plate lifting device includes a supporting longitudinal bar 1, a supporting horizontal bar 2 and a lifting mechanism 3. The supporting longitudinal bar 1 is fixed on the ground, and one end of the supporting horizontal bar 2 is hinged on the top of the supporting longitudinal bar 1. The other end of the support crossbar 2 rotates around the support longitudinal bar 1. The lifting mechanism 3 includes an electric hoist 31 and a hanger 32. The electric hoist 31 can reciprocate on the support crossbar 2 along the extension direction of the support crossbar 2. The electric hoist 31 A cable with a hook is wound around it, and the hanger 32 is hung on the hook. Under the traction of the electric hoist 31, the hanger 32 can reciprocate in the vertical direction (according to the weight of the board and the production budget, the electric hoist 31 can be used The hanger 32 is towed by other equipment, such as a hand chain hoist or a hoist, etc.). The hanger 32 is provided with a handle. When the hanger 32 is in a suspended state, hold the handle and push the hanger 32 in the horizontal plane. Under the action of the rotation of the support crossbar 2 and the sliding of the electric hoist 31, the hanger 32 can move reliably in the plane.

å¾2æ¯åæ¶çç¤ºææ§ç«ä½å¾ãåè§å¾2ï¼åæ¶32å

æ¬ä¸æ ¹ä¸»æ321åè³å°ä¸¤æ ¹å¯æ322ï¼å¤æ ¹å¯æ322è¿æ¥å¨ä¸»æ321çåºé¨ï¼æ¯æ ¹å¯æ322ä¸åå¥è®¾æä¸ä¸ªåå£å­åçåºå®å¡ä»¶6åä¸ä¸ªåå£å­åçæ´»å¨å¡ä»¶5ï¼ä¸åºå®å¡ä»¶6åæ´»å¨å¡ä»¶5åå«ä½äºä¸»æ321çä¸¤ä¾§ï¼åºå®å¡ä»¶6ä¸å¯æ322ä¹é´åºå®è¿æ¥ï¼æ´»å¨å¡ä»¶5çå¤å£ä¸è®¾æèºçº¹å­52ï¼èºçº¹å­52å

éé

å°æè®¾æèºæ53ï¼éè¿èºæ53å¯¹å¯æ322å¤å£çæµåä½ç¨åèºæ53ä¸èºçº¹å­52ä¹é´çèºçº¹è¿æ¥ä½ç¨ï¼å®ç°æ´»å¨å¡ä»¶5å¨å¯æ322ä¸çæ´»å¨è¿æ¥ãå¨æ´»å¨å¡ä»¶5ååºå®å¡ä»¶6çå¤å£ä¸åè®¾æä¸ä¸ªè¿æ¥æ51ï¼è¿æ¥æ51çåºé¨è®¾æåºå®å¸ç4ï¼å¤ä¸ªåºå®å¸ç4çåºé¨å¤äºåä¸æ°´å¹³é¢å

ï¼å³å¤ä¸ªåºå®å¸ç4çå®è£

é«åº¦ä¸è´ï¼ãå¨ä¸»æ321ä¸è®¾æè´åæ¯æ¶34åçç©ºæ³µ33ï¼è´åæ¯æ¶34å

è®¾æç©ºè

ï¼çç©ºæ³µ33ä¸ç©ºè

è¿éå¹¶å°ç©ºè

å

çç©ºæ°æ½åºèå½¢æè´ååºï¼å¤ä¸ªåºå®å¸ç4çå¤å£ä¸åè®¾ææ°ç®¡ï¼æ°ç®¡è¿éåºå®å¸ç4ä¸è´ååºï¼ä»èå¨åºå®å¸ç4å

å½¢æè´åãFigure 2 is a schematic perspective view of the hanger. Referring to Figure 2, the hanger 32 includes a main rod 321 and at least two auxiliary rods 322. A plurality of auxiliary rods 322 are connected to the bottom of the main rod 321, and each auxiliary rod 322 is provided with a mouth-shaped The fixed clamp 6 and a movable clamp 5 are in the shape of a mouth, and the fixed clamp 6 and the movable clamp 5 are respectively located on both sides of the main rod 321. The fixed clamp 6 and the auxiliary rod 322 are fixedly connected, and the movable clamp The outer wall of the component 5 is provided with a threaded hole 52, and a screw rod 53 is adaptedly screwed in the threaded hole 52. Through the pressing effect of the screw rod 53 on the outer wall of the auxiliary rod 322 and the threaded connection between the screw rod 53 and the threaded hole 52, The movable connection of the movable clamping member 5 on the auxiliary rod 322 is realized. A connecting rod 51 is provided on the outer walls of the movable clamp 5 and the fixed clamp 6. A fixed suction cup 4 is provided at the bottom of the connecting rod 51. The bottoms of the plurality of fixed suction cups 4 are in the same horizontal plane (that is, the plurality of fixed suction cups 4 The installation height is consistent). The main rod 321 is provided with a negative pressure bracket 34 and a vacuum pump 33. The negative pressure bracket 34 is provided with a cavity. The vacuum pump 33 is connected with the cavity and draws out the air in the cavity to form a negative pressure area. A plurality of fixed suction cups 4 There are air pipes on the outer walls of the air pipes, and the air pipes communicate with the fixed suction cup 4 and the negative pressure area, thereby forming a negative pressure in the fixed suction cup 4.

åè§å¾1åå¾2ï¼å½ç§»å¨åæ¶32çä½ç½®è³éè¦èµ·åçæ¿æä¸æ¹åï¼å¾®è°åæ¶32çä½ç½®ï¼ä½¿å¾åæ¶32ä¸åºå®å¸ç4è½å¤ååå°åå¸å¨æ¿æä¸ï¼ç¶åçµå¨è«è¦31ä¸æ¾åæ¶32ï¼ä½¿å¾åºå®å¸ç4ä¸æ¿åå¯é è´´åï¼å½çµå¨è«è¦31çç¼ç»³å¤äºæ¾å¼ç¶æåï¼çµå¨è«è¦31åæ­¢å¨ä½ï¼åæ¶ï¼çç©ºæ³µ33å¼å§è¿è½¬ï¼å°è´åæ¯æ¶34ãæ°ç®¡ååºå®å¸ç4å

çç©ºæ°æ½åºï¼å³å¯å®ç°åºå®å¸ç4å¯¹æ¿æçå¯é å¸åï¼ç¶åçµå¨è«è¦31åä¸æå¨åæ¶32ï¼è¿æ ·ï¼å¨å¤ä¸ªåååå¸çåºå®å¸ç4çå¸åä½ç¨ä¸ï¼æ¿æè½å¤è¢«å¯é å°åèµ·ï¼èä¸ï¼æ¯æçºµæ1çæ´ä½é«ä½è¾ä½ï¼ç¨äºåèµ·åæ¶32çç¼ç»³é¿åº¦ä¹è¾ä½ï¼è¿æ ·ï¼å¨æ¿æèµ·åå®æå¹¶è½¬ç§»çè¿ç¨ä¸­ï¼è½å¤æå¤§ç¨åº¦ä¸éä½æ¿æçæå¨å¹

åº¦ï¼ä¾¿äºå¯¹æ¿æçä½ç§»ç²¾åº¦è¿è¡ææ§ï¼è¿ä¸æ­¥çï¼éè¿å¸¦å¨æ¯ææ¨ªæ2è½¬å¨æ¥å®ç°æ¿æä½ç½®çè°æ´ï¼å

·æçåä¸æä½ç®åçç¹ç¹ï¼ä»

éè¿åäººå°±è½å¤å®ææä½ï¼ç¡®ä¿å·¥ä½æççåæ¶ï¼æé«äºæ´ä½çç»æµæçãReferring to Figures 1 and 2, after moving the position of the hanger 32 to above the plate that needs to be lifted, fine-tune the position of the hanger 32 so that the fixed suction cups 4 on the hanger 32 can be evenly distributed on the plate, and then lower the electric hoist 31 The hanger 32 makes the fixed suction cup 4 reliably fit the plate. When the cable of the electric hoist 31 is in a relaxed state, the electric hoist 31 stops moving. At the same time, the vacuum pump 33 starts to operate, and the negative pressure bracket 34, the trachea and the fixed suction cup 4 are By extracting the air, the fixed suction cups 4 can reliably attract the plate, and then the electric hoist 31 pulls the hanger 32 upward. In this way, under the suction action of multiple evenly distributed fixed suction cups 4, the plate can be reliably lifted. Moreover, the overall height of the supporting longitudinal bar 1 is relatively low, and the length of the cable used to lift the hanger 32 is also relatively low. In this way, when the plate is lifted and transferred, the shaking amplitude of the plate can be reduced to the greatest extent, which is convenient for The displacement accuracy of the plate is controlled, and further, the position of the plate is adjusted by driving the support crossbar 2 to rotate, which is labor-saving and simple to operate. The operation can be completed by only one person, ensuring work efficiency while improving the overall economic benefits.

å¾3æ¯æ´»å¨å¸ççè£

é

ç¶æç¤ºæå¾ï¼å¾4æ¯å¯æçå

é¨ç»æåè§å¾ãåè§å¾3åå¾4ï¼å¨å¯æ322ä¸è¿è®¾ææ´»å¨å¸ç7ï¼æ´»å¨å¸ç7ä½äºæ´»å¨å¡ä»¶5ä¸ä¸»æ321ä¹é´ï¼å³æ´»å¨å¸ç7çå®è£

ä½ç½®é è¿æ´»å¨å¡ä»¶5ï¼ï¼æ´»å¨å¸ç7çé¡¶é¨è®¾ææ¯ææ71ï¼æ¯ææ71æ²¿ç«ç´æ¹åç©¿è¿å¯æ322ï¼æ¯ææ71çä¸ç«¯ä½äºå¯æ322çä¸æ¹ä¸ä¸æ´»å¨å¸ç7è¿æ¥ï¼æ¯ææ71çå¦ä¸ç«¯ä½äºå¯æ322çä¸æ¹ä¸è¿æ¥æé¡¶æ¿95ï¼é¡¶æ¿95ä¸å¯æ322çå¤å£é¡¶é¨ä¹é´è®¾æå¤ä¸ªå¼¹ç°§96ï¼å¨æ¯ææ71çä¸­é¨è®¾ææ»å­710ï¼å¯æ322åç©ºå¿çç®¡ç¶ç»æï¼æ»å­710ä½äºå¯æ322çå

ä¾§ï¼å¯æ322ä¸è®¾ææ¥å½¢å8åæ¥å½¢å8çé©±å¨æºæ9ï¼æ¥å½¢å8çåºé¨ä¸å¯æ322çå

å£åºé¨è´´åï¼æ¥å½¢å8çæé¢ï¼å³æ¥å½¢å8çé¡¶é¨ï¼ä¸æ»å­710çå

å£é¡¶é¨è´´åï¼èæ¥å½¢å8çæé¢çå®½åº¦è¿å¤§äºæ»å­710çå

å£é¡¶é¨çå®½åº¦ï¼ä¸æ»å­710çå­å¾å¤§äºæ¥å½¢å8çæå°ååº¦å¹¶å°äºæ¥å½¢å8çæå¤§ååº¦ï¼è¿æ ·ï¼æ¥å½¢å8å¨é©±å¨æºæ9çé©±å¨ä¸å°±è½å¤å¨æ»å­710çæ»å¨ãFigure 3 is a schematic diagram of the assembly state of the movable suction cup, and Figure 4 is a cross-sectional view of the internal structure of the auxiliary rod. Referring to Figures 3 and 4, a movable suction cup 7 is also provided on the auxiliary rod 322. The movable suction cup 7 is located between the movable clamp 5 and the main rod 321 (that is, the movable sucker 7 is installed close to the movable clamp 5). 7 is provided with a support rod 71 at the top. The support rod 71 passes through the auxiliary rod 322 in the vertical direction. One end of the support rod 71 is located below the auxiliary rod 322 and is connected to the movable suction cup 7. The other end of the support rod 71 is located at the auxiliary rod 322. A top plate 95 is connected to the top of the support rod 71. A plurality of springs 96 are provided between the top plate 95 and the top of the outer wall of the auxiliary rod 322. A sliding hole 710 is provided in the middle of the support rod 71. The auxiliary rod 322 has a hollow tubular structure, and the sliding hole 710 Located inside the auxiliary rod 322, the auxiliary rod 322 is provided with a wedge block 8 and a driving mechanism 9 of the wedge block 8. The bottom of the wedge block 8 is in contact with the bottom of the inner wall of the auxiliary rod 322. The slope of the wedge block 8 (ie, the wedge block 8 The top of the sliding hole 710 fits the top of the inner wall of the sliding hole 710 , and the width of the slope of the wedge block 8 is much larger than the width of the top of the inner wall of the sliding hole 710 , and the aperture of the sliding hole 710 is larger than the minimum thickness of the wedge block 8 and smaller than the wedge block 8 The maximum thickness is such that the wedge block 8 can slide in the sliding hole 710 under the driving of the driving mechanism 9 .

åè§å¾4ï¼é©±å¨æºæ9å

æ¬å¥ç®¡91ãä¸æ92åè½¬ç97ï¼å¥ç®¡91ä¸å¯æ322çå

å£åºå®è¿æ¥ï¼å¥ç®¡91çå

å£ä¸è®¾æå

èºçº¹ï¼ä¸æ92ä¸å¥ç®¡91ä¹é´éè¿èºçº¹è¿æ¥ï¼ä¸æ92çä¸ç«¯ä½äºå¯æ322çå¤ä¾§ä¸ä¸è½¬ç97åè½´è¿æ¥ï¼ä¸æ92çå¦ä¸ç«¯ç©¿è¿å¥ç®¡91åä¸è¿æ¥å93è¿æ¥ï¼è¿æ¥å93è®¾äºæ¥å½¢å8çä¾§å£ä¸ï¼è¿æ¥å93ä¸è®¾æè½´æ¿94ï¼è½´æ¿94çå¤åä¸è¿æ¥å93è¿æ¥ï¼è½´æ¿94çå

åä¸ä¸æ92ä¹é´è¿çé

åï¼è¿æ ·ï¼å¨è½¬å¨è½¬ç97æ¶ï¼ä¸æ92ä¼éä¹è½¬å¨ï¼èä¸æ92ä¸å¥ç®¡91ä¹é´èºçº¹è¿æ¥ä¸å¥ç®¡91çä½ç½®åºå®ï¼ä½¿å¾ä¸æ92å¨è½¬å¨çåæ¶ï¼è¿ä¼äº§çæ°´å¹³æ¹åçä½ç§»ï¼å¨ä¸æ92è½¬å¨å¹¶æ°´å¹³ä½ç§»çè¿ç¨ä¸­ï¼å¹¶å¨è½´æ¿94çè¿æ¥ä½ç¨ä¸ï¼è¿æ¥å93åæ¥å½¢å8ä¼äº§çæ°´å¹³ä½ç§»ä¸ä¸ä¼è½¬å¨ï¼ä¹å°±æ¯è¯´ï¼å¨è½¬å¨è½¬ç97åï¼è½å¤å®ç°æ¥å½¢å8å¨å¯æ322å

çæ°´å¹³æ¹åçå¾å¤ä½ç§»ãReferring to Figure 4, the driving mechanism 9 includes a sleeve 91, a screw rod 92 and a turntable 97. The sleeve 91 is fixedly connected to the inner wall of the auxiliary rod 322. The inner wall of the sleeve 91 is provided with internal threads. The connection between the screw rod 92 and the sleeve 91 are connected through threads. One end of the screw rod 92 is located outside the auxiliary rod 322 and is coaxially connected to the turntable 97. The other end of the screw rod 92 passes through the sleeve 91 and is connected to the connecting block 93. The connecting block 93 is located on the wedge block 8 On the side wall, a bearing 94 is provided on the connecting block 93. The outer ring of the bearing 94 is connected to the connecting block 93. There is an interference fit between the inner ring of the bearing 94 and the screw rod 92. In this way, when the turntable 97 is rotated, the screw rod 92 will rotate accordingly, and the threaded connection between the screw rod 92 and the sleeve 91 and the position of the sleeve 91 is fixed, so that when the screw rod 92 rotates, it will also produce horizontal displacement. When the screw rod 92 rotates and becomes horizontal During the displacement process, and under the connection of the bearing 94, the connecting block 93 and the wedge block 8 will produce horizontal displacement and will not rotate. That is to say, after the turntable 97 is rotated, the wedge block 8 can be positioned in the auxiliary rod 322 horizontal reciprocating displacement.

å½æ¥å½¢å8æç»­åæ»å­710å

æå

¥æ¶ï¼æ»å­710çå

å£é¡¶é¨ä¸æ¥å½¢å8çæé¢ä¹é´çè·ç¦»ä¼éæ¸éä½ï¼è¿æ ·ï¼å°±ä¼å°æ¯ææ71åä¸é¡¶èµ·ï¼è¿èå¸¦å¨æ´»å¨å¸ç7åé«ï¼å¼¹ç°§96ä¼å¤äºæä¼¸çç¶æï¼å½æ¥å½¢å8æç»­ç±æ»å­710å

æåºæ¶ï¼æ»å­710çå

å£é¡¶é¨ä¸æ¥å½¢å8çæé¢ä¹é´çè·ç¦»ä¼éæ¸åå¤§ï¼æ¯ææ71å°±ä¼å¨èªèº«éåä½ç¨åå¼¹ç°§96åç¼©æåçä½ç¨ä¸ï¼æ¯ææ71å°±ä¼åä¸è¿å¨ï¼è¿èå¸¦å¨æ´»å¨å¸ç7ä¸éï¼è¿æ ·ï¼éè¿æ¥å½¢å8ä¸æ¯ææ71çæ»å­710ä¹é´çç¸äºä½ç¨ï¼è½å¤å®ç°æ´»å¨å¸ç7çé«åº¦çè°æ´ï¼å½æ¿æçé¢ç§¯åééè¾å°æ¶ï¼æ´»å¨å¸ç7çé«åº¦ä¼é«äºåºå®å¸ç4çé«åº¦ï¼éä½çç©ºæ³µ33çå·¥ä½è´æ

ï¼å½æ¿æçé¢ç§¯åééè¾å¤§æ¶ï¼æ´»å¨å¸ç7çé«åº¦ä¸åºå®å¸ç4çé«åº¦ä¸è´ï¼ä½¿å¾æ´»å¨å¸ç7ååºå®å¸ç4è½å¤åæ¶å¯¹æ¿æè¿è¡å¸åä¸æåï¼è½å¤æé«å¯¹æ¿æèµ·åçç¨³å®æ§ï¼é²æ­¢æ¿æè±è½ãæ´»å¨å¸ç7ä¸è´åæ¯æ¶34ä¹éè¿æ°ç®¡è¿éï¼å¨æ´»å¨å¸ç7çæ°ç®¡ä¸è®¾ç½®çµç£éï¼å¨æ´»å¨å¸ç7å¤äºæ¬ç©ºç¶æï¼å³æ´»å¨å¸ç7çé«åº¦é«äºåºå®å¸ç4çé«åº¦ï¼æ´»å¨å¸ç7ä¸åä¸æ¿æçå¸åï¼æ¶ï¼æ´»å¨å¸ç7ä¸è´åæ¯æ¶34çè¿éè¢«æªæ­ï¼é²æ­¢å ä¸ºæ´»å¨å¸ç7çåé«èå¯¼è´çåºå®å¸ç4å¤äºçè´åææè¢«ç ´åï¼ä¹å°±æ¯è¯´ï¼æ´»å¨å¸ç7çåéä¸ä¼å¯¹åºå®å¸ç4å¯¹æ¿æçå¸åä½ç¨äº§çå½±åãå½æ´»å¨å¸ç7å¤äºæ¬ç©ºç¶ææ¶ï¼æ´»å¨å¸ç7é è¿æ´»å¨å¡ä»¶5ä¸çåºå®å¸ç4ï¼è¿æ ·ï¼å½è½¬å¨è½¬ç97å®ç°æ´»å¨å¸ç7ä¸æ´»å¨å¡ä»¶5ä¸çåºå®å¸ç4çä½ç½®è°æ´åï¼åä¸å¯æ322ä¸çåºå®å¡ä»¶6ä¸çåºå®å¸ç4ãæ´»å¨å¸ç7ä¸æ´»å¨å¡ä»¶5ä¸çåºå®å¸ç4ä¹é´çé´è·æ¥è¿æç¸åï¼ä»èç¡®ä¿å¤ä¸ªåºå®å¸ç4ä¸æ´»å¨å¸ç7å¨æ¿æä¸åå¸çååæ§ï¼ç¡®ä¿æ¿æè½å¤ä»¥å¹³ç¨³çå§¿æè¢«åèµ·å¹¶äº§çä½ç½®ç§»å¨ãWhen the wedge block 8 continues to be inserted into the sliding hole 710 , the distance between the top of the inner wall of the sliding hole 710 and the slope of the wedge block 8 will gradually decrease. In this way, the support rod 71 will be pushed upward, thereby driving the movable suction cup 7 when the wedge block 8 continues to be pulled out from the sliding hole 710, the distance between the top of the inner wall of the sliding hole 710 and the slope of the wedge block 8 will gradually become larger, and the support rod 71 Under the action of its own gravity and the retraction force of the spring 96, the support rod 71 will move downward, thereby driving the movable suction cup 7 to descend. In this way, through the interaction between the wedge block 8 and the sliding hole 710 of the support rod 71, Function, the height of the movable suction cup 7 can be adjusted. When the area and weight of the board are small, the height of the movable suction cup 7 will be higher than the height of the fixed suction cup 4, reducing the work load of the vacuum pump 33. When the area and weight of the board are large, At this time, the height of the movable suction cup 7 is consistent with the height of the fixed suction cup 4, so that the movable suction cup 7 and the fixed suction cup 4 can suck and lift the board at the same time, which can improve the stability of lifting the board and prevent the board from falling off. The movable suction cup 7 and the negative pressure bracket 34 are also connected through the trachea. A solenoid valve is set on the trachea of the movable suction cup 7. When the movable suction cup 7 is in a suspended state (that is, the height of the movable suction cup 7 is higher than the height of the fixed suction cup 4, the movable suction cup 7 does not When participating in the suction of the board), the connection between the movable suction cup 7 and the negative pressure bracket 34 is cut off to prevent the negative pressure effect of the fixed suction cup 4 from being destroyed due to the rise of the movable suction cup 7. In other words, the movable suction cup 7 The lifting and lowering will not affect the suction effect of the fixed suction cup 4 on the plate. When the movable suction cup 7 is in the suspended state, the movable suction cup 7 is close to the fixed suction cup 4 on the movable clamp 5. In this way, when the turntable 97 is rotated to adjust the positions of the movable suction cup 7 and the fixed suction cup 4 on the movable clamp 5, the same pair The distance between the fixed suction cups 4 and the movable suction cups 7 on the fixed clamp 6 on the rod 322 and the fixed suction cups 4 on the movable clamp 5 are close to or the same, thereby ensuring that multiple fixed suction cups 4 and movable suction cups 7 are distributed on the plate. The uniformity ensures that the board can be lifted in a stable manner and move in position.

å¾5æ¯è½¬çä¸ä¸æçè£

é

ç¶æç¤ºæå¾ï¼å¾6æ¯è½¬ççå

é¨ç»æåè§å¾ãåè§å¾5åå¾6å¹¶ç»åå¾4ï¼è½¬ç97æåæ´»å¨å¡ä»¶5çä¸ä¾§è®¾æå¡æ§½971ï¼å¡æ§½971çæªé¢åå¸å­å½¢ï¼å¡æ§½971å

è®¾ææ»å972ï¼æ»å972å¯ä»¥å¨å¡æ§½971å

è¿è¡å¨åçæ»å¨ä½æ æ³è¿è¡è½´åçä½ç§»ï¼æ»å972ä¸æ´»å¨å¡ä»¶5ä¹é´éè¿ææ54è¿æ¥ï¼å¨è½¬ç97è½¬å¨å¹¶æ°´å¹³ä½ç§»çè¿ç¨ä¸­ï¼æ»å972ä¼å¨å¡æ§½971å

æ»å¨ä¸ä¼å¯¹ææ54å½¢ææå¨ä½ç¨ï¼ä¹å°±ä½¿å¾ææ54è½å¤éè½¬ç97äº§çåæ­¥çæ°´å¹³ä½ç§»ï¼è¿èå®ç°æ´»å¨å¡ä»¶5å¨å¯æ322ä¸ä½ç½®çè°æ´ï¼ä¹å°±å®ç°äºæ´»å¨å¡ä»¶5ä¸çåºå®å¸ç4çä½ç½®çè°æ´ï¼ä½¿å¾æ´»å¨å¸ç7é«åº¦çè°æ´ä¸æ´»å¨å¡ä»¶5ä¸çåºå®å¸ç4æ°´å¹³ä½ç½®çè°æ´å½¢æèå¨ï¼å½æ´»å¨å¸ç7ä¸éãåå¤è¿è¡æ¿æå¸åæ¶ï¼æ´»å¨å¡ä»¶5ä¸çåºå®å¸ç4ä¼æåè¿ç¦»æ´»å¨å¸ç7çæ¹åç§»å¨ï¼è¿æ ·ï¼ä½¿å¾æ¿æçå°ºå¯¸åçåååï¼åºå®å¸ç4åæ´»å¨å¸ç7è½å¤éä¹æ¹ååå¸å¯åº¦ï¼è½å¤ä»¥æ´å åè¡¡å°ç¶æå¯¹æ¿æè¿è¡å¸åï¼ä¸å¨èå¨ä½ç¨ä¸ææéä½æä½é¾åº¦ï¼è½å¤å®ç°æ´»å¨å¸ç7ä¸åºå®å¸ç4ç¸å¯¹ä½ç½®çå¿«éè°æ´ï¼æé«äºå·¥ä½æçãFigure 5 is a schematic diagram of the assembly state of the turntable and the screw rod, and Figure 6 is a cross-sectional view of the internal structure of the turntable. Referring to Figures 5 and 6 and combined with Figure 4, the turntable 97 is provided with a slot 971 on the side facing the movable clamping member 5. The cross section of the slot 971 is convex. A slider 972 is provided in the slot 971. The slider 972 can The sliding block 972 can slide circumferentially in the slot 971 but cannot move axially. The sliding block 972 and the movable clamping member 5 are connected through the tie rod 54. When the turntable 97 rotates and moves horizontally, the sliding block 972 will slide in the clamping groove 971. The groove 971 slides and exerts a pulling effect on the pull rod 54, which enables the pull rod 54 to produce synchronous horizontal displacement with the turntable 97, thereby realizing the adjustment of the position of the movable clamp 5 on the auxiliary rod 322, thus realizing the movable clamp The adjustment of the position of the fixed suction cup 4 on 5 causes the adjustment of the height of the movable suction cup 7 to be linked with the adjustment of the horizontal position of the fixed suction cup 4 on the movable clamp 5. When the movable suction cup 7 is lowered and is ready for plate suction, the movable suction cup 7 The fixed suction cup 4 on the component 5 will move in a direction away from the movable suction cup 7. In this way, after the size of the board changes, the fixed suction cup 4 and the movable suction cup 7 can change the distribution density accordingly, and the board can be processed in a more balanced state. It can be sucked together, and the operation difficulty is effectively reduced under the linkage action, and the relative positions of the movable suction cup 7 and the fixed suction cup 4 can be quickly adjusted, thereby improving work efficiency.

ä»¥ä¸åä¸ºæ¬ç³è¯·çè¾ä½³å®æ½ä¾ï¼å¹¶éä¾æ­¤éå¶æ¬ç³è¯·çä¿æ¤èå´ï¼æ

ï¼å¡ä¾æ¬ç³è¯·çç»æãå½¢ç¶ãåçæåçç­æååï¼ååºæ¶µçäºæ¬ç³è¯·çä¿æ¤èå´ä¹å

ãThe above are all preferred embodiments of the present application, and do not limit the scope of protection of the present application. Therefore, any equivalent changes made based on the structure, shape, and principle of the present application shall be covered by the protection scope of the present application. Inside.

## Classifications

- B66C23/027
- B66C1/02
- B66C1/0243
- B66C1/0256
- B66C11/06
- B66C11/06
- B66C13/06
- B66C13/06
- B66C23/02
- B66C23/16
- B66C23/16

## Cited patent documents

- [CN-110668297-A](https://patents.google.com/patent/CN110668297A/en) — SEA
- [CN-205532738-U](https://patents.google.com/patent/CN205532738U/en) — SEA
- [CN-210550617-U](https://patents.google.com/patent/CN210550617U/en) — SEA
- [CN-216549318-U](https://patents.google.com/patent/CN216549318U/en) — SEA
- [KR-20220168656-A](https://patents.google.com/patent/KR20220168656A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
