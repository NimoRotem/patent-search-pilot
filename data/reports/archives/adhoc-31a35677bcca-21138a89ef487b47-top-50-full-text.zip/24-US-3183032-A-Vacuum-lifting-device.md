# 24. Vacuum lifting device

- **Archive rank:** 24 of 50
- **Publication:** [US-3183032-A](https://patents.google.com/patent/US3183032A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/023214238/publication/US3183032A?q=pn%3DUS3183032A)
- **Publication date:** 1965-05-11
- **Filing date:** 1963-10-01
- **Earliest priority:** 1963-10-01
- **Family:** 23214238
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** BANBURY EQUIPMENT CORP
- **Inventors:** WARFEL RICHARD M

## Abstract

_No abstract was available from the queried sources._

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-3183032-A/000.png)

![Sketch 1 for US-3183032-A](https://nimo.iptorch.com/refdrawing/US-3183032-A/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/US-3183032-A/001.png)

![Sketch 2 for US-3183032-A](https://nimo.iptorch.com/refdrawing/US-3183032-A/001.png)

## Claims

### Claim 1 (independent)

A VACUUM LIFTING DEVICE COMPRISING A HORIZONTAL FLEXIBLE PAD PROVIDED WITH A SURROUNDING DEPENDING LIP, SAID PAD BEING PROVIDED WITH A PLURALITY OF VERTICAL OPENINGS, A SEPARATE METAL BOTTOM PLATE ENGAGING THE BOTTOM OF THE PAD AROUND EACH OPENING, THE PLATES HAVING OUTER EDGES ADJACENT THE UPPER PORTIONS OF SAID LIP, THE PLATES BEING SPACED A SHORT DISTANCE APART TO PROVIDE NARROW GAPS BETWEEN THEIR INNER EDGES, A METAL TOP PLATE SEATED ON SAID PAD ABOVE EACH BOTTOM PLATE AND PROVIDED WITH AN OPENING REGISTERING WITH THE UNDERLYING PAD OPENING, THE TOP PLATES BEING SEPARATED BY NARROW GAPS DIRECTLY ABOVE SAID FIRST-MENTIONED GAPS, FASTENERS EXTENDING THROUGH THE TOP PLATES AND PAD AROUND EACH OPENING AND INTO THE BOTTOM PLATES FOR CLAMPING THE PAD BETWEEN THE TOP AND BOTTOM PLATES, SUSPENSION MEANS EXTENDING THROUGH EACH PAD OPENING AND CONNECTED TO THE TOP OF THE UNDERLYING BOTTOM PLATE, AND A VERTICALLY MOVABLE COMMON SUPPORT ABOVE THE TOP PLATES FOR ALL OF SAID SUSPENSION MEANS, SAID SUSPENSION MEANS BEING FORMED TO PERMIT TILTING OF ANY BOTTOM PLATE RELATIVE TO THE OTHER BOTTOM PLATES.

## Full description

**[p0001]**

May 11, 1965 R. M. WARFEL VACUUM LIFTING DEVICE 2 Sheets-Sheet 1 Filed Oct. 1, 1963 INVENTOR. 1 0/6/1420 MMMRFEL. ATTORNEKS. y 1965 R. M. WARFEL 3,183,032 VACUUM LIFTING DEVICE Filed Oct. 1, 1963 2 Sheets-Sheet 2 INVENTOR. P/Cl/AIQD M. WAR/ 51. ATTORNEYS. United States Patent s,1ss,032 VACUUM LIFTING DEVICE Richard M. Warfel, Pittsburgh, Pa, assignor to Banbury Equipment Corporation, Pittsburgh, Pa., 21 corporation of Pennsylvania Filed Oct. 1, 1963, Ser. No. 313,066 9 Claims. (Cl. 294-65) This invention relates to vacuum lifting devices, and more particularly to those used for lifting flexible sheets and plates. In shifting plates and sheets, usually of metal, from one location to another it is common practice to lift them by apparatus provided with one or more vacuum pads, from which air is exhausted to attach the pads to the sheets. When the sheets are flexible, they will bend as they are lifted and this often places so much strain on the lips of the pads as to cause inward leakage of air around the edges of the pads, whereupon the sheets will be released.

**[p0002]**

It is among the objects of this invention to provide a lifting device in which the vacuum pads can flex vertically to accommodate themselves to uneven surfaces or to help hold the pads in contact with sheets that bend as they are lifted. The preferred embodiment of the invention is illustrated in the accompanying drawings, in which FIG. 1 is a plan view of a single lifting device; FIG. 2 is a combined side view and vertical section taken on the line III&#39;I of FIG. 1; FIG. 3 is a fragmentary horizontal section taken on the line IIIIII of FIG. 2; and FIG. 4 is a fragmentary bottom view taken on the line IVIV of FIG. 2. Referring to the drawings, there is shown only one of what may be several vacuum lifting devices forming part of a single machine. The most important part of the lifting device is the fiexile pad 1 of rubber or the like that engages the work. The pad will be described as horizontal, which is the position it generally occupies. It may be any desired shape, the pad illustrated being square with rounded corners. Surrounding the pad and integral with it is a depending lip 2 that flares downwardly. The pad therefore resembles a very shallow inverted cup, except that it is provided with a number of vertical openings 3. With a square pad, four openings are suflicient and they also may be square. The openings are spaced uniform distances apart and from the center of the pad.

**[p0003]**

In accordance with this invention, the pad is supported from beneath by a plurality of bottom plates 5, as shown in FIGS. 2 and 4, each of which engages the bottom of the pad around one of its openings. Therefore, there are four bottom plates. The plates are square and the two outer edges of each one are located adjacent to, and preferably in contact with, the upper portion of the surrounding lip 2. The two inner edges of each plate, which likewise are perpendicular to each other, are spaced a short distance from the adjacent innet edges of the plates next to them, whereby to form between the plates narrow gaps that radiate from the center of the pad. Seated on the pad above each bottom plate is a top plate 7 of the same general shape as the bottom plates, as shown in FIGS. 2 and 3. Each top plate is provided with an opening 8 registering with the underlying pad opening 3. Like the bottom plates, the top plates are separated to form radiating narrow gaps directly above the gaps between the bottom plates. Preferably, the top plates project outward from the pad beyond its lip. The top and bottom pads clamp the pad between them. For

**[p0004]**

ice this purpose, fasteners extend through the top plates and pad around each opening and are secured to the bottom plates. A suitable way of doing this is to screw the lower ends of set screws 10 into threaded openings in each bottom plate around the pad opening above it and to provide the pad and the overlying top plate with holes, up through which the screws extend. Lock nuts &#39;11 on the upper ends of the screws are turned down against the top plates so that the pad will be clamped between them and the bottom plate. The pad and plates are suspended from a support above them. As shown in FIGS. 1 and 2, this support may be a reinforced metal plate 13, to the center of which the lower end of a post 14 is flexibly connected. The upper end of the post, along with similar posts from other pads in the group, is connected to apparatus (not shown) that rises and descends and travels laterally to transport Work from one location to another. The suspension means, by which the pad is suspended from the common support 13, extend through the top plate and pad openings and are connected to the tops of the bottom plates. The suspension means are formed to permit tilting of any bottom plate relative to the other bottom plates. Preferably, as shown in FIG. 2, each suspension means includes a vertical rod 15 slidably mounted in a hole in plate 13 above a pad opening. A nut 16 screwed on the upper end of the rod supports it. The lower end of the rod is rigidly mounted in a ball 17 that fits in a socket 18 mounted on the underlying bottom plate. In order that the pad will firmly engage th

**[p0004]**

e Work when support 13 is lowered, coil springs 19 encircle the vertical rods to urge the pad down away from the support. Each spring is seated on a collar 20 welded to the encircled rod a short distance above the underlying socket 18. The pressure of the springs against these collars urges the pad downwardly. One of the bottom plates 5 is provided with a small hole 21, into which is screwed a nipple 22 that is connected by a flexible hose 23 to a suitable source of vacuum for evacuating the space between the pad and the sheets or plates that it engages.

**[p0005]**

It will be seen that if the pad engages an uneven surface or if it picks up a sheet that bends, any one or more of the bottom plates can tilt relative to the other bottom plates to enable the pad to accommodate itself to the curvature of the Work. Of course, the top plates tilt with the bottom plates. Flexing of the pad takes place in the gaps between the plates, where the exposed strips of the pad hinge the plates together. The pad may be reinforced in these gaps to strengthen it by providing either its upper or lower surface, or both, with integral ribs 24 extending along the gaps. Another feature of this invention is that the pad and suspension means are protected from damage and the pad is guided into proper position for engagement with the work. For these purposes a guard member surrounds the pad and is suspended from support plate 13. The guard member has a rim 25 that surrounds the pad and normally extends below it as shown in FIG. 2. The rim is suspended by a number of vertical bars 26 provided with vertical slots 27, through the upper ends of which extend studs 28 that are screwed into blocks 29 welded onto the bottom of plate 13 at its edge. Since this lifting device is very heavy and often swings as it is lowered, to prevent the bottom of the guard from ma-rring the work the rim may be provided at its corners, or all around, with downwardly extending cushioning strips 30 formed of a suitable non-marring material, such as a plastic.

**[p0006]**

When the lifting device is lowered toward the work it may be swinging, but as soon as the guard cushions engage the -work the swinging will be stopped by then and so the pad will move straight down against the work with- 3 out moving sideways, which would be likely to curl lip 2 under the pad. The slotted bars then permit the pad to move downwardly in the stationary guard resting on the work. Also, the guard prevents the pad and the members attached to it from striking other elements that might cause damage. It will be obvious that if a rectangular pad is used, the plates may extend across it and be spaced apart lengthwise of the pad so that the gaps between them will be parallel and transverse to the pad. According to the provisions of the patent statutes, I have explained the principle of my invention and have illustrated and described what I now consider to represent its best embodiment. However, I desire to have it understood that, within the scope of the appended claims, the invention may be practiced otherwise than as specifically illustrated and described.

**[p0007]**

I claim: 1. A vacuum lifting device comprising a horizontal flexible pad provided with a surrounding depending lip, said pad being provided with a plurality of vertical openings, a separate metal bottom plate engaging the bottom of the pad around each opening, the plates having outer edges adjacent the upper portions of said lip, the plates being spaced a short distance apart to provide narrow gaps between their inner edges, a metal top plate seated on said pad above each bottom plate and provided with an opening registering with the underlying pad opening, the top plates being separated by narrow gaps directly above said first-mentioned gaps, fasteners extending through the top plates and pad around each opening and into the bottom plates for clamping the pad between the top and bottom plates, suspension means extending through each pad opening and connected to the top of the underlying bottom plate, and a vertically movable common support above the top plates for all of said suspension means, said suspension means being formed to permit tilting of any bottom plate relative to the other bottom plates.

**[p0008]**

2. A vacuum lifting device according to claim 1, in which said pad is provided with integral ribs extending along said gaps at one side of the pad. 3. A vacuum lifting device according to claim 1, in which said suspension means include ball and socket joints. 4. A vacuum lifting device according to claim 1, in which said common support is provided with vertical holes, and said suspension means include vertical rods slidingly mounted in said holes, flexible joints connecting the lower ends of the rods to said bottom plates, and coil springs encircling the rods and urging the pad away from the common support. 15. A vacuum lifting device according to claim 1, including a guard member surrounding the pad and normally extending below it, said member being provided with vertical slots extending above the pad, and studs extending through the upper ends of the slots and into said common support to support the guard member. 6. A vacuum lifting device according to claim 5, including cushioning means carried by said guard member and projecting below it.

**[p0009]**

7. A vacuum lifting device comprising a horizontal flexible pad provided with a surrounding depending lip, said pad being provided with a plurality of vertical openings spaced uniformly from its center, a separate metal bottom plate engaging the bottom of the pad around each opening, the plates having outer edges adjacent the upper portions of said lip, the plates being spaced a short distance apart along lines radiating from said center to provide narrow gaps between their inner edges, 2. metal top plate seated on said pad above each bottom plate and provided with an opening registering with the underlying pad opening, the top plates being separated by radiating narrow gaps directly above said first-mentioned gaps, fasteners extending through the top plates and pad around each opening and into the bottom plates for clamping the pad between the top and bottom plates, suspension means extending through each pad opening and connected to the top of the underlying bottom plate, and a vertically movable common support above the top plates for all of said suspension means, said suspension means being formed to permit tilting of any bottom plate relative to the other bottom plates.

**[p0010]**

8. A vacuum lifting device according to claim 7, in which there are four of said bottom plates and -four of said top plates, and the gaps between the plates in each group intersect one another at right angles. 9. A vacuum lifting device comprising a horizontal flexible pad provided with a surrounding depending lip, a plurality of metal plates tightly engaging the pad to form stiffened areas of the pad, said plates having outer edges adjacent said lip, the plates being spaced at short distance apart horizontally to provide narrow gaps between their inner edges, individual suspension means for each of said stiffened areas, and a vertically movable common support for all of said suspension means spaced above the pad, said suspension means being formed to permit tilting of any of said stiffened areas relative to the other stiffened areas. References Cited by the Examiner FOREIGN PATENTS 757,878 10/33 France. SAMUEL F. COLEMAN, Primary Examiner,

## Figure captions

- **Figure 1:** The preferred embodiment of the invention is illustrated in the accompanying drawings, in which FIG. 1 is a plan view of a single lifting device;
- **Figure 2:** FIG. 2 is a combined side view and vertical section taken on the line III&#39;I of FIG. 1;
- **Figure 3:** FIG. 3 is a fragmentary horizontal section taken on the line IIIIII of FIG. 2; and
- **Figure 4:** FIG. 4 is a fragmentary bottom view taken on the line IVIV of FIG. 2.

## Classifications

- B66C1/0281
- B66C1/0281
- B66C1/02
- B66C1/0231
- B66C1/0231
- B66C1/0293
- B66C1/0293

## Cited patent documents

- [FR-757878-A](https://patents.google.com/patent/FR757878A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
