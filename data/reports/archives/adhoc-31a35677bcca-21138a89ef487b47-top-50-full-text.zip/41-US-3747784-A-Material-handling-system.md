# 41. Material handling system

- **Archive rank:** 41 of 50
- **Publication:** [US-3747784-A](https://patents.google.com/patent/US3747784A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/022881769/publication/US3747784A?q=pn%3DUS3747784A)
- **Publication date:** 1973-07-24
- **Filing date:** 1972-03-14
- **Earliest priority:** 1972-03-14
- **Family:** 22881769
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** DEAN RES CORP
- **Inventors:** DEAN G

## Abstract

An improved material handling system is provided in which a head adapted to lift one or more sheets of material is provided with a pair of plates for engaging both sides of the stack of material to be lifted. One of the plates is movable about a pivot to engage one side of the stack. Means for applying positive pressure to the movable plate on one side of the pivot is provided along with means for applying negative pressure between the plates on the other side of the pivot to both clamp and lift the stacked material.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-3747784-A/000.png)

![Sketch 1 for US-3747784-A](https://nimo.iptorch.com/refdrawing/US-3747784-A/000.png)

## Claims

### Claim 1 (independent)

A material handling head for lifting sheet material comprising a back plate, a top plate and a pair of end plates, a pivot mounted on said back plate, said pivot traversing the entire length of said back plate, a movable plate mounted on said pivot, said movable plate having a first leg extending above said pivot toward said top plate to define a first chamber comprising said end plates, top plate, back plate and pivot, and a second leg extending below said pivot to define a second chamber comprising said end plates, back plate, pivot and the said sheet material, means for applying gas under pressure to said first chamber to urge the movable plate to rotate about said pivot to bring the said second leg into contact with said sheet material, and means to apply a vacuum force to said second chamber to provide additional force to maintain said sheet material within the material handling head when said head is moved.

### Claim 2

The material handling head according to claim 1 further comprising means for sealing said first chamber against pressure leakage.

### Claim 3

The material handling head according to claim 2 wherein the sealing means comprises a wiper seal, a recess in said first leg for receiving said wiper seal, said top being curved adjacent said first leg such that the said wiper seal remains in wiping contact with said top plate during movement of said movable plate.

### Claim 4

The material handling head according to claim 2 further comprising a pair of end seals, said end seals being placed on said end plates such that said end seals contact said sheet material when the head is moved into position.

### Claim 5 (independent)

The method of lifting sheet material with a material handling head of the type having a first and second chamber, the first utilizing the sheet material as a closure for the chamber, said head having a back plate and a movable plate pivotally mounted on said back plate, said chambers lying to either side of said pivot and being defined by said back plate, and said movable plate, comprising the steps of: moving said head to position said back plate and said movable plate about said sheet material, applying gas under pressure to said second chamber to urge said movable plate to pivot to clamp said sheet material, and applying a negative pressure to said first chamber to enhance the clamping force to permit said sheet material to be moved by said head, and moving said head to move the clamped sheet material.

## Full description

**[p0001]**

United States Patent [191 Dean [ MATERIAL HANDLING SYSTEM [75] Inventor: George A. Dean, Kansas City, Mo. [73] Assignee: Dean Research Corporation, Kansas City, Mo. [22] Filed: Mar. 14, 1972 [21] Appl. No.: 234,534 [52] U.S. Cl. 214/152, 214/1 BS, 294/64, 294/88, 294/104 [51] Int. Cl. 1366c 1/02 [58] Field of Search 294/88, 104, 64; 21411 B, 1 BS, 152 [56] References Cited UNITED STATES PATENTS 2,870,556 1/1969 Riddell 294/88 X 14 1 July 24,1973 3,056,625 10/1962 Timmerman 294/88 X Primary Examiner-Gerald M. Forlenza Assistant Examiner-George F. Abraham Attorney-Jordan B. Bierman et a1. [57] ABSTRACT An improved material handling system is provided in which a head adapted to lift one or more sheets of material is provided with a pair of plates for engaging both sides of the stack of material to be lifted. One of the plates is movable about a pivot to engage one side of the stack. Means for applying positive pressure to the movable plate on one side of the pivot is provided along with means for applying negative pressure between the plates on the other side of the pivot to both clamp and lift the stacked material.

**[p0002]**

5 Claims, 3 Drawing Figures MATERIAL HANDLING SYSTEM This invention relates to improvements in material handling systems, and more particularly to improvements in those systems requiring the lifting of a stack of sheet material for transport between a first and second point. Apparatus for lifting stacks of sheet material is known to the art, as embodied in U. S. Pat. No. 3,411,641, issued to the instant applicant on Nov. 19, 1968. As shown and described in this patent, a material handling head adapted to engage the edges of a stack of sheet material is provided in which suction is applied to a chamber located within the head and defined by the head on three sides and the sheet material on the fourth. After the sheet material has been gripped by the material handling head a vacuum is supplied to the chamber to maintain the sheet material within the head for transport. This system is sufficient for most purposes. However, there are times when the sheer weight of the stack to be lifted requires additional clamping force beyond that provided for by the use of a vacuum alone or if the material is to a degree porous, such as perforated metal.

**[p0003]**

In accordance with the present invention, the material handling head is provided with a movable plate mounted on a pivot which traverses the length of the head. The pivot is located within the head such that two chambers are formed, one above the pivot and one below. The sheet material is clamped between the lower section of the plate below the pivot and a second plate, preferably stationary. Vacuum is applied to the chamber defined by the pivot, the two plates and two end plates to maintain the stack of sheet material within the head. Means for providing a pressure force is mounted on said head to pressurize the chamber above the pivot to force the movable plate tightly against the stack of sheet material to increase the lifting capability of the entire material handling head. Referring now to the draiwings, depicting a preferred embodiment of the invention, and wherein like numerals refer to like parts: FIG. 1 is a side view in partial section of the material handling head; FIG. 2 is a front view in partial section of the material handling head taken along line 2--2 of FIG. I; and

**[p0004]**

FIG. 3 is a side detail view of the material handling head of FIG. I. In the drawings, denotes the material handling head. The material handling head 10 is formed of a back plate 12, a top plate 14, and a front plate 16. The ends of the material handling head are sealed by a pair of end plates 18 on which seals 20 are mounted. Seals 20 are adapted to engage the top of a stack of sheet material shown at 22 in the drawing, as will be explained below. Mounted on back plate 12, such as by welding, is a pivot 24 which runs the entire length of the back plate 12. Mounted on pivot 24 is a movable plate generally denoted by the numeral 26, having a leg 28 located above the pivot and a leg 30 located below the pivot. The end of leg 28 is formed with a recess 32 running the entire length of the leg 28 and in which is mounted a wiping seal 34. Top plate 14 is formed with a curved surface as shown at 36 to provide continuous contact between wiping seal 34 and the curved surface 36 during pivotal motion of plate 26 about pivot 24. Pivot 24 is in sealing contact with end plates 18. Such sealing contact may be achieved by mounting rubber stops (not shown) at each end of the pivot to prevent leakage of air from the region above to the region below the pivot.

**[p0005]**

Plate 14 is provided with a bore 38 which extends into chamber 40 defined by curved surface 36, leg 28 and the interior surface 42 of back plate 12. Conventional means (not shown) for applying gas under pressure, such as an air pump, is provided through tubing 44 to apply pressure to chamber 40. Back plate 12 is provided with a bore 46 extending :into chamber 52 defined by rear surface portion 48 of back plate 12, pivot 24 and leg 30 of movable plate 26. A conventional vacuum pump (not shown) is mounted via tubing 50 to supply vacuum to the chamber 52.. In operation, plate 26 is easily movable about pivot 24 to permit leg 30 to be pivoted away from rear surface 48. The material handling head 10 is then moved downwardly over the stack of sheet material 22, the said stack being positioned between leg 30 and rear surface 48. The material handling head is moved downwardly until end seals 20 contact the upper surface of the stack to be moved. At this point, positive gas pressure is applied via tubing 44 and bore 38 to pressurize chamber 40. Pressurizing chamber 40 causes plate 26 to pivot about pivot 24 to move leg 30 against the side of the stack to be lifted. The pressure exerted by leg 30 at this point is determined solely by the pressure force existing on the leg 28. Once clamping has been accomplished, a vacuum force is applied via tubing 50 and bore 46 to evacuate chamber 52. The evacuation of chamber 52 provides additional force for retaining the stack of material in position for lifting. Of course, plate 26 may be provided with sealing strips along the edges of the plate

**[p0005]**

which contact the end plates 18 to mini mize leakage between the two chambers and to aid in controlling the applied pressure and/or vacuum forces.

**[p0006]**

Prior apparatus have depended solely on the vacuum force for lift capability. However, by the use of positive clamping pressure as described herein, additional lifting capability is imparted to the material handling head to enable it to handle larger gross weights of stacked material, a tremendous advantage when large stacks have to be moved from one section of a plant to another. Of course, the entire material handling head can be mounted on overhead rails as described in U.S. Pat. No. 3,411,641, for movement within a plant in a manner defined by the number and placement of the rails. In addition, the material handling head of this invention can be mounted on a conventional crane for use outside of a building to lend an additional lifting and moving capability to the loading and unloading of stacks of sheet material from vehicles or from outside storage depots. To provide for a more fully automated operation, the pressure pump connected through tubing 44 can be a two-sided pump having both pressure and vacuum connections which may be connected to tubing 44 through a conventional reversing valve well known to the art. By controlling the reversing valve, either vacuum or positive pressure can be applied to chamber 40 to control movement of plate 26. For instance, when a large stack is to be engaged, negative pressure may be up plied to chamber 40 to move leg 30 outwardly to permit engagement of the stack, whereupon positive pressure is then employed to clamp the stack.

**[p0007]**

For best results, a seal 54 of rubber or some other type of resilient material is provided along the entire length of leg 30. Seal material 56, also resilient, may be placed on rear surface 48 of back plate 12 so that material gripped between the seals 54 and 56 will be gripped in a manner such that the vacuum induced in chamber 52 will not be lost due to poor sealing between leg 30, the stack, and rear surface 48. In addition, a sealing cap 58 may be provided to positively prevent leakage between compartments 40 and 52. It is to be understood that many modifications to the above-described invention may be made by those skilled in the art, and it is intended to cover all such modifications which fall within the spirit and scope of the appended claims. What is claimed is: 1. A material handling head for lifting sheet material comprising a back plate, a top plate and a pair of end plates, a pivot mounted on said back plate, said pivot traversing the entire length of said back plate, a movable plate mounted on said pivot, said movable plate having a first leg extending above said pivot toward said top plate to define a first chamber comprising said end plates, top plate, back plate and pivot, and a second leg extending below said pivot to define a second chamber comprising said end plates, back plate, pivot and the said sheet material, means for applying gas under pressure to said first chamber to urge the movable plate to rotate about said pivot to bring the said second leg into contact with said sheet material, and means to apply a vacuum force to said second chamber to prov

**[p0007]**

ide additional force to maintain said sheet material within the material handling head when said head is moved.

**[p0008]**

2. The material handling head according to claim 1 further comprising means for sealing said first chamber against pressure leakage. 3. The material handling head according to claim 2 wherein the sealing means comprises a wiper seal, a recess in said first leg for receiving said wiper seal, said top being curved adjacent said first leg such that the said wiper seal remains in wiping contact with said top plate during movement of said movable plate. 4. The material handling head according to claim 2 further comprising a pair of end seals, said end seals being placed on said end plates such that said end seals contact said sheet material when the head is moved into position. 5. The method of lifting sheet material with a material handling head of the type having a first and second chamber, the first utilizing the sheet material as a closure for the chamber, said head having a back plate and a movable plate pivotally mounted on said back plate, said chambers lying to either side of said pivot and being defined by said back plate, and said movable plate, comprising the steps of: moving said head to position said back plate and said movable plate about said sheet material, applying gas under pressure to said second chamber to urge said movable plate to pivot to clamp said sheet material, and applying a negative pressure to said first chamber to enhance the clamping force to permit said sheet material to be moved by said head, and moving said head to move the clamped sheet material.

**[p0009]**

a a a:

## Figure captions

- **Figure 1:** FIG. 1 is a side view in partial section of the material handling head;
- **Figure 2:** FIG. 2 is a front view in partial section of the material handling head taken along line 2--2 of FIG. I; and
- **Figure 3:** FIG. 3 is a side detail view of the material handling head of FIG. I.

## Classifications

- B66C1/0287
- B66C1/0287
- B65H3/00
- B65H5/14
- B66C1/02
- B66C1/0256
- B66C1/0256
- B66C1/0293
- B66C1/0293
- B66C1/44
- B66C1/447
- B66C1/447
- B66C1/48

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
