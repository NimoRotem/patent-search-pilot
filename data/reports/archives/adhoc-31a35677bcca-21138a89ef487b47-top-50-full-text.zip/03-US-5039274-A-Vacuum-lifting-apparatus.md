# 03. Vacuum lifting apparatus

- **Archive rank:** 3 of 50
- **Publication:** [US-5039274-A](https://patents.google.com/patent/US5039274A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/010648324/publication/US5039274A?q=pn%3DUS5039274A)
- **Publication date:** 1991-08-13
- **Filing date:** 1989-12-08
- **Earliest priority:** 1988-12-10
- **Family:** 10648324
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus

## Parties

- **Applicant / assignee:** PALAMATIC HANDLING SYST
- **Inventors:** BENNISON STEWART

## Abstract

Valve means 1 for controlling vacuum lifting apparatus 2 comprising a bellows like lift tube 3 having an interior 6 connectable to a vacuum generating means, with a suction foot 10 associated with the lift tube 4. Valve means 1, serving to connect the interior 6 at a controllable level to atmosphere to regulate the vacuum therein and hence the axial extension of the lift tube 3, comprises a housing 11 having a first connection 12 to the suction foot 10 in air-flow communication with a first chamber 13 of the housing 11, which chamber 13 has an outlet 14 to atmosphere controlled by a first valve member 15. A second connector 18 is in air flow communication to a source of vacuum via the lift tube 3, and air flow along the second connector 18 is controlled by a second valve member 20, whereby, in a load gripping and lifting mode, the first valve member 15 is partially open and the second valve member 20 is fully open; and in a load-releasing mode where the first valve member 15 is further or fully opened to admit air to the suction foot 10 and simultaneously, or shortly thereafter, the second valve member 20 is closed, or partially closed, producing a higher vacuum in the interior 6.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/4e/3d/da/f9b53a9c9151cc/US5039274-drawings-page-2.png)

![Sketch 1 for US-5039274-A](https://patentimages.storage.googleapis.com/4e/3d/da/f9b53a9c9151cc/US5039274-drawings-page-2.png)

[Sketch 2](https://patentimages.storage.googleapis.com/c4/e1/bb/00c4a615b05ac2/US5039274-drawings-page-3.png)

![Sketch 2 for US-5039274-A](https://patentimages.storage.googleapis.com/c4/e1/bb/00c4a615b05ac2/US5039274-drawings-page-3.png)

[Sketch 3](https://patentimages.storage.googleapis.com/ad/d9/5e/455f8aa97d8247/US5039274-drawings-page-4.png)

![Sketch 3 for US-5039274-A](https://patentimages.storage.googleapis.com/ad/d9/5e/455f8aa97d8247/US5039274-drawings-page-4.png)

## Claims

### Claim 1 (independent)

Vacuum lifting apparatus comprising a bellows-like lift tube which is extendable and retractable in length, and is adapted to be located in an upright disposition, an upper end of said lift tube connectable to a support, an interior of said lift tube being connectable to a vacuum pump, an air sealing means being provided at each end of said lift tube, manually operable valve means to connect said interior of said lift tube at a controllable level to atmosphere to regulate said vacuum therein and hence the axial extension and retraction of said lift tube, and a relatively rigid telescopic device located substantially wholly within and extendable and retractable in length as said lift tube extends and retracts in length, which device is connected to said air sealing means, and means for engaging a load to be lifted, transported and lowered, carried at a lower end of said lift tube.

### Claim 2

Vacuum lifting apparatus as claimed in claim 1, wherein said load engaging means is attached directly to said lower end of said lift tube.

### Claim 3

Vacuum lifting apparatus as claimed in claim 1, wherein said load engaging means is attached indirectly to said lower end of said lift tube, a beam being interposed between said load engaging means and said lift tube.

### Claim 4

Vacuum lifting apparatus as claimed in claim 3, wherein said beam is symmetrical, extending equally to opposite sides of a longitudinal axis of said lift tube.

### Claim 5

Vacuum lifting apparatus as claimed in claim 4, wherein a load engaging means is provided at each end of said beam.

### Claim 6

Vacuum lifting apparatus as claimed in claim 3, wherein said beam is asymmetrical, extending to one side only of a longitudinal axis of said lift tube.

### Claim 7

Vacuum lifting apparatus as claimed in claim 6, wherein a load engaging means is carried at an end of said beam distal from said lift tube.

### Claim 8

Vacuum lifting apparatus as claimed in claim 1, wherein a spiral spring reinforces said bellows.

### Claim 9

Vacuum lifting apparatus as claimed in claim 1, wherein said telescopic device is of piston and cylinder form, with an inner, elongate member axially displaceable with respect to an outer, elongate member.

### Claim 10

Vacuum lifting apparatus as claimed in claim 9, comprising friction reducing or eliminating bearing means between said inner and outer members.

### Claim 11 (independent)

Vacuum lifting apparatus comprising a lift tube which is extendable and retractable in length, and is adapted to be located in an upright disposition, an upper end of said lift tube connectable to a support, an interior of said lift tube being connectable to a vacuum generating means, an air sealing means being provided at each end of said lift tube, manually operable valve means to connect said interior of said lift tube at a controllable level to atmosphere to regulate said vacuum therein and hence the axial extension and retraction of said lift tube, and a relatively rigid device located within and extendable and retractable in length as said lift tube extends and retracts in length, which device is connected to said air sealing means, and means for engaging a load to be lifted, transported and lowered, carried at a lower end of said lift tube, wherein said axially displaceable device comprises a telescopic device of piston and cylinder form, with an inner, elongate member axially displaceable with respect to an outer, elongate member, including friction reducing or eliminating bearing means between said inner and outer members, wherein, said inner member is of square section, and said bearing means comprises a set of four rollers, located 90° apart, around said inner member, a periphery of each said roller engaging one face of said square section member.

### Claim 12 (independent)

Vacuum lifting apparatus comprising a lift tube which is extendable and retractable in length, and is adapted to be located in an upright disposition, an upper end of said lift tube connectable to a support, an interior of said lift tube being connectable to a vacuum generating means, an air sealing means being provided at each end of said lift tube, manually operable valve means to connect said interior of said lift tube at a controllable level to atmosphere to regulate said vacuum therein and hence the axial extension and retraction of said lift tube, and a relatively rigid device located within and extendable and retractable in length as said lift tube extends and retracts in length, which device is connected to said air sealing means, and means for engaging a load to be lifted, transported and lowered, carried at a lower end of said lift tube, wherein said axially displaceable device comprises a telescopic device of piston and cylinder form, with an inner, elongate member axially displaceable with respect to an outer, elongate member, including friction reducing or eliminating bearing means between said inner and outer members, wherein, said inner member is tubular and a set of four balls constitute said bearing means, said balls being located 90° apart around said inner member, to engage said inner member.

### Claim 13

Vacuum lifting apparatus as claimed in claim 11, wherein two sets of said rollers are provided, said sets being axially spaced apart.

### Claim 14

Vacuum lifting apparatus as claimed in claim 12, wherein two sets of said balls are provided, said sets being axially spaced apart.

### Claim 15

Vacuum lifting apparatus as claimed in claim 11, wherein a rotating connection is provided between a lower end of said inner member and a laterally extending member.

### Claim 16

Vacuum lifting apparatus as claimed in claim 15, wherein spaced-apart bearing means are incorporated in said rotating connection.

### Claim 17

Floor mounted vacuum lifting apparatus as claimed in claim 1, attached to a vertical column via two arms being with a first arm pivotally attached to said column, a second arm pivotally attached to said first arm, with said vacuum lifting apparatus attached to said second arm.

### Claim 18

Mobile vacuum lifting apparatus as claimed in claim 1, mounted on an overhead conveyor system.

### Claim 19

Vacuum lifting apparatus as claimed in claim 1, wherein a suction foot constitutes said load engaging means.

## Full description

**[p0001]**

This invention relates to a vacuum lifting apparatus of the general type described in GB 2080764B. Whilst this known apparatus has been used for lifting all manner of objects its use has always been limited to lifting from directly above the load, as the lift tube is a flexible bellows which cannot accommodate side loading. Hence it has been impossible to offer a solution to lifting loads from a lateral location e.g., from inside a machine press or from under pallet racking or shelving or from inside a machine guard. Also it has become increasingly apparent that, when handling large boards and planks, unless the load is picked up exactly on centre-line it will not remain horizontal and, in un-trained hands, can be somewhat unnerving in operation. According to the present invention, there is provided vacuum lifting apparatus comprising a lift tube which is extendable and retractable in length, and is adapted to be located in an upright disposition with an upper end connectable to a fixed or movable anchorage point or support, the lift tube interior being connectable to a vacuum generating means and each end of the lift tube provided with air sealing means, valve means to connect the interior of the lift tube at a controllable level to atmosphere to regulate the vacuum therein and hence the axial extension of the lift tube, and a relatively rigid device located within the lift tube, which device is axially displaceable or extendable and retractable with the lift tube and carries at a lower end a means for engaging a load to be lifted, transported and lowered.

**[p0002]**

A basic advantage of installing the axially displaceable or extendable device within lift tube is to ensure no additional bulky structures are required surrounding the lift tube. Also there is no fundamendal reduction in the lifting capacity of the appartus in accordance with the invention, except for that resulting from the weight of the additional components attached to the load engaging means, but basically the invention results in a rigidised lift tube, whereby the apparatus is capable, inter alia, of lifting and lowering lateral loads, remote from the centre line of the lift tube. The load engaging means may be attached directly to the lower end of the lift tube. Alternatively the load engaging means may be attached indirectly to the lower end of the lift tube, via a beam, which may be symmetrical, extending equally to opposite sides of the longitudinal axis of the lift tube e.g., with a load engaging means at each end, and possibly intermediate the two ends, (which arrangement is suitable for lifting sheets of timber, glass etc), or which may be asymmetrical, extending to one side only of the longitudinal axis of the lift tube, with a load engaging means carried at the end of this beam distal from the lift tube (which arrangement is suitable for penetrating pallet racking or shelving for instance).

**[p0003]**

In detail, the lift tube may be extendable and retractable by being constituted by a bellows, preferably reinforced by a spiral spring. The axially displaceable or extendable device may, in one embodiment, be constituted by a telescopic device e.g., generally of piston and cylinder form, with an inner elongate member axially displaceable with respect to an outer elongate member, preferably with friction reducing or eliminating bearing means between the inner and outer members. Thus, if the inner member is of square section the bearing means may comprise four rollers located 90° apart around the inner member, the periphery of each roller engaging one face of the member, while if the inner member is tubular, four balls instead of rollers may be employed, also located 90° apart, to engage around the inner member. Preferably, two sets of rollers or balls are provided, the sets being axially spaced apart. With a square section inner member, a rotating connection, also preferably incorporating axially spaced-apart bearing means, is required between the lower end of the inner member and the laterally extending member, if a facility for arcuate movement of the load engaging means, e.g. a laterally extending member, is required.

**[p0004]**

The same principles can be used on an apparatus incorporating double or triple lift tubes, while if four, six or eight lift tubes were involved, preferably a piston and cylinder type extendable device would be replaced by an inverted scissor device to ensure complete rigidity e.g. when handling up to 1/2 ton loads on fully automated equipment. The apparatus may be floor mounted on a vertical column with at least one, and preferably two, arms interposed between the column and the apparatus. With one arm arrangement, the latter is pivotally attached to the column, while with a two arm arrangement a second arm is pivotally attached to a first arm which is pivotally attached to the column. Alternatively, the apparatus may be rendered mobile by being mounted on an overhead conveyor system. Preferably the laterally extending member is constituted by a beam. The load engaging means preferably takes the form of a suction foot. If however, this is unsuitable for the particular load to be handled, then this may be supplemented or replaced by mechanical and/or electromagnetic grippers.

**[p0005]**

The invention will now be described in greater detail, by way of examples, with reference to the accompanying drawings, in which: FIG. 1 is a diagrammatic sectional view through a first embodiment of vacuum lifting apparatus in accordance with the invention, being a section on the line I--I of FIG. 2; FIG. 2 is a section on the line II--II of FIG. 1; FIG. 3 corresponds to FIG. 1 but shows a second embodiment and is a section on the line III--III of FIG. 4; FIG. 3A illustrates an alternative attachment of the load engaging means. FIG. 4 is a section on the line IV--IV of FIG. 3; FIG. 5 shows the apparatus of FIGS. 1 and 2, or FIGS. 3 and 4 attached to a static mounting in the form of a column, FIG. 6 shows the apparatus of FIGS. 1 and 2, or FIGS. 3 and 4 attached to a mobile mounting, and FIGS. 7-9 show details of the valve means of FIGS. 1-6. In the drawings, vacuum lifting apparatus 1 comprises a lift tube 2 of known construction comprising an extendable and retractable bellows reinforced by a spiral spring. The lift tube 2 is adapted to be located in an upright disposition, as indicated in FIGS. 1, 3, 5 and 6, with an upper end 3 connected to a fixed support 4 (as illustrated in FIGS. 1 and 3) or a mobile support 5 (as illustrated in FIGS. 5 and 6). The lift tube 2 has an interior 6 connectable to a vacuum generating means (not shown) and the upper and lower ends 3, 7 of the lift tube 2 are provided with air sealing means, being an upper, rotary seal 8 and a lower seal 9. A valve means 10 is connected to the interior 6 of the lift tube 2, to connect the interior 6, in a c

**[p0005]**

ontrolled manner, to atmosphere, whereby the vacuum level within the interior 6, and hence the axial extension of the lift tube, is controlled, to provide the up and down movements required during load handling operations. Within the lift tube 2 is located a relatively rigid device in the form of a rod 11, e.g. of lightweight alloy, which rod 11 is axially displaceable, or extendable and retractable, simultaneously with the lift tube 2, as indicated by the arrow 12. The rod 11 carries at a lower end 13 means for engaging a load to be lifted, transported and lowered, which means is constituted by a suction foot 14 of known construction. The foot 14 may be attached to the rod 11 indirectly, via an interposed, laterally extending beam 15, as illustrated in FIGS. 1, 3, 5, and 6; or alternatively may be attached directly to the rod 11, as illustrated in FIG. 3A. The beam 15 may be asymmetrical, as illustrated in FIGS. 1, 3 and 5, with the valve means 10 located diammetrically opposite the beam to assist counterbalancing of the latter, or alternatively may be symmetrical, as illustrated in FIG. 6.

**[p0006]**

The rod 11 is located within an outer, elongate casing 11A which, together with the rod 11, constitutes a piston and cylinder telescopic device. In this embodiment, the upper end 3 is attached to the casing 11A, which is in turn attached to the support 4 or 5. In the embodiment of FIGS. 1 and 2, the rod 11 is of square section, and a friction-reducing bearing means is provided, comprising two axially-spaced sets of four rollers 16, located 90° apart, and carried by the casing 11A, the periphery of each roller 16 engaging one of the four faces of the square rod 11. In the embodiment of FIGS. 3 and 4, the rod 11 is tubular, and two axially spaced sets of four balls 16A, also located 90° apart, are carried by the casing 11A and engage around the rod 11. In the embodiment of FIGS. 1 and 2, a rotating connection 17, also incorporating axially spaced-apart bearing means 18 is provided between the lower end of the rod 11 and the beam 15. The apparatus 1 is particularly adapted for manual operation, for which purpose a square &#34;U&#34;-shaped hand grip 19 is attached to a housing 20 of the valve means 10, whereby the apparatus 1 may be manually manoeuvred, particularly by rotation about the longitudinal axis 21 of the lift tube 2, while a similar, square &#34;U&#34;-shaped valve actuation lever 22 is pivotally attached to the housing 20, for one-handed control by the operator.

**[p0007]**

As illustrated in FIG. 5, the apparatus 1 may be floor mounted on a vertical column 23, with two arms 24, 25 interposed between the column 23 and the apparatus 1, the second arm 25 being pivotally attached to the first arm 24, which is pivotally attached to the column 23. As illustrated in FIG. 6, the apparatus may, alternatively, be mobile by being mounted on an overhead conveyor system 26, and furthermore, as indicated in chain-dotted line, the beam 15 may be extended equally to opposite sides of the lift tube 2, with each end of the beam provided with a suction foot 14.

## Figure captions

- **Figure 1:** FIG. 1 is a diagrammatic sectional view through a first embodiment of vacuum lifting apparatus in accordance with the invention, being a section on the line I--I of FIG. 2;
- **Figure 2:** FIG. 2 is a section on the line II--II of FIG. 1;
- **Figure 3:** FIG. 3 corresponds to FIG. 1 but shows a second embodiment and is a section on the line III--III of FIG. 4;
- **Figure 3A:** FIG. 3A illustrates an alternative attachment of the load engaging means.
- **Figure 4:** FIG. 4 is a section on the line IV--IV of FIG. 3;
- **Figure 5:** FIG. 5 shows the apparatus of FIGS. 1 and 2, or FIGS. 3 and 4 attached to a static mounting in the form of a column,
- **Figure 6:** FIG. 6 shows the apparatus of FIGS. 1 and 2, or FIGS. 3 and 4 attached to a mobile mounting, and
- **Figure 7:** FIGS. 7-9 show details of the valve means of FIGS. 1-6.
- **Figure 5:** As illustrated in FIG. 5, the apparatus 1 may be floor mounted on a vertical column 23, with two arms 24, 25 interposed between the column 23 and the apparatus 1, the second arm 25 being pivotally attached to the first arm 24, which is pivotally attached to the column 23.
- **Figure 6:** As illustrated in FIG. 6, the apparatus may, alternatively, be mobile by being mounted on an overhead conveyor system 26, and furthermore, as indicated in chain-dotted line, the beam 15 may be extended equally to opposite sides of the lift tube 2, with each end of the beam provided with a suction foot 14.

## Classifications

- B66F3/35
- B66F3/35
- B25J9/02
- B65G47/91
- B65G47/914
- B65G47/914
- B66C1/00
- B66C1/02
- B66C1/0218
- B66C1/0218
- B66C1/0256
- B66C1/0256
- B66F3/35
- F16K11/14

## Cited patent documents

- [CH-526461-A](https://patents.google.com/patent/CH526461A/en) — SEA
- [CH-541507-A](https://patents.google.com/patent/CH541507A/en) — SEA
- [DE-1584615-A1](https://patents.google.com/patent/DE1584615A1/en) — SEA
- [FR-2553327-A1](https://patents.google.com/patent/FR2553327A1/en) — SEA
- [GB-2200615-A](https://patents.google.com/patent/GB2200615A/en) — SEA
- [US-2716497-A](https://patents.google.com/patent/US2716497A/en) — SEA
- [US-3558171-A](https://patents.google.com/patent/US3558171A/en) — SEA
- [US-3704038-A](https://patents.google.com/patent/US3704038A/en) — SEA
- [US-3743340-A](https://patents.google.com/patent/US3743340A/en) — SEA
- [US-4413853-A](https://patents.google.com/patent/US4413853A/en) — SEA
- [US-4620831-A](https://patents.google.com/patent/US4620831A/en) — SEA
- [US-4648786-A](https://patents.google.com/patent/US4648786A/en) — SEA
- [WO-8102289-A1](https://patents.google.com/patent/WO8102289A1/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
