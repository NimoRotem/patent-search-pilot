# 08. Vacuum system for load handling

- **Archive rank:** 8 of 50
- **Publication:** [US-3219380-A](https://patents.google.com/patent/US3219380A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/023215419/publication/US3219380A?q=pn%3DUS3219380A)
- **Publication date:** 1965-11-23
- **Filing date:** 1963-10-02
- **Earliest priority:** 1963-10-02
- **Family:** 23215419
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** YALE & TOWNE INC

## Abstract

_No abstract was available from the queried sources._

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-3219380-A/000.png)

![Sketch 1 for US-3219380-A](https://nimo.iptorch.com/refdrawing/US-3219380-A/000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/20/9c/2a/da0ae8b6ac3b0c/US3219380-drawings-page-1.png)

![Sketch 2 for US-3219380-A](https://patentimages.storage.googleapis.com/20/9c/2a/da0ae8b6ac3b0c/US3219380-drawings-page-1.png)

## Claims

### Claim 1 (independent)

IN A VACUUM SYSTEM FOR HANDLING LOADS ON AN INDUSTRIAL TRUCK, A SOURCE OF COMPRESSED AIR, MEANS FOR STORING AIR UNDER CONSIDERABLE PRESSURE FROM SAID SOURCE, A VACUUM RESERVOIR, A VACUUM ACTUATED LOAD HOLDER HAVING A PAIR OF OUTLETS, MEANS CONNECTING SAID VACUUM RESERVOIR TO ONE OF SAID VACUUM LOAD HOLDER OUTLETS, AND MEANS FOR

## Full description

PERFORMING OPERATIONS; TRANSPORTINGVEHICLES IN GENERALVEHICLES ADAPTED FOR LOAD TRANSPORTATION OR TO TRANSPORT, TO CARRY, OR TO COMPRISE SPECIAL LOADS OR OBJECTSVehicles predominantly for transporting loads and modified to facilitate loading, consolidating the load, or unloadingVehicles predominantly for transporting loads and modified to facilitate loading, consolidating the load, or unloading using fluids, e.g. having direct contact between fluid and loadPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGHOISTING, LIFTING, HAULING OR PUSHING, NOT OTHERWISE PROVIDED FOR, e.g. DEVICES WHICH APPLY A LIFTING OR PUSHING FORCE DIRECTLY TO THE SURFACE OF A LOADDevices for lifting or lowering bulky or heavy goods for loading or unloading purposesDevices for lifting or lowering bulky or heavy goods for loading or unloading purposes movable, with their loads, on wheels or the like, e.g. fork-lift trucksConstructional features or detailsPlatforms; Forks; Other load supporting or gripping membersLoad gripping or retaining meansLoad gripping or retaining means by suction means

Description

Nov. 23, 1965 o. s. cARLlss 3,219,380

VACUUM SYSTEM FOR LOAD HANDLING Filed Oct. 2, 1963 CON/ 1? PRFSS U/Ff VACUUM T/I/V/f INVENTOR. 0. 5. CWRL A55 BY M c ATTORNEY United States Patent 3,219,380 VACUUM SYSTEM FOR LOAD HANDLING Oswald S. Carliss, Rydal, Pa., assignor to Yale & Towne, Inc., Cleveland, Ohio, a corporation of Ohio Filed Oct. 2, 1963, Ser. No. 313,363 9 Claims. (Cl. 294-64) This invention relates to a novel vacuum system for handling loads on an industrial truck.

Those skilled in the art will appreciate that there has been a great increase in the use of vacuum load handling systems on industrial trucks. I have now conceived an extremely novel vacuum and pressure system that has very considerable advantages over the systems that have been developed heretofore.

In my invention, I apply both air pressure and vacuum so inter-related as to make possible the practically instantaneous holding or release of a load, as may be desired.

As a feature of my invention, I utilize compressed air as the means for developing a vacuum for holding a load. This permits me to accumulate and to store relatively large sources of vacuum developing power. Further, it gives me an ample source of pressure with which to effect instant release of a load from its vacuum holding means.

As a further feature, my novel system has controls that will safeguard a source of load holding vacuum against the etfects of air pressure, while also enabling the air pressure to act very quickly to release the load. I prefer to utilize vacuum and air control valves that will operate sequentially, closing communication between the vacuum source and load slightly before an application of air pressure to the load.

As another feature, I utilize a vacuum valve that will enable a full degree of vacuum to be available for hold ing a load immediately after an application of air pressure to release a load. 'More particularly, I mount the vacuum valve in position at the vacuum load holding device, and I arrange the valve to close upon the release of the load by air pressure. That enables the vacuum to be applied from a source to a point at the holding device, so that the vacuum will at once take effect when it is again desired to hold a load.

I have thus outlined rather broadly the more important features of my invention in order that the detailed description thereof that follows may be better undersood, and in order that my contribution to the art may be better appreciated. There are, of course, additional features of my invention that will be described hereinafter and which will form the subject of the claims appended hereto. Those skilled in the art will appreciate that the conception on which my disclosure is based may readily be utilized as a basis for the designing of other structures for carrying out the several purposes of my invention. It is important, therefore, that the claims be regarded as including such equivalent constructions as do not depart from the spirit and scope of my invention, in order to prevent the appropriation of my invention by those skilled in the art.

The drawing shows diagrammatically the novel load handling vacuum system of my invention. I indicate generally at 10 a pair of rather usual vacuum pads, each of those pads having a base plate 11 and a yielding member 12 that is adapted to make vacuum sealing contact with the surface of a load L. Particular details of the vacuum pads 10 actually are not important to an understanding of my invention, and it is merely necessary to know that one or more of the vacuum pads 10 will be mounted on an industrial truck, not shown, and will enable the truck to utilize vacuum for handling a load.

3,219,380 Patented Nov. 23, 1965 The power for operating my system will be supplied through a compressed air tank which I show at '13. The tank 13 will be charged by an air compressor 14 that is driven by an engine or motor 15 and that is connected through a line 16 to tank 13. A governor 17 will control the operation of compressor 14 so as to maintain relatively high air pressures in the tank 13.

I apply the air pressure from tank 13 through a line 18 to a pressure regulator 19, which may be of a standard type that is commercially available. The pressure regulator '19 will operate in a usual way to effect a reduction of pressure between the line 18 and the regulator outlet 19a, directing air at a controlled and relatively low pressure through a line'20 toward the vacuum pads 10. In the line 20, I interpose a control valve 21 that normally is spring pressed to a closed position, but that may be actuated to an open position so as to apply the air pressure to the vacuum pads 10 in a manner that I shall describe.

My novel system further includes an ejector 22 having a standard construction, with a jet 23 that will direct compressed air through an exhaust outlet 24 so as to create sub-atmospheric pressure at an intake 25. I connect the jet 23 through a valve 30 to the outlet 19a of pressure regulator 19, so that I may utilize to operate the ejector 22 the same controlled air pres-sure that is directed through line 20 toward the vacuum pads 10. I then connect the ejector intake '25 through a line 2 6 to a vacuum storage tank 28, so that operation of the ejector 22 will develop vacuum in the tank 28. I show a check valve 29 arranged in the line 26 to prevent loss of the vacuum in tank 28 when the ejector 22 is not in operation.

I utilize the Valve 30 to control the charging of vacuum tank 28. As indicated diagrammatically in the drawing, the valve 30 normally is spring pressed to open position, and will be actuated to closed position when a solenoid 31 is energized. A vacuum switch 32 is connected to the vacuum storage tank 28, the arrangement being such that switch 32 will close a pair of normally open contacts 33 when the vacuum in tank 28 reaches a predetermined degree. The contacts 33 are connected in circuit with the solenoid 31 and a battery 34. Thus, when vacuum tank 28 is fully charged, the switch 32 will cause the ejector control valve 30 to move to closed position, stopping the operation of ejector 22.

While I do not with to be limited to particular degrees of air and vacuum pressure in my novel system, I have found that my system operates very well when the compressed air governor 17 is so set as to maintain air pressure between and pounds per square inch in the compressed air tank 13. Also, I may set the pressure regulator 19 so as to maintain approximately 60 pounds per square inch at its outlet, that pressure being effective through compressed air line 20, while also enabling the ejector 22 to operate efliciently for exhausting the vacuum storage tank 28. The degree of vacuum that ejector 22 develops in the tank 28 naturally will be controlled through the operation of the vacuum switch 32, and that switch preferably will maintain the vacuum between 18 and 12 inches Hg. From the description I have thus far made, it will be seen that my system will enable rather large amounts of power to be stored in the compressed air tank 13, while actually utilizing the power at a relatively low rate in order to supply effective amounts of both air pressure and vacuum.

I connect the vacuum tank 28 through a control valve 36 and a line 37 to a pair of vacuum valves 38, one for each vacuum pad 10. The control valve 36 is spring pressed to open position so that the vacuum normally will be applied to the vacuum valves 38. Incidentally, I show between tank 28 and control valve 36 a check valve 28a,

but that check valve actually is not important to an understanding of my invention, and may merely prevent a loss of vacuum from line 37 and pads should a part of the vacuum system meet with an accident.

I arrange each vacuum valve 38 in position at a vacuum pad 10, the valves 38 in my preferred construction actually being mounted on the pads. Each vacuum valve 38 has a spring 39 that normally will be effective for holding the valve 38 in a closed position, and also a sensing plunger 40 that will be depressed by the surface of the load L so as to open valve 38 against its spring pressure when the load and pad 10 move toward contact with each other. When the load L moves away from contact relatively to a vacuum pad 10, the vacuum valve 38 will close communication between the pad 10 and vacuum line 37. Since the vacuum valve 38 is arranged at the vacuum pad it will be possibe, while the pad is not engaged with a load, to maintain a full degree of vacuum through line 37 to a point that actually is at the pad. Thus, the vacuum will be immediately available at the vacuum pad and may very quickly act through the pad to hold a load when the operator again wishes to do so.

The control valve 36 is equipped with a solenoid 41 which is adapted to move that valve to closed position, while the compressed air valve 21 has a solenoid 42 adapted to move that valve to an open position. The battery 34 will energize each of the solenoids 41, 42 through a separate circuit controlled by a corresponding pair of contacts 43 or 44. There is a push button 45 that the operator of the truck may depress, push button 45 first acting through a spring 46 to move a switch member 47 against the contacts 43 whereby to energize the solenoid 41. Spring 46 then will yield, so that push button 45 will act sequentially through a rod 48 to move a switch member 49 against the contacts 44 whereby to energize the solenoid 42. The arrangement is such that a depression of the push button 45 will cause the vacuum control valve 36 to close, thereafter causing the compressed air control valve 21 to open. I do not actually with to be limited to the sequentially moving switch members 47 and 49, since those skilled in the art will know how to design a control that will eifect sequential movements of the vacuum control valve 36 and the compressed air valve 21. It is merely necessary that valve 36 be in closed position while valve 21 is open. That will safeguard the source of vacuum when compressed air is applied to the vacuum pads 10, while also enabling the air pressure to act more quickly.

While utilizing my extremely novel vacuum system on an industrial truck, only a minimum of manual controls need be used. Thus, when the operator wishes to pick up a load, he merely need maneuver the industrial truck so as to bring the vacuum pads 19 against the surface of a load. That will automatically cause the vacuum valves 38 to apply vacuum to hold the load. The vacuum valves 38 will effect a very rapid pick up, since a full degree of vacuum will be available at a point which actually is on the pads, enabling the vacuum to take effect immediate- 1y when the valves 38 open.

When the operator wishes to release a load relatively to the vacuum pads 10, he will simply depress the push button 45 momentarily. That will cause the compressed air valve 21 to apply air pressure to the vacuum pads 10. Vacuum control valve 36 will have moved to closed position, safeguarding the vacuum in tank 28 and also enabling the air pressure very quickly to destroy the vacuum acting in the pads 10. The air pressure actually will force the load away from the pads and will effect practically instantaneous release of the load. At that time, vacuum valves 38 will automatically close. Because only a momentary depression of the push button 45 is necessary, the vacuum control valve 36 may return almost at once to open position. That will restore the full degree of vacuum at the vacuum valves 38, enabling the vacuum pads 10 to be utilized immediately for holding a load, if the operator should so desire.

My novel system will operate to very good effect, and with a large reserve of power. Thus, I utilize compressed air as a means for developing a load holding vacuum. I store the air at a relatively high pressure in a compressed air tank, so that a large amount of power will be available for developing the vacuum even though the air tank may be rather small. I further utilize the air tank as a source of pressure for releasing a load from the vacuum holding means. Moreover, my system will so apply the vacuum and the compressed air as to achieve practically instantaneous operation to pick up and to release a load.

To a large extent my system will be automatically controlled, and the operator will effect the operation that he desires through manual controls that are extremely simple.

I believe, therefore, that the operation and the advantages of my novel vacuum system will now be understood, and that the very considerabe merits of my invention will be fully appreciated by those skilled in the art.

I now claim:

1. In a vacuum system for handling loads on an industrial truck, a source of compressed air, means for storing air under considerable pressure from said source, a vacuum reservoir, a vacuum actuated load holder having a pair of outlets, means connecting said vacuum reservoir to one of said vacuum load holder outlets, and means for directing compressed air to the other of said vacuum load holder outlets from said source of compressed air to release the load from said holder.

2. In a vacuum system for handling loads on an industrial truck, a source of compressed air, means for storing air under considerable pressure from said source, means utilizing compressed air from said source for developing vacuum within a vacuum reservoir, a vacuum actuated load holder, means connecting said vacuum reservoir to said vacuum load holder, and means for directing compressed air to said vacuum actuated holder from said compressed air storing means to release the load from said holder after disconnecting said holder from said vacuum reservoir.

3. In a vacuum system for handling loads on an industrial truck, a source of compressed air, means for storing air under considerable pressure from said source, means utilizing compressed air from said source for developing vacuum within a vacuum reservoir, a vacuum actuated load holder, means connecting said vacuum reservoir to said vacuum load holder and for directing compressed air to said vacuum load holder from said compressed air storing means to release the load from said holder including valve means for disconnecting said holder from said source of vacuum while connecting said compressed air storing means to said load holder.

4. In a vacuum system for handling loads on an industrial truck, a source of compressed air, means for storing air under considerable pressure from said source, a vacuum reservoir, a vacuum actuated load holder, means connecting said vacuum reservoir to a first outlet in said vacuum load holder, and means operating sequentially to disconnect said first outlet from said reservoir of vacuum and thereafter directing compressed air to another outlet in said vacuum actuated holder from said compressed air storing means to release the load from said holder.

5. In a vacuum system for handling loads on an industrial truck, a source of compressed air, means for storing air under considerable pressure from said source, means utilizing compressed air from said source for developing vacuum within a vacuum reservoir, a vacuum actuated load holder, means connecting said vacuum reservoir to an outlet in said vacuum load holder, and means connecting said load holder also to said storing means of compressed air for directing compressed air to another outlet in said vacuum actuated holder to facilitate release of the load from said holder.

6. In a vacuum system for handling loads on an industrial truck, a load holding vacuum device, a compressed air tank acting as a source of air pressure, a vacuum reservoir, an ejector utilizing air pressure from said tank to develop vacuum in said reservoir, a normally closed vacuum valve on the load holding vacuum device, means applying the vacuum developed by the ejector to said vacuum valve so that a full degree of vacuum will be immediately available at said device, the air pressure in said tank forming a reserve of vacuum developing power for holding a load on the vacuum device when the vacuum valve is actuated to open position, and means connecting said compressed air tank to said device for directing compressed air to said device prior to closing said valve.

7. In a vacuum system for handling loads on an industrial truck, a load holding vacuum device, a compressed air tank acting as a source of relatively high air pressure, an air control valve for controlling an application of air pressure to the vacuum device, a pressure regulator connected between said tank and said control valve and reducing the relatively high air pressure to a relatively low controlled pressure effective for releasing a load held on the vacuum device, an ejector connected to the pressure regulator outlet and utilizing the relatively low air pressure to develop vacuum, a vacuum reservoir, means connecting said vacuum reservoir to the load holding vacuum device, and the relatively high air pressure in said tank forming a reserve of vacuum developing power for holding a load on the vacuum device following an application of load releasing air pressure to said device.

8. In a vacuum system for handling loads on an industrial truck, a compressed air tank acting as a source of relatively high air pressure, a pressure operated ejector, a pressure regulator for applying air from said tank at a relatively low controlled pressure to said ejector whereby to develop vacuum, a vacuum actuated load holder, an

air control valve effective when actuated to direct low pressure air from the outlet of said regulator to said load holder, a load sensing vacuum valve on the vacuum actuated load holder, a normally open control valve applying the vacuum developed by the ejector to said sensing valve so that the vacuum may actuate the load holder immediately upon actuation of the sensing valve, and means operating sequentially to move the vacuum control valve to closed position and thereafter actuating the air control valve, whereby to conserve the vacuum developing power while the outlet pressure of the regulator promptly takes effect for releasing a load relatively to the load holder.

9. In a vacuum system for handling loads on an industrial truck, a source of compressed air, a vacuum source, a vacuum actuated load holder, a normally closed load sensing valve on said load holder actuated to open position upon contact with the load, means for connecting said sensing valve to said vacuum source, including a normally open control valve efiective to direct low vacuum from said vacuum source to said sensing valve so that the vacuum may actuate the load holder immediately upon the actuation of the sensing valve, means including a normally closed third valve connecting said source of high air pressure to an outlet on said vacuum actuated load holder, and means for first closing said control valve and then opening said third valve for admitting compressed air to said load holder for releasing a load relatively to the load holder after closing off the supply of vacuum to said load holder.

References Cited by the Examiner UNITED STATES PATENTS SAMUEL F. COLEMAN, Primary Examiner.

## Classifications

- B60P1/60
- B60P1/60
- B66F9/181
- B66F9/181

## Cited patent documents

- [US-2253283-A](https://patents.google.com/patent/US2253283A/en) — SEA
- [US-2887849-A](https://patents.google.com/patent/US2887849A/en) — SEA
- [US-3039623-A](https://patents.google.com/patent/US3039623A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
