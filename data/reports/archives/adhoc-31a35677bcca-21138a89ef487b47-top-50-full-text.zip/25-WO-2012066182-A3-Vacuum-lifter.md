# 25. Vacuum lifter

- **Archive rank:** 25 of 50
- **Publication:** [WO-2012066182-A3](https://patents.google.com/patent/WO2012066182A3/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/043268908/publication/WO2012066182A3?q=pn%3DWO2012066182A3)
- **Publication date:** 2012-08-02
- **Filing date:** 2011-11-17
- **Earliest priority:** 2010-11-18
- **Family:** 43268908
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** LINEARTEC OY; NUUTINEN ARVO
- **Inventors:** NUUTINEN ARVO

## Abstract

Vacuum lifter for lifting laminar objects which lifter comprises one or several low- pressure chambers (4) which can be lowered on top of an object to be lifted, such as a board (1) with the help of a lifting apparatus, a sealing element (5) at the lower surface of a low-pressure chamber (4) which sealing element gets settled against the surface of the board (1), further a formation device of the low pressure, such as a suction unit which is connected to the low-pressure chamber (4) and a valve arrangement for creating low pressure in the chamber (4) and for removing the low pressure from the mentioned chamber. At a grip area, which is limited (5) by the low-pressure chamber (4) and the sealing element onto the surface of the board (1), pressurized air or nozzle devices (9) blowing other pressurized gas are adjusted against the board (1) to be lifted the length of the blowing time and the blowing moment of which nozzle devices are regulated during the lift.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/WO-2012066182-A3/ops000.png)

![Sketch 1 for WO-2012066182-A3](https://nimo.iptorch.com/refdrawing/WO-2012066182-A3/ops000.png)

## Claims

### Claim 1 (independent)

Vacuum lifter for lifting laminar objects which lifter comprises one or several low- pressure chambers (4) which can be lowered on top of an object to be lifted, such as a board (1) with the help of a lifting apparatus, a sealing element (5) at the lower surface of a low-pressure chamber (4) which sealing element gets settled against the surface of the board (1), further a formation device of the low pressure, such as a suction unit which is connected to the low-pressure chamber (4) and a valve arrangement for creating low pressure in the chamber (4) and for removing the low pressure from the mentioned chamber, characterized in that at a grip area, which is limited (5) by the low-pressure chamber (4) and the sealing element onto the surface of the board (1), pressurized air or nozzle devices (9) blowing other pressurized gas are adjusted against the board (1) to be lifted the length of the blowing time and the blowing moment of which nozzle devices are regulated during the lift.

### Claim 2

Vacuum lifter according to the claim 1, characterized in that the nozzle devices (9) are adjusted to blow through the sealing element (5).

### Claim 3

Vacuum lifter according to the claim 1, characterized in that when more than one board (1) is rising during the lift, the pressurized air impulse can be regulated to have an effect against the surface of the uppermost board (1) through the nozzle devices (9).

### Claim 4

Vacuum lifter according to the claim 1 or 3, characterized in that the board (1) to be lifted is porous at least to a certain extent, such as it lets the air go through it and the pressurized air impulse is given at that stage of the lift when several boards (1, 2, 3) have risen due to the lift.

### Claim 5

Vacuum lifter according to the claim 1 or 3, characterized in that the board (1) to be lifted is porous at least to a certain extent such as it lets the air go through it and the pressurized air impulse is given simultaneously with the beginning of the lift.

### Claim 6

Vacuum lifter according to the claim 1, characterized in that the low pressure is arranged to have an effect on the board (1) through the holes (10) of the sealing element (5) and the amount of the nozzle devices (9) is 2-10 % of the amount of the mentioned holes (10).

## Full description

**[0001]**

VACUUM LIFTER

**[0002]**

The invention relates to a vacuum lifter for lifting laminar objects which lifter comprises one or several low-pressure chambers which can be lowered on top of the object to be lifted, such as a board, at the lower surface of the low-pressure chamber a sealing element which element gets settled against the surface of the board, further a formation device of vacuum pressure, such as a suction unit which is connected to the vacuum pressure chamber and a valve arrangement for generating low pressure in the chamber and for removing low pressure from the mentioned chamber.

**[0003]**

Previously vacuum lifters according to the above mentioned preamble are known which vacuum lifters comprise either several suction pads or several low-pressure chambers or only one suction pad or a low-pressure chamber. These elements performing the grip are lowered on top of the object to be lifted with the help of the lifter, the low pressure is let to have an effect on the lifting elements and the lift of the object is performed. These kind of known solutions work when the item to be lifted is a flat board which is not porous that does not let the air go through it. If the boards let the air go through them, then usually instead of one board located in a pile, several boards will rise. Several boards can rise from the pile also therefore that they are glued or stuck to each other. One known solution is that some suction pads of the lifting apparatus are tried to get organized precisely to the edge of the board during the lift in which case they would at first lift open the edge of the bendable board and after that the whole board would come loose from the other boards of the pile. For example the patent publication US 6886827 is one example of how to separate this kind of uppermost, bendable board from the pile during the lift.

**[0004]**

The disadvantage of the lifter according to the publication US6886827 is the fact that at least one or preferably more of the suction graspers or suction pads must be directed to the edge part of the board to be lifted so that the edge of the board would start to bend up. Further these kind of graspers directed to the edge must still be separately raised up in front of the other graspers so that the edge would bend and the loosening of the board from the lower board would begin.

**[0005]**

There is no guaranteed solution for the lifting of the porous and relatively light boards so that the above mentioned disadvantages could be avoided. With the present invention the problems which have appeared during the lift of the porous boards have

**[0006]**

surprisingly been able to be solved earlier and it is characteristic of the invention that at the grip area, which is limited to the surface of the board by the low-pressure chamber and sealing element, one has adjusted pressurized air against the board to be lifted or nozzle devices blowing pressurized gas the length of the blowing time and blowing moment of which nozzle devices are regulated during the lift.

**[0006]**

Other embodiments of the invention have been shown in the dependent claims. With the vacuum lifter according to the invention an essential improvement is achieved regarding the lifting of the porous boards when between the uppermost board to be lifted and the next lowest board a pressurized air impulse can be blown through the porous uppermost board as a result of which only the uppermost board will be supported by the lifter. It is easy to arrange things so that the pressurized air impulse has an immediate effect through the uppermost board at certain places on the space between it and the next plate. It is also easy to adjust the timing and the duration of the pressurized air impulse. The solution according to the invention is especially applicable to a lifting system comprising one low-pressure chamber. If there are several chambers or suction pads in the system, also then the detachment way of the uppermost board according to the invention can naturally be applied by arranging the detaching blow to a required amount of chambers or suction pads.

**[0007]**

In the following the invention is described more detailed by referring to the accompanying drawings in which

**[0008]**

Figure 1 shows a vacuum lifter according to the invention being lowered on top of a board pile as a side view.

**[0009]**

Figure 2 shows a lift of the uppermost board performed by the vacuum lifter and the

**[0010]**

detachment of the extra boards.

**[0011]**

Figure 3 shows an enlargement of one part between the board and the low-pressure

**[0012]**

chamber.

**[0013]**

In the figure 1 a board pile is shown from which it is the meaning to lift only the uppermost board 1. The board 1, such as other boards, is a porous board which lets some air go through it, such as for example a fiber board, a chipboard or a MDF-board. The low-pressure chamber 4 performing the lift is lowered on top of the board pile. There is a sealing element, such as a cellular rubber seal 5 between the lower edge of the low- pressure chamber 4 and the board pile which sealing element makes sure that the low- pressure chamber 4 stays tight enough. Low pressure suction is directed to a unit 6 located

**[0015]**

on top of the chamber 4 which unit comprises for example a valve arrangement for letting the low pressure to have an effect on the chamber 4 and again for letting the chamber 4 to endure the pressure of the environment. When the chamber 4 becomes underinflated, the low-pressure chamber 4 is lifted with the help of lifting lugs 7.

**[0014]**

In the figure 2 a situation is shown where a board pile comprises porous boards 1 - 3 and the purpose is to lift only the uppermost board 1 from the board pile. The vacuum lifter is at first lowered on top of the board pile, such as in the figure 1. The low pressure has been let to have an effect on the chamber 4 and after that the low-pressure chamber 4 has been lifted a little bit upwards, for example 20 - 50 mm with the help of the lifter.

**[0015]**

In this example describing the invention three uppermost boards 1 - 3 have risen out of the pile because of the porosity of the boards 1 - 3. When the lift is stopped at this height, pressurized air is directed as an instantaneous impulse inside the low-pressure chamber 4 from several nozzles leaning to the surface of the uppermost board 1 against the uppermost board 1. Because of the porosity of the uppermost board 1 the pressurized air goes through the uppermost board and penetrates between the uppermost board 1 and the next board. The fast result of this is the fact that a fast expanding, thin pressurized air cushion becomes formed between the uppermost board 1 and the board 2 next to it which air cushion drops the boards 2, 3 which have risen with the board 1 back on top of the pile. When the boards 2 and 3 have not risen more than 20 - 50 mm, they drop very accurately to the pile to their original places. The board 1 stays firmly resting on the low-pressure chamber 4 because it is supported with the help of a very large underinflated surface area.

**[0016]**

Figure 3 shows a seal made of cellular rubber 5 which functions most preferably as a mat at the lower surface of the low-pressure chamber 4 covering the whole lower surface. The seal mat is supported inside the low-pressure chamber 4 for example with the help of an aperture plate so that it stays planar while the low pressure is having an effect. It is also possible that the seal 5 only surrounds around the lower edge of the low-pressure chamber 4 with a certain width. In this case the low-pressure chamber 4 must have a fairly small surface area and the boards to be lifted must be stiff so that they don't bend to be baggy inside the low-pressure chamber being pulled by the low pressure.

**[0017]**

In the figure 3 a situation is shown where the seal 5 comprises holes 10 from which the low pressure has an effect on the board 1 by pulling the board 1 close against the seal 5. Through the porous board 1 low pressure has also an effect on the next, lower board 2 and possibly still on the next ones, too. There are a lot of holes 10 being formed

**[0020]**

through the seal 5 having for example the diameter of 10 mm. Channels 8, along which the pressurized air impulses are given against the board 1 , are arranged through the low- pressure chamber 4 also to the seal 5 and a nozzle hole 9 is formed to the seal 5 through which nozzle hole the pressurized air has an access to the surface of the board 1 and also more or less through the board 1. In the seal 5 there are these channels of the pressurized air 8 and analogously nozzle holes 9 a couple per a gripper. There are considerably less of these than the holes 10 and regarding the diameter size the nozzle holes 9 are made smaller, such as for example 6 mm. The amount of nozzle holes 9 in the seal 5 is 2 % -10 % of the amount of the suction holes 10. It has been stated that even a small amount of nozzle holes 9 is enough to detach the extra boards from the uppermost board 1 because the pressurized air gone through the uppermost board 1 spreads immediately between the uppermost board and the board 2 next to it efficiently by detaching them from each other. It one uses a hole mat as a seal 5 which hole mat fills the lower surface of the whole chamber 4 the pressurized air nozzle holes 9 are located for the whole area.

**[0018]**

Pressurized air impulse is caused by opening a valve in the channel 8 after the boards 1 - 3 have been moved up a little bit with the lifter as many as of them can rise. The pressurized air is directed to have an effect only for a short while, approximately 0,5 - 3 s because it is known that it is enough for porous boards of a different type. Pressurized air impulse or other pressurized gas can also be directed simultaneously with the beginning of the lift onto the surface of the uppermost board 1 in which case the lower boards may stay at their places. The pressurized air can easily be directed from an external source along a hose to the low-pressure chamber 4 and further through it to the usage target for example along the structures of the lifter.

## Classifications

- B65G59/04
- B65H3/0816
- B65G2201/022
- B65H3/08
- B65H3/46
- B65H3/46
- B66C1/0268
- B66C1/0281

## Cited patent documents

- [FI-95455-C](https://patents.google.com/patent/FI95455C/en) — ISR
- [JP-H1111710-A](https://patents.google.com/patent/JPH1111710A/en) — ISR

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
