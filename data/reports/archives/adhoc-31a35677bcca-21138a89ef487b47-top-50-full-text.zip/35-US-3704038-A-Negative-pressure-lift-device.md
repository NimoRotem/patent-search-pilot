# 35. Negative pressure lift device

- **Archive rank:** 35 of 50
- **Publication:** [US-3704038-A](https://patents.google.com/patent/US3704038A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/027182731/publication/US3704038A?q=pn%3DUS3704038A)
- **Publication date:** 1972-11-28
- **Filing date:** 1971-07-12
- **Earliest priority:** 1970-07-15
- **Family:** 27182731
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** ECKERT PAUL
- **Inventors:** GLANEMANN RUDOLF

## Abstract

A negative pressure lift device is shown which exhibits a suction cannister consisting of an upper part shaped as a cover and having a center opening to accommodate a piston rod connected to a disk piston, and a funnel-shaped lower part connected thereto, which has a bottom opening to accommodate the disk piston. This device is provided with a sealing membrane affixed, respectively, in the flange-joint between the upper and lower parts and to the disk piston. When the piston rod is lifted a vacuum is created between the membrane, the lower part and the object to be lifted.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-3704038-A/000.png)

![Sketch 1 for US-3704038-A](https://nimo.iptorch.com/refdrawing/US-3704038-A/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/US-3704038-A/001.png)

![Sketch 2 for US-3704038-A](https://nimo.iptorch.com/refdrawing/US-3704038-A/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/US-3704038-A/002.png)

![Sketch 3 for US-3704038-A](https://nimo.iptorch.com/refdrawing/US-3704038-A/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/US-3704038-A/003.png)

![Sketch 4 for US-3704038-A](https://nimo.iptorch.com/refdrawing/US-3704038-A/003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/US-3704038-A/004.png)

![Sketch 5 for US-3704038-A](https://nimo.iptorch.com/refdrawing/US-3704038-A/004.png)

## Claims

### Claim 1 (independent)

A negative pressure lift device, comprising: a. a lift frame; b. a suction cannister having an upper cover portion with a center opening, and a lower generally funnel-shaped portion connected by a peripheral flange joint, said lower portion having a flat base with a center opening adapted to be placed over a flat object to be lifted; c. a hollow piston rod extending through said center opening of said upper portion having its upper end secured to said lift frame, and having a disk piston connected at its bottom end to close said center opening of said lower portion, said disk piston having bore hole means in communication with the interior of said piston rod; d. a sealing membrane fastened at its periphery in said flange joint and having a center opening with the edge thereof sealed to said disk piston whereby a vacuum can be developed between said membrane, said lower portion and said object when said piston rod is lifted; e first means including valve means within said hollow piston rod for opening and closing said bore hole means; and f. means on said lift frame responsive to the lifting thereof to operate said first means to open or close said bore hole means each time said frame is lifted in accordance with a predetermined program.

### Claim 2

The device of claim 1 wherein the hollow piston rod has an internal ring recess for an inner pressure cylinder with a piston and an inner piston rod which projects downwardly to said disk piston and constitutes a part of the said valve means, wherein the inner pressure cylinder is connected via a compressed air line to an outer pressure cylinder which is mounted on said lift frame wherein a piston of the outer pressure cylinder is connected to a pull rod of the lift frame, wherein compressed air generated in the outer pressure cylinder upon lifting of said pull rod is conducted either to said inner pressure cylinder or into the open by means of a commutator cylinder in said compressed air line which has a valve regulated by the pull rod carrying a pawl to actuate a ratchet wheel which in turn actuates the valve.

### Claim 3

A negative pressure lift device according to claim 1 wherein said first means includes a valve cylinder which is open on one side and provided with internal threads and an external collar in the area of the bore hole means, a screw plug screwed into the valve cylinder, an inner piston rod which fits through an opening in the screw plug, and which has a terminal collar, and a compression spring mounted between the plug and the inner ring recess.

### Claim 4

A device according to claim 3 wherein the disk piston bore hole means includes a large incomplete bore hole with a ring groove in the base thereof and a rubber seal therein, and a small concentric bore hole, said external collar of the valve cylinder pressing against said rubber seal and the closed end of the valve cylinder being located in the small bore hole of the disk piston when said bore hole means is closed.

### Claim 5

A negative pressure lift device according to claim 2 wherein the commutator cylinder exhibits two chambers in one of which a vaLve disk with a double-bearing commutator pusher is mounted which can be raised and lowered by that portion which projects to the outside of the chamber, for which purpose an octagonal commutator disk is employed, which is firmly connected to an eight-tooth ratchet wheel which is moved by the pawl.

### Claim 6

A negative pressure lift device according to claim 2 wherein two or more suction cannisters are mounted on an appropriately constructed lift frame and the size of the outer pressure cylinder is adjusted accordingly.

### Claim 7

A negative pressure lift device according to claim 2 wherein a hole in said lower portion closeable by said sealing membrane, is provided near the flange joint of the upper portion and the lower portion, from which hole a vacuum tube leads to a hollow traverse arm which communicates with a back pressure valve which is mounted on the underside of and in communication with the outer pressure cylinder and which opens when the lift device is raised to evacuated the traverse arm.

### Claim 8

A negative pressure lift device according to claim 7 wherein the sealing membrane exhibits a knub or the like on its underside opposite the hole, which knub fits into a recess located at one end of the hole.

### Claim 9

A negative pressure lift device according to claim 7 wherein an additional back pressure relief valve is provided on the underside of the outer pressure cylinder, which back pressure valve has a valve plate which closes an opening in the bottom of the outer pressure cylinder under the pressure of a spring and which back pressure valve opens to the outside under the affect of compressed air when the lift device is lowered.

### Claim 10

A negative pressure lift device according to claim 1 wherein said valve means comprises two valve disks connected together, between which a flexible membrane is stretched, wherein above the membrane in the upper valve disk a hole communicates with a compressed air line, and wherein beneath the membrane, in the lower valve disk, there is a hole into which an upward projecting center journal of the disk piston protrudes to a point just under the membrane.

### Claim 11

A negative pressure lift device according to claim 10 wherein the disk piston exhibits several air passage holes within the confines of a ring groove, in which rests a rubber seal.

### Claim 12

A negative pressure lift device according to claim 11 wherein the lower valve disk has a downwardly protruding ring shoulder which rests on the rubber seal of the disk piston when the valve is closed.

### Claim 13 (independent)

A negative pressure lift device, comprising: a. a lift frame; b. a suction cannister having a base with an opening therein adapted to be placed over an object to be lifted; c. a hollow piston rod extending through an opening in an upper cover portion of said cannister and having a disk piston at its bottom end to close said base opening, said disk piston having bore hole means leading to the interior of said hollow piston rod; d. means connecting said piston rod at its upper end to said frame; e. a flexible sealing membrane connected between said disk piston and the interior of said cannister; f. first means within said hollow piston rod for opening and closing said bore hole means; and g. second means on said lift frame responsive to the lifting thereof to operate said first means.

### Claim 14

The device of claim 13 wherein said bore hole means is alternately opened and closed by said first and second means as said lift frame is repeatedly lifted.

## Full description

**[p0001]**

[ NOV. 28, 1972 United States Patent Glanemann 3,431,010 3/1969 Glanemann..............294/64 R Rudolf Glanemann, Gimbter we 1,294,103 2/1919 Hitchcock................294/64 R Germany Primary Examiner-Even C. Blunk [73] Ass1gnee: Paul Eckert, Emsdetten, Germany Assistant Examiner nouglas Bems [22] Filed: Attomey-Merchant &amp; Gould July 12, 1971 [54] NEGATIVE PRESSURE LIFI DEVICE [72] Inventor: [21] Appl. No.: 161,784 [30] Foreign Application Priority Data a suction cannister consisting of an upper part shaped .P 20 35 058.7 as a cover and having a center opening to accom- 21 00 974-5 modate a piston rod connected to a disk piston, and a funnel-shaped lower part connected thereto, which Germany......... March 5, 1971 Germany..........P 21 10711.9 has a bottom opening to accommodate the disk piston. This device is provided with a sealing membrane af- US. ....294/65, 294/64 R [51] Int. 1/02 .294/64 A, 64 B, 64 R, 65 fixed, respectively, in the flange-joint between the upper and lower parts and to the disk piston. When [58] Field of Search...........

**[p0002]**

R f Cted the piston rod is lifted a vacuum is created between 6 erencw l the membrane, the lower part and the object to be UNITED STATES PATENTS lifted- 3,033,381 5/1962 Noble et a1. ...294/65 14 Claims, 8 Drawing Figures PATENTEDNHV 28 1972 3. 7 O4 038 SHEET 2 0F 5 INVENTOR 4 0004; mms-rm/m 6V PATENTED HV 28 3. 704.038 saw u 0r 5 PATENTEDNUVZB I972 I 3,704,038 SHEET 5 OF 5 INVENTOR NEGATIVE PRESSURE LIFI DEVICE BACKGROUND OF THE INVENTION A familiar vacuum lift device is operated as follows: alternately, air is fed in under pressure, whereupon the high pressure is reduced. The operation is intricate and does not take place automatically when the implement is raised and lowered. SUMMARY OF THE INVENTION The invention answers to the task of creating a nega tive pressure lifting device which is equipped with a pneumatic automatic commutator switch which is simple in its construction, which can be quickly assembled from available components as though from a kit, and which is reliable in its operation.

**[p0003]**

The invention accomplishes this task as follows: the piston rod is hollow and has an inner ring mounting for an inner pressure cylinder with a piston, and an inner piston rod which points downward to the disk piston and constitutes part of the valve which is mounted in .the disk piston. The inner pressure cylinder is connected by means of a compressed air line to an outer pressure cylinder which is mounted in or on a lift frame. The piston of this latter cylinder is connected to the pull rod of the lift frame via the piston rod. In this device, the automatic release of the compressed air generatedin the outer pressure cylinder, either into the inner pressure cylinder or into the air, is accomplished by means of &#39;a commutator switch cylinder which is regulated by the push rod through the use of a pawl and a ratchet wheel. The pneumatically operated commutator valve consists of the following: a valve cylinder which is open on one side and provided with internal threads and an external collar in the area of the opening; a screw plug with a bore hole; the internal piston rod which passes through the bore hole and which has a terminal collar and a compression spring located between the plug (which is screwed into the valve cylinder) and the inner ring mounting, i.e., the inner pressure cylinder.

**[p0004]**

The disk piston has a large bore hole (which does not extend all the way through it) with a ring slot in the bot-&#39; tom wall thereof and a rubber seal therein, as well as a small concentric bore hole. When the valve is closed, the outer collar of the valve cylinder presses against this rubber seal and the closed end of the valve cylinder is located in the small bore hole of the disk piston. The commutator cylinder has two chambers. In one of these is located a valve disk with a double-bearing commutator pusher which can be raised lowered by that portion which extends beyond the chamber to the outside by means of an octagonal commutator disk which is firmly attached to the eight-tooth ratchet wheel which, is moved by the pawl. If the size of the outer pressure cylinder permits, two or more vacuum cannisters can be installed on a correspondingly constructed lift frame. To increase the security of the device, a bore hole, closeable by means of a sealing membrane, is provided near the flange-joint between the upper and lower part. From this bore hole, a vacuum tube leads to the hollow transverse arm which is connected to a back pressure valve located on the bottom side of the outer pressure cylinder and opening toward the transverse arm when the lift apparatus is raised. In a preferrable model, the

### Lii

**[p0005]**

sealing membrane has a knub or the like on its underside opposite the bore hole close to where it is mounted. This knub fits into a recess at one end of the bore hole. In an additional model, an additional back pressure valve is provided on the underside of the outer pressure cylinder, whereby the valve plate closes the opening in the bottom of the outer pressure cylinder under the pressure of a spring. This valve opens &#39;to the outside by action of compressed air when the lift device is lowered. To provide a much simplified automatic commutator for the negative pressure lift device, I suggest that the automatic pneumatic commutator located in the hollow piston rod consist of two valve disks screwed together, between which a flexible membrane is stretched, whereby above the membrane a bore hole connected toithe compressed air line is located in the upper valve disk while below the membrane, in the lower valve disk, a bore hole is located, into which a center journal of the disk piston protrudes upwardly to a point just beneath the membrane. The disk piston itself exhibits several air passage bore holes and a ring groove in which a rubber seal is present. The lower valve disk has a ring shoulder whichprotrudes downward which rests on the rubber seal of the disk piston when the valve is closed.

**[p0006]**

BRIEF DESCRIPTION OF THE DRAWINGS FIG. 1 shows an overall side view of the negative pressure device; FIG. 2 shows the vacuum cannister with valve in vertical section (inner automatic commutator); FIG. 3 shows the outer automatic commutator in partial section; FIG. 4 shows an overall side view of a second model of the negative pressure lift device; FIG. 5 shows the vacuum cannister with valve is vertical section (inner automatic commutator); FIG. 6 is an excerpt taken from FIG. 5; FIG. 7 shows the outer automatic commutator in partial section; and Y FIG. 8 shows in vertical section the vacuum cannister with the hollow piston rod and the automatic commutator installedtherein. DESCRIPTION or THE PREFERRED I EMBODIMENT The suction cannister consists of an upper part or portion 10 shaped as a cover and a funnel-shaped lower part or portion 11. In the upper part 10 there is an opening, through which a hollow piston rod 12 fits. The lower part 11 has an opening for a disk piston 13. A sealing membrane 14 is installed, on the one hand, with a peripheral edge thereof positioned between the flanges of upper part 10 and lower part 11 and, on the The hollow piston rod 12 has a so-called inner ring mounting 18 for an inner pressure cylinder 19, the cylinder neck of which fits through the opening of inner ring mounting 18 and is fastened by means of a nut 20. Inner piston rod 21, which exhibits a collar 23 on the end opposite piston 22 and constitutes part of the actual commutator valve, is guided in the cylinder neck. The inner pressure cylinder is so connected to a compressed air line

**[p0006]**

24 that the inflowing compressed air drives piston 22 upwards with the result that the inner piston rod 21 opens the valve.

**[p0007]**

The commutator valve consists further of a so-called valve cylinder 25 which is open on one side and has an outer collar 26 as well as internal threads in the vicinity of the opening. When the valve is closed, the closed end of valve cylinder 25 is located in a small bore hole of disk piston 13, while the outer collar 26 fills the large bore hole of disk piston 13 and pressed against a rubber seal 27 which in installed in a ring slot adjacent to the small opening of disk piston 13. The upper opening of the valve cylinder 25 is closed by means of a screw plug 28 against which compression spring 29 presses. This spring is braced toward the top against nut 20. i In FIG. 2, the commutator valve is shown in its closed position. When compressed air is fed into the inner pressure cylinder 19 through line 24, piston 22 moves upwards, and collar 23 of piston rod 21 raises screw plug 28 against the strength of spring 29, thereby raising valve cylinder 25 out of the valve seat so that the valve opens. With decreasing pressure in the inner pressure cylinder 19, compression spring 29 presses the commutator valve back into its seat and onto rubber seal 27 with the effect that a perfect seal is achieved.

**[p0008]**

The high pressure necessary to activate the commutator valve is generated outside the actual suction cannister (FIG. 3). For this purpose, an outer pressure cylinder 31 is located in or on a lift frame30. A piston 32 is in normal position, i.e., there is no raised load, on the bottom of the outer pressure cylinder 31. Piston rod 33 is suspended in a T-groove of pull rod 34. If this rod 34 is raised, then piston 32 also moves upwards and forces the air out of the outer pressure cylinder 31, thereby generating high pressure which is conducted away via high pressure line 24. Before piston 32 pushes against the cover of the outer pressure cylinder 31, the collar 35 of pull rod 34 strikes against the transverse arm of lift frame 30. The outer automatic commutator (also FIG. 3) consists of commutator cylinder 36, ratchet wheel 37 with commutator disk 38 and pawl 39 which is moveably mounted on pull rod 34. Commutator cylinder 36 consists of pressure distribution chamber 40 and a second chamber 41 which communicates with the first via bore holes. The second chamber contains valve disk 42, on which the commutator pusher 43 is mounted and extends to commutator disk 38.

**[p0009]**

&#39; The outer automatic commutator operates in such a way that the high pressure generated in the outer pressure cylinder 31 first reaches the pressure distribution chamber 40 via a high pressure line 240, from where it flows to the inner pressure cylinder 19 via another high pressure line 24. The valve opens and, when the negative pressure lift device is raised, the load is not taken up. The compressed air must flow in the above described way because valve disk 42 in the second chamber 41 is in the closed position. If the device is set down again, pull rod 34 again moves downward, whereby pawl 39 catches on a tooth of ratchet wheel 37, thus producing a rotation of commutator disk 38 which is connected with the ratchet wheel. In this way, commutator pusher 43 is operated and valve disk 42 lifts off. If the device is again raised, pressure is again built up in the described manner in outer pressure cylinder 31. Because of the opened valve 72, however, this pressure escapes via pressure distribution chamber and the second chamber 41 into the open through the bore holes. Thus, no compressed air reaches inner pressure cylinder 19, so that the commutator valve in hollow piston rod 12 remains closed. Now, the load is carried along as the negative pressure lift device rises.

**[p0010]**

The automatic commutator according to the invention is demonstrated only with a suction cannister. It is clear, of course, that the commutation can also be applied to several suctioncannisters. When this is done, the outer pressure cylinder 31 must then be larger because of the greater amount of compressed air needed. The outer automaticcommutator need not be altered. FIG. 1 shows an assembly with three suctioncannisters. The hollow piston rods 12 are suspended with connecting plates 44 which extend between a double traverse arm 45. The compression springs 46 between the connecting plates and the upper part 10 of the suction cannisters allows the negative pressure lift device to make soft contact with the object to be lifted. In the model according to FIGS. 4 through 7, a bore hole 47 is provided in the lower part close to the flangejoint. Fromthis bore hole, a vacuum line 48 leads to traverse arm a which must be hollow. The bore hole terminates inside the suction cannister in a recess 49 into which a knub 50 fits which is located on the underside of sealing membrane 14 near the point where it is held taut- The hollow traverse arm 45a communicates with the outer pressure. cylinder 31 via a back pressure valve 51. In the present case which involves an extra invention, the outer pressure cylinder 31 does not rest on the traverse arm, but is fastened to a bow-like frame structure at some interval from the traverse arm. The back pressure valve 51 is located between the underside of the outer pressure cylinder 31 and the hollow traverse arm 45a. The valve plate 52 of back pressu

**[p0010]**

re valve 51 is lifted off its valve seat 53 when piston 32 of outer pressure cylinder 31 moves upward when the lift device is raised. With this motion, the air is sucked out of the hollow traverse arm 45a via back pressure valve 51. In this way, a vacuum occurs in the traverse arm which is increased with each upward motion of piston 32. The reason is that the back pressure valve 51 closes automatically with the downward motion of piston 32. The air then escapes into the open from the outer pressure cylinder 31 via an additional back pressure valve 54 which is switched in the opposite way. The valve plate 55 of this second back pressure valve 54 which communicates with the outside air is pressed into its valve seat 57 by means of a compression spring 56 even when the piston 32 of the outer pressure cylinder 31 is not moving at all. Were it not for spring 56, the ascending piston 32 would not draw the air from the hollow traverse arm 450, but from the surrounding atmosphere. When piston 32 moves downward, the presbefore this situation occurs, however, knub&#39; 50 will have lifted off its bore hole seat, such that a connection with the negative pressure area in traverse arm 45a is created. In this way the vacuum reserve is considerably increased with a considerable increase in security.

**[p0011]**

FIG. 8 shows the pneumatic automatic commutator. This consists essentially of an upper valve disk 58 and a lower valve disk 59, between which a flexible membrane 60 is stretched. Both the upper valve disk 58 and the lower valve disk 58 and the lower valve disk have center bore holes, each of which terminates at the flexible membrane60. The bore hole of the upper valve disk communicates with high pressure line 24. A center journal 61 of disk piston 13 protrudes into the bore hole of the lower valve disk 59 to a point close under membrane 60. Disk piston 13 itself has several air passage bore holes 62 and a ring groove in which rests a rubber seal 27. The lower valve disk 59 has a ring shoulder 63 which protrudes downwardly and presses into rubber seal 27 when the valve is in the closed positron. The pneumatic automatic commutator works as follows: when compressed air, which is brought in via compressed air line 24, affects the flexible membrane 60, the result is that the membrane 60 pushes against the center journal 61 of disk piston 13. The application of additional compressedv air then results in even greater bulging of membrane 60, whereby the entire valve assembly is pushed upwardly, including the upper valve disk 58 and the lower valve disk59 attached thereto. in the process, ring shoulder 63 of lower valve disk 59 is simultaneously lifted off the rubber seal. The valve is now opened and no vacuum is created when disk piston 13 is raised. Conversely, if the pressure in compressed air line 24 diminishes, then the valve closes and a vacuum is created in the space located

**[p0011]**

beneath when the disk piston 13 rises.

**[p0012]**

What is claimed is: l. A negative pressure lift device, comprising: a. a lift frame; b. a suction cannister having an upper cover portion with a center opening, and a lower generally funnel-shaped portion connected by a peripheral flange joint, said lower portion having a flat base the edge thereof sealed to said disk piston whereby a vacuum can be developed between said membrane, said lower portion and said object when said piston rod is lifted; v I e first means including valve means within said hollow piston rod for opening and closing said bore hole means; and f. means on said lift frame responsive to the lifting thereof to operate said first means to open or close said bore hole means each time&#39;said frame-is lifted in accordance with a predetermined program. 2. The device of claim 1 wherein the hollow piston rod has an internal ring recess for an inner pressure cylinder with a piston and an inner piston rod which projects downwardly to said disk piston and constitutes a part of the said valve means, wherein the inner pressure cylinder is connected via a compressed air line to an outer pressure cylinder which is mounted on said lift frame wherein a piston of the outer pressure cylinder is connected to a pull rod of the lift frame, wherein compressed air generated in the outer pressure cylinder upon lifting of said pull rod is conducted either to said inner pressure cylinder or into the open by means of a commutator cylinder in said compressed air line which has a valve regulated by the pull rod carrying a pawl to actuate a ratchet wheel which in turn actuates the va

**[p0012]**

lve.

**[p0013]**

3. A negative pressure lift device according to claim 1 wherein said first means includes a valve cylinder which is open on one side and provided with internal threads and an external collar in the area of the bore hole means, a screw plug screwed into the valve cylinder, an inner piston rod which fits through an opening in the screw plug, and which has a terminal collar, and a compression spring mounted between the plug and the inner ring recess. 4. A device according to claim 3 wherein the disk piston bore hole means includes a large incomplete bore hole with a ring groove in the base thereof and a rubber seal therein, and a small concentric bore hole, said external collar of the valve cylinder pressing against said rubber seal and the closed end of the valve cylinder being located in the small bore hole of the disk piston when said bore hole means is closed. 5. A negative pressure lift device according to claim 2 wherein the commutator cylinder exhibits two chambers in one of which a valve disk with a double-bearing commutator pusher is mounted which can be raised and lowered by that portion which projects to the outside of the chamber, for which purpose an octagonal commutator disk is employed, which is firmly connected to an eight-tooth ratchet wheel which is moved by the pawl.

**[p0014]**

6. A negative pressure lift device according to claim 2 wherein two or more suction cannisters are mounted on an appropriately constructed lift frame and the size of the outer pressure cylinder is adjusted accordingly. 7. A negative pressure lift device according to claim 2 wherein a hole in said lower portion closeable by said sealing membrane, is provided near the flange joint of the upper portion and the lower portion, from which hole a vacuum tube leads to a hollow traverse arm which conununicates with a back pressure valve which is mounted on the underside of and in communication with the outer pressure cylinder and which opens when the lift device is raised to evacuated the traverse arm. 8. A negative pressure lift device according to claim 11 wherein the lower disk has a downwardly 7-wherein the sealing membrane exhibits a knub or the like on its underside opposite the hole, which knub fits into a recess located at one end of the hole. 9. A negative pressure lift device according to claim 7 wherein an additional back pressure relief valve is provided on the underside of the outer pressure cylinder, which back pressure valve has a valve plate which closes an opening in the bottom of the outer pressure cylinder under the pressure of a spring and which back pressure valve opens to the outside under the affect of compressed air when the lift device is lowered.

**[p0015]**

10. A negative pressure lift device according to claim 1 wherein said valve means comprises two valve disks connected together, between which a flexible membrane is stretched, wherein above the membrane in the upper valve disk a hole communicates with a compressed air line, and wherein beneath the membrane, in the lower valve disk, there is a hole into which an upward projecting center journal of the disk piston protrudes to a point just under the membrane. 1 l. A negative pressure lift device according to claim wherein the disk piston exhibits several air passage holes within the confines of a ring groove, in which rests a rubberseal. 12. A negative pressure lift device according to claim protruding ring shoulder which rests on the rubber seal of the disk piston when the valve is closed. 13. A negative pressure lift device, comprising: a. a lift frame; b. a suction cannister having a base with an opening therein adapted to .be placed over an object to be lifted; c. a hollow piston rod extending through an opening in an upper cover portion of said cannister and having a disk piston atits bottom end to close said base opening, said disk piston having bore hole means leading to the interior of said hollow piston rod;

**[p0016]**

d. means connecting said piston rod at its upper end to said frame; e. a flexible sealing membraneconnected between said disk piston and the interior of said cannister; f. first means within said hollow piston rod for opening and closing said bore hole means; and g. second means on saidlift frame responsive to the lifting thereof to operate said first means. 1 a 14. The device of claim 13- wherein said bore hole means is alternately opened and closed by said first and second means as said lift frame is repeatedly lifted;

## Figure captions

- **Figure 1:** BRIEF DESCRIPTION OF THE DRAWINGS FIG. 1 shows an overall side view of the negative pressure device;
- **Figure 2:** FIG. 2 shows the vacuum cannister with valve in vertical section (inner automatic commutator);
- **Figure 3:** FIG. 3 shows the outer automatic commutator in partial section;
- **Figure 4:** FIG. 4 shows an overall side view of a second model of the negative pressure lift device;
- **Figure 5:** FIG. 5 shows the vacuum cannister with valve is vertical section (inner automatic commutator);
- **Figure 6:** FIG. 6 is an excerpt taken from FIG. 5;
- **Figure 7:** FIG. 7 shows the outer automatic commutator in partial section; and Y FIG. 8 shows in vertical section the vacuum cannister with the hollow piston rod and the automatic commutator installedtherein.

## Classifications

- B66C1/025
- B66C1/025
- B66C1/02
- B66C1/0212
- B66C1/0212

## Cited patent documents

- [US-1294103-A](https://patents.google.com/patent/US1294103A/en) — SEA
- [US-3033381-A](https://patents.google.com/patent/US3033381A/en) — SEA
- [US-3431010-A](https://patents.google.com/patent/US3431010A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
