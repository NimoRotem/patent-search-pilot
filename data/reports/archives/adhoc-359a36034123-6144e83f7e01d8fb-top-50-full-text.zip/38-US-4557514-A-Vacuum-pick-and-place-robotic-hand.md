# 38. Vacuum pick and place robotic hand

- **Archive rank:** 38 of 50
- **Publication:** [US-4557514-A](https://patents.google.com/patent/US4557514A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/024534350/publication/US4557514A?q=pn%3DUS4557514A)
- **Publication date:** 1985-12-10
- **Filing date:** 1984-07-18
- **Earliest priority:** 1984-07-18
- **Family:** 24534350
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery

## Parties

- **Applicant / assignee:** AT & T TECHNOLOGIES INC
- **Inventors:** CUSHMAN ROBERT H; HOEGERMEYER CARL L

## Abstract

A hand (10) capable of simultaneously handling a plurality of articles (11) comprising a pickup head (15) having a plurality of vacuum pickup cavities (18), each cavity substantially matching the size and shape of the article to be handled. In one embodiment, the pickup head comprises a seal (26) positioned around an article-matching cavity (18) thereof and an opening (19) therethrough for communicating the cavity (18) with a vacuum chamber (20). In another embodiment, the pickup head comprises, positioned within its opening, a bellows (48) having a cylindrical sleeve (51) at one end and a planar flange (49) coupled to the vacuum chamber (20) by means of a seal (52) at its other end.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/ee/b9/0c/30aa770923b69e/US4557514-drawings-page-2.png)

![Sketch 1 for US-4557514-A](https://patentimages.storage.googleapis.com/ee/b9/0c/30aa770923b69e/US4557514-drawings-page-2.png)

[Sketch 2](https://patentimages.storage.googleapis.com/3d/9d/fe/efef1fd9f515fd/US4557514-drawings-page-3.png)

![Sketch 2 for US-4557514-A](https://patentimages.storage.googleapis.com/3d/9d/fe/efef1fd9f515fd/US4557514-drawings-page-3.png)

## Claims

### Claim 1 (independent)

An apparatus for handling an article comprising: a pickup head having first and second planar surfaces, the pickup head having a cavity formed therein proximate its first planar surface and substantially conforming to the geometry of an article to be handled; an opening formed in the pickup head for communicatively coupling the cavity with a chamber proximate the second planar surface of the pickup head; an elongated bellows having a first and a second end portion, said bellows being dimensioned to slide within said opening; a flange attached to the first end portion of the bellows and having a central aperture communicatively coupled to the chamber; and a sleeve attached to the second end portion of the bellows and dimensioned to slidably fit within said opening.

### Claim 2

An apparatus according to claim 1, wherein a portion of said sleeve extends away from said cavity in the absence of vacuum applied to the chamber.

### Claim 3

An apparatus according to claim 1, wherein, in response to vacuum applied to the chamber, the sleeve when contacting an article slides into the opening as said bellows contracts within said opening.

### Claim 4 (independent)

A robotic hand for simultaneously handling a plurality of articles comprising: a plate-like pickup head having first and second planar surfaces; a plurality of cavities formed in the pickup head proximate to the first planar surface thereof, said cavities substantially matching the respective size and shape of the articles to be handled; a like plurality of openings located within the pickup head and extending between the first and the second planar surface thereof for communicatively coupling a corresponding one of said plurality of cavities to a source of vacuum; a like plurality of selectively retractable and expandable means slidably fitting within said openings for simultaneously retaining and releasing the plurality of articles to be handled in and out of said cavities, each said retractable and expandable means including: an elongated bellows having a first and a second end portion, said bellows being dimensioned to slide within its corresponding opening; a flange attached to the first end portion of the bellows and having a central aperture communicatively coupled to the source of vacuum; and a sleeve attached to the second end portion of the bellows and dimensioned to slidably fit within its corresponding opening.

### Claim 5 (independent)

Method for simultaneously transferring a plurality of articles from a first work station to a second work station comprising the steps of: directing to the first work station an apparatus having a plurality of article-matching cavities formed therein, each cavity having an opening therein which receives a bellows provided with a flange at its upper end having a central aperture, and the bellows having a sleeve at its lower end which is dimensioned to fit within the opening in said cavity; aligning the sleeve at the lower end of the bellows in each cavity with a separate one of the plurality of articles located at the first work station; applying vacuum to said plurality of cavities to retract each of the bellows from its normal expanded state and thereby pull the plurality of articles into their corresponding matching cavities while maintaining their initial orientation and spacing; moving the apparatus with the plurality of articles held therein to the second work station; and interrupting the vacuum to cause each bellows to return to its expanded state thereby releasing the articles in their initial orientation and spacing out of their corresponding matching cavities onto the second work station.

## Full description

### Technical Field

**[p0001]**

The present invention relates generally to the field of manipulators, and more particularly, to an improved vacuum pick and place robotic hand for handling articles.

### Background Of The Invention

**[p0002]**

Over the past few years, industrial manufacturing production lines have included an increasing number of automated processes using programmable manipulators or robots. These robots simulate the hand, arm and wrist movements of a machine operator with consistent accuracy and without any risk to operator personal injury or fatigue. A variety of such robots have been proposed and are commercially available in various sizes, specifications and performances. One such commercially available robotic arm is the SEIKO Model 700 pick and place robot manufactured by Seiko Instruments Inc. of Japan. Such a known arm is capable of performing four basic motions usually required in a manufacturing or part assembly process. In the manufacture of large scale integrated semiconductor devices, it is usually necessary to first form the various circuit elements in a semiconductor wafer and then to cut the processed wafer into a plurality of individual integrated circuit (IC) chips. The latter are, in turn, mounted and assembled in individual packages called chip carriers varying in size, shape and type. Current IC chip mounting processes require the pre-heating of a package and the placing of an Au-P preform in a cavity of the package thereby forming a eutectic bond between the IC chip and the package. Chip protection is typically provided in a lid sealing operation where a gold plated lid is attached to the package. Such a lid sealing operation requires a very accurate positioning of the lid with respect to the chip carrier to achieve a reliable chip protection technique.

**[p0003]**

As integrated semiconductor IC packages are becoming smaller in size with the demand for such packages having recently substantially increased, the miniaturization of the IC packages renders unattractive any technique using a manual lid sealing operation. Indeed, in a manufacturing environment, such an operation would yield small throughput, would be labor intensive and would cause substantial reliability problems due to operator fatigue. Therefore, there exists a need for an apparatus (e.g., a robotic hand) of the pick and place type capable of accurately and reliably handling articles, in a manufacturing environment, while substantially avoiding the above-discussed difficulties.

### Summary Of The Invention

**[p0004]**

The foregoing need is met in an illustrative embodiment of the invention wherein an apparatus for handling an article comprises a pickup head having first and second planar surfaces, the head having a cavity formed therein proximate to its first planar surface and substantially conforming to the geometry of an article to be handled; and means located within the pickup head and extending between the first and second planar surfaces thereof for selectively retaining or releasing an article to be handled in or out of the cavity, respectively. In accordance with one embodiment of the invention, the means for selectively retaining or releasing an article comprise an opening formed in the pickup head for communicatively coupling the cavity with a vacuum chamber proximate to the second planar surface of the pickup head. In a preferred embodiment of the invention, the opening comprises selectively contractable or expandable means positioned therein and including an elongated bellows having a first and a second end portion, the bellows being dimensioned to slide within the opening; a flange attached to the first end portion of the bellows and having a central aperture communicatively coupled to the chamber; and a sleeve attached to the second end portion of the bellows and dimensioned to slidably fit within the opening.

### Brief Description Of The Drawings

**[p0005]**

FIG. 1 illustrates an enlarged partial cross-sectional view of a hand in accordance with one embodiment of the invention; and FIGS. 2A and 2B illustrate portions of a robotic hand, in two different positions, in accordance with a preferred embodiment of the invention.

### Detailed Description

**[p0006]**

Shown in FIG. 1 is a hand 10 for handling one or a plurality of articles 11 located in an article-receiving plate 12. Each one of the articles 11--11 to be handled by the hand 10 is located in a cavity 13 formed in the upper surface of the article-receiving plate 12. A through hole 14 formed in the plate 12 connects the cavity 13 with the lower surface of the plate 12. The articles 11 held in the plate 12 may include chip carriers, lids for chip carriers, or other relatively flat electronic components commonly used in the electronics industry. The hand 10 comprises a plate-like pickup head 15 having a first planar surface 16 and a second planar surface 17, and a cover 21 sealably attached to the pickup head 15. For purpose of illustration only, a cross-sectional view of a portion of the hand 10 in accordance with one embodiment of the invention is shown. As shown, the first planar surface 16 of the pickup head 15 has a plurality of cavities 18 formed therein. Each cavity 18 is dimensioned to substantially match the dimensions, size and shape of the articles 11 to be handled by the hand 10. As will be explained in connection with the operation of the hand 10, the cavities 18 are designed to receive and to retain therein the articles 11 to be handled.

**[p0007]**

In accordance with an embodiment of the invention, each one of the cavities 18 communicates with a vacuum or pressurized fluid source (not shown) via an opening 19 located within the pickup head 15 and extending between its first and its second planar surfaces 16 and 17. As shown in FIG. 1, the opening 19 couples the cavity 18 with a chamber 20 via an orifice 25 formed in the cover 21 which, in turn, is sealably attached to the second planar surface 17 of the pickup head 15 by means of a sealing member 26. The chamber 20 is coupled, via a conduit 22, to a vacuum source or to a source of pressurized fluid, e.g., air (not shown). As illustratively shown, a hand mounting base 23 formed on or attached to the cover 21 may be connected to a wrist flange portion 24 of a robotic arm (not shown) or to some other selectively movable apparatus. Also, positioned around the periphery of each one of the cavities 18 is a sealing element 27, e.g., an O-ring, made of a compliant-type material. Alternatively, a single sealing element may be used and positioned around all the cavities 18 formed in the pickup head 15.

**[p0008]**

The operation of the hand 10 in accordance with the present invention will be hereafter described with reference to the handling of one article 11 out of the receiving plate 12 by means of the hand 10. However, applying the present inventive teachings to simultaneously handling a plurality of articles 11, whether arranged in an array of articles or in a single row of articles, is well within the spirit and scope of the present invention. Referring to FIG. 1, first the hand 10 is moved toward the article-receiving plate 12 until the sealing element 27 contacts the upper surface of the plate 12 thereby sealing the two cavities 13 and 18. Next, vacuum is applied to the chamber 20 via the conduit 22. This results in vacuum being applied to the pickup head cavity 18 via the orifice 25 and the opening 19. The article 11 being located in the plate-cavity 13 will thus be transferred to the head-cavity 18 with its initial orientation maintained. The article 11 is retained in the cavity 18 by means of the applied vacuum. Without interrupting the applied vacuum, the hand 10 with the article 11 held therein may now be moved away from the plate 12 to another location or work station. The release of the article 11 out of the cavity 18 while maintaining its initial orientation may be achieved by interrupting the vacuum and allowing the article 11 to &#34;drop out&#34; of the cavity 18 under the effect of gravity. Alternatively, a source of pressurized air may be coupled, via the conduit 22, to the chamber 20 in order to &#34;push&#34; the article 11 and release it out of the cavity 18.

**[p0009]**

Successful transfer of a plurality of articles 11 from the plate 12 into the cavities 18 is achieved by adequately selecting the size of the orifices 25 as a function of the applied vacuum and the overall articles&#39; characteristics. Similarly, the size of the orifices 25 will determine whether the articles are successfully transferred when one or more article is missing from, or misaligned within, the plate 12. In accordance with an embodiment of the invention, the initial orientation of the plurality of articles 11 is maintained while the articles are transferred from the plate 12 into the pickup head 15. Also, the center-to-center spacing between the articles 11 is maintained during all of the article handling steps. Referring now to FIGS. 2A and 2B wherein a portion of a robotic hand 40 in accordance with a preferred embodiment of the invention is shown in two different operational positions. Various structural elements of this robotic hand 40 have identical reference numerals to the numerals of the hand 10 of FIG. 1 to illustrate the similarities of these two embodiments.

**[p0010]**

The plate-like pickup head 15 has a through hole 41 formed therein and extending between its first planar surface 16 and its second planar surface 17. An elongated tubular body 42 is positioned within the through hole 41 with one end portion 43 thereof flush with the second planar surface 17. The other end portion 44 of the tubular body 42 may also be flush with the first planar surface 16, or may extend away from the first planar surface 16 as shown. In either case, the cavity 18 which substantially matches the dimensions, size and shape of the article 11 to be handled by the hand 40 is formed in the end portion 44 of the tubular body 42 which is a mere extension of the pickup head 15. The tubular body 42 has an opening 46 extending longitudinally therein between its two end portions 43 and 44. The opening 46, which also extends between the two planar surfaces 16 and 17 of the pickup head 15 communicatively couples the cavity 18 with the chamber 20 formed in the cover 21 attached to the pickup head 15.

**[p0011]**

In accordance with a preferred embodiment of the invention, a selectively expandable and contractable member 47 is positioned within the opening 46 of the tubular body 42. The member 47 comprises an elongated bellows 48 dimensioned to a loose slide non-contact fit within the opening 46. The outer diameter of the bellows 48 is selected such that it remains clear from the wall of the opening 46 thereby resulting in stick-free operation as well as a substantially increased operational life of the bellows. Attached to the upper stationary end of the bellows 48 is a flange 49 having a central aperture 50 and adapted to fit and sit in the end portion 43 of the tubular body 42. At the lower free end of the bellows 48 is a sleeve 51 attached thereto and dimensioned to a tighter slide fit within the opening 46 so as to keep the bellows 48 centered in the opening 46. A sealing ring 52 is located between the flange 49 and the cover 21 to prevent leaks when vacuum is applied to the chamber 20. The tubular body 42 may be removed out of the through hole 41 for repair or maintenance purposes. Moreover, the tubular body 42 may be easily replaced when a different shape cavity 18 is needed to handle a different type article 11.

**[p0012]**

In operation, the robotic hand 40 is lowered toward the article-receiving plate 12 such that the lower end of the sleeve 51 contacts the surface of the article 11 as shown in FIG. 2A. As the vacuum is applied to the chamber 20, the bellows 48 contracts thereby pulling the article 11 toward the pickup head 40 into the cavity 18 thereof as shown in FIG. 2B. In order to unload the article 11 from pickup head 40 onto a receiving plate (such as 12), the vacuum is turned off causing the spring action of the bellows 48 to expand, thus pressing or pushing the article 11 out of the cavity 18 into a receiving cavity of the plate. The slide fit between the bellows 48/sleeve 50 and the opening 46 causes, when the bellows 48 contracts during the pickup of an article 11, a puff of air to be created between the selectively contractable and expandable member 47 and the opening 46. The foregoing prevents any particles from entering the space between the outer diameter of the bellows 48 and the confining walls of the opening 46.

**[p0013]**

Thus, in accordance with an embodiment of the invention, the vacuum is used to pull the article 11 into the cavity 18 and, when the vacuum is released, the bellows 48 acts as a spring to push the article 11 into an article-receiving cavity (such as 13). In other words, the bellows 48 has dual useful functions in both operational cycles of the hand 40, i.e., in the pickup mode and in the release mode. It is to be understood that the above-described embodiments are simply illustrative of the principles of the invention. Various other modifications and changes may be devised by those skilled in the art which will embody the principles of the invention and fall within the spirit and scope thereof.

## Figure captions

- **Figure 1:** FIG. 1 illustrates an enlarged partial cross-sectional view of a hand in accordance with one embodiment of the invention; and
- **Figure 2A:** FIGS. 2A and 2B illustrate portions of a robotic hand, in two different positions, in accordance with a preferred embodiment of the invention.
- **Figure 2A:** Referring now to FIGS. 2A and 2B wherein a portion of a robotic hand 40 in accordance with a preferred embodiment of the invention is shown in two different operational positions. Various structural elements of this robotic hand 40 have identical reference numerals to the numerals of the hand 10 of FIG. 1 to illustrate the similarities of these two embodiments.

## Classifications

- B65G47/91
- B65G47/91
- B25J15/06
- B25J15/0616
- B25J15/0616
- B65G47/91

## Cited patent documents

- [US-2163441-A](https://patents.google.com/patent/US2163441A/en) — SEA
- [US-3158381-A](https://patents.google.com/patent/US3158381A/en) — SEA
- [US-3389682-A](https://patents.google.com/patent/US3389682A/en) — SEA
- [US-3865359-A](https://patents.google.com/patent/US3865359A/en) — SEA
- [US-3929234-A](https://patents.google.com/patent/US3929234A/en) — SEA
- [US-3949295-A](https://patents.google.com/patent/US3949295A/en) — SEA
- [US-4006909-A](https://patents.google.com/patent/US4006909A/en) — SEA
- [US-4119211-A](https://patents.google.com/patent/US4119211A/en) — SEA
- [US-4138692-A](https://patents.google.com/patent/US4138692A/en) — SEA
- [US-4162018-A](https://patents.google.com/patent/US4162018A/en) — SEA
- [US-4221356-A](https://patents.google.com/patent/US4221356A/en) — SEA
- [US-4351518-A](https://patents.google.com/patent/US4351518A/en) — SEA
- [US-4428815-A](https://patents.google.com/patent/US4428815A/en) — SEA
- [US-750667-A](https://patents.google.com/patent/US750667A/en) — SEA

---

Generated by IPtorch. Verify legal conclusions against the official publication.
