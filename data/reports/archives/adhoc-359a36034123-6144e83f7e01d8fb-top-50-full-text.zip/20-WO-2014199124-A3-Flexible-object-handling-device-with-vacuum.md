# 20. Flexible object-handling device with vacuum

- **Archive rank:** 20 of 50
- **Publication:** [WO-2014199124-A3](https://patents.google.com/patent/WO2014199124A3/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/048914555/publication/WO2014199124A3?q=pn%3DWO2014199124A3)
- **Publication date:** 2015-03-26
- **Filing date:** 2014-05-29
- **Earliest priority:** 2013-06-14
- **Family:** 48914555
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus

## Parties

- **Applicant / assignee:** UNIV BRISTOL
- **Inventors:** BOWERING MARK; MCKEOWN COLM

## Abstract

The present invention provides object-handling devices having a device body connected to a deformable object-contacting portion useful in moving objects, such as composite materials, from one location to another. Also provided are methods of handling an object using object-handling devices and object-handling assemblies including object-handling devices.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/WO-2014199124-A3/pdf000.png)

![Sketch 1 for WO-2014199124-A3](https://nimo.iptorch.com/refdrawing/WO-2014199124-A3/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/WO-2014199124-A3/pdf001.png)

![Sketch 2 for WO-2014199124-A3](https://nimo.iptorch.com/refdrawing/WO-2014199124-A3/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/WO-2014199124-A3/pdf002.png)

![Sketch 3 for WO-2014199124-A3](https://nimo.iptorch.com/refdrawing/WO-2014199124-A3/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/WO-2014199124-A3/pdf003.png)

![Sketch 4 for WO-2014199124-A3](https://nimo.iptorch.com/refdrawing/WO-2014199124-A3/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/WO-2014199124-A3/pdf004.png)

![Sketch 5 for WO-2014199124-A3](https://nimo.iptorch.com/refdrawing/WO-2014199124-A3/pdf004.png)

## Claims

### Claim 1

CLAIMS : .1. An. object-handling device having a device body connected to a deformable o ject-contacting portion, the object-contacting portion having an obj ect -contacting surface with two or more gripping apertures, ^each gripping aperture being connected to a vacuum source for gripping an object, onto the contacting surface, wherein the device body is connected to the object-contacting portion by one or more manipulating arms for manipulating the shape of the object-contacting surface. 2. The object-handling device of claim 1, wherein at least one of the manipulating arras is a robotic manipulating arm. 3. The obj ect -handling device of claim. 1, wherein at least one of the manipulating arms is a manually-adjustable manipulating arm. 4. The ob ect-handling device of any one of claims 1 to 3, wherein at least one manipulating arm has four, five, six, seven, eight or more degrees of motion, 5. The ob ect-handling device of claim 4, wherein at least one manipulating arm is a 5-axis robotic manipulating arm, 6. The object-handling device of any one of claims 1 to 5, wherein the flow of gas from a first gripping aperture to th vacuum source to which the first gripping aperture is connected is independently controllable from the flow of gas from a second gripping aperture to the vacuum source to which the second gripping aperture is connected. 1. An object-handling device having a device body connected to a deformabie ob ect-contacting portion, the obj ect -contacting portion having an o ject-contacting surface with two or more gripping apertures, whereby each gripping aperture is connected to a vacuum, source for holding an object on the contacting surface <f> and flow of gas from two or more of the gripping apertures to a vacuum source is independently controllable. 8, The object-handling device of claim 6 or claim 7, wherein the flow of gas from each gripping aperture to the vacuum source to which the aperture is connected is .1nde enden11y con.trollable. 9, The ob ect-handling device of any one of claims 6 to 8, wherein the connection between at least one gripping aperture and the vacuum source to which it is connected is reversibly closable independently from the reversibly closable connection between at least one other gripping aperture and the vacuum source to which the aperture is connected, 10, The object-handling device of any one of claims 6 to 9; wherein the flow rate of gas from at least one gripping aperture to the vacuum source to which the aperture is connected is independently controllable from the flow rate of g s from at least one other gripping aperture to the vacuum, source to which the aperture is connected , 11, The object-handling device of any one of claims 6 to 10, wherein the object-handling device has a valve between each independently controllable gripping aperture and the vacuum source to which each aperture is connected to control the flow of gas from the gripping aperture to the vacuum source to which the aperture is connected. 12, The obj ect-handli g device of claim 11, wherein the valve is controlled electronically. 13 The object-handling device of claim. 11, wherein the valve is manually controlled. 14. The object-handling device of any one of clalias 1 to 13, wherein the deformable ob ect-contacting portion is elastically deformable. 15. The object-handling device of any one of claims 1 to 14 , wherein the object is a composite pre-preg material or a dry fibre material. 16. The object-handling device of any one of claims 1 to 15, wherein the device body includes a movement arm attachment point. 17. The object-handling device of claim 16, wherein the device body includes an information connection point for exchanging information between the device and another electronic device. 18. A method of handling an object comprising the steps of; (i) contacting an object-contacting surface of an object handling device, the object-contacting surface having two or more gripping apertures to grip a surface of an object, the object-handling device having a device body connected to a deformafole ob ect-contacting portion with the object-contacting surface, each gripping aperture of the object-contacting surface being connected to a vacuum source to grip the object onto the contacting surface<f> and wherein the object-contacting portion is connected to the device body by one or more manipulating arras for manipulating the shape of the ob ect-contacting surface,* (ii) flowing gas from, one or more gripping apertures to the vacuum source when the object-contacting surface is in contact with the object; and (iii) moving the ob ect-handling device with the object on the object-contacting surface from a first location to a second location. 19, The method of handling an object of claim 18, including the step of altering the shape of the object-contacting surface with the manipulating arm or arms . 20. The method of handling an object of claim 19, wherein the step of altering the shape of the object-contacting surface with the manipulating arm or arms occurs during the step of moving the object from a first location to a second location, 21. A method of handling an obj ct comprising the steps (i) contacting an object-contacting surface with two or mors gripping apertures to grip a surface of an object,, the ob ect-handl ng device having a device body connected to a deferrable object-contacting portion with the ob ect-contacting surface, each gripping aperture of the object-containing surface being connected to a vacuum source to grip the object onto the contacting surface, and flow of gas from two or more gripping apertures to a vacuum source is independe tly controllable; (ii) flowing gas from one or .more gripping apertures to the vacuum source or vacuum sources whe the object-contacting surface is in contact with the object; and (iii) moving the object-handling device and gripped object from a first location to a second location. 22, An object-handling assembly including the object-handling device of any one of claims 1 to 17, wherein object-handling device is connected to a movement arm for moving the object-handling device from a first location to a second location, 23, An ob ect-handling device, object-handling assembly or method of handling an object as substantially described herein, with reference to the accompanying drawings .

## Full description

**[0001]**

OBJECT-HANDLING DEVICE

**[0002]**

The present invention relates to an object-handling device, use of such a device and a method of using the device to move objects from one location to another location .

**[0003]**

BACKGROUND TO THE INVENTION

**[0004]**

The movement of objects around, for example, a manufacturing plant or warehouse was traditionally done by manual handling of the objects from one location o another location. However, such method is very labour intensive. In addition, such method may lead to damage to the object or the errors in placing of the object.

**[0005]**

Such objects include composite materials and

**[0006]**

components of composite materials, which are now widely used In high-tech industries, such as the aerospace and automotive industries. Such composite materials and composite material components include "pre-preg"

**[0007]**

materials and dry-fibre materials.

**[0008]**

Pre-preg materials are made from fibres which are pre-impregnated with resin and partially cured. The resulting pre-preg is easy to handle and may be cured in a mould with other sheets of pre-preg to form composite articles .

**[0009]**

Dry-fibre materials, such as a fibre textile, are typically combined with a matrix to form composites. For example, carbon fibre cloth may be layered in sheets into a mould in the shape of a final product. The alignment and weave of the cloth fibres is chosen to optimise properties, such as strength and stiffness, of the final product . Epoxy resin (as a matrix material) may be

**[0010]**

.·;. poured into the mould, and the mould heated or air-cured to produce a fibre-reinforced polymer.

**[0010]**

Sheets or plies of dry-fibre composite or pre-preg material can be manually cut and transferred to a mould. However, such a process is time-consuming,, inefficient and may lead to errors in the placing of the plies within the mould. As a result<.>, accuracy of the moulding process may foe reduced, and the shape and form of the resuiting- moulded article may be compromised.

**[0011]**

Therefore,, it is desirable to automate such a process. Automated material handling devices may use a vacuum suction source to grip an object during transfer from, one location to another location.

**[0012]**

Typically, an array of suction cups or tubes is used to grip the object to be transferred. However, such suction cups or tubes may cause damage to the object or material, for example, by crumpling the flexible

**[0013]**

dry-fibre composite or pre-preg plies where the rim of the suction cup is in contact with the ply.

**[0014]**

Such composite materials (or components for making composite materials} may also be stacked, or laid-up, before the materials are used. It is important to transfer such materials without damaging the material.

**[0015]**

SUMMARY OF THE INVENTION

**[0016]**

At its most, general, the present invention provides an object-handling device having a deformable

**[0017]**

object-contacting surface for gripping an object, wherein the shape of the ob1 ect-contacting surface is manipulated by one or more manipulating arms connecting the

**[0018]**

deformable obj ect-contacting portion to a device body. The object-handling device allows manipulation of the shape of the object-contacting surface before and/or

**[0020]**

during handling of the object on the o ect-contacting surface. When the ob ect-contacting surface is

**[0019]**

manipulated during handling of the object, the shape of the object may be manipulated before placing of the object. When the ob ect-contacting surface is

**[0020]**

manipulated before gripping the object , a good fit between the object and the obj ct-contacting surface may<¬> be provided to optimise gripping of the object.

**[0021]**

In a first aspect, the present invention provides an object-handling device having a device body connected to a deformable ob ect-contacting portion, the

**[0022]**

object-contacting portion having an object-contact surface with two or more gripping apertures, each

**[0023]**

gripping aperture being connected to a vacuum source for gripping an object onto the contacting surface, wherein the device body is connected to the ob ect-contacting portion by one or more manipulating arms for manipulating the shape of the object-contacting surface.

**[0024]**

The object-handling device has a deformable

**[0025]**

object-handling portion with an object-contacting

**[0026]**

surface. The deformable nature of the ob ect-handling portion allows the shape of the object-contacting surface to change before and/or while an object is held on the object-contacting surface by suction from the gripping aperture or a ertures .

**[0027]**

The shape of the ob ct-contact surface may be manipulated by one or more manipulating arms connecting the deformable object-contacting portion with the device body. The manipulating arm or arms are adjustable between two or more positions to allow the position of one or more parts of the object-contacting surface to be moved relative to other parts of the surface. For

**[0028]**

example, the manipulating arm or arms may be adjust ble

**[0031]**

between a first locked position and a second locked position. The shape of the object-contacting surface is thus altered.

**[0029]**

The present invention also aims to automate some, most or all of the process of moving a composite material (or component for making a composite material) , for example, in laying up the materials. For this reason, the control of any of the features described below, such, as the movement of the manipulating arms or the

**[0030]**

regulation of the gas flow to or from the gripping apertures, may be automated. Such automation, per se, is known in the art.

**[0031]**

The obj ect-handling device may have a single

**[0032]**

manipulating arm or a plurality of manipulating arms. Ά single central manipulating arm may be used to alter the shape of the object-contacting surface from a central position. Preferably the device has a plurality of manipulating arms . The number of manipulating arms is not particularly limited, and the skilled person may select the number of a s appropriate to the design of the object-contacting portion, e.g. the shape,

**[0033]**

flexibility, and to the needs of the user. The device may have 2, 3, 4, 5, 6 or more manipulating arras. When the object-contacting portio has corners, the device preferably has a manipulating arm for each corner. The manipulating arms may be positioned at each corner of the object-contacting portion, the manipulating arms may be positioned along a side of the object-contacting portion, or the manipulating arms may foe positioned in a

**[0034]**

combination of sides and corners of the object-contacting portion. Preferably the device has 4 manipulating arms, each arm being positioned at a corner of the

**[0035]**

obj ct-contacting portion.

**[0039]**

The manipulating arm or arms will have one or more degrees of motion, e.g. rotation. Preferably the

**[0036]**

manipulating arm or arms have four,, five, six, seven,, eight or more axes of motion. More preferably the manipulating arm or arras have four, five,- six, seven,, eight or mere degrees of rotation. A 5--axis manipulating arm is particularly preferred. The manipulating arm may have one or more of a body joint attached to the device body, an object-contacting portion joint attached to the object-contacting portion and an. elbow joint positioned at an intermediate point along the manipulating arm. The elbow joint may be positioned around midway along the length of the manipulating arm.

**[0037]**

The manipulating arm or arms may be manually

**[0038]**

adjusted, for example, by screw adjustment.

**[0039]**

.Alternatively, the manipulating arm or arms may be mechanically driven. Preferably the manipulating arms are robotic manipulating arms . For example, the robotic manipulating arm may be a 5-axis robotic manipulating arm. The adjustment of the robotic manipulating arms may be programmed so that the shape of the ob ect -contact ing surface is formed in a precise manner. The adjustment of the robotic manipulating arms may be programmed by conventional methods of robotic programming. For

**[0040]**

example, a program controlling the robotic manipulating arm or arms may be fed with a number of variables, such as the relative positron of the gripped object on the object-contacting surface, the current shape of the object-contacting surface, and the current positions of the robotic manipulating arm or arms. Such information may be obtained, for example, visually, using positioning devices, such as position scanners, or from information provided by previous automated steps leading to the

**[0045]**

current position and shape of the object and components of the object-handling device, Ά predetermined desired shape of the ob ect-contacting surface (and/or attached object) may also be inputted into the program. Using the information provided, the program may then run an

**[0041]**

algorithm to find the required repositioning vector of one or more robotic manipulating arms in order to achieve desired shape of the object-contacting surface (and/or attached object) . Such an algorithm may involve

**[0042]**

predicting the change in normal vectors on the surface of the object -contacting surface (and/or attached object) to provide the desired shape.

**[0043]**

The deformable ob ect-contacting portion may be made of any deformable material. Preferably the deformable object-contacting portion is elasticaliy deformable.

**[0044]**

Examples of elasticaliy deformable materials include, but are not limited to, spring steely a rubber material and plexiglass (PMMA) .

**[0045]**

The deformable object-contacting portion is

**[0046]**

preferably a deformable object-contacting sheet or plate. The deformable sheet or piate has a relatively large object-contacting surface relative to its volume. Thus the deformable object-contacting sheet or plate is relatively cheap, lightweight and/or easy to manufacture.

**[0047]**

The object-contacting surface in the undeformed state is typically flat, although in other embodiments it may be curved. The object-contacting surface may be uncontoured across its surface. The thickness of the object -contacting sheet or plate may be substantially uniform in these embodiments. In alternative

**[0048]**

embodiments, the object-contacting surface may be

**[0049]**

contoured across at least part of its surface. For example, the object contacting surface may have a relief

**[0055]**

pattern across at least part of its surface. The relief pattern will typically have a shape that is independent of the overall shape of the deformable object-contacting portion, i.e. the relief pattern will not substantially change when the object-contacting portion is deformed. In these embodimen s, the thickness of the

**[0050]**

object-contacting sheet or plate may vary.

**[0051]**

The object- contacting surface has two or more

**[0052]**

gripping apertures and each gripping aperture is

**[0053]**

connected to a vacuum source. The outer rim of each aperture is flush with the rest of the obj ct-contacting surface. Accordingly, the apertures do not protrude from the surface and significant surface damage to the surface of the object may be avoided. The gripping apertures may be arranged in an array, such as a grid.

**[0054]**

Each gripping aperture is in fluid connection with a vacuum source. As described herein, a vacuum source is any device capable of drawing a gas from, the gripping aperture towards the vacuum source. The vacuum source is typically a vacuum pump. The vacuum source thus creates a flow of gas from the gripping aperture towards the vacuum source when the gripping aperture is uncovered or

**[0055]**

initially covered by an object. When the gripping aperture is covered by an objec , the vacuum source can create a vacuum or partial vacuum at the gripping

**[0056]**

aperture. The object to be handled may thus be held onto the ob ect-contacting surface, The flow rate of the gas will depend on, for example, the number of apertures gripping the object, the permeability of the object; the overall weight of the object and the weight distribution of the object. An appropriate flow rate for each

**[0057]**

aperture can be easily determined by the skilled person. Each gripping aperture may be connected to the same

**[0064]**

vacuum source as another gripping aperture, or to a different vacuum source than anothe gripping aperture.

**[0058]**

In preferred embodiments, the flow of gas from one (a first) gripping aperture to the vacuum source to which the aperture is connected is independently controllable <'>from the flow of gas from a different (second) gripping aperture to the vacuum source to which the aperture is connected. The independent control of the flow of gas from a gripping aperture to the vacuum, source may be,, for example, independently switching the flow on or off, or independently regulating the flow of gas from the

**[0059]**

gripping aperture to the vacuum source to which the aperture is connected. The flow of gas from the gripping aperture to the vacuum source to which the gripping

**[0060]**

aperture is connected may be varied to vary the extent of vacuum created when the gripping aperture is covered with the object so that the gripping force may be varied. The gas flowing from the gripping aperture to the vacuum source to which the gripping aperture is connected may be any gas or gas mixture, and is typically the atmospheric gas surrounding the device when in use. The gas may be, tor example, atmospheric air or one or more inert gases, such as nitrogen or argon.

**[0061]**

The flow of gas from one gripping aperture can be independe tly controllabl f om the flow of gas from another gripping aperture, for example, by connecting the first gripping aperture to a different vacuum source than the vacuum source of the second gripping aperture. In preferred embodiments, the object-handling device has a valve between each independently controllable gripping aperture and the vacuum source to which each gripping aperture is connected. In other words, the

**[0062]**

object-handling device may have a first valve between the

**[0070]**

first gripping aperture and the vacuum source to which the first gripping aperture is connected and a second valve between valve between the second gripping aperture and the vacuum source to which the second gripping aperture is connected. In these embodiments, the vacuum source connected to the first gripping aperture may be the different from the vacuum source connected to the second gripping aperture, but is preferably the same.

**[0063]**

Preferably the flow of gas from each gripping aperture to the vacuum, source to which each gripping aperture is connected is independently controllable. The flow of gas from each gripping aperture that is

**[0064]**

independently controllable may be, for example,

**[0065]**

switchable from an "on" position to an "off" position, The "on" position may allow flow of gas from the gripping aperture to the vacuum, source to which the aperture is connected. The <,> of f" position may block flow of gas flow of gas from the gripping aperture to the vacuum source to which the aperture is connected. Equally, rate of flow of gas from each gripping aperture that is independently control.]. able may be independently regulated. When the gas flow from, each gripping aperture is independently controllable, each independently controllable gripping aperture may be connected b a valve to the vacuum source to which the gripping aperture is connected.

**[0066]**

When the gas flow from two or more of the gripping apertures is independently controllable (e.g.

**[0067]**

independently switched on or off) , the object- contacting surface may have one or more gripping regions, the gripping regions being a group of adjacent gripping apertures with a flow of gas from the gripping aperture to the vacuum source to which the aperture is connected, when in use. These adjacent gripping apertures with a

**[0076]**

flow of gas from the gripping aperture to the vacuum source to which the aperture is connected are <M>on:" when in use, Gripping apertures adjacent to, but outside of the gripping region, will ot. have a flow of gas from the gripping aperture to the vacuum source to which the aperture is connected, when in use. These adjacent gripping apertures without a flow of gas from, the

**[0068]**

gripping aperture to the vacuum source to which the aperture is connected are "off" when in use. The gripping region can be changed from ofoj ect to object to match the outline of the object to be gripped.

**[0069]**

Within a gripping region, the flow rate of gas at one gripping aperture may be different from the reduction in gas pressure at another gripping aperture. For example, there may be a greater flow rate of gas at. one or more gripping apertures in a central gripping section of the gripping region compared to the flow rate of gas at one or more gripping apertures in an outer gripping section of the gripping region.

**[0070]**

Each valve connecting a gripping aperture to the vacuum source to which the aperture is connected allows the regulation of gas flow and/or gas flow rate from the gripping aperture to the vacuum source. One or more of the valves may be a solenoid valve, such as a pneumatic solenoid valve. Each valve may be controlled manually or electronically. Preferably the valves are controlled electronically. When the valve or val es are controlled electronically, a gripping region on the

**[0071]**

ob ect-contacting surface can be programmed to activate the valves and apertures within a gripping section automatically. Preferably the valves are in the body of the ofoj ect -handling device.

**[0081]**

The gripping apertures may be connected to a vacuum source with a vacuum hose. The vacuum hose may be ela.sticall.y d.eformable, e.g. a coiled hose, or may have a slack portion to allow for the vacuum hose to remain in contact with the aperture through the variety of shapes and positions of the deformable ob ect-contacting

**[0072]**

po tion ,

**[0073]**

One or more of the gripping apertures of the

**[0074]**

object-contacting surface may also connected to a

**[0075]**

gas -blowing source. As described herein, a gas-blowing source may be any device capable of flowing gas from the gas-blowing source to the gripping aperture,, such as a gas pump. The gas-blowing source thus provides a positive gas pressure at the gripping aperture. Such an

**[0076]**

arrangement allows an amount of gas to be blown out of the gripping aperture to, for example, release the gripped object or to clear debris, if required.

**[0077]**

Preferably all of the gripping apertures of the

**[0078]**

object-contacting surface are connected to a gas-blowing source . The gas flowing from the gas-blowing source may be any gas or gas mixture, and. is typically an.

**[0079]**

atmospheric gas. The gas may be, for example,

**[0080]**

atmospheric air or one or more inert gases, such as nitrogen or argon. In some embodiments, the gas blowing source, and the vacuum source may be the same device, namely a device capable of flowing gas from the device to the gripping aperture and also flowing gas from the gripping aperture to the device.

**[0081]**

Du ing use, the shape of the obj ect-contacting surface may be manipulated before gripping an object.

**[0082]**

The shape of the ob ect-contacting surface may be, for example, flat, convex, concave, have a double curvature such as a saddle curvature, or a shape that is

**[0093]**

compli.rnent.ary to a gripping surface of the object to be gripped.

**[0083]**

in some embodiments <f> the obj ct-contacting surface may have a preliminary gripping region including a subset of gripping apertures. The subset of gripping apertures provides a number of gripping apertures which may contact the object before the rest of the object-contacting surface, . This preliminary gripping region may have a small number of gripping apertures<.>, e.g. one or two, each aperture being connected to a vacuum source for holding the object onto the contacting surface. As a result,- the object-contacting surface initially grips the object with the small number of gripping apertures by providing a partial vacuum from a vacuum source at these preliminary gripping region gripping apertures. The relative

**[0084]**

position of the object and the ob ect-contacting surface may then be fixed. Then, the other parts of the

**[0085]**

ob ect -contacting surface (e.g. the rest of the gripping region) may be brought into contact with the object.

**[0086]**

This may be achieved by deforming the shape of the ob ect-contacting surface either by movement of the manipulating arms or by movement of the object-handling device as a whole. It is advantageous to pick up an object with such precision. For example, the exact

**[0087]**

position of the object on the object-contacting surface may be required for precision placing on a mould.

**[0088]**

In some embodiments <f> the object-contacting surface is convex and the preliminary gripping region may form at an apex region of the object -contacting surface.

**[0089]**

Alternatively, the object may be curved such that the preliminary gripping region may be formed when the object-contacting surface is flat or concave.

**[0101]**

The shape of the object-contacting surface may be manipulated to a shape that is complementary to the object to be gripped before the object-contacting surface contacts the object. In this wa ; a close fit between the object and the object-contacting surface can be produced .

**[0090]**

In preferred embodiments the shape of the

**[0091]**

ob ect-contacting surface is manipulated while the object is gripped to the object-contacting surface. In this way, the shape of the object is also manipulated. The shape of the obj ct can be manipulated to fit, for example, a shape of a component mould.

**[0092]**

The object-handling device of the present invention may also be used to stack, or lay-up, objects in a. pile. For example, the object-handling may be used to move objects from different locations to a single common location, and place several objects in a pile.

**[0093]**

The object-handling device may be connected to a movement arm for assisting the movement of the

**[0094]**

object-handling device, Such movement arm may be, for example, a crane. In preferred embodiments, the movement arm is a robotic movement arm. In these embodiments, the object-handling device is a robot end-effector.

**[0095]**

Accordingly, the ob ect-handling device may include a movement arm connection point on the device body. When the movement arm is a robotic arm, the movement arm connection point may include an information connection point to provide information to electronics within the object-handling device. Such information may be

**[0096]**

positioning information for the one or more robotic manipulating arms. Alternatively or additionally, the information may be valve i formation for a programmed sequence of valve openings or closings.

**[0109]**

The movement arm. may be anchored to a movement arm platform. The platform may be fixed to a single point on the ground or may be movable from one point to another point; e.g. by wheels or on a rail.

**[0097]**

The object to be handled on the object-contacting surface of the object-handling device is not particularly limited. The object may be an object with a cur ed or irregularly shaped surface. The ob ect-handling device described herein can manipulate the deformable

**[0098]**

obj ect-contact ing surface to complement the shape of the object and provide a good gripping surface. Such

**[0099]**

manipulation of the deformable object-contacting surface can be done before the object-contacting surface is in contact with the object and/or when part of the

**[0100]**

o ject-contacting surface is in contact with the object. Thus the deformable object-contacting surface can be manipulated to fit the shape of the object to be gripped and fine tuning shape changing can be performed when part of the obj ct-contacting surface is in contact with the object..

**[0101]**

In preferred embodiments, the object is a composite material or a component of a composite material

**[0102]**

{composite material component) , As descried herein, a composite material is any material made from two or more constituent materials with different physical or chemical properties, that when combined, produce a material with characteristics different from the individual components. Such composite materials include reinforced plastics, metal composites and ceramic composites. Components of a composite material are known to the skilled person. Such components include, for example, a single ply of fibre and a sheet of textile.

**[0116]**

In preferred embodiments, the composite material or composite material component is a sheet or ply. Such composite material plies may be cut from a larger sheet of composite material into a desired shape. Squally, the composite material component ply may be cut. from a larger sheet of composite material component material into a. desired shape. The composite material ply or composite material component ply may then be gripped by the

**[0103]**

ob ect-handling device and the shape of the composite material ply or composite material component ply altered by manipulating the shape of the ob ect -contacting

**[0104]**

surface of the device, A shaped composite material pl or composite material, component ply on the object-contacting surface of the device may then be placed onto a mould in a set shape and precise manner. Alternatively,, the composite material ply or composite material component ply on the object-contacting surface of the device may be placed onto another or other pli s, such as previously laid plies, In other words, the composite material ply or composite material component, ply may be laid-up. In some uses; the ob ect-handling device may be used to consolidate laid-piies for debuiking purposes. In other words, the object handling device applies a force onto the laid-up plies, for example, under its own weight or by controlled force. In such a way, the laid plies are compressed.

**[0105]**

A preferred composite material or composite material component is a pre-preg material. As described herein, a pre-preg material is a material of fibres pre-impregnated with a resin and. partially cured. Pre-preg materials are typically deformable and the surface may be damaged by excessive force used when handling such materials. The object-handling device as described herein can handle

**[0120]**

such pre-peg materials without significantly damaging the surface of the material. In addition, the

**[0106]**

object-handling device as described herein can alter the shape of the p.re-preg material, gripped to the deformabie ob ect-contacting surface in order to place the pre-preg material on, for example, a mould for final curing (along with other pre-preg plies) in a particular shape and configuratio .

**[0107]**

Another preferred composite material or composite material component is a dry-fibre composite material . Such materials m&y be a sheet of woven fibres .

**[0108]**

Typically, the dry-fibre material is made of fibres of a single material. However, dry-fibre materials using fibres of two or more materials, either in the same fibre or separate, fibres., may be used.

**[0109]**

In a second aspect, the present invention provides an object-handling device having a device body connected to a deformabie obj ect -contacting portion, the

**[0110]**

object-contacting portion having an object-contacting surface with two or more gripping apertures, whereby each gripping aperture is connected to a vacuum source for holding an object on the contacting surface, and flow of gas from two or more of the gripping apertures to the vacuum source to which the aperture is connected is independently control table .

**[0111]**

The device of the second aspect provides an

**[0112]**

ob ect-handling device with a deformabie

**[0113]**

obj ect-contacting surface whereby, in use, the

**[0114]**

obj ect~contacting surface may be divided into gripping sections where a vacuum is applied through each aperture within a section and non- gripping sections where no vacuum is applied through each aperture in the

**[0130]**

non-gripping section. As a result, efficient handling of irregularly shaped objects and/or multiple objects may be achieved >

**[0115]**

Preferably the flow of gas from each gripping

**[0116]**

apertures to the vacuum source to which each aperture is connected is independently controllable.

**[0117]**

In a third aspect, the present invention provides a method of handling an object comprising the steps of;

**[0118]**

{i} contacting an object-contacting surface of a object handling device, the object-contacting surface having two or more gripping apertures to a surface of an object, the object-handling device having a device body connected to a deformable object-contacting portion with the object-contacting surface, each gripping aperture of the obj ect -containing surface being connected to a vacuum source to grip the object onto the contacting surface, and wherein the object-contacting portion is connected to the device body by one or more manipulating arms for manipulating the shape of the. ob ect-contacting surface;

**[0119]**

(ii) flowing gas from one or more gripping apertures to the vacuum source when the object-contacting surface is in contact with the object; and

**[0120]**

(iii) moving the obj ect-handling device with the object on the object-contacting surface f om a first location to a second location.

**[0121]**

Preferably the method includes the step of altering the shape of the object-contacting surface with the manipulating arm or a ms. In some embodiments, the step of altering the shape o the object-contacting surface with the manipulating arm or arms occurs before step (i) , Additionally or alternatively, the step of altering the shape of the object-contacting surface with the

**[0138]**

manipulating arm or arms occurs during the step of .moving the object from a first location to a second location. In these embodiments, step (iii) may include stopping at an intermediate location to perform the step of altering the shape of the obj ect -contacting surface with the manipulating arm or arms.

**[0122]**

The flow of gas from a gripping aperture to a vacuum source may start before the object-contacting surface is in contact with the object. When the ob ect-contacting surface comes into contact with the object and the gripping aperture is covered,, gas flows frorn the gripping aperture to the vacuum source and creates a partial vacuum to hold the object to the object-contacting su face ,

**[0123]**

The second location for the object may be another area of a warehouse or factory. The method of the third, aspect may include the step of (iv) depositing the object at the second location. This step occurs after moving the obj ect-handling device to the second locatio in step (iii.}<*> Preferably step (iv) of the method includes flowing gas from a gas-blowing source in the

**[0124]**

object-handling device to one or more of the gripping apertures covered by or in contact with the object. In this way, the object may be pushed off the

**[0125]**

ob ect -contacting surface by the gas from the gas-b source .

**[0126]**

The second location may be a mould for receiving a composite material when the object is a composite material,- such as a composite ply. Alternatively, the second location is a pile location for depositing more than one object in a pile. Accordingly, the method of the third, aspect may include repetition of steps (i) , (ii) and (iii) one o more times with different objects.

**[0144]**

In a fourth aspect, the present invention provides a raethod of handling an object comprising the steps of:

**[0127]**

(i) contacting an object-contacting surface with two or more gripping apertures to a surface of an object, the ob ect-handling device having a device body connected to a deforraable object-contacting portion with the object- contacting surface, each gripping aperture of the object- containing surface being connected to a vacuum source to grip the object onto the contacting surface, and flow of gas from two or more gripping apertures to a vacuum source is independently controllable;

**[0128]**

(ii) flowing gas from one or raore gripping apertures to the vacuum source or vacuum sources when the

**[0129]**

object-contacting surface is in contact with the object; and

**[0130]**

(iii) moving the object-handling device and gripped object from a first location to a second location.

**[0131]**

The method of the fourth aspect provides a method using an ob ect-handling device with a deformabie

**[0132]**

object-contacting surface that may be divided into gripping sections where a vacuum is applied through each, aperture within a section and non-gripping sections where no vacuum is applied, through each aperture in the

**[0133]**

non-gripping section. As a result, efficient handling of irregularly shaped objects and/or multiple objects may be achieved.

**[0134]**

In a fifth aspect, the present invention provides an object-handling assembly including the obj ect-handling- device of the first or second aspect, connected, to a movement arm for moving the object -handling device from a first location to a second location.

**[0153]**

Also described herein is the use of an ob ect -handling device according to the first or second aspect for moving an object from one location to another location, whereby the object-handling device is connected to a movement arm.

**[0135]**

The preferred features of the each aspect may also foe preferred features of the other aspects of the

**[0136]**

invention. I particular, the preferred features of the object-handling device of the first aspect may be the preferred features of object-handling device of the second, third and fourth aspect, and the preferred method features of the third aspect may be the preferred method features of the fourth aspect.

**[0137]**

BRIEF DESCRIPTION OF THE DRAWINGS

**[0138]**

Figure 1 shows a perspective view of an

**[0139]**

object-handling device of the present invention.

**[0140]**

Figure 2 shows a perspective view of the

**[0141]**

object-handling device of Figure 1 from a different angle .

**[0142]**

Figure 3 shows a side view of the object-handling device of Figures 1 and 2 where a composite material is gripped to an object-contacting surface of the device.

**[0143]**

Figure 4 shows a side view of the object-handling device and gripped object of Figure 3, wherein the object-contacting plate and gripped object attached to the plate are bent by the robotic -manipulating arms connecting the plate to the device foody.

**[0144]**

Figure 5 shows a plan view of the obi eot-hand!ing device and g ipped object of Figure 3 showing the

**[0145]**

irregular outline of the object being gripped to the ob ect-contacting surface of the object-contacting plate .

**[0165]**

Figure 6 shows the object-handling device and gripped object of Figures 3 to 5, wherein the body of the device is connected to a robotic movement arm, the robotic manipulating arms of the device are bending the ob ect-contacting plate and gripped object in order to place the composite material object on to a mould.

**[0146]**

Figure 7 shows a alternative object-handling device of the present invention, whereby the manipulating arms are manually adjustable manipulating arms capable of adjusting between a first locked position and a second locked position.

**[0147]**

Note that the hoses connecting the vacuum source to each aperture on the obj ct-contacting plate (as shown in Figures 1, 2 and 7) are not shown in Figures 3, 4 and 6 for clarity purposes only.,

**[0148]**

DETAILED^

**[0149]**

The present invention provides an object-handling device, a method of moving an object and use of the object-handling device. The present invention will now be described in more detail with reference to the

**[0150]**

figures ,

**[0151]**

Figure 1 shows a perspective view of an

**[0152]**

object-handling device 2 of the present invention. The device has a device body 4 and adjustable robotic

**[0153]**

manipulating arms 6 connecting the device body 2 to an elastically deformable ob ect-contacting plate 8,

**[0154]**

The device body 4 has a body frame 10 formed from a top plate 12 connected to a bottom plate 14 by four upright corner struts 16. The device body frame 10 has a side plate 18 with a grid of solenoid valves 20

**[0155]**

protruding from the side plate 18.

**[0176]**

Each solenoid valve 20 is connected to a vacuum source {not shown} on one side of the solenoid valve 20. The other side of the solenoid valve 20 is connected to a vacuum hose 22, Each vacuum hose extends through an aperture in the bottom plate of the device body 4 to an. aperture on the object-contacting plate 8.

**[0156]**

There are four robotic manipulating arms 6 (one not shown) attached to the four corners of the square bottom plate of the device body frame 10. The robotic

**[0157]**

manipulating arm 6 has a body joint 24 where the robotic manipulating arm is attached to the device body frame 10. The robotic manipulating arm 6 has object-contacting portion joint 28 where the robotic manipulating arm is attached to the ob ct-contacting plate 8, An elbow joint is positioned around midway along the robotic

**[0158]**

manipulating arm 6.

**[0159]**

Each robotic manipulating arm 6 has multiple axes of movement. Each robotic manipulating arm is a 5-axis robotic manipulating arm. The body joint 24 and the object-contacting portion joint 26 each have two rotation modes: one axis of rotation perpendicular to the object- contacting plate 8 and one rotational axis parallel to the major plane of the object-contacting plate 8» The elbow joint 28 has a further axis of rotation. As a result, each robotic arm 6 has a wide range of movement and the four robotic arms 6 can. manipulate the object- contacting plate 8 into a large number of shapes or configurations .

**[0160]**

The valves 20 in the device body are numbered to correspond with a numbered aperture on the

**[0161]**

object-contacting plate to which, the valve 20 is

**[0162]**

connected. For example, the columns of the valves may be numbered A to X and the rows may be numbered 1 to 8.

**[0184]**

Each valve can then be identified according to its column and row, for example, F3. A similar grid marking system is used on the object-contacting piate so that valve F3 is connected to aperture F3. The valves can then be selectively opened to provide gripping regions on the obj ect-contacting surface .

**[0163]**

The device body 4 has a robotic movement arm

**[0164]**

attachment point 30 with three attachment nodes on the upper plate 12 of the device body frame 10. The

**[0165]**

attachment nodes are automatic Schunk clam s from Schunk GmbH, Other known att.achm.ent nodes may be used,

**[0166]**

Figure 2 shows the object-handling device shown in Figure 1 from a different perspective. The deformabl obj ect -handling plate 8 with its apertures 24 are visible from this viewpoint.

**[0167]**

The deformable object-contacting plate 8 is made of eiastically deformable plex.i-giass

**[0168]**

(polymethylmethacrylate, PMMA) - The underside of the object-contacting piate 8 has a. grid of gripping

**[0169]**

apertures 32. Each gripping aperture 32 is connected to a vacuum hose 22 on the upper side of the

**[0170]**

obj ect -contacting plate 8 , The grid of apertures 32 is arranged in an 18 x 18 square grid. However, the number, size, density and arrangement of the apertures 22 can be varied to suit the particular needs of a user, The grid of apertures 32 connected to the vacuum hoses 22 may form a gripping region on the underside (object-contacting surface) of the ob ect-contacting plate 8, The valves 20 in the device, body 1.0 can be selectively opened and closed in order to provide a flow of gas from some gripping apertures 32 to the vacuum source and no flow of gas from other gripping apertures 32 to the vacuum source

**[0193]**

during operation. As a result, a gripping region of gripping apertures 32 is created in tne area where the gripping apertures 32 are connected to an open valve. The formation of gripping regions with different shapes allows the object-contacting plate to hold objects with different outlines.

**[0171]**

Figure 3 and Figure 4 show a side view of the obj ct-handling device 2 of Figures 1 and 2 gripping an object 3 on the surface-contacting surface of the defcr able ob ect-contacting plate 8, As mentioned above, the vacuum hoses 22 have been omitted for clarity oniy .

**[0172]**

In operation,- the robotic arms 6 are locked into first position so that the surface-contacting plate 8 is substantially flat to provide a substantially flat object-contacting surface. A number of the valves 20 are opened to provide fluid contact between the vacuum source and some of the vacuum, hoses 22, Air in the vacuum, hoses 22 that are connected to an open valve 20 is drawn out of the hoses to the vacuum source. As a result, gas flows from the gripping apertures connected to the open valves 20 to create a gripping region on the

**[0173]**

object-contacting surface corresponding to. the shape of the object 34 to be picked up. The gas flow from the gripping apertures to the vacuum source or vacuum sources may be initiated after the object-contacting- surface is brought into contact with the object.

**[0174]**

The object-handling device 2 is moved into position, for example, using a robotic movement arm so that, the object-contacting surface of the device 2 comes into Contact with the object 34 to be gripped. The object 34

**[0198]**

to be gripped may be a piece of composite pre-preg ply cut out from a larger sheet of composite pre-preg material. The robotic movement arm can position the gripping region of the object-contacting surface adjacent to the section of the composite pre-preg material to be picked u based on the cutting coordinates from an

**[0175]**

automated catting process. This can ensure that the area gripping region on the object-contacting surface matches the shape and position of the pre-preg composite ply cut-out. As a result, the off-cuts (in other wo ds,, the material surrounding the cut-out) are not picked up by the ob ect-handling device.

**[0176]**

in addition, a sighting device to visually confirm the positioning of the ob ect-contacting plate 8 with respect to the object 34 to be picked up can be used.

**[0177]**

Once the object 34 has been gripped, the

**[0178]**

object-handling device is moved, for example, by the robotic movement arm, away from the original location of the object. The robotic manipulating arms 6 can then adjust their position relative to the device body 10 in order to deform the object-contacting plate 8. in this way, the shape of the object-contacting surface and the gripped obj ect 34 is altered, In Figure 4, the object- contacting plate is bent by the robotic arm 6 to give an arc cross-section. The bending of the ob ect-contacting plate 8 and gripped object 34 can be done while the obj ct-handling device is moving to another location or can be done while the obj ct-handling device is

**[0179]**

stationary at an intermediate location.

**[0180]**

In this embodiment, the negative pressure from the vacuum source at the gripping region is applied

**[0181]**

throughout the movement of the object-handling device 2 in order to ensure that the object 34 remains gripped to

**[0206]**

the object-contacting surface. However, in some

**[0182]**

embodiments the negative pressure from the vacuum source may be reduced or eliminated, and the object 34 remains gripped to the object-contacting surface.

**[0183]**

Figure 5 shows a pla view of the object 34 being gripped on the ob ect-contacting surface of the

**[0184]**

plexi-giass object-contacting portion 8, The grid of apertures 32 allows an object 34 with an irregular outline to be gripped. Negative pressure can be applied from the apertures 32: where the object 34 will be in.

**[0185]**

contact with the ob ect-contacting surface. The vacuum suction is spread over several apertures 32. As a result, there are several points on the surface of the object 34 where suctio is applied and so suction at each point can be relatively low. Accordingly, minimal or no sign ficant damage is done to the su face of the

**[0186]**

object 34.

**[0187]**

Figure 6 shows the ob ect-handling device 2 with a gripped object 34 attached to a robotic movement arm 36. The robotic movement arm 36 is fixed to a robotic

**[0188]**

movement arm platform 38. The robotic movement arm 36 has positioned the object-handling device 2 so that the object 34 may be placed on a mould 40. As in Figure 4, the robotic arms 6 are in a locked position such that the ob ect-contacting plate 8 and gripped object 34 are bent. The bending of the plate 8 and object. 34 correspond to the shape of the outer surface of the mould 40. In this way, the object 34 is in a shape complementary to the mould 40 before it is applied to the mould 40. Such a method reduces error in placing the object 34, such as a pre-preg composite ply.

**[0214]**

In th s embodiment the robotic movement arm 36 places the object 34 onto the mould 40 by movement of the object-handling device 2 and gripped object 34 towards the mould 40 by the robotic movement arm 36, However, it is possible that the final stages of placing the

**[0189]**

object 34 onto the mould 40 may be achieved by movement of the robotic manipulating arm 6. Such a movement would need to take into account any change in. the shape of the o ect-contacting plate 8 and gripped object 34 as a result of the movement in the robotic arms 6.

**[0190]**

Figure 7 shows an alternative object-handling device to that shown In Figure 1, whereby the robotic

**[0191]**

manipulating arms are replaced by manually adjustable arms 106. The manually adjustable manipulating arms 106 and thus the shape of the object-contacting plate 8 may be adjusted before the plate 8 grips an object and/or while the plate 8 is gripping an object. The manually adjustable manipulating arms may be manipulated between a first locked position and a second locked position. In this way, the ob ect-contacting plate may be manipulated between two different configurations and held In those configurations. Typically, the shape of the

**[0192]**

object-contacting surface will be different in the two different configurations of the object-contacting plate 8.

**[0193]**

Each manually adjustable arm 106 has an adjusting handle 122 positioned on a plate joint 126. The plate joint 126 is positioned by the attachment point,

**[0194]**

connecting the manually adjustable arm 106 to the object-contacting plate 8, The adjusting handle 122 a sists movement of each arm 106, for example, from a. first locked position to a second locked, position. In

**[0221]**

addition, the adjusting handles 122 may provide a locking mechanism, such as a screw lock, so that the manually adjustable arms 106 are re.vers.ibly locked in a fixed position.

**[0195]**

As with the robotic arms, the manually adjustable arms 106 have multiple degrees of movement. For example, the body joint 124 attached to the device body 4 and late oint 12 attached, to the object--centacting plate 8 each have two degrees of rotation: one axis of rotation perpendicular to the object-contacting plate 8 and one rotational axis parallel to the major plane of the object-contacting plate 8. In addition, the elbow joint 128 of the manually adjustable arms 106 has a further degree of rotation.

**[0196]**

The valves 120 are manually operated between "open'<">', "closed/' and "partially open" positions to regulate the flow of gas from the gripping apertures to the vacuum source to which the gripping aperture is connected, during use.

## Classifications

- B25J15/0616
- B25J15/06

## Cited patent documents

- [DE-102011106214-A1](https://patents.google.com/patent/DE102011106214A1/en) — ISR
- [EP-0429901-A1](https://patents.google.com/patent/EP0429901A1/en) — ISR
- [ES-2354793-A1](https://patents.google.com/patent/ES2354793A1/en) — ISR
- [JP-2007331056-A](https://patents.google.com/patent/JP2007331056A/en) — ISR
- [JP-2009072850-A](https://patents.google.com/patent/JP2009072850A/en) — ISR
- [JP-H02221034-A](https://patents.google.com/patent/JPH02221034A/en) — ISR

---

Generated by IPtorch. Verify legal conclusions against the official publication.
