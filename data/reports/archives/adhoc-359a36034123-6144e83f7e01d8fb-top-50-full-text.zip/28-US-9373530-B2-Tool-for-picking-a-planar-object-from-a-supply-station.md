# 28. Tool for picking a planar object from a supply station

- **Archive rank:** 28 of 50
- **Publication:** [US-9373530-B2](https://patents.google.com/patent/US9373530B2/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/042536367/publication/US9373530B2?q=pn%3DUS9373530B2)
- **Publication date:** 2016-06-21
- **Filing date:** 2010-09-09
- **Earliest priority:** 2009-09-09
- **Family:** 42536367
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery

## Parties

- **Applicant / assignee:** KULICKE AND SOFFA DIE BONDING GMBH; SCHMIDT-LANGE MICHAEL; SCHUSTER JOHANNES; WONG KAM-SHING
- **Inventors:** SCHMIDT-LANGE MICHAEL; SCHUSTER JOHANNES; WONG KAM-SHING

## Abstract

A pick tool for picking a planar object from a supply station is presented, in particular to be used for picking a semiconductor die from a carrier tape, said pick tool comprising: a work surface, said work surface comprising at least one contact region that may be brought into contact with a first surface on a first side of the planar object; one or more vacuum outlets in the work surface that may be connected to a vacuum source to allow for temporarily fixing the planar object to the work surface; and wherein a flexible seal is provided to maintain vacuum if the planar object becomes deformed.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/b6/31/bf/692eb9f159700d/US09373530-20160621-D00000.png)

![Sketch 1 for US-9373530-B2](https://patentimages.storage.googleapis.com/b6/31/bf/692eb9f159700d/US09373530-20160621-D00000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/d0/33/6e/174a1430ccf0cc/US09373530-20160621-D00001.png)

![Sketch 2 for US-9373530-B2](https://patentimages.storage.googleapis.com/d0/33/6e/174a1430ccf0cc/US09373530-20160621-D00001.png)

[Sketch 3](https://patentimages.storage.googleapis.com/8d/d9/fa/b4dec3aa21de18/US09373530-20160621-D00002.png)

![Sketch 3 for US-9373530-B2](https://patentimages.storage.googleapis.com/8d/d9/fa/b4dec3aa21de18/US09373530-20160621-D00002.png)

[Sketch 4](https://patentimages.storage.googleapis.com/98/55/1a/6166d7f154da7a/US09373530-20160621-D00003.png)

![Sketch 4 for US-9373530-B2](https://patentimages.storage.googleapis.com/98/55/1a/6166d7f154da7a/US09373530-20160621-D00003.png)

[Sketch 5](https://patentimages.storage.googleapis.com/56/fc/cc/4d3e0f4c8f012f/US09373530-20160621-D00004.png)

![Sketch 5 for US-9373530-B2](https://patentimages.storage.googleapis.com/56/fc/cc/4d3e0f4c8f012f/US09373530-20160621-D00004.png)

[Sketch 6](https://patentimages.storage.googleapis.com/9c/5f/4b/3c85b28bfb1591/US09373530-20160621-D00005.png)

![Sketch 6 for US-9373530-B2](https://patentimages.storage.googleapis.com/9c/5f/4b/3c85b28bfb1591/US09373530-20160621-D00005.png)

[Sketch 7](https://patentimages.storage.googleapis.com/03/6a/bd/cc43a962be1e00/US09373530-20160621-D00006.png)

![Sketch 7 for US-9373530-B2](https://patentimages.storage.googleapis.com/03/6a/bd/cc43a962be1e00/US09373530-20160621-D00006.png)

[Sketch 8](https://patentimages.storage.googleapis.com/81/71/1c/dab174cd397227/US09373530-20160621-D00007.png)

![Sketch 8 for US-9373530-B2](https://patentimages.storage.googleapis.com/81/71/1c/dab174cd397227/US09373530-20160621-D00007.png)

[Sketch 9](https://patentimages.storage.googleapis.com/e7/44/62/bfe80f750f3ab7/US09373530-20160621-D00008.png)

![Sketch 9 for US-9373530-B2](https://patentimages.storage.googleapis.com/e7/44/62/bfe80f750f3ab7/US09373530-20160621-D00008.png)

[Sketch 10](https://patentimages.storage.googleapis.com/9c/9b/1c/e80f61b11c1f0f/US09373530-20160621-D00009.png)

![Sketch 10 for US-9373530-B2](https://patentimages.storage.googleapis.com/9c/9b/1c/e80f61b11c1f0f/US09373530-20160621-D00009.png)

[Sketch 11](https://patentimages.storage.googleapis.com/28/96/43/52708d9667452b/US09373530-20160621-D00010.png)

![Sketch 11 for US-9373530-B2](https://patentimages.storage.googleapis.com/28/96/43/52708d9667452b/US09373530-20160621-D00010.png)

[Sketch 12](https://patentimages.storage.googleapis.com/c9/bc/c7/9e03e70c28c268/US09373530-20160621-D00011.png)

![Sketch 12 for US-9373530-B2](https://patentimages.storage.googleapis.com/c9/bc/c7/9e03e70c28c268/US09373530-20160621-D00011.png)

## Claims

### Claim 1 (independent)

A pick tool for picking a semiconductor die from a carrier tape, said pick tool comprising: a. a work surface, said work surface being substantially formed of at least one contact region, the at least one contact region being configured to be brought into complete contact with a first surface on a first side of the semiconductor die, b. one or more vacuum outlets in the work surface to be connected to a vacuum source to allow for temporarily fixing the semiconductor die to the work surface, and c. a flexible seal provided to contact the first surface on the first side of the semiconductor die, and to maintain vacuum if the semiconductor die becomes deformed, the flexible seal surrounding the work surface.

### Claim 2

The pick tool according to claim 1 , wherein the work surface includes a plurality of planar contact regions for contacting the semiconductor die, the plurality of planar contact regions being disjointed.

### Claim 3

A pick tool according to claim 1 , wherein the flexible seal extends along an edge region of the work surface.

### Claim 4

A pick tool according to claim 1 , wherein a. the pick tool includes a tool tip on which the work surface is formed, and wherein b. at least part of the tool tip is made from an elastic material so that at least one edge region of the work surface may bend in a direction opposite to a direction of a pick movement of the tool tip to provide the flexible seal.

### Claim 5

A pick tool according to claim 1 , wherein the work surface is concave.

### Claim 6

A pick tool according to claim 1 , wherein the one or more vacuum outlets include one or more vacuum channels formed in the work surface.

### Claim 7

A pick tool according to claim 1 , wherein the work surface includes at least a first contact region and a second contact region, the first contact region and the second contact region being disjoint.

### Claim 8

A pick tool according to claim 7 , wherein the first contact region and the second contact region are separated by one or more vacuum channels.

### Claim 9

A pick tool according to claim 7 , wherein the second contact region is provided along a circumference of the work surface so that said second contact region may act as a sealing surface.

### Claim 10

A pick tool according to claim 1 , wherein the pick tool includes a tool tip on which the work surface is formed, and a flange is provided that surrounds a die contacting portion of the tool tip.

### Claim 11

A pick tool according to claim 10 , wherein the flange is made from an elastic material.

### Claim 12

A pick tool according to claim 10 , wherein a sealing ring is formed on the flange.

### Claim 13

A pick tool according to claim 12 , wherein the work surface includes at least a first contact region and a second contact region, and wherein the second contact region is formed on the sealing ring.

### Claim 14 (independent)

A chip processing apparatus, in particular a semiconductor die bonder, said chip processing apparatus comprising: a. a pick tool including (1) a work surface, said work surface being substantially formed of at least one contact region, the at least one contact region being configured to be brought into complete contact with a first surface on a first side of a chip, (2) one or more vacuum outlets in the work surface to be connected to a vacuum source to allow for temporarily fixing the chip to the work surface, and (3) a flexible seal provided to contact the first surface on the first side of the semiconductor die, and to maintain vacuum if the chip becomes deformed, the flexible seal surrounding the work surface; and b. a place tool for bonding the chip onto a substrate or another chip.

### Claim 15

The chip processing apparatus according to claim 14 , further comprising at least one transfer tool for handing the chip from the pick tool to the place tool.

## Full description

### Cross Reference To Related Application

**[p0001]**

This application claims the benefit of International Application No. PCT/EP2010/063267 filed Sep. 9, 2010, which claims the benefit of European Patent Application No. 10165160.2 filed Jun. 7, 2010 and U.S. Provisional Patent Application No. 61/240,858, filed Sep. 9, 2009, the content of all of which are incorporated herein by reference.

### Field Of The Invention

**[p0002]**

The present invention pertains to the field of automation technology. It relates to a device for picking chips from a supply station, in particular semiconductor dies from a carrier tape, in accordance with the preamble of the independent patent claims.

### Background Of The Invention

**[p0003]**

One of the biggest challenges in semiconductor packaging is picking, handling and processing of very thin semiconductor chips. The semiconductor chips are generally provided on a carrier tape, which generally contains a whole semiconductor wafer that has been cut into small chips, a process frequently referred to as dicing. The semiconductor chips are thus commonly referred to as dies. The carrier tape is often the same tape that supported the wafer during dicing, often referred to as dicing tape. Die thicknesses of down to 25 μm are common today, and there is an ongoing trend to decrease thicknesses even further. Consequently, features on a structured side of such thin dies usually have maximum heights of only a few micrometers. Die bonders pick a single die from the carrier tape and place and subsequently attach the picked die onto a substrate or onto another die. In most situations, the die is attached permanently, but configurations where dies are only attached temporarily also exist. Often, a temporary attachment is subsequently turned into a permanent one by an additional heating and/or pressing process. Often, thin dies come with a wafer backside lamination (WBL) or film or flow over wire (FOW) lamination, i.e. an adhesive film which is applied to an unstructured side of the wafer or die. A process of thinning wafers, applying an adhesive film to the wafers, mounting the wafers to a carrier tape and frame, and dicing them into individual chips is usually referred to as wafer preparation. The lamination, which allows for the dies to be attached due to its adhesive pro

**[p0003]**

perties, may be provided either between the carrier tape and the wafer, or on a surface of the wafer facing away from the carrier tape.

**[p0004]**

Picking and placing may be carried out by a single die handling unit in the die bonder as illustrated in FIG. 1 . In modern die bonders, e.g. as shown in FIG. 2 , a plurality of die handling units can be present: In general, picking takes place from a so called wafer table, and is assisted by a first die handling unit, also referred to as die ejector 5 . The die ejector 5 facilitates the removal of the die 30 from the carrier tape 4 , e.g. by pushing the die 30 against a second die handling unit called pick unit 92 —from underneath the carrier tape 4 . The pick unit 92 subsequently picks the die 30 from the carrier tape 4 in a pick process and hands it over to a third die handling unit, also referred to as place unit 94 . The place unit 94 places the die 30 onto a target position, where it is attached. In some cases, at least one fourth die handling unit—a so called transfer unit 93 —is provided to hand the die 30 from the pick unit 92 to the place unit 94 . An example is given in WO 07118511 A1 which is hereby incorporated by reference in its entirety. In this manner, a die 30 may be attached to a substrate 6 , e.g. a leadframe, printed circuit board, multilayer board etc., or to another die, which itself may be have been attached in the same way. A plurality of cameras 40 , 41 , 42 , 44 is normally present for monitoring and/or measuring purposes.

**[p0005]**

The fabrication of very thin wafers and the corresponding dies is very expensive as compared to standard thickness wafers without lamination. Sawing, picking as well as handling of very thin dies have significant yield losses. Most of the yield is lost during wafer preparation, die picking, or subsequent handling, resulting in damaged dies due to typical defects as e.g. broken dies, cracked dies, chipped dies, etc. Both place and attachment processes, in comparison, are more reliable, giving rise to only negligible loss. During picking, damage frequently results from bending a die beyond an elastic range. This occurs when the die 30 , while still being attached to the carrier tape 4 is grabbed by a pick tool 1 and subsequently detached from the carrier tape 4 as shown in FIG. 3 . This is usually done by bringing a work surface of the pick tool into contact with a first surface of the die 30 which faces away from the carrier tape 4 , fixing the die 30 to the work surface by means of a vacuum, and moving the pick tool 1 away from the carrier tape 4 which is thus peeled off of the die 30 . During peeling, regions of the carrier tape 4 underneath positions of neighboring dies 31 , 32 are generally held in place on a support surface of a die ejector 5 by vacuum. As a consequence, the carrier tape 4 exerts a reactionary force onto the die 30 away from the work surface. As air can easily enter between the die 30 and the work surface at an edge of the die 30 , vacuum often breaks down in an area near the edge so that the die 30 looses contact to the work surface in said area. The a

**[p0005]**

rea near the edge of the die 30 is then bent down. This may lead to breaking, cracking or chipping of the die 30 if a bending radius becomes too small. It may also result in the die 30 becoming completely detached from the pick tool 1 . In this case, picking has to be repeated, resulting in reduced performance of the die bonder.

### Summary Of The Invention

**[p0006]**

It is thus an object of the invention to provide a pick tool that overcomes the disadvantages described above. In particular, the pick tool shall allow for a vacuum to be maintained while a planar object is picked from a supply station, even if the planar object becomes deformed. The above objects are achieved by a pick tool according to the independent claims. In an exemplary embodiment of the present invention, a pick tool for picking a planar object from a supply station, in particular for picking a semiconductor die from a carrier tape, comprises a work surface, said work surface comprising at least one contact region that may be brought into contact with a first surface on a first side of the planar object; one or more vacuum outlets in the work surface that may be connected to a vacuum source to allow for temporarily fixing the planar object to the work surface. A flexible seal is provided to maintain vacuum if the planar object becomes deformed. The aforementioned and further objectives, advantages and features of the invention will be detailed in the description of preferred embodiments below in combination with the drawings.

### Brief Description Of The Drawings

**[p0007]**

The invention is best understood from the following detailed description when read in connection with the accompanying drawing. It is emphasized that, according to common practice, the various features of the drawing are not to scale. On the contrary, the dimensions of the various features are arbitrarily expanded or reduced for clarity. Included in the drawing are the following figures: FIGS. 1 and 2 show schematic representations of prior art die bonders. FIG. 3 shows a detail of a pick process carried out by means of a prior art pick tool. FIG. 4 shows a perspective view of a pick tool in accordance with an exemplary embodiment of the present invention. FIG. 5 shows another perspective view of a pick tool 1 in accordance with an exemplary embodiment of the present invention. FIGS. 6, 7 and 8 show cross sections of the pick tool shown in FIGS. 4 and 5 . FIG. 9 shows a detail of a pick process carried out with a pick tool in accordance with an exemplary embodiment of the present invention.

**[p0008]**

FIG. 10 shows a cross section of the pick tool from FIG. 8 along a line A-A′. FIG. 11 shows various steps of a pick process.

### Detailed Description Of The Invention

**[p0009]**

FIG. 4 shows a perspective view of a pick tool 1 in accordance with an exemplary embodiment of the present invention. The pick tool 1 comprises a tip holder 11 made of metal and an essentially box-shaped, replaceable tool tip 12 made of an elastomeric material, in particular rubber, preferably silicone rubber. Preferably, the elastomeric material has a Shore A hardness of between 30 and 75, preferably between 40 and 60; and ideally around 50. A rectangular work surface 2 formed on a lower side of the tool tip 12 comprises twenty rectangular contact regions 120 , which are separated from one another by first vacuum channels 122 . The work surface 2 further comprises an additional contact region 121 that is formed on a sealing ring 125 which in turn is formed on a flange 123 provided along a circumference of a lower part of the tool tip 12 , thus forming a flexible lip seal with the additional contact region 121 acting as a sealing surface. First vacuum ducts 124 open into first vacuum channels 122 . Flange 123 , sealing ring 125 , work surface 2 and first vacuum channels 122 form a die contacting portion 129 of the tool tip 12 , with the flange 123 and the sealing ring 125 surrounding said die contacting portion 129 ; i.e. flange 123 and sealing ring 125 are provided on an edge region of the die contacting portion 129 so that the additional contact region 121 surrounds the rectangular contact regions 120 . The tool tip 12 further comprises a body portion 128 in which an indentation is formed for mounting the tool tip 12 onto the tip holder 11 , and which has a smaller cross

**[p0009]**

section than the die contacting portion 129 in a plane parallel to the work surface, i.e. perpendicular to the z-direction. Thus, a first cross section area of the die contacting portion 129 is larger than a second cross section area of the body portion 128 of the tool tip 12 . First vacuum ducts 124 provided in the body portion 128 of the tool tip 12 open into the first vacuum channels 122 .

**[p0010]**

As illustrated in FIG. 5 , the tool tip 12 may be mounted onto a protruding section 111 which acts as an interface portion of the tip holder 11 . Second vacuum channels 112 are formed in a lower surface of the protruding section 111 , and connect to the first vacuum ducts 124 provided in the tool tip 12 . The tip holder 11 may be attached to a pick unit 92 of a die bonder by means of a shaft 110 . One or more second vacuum ducts 113 , which are connected to the second vacuum channels 112 , are provided in the tip holder 11 , comprising the shaft 110 . FIGS. 6, 7 and 8 show cross sections of the pick tool 1 shown in FIGS. 4 and 5 . To pick a die 30 from a carrier tape 4 , the pick tool 1 is lowered by the pick unit 92 until the work surface 2 comes into contact with a surface of a die 30 . A vacuum is then applied to the first vacuum channels 122 through first vacuum ducts 124 , and through the second vacuum ducts 113 and channels 112 provided in the tip holder 11 . Once the vacuum has been applied, the die 30 is pressed against the work surface 2 by an atmospheric pressure of an air surrounding the die bonder. As a consequence, the die 30 is temporarily fixed to the work surface 2 . When the pick tool 1 is lifted again in a pick movement in a +z-direction to detach the die 30 from the carrier tape 4 , the carrier tape 4 is being bent downwards, i.e. in −z-direction, in an area underneath the edges of the die 30 due to the fact that a surrounding region of the carrier tape 4 underneath neighbouring dies 31 and 32 is fixed to a support surface of a die ejector 5 , e.g. by mea

**[p0010]**

ns of vacuum. As a consequence, the edges of the die 30 are also being bent downwards, i.e. in −z-direction, relative to a central region of the die 30 , so that the die 30 becomes deformed.

**[p0011]**

Since the flange 123 is relatively thin, it may easily bend downwards, i.e. in −z-direction, due to a compliance of the elastomeric material the tool tip 12 is made of. As a consequence, the additional contact region 121 which acts as sealing surface may advance in −z-direction at the beginning of a pick process. Thus, the flange 123 may provide compliance in a vertical direction between the body portion 128 of the tool tip 12 and the sealing surface. As the pick process continues, the edge region of the tool tip 12 , which comprises the flange 123 and the sealing ring 125 , may thus bend downwards so that the work surface 2 may become concave and the sealing surface can continue to be in contact with the die 30 —and thus maintain a seal—even if the die 30 is deformed substantially due to bending that may occur in particular in the final stages of the pick process, as illustrated in FIG. 9 . As a consequence, the vacuum in the first vacuum channels 122 remains intact and the die 30 is held securely by the tool tip 12 .

**[p0012]**

A major benefit of the invention is that a magnitude of die deformation that can be matched without breakdown of the vacuum is much larger than with a conventional tool tip, even if the conventional tool tip is fabricated with a very compliant material. Also, if vacuum breakdown can be prevented, a likelihood of failed pick attempts due to a loss of vacuum suction between the pick tool 1 and the die 30 can be greatly reduced. In addition, the die 30 will be subjected to less stress during the pick process. Due to an elastic restoring force of the silicone rubber, the flange 123 exerts a restoration force onto the die 30 via the sealing ring 125 and the sealing surface that reduces bending, thus reducing a risk of chipping, breaking, splitting etc. of the die 30 . As can clearly be seen from FIGS. 4 through 8 , all contact regions 120 as well as the additional contact region 121 preferably have planar surfaces; and are preferably all situated at the same z-location. As a consequence, all contact surfaces of the contact regions 120 and the sealing surface of the additional contact region 121 lie in one and the same plane when no die is being held by the pick tool 1 . Thus a planar work surface 2 is formed, so that the pick tool 1 is capable of holding a planar thin die without exerting any bending force onto the die that might damage it.

**[p0013]**

Alternatively, the additional contact region 121 may protrude slightly with respect to the contact regions 120 , i.e. be located at a z-location z 121 somewhat smaller than a z-location z 120 of the contact regions 120 . Preferably, the additional contact region 121 is essentially parallel to the contact regions 120 in this case when no die is being held by the pick tool 1 . This way, it can be ensured that the sealing surface provided by the additional contact region 121 may be brought in tight contact with a die to be picked and thus may efficiently seal the vacuum required for securely fixing the die to the pick tool 1 during the pick process. However, if the additional contact region 121 protrudes too far in −z-direction, the working surface 2 becomes essentially non-flat, and the die will thus be substantially bent under the influence of the vacuum, which may lead to damage. Thus, the additional contact region 121 should not protrude more than a few ten micrometers, i.e. preferably z 120 -z 121 &lt;50 μm, preferably z 120 -z 121 &lt;10 μm should hold. Alternatively, the protrusion of the additional contact region may also be designed in such a manner that when the pick tool 1 is pressed against a planar reference surface with a typical pick force of the process for which it is to be used, e.g. a force between 0.5 and 2N, preferably between 0.8 and 1.25 N, all the contact regions 120 as well as the additional contact region 121 come into tight contact with the planar reference surface.

**[p0014]**

FIG. 10 shows a cross section of the pick tool from FIG. 8 along a line A-A′. The contact regions have lengths l 1 and l 2 in x- and y-directions, respectively. The vacuum channels 122 have widths w 1 and w 2 . Preferably, w 1 and w 2 are significantly smaller than l 1 and l 2 , i.e. w n &lt;&lt;l m for n,mε{1,2}. Optimum results are achieved if 5w n &lt;l m , preferably 10w n &lt;l m . This provides optimum support for a thin die to be picked by the pick tool 11 , and thus avoids that the die will be forced locally to comply to large curvatures when being pressed against the work surface 2 as a consequence of the vacuum present in the vacuum channels 122 . While a pick tool 1 in accordance with the present invention may be used in a die bonder that comprises only a single die handling unit for picking and placing, it is particularly well suited for use in a die bonder that comprises multiple die handling tools, or at least a separate pick unit 92 and place unit 94 . In such a configuration, geometry and material parameters of the tool tip 12 may be optimized for maximum pick performance without negative effect on a place process.

**[p0015]**

Although the invention is illustrated and described herein with reference to specific embodiments, the invention is not intended to be limited to the details shown. Rather, various modifications may be made in the details within the scope and range of equivalents of the claims and without departing from the invention. In particular, rather than providing the sealing surface of the additional contact region 121 in combination with a flange 123 and a sealing ring 125 as described above, the sealing surface may also be provided by an additional contact region that is formed on a peripheral area of a tool tip 12 and supported by a region of relatively soft elastomeric material, and encloses contact regions 120 located in a central area of the tool tip 12 . In addition, the following are preferred embodiments of the invention as described above: A pick tool for picking a planar object from a supply station, in particular for picking a semiconductor die from a carrier tape, said pick tool comprising: a work surface, said work surface comprising at least one contact region that may be brought into contact with a first surface on a first side of the planar object; one or more vacuum outlets in the work surface that may be connected to a vacuum source to allow for temporarily fixing the planar object to the work surface; a tool tip; said tool tip comprising a die contacting portion on which the work surface is formed, wherein at least part of the die contacting portion is made from compliant, in particular elastic, material; and a die contacting portion has a bigger cross section th

**[p0015]**

an a body portion of the tool tip.

**[p0016]**

A pick tool for picking a planar object from a supply station, in particular for picking a semiconductor die from a carrier tape, said pick tool comprising: a tool tip; a work surface formed on said tool tip, said work surface comprising at least one contact region that may be brought into contact with a first surface on a first side of the planar object; vacuum outlets in the work surface that may be connected to a vacuum source to allow for temporarily fixing the planar object to the work surface; wherein at least part of the tool tip is made from compliant material, in particular elastic material, so that at least one edge region of the work surface may bend in a direction opposite to a direction of a pick movement of the tool tip. A pick tool as described in paragraph [0027] or [0028], wherein the work surface may be deformed to become concave. A pick tool as described in paragraphs [0027] through [0029], wherein the one or more vacuum outlets comprise one or more vacuum channels formed in the work surface. A pick tool as described in paragraphs [0027] through [0030], wherein the work surface comprises at least a first and a second contact region, the two contact regions being disjoint.

**[p0017]**

A pick tool as described in paragraphs [0030] and [0031], wherein the contact regions are separated by one or more vacuum channels. A pick tool as described in paragraphs [0031] or [0032], wherein the second contact region is provided along a circumference of the work surface so that said second contact region may act as a sealing surface. A pick tool as described in paragraphs [0027] through [0033], wherein a flange is provided that surrounds a die contacting portion of the tool tip. A pick tool as described in paragraphs [0034], wherein the flange is made from compliant, in particular elastic material. A pick tool as described in paragraphs [0034] or [0035], wherein a sealing ring is formed on the flange. A pick tool as described in paragraph [0036], wherein the second contact region is formed on the sealing ring. A pick tool as described above may preferably be obtained by one of the methods as described below: A method for obtaining a pick tool capable of picking a planar object from a supply station while carrying out a pick movement, in particular for picking a semiconductor die from a carrier tape, the method comprising the steps of

**[p0018]**

a) forming a tool tip on said pick tool so that at least a part of said tool tip consists of compliant, in particular elastic material; b) forming a work surface on said tool tip, c) forming at least one contact region on said work surface so that said contact region may be brought into contact with a first surface on a first side of the planar object, d) forming vacuum outlets in the work surface that may be connected to a vacuum source to allow for temporarily fixing the planar object to the work surface, wherein e) in step b), the work surface is formed in a vicinity of the compliant material so that at least an edge region of the work surface is capable of bending in a direction opposite to a direction of the pick movement. A method for producing a tool tip for a pick tool capable of picking a planar object from a supply station, in particular for picking a semiconductor die from a carrier tape, the method comprising the steps of a) providing a die contacting portion adjacent to a body portion of said tool tip b) forming a work surface on said die contacting portion, c) forming at least one contact region on the work surface that may be brought into contact with a first surface on a first side of the planar object, d) forming one or more vacuum outlets in the work surface that may be connected to a vacuum source to allow for temporarily fixing the planar object to the work surface, wherein e) in step a), at least part of the die contacting portion is made from compliant, in particular elastic, material, f) in step b), the die contacting portion is formed to have a first

**[p0018]**

cross section area which is larger than a second cross section area of the body portion of the tool tip.

## Figure captions

- **Figure 1:** FIGS. 1 and 2 show schematic representations of prior art die bonders.
- **Figure 3:** FIG. 3 shows a detail of a pick process carried out by means of a prior art pick tool.
- **Figure 4:** FIG. 4 shows a perspective view of a pick tool in accordance with an exemplary embodiment of the present invention.
- **Figure 5:** FIG. 5 shows another perspective view of a pick tool 1 in accordance with an exemplary embodiment of the present invention.
- **Figure 6:** FIGS. 6, 7 and 8 show cross sections of the pick tool shown in FIGS. 4 and 5 .
- **Figure 9:** FIG. 9 shows a detail of a pick process carried out with a pick tool in accordance with an exemplary embodiment of the present invention.
- **Figure 10:** FIG. 10 shows a cross section of the pick tool from FIG. 8 along a line A-A′.
- **Figure 11:** FIG. 11 shows various steps of a pick process.
- **Figure 6:** FIGS. 6, 7 and 8 show cross sections of the pick tool 1 shown in FIGS. 4 and 5 .

## Classifications

- H01L21/67144
- H10P72/0446
- H10P72/0446
- H10P95/00
- B32B37/10
- B32B37/10
- B32B37/1018
- B32B37/26
- B65G47/91
- B65G47/91
- B65G47/91
- B65G47/91
- B65H37/04
- H01L21/00
- H01L21/00
- H01L21/67
- H01L21/68
- H01L21/68
- H01L21/683
- H01L21/6838
- H01L21/687
- H10P72/00
- H10P72/50
- H10P72/50
- H10P72/70
- H10P72/78
- H10P72/78
- H10P95/00
- H10P95/00
- Y10T156/17
- Y10T156/17
- Y10T156/17

## Cited patent documents

- [EP-0235781-A2](https://patents.google.com/patent/EP0235781A2/en) — APP
- [EP-0312924-A2](https://patents.google.com/patent/EP0312924A2/en) — SEA
- [EP-1209724-A2](https://patents.google.com/patent/EP1209724A2/en) — APP
- [JP-2000195877-A](https://patents.google.com/patent/JP2000195877A/en) — APP
- [US-2002024883-A1](https://patents.google.com/patent/US20020024883A1/en) — SEA
- [US-2002069952-A1](https://patents.google.com/patent/US20020069952A1/en) — APP
- [US-2003034120-A1](https://patents.google.com/patent/US20030034120A1/en) — SEA
- [US-2003115747-A1](https://patents.google.com/patent/US20030115747A1/en) — SEA
- [US-2009269178-A1](https://patents.google.com/patent/US20090269178A1/en) — APP
- [US-2014060751-A1](https://patents.google.com/patent/US20140060751A1/en) — SEA
- [US-3774834-A](https://patents.google.com/patent/US3774834A/en) — SEA
- [US-4052241-A](https://patents.google.com/patent/US4052241A/en) — SEA
- [US-4850780-A](https://patents.google.com/patent/US4850780A/en) — SEA
- [US-5803797-A](https://patents.google.com/patent/US5803797A/en) — SEA
- [US-6279976-B1](https://patents.google.com/patent/US6279976B1/en) — SEA
- [US-8037918-B2](https://patents.google.com/patent/US8037918B2/en) — SEA
- [US-8132608-B2](https://patents.google.com/patent/US8132608B2/en) — SEA
- [WO-2007118511-A1](https://patents.google.com/patent/WO2007118511A1/en) — APP
- [WO-2008130173-A1](https://patents.google.com/patent/WO2008130173A1/en) — APP

---

Generated by IPtorch. Verify legal conclusions against the official publication.
