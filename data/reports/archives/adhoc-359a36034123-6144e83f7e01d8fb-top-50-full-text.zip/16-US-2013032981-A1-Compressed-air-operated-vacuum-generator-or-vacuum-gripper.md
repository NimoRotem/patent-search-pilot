# 16. Compressed-air-operated vacuum generator or vacuum gripper

- **Archive rank:** 16 of 50
- **Publication:** [US-2013032981-A1](https://patents.google.com/patent/US20130032981A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/043607990/publication/US20130032981A1?q=pn%3DUS20130032981A1)
- **Publication date:** 2013-02-07
- **Filing date:** 2010-11-18
- **Earliest priority:** 2009-11-24
- **Family:** 43607990
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus

## Parties

- **Applicant / assignee:** SCHAAF WALTER; SCHMALZ J GMBH
- **Inventors:** SCHAAF WALTER

## Abstract

The invention relates to a compressed-air-operated vacuum generator or vacuum gripper having at least two vacuum units, wherein each vacuum unit has a suction chamber, an intake opening which opens into the suction chamber, an outflow opening which opens out of the suction chamber, and at least one drive air opening which opens into the outflow opening between the intake opening and the outflow opening, and wherein the vacuum units operate on the basis of at least two different principles (Venturi, Bernoulli, Coanda, vortex, etc.) for generating a negative pressure.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/8d/c6/ef/8f78a2dfa05aee/US20130032981A1-20130207-D00000.png)

![Sketch 1 for US-2013032981-A1](https://patentimages.storage.googleapis.com/8d/c6/ef/8f78a2dfa05aee/US20130032981A1-20130207-D00000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/06/3a/1e/5695d805eee6e5/US20130032981A1-20130207-D00001.png)

![Sketch 2 for US-2013032981-A1](https://patentimages.storage.googleapis.com/06/3a/1e/5695d805eee6e5/US20130032981A1-20130207-D00001.png)

[Sketch 3](https://patentimages.storage.googleapis.com/03/8f/16/0ccfe4d96f8b30/US20130032981A1-20130207-D00002.png)

![Sketch 3 for US-2013032981-A1](https://patentimages.storage.googleapis.com/03/8f/16/0ccfe4d96f8b30/US20130032981A1-20130207-D00002.png)

[Sketch 4](https://patentimages.storage.googleapis.com/a0/f6/2f/1d93572270bf78/US20130032981A1-20130207-D00003.png)

![Sketch 4 for US-2013032981-A1](https://patentimages.storage.googleapis.com/a0/f6/2f/1d93572270bf78/US20130032981A1-20130207-D00003.png)

[Sketch 5](https://patentimages.storage.googleapis.com/fc/e5/eb/4fd798b41a6ce1/US20130032981A1-20130207-D00004.png)

![Sketch 5 for US-2013032981-A1](https://patentimages.storage.googleapis.com/fc/e5/eb/4fd798b41a6ce1/US20130032981A1-20130207-D00004.png)

[Sketch 6](https://patentimages.storage.googleapis.com/eb/c5/78/9fbc13b53d2f0e/US20130032981A1-20130207-D00005.png)

![Sketch 6 for US-2013032981-A1](https://patentimages.storage.googleapis.com/eb/c5/78/9fbc13b53d2f0e/US20130032981A1-20130207-D00005.png)

[Sketch 7](https://patentimages.storage.googleapis.com/ee/fd/9b/e6856aedb4a8c6/US20130032981A1-20130207-D00006.png)

![Sketch 7 for US-2013032981-A1](https://patentimages.storage.googleapis.com/ee/fd/9b/e6856aedb4a8c6/US20130032981A1-20130207-D00006.png)

[Sketch 8](https://patentimages.storage.googleapis.com/72/d6/3f/b50faf559aa193/US20130032981A1-20130207-D00007.png)

![Sketch 8 for US-2013032981-A1](https://patentimages.storage.googleapis.com/72/d6/3f/b50faf559aa193/US20130032981A1-20130207-D00007.png)

[Sketch 9](https://patentimages.storage.googleapis.com/31/8a/5b/83255d92e604dc/US20130032981A1-20130207-D00008.png)

![Sketch 9 for US-2013032981-A1](https://patentimages.storage.googleapis.com/31/8a/5b/83255d92e604dc/US20130032981A1-20130207-D00008.png)

## Claims

### Claim 12 (independent)

A compressed-air-operated vacuum generator or vacuum gripper with at least two vacuum units, each vacuum unit comprising: a suction chamber, an intake opening which opens into the suction chamber, at least one outlet opening which exits from the suction chamber, and at least one compressed air or drive air opening which opens into the outlet opening, wherein the at least two vacuum units operate according to at least two different principles for generating a negative pressure.

### Claim 13

The vacuum generator or vacuum gripper of claim 12, wherein the at least two vacuum units comprise at least one unit selected from a vacuum nozzle, an ejector and a vacuum-generating stage.

### Claim 14

The vacuum generator or vacuum gripper of claim 12, wherein the at least one outlet opening of one of the at least two vacuum units opens into the at least one compressed air or drive air opening of another of the at least two vacuum units.

### Claim 15

The vacuum generator or vacuum gripper of claim 12, wherein the at least two vacuum units are connected in a parallel.

### Claim 16

The vacuum generator or vacuum gripper of claim 12, wherein the at least two vacuum units are connected in series.

### Claim 17

The vacuum generator or vacuum gripper of claim 12, wherein the at least two vacuum units are arranged in a common housing.

### Claim 18

The vacuum generator or vacuum gripper of claim 12, wherein the suction chambers of the at least two different vacuum units are separated from each other.

### Claim 19

The vacuum generator or vacuum gripper of claim 12, wherein the suction chambers of the at least two different vacuum units are connected to one another by at least one movable flap.

### Claim 20

The vacuum generator or vacuum gripper of claim 19, wherein the at least one movable flap is controllably closed or opened depending on vacuum pressure or volume flow rate, or both.

### Claim 21

The vacuum generator or vacuum gripper of claim 12, wherein the at least two different principles are selected from the group consisting of Venturi principle, Bernoulli principle, Coanda principle and vortex principle.

### Claim 22

The vacuum generator or vacuum gripper of claim 12, further comprising a blower system.

### Claim 23

The vacuum generator or vacuum gripper of claim 12, further comprising a sensor detecting at least one of flow conditions and pressure conditions.

### Claim 24

The vacuum generator or vacuum gripper of claim 23, wherein the sensor is constructed to detect the at least one of flow conditions and pressure conditions in the suction chamber.

### Claim 25

The vacuum generator or vacuum gripper of claim 12, wherein the at least two vacuum units vacuum units operate simultaneously.

### Claim 26

The vacuum generator or vacuum gripper of claim 12, wherein the at least two vacuum units vacuum units operate sequentially.

## Full description

**[p0001]**

The invention relates to a compressed-air-operated vacuum generator or vacuum gripper with the features of the preamble of Claim 1 . Multi-stage ejectors with cascaded Venturi nozzles are known, for example, from WO 99/49216 and from the companies Piab, SMC and Vtec. A feature of the multi-stage principle is that the exhaust jet of an upstream stage is the drive air jet of the downstream stage. For example, a combination of the Coanda principle with the Venturi principle may be useful for increasing the suction volume flow. General vacuum generating principles are the Venturi principle with a jet nozzle and a receiver nozzle, the Bernoulli principle, wherein “fast” air with high dynamic pressure produces of a static negative pressure, and the Coanda principle, wherein the air follows a curved surface. It is an object of the invention to provide a vacuum generator or vacuum gripper capable of efficiently generating a negative pressure. This object is attained with a vacuum generator or vacuum gripper having the features of claim 1 .

**[p0002]**

The multi-stage ejector according to present invention includes at least two vacuum generation stages. The exhaust jet of an upstream vacuum generating step hereby forms the drive air jet of a downstream vacuum generation stage, whereby at least two different vacuum generation principles are employed. The following advantages are hereby attained. By combining a principle for high volume flow with a principle for high vacuum, the object to be sucked quickly moves against the intake device due to the high volume flow and is strongly retained due to the high negative pressure. According to the invention, the vacuum unit may here be a vacuum nozzle, an ejector and/or a vacuum generating stage and may, for example, operate according to the Venturi principle, the Bernoulli principle, the Coanda principle or the vortex principle. According to a further embodiment of the invention, at least one exhaust port of a vacuum unit opens into the drive air port of the other vacuum unit. The two vacuum units are connected in series.

**[p0003]**

Advantageously, the vacuum units are combined in parallel and/or in series. One or more vacuum units connected in parallel may here be arranged downstream of the one vacuum unit. Advantageously, the vacuum units may be housed in a common housing to reduce the construction volume. According to a further embodiment of the invention, at least two different suction chambers may be separated from each other or connected to one another by one or more movable flaps. With these flaps, which are preferably designed as a non-return swing valves, the volume flows and the resulting negative pressures can be specifically controlled. The closing or opening of the flaps may be controllable, in particular automatically, depending on the vacuum pressure and/or the volume flow. Advantageously, a blower system opening into the suction chamber may be provided so that the negative pressure can be rapidly relieved and the sucked-in workpiece can be quickly ejected. Preferably, one or more sensors are provided for detecting the flow and/or pressure conditions, in particular in the suction chamber.

**[p0004]**

According to a further embodiment of the invention, the vacuum units operating according to at least two different principles for generating negative pressure operate simultaneously or sequentially. One vacuum unit may hereby be used for generating a high volume flow and the other vacuum unit for generating a high negative pressure. Further advantages, features and details of the invention will become apparent from the dependent claims and the accompanying drawings. The features shown in the drawing and described in the description and the claims may be important for the invention individually and in any combination. The drawings show in: FIG. 1 a combination of the Venturi and the Coanda principle with separate vacuum chambers (Venturi nozzle circumferential or several individual nozzles); FIG. 2 a combination of the Venturi and the Coanda principle with a single vacuum chamber, wherein the exhaust air flow of the Venturi nozzles represents the drive air flow of the Coanda nozzle (Venturi nozzle circumferential or several individual nozzles);

**[p0005]**

FIG. 3 a combination of the Venturi and the Bernoulli principle with separate vacuum chambers (Venturi nozzle circumferential or several individual nozzles); FIG. 4 a multi-stage ejector with a combination of a Venturi nozzle with a vortex nozzle in different views. The Venturi nozzles may here also be formed as a Coanda nozzles; FIG. 5 a multi-stage ejector with a combination of a Coanda nozzle with a Venturi nozzle; FIG. 6 a combination of the Coanda and the Bernoulli principle with outwardly guided exhaust air flow; FIG. 7 a combination of the Coanda and the Bernoulli principle with inwardly guided exhaust air flow for sucking in air and for generating a suction force, and FIG. 8 a combination of the vortex and the Coanda principle. FIG. 1 shows a combination of two vacuum units 8 , namely a Venturi nozzle 10 and a Coanda nozzle 12 with separate vacuum chambers 14 and 16 , wherein the Venturi nozzle 10 may be formed circumferentially or as several individual nozzles. The reference numeral 18 denotes the compressed air port of the Venturi nozzle 10 and the reference numeral 20 denotes the compressed air supply of the Coanda nozzle 12 . The exhaust air port 22 of the Venturi nozzle 10 opens into the compressed air port 20 of the Coanda nozzle 12 . The reference numeral 24 denotes the compressed air and the reference numeral 26 the suction air.

**[p0006]**

FIG. 2 shows a vacuum gripper 6 with the combination of the Venturi nozzle 10 with the Coanda nozzle 12 according to FIG. 1 with a single, common vacuum chamber 28 . The compressed air port 18 is here integrated in a housing 30 which also encompasses the suction chamber 28 . FIG. 2 a ) shows the beginning of the intake process, in which a high volume flow is generated. A flap 34 , in particular a swing check valve 36 , which is moved by the suction flow 26 into the open position, is attached downstream of the intake opening 32 of the Coanda nozzle 12 . When a workpiece 38 is sucked in, the volume flow gradually decreases, closing the flap 34 , as illustrated in FIG. 2 b ). The Coanda nozzle 12 is now switched off, so that only the Venturi nozzle 10 is operated. The volume flow decreases again as a result, thereby increasing the negative pressure in the vacuum chamber 28 . According to the invention, one vacuum unit 8 is primarily used for generating a high volume flow, while the other one vacuum unit 8 is used for generating a high negative pressure.

**[p0007]**

FIG. 3 shows a combination of other vacuum units 8 , namely, a Venturi nozzle 10 and a Bernoulli nozzle 40 with separate vacuum chambers 14 and 42 , wherein the Venturi nozzle 10 may be formed circumferentially or from several individual nozzles. The exhaust port 22 of the Venturi nozzle 10 opens here also into the compressed air port 20 of the Bernoulli nozzle 40 . FIG. 4 shows a multi-stage ejector 46 with a combination of a Venturi nozzle 10 with a vortex nozzle 48 in various views. The Venturi nozzles 10 may here also be formed as Coanda nozzles 12 . The Venturi nozzle 10 opens into a central main flow channel 50 such that the exhaust air flow 52 is inclined towards the outlet opening 54 ( FIGS. 4 c ) and 4 d )). In addition, the exhaust air flow 52 flows into the central main flow channel 50 at an angle, which lies between the radial direction and the tangential direction ( FIGS. 4 a ) and 4 b )). This produces in the central main flow channel 50 a vortex which is directed towards the outlet opening 54 causing suction air 26 to be sucked in through the lower opening of the central main flow channel 50 . The swing check valve 36 then opens at the beginning of the intake process due to a high volume flow. However, the produced negative pressure, is still low ( FIG. 4 d )). As soon as the flow rate decreases, as illustrated in FIG. 4 e ), the swing check valve 36 closes and only suction air 26 is sucked in through the Venturi nozzles 10 . This causes an increase of the negative pressure in the vacuum chamber 28 . The reference numeral 60 denotes a sensor, in particular a

**[p0007]**

vacuum sensor. The reference numeral 62 denotes a separately controllable blower system, with which the negative pressure in the vacuum chamber 28 can be rapidly relieved following the suction process.

**[p0008]**

FIG. 5 shows a multi-stage ejector 46 with a combination of a Coanda nozzle 12 and a Venturi nozzle 10 for operating the vacuum gripper 6 , e.g. an area suction gripper. The compressed air 24 flows radially into the Coanda nozzle 12 , and suction air 26 is sucked centrally into the housing 30 . The exhaust port 56 of the Coanda nozzle 12 serves as a compressed air port 18 for the Venturi nozzle 10 . The swing check valve 36 opens at the beginning of the intake process due to a high volume flow. The generated negative pressure is still low ( FIG. 5 a )). As soon as the volume flow decreases, as shown in FIG. 5 b ), the swing check valve 38 closes and only suction air 26 is sucked in via the Coanda nozzle 12 . The negative pressure in the vacuum chamber 28 is thereby increased. FIG. 6 shows a combination of a Coanda nozzle 12 and a Bernoulli nozzle 40 , similar to FIG. 3 with separate vacuum chambers 16 and 42 . The exhaust port 56 of the Coanda nozzle 12 serves as a compressed air port 20 for the Bernoulli nozzle 40 .

**[p0009]**

FIG. 7 shows a vacuum gripper 6 with a combination of a Coanda nozzle 12 and a Bernoulli nozzle 40 with an inwardly guided air stream for drawing in suction air 26 and for generating a suction force for the workpiece 38 . Spacers 58 may be provided on the underside of the vacuum gripper 6 for maintaining a permanent flow of suction air 26 even when the workpiece 38 is drawn in. FIG. 8 shows a combination of a Vortex nozzle 48 and a Coanda nozzle 12 . The inflow direction of the compressed air 24 into the Vortex nozzle 48 corresponds to the embodiment of FIG. 4 , so that a twist which sucks in the suction air 26 is produced in the Vortex nozzle 48 . This twisting exhaust air flow flows substantially radially into the Coanda nozzle 12 and generates a central suction air flow.

## Figure captions

- **Figure 1:** FIG. 1 a combination of the Venturi and the Coanda principle with separate vacuum chambers (Venturi nozzle circumferential or several individual nozzles);
- **Figure 2:** FIG. 2 a combination of the Venturi and the Coanda principle with a single vacuum chamber, wherein the exhaust air flow of the Venturi nozzles represents the drive air flow of the Coanda nozzle (Venturi nozzle circumferential or several individual nozzles);
- **Figure 3:** FIG. 3 a combination of the Venturi and the Bernoulli principle with separate vacuum chambers (Venturi nozzle circumferential or several individual nozzles);
- **Figure 4:** FIG. 4 a multi-stage ejector with a combination of a Venturi nozzle with a vortex nozzle in different views. The Venturi nozzles may here also be formed as a Coanda nozzles;
- **Figure 5:** FIG. 5 a multi-stage ejector with a combination of a Coanda nozzle with a Venturi nozzle;
- **Figure 6:** FIG. 6 a combination of the Coanda and the Bernoulli principle with outwardly guided exhaust air flow;
- **Figure 7:** FIG. 7 a combination of the Coanda and the Bernoulli principle with inwardly guided exhaust air flow for sucking in air and for generating a suction force, and
- **Figure 8:** FIG. 8 a combination of the vortex and the Coanda principle.
- **Figure 3:** FIG. 3 shows a combination of other vacuum units 8 , namely, a Venturi nozzle 10 and a Bernoulli nozzle 40 with separate vacuum chambers 14 and 42 , wherein the Venturi nozzle 10 may be formed circumferentially or from several individual nozzles. The exhaust port 22 of the Venturi nozzle 10 opens here also into the compressed air port 20 of the Bernoulli nozzle 40 .
- **Figure 6:** FIG. 6 shows a combination of a Coanda nozzle 12 and a Bernoulli nozzle 40 , similar to FIG. 3 with separate vacuum chambers 16 and 42 . The exhaust port 56 of the Coanda nozzle 12 serves as a compressed air port 20 for the Bernoulli nozzle 40 .
- **Figure 7:** FIG. 7 shows a vacuum gripper 6 with a combination of a Coanda nozzle 12 and a Bernoulli nozzle 40 with an inwardly guided air stream for drawing in suction air 26 and for generating a suction force for the workpiece 38 . Spacers 58 may be provided on the underside of the vacuum gripper 6 for maintaining a permanent flow of suction air 26 even when the workpiece 38 is drawn in.

## Classifications

- B65G47/91
- F04F5/16
- F04F5/16
- B25B11/00
- B65G47/91
- F04F5/22
- F04F5/22
- F04F5/54
- F04F5/54

## Cited patent documents

- [US-1333713-A](https://patents.google.com/patent/US1333713A/en) — PRS
- [US-2044088-A](https://patents.google.com/patent/US2044088A/en) — PRS
- [US-2938658-A](https://patents.google.com/patent/US2938658A/en) — PRS
- [US-2965312-A](https://patents.google.com/patent/US2965312A/en) — PRS
- [US-3739576-A](https://patents.google.com/patent/US3739576A/en) — PRS
- [US-3806039-A](https://patents.google.com/patent/US3806039A/en) — PRS
- [US-4046492-A](https://patents.google.com/patent/US4046492A/en) — PRS
- [US-4245961-A](https://patents.google.com/patent/US4245961A/en) — PRS
- [US-4749336-A](https://patents.google.com/patent/US4749336A/en) — PRS
- [US-5125579-A](https://patents.google.com/patent/US5125579A/en) — PRS
- [US-5344079-A](https://patents.google.com/patent/US5344079A/en) — PRS
- [US-6718752-B2](https://patents.google.com/patent/US6718752B2/en) — PRS
- [US-6854260-B2](https://patents.google.com/patent/US6854260B2/en) — PRS
- [US-8807458-B2](https://patents.google.com/patent/US8807458B2/en) — PRS

---

Generated by IPtorch. Verify legal conclusions against the official publication.
