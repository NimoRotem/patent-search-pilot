# 30. Suction gripper

- **Archive rank:** 30 of 50
- **Publication:** [EP-1580158-A1](https://patents.google.com/patent/EP1580158A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/034854050/publication/EP1580158A1?q=pn%3DEP1580158A1)
- **Publication date:** 2005-09-28
- **Filing date:** 2005-03-22
- **Earliest priority:** 2004-03-22
- **Family:** 34854050
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo, Google Patents full-document page

## Parties

- **Applicant / assignee:** SCHMALZ J GMBH
- **Inventors:** EISELE THOMAS; SCHMALZ KURT DR

## Abstract

A pressure pad (30) is located inside the suction space (22) and secured to the gripper base (12). The pad is a bellows made from an elastic material (preferably a plastic material and especially rubber) and filled, fillable or inflatable with a fluid.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/12/a4/ac/851984a9ce70f2/00110001.png)

![Sketch 1 for EP-1580158-A1](https://patentimages.storage.googleapis.com/12/a4/ac/851984a9ce70f2/00110001.png)

[Sketch 2](https://patentimages.storage.googleapis.com/50/8d/24/b0fa5431acb268/00120001.png)

![Sketch 2 for EP-1580158-A1](https://patentimages.storage.googleapis.com/50/8d/24/b0fa5431acb268/00120001.png)

## Claims

### Claim 1 (independent)

Sauggreifer (10) mit einem Grundkörper (12) und einer am Grundkörper (12) befestigten umlaufenden Dichtlippe (16), die vom Grundkörper (12) mit ihrer Dichtkante (18) abragt und einen Saugraum (22) umschließt, dadurch gekennzeichnet, dass innerhalb dieses Saugraumes (22) ein Druckkissen (30) am Grundkörper (12) befestigt ist.Suction gripper (10) having a base body (12) and a circumferential sealing lip (16) attached to the base body (12), which protrudes from the base body (12) with its sealing edge (18) and surrounds a suction space (22), characterized in that inside this suction space (22) a pressure pad (30) on the base body (12) is attached.

### Claim 2

Sauggreifer nach Anspruch 1, dadurch gekennzeichnet, dass das Druckkissen (30) hohl ist.Suction gripper according to claim 1, characterized in that the pressure pad (30) is hollow.

### Claim 3

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass das Druckkissen (30) mit einem Fluid gefüllt ist.Suction gripper according to one of the preceding claims, characterized in that the pressure pad (30) is filled with a fluid.

### Claim 4

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass das Druckkissen (30) aufblasbar oder auffüllbar ist.Suction gripper according to one of the preceding claims, characterized in that the pressure pad (30) is inflatable or refillable.

### Claim 5

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass das Druckkissen (30)auf unterschiedliche Größen aufblasbar oder auffüllbar ist.Suction gripper according to one of the preceding claims, characterized in that the pressure pad (30) is inflatable or refillable to different sizes.

### Claim 6

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass das Druckkissen (30) von einer an der dem Saugraum (22) zugewandten Außenseite (28) des Grundkörpers (12) befestigten Membran (32) gebildet wird.Suction gripper according to one of the preceding claims, characterized in that the pressure pad (30) is formed by a membrane (32) fastened to the outside (28) of the base body (12) facing the suction space (22).

### Claim 7

Sauggreifer nach einem der Ansprüche 1 bis 5, dadurch gekennzeichnet, dass das Druckkissen (30) ein Faltenbalg ist.Suction gripper according to one of claims 1 to 5, characterized in that the pressure pad (30) is a bellows.

### Claim 8

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass der Grundkörper (12) einen in das Druckkissen (30) mündenden Kanal (40) aufweist.Suction gripper according to one of the preceding claims, characterized in that the base body (12) has a channel (40) opening into the pressure pad (30).

### Claim 9

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass das Druckkissen (30) aus einem elastischen Material, insbesondere aus Kunststoff, vorzugsweise aus Gummi, besteht.Suction gripper according to one of the preceding claims, characterized in that the pressure pad (30) consists of an elastic material, in particular of plastic, preferably of rubber.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippersPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALHANDLING THIN OR FILAMENTARY MATERIAL, e.g. SHEETS, WEBS, CABLESSeparating articles from pilesSeparating articles from piles using pneumatic forceSuction grippersConstruction of suction grippers or their holding devicesPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansCircular shapePERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansSpecial lip configurationsPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansSingle lifting units; Only one suction cupPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSIndexing codes relating to handling devices, e.g. conveyors, characterised by the type of product or load being conveyed or handledArticlesArticles of special size, shape or weighFlatPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALHANDLING THIN OR FILAMENTARY MATERIAL, e.g. SHEETS, WEBS, CABLESHandling processes for sheets or websType of handling processPiling, depiling, handling pilesDepiling; Separating articles from a pileDepiling; Separating articles from a pile assisting separation or preventing double feedPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALHANDLING THIN OR FILAMENTARY MATERIAL, e.g. SHEETS, WEBS, CABLESProblem to be solved or advantage achievedAvoiding or preventing undesirable effectsPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALHANDLING THIN OR FILAMENTARY MATERIAL, e.g. SHEETS, WEBS, CABLESHandled material; Storage meansHandled articles or websNature of materialMetal

Description

Translated from German

Die Erfindung betrifft einen Sauggreifer mit einem

GrundkÃ¶rper und einer am GrundkÃ¶rper befestigten

umlaufenden Dichtlippe, die vom GrundkÃ¶rper mit ihrer

Dichtkante abragt und einen Saugraum umschlieÃt.The invention relates to a suction pad with a

Base body and one attached to the base body

circumferential sealing lip extending from the main body with its

Protruding sealing edge and surrounds a suction chamber.

Sauggreifer werden dazu benÃ¶tigt, um GegenstÃ¤nde

anzusaugen, anzuheben und an einen anderen Ort verbringen

zu kÃ¶nnen. HierfÃ¼r weist der Sauggreifer eine Dichtlippe

auf, die an der OberflÃ¤che des WerkstÃ¼cks anliegt und

zwischen dem Sauggreifer und der OberflÃ¤che des WerkstÃ¼cks

einen Saugraum umschlieÃt, welcher evakuiert werden kann. Suction cups are needed to hold objects

suck in, lift and spend somewhere else

to be able to. For this purpose, the suction pad has a sealing lip

on, which rests against the surface of the workpiece and

between the suction pad and the surface of the workpiece

encloses a suction chamber, which can be evacuated.

Dadurch legt sich der Sauggreifer dicht an die OberflÃ¤che

des WerkstÃ¼cks an und hÃ¤lt dieses pneumatisch fest.

Insbesondere bei der Handhabung von Blechen, zum Beispiel

in der Automobilindustrie, haben sich derartige Sauggreifer

bewÃ¤hrt. Da aber die Bleche oftmals eine geÃ¶lte OberflÃ¤che

aufweisen besteht mitunter die Gefahr, dass beim Ansaugen

und Abheben des obersten Bleches eines Blechstapels nicht

nur dieses Blech abgehoben wird, sondern dass an diesem

Blech aufgrund von AdhÃ¤sionskrÃ¤ften ein oder mehrere

weitere Bleche anhaften und mit abgehoben werden. Diese

AdhÃ¤sionskrÃ¤fte stammen von den aneinander anliegenden,

geÃ¶lten OberflÃ¤chen der Bleche.This places the suction pad close to the surface

of the workpiece and holds this pneumatically.

Especially when handling sheet metal, for example

in the automotive industry, such suction pads have become

proven. But since the sheets often have an oiled surface

sometimes there is a risk that when sucking

and lifting the top sheet of a sheet pile not

only this sheet is lifted, but that on this

Sheet metal due to adhesion forces one or more

adhere further sheets and be lifted off with. These

Adhesive forces come from the adjoining,

oiled surfaces of the sheets.

Der Erfindung liegt die Aufgabe zugrunde, einen Sauggreifer

bereitzustellen, mit dem sichergestellt werden kann, dass

bei einem Blechstapel lediglich das oberste Blech abgehoben

wird.The invention is based on the object, a suction pad

to ensure that

in a stack of sheets, only lifted the top sheet

becomes.

Diese Aufgabe wird mit einem Sauggreifer der eingangs

genannten Art erfindungsgemÃ¤Ã dadurch gelÃ¶st, dass

innerhalb des Saugraumes ein Druckkissen am GrundkÃ¶rper

befestigt ist.This task is done with a suction pad of the beginning

mentioned type according to the invention solved in that

within the suction chamber a pressure pad on the body

is attached.

Wird ein derartiger Sauggreifer auf die Oberseite eines

Bleches aufgesetzt, dann kommt die Dichtkante der

Dichtlippe mit der Oberseite des Bleches in BerÃ¼hrung und

der Saugraum ist geschlossen. Dieser Saugraum kann nun mit

einem Unterdruck beaufschlagt werden. An der Oberseite des

Bleches liegt jedoch nicht nur die Dichtkante der

Dichtlippe an, sondern an der Oberseite liegt auch das im

Saugraum befindliche Druckkissen an. Dieses Druckkissen

verhindert nun, dass beim Evakuieren des Saugraumes das

Blech in den Saugraum eingewÃ¶lbt wird. Vielmehr verformt

sich die Dichtlippe derart, dass sie zurÃ¼ckweicht, so dass

lediglich noch das Druckkissen vom GrundkÃ¶rper abragt. Das

Blech wird also nicht mehr konkav in den Saugraum

eingesaugt, sondern nimmt eine konvexe Form an, indem das

Druckkissen das Blech vom Saugraum wegdrÃ¼ckt, wobei der

Bereich auÃerhalb des Druckkissens Ã¼ber die Dichtlippe

angesaugt wird. Das Druckkissen ragt also weiter vom

GrundkÃ¶rper ab, als die Dichtlippe. Befindet sich ein

derartiger Sauggreifer im Randbereich des Bleches, wird

durch diese Verformung des Bleches der Randbereich des

obersten Bleches vom darunter liegenden Blech abgehoben, so

dass der zwischen den Blechen sich befindende Ãlfilm

aufgerissen wird, Luft einstrÃ¶men kann und dadurch die

AdhÃ¤sionskrÃ¤fte abgebaut werden. Hierdurch wird

sichergestellt, dass lediglich das oberste Blech eines

Blechstapels angesaugt und abgehoben wird.If such a suction pad on the top of a

Placed sheet metal, then comes the sealing edge of the

Sealing lip in contact with the top of the sheet metal and

the suction chamber is closed. This suction chamber can now use

be subjected to a negative pressure. At the top of the

However, sheet metal is not just the sealing edge of the

Sealing lip on, but at the top is also in the

Suction chamber located pressure pad on. This pressure pad

now prevents that when evacuating the suction chamber the

Sheet metal is arched into the suction chamber. Rather deformed

the sealing lip so that it recedes, so that

only the pressure pad protrudes from the base body. The

Sheet metal is therefore no longer concave in the suction chamber

sucks, but assumes a convex shape by the

Pressure pad pushes the sheet away from the suction chamber, wherein the

Area outside the pressure pad over the sealing lip

is sucked. So the pressure pad protrudes further from the

Base off, as the sealing lip. Is located

Such suction pads in the edge region of the sheet is

by this deformation of the sheet the edge area of the

lifted off the top sheet of the underlying sheet, so

that the oil film located between the sheets is

is torn open, air can flow in and thereby the

Adhesive forces are degraded. This will

ensures that only the top sheet of a

Sheet stack is sucked and lifted.

Dabei kann das Druckkissen aus Vollmaterial bestehen

beziehungsweise aus einem geschÃ¤umten Material gefertigt

sein, wobei bei einer anderen AusfÃ¼hrungsform das

Druckkissen hohl ist. Dieses hohle Druckkissen kann mit

einem kompressiblen Medium, zum Beispiel Gas, angefÃ¼llt

sein, es kann jedoch auch mit einem inkompressiblen Medium,

zum Beispiel einer FlÃ¼ssigkeit oder einem Gel, angefÃ¼llt

sein. Ein derartiges Druckkissen kann beim Aufsetzen des

Sauggreifers auf das anzusaugende WerkstÃ¼ck so lange

verformt werden, bis die Dichtkante der Dichtlippe an der

Oberseite des WerkstÃ¼cks anliegt und der Saugraum

geschlossen ist. Beim Evakuieren des Saugraumes kann dann

das Druckkissen, falls dieses mit einem kompressiblen

Medium angefÃ¼llt ist, sich aufgrund des umgebenden

Unterdruckes ausdehnen und eine Kraft auf das anzusaugende

WerkstÃ¼ck ausÃ¼ben.In this case, the pressure pad may consist of solid material

or made of a foamed material

be, wherein in another embodiment, the

Pressure pad is hollow. This hollow pressure pad can with

a compressible medium, for example gas, filled

but it can also be used with an incompressible medium,

for example, a liquid or gel filled

be. Such a pressure pad can when placing the

Suction gripper on the workpiece to be sucked so long

be deformed until the sealing edge of the sealing lip on the

Top of the workpiece rests and the suction chamber

closed is. When evacuating the suction chamber can then

the pressure pad, if this with a compressible

Medium is stuffed, due to the surrounding

Extend negative pressure and a force on the sucked

Exercise workpiece.

Bei einer Weiterbildung ist vorgesehen, dass das

Druckkissen aufblasbar oder auffÃ¼llbar ist. Bei dieser

Variante kann das Druckkissen entweder mit einem

kompressiblen oder mit einem inkompressiblen Fluid

angefÃ¼llt werden, so dass die Verformung des Druckkissens

gezielt gesteuert werden kann. So kann zum Beispiel die

Verformung lediglich in der Abhebephase stattfinden oder es

werden lediglich die Druckkissen der Sauggreifer

angesteuert, die sich im Randbereich eines Bleches

befinden. In a further development, it is provided that the

Pressure pad is inflatable or refillable. At this

Variant may be the pressure pad with either one

compressible or with an incompressible fluid

be filled, so that the deformation of the pressure pad

can be controlled selectively. For example, the

Deformation only take place in the lift-off phase or it

only the pressure pad of the suction pads

driven, located in the edge region of a sheet

are located.

Bei einer Weiterbildung ist vorgesehen, dass das

Druckkissen von einer an der dem Saugraum zugewandten

AuÃenseite des GrundkÃ¶rpers befestigten Membran gebildet

wird. Eine derartige Membran ist einfach herzustellen und

problemlos an der AuÃenseite des GrundkÃ¶rpers befestigbar.

Bei einer anderen AusfÃ¼hrungsform wird das Druckkissen von

einem Faltenbalg gebildet. Dieser Faltenbalg hat den

Vorteil, dass er stark expandierbar beziehungsweise

komprimierbar ist, und dass der Angriffspunkt

beziehungsweise die FlÃ¤che, an welcher das Druckkissen am

WerkstÃ¼ck angreift, exakt bestimmt werden kann.In a further development, it is provided that the

Pressure pad from one to the suction chamber facing

Outside of the main body attached membrane formed

becomes. Such a membrane is easy to manufacture and

easily attachable to the outside of the body.

In another embodiment, the pressure pad of

formed a bellows. This bellows has the

Advantage that he is highly expandable respectively

is compressible, and that the attack point

or the area at which the pressure pad on

Workpiece attacks, can be determined exactly.

Um das Druckkissen mit einem Medium zu versorgen, weist der

GrundkÃ¶rper erfindungsgemÃ¤Ã einen in das Druckkissen

mÃ¼ndenden Kanal auf. Ãber diesen Kanal kann ein Fluid, das

heiÃt ein Gas oder eine FlÃ¼ssigkeit, zu- beziehungsweise

abgefÃ¼hrt werden.To supply the pressure pad with a medium, the

Basic body according to the invention in the pressure pad

opening channel. Through this channel, a fluid, the

means a gas or a liquid, on or

be dissipated.

Mit Vorzug besteht das Druckkissen aus einem elastischen

Material, insbesondere aus Kunststoff, und vorzugsweise aus

Gummi. Es ist jedoch auch denkbar, dass zum Beispiel ein

Faltenbalg verwendet wird, der aus Metall besteht.With preference, the pressure pad consists of an elastic

Material, in particular of plastic, and preferably made of

Rubber. However, it is also conceivable that, for example, a

Bellows is used, which consists of metal.

Weitere vorteile, Merkmale und Einzelheiten der Erfindung

ergeben sich aus den AnsprÃ¼chen sowie der nachfolgenden

Beschreibung, in der unter Bezugnahme auf die Zeichnung ein

besonders bevorzugtes AusfÃ¼hrungsbeispiel im Einzelnen

beschrieben ist. Dabei kÃ¶nnen die in der Zeichnung

dargestellten sowie in der Beschreibung und in den

AnsprÃ¼chen erwÃ¤hnten Merkmale jeweils einzeln fÃ¼r sich oder

in beliebiger Kombination erfindungswesentlich sein.Further advantages, features and details of the invention

result from the claims and the following

Description, in reference to the drawing a

particularly preferred embodiment in detail

is described. It can in the drawing

presented as well as in the description and in the

Claims mentioned in each case individually or for themselves

be inventive in any combination.

In der Zeichnung zeigen:

Figur 1 einen LÃ¤ngsschnitt durch einen Sauggreifer; und

Figur 2 den Sauggreifer gemÃ¤Ã Figur 1 mit einem daran

angesaugten WerkstÃ¼ck.

In the drawing show:

Figure 1 shows a longitudinal section through a suction pad; and

2 shows the suction gripper according to Figure 1 with a workpiece sucked thereto.

In der Zeichnung ist ein insgesamt mit 10 bezeichneter

Sauggreifer dargestellt, der einen GrundkÃ¶rper 12, zum

Beispiel aus Aluminium, und ein daran befestigtes

Dichtelement 14 aus Kunststoff, insbesondere aus einem

Elastomer aufweist. Dieses Dichtelement 14 ist

auswechselbar am GrundkÃ¶rper 12 befestigt, insbesondere

aufgeklipst. Das Dichtelement 14 weist eine Dichtlippe 16

mit einer Dichtkante 18 auf, Ã¼ber welche bei Anlage an ein

WerkstÃ¼ck 20 ein Saugraum 22 abgeschlossen wird. Liegt, wie

in der Figur 2 dargestellt, ein WerkstÃ¼ck 20, insbesondere

ein Blech 24, am Saugreifer 10 an, dann ist der Saugraum 22

zur Umgebung hin abgedichtet. Er kann Ã¼ber einen Kanal 26

evakuiert werden. In the drawing, a total of 10 designated

Suction gripper shown, the base body 12, for

Example of aluminum, and one attached to it

Sealing element 14 made of plastic, in particular of a

Having elastomer. This sealing element 14 is

interchangeable attached to the base body 12, in particular

clipped. The sealing element 14 has a sealing lip 16

with a sealing edge 18, over which when investing in a

Workpiece 20, a suction chamber 22 is completed. Lies, like

shown in Figure 2, a workpiece 20, in particular

a sheet 24, the Saugreifer 10, then the suction chamber 22nd

sealed to the environment. He can over a channel 26

be evacuated.

An der dem WerkstÃ¼ck 20 zugewandten AuÃenseite 28 des

GrundkÃ¶rpers 12 ist ein insgesamt mit 30 bezeichnetes

Druckkissen befestigt, an welchem das WerkstÃ¼ck 20 anliegt.

Das Druckkissen 30 wird von einer Membran 32 gebildet, die

insbesondere aus Gummi bestehen. Die Membran 32 ist an

einen Halter 34 anvulkanisiert, der mittels Schrauben 36 am

GrundkÃ¶rper 12 fixiert ist, und umschlieÃt einen Hohlraum

38, der Ã¼ber einen Kanal 40 zugÃ¤nglich ist. Ãber diesen

Kanal 40 kann der Hohlraum 38 mit Druckluft oder einem

anderen Medium beaufschlagt werden, so dass sich die

Membran 32 nach auÃen, dass heiÃt in Richtung des

werkstÃ¼cks 20 auswÃ¶lbt. Es besteht jedoch auch die

MÃ¶glichkeit, dass der Kanal 40 verschlossen wird, so dass

der Hohlraum 38 abgeschlossen ist. Dabei kann der Hohlraum

38 mit einem komprimierbaren oder einem inkompressieblen

Medium, Luft oder ein Gel, angefÃ¼llt sein.At the workpiece 20 facing the outside 28 of the

Base 12 is a designated 30 in total

Attached pressure pad on which the workpiece 20 is applied.

The pressure pad 30 is formed by a membrane 32, the

especially made of rubber. The membrane 32 is on

vulcanized a holder 34 which by means of screws 36 on

Base body 12 is fixed, and encloses a cavity

38, which is accessible via a channel 40. About this

Channel 40, the cavity 38 with compressed air or a

be applied to other medium, so that the

Membrane 32 to the outside, that is in the direction of the

workpiece 20 bulges. However, there is also the

Possibility that the channel 40 is closed, so that

the cavity 38 is completed. In this case, the cavity

38 with a compressible or incompressieblen

Medium, air or a gel, be filled.

Wird der Sauggreifer 10, wie in der Figur 2 dargestellt,

auf ein WerkstÃ¼ck 20 aufgesetzt und der Saugraum 22

evakuiert, dann legen sich die Dichtlippen 16 flÃ¤chig an

der Oberseite des WerkstÃ¼cks 20, wobei der zwischen den

Dichtlippen 18 sich befindende Bereich des WerkstÃ¼cks vom

Druckkissen 30 abgestÃ¼tzt wird. Mit zunehmendem Evakuieren

des Saugraumes 22 werden die Dichtlippen 16 nach oben

gebogen und nehmen das Blech 24 in diesem Bereich mit. If the suction gripper 10, as shown in Figure 2,

placed on a workpiece 20 and the suction chamber 22nd

evacuated, then put the sealing lips 16 flat

the top of the workpiece 20, wherein the between the

Sealing lips 18 located area of the workpiece from

Pressure pad 30 is supported. With increasing evacuation

of the suction chamber 22, the sealing lips 16 are upwards

bent and take the sheet 24 in this area.

Befindet sich der Saugreifer 10 in der NÃ¤he eines Randes 42

des Bleches 24, dann wird dieser Rand 42 nach oben gebogen

und das oberste Blech eines Blechstapels 44 abgehoben.

Dabei kann das Druckkissen 30 durch Zugabe von Druckluft

Ã¼ber den Kanal 40 zusÃ¤tzlich aufgeblasen werden, wodurch

die UnterstÃ¼tzungswirkung im mittleren Bereich noch

vergrÃ¶Ãert wird. Hierdurch wird sichergestellt, dass das

oberste Blech 24 vom Stapel 44 quasi abgeschÃ¤lz wird, so

dass lediglich dieses oberste Blech 24 und keine der

darunter liegenden Bleche mit abgehoben werden. Durch

gezielte Ansteuerung kÃ¶nnen z.B. lediglich die im Bereich

eines Randes 42 sich befindende Saugreifer 10 mit Druckluft

versorgt werden, so dass lediglich dort das Druckkissen 30

aktiviert wird und lediglich in diesem Bereich das Blech

24, wie dargestellt, verformt wird, um die RÃ¤nder 42

abzuheben.Is the Saugreifer 10 in the vicinity of an edge 42nd

of the sheet 24, then this edge 42 is bent upwards

and the top sheet of a stack of sheets 44 lifted.

In this case, the pressure pad 30 by adding compressed air

be additionally inflated via the channel 40, whereby

the support effect in the middle range still

is enlarged. This will ensure that the

top plate 24 from the stack 44 is virtually peeled off, so

that only this top sheet 24 and none of

underlying sheets to be lifted off. By

targeted driving can e.g. only in the area

an edge 42 located Saugreifer 10 with compressed air

be supplied, so that only there the pressure pad 30th

is activated and only in this area the sheet metal

24, as shown, around the edges 42

withdraw.

Mit einem derartigen Saugreifer 10 kÃ¶nnen Bleche 24 von

einem Stapel 44 mit Sicherheit einzeln abgehoben werden.With such a Saugreifer 10 sheets 24 of

a stack 44 are certainly lifted individually.

## Classifications

- B65G47/91
- B65G2201/022
- B65G47/91
- B65H2301/4234
- B65H2601/20
- B65H2701/173
- B65H3/08
- B65H3/0883
- B66C1/02
- B66C1/0212
- B66C1/0231
- B66C1/0293

## Cited patent documents

- [DE-4002324-A1](https://patents.google.com/patent/DE4002324A1/en) — SEA
- [EP-0368166-A2](https://patents.google.com/patent/EP0368166A2/en) — SEA
- [US-3724687-A](https://patents.google.com/patent/US3724687A/en) — APP,SEA
- [US-4589648-A](https://patents.google.com/patent/US4589648A/en) — APP,SEA
- [US-4979729-A](https://patents.google.com/patent/US4979729A/en) — APP,SEA

---

Generated by IPtorch. Verify legal conclusions against the official publication.
