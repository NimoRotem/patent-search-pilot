# 12. Vakuumgreifer fuer vorzugsweise flaechige Gegenstaende

- **Archive rank:** 12 of 50
- **Publication:** [DE-1286275-B](https://patents.google.com/patent/DE1286275B/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/007128644/publication/DE1286275B?q=pn%3DDE1286275B)
- **Publication date:** 1969-01-02
- **Filing date:** 1966-11-04
- **Earliest priority:** 1966-11-04
- **Family:** 7128644
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** VACU LIFT MASCHB GMBH
- **Inventors:** RUDOLF GLANEMANN

## Abstract

_No abstract was available from the queried sources._

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-1286275-B/ops000.png)

![Sketch 1 for DE-1286275-B](https://nimo.iptorch.com/refdrawing/DE-1286275-B/ops000.png)

## Claims

### Claim 1 (independent)

Vakuumgreifer für vorzugsweise flächige Gegenstände, bestehend aus einem Zylinder, einem darin verschiebbaren, nach oben hin offenen Kolben und einer von der Kolbenoberkante zu der Zylinderoberkante verlaufenden, an der Zylinderinnenwandung anliegenden, abdichtenden Rollmembran, dadurch gekennzeichnet, daß ferner ein Innenzylinder (14) vorgesehen ist, der kürzer als der Außenzylinder (10) ist und zusammen mit diesem einen oberen, durch einen Deckelflansch (15) dicht abgeschlossenen Ringraum (16) bildet, in den von unten her der Kolben (17) mit seiner Wandung (18) einschiebbar ist, an deren freiem Ende (Flansch 23) die sich auch zur Oberkante (Innenflansch 21) des kürzeren Innenzylinders (14) erstreckende und den Ringraum (16) auch nach unten dicht abschließende, verschiebbare Rollmembran (19) befestigt ist.1. Vacuum gripper for preferably flat objects, consisting of a cylinder, a piston that can be moved in it and is open at the top, and one from the upper edge of the piston to the upper edge of the cylinder, adjacent to the cylinder inner wall, sealing Rolling membrane, characterized in that an inner cylinder (14) is also provided is, which is shorter than the outer cylinder (10) and together with this an upper, through forms a cover flange (15) tightly sealed annular space (16) into which the from below Piston (17) can be pushed in with its wall (18), at the free end (flange 23) of which the also extending to the upper edge (inner flange 21) of the shorter inner cylinder (14) and the annular space (16) also attached to the bottom tightly sealing, displaceable roller membrane (19) is.

### Claim 2

Vakuumgreifer nach Anspruch 1, dadurch gekennzeichnet, daß sich die Rollmembran (19) von einem die Oberkante bildenden Innenflansch (21) des Innenzylinders (14) aus fortsetzt und mittels einer mittig vorhandenen Ausnehmung zum Schutz der darunter befindlichen Einrichtungen gegen das Eindringen von Feuchtigkeit und Schmutz über die Kolbenstange (27) gezogen ist.2. Vacuum gripper according to claim 1, characterized in that the rolling membrane (19) from an inner flange (21) of the inner cylinder (14) which forms the upper edge and continues by means of a central recess to protect the facilities below Pulled over the piston rod (27) to prevent the ingress of moisture and dirt is.

### Claim 3

Vakuumgreifer nach den Ansprüchen 1 und 2, dadurch gekennzeichnet, daß der durch die Rollmembran (19) luftdicht abgeschlossene, als Druckraum wirkende Ringraum (16) mit einem nach außen hin sperrenden Rückschlagventil (36) und mit einem Luftauslaßventil (37) mit Pfeife über entsprechende, im Deckelflansch (15) angebrachte Bohrungen in Verbindung steht.3. Vacuum gripper according to claims 1 and 2, characterized in that the through the rolling diaphragm (19) with an airtight ring chamber (16) acting as a pressure chamber an outwardly blocking check valve (36) and with an air outlet valve (37) is connected to the whistle via corresponding holes in the cover flange (15). Hierzu 1 Blatt Zeichnungen 1 sheet of drawings

## Full description

PERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansSingle lifting units; Only one suction cupPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippersPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansCircular shape

Description

Translated from German

1 21 2

Die Erfindung bezieht sich auf einen Vakuum- Oberkante bildenden Innenflansch des Innenzylinders

greifer, bei dem das Haftvakuum durch die auf- aus fort und ist mittels einer mittig vorhandenen Ausgenommene

Last selbst erzeugt wird. Sie geht aus von nehmung zum Schutz der darunter befindlichen Eineinem

Vakuumgreifer fÃ¼r vorzugsweise flÃ¤chige richtungen gegen das Eindringen von Feuchtigkeit

GegenstÃ¤nde, der aus einem Zylinder, einem darin 5 und Schmutz Ã¼ber die Kolbenstange gezogen,

verschiebbaren, nach oben hin offenen Kolben und Der durch die Rollmembran luftdicht abgeschloseiner

von der Kolbenoberkante zu der Zylinderober- sene, als Druckraum wirkende Ringraum steht mit

kante verlaufenden, an der Zylinderinnenwandung einem nach auÃen hin sperrenden RÃ¼ckschlagventil

anliegenden, abdichtenden Rollmembran besteht. und einem LuftauslaÃventil mit Pfeife Ã¼ber ent-Bekannt

ist bereits ein SauggreifgerÃ¤t, welches aus io sprechende, im Deckelflansch angebrachte Bohrungen

zwei miteinander verschraubten Zylinderteilen und in Verbindung.The invention relates to an inner flange of the inner cylinder which forms the upper edge of the vacuum

gripper, in which the adhesive vacuum continues through the open and is by means of a central gutted

Load is generated by itself. It is based on the assumption to protect the one below

Vacuum gripper for preferably flat directions against the ingress of moisture

Objects pulled from a cylinder, one in it 5 and dirt over the piston rod,

sliding, upwardly open piston and the airtight sealed by the rolling diaphragm

from the top edge of the piston to the top of the cylinder, the annular space acting as a pressure space stands with

edge running, on the cylinder inner wall an outwardly blocking check valve

adjacent, sealing roll membrane consists. and an air outlet valve with a whistle via ent-known

is already a suction gripper, which is made of io-speaking, drilled holes in the cover flange

two cylinder parts screwed together and in connection.

einem nach oben hin offenen Kolben besteht, wobei Der erfindungsgemÃ¤Ãe Vakuumgreifer besitzt ineine

Rollmembran mit ihrem einen Rand zwischen folge des als Sicherheitsdruckraum wirkenden Ringden

Zylinderteilen festgelegt und mit ihrem anderen raumes und der akustischen Einrichtungen zur AnRand

am oberen Kolbenrand befestigt ist. Die Roll- 15 zeige von Gefahr beachtliche Vorteile gegenÃ¼ber den

membran liegt bei dieser bekannten AusfÃ¼hrungs- Vakuumgreifern nach dem Stand der Technik. Wird

form eines Vakuumgreifers an der Zylinderinnen- mit dem erfindungsgemÃ¤Ã ausgebildeten Vakuumwandung

an. greifer eine Last gehoben, so bewegt sich der Kolbenconsists of an upwardly open piston, wherein the vacuum gripper according to the invention has in a

Rolling membrane with one edge between the following of the ring that acts as a safety pressure chamber

Cylinder parts set and with their other room and the acoustic facilities to the edge

is attached to the upper edge of the piston. The roll 15 show considerable advantages over the danger

The membrane is in this known execution vacuum gripper according to the prior art. Will

form of a vacuum gripper on the inside of the cylinder with the vacuum wall designed according to the invention

at. When the gripper lifts a load, the piston moves

Der beim Heben einer Last entstehende Unter- im AuÃenzylinder unter Vakuumerzeugung nach

druck wird mit Hilfe eines Manometers gemessen und ao oben. Gleichzeitig jedoch wird die im RingdruckraumThe lower cylinder in the outer cylinder that occurs when a load is lifted under vacuum generation

pressure is measured with the help of a manometer and ao above. At the same time, however, the pressure in the annulus

kann an einem SichtanzeigegerÃ¤t abgelesen werden. vorhandene Luft komprimiert. Die zur Warnung vor-can be read on a display device. existing air is compressed. The warning

Die Anordnung lediglich eines Ableseinstrumentes gesehene Pfeife kann man so einregulieren, daÃ sieThe arrangement of only a reading instrument seen pipe can be adjusted so that it

am VakuumgreifgerÃ¤t ist insofern nachteilig, als das ertÃ¶nt, wenn sich der Kolben beim Anheben der Laston the vacuum gripping device is disadvantageous in that it sounds when the piston is when the load is lifted

Bedienungspersonal nicht immer wÃ¤hrend des Han- nach oben bewegt. Dabei wird dann die Ã¼berschÃ¼ssige

tierens mit dem VakuumgreifgerÃ¤t den herrschenden 25 Luft durch die Pfeife ins Freie geleitet. HÃ¤ngt dieOperating personnel not always moved up during the hand. This then removes the excess

the air through the pipe into the open air with the vacuum gripper. Depends on the

Unterdruck optisch erfassen kann. Oftmals muÃ bei Last an dem HebegerÃ¤t, so nimmt der Kolben eineCan detect negative pressure optically. Often when there is a load on the lifter, the piston takes one

hÃ¤ngender Last gearbeitet werden. Wenn in der An- bestimmte Mittelstellung zwischen der untersten undsuspended load. If there is a certain middle position between the lowest and

lage durch irgendwelche Ursachen eine Undichtig- der obersten mÃ¶glichen Stellung ein. Beim Auftretenlay a leak due to some cause - the highest possible position. When occurring

keit auftritt, so wird zunÃ¤chst der Kolben bei gleich- einer Undichtigkeit gleitet der Kolben weiter nachIf there is a leakage, the piston will first slide in the event of a leak

bleibendem Vakuum im Zylinder bis zu einem An- 30 oben zur oberen Endstellung hin, wobei wiederumremaining vacuum in the cylinder up to a 30 up to the upper end position, again

schlag hochgehen, daraufhin aber wird der Druck Luft aus dem Druckraum Ã¼ber die Signalpfeife insblow up, but then the pressure is air from the pressure chamber via the signal whistle into

schnell ansteigen, d. h. das Vakuum immer geringer Freie entweicht. Tritt also bei hÃ¤ngender Last einrise rapidly, d. H. the vacuum escapes less and less. So occurs when the load is hanging

werden, und dann besteht die Gefahr, daÃ die Last Warnton auf, so bedeutet dies, daÃ der Kolben weiterand then there is a risk that the load will beep, this means that the piston continues

abfÃ¤llt. Wenn das Bedienungspersonal nicht auÃer- nach oben wandert und nach dessen Anschlag imfalls off. If the operating personnel does not move out of the way up and after it has hit the

ordentlich gut aufpaÃt, kann es schnell zu UnglÃ¼cks- 35 oberen Totpunkt dann das Haftvakuum abnimmt,careful, it can quickly lead to unfortunate 35 top dead center then the adhesive vacuum decreases,

fÃ¤llen kommen. Die Pfeife kann auch in anderer Weise einreguliertcases come. The whistle can also be adjusted in other ways

Die Erfindung hat sich daher die Aufgabe gestellt, sein, so daÃ sie erst nach Ãberschreiten eines gewiseine

akustische Sicherheitseinrichtung zu schaffen, sen Ãberdrucks anspricht. Geht der Kolben beim

die die Arbeiter bei der geringsten Undichtigkeit im Aufnehmen einer Last im Zylinder in die HÃ¶he, entSystem

warnt. 40 steht im erfindungsgemÃ¤Ã angeordneten RingraumThe invention has therefore set itself the task of being so that it only after a certain amount has been exceeded

To create acoustic safety device that responds to overpressure. The piston goes at

which the workers at the slightest leak in picking up a load in the cylinder, entSystem

warns. 40 stands in the annular space arranged according to the invention

Die Aufgabe der Erfindung besteht insbesondere in ein Ãberdruck. Bei einer auftretenden UndichtigkeitThe object of the invention consists in particular in an overpressure. In the event of a leak

der Schaffung eines hierfÃ¼r geeigneten Druckraumes erhÃ¶ht sich dann natÃ¼rlich der Druck im Ringraum,the creation of a suitable pressure space then naturally increases the pressure in the annulus,

und einer speziellen, diesen Druckraum verschlieÃen- und von einem bestimmten, einstellbaren Wert anand a special one that closes this pressure space and starts from a certain, adjustable value

den Rollmembran, die zugleich das Dichtungselement entweicht die komprimierte Luft unter Erzeugungthe rolling diaphragm, which is also the sealing element, escapes the compressed air while generating

zwischen Saugkolben und Zylinder darstellt. 45 eines Warntons aus der Pfeife.represents between suction piston and cylinder. 45 of a warning tone from the whistle.

Eine weitere Aufgabe der Erfindung besteht Ein weiterer Vorteil ist in der speziellen AusbilschlieÃlich

in der Schaffung einer einfachen, elasti- dung der Rollmembran bzw. -manschette fÃ¼r die

sehen Abdeckung der sich bewegenden Teile der Dichtung zu sehen. Diese ist zwischen Kolbenober-Zylinder-Kolben-Anordnung

gegen das Eindringen kante und den Oberkanten des AuÃenzylinders sowie von Feuchtigkeit und Schmutz. so des Innenzylinders festgelegt und ermÃ¶glicht Ã¼ber-Another object of the invention is. Another advantage is in the particular design

in the creation of a simple, elasticization of the roll membrane or cuff for the

see cover to see the moving parts of the seal. This is between the piston-cylinder-piston arrangement

against the penetration edge and the upper edges of the outer cylinder as well as moisture and dirt. so defined of the inner cylinder and allows over-

Zur LÃ¶sung dieser Aufgaben wird bei einem Va- haupt erst das Arbeiten mit dem Ringraum als Sicher-In order to solve these tasks, one of Vada's first considerations is to work with the annular space as a safety

kuumgreifer, der aus einem Zylinder, einem darin ver- heitsdruckraum.vacuum gripper, which consists of a cylinder and a pressure chamber inside.

schiebbaren, nach oben hin offenen Kolben und einer SchlieÃlich ist noch vorteilhaft, daÃ sich die RoIlvon

Kolbenoberkante zu Zylinderoberkante ver- membran gemÃ¤Ã der Erfindung als Abdeckung fÃ¼r

laufenden, an der Zylinderinnenwandung anliegenden 55 die vor Schmutz und Feuchtigkeit zu schÃ¼tzende Ein-Dichtungsrollmembran

besteht, gemÃ¤Ã der Erfindung richtung der Zylinder-Kolben-Anordnung verwenden vorgeschlagen, ferner einen Innenzylinder vorzu- lÃ¤Ãt, indem sie mittels einer Ausnehmung Ã¼ber die

sehen, der kÃ¼rzer als der AuÃenzylinder ist und zu- Kolbenstange gezogen wird. Wie aus der Zeichnung

sammen mit diesem einen oberen, durch einen Dek- ersichtlich ist, legt sie sich schÃ¼sseifÃ¶rmig um die Kolkelflansch

dicht abgeschlossenen Ringraum bildet, in 60 benstange und fÃ¤ngt Wasser und Schmutz auf. Diese

den von unten her der Kolben mit seiner Wandung flieÃen spÃ¤ter bei hochstehendem Kolben von der

einschlieÃbar ist, an deren freiem Ende die sich auch dann kuppenfÃ¶rmigen Abdeckung nach auÃen ab.

zur Oberkante des kÃ¼rzeren Innenzylinders erstrek- Die erfindungsgemÃ¤Ã angeordnete Rollmembran

kende und den Ringraum auch nach unten dicht vereinigt somit mehrere Wirkungen in sich. Sie ist

abschlieÃende, verschiebbare Rollmembran be- 65 nicht nur ein Bestandteil des Vakuumgreifers zur

festigt ist. Erzeugung des Haftvakuums zum Heben von Lasten,sliding, upwardly open piston and a Finally, it is also advantageous that the RoIlvon

Piston top edge to cylinder top edge vermembran according to the invention as a cover for

running, resting against the cylinder inner wall 55 is the one-sealing rolling membrane to be protected from dirt and moisture

consists, proposed according to the invention to use the direction of the cylinder-piston arrangement, also an inner cylinder vorzu- can by means of a recess over the

see, which is shorter than the outer cylinder and is pulled to the piston rod. As from the drawing

Together with this one upper one, which can be seen through a cover, it lies around the piston flange in the shape of a bowl

forms a tightly sealed annulus, in 60 rods and catches water and dirt. These

The piston with its wall from below will later flow away from the piston when the piston is in the upright position

can be included, at the free end of which the dome-shaped cover then extends outwards.

The rolling membrane arranged according to the invention extends to the upper edge of the shorter inner cylinder

kende and the annular space also tightly downwards thus combines several effects in itself. she is

The final, displaceable rolling membrane is not only part of the 65 vacuum gripper

is consolidated. Creation of the adhesive vacuum for lifting loads,

GemÃ¤Ã einer bevorzugten AusfÃ¼hrungsform der sondern sie ist gleichermaÃen Bestandteil des erfin-According to a preferred embodiment of the but it is equally part of the invention

Erfindung setzt sich die Rollmembran von einem die dungsgemÃ¤Ã vorgesehenen SicherheitsdruckraumesIn accordance with the invention, the rolling diaphragm is made up of a safety pressure chamber provided according to the invention

und schÃ¼tzt auÃerdem das gesamte VakuumgreifgerÃ¤t gegen das Eindringen von Schmutz und Feuchtigkeit.

DemgegenÃ¼ber dient bei dem bekannten Vakuumgreifer die Rollmembran nur zur Erzeugung des

Haftvakuums. Zur Vakuumanzeige ist ein besonderes Manometer an das VakuumgreifgerÃ¤t angebaut. Die

Abdeckung gegen Schmutz und Wasser erfolgt mittels eines weiteren, am Kopf des VakuumgreifgerÃ¤tes

angebrachten Manschettenbalges. Abgesehen von den hinsichtlich der Sicherheit vorhandenen VorzÃ¼gen

beim erfindungsgemÃ¤Ã ausgebildeten Vakuumgreifer weist dieser noch eine betrÃ¤chtliche Vereinfachung

auf, da die Rollmembran drei Wirkungen in sich vereinigt. and also protects the entire vacuum gripper against the ingress of dirt and moisture.

In contrast, in the known vacuum gripper, the rolling membrane is only used to generate the

Adhesive vacuum. A special pressure gauge is attached to the vacuum gripping device to indicate the vacuum. the

Covering against dirt and water takes place by means of another one on the head of the vacuum gripping device

attached cuff bellows. Apart from the advantages in terms of security

in the case of the vacuum gripper designed according to the invention, this still has a considerable simplification

because the rolling membrane combines three effects.

Nachfolgend wird die Erfindung an Hand eines in der Zeichnung dargestellten Vakuumgreifers erlÃ¤utert,

bei der ein Axialschnitt durch den Vakuumgreifer gezeigt ist.The invention is explained below using a vacuum gripper shown in the drawing,

in which an axial section through the vacuum gripper is shown.

An einem AuÃenzylinder 10 ist ein Ring 11 zum Aufsetzen auf eine zu hebende Last angeflanscht, ao

Dieser Ring 11 nimmt einen elastischen Dichtring 12 mit Halbrundprofil 13 auf.A ring 11 for placing on a load to be lifted is flanged to an outer cylinder 10, ao

This ring 11 accommodates an elastic sealing ring 12 with a semicircular profile 13.

Vom AuÃenzylinder 10 und einem im Vergleich dazu kÃ¼rzeren Innenzylinder 14 wird ein oberer,

durch einen Deckelflansch 15 dicht abgeschlossener Ringraum 16 gebildet, in den von unten her ein nach

oben hin offener Kolben 17 mit seiner Wandung 18 einschiebbar ist. Am freien Ende der Wandung 18 ist

eine den Ringraum 16 auch nach unten hin dicht abschlieÃende, verschiebbare, als Rollmembran 19 ausgebildete

Dichtung befestigt. Die Rollmembran 19 ist einerseits zwischen dem Deckelflansch 15 und einem

AuÃenflansch 20 des AuÃenzylinders 10 bzw. einem Innenflansch 21 des Innenzylinders 14 und andererseits

zwischen einem Haltering 22 und einem am freien Ende der Wandung 18 des Kolbens 17 vorgesehenen

Flansch 23 durch Verschraubung festgelegt. An upper,

formed by a cover flange 15 tightly closed annular space 16, into which a from below

Piston 17, which is open at the top, can be pushed in with its wall 18. At the free end of the wall 18 is

a displaceable, designed as a rolling diaphragm 19, which also seals the annular space 16 tightly towards the bottom

Seal attached. The rolling membrane 19 is on the one hand between the cover flange 15 and a

Outer flange 20 of the outer cylinder 10 or an inner flange 21 of the inner cylinder 14 and on the other hand

between a retaining ring 22 and one provided at the free end of the wall 18 of the piston 17

Flange 23 fixed by screwing.

Die Rollmembran 19 ist im Schnitt vorzugsweise U-fÃ¶rmig ausgebildet und liegt mit ihren nicht festgelegten

Teilen lose an der Innenwand des AuÃenzylinders 10 bzw. an der AuÃenwand des Innenzylinders

14 an.The rolling diaphragm 19 is preferably U-shaped in section and is not fixed with its

Parts loosely on the inner wall of the outer cylinder 10 or on the outer wall of the inner cylinder

14 at.

Im unteren Bereich des Innenzylinders 14 ist an der vom Ringraum 16 abgewandten Seite eine mit

einer groÃen Bohrung versehene Platte 24 fÃ¼r einen durch die Bohrung der Platte 24 fassenden und auf

dem Boden des Kolbens 17 befestigten FÃ¼hrungszylinder 26 vorgesehen. Die Bohrung durch die Platte

24 ist durch einen mit der Platte 24 verbundenen FÃ¼hrungsring 25 verlÃ¤ngert.In the lower region of the inner cylinder 14, on the side facing away from the annular space 16, there is one with

a large bore provided plate 24 for a through the bore of the plate 24 and on

the bottom of the piston 17 attached guide cylinder 26 is provided. The hole through the plate

24 is extended by a guide ring 25 connected to the plate 24.

In einer Axialbohrung des FÃ¼hrungszylinders 26 ist eine Kolbenstange 27 um eine geringe HÃ¶he verschiebbar

angeordnet, die an ihrem in der NÃ¤he des Kolbenbodens befindlichen Ende einen AuÃenbund

28 aufweist.A piston rod 27 can be displaced by a small height in an axial bore of the guide cylinder 26

arranged, which at its end located in the vicinity of the piston crown has an outer collar

28 has.

Die Rollmembran 19 setzt sich vom Innenflansch 21 des Innenzylinders 14 aus fort und ist mittels einer

mittig vorhandenen Ausnehmung Ã¼ber die Kolbenstange 27 bis zum FÃ¼hrungszylinder 26 geschoben.The rolling diaphragm 19 continues from the inner flange 21 of the inner cylinder 14 and is by means of a

the central recess is pushed over the piston rod 27 to the guide cylinder 26.

Der Deckelflansch 15 weist zwei Bohrungen auf. wobei Ã¼ber der einen Bohrung ein nach auÃen hin

sperrendes RÃ¼ckschlagventil 36 und Ã¼ber der anderen Bohrung ein LuftauslaÃventil 37 mit Pfeife angeordnet

ist. Unterhalb des LuftauslaÃventils 37 und in der VerlÃ¤ngerung der im Deckelflansch 15 angeordneten

Bohrung ist ein StÃ¶Ãel vorgesehen, dessen BetÃ¤tigung durch den Kolben 17 bzw. durch den Haltering 22

das AuslaÃventil 37 Ã¶ffnet, so daÃ die komprimierte Luft durch die Pfeife unter Erzeugung eines Wamtones

entweichen kann. Ferner ist ein Manometer 44 vorgesehen.The cover flange 15 has two bores. with one hole facing outwards

blocking check valve 36 and above the other bore an air outlet valve 37 with a whistle

is. Below the air outlet valve 37 and in the extension of the one in the cover flange 15

A tappet is provided in the bore, which is actuated by the piston 17 or by the retaining ring 22

the outlet valve 37 opens so that the compressed air passes through the whistle, producing a warning tone

can escape. A manometer 44 is also provided.

Der erfindungsgemÃ¤Ã ausgebildete Vakuumgreifer mit Sicherheitsdruckraum arbeitet wie folgt:The vacuum gripper designed according to the invention with a safety pressure chamber works as follows:

Beim Aufnehmen einer Last bewegt sich der Kolben 17 infolge der einwirkenden KrÃ¤fte nach oben in

den Ringraum 16 hinein, bzw. der Ringraum 16 schiebt sich Ã¼ber die Kolbenwandung 18. Durch das

Vorhandensein der Rollmembran 19, die einwandfrei abdichtet, bildet sich im Ringraum 16 ein Ãberdruck

aus. Bei Undichtigkeiten, z. B. im ergriffenen WerkstÃ¼ck, dringt von auÃen Luft in das erzeugte

Vakuum, was zur Folge hat, daÃ sich der Kolben 17 noch weiter im Ringraum 16 aufwÃ¤rts bewegt. Beim

BetÃ¤tigen des StÃ¶Ãels des LuftauslaÃventils 37 erklingt ein durch die dort angeordnete Pfeife erzeugter

Warnton. Hierdurch wird angezeigt, daÃ keine Hubreserve mehr vorhanden ist. In diesem Moment wird

jedoch die Last noch durch das volle Vakuum gehalten. Erst von diesem Zeitpunkt an weiter durch

undichte Stellen eindringende Luft lÃ¤Ãt den Unterdruck langsam absinken, was man durch Beobachtung

des Manometers 44 verfolgen kann. Selbst beim Absinken des Unterdrucks auf den halben Wert ist

noch genÃ¼gend Zeit zum Absetzen der Last vorhanden. When a load is picked up, the piston 17 moves upwards in due to the forces acting on it

the annular space 16 into it, or the annular space 16 pushes over the piston wall 18

The presence of the rolling diaphragm 19, which seals properly, creates an overpressure in the annular space 16

the end. In the event of leaks, e.g. B. in the gripped workpiece, air penetrates from the outside into the generated

Vacuum, with the result that the piston 17 moves even further upwards in the annular space 16. At the

When the plunger of the air outlet valve 37 is actuated, a whistle generated by the whistle located there sounds

Beep. This indicates that there is no longer any lift reserve. At that moment will

however, the load was still held by the full vacuum. Only from this point onward through

Air penetrating leaks causes the negative pressure to drop slowly, which can be seen by observation

of the manometer 44 can follow. Even when the negative pressure drops to half the value

there is still enough time to set down the load.

## Classifications

- B66C1/0293
- B66C1/0293
- B65G47/91
- B65G47/91
- B65G47/91
- B66C1/02
- B66C1/0212
- B66C1/0212

## Cited patent documents

- [GB-1029109-A](https://patents.google.com/patent/GB1029109A/en) — SEA
- [US-2776857-A](https://patents.google.com/patent/US2776857A/en) — SEA

---

Generated by IPtorch. Verify legal conclusions against the official publication.
