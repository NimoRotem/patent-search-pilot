# 01. Device for handling discs, such as CDs

- **Archive rank:** 1 of 50
- **Publication:** [US-6328363-B1](https://patents.google.com/patent/US6328363B1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/008090375/publication/US6328363B1?q=pn%3DUS6328363B1)
- **Publication date:** 2001-12-11
- **Filing date:** 2000-08-30
- **Earliest priority:** 1999-02-05
- **Family:** 8090375
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** TOMMY LARSEN AS

## Abstract

A device for handling light objects, such as CDs, with one hand without the objects being touched with the hand, the device having one or more suction parts configured for inspiration against a plane face of the object and a gripper configured for being seized and secured with one hand. A flexible elastomer body is provided at the gripper which is configured for complete or partial filling and emptying of a void in order to produce, via one or more communication passages, a sub atmospheric pressure between the suction parts and the plane face of the objects upon abutment and inspiration by the device against the object.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-6328363-B1/000.png)

![Sketch 1 for US-6328363-B1](https://nimo.iptorch.com/refdrawing/US-6328363-B1/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/US-6328363-B1/001.png)

![Sketch 2 for US-6328363-B1](https://nimo.iptorch.com/refdrawing/US-6328363-B1/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/US-6328363-B1/002.png)

![Sketch 3 for US-6328363-B1](https://nimo.iptorch.com/refdrawing/US-6328363-B1/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/US-6328363-B1/003.png)

![Sketch 4 for US-6328363-B1](https://nimo.iptorch.com/refdrawing/US-6328363-B1/003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/US-6328363-B1/004.png)

![Sketch 5 for US-6328363-B1](https://nimo.iptorch.com/refdrawing/US-6328363-B1/004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/US-6328363-B1/005.png)

![Sketch 6 for US-6328363-B1](https://nimo.iptorch.com/refdrawing/US-6328363-B1/005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/US-6328363-B1/006.png)

![Sketch 7 for US-6328363-B1](https://nimo.iptorch.com/refdrawing/US-6328363-B1/006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/US-6328363-B1/007.png)

![Sketch 8 for US-6328363-B1](https://nimo.iptorch.com/refdrawing/US-6328363-B1/007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/US-6328363-B1/008.png)

![Sketch 9 for US-6328363-B1](https://nimo.iptorch.com/refdrawing/US-6328363-B1/008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/US-6328363-B1/009.png)

![Sketch 10 for US-6328363-B1](https://nimo.iptorch.com/refdrawing/US-6328363-B1/009.png)

[Sketch 11](https://patentimages.storage.googleapis.com/77/f4/85/1086c863ac73c0/US06328363-20011211-D00000.png)

![Sketch 11 for US-6328363-B1](https://patentimages.storage.googleapis.com/77/f4/85/1086c863ac73c0/US06328363-20011211-D00000.png)

[Sketch 12](https://patentimages.storage.googleapis.com/bb/96/a5/2833eb09f6f41b/US06328363-20011211-D00001.png)

![Sketch 12 for US-6328363-B1](https://patentimages.storage.googleapis.com/bb/96/a5/2833eb09f6f41b/US06328363-20011211-D00001.png)

[Sketch 13](https://patentimages.storage.googleapis.com/8c/b4/76/5c8d4ce27b624c/US06328363-20011211-D00002.png)

![Sketch 13 for US-6328363-B1](https://patentimages.storage.googleapis.com/8c/b4/76/5c8d4ce27b624c/US06328363-20011211-D00002.png)

[Sketch 14](https://patentimages.storage.googleapis.com/79/f6/7f/70214ff8c54d21/US06328363-20011211-D00003.png)

![Sketch 14 for US-6328363-B1](https://patentimages.storage.googleapis.com/79/f6/7f/70214ff8c54d21/US06328363-20011211-D00003.png)

[Sketch 15](https://patentimages.storage.googleapis.com/39/0d/27/18e8d9121fe735/US06328363-20011211-D00004.png)

![Sketch 15 for US-6328363-B1](https://patentimages.storage.googleapis.com/39/0d/27/18e8d9121fe735/US06328363-20011211-D00004.png)

[Sketch 16](https://patentimages.storage.googleapis.com/3a/c3/2e/94bc4c70fba753/US06328363-20011211-D00005.png)

![Sketch 16 for US-6328363-B1](https://patentimages.storage.googleapis.com/3a/c3/2e/94bc4c70fba753/US06328363-20011211-D00005.png)

[Sketch 17](https://patentimages.storage.googleapis.com/08/a5/f7/191aa3aa313274/US06328363-20011211-D00006.png)

![Sketch 17 for US-6328363-B1](https://patentimages.storage.googleapis.com/08/a5/f7/191aa3aa313274/US06328363-20011211-D00006.png)

[Sketch 18](https://patentimages.storage.googleapis.com/a1/e4/d3/32bd407d516fcd/US06328363-20011211-D00007.png)

![Sketch 18 for US-6328363-B1](https://patentimages.storage.googleapis.com/a1/e4/d3/32bd407d516fcd/US06328363-20011211-D00007.png)

[Sketch 19](https://patentimages.storage.googleapis.com/d1/80/a8/2492fc2468ca38/US06328363-20011211-D00008.png)

![Sketch 19 for US-6328363-B1](https://patentimages.storage.googleapis.com/d1/80/a8/2492fc2468ca38/US06328363-20011211-D00008.png)

[Sketch 20](https://patentimages.storage.googleapis.com/15/ca/91/50c496ffa3b908/US06328363-20011211-D00009.png)

![Sketch 20 for US-6328363-B1](https://patentimages.storage.googleapis.com/15/ca/91/50c496ffa3b908/US06328363-20011211-D00009.png)

## Claims

### Claim 1 (independent)

A device for handling light objects with one hand only without touching the objects with one&#39;s hand, said device comprising: at least one suction part configured for inspiration against a plane face of the object, said suction part comprising an annular suction ring delimited by two separate annular lips extending around a central area of the device for abutment with said object; a gripper having a shape that allows it to be seized and secured with one hand only; a flexible, elastomer body connected to the gripper, said elastomer body for at least partially filling and emptying a void to provide, via at least one connecting passage, a sub atmospheric pressure to an area between the suction ring and the plane face of the object upon abutment of said lips and inspiration of said device against the object; and a valve arranged for establishing a connecting passage from the central area under the device to the area between the suction ring and the plane face of the object for equalizing the sub atmospheric pressure to release the object, said valve being positioned underneath the elastomer body and being operable by pressure through the elastomer body.

### Claim 2

The device according to claim 1 , wherein the elastomer body is surrounded by the gripper which has a form of an annular flange with an outside that is configured for finger-abutment.

### Claim 3

The device according to claim 1 , wherein said lips each have a wide and flexibly resilient contact face with the plane face of the object.

### Claim 4

A device according to claim 1 , wherein the elastomer body is dome-shaped within the gripper and has an outwardly extending flange, said flange extending between the annular gripper and a bottom element, said valve being provided in the bottom element.

### Claim 5

The device according to claim 4 , said valve having a bearing surface that abuts an underside of said bottom element around a central opening in said bottom surface, a central portion that extends upward through said central opening, and abutment members that extend downward from said central portion toward a top face of said bottom element.

### Claim 6

A device according to claim 4 , wherein the suction ring is secured between an underside of the bottom element and an assembly element located between the two lips of the suction ring.

### Claim 7

A device according to claim 6 , wherein the assembly element has a number of upright pins arranged to extend through openings in the suction ring, in the bottom element, and in the outwardly extending flange of the elastomer body, said pins being connected to an underside of the gripper.

### Claim 8

The device according to claim 1 , wherein the object is a CD.

### Claim 9

The device according to claim 1 , wherein the sub atmospheric pressure is limited to said area between the suction ring and the plane face of the object, said central area under the device remaining at atmospheric pressure.

### Claim 10 (independent)

A device for handling light objects having a centrally located through-going opening without touching the objects with one&#39;s hand, said device comprising: at least one suction part configured for inspiration against a plane face of the object, said suction part comprising an annular suction area delimited by inner and outer sealing lips which form concentric rings extending around a central area of the device for abutment with said object; a dome-shaped elastomer body for at least partially filling and emptying a void located beneath the dome to provide, via at least one connecting passage, a sub atmospheric pressure to said annular suction area between said inner and outer sealing lips and the plane face of the object upon abutment of said lips and inspiration of said device against the object; and a valve for establishing a connecting passage from the central area under the device to said annular suction area for equalizing the sub atmospheric pressure to release the object, said valve being positioned underneath the elastomer body and being operable by pressure through the elastomer body.

### Claim 11

The device according to claim 10 , wherein the elastomer body is surrounded by a gripper having an annular flange with an outer surface that is configured for finger-abutment.

### Claim 12

The device according to claim 11 , further comprising a bottom element located beneath the void and an assembly element, said suction part secured between an underside of said bottom element and said assembly element, said assembly element fitted between said inner and outer lips.

### Claim 13

A device according to claim 12 , wherein the elastomer body has an outwardly extending flange extending between the annular gripper and the bottom element, said valve being provided in the bottom element.

### Claim 14

A device according to claim 13 , wherein the assembly element has a number of upright pins arranged to extend through openings in the suction part, in the bottom element, and in the outwardly extending flange of the elastomer body, said pins being connected to an underside of the gripper.

### Claim 15

The device according to claim 12 , said valve having a bearing surface that abuts an underside of said bottom element around a central opening in said bottom surface, a central portion that extends upward through said central opening, and abutment members that extend downward from said central portion toward a top face of said bottom element.

### Claim 16

The device according to claim 10 , wherein said lips each have a wide and flexibly resilient contact face with the plane face of the object.

### Claim 17

The device according to claim 10 , wherein the object is a CD.

### Claim 18

The device according to claim 10 , wherein the sub atmospheric pressure is limited to said annular suction area between the lips and the plane face of the object, said central area under the device remaining at atmospheric pressure.

## Full description

ASSIGNMENT OF ASSIGNORS INTEREST (SEE DOCUMENT FOR DETAILS).Assignors: LARSEN, TOMMYASSIGNMENT OF ASSIGNORS INTEREST (SEE DOCUMENT FOR DETAILS).Assignors: LARSEN, TOMMYRECORD TO CORRECT ASSIGNEE'S ADDRESS ON A DOCUMENT PREVIOUSLY RECORDED AT REEL 011432 FRAME 0779.Assignors: LARSEN, TOMMYPHYSICSINFORMATION STORAGEINFORMATION STORAGE BASED ON RELATIVE MOVEMENT BETWEEN RECORD CARRIER AND TRANSDUCERRecord carriers not specific to the method of recording or reproducing; Accessories, e.g. containers, specially adapted for co-operation with the recording or reproducing apparatus ; Intermediate mediums; Apparatus or processes specially adapted for their manufacturePERFORMING OPERATIONS; TRANSPORTINGHAND TOOLS; PORTABLE POWER-DRIVEN TOOLS; MANIPULATORSTOOLS OR BENCH DEVICES NOT OTHERWISE PROVIDED FOR, FOR FASTENING, CONNECTING, DISENGAGING, OR HOLDINGWork holders not covered by any preceding group in the subclass, e.g. magnetic work holders, vacuum work holdersVacuum work holdersVacuum work holders portable, e.g. handheld

Description

This application is a con't of PCT/DK00/00046 filed Feb. 4, 2000.

BACKGROUND OF THE INVENTION

1. Field of the Invention

The present invention relates to a device for handling light objects with one hand only without touching said objects with one's hand, said device comprising one or more suction parts configured for inspiration against a plane face of said object and a gripping means configured for being seized and held with one hand and where a movable piston body comprising a flexible, elastomer body is arranged at the gripper for complete or partial filling and emptying of a void for providing, via one or more connecting passages, a sub atmospheric pressure between the suction parts and the plane face of the object upon abutment and inspiration against the object.

2. Description of the Related Art

Devices of this type are used to seize and handle a variety of objects, such as CDs or CD-ROMs that may suffer damage when handled directly. When handled directly, deposition of dust, saline perspiration and other kinds of pollution may occur from the surface of fingers, which is harmful to many different types of surfaces. It is a particular problem especially in connection with the handling of CDs and CD-ROMs that their removal from ordinary cassettes for storing the discs is extremely difficult due to the gripping means that secure the CDs in their central holes being released only with difficulty which means that the CDs must be twisted or broken loose from the cassette which may have the practical consequence that it is necessary to touch and optionally scratch or soil the surface of the CDs which is both extremely delicate and intolerant of precisely such scratches or soil since this may entail a poor reproduction of the tracks of the CD.

Such devices are known in which the suction elements are resilient whereby a light pressure against a plane face enables them to be firmly inspired there against. It may present a problem when such suction cup is to be let go when the object is to be released and in reality it is not possible to regulate the inspiration pressure. If more separate suction cups are used, complex devices are required to ensure that they let go of the surface simultaneously. In another type of prior art suction cups, a central part of the suction cup can be withdrawn upon abutment against the surface to create the requisite sub atmospheric pressure. In these prior art devices it will be very difficultâand involve an extremely complex constructionâto configure the suction cups such that they have, to a very large extent, the shape of the objects to be seized by the relevant device.

Thus, FR patent application No 2750910 discloses a suction device for handling eg CDs, which suction device comprises a plurality of flexible suction cups that are connected via passages to a common ventilation opening. The ventilation opening is located such that the operator can close the opening by use of a finger. Hereby it is possible to press the suction device against the surface of a CD following which the operator closes the opening with his finger and thereby the elastic lips on the suction device will, due to its resilient abutment on the surface of the CD, form a sub atmospheric pressure that secures the CD to the suction device. However, it is a problem of such lifting devices that the CDs often have surfaces with pictures and the like printed thereon which may prevent the lips of the suction device from engaging completely sealingly with an ensuing risk that the CD is dropped after a relatively short time. It is a further problem that the prior art suction cups are to be pressed against the CD while applying a certain amount of force to inspire properly, and this is undesirable, it being most often the case that the CD is to be lifted from a drawer in a CD-player which is relatively fragile and does not readily tolerate a downward pressure.

Prior art document FR patent application No 2750910 further discloses a device which comprises one or more suction parts configured for inspiration against a plane face of the object, and a gripper configured for being seized and secured with one hand only, and where a movable piston body comprising a flexible, elastomer body which is arranged at the gripper for complete or partial filling and emptying of a void for providing, via one or more connecting passages, a sub atmospheric pressure between the suction parts and the plane face of the object upon abutment and inspiration against the object.

In order to release the object, the sub atmospheric pressure must be equalised, and according to the prior art, and this is done by applying further pressure to the piston body. This however is not always enough to equalise the pressure, as the suction parts may have become deformed during the inspiration process, and said deformation may cause a certain sub atmospheric pressure to prevail even when the elastomer body is fully depressed. In this case, the CD is stuck with the device.

SUMMARY OF THE INVENTION

In the light of this, it is the object of the invention to provide a device for handling light objects wherein the sub atmospheric pressure in the suction means can be established in a simple manner, without necessitating that the suction cup has to be pressed against the object to be lifted, and where the objects lifted may at any time be safely released by equalizing the sub atmospheric pressure with the pressure of the surrounding environment.

This is obtained by a device of the kind described above wherein a service means is provided for a valve for establishing a connecting passage between the environment and the area between the suction parts and the plane face of the object for equalising the sub atmospheric pressure for releasing the object, and where said valve is configured underneath the elastomer body, whereby the service means is configured for being operated under influence of pressure through the elastomer body. The piston body makes it possible in a simple manner, eg by means of a finger not used for abutment on the gripper portion, to provide a well-defined sub atmospheric pressure in the void, and via connecting passages to transmit this sub atmospheric pressure to the area between the suction elements and the plane face of the object. In reality, the piston body and the void constitute a pump that imparts the sub atmospheric pressure to the suction cups, and by use of a central pump separated from the suction cups, it is possible to regulate the pressure in a simple manner in a single or more separate suction cups.

When the valve is located underneath the dome-shaped elastomer body and is configured for operation by pressure through the elastomer body, it is accomplished that the valve is within reach of a finger, irrespective of where the device is seized, and furthermore the valve will be hidden which contributes to maintaining a pleasant appearance.

A simple and readily operable device is obtained if the piston body is surrounded by the gripper in the form of an annular flange, whose outside is configured for abutment with fingers. In that case, the flange can be secured to the outside between two fingers, e.g., the thumb and the middle finger, in which case the index finger is used to operate the piston body.

The suction cups themselves can conveniently have a course that extends around the central area. In that case, the suction cup can form an annular region or can be constituted by one or more kidney-shaped parts. Hereby a relatively large suction area is obtained compared to the total area of a CD or any other item covered by the device.

Particularly in connection with CD-discs it has been found to be convenient if the abutment parts of the suction cups comprise lips that each have a small linear contact with the plane face of the item upon inspiration. The surface pressure on the contact faces between lips and CD is thereby high, and this contributes to preventing air from being drawn in between lips and CD.

However, it is also possible to configure the suction cups of the device, whose abutment parts comprise lips that each have a wide and flexible contact face with the plane face of the object upon inspiration.

BRIEF DESCRIPTION OF THE DRAWINGS

The invention will now be described in further detail with reference to the accompanying drawings, in which

FIG. 1 is a sectional view through an embodiment of the device according to the invention;

FIG. 2 is an exploded view of the device shown in FIG. 1, seen in inclined perspective from below;

FIG. 3 is a reproduction corresponding to FIG. 2 featuring, however, an alternative embodiment seen in an inclined view from above;

FIG. 4 is a perspective reproduction of the device shown in sectional view in FIG. 1;

FIG. 5 is a reproduction corresponding to FIG. 4 of the embodiment shown in FIG. 3; and

FIG. 6 is an enlarged sectional view of an exemplary valve element in accordance with the invention;

FIG. 7 is a schematic view of an alternative embodiment of the suction area of a device in accordance with the invention;

FIG. 8 is a schematic view of a second alternative embodiment of the suction area on a device according to the invention;

FIGS. 9 and 10 display a further alternative embodiment of the invention.

DETAILED DESCRIPTION OF THE PREFERRED EMBODIMENTS

Further scope of applicability of the present invention will become apparent from the detailed description given hereinafter. However, it should be understood that the detailed description and specific examples, while indicating preferred embodiments of the invention, are given by way of illustration only, since various changes and modifications within the spirit and scope of the invention will become apparent to those skilled in the art from this detailed description.

Now FIG. 1 illustrates an exemplary device 20 in accordance with the present invention wherein there is a gripper having an annular flange portion 1 with an external, essentially conical engagement face 2. In the underside 4 of the flange portion, openings are configured that match the upright pins 6 of an annular assembly element 3. Between the flange element 1 and the assembly element 3, three separate elements are secured, viz the lip parts 7 defining the suction ring, and openings 11 and 12 in the bottom element 8 and an outwardly oriented flange element 13 accompanying the dome-shaped element 9, respectively. A suitable connection has been established between the pins 6 and the flange portion 1, e.g., by gluing, welding, or a snap fitting. The bottom element 8 has external and internal, annular, downwardly protruding flanges that engage around the lip portion 7 and the assembly element 3 located between the two lips.

As will appear from FIGS. 3 and 4, the top face of the bottom element 8 comprises grooves 14 that form connecting passages for holes 15 that extend through the assembly element 3, the lip portions 7 and the bottom element 8. Between the bottom element 8 and the dome-shaped element 9, a void 16 is delimited that will, via the passages 14 and the openings 15, be in communication with the area below the lip parts 7.

If the gripper is now positioned on eg a CD-disc in such a manner that the lips enclose the central opening of the disc; and if the dome-shaped elastic element is pressed downwards, the void 16 is emptied partially of air, and when the element 9 is released and attempts to assume its original shape, a sub atmospheric pressure will be established in the void 16. The sub atmospheric pressure is transmitted via the passages 14 and the openings 15 to the area underneath the lips 7, and thereby the gripper is sucked firmly towards the disc that can now be handled without contact with fingers, and the CD can eg be lifted out of a cassette and positioned in a CD-player.

In order to remove the existing sub atmospheric pressure in the void, a valve 17 is provided in a central opening 18 in the centre face of the bottom element 8. The valve 17 is made of a relatively flexible material and has a bearing surface 19 that abuts on the underside of the bottom element 8 around the opening 18. The valve 17 has a central portion 21 that extends upwards through the opening 18, and at the top of the central potion 21 there are abutment means 22 that extend downwards towards the top face of the bottom element and that will, by resilient abutment there against, ensure that an abutment pressure is maintained between the bearing face 19 of the valve and the underside of the bottom element 8.

When the valve element is exposed to pressure from above through the dome-element the abutment means 22 will yield resiliently, and the abutment pressure in the bearing face is increased and via the play between the central portion 21 and the opening 18 a sub atmospheric pressure, if any, in the void 16 can be neutralized, and an object sucked firmly against the underside of the lips 7 is released.

In FIGS. 1, 2 and 4, an embodiment is shown wherein the lips are configured with narrow linear abutment faces 23. Hereby it is ensured, even in the case of a weak sub atmospheric pressure, that the surface pressure between the abutment faces on the lips and on the CD becomes fairly high. This has been found to be advantageous in that it ensures attachment of a CD against the lips, even in case certain inevitable irregularities are present in its surface, e.g., due to the applied advertisement or information print on the top face of the CD. In FIGS. 1, 2, and 4, lips 7 with a V-shaped section are shown wherein the tip of the V forms the abutment line. The pointed ends of the lips 7 mean that to some extent the material is capable of following the irregularities in the surface formed by the printing matter by the pressure on the CD.

FIGS. 3 and 5 disclose an exemplary embodiment of the suction cups with usual wide abutment faces. They will be suitable if the object seized is not completely planar, the resilient lips still being capable of following the surface of the object.

The embodiments shown in FIGS. 1 through 5 are configured with two concentric lips 7 that abut on the surface of the CD. However, the present invention can also be configured in another way, as is outlined eg in FIGS. 7 and 8 that show the configuration of the abutment faces in two alternative embodiments of the invention.

Thus, FIG. 7 shows that the suction areas can be delimited by a plurality of annular, circular abutment faces 23 a. According to a not shown, alternative embodiment the circular abutment faces can be replaced by other annular, convex shapes, such as elliptic abutment faces.

Now FIG. 8 illustrates a further alternative embodiment, wherein a plurality of kidney-shaped suction areas delimited by the abutment faces 23 b are configured instead.

FIGS. 9 and 10 illustrate a further embodiment of the present invention in which the gripper has annular ring recess 26 for receiving protrusion 25 on the flange of elastomeric body 9. A central portion of bottom element 8 includes cutout portions 8.1, 8.2, 8.3, and valve 17 includes bearing surface 17.1. The remaining elements have been previously identified.

The invention being thus described, it will be apparent that the same may be varied in many ways. Such variations are not to be regarded as a departure from the spirit and scope of the invention, and all such modifications as would be recognized by one skilled in the art are intended to be included within the scope of the following claims.

## Classifications

- G11B23/00
- G11B23/00
- B25B11/007
- B25B11/007

## Cited patent documents

- [DE-1966112-A1](https://patents.google.com/patent/DE1966112A1/en) — SEA
- [DE-3213635-A1](https://patents.google.com/patent/DE3213635A1/en) — APP
- [DE-4304937-A1](https://patents.google.com/patent/DE4304937A1/en) — APP
- [FR-2375004-A1](https://patents.google.com/patent/FR2375004A1/en) — APP
- [FR-2511921-A1](https://patents.google.com/patent/FR2511921A1/en) — SEA
- [FR-2750910-A1](https://patents.google.com/patent/FR2750910A1/en) — APP
- [FR-890551-A](https://patents.google.com/patent/FR890551A/en) — APP
- [SU-1135710-A1](https://patents.google.com/patent/SU1135710A1/en) — SEA
- [SU-219144-A1](https://patents.google.com/patent/SU219144A1/en) — SEA
- [US-1251258-A](https://patents.google.com/patent/US1251258A/en) — SEA
- [US-2303393-A](https://patents.google.com/patent/US2303393A/en) — SEA
- [US-2783018-A](https://patents.google.com/patent/US2783018A/en) — SEA
- [US-2910264-A](https://patents.google.com/patent/US2910264A/en) — SEA
- [US-3230002-A](https://patents.google.com/patent/US3230002A/en) — SEA
- [US-3240525-A](https://patents.google.com/patent/US3240525A/en) — SEA
- [US-3627188-A](https://patents.google.com/patent/US3627188A/en) — APP
- [US-4214785-A](https://patents.google.com/patent/US4214785A/en) — APP
- [US-4583343-A](https://patents.google.com/patent/US4583343A/en) — SEA
- [US-4593947-A](https://patents.google.com/patent/US4593947A/en) — APP
- [US-5201913-A](https://patents.google.com/patent/US5201913A/en) — APP
- [US-5511752-A](https://patents.google.com/patent/US5511752A/en) — APP
- [US-762499-A](https://patents.google.com/patent/US762499A/en) — SEA
- [US-897060-A](https://patents.google.com/patent/US897060A/en) — SEA

---

Generated by IPtorch. Verify legal conclusions against the official publication.
