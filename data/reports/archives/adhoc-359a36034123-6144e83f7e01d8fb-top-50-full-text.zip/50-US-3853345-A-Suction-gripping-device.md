# 50. Suction gripping device

- **Archive rank:** 50 of 50
- **Publication:** [US-3853345-A](https://patents.google.com/patent/US3853345A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/023666332/publication/US3853345A?q=pn%3DUS3853345A)
- **Publication date:** 1974-12-10
- **Filing date:** 1973-11-30
- **Earliest priority:** 1973-11-30
- **Family:** 23666332
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** US NAVY
- **Inventors:** MILLER D

## Abstract

A suction device for gripping an object wherein the device includes a container. The container has a compartment which is capable of withstanding a vacuum relative to ambient pressure, and a plunger slidably and sealably extends through a wall of the container. Elastomeric means are mounted to the exterior of the container about the plunger for forming a chamber. The plunger extends beyond the container so as to be capable of engaging the object and sliding toward the vacuum compartment when the elastomeric means is pushed against the object. The plunger has passageway means for communicating the chamber with the vacuum compartment when the plunger is slid toward the vacuum compartment. With such a device a vacuum is established within the chamber when the elastomeric means is pushed against the object so that the object is gripped for retention, movement, or retrieval purposes.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-3853345-A/000.png)

![Sketch 1 for US-3853345-A](https://nimo.iptorch.com/refdrawing/US-3853345-A/000.png)

## Claims

### Claim 1 (independent)

sA suction device for gripping an object comprising: a container which has a compartment which is capable of withstanding a vacuum relative to ambient pressure; a plunger slidably and sealably extending through the wall of said container; elastomeric means mounted to the exterior of the container about said plunger for forming a chamber about the plunger; the elastomeric means having a periphery which lies in a plane and is capable of making sealing engagement with said object; said elastomeric means being resilient so that after the periphery of the elastomeric means makes engagement with the object the container can be pushed toward the object a distance during which the periphery of the elastomeric means maintains sealing engagement with the object; said plunger extending beyond the container so as to be capable of engaging the object and sliding toward the vacuum compartment when the elastomeric means is pushed against the object; and said plunger having a passageway for communicating the chamber with the vacuum compartment when the plunger is slid toward the compartment; said passageway communicating the chamber with the vacuum compartment only after the periphery of the elastomeric means makes sealing engagement with the object; whereby upon pushing the elastomeric means against the object a vacuum is established in the chamber and the object is gripped by said device.

### Claim 2

A gripping device as claimed in claim 1 including: said elastomeric means diverging from the container and forming with the exterior of the container a cup which extends about the plunger.

### Claim 3

A gripping device as claimed in claim 1 including: a fitting mounted through a wall of the container for pulling a vacuum within said compartment; and a valve interconnected in the fitting for opening and closing the compartment.

### Claim 4

A gripping device as claimed in claim 1 including: said plunger being a rod; and said rod slidably and sealably extending through opposite walls of the container.

### Claim 5

A gripping device as claimed in claim 1 including: said container being a hollow cylinder which has top and bottom ends.

### Claim 6

A gripping device as claimed in claim 5 including: said elastomeric means being mounted to the bottom of the cylinder and diverging therefrom so as to form in combination with the container a cup shaped chamber which extends about the plunger.

### Claim 7

A gripping device as claimed in claim 6 including: said plunger being a rod; and said rod slidably and sealably extending through the top and bottom ends of the cylinder.

### Claim 8

A gripping device as claimed in claim 7 including: a fitting mounted through the top end of the cylinder for pulling a vacuum within said compartment; and a valve interconnected in the fitting for opening and closing the compartment.

### Claim 9

A gripping device as claimed in claim 7 including: said passageway having top and bottom openings along said rod which opens simultaneously into the vacuum compartment and the chamber respectively so as to establish communication therebetween; the length of the rod below the bottom opening of the passageway being such that said communication is established only within the distance of movement of the container toward the object after the periphery of the elastomeric means makes sealing engagement with the object.

## Full description

**[p0001]**

r United States Patent 91 [111 3,853,345 Miller Dec. 10, 1974 SUCTION GRIPPING DEVICE Primary Examiner-Even C. Blunk Assistant Examiner-Johnny D. Cherry 75 I t. Do ldMll S D ,Clf. 1 men or 1 an lego Attorney, Agent, or Firm-R1chard S. Sciascia; Ervin [73] Assignee: The United States of America as F Johnston represented by the Secretary of the .Navy, Washington, DC. 57 ABSTRACT [22] Filed: Nov. 30, 1973 I 1 A suction device for gripping an object wherein the [21] Appl&#39; 420404 device includes a container. The container has a compartment which is capable of withstanding a vacuum [52] U.S.&#39;Cl 294/64 R relative to ambient ressur and a p g r slida ly [51] Int.- Cl. B66c 1/02 and sealably extends through a wall of the container. [58] Field of Search 294/64 R, 65, 66 R, 88; Elastomeric means are mounted to the exterior of the 114/51; 214/650 SG 248/562, 316}; 251/1124, container about the plunger for forming a chamber. 251/325; 269/21; 279/3 The plunger extends beyond the container so as to be capable of engaging the object and sliding toward the [56] References Cited vacuum compartment when the elastomeric means is UNITED STATES PATENTS pushed against the object. The plunger has passageway means for communicating the chamber with the gggz lg et 2 2? vacuum compartment when the plunger is slid toward 3&#39;481858 12/1969 Fromsont: X the vacuum compartment. With such a device a vac- 3:549:031 12/1970 Blood a a]. 294/65 X uum is established within the chamber when the elas- 3,587,506 6/1971 Thompson 114/51 tomeric means is pushed against the object so that the 3,602,543 8/197

**[p0001]**

1 Sjodin 294/64 R object is gripped for retention, movement, or retrieval 3,696,596 10/1972 Wegscheid... 294/64 R purposes 3,724,504 4/1973 Matsui 251/325 X r 9 Claims, 4 Drawing Figures we 2g SUCTION GRIPPING DEVICE STATEMENT OF GOVERNMENT INTEREST The invention described herein may be manufactured and used by or for the Government of the United States of America for governmental purposes without the payment of any royalties thereon or therefor.

**[p0002]**

BACKGROUND OF THE INVENTION The Navy is dealing more and more with the bottom of the ocean. In some instances, instrumentation is inserted into the ocean for retrieving and recording functional data of the oceans temperature, salienty, or optical characteristics. In some instances instrumentation is dropped for obtaining soil samples from the ocean bottom. Sometimes, Navy hardware is advertently dropped or damaged within the ocean which requires a salvageor retrieval operation to be performed. The Navy is also involved in underwater construction where structural members must be moved from one location to another. In all this work there is a need for gripping devices which will enable retention of the instrumentation, structural member, or misplaced hardware so that it can be moved by a lifting device. Divers or deep submersibles are often employed to attach a gripping device to an object on the ocean floor. Various known attachment devices are slings, clamps, and pad eyes. In dealing with heavy objects, a diver is required to weld a pad eye to the object before a liftcable can be attached for retrieval purposes. All of these gripping devices are extremely difficult to operate in an underwater environment. When the water is deep the ocean pressure and the coldness of the water presents a hostile environment to a diver who is attempting to rig the gripping device to a submerged object.

**[p0003]**

SUMMARY OF THE INVENTION There is a strong need for a gripping device which can be easily and quickly operated in the deep ocean for retrieving or moving an object therein. The present invention has provided a device which will grip an ob-&#39; ject with a suction force so as to cause a very tight retention of the object. The gripping device of the present invention includes a container which has a compartment which is capable of withstanding a vacuum relative to the ambient ocean pressure. A plunger is slidably and sealably mounted through a wall of the container, and elastomeric means are mounted to the exterior of the container about the plunger for forming a chamber. The plunger extends beyond the container so as to be capable of engaging the submerged object and sliding toward the vacuum compartment when the elastomeric means is pressed against the object. The plunger has a passageway means for communicating the chamber with the vacuum compartment when the plunger is slid toward the compartment. With such an arrangement, the device will vacuum grip the submerged object when the elastomeric means is pressed OBJECTS OF THE INVENTION An object of the present invention is to overcome the aforementioned problems associated with prior art gripping devices.

**[p0004]**

Another object is to provide a device for gripping an object wherein the device will perform its gripping function by simply a pressing action against the object. A further object is to provide a gripping device which can be easily and quickly utilized by a diver for attachment to a submerged object. These and other objects of the invention will become more readily apparent from the ensuing specification when taken with the drawings. DESCRIPTION OF THE DRAWINGS FIG. 1 is an ocean view illustrating a diver attaching the present device to a submerged object for retrieval purposes. FIG. 2 is an isometric view of the present gripping device. FIG. 3 is a longitudinal cross-sectional view of the gripping device prior to attachment to an object. FIG. 4 is a longitudinal cross-sectional view of the gripping device after attachment to the object. DESCRIPTION OF THE PREFERRED EMBODIMENT Referring now to the drawings, wherein like reference numerals designate like or similar parts throughout the several views, there is illustrated in FIG. 1 a gripping device 10 which has been attached by a diver (not shown) to a submerged object 12. In this mode of operation, a lifting line 14 may be connected to the gripping device 10 so that after the diver has attached the gripping device 10 to the oject 12, the object 12 can be lifted to a surface ship.

**[p0005]**

Referring now to FIG. 2, there is illustrated an exemplary gripping device 10. The gripping device includes a container 18 which has a compartment 20 which is capable of withstanding a vacuum relative to the ambient pressure surrounding the container. The container may be cylindrical with top and bottom ends 22 and 24 respectively. The annular wall of the container 18 may extend downwardly from the bottom end 24, so as to form an annular foot portion 26 which will be described in more detail hereinafter. A plunger, such as a rod 28, slidably and sealably extends through the container, 18. When the container is cylindrically shaped, as illustratd in FIG. 2, it is preferred that the rod 28 slidably and sealably extend through the bottom end 24 of the container. The seal between the rod 28 and the bottom end 24 of the container can be accomplished by an O-ring 30. In the preferred embodiment, the rod 28 also slidably and sealably extends through the top end 22 of the container for lateral stability. Another O-ring 30 should be utilized for accomplishing this seal in the same fashion as for the bottom end 24.

**[p0006]**

Elastomeric means, such as an annular neoprene boot 32, is mounted to the exterior of the container 18 about the plunger 28 for forming a chamber 34. The boot 32 is preferably mounted to the bottom of the container 18, and diverges therefrom so as to form in combination with the container a generally cup shaped chamber 34. In order to retain the boot 32 to the bottom of the container 18 the boot 32 may have an annular lip 36 which is bonded or molded to a ring 38. The ring 38, in turn, may be threaded within the annular foot 26 of the container. In this manner, the boot 32 may be easily removed and replaced as desired. The boot 32 should be sufficiently flexible, and preferably also resilient, so that upon engaging an underwater object the boot will flex slightly upwardly, as illustrated in FIG. 4, to make a good seal with the object. As illustrated in FIG. 3, the rod 28 is capable of extending beyond the container 18 so as to engage the submerged object 12 and so as to slide toward the vacuum compartment 20 when the flexible boot 32 is pressed against the object. In order to transfer the vacuum from the compartment 20 to the chamber 34, the rod 28 is provided with a passageway means, such as a slanted aperture 40, which communicates the chamber 34 with vacuum compartment 20 when the rod 28 is slid toward the compartment 20. As illustrated in FIG. 4, the slanted aperture 40 must bridge the wall thickness of the bottom end 24 of the container so as to make this desired communication. In this position the bottom end 42 of the rod 28 has moved up simultaneously with flexing of

**[p0006]**

the boot 32 so that the perimeter of the boot 32 makes a good seal with the submerged object. It is important that the slanted aperture 40 not make communication between the chamber 34 and the compartment 20 until the perimeter of the boot 32 has engaged the object 12. If desired, the rod 28 can be provided with a longitudinal groove in lieu of the slanted aperture 40 for making the desired communication.

**[p0007]**

In order to draw a vacuum in the compartment 20 the top end 22 of the container may be provided with a threaded fitting 44. The fitting 44, in turn, may be provided with a valve 46 for shutting off the compartment 20 after a vacuum has been established by an external vacuum device (not shown). It should be noted, however, that it would not be necessary to pull a vacuum on the compartment 20 if a submerged object is just moved from one location to another underwater and is not brought to the surface since a lowering of the container 18 in the water will cause the compartment 20 to be at a lower pressure than the ambient water pressure. When the lifting device is utilized in this mode a plug could be utilized in lieu of the fitting 44 for closing off the compartment 20. If the gripping device 10 is to be lifted by the lift line 14 from a surface vessel, it may be provided with lifting eyes 48 which are threaded into the top end 22 of the container 18. Saddle cables 50 may be connected to these eyes 48, which, in turn, may be connected to the lifting cable 14 by a ring 52.

**[p0008]**

OPERATION OF THE INVENTION In the operation of the invention a vacuum may be pulled within the copartment at the surface when it is desired to retrieve a submerged object to the surface of the water. Alternatively, ambient surface pressure within the compartment 20 can be used when it is desired only to move a submerged object from one location to another under the surface of the water. As illustrated in FIG. 1, the gripping device 10 may be lowered to the proximity of the submerged object 12 and a diver may press the boot portion 32 of the device against the object 12. This causes the boot to flex slightly upwardly and the rod 28 to be moved from the position illustrated in FIG. 3 to the position illustrated in FIG. 4. When the rod is in the position of FIG. 4, the slanted aperture 40 communicates the chamber 34 with the low pressure compartment 20. The chamber 34 is then brought to a low pressure relative to the ocean ambient pressure with the perimeter of the boot 32 making a seal with the submerged object 12. This causes the device 10 to make a tight suction grip of the object 12 so that is can be lifted by the lift line 14.

**[p0009]**

Obviously, many modifications and variations of the present invention are possible in the light of the above teachings, and, it is therefore understood that within the scope of the disclosed invention concept, the invention may be practiced otherwise than specifically described. What is claimed is: 1. A suction device for gripping an object comprisa container which has a compartment which is capable of withstanding a vacuum relative to ambient pressure; a plunger slidably and sealably extending through the wall of said container; elastomeric means mounted to the exterior of the container about said plunger for forming a chamber about the plunger; the elastomeric means having a periphery which lies in a plane and is capable of making sealing engagement with said object; 7 said elastomeric means being resilient so that after the periphery of the elastomeric means makes engagement with the object the container can be pushed toward the object a distance during which the periphery of the elastomeric means maintains sealing engagement with the object;

**[p0010]**

said plunger extending beyond the container so as to be capable of engaging the object and sliding toward the vacuum compartment when the elastomeric means is pushed against the object; and said plunger having a passageway for communicating the chamber with the vacuum compartment when the plunger is slid toward the compartment; said passageway communicating the chamber with the vacuum compartment only after the periphery of the elastomeric means makes sealing engagement with the object; whereby upon pushing the elastomeric means against the object a vacuum is established in the chamber and the object is gripped by said device. 2. A gripping device as claimed in claim 1 including: said elastomeric means diverging from the container and forming with the exterior of the container a cup which extends about the plunger. 3. A gripping device as claimed in claim 1 including: a fitting mounted through a wall of the container for pulling a vacuum within said compartment; and a valve interconnected in the fitting for opening and closing the compartment.

**[p0011]**

4. A gripping device as claimed in claim 1 including: said plunger being a rod; and said rod slidably and sealably extending through opposite walls of the container. 5. A gripping device as claimed in claim 1 including: said container being a hollow cylinder which has top and bottom ends. 6. A gripping device as claimed in claim 5 including: said elastomeric means being mounted to the bottom of the cylinder and diverging therefrom so as to form in combination with the container a cup shaped chamber which extends about the plunger. 7. A gripping device as claimed in claim 6 including: said plunger being a rod; and said rod slidably and sealably extending through the top and bottom ends of the cylinder. 8. A gripping device as claimed in claim 7 including: a fitting mounted through the top end of the cylinder for pulling a vacuum within said compartment; and a valve interconnected in the fitting for opening and closing the compartment. 9. A gripping device as claimed in claim 7 including:

## Figure captions

- **Figure 1:** DESCRIPTION OF THE DRAWINGS FIG. 1 is an ocean view illustrating a diver attaching the present device to a submerged object for retrieval purposes.
- **Figure 2:** FIG. 2 is an isometric view of the present gripping device.
- **Figure 3:** FIG. 3 is a longitudinal cross-sectional view of the gripping device prior to attachment to an object.
- **Figure 4:** FIG. 4 is a longitudinal cross-sectional view of the gripping device after attachment to the object.

## Classifications

- B63C7/22
- B63C7/22
- B63C7/22
- B66C1/02
- B66C1/0212
- B66C1/0212
- B66C1/0231
- B66C1/0231
- B66C1/0293
- B66C1/0293

## Cited patent documents

- [US-2078402-A](https://patents.google.com/patent/US2078402A/en) — SEA
- [US-3167326-A](https://patents.google.com/patent/US3167326A/en) — SEA
- [US-3481858-A](https://patents.google.com/patent/US3481858A/en) — SEA
- [US-3549031-A](https://patents.google.com/patent/US3549031A/en) — SEA
- [US-3587506-A](https://patents.google.com/patent/US3587506A/en) — SEA
- [US-3602543-A](https://patents.google.com/patent/US3602543A/en) — SEA
- [US-3696596-A](https://patents.google.com/patent/US3696596A/en) — SEA
- [US-3724504-A](https://patents.google.com/patent/US3724504A/en) — SEA

---

Generated by IPtorch. Verify legal conclusions against the official publication.
