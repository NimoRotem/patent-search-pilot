# 17. Device forming a workpiece clamp

- **Archive rank:** 17 of 50
- **Publication:** [US-10245710-B2](https://patents.google.com/patent/US10245710B2/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/044511764/publication/US10245710B2?q=pn%3DUS10245710B2)
- **Publication date:** 2019-04-02
- **Filing date:** 2011-12-20
- **Earliest priority:** 2010-12-20
- **Family:** 44511764
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus

## Parties

- **Applicant / assignee:** THIBAUT; THIBAUT CHRISTOPHE; THIBAUT JACQUES
- **Inventors:** THIBAUT CHRISTOPHE; THIBAUT JACQUES

## Abstract

A device forming a clamping pad includes a body ( 1 ) presenting a first face ( 1   a ) to be secured by suction to a worktable (T) and a second face ( 1   b ) to be secured by suction to a workpiece (P). The body ( 1 ) contains elements for generating suction, which elements are linked to the first face ( 1   a ) to be secured to the worktable (T) and to the second face ( 1   b ) to be secured to a workpiece (P). The device is applicable to double-sided clamping of workpieces (P) with a view to treating them or to working on them.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/c8/7d/70/74817dd0e24539/US10245710-20190402-D00000.png)

![Sketch 1 for US-10245710-B2](https://patentimages.storage.googleapis.com/c8/7d/70/74817dd0e24539/US10245710-20190402-D00000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/32/e6/a6/570d14ba26fbf8/US10245710-20190402-D00001.png)

![Sketch 2 for US-10245710-B2](https://patentimages.storage.googleapis.com/32/e6/a6/570d14ba26fbf8/US10245710-20190402-D00001.png)

[Sketch 3](https://patentimages.storage.googleapis.com/74/23/68/33bd8b88827e05/US10245710-20190402-D00002.png)

![Sketch 3 for US-10245710-B2](https://patentimages.storage.googleapis.com/74/23/68/33bd8b88827e05/US10245710-20190402-D00002.png)

[Sketch 4](https://patentimages.storage.googleapis.com/84/04/14/b120ae9b833027/US10245710-20190402-D00003.png)

![Sketch 4 for US-10245710-B2](https://patentimages.storage.googleapis.com/84/04/14/b120ae9b833027/US10245710-20190402-D00003.png)

## Claims

### Claim 1 (independent)

A device forming a clamping pad comprising; a body presenting a first face to be secured by suction to a worktable; and a second face to be secured by suction to a workpiece, wherein the body contains means for generating suction, which suction generator means are linked, through at least a duct, to said first face to be secured to the worktable and to said second face to be secured to a workpiece and are able to generate suction on the first and second faces, wherein the suction generator means comprise a vacuum pump and an energy source for powering said vacuum pump, the vacuum pump and the energy source being located within the body, wherein the body contains a vacuum buffer tank, connected to said suction generator means and suitable, when evacuated by the suction generator means through said duct, for applying suction to said first and second faces, wherein the device comprises means for lifting the workpiece, in order to facilitate moving the workpiece in translation and positioning the workpiece.

### Claim 2

A device according to claim 1 , wherein the energy source for powering said vacuum pump comprises at least one battery.

### Claim 3

A device according to claim 2 , wherein the suction generator means present means forming an on/off switch for the power supply.

### Claim 4

A device according to claim 2 , wherein the suction generating means present at least one normally open valve for applying suction to the second face to be secured to the workpiece, in such a manner as to save the energy of maintaining the valve in a predetermined position.

### Claim 5

A device according to claim 2 , wherein the body contains a vacuum buffer tank, suitable for applying suction by means of the suction generator means.

### Claim 6

A device according to claim 2 , wherein said means for lifting the workpiece is controlled by at least one normally open valve for applying suction, in such a manner as to save the energy of maintaining the valve in a predetermined position.

### Claim 7

A device according to claim 1 , wherein the suction generator means present means forming an on/off switch for the power supply.

### Claim 8

A device according to claim 1 , wherein the suction generator means present at least one normally open valve for applying suction to the second face to be secured to the workpiece, in such a manner as to save the energy of maintaining the valve in a predetermined position.

### Claim 9

A device according to claim 8 , wherein the normally open valve for applying suction to said second face to be secured by suction to the workpiece, is connected in parallel on the line for applying suction to the first face to be secured to the worktable.

### Claim 10

A device according to claim 1 , said means for lifting the workpiece comprise a jack.

### Claim 11

A device according to claim 1 , wherein said means for lifting the workpiece is controlled by at least one normally open valve for applying suction, in such a manner as to save the energy of maintaining the valve in a predetermined position.

### Claim 12

A device according to claim 1 , wherein the energy source for powering said vacuum pump comprises at least one rechargeable battery.

### Claim 13

A device according to claim 1 , wherein said means for lifting the workpiece comprise a jack having a load-carrier ball.

### Claim 14 (independent)

A device forming a clamping pad, comprising a body presenting a first face to be secured by suction to a worktable and a second face to be secured by suction to a workpiece, wherein the body contains means for generating suction, which suction generator means are linked to said first face to be secured to the worktable and to said second face to be secured to a workpiece, means for lifting the workpiece, in order to facilitate moving the workpiece in translation and positioning the workpiece, wherein said means for lifting the workpiece comprise a jack having a load-carrier ball.

### Claim 15 (independent)

A device forming a clamping pad, comprising a body presenting a first face to be secured by suction to a worktable and a second face to be secured by suction to a workpiece, wherein the body contains means for generating suction, which suction generator means are linked to said first face to be secured to the worktable and to said second face to be secured to a workpiece, means for lifting the workpiece, in order to facilitate moving the workpiece in translation and positioning the workpiece, and said means for lifting the workpiece is controlled by at least one normally open valve for applying suction, in such a manner as to save the energy of maintaining the valve in a predetermined position.

## Full description

### Background Of The Invention

**[p0001]**

Field of the Invention The invention relates to a device forming a clamping pad, of the type comprising a first face to be secured by suction to a worktable and a second face to be secured by suction to a workpiece. Description of the Related Art Documents EP 1 342 533 A1 and WO 2007/028 886 A1 describe automatic machines for working materials in sheet or plate form, in which the materials to be worked are positioned and held by double-sided clamping pads. Double-sided clamping pads comprise a top suction cup and a bottom suction cup. The top and bottom suction cups are connected to air and vacuum pipes. The suction that makes it possible to fasten the clamping pad to the worktable and the workpiece to be fastened to the clamping pad is obtained by pumping through side suction pipes, and the presence of those pipes on the worktable leads to a risk of a suction pipe catching the machining tool and may lead to a risk of accident for the operator of the machine-tool. Attempts are made to avoid those risks by pressing the suction pipes onto the machining surface by parts or wedges pressing thereon. However, the pipes pressed on the machining surface retain dust, sludge, and swarf, entrained by the machining lubrification fluid, and that harms the quality of work.

**[p0002]**

Finally, it has been envisaged to arrange a plurality of orifices opening out into the worktable and to use the orifices in register with the suction cups to convey the suction through said orifices. Although that arrangement gives satisfaction, it does not make it possible to place the positioning pads in any desired position. In addition, the orifices used are liable to become soiled and thus to impede correct operation of the positioning pad.

### Brief Summary Of The Invention

**[p0003]**

A first object of the invention is to overcome the drawbacks of the state of the art, by removing the suction and vacuum pipes of the prior art. A second object of the invention is to enable double-sided suction cups to be placed in any desired location on the worktable. A third object of the invention is to avoid risks of accidents for the operator of the machine-tool, and to improve the quality of the work during use of the clamping pads. A fourth object of the invention is to facilitate positioning of the workpiece on the clamping pad, by improving the ease and quality of movement in translation of the workpiece on the clamping pads fastened to the worktable. The invention provides a device forming a clamping pad, of the type comprising a body presenting a first face to be secured by suction to a worktable and a second face to be secured by suction to a workpiece, the pad being characterized by the fact that the body contains means for generating suction, which means are linked to said first face to be secured by suction to the worktable and to said second face to be secured by suction to a workpiece.

**[p0004]**

According to other alternative characteristics of the invention: The suction generator means comprise a vacuum pump and an energy source for powering said vacuum pump. The energy source for powering said vacuum pump comprises at least one battery. The suction generator means present means forming an on/off switch for the power supply. The suction forming means may present at least one normally open valve for applying suction to said second face to be secured to the workpiece, in such a manner as to save the energy of maintaining the valve in a predetermined position. The normally open valve for applying suction to said second face to be secured to the workpiece, is connected in parallel on the line for applying suction to the first face to be secured to the worktable. The body may contain a vacuum buffer tank, suitable for being evacuated by the suction generator means. The device may include means for lifting the workpiece, in order to facilitate moving it in translation and positioning it. Said means for lifting the workpiece comprise a jack, preferably a ball screw jack. Said means for lifting the workpiece may be controlled by at least one normally open valve for applying suction, in such a manner as to save the energy of maintaining the valve in a predetermined position.

### Brief Description Of The Drawings

**[p0005]**

The invention can be better understood by means of the description given below, given by way of non-limiting example and with reference to the accompanying drawings, in which: FIG. 1 is a diagram showing a diametral section view of a clamping device of the invention. FIG. 2 is an exploded diagrammatic view of the clamping device of the invention shown in FIG. 1 . FIG. 3 is a diagram showing a diametral section view of a second implementation of the clamping device of the invention. FIG. 4 is an exploded diagrammatic view of the clamping device of the invention shown in FIG. 3 .

### Detailed Description Of The Preferred Embodiments

**[p0006]**

With reference to FIGS. 1 to 4 , elements that are identical or functionally equivalent are identified by identical reference numbers. In FIGS. 1 and 2 , a clamping device of the invention comprises a body ( 1 ) of substantially cylindrical shape presenting a first suction face ( 1 a ) to be secured by suction to a worktable (T) shown in dotted lines and presenting a second suction face ( 1 b ) to be secured by suction to a workpiece (P). The body ( 1 ) contains means for generating suction, which means are linked to said first face ( 1 a ) to be secured to the worktable (T) and to said second face ( 1 b ) to be secured to a workpiece (P), via respective appropriate ducts ( 2 a, 2 b ). The suction generator means essentially comprise a vacuum pump ( 3 ) associated with an energy source ( 4 ) for powering said vacuum pump ( 3 ). The suction vacuum pump ( 3 ) is suitable for generating suction on the bottom first face to be secured by suction to the worktable (T), as well as onto the second face to be secured by suction to the workpiece (P).

**[p0007]**

The vacuum pump ( 3 ) is, firstly, advantageously associated with a first filter ( 5 a ) disposed on the duct ( 2 a ) associated with the bottom first suction face ( 1 a ). The vacuum pump ( 3 ) is, secondly, advantageously associated with a second filter ( 5 b ) disposed on the duct ( 2 b ) associated with the second suction face ( 1 b ) to be secured to a workpiece (P). A first vacuum gauge ( 6 a ) is advantageously provided in order to provide a signal representative of the suction generated on the first suction face ( 1 a ), and a second vacuum gauge ( 6 b ) is advantageously provided to provide a signal representative of the suction generated on the second suction face ( 1 b ). A vacuum gauge ( 6 a ) or ( 6 b ) is a suction detector for detecting the suction generated on the bottom first face to be secured by suction to the worktable (T), or on the second face to be secured by suction to the workpiece (P), and to deliver an electrical or mechanical signal indicating the presence of a vacuum representative of a holding strength value on the bottom first face to be secured by suction to the worktable (T), or on the second face to be secured by suction to the workpiece (P).

**[p0008]**

A control valve ( 7 ) is associated with the second face ( 1 b ) to be secured by suction to the workpiece (P) in order to apply suction to said second suction face ( 1 b ) to apply suction, or in order to enable said second suction face ( 1 b ) to be set to atmospheric pressure. The control valve ( 7 ) advantageously consists of a solenoid valve that is normally open for applying suction to the second face ( 1 b ) to be secured to the workpiece (P), in such a manner as to save the energy of maintaining the solenoid valve ( 7 ) in said predetermined suction position. The coil or “solenoid” of the solenoid valve ( 7 ) is also preferably powered by the same energy source ( 4 ). A vacuum buffer tank ( 8 ) connected to the vacuum pump ( 3 ) may be provided in order to ensure regularity of the vacuum pump ( 3 ) and to avoid repeated stopping and starting of the vacuum pump at short intervals. This vacuum buffer tank ( 8 ) also makes it possible to save energy obtained from the power supply ( 4 ).

**[p0009]**

In the embodiment shown, the energy source ( 4 ) comprises at least one electric battery that is preferably rechargeable via a socket ( 4 a ). The invention also covers any other method of powering the vacuum pump ( 3 ), in particular methods of powering remotely, e.g. by electromagnetic, microwave, or any other transmission means. The vacuum pump ( 3 ) is advantageously an electric vacuum pump when power is supplied by electric batteries. In this configuration, the vacuum pump ( 3 ) is preferably in the form of a unit comprising an electric motor and a suction block actuated by said electric motor. The electric batteries ( 4 ) are preferably rechargeable storage batteries of the electrochemical type associating a nickel hydroxide with a metal hydride and presenting an energy density in the charged state that lies in the range 30 watt-hours per kilogram Wh/kg to 100 Wh/kg. The vacuum pump ( 3 ) is preferably an eccentric diaphragm vacuum pump presenting a nominal suction flow-rate lying in the range 1 liters per minute (L/min) to 5 L/min, and suitable for reaching suction of the order of 500 millibars relative to atmospheric pressure.

**[p0010]**

The suction generator means may be turned on manually by means for forming an on/off switch for the power supply, or may alternatively be controlled by an electronic circuit, possibly comprising a microcontroller, in such a manner as to use the power supply solely to compensate suction leaks likely to impede correct clamping of the workpiece (P) relative to the worktable (T). When the suction generator means are controlled by an electronic control circuit, the suction signals from the vacuum gauges ( 6 a, 6 b ) are used as input signals for a feedback loop or for an operating program stored in the microcontroller of the control circuit. A method of using the clamping device of FIG. 1 begins with a step of positioning the clamping pad on a worktable (T). The clamping pads on the table (T) may be positioned manually, or else automatically by a work machine fitted with a spindle that is adapted for that purpose. After the clamping pads have been positioned, the vacuum pump ( 3 ) and the electromagnetic solenoid valve ( 7 ) are activated simultaneously, in such a manner as to isolate the top suction face ( 1 b ) by ensuring it is in communication with atmospheric pressure and in such a manner as to generate suction on the bottom face ( 1 a ) that is to be secured to the worktable (T).

**[p0011]**

After the first face ( 1 a ) has been clamped by suction to the worktable (T) and after a vacuum has been created in the buffer tank ( 8 ), the workpiece (P) is placed on the top suction face ( 1 b ) and the solenoid valve ( 7 ) is de-activated, in order to bring it back to the normally open suction position of FIG. 1 . Operation of the vacuum pump ( 3 ) thus ensures that the workpiece (P) is secured by suction to the top suction face ( 1 b ) of the clamping pad of the invention. When the vacuum gauges ( 6 a, 6 b ) indicate that the level of suction is satisfactory, the vacuum pump ( 3 ) containing a check valve that is not shown in detail may be stopped, and suction may be maintained by means of the vacuum buffer tank ( 8 ). For a variant embodiment not containing a vacuum gauge ( 6 a, 6 b ), operation of the vacuum pump ( 3 ) may be interrupted at the end of a predetermined amount of time corresponding to a sufficient level of suction at the bottom ( 1 a ) and top ( 1 b ) suction faces.

**[p0012]**

After the workpiece (P) has been clamped to the worktable (T), the work operation proper is then performed: machining, shaping, or other surface treatment operations on the workpiece (P). After performing the work operations on the workpiece (P), the worked piece (P) may be removed from the worktable (T). To this end, the solenoid valve ( 7 ) is activated in order to cause the solenoid valve to communicate with atmospheric pressure. Air entering via the atmospheric pressure duct ( 9 ) makes it possible to eliminate the clamping suction on the suction face ( 1 b ), and that releases the workpiece (P). During release of the worked piece (P), suction is maintained beside the first suction face ( 1 a ) due to the fact that the duct ( 2 a ) is blocked by the solenoid valve ( 7 ), when the solenoid valve ( 7 ) is urged into its activation position. The worked piece (P) can thus be removed while the clamping pad of the invention remains secured by suction to the worktable (T) via its bottom face ( 1 a ).

**[p0013]**

After the worked piece (P) has been removed, the solenoid valve ( 7 ) is deactivated in order for it to move back into the normally open position of FIG. 1 . In this normally open position of FIG. 1 , air enters via the top face ( 1 b ) through the duct ( 2 b ) and feeds the suction circuit in order to bring it to atmospheric pressure and in order to eliminate the suction on the bottom first suction face ( 1 a ). Bringing the first suction face ( 1 a ) to atmospheric pressure releases the clamping pad and makes it possible to move it on or away from the worktable (T). The clamping pad of the invention may be moved manually or in automatic manner by a machine adapted to this purpose, and the power supply may optionally be recharged in a recharging position, by plugging into the power socket ( 4 a ). The device forming the clamping pad of the invention may be re-used at will in the same succession of steps as described above. In FIG. 2 , a clamping pad of the invention includes a bottom cover ( 10 ) assembled to the body ( 1 ) of the clamping pad. The body ( 1 ) of the clamping pad of the invention presents a hollow cylindrical shape containing in its top portion a set of several storage batteries ( 4 ) that are suitable for being recharged via a socket ( 4 a ).

**[p0014]**

The set of storage batteries ( 4 ) is mounted on a plate ( 11 ) supporting a vacuum buffer tank ( 8 ). The plate ( 11 ) is spaced apart from another plate ( 12 ) carrying an electronic circuit (not shown in detail) and supporting a solenoid valve ( 7 ) as described with reference to FIG. 1 . Under its bottom portion, the plate ( 12 ) receives a drilled block ( 12 a ) to which the vacuum pump is fastened ( 3 ), in such a manner that the vacuum pump ( 3 ) is suspended inside the body ( 1 ) at a predetermined distance making it possible to avoid any water entering while the suction-cup forming bottom face ( 1 a ) has suction applied thereto to secure it to the worktable (T). The assembly suspended in the top portion of the body ( 1 ) may thus be installed or removed after removal of the bottom cover ( 10 ). The suction-cup forming bottom face ( 1 a ) to be secured to the worktable (T) is attached to the bottom cover ( 10 ). The vacuum pump ( 3 ) is, firstly, advantageously associated with a first filter ( 5 a ) associated with the suction-cup forming bottom first face ( 1 a ).

**[p0015]**

The vacuum pump ( 3 ) is, secondly, advantageously associated with a second filter ( 5 b ) associated with the suction-cup forming second face ( 1 b ) that is to be secured to a workpiece (P). A first vacuum gauge ( 6 a ) is advantageously provided in order to deliver a signal representative of the suction generated at the suction-cup forming first face ( 1 a ), and a second vacuum gauge ( 6 b ) is advantageously provided in order to deliver a signal representative of the suction generated at the suction-cup forming second face ( 1 b ). A vacuum gauge ( 6 a ) or ( 6 b ) is advantageously mounted on a column ( 6 ) presenting two open bore holes. The control valve ( 7 ) is connected via ducts (not shown) to the suction-cup forming second face (l b ) that is to be secured by suction to the workpiece (P) in order to enable said suction-cup forming second face ( 1 b ) to be secured by suction, or in order to enable said suction-cup forming second face ( 1 b ) to be set to atmospheric pressure.

**[p0016]**

The control valve ( 7 ) advantageously consists of a solenoid valve that is normally open for applying suction to the second face ( 1 b ) to be secured to the workpiece (P), in such a manner as to save the energy of maintaining the solenoid valve ( 7 ) in said predetermined suction position. A vacuum buffer tank ( 8 ) connected to the vacuum pump ( 3 ) ensures regularity of the vacuum pump ( 3 ) and avoids repeated stopping and starting of the vacuum pump at short intervals. This modular arrangement makes it possible to manufacture clamping-pad forming devices of the invention that are as compact as prior-art double-sided clamping pads as fed by prior-art vacuum hoses. A fluid curtain is disposed at the periphery of the suction-cup forming top second face ( 1 b ), in order to constitute a coaxial capillary gasket and to avoid “drying” and detachment of the suction-cup forming top second face ( 1 b ), by further preventing undesirable dust, sludge, swarf, or other particles from penetrating therein.

**[p0017]**

The fluid curtain, in particular a liquid curtain, thus reinforces sealing by capillarity at the top suction face ( 1 b ) and contributes to saving the energy required for establishing suction and for maintaining clamping by suction. Machining lubrification water is advantageously used to form a fluid curtain or barrier, by pumping using a liquid pump 33 sucking up the machining lubrification water through an outer filter 34 surrounding the body 1 . An electronic control circuit connected by communication means, preferably wireless communication means, to the machine-tool makes it possible to manage a stock of double-sided clamping pads of the invention. In FIG. 3 , a second embodiment of the clamping pad of the invention comprises elements that are identical or functionally equivalent to the elements described in reference to FIG. 1 . This second embodiment of the device of the invention further comprises means for lifting the workpiece (P) in order to facilitate moving it in translation and positioning it.

**[p0018]**

In the example shown, the lifting means for lifting the workpiece (P) comprise a jack ( 13 ) having a load-carrier ball ( 14 ). The jack ( 13 ) with a load-carrier ball ( 14 ) is preferably a pneumatic jack, powered by a pump ( 15 ) providing compressed air pressure in order to ensure movement of a piston ( 16 ) in a jacket ( 17 ). A control valve ( 18 ) is mounted to communicate with the jack ( 13 ), in order to enable it to be fed with compressed air and to enable the jack ( 13 ) to extend, or to enable communication with the vacuum pump ( 3 ) and enable the jack ( 13 ) to be withdrawn by suction. The control valve ( 18 ) is preferably a normally open solenoid valve ( 18 ), having an inactivated position that is a position of connection with the line for applying suction via the vacuum pump ( 3 ). A filter ( 19 ) is preferably provided between the pump ( 15 ) and the communication with atmospheric pressure outside the body ( 1 ). The pump ( 15 ) is preferably an electric pump powered by the energy source ( 4 ) of the vacuum pump ( 3 ).

**[p0019]**

The invention also covers any other method of powering the pump ( 15 ), in particular methods of powering remotely, e.g. by electromagnetic, microwave, or any other transmission means. The electric pump ( 15 ), in this example connected to an energy source using electric batteries, is preferably in the form of a unit comprising an electric motor and a suction compression block actuated by said electric motor. The electric pump ( 15 ) is preferably an eccentric diaphragm pump presenting a nominal suction flow-rate lying in the range 1 L/min to 5 L/min and suitable for reaching pressure of the order of 1 bar relative to atmospheric pressure. The coils or solenoids of the solenoid valves ( 7 ) and ( 18 ) are also preferably powered by the same energy source ( 4 ). Operation of the second embodiment of the clamping device of the invention is substantially identical to the operation described in reference to FIG. 1 , allowing for the addition of additional steps during positioning of the workpiece (P) on the top suction face ( 1 b ).

**[p0020]**

After the step of clamping the bottom suction face ( 1 a ) to the worktable (T) by suction, the pump ( 15 ) is activated to move the piston ( 16 ) of the jack ( 13 ) upwards and to cause the load-carrier ball ( 14 ) to exit above the level of the top suction face ( 1 a ). To do this, the solenoid valve is activated ( 18 ) so as to cause the jacket ( 17 ) to communicate with the pump ( 15 ) creating pneumatic pressure. The workpiece (P) is then moved in translation on the load-carrier ball ( 14 ) so as to be positioned in the reference position for the work to be carried out. When the workpiece is placed in abutment or in a reference position, the pump ( 15 ) creating the pneumatic pressure is stopped and the solenoid valve ( 18 ) is deactivated, in such a manner as to be placed in the normally open position shown in FIG. 3 , in order to suck the piston ( 16 ) and to move it downwards inside the jacket ( 17 ), thus retracting the load-carrier ball ( 14 ) to below the level of the second face ( 1 b ) that is to be secured to the workpiece (P).

**[p0021]**

The vacuum tank ( 8 ) is connected to the jacket ( 17 ) in order to ensure the piston ( 16 ) is held in the low position with the load-carrier ( 14 ) retracted. Deactivating the solenoid valve ( 7 ) thus enables suction to be applied to the top face ( 1 b ) that is to be secured to the workpiece (P), thus ensuring clamping of the workpiece (P) prior to performing work thereon. The rest of the operation steps of the second embodiment of the device of the invention are similar or identical to the steps described in reference to FIG. 1 . In some circumstances, in order to remove or move the worked piece (P), the load-carrier ball ( 14 ) may be used above the level of the top suction face ( 1 a ). After the step of setting the top suction face ( 1 b ) at atmospheric pressure, the pump ( 15 ) is activated to move the piston ( 16 ) of the jack ( 13 ) upwards and to cause the load-carrier ball ( 14 ) to exit above the level of the top suction face ( 1 a ). To do this, the solenoid valve is activated ( 18 ) so as to cause the jacket ( 17 ) to communicate with the pump ( 15 ) creating pneumatic pressure.

**[p0022]**

The workpiece (P) is then moved in translation on the load-carrier ball ( 14 ) so as to be placed in a position chosen by the operator or by the program of an appropriate machine. In FIG. 4 , another clamping pad of the invention also includes a bottom cover ( 10 ) assembled to the body ( 1 ) of the clamping pad. The body ( 1 ) of the clamping pad of the invention presents a hollow cylindrical shape containing in its top portion a set of several storage batteries ( 4 ) that are suitable for being recharged via a socket ( 4 a ). The set of storage batteries ( 4 ) is mounted on a plate ( 11 ) supporting a vacuum buffer tank ( 8 ). The plate ( 11 ) is spaced apart from another plate ( 12 ) carrying an electronic circuit (not shown in detail) and supporting a solenoid valve ( 7 ). Under its bottom portion, the plate ( 12 ) receives a drilled block ( 12 a ) to which the vacuum pump is fastened ( 3 ), in such a manner that the vacuum pump ( 3 ) is suspended inside the body ( 1 ) at a predetermined distance making it possible to avoid any water entering while the suction-cup forming bottom face ( 1 a ) has suction applied thereto to secure it to the worktable (T).

**[p0023]**

The assembly suspended in the top portion of the body ( 1 ) may thus be installed or removed after removal of the bottom cover ( 10 ). The suction-cup forming bottom face ( 1 a ) to be secured by suction to the worktable (T) is attached to the bottom cover ( 10 ). The vacuum pump ( 3 ) is, firstly, advantageously associated with a first filter ( 5 a ) associated with the suction-cup forming bottom first face ( 1 a ). The vacuum pump ( 3 ) is, secondly, advantageously associated with a second filter ( 5 b ) associated with the suction-cup forming second face ( 1 b ) that is to be secured to a workpiece (P). A first vacuum gauge ( 6 a ) is advantageously provided in order to deliver a signal representative of the suction generated at the suction-cup forming first face ( 1 a ), and a second vacuum gauge ( 6 b ) is advantageously provided in order to deliver to provide a signal representative of the suction generated at the suction-cup forming second face ( 1 b ). A vacuum gauge ( 6 a ) or ( 6 b ) is advantageously mounted on a column ( 6 ) presenting two open bore holes.

**[p0024]**

The control valve ( 7 ) is connected via ducts (not shown) to the suction-cup forming second face ( 1 b ) that is to be secured by suction to the workpiece (P) in order to enable said suction-cup forming second face ( 1 b ) to be secured by suction, or in order to enable said suction-cup forming second face ( 1 b ) to be set to atmospheric pressure. The control valve ( 7 ) advantageously consists of a solenoid valve that is normally open for applying suction to the second face ( 1 b ) to be secured to the workpiece (P), in such a manner as to save the energy of maintaining the solenoid valve ( 7 ) in said predetermined suction position. A vacuum buffer tank ( 8 ) connected to the vacuum pump ( 3 ) ensures regularity of the vacuum pump ( 3 ) and avoids repeated stopping and starting of the vacuum pump at short intervals. This modular arrangement makes it possible to manufacture clamping-pad forming devices of the invention that are as compact as prior-art double-sided clamping pads as fed by prior-art vacuum hoses.

**[p0025]**

A fluid curtain is disposed at the periphery of the suction-cup forming top second face ( 1 b ), in order to constitute a coaxial capillary gasket and to avoid “drying” and detachment of the suction-cup forming top second face ( 1 b ), by further preventing undesirable dust, sludge, swarf, or other particles from penetrating therein. The fluid curtain, in particular a liquid curtain, thus reinforces sealing by capillarity at the top suction face ( 1 b ) and contributes to saving the energy required for establishing suction and for maintaining clamping by suction. Machining lubrification water is advantageously used to form a fluid curtain or barrier, by pumping using a liquid pump 33 sucking up the machining lubrification water through an outer filter 34 surrounding the body 1 of the clamping pad. An electronic control circuit connected by communication means, preferably wireless communications means, to the machine-tool makes it possible to manage a stock of double-sided clamping pads of the invention.

**[p0026]**

The means for lifting the workpiece (P), provided in order to facilitate moving it in translation and positioning it comprise a jack ( 13 ) having a load-carrier ball ( 14 ). The jack ( 13 ) with a load-carrier ball ( 14 ) is preferably a pneumatic jack, powered by a pump ( 15 ) providing compressed air pressure in order to ensure movement of a piston ( 16 ) in a jacket ( 17 ). A control valve is mounted to communicate with the jack ( 13 ), in order to enable it to be fed with compressed air and to enable the jack ( 13 ) to extend, or to enable communication with the vacuum pump ( 3 ) and enable the jack ( 13 ) to be withdrawn by suction. The control valve ( 18 ) is a normally open solenoid valve ( 18 ), having an inactivated position that is a position of connection with the line for applying suction via the vacuum pump ( 3 ). An air filter is provided between the pump ( 15 ) and the communication with atmospheric pressure outside the body ( 1 ). The pump ( 15 ) is preferably an electric pump powered by the energy source ( 4 ) of the vacuum pump ( 3 ).

**[p0027]**

The jack ( 13 ) comprising the jacket ( 17 ) is mounted secured to the vacuum tank ( 8 ), being disposed centrally relative to the set of storage batteries ( 4 ) constituting the electrical energy source of the device. The base formed by the spaced apart plates 11 and 12 carry the bottom portion of the tank ( 8 ) and constitutes a mounting support for the electric vacuum pump ( 3 ) and for its associated control valve ( 7 ). The air pump ( 15 ) and its associated control valve ( 18 ) are also mounted secured to the base formed by the spaced apart plates 11 and 12 , in such a manner as to be suspended high up inside the body 1 . The column ( 6 ) presents two bore holes in connection with the spaces for applying suction in the bottom and top suction faces ( 1 a, 1 b ). An electronic control unit is mounted inside the body ( 1 ) and includes a wireless antenna for communicating with a work machine (not shown), preferably by radio communication. The position of the clamping devices of the invention may thus be controlled remotely by the program contained in the work machine (not shown).

**[p0028]**

A mounting flange makes it possible to assemble the vacuum tank ( 8 ) and the jack ( 13 ) components from above. Removing said flange thus makes it possible to completely clean the jack ( 13 ) components and the vacuum tank ( 8 ). The arrangement of the second embodiment is similar to the arrangement of the first embodiment described with reference to FIGS. 1 and 2 , and makes interchangeability of components possible, in particular of rechargeable storage batteries ( 4 ). The device of the invention is designed to have sufficient energy, in particular electrical energy, to maintain suction while working on workpieces, by ensuring lower clamping to the worktable (T) and upper clamping to the workpiece during the operations carried out by the work machine. The arrangement of vacuum seals, of a liquid curtain, and of appropriate suction cups makes it possible to save a considerable amount of energy by ensuring that the vacuum pump is stopped, and that pumps operate only to compensate vacuum leaks or during the time intervals corresponding to positioning or to changing step.

**[p0029]**

The use of a wireless transmission system, in particular by radio frequency, makes it possible to activate the electrical elements, in particular the solenoids of the solenoid valves ( 7 ) and ( 18 ) only during the operating stages, and thus makes it possible to save energy outside of operating stages, because of the fact that the normally open positions of the valves ( 7 ) and ( 18 ) correspond to suction positions, without electricity being supplied to their solenoids. The use of a jack ( 13 ) having a load-carrier ball, in particular of a pneumatic jack ( 13 ) having a load-carrier ball ( 14 ), makes it possible to extend the load-carrier ball ( 14 ) quickly and to place the workpiece (P) that is to be machined in a reference position for the work, in simple and reliable manner. The retraction of the piston ( 16 ) by putting it into communication with the suction source ensures that the load-carrier ball ( 14 ) is retracted below the plane of the workpiece (P) to which suction is applied and thus avoids the bottom surface of the workpiece being marked while the workpiece is being machined by a work machine (not shown).

**[p0030]**

Provision of a vacuum tank ( 8 ) facilitates clamping the workpiece in simple and fast manner, avoiding energy consumption caused by successive stopping and starting of the vacuum pump ( 3 ), and thus saving on energy supply. Recharging storage batteries ( 4 ) between loading two workpieces (P) enables a set of double-sided clamping pads to be made available constantly and continuously. The use of filters ( 5 a, 5 b, and 19 ) protects the vacuum and air ducts against external pollution caused by working on or machining of the workpiece (P). A fluid curtain is disposed at the periphery of the top suction face ( 1 b ) in such a manner as to prevent undesirable dust, sludge, swarf, or other particles from penetrating therein. The fluid curtain, in particular the liquid curtain, makes it possible to reinforce sealing by capillarity at the top suction face ( 1 b ). Machining lubrification water may advantageously be used to form a barrier or fluid curtain, possibly by pumping using an additional liquid pump.

**[p0031]**

The electronic control circuit connected by communication means, preferably wireless communications means, to the machine-tool makes it possible to manage a stock of double-sided clamping pads of the invention. The machine tool for machining (not shown) may advantageously include a programmable machine or a dedicated industrial micro-computer that governs both the positioning and the moving of the double-sided clamping pads of the invention. In an economical version of the invention, the double-sided clamping pads may include switches or on/off control members outside the body ( 1 ) to enable the devices of the invention and their electrical members, such as electric pumps or solenoid valves to be operated to execute the operating steps in sequential, staggered, or simultaneous manner. Operation of the top suction face may be improved by providing a flange or skirt coaxial with the corresponding suction cup of the top suction face. Said additional coaxial flange or skirt makes it possible to limit the length of time of the vacuum pumps are in operation and makes it possible to reduce their normal flow-rate as well as the energy required for operating of the device of the invention.

**[p0032]**

By means of the invention, the suction hoses of the prior art are completely eliminated, and the double-sided clamping pads of the invention may be installed in any position on the worktable (T) in order to support a workpiece (P) in optimum manner. The invention described in reference to two particular embodiments is not limited thereto, but on the contrary covers any modification in form and any variant embodiment within the ambit of the accompanying claims.

## Figure captions

- **Figure 1:** FIG. 1 is a diagram showing a diametral section view of a clamping device of the invention.
- **Figure 2:** FIG. 2 is an exploded diagrammatic view of the clamping device of the invention shown in FIG. 1 .
- **Figure 3:** FIG. 3 is a diagram showing a diametral section view of a second implementation of the clamping device of the invention.
- **Figure 4:** FIG. 4 is an exploded diagrammatic view of the clamping device of the invention shown in FIG. 3 .
- **Figure 1:** With reference to FIGS. 1 to 4 , elements that are identical or functionally equivalent are identified by identical reference numbers.
- **Figure 1:** In FIGS. 1 and 2 , a clamping device of the invention comprises a body ( 1 ) of substantially cylindrical shape presenting a first suction face ( 1 a ) to be secured by suction to a worktable (T) shown in dotted lines and presenting a second suction face ( 1 b ) to be secured by suction to a workpiece (P).
- **Figure 1:** A method of using the clamping device of FIG. 1 begins with a step of positioning the clamping pad on a worktable (T).
- **Figure 1:** After the first face ( 1 a ) has been clamped by suction to the worktable (T) and after a vacuum has been created in the buffer tank ( 8 ), the workpiece (P) is placed on the top suction face ( 1 b ) and the solenoid valve ( 7 ) is de-activated, in order to bring it back to the normally open suction position of FIG. 1 .
- **Figure 1:** After the worked piece (P) has been removed, the solenoid valve ( 7 ) is deactivated in order for it to move back into the normally open position of FIG. 1 .
- **Figure 1:** In this normally open position of FIG. 1 , air enters via the top face ( 1 b ) through the duct ( 2 b ) and feeds the suction circuit in order to bring it to atmospheric pressure and in order to eliminate the suction on the bottom first suction face ( 1 a ).
- **Figure 2:** In FIG. 2 , a clamping pad of the invention includes a bottom cover ( 10 ) assembled to the body ( 1 ) of the clamping pad. The body ( 1 ) of the clamping pad of the invention presents a hollow cylindrical shape containing in its top portion a set of several storage batteries ( 4 ) that are suitable for being recharged via a socket ( 4 a ).
- **Figure 1:** The set of storage batteries ( 4 ) is mounted on a plate ( 11 ) supporting a vacuum buffer tank ( 8 ). The plate ( 11 ) is spaced apart from another plate ( 12 ) carrying an electronic circuit (not shown in detail) and supporting a solenoid valve ( 7 ) as described with reference to FIG. 1 .
- **Figure 3:** In FIG. 3 , a second embodiment of the clamping pad of the invention comprises elements that are identical or functionally equivalent to the elements described in reference to FIG. 1 .
- **Figure 1:** Operation of the second embodiment of the clamping device of the invention is substantially identical to the operation described in reference to FIG. 1 , allowing for the addition of additional steps during positioning of the workpiece (P) on the top suction face ( 1 b ).
- **Figure 1:** The rest of the operation steps of the second embodiment of the device of the invention are similar or identical to the steps described in reference to FIG. 1 .
- **Figure 4:** In FIG. 4 , another clamping pad of the invention also includes a bottom cover ( 10 ) assembled to the body ( 1 ) of the clamping pad. The body ( 1 ) of the clamping pad of the invention presents a hollow cylindrical shape containing in its top portion a set of several storage batteries ( 4 ) that are suitable for being recharged via a socket ( 4 a ).
- **Figure 1:** The arrangement of the second embodiment is similar to the arrangement of the first embodiment described with reference to FIGS. 1 and 2 , and makes interchangeability of components possible, in particular of rechargeable storage batteries ( 4 ).

## Classifications

- B25B11/005
- B25B11/007
- B25B11/007
- B23Q1/03
- B23Q1/03
- B23Q1/03
- B23Q1/037
- B23Q1/037
- B23Q3/08
- B23Q3/088
- B23Q3/088
- B23Q3/088
- B25B11/00
- B25B11/005
- B25B11/005

## Cited patent documents

- [CN-202971351-U](https://patents.google.com/patent/CN202971351U/en) — SEA
- [DE-19629685-A1](https://patents.google.com/patent/DE19629685A1/en) — APP
- [DE-202009006437-U1](https://patents.google.com/patent/DE202009006437U1/en) — APP
- [DE-29518188-U1](https://patents.google.com/patent/DE29518188U1/en) — APP
- [EP-1342533-A1](https://patents.google.com/patent/EP1342533A1/en) — APP
- [FR-2546790-A1](https://patents.google.com/patent/FR2546790A1/en) — APP
- [FR-2890325-A1](https://patents.google.com/patent/FR2890325A1/en) — SEA
- [FR-2950556-A1](https://patents.google.com/patent/FR2950556A1/en) — SEA
- [US-1130679-A](https://patents.google.com/patent/US1130679A/en) — SEA
- [US-2007175022-A1](https://patents.google.com/patent/US20070175022A1/en) — SEA
- [US-2008277885-A1](https://patents.google.com/patent/US20080277885A1/en) — APP
- [US-2756644-A](https://patents.google.com/patent/US2756644A/en) — SEA
- [US-2782574-A](https://patents.google.com/patent/US2782574A/en) — SEA
- [US-3520055-A](https://patents.google.com/patent/US3520055A/en) — SEA
- [US-3584859-A](https://patents.google.com/patent/US3584859A/en) — SEA
- [US-3652075-A](https://patents.google.com/patent/US3652075A/en) — SEA
- [US-3797797-A](https://patents.google.com/patent/US3797797A/en) — SEA
- [US-4561642-A](https://patents.google.com/patent/US4561642A/en) — SEA
- [US-5553837-A](https://patents.google.com/patent/US5553837A/en) — SEA
- [US-6068547-A](https://patents.google.com/patent/US6068547A/en) — SEA
- [US-6264259-B1](https://patents.google.com/patent/US6264259B1/en) — SEA
- [US-6286822-B1](https://patents.google.com/patent/US6286822B1/en) — SEA
- [US-6817933-B2](https://patents.google.com/patent/US6817933B2/en) — SEA
- [US-8439490-B2](https://patents.google.com/patent/US8439490B2/en) — SEA
- [WO-2007028886-A1](https://patents.google.com/patent/WO2007028886A1/en) — APP

---

Generated by IPtorch. Verify legal conclusions against the official publication.
