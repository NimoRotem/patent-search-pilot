# 33. Grasping gripper

- **Archive rank:** 33 of 50
- **Publication:** [US-10195746-B2](https://patents.google.com/patent/US10195746B2/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/055581998/publication/US10195746B2?q=pn%3DUS10195746B2)
- **Publication date:** 2019-02-05
- **Filing date:** 2015-09-24
- **Earliest priority:** 2014-09-26
- **Family:** 55581998
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus

## Parties

- **Applicant / assignee:** TERADYNE INC
- **Inventors:** TRUEBENBACH ERIC L

## Abstract

An example gripper may include: a base; two or more fingers attached to the base, with each finger being movable towards, and away from, one or more others of the fingers; and one or more ports at the base or at one or more of the fingers to provide suction through a vacuum.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-10195746-B2/000.png)

![Sketch 1 for US-10195746-B2](https://nimo.iptorch.com/refdrawing/US-10195746-B2/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/US-10195746-B2/001.png)

![Sketch 2 for US-10195746-B2](https://nimo.iptorch.com/refdrawing/US-10195746-B2/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/US-10195746-B2/002.png)

![Sketch 3 for US-10195746-B2](https://nimo.iptorch.com/refdrawing/US-10195746-B2/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/US-10195746-B2/003.png)

![Sketch 4 for US-10195746-B2](https://nimo.iptorch.com/refdrawing/US-10195746-B2/003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/US-10195746-B2/004.png)

![Sketch 5 for US-10195746-B2](https://nimo.iptorch.com/refdrawing/US-10195746-B2/004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/US-10195746-B2/005.png)

![Sketch 6 for US-10195746-B2](https://nimo.iptorch.com/refdrawing/US-10195746-B2/005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/US-10195746-B2/006.png)

![Sketch 7 for US-10195746-B2](https://nimo.iptorch.com/refdrawing/US-10195746-B2/006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/US-10195746-B2/007.png)

![Sketch 8 for US-10195746-B2](https://nimo.iptorch.com/refdrawing/US-10195746-B2/007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/US-10195746-B2/008.png)

![Sketch 9 for US-10195746-B2](https://nimo.iptorch.com/refdrawing/US-10195746-B2/008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/US-10195746-B2/009.png)

![Sketch 10 for US-10195746-B2](https://nimo.iptorch.com/refdrawing/US-10195746-B2/009.png)

[Sketch 11](https://nimo.iptorch.com/refdrawing/US-10195746-B2/010.png)

![Sketch 11 for US-10195746-B2](https://nimo.iptorch.com/refdrawing/US-10195746-B2/010.png)

[Sketch 12](https://nimo.iptorch.com/refdrawing/US-10195746-B2/011.png)

![Sketch 12 for US-10195746-B2](https://nimo.iptorch.com/refdrawing/US-10195746-B2/011.png)

## Claims

### Claim 1 (independent)

A gripper comprising: a base; two or more fingers attached to the base, each of the two or more fingers being configured to move inward towards at least one other of the two or more fingers to enable grasping of an object by the two or more fingers; and one or more ports located on a pad of at least one of the fingers facing at least one other finger to grasp the object, the one or more ports to provide suction on the pad to aid the two or more fingers in grasping the object; wherein suction through the one or more ports is controllable based, at least in part, on a grasping force produced by the at least one finger and the at least one other finger.

### Claim 2

The gripper of claim 1 , wherein each of the two or more fingers comprises multiple parts interconnected at, and movable about, one or more joints.

### Claim 3

The gripper of claim 1 , wherein each of the two or more fingers has an inner surface facing one or more others of the fingers and an outer surface facing away from one or more others of the fingers; and wherein one or more ports are located on tips of the fingers.

### Claim 4

The gripper of claim 1 , wherein each of the two or more fingers has an inner surface facing one or more others of the fingers and an outer surface facing away from one or more others of the fingers; and wherein one or more ports are located on outer surfaces of the fingers.

### Claim 5

The gripper of claim 1 , wherein at least one of the two or more fingers has a tip that can be configured to face away from the base; wherein at least one of the one or more ports is located on the tip.

### Claim 6

The gripper of claim 3 , 4 , or 5 , wherein at least one port is on the base.

### Claim 7

The gripper of claim 1 , wherein each of the two or more fingers has an inner surface facing others of the fingers, the inner surface comprising a pad, an outer surface facing away from others of the fingers, and a tip that can be configured to face away from the base; and wherein, for each of the fingers, at least one port is located on at least two of: the inner surface, the outer surface, and the tip.

### Claim 8

The gripper of claim 7 , wherein at least one port is also on the base.

### Claim 9

The gripper of claim 1 , further comprising: one or more vacuum sources to produce vacuum for the one or more ports; and one or more controllers to control the vacuum sources to produce the vacuum.

### Claim 10

The gripper of claim 9 , wherein the one or more controllers are configured to control the one or more vacuum sources to apply vacuum to individual ports independently.

### Claim 11

The gripper of claim 1 , further comprising a cannula disposed in the base that is extendible from the base, and retractable into the base.

### Claim 12

The gripper of claim 11 , further comprising: a port on the cannula to provide suction through a vacuum.

### Claim 13

The gripper of claim 12 , wherein the port is on a tip of the cannula.

### Claim 14

The gripper of claim 1 , further comprising a cannula in at least one of the fingers, the cannula being extendible from the at least one of the fingers, and the cannula being retractable into the at least one of the fingers.

### Claim 15

The gripper of claim 14 , further comprising: a port on the cannula to provide suction through a vacuum.

### Claim 16

The gripper of claim 15 , wherein the port is on a tip of the cannula.

### Claim 17

The gripper of claim 1 , wherein each finger is bendable towards, and away from, an interior of the gripper.

### Claim 18 (independent)

Automatic test equipment (ATE) comprising: one or more instruments to test a device under test (DUT); and a gripper to grasp the DUT during movement of the DUT relative to an interface to the one or more instruments, the gripper comprising: a base; two or more fingers attached to the base, each of the two or more fingers being interconnected at, and movable about, one or more joints, each of the two or more fingers being configured to move inward towards at least one other of the two or more fingers to enable grasping of an object by the two or more fingers; and one or more ports on one or more pads of the fingers, each finger facing at least one other finger to grasp the object, each port to provide suction on a pad to aid the two or more fingers in holding the object; wherein suction through the one or more ports is controllable based, at least in part, on a grasping force produced by at least one finger and the at least one other finger.

### Claim 19

The ATE of claim 18 , wherein the object is the DUT.

### Claim 20 (independent)

A gripper comprising: a base; fingers attached to the base, each finger being movable towards, and away from, one or more others of the fingers to produce force to grasp an object; one or more cannulas disposed on, and extendible from, a tip of one or more corresponding ones of the fingers; and a port on at least one of the one or more cannulas, the port to provide suction through a vacuum.

### Claim 21

The gripper of claim 20 , wherein each of the fingers has an inner surface facing one or more others of the fingers and an outer surface facing away from one or more others of the fingers; and wherein one or more ports are located on inner surfaces of the fingers.

### Claim 22

The gripper of claim 20 , wherein each of the fingers has an inner surface facing one or more others of the fingers and an outer surface facing away from one or more others of the fingers; and wherein one or more ports are located on outer surfaces of the fingers.

### Claim 23

The gripper of claim 20 , wherein at least one of the fingers has a tip that is movable to face away from the base; wherein at least port is located on at least one tip.

### Claim 24

The gripper of claim 20 , further comprising: one or more vacuum sources to produce vacuum for one or more ports; and one or more controllers to control the vacuum sources independently.

## Full description

### Cross-Reference To Related Application

**[p0001]**

Priority is hereby claimed to U.S. Provisional Application No. 62/056,092, filed on Sep. 26, 2014. The contents of U.S. Provisional Application No. 62/056,092 are incorporated herein by reference.

### Technical Field

**[p0002]**

This specification relates generally to a gripper for use, e.g., with an automated system, such as, but not limited to, a robotic test system.

### Background

**[p0003]**

Robot grippers may be custom-developed for specific applications. General purpose robot grippers exist, which mimic the human hand, use jamming technology, or use vacuum pick-up. Mechanical hand-like grippers and jamming grippers may, in some cases, be too large to pick-up small objects. Vacuum pick-up may be limited by the amount of smooth area available on an object and the object&#39;s weight.

### Summary

**[p0004]**

An example gripper comprises: a base; two or more fingers attached to the base; and one or more ports located on the base or on at least one of the two or more fingers to provide suction through a vacuum. The example gripper may include one or more of the following features, either alone or in combination. Each of the two or more fingers may comprise multiple parts interconnected at, and movable about, one or more joints. Each of the two or more fingers may have an inner surface facing one or more others of the fingers and an outer surface facing away from one or more others of the fingers. The one or more ports may be located on inner surfaces of the fingers. The one or more ports may be located on outer surfaces of the fingers. At least one of the two or more fingers may have a tip that can be configured to face away from the base, and at least one of the one or more ports may be located on the tip. At least one of the ports may be on the base. Each of the two or more fingers may have an inner surface facing others of the fingers, an outer surface facing away from others of the fingers, and a tip that can be configured to face away from the base. For each of the fingers, at least one of the ports may be located on at least two of: the inner surface, the outer surface, and the tip. At least one of the ports may also be on the base.

**[p0005]**

The gripper may further comprise: one or more vacuum sources to produce vacuum for the one or more ports; and one or more controllers to control the vacuum sources to produce the vacuum. The one or more controllers may be configured (e.g., programmed or designed) to control the one or more vacuum sources to apply vacuum to individual ports independently. The gripper may comprise a cannula disposed in the base that is extendible from the base, and retractable into the base. A port may be on the cannula (e.g., the tip of the cannula) to provide suction through a vacuum. A cannula may be in at least one of the fingers, that is extendible from the at least one of the fingers, and that is retractable into the at least one of the fingers. A port on the cannula (e.g., on the tip of the cannula) may provide suction through a vacuum. Each finger may be bendable towards, and away from, an interior of the gripper. Example automatic test equipment (ATE) may comprise: one or more instruments to test a device under test (DUT); and a gripper to grasp the DUT during movement of the DUT relative to an interface to the one or more instruments. The gripper may comprise: a base; two or more fingers attached to the base, with each finger being interconnected at, and movable about, one or more joints; and one or ports at the base or at one or more of the fingers to provide suction through a vacuum.

**[p0006]**

An example gripper may include: a base; two or more fingers attached to the base, with each finger being movable towards, and away from, one or more others of the fingers; and one or ports at the base or at one or more of the fingers to provide suction through a vacuum. The example gripper may include one or more of the following features, either alone or in combination. Each of the fingers may have an inner surface facing one or more others of the fingers and an outer surface facing away from one or more others of the fingers. The one or more ports may be located on inner surfaces of the fingers. The one or more ports may be located on outer surfaces of the fingers. At least one of the fingers may have a tip that is movable to face away from the base, and at least one of the one or more ports may be located on at least one tip. The gripper may also include one or more vacuum sources to produce vacuum for the one or more ports, and one or more controllers to control the vacuum sources independently.

**[p0007]**

Any two or more of the features described in this specification can be combined to form implementations not specifically described herein. Automated systems and techniques, with which the implementations described herein may be used, or portions thereof, can be implemented as/controlled by a computer program product that includes instructions that are stored on one or more non-transitory machine-readable storage media, and that are executable on one or more processing devices to control (e.g., coordinate) the operations described herein. The automated systems and techniques including the gripper described herein, or portions thereof, can be implemented in an apparatus, method, or electronic system that can include one or more processing devices and memory to store executable instructions to implement various operations. The details of one or more implementations are set forth in the accompanying drawings and the description below. Other features and advantages will be apparent from the description and drawings, and from the claims.

### Description Of The Drawings

**[p0008]**

FIGS. 1A, 1B, 1C, and 1D show perspective views of example vacuum grippers. FIG. 2 shows a side view of an example vise gripper. FIG. 3 shows side views of an example jamming gripper operating to grip three different types of objects. FIG. 4 is a perspective view of an example machine claw. FIG. 5 is a perspective view of an example grasping gripper. FIG. 6 is a perspective view of an example grasping gripper having vacuum ports on both its fingers and the base. FIG. 7 is a perspective view of an example grasping gripper showing a different number and configuration of vacuum ports than those shown in FIG. 6 . FIG. 8 is a perspective view of an example grasping gripper showing one finger folded to expose a back-side vacuum port. FIG. 9 is a perspective view of an example grasping gripper showing a cannula extending from the base of the grasping gripper. FIG. 10 is a perspective view of an example grasping gripper showing a cannula extending from a fingertip of the grasping gripper. FIG. 11 is a perspective view of an example robot in a test system that employs a grasping gripper of the type described herein.

**[p0009]**

Like reference numerals in different figures indicate like elements.

### Detailed Description

**[p0010]**

Robot grippers, also known as End of Arm Tooling (EOAT) or End Effectors, may be used to pick-up objects for transportation or assembly. For example, in automatic test equipment (ATE), a robot gripper may pick-up a device under test (DUT), and a robotic arm to which the gripper is attached may move the DUT between a loading station and a test slot or test head. At that point, the gripper may let go of the object, and the arm may move the gripper to another device. Grippers may be custom-designed to be specific to the object to be moved. For example, a gripper may be designed, both in structure and size, to pick-up a DUT in ATE. Although the grippers presented herein are described in the context of testing and ATE, the grippers described herein may be used in any appropriate robotic or automated process, including non-test applications. A vacuum gripper may employ a vacuum to lift an object. The object being lifted typically has a smooth surface area against which a vacuum is applied. FIGS. 1A, 1B, 1C, and 1D show example vacuum grippers 10 , 11 , 12 , and 13 , respectively, that may be used to pick-up small objects like electronic components, or flat objects like small pieces of sheet metal, glass, or paper. In a vacuum gripper, the weight of an object that can be picked-up by a vacuum may be limited by the difference between the vacuum pressure and the ambient atmospheric pressure, divided by the area to which the vacuum can be applied. For example, a 100 gram object at sea level requires a minimum of approximately 0.981 N of force to be lifted. At a nominal sea level atmo

**[p0010]**

spheric pressure of 101,325 Pa, a minimum surface area of 0.981/101,325=9.68×10-6 m 2 or 9.68 mm 2 is required to lift the object with a perfect vacuum and no acceleration. Due to imperfections of vacuums and vacuum seals, large-surface traditional vacuum grippers have limitations. For example, vacuum gripping has heretofore been most applicable to light objects like electronic components, or to objects with large and smooth surface areas like panes of glass. Traditional vacuum grippers are not always well-suited for picking up flexible objects, porous objects, objects with a rough surface, objects with a high aspect ratio, heavy objects with small surface areas, or objects with an unpredictable shape.

**[p0011]**

A general-purpose mechanical gripper may use a grasping or pinching motion to grab an object. A mechanical gripper uses friction to maintain its grasp on an object. The use of resilient materials, such as rubber, at a contact surface of the mechanical gripper (e.g., the surface that contacts the object to be picked-up) may allow some conformation of the contact surface to the shape of the object to be lifted, increasing friction. A vise gripper is an example of a mechanical gripper. The vise gripper 15 of FIG. 2 operates like a bench vise. Two movable jaws 16 , 17 (or one moveable and one fixed jaw) open and close by electric or pneumatic actuation. The object to be gripped (not shown) fits between the two jaws, and is able to withstand force exerted on its (possibly small) contact area. The type of object that may be gripped may be limited by the amount that the jaws can open and by the degree to which the jaws can fully close (known as the jaws&#39; stroke). A basic vise gripper may not be able to grab objects having insufficient contact area relative to their weight (like a steel ball), objects that may be damaged by the force needed to obtain sufficient friction (like a piece of coral), or low friction objects (like an oily part). And, like a human hand, a vise gripper may have difficulty grasping very thin or delicate objects, or different objects of different sizes. It may be difficult to surround a relatively thin object sufficiently with the tips of the jaws to obtain enough frictional force, especially if the vise gripper is also capable of surrounding very large o

**[p0011]**

bjects.

**[p0012]**

Referring to FIG. 3 , a jamming gripper 19 uses a granular substance inside a flexible membrane 18 to pick-up an object. When forced into contact with an object 20 , 21 , or 22 , jamming gripper 19 conforms to the object&#39;s size, particularly when the internal granular substance is loosely packed. The granules are jammed by reducing their volume, by applying a vacuum, or by mechanical displacement. The jammed gripper hardens and exerts sufficient force on the side of an object to lift it by friction. The object may also be lifted by wrapping around features on the object, or by creating a region of reduced air pressure above the object. Jamming grippers may require that the object be thick enough to have a side on which to exert some frictional force, or to have a protrusion that the gripper can mostly surround. Jamming grippers also may require that the object be large in proportion to the granules, so that the granules can flow when not jammed. Jamming grippers also may require that the gripper be significantly wider than the object to be grasped, so that the gripper membrane and granules can surround the object on at least two sides. As such, jamming grippers may not be suitable for picking up relatively small objects (e.g., small screws, small electronic components), objects of different sizes, or flat objects (e.g., sheet metal, paper). Finally, jamming grippers can, in some cases, generate electrostatic discharge (ESD) due to the large volume of air generally used for jamming and unjamming, and the triboelectric transfer of charge between the granules as they rub p

**[p0012]**

ast each other.

**[p0013]**

FIG. 4 shows an example machine claw 25 , which is a gripper that may grip using less friction, and that can be used to lift an object by surrounding (and possibly compressing) the object. A sufficiently powerful machine claw can pick-up an object that a vise gripper, such as the one shown in FIG. 3 , can pick-up. In addition, such a gripper can pick-up objects that have relatively low friction, or delicate objects, if it is possible to surround the object from underneath. If, however, it is not possible to surround an object, such as a thin piece of metal or a small electronic component, the machine claw may not be able to grasp the object. The use of resilient materials to increase friction may also be problematic. The materials may wear and need to be replaced. They also can limit the dexterity of a gripper, e.g., a gripper with a resilient pad may not be able to grasp a relatively small or thin object. The part may become embedded (stuck) in the pad, or the pad may deform too much before sufficient friction is obtained to achieve lift.

**[p0014]**

An example grasping gripper 26 is shown in FIG. 5 . Grasping gripper 26 is configured to have a structure and function that is based on (and in some cases resembles) the structure and function of a human hand. The example grasping gripper of FIG. 5 has three fingers 27 , 28 , 29 that act against (e.g., oppose) each other or against a fixed base 30 on which the fingers are mounted. Although only three fingers are shown in FIG. 5 , grasping gripper 26 may include any number of two or more such fingers. For example, grasping gripper 26 may include two, three, four, five, six, seven, eight, nine, ten, eleven, twelve, and so forth, number of fingers. In the example of FIG. 5 , each of the fingers includes multiple parts interconnected at, and movable about or around, one or more finger joints. For example, finger 27 includes parts 31 , 32 , 33 . Parts 31 and 32 are connected at joint 35 , and parts 32 and 33 are connected at joint 36 . In the example of FIG. 5 , there are three parts and two joints per finger. However, in some implementations, there may be more, or less, than three parts per finger, and more, or less, than two joints per finger. For example in some implementations, there may be two parts and one joint per finger; there may be four parts and three joints per finger; there may be five parts and four joints per finger; there may be six parts and five joints per finger; there may be seven parts and six joints per finger; there may be eight parts and seven joints per finger; and so forth. In some implementations, each finger may include a single part and no joints, e

**[p0014]**

.g., each finger may be a single rigid part. In some implementations, one or more fingers may be integral parts of the base, and immobile relative to one or more other fingers. For example, a finger may be a rigid structure extending from the base that is opposed by other, moveable fingers. Such a finger may act as a backstop gripping by one or more other, actuated fingers, and may not be actuated itself.

**[p0015]**

In the example of FIG. 5 , each finger has the same number of parts and the same number of joints, resulting in substantially the same configuration for each finger. In some implementations, different fingers may have different numbers of parts and joints, resulting in different configurations for each finger. In some implementations, the grasping gripper may include one or more fingers on a one side 38 of base 30 (two fingers 27 , 28 are shown in FIG. 5 ) and one or more other fingers on another side 39 of base 30 (one finger 29 is shown in FIG. 5 ). In some implementations, one finger may approximate a human thumb, and oppose all other fingers, although this need not be the case in all implementations. In some implementations, the finger approximating the human thumb may have fewer numbers of parts and joints than the other fingers. For example, the finger approximating the human thumb may have two parts and one joint, whereas the other fingers in such an implementation may each have three parts and two joints (or any other appropriate number of parts and joints).

**[p0016]**

In the example of FIG. 5 , base 30 is rectangular and rigid; however, in other implementations base 30 may have a different shape. For example, base 30 may be square, oval, round, pentagonal, hexagonal, heptagonal, octagonal, or any other shape that is appropriate to hold multiple fingers such as those described herein and, if appropriate, the electronics, hydraulics, pneumatics, or other elements used to control the fingers. In some implementations, such as that show in FIG. 5 , the fingers may have the same length or approximately the same length. In some implementations, different fingers may have different lengths. For example, one finger may be longer or shorter than the other fingers; two fingers may be longer or shorter than the other fingers; three fingers may be longer or shorter than the other fingers; four fingers may be longer or shorter than the other fingers; and so forth. As shown in the example of FIG. 5 , the grasping gripper includes two or more fingers acting against (e.g., opposing) each other or against fixed base. That is, in some implementations, the fingers may each move towards each other in a way that is similar to the operation of the human hand. The individual parts may be controllable along the joints to move and to fold inward, towards other fingers, and/or to rotate around a corresponding joint. When working together in this manner, two or more of the fingers may contact, and conform to, the shape of an object to be picked-up and moved. By contacting opposing, or substantially opposing, fingers against an object, frictional force may be genera

**[p0016]**

ted to grasp and, in some cases, pick-up (or lift) the object. In some implementations, as described below with respect to FIG. 6 , vacuum ports may be incorporated into the fingers to expand the range of objects that can be picked-up by the grasping gripper.

**[p0017]**

Thus, as explained above, the fingers may have a rigid shape, or they may be articulated. The gripper may be actuated electrically, hydraulically, pneumatically, or using any other appropriate mechanism(s). For example, two or more (e.g., all) of the fingers may be controlled individually, or in concert, to generate motion appropriate to grasp, and to pick-up, an object. As described herein, each finger part may be controlled to pivot about and/or rotate around its corresponding joint to implement the movements described herein. In some implementations, each finger part is controllable individually. As noted, in some implementations, control over the parts may be coordinated, as appropriate, to achieve a desired configuration. Control may be implemented via one or computer programs (comprised of instructions/code) that are executable on one or more computers remote to the grasping gripper, or via one or more computer programs that are executable on one or more controllers or other processing devices that resides locally on the grasping gripper itself, on a robotic arm to which the grasping gripper is attached, or on a robot to which the grasping gripper is attached. Control signals from the computer(s) or other processing devices may be sent to the grasping gripper (or parts thereof) via wired or wireless connections or a combination of wired and wireless connections.

**[p0018]**

In operation, grasping gripper 26 picks-up objects by friction generated between two or more fingers, e.g., by surrounding the object with the fingers and clamping the object. In some implementations, an entire finger or individual part(s) thereof may be bent back, e.g., away from, the base. For example, part 31 may be bent back along the direction of arrow 40 so that part 31 is substantially parallel to base 30 , or bent back beyond that position. In some implementations, various parts of the grasping gripper may be controllable to bend back in this manner. For example, each finger may be bent so that it is parallel or substantially parallel to base 30 , thereby resembling an open hand with the palm/base exposed. FIG. 6 shows an example grasping gripper 41 of the type shown in FIG. 5 , which incorporates vacuum ports on one or more of the fingers and/or on the base. In this example, the grasping gripper of FIG. 6 includes all of the structure and function of the grasping gripper of FIG. 5 , including the different implementations described herein. However, this need not be the case in all implementations.

**[p0019]**

In the example of FIG. 6 , one or more vacuum ports are incorporated into the tips of fingers 44 , 45 , 46 (e.g., example vacuum port 42 is shown), one or more vacuum ports 47 are incorporated into base 49 , one or more vacuum ports are incorporated into the backs of the fingers (example vacuum port 50 is shown), one or more vacuum ports are incorporated into one or more (e.g., all) parts of the fingers (examples are shown in FIG. 7 ), and/or one or more vacuum ports are incorporated into the uppermost pads (the fronts) of the fingers (example vacuum ports 51 and 52 are shown). The vacuum force generated through these vacuum ports can be used to can pick-up objects, either for movement as is, or to subsequently be grasped by the mechanical actuation of the gripper. The amount of vacuum force generated for each port may vary, as appropriate, based on the amount of force required to pick-up an object or to assist in picking-up the object (with the remaining force being generated through gripping achieved by mechanical actuation of the gripper, e.g., by force applied through contact with the fingers).

**[p0020]**

FIG. 7 shows an implementation of a grasping gripper 55 of the type described herein having vacuum port numbers and configurations different than those shown in FIG. 6 . In FIG. 7 each circle represents a vacuum port. The numbers, sizes, shapes, and arrangements of vacuum ports on a grasping gripper may vary, and are not limited to the examples presented herein. The vacuum force is analogous to a human wetting their finger to generate surface tension to lift an object prior to grasping the object by pressing it against a second finger or the palm of the hand for subsequent movement under higher acceleration. Here, vacuum is used instead of surface tension. In some implementations, subsequent grasp may not be necessary if the object is light enough and the vacuum force is high enough. However, in some implementations, subsequent grasp may be necessary if the object is not light enough and/or the vacuum force is not high enough. The vacuum force may be a function of the size of the object and the grasping force that is applied by the fingers. For example, assuming a same size object, a higher vacuum force is required if no grasping force is used, whereas a lower vacuum force may be used if grasping force is also used. In this regard, the terms “high” and “low” used herein do not have any specific numerical connotations, but rather are used to denote relative size.

**[p0021]**

By folding several fingers out of the way, a single fingertip vacuum port may be used to selectively lift an object from a confined space, or when surrounded by other objects. In this example, “out of the way” may refer, e.g., to the bending back of a finger away from the finger that is performing the lifting. In this example, vacuum force alone is used to generate sufficient force to pick-up an object; grasping through opposable fingers is not used. In some implementations, as appropriate given the structure of the grasping gripper, different parts of each finger may be operated in this manner to pick-up objects. For example, in some implementations, two or more fingertips may be moved relative to an object to enable the vacuum ports on those fingertips to operate in concert and together generate enough force to lift the object absent grasping force. When the grasping gripper is used for non-vacuum-assisted grasping, fingertip vacuum ports (e.g., port 42 of FIG. 6 ) need not be in contact with the grasped object, allowing the ports to have protruding resilient material that may be delicate or large, without obstructing the grasp or wearing the resilient material. The same may not be true of finger pad or base vacuum ports. That is, as described herein, the vacuum force on fronts of one or more parts of the fingers may augment the grasping force achieved through contact between the object and the fingers. In the example of FIG. 6 , the front part of each finger has a vacuum port, examples of which are vacuum ports 51 and 52 (the vacuum port on the front part of finger 44 ca

**[p0021]**

nnot be seen in FIG. 6 due to the angle of that finger). Those parts of the fingers may also be used to grasp an object in this example. Vacuum force generated through the one or more vacuum ports on each front may augment the grasping force, together achieving enough force to lift and move/accelerate an object. The amount of force required to lift an object corresponds to the total force needed; however, the relative amounts of force generated by grasping and the vacuum ports may be controlled as desired based on the ranges of grasping forces that are achievable and the ranges of vacuum force that are achievable.

**[p0022]**

In some implementations, the fingers can be folded out of the way (rotating so as to be at or beyond the plane of the base). In this configuration, a flat object can be lifted off of a surface via vacuum force generated through the one or more vacuum ports on the base. The fingers may then be folded around the object for subsequent movement under higher acceleration. Thus, much like fingers on a human hand can be extended leaving the open palm free to contact a surface, the fingers of grasping gripper can be controlled so as to allow the base 59 , and thus one or more vacuum ports (e.g., 47 ) on the base, to contact a surface. For standard, non-vacuum-assisted grasping, vacuum ports on the backs of the fingers (e.g., port 50 of finger 44 in FIG. 6 ) are not contact with the grasped object, allowing the ports to have protruding resilient material that may be delicate or large, without obstructing the grasp or wearing the resilient material. The backs of the fingers may include a cannula that protrudes beyond the body of the finger, to allow greater selectivity in locating an object to pick-up. Objects picked up by the back-of-finger ports may not be graspable by the other fingers, unless an opposite finger is longer, and able to fold over the port. For example, as shown in FIG. 8 , finger 44 may fold over, allowing a vacuum port 50 to contact an object and, through appropriate vacuum force, lift the object. If finger 45 , for example, has sufficient length to contact the object, grasping force may augment the vacuum force.

**[p0023]**

Some implementations of the grasping gripper described herein may include one or more of the following features, either alone in combination with the features described elsewhere herein. Some implementations of the grasping gripper described herein may also include one or more features of the grippers shown in FIGS. 1A, 1B, 1C, 1D , FIG. 2 , FIG. 3 , and/or FIG. 4 . In some implementations, the vacuum ports may be individually actuated, or a single actuation may be performed to control the vacuum force generated through the vacuum ports. For example, all vacuum ports may be connected to a single vacuum source to achieve vacuum force through the ports. The sizes of the ports may influence the amount of vacuum force achieved. In some implementations, different vacuum sources may be connected to the different vacuum ports, thereby allowing different vacuum ports having the same size to generate different vacuum force. Various control methods may be used for shutting off the suction to ports that are not in contact with an object. For example, in the cases of separately controllable vacuum sources, the source(s) to different ports may be shut-off or reduced in suction. In some implementations, including those that use a single vacuum source for example, electromechanical switches may be controllable to open or close the vacuum ports individually and independently.

**[p0024]**

One or more of the vacuum ports may have a cannula that may be selectively extended and retracted, for enhanced selectivity and clearance when extended, and for enhanced protection and flexibility when retracted. The cannula may include a tube or the like, that is extendible, that is hollow, and that includes a port at a tip thereof to enable vacuum force to be created at the end of the cannula. As a result, the cannula can be used in small spaces to pick-up objects using vacuum force, and then retract when not needed. For example, a cannula may be extended from the base of the hand to pick-up a flat object, and then be retracted while carrying the object, as the fingers close around the object. In some implementations, a relatively small cannula may be extended from the tip of a finger to allow greater selectivity without restrictions resulting from finger size in a confined space. Each cannula, and the vacuum force generated therethrough, may be separately and individually controlled via one or more computer programs, as described herein.

**[p0025]**

FIG. 9 shows an example of a cannula 58 extending from base 49 of grasping gripper 41 ; and FIG. 10 shows an example of a cannula 59 extending from a tip of finger 45 . In some implementations, each finger and the base may have an extendible and retractable cannula. In some implementations, an extendible and retractable cannula may be included in only a subset of the fingers or the base. In some implementations, there may be more than one cannula per base or finger. Different size and shapes of vacuum ports may be used in different parts of the grasping gripper. The sizes and shapes of the vacuum ports may be dependent upon the size of the grasping gripper and on the size of object(s) that the grasping gripper is intended to pick-up. Generally, for the same amount of vacuum suction, a larger port will produce less vacuum force than a smaller port. In this regard, the terms “larger/larger” and “small/smaller” used herein do not have any specific numerical connotations, but rather are used to denote relative size.

**[p0026]**

The vacuum ports described herein, and associated features, may also be incorporated into a vise-type gripper, such as that shown in FIG. 2 . For example, vacuum ports may be incorporated into the sides of vise-type gripper 15 ( FIG. 2 ). As such, that gripper may be used to hold small objects by vacuum alone or, if appropriate, by a combination of vacuum force and grasping force. In some implementations, vacuum ports of the type described herein, and their associated features, may be incorporated into any of the grippers shown in FIGS. 1A, 1B, 1C, 1D , FIG. 2 , FIG. 3 , and/or FIG. 4 , as appropriate. In some implementations, a single grasping gripper of the type described herein is capable of lifting large objects (e.g., a standard-sized brick), small objects (e.g., a 0603 resistor), porous objects (e.g., a square of cotton cloth), irregular and delicate objects (e.g., a piece of coral), and/or thin objects (e.g., a 100×50 mm piece of 0.15 mm thick aluminum). Grasping grippers having different sizes and shapes may be usable to lift different sized and shaped objects.

**[p0027]**

The grasping gripper described herein can be used in any appropriate factory or warehouse applications including, but not limited to, test applications, such as automatic test equipment (ATE) used to test various components that need to be grabbed and moved. FIG. 11 shows an example a robot 60 that is part of a test system (e.g., ATE) that includes a grasping gripper 61 of the type described herein (e.g., of the type shown in FIGS. 5 to 10 ). Devices tested by such ATE may include any appropriate semiconductor or other testable device that can be contacted and lifted by the grasping gripper described herein. The devices may include, but are not limited to, devices at the integrated circuit (IC) package level, which may be used in various applications, such as solid state drives. A solid-state drive (SSD) is a data storage device that uses solid-state memory to store persistent data. The grasping gripper described herein may be used to lift a device to be tested by the system, as described herein.

**[p0028]**

Referring to FIG. 11 , robot 60 includes a robotic arms, such as arm 62 , and a grasping gripper 61 disposed at a distal end of the robotic arm. The robotic arm and gripper are controllable to lift a DUT 70 that has not been tested, and to transport the DUT to a test station, test rack, or other appropriate testing facility. The robot arm and gripper are also controllable to remove a device that has already been tested from the test station, test rack, or other appropriate testing facility. In some implementations, the test system also includes at least one computer in communication with robot 60 . The computer may include one or more processing devices (e.g., multiple computers or devices) and may be configured to provide inventory control of the devices under test and/or an automation interface to control the device test system, including robot 60 . Test electronics that are part of the test system may include one or more processing devices to execute test processes and monitor the status (e.g., temperature, performance, etc.) of the devices under test.

**[p0029]**

The example grippers described herein, or automated systems that use those grippers, may be controlled using hardware or a combination of hardware and software. For example, a system that includes the gripper described herein may include various controllers and/or processing devices located at various points. A central computer may coordinate operation among the various controllers or processing devices. The central computer, controllers, and processing devices may execute various software routines to effect control and coordination of system operation. System, including gripper, operations can be controlled, at least in part, using one or more computer program products, e.g., one or more computer program tangibly embodied in one or more information carriers, such as one or more non-transitory machine-readable media, for execution by, or to control the operation of, one or more data processing apparatus, e.g., a programmable processor, a computer, multiple computers, and/or programmable logic components.

**[p0030]**

A computer program can be written in any form of programming language, including compiled or interpreted languages, and it can be deployed in any form, including as a stand-alone program or as a module, component, subroutine, or other unit suitable for use in a computing environment. A computer program can be deployed to be executed on one computer or on multiple computers at one site or distributed across multiple sites and interconnected by a network. Actions associated with implementing all or part of the testing and calibration can be performed by one or more programmable processors executing one or more computer programs to perform the functions described herein. All or part of the testing and calibration can be implemented using special purpose logic circuitry, e.g., an FPGA (field programmable gate array) and/or an ASIC (application-specific integrated circuit). Processors suitable for the execution of a computer program include, by way of example, both general and special purpose microprocessors, and any one or more processors of any kind of digital computer. Generally, a processor will receive instructions and data from a read-only storage area or a random access storage area or both. Elements of a computer (including a server) include one or more processors for executing instructions and one or more storage area devices for storing instructions and data. Generally, a computer will also include, or be operatively coupled to receive data from, or transfer data to, or both, one or more machine-readable storage media, such as mass PCBs for storing data, e.g., magnetic

**[p0030]**

, magneto-optical disks, or optical disks. Machine-readable storage media suitable for embodying computer program instructions and data include all forms of non-volatile storage area, including by way of example, semiconductor storage area devices, e.g., EPROM, EEPROM, and flash storage area devices; magnetic disks, e.g., internal hard disks or removable disks; magneto-optical disks; and CD-ROM and DVD-ROM disks.

**[p0031]**

Any “electrical connection” as used herein may imply a direct physical connection or a connection that includes intervening components but that nevertheless allows electrical signals (including wireless signals) to flow between connected components. Any appropriate “connection” involving electrical circuitry mentioned herein, unless stated otherwise, is an electrical connection and not necessarily a direct physical connection regardless of whether the word “electrical” is used to modify “connection”. Elements of different implementations described herein may be combined to form other embodiments not specifically set forth above. Elements may be left out of the structures described herein without adversely affecting their operation. Furthermore, various separate elements may be combined into one or more individual elements to perform the functions described herein.

## Figure captions

- **Figure 1A:** FIGS. 1A, 1B, 1C, and 1D show perspective views of example vacuum grippers.
- **Figure 2:** FIG. 2 shows a side view of an example vise gripper.
- **Figure 3:** FIG. 3 shows side views of an example jamming gripper operating to grip three different types of objects.
- **Figure 4:** FIG. 4 is a perspective view of an example machine claw.
- **Figure 5:** FIG. 5 is a perspective view of an example grasping gripper.
- **Figure 6:** FIG. 6 is a perspective view of an example grasping gripper having vacuum ports on both its fingers and the base.
- **Figure 7:** FIG. 7 is a perspective view of an example grasping gripper showing a different number and configuration of vacuum ports than those shown in FIG. 6 .
- **Figure 8:** FIG. 8 is a perspective view of an example grasping gripper showing one finger folded to expose a back-side vacuum port.
- **Figure 9:** FIG. 9 is a perspective view of an example grasping gripper showing a cannula extending from the base of the grasping gripper.
- **Figure 10:** FIG. 10 is a perspective view of an example grasping gripper showing a cannula extending from a fingertip of the grasping gripper.
- **Figure 11:** FIG. 11 is a perspective view of an example robot in a test system that employs a grasping gripper of the type described herein.
- **Figure 6:** FIG. 6 shows an example grasping gripper 41 of the type shown in FIG. 5 , which incorporates vacuum ports on one or more of the fingers and/or on the base. In this example, the grasping gripper of FIG. 6 includes all of the structure and function of the grasping gripper of FIG. 5 , including the different implementations described herein. However, this need not be the case in all implementations.
- **Figure 7:** FIG. 7 shows an implementation of a grasping gripper 55 of the type described herein having vacuum port numbers and configurations different than those shown in FIG. 6 . In FIG. 7 each circle represents a vacuum port. The numbers, sizes, shapes, and arrangements of vacuum ports on a grasping gripper may vary, and are not limited to the examples presented herein.
- **Figure 1A:** Some implementations of the grasping gripper described herein may include one or more of the following features, either alone in combination with the features described elsewhere herein. Some implementations of the grasping gripper described herein may also include one or more features of the grippers shown in FIGS. 1A, 1B, 1C, 1D , FIG. 2 , FIG. 3 , and/or FIG. 4 .

## Classifications

- B25J15/0616
- B25J15/0616
- B25J15/0616
- B25J15/0616
- B25J15/0009
- B25J15/06
- B25J15/10
- B25J15/10
- B25J15/10
- B25J15/10
- B25J15/10
- G01R31/28
- G01R31/2834
- G01R31/2834
- G01R31/2834
- G01R31/2893
- G01R31/2893
- G01R31/2893
- G01R31/2893
- G01R31/2896
- G01R31/2896
- G01R31/2896

## Cited patent documents

- [CN-103250109-A](https://patents.google.com/patent/CN103250109A/en) — APP
- [DE-10048096-A1](https://patents.google.com/patent/DE10048096A1/en) — APP
- [DE-10157174-A1](https://patents.google.com/patent/DE10157174A1/en) — APP
- [DE-102006061752-A1](https://patents.google.com/patent/DE102006061752A1/en) — APP
- [DE-102008027008-A1](https://patents.google.com/patent/DE102008027008A1/en) — APP
- [DE-10239694-A1](https://patents.google.com/patent/DE10239694A1/en) — APP
- [DE-19858154-A1](https://patents.google.com/patent/DE19858154A1/en) — APP
- [DE-2735632-C2](https://patents.google.com/patent/DE2735632C2/en) — APP
- [EP-1505464-A2](https://patents.google.com/patent/EP1505464A2/en) — APP
- [EP-1696289-A1](https://patents.google.com/patent/EP1696289A1/en) — APP
- [EP-1724676-A1](https://patents.google.com/patent/EP1724676A1/en) — APP
- [EP-2258521-A1](https://patents.google.com/patent/EP2258521A1/en) — APP
- [EP-2453325-A1](https://patents.google.com/patent/EP2453325A1/en) — APP
- [EP-2641136-A1](https://patents.google.com/patent/EP2641136A1/en) — APP
- [EP-3015932-A1](https://patents.google.com/patent/EP3015932A1/en) — APP
- [ES-2548037-T3](https://patents.google.com/patent/ES2548037T3/en) — APP
- [JP-2001050741-A](https://patents.google.com/patent/JP2001050741A/en) — APP
- [JP-2002120174-A](https://patents.google.com/patent/JP2002120174A/en) — APP
- [JP-2004049731-A](https://patents.google.com/patent/JP2004049731A/en) — APP
- [JP-2004148466-A](https://patents.google.com/patent/JP2004148466A/en) — APP
- [JP-2004316722-A](https://patents.google.com/patent/JP2004316722A/en) — APP
- [JP-2005148789-A](https://patents.google.com/patent/JP2005148789A/en) — APP
- [JP-2005342885-A](https://patents.google.com/patent/JP2005342885A/en) — APP
- [JP-2008207263-A](https://patents.google.com/patent/JP2008207263A/en) — APP
- [JP-2010158754-A](https://patents.google.com/patent/JP2010158754A/en) — APP
- [JP-2014151371-A](https://patents.google.com/patent/JP2014151371A/en) — APP,SEA
- [JP-H01146645-A](https://patents.google.com/patent/JPH01146645A/en) — APP
- [JP-H02250782-A](https://patents.google.com/patent/JPH02250782A/en) — APP
- [JP-H06190753-A](https://patents.google.com/patent/JPH06190753A/en) — APP
- [JP-H08257965-A](https://patents.google.com/patent/JPH08257965A/en) — APP
- [JP-H08323676-A](https://patents.google.com/patent/JPH08323676A/en) — APP,SEA
- [JP-H10254527-A](https://patents.google.com/patent/JPH10254527A/en) — APP
- [MX-2013005425-A](https://patents.google.com/patent/MX2013005425A/en) — APP
- [RU-2013125348-A](https://patents.google.com/patent/RU2013125348A/en) — APP
- [US-2002013675-A1](https://patents.google.com/patent/US20020013675A1/en) — APP
- [US-2003120391-A1](https://patents.google.com/patent/US20030120391A1/en) — APP
- [US-2004018631-A1](https://patents.google.com/patent/US20040018631A1/en) — APP
- [US-2004078114-A1](https://patents.google.com/patent/US20040078114A1/en) — APP
- [US-2004172164-A1](https://patents.google.com/patent/US20040172164A1/en) — APP
- [US-2004212626-A1](https://patents.google.com/patent/US20040212626A1/en) — APP
- [US-2005080515-A1](https://patents.google.com/patent/US20050080515A1/en) — APP
- [US-2005267637-A1](https://patents.google.com/patent/US20050267637A1/en) — APP
- [US-2005273198-A1](https://patents.google.com/patent/US20050273198A1/en) — APP
- [US-2006069466-A1](https://patents.google.com/patent/US20060069466A1/en) — APP
- [US-2006125806-A1](https://patents.google.com/patent/US20060125806A1/en) — APP
- [US-2006163939-A1](https://patents.google.com/patent/US20060163939A1/en) — APP
- [US-2006178775-A1](https://patents.google.com/patent/US20060178775A1/en) — APP
- [US-2008004632-A1](https://patents.google.com/patent/US20080004632A1/en) — APP
- [US-2008140258-A1](https://patents.google.com/patent/US20080140258A1/en) — APP
- [US-2008188983-A1](https://patents.google.com/patent/US20080188983A1/en) — APP
- [US-2008188986-A1](https://patents.google.com/patent/US20080188986A1/en) — APP
- [US-2008319557-A1](https://patents.google.com/patent/US20080319557A1/en) — APP
- [US-2009076655-A1](https://patents.google.com/patent/US20090076655A1/en) — APP
- [US-2009157226-A1](https://patents.google.com/patent/US20090157226A1/en) — APP
- [US-2009259337-A1](https://patents.google.com/patent/US20090259337A1/en) — APP
- [US-2009289591-A1](https://patents.google.com/patent/US20090289591A1/en) — APP
- [US-2010241270-A1](https://patents.google.com/patent/US20100241270A1/en) — APP
- [US-2011022216-A1](https://patents.google.com/patent/US20110022216A1/en) — APP
- [US-2011137463-A1](https://patents.google.com/patent/US20110137463A1/en) — SEA
- [US-2012191402-A1](https://patents.google.com/patent/US20120191402A1/en) — SEA
- [US-2012210817-A1](https://patents.google.com/patent/US20120210817A1/en) — APP
- [US-2013079928-A1](https://patents.google.com/patent/US20130079928A1/en) — APP
- [US-2013231778-A1](https://patents.google.com/patent/US20130231778A1/en) — APP
- [US-2013255426-A1](https://patents.google.com/patent/US20130255426A1/en) — APP
- [US-2014062516-A1](https://patents.google.com/patent/US20140062516A1/en) — APP
- [US-2014197652-A1](https://patents.google.com/patent/US20140197652A1/en) — SEA
- [US-4166543-A](https://patents.google.com/patent/US4166543A/en) — APP
- [US-4398110-A](https://patents.google.com/patent/US4398110A/en) — APP
- [US-4678952-A](https://patents.google.com/patent/US4678952A/en) — APP
- [US-4744039-A](https://patents.google.com/patent/US4744039A/en) — APP
- [US-4753569-A](https://patents.google.com/patent/US4753569A/en) — APP
- [US-4817017-A](https://patents.google.com/patent/US4817017A/en) — APP
- [US-5103941-A](https://patents.google.com/patent/US5103941A/en) — APP
- [US-5155423-A](https://patents.google.com/patent/US5155423A/en) — APP
- [US-5220261-A](https://patents.google.com/patent/US5220261A/en) — APP
- [US-5293107-A](https://patents.google.com/patent/US5293107A/en) — APP
- [US-5341289-A](https://patents.google.com/patent/US5341289A/en) — APP
- [US-5353386-A](https://patents.google.com/patent/US5353386A/en) — APP
- [US-5495410-A](https://patents.google.com/patent/US5495410A/en) — APP
- [US-5880956-A](https://patents.google.com/patent/US5880956A/en) — APP
- [US-6040109-A](https://patents.google.com/patent/US6040109A/en) — APP
- [US-6041274-A](https://patents.google.com/patent/US6041274A/en) — APP
- [US-6070109-A](https://patents.google.com/patent/US6070109A/en) — APP
- [US-6131296-A](https://patents.google.com/patent/US6131296A/en) — APP
- [US-6292715-B1](https://patents.google.com/patent/US6292715B1/en) — APP
- [US-6408224-B1](https://patents.google.com/patent/US6408224B1/en) — APP
- [US-6519860-B1](https://patents.google.com/patent/US6519860B1/en) — APP
- [US-6535794-B1](https://patents.google.com/patent/US6535794B1/en) — APP
- [US-6704619-B1](https://patents.google.com/patent/US6704619B1/en) — APP
- [US-6822412-B1](https://patents.google.com/patent/US6822412B1/en) — APP
- [US-6837892-B2](https://patents.google.com/patent/US6837892B2/en) — APP
- [US-6847922-B1](https://patents.google.com/patent/US6847922B1/en) — APP
- [US-6856863-B1](https://patents.google.com/patent/US6856863B1/en) — APP
- [US-6922610-B2](https://patents.google.com/patent/US6922610B2/en) — APP
- [US-6996456-B2](https://patents.google.com/patent/US6996456B2/en) — APP
- [US-7248012-B2](https://patents.google.com/patent/US7248012B2/en) — APP
- [US-7272524-B2](https://patents.google.com/patent/US7272524B2/en) — APP
- [US-7278222-B2](https://patents.google.com/patent/US7278222B2/en) — APP
- [US-7298385-B2](https://patents.google.com/patent/US7298385B2/en) — APP
- [US-7300240-B2](https://patents.google.com/patent/US7300240B2/en) — APP
- [US-7571025-B2](https://patents.google.com/patent/US7571025B2/en) — APP
- [US-7643907-B2](https://patents.google.com/patent/US7643907B2/en) — APP
- [US-7756608-B2](https://patents.google.com/patent/US7756608B2/en) — APP
- [US-8002716-B2](https://patents.google.com/patent/US8002716B2/en) — APP
- [US-8050797-B2](https://patents.google.com/patent/US8050797B2/en) — APP
- [US-8160205-B2](https://patents.google.com/patent/US8160205B2/en) — APP
- [US-8255462-B2](https://patents.google.com/patent/US8255462B2/en) — APP
- [US-8301421-B2](https://patents.google.com/patent/US8301421B2/en) — APP
- [US-8340820-B2](https://patents.google.com/patent/US8340820B2/en) — APP
- [US-8382174-B2](https://patents.google.com/patent/US8382174B2/en) — SEA
- [US-8410732-B2](https://patents.google.com/patent/US8410732B2/en) — APP
- [US-8457786-B2](https://patents.google.com/patent/US8457786B2/en) — APP
- [US-8571706-B2](https://patents.google.com/patent/US8571706B2/en) — APP
- [US-8571711-B2](https://patents.google.com/patent/US8571711B2/en) — APP
- [US-8614559-B2](https://patents.google.com/patent/US8614559B2/en) — APP
- [US-8756973-B2](https://patents.google.com/patent/US8756973B2/en) — APP
- [US-8774965-B2](https://patents.google.com/patent/US8774965B2/en) — APP
- [US-8779715-B2](https://patents.google.com/patent/US8779715B2/en) — APP
- [US-8812155-B2](https://patents.google.com/patent/US8812155B2/en) — APP
- [US-9248573-B2](https://patents.google.com/patent/US9248573B2/en) — APP
- [WO-2004071717-A1](https://patents.google.com/patent/WO2004071717A1/en) — APP
- [WO-2007099511-A2](https://patents.google.com/patent/WO2007099511A2/en) — APP
- [WO-2009107358-A1](https://patents.google.com/patent/WO2009107358A1/en) — APP
- [WO-2012066025-A1](https://patents.google.com/patent/WO2012066025A1/en) — APP
- [WO-9700454-A1](https://patents.google.com/patent/WO9700454A1/en) — APP

---

Generated by IPtorch. Verify legal conclusions against the official publication.
