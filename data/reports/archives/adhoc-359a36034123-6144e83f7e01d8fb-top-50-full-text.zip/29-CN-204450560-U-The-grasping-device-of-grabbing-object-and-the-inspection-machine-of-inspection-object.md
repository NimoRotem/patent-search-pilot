# 29. The grasping device of grabbing object and the inspection machine of inspection object

- **Archive rank:** 29 of 50
- **Publication:** [CN-204450560-U](https://patents.google.com/patent/CN204450560U/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/052685306/publication/CN204450560U?q=pn%3DCN204450560U)
- **Publication date:** 2015-07-08
- **Filing date:** 2014-11-12
- **Earliest priority:** 2013-11-12
- **Family:** 52685306
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** ORBOTECH LTD
- **Inventors:** D STEPHEN; G LARRYL; N YARUILY

## Abstract

The utility model provides a kind of grasping device for grabbing object, and described grasping device comprises: rigid bodies; Vacuum pad assembly, is attached to described rigid bodies, and described vacuum pad assembly comprises grip surface, and described grip surface is used for grasping described object when applying vacuum to described vacuum pad assembly; Actuator, for described vacuum pad assembly mobile relative to described rigid bodies; And vacuum generator, be positioned at contiguous described vacuum pad assembly place, and grasp described object for described vacuum being applied to described vacuum pad assembly to make described grip surface.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf000.png)

![Sketch 1 for CN-204450560-U](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf001.png)

![Sketch 2 for CN-204450560-U](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf002.png)

![Sketch 3 for CN-204450560-U](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf003.png)

![Sketch 4 for CN-204450560-U](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf004.png)

![Sketch 5 for CN-204450560-U](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf005.png)

![Sketch 6 for CN-204450560-U](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf006.png)

![Sketch 7 for CN-204450560-U](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf007.png)

![Sketch 8 for CN-204450560-U](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf008.png)

![Sketch 9 for CN-204450560-U](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf009.png)

![Sketch 10 for CN-204450560-U](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf009.png)

[Sketch 11](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf010.png)

![Sketch 11 for CN-204450560-U](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf010.png)

[Sketch 12](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf011.png)

![Sketch 12 for CN-204450560-U](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf011.png)

[Sketch 13](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf012.png)

![Sketch 13 for CN-204450560-U](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf012.png)

[Sketch 14](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf013.png)

![Sketch 14 for CN-204450560-U](https://nimo.iptorch.com/refdrawing/CN-204450560-U/pdf013.png)

## Claims

### Claim 1 (independent)

A gripper for grasping an object, characterized in that the gripper comprises: a.刚性主体(rigid main body)； a. Rigid main body (rigid main body); b.真空垫总成(vacuum pad assembly)，附装至所述刚性主体，所述真空垫总成包括抓持表面，所述抓持表面用于在对所述真空垫总成施加真空时抓持所述物体； b. a vacuum pad assembly attached to said rigid body, said vacuum pad assembly comprising a gripping surface for gripping when a vacuum is applied to said vacuum pad assembly holding said object; c.致动器，用于相对于所述刚性主体而移动所述真空垫总成；以及 c. an actuator for moving the vacuum pad assembly relative to the rigid body; and d.真空发生器，位于邻近所述真空垫总成处，并用于将所述真空施加至所述真空垫总成以使所述抓持表面抓持所述物体。 d. A vacuum generator located adjacent to said vacuum pad assembly for applying said vacuum to said vacuum pad assembly to cause said gripping surface to grip said object. 2.如权利要求1所述的抓持器，其特征在于，所述抓持表面包括耦合至所述真空发生器的多个孔。

### Claim 2

The gripper of claim 1, wherein the gripping surface includes a plurality of holes coupled to the vacuum generator. 3.如权利要求1所述的抓持器，其特征在于，所述真空垫总成包括多个单独的真空区(vacuum zone)。

### Claim 3

The gripper of claim 1, wherein the vacuum pad assembly includes a plurality of individual vacuum zones. 4.如权利要求1所述的抓持器，其特征在于，所述刚性主体包括中空部(hollow portion)，且其中所述真空发生器设置于所述刚性主体的所述中空部内。

### Claim 4

The gripper of claim 1, wherein the rigid body includes a hollow portion, and wherein the vacuum generator is disposed within the hollow portion of the rigid body. 5.如权利要求1所述的抓持器，其特征在于，还包括真空传感器，所述真空传感器用于监测由所述真空发生器产生的真空的至少一个参数，其中所述真空传感器设置于所述刚性主体的中空部内。

### Claim 5

The gripper of claim 1, further comprising a vacuum sensor for monitoring at least one parameter of the vacuum generated by the vacuum generator, wherein the vacuum sensor is disposed at within the hollow portion of the rigid body. 6.如权利要求1所述的抓持器，其特征在于，所述致动器利用刚性耦合器(rigid coupling)而被机械耦合至所述真空垫总成。

### Claim 6

The gripper of claim 1, wherein the actuator is mechanically coupled to the vacuum pad assembly using a rigid coupling. 7.如权利要求1所述的抓持器，其特征在于，所述真空垫总成包括真空垫总成框架及顶部，其中所述抓持表面设置于所述顶部上。

### Claim 7

The gripper of claim 1, wherein the vacuum pad assembly includes a vacuum pad assembly frame and a top, wherein the gripping surface is disposed on the top. 8.如权利要求7所述的抓持器，其特征在于，所述顶部相对于所述真空垫总成框架枢转并利用多个锁定构件(locking member)而被固定于定位上，从而使得所述顶部的所述抓持表面与所述物体的表面对齐。

### Claim 8

The gripper of claim 7, wherein said top is pivoted relative to said vacuum pad assembly frame and secured in position by a plurality of locking members such that The gripping surface of the top is aligned with the surface of the object. 9.如权利要求1所述的抓持器，其特征在于，所述真空发生器利用用 于将真空递送至所述真空垫总成的多个管道(pipe)而被耦合至所述真空垫总成。

### Claim 9

The gripper of claim 1, wherein the vacuum generator is coupled to the vacuum pad with a plurality of pipes for delivering vacuum to the vacuum pad assembly Assembly. 10.如权利要求9所述的抓持器，其特征在于，所述多个管道为短的刚性管道。

### Claim 10

The gripper of claim 9, wherein the plurality of tubes are short rigid tubes. 11.如权利要求1所述的抓持器，其特征在于，所述真空垫总成通过线性轨道(linear rail)附装至所述刚性主体且其中所述真空垫总成用于在所述线性轨道上滑动。

### Claim 11

The gripper of claim 1, wherein said vacuum pad assembly is attached to said rigid body by a linear rail and wherein said vacuum pad assembly is used in said slides on a linear track. 12.如权利要求11所述的抓持器，其特征在于，所述真空垫总成用于在由所述致动器产生的致动力致动下沿垂直方向在所述线性轨道上滑动。

### Claim 12

The gripper of claim 11, wherein said vacuum pad assembly is adapted to slide in a vertical direction on said linear track under actuation force generated by said actuator. 13.如权利要求11所述的抓持器，其特征在于，所述真空垫总成具有真空垫总成框架，所述真空垫总成框架附装至所述线性轨道。

### Claim 13

The gripper of claim 11, wherein the vacuum pad assembly has a vacuum pad assembly frame attached to the linear track. 14.如权利要求1所述的抓持器，其特征在于，还包括控制器，所述控制器使所述致动器相对于所述刚性主体而移动所述真空垫总成以执行对所述物体的抓持。

### Claim 14

The gripper of claim 1, further comprising a controller that causes the actuator to move the vacuum pad assembly relative to the rigid body to perform alignment of the vacuum pad assembly. grasping of the object. 15.如权利要求1所述的抓持器，其特征在于，还包括控制器，其中所述刚性主体用于相对于用以固持所述物体的机台(table)而移动，且其中所述控制器用于使所述致动器相对于所述刚性主体而移动所述真空垫总成以补偿所述机台高度的变化。

### Claim 15

The gripper of claim 1, further comprising a controller, wherein said rigid body is adapted to move relative to a table for holding said object, and wherein said A controller is configured to cause the actuator to move the vacuum pad assembly relative to the rigid body to compensate for variations in the table height. 16.如权利要求1所述的抓持器，其特征在于，所述致动器设置于所述刚性主体的中空部内。

### Claim 16

The gripper of claim 1, wherein the actuator is disposed within a hollow portion of the rigid body. 17.如权利要求1所述的抓持器，其特征在于，所述真空发生器为文丘里(Venturi)真空泵。

### Claim 17

The gripper of claim 1, wherein the vacuum generator is a Venturi vacuum pump. 18.一种用于检验物体的检验设备，其特征在于，所述检验设备包括：

### Claim 18 (independent)

An inspection device for inspecting an object, characterized in that the inspection device comprises: a.用于固持所述物体的机台； a. A machine for holding said object; b.位于所述机台上方的检验头，用于检验所述机台上的所述物体； b. an inspection head positioned above the machine table for inspecting the object on the machine table; c.用于抓持所述物体并在所述机台上移动所述物体的抓持器，所述抓持器包括： c. a gripper for gripping said object and moving said object on said machine table, said gripper comprising: i.刚性主体； i. Rigid body; ii.真空垫总成，附装至所述刚性主体，所述真空垫总成包括抓持表面，所述抓持表面用于在对所述真空垫总成施加真空时抓持所述物体； ii. a vacuum pad assembly attached to said rigid body, said vacuum pad assembly comprising a gripping surface for gripping said object when a vacuum is applied to said vacuum pad assembly; iii.致动器，用于相对于所述刚性主体而移动所述真空垫总成；以及 iii. an actuator for moving the vacuum pad assembly relative to the rigid body; and iv.真空发生器，位于邻近所述真空垫总成处，并用于对所述真空垫总成施加真空以使所述抓持表面抓持所述物体。 iv. A vacuum generator located adjacent to said vacuum pad assembly for applying a vacuum to said vacuum pad assembly to cause said gripping surface to grip said object. 19.如权利要求18所述的检验设备，其特征在于，所述抓持表面包括耦合至所述真空发生器的多个孔。

### Claim 19

The testing apparatus of claim 18, wherein the gripping surface includes a plurality of holes coupled to the vacuum generator. 20.如权利要求18所述的检验设备，其特征在于，所述真空垫总成包括多个单独的真空区。

### Claim 20

The inspection apparatus of claim 18, wherein the vacuum pad assembly includes a plurality of individual vacuum zones. 21.如权利要求18所述的检验设备，其特征在于，所述刚性主体包括中空部(hollow portion)，且其中所述真空发生器设置于所述刚性主体的所述中空部内。

### Claim 21

The inspection apparatus of claim 18, wherein the rigid body includes a hollow portion, and wherein the vacuum generator is disposed within the hollow portion of the rigid body. 22.如权利要求18所述的检验设备，其特征在于，还包括真空传感器，所述真空传感器用于监测由所述真空发生器产生的真空的至少一个参数，其中所述真空传感器设置于所述刚性主体的中空部内。

### Claim 22

The inspection apparatus of claim 18, further comprising a vacuum sensor for monitoring at least one parameter of the vacuum generated by the vacuum generator, wherein the vacuum sensor is disposed on the In the hollow part of the rigid body. 23.如权利要求18所述的检验设备，其特征在于，所述致动器利用刚性耦合器而被机械耦合至所述真空垫总成。

### Claim 23

The testing apparatus of claim 18, wherein the actuator is mechanically coupled to the vacuum pad assembly with a rigid coupler. 24.如权利要求18所述的检验设备，其特征在于，所述真空垫总成包括真空垫总成框架及顶部，其中所述抓持表面设置于所述顶部上。

### Claim 24

The inspection apparatus of claim 18, wherein the vacuum pad assembly comprises a vacuum pad assembly frame and a top, wherein the gripping surface is disposed on the top. 25.如权利要求24所述的检验设备，其特征在于，所述顶部相对于所述真空垫总成框架枢转并利用多个锁定构件而被固定于定位上，从而使得所述顶部的所述抓持表面与所述物体的表面对齐。

### Claim 25

The inspection apparatus of claim 24, wherein the top is pivoted relative to the vacuum pad assembly frame and is secured in position by a plurality of locking members such that all of the top The gripping surface is aligned with the surface of the object. 26.如权利要求18所述的检验设备，其特征在于，所述真空发生器利用用于将真空递送至所述真空垫总成的多个管道而被耦合至所述真空垫总成。

### Claim 26

The inspection apparatus of claim 18, wherein the vacuum generator is coupled to the vacuum pad assembly with a plurality of conduits for delivering vacuum to the vacuum pad assembly. 27.如权利要求26所述的检验设备，其特征在于，所述多个管道为短的刚性管道。

### Claim 27

The testing apparatus of claim 26, wherein the plurality of tubes are short rigid tubes. 28.如权利要求18所述的检验设备，其特征在于，所述真空垫总成通过线性轨道附装至所述刚性主体，且其中所述真空垫总成用于在所述线性轨道上滑动。

### Claim 28

The inspection apparatus of claim 18, wherein the vacuum pad assembly is attached to the rigid body by a linear track, and wherein the vacuum pad assembly is adapted to slide on the linear track . 29.如权利要求28所述的检验设备，其特征在于，所述真空垫总成用于在由所述致动器产生的致动力致动下沿垂直方向在所述线性轨道上滑动。

### Claim 29

The inspection apparatus of claim 28, wherein said vacuum pad assembly is adapted to slide in a vertical direction on said linear track under actuation by an actuation force generated by said actuator. 30.如权利要求18所述的检验设备，其特征在于，所述真空垫总成具有真空垫总成框架，所述真空垫总成框架附装至线性轨道。

### Claim 30

The inspection apparatus of claim 18, wherein the vacuum pad assembly has a vacuum pad assembly frame attached to a linear track. 31.如权利要求18所述的检验设备，其特征在于，还包括控制器，所述控制器使所述致动器相对于所述刚性主体而移动所述真空垫总成以执行对所述物体的抓持。

### Claim 31

The testing apparatus of claim 18 , further comprising a controller that causes the actuator to move the vacuum pad assembly relative to the rigid body to perform testing of the vacuum pad assembly. grasping of objects. 32.如权利要求18所述的检验设备，其特征在于，还包括控制器，其中所述刚性主体用于相对于用以固持所述物体的机台而移动，且其中所述控制器用于使所述致动器相对于所述刚性主体而移动所述真空垫总成以补偿所述机台高度的变化。

### Claim 32

The inspection apparatus of claim 18, further comprising a controller, wherein the rigid body is configured to move relative to a table for holding the object, and wherein the controller is configured to use The actuator moves the vacuum pad assembly relative to the rigid body to compensate for variations in the table height. 33.如权利要求18所述的检验设备，其特征在于，所述致动器设置于所述刚性主体的中空部内。

### Claim 33

The testing apparatus of claim 18, wherein the actuator is disposed within a hollow portion of the rigid body. 34.如权利要求18所述的检验设备，其特征在于，所述真空发生器为文丘里真空泵。

### Claim 34

The inspection apparatus of claim 18, wherein the vacuum generator is a venturi vacuum pump.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSConveying systems characterised by their application for specified purposes not otherwise provided forConveying systems characterised by their application for specified purposes not otherwise provided for for fragile or damageable materials or articlesConveying systems characterised by their application for specified purposes not otherwise provided for for fragile or damageable materials or articles for fragile sheets, e.g. glassLifting, gripping, or carrying means, for one or more sheets forming independent means of transport, e.g. suction cups, transport framesPERFORMING OPERATIONS; TRANSPORTINGHAND TOOLS; PORTABLE POWER-DRIVEN TOOLS; MANIPULATORSMANIPULATORS; CHAMBERS PROVIDED WITH MANIPULATION DEVICESGripping heads and other end effectorsGripping heads and other end effectors with vacuum or magnetic holding meansGripping heads and other end effectors with vacuum or magnetic holding means with vacuumPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSIndexing code relating to control or detection of the articles or the load carriers during conveyingControl or detectionControl or detection relating to the load carrier(s)PERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSIndexing code relating to control or detection of the articles or the load carriers during conveyingDetection meansSensorsPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSAspects relating to conveying systems for the manufacture of fragile sheetsControlled or contamination-free environments or clean space conditionsPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSAspects relating to conveying systems for the manufacture of fragile sheetsArrangements of vacuum systems or suction cupsPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippersDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippers provided with drive systems with rectilinear movements onlyPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSConveying systems characterised by their application for specified purposes not otherwise provided forConveying systems characterised by their application for specified purposes not otherwise provided for for fragile or damageable materials or articlesConveying systems characterised by their application for specified purposes not otherwise provided for for fragile or damageable materials or articles for fragile sheets, e.g. glassTransporting devices for sheet glass

Description

Translated from Chinese

ææç©ä½çææå¨åæ£éªç©ä½çæ£éªè®¾å¤Gripper for grasping objects and inspection equipment for inspecting objects

ææ¯é¢å

technical field

æè¿°å®æ½ä¾å¤§ä½èè¨æ¶åç¨äºææåç§»å¨åç§ç©ä½çæºæ¢°ç³»ç»ï¼æ´å

·ä½èè¨ï¼æ¶åä¸ç§ç¨äºææèçææ(ä¾å¦æ¶²æ¶æ¾ç¤º(LCD)é¢æ¿ç»ç)çææå¨æ»æãä»¥åä¸ç§å

æ¬è¯¥ææå¨æ»æçæ£éªè®¾å¤ã

The described embodiments relate generally to mechanical systems for gripping and moving various objects, and more particularly, to a gripper assembly for gripping thin sheets of material such as liquid crystal display (LCD) panel glass. Assemblies, and an inspection device comprising the gripper assembly.

èæ¯ææ¯

Background technique

æ¶²æ¶æ¾ç¤º(liquidÂ crystalÂ displayï¼LCD)é¢æ¿å

å«æ¶²æ¶ï¼æ¶²æ¶è¡¨ç°åºçµåºç¸å

³(electric-fieldÂ dependent)å

è°å¶ç¹æ§ãæ¶²æ¶æ¾ç¤ºé¢æ¿æå¸¸ç¨æ¥å¨ä»ä¼ çæºãèä¸åè®¡ç®æºå±å¹å°å¤§å±å¹ãé«æ¸

æ°åº¦çµè§å¨å

çåç§è£

ç½®ä¸­æ¾ç¤ºå¾ååå

¶ä»ä¿¡æ¯ãææºç©éµå¼LCDé¢æ¿æ¯ç±ä»¥ä¸å¤ä¸ªåè½å±ç»æçå¤æåå±å¼ç»æï¼åå

èï¼èèæ¶ä½ç®¡(TFT)ç»çåºæ¿ï¼å

å«èèæ¶ä½ç®¡ãå­å¨çµå®¹å¨ãç»ç´ çµæä»¥åäºèå¸çº¿ï¼æ»¤è²çç»çåºæ¿ï¼å

å«é»è²ç©éµåæ»¤è²çéµåä»¥åéæå

±ç¨çµæï¼ç±èé

°äºèºå¶æçååèï¼ä»¥åå®é

æ¶²æ¶ææï¼å

å«å¡æ/ç»çé´éä½ä»¥ç»´ææ°å½çLCDåå

ååº¦ã

A liquid crystal display (liquid crystal display; LCD) panel includes liquid crystals that exhibit electric-field dependent light modulation characteristics. Liquid crystal display panels are most commonly used to display images and other information in everything from fax machines and laptop computer screens to large-screen, high-definition televisions. The active matrix LCD panel is a complex layered structure composed of the following multiple functional layers: polarizing film; thin film transistor (TFT) glass substrate, including thin film transistors, storage capacitors, pixel electrodes and interconnection wiring; color filter glass substrate , including the black matrix and color filter array and transparent common electrode; the alignment film made of polyimide; and the actual liquid crystal material, including plastic/glass spacers to maintain the proper LCD cell thickness.

LCDé¢æ¿æ¯å¨é«åº¦åæ§çæ¡ä»¶ä¸å¨æ´åå®¤ç¯å¢ä¸­å¶é ï¼ä»¥ä½¿è¯çæå¤§åãç¶èï¼è®¸å¤LCDå ä¸ºå¶é ççµèä¸å¾ä¸è¢«ä¸¢å¼ã

LCD panels are manufactured in a clean room environment under highly controlled conditions to maximize yield. However, many LCDs have to be discarded due to manufacturing flaws.

å¦ä¸æè¿°ï¼ä¸ºæé«å¤æçµå­è£

ç½®(ä¾å¦LCDé¢æ¿)ççäº§è¯çï¼æ§è¡åç§æ£éªæ­¥éª¤æ¥è¯å«å¨å¶é è¿ç¨(process)çåä¸ªæ­¥éª¤æé´å¯è½åºç°çåç§ç¼ºé·ãå¯å¨åå¶é æ­¥éª¤ä¹é´æå¨å®ææ´ä¸ªå¶é è¿ç¨ä¹åæ§è¡ä¸è¿°æ£éªæ­¥éª¤ãä¸è¿°æ£éªè¿ç¨çä¸ä¸ªå®ä¾æ¯æµè¯æ¶²æ¶(LC)æ¾ç¤ºå¨åææºåå

äºæç®¡(OLED)æ¾ç¤ºå¨ä¸­æç¨çTFTéµåæ¯å¦å­å¨çµæ§ç¼ºé·ãä½¿ç¨åç§æ£éªè£

ç½®æ¥æ§è¡ä¸è¿°æµè¯ãå¯ç¨äºæ­¤ç§ç®ççå®ä¾æ§è£

ç½®å

æ¬ç±ä½äºç¾å½å å©ç¦å°¼äºå·å£ä½å¡(SanÂ Jose,California,USA)çå¥¥å®ç§ææéå

¬å¸(OrbotechÂ Ltd.)å¸å®çéµåæ£æ¥å¨(ArrayÂ Checker)AC5080ãä½ä¸ºå¦å¤ä¸ç§éæ©ï¼Â å¯ä½¿ç¨æå±é¢åçææ¯äººåæå·²ç¥çä¸å¯å¨å¸åºä¸è´­å¾ççµå­ææ£éªç³»ç»æ¥æ§è¡TFTéµåæµè¯ã

As mentioned above, to improve the production yield of complex electronic devices such as LCD panels, various inspection steps are performed to identify various defects that may arise during various steps of the manufacturing process. The inspection steps described above may be performed between manufacturing steps or after completion of the entire manufacturing process. An example of the above-mentioned inspection process is testing TFT arrays used in liquid crystal (LC) displays and organic light emitting diode (OLED) displays for electrical defects. The tests described above were performed using various inspection devices. An exemplary device that can be used for this purpose includes the Array Checker AC5080 commercially available from Orbotech Ltd., San Jose, California, USA. Alternatively, TFT array testing can be performed using commercially available e-beam inspection systems known to those skilled in the art.

å¨å

¸åçé¢æ¿æ£éªè®¾å¤ä¸­ï¼æ¬²è¢«æµè¯çLCDç»çé¢æ¿è¢«å®å

¨å°æ¾ç½®å¨å·¨å¤§çæ£éªæºå°ä¸ï¼ä¸æ£éªè£

å¤(ä¾å¦å

å­¦æå

çµ(electro-optical)æ£éªå¤´)ä½äºLCDé¢æ¿ç»çä¸æ¹ãå¨æ­¤ç§æ£éªä¸­ï¼éè¦å¿«éä¸åç¡®å°å¨æ£éªæºå°ä¸ç§»å¨å¾

æµLCDé¢æ¿ãå¨ä¸ä¸ªå®ä¾ä¸­ï¼ä»¥å¼ç¨æ¹å¼å¹¶å

¥æ¬æä¸­çç¾å½ä¸å©æ¡ç¬¬7,543,867å·éè¿°ä¸ç§ç¨äºLCDé¢æ¿å®ä½æä½ä¸­ççç©ºæä½ææå¨ãæéè¿°çé¢æ¿ææå¨å

æ¬ç¨ä»¥æ¥è§¦LCDé¢æ¿ççç©ºå«ä»¥åè¿æ¥è³æè¿°çç©ºå«çè½´ãå¨æ£éªæé´ï¼å¯è½¬å¨çç©ºå«åè½´æ»ææ¥ä¿è¿LCDé¢æ¿çè½¬å¨(æ ¡æ­£å¹³ç´åº¦(squaring))ã

In typical panel inspection equipment, the LCD glass panel to be tested is safely placed on a large inspection machine, and inspection equipment (such as an optical or electro-optical inspection head) is positioned above the LCD panel glass. In such inspection, it is necessary to move the LCD panel to be tested on the inspection machine quickly and accurately. In one example, US Patent No. 7,543,867, incorporated herein by reference, sets forth a vacuum operated gripper for use in LCD panel positioning operations. The illustrated panel gripper includes a vacuum pad to contact the LCD panel and a shaft connected to the vacuum pad. During inspection, the vacuum pad and shaft assembly can be rotated to facilitate rotation of the LCD panel (squaring).

æå±é¢åçä¸è¬ææ¯äººååºçè§£ï¼ä¸ºå®ç°é¢æ¿ç§»å¨ï¼ææé è¿è¾¹ç¼æ¥ç¢åºå°ææé¢æ¿ä»èé¿å

å¹²æ°æ£éªè¿ç¨ãå æ­¤ï¼éè¦æä¾æ°çãæ¹è¿çææå¨è®¾è®¡ã

Those of ordinary skill in the art will appreciate that for panel movement it is desirable to grip the panel close to the edges to securely grip it so as not to interfere with the inspection process. Therefore, there is a need to provide new and improved gripper designs.

å®ç¨æ°åå

å®¹

Utility model content

æ¬å®ç¨æ°åæ¶åç¨äºå®è´¨ä¸æ¶é¤ä¸è¿°åå

¶ä»ä¸ä¼ ç»ææå¨ç¸å

³èçé®é¢ä¸­çä¸æå¤ä¸ªé®é¢çæ¹æ³åç³»ç»ã

The present invention relates to methods and systems for substantially eliminating one or more of the above and other problems associated with conventional grippers.

æ ¹æ®æ¬å®ç¨æ°åçä¸ä¸ªæ¹é¢ï¼æä¾ä¸ç§ç¨äºææç©ä½çææå¨ï¼æè¿°ææå¨å

æ¬ï¼åæ§ä¸»ä½(rigidÂ mainÂ body)ï¼çç©ºå«æ»æ(vacuumÂ padÂ assembly)ï¼éè£

è³æè¿°åæ§ä¸»ä½ï¼æè¿°çç©ºå«æ»æå

æ¬ææè¡¨é¢ï¼æè¿°ææè¡¨é¢ç¨äºå¨å¯¹æè¿°çç©ºå«æ»ææ½å çç©ºæ¶æææè¿°ç©ä½ï¼è´å¨å¨ï¼ç¨äºç¸å¯¹äºæè¿°åæ§ä¸»ä½èç§»å¨æè¿°çç©ºå«æ»æï¼ä»¥åçç©ºåçå¨ï¼ä½äºé»è¿æè¿°çç©ºå«æ»æå¤ï¼å¹¶ç¨äºå°æè¿°çç©ºæ½å è³æè¿°çç©ºå«æ»æä»¥ä½¿æè¿°ææè¡¨é¢æææè¿°ç©ä½ã

According to one aspect of the present invention, there is provided a gripper for gripping an object, the gripper includes: a rigid main body; a vacuum pad assembly attached to the The rigid body, the vacuum pad assembly includes a gripping surface for gripping the object when a vacuum is applied to the vacuum pad assembly; an actuator for relative to the rigid body a main body to move the vacuum pad assembly; and a vacuum generator located adjacent to the vacuum pad assembly for applying the vacuum to the vacuum pad assembly to cause the gripping surface to grip the vacuum pad assembly object.

åç§å®æ½ä¾å

æ¬ï¼æè¿°ææè¡¨é¢å

æ¬è¦åè³æè¿°çç©ºåçå¨çå¤ä¸ªå­ã

Various embodiments include the gripping surface including a plurality of holes coupled to the vacuum generator.

åç§å®æ½ä¾å

æ¬ï¼æè¿°çç©ºå«æ»æå

æ¬å¤ä¸ªåç¬ççç©ºåº(vacuumÂ zone)ã

Various embodiments include that the vacuum pad assembly includes a plurality of individual vacuum zones.

åç§å®æ½ä¾å

æ¬ï¼æè¿°åæ§ä¸»ä½å

æ¬ä¸­ç©ºé¨(hollowÂ portion)ï¼ä¸å

¶ä¸­æè¿°çç©ºåçå¨è®¾ç½®äºæè¿°åæ§ä¸»ä½çæè¿°ä¸­ç©ºé¨å

ã

Various embodiments include: the rigid body includes a hollow portion, and wherein the vacuum generator is disposed within the hollow portion of the rigid body.

åç§å®æ½ä¾å

æ¬ï¼çç©ºä¼ æå¨ï¼ç¨äºçæµç±æè¿°çç©ºåçå¨äº§çççç©ºçè³å°ä¸ä¸ªåæ°ï¼å

¶ä¸­æè¿°çç©ºä¼ æå¨è®¾ç½®äºæè¿°ä¸»ä½çä¸­ç©ºé¨å

ã

Various embodiments include a vacuum sensor for monitoring at least one parameter of the vacuum generated by the vacuum generator, wherein the vacuum sensor is disposed within the hollow portion of the body.

åç§å®æ½ä¾å

æ¬ï¼æè¿°è´å¨å¨å©ç¨åæ§è¦åå¨(rigidÂ coupling)èè¢«æºæ¢°è¦åè³æè¿°çç©ºå«æ»æã

Various embodiments include the actuator being mechanically coupled to the vacuum pad assembly using a rigid coupling.

åç§å®æ½ä¾å

æ¬ï¼æè¿°çç©ºå«æ»æå

æ¬çç©ºå«æ»ææ¡æ¶åé¡¶é¨ï¼å

¶ä¸­æè¿°ææè¡¨é¢è®¾ç½®äºæè¿°é¡¶é¨ä¸ã

Various embodiments include the vacuum pad assembly including a vacuum pad assembly frame and a top, wherein the gripping surface is disposed on the top.

åç§å®æ½ä¾å

æ¬ï¼æè¿°é¡¶é¨ï¼ç¸å¯¹äºæè¿°çç©ºå«æ»ææ¡æ¶æ¢è½¬å¹¶å©ç¨å¤ä¸ªéå®æä»¶(lockingÂ member)èè¢«åºå®äºå®ä½ä¸ï¼ä»èä½¿å¾æè¿°é¡¶é¨çæè¿°ææè¡¨é¢ä¸æè¿°ç©ä½çè¡¨é¢å¯¹é½ã

Various embodiments include the top being pivotable relative to the vacuum pad assembly frame and secured in position with a plurality of locking members such that the gripping surface of the top is in contact with The surfaces of the objects are aligned.

åç§å®æ½ä¾å

æ¬ï¼æè¿°çç©ºåçå¨å©ç¨ç¨äºå°çç©ºééè³æè¿°çç©ºå«æ»æçå¤ä¸ªç®¡é(pipe)èè¢«è¦åè³æè¿°çç©ºå«æ»æã

Various embodiments include the vacuum generator being coupled to the vacuum pad assembly with a plurality of pipes for delivering vacuum to the vacuum pad assembly.

åç§å®æ½ä¾å

æ¬ï¼æè¿°å¤ä¸ªç®¡éæ¯ç­çåæ§ç®¡éã

Various embodiments include that the plurality of tubes are short rigid tubes.

åç§å®æ½ä¾å

æ¬ï¼æè¿°çç©ºå«æ»æéè¿çº¿æ§è½¨é(linearÂ rail)éè£

è³æè¿°ä¸»ä½ä¸å

¶ä¸­æè¿°çç©ºå«æ»æç¨äºå¨æè¿°çº¿æ§è½¨éä¸æ»å¨ã

Various embodiments include the vacuum pad assembly being attached to the body by a linear rail and wherein the vacuum pad assembly is adapted to slide on the linear rail.

åç§å®æ½ä¾å

æ¬ï¼æè¿°çç©ºå«æ»æç¨äºå¨ç±æè¿°è´å¨å¨äº§ççè´å¨åè´å¨ä¸æ²¿åç´æ¹åå¨æè¿°çº¿æ§è½¨éä¸æ»å¨ã

Various embodiments include the vacuum pad assembly for sliding in a vertical direction on the linear track under actuation by an actuation force generated by the actuator.

åç§å®æ½ä¾å

æ¬ï¼æè¿°çç©ºå«æ»ææ¡æ¶éè£

è³æè¿°çº¿æ§è½¨éã

Various embodiments include the vacuum pad assembly frame being attached to the linear track.

åç§å®æ½ä¾å

æ¬ï¼æ§å¶å¨ï¼æè¿°æ§å¶å¨ä½¿æè¿°è´å¨å¨ç¸å¯¹äºæè¿°ä¸»ä½èç§»å¨æè¿°çç©ºå«æ»æä»¥æ§è¡å¯¹æè¿°ç©ä½çææã

Various embodiments include a controller that causes the actuator to move the vacuum pad assembly relative to the body to perform the grasping of the object.

åç§å®æ½ä¾å

æ¬ï¼æ§å¶å¨ï¼å

¶ä¸­æè¿°åæ§ä¸»ä½ç¨äºç¸å¯¹äºç¨ä»¥åºææè¿°ç©ä½çæºå°(table)èç§»å¨ï¼ä¸å

¶ä¸­æè¿°æ§å¶å¨ç¨äºä½¿æè¿°è´å¨å¨ç¸å¯¹äºæè¿°ä¸»ä½èç§»å¨æè¿°çç©ºå«æ»æä»¥è¡¥å¿æè¿°æºå°é«åº¦çååã

Various embodiments include a controller, wherein the rigid body is configured to move relative to a table for holding the object, and wherein the controller is configured to cause the actuator to move relative to the body to move the vacuum pad assembly to compensate for variations in the machine height.

åç§å®æ½ä¾å

æ¬ï¼æè¿°è´å¨å¨è®¾ç½®äºæè¿°åæ§ä¸»ä½çä¸­ç©ºé¨å

ã

Various embodiments include that the actuator is disposed within a hollow portion of the rigid body.

å¨åç§å®æ½ä¾ä¸­ï¼æè¿°çç©ºåçå¨ä¸ºæä¸é(Venturi)çç©ºæ³µã

In various embodiments, the vacuum generator is a Venturi vacuum pump.

æ ¹æ®æ¬å®ç¨æ°åçå¦ä¸æ¹é¢ï¼æä¾ä¸ç§ç¨äºæ£éªç©ä½çæ£éªè®¾å¤ï¼æè¿°æ£éªè®¾å¤å

æ¬ï¼ç¨äºåºææè¿°ç©ä½çæºå°ï¼ä½äºæè¿°æºå°ä¸æ¹çæ£éªå¤´ï¼ç¨äºæ£éªæè¿°æºå°ä¸çæè¿°ç©ä½ï¼ç¨äºæææè¿°ç©ä½å¹¶å¨æè¿°æºå°ä¸ç§»å¨æè¿°ç©ä½çææå¨ï¼æè¿°ææå¨å

æ¬ï¼åæ§ä¸»ä½ï¼çç©ºå«æ»æï¼éè£

è³æè¿°åæ§ä¸»ä½ï¼æè¿°çç©ºå«æ»æå

æ¬ææè¡¨é¢ï¼æè¿°ææè¡¨é¢ç¨äºå¨å¯¹æè¿°çç©ºå«æ»ææ½å çç©ºæ¶æææè¿°ç©ä½ï¼è´å¨å¨ï¼ç¨äºç¸å¯¹äºæè¿°åæ§ä¸»ä½èç§»å¨æè¿°çç©ºå«æ»æï¼ä»¥åçç©ºåçå¨ï¼ä½äºé»è¿æè¿°çç©ºå«æ»æå¤ï¼å¹¶ç¨äºå¯¹æè¿°çç©ºå«æ»ææ½å çç©ºä»¥ä½¿æè¿°ææè¡¨é¢æææè¿°ç©ä½ã

According to another aspect of the utility model, there is provided an inspection device for inspecting an object, the inspection device includes: a machine table for holding the object; an inspection head located above the machine table for inspection said object on said machine table; a gripper for gripping said object and moving said object on said machine table, said gripper comprising: a rigid body; a vacuum pad assembly attached to the rigid body, the vacuum pad assembly including a gripping surface for gripping the object when a vacuum is applied to the vacuum pad assembly; an actuator for relative to the a rigid body to move the vacuum pad assembly; and a vacuum generator located adjacent to the vacuum pad assembly and configured to apply a vacuum to the vacuum pad assembly to cause the gripping surface to grip the object.

åç§å®æ½ä¾å

æ¬ï¼æè¿°ææè¡¨é¢å

æ¬è¦åè³æè¿°çç©ºåçå¨çå¤ä¸ªå­ã

Various embodiments include the gripping surface including a plurality of holes coupled to the vacuum generator.

åç§å®æ½ä¾å

æ¬ï¼æè¿°çç©ºå«æ»æå

æ¬å¤ä¸ªåç¬ççç©ºåºã

Various embodiments include that the vacuum pad assembly includes a plurality of individual vacuum zones.

åç§å®æ½ä¾å

æ¬ï¼æè¿°åæ§ä¸»ä½å

æ¬ä¸­ç©ºé¨ï¼ä¸å

¶ä¸­æè¿°çç©ºåçå¨è®¾ç½®äºæè¿°åæ§ä¸»ä½çæè¿°ä¸­ç©ºé¨å

ã

Various embodiments include: the rigid body includes a hollow, and wherein the vacuum generator is disposed within the hollow of the rigid body.

åç§å®æ½ä¾å

æ¬ï¼çç©ºä¼ æå¨ï¼ç¨äºçæµç±æè¿°çç©ºåçå¨äº§çççç©ºçè³å°ä¸ä¸ªåæ°ï¼å

¶ä¸­æè¿°çç©ºä¼ æå¨è®¾ç½®äºæè¿°ä¸»ä½çä¸­ç©ºé¨å

ã

Various embodiments include a vacuum sensor for monitoring at least one parameter of the vacuum generated by the vacuum generator, wherein the vacuum sensor is disposed within the hollow portion of the body.

åç§å®æ½ä¾å

æ¬ï¼æè¿°è´å¨å¨å©ç¨åæ§è¦åå¨èè¢«æºæ¢°è¦åè³æè¿°çÂ ç©ºå«æ»æã

Various embodiments include the actuator being mechanically coupled to the vacuum pad assembly using a rigid coupler.

åç§å®æ½ä¾å

æ¬ï¼æè¿°çç©ºå«æ»æå

æ¬çç©ºå«æ»ææ¡æ¶åé¡¶é¨ï¼å

¶ä¸­æè¿°ææè¡¨é¢è®¾ç½®äºæè¿°é¡¶é¨ä¸ã

Various embodiments include the vacuum pad assembly including a vacuum pad assembly frame and a top, wherein the gripping surface is disposed on the top.

åç§å®æ½ä¾å

æ¬ï¼æè¿°é¡¶é¨ç¸å¯¹äºæè¿°çç©ºå«æ»ææ¡æ¶æ¢è½¬å¹¶å©ç¨å¤ä¸ªéå®æä»¶èè¢«åºå®äºå®ä½ä¸ï¼ä»èä½¿å¾æè¿°é¡¶é¨çæè¿°ææè¡¨é¢ä¸æè¿°ç©ä½çè¡¨é¢å¯¹é½ã

Various embodiments include the top pivoting relative to the vacuum pad assembly frame and secured in position with a plurality of locking members such that the gripping surface of the top is aligned with the surface of the object align.

åç§å®æ½ä¾å

æ¬ï¼æè¿°çç©ºåçå¨å©ç¨ç¨äºå°çç©ºééè³æè¿°çç©ºå«æ»æçå¤ä¸ªç®¡éèè¢«è¦åè³æè¿°çç©ºå«æ»æã

Various embodiments include the vacuum generator being coupled to the vacuum pad assembly with a plurality of conduits for delivering vacuum to the vacuum pad assembly.

åç§å®æ½ä¾å

æ¬ï¼æè¿°å¤ä¸ªç®¡éæ¯ç­çåæ§ç®¡éã

Various embodiments include that the plurality of tubes are short rigid tubes.

åç§å®æ½ä¾å

æ¬ï¼æè¿°çç©ºå«æ»æéè¿çº¿æ§è½¨ééè£

è³æè¿°ä¸»ä½ï¼ä¸å

¶ä¸­æè¿°çç©ºå«æ»æç¨äºå¨æè¿°çº¿æ§è½¨éä¸æ»å¨ã

Various embodiments include the vacuum pad assembly being attached to the body by a linear track, and wherein the vacuum pad assembly is adapted to slide on the linear track.

åç§å®æ½ä¾å

æ¬ï¼æè¿°çç©ºå«æ»æç¨äºå¨ç±æè¿°è´å¨å¨äº§ççè´å¨åè´å¨ä¸æ²¿åç´æ¹åå¨æè¿°çº¿æ§è½¨éä¸æ»å¨ã

Various embodiments include the vacuum pad assembly for sliding in a vertical direction on the linear track under actuation by an actuation force generated by the actuator.

åç§å®æ½ä¾å

æ¬ï¼æè¿°çç©ºå«æ»ææ¡æ¶éè£

è³æè¿°çº¿æ§è½¨éã

Various embodiments include the vacuum pad assembly frame being attached to the linear track.

åç§å®æ½ä¾å

æ¬ï¼æ§å¶å¨ï¼æè¿°æ§å¶å¨ä½¿æè¿°è´å¨å¨ç¸å¯¹äºæè¿°ä¸»ä½èç§»å¨æè¿°çç©ºå«æ»æä»¥æ§è¡å¯¹æè¿°ç©ä½çææã

Various embodiments include a controller that causes the actuator to move the vacuum pad assembly relative to the body to perform the grasping of the object.

åç§å®æ½ä¾å

æ¬ï¼æ§å¶å¨ï¼å

¶ä¸­æè¿°åæ§ä¸»ä½ç¨äºç¸å¯¹äºç¨ä»¥åºææè¿°ç©ä½çæºå°èç§»å¨ï¼ä¸å

¶ä¸­æè¿°æ§å¶å¨ç¨äºä½¿æè¿°è´å¨å¨ç¸å¯¹äºæè¿°ä¸»ä½èç§»å¨æè¿°çç©ºå«æ»æä»¥è¡¥å¿æè¿°æºå°é«åº¦çååã

Various embodiments include a controller, wherein the rigid body is configured to move relative to a table for holding the object, and wherein the controller is configured to move the actuator relative to the body The vacuum pad assembly is used to compensate for changes in the machine height.

åç§å®æ½ä¾å

æ¬ï¼æè¿°è´å¨å¨è®¾ç½®äºæè¿°åæ§ä¸»ä½çä¸­ç©ºé¨å

ã

Various embodiments include that the actuator is disposed within a hollow portion of the rigid body.

å¨åç§å®æ½ä¾ä¸­ï¼æè¿°çç©ºåçå¨ä¸ºæä¸éçç©ºæ³µã

In various embodiments, the vacuum generator is a venturi vacuum pump.

ä¸æ¬å®ç¨æ°åç¸å

³çå

¶ä»æ¹é¢å°å¨ä»¥ä¸è¯´æä¸­äºä»¥é¨åå°éè¿°ï¼ä¸å°éè¿æ¬è¯´æèé¨åå°åå¾æ¾èæè§æå¯éè¿å®è·µæ¬å®ç¨æ°åèå¾ç¥ãæ¬å®ç¨æ°åçåä¸ªæ¹é¢å¯éè¿åå

ä»¶åéè¿å¨ä»¥ä¸è¯¦ç»è¯´æåééæå©è¦æ±ä¹¦ä¸­æç¹å«æåºçåç§å

ä»¶ä»¥ååä¸ªæ¹é¢çç»åæ¥å®ç°åè·å¾ã

Other aspects related to the utility model will be partly set forth in the following description, and will be partly apparent through the description or can be learned by practicing the utility model. Various aspects of the present invention can be realized and obtained by means of various elements and combinations of various elements and aspects particularly pointed out in the following detailed description and appended claims.

åºçè§£ï¼ä»¥ä¸è¯´æåä»¥ä¸è¯´æäºè

ä»

ä¸ºå®ä¾æ§çåè§£éæ§çï¼èå¹¶éæ¨å¨ä»¥ä»»ä½æ¹å¼éå¶æ¬å®ç¨æ°ååæ¬å®ç¨æ°åçåºç¨ã

It should be understood that both the above description and the following description are only exemplary and explanatory, and are not intended to limit the utility model and the application of the utility model in any way.

éå¾è¯´æ

Description of drawings

å¹¶å

¥æ¬è¯´æä¹¦ä¸­å¹¶æææ¬è¯´æä¹¦ä¸é¨åçéå¾ä¾ç¤ºæ¬å®ç¨æ°åçå®æ½ä¾ï¼å¹¶ä¸æ¬è¯´æä¸èµ·è§£éåä¾ç¤ºæ¬å®ç¨æ°åçåçãå

·ä½èè¨ï¼

The accompanying drawings, which are incorporated in and constitute a part of this specification, illustrate embodiments of the invention and, together with the description, explain and illustrate the principle of the invention. in particular:

å¾1ä¾ç¤ºææå¨æ»æçå®ä¾æ§å®æ½ä¾çæ»ä½è§å¾ï¼

Figure 1 illustrates a general view of an example embodiment of a gripper assembly;

å¾2ä¾ç¤ºå®è£

äºçç©ºå«å®è£

æ»æä¸ççç©ºå«æ»æçå®ä¾æ§å®æ½ä¾ï¼

Figure 2 illustrates an exemplary embodiment of a vacuum pad assembly mounted on a vacuum pad mounting assembly;

å¾3ä¾ç¤ºå®è£

äºçç©ºå«å®è£

æ»æä¸ççç©ºå«æ»æçå®ä¾æ§å®æ½ä¾çåè§å¾ï¼ä»¥å

3 illustrates a cross-sectional view of an exemplary embodiment of a vacuum pad assembly mounted on a vacuum pad mounting assembly; and

å¾4ä¾ç¤ºè®¾ç½®äºææå¨ä¸»ä½çä¸­ç©ºé¨ä¸­ççç©ºåçæ»æçå®ä¾æ§å®æ½ä¾ã

Figure 4 illustrates an example embodiment of a vacuum generating assembly disposed in the hollow of the gripper body.

å

·ä½å®æ½æ¹å¼

Detailed ways

å¨ä¸æè¯´æä¸­ï¼å°åèéå¾ï¼å¨åéå¾ä¸­ä»¥ç¸åç¼å·è¡¨ç¤ºç¸åçåè½å

ä»¶ãä¸è¿°éå¾ä»¥ä¾ç¤ºæ¹å¼èéä»¥éå¶æ¹å¼æ¾ç¤ºæ ¹æ®æ¬å®ç¨æ°ååççå

·ä½å®æ½ä¾åå®æ½æ¹æ¡ãå¯¹è¿äºå®æ½æ¹æ¡è¿è¡éå¸¸è¯¦ç»çè¯´æä»¥ä½¿æå±é¢åçææ¯äººåè½å¤å®è·µæ¬å®ç¨æ°åï¼ä¸åºçè§£ï¼å¨ä¸èç¦»æ¬å®ç¨æ°åçèå´åç²¾ç¥çæ¡ä»¶ä¸ï¼å¯å©ç¨å

¶ä»å®æ½æ¹æ¡ä»¥åå¯å¯¹åç§å

ä»¶è¿è¡ç»æä¸çæ¹åå/ææ¿ä»£ãå æ­¤ï¼ä»¥ä¸è¯¦ç»è¯´æä¸åºè¢«è§ä¸ºå

·æéå¶æä¹ã

In the following description, reference will be made to the accompanying drawings in which like numerals denote like functional elements. The above-mentioned drawings show specific examples and implementations according to the principles of the present invention by way of illustration and not by way of limitation. These embodiments are described in great detail to enable those skilled in the art to practice the invention, and it should be understood that other embodiments can be utilized and various modifications can be made without departing from the scope and spirit of the invention. Components undergo structural changes and/or substitutions. Accordingly, the following detailed description should not be viewed in a limiting sense.

æ ¹æ®æ¬ææè¿°çä¸æå¤ä¸ªå®æ½ä¾ï¼æä¾ä¸ç§ç¨äºæ¬è¿èçææ(ä¾å¦LCDé¢æ¿ç»ç)çé«ç²¾åº¦ææå¨æ»æãå¨ä¸æå¤ä¸ªå®æ½ä¾ä¸­ï¼æè¿°ææå¨æ»æç¨äºå¨æ£éªè®¾å¤çæ°æ¬æµ®æºå°(floatingÂ airÂ table)çæè¾¹æ»å¨ï¼ä»èÂ ä¿è¿LCDé¢æ¿ç»çå¨æ¬æµ®æºå°(floatingÂ table)ä¸ç§»å¨ãå¨ä¸æå¤ä¸ªå®æ½ä¾ä¸­ï¼ææå¨æ»æè¢«è®¾è®¡æå¨æ¬æµ®æºå°ä¸æ¹ä»¥é«çå éåº¦(10ç±³/ç§^2)åé«çéåº¦(2ç±³/ç§)æ¥ç§»å¨å¤§çLCDç»çé¢æ¿(ä¾å¦ï¼å°ºå¯¸ä¸º2ç±³Ã2ç±³)ãæºå°ç¨äºæ§è¡éå¸¸ç²¾ç¡®åå¯éå¤çç§»å¨ãç¨äºæ£éªç©ä½çæ£éªå¤´(ä¾å¦å

çµæ£éªå¤´)å¯å®ä½äºæºå°ä¸æ¹ä»¥å¯¹æºå°ä¸çç©ä½æ§è¡æ£éªã

According to one or more embodiments described herein, there is provided a high precision gripper assembly for handling thin sheet materials, such as LCD panel glass. In one or more embodiments, the gripper assembly is configured to slide alongside a floating air table of an inspection device, thereby facilitating the movement of the LCD panel glass on the floating air table . In one or more embodiments, the gripper assembly is designed to move a large LCD glass over a suspended platform with high acceleration (10 m/s^2) and high velocity (2 m/s) Panels (for example, with dimensions of 2 meters by 2 meters). Machine tables are used to perform very precise and repeatable movements. An inspection head for inspecting objects, such as a photoelectric inspection head, may be positioned above the machine table to perform inspection on the objects on the machine table.

å¾1ä¾ç¤ºææå¨æ»æ100çå®ä¾æ§å®æ½ä¾çæ»ä½è§å¾ãæç¤ºå®æ½ä¾å

æ¬ä¸»ä½101ä»¥åä¸¤ä¸ªçç©ºå«æ»æ102ï¼çç©ºå«æ»æ102å©ç¨å¤ä¸ªçç©ºå«å®è£

æ»æ103èè¢«å®è£

äºä¸»ä½101ä¸ãå¨ä¸æå¤ä¸ªå®æ½ä¾ä¸­ï¼ä¸»ä½101åçç©ºå«å®è£

æ»æ103æ¯ä¸­ç©ºçæºæ¢°ç»æï¼å

¶è¢«è®¾è®¡æå

·æé¢å®ååº¦(rigidity)åæ°ãå¨ä¸æå¤ä¸ªå®æ½ä¾ä¸­ï¼ä¸»ä½101å¯å©ç¨ææ¶(carriage)æ»æåè´å¨å¨(æªæ¾ç¤º)èç¸å¯¹äºæ£éªè®¾å¤çæ°æ¬æµ®æºå°èç§»å¨ãå¨ä¸æå¤ä¸ªå®æ½ä¾ä¸­ï¼ææå¨ä¸»ä½101å¯æé¿è¾¾æ°ç±³ä¸å¯æºå¸¦å¤ä¸ªçç©ºå«æ»æ102ä»¥å¨ç§»å¨æé´ä¸ºLCDç»çæä¾æ´å¥½çæ¯æã

FIG. 1 illustrates a general view of an example embodiment of a gripper assembly 100 . The illustrated embodiment includes a main body 101 and two vacuum pad assemblies 102 mounted to the main body 101 using a plurality of vacuum pad mounting assemblies 103 . In one or more embodiments, the main body 101 and the vacuum pad mounting assembly 103 are hollow mechanical structures designed to have predetermined rigidity parameters. In one or more embodiments, the main body 101 is movable relative to the air suspension platform of the inspection apparatus using a carriage assembly and actuator (not shown). In one or more embodiments, the gripper body 101 can be up to several meters long and can carry multiple vacuum pad assemblies 102 to provide better support for the LCD glass during movement.

å¾2ä¾ç¤ºå®è£

äºçç©ºå«å®è£

æ»æ103ä¸ççç©ºå«æ»æ102çå®ä¾æ§å®æ½ä¾ãåç

§å¾2ï¼çç©ºå«æ»æ102å

å«å

·æææè¡¨é¢201çé¡¶é¨207ï¼ææè¡¨é¢201è¢«è®¾è®¡æå©ç¨çç©ºææææ¯èéè£

è³æ¬²è¢«ç§»å¨çç©ä½ï¼ä¾å¦LCDç»çé¢æ¿ãä¸ºæ­¤ï¼ææè¡¨é¢201ç±å

·æå¤§éå¾®å°å°ºå¯¸çå­çææå¶æãä¸¾ä¾èè¨ï¼ææè¡¨é¢201å¯ä¸ºå

·æå©ç¨ä¾å¦æ¿å

é»å­(laserÂ drilling)èå¨å

¶ä¸­é»å¶å¤§éå¾®å­çéå±æ¿æ¡(strip)ãææè¡¨é¢201ä¸­çåè¿°å¾®å­æç»å­(pore)ä¸ä»¥ä¸æè¯¦ç»éè¿°ççç©ºå«æ»æ102ççç©ºç³»ç»è¦åãå

·æææè¡¨é¢201ççç©ºå«æ»æçé¡¶é¨207å©ç¨å¤ä¸ªéå®æä»¶205ä»¥åå¤ä¸ªç´§åºä»¶208èè¢«å®è£

äºçç©ºå«æ»ææ¡æ¶206ä¸ã

FIG. 2 illustrates an exemplary embodiment of a vacuum pad assembly 102 mounted on a vacuum pad mounting assembly 103 . Referring to FIG. 2, the vacuum pad assembly 102 includes a top 207 having a gripping surface 201 designed to be attached to an object to be moved, such as an LCD glass panel, using vacuum gripping techniques. To this end, the gripping surface 201 is made of a material having a large number of micro-sized pores. For example, the gripping surface 201 may be a metal strip having a large number of micro-holes drilled therein using eg laser drilling. The aforementioned micropores or pores in the gripping surface 201 are coupled to the vacuum system of the vacuum pad assembly 102 explained in detail below. The top 207 of the vacuum pad assembly having the gripping surface 201 is mounted on the vacuum pad assembly frame 206 using a plurality of locking members 205 and a plurality of fasteners 208 .

å¨ä¸æå¤ä¸ªå®æ½ä¾ä¸­ï¼çç©ºå«æ»æ102å¯ç¸å¯¹äºææå¨ä¸»ä½101èæ²¿Z(åç´)æ¹åç§»å¨ãä¸ºæ­¤ï¼çç©ºå«æ»ææ¡æ¶206è¢«å¯æ»å¨å°å®è£

äºZçº¿æ§è½¨é202ä¸ï¼èZçº¿æ§è½¨é202åç¸åºå°è¢«éè£

è³çç©ºå«å®è£

æ»æ103ãå¨ä¸æå¤ä¸ªå®æ½ä¾ä¸­ï¼çç©ºå«å®è£

æ»ææ¡æ¶206ç¨äºå¨ä½äºææå¨ä¸»ä½101çä¸­ç©ºé¨204å

çZè´å¨å¨203çæºæ¢°è´å¨ä¸æ²¿åç´æ¹åå¨Zçº¿æ§è½¨é202ä¸æ»å¨ãæå±é¢åçææ¯äººååºçè§£ï¼å¯å°è¢«è´å¨çZ-èªç±åº¦çå¯ç¨æ§(availability)ç¨äºææè¿å¨å¹¶ç¨äºè¡¥å¿æ£éªæºå°çé«åº¦ç¸å¯¹äºææÂ å¨è½´çº¿çåç´ä½ç½®çååã

In one or more embodiments, the vacuum pad assembly 102 is movable in the Z (vertical) direction relative to the gripper body 101 . To this end, the vacuum pad assembly frame 206 is slidably mounted on the Z linear rail 202 which in turn is attached to the vacuum pad mounting assembly 103 . In one or more embodiments, the vacuum pad mounting assembly frame 206 is used to move vertically on the Z linear track 202 under the mechanical actuation of the Z actuator 203 located within the hollow portion 204 of the gripper body 101 slide. Those skilled in the art will understand that the availability of the actuated Z-degrees of freedom can be used for gripping motion and for compensating for changes in the vertical position of the inspection table's height relative to the gripper axis.

å¨ä¸æå¤ä¸ªå®æ½ä¾ä¸­ï¼å

·æææè¡¨é¢201ççç©ºå«æ»æçé¡¶é¨207ç¸å¯¹äºçç©ºå«æ»ææ¡æ¶206èå´ç»åç´(Z)è½´çº¿å¨æ°´å¹³(X,Y)å¹³é¢ä¸­æ¢è½¬ï¼ä¸å

¶ç¸å¯¹äºçç©ºå«æ»ææ¡æ¶206çä½ç½®æ¯å©ç¨å¤ä¸ªfxï¼fyéå®æä»¶205åå¤ä¸ªç´§åºä»¶208èè¢«åºå®äºæ°´å¹³X/Yå¹³é¢ä¸­ãå¨ä¸ä¸ªå®æ½ä¾ä¸­ï¼ç´§åºä»¶208ä¸ºèºéãæå±é¢åçä¸è¬ææ¯äººååºçè§£ï¼ææè¡¨é¢201çå®½åº¦å¯è¶³å¤å°ï¼ä»èä½¿å

¶å¯éè£

è³ä½äºèè¾¹ç¼åºåä¸­çLCDç»çï¼ä»¥ä¿è¯å

¶è¿å¨ä¸ä¼å¹²æ°ç¼ºé·æ£æµè¿ç¨ã

In one or more embodiments, the top 207 of the vacuum pad assembly having the gripping surface 201 pivots in the horizontal (X,Y) plane about a vertical (Z) axis relative to the vacuum pad assembly frame 206 and its The position relative to the vacuum pad assembly frame 206 is fixed in the horizontal X/Y plane using a plurality of fx, fy locking members 205 and a plurality of fasteners 208 . In one embodiment, the fasteners 208 are screws. Those of ordinary skill in the art will understand that the width of the gripping surface 201 can be small enough that it can be attached to the LCD glass in the thin edge region so that its movement does not interfere with the defect detection process.

å¾3ä¾ç¤ºå®è£

äºçç©ºå«å®è£

æ»æ103ä¸ççç©ºå«æ»æ102çå®ä¾æ§å®æ½ä¾çåè§å¾ãä»å¾3å¯ä»¥çåºï¼çç©ºå«æ»æçé¡¶é¨207å´ç»è£

å¤ææ¢è½´è½´æ¿(pivotÂ bearing)çæ¢è½´301èç¸å¯¹äºçç©ºå«æ»ææ¡æ¶206å¨æ°´å¹³(X,Y)å¹³é¢ä¸æ¢è½¬ãå¨ä¸æå¤ä¸ªå®æ½ä¾ä¸­ï¼æ¢è½´301ä¸ºçå½¢(sphere)æ¢è½´ãåºæ³¨æï¼æ¬å®ç¨æ°åå¹¶ä¸éå¶äºä½¿ç¨çå½¢æ¢è½´ï¼ä¸äº¦å¯ä½¿ç¨ä»»ä½å

¶ä»æºæ¢°éè£

ææ¯æ¥æä¾å¨åä¸ªèªç±åº¦ä¸çè¿å¨ã

FIG. 3 illustrates a cross-sectional view of an example embodiment of a vacuum pad assembly 102 mounted on a vacuum pad mounting assembly 103 . It can be seen from FIG. 3 that the top 207 of the vacuum pad assembly pivots in a horizontal (X,Y) plane relative to the vacuum pad assembly frame 206 about a pivot 301 equipped with pivot bearings. In one or more embodiments, the pivot 301 is a sphere pivot. It should be noted that the present invention is not limited to the use of spherical pivots, and any other mechanical attachment technique may be used to provide motion in various degrees of freedom.

å¨ä¸æå¤ä¸ªå®æ½ä¾ä¸­ï¼å©ç¨æ¢è½¬æ¥è°æ´ææè¡¨é¢201å¨æ°´å¹³(X,Y)å¹³é¢ä¸­ä»¥åå¯è½å¨åç´(Z)å¹³é¢ä¸­çååï¼ä»¥æ°å½å°å¯¹é½ææè¡¨é¢201ï¼ææè¡¨é¢201ç¨äºææå©ç¨ææå¨æç§»å¨çLCDç»ççè¾¹ç¼ãå

·ä½èè¨ï¼å«æ»æé¡¶é¨207ä»¥åææè¡¨é¢201çååè¢«è°æ´æä½¿ææè¡¨é¢201å®è´¨å¹³è¡äºLCDç»çãä¸æ¦è®¾å®ææè¡¨é¢201çæä½³ååï¼ææè¡¨é¢201ä¾¿ä¼å©ç¨éå®æä»¶205èè¢«ä¿æäºå®ä½ä¸ï¼éå®æä»¶205å¨ä¸ä¸ªå®æ½ä¾ä¸­ä¸ºèçéå±æ¿ã

In one or more embodiments, pivoting is used to adjust the orientation of the gripping surface 201 in the horizontal (X, Y) plane and possibly in the vertical (Z) plane to properly align the gripping surface 201, gripping Surface 201 is used to grip the edge of the LCD glass being moved by the gripper. Specifically, the orientation of pad assembly top 207 and gripping surface 201 is adjusted such that gripping surface 201 is substantially parallel to the LCD glass. Once the optimal orientation of the gripping surface 201 is set, the gripping surface 201 is held in position by the locking member 205, which in one embodiment is a thin metal plate.

å¨ä¸æå¤ä¸ªå®æ½ä¾ä¸­ï¼è´å¨å¨203å¯¹è´å¨å¨è½´303æ½å åç´(Z)è´å¨åï¼èè´å¨å¨è½´303åç¸åºå°å°æè¿°è´å¨åç»ç±åæ§è¦åå¨302ä¼ éè³çç©ºå«æ»ææ¡æ¶206ï¼ä»èä½¿çç©ºå«æ»ææ¡æ¶206æ²¿åç´æ¹å(åä¸æåä¸)ç§»å¨ãæè¿°è´å¨å¨203åå

¶æ§å¶ç³»ç»ç¨äºææLCDç»çãå¨ä¸æå¤ä¸ªå®æ½ä¾ä¸­ï¼è´å¨å¨203ä¹è¢«ç¨äºè¡¥å¿æ¬æµ®äºæ£éªè®¾å¤çæºå°ä¸çç»çä¸æºå°ä¹é´çé«åº¦å·®ãä¸¾ä¾èè¨ï¼å¨æ²¿Yè½´ç§»å¨ææå¨æé´ï¼å¯éæ¸è°æ´ææè¡¨é¢201çZä½ç½®ä»¥è¡¥å¿æºå°é«åº¦ååãå¨ä¸æå¤ä¸ªå®æ½ä¾ä¸­ï¼æè¿°ç³»Â ç»æ¯éè¿å©ç¨æºå°é«åº¦ä¼ æå¨è·å¾å¹¶å­å¨æ´ä¸ªæºå°ä¸çæºå°é«åº¦çæµéå¼èè¢«æ ¡åã

In one or more embodiments, the actuator 203 applies a vertical (Z) actuation force to the actuator shaft 303 which in turn transmits the actuation force to the vacuum pad via the rigid coupler 302 assembly frame 206 so that the vacuum pad assembly frame 206 moves in a vertical direction (up or down). The actuator 203 and its control system are used to grip the LCD glass. In one or more embodiments, the actuator 203 is also used to compensate for the height difference between the glass suspended on the table of the inspection apparatus and the table. For example, during movement of the gripper along the Y axis, the Z position of the gripping surface 201 can be gradually adjusted to compensate for machine height variations. In one or more embodiments, the system is calibrated by using a table height sensor to obtain and store measurements of table height across the table.

å¨ä¸æå¤ä¸ªå®æ½ä¾ä¸­ï¼è´å¨å¨203å¯ä¸ºæ¶²åè´å¨å¨ãçµæ§è´å¨å¨(ä¾å¦çµç£è´å¨å¨)ãåçµè´å¨å¨ãæºçµè´å¨å¨(ä¾å¦ç´çº¿çµå¨æº(linearÂ motor))ãææ°å¨è´å¨å¨ãå æ­¤ï¼è´å¨å¨203çç±»åå¯¹äºæè¿°å®æ½ä¾èè¨å¹¶éè³å

³éè¦ï¼ä¸å¯ä½¿ç¨ä»»ä½ç°å¨å·²ç¥æä»¥åå¼åçè´å¨å¨æ¥å®ç°çç©ºå«æ»æ102çåç´(Z-è½´)ç§»å¨ã

In one or more embodiments, the actuator 203 can be a hydraulic actuator, an electric actuator (such as an electromagnetic actuator), a piezoelectric actuator, an electromechanical actuator (such as a linear motor (linear motor) )), or pneumatic actuators. Thus, the type of actuator 203 is not critical to the described embodiment, and any now known or later developed actuator may be used to achieve vertical (Z-axis) movement of vacuum pad assembly 102 .

å¾4ä¾ç¤ºè®¾ç½®äºææå¨ä¸»ä½101çä¸­ç©ºé¨401ä¸­ççç©ºåçæ»æ400çå®ä¾æ§å®æ½ä¾ãæå±é¢åçææ¯äººååºçè§£ï¼éè¿å°ææå¨ä¸»ä½101å

ççç©ºåçæ»æ400ç´§é»çç©ºå«æ»æ102è®¾ç½®ï¼ä¾¿ä¸åéè¦è®¾ç½®ç¨äºå°çç©ºä¼ éè³ææå¨çé¿çææ§ç®¡éãå¨ä¸æå¤ä¸ªå®æ½ä¾ä¸­ï¼ç±äºå°çç©ºåçæ»æ400æå©å°æ¾ç½®äºææå¨ä¸»ä½101å

ï¼æä»¥å°çç©ºè½½éç®¡é403å¶æç­çååæ§çãè¿ä½¿å¾çç©ºåçæ»æ400å°æ´é«ççç©ºåº¦å¨æ´ç­æ¶é´å

ééè³çç©ºå«æ»æ102çè½åå¢å¼ºï¼ä»èä½¿æææ´ç¢åºä¸æ´å¿«ã

FIG. 4 illustrates an exemplary embodiment of a vacuum generating assembly 400 disposed in the hollow portion 401 of the gripper body 101 . Those skilled in the art will appreciate that by placing the vacuum generating assembly 400 within the gripper body 101 in close proximity to the vacuum pad assembly 102, the need for long flexible conduits for delivering vacuum to the gripper is eliminated. In one or more embodiments, due to the advantageous placement of the vacuum generating assembly 400 within the gripper body 101, the vacuum carrying tubing 403 is made short and rigid. This enhances the ability of the vacuum generating assembly 400 to deliver higher vacuum levels to the vacuum pad assembly 102 in less time, resulting in a firmer and faster grip.

å¨ä¸æå¤ä¸ªå®æ½ä¾ä¸­ï¼æ¯ä¸çç©ºå«æ»æ102è¢«ç»åæå¤ä¸ªçç©ºåºåãå¨ä¸æå¤ä¸ªå®æ½ä¾ä¸­ï¼å¯å°çç©ºå«æ»æ102ç»åææå¤è¾¾4ä¸ªç¬ç«ççç©ºåºåãåºåçç²¾ç¡®æ°ç®å¯ä¾å¨æ£éªè¿ç¨ä¸­æä½¿ç¨çææçç±»å(ä¾å¦LCDç»ç)èå®ãæå±é¢åçææ¯äººååºçè§£ï¼ä¸è¿°ç¬ç«çåºåä¼ç¡®ä¿å¨æè¿°å¤ä¸ªçç©ºåºåä¸­çä¸è

ä¸­æåççæ³æ¼ä¸ä¼å¯¹å

¶ä»çç©ºåºåä¸­ççç©ºå¼ºåº¦äº§çä¸å©å½±åã

In one or more embodiments, each vacuum pad assembly 102 is subdivided into a plurality of vacuum regions. In one or more embodiments, the vacuum pad assembly 102 can be subdivided into up to 4 separate vacuum regions. The exact number of regions may depend on the type of material (eg, LCD glass) used in the inspection process. Those skilled in the art will understand that the separate regions described above will ensure that a leak occurring in one of the plurality of vacuum regions will not adversely affect the vacuum strength in the other vacuum regions.

å¨ä¸æå¤ä¸ªå®æ½ä¾ä¸­ï¼å©ç¨é»è®¾äºçç©ºå«æ»æ102çæä¸éçç©ºæ³µ401ä¸ºææå¨å½¢æçç©ºãå¨ä¸æå¤ä¸ªå®æ½ä¾ä¸­ï¼æä¸éçç©ºæ³µ401æ¾ç½®äºææå¨ä¸»ä½101çä¸­ç©ºé¨404å

ï¼è¯·åè§å¾4ã

In one or more embodiments, a vacuum is created for the gripper using a venturi vacuum pump 401 adjacent to the vacuum pad assembly 102 . In one or more embodiments, a venturi vacuum pump 401 is placed within the hollow portion 404 of the gripper body 101 , see FIG. 4 .

æå±é¢åçææ¯äººååºçè§£ï¼ä½¿ç¨ä½ç½®ç´§é»çç©ºå«æ»æ102çæä¸éçç©ºæ³µ401ä¼ä½¿å¾å¨çç©ºå«æ»æ102å¤æ´å å¿«éä¸æ´å®¹æå°æå¼åå

³é­çç©ºãç¶èåºæ³¨æï¼æ¬å®ç¨æ°åå¹¶ä¸éå¶äºä½¿ç¨ææ­é²çæä¸éçç©ºæ³µï¼å¯å°ä»»ä½å

¶ä»çç©ºæ³µãçç©ºå·å°å¨(ejector)æä»»ä½å

¶ä»ç¨äºäº§ççç©ºçè£

ç½®ä¸æ¬æä¸­ææ­é²çææå¨è®¾è®¡è¿æ¥ä½¿ç¨ãå®ä¾æ§çç©ºåçè£

ç½®å

æ¬åè½¬Â å¼æ»çæ³µ(rotaryÂ vaneÂ pump)ãéèæ³µ(diaphragmÂ pump)ãæ¶²ç¯(liquidÂ ring)ãæ´»å¡æ³µ(pistonÂ pump)ãæ¶¡ææ³µ(scrollÂ pump)ãèºææ³µ(screwÂ pump)ãæ±ªå

å°æ³µ(wankelÂ pump)ãåå¿æè½¬æ³µ(externalÂ vaneÂ pump)ãå¢åæ³µ(boosterÂ pump)ãå¤çº§é²æ°æ³µ(multistageÂ RootsÂ pump)ãææ®åæ³µ(ToeplerÂ pump)æå¸è½®æ³µ(LobeÂ pump)ä»¥åä»»ä½å

¶ä»ç°å¨å·²ç¥æä»¥åå¼åççç©ºæ³µã

Those skilled in the art will understand that the use of a venturi vacuum pump 401 located in close proximity to the vacuum pad assembly 102 allows for faster and easier switching of the vacuum on and off at the vacuum pad assembly 102 . It should be noted, however, that the present invention is not limited to the use of the disclosed venturi vacuum pump, and that any other vacuum pump, vacuum ejector (ejector), or any other device for generating vacuum may be used with the gripper design disclosed herein. connection use. Exemplary vacuum generating devices include rotary vane pumps, diaphragm pumps, liquid rings, piston pumps, scroll pumps, screw pumps pump), Wankel pump, external vane pump, booster pump, multistage Roots pump, Toepler pump or cam Lobe pump and any other vacuum pump now known or later developed.

å¨ä¸æå¤ä¸ªå®æ½ä¾ä¸­ï¼ä¸ºæä¾å¯¹çç©ºå«æ»æ102å¤ççç©ºæ¡ä»¶çåé¦ï¼é»è¿æè¿°å«è®¾ç½®çç©ºä¼ æå¨402ãä¼ æå¨402å¯¹æ½å è³çç©ºå«æ»æ102ççç©ºæ¡ä»¶è¿è¡è®°å½å¹¶å°æ­¤åé¦æä¾è³æ§å¶ç³»ç»(æªæ¾ç¤º)ãå¨ä¸æå¤ä¸ªå®æ½ä¾ä¸­ï¼ææå¨çæ§å¶ç³»ç»è¿ç»­å°çæµçç©ºä¼ æå¨402çè¯»æ°(reading)ã

In one or more embodiments, to provide feedback on the vacuum conditions at the vacuum pad assembly 102, a vacuum sensor 402 is positioned adjacent to the pad. Sensor 402 records the vacuum conditions applied to vacuum pad assembly 102 and provides this feedback to a control system (not shown). In one or more embodiments, the gripper's control system continuously monitors the vacuum sensor 402 readings.

æå±é¢åçææ¯äººååºçè§£ï¼æ¬å®ç¨æ°åçææå¨æ»æçä¼ç¹å

æ¬ï¼æä¾å¿«éåæåææçè½åãå å

·æå¤ä¸ªçç©ºå«æ»æèä¸ºç»çæä¾å¥½çæ¯æãä»¥åè¡¥å¿ç»çæºå°é«åº¦ååçè½åã

Those skilled in the art will appreciate that the advantages of the gripper assembly of the present invention include the ability to provide a quick and strong grip, good support for the glass due to having multiple vacuum pad assemblies, and compensation for the glass machine. Ability to change table height.

æåï¼åºçè§£ï¼æ¬ææéè¿°çè¿ç¨åææ¯å¹¶ä¸åºæå°æ¶åä»»ä½ç¹å®çè®¾å¤ï¼ä¸å¯ç±ä»»ä½åéçç»ä»¶ç»åæ¥å®æ½ãæ­¤å¤ï¼å¯æ ¹æ®æ¬ææè¿°çæç¤ºå

å®¹æ¥ä½¿ç¨åç§ç±»åçéç¨è£

ç½®ãä¹å¯è¯ææé ä¸ç¨è®¾å¤æ¥æ§è¡æ¬ææè¿°çæ¹æ³æ­¥éª¤æ¯æå©çãå·²åç

§ç¹å®çå®ä¾éè¿°äºæ¬å®ç¨æ°åï¼æè¿°å®ä¾æ¨å¨æææ¹é¢åæ¯ä¾ç¤ºæ§çèééå¶æ§çã

Finally, it should be understood that the processes and techniques described herein are not inherently related to any particular device and may be implemented by any suitable combination of components. In addition, various types of general purpose devices can be used in accordance with the teachings described herein. It may also prove advantageous to construct dedicated apparatus to perform the method steps described herein. This invention has been described with reference to specific examples, which are intended in all respects to be illustrative and not restrictive.

æ­¤å¤ï¼æå±é¢åçææ¯äººåæ ¹æ®æ¬ææå

¬å¼å®ç¨æ°åçè¯´æä¹¦åå®è·µæ¬å®ç¨æ°åï¼å°æç¥æ¬å®ç¨æ°åçå

¶ä»å®æ½æ¹æ¡ãæè¿°å®æ½ä¾çåä¸ªæ¹é¢å/æç»ä»¶å¯å¨ç¨äºææèçææ(ä¾å¦LCDç»ç)çç³»ç»ä¸­åç¬ä½¿ç¨æä»¥ä»»ä½ç»åæ¹å¼ä½¿ç¨ãæ¬å®ç¨æ°åæ¨å¨ä½¿è¯´æä¹¦åå®ä¾ä»

è¢«è§ä¸ºå®ä¾æ§çï¼æ¬å®ç¨æ°åççæ­£èå´åç²¾ç¥ç±ä¸ææå©è¦æ±ä¹¦æç¤ºã

In addition, those skilled in the art will easily know other embodiments of the utility model according to the specification of the utility model disclosed herein and practicing the utility model. Various aspects and/or components of the described embodiments may be used alone or in any combination in a system for gripping thin sheet materials, such as LCD glass. It is intended that the specification and examples be considered illustrative only, with a true scope and spirit of the invention being indicated by the following claims.

## Classifications

- B65G49/061
- B25J11/00
- B25J15/06
- B25J15/0616
- B65G2203/0266
- B65G2203/042
- B65G2249/02
- B65G2249/04
- B65G47/912
- B65G49/063

---

Generated by IPtorch. Verify legal conclusions against the official publication.
