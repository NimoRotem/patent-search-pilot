# 19. Suction device

- **Archive rank:** 19 of 50
- **Publication:** [US-7992908-B2](https://patents.google.com/patent/US7992908B2/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/035395279/publication/US7992908B2?q=pn%3DUS7992908B2)
- **Publication date:** 2011-08-09
- **Filing date:** 2006-10-04
- **Earliest priority:** 2005-10-04
- **Family:** 35395279
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** CARGLASS LUXEMBOURG SARL ZUG
- **Inventors:** FINCK WILLIAM

## Abstract

A suction device has a flexible sucker membrane having a peripherally extending skirt, and an actuator arranged to act to reconfigure the sucker between a suction enhanced configuration and a suction released configuration. The actuator is also operable to lift an outer edge of the peripherally extending skirt which enables more convenient release of the suction device than would otherwise be possible.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-7992908-B2/000.png)

![Sketch 1 for US-7992908-B2](https://nimo.iptorch.com/refdrawing/US-7992908-B2/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/US-7992908-B2/001.png)

![Sketch 2 for US-7992908-B2](https://nimo.iptorch.com/refdrawing/US-7992908-B2/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/US-7992908-B2/002.png)

![Sketch 3 for US-7992908-B2](https://nimo.iptorch.com/refdrawing/US-7992908-B2/002.png)

## Claims

### Claim 1 (independent)

A suction device comprising: a flexible sucker having a peripherally extending skirt; a lever operable to: i) apply or release an activating force at a central region of the sucker to reconfigure the sucker between a suction released configuration and a suction enhanced configuration; and ii) lift an outer edge of the peripherally extending skirt, wherein the lever is movable in a first pivotal direction from a neutral position in order to reconfigure the sucker between the suction released configuration and the suction enhanced configuration, the lever being movable in an opposed pivotal direction from the neutral position in order to lift the outer edge of the peripherally extending skirt.

### Claim 2

A suction device according to claim 1 , wherein the lever has a first range of movement to apply the activating force to the central region of the sucker, and a second range of movement to lift the edge of the peripherally extending skirt.

### Claim 3

A suction device according to claim 1 , wherein the lever is operable to depress the central region of the sucker.

### Claim 4

A suction device according to claim 1 , including a mounting for mounting the sucker and the lever.

### Claim 5

A suction device according to claim 1 , wherein the lever is connected to an edge lifter linkage extending to a distal portion of the peripherally extending skirt.

### Claim 6

A suction device according to claim 5 , wherein the edge lifter linkage is guided to be movable in a guide arrangement.

### Claim 7

A suction arrangement according to claim 6 , wherein the guide arrangement comprises a guide channel formed in a mounting for the sucker and lever.

## Full description

### Background Of The Invention

**[p0001]**

1. Field of the Invention The present invention relates to a suction device, and in particular to a suction device including a flexible suction skirt. 2. State of the Art Suction devices are known having sucker membrane including a flexible sucker skirt extending from a flexible sucker body. Typically a mounting is provided to locate the sucker body and support a lever actuator arrangement which is manually operable to energize or de-energize the sucker. An exemplary suction device is disclosed, for example, in DE 20103755, in which a lever having a cam is movable to urge a cam follower pin to push down the concave dish of the flexible sucker body, so energizing or de-energizing the suction device. The suction device of DE 20103755 is provided with a lifting tab proximate the radially outer edge of the flexible sucker skirt, and a suction relieving groove on the underside of the flexible sucker membrane. The suction relieving groove aids in releasing the suction device when the lifting tab is lifted.

### Summary Of The Invention

**[p0002]**

An improved arrangement has now been devised. According to a first aspect, the present invention provides a suction device comprising: a flexible sucker having a peripherally extending skirt; an actuator operable to both: i) apply or release an activating force at a central region of the sucker to reconfigure the sucker between a suction released configuration and a suction applied configuration; and ii) lift an outer edge of the peripherally extending skirt. It is a beneficial feature of the invention that the actuator is operable to both act to activate the suction of the sucker and also act to lift the edge of the sucker membrane. Lifting the edge of the sucker membrane allows air to pass under the edge and aid in release of the sucker device. It is preferred that the a suction device includes a mounting for mounting the sucker and the actuator. Beneficially, the actuator comprises a lever, the lever preferably including a cam arrangement to act to apply the force on the sucker to reconfigure the sucker between the suction released configuration and the suction enhanced configuration. Desirably a cam follower is arranged to act to reconfigure the sucker.

**[p0003]**

In a preferred embodiment, the lever is movable in a first pivotal direction from a neutral position in order to reconfigure the sucker between the suction released configuration and the suction enhanced configuration, the lever being movable in an opposed pivotal direction from the neutral position in order to lift the outer edge of the peripherally extending skirt. It is preferred that the actuator is connected to an edge lifter linkage extending to a distal portion of the peripherally extending skirt. The edge lifter linkage is desirably guided to be movable in a guide arrangement. In a preferred embodiment, the guide arrangement comprises a guide channel formed in a mounting for the sucker and lever. According to an alternative aspect, the invention provides a suction device comprising: a flexible sucker having a peripherally extending skirt; a lever mounted to the sucker; the lever operating an elongate lifter element extending to the sucker skirt, the lifter element operable to lift the edge of the skirt upon operation of the lever.

**[p0004]**

Beneficially, a lifting tab is provided for the skirt, the elongate lifter element being linked to the lifting tab. The elongate lifter element is preferably flexible. It is preferred that the underside of the sucker membrane includes a suction relieving groove having a relatively wider mouth distal end toward the periphery of the sucker membrane and a relatively narrower proximal end toward the center of the sucker membrane. This has been found to aid in relieving the applied suction when the edge of the flexible skirt is lifted. The groove preferably extends outwardly onto the underside of the peripherally extending skirt, and is beneficially positioned radially in line with the lifting portion of the skirt. According to a further aspect, therefore, the present invention provides a suction device including a flexible sucker membrane having a peripherally extending skirt, the underside of the sucker membrane including a suction relieving groove having a relatively wider distal end toward the periphery of the sucker membrane and a relatively narrower proximal end toward the center of the sucker membrane.

**[p0005]**

Desirably, the suction relieving groove tapers from the relatively wider distal end toward the relatively narrower proximal end. In certain embodiments, devices in accordance with the invention will include a grab handle enabling the device to be used, for example, for lifting. Apparatus in accordance with the invention may make use of a plurality of suction devices, including one or more suction devices according to one or more aspects of the invention. A grab handle may be provided extending between two suction devices. Suction devices may be used for mounting one or more components or apparatus to a surface. For example suction devices according to the various aspects of the invention have utility in the activities of glazing panel replacement and repair for example for use in lifting glazing panels or mounting removal or repair apparatus to glazing panels. The invention will now be further described, by way of example only, with reference to the accompanying drawings.

### Brief Description Of The Drawings

**[p0006]**

FIG. 1 is a perspective view of a suction device in accordance with the invention; FIG. 2 is a side view of the device of FIG. 1 with the actuator lever in a neutral position; FIG. 3 is a side view of the device of FIG. 1 with actuator lever in suction relief configuration; FIG. 4 is a view of the underside of a suction device in accordance with the invention; and, FIG. 5 is a perspective view of two sucker grab handle apparatus in accordance with the invention.

### Detailed Description Of The Preferred Embodiments

**[p0007]**

Referring to the drawings, and initially to FIGS. 1 to 3 , there is shown a sucker device 1 for use in securing to generally gas impermeable surfaces such as, for example, glazing panels, enabling lifting or attachment of other apparatus. The device 1 comprises a hard plastics mounting shell 2 , to the underside of which is secured a flexible rubber membrane having a body disc 3 and an integral peripherally extending flexible skirt 4 . An actuation lever 6 is pivotally mounted at pivot 7 , to the hard plastics mounting shell 2 , the primary purpose of the actuation lever being to energize or de-energize the sucker. Such arrangements are known in the art and an exemplary such lever actuator arrangement is disclosed, for example, in DE 20103755, in which a lever having a cam is movable to urge a cam follower pin to push down the concave dish of the flexible sucker body 3 , so energizing or de-energizing the suction device. The present arrangement is designed to operate in this manner.

**[p0008]**

The lever 6 includes an aperture 10 locating a cross pin 11 , to which is attached the proximal end of a flexible link tether 15 . Flexible link tether 15 is connected at its distal end to a pull tab 17 which is formed integrally with the skirt 4 and projects upwardly therefrom. The purpose of the pull tab 17 is to enable the rim lip 18 of the flexible skirt to be selectively lifted in order to enable full release the suction applied by the device. The present invention enables the lip to be released by means of actuation remote from the rim lip 18 . Alternative means may be provided for securing the distal end of the flexible link tether 15 to the portion of the skirt to be lifted. In the embodiment shown, the flexible linkage is received in a guide channel 19 formed in the hard plastics mounting shell 2 . Referring to FIG. 2 , the device 1 is shown in with the actuator lever 6 in a neutral position standing upright from the hard plastics mounting shell 2 . In this position the vacuum is not fully applied and the rim lip 18 is not being lifted. In the energized configuration, with the actuator lever 6 pivoted forward (as shown in dashed line in FIG. 2 ), the cam action causes push down of the flexible sucker body 3 , so energizing the suction. In this arrangement the underside of the flexible skirt 4 is pressed face down against the substrate surface.

**[p0009]**

When seeking to release the applied suction, the lever 6 is returned to the neutral position and then pivoted forward over center (as shown in FIG. 3 ). This has the effect of causing flexible link tether 15 to slide in the direction of arrow A in guide channel 19 , pulling upwardly on pull tab 17 and on so doing, lifting the rim lip 18 of skirt 4 . This permits air to pass under the skirt and body of the sucker membrane 3 , relieving the applied suction. The suction device can then easily be lifted from the substrate surface. The present invention enables a lever or other actuator to be used to lift the rim lip of the skirt. By making this the primary suction application actuator lever 6 , convenient and single handed release actuation may be achieved. The other hand may be used to support the device, for example by means of gripping a grip handle. such an arrangement is shown in FIG. 5 , where a grip handle 21 extends between 2 suction devices 1 a , 1 b in accordance with the invention.

**[p0010]**

As most clearly shown in FIG. 4 , the sucker membrane is provided on its underside (the side arranged to contact the substrate surface) with a suction relieving groove 25 extending across the junction between the flexible skirt 4 and the flexible body 3 of the sucker membrane. The groove 25 provides a conduit enabling rapid pressure equalization when the rim lip 18 is sufficiently lifted. The pressure relieving groove 25 coincides substantially with the position of the lifting tab 17 . It has been found that the operation of the pressure relieving groove 25 is enhanced in configurations in which the groove 25 tapers from a relatively wider distal end 28 positioned toward the periphery of the sucker membrane to a relatively narrower proximal end 29 positioned toward the center of the sucker membrane. Additionally, the arrangement of the invention provides enhanced operation when securing the device to a substrate surface. This is achieved by placing the sucker device on the substrate surface and, with downward pressure applied via the device, first moving the lever 6 to the over-center position (as shown in FIG. 3 ), with downward force applied via the device to the substrate, before moving the lever 6 all the way forward to the energized position (shown by the dashed line in FIG. 2 ). The initial over-center movement with downward force applied lifts the skirt 4 and expels air from under the body 3 of the sucker membrane. This results in a greater vacuum effect.

## Figure captions

- **Figure 1:** FIG. 1 is a perspective view of a suction device in accordance with the invention;
- **Figure 2:** FIG. 2 is a side view of the device of FIG. 1 with the actuator lever in a neutral position;
- **Figure 3:** FIG. 3 is a side view of the device of FIG. 1 with actuator lever in suction relief configuration;
- **Figure 4:** FIG. 4 is a view of the underside of a suction device in accordance with the invention; and,
- **Figure 5:** FIG. 5 is a perspective view of two sucker grab handle apparatus in accordance with the invention.

## Classifications

- B25B11/007
- F16B47/00
- F16B47/00
- B25J15/06
- B65G49/061
- F16B47/00
- F16B47/006

## Cited patent documents

- [DE-20103755-U1](https://patents.google.com/patent/DE20103755U1/en) — APP
- [JP-2000126014-A](https://patents.google.com/patent/JP2000126014A/en) — APP
- [US-2127154-A](https://patents.google.com/patent/US2127154A/en) — SEA
- [US-2194989-A](https://patents.google.com/patent/US2194989A/en) — SEA
- [US-2212755-A](https://patents.google.com/patent/US2212755A/en) — SEA
- [US-2287576-A](https://patents.google.com/patent/US2287576A/en) — SEA
- [US-2474950-A](https://patents.google.com/patent/US2474950A/en) — SEA
- [US-4932701-A](https://patents.google.com/patent/US4932701A/en) — SEA
- [US-5405112-A](https://patents.google.com/patent/US5405112A/en) — SEA
- [US-5454540-A](https://patents.google.com/patent/US5454540A/en) — SEA
- [US-5516019-A](https://patents.google.com/patent/US5516019A/en) — SEA
- [US-5611511-A](https://patents.google.com/patent/US5611511A/en) — APP
- [US-5911394-A](https://patents.google.com/patent/US5911394A/en) — APP
- [US-6382692-B1](https://patents.google.com/patent/US6382692B1/en) — SEA
- [WO-9300549-A1](https://patents.google.com/patent/WO9300549A1/en) — APP

---

Generated by IPtorch. Verify legal conclusions against the official publication.
