# 48. Vacuum grippers

- **Archive rank:** 48 of 50
- **Publication:** [GB-2272420-A](https://patents.google.com/patent/GB2272420A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/010725188/publication/GB2272420A?q=pn%3DGB2272420A)
- **Publication date:** 1994-05-18
- **Filing date:** 1993-11-15
- **Earliest priority:** 1992-11-16
- **Family:** 10725188
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery

## Parties

- **Applicant / assignee:** PORTSMOUTH POLYTECH ENTPR; PORTSMOUTH TECH CONSULT
- **Inventors:** COLLIE ARTHUR ALEXANDER; HEWER NEAL DAVID

## Abstract

A vacuum gripper arrangement comprises a gripper device 1 having a body 2 and a seal 3 for contacting a supporting surface 5 to which the gripper device 1 is to be attached, a vacuum pump 6 connected to the gripper device 1, a compressed air source 8 and a two-way valve 9 for connecting the compressed air source 8 to the vacuum pump 6 for causing a vacuum to be formed between the gripper device 1 and the supporting surface 5 to cause it to be attached thereto, or for connecting the compressed air source to the gripper device 1 for causing a pressure to be formed between the gripper device 1 and the supporting surface 5, to cause it to be at least partially lifted from the surface 5. Preferably a variable resistance 13 is provided in the air supply side 12. &lt;IMAGE&gt;

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/GB-2272420-A/pdf000.png)

![Sketch 1 for GB-2272420-A](https://nimo.iptorch.com/refdrawing/GB-2272420-A/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/GB-2272420-A/pdf001.png)

![Sketch 2 for GB-2272420-A](https://nimo.iptorch.com/refdrawing/GB-2272420-A/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/GB-2272420-A/pdf002.png)

![Sketch 3 for GB-2272420-A](https://nimo.iptorch.com/refdrawing/GB-2272420-A/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/GB-2272420-A/pdf003.png)

![Sketch 4 for GB-2272420-A](https://nimo.iptorch.com/refdrawing/GB-2272420-A/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/GB-2272420-A/pdf004.png)

![Sketch 5 for GB-2272420-A](https://nimo.iptorch.com/refdrawing/GB-2272420-A/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/GB-2272420-A/pdf005.png)

![Sketch 6 for GB-2272420-A](https://nimo.iptorch.com/refdrawing/GB-2272420-A/pdf005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/GB-2272420-A/pdf006.png)

![Sketch 7 for GB-2272420-A](https://nimo.iptorch.com/refdrawing/GB-2272420-A/pdf006.png)

## Claims

### Claim 1 (independent)

A vacuum gripper arrangement comprising a gripper device having a body and a sealing skirt or rim for contacting a supporting surface to which the gripper device is to be attached, a vacuum pump connected to said gripper device, a compressed air inlet, and valve means for causing said compressed air inlet to be connected to said vacuum pump or said gripper device whereby when a compressed air supply is connected to said inlet, in one position of said valve means it is connected to said vacuum pump for causing a vacuum to be formed between said gripper device and a supporting surface to cause said gripper device to be attached thereto, and in another position of said valve means it is connected to said gripper device for causing a pressure to be formed between said gripper device and said supporting surface.

### Claim 2

An arrangement as claimed in claim 1, in which the vacuum pump is a multi-ejector vacuum pump.

### Claim 3

An arrangement as claimed in claim 1 or claim 2, in which said vacuum pump is separate from said gripper device.

### Claim 4

An arrangement as claimed in any preceding claim, comprising a restrictor device connected between said valve means and said gripper device.

### Claim 5

An arrangement as claimed in claim 4, in which said restrictor device is adjustable.

### Claim 6

An arrangement as claimed in any preceding claim, in which said valve means is a two-way electrically operated valve.

### Claim 7 (independent)

A vacuum gripper arrangement substantially as hereinbefore described with reference to the accompanying drawing.

## Full description

Vacuum Gripper Arrangements This invention relates to vacuum gripper arrangements and especially to such arrangements for use with robotic devices. The invention has particular application to vacuum gripper feet for use in robotic devices of the kind which form the basis of U.K. Patent Application Nos. 2230357A and 2238992A.

The vacuum gripper arrangement which forms the basis of the present invention lends itself to use in dirty or contaminated environments.

In U.K. Patent Application No. 2248221A there is disclosed a vacuum gripper device in the form of a gripper foot which includes a vacuum generating ejector pump mounted on a body of the foot in such a way that air is withdrawn from the space under the gripper foot to cause it to attach itself to an adjacent surface for as long as a supply of compressed air is supplied to the ejector pump.

To release the gripper foot with the compressed air still applied, a pneumatic poppet valve is operated to close the exhaust outlet of the ejector pump for causing back pressure which breaks the vacuum and releases the foot.

In some applications it is not convenient to mount a poppet valve on the ejector pump, and the present invention relates to an improved form of vacuum gripper arrangement whereby this requirement is obviated.

According to the present invention there is provided a vacuum gripper arrangement comprising a gripper device having a body and a sealing skirt or rim for contacting a supporting surface to which the gripper device is to be attached, a vacuum pump connected to said gripper device, a compressed air inlet, and valve means for causing said compressed air inlet to be connected to said vacuum pump or said gripper device whereby when a compressed air supply is connected to said inlet, in one position of said valve means it is connected to said vacuum pump for causing a vacuum to be formed between said gripper device and a supporting surface to cause said gripper device to be attached thereto, and in another position of said valve means it is connected to said gripper device for causing a pressure to be formed between said gripper device and said supporting surface.

It may be arranged that the vacuum pump is a multi-ejector vacuum pump, and the vacuum pump may be separate from the gripper device or formed as part of it.

A restrictor device may be provided connected between said valve means and said gripper device, and it may be arranged that the restrictor device is adjustable.

Conveniently, said valve means is a two-way electrically operated valve.

An exemplary embodiment of the invention will now be described, reference being made to the accompanying single figure drawing which depicts a vacuum gripper arrangement in accordance with the present invention.

The vacuum gripper arrangement shown in the drawing comprises a gripper foot 1 having a generally cylindrical body 2 around the periphery of which is disposed a seal 3 whereby a space 4 is formed between the body 2 and a supporting surface 5 which, when evacuated of air, causes the gripper foot 1 to be attached to the surface 5.

The vacuum gripper arrangement is provided with a vacuum ejector pump 6, the vacuum take-off port of which is connected to the space 4 of the gripper foot 1 by means of a pipe 7. The ejector pump 6 is supplied with compressed air from a compressed air source 8 via a two-way valve 9 which is electromagnetically operated by means of a coil 10 such that when the coil 10 is energised, the two-way valve 9 is operated to cause compressed air to be supplied to the vacuum ejector pump 6 via the pipe 11, which in turn causes a vacuum to be formed in the space 4 of the gripper foot 1 thereby causing it to be attached to the surface 5.

When the gripper foot 1 is required to be released from the surface 5, the coil 10 of the two-way valve 9 is de-energised to cause the valve 9 to operate to cause compressed air to be supplied directly to the gripper foot 1 via a pipe 12 and restrictor device 13 whereby a positive pressure is developed in the space 4 of the gripper foot 1 which enables it to slide freely over the surface 5 on an air cushion. The magnitude of the pressure in the space 4 of the gripper foot 1 is adjusted by means of the restrictor 13 to a minimum value to minimise air consumption. Some air from the space 4 will escape via the pipe 7 and the vacuum ejector pump 6 but this can be minimised.

The positive pressure developed in the space 4 of the gripper foot 1 not only enables it to slide freely over the surface 5, it enables the seal 3 to distribute itself evenly over the surface 5 and helps to prevent the gripper foot 1 from "tripping" on its front edge when it is moving. The positive pressure also enables the gripper foot 1 to be used in dirty, dusty environments since any dust particles, etc., will be blown clear.

It will be appreciated that the vacuum gripper arrangement which has been described obviates the need for a poppet valve and the ejector pump 6 may be formed separately from the gripper foot 1 as shown or may be formed as part of the gripper foot 1.

## Classifications

- B25J15/0616
- B25J15/06
- B62D57/024
- B62D57/024

## Cited patent documents

- [GB-1114029-A](https://patents.google.com/patent/GB1114029A/en) — SEA
- [GB-2254909-A](https://patents.google.com/patent/GB2254909A/en) — SEA
- [GB-2257412-A](https://patents.google.com/patent/GB2257412A/en) — SEA
- [US-4453755-A](https://patents.google.com/patent/US4453755A/en) — SEA

---

Generated by IPtorch. Verify legal conclusions against the official publication.
