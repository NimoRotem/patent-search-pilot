# 23. Area vacuum gripper

- **Archive rank:** 23 of 50
- **Publication:** [US-2015352726-A1](https://patents.google.com/patent/US20150352726A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/050002714/publication/US20150352726A1?q=pn%3DUS20150352726A1)
- **Publication date:** 2015-12-10
- **Filing date:** 2014-01-21
- **Earliest priority:** 2013-01-25
- **Family:** 50002714
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus

## Parties

- **Applicant / assignee:** SCHMALZ J GMBH
- **Inventors:** HARTER LEONHARD; STEYERL KEN

## Abstract

The invention relates to an surface area vacuum gripper ( 10 ) for sucking and handling workpieces, comprising a housing ( 12 ), in which a negative pressure vacuum chamber is provided that can be subjected to negative pressure and wherein the housing ( 12 ) comprises on the suction side, facing the workpiece, suction openings ( 28 ). According to the invention, an insertion element ( 22 ) is provided in the housing, which reduces the free inner space of the housing and comprises vacuum channels ( 24 ) fed by a vacuum generator ( 38 ). The insertion element ( 22 ) can be equipped with a plurality of optional functions.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/7f/25/fc/3426d873817908/US20150352726A1-20151210-D00000.png)

![Sketch 1 for US-2015352726-A1](https://patentimages.storage.googleapis.com/7f/25/fc/3426d873817908/US20150352726A1-20151210-D00000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/52/2c/5e/96d37589118dff/US20150352726A1-20151210-D00001.png)

![Sketch 2 for US-2015352726-A1](https://patentimages.storage.googleapis.com/52/2c/5e/96d37589118dff/US20150352726A1-20151210-D00001.png)

## Claims

### Claim 1 (independent)

Surface area vacuum gripper (10) for sucking onto and handling of workpieces, with a frontally closable housing (12), in which is provided a negative pressure chamber which can be exposed to vacuum and the housing (12) comprises suction openings (28) on its suction side facing the workpiece, characterized in that in the housing (12) is placed an insert element (22) which can be frontally inserted into and again pulled out from the housing (12), which insert element reduces the free inner space of the housings (12) and comprises vacuum channels (24) supplied by a vacuum generator.

### Claim 2

Surface area vacuum gripper according to claim 1, characterized in that the insert element (22) comprises on its bottom side facing the suction side of the housing (12) vacuum channels designed as grooves (24).

### Claim 3

Surface area vacuum gripper according to claim 2, characterized in that the grooves (24) are sealed from each other.

### Claim 4

Surface area vacuum gripper according to any one of the preceding claims, characterized in that the housing (12) is an extruded profile and that the grooves (24) extend in longitudinal direction of the housings (12) and the profile.

### Claim 5

Surface area vacuum gripper according to claims 3 and 4, characterized in that on the inner side of the suction side of the housing (12) studs (44) are provided, which protrude into the grooves (24) of the insert element (22).

### Claim 6

Surface area vacuum gripper according to any one of the preceding claims, characterized in that the insert element (22) comprises at least one receiving chamber (38) e.g. for an ejector or a multiple-stage ejector, for a pressure reservoir or for a vacuum reservoir.

### Claim 7

Surface area vacuum gripper according to any one of the preceding claims, characterized in that the insert element (22) comprises at least one illumination device.

### Claim 8

Surface area vacuum gripper according to claim 7, characterized in that the illumination device illuminates the vacuum channel (24) and/ or one or more suction openings (28).

### Claim 9

Surface area vacuum gripper according to any one of the preceding claims, characterized in that the insert element (22) comprises at least one pressurized air channel and/or pressurized air nozzle.

### Claim 10

Surface area vacuum gripper according to any one of the preceding claims, characterized in that the insert element (22) comprises at least one electrically driven pump for the generation of vacuum.

### Claim 11

Surface area vacuum gripper according to any one of the preceding claims, characterized in that the insert element (22) comprises at least one energy reservoir, e.g. an accumulator, integrated electronics for the evaluation and control of process parameters, a device for the detection of the weight, a camera for process and quality assurance or for process control, an interface to a robot and/or elements for vacuum measurement and control.

## Full description

### Cross-Reference To Related Applications

**[p0001]**

The present application is a National Stage of International Patent Application No. PCT/EP2014/051089, filed on Jan. 21, 2014, which claims priority to and all the benefits of German Patent Application No. 10 2013 201 248.9, filed on Jan. 25, 2013, both of which are hereby expressly incorporated herein by reference in their entirety.

### Description

**[p0002]**

The invention relates to a surface area vacuum gripper for sucking onto and handling workpieces, with a housing, which is provided with a negative pressure chamber that can be acted upon with negative pressure and the housing comprises suction openings on its side facing the workpiece. Such surface area vacuum grippers (DE 10 2006 050 970 A1) serve in particular for gripping and lifting of objects, such as positionally stable flat materials, such as boards or plates, or smaller objects, such as cans, cups, dishes or the like. The surface area vacuum gripper comprises a flexible lining, which is usually applied to the top side of the objects to be gripped. Foam lining has proven as advantageous, because it conforms well to the sometimes uneven surface. There is, however, still the problem that different objects have different surfaces and sometimes large gaps exist between the objects. However, the flow behavior of the conventional suction grippers is too slow to quickly respond to different objects.

**[p0003]**

If the surface area vacuum gripper is equipped with flow valves with a predetermined suction, the valve bodies must not be too sluggish, because otherwise they do not close. Fast-acting valve bodies carry the risk that they will close when a sucked-on workpiece e.g. is briefly lifted by vibration so that briefly ambient air is sucked in. In this case, the workpiece would drop. Publications DE 36 36 523 C2, DE 198 17 217 C1, US 3 910 621 A and EP 0 267 874 A1 describe surface area vacuum grippers, in which components are arranged in the negative pressure chamber. The present invention therefore has for its object to further develop a suction gripper surface of the aforementioned type in such a way that even slow-closing valves can be used. According to the invention, this technical task is solved with a surface area vacuum gripper of the initially mentioned type in that in the housing is disposed an insert element, which reduces the free inner space of the housing and comprises negative pressure channels supplied by a generator of negative pressure. Further features become evident from dependent claims.

**[p0004]**

According to the invention, the insert element reduces the negative pressure chamber within the housing and thus improves the responsiveness of the surface area vacuum gripper. Since the dead space is reduced by the insert element, each individual suction opening responds better even for a smaller suction volume flow. It is not a large suction volume that needs to be evacuated. Any present flow valves may be designed in their closing behavior in a sluggish manner. This design of the flow valves thus allows a reliable lifting and transportation of objects without the existence of the danger that the valve closes during the lifting procedure due to leakage on the surface of the sucked-on object. The invention thus ensures the transportation of objects with leakage with a minimal use of the total volume flow. Another advantage consists in the fact that the surface area vacuum gripper can be quickly adapted to different purposes by different insert elements in that the suitable insert element is inserted into the housing. This allows complementing or changing the functions. The surface area vacuum gripper is designed in the fashion of a construction kit.

**[p0005]**

In a further development of the invention, the insert element comprises, on its bottom side facing the suction side of the housing, negative pressure channels designed as grooves. These negative pressure channels are connected to the generator of negative pressure and form with the feeding lines quasi the only dead space connected with the suction openings. Its volume depends solely on the dimensions of the grooves and the feeding lines and can therefore be kept very small. To prevent a breakdown of the whole negative pressure system caused by leakage or unoccupied suction openings, the grooves can be sealed from each other. In addition, the grooves themselves can comprise one or more dividers over their length. The housing can be frontally closed and the insert element can be frontally inserted into the housing and pulled out again. Advantageously, the housing is an extruded profile, wherein the grooves extend in the longitudinal direction of the housing or its extruded profile. The grooves can therefore be formed during the manufacturing of the housing, wherein they protrude on the inner side of the suction side of the housing. If the insert element is inserted into the housing frontally, the studs mesh into the grooves of the insert element.

**[p0006]**

In a preferred embodiment of the invention, it is provided that the insert element comprises at least a receiving chamber e.g. for an ejector or a multi-stage ejector for a pressure reservoir or a negative pressure reservoir. The pressure or negative pressure reservoir can be formed directly in the insertion channel. In this manner, negative pressure is immediately present at the suction openings and, if needed, can be quickly released by the pressure stored in the pressure reservoir. Using the higher pressure, any impurities can also be blown out. A further development provides that electrical components such as valves, sensors, energy storage, cameras, controllers, etc., are mounted within or on the insert element. An advantageous embodiment provides that the insert element comprises at least one lighting device. The lighting device illuminates the negative pressure channel and one or more suction openings and shines from the inside to the outside. The surface area vacuum gripper can thus illuminate the surface of the object to be gripped before it touches down on it, which is of great advantage in particular in insufficiently lit workplaces. In addition or as an alternative, in the insert element and in particular in the suction openings reflectors can be provided. If the suction openings are illuminated from outside, any dirt can be easily recognized.

**[p0007]**

With preference, the invention further provides that the insert element comprises at least one compressed air channel and/or compressed air nozzles. On the one hand, by these compressed air nozzles dirt can be easily blown out, on the other hand it serves to release the gripped workpiece. In another embodiment, the insert element has at least one electrically driven pump for generating vacuum. In this variant, the supply line for compressed air and/or negative pressure is omitted. It only requires electrical supply leads. To be able to operate this surface area vacuum gripper at least in the short term even without a connection to the mains supply, the insert element comprises at least one energy storage device, for example, an accumulator. It operates the electric pump and can later be recharged. Further advantages, features and details of the invention become evident from the dependent claims and the following description, which describes a particularly preferred embodiment with reference to the drawing. The features shown in the drawing and mentioned in the description and in the claims can each be essential to the invention individually or in any combination.

**[p0008]**

The drawings show: FIG. 1 shows an exploded view of the invented surface area vacuum gripper, partly cut; FIG. 2 shows a cross-section of the surface area vacuum gripper; and FIG. 3 shows a longitudinal section II-II according to FIG. 1 through the surface area vacuum gripper. In FIG. 1 is shown in perspective view a surface area vacuum gripper 10 , which comprises a housing 12 , which is for example a section of an extruded profile. Alternatively the housing 12 can also be a bent sheet metal part, 3D compression-molded part, CFRP part or a cast part. The housing 12 is closed frontally by two end caps 14 . At the end cap 14 shown in FIG. 1 , we can see a pressure gauge 16 , a pressure air connection 18 and further connections 20 , which are not essential for the invention. In housing 12 is located an insert element 22 , which reduces the free interior of the housing 12 and conforms to the inner surface of housing 12 as close as possible, but still has so much play to it that it can be inserted into the housing 12 and removed again, i.e. it can be pulled out. The insert element 22 has on its underside negative pressure channels designed as grooves 24 . Corresponding to these grooves 24 , the housing 12 has at its bottom 26 several rows with suction openings 28 which are designed as flow resistance or serve for receiving flow valves 30 , for example, valve balls or the like. To the floor 26 is attached a flexible lining 32 , which is formed by a foam pad 34 or a sealing plate. This lining 32 is formed porous or into this lining 32 is introduced a plurality of slots or apertur

**[p0008]**

es which in turn spatially correspond with the suction openings 28 .

**[p0009]**

Further, it can be seen in FIG. 2 that on the inside of the bottom 26 extend studs 44 , in which the suction openings 28 are provided and by which the individual grooves 24 are sealed from each other. Above the grooves 24 are recesses 36 , in which, for example, lighting bodies, reflectors, blow-off nozzles and/or the like may be used. These recesses 36 are located in the extension behind the suction channels or suction openings 28 . FIG. 3 shows in the longitudinal section III-III the insert element 22 in the housing 12 and there is also illustrated a vacuum generator 38 . This vacuum generator 38 is directly connected to the end cap 14 so that through this cap the inlets and outlets for fluids and electric power as well as data can be conducted. The insert element 22 is formed as a hollow body 40 and serves as a reservoir for compressed air or as a vacuum reservoir. In this case, the vacuum generator is inserted directly into the insert element 22 . The hollow body 40 designed as a vacuum reservoir has an opening closable with a flap in the direction of the flow openings 28 . The flap can be opened with a cylinder 42 so that vacuum is abruptly created at the flow openings 28 . This has the particular advantage that even slowly reacting valves can be used. In addition, a memory may be integrated in the insert element 22 as a separate component.

## Figure captions

- **Figure 1:** FIG. 1 shows an exploded view of the invented surface area vacuum gripper, partly cut;
- **Figure 2:** FIG. 2 shows a cross-section of the surface area vacuum gripper; and
- **Figure 3:** FIG. 3 shows a longitudinal section II-II according to FIG. 1 through the surface area vacuum gripper.

## Classifications

- B25J15/0616
- B25J15/0616
- B65G47/91
- B25J15/06
- B25J15/0691
- B25J15/0691
- B25J19/00
- B25J19/00
- B25J19/00
- B65G47/91
- B65G47/917
- B65G47/917

## Cited patent documents

- [DE-10216221-C1](https://patents.google.com/patent/DE10216221C1/en) — PRS
- [US-2015360371-A1](https://patents.google.com/patent/US20150360371A1/en) — PRS
- [US-4265476-A](https://patents.google.com/patent/US4265476A/en) — PRS
- [US-5259859-A](https://patents.google.com/patent/US5259859A/en) — PRS
- [US-5749614-A](https://patents.google.com/patent/US5749614A/en) — PRS
- [US-7661736-B2](https://patents.google.com/patent/US7661736B2/en) — PRS
- [US-8251422-B2](https://patents.google.com/patent/US8251422B2/en) — PRS

---

Generated by IPtorch. Verify legal conclusions against the official publication.
