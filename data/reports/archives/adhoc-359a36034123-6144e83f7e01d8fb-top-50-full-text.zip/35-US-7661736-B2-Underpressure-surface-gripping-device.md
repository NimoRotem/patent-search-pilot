# 35. Underpressure surface gripping device

- **Archive rank:** 35 of 50
- **Publication:** [US-7661736-B2](https://patents.google.com/patent/US7661736B2/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/038438438/publication/US7661736B2?q=pn%3DUS7661736B2)
- **Publication date:** 2010-02-16
- **Filing date:** 2007-03-14
- **Earliest priority:** 2006-03-15
- **Family:** 38438438
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus

## Parties

- **Applicant / assignee:** SCHMALZ J GMBH
- **Inventors:** EISELE THOMAS; HARTER LEONHARD; SCHMALZ KURT

## Abstract

The invention concerns an underpressure surface gripping device with an extruded profile having a hollow chamber, a vacuum plate which is mounted parallel to the extruded profile, at least one flow through opening which connects the extruded profile to the vacuum plate, and with an ejector as a vacuum generator, wherein the ejector is inserted into the hollow chamber of the extruded profile and the suction opening of the ejector communicates with the flow through opening.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/e9/b8/20/57811a78988808/US07661736-20100216-D00000.png)

![Sketch 1 for US-7661736-B2](https://patentimages.storage.googleapis.com/e9/b8/20/57811a78988808/US07661736-20100216-D00000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/d8/0f/ec/6211cabf1d2b17/US07661736-20100216-D00001.png)

![Sketch 2 for US-7661736-B2](https://patentimages.storage.googleapis.com/d8/0f/ec/6211cabf1d2b17/US07661736-20100216-D00001.png)

[Sketch 3](https://patentimages.storage.googleapis.com/b3/23/f2/15ef52c46885ba/US07661736-20100216-D00002.png)

![Sketch 3 for US-7661736-B2](https://patentimages.storage.googleapis.com/b3/23/f2/15ef52c46885ba/US07661736-20100216-D00002.png)

## Claims

### Claim 1 (independent)

An underpressure surface gripping device comprising: an extruded profile having one single hollow chamber; a vacuum plate, mounted parallel to said extruded profile; means defining at least one flow through opening to connect said extruded profile to said vacuum plate; and vacuum generator ejector, said ejector being inserted into said hollow chamber of said extruded profile, wherein a suction opening of said ejector communicates with said flow through opening, a pressure connection of said ejector opening from a lid closing an end face of said extruded profile or said pressure connection communicating with a connection provided in said lid, wherein said lid serves to align and/or hold said ejector.

### Claim 2

The underpressure surface gripping device of claim 1 , wherein said extruded profile forms a housing of said ejector.

### Claim 3

The underpressure surface gripping device of claim 1 , wherein said ejector abuts, in a fluid-tight fashion, an inner wall of said extruded profile defining said flow through opening.

### Claim 4

The underpressure surface gripping device of claim 1 , wherein a side of said extruded profile opposite to said vacuum plate forms an abutment surface for a flange of a robot arm.

### Claim 5

The underpressure surface gripping device of claim 1 , wherein said extruded profile has side walls which are continued in a direction towards said vacuum plate to form a U-shaped profile which opens downwardly towards said vacuum plate.

### Claim 6

The underpressure surface gripping device of claim 5 , wherein said downwardly opening U-shaped profile is closed by said vacuum plate.

### Claim 7

The underpressure surface gripping device of claim 5 , wherein said downwardly opening U-shaped profile and said vacuum plate form a vacuum storage.

### Claim 8

The underpressure surface gripping device of claim 1 , wherein said lid has pneumatic and electric connections.

### Claim 9 (independent)

An underpressure surface gripping device comprising: an extruded profile having one single hollow chamber; a vacuum plate, mounted parallel to said extruded profile; means defining at least one flow through opening to connect said extruded profile to said vacuum plate; and vacuum generator ejector, said ejector being inserted into said hollow chamber of said extruded profile, wherein a suction opening of said ejector communicates with said flow through opening, an outlet of said ejector opening from a lid which closes an end face of said extruded profile.

### Claim 10

The underpressure surface gripping device of claim 9 , wherein a foamed material, through which outgoing air flows, is disposed in said hollow chamber between an outlet and said lid.

### Claim 11

The underpressure surface gripping device of claim 9 , wherein said extruded profile forms a housing of said ejector.

### Claim 12

The underpressure surface gripping device of claim 9 , wherein said ejector abuts, in a fluid-tight fashion, an inner wall of said extruded profile defining said flow through opening.

### Claim 13

The underpressure surface gripping device of claim 9 , wherein a side of said extruded profile opposite to said vacuum plate forms an abutment surface for a flange of a robot arm.

### Claim 14

The underpressure surface gripping device of claim 9 , wherein said extruded profile has side walls which are continued in a direction towards said vacuum plate to form a U-shaped profile which opens downwardly towards said vacuum plate.

### Claim 15

The underpressure surface gripping device of claim 14 , wherein said downwardly opening U-shaped profile is closed by said vacuum plate.

### Claim 16

The underpressure surface gripping device of claim 14 , wherein said downwardly opening U-shaped profile and said vacuum plate form a vacuum storage.

### Claim 17

The underpressure surface gripping device of claim 9 , wherein said lid has pneumatic and electric connections.

## Full description

**[p0001]**

This application claims Paris Convention priority of DE 10 2006 013 970 filed on Mar. 15, 2006.

### Background Of The Invention

**[p0002]**

The invention concerns an underpressure surface gripping device comprising an extruded profile, a vacuum plate which is mounted parallel to the extruded profile, at least one flow through opening that connects the extruded profile to the vacuum plate, and an ejector as a vacuum generator. Conventional underpressure surface griping devices of this type are e.g. produced by the companies Joulin and Tepro. A vacuum surface gripping system due to the Assignee is designated “FX”. In this vacuum surface gripping system, a vacuum generator and its mufflers are disposed on a holding plate. This holding plate also includes a structural valve component and a vacuum display. A vacuum plate is also mounted to the lower side of the holding plate for gripping the tool using vacuum. The overall device is mounted to a robot arm via a mounting bracket which extends over the components mounted to the holding plate, such that the workpiece which is gripped by the vacuum surface gripping system can be lifted and moved to another location. A vacuum surface gripper system of this type has, however, a large height, since the components such as vacuum generator, mufflers and the like are mounted to the holding plate. Due to the large height, the surface gripper system generates a large lever arm on the robot flange, which must always be taken into consideration in handling the workpiece. DE 10 2004 037 609 B3 discloses a vacuum beam which comprises an extruded profile containing a pre-storage chamber and a suction chamber. All functional parts are housed in the extruded profile. This vacuum beam i

**[p0002]**

s advantageous in that the functional parts are no longer provided on the outer side of the profile. However, the dimensions of the vacuum beam are still excessively large.

### Summary Of The Invention

**[p0003]**

It is therefore the underlying purpose of the invention to provide an underpressure surface gripping device having a smaller size, thereby reducing the separation between the workpiece and the robot flange. This object is achieved in accordance with the invention in an underpressure surface gripping device of the above-mentioned type in that the extruded profile has one single hollow chamber, the ejector is inserted into the hollow chamber of the extruded profile, and the suction opening of the ejector communicates with the flow through opening. Since the ejector is integrated in the extruded profile, the flange for the robot arm can be mounted directly onto the upper side of the extruded profile. Since this side is opposite to the vacuum plate and the workpiece abuts the vacuum plate, the lever arm between the workpiece and the flange of the robot arm is determined by the thickness of the extruded profile with mounted vacuum plate. The thickness of the extruded profile is selected to accept the ejector without housing, since the extruded profile itself forms the housing. Since an ejector without housing is smaller than an ejector with housing, the lever arm is reduced in length. Due to the smaller lever arm, the same robot arm can grasp and move workpieces of a larger weight.

**[p0004]**

In a further development, the pressure connection of the ejector terminates in a lid that closes the end face of the extruded profile. The pressure hose for the pressure medium is connected to this lid for operating the ejector. For this reason, the extruded profile needs no separate connecting devices or corresponding provisions. The lid may additionally serve as a positioning element and/or a holder for the ejector. The ejector is positioned and/or fixed after insertion into the hollow chamber of the extruded profile through mounting the lid to the end face of the extruded profile. The length of the extruded profile can also be neglected as long as it is at least sufficiently long to receive the ejector. The underpressure surface gripping device can thereby be advantageously adjusted to the optimum size for the workpiece to be handled simply through cutting the extruded profile to the desired length. The extruded profile must only be closed on the end faces by lids, and the vacuum plate must be mounted, in particular, screwed. Several vacuum plates may be used, together in tandem. Several extruded profiles can be advantageously connected in tandem via suitable couplings, i.e. couplings that transmit the bending moment and have seals, such that an underpressure surface gripping device having the desired size can be built in a modular fashion.

**[p0005]**

The outlet of the ejector preferably opens from a lid which closes the end face of the extruded profile. This may be the same lid to which the ejector is mounted and via which the ejector is mounted to the extruded profile. The opposite lid may also be used. The outgoing ejector air is guided in the hollow chamber of the extruded profile e.g. via hoses to the lids having the outlet opening. The outlet of the ejector or the free end of the hose may thereby be guided into a foamed material which serves as a muffler and through which the outgoing air flows. This foamed material is also housed in the hollow chamber of the extruded profile. In this case, the extruded profile itself also serves as a housing for the muffler, wherein the foamed material represents the damping material. The ejector advantageously abuts the inner wall of the extruded profile having the flow through opening in a fluid tight fashion. The vacuum generated by the ejector thereby directly abuts the vacuum plate, which reduces the reaction time and the air consumption due to the smaller dead volume. The ejector is thereby dimensioned such that it is received by the hollow chamber of the extruded profile without play and advantageously has a seal on the side facing the flow through openings.

**[p0006]**

The hollow chamber of the extruded profile may moreover contain further components such as switching valves, pressure monitoring means, further lines for underpressure and overpressure and control pressure and the like. The hollow chamber may also contain all electronic components which are required to drive the ejector, monitor the pressures, store data, or transmit and receive information. Further advantages, features and details of the invention can be extracted from the dependent claims and the following description which describes in detail a particularly preferred embodiment with reference to the drawing. The features shown in the drawing and mentioned in the description and the claims may thereby be essential to the invention either individually or collectively in arbitrary combination.

### Brief Description Of The Drawing

**[p0007]**

FIG. 1 shows a perspective view of an underpressure surface gripping device which is flanged to a robot arm; FIG. 2 shows a section of an extruded profile of the underpressure surface gripping device; FIG. 3 shows a view of the lower side of the extruded profile with inserted ejector; and FIG. 4 shows a view of the upper side of the extruded profile with inserted ejector.

### Description Of The Preferred Embodiment

**[p0008]**

FIG. 1 shows a perspective view of a section of a robot arm, designated in total with 10 , to which an underpressure surface gripping device 12 is flanged. Towards this end, the robot arm 10 has a flange 14 which directly abuts the upper side 16 of an extruded profile 18 , i.e. without interconnection of mounting brackets or the like. It is e.g. screwed or clamped to the upper side 16 . For mounting other flanges, the extruded profile 18 has holding grooves 20 on its upper side 16 , into which e.g. guides of a corresponding other flange can be inserted, and the flange can be clamped to the upper side 16 at any location. FIG. 1 also shows a workpiece 22 which is suctioned by the underpressure surface gripping device 12 via a vacuum plate 24 . An end face of the extruded profile 18 is closed by a lid 26 which is broken away in the illustration. A pressure connection 28 projects from the lid 26 and is guided to an ejector 32 which is disposed in the hollow chamber 30 of the extruded profile 18 . The lid 26 has electrical connections 62 .

**[p0009]**

FIG. 2 shows the extruded profile 18 in the hollow chamber 30 of which the ejector 32 is housed (indicated with dashed lines 34 ). The ejector 32 is fitted into the hollow chamber 30 such that its lower side 36 is supported on the inner surface 38 of the lower longitudinal wall 40 of the extruded profile 18 in a fluid-tight fashion. For sealing, the lower side 36 of the ejector 32 may e.g. be laminated with a sealing coating. The ejector 32 is also surrounded on both sides and at the top by further hollow spaces 42 , 44 and 46 which extend in the longitudinal direction, and can be used to receive electric lines or pneumatic lines or guide pressurized or vacuumized fluids. The figure also shows that screw channels 48 are provided opposite to the holding grooves 20 , into which screws can be screwed for mounting the vacuum plate 24 to the extruded profile 18 . FIG. 3 shows that the longitudinal wall 40 has flow through openings 50 which connect the hollow chamber 30 of the extruded profile 18 to the vacuum plate 24 (not shown). The ejector 32 is located in the hollow chamber 30 whose suction opening or suction openings communicate with the flow through openings 50 . In this fashion, the ejector 32 suctions air directly via the flow through opening 50 from the area located beneath 54 .

**[p0010]**

FIG. 4 shows that the ejector 32 directly seats on the inner surface 38 of the longitudinal wall 40 , such that the dead volume between the ejector 32 and the flow valves (not shown) in the vacuum plate 24 is minimum in order to minimize the air consumption. Moreover, due to the smaller dead volume, the underpressure surface gripping device 12 reacts faster and the workpiece 20 is suctioned more quickly. At least one of the flow through openings 50 can be connected to the outlet of the ejector 32 , such that the vacuum plate 24 is also ventilated and ejection of the workpiece 22 can be accelerated. The lid 26 is mounted to the extruded profile 18 via screws which are screwed into the screw channels 52 . FIG. 4 shows that the side walls 56 of the extruded profile 18 are downwardly elongated, i.e. in the direction towards the vacuum plate 24 , and the free sections 58 and the longitudinal wall 40 form a downwardly open U-shaped profile which surrounds the area 54 . As soon as the vacuum plate 24 is mounted, the area 54 forms a vacuum storage for the vacuum plate 24 which is directly behind the flow valves provided in the vacuum plate 24 .

**[p0011]**

It is clearly shown that due to the integration of the ejector 32 and all other components, such as controls, valves, electric and pneumatic lines and the like in the hollow chamber 30 of the extruded profile 18 , the separation between the vacuum plate 24 and the flange 14 of the robot arm 10 is reduced to a minimum. This reduces the length of the lever arm such that heavy workpieces 22 can be moved by the robot arm 10 . A foamed material 60 , through which outgoing air flows, is disposed in the hollow chamber 30 , between the outlet and the lid 26 .

## Figure captions

- **Figure 1:** FIG. 1 shows a perspective view of an underpressure surface gripping device which is flanged to a robot arm;
- **Figure 2:** FIG. 2 shows a section of an extruded profile of the underpressure surface gripping device;
- **Figure 3:** FIG. 3 shows a view of the lower side of the extruded profile with inserted ejector; and
- **Figure 4:** FIG. 4 shows a view of the upper side of the extruded profile with inserted ejector.

## Classifications

- B25J15/0616
- B25J15/0616
- B25J15/06
- B65G47/91
- B65G47/91

## Cited patent documents

- [DE-102004037609-B3](https://patents.google.com/patent/DE102004037609B3/en) — APP
- [DE-10216221-C1](https://patents.google.com/patent/DE10216221C1/en) — APP
- [DE-19812275-A1](https://patents.google.com/patent/DE19812275A1/en) — APP
- [US-2004212205-A1](https://patents.google.com/patent/US20040212205A1/en) — SEA
- [US-3743340-A](https://patents.google.com/patent/US3743340A/en) — SEA
- [US-4265476-A](https://patents.google.com/patent/US4265476A/en) — SEA
- [US-4674785-A](https://patents.google.com/patent/US4674785A/en) — SEA
- [US-4925225-A](https://patents.google.com/patent/US4925225A/en) — SEA
- [US-7181854-B2](https://patents.google.com/patent/US7181854B2/en) — SEA

---

Generated by IPtorch. Verify legal conclusions against the official publication.
