# 40. Unit for picking up ceramic products or the like

- **Archive rank:** 40 of 50
- **Publication:** [US-2008299245-A1](https://patents.google.com/patent/US20080299245A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/039767200/publication/US20080299245A1?q=pn%3DUS20080299245A1)
- **Publication date:** 2008-12-04
- **Filing date:** 2008-05-29
- **Earliest priority:** 2007-05-31
- **Family:** 39767200
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery

## Parties

- **Applicant / assignee:** SACMI
- **Inventors:** BAMBI DOMENICO; FALLETTA FABRIZIO; MEDRI IVANO

## Abstract

A unit for picking up ceramic products or the like comprises: a tray ( 2 ) associated with a movement unit ( 3 ); a sealing gasket ( 4 ) located along the perimeter of an operating wall ( 5 ) of the tray ( 2 ) and designed to work in contact with a surface (S) of the product (M); means ( 6 ) for generating a vacuum inside at least one first chamber ( 7 ) made by the operating wall ( 5 ) with the inside of the tray ( 2 ) and being in communication with at least one second chamber ( 7   e ) through the operating wall ( 5 ) which is permeable; the second chamber ( 7   e ) is perimetrically delimited by the gasket ( 4 ); vacuum is applied to the opposite and facing surfaces of the wall ( 5 ) and of the surface (S) of the product (M), respectively, when the gasket ( 4 ) comes into stable contact with the surface (S) in order to pick the product up; a porous interface element ( 8 ) permeable to air is located at least on the sealing gasket ( 4 ) and forms a surface that is more deformable than the gasket ( 4 ) and impermeable to liquids, or hydro repellent, interposed between the gasket ( 4 ) and the surface (S) of the product (M) when stable contact is made.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/ac/cb/e5/1c0796e9f4358a/US20080299245A1-20081204-D00000.png)

![Sketch 1 for US-2008299245-A1](https://patentimages.storage.googleapis.com/ac/cb/e5/1c0796e9f4358a/US20080299245A1-20081204-D00000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/d7/c1/15/0210c8091c872b/US20080299245A1-20081204-D00001.png)

![Sketch 2 for US-2008299245-A1](https://patentimages.storage.googleapis.com/d7/c1/15/0210c8091c872b/US20080299245A1-20081204-D00001.png)

[Sketch 3](https://patentimages.storage.googleapis.com/65/b6/00/77fccc9e999e99/US20080299245A1-20081204-D00002.png)

![Sketch 3 for US-2008299245-A1](https://patentimages.storage.googleapis.com/65/b6/00/77fccc9e999e99/US20080299245A1-20081204-D00002.png)

[Sketch 4](https://patentimages.storage.googleapis.com/6f/6a/35/7ec3f765bda76c/US20080299245A1-20081204-D00003.png)

![Sketch 4 for US-2008299245-A1](https://patentimages.storage.googleapis.com/6f/6a/35/7ec3f765bda76c/US20080299245A1-20081204-D00003.png)

## Claims

### Claim 1 (independent)

A unit for picking up ceramic products or the like, said unit ( 1 ) comprising at least: a tray ( 2 ) associated with a movement unit ( 3 ); a sealing gasket ( 4 ) located at least along the perimeter of at least one operating wall ( 5 ) of the tray ( 2 ) and designed to work in contact with a surface (S) of the product (M); means ( 6 ) for generating a vacuum inside at least one first chamber ( 7 ) made by the operating wall ( 5 ) with the inside of the tray ( 2 ) and being in communication with at least one second chamber ( 7 e ) through the operating wall ( 5 ) which is permeable to liquids; the second chamber ( 7 e ) being perimetrically delimited by the gasket ( 4 ) in such a way that vacuum is applied to the opposite and facing surfaces of the wall ( 5 ) and of the surface (S) of the product (M), respectively, when the gasket ( 4 ) comes into stable contact with the surface (S) to enable the product to be picked up; the unit ( 1 ) being characterized by a porous interface element ( 8 ) permeable to air located at least on the sealing gasket ( 4 ) and forming a surface that is more deformable than the gasket ( 4 ) and impermeable to liquids, or hydro repellent, interposed between the gasket ( 4 ) and the surface (S) of the product (M) when the stable contact is made.

### Claim 2

The unit according to claim 1 , wherein between the interface element ( 8 ) and the tray ( 2 ) there are interposed means ( 9 ) for locking/unlocking the interface element ( 8 ) to/from the tray ( 2 ) and in such a way as to position it on the gasket ( 4 ) and move it away from the gasket ( 4 ), respectively.

### Claim 3

The unit according to claim 1 , wherein the interface element is composed of a single deformable sheet ( 8 ) with suitable porosity and impermeability properties, fully covering the operating wall ( 5 ) of the tray ( 2 ) and the gasket ( 4 ) like a cap.

### Claim 4

The unit according to claim 2 , wherein the interface element is composed of a sheet ( 8 ) and the means ( 9 ) for locking and unlocking the sheet ( 8 ) comprise an elastic ring element ( 10 ) for engaging/disengaging the sheet ( 8 ) with/from the perimetric surface of the tray ( 2 ) close to its operating wall ( 5 ).

### Claim 5

The unit according to claim 2 , wherein the interface element is composed of a sheet ( 8 ) and the locking/unlocking means ( 9 ) comprise a winding/unwinding roller ( 11 ) mounted on a wall ( 2 a ) of the tray ( 2 ) and designed to roll up and unroll the sheet ( 8 ) in such a way that it covers and uncovers the operating wall ( 5 ) and, when the operating wall ( 5 ) is covered, is latched securely to a fastening element ( 12 ) located on the opposite wall ( 2 b ) of the tray ( 2 ).

### Claim 6

The unit according to claim 2 , wherein the interface element is composed of a sheet ( 8 ) and the locking/unlocking means ( 9 ) comprise tie rods ( 13 ) associated with at least two opposite sides of the sheet ( 8 ) and able to be fastened or unfastened to or from respective protrusions ( 14 ) located on corresponding walls of the tray ( 2 ).

### Claim 7

The unit according to claim 1 , wherein the interface element ( 8 ) is composed of a sheet ( 8 ) that is washable.

### Claim 8

The unit according to claim 1 , wherein the interface element is composed of a sheet ( 8 ) acted upon by means ( 8 t ) for tensioning at least the surface that comes into contact with the product (M) so as to prevent creases from forming on the surface of the sheet ( 8 ).

### Claim 9

The unit according to claim 8 , wherein the tensioning means ( 8 t ) are composed of the locking/unlocking means ( 9 ).

### Claim 10

The unit according to claim 1 , where the gasket ( 4 ) protrudes partly, by a quantity (H), from the operating wall ( 5 ) of the tray ( 2 ), wherein interface element is composed of a sheet ( 8 ) whose thickness (K) is sufficient at least to limit the difference in height (H) between the operating wall ( 5 ) and the protruding portion of the gasket ( 4 ).

### Claim 11

The unit according to claim 1 , wherein the operating wall ( 5 ) is made as a single part with the tray ( 2 ).

### Claim 12

The unit according to claim 1 , wherein the operating wall ( 5 ) is associated with the tray ( 2 ).

### Claim 13

The unit according to claim 1 , wherein the operating wall ( 5 ) is of the rigid type, equipped with a plurality of holes made in the wall ( 5 ) itself in such a way as to enable the two chambers ( 7 , 7 e ) to communicate with the source of the vacuum.

### Claim 14

The unit according to claim 1 , wherein the operating wall ( 5 ) is made of a porous material so as to enable the two chambers ( 7 , 7 e ) to communicate with the source of the vacuum.

### Claim 15

The unit according to claim 1 , wherein the operating wall ( 5 ) is made of a porous material obtained by sintering so as to enable the two chambers ( 7 , 7 e ) to communicate with the source of the vacuum.

### Claim 16

The unit according to claim 1 , wherein the operating wall ( 5 ) is made of a porous material obtained by polymerization so as to enable the two chambers ( 7 , 7 e ) to communicate with the source of the vacuum.

### Claim 17

The unit according to claim 1 , wherein the operating wall ( 5 ) is made from metal netting.

### Claim 18

The unit according to claim 1 , wherein the operating wall ( 5 ) is shaped to match the surface (S) of the product (M) to be picked up.

## Full description

### Background Of The Invention

**[p0001]**

This invention relates to a unit for picking up ceramic products or the like, in particular ceramic products constituting parts of sanitaryware. As is well known, ceramic sanitaryware (such as washbasins, toilet bowls, bidets, flush tanks and the like) is made by casting a fluid mixture (known as “slip” in the jargon of the trade, consisting of a ceramic body in aqueous suspension) in customary moulds with a porous structure, which may be divided into two or more parts. The mould gives the article of sanitaryware the required shape and after a certain length of time (necessary to draw out a part of the water) the article is extracted from the mould in a solid form, known as “greenware” (still having a water content of between 17% and 20% by weight) and hence still subject to plastic deformation. Some of these products, such as, for example, flush tank lids, because they are small in size and relatively simple in shape, are preferably made using individual moulds having two or more cavities located side by side so that a large number of products can be obtained in a single casting cycle.

**[p0002]**

In addition to that, the simultaneous extraction of these products from the mould (by opening it into its two half-moulds), an operation known as demoulding, is usually performed by a servo- or robot-controlled mechanical device equipped with an extraction tray mounted on an operating arm. At present, the extraction tray consists of at least one operating pickup surface having at least one perimetric gasket for contact with the product and a central cavity for generating the vacuum necessary for picking up the product. The mechanical device moves the gasket into contact with a surface of the product, activates the vacuum generating means to enable the product to be picked up and then transfers the product to a table, normally horizontal, where finishing operations are performed on it. A product like the one mentioned above can be handled in two different ways: by its “noble” surface (that is to say, the surface that will be in view when the finished product is assembled) or by the opposite, less noble, surface that will be hidden by the other part of the flush tank.

**[p0003]**

At present, both these solutions have some disadvantages: if the lid is picked up by the noble surface, there is the risk of the pickup device leaving permanent marks on it due to the inevitable contact with the gasket or equivalent suction cup systems (it should be remembered that the product is still in a plastically deformable state); these marks may be visible as depressions or irregular impressions on the surface of the finished product; if the lid is picked up by the less noble surface, additional trays must be provided on which the product can be deposited to enable finishing operations to be carried out; the supporting surface of these trays must be shaped (for example slightly arched and hardly every flat) to match the shape of the noble surface, which means that each different lid shape requires a specific deposit tray to be made. In other words, picking up the products in the green state by the noble surfaces has the obvious advantage of making subsequent operations simpler since the opposite surfaces (less noble) are usually flat and do not require particularly complex trays, but increases the risk of marking the noble surfaces and thus raises the number of end products that must be scrapped.

**[p0004]**

Picking up the product in the green state by the less noble surface, on the other hand, reduces the risk of marking the visible parts but requires a large number of accessories for subsequent operations, thus increasing production cycle times and costs and reducing production efficiency. Moreover, whether a product is picked by its noble or less noble surface, there is always the risk of its sticking to the tray, after being demoulded, on account of the vacuum and the fact that the surface by which it is picked is wet. That means the product must be forcibly removed from the tray—for example reversing the direction of air flow or even manually—thus obviously slowing down product and creating the risk of damaging the product.

### Summary Of The Invention

**[p0005]**

This invention has for an aim to overcome the above mentioned disadvantages by providing a unit for picking up ceramic products or the like which can hold the ceramic product securely and effectively by its noble surface and which has a low impact on the surface so as to reduce the risk of marking the surface. Accordingly, this invention achieves this aim by providing a unit for picking up ceramic product or the like comprising the technical characteristics set out in one or more of the appended claims.

### Brief Description Of The Drawings

**[p0006]**

The technical characteristics of the invention, with reference to the above aims, are clearly described in the claims below and its advantages are apparent from the detailed description which follows, with reference to the accompanying drawings which illustrate a preferred embodiment of the invention provided merely by way of example without restricting the scope of the inventive concept, and in which: FIG. 1 is a perspective view, with some parts cut away, of a unit according to the invention, for picking up ceramic products or the like; FIG. 2 is a schematic side view of the pickup unit of FIG. 1 with a part of it not shown; FIGS. 3 to 5 are schematic side views, with some parts cut away to better illustrate others, of alternative embodiments of the pickup unit according to the invention; FIG. 6 shows an enlarged detail from FIG. 5 ; FIG. 7 illustrates the pickup unit of FIG. 3 in a plan view from above.

### Description Of The Preferred Embodiments

**[p0007]**

With reference to the accompanying drawings, in particular FIGS. 1 , 2 , 5 and 7 , the unit according to the invention is used for picking up ceramic products M or the like, such as for, example, the flush tank lid shown in FIG. 2 . In particular, the unit, which is labeled 1 in its entirety, is used for extracting the product M from the respective half mould (not shown) after a known step of making the product M by casting a fluid mixture (known as slip in the jargon of the trade, consisting of a ceramic body in aqueous suspension) in customary moulds with a porous structure. The unit 1 basically comprises: a tray 2 associated with a movement unit 3 (for example, but without limiting the scope of the invention, of the robot-controlled type) illustrated schematically as a block, connected to a frame 3 a l for mounting the tray 2 ; a sealing gasket 4 located at least along the perimeter of at least one operating wall 5 of the tray 2 and designed to work in contact with a surface S of the product M; means 6 (of known type and therefore illustrated as a block in FIG. 5 ) for generating a vacuum inside at least one first chamber 7 made by the operating wall 5 with the inside of the tray 2 ; the first chamber 7 is in communication with at least one second chamber 7 e through the operating wall 5 , which is permeable thanks to intrinsic porosity or passages (holes made in the wall 5 ) made especially for this purposes (as explained below).

**[p0008]**

The second chamber 7 e is perimetrically delimited by the gasket 4 : thanks to this structure, the above mentioned vacuum is applied to the opposite and facing surfaces of the wall 5 and of the surface S of the product M, respectively, when the gasket 4 comes into stable contact with the surface S in order to pick the product up. The unit 1 further comprises a porous interface element 8 permeable to air located at least on the sealing gasket 4 and forming a surface that is more deformable than the gasket 4 and impermeable to liquids, or hydro repellent, interposed between the gasket 4 and the surface S of the product M when the above mentioned stable contact is made. In other words, at least the contact gasket and, preferably, in the sealed vacuum area or second chamber 7 e thus has placed over it a surface which is more deformable than it and which is porous so that air can be sucked in from the outside in order to hold the product M securely but without significantly deforming the surface of the product, especially if the contact surface is the “noble” surface, that is to say, the surface that remains in view when the product is finished and assembled.

**[p0009]**

Preferably, between the interface element 8 and the tray 2 , there are interposed means 9 for locking/unlocking the element 8 to/from the tray 2 and in such a way as to position it on the gasket 4 and move it away from the gasket 4 . In one non-limiting embodiment, the interface element may be composed of a single deformable sheet 8 , with suitable porosity and impermeability properties, covering the entire operating wall 5 of the tray 2 and forming a top (see FIGS. 1 , and from 3 to 5 ) that completely covers the gasket 4 , too. In FIGS. 1 and 5 , the sheet 8 is connected to the locking/unlocking means 9 , which comprise an elastic ring element 10 for engaging/disengaging the sheet 8 with/from the perimetric surface of the tray 2 close to the operating wall 5 . In an alternative embodiment, illustrated in FIG. 4 , the locking/unlocking means 9 comprise a winding/unwinding roller 11 mounted on a wall 2 a of the tray 2 and designed to roll up and unroll the sheet 8 .

**[p0010]**

The movement of the sheet 8 (see arrow F 11 ) enables the operating wall 5 to be covered and uncovered as required; when the operating wall 5 is covered, the sheet 8 is latched securely to a fastening element 12 located on the wall 2 b on the opposite side of the tray 2 relative to the wall 2 a. In another alternative embodiment, illustrated in FIG. 3 , the locking/unlocking means 9 comprise tie rods 13 associated with at least two opposite sides of the sheet 8 and able to be fastened or unfastened to or from respective protrusions 14 located on corresponding walls of the tray 2 . These locking and unlocking means 9 may also constitute means 8 t for tensioning the surface that comes into contact with the product M in order to prevent creases from forming on the surface of the sheet. Obviously, other types of tensioning means 8 t can be used instead of the locking means, such as for example, plates L for rigidly retaining the sheet 8 after it has been tensioned (see FIG. 4 ).

**[p0011]**

Further, the sheet 8 is easy to wash, which means that optimum working conditions can be quickly and easily restored when the surface of the sheet 8 is dirtied by particles of the product M adhering to it. A further characteristic feature of the interface element described above is that, since the gasket 4 protrudes partly, by a quantity H, from the operating wall 5 of the tray 2 , the thickness K of the sheet 8 is sufficient to limit the difference in height H between the operating wall 5 and the protruding portion of the gasket 4 (see FIG. 6 ). In other words, the thickness K of the sheet 8 reduces or cancels the “step” created by the gasket 4 and allows the surface of the operating wall 5 to be made even more level, thereby eliminating any features that can cause deformation of the product M. Furthermore, the operating wall 5 may be made as a single part with the tray 2 or it may be associated with the tray 2 . The operating wall 5 may be of the rigid type, equipped with a plurality of holes made in the wall 5 itself in such a way as to enable the two chambers 7 , 7 e to communicate with the vacuum source, as mentioned above. In this case, the operating wall 5 may be made from metal netting.

**[p0012]**

Alternatively, the operating wall 5 may be made of a porous material obtained, for example, by sintering or polymerization so that, in this case too, the two chambers 7 , 7 e can communicate with the vacuum source. Lastly, the operating wall 5 may be advantageously shaped to match the surface S of the product M to be picked up, thus further improving the performance of the pick-up unit. A pick-up unit made as described above fully achieves the aforementioned aims thanks to the interface element between the product and the gasket, which allows: leveling of the irregular surfaces of the gasket, thus protecting the noble surface of the product (thanks to the higher degree of deformability); greater protection between the product and the suction areas of the unit, preventing solid particles of slip from entering the suction areas (thanks to porosity and impermeability to liquids); quicker and easier maintenance of the interface thanks to the locking/unlocking means and the washability of the sheet; optimum and clean detachment of the product from the tray thanks to the intrinsic properties of the interface which prevents the product from sticking to the tray after being extracted from the mould.

**[p0013]**

The invention described above is susceptible of industrial application and may be modified and adapted in several ways without thereby departing from the scope of the inventive concept. Moreover, all details of the invention may be substituted by technically equivalent elements.

## Figure captions

- **Figure 1:** FIG. 1 is a perspective view, with some parts cut away, of a unit according to the invention, for picking up ceramic products or the like;
- **Figure 2:** FIG. 2 is a schematic side view of the pickup unit of FIG. 1 with a part of it not shown;
- **Figure 3:** FIGS. 3 to 5 are schematic side views, with some parts cut away to better illustrate others, of alternative embodiments of the pickup unit according to the invention;
- **Figure 6:** FIG. 6 shows an enlarged detail from FIG. 5 ;
- **Figure 7:** FIG. 7 illustrates the pickup unit of FIG. 3 in a plan view from above.
- **Figure 1:** With reference to the accompanying drawings, in particular FIGS. 1 , 2 , 5 and 7 , the unit according to the invention is used for picking up ceramic products M or the like, such as for, example, the flush tank lid shown in FIG. 2 .
- **Figure 1:** In one non-limiting embodiment, the interface element may be composed of a single deformable sheet 8 , with suitable porosity and impermeability properties, covering the entire operating wall 5 of the tray 2 and forming a top (see FIGS. 1 , and from 3 to 5 ) that completely covers the gasket 4 , too.
- **Figure 1:** In FIGS. 1 and 5 , the sheet 8 is connected to the locking/unlocking means 9 , which comprise an elastic ring element 10 for engaging/disengaging the sheet 8 with/from the perimetric surface of the tray 2 close to the operating wall 5 .
- **Figure 4:** In an alternative embodiment, illustrated in FIG. 4 , the locking/unlocking means 9 comprise a winding/unwinding roller 11 mounted on a wall 2 a of the tray 2 and designed to roll up and unroll the sheet 8 .
- **Figure 3:** In another alternative embodiment, illustrated in FIG. 3 , the locking/unlocking means 9 comprise tie rods 13 associated with at least two opposite sides of the sheet 8 and able to be fastened or unfastened to or from respective protrusions 14 located on corresponding walls of the tray 2 .
- **Figure 4:** Obviously, other types of tensioning means 8 t can be used instead of the locking means, such as for example, plates L for rigidly retaining the sheet 8 after it has been tensioned (see FIG. 4 ).
- **Figure 6:** A further characteristic feature of the interface element described above is that, since the gasket 4 protrudes partly, by a quantity H, from the operating wall 5 of the tray 2 , the thickness K of the sheet 8 is sufficient to limit the difference in height H between the operating wall 5 and the protruding portion of the gasket 4 (see FIG. 6 ).

## Classifications

- B25J15/0616
- B25J15/0616
- B28B13/06
- B28B13/06
- B29C45/43

## Cited patent documents

- [US-1505626-A](https://patents.google.com/patent/US1505626A/en) — PRS
- [US-2008197644-A1](https://patents.google.com/patent/US20080197644A1/en) — PRS
- [US-3743340-A](https://patents.google.com/patent/US3743340A/en) — PRS
- [US-4389064-A](https://patents.google.com/patent/US4389064A/en) — PRS
- [US-4732415-A](https://patents.google.com/patent/US4732415A/en) — PRS
- [US-4752180-A](https://patents.google.com/patent/US4752180A/en) — PRS
- [US-4858975-A](https://patents.google.com/patent/US4858975A/en) — PRS
- [US-4872826-A](https://patents.google.com/patent/US4872826A/en) — PRS
- [US-4943222-A](https://patents.google.com/patent/US4943222A/en) — PRS
- [US-5720992-A](https://patents.google.com/patent/US5720992A/en) — PRS
- [US-5855932-A](https://patents.google.com/patent/US5855932A/en) — PRS
- [US-5935511-A](https://patents.google.com/patent/US5935511A/en) — PRS
- [US-6086808-A](https://patents.google.com/patent/US6086808A/en) — PRS
- [US-6322733-B1](https://patents.google.com/patent/US6322733B1/en) — PRS
- [US-6325955-B1](https://patents.google.com/patent/US6325955B1/en) — PRS
- [US-6386850-B1](https://patents.google.com/patent/US6386850B1/en) — PRS
- [US-6516866-B1](https://patents.google.com/patent/US6516866B1/en) — PRS

---

Generated by IPtorch. Verify legal conclusions against the official publication.
