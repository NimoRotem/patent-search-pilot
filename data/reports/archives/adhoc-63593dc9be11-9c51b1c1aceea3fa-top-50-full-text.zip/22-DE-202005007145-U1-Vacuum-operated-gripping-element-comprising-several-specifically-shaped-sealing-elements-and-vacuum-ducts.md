# 22. Vacuum operated gripping element, comprising several specifically shaped sealing elements and vacuum ducts

- **Archive rank:** 22 of 50
- **Publication:** [DE-202005007145-U1](https://patents.google.com/patent/DE202005007145U1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/037055789/publication/DE202005007145U1?q=pn%3DDE202005007145U1)
- **Publication date:** 2006-09-14
- **Filing date:** 2005-05-02
- **Earliest priority:** 2005-05-02
- **Family:** 37055789
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** FIPA GMBH

## Abstract

The device can be connected to a robot arm or similarly working device and is assembled of the suction element (1) made of rubber and a metal holding element (2). Both parts (1,2) are provided with a first bore (3) for the creation of a vacuum and a second bore (4) for the creation of pressure. The central bore (4) and the outer edge of the device are surrounded by sealing elements (7,8) with integrated w-shaped sealing lips. Several semicircular ducts located at the lower surface facilitate a safe connection between suction element (1) and base (2).

## Sketches and drawings

_No digitized sketch link was returned._

## Claims

### Claim 1 (independent)

Sauggreifer zum Ansaugen und Halten von Werkstücken, mit einem als elastisches Formteil ausgebildeten Saugkörper (1) und einem Saugkörperhalter (2), wobei der Saugkörperhalter eine erste Bohrung (3) zum Anlegen eines Unterdrucks und eine zweite Bohrung (4) zum Anlegen eines Überdrucks zwischen Sauggreifer und Werkstück und der Saugkörper (1) mit diesen Bohrungen (3, 4) korrespondierende Öffnungen (5, 6) aufweist, und eine umlaufende Dichtung (7) zur Abgrenzung der Bereiche mit Unterdruck und Überdruck vorgesehen ist, dadurch gekennzeichnet, dass die Dichtung (7) in dem Saugkörper (1) ausgebildet ist.Suction gripper for sucking and holding workpieces, with an absorbent body designed as an elastic molded part ( 1 ) and a suction body holder ( 2 ), wherein the absorbent body holder a first bore ( 3 ) for applying a negative pressure and a second bore ( 4 ) for applying an overpressure between suction gripper and workpiece and the absorbent body ( 1 ) with these holes ( 3 . 4 ) corresponding openings ( 5 . 6 ), and a circumferential seal ( 7 ) is provided for delimiting the areas with negative pressure and overpressure, characterized in that the seal ( 7 ) in the absorbent body ( 1 ) is trained.

### Claim 2

Sauggreifer nach Anspruch 1, dadurch gekennzeichnet, dass der Sauggreifer vom Werkstück aus betrachtet, im wesentlichen rund ist, die erste Bohrung (3) dezentral und die zweite Bohrung (4) zentral angeordnet ist und die Dichtung (7) die zweite Bohrung umgibt.Suction gripper according to claim 1, characterized in that the suction gripper viewed from the workpiece, is substantially round, the first bore ( 3 ) decentralized and the second hole ( 4 ) is centrally located and the seal ( 7 ) surrounds the second bore.

### Claim 3

Sauggreifer nach einem der voranstehenden Ansprüche, dadurch gekennzeichnet, dass die Dichtung (7) mindestens zwei konzentrisch verlaufende Dichtlippen aufweist.Suction gripper according to one of the preceding claims, characterized in that the seal ( 7 ) has at least two concentrically extending sealing lips.

### Claim 4

Sauggreifer nach einem der voranstehenden Ansprüche, dadurch gekennzeichnet, dass der Saugkörper (1) an seinem äußeren, dem Werkstück zugewandten Rand eine umlaufende Außendichtung (8), vorzugsweise mit zwei konzentrischen Dichtlippen aufweist.Suction gripper according to one of the preceding claims, characterized in that the absorbent body ( 1 ) at its outer, the workpiece facing edge a circumferential outer seal ( 8th ), preferably with two concentric sealing lips.

### Claim 5

Sauggreifer nach einem der voranstehenden Ansprüche, dadurch gekennzeichnet, dass der Saugkörper (1) an seiner Außenseite eine schräg nach außen und in Richtung auf das Werkstück weisende Dichtfläche (9) aufweist, deren Dicke, gesehen in ihrem radialen Querschnitt von innen nach außen, kontinuierlich abnimmt.Suction gripper according to one of the preceding claims, characterized in that the absorbent body ( 1 ) on its outside a obliquely outward and in the direction of the workpiece facing sealing surface ( 9 ), whose thickness, seen in its radial cross-section from the inside to the outside, decreases continuously.

### Claim 6

Sauggreifer nach einem der voranstehenden Ansprüche, dadurch gekennzeichnet, dass der Saugkörper (1) an seiner dem Saugkörperhalter (2) zugewandten Rückseite umlaufende Kanäle (13) aufweist, welche mit der ersten Bohrung verbunden sind.Suction gripper according to one of the preceding claims, characterized in that the absorbent body ( 1 ) at its the absorbent holder ( 2 ) facing rear circumferential channels ( 13 ), which are connected to the first bore.

### Claim 7

Sauggreifer nach einem der voranstehenden Ansprüche, dadurch gekennzeichnet, dass der Saugkörperhalter (2) aus Metall besteht und einstückig ausgebildet ist.Suction gripper according to one of the preceding claims, characterized in that the absorbent body holder ( 2 ) consists of metal and is integrally formed.

### Claim 8

Sauggreifer nach einem der voranstehenden Ansprüche, dadurch gekennzeichnet, dass der Saugkörper (1) aus Gummi oder Naturkautschuk besteht.Suction gripper according to one of the preceding claims, characterized in that the absorbent body ( 1 ) consists of rubber or natural rubber.

### Claim 9

Sauggreifer nach einem der voranstehenden Ansprüche, dadurch gekennzeichnet, dass der Saugkörper (1) an seiner dem Werkstück zugewandten Oberfläche erhabene Stege (10) aufweist.Suction gripper according to one of the preceding claims, characterized in that the absorbent body ( 1 ) at its workpiece-facing surface raised webs ( 10 ) having.

### Claim 10

Sauggreifer nach einem der voranstehenden Ansprüche, dadurch gekennzeichnet, dass der Saugköperhalter (2) an seiner dem Saugkörper (1) zugewandten Seite eine umlaufende Nut (11) mit schwalbenschwanzförmigem Querschnitt aufweist, in welche ein entsprechendes schwalbenschwanzförmiges Profil (12) des Saugkörpers (1) eingreift.Suction gripper according to one of the preceding claims, characterized in that the Saugköperhalter ( 2 ) at its the absorbent body ( 1 ) facing side a circumferential groove ( 11 ) having a dovetailed cross section into which a corresponding dovetailed profile ( 12 ) of the absorbent body ( 1 ) intervenes.

### Claim 11

Sauggreifer nach einem der voranstehenden Ansprüche, dadurch gekennzeichnet, dass der Saugkörper (1) an seiner dem Werkstück abgewandten Außenseite, den Saugkörperhalter (2) radial übergreift.Suction gripper according to one of the preceding claims, characterized in that the absorbent body ( 1 ) on its side facing away from the workpiece, the absorbent body ( 2 ) radially overlaps.

### Claim 12

Sauggreifer nach einem der voranstehenden Ansprüche, dadurch gekennzeichnet, dass der Saugkörperhalter (2) an seiner dem Saugkörper (1) zugewandten Seite mindestens eine Vertiefung aufweist, in welche ein Noppen (14) an der dem Saugkörperhalter (2) zugewandten Rückseite des Saugkörpers (1) eingreift.Suction gripper according to one of the preceding claims, characterized in that the absorbent body holder ( 2 ) at its the absorbent body ( 1 ) facing side has at least one recess into which a knob ( 14 ) on the absorbent body holder ( 2 ) facing back of the absorbent body ( 1 ) intervenes.

### Claim 13

Sauggreifer nach Anspruch 12, dadurch gekennzeichnet, dass mehrere Vertiefungen und Noppen (14) vorgesehen sind, welche asymmetrisch angeordnet sind.Suction gripper according to claim 12, characterized in that a plurality of depressions and nubs ( 14 ) are provided, which are arranged asymmetrically.

### Claim 14

Saugkörper für einen Sauggreifer nach einem der voranstehenden Ansprüche.suction body for one Suction gripper according to one of the preceding claims.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippersPERFORMING OPERATIONS; TRANSPORTINGHAND TOOLS; PORTABLE POWER-DRIVEN TOOLS; MANIPULATORSTOOLS OR BENCH DEVICES NOT OTHERWISE PROVIDED FOR, FOR FASTENING, CONNECTING, DISENGAGING, OR HOLDINGWork holders not covered by any preceding group in the subclass, e.g. magnetic work holders, vacuum work holdersVacuum work holdersPERFORMING OPERATIONS; TRANSPORTINGHAND TOOLS; PORTABLE POWER-DRIVEN TOOLS; MANIPULATORSTOOLS OR BENCH DEVICES NOT OTHERWISE PROVIDED FOR, FOR FASTENING, CONNECTING, DISENGAGING, OR HOLDINGWork holders not covered by any preceding group in the subclass, e.g. magnetic work holders, vacuum work holdersVacuum work holdersVacuum work holders portable, e.g. handheldPERFORMING OPERATIONS; TRANSPORTINGHAND TOOLS; PORTABLE POWER-DRIVEN TOOLS; MANIPULATORSMANIPULATORS; CHAMBERS PROVIDED WITH MANIPULATION DEVICESGripping heads and other end effectorsGripping heads and other end effectors with vacuum or magnetic holding meansGripping heads and other end effectors with vacuum or magnetic holding means with vacuum

Description

Translated from German

Die

Erfindung betrifft einen Sauggreifer zum Ansaugen und Halten von

WerkstÃ¼cken

nach dem Oberbegriff des Anspruchs 1.The

The invention relates to a suction pad for sucking and holding

workpieces

according to the preamble of claim 1.

Derartige

Sauggreifer werden benutzt, um WerkstÃ¼cke zu handhaben, insbesondere

WerkstÃ¼cke

mit einer planebenen OberflÃ¤che

wie Platten und Scheiben. In der Regel befinden sich diese Sauggreifer

an den Enden von Roboterarmen oder Manipulatoren und dienen dem

Erfassen, Ansaugen, Anheben und Wiederablegen der flachen WerkstÃ¼cke. HerkÃ¶mmliche

Sauggreifer, wie sie beispielsweise in der DE 103 35 021 B3 beschrieben

sind, bestehen aus einem SaugkÃ¶rper

und einem SaugkÃ¶rperhalter,

wobei der SaugkÃ¶rperhalter

in der Regel aus Metall gefertigt ist und dem SaugkÃ¶rper, bei

dem es sich um ein gummielastisches Bauteil handelt, lagert. Der SaugkÃ¶rperhalter

selbst ist wiederum an dem Manipulator oder Roboterarm angebracht

und weist sowohl Befestigungsvorrichtungen (z. B. Gewinde) auf als

auch eine Vorrichtung zur Ãbertragung

des Vakuums von einer zentralen Vakuumquelle in den Raum zwischen

SaugkÃ¶rper

und WerkstÃ¼ck.Such suction pads are used to handle workpieces, especially workpieces with a flat surface such as plates and discs. As a rule, these suction pads are located at the ends of robot arms or manipulators and serve to grasp, suck, lift and reload the flat workpieces. Conventional suction pads, as used for example in the DE 103 35 021 B3 are described, consist of a suction body and a suction body holder, wherein the absorbent body is usually made of metal and the absorbent body, which is a rubber-elastic component stores. The absorbent body itself is in turn attached to the manipulator or robotic arm and has both attachment devices (eg, threads) and a device for transferring the vacuum from a central vacuum source into the space between the absorbent body and the workpiece.

FÃ¼r die meisten

AnwendungsfÃ¤lle

genÃ¼gt

es, lediglich mit Vakuum zu arbeiten, um eine Platte zu handhaben.

Der Sauggreifer wird auf die Platte aufgesetzt, dann das Vakuum

angelegt, wodurch sich die Platte an dem SaugkÃ¶rper ansaugt, sodann wird die

Manipulation der Platte vorgenommen und anschlieÃend der evakuierte Raum zwischen

SaugkÃ¶rper

und Platte wieder belÃ¼ftet,

so dass der Sauggreifer von der (an ihrem neuen Standort gebrachten) Platte

abgehoben werden kann.For the most

use cases

enough

it just to work with vacuum to handle a plate.

The suction pad is placed on the plate, then the vacuum

applied, whereby the plate sucks on the absorbent body, then the

Manipulation of the plate made and then the evacuated space between

suction body

and plate ventilated again,

so that the suction pads from the (brought at their new location) plate

can be lifted.

In

manchen AnwendungsfÃ¤llen

ist es jedoch erforderlich, den Sauggreifer auch mit einem Ãberdruckanschluss

zu versehen, insbesondere bei der Handhabung von porÃ¶sen Platten,

z. B. dÃ¼nnen

Holz- oder Spanplatten oder Furnierplatten. Diese Platten sind (im

Gegensatz zu Glas- oder

Metallplatten) nicht vÃ¶llig

Vakuumdicht, was dazu fÃ¼hrt,

dass hÃ¤ufig

nicht nur eine (die oberste) Platte angesaugt wird, sondern auch

darunter liegende weitere Platten, da ein Teil des Vakuums die erste,

unmittelbar angesaugte Platte quasi durchtritt. In solchen FÃ¤llen ist

es notwendig, die weiteren, versehentlich mit angesaugten Platten wieder

abzuwerfen, was in der Praxis dadurch gelingt, dass der Sauggreifer

neben einem Vakuumraum auch einen, in der Regel kleineren, mit Ãberdruck

beaufschlagbaren Raum aufweist. Werden, wie oben beschrieben, zwei

oder mehrere Platten angesaugt, so genÃ¼gt ein kurzer DruckstoÃ. Dieser

fÃ¼hrt zwar

nicht dazu, dass die erste Platte abgestoÃen wird, weil das Vakuum hier

stÃ¤rker

ist, durchtritt aber die erste Platte und lÃ¤st die weiteren, mit angesaugten

Platten auf den Stapel zurÃ¼ck.In

some applications

However, it is necessary, the suction pad with an overpressure port

to provide, in particular in the handling of porous plates,

z. B. thin

Wood or chipboard or veneer boards. These plates are (in

Unlike glass or

Metal plates) not completely

Vacuum-tight, which leads to

that often

not only one (the top) plate is sucked, but also

underlying further plates, since part of the vacuum is the first,

directly sucked plate quasi passes through. In such cases

it necessary to return the others, accidentally with sucked plates

to throw off what succeeds in practice, that the suction pads

in addition to a vacuum space also one, usually smaller, with overpressure

has loadable space. Be as described above, two

or sucked several plates, so a short pressure surge is sufficient. This

leads though

not that the first plate is repelled, because the vacuum here

stronger

is, but passes through the first plate and loads the others, with sucked

Plates back on the stack.

Bei

diesen Sauggreifern ist es selbstverstÃ¤ndlich notwendig, den Unterdruckraum

von dem Ãberdruckraum

abzudichten, was bei den am Markt erhÃ¤ltlichen Zweikammer-Sauggreifern

durch eine weitere, gekrÃ¼mmte,

hervorstehende und als eigenes Bauteil ausgebildete Dichtung erfolgt.

Diese ist zwar ebenfalls aus dem gummielastischen Material des SaugkÃ¶rpers, aber

als eigenes Bauteil und mit eigener Befestigung ausgebildet. DarÃ¼ber hinaus

fÃ¼hrt der

gekrÃ¼mmte

Verlauf der DichtflÃ¤che

dazu, dass bei jedem Ansaugvorgang einer Holzplatte, deren OberflÃ¤che immer

leicht aufgeraut ist, ein VerschleiÃ der DichtflÃ¤che der

wÃ¤hrend

des Ansaugvorgang gegenÃ¼ber

der OberflÃ¤che

verrutschenden Dichtung gegeben ist. Aus diesem Grund mÃ¼ssen die

bekannten Dichtungen hÃ¤ufig

ausgetauscht werden. Ferner ist der gesamte Aufbau der bekannten

Zweikammer-Sauggreifer deutlich aufwendiger, da auch der SaugkÃ¶rperhalter

aufgrund der zusÃ¤tzlichen

Dichtung aus mehreren Teilen besteht, die zusammengeschraubt werden

mÃ¼ssen.at

Of course, it is necessary for these vacuum grippers to use the vacuum chamber

from the overpressure room

seal, what with the two-chamber suction pads available on the market

through another, curved,

protruding and designed as a separate component seal is done.

Although this is also made of the rubber-elastic material of the absorbent, but

designed as a separate component and with its own attachment. Furthermore

leads the

curved

Course of the sealing surface

to that with every aspiration of a wooden plate whose surface always

slightly roughened, wear of the sealing surface of the

while

the suction opposite

the surface

Slipping seal is given. For this reason, the

known seals often

be replaced. Furthermore, the entire structure of the known

Two-chamber suction pads significantly more complex, as well as the absorbent body

because of the extra

Seal consists of several parts that are screwed together

have to.

Es

besteht daher die Aufgabe, einen Sauggreifer mit einem Vakuumraum

und einem Druckraum so auszubilden, dass ein einfacher, kostengÃ¼nstiger

Aufbau gewÃ¤hrleistet

ist und die Dichtung zwischen Vakuum- und Druckraum einem geringeren VerschleiÃ unterliegt.It

There is therefore the task of a suction pad with a vacuum space

and form a pressure chamber so that a simpler, more cost-effective

Construction guaranteed

is and the seal between vacuum and pressure chamber is subject to less wear.

GelÃ¶st wird

diese Aufgabe mit den kennzeichnenden Merkmalen des Anspruchs 1.

Vorteilhafte Ausgestaltungen sind den UnteransprÃ¼chen entnehmbar.Is solved

This object with the characterizing features of claim 1.

Advantageous embodiments are the dependent claims.

Ein

AusfÃ¼hrungsbeispiel

eines erfindungsgemÃ¤Ãen Sauggreifers

wird im folgenden unter Bezugnahme auf die begleitenden Zeichnungen

nÃ¤her beschrieben.

Diese zeigen:One

embodiment

a suction gripper according to the invention

will be described below with reference to the accompanying drawings

described in more detail.

These show:

1:

eine Draufsicht auf den Sauggreifer von der Blickrichtung des anzusaugenden

WerkstÃ¼cks; 1 a top view of the suction gripper from the viewing direction of the workpiece to be sucked;

2:

einen teilweisen Querschnitt durch die Ansicht aus 1; 2 : a partial cross section through the view 1 ;

3:

eine Draufsicht auf die dem WerkstÃ¼ck angewandte Seite des in

den 3 : A plan view of the workpiece applied side of the in the

1 und 2 dargestellten

SaugkÃ¶rpers; und 1 and 2 illustrated absorbent body; and

4:

einen Querschnitt durch die Darstellung der 3. 4 : a cross section through the representation of the 3 ,

Der

erfindungsgemÃ¤Ãe Sauggreifer

besteht lediglich aus zwei Teilen, nÃ¤mlich dem als elastisches Formteil

aus Gummi, Naturkautschuk oder gummielastischem Material ausgebildeten

SaugkÃ¶rper 1 und dem

diesen SaugkÃ¶rper 1 haltenden,

vorzugsweise aus Metall gefertigten SaugkÃ¶rperhalter 2. Der

SaugkÃ¶rperhalter 2 weist

eine erste, dezentral angeordnete Bohrung 3 zum Anlegen

eines Unterdrucks eine zweite, zentral angeordnete Bohrung 4 zum

Anlegen eines Ãberdrucks

zwischen Sauggreifer und (nicht dargestelltem) WerkstÃ¼ck auf,

wobei eine oder beide dieser Bohrungen auch dazu dienen kÃ¶nnen, den Sauggreifer

am Ende eines (ebenfalls nicht dargestellten) Manipulators oder

Roboterarms zu befestigen.The suction pad according to the invention consists only of two parts, namely the formed as an elastic molding of rubber, natural rubber or rubber-elastic material absorbent body 1 and this absorbent body 1 holding, preferably made of metal absorbent body holder 2 , The absorbent body holder 2 has a first, decentrally located hole 3 for applying a negative pressure, a second, centrally located bore 4 for applying an overpressure between the suction gripper and the workpiece (not shown), one or both of these holes also serving to fix the suction gripper to the end of a manipulator or robotic arm (also not shown).

Der

aus gummielastischem Material bestehenden SaugkÃ¶rper 1 weist zu den

Bohrungen 3 und 4 korrespondierende Ãffnungen 5 bzw. 6 auf,

so dass der angelegte Unter- bzw. Ãberdruck auch in den dem WerkstÃ¼ck zugewandten

Raum gelangen kann.The existing of rubber-elastic material absorbent body 1 points to the holes 3 and 4 corresponding openings 5 respectively. 6 on, so that the applied negative pressure or overpressure can also get into the space facing the workpiece.

Die

dem WerkstÃ¼ck

zugewandte OberflÃ¤che des

SaugkÃ¶rpers 1 weist

verschiedene, im Spritzgussverfahren in den SaugkÃ¶rper 1 eingebrachte Profilierungen

auf. ZunÃ¤chst

befindet sich zwischen der inneren, zentralen Ãffnung 6 des SaugkÃ¶rpers 1 und

dessen Peripherie eine erste umlaufende Dichtung 7, welche

den inneren Ãberdruckbereich

von dem Ã¤uÃeren peripheren

Unterdruckbereich abgrenzt und abdichtet. Diese Dichtung 7 ist

eine schmale, stegfÃ¶rmig

aus der OberflÃ¤che

des SaugkÃ¶rpers 1 hervorstehenden

Dichtung mit zwei Dichtlippen, deren Form man als W-Form beschreiben kÃ¶nnte. Durch

die Verwendung von zwei nebeneinander liegenden Dichtlippen wird

eine bessere Abdichtung gewÃ¤hrleistet.

Ferner ist von Bedeutung, dass die Dichtung 7 im wesentlichen

senkrecht aus der OberflÃ¤che

des SaugkÃ¶rpers 1 hervorsteht,

als wÃ¤hrend

des Ansaugens und Loslassens des WerkstÃ¼cks keine laterale Bewegung

mit entsprechender Reibung auf dem WerkstÃ¼ck vollzieht.The workpiece facing surface of the absorbent body 1 has different, by injection molding in the absorbent body 1 introduced profiles on. First, it is located between the inner, central opening 6 of the absorbent body 1 and its periphery a first circumferential seal 7 which delimits and seals the inner overpressure area from the outer peripheral negative pressure area. This seal 7 is a narrow, ridge-shaped out of the surface of the absorbent body 1 protruding seal with two sealing lips whose shape could be described as a W-shape. The use of two adjacent sealing lips ensures a better seal. It is also important that the seal 7 substantially perpendicular from the surface of the absorbent body 1 protrudes, as during the suction and release of the workpiece no lateral movement with corresponding friction on the workpiece takes place.

Im

Randbereich des SaugkÃ¶rpers 1 weist dieser,

ebenfalls an seiner dem WerkstÃ¼ck

zugewandten und in 1 dargestellten OberflÃ¤che eine weitere

umlaufende Dichtung 8 auf, die im wesentlichen genauso

gestaltet ist wie die Dichtung 7, also die genannte W-Form mit

zwei Dichtlippen aufweist und im wesentlichen senkrecht aus der

OberflÃ¤che des

SaugkÃ¶rpers 1 hervorsteht.

Diese Ã¤uÃere Dichtung 8 dient

der Abdichtung des Vakuums gegenÃ¼ber der

AtmosphÃ¤re.In the edge region of the absorbent body 1 has this, also at its the workpiece facing and in 1 surface shown another circumferential seal 8th which is designed essentially the same as the seal 7 , That is, said W-shape having two sealing lips and substantially perpendicular from the surface of the absorbent body 1 protrudes. This outer seal 8th serves to seal the vacuum with the atmosphere.

Entlang

seiner AuÃenseite,

also an seiner Peripherie, weist der vom WerkstÃ¼ck aus betrachtet runde SaugkÃ¶rper 1 auÃerhalb

der AuÃendichtung 8 eine

schrÃ¤g

nach auÃen

und in Richtung auf das WerkstÃ¼ck

weisende DichtflÃ¤che 9 auf,

deren Dicke, gesehen in ihrem radialen Querschnitt (vergleiche 2)

von innen nach auÃen

kontinuierlich abnimmt. Hierdurch wird eine nach auÃen hin

zunehmende FlexibilitÃ¤t

dieser DichtflÃ¤che

gewÃ¤hrleistet,

welche letztendlich in einer dÃ¼nnen

Dichtlippe ganz an der Ã¤uÃeren Peripherie

des SaugkÃ¶rpers 1 endet.

Auf diese Weise ergibt sich bei unebenen OberflÃ¤chen, wo die AuÃendichtung 8 teilweise

nur unvollstÃ¤ndig anliegt,

eine zusÃ¤tzliche

Dichtung, da sich die DichtflÃ¤che 9 aufgrund

der nach auÃen

hin zunehmenden ElastizitÃ¤t

der WerkstÃ¼ckoberflÃ¤che in einem

gewissen Umfang anpassen kann.Along its outside, that is on its periphery, has the round suction body viewed from the workpiece 1 outside the outer gasket 8th an obliquely outward and in the direction of the workpiece facing sealing surface 9 whose thickness, seen in their radial cross-section (cf. 2 ) decreases continuously from the inside to the outside. As a result, an outwardly increasing flexibility of this sealing surface is ensured, which ultimately in a thin sealing lip entirely on the outer periphery of the absorbent body 1 ends. This results in uneven surfaces where the outer seal 8th partially incomplete, an additional seal, as the sealing surface 9 due to the outwardly increasing elasticity of the workpiece surface can adapt to a certain extent.

Wie

in 1 dargestellt weist der SaugkÃ¶rper 1 an seiner dem

WerkstÃ¼ck

zugewandten OberflÃ¤che

erhabene Stege 10 auf, die im dargestellten AusfÃ¼hrungsbeispiel

radial nach auÃen

weisen, wobei sich Stege unterschiedlicher LÃ¤nge abwechseln. Diese Stege 10 befinden

sich im Vakuumraum, also zwischen den beiden umlaufenden Dichtungen 7 und 8 und

dienen der Verbesserung des Reibschlusses zum angesaugten WerkstÃ¼ck.As in 1 shown has the absorbent body 1 raised webs on its surface facing the workpiece 10 on, which point radially outward in the illustrated embodiment, with webs of different lengths alternate. These bridges 10 are located in the vacuum space, ie between the two circumferential seals 7 and 8th and serve to improve the frictional engagement with the sucked workpiece.

Wie

insbesondere in 2 zu erkennen ist weist der

SaugkÃ¶rperhalter 2 an

seiner dem SaugkÃ¶rper 1 zugewandten

Seite eine umlaufende Nut 11 mit schwalbenschwanzfÃ¶rmigem Querschnitt

auf. In diese Nut greif ein entsprechendes schwalbenschwanzfÃ¶rmiges profil 12 des

SaugkÃ¶rpers

ein. Ferner ist aus 2 ersichtlich, dass der SaugkÃ¶rper 1 an

seiner dem WerkstÃ¼ck

abgewandten AuÃenseite

den SaugkÃ¶rperhalter 2 radial Ã¼bergreift.

Durch diese Kombination aus Ã¤uÃerem Ãbergreifen

und schwalbenschwanzfÃ¶rmiger

inneren Aufnahme wird eine leichte Montierbarkeit des SaugkÃ¶rpers 1 auf

dem SaugkÃ¶rperhalter 2 ermÃ¶glicht,

da lediglich von innen nach auÃen

montiert werden muss. ZunÃ¤chst

wird hierbei das schwalbenschwanzfÃ¶rmige Profil 12 des

SaugkÃ¶rpers 1 in

die entsprechende Nut 11 des SaugkÃ¶rperhalters 2 eingesteckt

und anschlieÃend

der Rand des SaugkÃ¶rpers 1 Ã¼ber die

AuÃenseite

des SaugkÃ¶rperhalters 2 gestÃ¼lpt. So

ist auch ein schnelles Ersetzten eines verschlissenen SaugkÃ¶rpers 1 auf

dem SaugkÃ¶rperhalter 2 ohne

Werkzeug mÃ¶glich. SchlieÃlich bietet

die Schwalbenschwanzaufnahme (Bezugszahlen 11 und 12)

den Vorteil, dass im Betrieb ein Nachgeben des Profils 12 und

damit der unmittelbar darunter angeordneten inneren Dichtung 7 damit

eine Anpassung an verschieden OberflÃ¤chen des handzuhabenden WerkstÃ¼cks mÃ¶glich ist.As in particular in 2 can be seen, the absorbent holder 2 at his the absorbent body 1 facing side a circumferential groove 11 with dovetailed cross section. In this groove engage a corresponding dovetail-shaped profile 12 of the absorbent body. Furthermore, it is off 2 it can be seen that the absorbent body 1 on its side facing away from the workpiece, the absorbent body holder 2 radially overlaps. By this combination of external overlap and dovetail-shaped inner receptacle is easy mountability of the absorbent body 1 on the absorbent body holder 2 allows, since only needs to be mounted from the inside out. First, this is the dovetailed profile 12 of the absorbent body 1 in the corresponding groove 11 of the absorbent body holder 2 inserted and then the edge of the absorbent body 1 over the outside of the absorbent body 2 slipped. So is a quick replacement of a worn absorbent body 1 on the absorbent body holder 2 possible without tools. Finally, the dovetail intake (reference numbers 11 and 12 ) has the advantage that during operation a yielding of the profile 12 and thus the immediately below inner seal 7 so that an adaptation to different surfaces of the workpiece to be handled is possible.

Die

dem WerkstÃ¼ck

abgewandte RÃ¼ckseite des

SaugkÃ¶rpers 1 wird

unter Bezugnahme auf die 3 und 4 beschrieben. 3 zeigt

hierbei eine besonders vorteilhafte Ausgestaltung des SaugkÃ¶rpers 1 der

Gestalt, dass dieser an seiner dem WerkstÃ¼ck abgewandten und dem SaugkÃ¶rperhalter 2 zugewandten

RÃ¼ckseite

umlaufende KanÃ¤le 13 aufweist.

Diese KanÃ¤le 13 sind

im wesentlichen tangential angeordnet und stehen mit der Ãffnung 5 in dem

SaugkÃ¶rper 1,

welche wiederum mit der Bohrung 3 in dem SaugkÃ¶rperhalter 2 korrespondiert

in Verbindung. Auf diese Weise gelangt das Vakuum, welches an die

Bohrung 3 angelegt wird, nicht nur in den Raum zwischen

SaugkÃ¶rper 1 und

WerkstÃ¼ck, sondern

auch in die KanÃ¤le 13,

also zwischen SaugkÃ¶rperhalter 2 und

SaugkÃ¶rper.

Damit wird eine zusÃ¤tzliche

Fixierung des SaugkÃ¶rpers 1 auf

dem SaugkÃ¶rperhalter 2 erreicht.The back of the absorbent body facing away from the workpiece 1 is referring to the 3 and 4 described. 3 shows a particularly advantageous embodiment of the absorbent body 1 the shape that this on its side facing away from the workpiece and the absorbent body holder 2 facing rear side circumferential channels 13 having. These channels 13 are arranged substantially tangentially and stand with the opening 5 in the absorbent body 1 which in turn with the bore 3 in the absorbent body holder 2 corresponds in connection. In this way, the vacuum, which reaches the hole 3 is applied, not only in the space between absorbent body 1 and workpiece, but also in the channels 13 So between suction body holder 2 and absorbent body. This is an additional fixation of the absorbent body 1 on the absorbent body holder 2 reached.

Besonders

vorteilhaft ist es, diese umlaufenden KanÃ¤le 13 in den SaugkÃ¶rper 1 einzubringen,

da dieser als billiges Formteil, zu dessen Herstellung nur einmal

ein Werkzeug angefertigt werden muss, praktisch beliebige OberflÃ¤chengestaltung

aufweisen kann, ohne dass hierdurch bei der Fertigung Mehrkosten

entstehen. Bringt man hingegen entsprechende KanÃ¤le in den aus Metall bestehenden

SaugkÃ¶rperhalter 2 ein,

wie es in den am Markt befindlichen Zweikammer-Sauggreifern erfolgt,

ist der Fertigungsaufwand erheblich hÃ¶her, da die KanÃ¤le dann

mit Hilfe spanabhebender Materialbearbeitung bei jedem EinzelstÃ¼ck einzeln

eingefrÃ¤st

oder gedreht werden mÃ¼ssen.It is particularly advantageous, these circulating channels 13 in the absorbent body 1 bring as this cheap mold part, the production of which only once a tool must be made, can have virtually any surface design, without resulting in the production of additional costs. In contrast, if you bring appropriate channels in the existing of metal absorbent body holder 2 As is the case in the two-chamber suction grippers on the market, the production outlay is considerably higher since the channels then have to be individually milled or rotated with the aid of machining material processing for each individual piece.

Die 3 und 4 zeigen

daneben noch eine Verdrehsicherung des SaugkÃ¶rpers 1 auf dem SaugkÃ¶rperhalter 2.

Hierzu weist der SaugkÃ¶rper 1 drei

Noppen 14 auf, welche asymmetrisch angeordnet sind und

in entsprechende Vertiefungen des SaugkÃ¶rperhalters 2 (nicht

dargestellt) eingreifen.The 3 and 4 next show still a rotation of the absorbent body 1 on the absorbent body holder 2 , For this purpose, the absorbent body 1 three pimples 14 which are arranged asymmetrically and in corresponding recesses of the absorbent body 2 (not shown) intervene.

Gegenstand

der Erfindung ist nicht nur ein Sauggreifer, bestehend aus einem

SaugkÃ¶rper

und einem SaugkÃ¶rperhalter,

sondern auch ein SaugkÃ¶rper

mit den beschriebenen Merkmalen, insbesondere also mit der integrierten

Innendichtung 7, der integrierten AuÃendichtung 8, der

genauen Gestalt der beiden Dichtungen in W-Form, der Ã¤uÃeren DichtflÃ¤che 9,

den rÃ¼ckseitigen,

umlaufenden KanÃ¤len 13, den

erhabenen Stegen 10, dem schwalbenschwanzfÃ¶rmigen Profil 12 und

den Noppen 14.The subject of the invention is not only a suction gripper, consisting of a suction body and a suction body holder, but also a suction body with the described features, in particular thus with the integrated inner seal 7 , the integrated external seal 8th , the exact shape of the two seals in W-shape, the outer sealing surface 9 , the back, surrounding channels 13 , the sublime bridges 10 , the dovetail-shaped profile 12 and the pimples 14 ,

## Classifications

- B65G47/91
- B25B11/005
- B25B11/007
- B25J15/06
- B25J15/0616

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
