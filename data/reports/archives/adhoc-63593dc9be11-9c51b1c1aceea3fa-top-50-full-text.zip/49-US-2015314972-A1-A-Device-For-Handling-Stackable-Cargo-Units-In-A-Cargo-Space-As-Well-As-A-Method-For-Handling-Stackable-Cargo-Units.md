# 49. A Device For Handling Stackable Cargo Units In A Cargo Space, As Well As A Method For Handling Stackable Cargo Units

- **Archive rank:** 49 of 50
- **Publication:** [US-2015314972-A1](https://patents.google.com/patent/US20150314972A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/047682034/publication/US20150314972A1?q=pn%3DUS20150314972A1)
- **Publication date:** 2015-11-05
- **Filing date:** 2013-12-03
- **Earliest priority:** 2012-12-04
- **Family:** 47682034
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery

## Parties

- **Applicant / assignee:** COPAL DEV B V
- **Inventors:** SCHENNING JOZEF GERHARDUS HENRICUS MARIA

## Abstract

The invention relates to a device ( 100 ) for loading/unloading stackable cargo units ( 101 ) such as boxes ( 101 ) from a cargo space, such as a sea container ( 102 ). Such a device ( 100 ) comprises a movable arm ( 104 ) with a head ( 110 ), comprising an array with downwardly directed gripping bodies (e.g. suction cups ( 211 )). According to the invention there is a second grip section ( 220 ) with which the cargo units ( 101 ) can be gripped at the sides thereof. Hereby also cargo units ( 101 ) of a top row can be unloaded quickly. The invention also relates to a method for the loading/unloading of a cargo space.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/e5/1b/bb/78bfdeecb5ea1c/US20150314972A1-20151105-D00000.png)

![Sketch 1 for US-2015314972-A1](https://patentimages.storage.googleapis.com/e5/1b/bb/78bfdeecb5ea1c/US20150314972A1-20151105-D00000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/6b/37/25/104e140b37e163/US20150314972A1-20151105-D00001.png)

![Sketch 2 for US-2015314972-A1](https://patentimages.storage.googleapis.com/6b/37/25/104e140b37e163/US20150314972A1-20151105-D00001.png)

[Sketch 3](https://patentimages.storage.googleapis.com/06/12/98/e386653126cd36/US20150314972A1-20151105-D00002.png)

![Sketch 3 for US-2015314972-A1](https://patentimages.storage.googleapis.com/06/12/98/e386653126cd36/US20150314972A1-20151105-D00002.png)

[Sketch 4](https://patentimages.storage.googleapis.com/54/26/43/608bc4bca20cea/US20150314972A1-20151105-D00003.png)

![Sketch 4 for US-2015314972-A1](https://patentimages.storage.googleapis.com/54/26/43/608bc4bca20cea/US20150314972A1-20151105-D00003.png)

[Sketch 5](https://patentimages.storage.googleapis.com/88/6e/46/322ec48391cae3/US20150314972A1-20151105-D00004.png)

![Sketch 5 for US-2015314972-A1](https://patentimages.storage.googleapis.com/88/6e/46/322ec48391cae3/US20150314972A1-20151105-D00004.png)

[Sketch 6](https://patentimages.storage.googleapis.com/2f/ec/72/eb935222e772d4/US20150314972A1-20151105-D00005.png)

![Sketch 6 for US-2015314972-A1](https://patentimages.storage.googleapis.com/2f/ec/72/eb935222e772d4/US20150314972A1-20151105-D00005.png)

## Claims

### Claim 1 (independent)

A device for handling stackable cargo units in a cargo space, wherein the device comprises a frame; and comprises a movable arm which has a proximal end and a distal end, wherein the proximal end is connected to the frame, and the distal end is provided with a head for gripping at least one stackable cargo unit, wherein the head comprises a head section, which head section is movable in height relative to the distal end of the arm; and comprises a grip section, which grip section comprises an array of downwardly facing gripping organs for gripping at the upper side of at least one stackable cargo unit of that at least one stackable cargo unit, characterized in that the head section comprises a second grip section at a side of the grip section that comprises the array of downwardly facing gripping organs which is facing away from the side with said array of downwardly facing gripping organs, wherein the second grip section comprises an array of second gripping organs arranged tranverse to the downward direction and facing away from the distal end of the arm, which second gripping organs are movable tranverse to the downward direction of the downwardly facing gripping organs between a first position wherein the second gripping organs are situated relatively close to the distal end of the arm and a second position wherein the second gripping organs are situated relatively far from the distal end of the arm and protrude to beyond the grip section comprising the array of downwardly facing gripping organs. 2 . The device according to claim 1 , wherein the second gripping organs of the second grip section are suction cups. 3 . The device according to claim 1 , wherein the head section is connected rotatably around an upright axis relative to the distal end of the arm with the arm. 4 . The device according to claim 1 , wherein the head section is hydraulically adjustable in height relative to the distal end of the arm. 5 . The device according to claim 1 , wherein the grip section is composed of grip section units which comprise at least 1 downwardly facing gripping organ of the array of downwardly facing gripping organs, wherein the grip section units can be moved independently from each other in a direction with a downward component. 6 . The device according to claim 1 , wherein the second grip section comprises an array of telescopic fingers, wherein the second gripping organs are located at the distal ends of the telescopic fingers, wherein the telescopic fingers can move independently from each other in axial direction. 7 . The device according to claim 1 , wherein the gripping organs of the second grip section can be driven independently from each other. 8 . The device according to claim 1 , wherein the device is a wheeled device. 9 . The device according to claim 1 , wherein the device is provided with a transport track. 10 . The device according to claim 1 , wherein the device and a second frame which comprises a transport track that can be driven form an assembly wherein the transport track that can be driven has a first end and a second end, and the device is movable in the longitudinal direction on and relative to the second frame. 11 . Method for handling stackable cargo units in a cargo space, wherein stackable cargo units are gripped by means of a device which comprises an arm provided with a grip section which comprises an array of downwardly facing gripping organs, characterized in that a device according to any one of claims 1 to 9 is used. 12 . Method according to claim 11 , wherein cargo units of a bottom row of cargo units are picked up using the grip section of downwardly facing gripping organs; and cargo units of a top row in the cargo space are picked up by means of a second grip section of gripping organs by positioning the grip section with the array of downwardly facing gripping organs near a row adjacent to and below the top row of stackable cargo units and placing at least one stackable cargo unit of the top row of cargo units by means of second gripping organs of the second grip section onto the first grip section.

## Full description

**[p0001]**

The present invention relates to a device for handling stackable cargo units in a cargo space, wherein the device comprises a frame; and comprises a movable arm which has a proximal end and a distal end, wherein the proximal end is connected to the frame, and the distal end is provided with a head for gripping at least one stackable cargo unit, wherein the head comprises a head section, which head section is movable in height relative to the distal end of the arm; and comprises a grip section, which grip section comprises an array of downwardly facing gripping organs for gripping at the upper side of at least one stackable cargo unit of that at least one stackable cargo unit. The unloading of stackable cargo units from a cargo space, such as a cargo space of a truck or a sea container,—or the placement of cargo units in such a cargo space—is a labour intensive job. For facilitating this hard work, a device of the above type is known, e.g. from WO2006/121329, which comprises a transport track in the form of a conveyor belt. The gripping organs are in the form of suction cups. During the unloading of the cargo at least the first end of the frame can be introduced into the cargo space. The stackable cargo units are transported to an end of the device that is situated away from the arm by means of the transport track, where they are placed onto a conveyor belt or stacked onto a pallet manually or automatically and are carried off using a forklift truck or the like. The stackable cargo units are boxes, crates, or the like. They usually have h×w×1 dimensions between 15 and 80 cm.

**[p0001]**

The use of an arm permits carrying the weight of the stackable cargo units, whereby workers are less burdened physically or not even burdened at all and can work faster. Especially, if the cargo is cold (for instance frozen), a big advantage can be achieved with the device, since the workers otherwise would have to work wearing gloves, which gloves reduce grip and although they do increase comfort they complicate unloading. Furthermore, an arm makes it possible to simultaneously pick up more than one stackable cargo unit.

**[p0002]**

A problem is that a container that has to be unloaded may be loaded to such an extent that the array of vertically facing gripping organs cannot be introduced between the upper side of the cargo units and the upper side of the cargo space. Thus, these cargo units cannot be picked up with the head section. A similar problem exists when a container has to be filled completely. In that case, the head section has to be able to lift up the bottom of a cargo unit to be placed so high that it finds itself at at least the height of the upper side of another cargo unit onto which said cargo unit has to be placed. Because in that case the head section is limited by the top of the cargo space, this may be impossible. The object of the present invention is to provide a solution for this. To this end, a device according to the preamble is characterized in that the head section comprises a second grip section at a side of the grip section that comprises the array of downwardly facing gripping organs which is facing away from the side with said array of downwardly facing gripping organs, wherein the second grip section comprises an array of second gripping organs arranged tranverse to the downward direction and facing away from the distal end of the arm, which second gripping organs are movable tranverse to the downward direction of the downwardly facing gripping organs between a first position wherein the second gripping organs are situated relatively close to the distal end of the arm and a second position wherein the second gripping organs are situated relatively far from the distal en

**[p0002]**

d of the arm and protrude to beyond the grip section comprising the array of downwardly facing gripping organs.

**[p0003]**

When unloading, the second grip section of second gripping organs permits gripping the at least one cargo unit at a sidewall thereof, pulling the at least one cargo unit onto the grip section with the array of downwardly facing gripping organs and subsequently moving the at least one cargo unit using the movable arm to a desired location such as the first end of a transport track that can be driven such as a conveyor belt where the second grip section of second gripping organs pushes the at least one cargo unit off the array of downwardly facing gripping organs. When loading, for placing at least one cargo unit, in particular for placing cargo units of the top row, the at least one cargo unit can be gripped at a sidewall thereof by the second grip section, the at least one cargo unit can be pulled onto the first grip section with the array of downwardly facing gripping organs and subsequently the at least one cargo unit can be moved to the desired location and to the desired height in the cargo space using the movable arm, and finally by means of the second grip section of second gripping organs be pushed off the first grip section. The gripping organs are for instance gripping pins which protrude into the packaging such as a cardboard box or a bag of textile such as a gunny sack. The height of the device according to the invention, more specifically, the highest part thereof in the lowest position thereof, is preferably lower than the highest internal height of a sea container, i.e. lower than 2 m 75, and more preferably lower than the lowest type, i.e. lower than 2 m 25.

**[p0004]**

According to a favourable embodiment, the second gripping organs of the second grip section are suction cups. Thus the sidewall of a stackable cargo unit can be gripped by means of vacuum. According to a favourable embodiment, the head section is connected rotatably around an upright axis relative to the distal end of the arm with the arm. This provides greater freedom when placing the at least one cargo unit onto a transport track. The head section is for instance rotatable because the head is mounted rotatably at the distal end of the arm. According to a favourable embodiment, the head section are hydraulically adjustable in height relative to the distal end of the arm. Thus, it can be avoided effectively to a large extent that when the at least one cargo unit is placed onto the grip section with the array of downwardly facing gripping organs, this grip section sags to an undesired extent, which would complicate the delivery of the at least one cargo unit present on the grip section with the array of downwardly facing gripping organs.

**[p0005]**

According to a favourable embodiment, the grip section is composed of units which comprise at least 1 downwardly facing gripping organ of the array of downwardly facing gripping organs, wherein the units can be moved independently from each other in a direction with a downward component. Thus, it is ascertained that stackable cargo units of which the upper side is not horizontal, for instance because they collapsed at one side or at both sides, can still be picked up using the head. This spares the workers manual labour. Hereby also the working range (the height over which the array of gripping organs can be moved) is enlarged. This makes it possible to also pick up low (small) stackable packaging units from the bottom of the cargo space. Moving with a downward component is preferably achieved using a hinging parallellogram-construction. For instance, the units have the shape of fingers which extend away from the distal end of the arm. According to a favourable embodiment, the second grip section comprises an array of telescopic fingers, wherein the second gripping organs are located at the distal ends of the telescopic fingers, wherein the telescopic fingers can move independently from each other in axial direction.

**[p0006]**

Thus, irregularaties, for instance caused by cargo units that are not aligned precisely or by a dent in the sidewall of a cargo unit, can be more effectively compensated for and the cargo unit or cargo units can be picked up more reliably. The telescopic fingers are for instance provided as pistons of cylinders, such as pistons of hydraulic cylinders. According to a favourable embodiment, the gripping organs of the second grip section can be driven independently from each other. This also contributes to the ability that irregularaties, for instance formed by a dent in the sidewall of a cargo unit, can be compensated more effectively and that the cargo unit or cargo units can be picked up more reliably. According to a favourable embodiment, the device is a wheeled device. This can then be used at various locations. According to a favourable embodiment, the device is provided with a transport track. Thus, a compact device is provided with which sea containers or the like can be unloaded effectively. The transport track preferably has a width of at least 40 cm and maximally 100 cm, and a length between 2 and 25 meters. Therewith a transport track with an adjustable length, such as a telescopic transport track, is preferred.

**[p0007]**

According to a favourable embodiment, the device and a second frame which comprises a transport track that can be driven form an assembly wherein the transport track that can be driven has a first end and a second end, and the device is movable in the longitudinal direction on and relative to the second frame. Thus, the device can be moved as a whole together with the transport track that can be driven. The second frame has preferably wheels that are placed tranverse to the direction of transport of the transport track as a result of which it can be easily moved in a direction tranverse to the longitudinal direction of a cargo space such as a sea container. The transport track preferably has a width of at least 40 cm and maximally 100 cm, and a length between 2 and 25 meters. A transport track with an adjustable length, such as a telescopic transport track, is preferred. Finally, the present invention relates to method for handling stackable cargo units in a cargo space, wherein stackable cargo units are gripped by means of a device which comprises an arm provided with a grip section which comprises an array of downwardly facing gripping organs, wherein a device according to any one of claims 1 to 9 is used.

**[p0008]**

Thus, a cargo space such as a cargo space of a truck or a (sea)container can be effectively loaded or unloaded. According to a favourable embodiment, cargo units of a bottom row of cargo units are picked up using the grip section of downwardly facing gripping organs; and cargo units of a top row in the cargo space are picked up by means of a second grip section of gripping organs by positioning the grip section with the array of downwardly facing gripping organs near a row adjacent to and below the top row of stackable cargo units and placing at least one stackable cargo unit of the top row of cargo units by means of second gripping organs of the second grip section onto the first grip section. Thus, cargo units can be unloaded effectively irrespective of the row height they are at. The arm will then be moved in order to deliver the at least one stackable cargo unit, for instance to a transport track. The present invention will now be illustrated with reference to the drawing where FIG. 1 shows a side view of the device according to the invention;

**[p0009]**

FIG. 2 shows a side view on the head of the device of FIG. 1 in a first position; FIG. 3 shows a side view on the head of FIG. 2 in a second position; FIG. 4 shows a top view on the head of FIG. 3 in the first position; and FIG. 5 shows a top view on the device of FIG. 1 . FIG. 1 shows a device 100 for unloading of stackable cargo units 101 (boxes 101 ) from a container 102 , or a cargo space of a truck or the like. The device 100 is a wheeled device with wheels 103 . The device has an arm 104 which is operated by an operator (not shown) from a cabin 105 . The arm 104 is slidably mounted to a frame 106 to which the cabin 105 is also fixed. Because of the slidable aspect a larger working range can be provided. The arm 104 is provided with a rotatable head 110 which comprises a first grip section of downwardly facing suction cups as well as a second grip section having suction cups that can move in a horizontal direction. The arrays are part of a head section 111 which can be moved in a vertical direction by means of a first hydraulic cylinder 121 , wherein the whole of the first hydraulic cylinder 121 and the head section 111 can be moved in a vertical direction by means of a second hydraulic cylinder 122 as a result of which the head section 111 can be brought near the bottom of the container 102 and close to the ceiling of the container 102 . The head section 111 will hereinafter be discussed in detail. The head 110 is used for gripping boxes 101 and placing them onto a conveyor belt 130 in order to transport them to a processing station 140 .

**[p0010]**

With the device 100 shown here the conveyor belt 130 is in the form of a telescopic conveyor belt 130 , which in FIG. 1 is shown in a extended position. The conveyor belt 130 and the processing station 140 are part of an auxiliary device 150 , which can be moved by means of transversely placed wheels 141 . The auxiliary device 150 comprises a second frame 151 provided with the transversely placed wheels 141 . The device 100 can be wheeled onto the second frame 151 and thus be transported simultaneously with the auxiliary device 150 . This is very convenient when the device 100 and the auxiliary device 150 have to be used for loading/unloading another container. Instead, it is also possible that the conveyor belt 130 forms an integral part of the device 100 . FIG. 2 shows the head section 111 in detail. A first grip section 210 can be seen of fingers 212 provided with downwardly facing suction cups 211 as downwardly facing gripping organs 211 . The head section 111 can be moved freely over a limited distance in a vertical direction by means of a parallellogram-suspension 213 . When the head section 111 is used to grip boxes with the downwardly facing suction cups 211 , the first grip section 210 approaches the boxes 101 (not shown in FIG. 2 ) from above. As soon as there is contact between the downwardly facing suction cups 211 and the boxes 101 these are held by vacuum generated by vacuum generators 214 and can be placed onto the conveyor belt 130 by moving the arm 104 at which the vacuum is discontinued.

**[p0011]**

Since containers are often loaded all the way to the ceiling, it is not always possible to pick up the top row of boxes 101 with the first grip section 210 since the first grip section 210 cannot be introduced between the top row of boxes and the ceiling. In order to solve this problem the head section 111 has a second grip section 220 of second gripping organs 221 , here also in the form of suction cups, provided with vacuum by vacuum generators 224 . The suction cups are mounted at the distal ends of piston rods 225 of cylinders 226 , by which they can be in a first position close to the distal end of the arm 104 (as shown in FIG. 3 ) or, as shown in FIG. 2 , in a second position in which the second gripping organs 221 protrude beyond the first grip section 210 . According to a possible embodiment the parallellogram-suspension 213 is provided with an actuator 250 , such as a cylinder, in order to lift up the head section 111 , as a result of which the head section 111 can be lifted up extra high, to above the second hydraulic cylinder 122 .

**[p0012]**

FIG. 3 shows the head section 111 in the first position (in which the second gripping organs 221 are close to the distal end of the arm 104 ), wherein the second grip section 220 has slid part of the row of boxes 101 onto the fingers 212 of the first grip section 210 . For placement onto the conveyor belt 130 the piston rods 225 will again be slid from the cylinders 226 . FIG. 4 shows a top view of the head section 111 in the first position. The pistons 225 of the cylinders 226 form telescopic fingers with at the distal ends thereof the second gripping organs 221 (suction cups). FIG. 5 shows the device 100 in a top view at the moment of delivering a number of cargo units 101 , which have been taken from a top row of cargo units in the container 102 , to the conveyor belt 130 . Herewith the first grip section 210 is situated next to the conveyor belt 130 through which the boxes placed on the fingers 212 of the first grip section 210 can be pushed onto the conveyor belt 130 by the second grip section 220 .

**[p0013]**

FIG. 5 shows an upright axis 501 around which the head 110 can rotate. Within the scope of the accompanying claims the invention can be varied in various ways. For example, a separate organ may be provided for pushing a cargo unit on the array off the first grip section, as a result of which this is not done by the second grip section. Within the scope of the accompanying claims the invention can be varied in various ways. For example, the first head section may also comprise a further array of gripping organs which point in the same direction as the second gripping organs but are closer to the distal end of the arm than the array of downwardly facing gripping organs and lower than the last-mentioned gripping organs. In this way a cargo unit can be gripped at the upper side as well as at a sidewall thereof.

## Figure captions

- **Figure 1:** FIG. 1 shows a side view of the device according to the invention;
- **Figure 2:** FIG. 2 shows a side view on the head of the device of FIG. 1 in a first position;
- **Figure 3:** FIG. 3 shows a side view on the head of FIG. 2 in a second position;
- **Figure 4:** FIG. 4 shows a top view on the head of FIG. 3 in the first position; and
- **Figure 5:** FIG. 5 shows a top view on the device of FIG. 1 .
- **Figure 1:** With the device 100 shown here the conveyor belt 130 is in the form of a telescopic conveyor belt 130 , which in FIG. 1 is shown in a extended position.
- **Figure 3:** FIG. 3 shows the head section 111 in the first position (in which the second gripping organs 221 are close to the distal end of the arm 104 ), wherein the second grip section 220 has slid part of the row of boxes 101 onto the fingers 212 of the first grip section 210 . For placement onto the conveyor belt 130 the piston rods 225 will again be slid from the cylinders 226 .
- **Figure 4:** FIG. 4 shows a top view of the head section 111 in the first position. The pistons 225 of the cylinders 226 form telescopic fingers with at the distal ends thereof the second gripping organs 221 (suction cups).
- **Figure 5:** FIG. 5 shows an upright axis 501 around which the head 110 can rotate.

## Classifications

- B65G47/914
- B65G65/08
- B65G65/08
- B65G2201/0235
- B65G2201/0235
- B65G2201/025
- B65G2201/025
- B65G2814/0311
- B65G2814/0311
- B65G35/06
- B65G35/06
- B65G35/06
- B65G47/914
- B65G47/918
- B65G47/918
- B65G61/00
- B65G61/00
- B65G61/00
- B65G63/00
- B65G63/004
- B65G63/004
- B65G65/08
- B65G67/04
- B65G67/04
- B65G67/04
- B65G67/08
- B65G67/08
- B65G67/24
- B65G67/24
- B65G67/24

## Cited patent documents

- [US-2009067953-A1](https://patents.google.com/patent/US20090067953A1/en) — PRS
- [US-2010239408-A1](https://patents.google.com/patent/US20100239408A1/en) — PRS

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
