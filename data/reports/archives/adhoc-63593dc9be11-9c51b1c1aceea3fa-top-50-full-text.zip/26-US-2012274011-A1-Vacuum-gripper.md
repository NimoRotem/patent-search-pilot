# 26. Vacuum-gripper

- **Archive rank:** 26 of 50
- **Publication:** [US-2012274011-A1](https://patents.google.com/patent/US20120274011A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/043466897/publication/US20120274011A1?q=pn%3DUS20120274011A1)
- **Publication date:** 2012-11-01
- **Filing date:** 2010-07-22
- **Earliest priority:** 2009-07-22
- **Family:** 43466897
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus

## Parties

- **Applicant / assignee:** SCHILP MICHAEL; ZIMMERMANN JOSEF; ZIMMERMANN & SCHILP HANDHABUNGSTECHNIK GMBH; ZITZMANN ADOLF
- **Inventors:** SCHILP MICHAEL; ZIMMERMANN JOSEF; ZITZMANN ADOLF

## Abstract

The present invention relates to a vacuum gripper and in particular to a vacuum gripper for gently gripping work-pieces having sensitive surfaces, such as solar cells, wafers, or panels for flat screens, and for gripping heavy glass plates or plates made of other material having a very smooth surface that are stacked on top of each other and should be removed from above, wherein the vacuum gripper has the following characteristics: a straight or curved gripper plate ( 2 ), at least one suction opening ( 3; 3   a ), which is provided in the gripper plate ( 2 ), wherein a workpiece throttle surface ( 6 ) is formed around the suction opening ( 3 ), at least one recess ( 4 ), which is provided in the side of the gripper plate ( 2 ) facing the workpiece, outside of the workpiece throttle surface ( 6 ) relative to the suction opening ( 3 ), and at least one ventilation hole ( 5 ), which is provided within each recess ( 4 ).

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/bd/1b/5c/d9a0c02ba9dcfc/US20120274011A1-20121101-D00000.png)

![Sketch 1 for US-2012274011-A1](https://patentimages.storage.googleapis.com/bd/1b/5c/d9a0c02ba9dcfc/US20120274011A1-20121101-D00000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/94/99/33/4995d663139a9d/US20120274011A1-20121101-D00001.png)

![Sketch 2 for US-2012274011-A1](https://patentimages.storage.googleapis.com/94/99/33/4995d663139a9d/US20120274011A1-20121101-D00001.png)

[Sketch 3](https://patentimages.storage.googleapis.com/8f/3b/89/feb19e8277c338/US20120274011A1-20121101-D00002.png)

![Sketch 3 for US-2012274011-A1](https://patentimages.storage.googleapis.com/8f/3b/89/feb19e8277c338/US20120274011A1-20121101-D00002.png)

[Sketch 4](https://patentimages.storage.googleapis.com/18/b2/f8/6ff15b18559b4a/US20120274011A1-20121101-D00003.png)

![Sketch 4 for US-2012274011-A1](https://patentimages.storage.googleapis.com/18/b2/f8/6ff15b18559b4a/US20120274011A1-20121101-D00003.png)

[Sketch 5](https://patentimages.storage.googleapis.com/6f/72/71/0a4f2c6e531bbf/US20120274011A1-20121101-D00004.png)

![Sketch 5 for US-2012274011-A1](https://patentimages.storage.googleapis.com/6f/72/71/0a4f2c6e531bbf/US20120274011A1-20121101-D00004.png)

[Sketch 6](https://patentimages.storage.googleapis.com/a3/a9/11/a66cf656a335f7/US20120274011A1-20121101-D00005.png)

![Sketch 6 for US-2012274011-A1](https://patentimages.storage.googleapis.com/a3/a9/11/a66cf656a335f7/US20120274011A1-20121101-D00005.png)

## Claims

### Claim 1 (independent)

Vacuum gripper for gripping a work-piece ( 1 ), the vacuum gripper comprising the following features: a plan or curved gripper plate ( 2 ), at least one suction port ( 3 ; 3 a ) which the gripper plate ( 2 ) is provided with, wherein a work-piece suction throttling zone ( 6 ) is formed around the suction port ( 3 ), at least one recess ( 4 ) provided in the gripper plate ( 2 ) at that side thereof directed the work-piece and arranged beyond the work-piece suction throttling zone ( 6 ) formed around the suction port ( 3 ), and at least one vent hole ( 5 ) formed within each of the recesses ( 4 ). 2 . Vacuum gripper according to claim 1 , characterized in that the cross sections of the vent holes ( 5 ) are variable. 25 3 . Vacuum gripper according to claim 1 , characterized in that several vent holes ( 5 ) are formed within each of the recesses, which can be closed selectively. 4 . Vacuum gripper according to claim 1 , characterized in that the vent holes ( 5 ) are filled with a porous material. 5 . Vacuum gripper according to claim 4 , characterized in that the porous material is a foamed plastic having open pores and shaped into a plug. 6 . Vacuum gripper according to claim 1 , characterized in that the vent holes ( 5 ) comprise exchangeable air filters. 7 . Vacuum gripper according to claim 1 , characterized in that the vent holes ( 5 ) are tap-holes for screwing in nozzles having different geometries. 8 . Vacuum gripper according to claim 1 , characterized in that the vent holes ( 5 ) comprise controllable flow valves. 9 . Vacuum gripper according to claim 1 , characterized in that the volumes of the recesses ( 4 ) are variable. 10 . Vacuum gripper according to claim 1 , characterized in that several work-piece suction throttling zones ( 6 ) are provided within a gripper plate ( 2 ). 11 . Vacuum gripper according to claim 1 , characterized in that the gripper plate ( 2 ) is formed as air bearing having air exit nozzles. 12 . Vacuum gripper according to claim 1 , characterized in that the gripper plate ( 2 ) is mechanically coupled to at least one ultrasonic vibrator, wherein the gripper plate ( 2 ) is dimensioned so that it forms an ultrasonic air bearing. 13 . Vacuum gripper according to claim 1 , characterized in that several suction ports ( 3 ) are provided, wherein a work-piece suction throttling zone ( 6 ) is formed around each of the suction ports ( 3 ).

## Full description

**[p0001]**

The present invention relates to a vacuum gripper and, in particular, to a vacuum gripper for gently gripping work-pieces having sensitive surfaces, such as solar cells, wafers or panels for flat screens, and for gripping heavy glass plates or plates made of a material having a very smooth surface, which are stacked on top of each other and are to be removed from above. Vacuum grippers are generally known and are constructively adapted to each case of application, that is, to the work-piece to be gripped. If work pieces having sensitive surfaces are to be gripped, special measures must be taken to prevent that surfaces from being damaged. On principle, there are two kinds of vacuum grippers: On the one hand, there are vacuum grippers which are put onto the work-piece and, at the beginning of the gripping procedure, are mechanically brought into contact with the surface of work-piece, that is, the gripper is provided with a sealing the lips of which effect a sealing action between the surface of work-piece and the gripper so that, when a vacuum is generated within the gripper, the barometric pressure causes the work-piece to be pressed against the sealing lips. However, due to the high contact pressure, the surface of work-piece can be changed undesirably.

**[p0002]**

On the other hand, there are vacuum grippers which are constructed such that they suck the work-piece to the gripper head from a certain distance and hold it in a non-contact way close to the gripping surface of the gripper. This effect is gained when the surface of the gripper is formed as an air bearing, for example. An air bearing can be generated by a field of nozzles from which compressed air flows out or by an oscillating plate such as described in the document EP 1387808 B1 which is completely included in the following description. When the work-piece is sucked, it is urged to the gripper surface by the atmospheric pressure and keeps hanging at it. However, contacting of the gripper surface by the work-piece is prevented by the air bearing. That is, the work-piece is kept levitating under the gripper surface in a predetermined distance without contacting it. However, this functional description is in force only for the stationary state. Therefore, during the procedure of gripping, there is a problem which will be explained below:

**[p0003]**

In order to lift a work-piece by sucking, an increased suction power is required. However, it would be desirable to reduce the suction power before the work-piece reaches its final position, because otherwise, there is the danger that, caused by its mass force of inertia, the accelerated work-piece overcomes the force generated by the air bearing and hits against the surface of gripper. In practice, it is often necessary to chose a maximum suction force 10 times greater than the holding force actually required, which, in turn, must slightly be greater than the weight of work-piece, that is, the mass thereof. Also, there are gripping actions where the maximum suction force must still be greater. This is the case when glass plates have to be lifted separately from a stack or a glass plate has to be lifted from a table having a very smooth surface, for example. In such a case, almost no air is present between the glass plate and the surface of table. When the glass plate is lifted up, first if all, during lifting, the surrounding barometric pressure must be overcome to form a small gap into which air can enter. When the gap is completely filled with air und, thus, the pressure in the gap corresponds to the barometric pressure, the contact pressure initially generated becomes zero so that merely the weight of work-piece has to be overcome. The additional force necessary for separating smooth plates is called breakaway force in the following.

**[p0004]**

Therefore, a vacuum suction gripper sucking work-pieces without contacting them mechanically, has to be designed so that the suction force of the gripper overcomes the breakaway force and then, accelerates the work-piece towards the surface of gripper, against the gravitational force. It would be desirable to decelerate the work-piece and thus, to reduce its mass force of inertia as soon as it reaches a predetermined distance to the surface of gripper to prevent it from hitting against the gripper. In an automatic process, as the work-pieces to be lifted have the same size and the same weight, it is theoretically possible to arrange a fast-reacting valve control means behind the suction nozzle, which, after the breakaway force has been overcome, reduces the suction flow in a first action so that the work-piece in the shape of a plate is decelerated to the technologically optimum speed. A second throttling action can be carried out after the plate has already been lifted a predetermined distance, in order to decelerate the plate such that it reaches its final position at the surface of gripper.

**[p0005]**

An expert knows that the control of such highly dynamic processes is extremely complex and thus costly, because it is difficult to control gaseous media, conditioned by the compressibility thereof. Therefore, subject matter of the invention is to provide a reliable and low-cost device enabling also smooth plates requiring a great breakaway force to be lifted in a non-contact way. This subject matter is solved by a vacuum gripper according to claim 1 , wherein the vacuum gripper comprises the following features: a flat or an arched gripper plate. The gripper plate can be flat to hold plane plates, it can be arched one-dimensionally to hold tubes, for example, or can be arched two-dimensionally to hold ball-shaped work-pieces, for example. Also, the gripper plate can have a shape adapted to the surface of a work-piece to be gripped, provided that the technical science described below is convertible in fluidic respect. The gripper plate is provided with at least one suction port in which a vacuum can be generated. The suction port is surrounded by a work-piece suction throttling zone. The work-piece suction throttling zone is an area section which, together with the surface of the work-piece, forms a defined gap when the work-piece is sucked. As soon as the work-piece has reached its final position, it is kept hanging at the gripper plate predominantly through this gap. Therefore, the work-piece suction throttling zone is dimensioned so that the suction force generated around this zone is greater than the force caused by the mass-dependant weight of work-piece and acting in th

**[p0005]**

e opposite direction.

**[p0006]**

In addition, the gripper plate is provided with at least one recess, on that side thereof directed to the work-piece. According to the technical science of the invention, this recess is always arranged beyond the work-piece suction throttling zone. In other words, the air sucked in from the edge of the gripper plate flows along the gripper plate up to the suction port, thereby passing the recess assigned to and positioned in front of it. The recess is provided with at least one vent hole. The function of the vacuum gripper will be described below. As soon as the bottom side of the gripper has reached a position about 2 mm to 0.5 mm away from the top side of work-piece, the vacuum gripper acts like a common vacuum gripper, that is, air is sucked in at the edge of the gripper and flows up to the suction port. Thereby, a negative pressure is generated along the entire gripper surface, the altitude of which lowering in the direction to the edge of gripper. The negative pressure has a constant height within the recess. A predetermined quantity of air is also sucked in through the vent hole. However, this quantity of air is relatively small compared with that sucked in through the 2 mm to 0.5 mm wide gap along the gripper surface.

**[p0007]**

With this constellation, with a given constant suction pressure and the given area of the gripper plate, the gripper generates its maximum lifting force. The more the work-piece approaches to the gripper surface, the narrower the gap and ,thus, the smaller the cross section through which air can flow from the edge of gripper plate. However, the cross section of the vent hole remains constant. The result is that a negative pressure can not be generated any longer within the recess because air permanently flows through the vent hole into it from the outside. This effect is increased when the cross section through which air is sucked in from the edge of gripper becomes smaller. Therefore, the area of the recess does not contribute any longer to the suction force being the product of effective suction area and suction pressure. In other words: With this constellation, the effective suction area is essentially restricted to the work-piece suction throttling zone and thus, is smaller than that formed with a greater distance between the gripper surface and the surface of work-piece, by a multiple. Thus, the suction force also is smaller by a multiple.

**[p0008]**

Therefore, the wanted effect is gained, that is, the vacuum gripper generates a very great suction force with a greater distance to the surface of the work-piece to be gripped, which, however, strongly decreases when the surface of work-piece approaches the vacuum gripper, so that, with proper dimensioning of gripper, the work-piece can be prevented from hitting against it. Thus, the suction force is reduced automatically. When the vacuum gripper is competently dimensioned dependant on the weight of work-piece and the height of suction pressure, the work-piece can be kept levitating without contacting it. In this case, a force balance, that is, a balance between the suctions force lifting the work-piece and the weight of work-piece, which acts downwardly, is gained. When the suction force is changed, that is, is reduced, for example, the work-piece slightly sags. Thereby, the effective suction area is increased, with the result, that the suction force is increased and, thus, the work-piece is drawn upwardly again.

**[p0009]**

This levitation state is always regulated and is independent on the surface condition of work-piece. Therefore, not only glass plates having smooth surfaces, but also wooden plates having coarse surfaces can be gripped by this gripper. With a further advantageous embodiment of the vacuum gripper according to claim 2 , the vent holes are executed variably. This enables the suction force to be adjusted to a predetermined distance between the surface of work-piece and the gripper in a simple way. With a further advantageous embodiment of the vacuum gripper according to claim 3 , each of the recesses is provided with several vent holes which can be closed by choice. This enables the suction force to be adjusted to a predetermined distance between the surface of work-piece and the gripper in a simple way. With a further advantageous embodiment of the vacuum gripper according to claim 4 , the vent holes are filled with a porous material having the function of a throttle. Thus, the cross section of the vent hole can be dimensioned greater, which enables small-sized grippers to be made more advantageously.

**[p0010]**

With a further advantageous embodiment of the vacuum gripper according to claim 5 , the porous material is a foamed plastic having open pores and being shaped into a plug. Such plugs can easily be made and exchanged. With a further advantageous embodiment of the vacuum gripper according to claim 6 , alternatively to the porous material, the vent holes are provided with air filters which function as throttles and can also be exchanged easily. With a further advantageous embodiment of the vacuum gripper according to claim 7 , the vent holes are executed as tap-holes into which nozzles having different geometries and thus, predetermined flow profiles can be screwed. With a further advantageous embodiment of the vacuum gripper according to claim 8 , the vent holes comprise controllable flow valves. Thus, when the work-piece is sucked in, the rate of air flow can be controlled effectively and thus, the suction and holding characteristics of the vacuum gripper can be improved. With a further advantageous embodiment of the vacuum gripper according to claim 9 , the volume of the recess is alterable so that the gripper can be adjusted to an other work-piece more quickly. An alteration of this volume can be effected by inserting any material into the recess. When the gripper is made of steel, for example, magnets can be inserted into the recesses without requiring additional fixing means. It is also possible to screw bolts into the recesses so that the heads thereof contribute to the volume reduction within the recesses.

**[p0011]**

With a further advantageous embodiment of the vacuum gripper according to claim 10 , the gripper plate is provided with several work-piece suction throttling zones. Such an arrangement is chosen when a plate to be lifted is to be held at several points. An expert knows that the work-piece suction throttling zones must not have an annular shape unconditionally, but can extend rectilinearly, which will be explained in more detail with the description of the exemplified embodiments. With a further advantageous embodiment of the vacuum gripper according to claim 11 , the gripper plate is designed as air bearing having air exit nozzles. Thus, an additional measure for preventing any contact between the work-piece and the gripper is provided. According to claim 12 , as an alternative to the embodiment according to claim 11 , the gripper plate is mechanically coupled to at least one ultrasonic vibrator and dimensioned so that an ultrasonic air bearing such as described in EP 1387808 B1, for example, is formed.

**[p0012]**

With a further advantageous embodiment of the vacuum gripper according to claim 13 , the gripper plate is provided with several suction ports, wherein a work-piece suction throttling zone is formed around each of the suction ports. Such an arrangement can be used advantageously for lifting a work-piece having an even surface, for example, which the gripper applies to, but being different in thickness. The suction ports can be admitted with different suction pressures, which enable a work-piece to be lifted uniformly and in horizontal position. In the following, the invention will be described by means of exemplified embodiments in connection with the drawings enclosed. FIG. 1 a,b show a first embodiment of the vacuum gripper. FIG. 2 a,b show a second embodiment of the vacuum gripper. FIG. 3 a,b show a third embodiment of the vacuum gripper. FIG. 4 a,b show a fourth embodiment of the vacuum gripper FIGS. 1 a,b show a cross-sectional view of a circular vacuum gripper for carrying a work-piece 1 , wherein the vacuum gripper comprises the following features: a disk-shaped round gripper plate 2 provided with a suction port 3 in its center. A round annular work-piece throttling zone 6 is formed around the suction port 3 , the operating characteristics of which being explained in the consecutive section. The gripper plate 2 is also provided with an annular recess 4 extending towards the margin of plate, which has two vent holes 5 dislocated to each other by 180 degrees, that is, the entire recess 4 is connected with the atmosphere.

**[p0013]**

FIG. 1 a shows the work-piece 1 still in its initial position. By the suction action of the gripper, air is sucked from the outside of gripper through the gap 7 usually having a width of about 2 mm to 0.8 mm and flows through the suction port 3 . In this position, the vacuum gripper generates its maximum suction force being greater than the weight of the work-piece 1 . Thereby, the work-piece 1 lifted. In other words: When the bottom side of the gripper approaches the surface of work-piece, the vacuum gripper acts like a common vacuum gripper, that is, air is sucked via the edge of gripper plate and flows towards the suction port. Thus, a negative pressure is generated along the entire gripper surface, the height of which decreasing towards the edge of gripper. However, in the region of the recess 4 , the negative pressure P is constant, represented by the plateau line 8 in the diagram A below this figure. Also, a predetermined volume of air is sucked through the vent hole. However, this volume of air is relatively small compared with that sucked through the 2 mm to 0.5 mm wide gap.

**[p0014]**

In the diagram B, in addition to the pressure distribution indicated in diagram A, a pressure distribution 9 is indicated, which would arise without the recesses 4 . As shown in FIG. 1 b , the more the work-piece approaches the gripper surface, the smaller the gap 7 through which air flows from the outside, that is, from the edge of gripper plate. Thus, the cross section of the gap, through which air can flow from the edge of gripper plate, is reduced remarkably. However, the cross sections of the vent holes remain constant. Because air in an adequate amount can permanently flow from the outside through the vent holes, a negative pressure is not generated any longer in the recess 4 . This effect is intensified with the reduction of the cross section of the gap 7 through which air flows from the outside. Therefore, the area of the recess does not contribute any longer to the suction force being the product of effective suction area and suction pressure. In other words: With this constellation, the effective suction area is essentially restricted to the work-piece suction throttling zone 6 and thus, is smaller than that formed with a greater distance between the gripper surface and the surface of work-piece, by a multiple. Thus, the suction force also is smaller by a multiple.

**[p0015]**

Therefore, the wanted effect is gained, that is, the vacuum gripper generates a very great suction force with a greater distance to the surface of the work-piece to be gripped, which, however, is decreased remarkably when the surface of work-piece approaches the vacuum gripper so that hitting of the work-piece against the gripper is prevented, provided that the gripper is dimensioned properly. The diagrams A and B drawn below figure lb represent the pressure distribution with and without a recess 4 , respectively. Thus, the suction force is reduced automatically. When the vacuum gripper is competently dimensioned based on the weight of work-piece and the height of suction pressure, the work-piece can be held in a levitation state without contacting the vacuum gripper. In this case, a force balance is gained between the suction force lifting the work-piece and the weight drawing the work-piece downwardly. When the suction force is somewhat lowered, for example, the work-piece 1 slightly sags. However, as the effective suction area is increased at this moment, the suction force is also increased so that the work-piece 1 is drawn upwardly again.

**[p0016]**

Nozzle geometry and negative pressure required are determined by the properties of the work-piece to be gripped. With numerous technological processes, work-pieces of the same kind are used so that nozzle and pressure parameters can be kept constant. As the nozzle and pressure parameters are dependant on the size, the weight, the surface and some further features of work-piece, it is not meaningful to specify shapes of nozzles and other parameters. Further embodiments of the vacuum gripper are shown in the corresponding figures mentioned above, all of which working according to the technical science described in connection with FIG. 1 . Therefore, in the following, the new features of each of these embodiments will be described only, but not the general technical science again. FIGS. 2 a,b show a circular gripper plate having a suction port 3 and four suction ports 3 a, in which a vacuum is generated, wherein the suction ports 3 a are connected with each other by an annular groove. With this embodiment, as the sum of the cross sections of the suction ports 3 a is remarkably smaller than the cross section of the suction port 3 , the suction effect thereof is also smaller than that of the suction port 3 . If necessary, the cross sections of the suction ports 3 a can be increased such that the suction effect thereof is almost the same as that of the suction port 3 .

**[p0017]**

FIGS. 3 a,b show a rectangular gripper plate for optimum gripping of work-pieces preferably being rectangular in shape. With this embodiment, the suction port 3 has a rectangular cross section and the groove-like recesses 4 are arranged in parallel with each other. FIGS. 4 a,b show a gripper plate like that represented in FIG. 3 , but designed for gripping a tube. For this purpose, the shape of gripper plate is proportioned to the radius of tube.

## Figure captions

- **Figure 1:** FIG. 1 a,b show a first embodiment of the vacuum gripper.
- **Figure 2:** FIG. 2 a,b show a second embodiment of the vacuum gripper.
- **Figure 3:** FIG. 3 a,b show a third embodiment of the vacuum gripper.
- **Figure 4:** FIG. 4 a,b show a fourth embodiment of the vacuum gripper
- **Figure 1:** FIG. 1 a shows the work-piece 1 still in its initial position. By the suction action of the gripper, air is sucked from the outside of gripper through the gap 7 usually having a width of about 2 mm to 0.8 mm and flows through the suction port 3 . In this position, the vacuum gripper generates its maximum suction force being greater than the weight of the work-piece 1 .
- **Figure 1:** Further embodiments of the vacuum gripper are shown in the corresponding figures mentioned above, all of which working according to the technical science described in connection with FIG. 1 . Therefore, in the following, the new features of each of these embodiments will be described only, but not the general technical science again.
- **Figure 3:** FIGS. 3 a,b show a rectangular gripper plate for optimum gripping of work-pieces preferably being rectangular in shape. With this embodiment, the suction port 3 has a rectangular cross section and the groove-like recesses 4 are arranged in parallel with each other.
- **Figure 4:** FIGS. 4 a,b show a gripper plate like that represented in FIG. 3 , but designed for gripping a tube. For this purpose, the shape of gripper plate is proportioned to the radius of tube.

## Classifications

- B65G47/91
- B65G47/91
- B65G47/911
- B25B11/00
- B25J15/0616
- B25J15/0616
- B65G2249/04
- B65G47/911
- B65G47/911
- B65G49/061
- B65G49/061
- B65G49/061
- H10P72/78
- H10P72/78
- H10P72/78

## Cited patent documents

- [US-4618292-A](https://patents.google.com/patent/US4618292A/en) — PRS
- [US-6515288-B1](https://patents.google.com/patent/US6515288B1/en) — PRS
- [US-6644703-B1](https://patents.google.com/patent/US6644703B1/en) — PRS
- [US-6781684-B1](https://patents.google.com/patent/US6781684B1/en) — PRS
- [US-6808358-B1](https://patents.google.com/patent/US6808358B1/en) — PRS
- [US-6899765-B2](https://patents.google.com/patent/US6899765B2/en) — PRS
- [US-7908885-B2](https://patents.google.com/patent/US7908885B2/en) — PRS
- [US-8142111-B2](https://patents.google.com/patent/US8142111B2/en) — PRS

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
