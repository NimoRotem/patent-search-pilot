# 17. A device for a tool and the proceeding for manufacture the same

- **Archive rank:** 17 of 50
- **Publication:** [WO-2009078797-A1](https://patents.google.com/patent/WO2009078797A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/039812037/publication/WO2009078797A1?q=pn%3DWO2009078797A1)
- **Publication date:** 2009-06-25
- **Filing date:** 2008-12-15
- **Earliest priority:** 2007-12-19
- **Family:** 39812037
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery

## Parties

- **Applicant / assignee:** AUTOLABEL AB; DIJKSTRA GERARD; SOEDERGAARD JONAS
- **Inventors:** DIJKSTRA GERARD; SOEDERGAARD JONAS

## Abstract

The invention relates to a device for a tool (2) as well as a proceeding for the manufacture thereof. The device (1) is adaptable for supporting objects and works with negative pressure and is provided with one or more ducts (3) in order to conduct negative pressure of said tool (2) manufactured by, e.g., free forming. The tool (2) is preferably formed of a solid piece and comprises, in close connection to the suction side of the same, one or more vacuum ejectors (4) having a fitting (5) for compressed air (6) and a number of vacuum suction ducts (3) extending from said vacuum ejectors (4) to the suction side of the tool.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf000.png)

![Sketch 1 for WO-2009078797-A1](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf001.png)

![Sketch 2 for WO-2009078797-A1](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf002.png)

![Sketch 3 for WO-2009078797-A1](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf003.png)

![Sketch 4 for WO-2009078797-A1](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf004.png)

![Sketch 5 for WO-2009078797-A1](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf005.png)

![Sketch 6 for WO-2009078797-A1](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf006.png)

![Sketch 7 for WO-2009078797-A1](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf007.png)

![Sketch 8 for WO-2009078797-A1](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf008.png)

![Sketch 9 for WO-2009078797-A1](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf009.png)

![Sketch 10 for WO-2009078797-A1](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf009.png)

[Sketch 11](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf010.png)

![Sketch 11 for WO-2009078797-A1](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf010.png)

[Sketch 12](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf011.png)

![Sketch 12 for WO-2009078797-A1](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf011.png)

[Sketch 13](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf012.png)

![Sketch 13 for WO-2009078797-A1](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf012.png)

[Sketch 14](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf013.png)

![Sketch 14 for WO-2009078797-A1](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf013.png)

[Sketch 15](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf014.png)

![Sketch 15 for WO-2009078797-A1](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf014.png)

[Sketch 16](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf015.png)

![Sketch 16 for WO-2009078797-A1](https://nimo.iptorch.com/refdrawing/WO-2009078797-A1/pdf015.png)

## Claims

### Claim 1

A141 P2PCT LG/KOE CLAIMS 1. Device (1; 101) for a retaining tool (2; 102; 202) for supporting objects and that works with negative pressure and that is provided with one or more ducts (3; 103) in order to conduct negative pressure of said tool (2; 102; 202) manufactured by, e.g., free forming, characterized in that the tool (2; 102; 202) preferably is formed of a solid piece and comprises, in close connection to the suction side of the same, one or more vacuum ejectors (4; 104; 204) having a fitting (5; 105) for compressed air (6; 106) integrated in the tool and a number of vacuum suction ducts (3; 103) extending from said vacuum ejectors (4; 104) to the suction side (8; 108) of the tool. 2. Device according to claim 1, characterized in that, internally in the tool (2; 102), a number of vacuum ejec- tors (4; 104) are received to which a fitting (5; 105) for compressed air (6; 106) leads, and that vacuum suction ducts (3, 103) extend from formed vacuum ejectors (4, 104) inside the tool (2; 102) to the suction side (8; 108) of the tool. 3. Device according to any one of the preceding claims, the tool (2) forming a applicator plate for the application of labels (50) on objects, characterized in that inlet (5) and outlets (7), respectively, for compressed air (6) are situated on a common side (9) of the plate (2) or on different sides (10, 11; 12, 13) of the plate (2) . 4. Device according to any one of the preceding claims, characterized in that the applicator side (14) of the plate (2) has a number of ducts (15) connecting to the open- ing(s) (16) of the duct(s) 3 of said vacuum ejectors (4) . 5. Device according to claim 4, characterized in that vacuum ejector openings (16) are situated mutually equi- distantly from each other along the respective duct (15) . 6. Device according to claim 5, characterized in that ducts (15) distributed line-wise and equidistantly from each other have vacuum ejectors (4) line-wise distributed transversely to the length extension (L) of said ducts. 7. Device according to any one of claims 4-6, characterized in that pair-wise or a plurality of vacuum suc- tion ducts (15) are connected to a common compressed-air fitting (17) for the respective vacuum ejector (4) . 8. Device according to any one of claims 4-7, characterized in that compressed-air fitting tunnels (17), situated internally in the plate (2) and extending along the surface extension of the plate and the suction side (8) of the plate (2), are distributed line-wise along said ducts (15) . 9. Device (101) according to claim 1, the tool (102) forming a lifting grip attachment for the fixation of individual parts by means of the robot arm of a robot, etc., characterized in that inlet (105) and outlets (107), respectively, for compressed air (106) are directed in different directions from the lifting grip attachment or are situated on a common side of the same. 10. Device according to claim 9, characterized in that the tool (102) is formed of an elongate curved handle hav- ing inlet (105) at the centre (149) thereof and outlets (107) at the respective ends (150, 151) thereof and having vacuum grip attachments (152) placed at the respective end portions (102A, 102B) of the handle. 11. Device according to claim 10, characterized in that the ejectors (104) are situated internally in the handle (102) at the respective ends (150, 151) thereof and are formed of ducts (175-177) intersecting each other and leading from air inlet (105), air outlet duct (107) as well as vacuum duct (103) . 12. Device according to claim 1, characterized in that, externally on the tool (202) , a number of vacuum ejectors (204) are detachably fastened and to which a fitting for compressed air leads, and that vacuum suction ducts (251) extend from formed vacuum ejectors (204) inside the tool (202) to the suction side of the tool. 13. Device according to claim 12, characterized in that vacuum ejectors (204) are fastened on the upperside (209) of the tool (202) by means of screws (250), and that ducts (251) for suction connection as well as screw holes (252) are integrated in the tool (202) on the upperside thereof. 14. Proceeding for the production of a tool according to any one of the preceding claims, characterized in that the tool (2; 102), in which pressure ducts, etc., as well as vacuum ejectors (4; 104) are integrated, is produced by casting or free forming of an integral piece of material of metal or plastic material.

## Full description

**[0001]**

A141 P2PCT LG/KOE

**[0002]**

A device for a tool and the proceeding for manufacture the same

**[0003]**

The present invention relates to a device for a retaining tool for supporting objects and that works with negative pressure and that is provided with one or more ducts in order to conduct negative pressure of said tool manufactured by, e.g., free forming.

**[0004]**

Applicator plates are utilized as carriers of labels from the moment when they have been dispensed away from the bottom paper of the paper web concerned to the moment when they have been pressed in place on objects concerned. In that connection, the label in question is held in place by means of negative pressure, which is provided by means of fans or a num- ber of vacuum ejectors. However, when using fans, there is the limitation that they are large, and when using ejectors, the disadvantage follows that high losses arise because of they being at a great distance from the position where they normally are most favourable. See, for instance, WO 2005/095215 Al. In that connection, the main object of the present invention is to solve said problems by simple and well working means.

**[0005]**

Said object is attained by means of a device according to the present invention that essentially is charac- terized in that the tool preferably is formed of a solid piece and comprises, in close connection to the suction side of the same, one or more vacuum ejectors having a fitting for compressed air integrated in the tool and a number of vacuum suction ducts extending from said vacuum ejectors to the suction side of the tool.

**[0006]**

Production of different objects can simply and efficiently be carried out by means of so-called free forming, i.e., a method that is based on layers of plastic material

**[0007]**

being applied for the formation of said objects based on a 3D geometry. Examples of this are shown among others in SE 527337 C2, in which patent specification it is shown and disclosed a method for, by means of free forming, providing grip attach- ments having integrated vacuum ducts. A fitting to an external vacuum source is, in that connection, shown in the form of a vacuum nipple (5) .

**[0007]**

Another free forming manufacturing method is casting, e.g., investment casting where the object in question is produced from a metallic material.

**[0008]**

Therefore, an additional object of the present invention is also to provide a proceeding for the production of a tool according to what has been mentioned above.

**[0009]**

Therefore, an object of the present invention is to provide an improved solution by a proceeding for the production of simple or complicated applicator plates preferably having integrated vacuum ejectors in a simple and effective way by free forming. Vacuum does not provide so high an effect since the negative pressure cannot be that great. In that con- nection, by utilizing pressure conducted in pressure ducts, the losses are decreased. This makes it is possible to place the ejectors next to the location where vacuum should be created as well as that it is possible to select as many ejectors as desired at a very low cost. Another advantage is that it is possible to decrease the flow in the ejector and thereby sup<¬> press noise as well as also save energy. A solid tool piece allows a tight arrangement with ejectors along the tool and the working surface thereof.

**[0010]**

Said additional object is attained by means of a proceeding that essentially is characterized in that the tool in which pressure ducts, etc., as well as vacuum ejectors are integrated is produced by casting or free forming of an inte<¬> gral piece of material of metal or plastic material.

**[0012]**

In the following, the invention is described in the form of a number of preferred embodiment examples, reference being made to the accompanying drawings in which,

**[0011]**

Fig. 1 shows a view from above of a tool for supporting labels,

**[0012]**

Fig. 2 shows the tool from the suction side thereof,

**[0013]**

Fig. 3 shows a section view along the line III-

**[0014]**

III in Fig. 1, Fig. 4 shows a section view along the line IV-

**[0015]**

IV in Fig. 1,

**[0016]**

Fig. 5 shows a section view along the line V-V in Fig. 1,

**[0017]**

Fig. 6 shows an enlargement of a vacuum ejector that is encircled in Fig. 5,

**[0018]**

Fig. 7 shows a view from above of the tool as seen in perspective,

**[0019]**

Fig. 8 shows a front view of the tool as seen in perspective, Fig. 9 shows a label adhered by suction on the front side of a tool,

**[0020]**

Figs. 10-11 schematically show ducts included in the tool,

**[0021]**

Figs. 12-14 show a variant of a supporting tool, wherein

**[0022]**

Fig. 12 shows the supporting tool in perspective,

**[0023]**

Fig. 13 shows the tool as seen from the front side thereof, Fig. 14 shows a section view along the line

**[0024]**

XIV-XIV in Fig. 13,

**[0025]**

Figs. 15-17 show a variant of a tool, wherein

**[0028]**

Fig. 15 shows in perspective and obliquely from above a partly exploded view of a tool,

**[0026]**

Fig. 16 shows the tool straight from above, and Fig. 17 shows different section views according to the arrows in Fig. 16.

**[0027]**

By the determination tool, reference is made to an applicator plate, attachment for lifting objects or other means suitable to grip as well as retain and deliver objects between different locations. According to the present invention, a device 1, intended to be applied for a retaining tool 2 in order to allow support of objects and that works by means of vacuum suction/negative pressure and that is provided with a number of ducts 3 for vacuum suction received internally in said tool 2 manufactured by, e.g., free forming or casting, comprises a number of vacuum ejectors 4 received internally in or at close distance on or at the tool 2. A fitting 5 for compressed air 6 leads to said present vacuum ejectors 4. The vacuum suction ducts 3 extend from one or more formed vacuum ejectors 4, which is or are integrated with the tool 2, to the suction side 8 of the tool.

**[0028]**

According to the embodiment example shown in the drawings in Figs. 1-13, the tool 2 is formed of an applicator plate arranged to allow simple and efficient application of labels 50 onto intended objects. In that connection, inlet 5 for compressed air 6 and outlets 7 for compressed air 6, respectively, are situated on a common side 9 of the plate 2 or on different sides 10, 11; 12, 13 of the plate 2.

**[0029]**

The proper applicator side 14 of the plate 2, which is common with the suction side 8 thereof, has ducts 15 connecting to the openings 16 of the ducts 3 of said vacuum ejectors 4, which openings suitably are situated mutually equi- distantly from each other along the respective duct 15.

**[0033]**

In that connection, ducts 15, preferably distributed line-wise and equidistantly from each other, have vacuum ejectors 4 line-wise distributed transversely to the length extension L of said ducts. Pair-wise or several vacuum suction ducts 15 are, in that connection, connected to a common compressed-air fitting 17 for the respective vacuum ejector 4. In that connection, compressed-air fitting tunnels 17, situated internally in the plate 2 and extending along the surface extension of the plate and the suction side 8 of the plate 2, may be distributed line-wise along said ducts 15 and which fittings 17 laterally may be connected with transverse ducts 18.

**[0030]**

The proceeding according to the present invention for the production of a tool 2 according to the type mentioned above in the form of an applicator plate 2 for the fixa- tion of labels 50 before the application of the same onto desired products, e.g., packages, and which comprises an optional number of suction ducts 15 as well as an optional number of ejectors 4, is provided by the fact that the tool 2, in which pressure ducts, etc., 5, 17, 18 as well as vacuum ejec- tors 4 are integrated internally therein, is produced by casting or by free forming of an integral piece of material. However, this does not prevent that a desired number of tools 2 situated laterally are mounted together in case it is desired to cover a larger surface than what the individual tool 2 nor- mally covers. Numbers 19 and 20, respectively, designates holes in the tool for receipt of a fixing screw and a probe, respectively.

**[0031]**

As shown in Figs. 14-16, the invention also relates to a device 101 where the tool 102 in question forms a lifting grip attachment for the fixation of individual parts by means of the robot arm of a robot or by means of the arm of a human, etc., and which tool 102 also works with vacuum suction and which is provided with ducts 103 for vacuum suction

**[0036]**

received internally in said tool 102 manufactured by free forming. According to the invention, a number of vacuum ejectors 104 are received internally in the tool 102 to which ejectors ducts 115 lead from a fitting 105 for compressed air 106, and vacuum suction ducts 103 extend from formed vacuum ejectors 104 inside the tool 102 to the suction side 108 of the tool.

**[0032]**

In that connection, inlet 105 and outlets 107, respectively, for compressed air may be directed in different directions from the air grip attachment or be situated on a common side of the same.

**[0033]**

Specifically, the tool 102 is, in that connection, formed of an elongate curved handle having compressed-air inlet 105 at the centre 149 thereof and compressed-air outlets 107 at the respective ends 150, 151 thereof and is provided with vacuum grip attachments 152 placed at the respective end portions 102A, 102B of the handle.

**[0034]**

A proceeding for the production of a tool according to the invention is carried out in such a way that the tool 2; 102, in which pressure ducts, etc., as well as vac- uum ejectors 4; 104 are integrated, is produced by free forming of an integral piece of material.

**[0035]**

An additional production proceeding is casting, as has been indicated above, containing cavities of the intended tool intended to be cast being formed of, e.g., wax or another material that easily can be removed after the casting.

**[0036]**

Thus, the ejectors 104 are situated internally in the handle 102 at the respective end 150 and 151 thereof and they are formed of ducts intersecting each other, similar to a T road crossing with ducts 175, 176, 177 leading from air inlet 105, air outlet duct 107 as well as vacuum duct 103.

**[0037]**

The embodiment example of the tool 202 shown in

**[0038]**

Figs. 15-17 is the same as shown and described according to the first embodiment above, but the vacuum ejectors 204 are loose

**[0044]**

and mounted on the upperside 209 of the tool 202 and fastened by screws 250. Ducts 251 for suction connection as well as screw holes 252 are, in that connection, integratedly arranged in the solid tool 202 on the upperside thereof, which is shown in Fig. 15 as an example. Otherwise, the device and the function of the tool are the same as indicated above.

**[0039]**

The function and the nature of the invention are clearly seen from what has been described above and shown and referred to in the drawings. Manufactured tools may be utilized in ways previously known per se.

**[0040]**

Naturally, the invention is not limited to the embodiments described above and shown in the accompanying drawings. Modifications are feasible, particularly as for the nature of the different parts, or by using an equivalent tech- nique, without departing from the protection area of the invention, such as it is defined in the claims.

## Classifications

- B25B11/005
- B25J15/0616
- B25B11/00
- B25B11/005
- B25B11/007
- B25J15/06
- B25J15/0616
- B65C9/14
- B65C9/14
- B65C9/1815
- B65C9/1876
- B65C9/26
- B65C9/36
- B65H2220/09
- B65H2406/3661
- B65H2701/192
- B65H3/08
- B65H3/0883
- B65H3/0883

## Cited patent documents

- [EP-1308633-A1](https://patents.google.com/patent/EP1308633A1/en) — ISR
- [SE-466561-B](https://patents.google.com/patent/SE466561B/en) — ISR
- [US-4185814-A](https://patents.google.com/patent/US4185814A/en) — ISR
- [US-5704673-A](https://patents.google.com/patent/US5704673A/en) — ISR
- [WO-2006001762-A1](https://patents.google.com/patent/WO2006001762A1/en) — ISR

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
