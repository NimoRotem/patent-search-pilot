# 48. End of line pick and place unit

- **Archive rank:** 48 of 50
- **Publication:** [EP-3453653-A1](https://patents.google.com/patent/EP3453653A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/062062913/publication/EP3453653A1?q=pn%3DEP3453653A1)
- **Publication date:** 2019-03-13
- **Filing date:** 2018-04-24
- **Earliest priority:** 2017-05-02
- **Family:** 62062913
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus

## Parties

- **Applicant / assignee:** GEA FOOD SOLUTIONS GERMANY GMBH
- **Inventors:** JAMES CRUICKSHANK; THORSTEN BURK

## Abstract

The present invention relates to a gripper unit (6) comprising a housing (20) at which a tool (12) is releasably provided, that comprises all grippers (7) for a specific application.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/EP-3453653-A1/000.png)

![Sketch 1 for EP-3453653-A1](https://nimo.iptorch.com/refdrawing/EP-3453653-A1/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/EP-3453653-A1/001.png)

![Sketch 2 for EP-3453653-A1](https://nimo.iptorch.com/refdrawing/EP-3453653-A1/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/EP-3453653-A1/002.png)

![Sketch 3 for EP-3453653-A1](https://nimo.iptorch.com/refdrawing/EP-3453653-A1/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/EP-3453653-A1/003.png)

![Sketch 4 for EP-3453653-A1](https://nimo.iptorch.com/refdrawing/EP-3453653-A1/003.png)

## Claims

### Claim 1 (independent)

End of line pick and place unit (1) with an infeed conveyer which transports n packages side by side in a row towards a gripper unit (6), wherein n is at least 1 and wherein the gripper unit (6) comprises one or a multitude of grippers (7) which grip at least one package simultaneously, lift it/them, transport it/them and lower it/them on an outfeed conveyor (4) in a row with one or n-1 packages side by side, or less, characterized in, that for lifting, and lowering, the entire gripper unit is moved.

### Claim 2

End of line unit (1) according to claim 1 or the preamble of claim 1, characterized in that the grippers (7) are provided stationary at the gripper unit (6).

### Claim 3

End of line unit (1) according to one of the preceding claims, characterized in, that the gripper unit (6) is provided at a frame and that the frame is lowered and lifted.

### Claim 4

End of line unit (1) according to one of the preceding claims, characterized in, that it comprises a guiding means (10) for a horizontal movement of the gripper unit.

### Claim 5

End of line unit (1) according to one of the preceding claims, characterized in, that the grippers (7) are vacuum operated.

### Claim 6

Gripper unit (6), preferably for an end of line unit (1) for one of the preceding claims, characterized in, that it comprises a housing (20) at which a tool (12) is releasably provided, that comprises all grippers (7) for a specific application.

### Claim 7

Gripper unit (6) according to claim 5, characterized in, that the tool (12) comprises no moving part.

### Claim 8

Gripper unit (6) according to claims 5 or 6, characterized in, that it comprises a central connector (17) for the energy, preferably the vacuum, for the grippers (7).

### Claim 9

Gripper unit (6) according to claim 8, characterized in, that the tool comprises tubes provided between the gripper (7) and the central connector (17).

### Claim 10 (independent)

Gripper unit (6) according to 6 - 9, characterized in, that it comprises a valve-block (16), preferably at the housing (20).

### Claim 11 (independent)

Gripper unit (6) according to 6 - 10, characterized in, that it comprises a plug (19), preferably at the housing (20), which supplies each gripper (7) with energy.

### Claim 12

Gripper unit (6) according to claims 6 - 11, characterized in, that there are guiding means (14) for the tool at the housing (20).

### Claim 13

Gripper unit (6) according to claims 6 - 12, characterized in, that the tool comprises identification means.

## Full description

**[0001]**

The present invention relates to an end of line pick and place unit with an infeed conveyer which transports n packages side by side in one row towards a gripper unit, wherein n is at least 1 and wherein the gripper unit comprises a multitude of grippers which grip at least one package simultaneously, lift it/them, transport it/them and lower it/them on an outfeed conveyor in a row with 1 or n-1 packages side by side or less.

**[0002]**

Such end of line pick and place units are known from the state in the art and are conventionally provided downstream from a packaging machine, particularly a so-called form-fill-seal- packaging machine (FFS-packaging machine), particularly a thermo-former. Such a packaging machines conventionally works intermittently, wherein during one index, an array of packages, a so-called format, with multiple rows and columns of packages, is produced. A row thereby extends perpendicular to the transport direction of the packages, while a column extends parallel to the transport direction of the packages. Downstream from the packaging machine number of columns need to be reduced which is done by the pick and place unit. The pick and place unit picks each package with a gripper unit consisting of at least one gripper, preferable a set of grippers, from an infeed conveyor and places it to an outfeed conveyor in reduced columns, preferably in one column. The end of line pick and place unit according to the state in the art are constructed costly and need too much time for a format change and/or gripper change.

**[0003]**

It is therefore the objective of the present invention to provide an end of line pick and place unit and a gripper unit that do not have the deficiencies according to the state in the art.

**[0004]**

The problem is attained with an end of line pick and place unit with an infeed conveyer which transports n packages side by side in a row towards a gripper unit, wherein n is at least 1 and wherein the gripper unit comprises one or a multitude of grippers which grip at least one package simultaneously, lift it/them, transport it/them and lower it/them on an outfeed conveyor in a row with one or n-1 packages side by side, or less and wherein for lifting, and lowering, the entire gripper unit is moved.

**[0005]**

The disclosure regarding this embodiment of the present invention also applies to the other embodiments of the present invention and vice versa. Features regarding this embodiment of the present invention can be combined with other embodiments of the present application and vice versa.

**[0006]**

The present invention relates to an end of line pick and place units which is conventionally provided downstream from a packaging machine, particularly a so-called form-fill-seal-packaging machine (FFS-packaging machine), particularly a thermo-former. Such a packaging machine conventionally works intermittently, wherein during one index, an array, a so-called format of packages, with one or multiple rows and columns, is produced. A row thereby extends perpendicular to the transport direction of the packages, while a column extends parallel to the transport direction of the packages. Downstream from the packaging machine number of columns need to be reduced which is done by the inventive pick and place unit.

**[0007]**

The inventive end of line unit comprises an infeed conveyor that transports the packages towards a gripper unit. The packages are conventionally still provided in their format, i.e. in an array with multiple rows and columns. Preferably, the infeed conveyor is a belt, preferably an endless belt, wherein the infeed conveyor is preferably operated intermittently. Preferably, the movement of the infeed conveyor is controlled by a computer, so that the packages can be placed in a defined position relative to the gripper unit and/or that the computer knows the exact position of each package on the infeed conveyor. The packages are transported until they each reach a certain position on the infeed conveyor. The infeed conveyor is then preferably stopped. Then, a gripper unit, which comprises one or a multitude of grippers, picks up, preferably lifts, at least one package and places it, preferably lowers it, on an outfeed conveyor. The outfeed conveyor extends preferably parallel to the infeed conveyor, but can be as well in line or under an angle to the infeed conveyor. Preferably, the gripper unit picks up all packages in one column. On the outfeed conveyor, the number of packages side by side in one row is preferably reduced, preferably to one, in comparison to the packages side by side in one row on the infeed conveyor. The outfeed conveyor is preferably a belt, more preferably an endless belt. Each gripper can be activated to provide a force- and/or form-fit between the gripper and a package and deactivated to annul the force- and/or form-fit, preferably individually or group-wise. However, particularly when larger and/or heavy packages need to be lifted and lowered, a multitude of gripper may be needed to transport one package. In this case, a multitude of grippers is activated and deactivated simultaneously. Preferably, the force- and/or form-fit is provided based on vacuum.

**[0008]**

Preferably the said computer knows which package might be empty and/or faulty and preferably the gripper unit is controlled by the computer, so that the gripper unit preferably picks only the good packages, but not the empty and/or faulty packages. At the earliest when the picked packages are free from the belt and away from possible collision to the still waiting empty and/or faulty packages the empty and/or faulty packages are taken out of the way preferably by moving the infeed conveyor in downstream direction in order to transfer the empty and/or faulty packages to a separate conveyor or into waste boxes. This functionality can be used even if the number of columns shall not be reduced.

**[0009]**

According to the present invention, for lifting and lowering the packages not the individual grippers are moved relative to a housing of the gripper unit, but the entire gripper unit is lifted and lowered, while the individual grippers are not actively moved relative to the housing of the gripper unit. The lifting and lowering can be done by every motor means known by the person skilled in the art. Preferably the motor means provides a feed-back signal so that a control system knows the exact position of the gripper unit, particularly regarding the upper surface of the infeed- and/or outfeed conveyor and/or to the upper surface of the package or it is possible that the exact positions can be taught to the control.

**[0010]**

Preferably, the gripper unit is reciprocated between a lifting position above the infeed conveyor and a lowering position, preferably above the outfeed conveyor. This movement is preferably a horizontal movement. This movement can be done by every motor means known by the person skilled in the art. Preferably the motor means provides a feed-back signal so that a control system knows the exact position of the gripper unit, particularly regarding the pick-up- and the place-position.

**[0011]**

Preferably, a motor with gear box and toothed belt are used for one or both movements of the gripper-unit. The movements of the gripper-unit can be carried out at least timewise simultaneously and/or sequentially.

**[0012]**

According to another inventive or preferred embodiment of the present invention, which also solves the problem stated, the grippers are provided stationary at the gripper unit.

**[0013]**

The disclosure regarding this embodiment of the present invention also applies to the other embodiments of the present invention and vice versa. Features regarding this embodiment of the present invention can be combined with other embodiments of the present application and vice versa.

**[0014]**

According to this embodiment of the present invention, the grippers are stationary relative to the gripper unit. This does not mean that the grippers do not own a certain flexibility and compress and decompress while being brought in contact with the package and/or released from the package. However, the grippers are not actively moved by a motor, compressor or the like. For lifting and lowering, the gripper unit, at which the grippers are provided, is moved.

**[0015]**

Preferably, the gripper unit is provided at a frame and this frame is lowered and lifted together with the gripper unit and relative to the infeed- and/or outfeed conveyor or its frame. This embodiment of the present invention solves as well the problem of reducing the sluggish mass on the preferably horizontal reciprocating movement of the gripper unit between a pick-and a place- position and reducing the acceleration forces on said movement, that need to be taken by the mechanical structure of the pick-and-place unit and that might needed to be hold back from the floor or similar structure, which carries the pick-and-place unit.

**[0016]**

Preferably, the end of line unit comprises a guiding means, preferably one or more guiding rod(s) for a horizontal movement of the gripper unit from the pick- to the place position. For the transfer of the packages from the infeed conveyor, the pick position, to the outfeed conveyor, the place position, the gripper unit moves along the guiding means, driven by a motor means.

**[0017]**

According to a preferred embodiment, the grippers are vacuum operated, i.e. the vacuum provides the connection between the grippers and the package to be transported.

**[0018]**

The problem is also solved with a gripper unit, preferably for the inventive end of line unit, wherein the gripper unit comprises a housing at which a tool is releasably provided, which comprises all grippers for a specific application.

**[0019]**

The disclosure regarding this embodiment of the present invention also applies to the other embodiments of the present invention and vice versa. Features regarding this embodiment of the present invention can be combined with other embodiments of the present application and vice versa.

**[0020]**

This embodiment of the present invention deals with a gripper unit, which comprises a housing. The housing preferably comprises and/or is connected to means to lower and lift the housing and/or to move it horizontally. At this housing, a tool is releasably provided that comprises the specific embodiment for a specific application. This invention is based on the idea that depending on the format and the design of the package, a tailormade arrangement of grippers is needed. The gripper configuration can vary in the number of grippers provided per package, the arrangement of the grippers relative to each other and/or the weight each gripper can carry and/or the type of grippers which i.e. depends on the surface and/or shape of the package. Nowadays, one packaging machine are designed to produce a multitude of different packages. In case the package produced is changed, the configuration of the grippers must be changed as well. This can be done fast and easily by changing the tool at which all grippers are provided.

**[0021]**

The tool is preferably a plate, which is provided horizontally during use. The grippers are distributed at the plate as needed.

**[0022]**

Preferably, the tool does not comprise any moving part. This makes the tool cheap and reduces the weight of the tool.

**[0023]**

According to a preferred embodiment, the gripper unit comprises a central connector for the energy, preferably the vacuum, for the grippers. Preferably, the tool comprises tubes provided between the gripper and the central connector. Due to this preferred embodiment of the present invention, the time needed to change the toll can be even more decreased, because the central connector only need to be connected to one single energy source, preferably a vacuum source. The central connector preferably comprises a multitude of tube connections so that each gripper or a group of grippers can be individually energized. The central connector is preferably a universal part for many different applications, but tailor-configured for the tool at which it is provided.

**[0024]**

Preferably, the gripper unit comprises a valve-block, preferably at the housing.

**[0025]**

Preferably, the gripper unit comprises a plug, preferably at the housing, which supplies each gripper with energy, e.g. vacuum. The plug is connected to the central connector and preferably downstream from the valve-block. The plug preferably comprises a multitude of outlets which are connected to corresponding inlets at the central connector. The valve-block together with the plug determines which outlet is connected to a vacuum source. Preferably, the direction of connecting the plug with the central connector is more or less the same as the inserting direction of the tool, preferably a tool-plate, when it is inserted in its working position at the housing for tool change. Preferably, the plug is automatically connected to the central connector during inserting of the tool in its working position when finishing the tool change and/or automatically unplugged when starting the tool change.

**[0026]**

Preferably, guiding means for the tool are provided at the housing. These guiding means can be for example a U-shaped or L-shaped rail, which cooperate with the tool-plate at two opposite ends. During tool-change, the tool is guided by the rails.

**[0027]**

Preferably, the tool, e.g. the tool-plate can be moved into a tool carrier and/or tool storage, which is at times placed preferably in corresponding position at the end of the guiding means, in order to make the tool change even faster and/or to reduce the carrying weight for the machine operator.

**[0028]**

Preferably, the tool change is done automatically, e.g. by pushing the tool, e.g. tool-plate, out of the housing and into a free spot of the waiting tool carrier and/or tool storage, and then moving the filled spot out of the way and replacing it by another filled spot with the wanted tool, then pulling or pushing this wanted tool out of the tool carrier and/or tool storage and into its working position in the housing.

**[0029]**

According to a preferred embodiment of the present invention, the tool comprises identification means to identify the tool. Such an identification can be a FID or a RFID or the like. Due to this identification, it can be excluded, that the wrong tool is installed for a certain application and/or that it is installed in the wrong orientation. The identification can also comprise information how to operate the tool, for example which degree of vacuum is needed for the grippers. Furthermore, the information on the tool can automatically configure the valve block.

**[0030]**

The inventions are now explained according to the Figures. These explanations do not limit the scope of protection and apply for all embodiments of the present invention likewise.

### shows the grippers

**[0031]**

Figure 1 shows the inventive end of line pick and place unit 1 which is located downstream from a packaging machine and which receives packages here from four lanes, i.e. each row of packages comprises four packages. The end of line pick and place unit 1 comprises an infeed conveyor, here an endless belt which transports the package towards a gripper unit 6, which comprises a multitude of grippers 7, here twelve grippers, which can pick up six packages from two lanes; i.e. two grippers are allocated to one package. For picking up the packages, the gripper unit is lowered until the grippers touch the packages. Then, a vacuum is applied between the packages and the grippers 7. As soon as a sufficient vacuum has been established, the gripper unit is lifted and simultaneous and/or subsequently the gripper unit moves towards the outfeed conveyor 4 as depicted by the arrow. During the connection of the grippers at the package, the infeed conveyor preferably stands still. After and/or while reaching the outfeed conveyor, the packages are lowered again, until they stand on the outfeed conveyor. The outfeed conveyor is in the present case provided as an endless belt. In the present case, the inventive end of line pick and place unit 1 comprises a pusher 5, which is however not demanding. The pusher pushes packages which have been placed on an area before the pusher and beside the outfeed conveyor on the outfeed conveyor after the area of the outfeed conveyor in front of the pusher has been emptied by advancing the outfeed conveyor. Downstream from the outfeed conveyor, there may be a pitching conveyor 21, which can be for example, the interface between the end of line pick and place unit 1 and a subsequent carton packaging machine. The inventive end of line pick and place unit 1 reduces packages in n parallel lanes on the infeed conveyor 3, here four parallel lanes to less, preferably one lane on the outfeed conveyor 4.

**[0032]**

The end of line pick and place unit 1 and the packaging machine 2 can exchange information for example via a common control system. Particularly information to synchronize the packaging machine and the end of line pick and place unit 1. For example, information about the index and/or the availability of packages to transferred can be exchanged. The information exchanged can also comprise data about packages in a format which need to be sorted out, because, for example, they are not sufficiently filled and/or the quality of the product in the package is not sufficient and/or the package is not properly closed and/or has a gas-atmosphere in the package which is not according to the specification. The inventive end of line pick and place unit 1 gets data about the position of such a package, particularly where it is located on the infeed convey 3. The gripper(s) which is/are allocated to such a deficient package is/are then not activated, e.g. no vacuum is applied to this/these gripper(s), so that the package is not lifted together with the gripper unit, but stays on the infeed conveyor. As soon as the infeed conveyor further advances, this package drops from the infeed conveyor, for example in a waste bin.

**[0033]**

Figure 2 shows the gripper unit 6. It can be seen that the entire gripper unit is provided at vertical lifting means, here a frame 8 and a guiding means 9, here a guiding rod. For lowering and lifting the gripper unit, here the frame 8 is lowered and lifted by motor means and guided by the guiding means during this movement. The gripper unit is also connected to horizontal guiding means, here two guiding rods 10, along which the gripper unit can reciprocate to transport packages from the infeed- to the outfeed conveyor. The vertical movement and/or the horizontal movement are preferably driven by a motor 11 and a toothed belt. The motor is preferably a motor that provides a signal about the rotational position of its shaft, so that the horizontal and/or vertical position of the gripper unit can be derived.

**[0034]**

The grippers of the inventive end of line pick and place unit 1 do not move relative to the gripper unit 6 in which they are provided, but only move together with the housing 20 of the gripper unit.

**[0035]**

Figures 4 - 6 show details of the gripper unit 6, which comprises a housing 20, and a tool 12, which is in the present case provided as a plate. At this tool, a multitude of grippers 7 is provided in a certain configuration, which is preferably tailormade for a specific application, i.e. adapted to the package(s) to be lifted. In the present case, three grippers, provided in a triangle, are utilized to lift one package and three packages can be lifted simultaneously. Furthermore, the tool may comprise a handle 15 and/or one or more, here three, recess(es) to reduce the weight of the tool and/or to simplify the inspection/maintenance of the tool. The housing preferably comprises guiding means 14, here U-shapes slots which guide the tool during installation and removal of the tool. It its operating position, the tool can be fixed by fixing means 13, which are released for removal of the tool from the housing. The inventive gripper unit may comprise a valve, particularly a valve-block 16 to provide the grippers individually and/or group-wise with energy, for example vacuum.

**[0036]**

As can particularly seen from Figure 5 , at the tool, preferably a central connector 17 is provided. This connector can be connected to a vacuum-source and downstream from the connector 17, tubes 18 are provided, which connect the connector 17 with the individual grippers 7. Again, according to the present example, three grippers 7 are tube-wise combined to one group to lift one package and three packages can be lifted simultaneously.

**[0037]**

Figure 6 shows the plug 19 that is connected to the central connector 17. It can be seen that the plug comprises a multitude of sockets, which can be connected to corresponding recesses in the central connector 17. Hence, if needed each gripper 7 at the tool 12 can be supplied with vacuum individually. The plug is connected to the valve block, which shuts the vacuum for the individual gripper or an individual group of grippers on and off.

**[0038]**

List of reference signs:

**[0038]**

1

## Classifications

- B65G47/91
- B65G47/68
- B65G47/682
- B65G47/91
- B65G47/912
- B65G47/918

## Cited patent documents

- [DE-4445108-A1](https://patents.google.com/patent/DE4445108A1/en) — SEA
- [EP-1270462-A1](https://patents.google.com/patent/EP1270462A1/en) — SEA
- [EP-2341001-A1](https://patents.google.com/patent/EP2341001A1/en) — SEA
- [GB-2297955-A](https://patents.google.com/patent/GB2297955A/en) — SEA
- [JP-S60144237-A](https://patents.google.com/patent/JPS60144237A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
