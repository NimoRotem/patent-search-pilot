# 18. Clamping device for holding workpiece by suction has support bearing element extending vacuum channel and movable between retracted and extended position controlled by motorised motion device

- **Archive rank:** 18 of 50
- **Publication:** [DE-10023915-A1](https://patents.google.com/patent/DE10023915A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/007642220/publication/DE10023915A1?q=pn%3DDE10023915A1)
- **Publication date:** 2001-11-29
- **Filing date:** 2000-05-17
- **Earliest priority:** 2000-05-17
- **Family:** 7642220
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** GOECKEL KARL; GOECKEL MARTIN
- **Inventors:** GOECKEL KARL; GOECKEL MARTIN

## Abstract

The vacuum suction element (6) of the device which can be biased by underpressure has a support bearing element (13) which extends the vacuum channel (24) and has a sealing element (25) for sealing the channel from the workpiece. The support bearing element is moved between a retracted and extended position by a controllable motorised motion device.  An electric motor (9) can be used which drives a threaded spindle (11) which is coupled to the support bearing element in a spindle holder (12).

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-10023915-A1/ops000.png)

![Sketch 1 for DE-10023915-A1](https://nimo.iptorch.com/refdrawing/DE-10023915-A1/ops000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-10023915-A1/ops001.png)

![Sketch 2 for DE-10023915-A1](https://nimo.iptorch.com/refdrawing/DE-10023915-A1/ops001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/DE-10023915-A1/ops002.png)

![Sketch 3 for DE-10023915-A1](https://nimo.iptorch.com/refdrawing/DE-10023915-A1/ops002.png)

## Claims

### Claim 1 (independent)

Spannvorrichtung zum Halten eines Gegenstands durch Ansaugen dessel­ ben, umfassend wenigstens ein mit Unterdruck beaufschlagbares Vakuum­ ansaugelement mit einem Vakuumkanal, über den der Unterdruck an den Gegenstand geführt werden kann, dadurch gekennzeichnet, dass das Va­ kuumansaugelement (6, 36) ein den Vakuumkanal (24, 51) verlängerndes Auflageelement (13, 39) mit einem Dichtelement (25, 56) zum Abdichten des Vakuumkanals zum Gegenstand hin und ein mittels einer Steuerungs­ einrichtung (15) ansteuerbares Bewegungsmittel zum Bewegen des Aufla­ geelements (13, 39) zwischen einer Ein- und einer Ausfahrstellung, in wel­ cher der Gegenstand aufnehmbar ist aufweist.1. Clamping device for holding an object by sucking the same, comprising at least one vacuum suction element that can be subjected to negative pressure, with a vacuum channel, via which the negative pressure can be guided to the object, characterized in that the vacuum suction element ( 6 , 36 ) is a vacuum channel ( 24 , 51 ) extending support element ( 13 , 39 ) with a sealing element ( 25 , 56 ) for sealing the vacuum channel towards the object and a means ( 15 ) which can be controlled by a control device for moving the support element ( 13 , 39 ) between one Retracted and an extended position in which the object can be picked up.

### Claim 2

Spannvorrichtung nach Anspruch 1, dadurch gekennzeichnet, dass das Bewegungsmittel ein elektrisches Betätigungsmittel umfassend einen Elekt­ romotor (9), insbesondere einen Servomotor ist.2. Clamping device according to claim 1, characterized in that the movement means is an electrical actuating means comprising an electric motor ( 9 ), in particular a servo motor.

### Claim 3

Spannvorrichtung nach Anspruch 2, dadurch gekennzeichnet, dass der E­ lektromotor (9) eine Gewindespindel (11) antreibt, die mit dem Auflageele­ ment (13) in einer Spindelaufnahme (12) gekoppelt ist.3. Clamping device according to claim 2, characterized in that the electric motor ( 9 ) drives a threaded spindle ( 11 ) which is coupled to the support element ( 13 ) in a spindle receptacle ( 12 ).

### Claim 4

Spannvorrichtung nach Anspruch 3, dadurch gekennzeichnet, dass die Gewindespindel (11) außermittig in der Spindelaufnahme (12) geführt ist.4. Clamping device according to claim 3, characterized in that the threaded spindle ( 11 ) is guided off-center in the spindle receptacle ( 12 ).

### Claim 5

Spannvorrichtung nach Anspruch 1, dadurch gekennzeichnet, dass das Bewegungsmittel ein pneumatisches oder hydraulisches Betätigungsmittel umfassend einen ein- oder doppelseitig wirkenden Zylinder (41), der mit ei­ nem entsprechenden Betriebsmittel beaufschlagbar ist, oder ein elektro­ magnetisches Betriebsmittel umfassend einen oder mehrere Hubmagnete ist.5. Clamping device according to claim 1, characterized in that the movement means is a pneumatic or hydraulic actuating means comprising a single or double-acting cylinder ( 41 ) which can be acted upon by a corresponding operating medium, or an electromagnetic operating medium comprising one or more lifting magnets .

### Claim 6

Spannvorrichtung nach Anspruch 5, dadurch gekennzeichnet, dass ein oder mehrere über die Steuerungseinrichtung (15) steuerbare Ventilelemente (45) vorgesehen sind, über die der Zylinder (41) mit dem Betriebsmittel ver­ sorgbar ist.6. Clamping device according to claim 5, characterized in that one or more via the control device ( 15 ) controllable valve elements ( 45 ) are provided, via which the cylinder ( 41 ) with the operating medium is ver ver.

### Claim 7

Spannvorrichtung nach einem der vorangehenden Ansprüche, dadurch ge­ kennzeichnet, dass das Auflageelement (13, 39) zumindest im Bereich un­ terhalb des Dichtelements (25, 56) im Wesentlichen zylindrisch ausgebildet ist und das Dichtelement (25, 56) am oder im Bereich des oberen Randes vorgesehen ist.7. Clamping device according to one of the preceding claims, characterized in that the support element ( 13 , 39 ) at least in the area below the sealing element ( 25 , 56 ) is substantially cylindrical and the sealing element ( 25 , 56 ) on or in the area the upper edge is provided.

### Claim 8

Spannvorrichtung nach Anspruch 7, dadurch gekennzeichnet, dass am Auflageelement (13) außenseitig ein Konus (18) ausgebildet ist, der in der Ausfahrstellung an einem feststehenden Gegenlagerkonus (19) anliegt.8. Clamping device according to claim 7, characterized in that on the support element ( 13 ) on the outside a cone ( 18 ) is formed, which rests in the extended position on a fixed counter-bearing cone ( 19 ).

### Claim 9

Spannvorrichtung nach einem der vorangehenden Ansprüche, dadurch ge­ kennzeichnet, dass das Auflageelement (13, 39) aus einem Vollmaterial gebildet ist, in dem ein den Vakuumkanal (24, 51) verlängernder Hohlkanal (26, 57) und gegebenenfalls eine Aufnahme (14) für die Spindel (11) vorge­ sehen ist.9. Clamping device according to one of the preceding claims, characterized in that the support element ( 13 , 39 ) is formed from a solid material, in which a vacuum channel ( 24 , 51 ) extending hollow channel ( 26 , 57 ) and optionally a receptacle ( 14 ) is provided for the spindle ( 11 ).

### Claim 10

Spannvorrichtung nach einem der vorangehenden Ansprüche, dadurch ge­ kennzeichnet, dass das Dichtelement (25, 56) aus Gummi oder Kunststoff ist.10. Clamping device according to one of the preceding claims, characterized in that the sealing element ( 25 , 56 ) is made of rubber or plastic.

### Claim 11

Spannvorrichtung nach einem der vorangehenden Ansprüche, dadurch ge­ kennzeichnet, dass das Auflageelement (13, 39) erst im Wesentlichen mit Erreichen der Ausfahrstellung mit dem Vakuumkanal (24, 51) gekoppelt wird.11. Clamping device according to one of the preceding claims, characterized in that the support element ( 13 , 39 ) is only substantially coupled with the vacuum channel ( 24 , 51 ) when reaching the extended position.

### Claim 12

Spannvorrichtung nach Anspruch 11, dadurch gekennzeichnet, dass am Auflageelement (13, 39) eine Öffnung (27, 58) vorgesehen ist, die in der Ausfahrstellung vorzugsweise über ein Dichtmittel abgedichtet mit einer Va­ kuumkanalöffnung (24, 59) kommuniziert. Clamping device according to claim 11, characterized in that an opening ( 27 , 58 ) is provided on the support element ( 13 , 39 ), which communicates in the extended position, preferably sealed by a sealant, with a vacuum channel opening ( 24 , 59 ).

### Claim 13

Spannvorrichtung nach Anspruch 12, dadurch gekennzeichnet, dass an dem Vakuumansaugelement ein mit einer Unterdruckquelle direkt oder indi­ rekt verbindbarer Vakuumkanal (24, 51) vorgesehen ist, der mit seiner Ka­ nalöffnung (24, 59) mit der Öffnung (27, 58) des Auflageelements (13, 39) verbindbar ist.13. Clamping device according to claim 12, characterized in that a vacuum channel ( 24 , 51 ) which can be connected directly or indirectly to a vacuum source is provided on the vacuum suction element and has its channel opening ( 24 , 59 ) with the opening ( 27 , 58 ). of the support element ( 13 , 39 ) can be connected.

### Claim 14

Spannvorrichtung nach Anspruch 12, dadurch gekennzeichnet, dass die Öffnung des Auflageelements mit einem externen, mit einer Unterdruck­ quelle direkt oder indirekt verbindbaren Vakuumkanal verbindbar ist.14. Clamping device according to claim 12, characterized in that the Opening of the support element with an external, with a vacuum source directly or indirectly connectable vacuum channel is connectable.

### Claim 15

Spannvorrichtung nach einem der vorangehenden Ansprüche, dadurch ge­ kennzeichnet, dass das Vakuumansaugelement (6, 36) lösbar an oder in einem Vorrichtungsgestell (2, 34) anordenbar ist.15. Clamping device according to one of the preceding claims, characterized in that the vacuum suction element ( 6 , 36 ) is releasably arranged on or in a device frame ( 2 , 34 ).

### Claim 16

Spannvorrichtung nach Anspruch 15, dadurch gekennzeichnet, dass am Vakuumansaugelement (6, 36) Verbindungsmittel zum Verbinden dessel­ ben mit einem gestellseitig vorgesehenen, mit einer Unterdruckquelle (63) direkt oder indirekt verbindbaren Vakuumkanal (20, 62), und/oder zum Ver­ binden des Bewegungsmittels mit der Steuerungseinrichtung (15, 64) und gegebenenfalls mit einer Versorgungseinrichtung (65) zum Zuführen eines zum Betrieb des Bewegungsmittels benötigten Betriebsmittels vorgesehen sind.16. Clamping device according to claim 15, characterized in that on the vacuum suction element ( 6 , 36 ) connecting means for connecting the same ben with a provided on the frame side, with a vacuum source ( 63 ) directly or indirectly connectable vacuum channel ( 20 , 62 ), and / or for Ver binding of the movement means with the control device ( 15 , 64 ) and optionally with a supply device ( 65 ) for supplying an operating means required for operating the movement means.

### Claim 17

Spannvorrichtung nach Anspruch 16, dadurch gekennzeichnet, dass die Verbindungsmittel steckerartig ausgebildet sind, die mit gestellseitig vorge­ sehenen buchsenartigen Gegenstücken beim Anordnen des Vakuuman­ saugelements (3, 36) an oder im Vorrichtungsgestell (2, 34) automatisch verbindbar sind.17. Clamping device according to claim 16, characterized in that the connecting means are plug-like, which are automatically connectable to socket-like counterparts provided on the frame side when arranging the vacuum element ( 3 , 36 ) on or in the device frame ( 2 , 34 ).

### Claim 18

Spannvorrichtung nach Anspruch 16 oder 17, dadurch gekennzeichnet, dass am Vorrichtungsgestell (2, 34) eine oder mehrere Leiterverbindungen (37), insbesondere gedruckte Leiterbahnen vorgesehen sind, über die das Bewegungsmittel mit der Steuerungseinrichtung (15, 64) koppelbar ist. Clamping device according to claim 16 or 17, characterized in that one or more conductor connections ( 37 ), in particular printed conductor tracks, are provided on the device frame ( 2 , 34 ), via which the movement means can be coupled to the control device ( 15 , 64 ).

### Claim 19

Spannvorrichtung nach einem der Ansprüche 16 bis 18, dadurch gekenn­ zeichnet, dass am Vorrichtungsgestell (2, 34) ein oder mehrere Versor­ gungskanäle (38) zum Zuführen und/oder Abführen des Betriebsmittels vorgesehen sind.19. Clamping device according to one of claims 16 to 18, characterized in that on the device frame ( 2 , 34 ) one or more supply channels ( 38 ) are provided for supplying and / or removing the equipment.

### Claim 20

Spannvorrichtung nach Anspruch 18 oder 19, dadurch gekennzeichnet, dass das Vorrichtungsgestell (2, 34) eine Aufnahmeplatte (3, 35) aufweist, auf welche das oder die Vakuumelemente (6, 36) aufstellbar sind, und an welcher die Leiterverbindungen (37) und/oder die Versorgungskanäle (38) und gegebenenfalls die entsprechenden gestellseitige Verbindungsmittel vorgesehen sind.20. Clamping device according to claim 18 or 19, characterized in that the device frame ( 2 , 34 ) has a receiving plate ( 3 , 35 ) on which the vacuum element (s) ( 6 , 36 ) can be set up and on which the conductor connections ( 37 ) and / or the supply channels ( 38 ) and optionally the corresponding frame-side connection means are provided.

### Claim 21

Spannvorrichtung nach Anspruch 20, dadurch gekennzeichnet, dass an der Aufnahmeplatte (35) auch der gestellseitige Vakuumkanal (62) vorgesehen ist.21. Clamping device according to claim 20, characterized in that the frame-side vacuum channel ( 62 ) is also provided on the receiving plate ( 35 ).

### Claim 22

Spannvorrichtung nach Anspruch 20, dadurch gekennzeichnet, dass das Vorrichtungsgestell (2) eine obere, wenigstens eine Durchsteck- oder Ein­ setzaufnahme (5) für wenigstens ein Vakuumelement (6) aufweisende Platte (4) umfasst, an welcher der gestellseitige Vakuumkanal (20) vorge­ sehen ist.That the device stand (2) 22. A clamping device according to claim 20, characterized in that an upper, at least a push-through or a set receptacle (5) for at least one vacuum element (6) comprising plate (4) on which the frame-side vacuum channel (20 ) is provided.

### Claim 23

Spannvorrichtung nach einem vorangehenden Ansprüche, dadurch ge­ kennzeichnet, dass ein Vorrichtungsgestell oder -gehäuse (2, 34) vorge­ sehen ist, an dem weitere Verbindungsmittel vorgesehen sind, mittels de­ nen ein gestell- oder gehäuseseitiger Vakuumkanal und/oder die Leiterver­ bindung(en) bzw. der oder die Versorgungskanäle für das Bewegungsmittel zweier Vorrichtungen verbindbar sind.23. Clamping device according to one of the preceding claims, characterized in that a device frame or housing ( 2 , 34 ) is provided, on which further connecting means are provided, by means of which a frame-side or housing-side vacuum channel and / or the conductor connection ( en) or the supply channel or channels for the movement means of two devices can be connected.

### Claim 24

Spannvorrichtung nach Anspruch 23, dadurch gekennzeichnet, dass die Verbindungsmittel derart ausgebildet sind, dass die Verbindung beim di­ rekten Aneinanderstellen der Vorrichtungen automatisch hergestellt wird. Clamping device according to claim 23, characterized in that the Connection means are designed such that the connection in the di right juxtaposition of the devices is automatically produced.

### Claim 25

Spannvorrichtung nach einem der vorangehenden Ansprüche, dadurch ge­ kennzeichnet, dass mehrere Vakuumansaugelemente (3, 36) vorgesehen sind, die in einem gemeinsamen Vorrichtungsgestell (2, 34) gehaltert sind, wobei jedes der Auflageelemente (1, 39 der in einer gemeinsamen Ebene angeordneten Vakuumansaugelemente (3, 36) separat über eine zentrale Steuerungseinrichtung (15, 64) ist, so dass beliebige Auflageelemente (13, 39) aus dem Verbund der Vakuumansaugelemente (3, 36) in die Ausfahr­ stellung bringbar sind.25. Clamping device according to one of the preceding claims, characterized in that a plurality of vacuum suction elements ( 3 , 36 ) are provided which are held in a common device frame ( 2 , 34 ), each of the support elements (1, 39 of the in a common plane arranged vacuum suction elements ( 3 , 36 ) separately via a central control device ( 15 , 64 ), so that any support elements ( 13 , 39 ) from the composite of vacuum suction elements ( 3 , 36 ) can be brought into the extended position.

### Claim 26

Spannvorrichtung nach Anspruch 25, dadurch gekennzeichnet, dass die Steuerungseinrichtung (15, 64) zum Ansteuern der Vakuumansaugele­ mente (3, 36) in Abhängigkeit gespeicherter oder erfasster Informationen bezüglich des aufzunehmenden Gegenstands ausgebildet ist, so dass die Auflageelemente (13, 39) in eine gegenstandsbezogene Position bringbar sind.26. Clamping device according to claim 25, characterized in that the control device ( 15 , 64 ) for controlling the vacuum suction elements ( 3 , 36 ) is designed as a function of stored or recorded information relating to the object to be picked up, so that the support elements ( 13 , 39 ) can be brought into an object-related position.

### Claim 27

Spannvorrichtung nach Anspruch 26, dadurch gekennzeichnet, dass Mittel zum Erfassen einer Kennung eines aufzunehmenden Gegenstands vorge­ sehen sind, die mit der Steuerungseinrichtung kommunizieren.27. Clamping device according to claim 26, characterized in that means for detecting an identifier of an object to be recorded are seen that communicate with the control device.

### Claim 28

Spannvorrichtung nach Anspruch 27, dadurch gekennzeichnet, dass die Mittel als Barcodeleser oder als Transponderleser ausgebildet sind.28. Clamping device according to claim 27, characterized in that the Means are designed as barcode readers or as transponder readers.

### Claim 29

Spannvorrichtung nach Anspruch 27, dadurch gekennzeichnet, dass die Mittel wenigstens eine Kameraeinrichtung zum Aufnehmen des Gegens­ tands umfassen, die mit der Steuerungseinrichtung, die ein Mittel zum Ver­ arbeiten des aufgenommenen Bilds zum Erkennen des Gegenstands und/oder dessen Oberflächenform aufweist, kommuniziert.29. Clamping device according to claim 27, characterized in that the Means at least one camera device for recording the opposite tands include that with the control device that a means for Ver work the captured image to recognize the object and / or its surface shape communicates.

### Claim 30

Anordnung zum Halten eines flächigen Gegenstands durch Ansaugen des­ selben, umfassend mehrere Spannvorrichtungen mit jeweils einem oder mehreren Vakuumansaugelementen nach einem der Ansprüche 1 bis 29, sowie eine zentrale, den Betrieb der Vorrichtungen steuernden Steue­ rungseinrichtung (15, 64).30. Arrangement for holding a flat object by sucking the same, comprising a plurality of clamping devices, each with one or more vacuum suction elements according to one of claims 1 to 29, and a central control device ( 15 , 64 ) controlling the operation of the devices.

### Claim 31

Anordnung nach Anspruch 30, dadurch gekennzeichnet, dass die Steue­ rungseinrichtung (15, 64) zum automatischen Einstellen der Vakuuman­ saugelemente bzw. der Auflageelemente in eine gegenstandsbezogene Position in Abhängigkeit einer eingegebenen oder erfassten Gegenstands­ information ausgebildet ist.31. The arrangement according to claim 30, characterized in that the control device ( 15 , 64 ) is designed for automatically setting the vacuum suction elements or the support elements in an object-related position as a function of an input or detected object information.

### Claim 32

Anordnung nach Anspruch 31, dadurch gekennzeichnet, dass Mittel zum Erfassen einer Kennung eines aufzunehmenden Gegenstands vorgesehen sind, die mit der Steuerungseinrichtung kommunizieren.32. Arrangement according to claim 31, characterized in that means for Detection of an identifier of an object to be recorded is provided are communicating with the control device.

### Claim 33

Anordnung nach Anspruch 32, dadurch gekennzeichnet, dass die Mittel als Barcodeleser oder als Transponderleser ausgebildet sind33. Arrangement according to claim 32, characterized in that the means as Barcode readers or designed as transponder readers

### Claim 34

Anordnung nach Anspruch 32, dadurch gekennzeichnet, dass die Mittel wenigstens eine Kameraeinrichtung zum Aufnehmen des Gegenstands umfassen, die mit der Steuerungseinrichtung, die ein Mittel zum Verarbeiten des aufgenommenen Bilds zum Erkennen des Gegenstands und/oder des­ sen Oberflächenform aufweist, kommuniziert.34. Arrangement according to claim 32, characterized in that the means at least one camera device for picking up the object include, with the controller, which is a means of processing the captured image to recognize the object and / or the sen surface shape, communicates.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGHAND TOOLS; PORTABLE POWER-DRIVEN TOOLS; MANIPULATORSTOOLS OR BENCH DEVICES NOT OTHERWISE PROVIDED FOR, FOR FASTENING, CONNECTING, DISENGAGING, OR HOLDINGWork holders not covered by any preceding group in the subclass, e.g. magnetic work holders, vacuum work holdersVacuum work holdersPERFORMING OPERATIONS; TRANSPORTINGMACHINE TOOLS; METAL-WORKING NOT OTHERWISE PROVIDED FORDETAILS, COMPONENTS, OR ACCESSORIES FOR MACHINE TOOLS, e.g. ARRANGEMENTS FOR COPYING OR CONTROLLING; MACHINE TOOLS IN GENERAL CHARACTERISED BY THE CONSTRUCTION OF PARTICULAR DETAILS OR COMPONENTS; COMBINATIONS OR ASSOCIATIONS OF METAL-WORKING MACHINES, NOT DIRECTED TO A PARTICULAR RESULTMembers which are comprised in the general build-up of a form of machine, particularly relatively large fixed membersStationary work or tool supportsStationary work or tool supports characterised by properties of the support surfacePERFORMING OPERATIONS; TRANSPORTINGHAND TOOLS; PORTABLE POWER-DRIVEN TOOLS; MANIPULATORSTOOLS OR BENCH DEVICES NOT OTHERWISE PROVIDED FOR, FOR FASTENING, CONNECTING, DISENGAGING, OR HOLDINGWork holders not covered by any preceding group in the subclass, e.g. magnetic work holders, vacuum work holdersVacuum work holdersVacuum work holders portable, e.g. handheld

Description

Translated from German

Die Erfindung betrifft eine Spannvorrichtung zum Halten eines Gegenstands durch

Ansaugen desselben, umfassend wenigstens ein mit Unterdruck beaufschlagbaÂ­

res Vakuumansaugelement mit einem Vakuumkanal, Ã¼ber den der Unterdruck an

den Gegenstand gefÃ¼hrt werden kann.The invention relates to a clamping device for holding an object

Sucking the same, comprising at least one pressurizable with negative pressure

res vacuum suction element with a vacuum channel, through which the negative pressure

the item can be carried.

Die Bearbeitung eines WerkstÃ¼cks, beispielsweise einer Holz- oder KunststoffÂ­

platte mit einem Werkzeug auf einer Werkzeugbearbeitungsmaschine erfordert es,

das WerkstÃ¼ck fest zu spannen, damit es beim Bearbeiten nicht verrutscht. HierfÃ¼r

kommen zunehmend Vakuumspanneinrichtungen zum Einsatz, mittels welchen

des WerkstÃ¼ck durch Ansaugen festgespannt wird. Die Spanneinrichtung bzw.

deren Vakuumansaugelemente sind bevorzugt mit einer zentralen UnterdruckÂ­

quelle verbunden, die den erforderlichen Unterdruck erzeugt. Dieser wird Ã¼ber

Ventilelemente an das WerkstÃ¼ck weitergegeben. Hierdurch ist eine sichere FixieÂ­

rung des WerkstÃ¼cks mÃ¶glich. Solche Spanneinrichtungen kÃ¶nnen tisch- oder

konsolenartig ausgebildet sein und einen Teil der Werkzeugbearbeitungsmaschine

selbst bilden, das heiÃt, deren Arbeitstisch oder Arbeitskonsolen werden von einer

solchen Vorrichtung selbst gebildet. Alternativ ist es auch mÃ¶glich, derartige VorÂ­

richtungen als separate Zubauteile auszugestalten, die auf einem bereits vorhanÂ­

denen Arbeitstisch oder einer vorhandenen Arbeitskonsole einer WerkzeugbearÂ­

beitungsmaschine aufgesetzt werden. Die Halterung dieser Vorrichtungen kann

ebenfalls mittels Unterdruck erfolgen, wozu die Unterseite derselben entsprechend

ausgebildet ist.The processing of a workpiece, for example a wood or plastic

plate with a tool on a machine tool requires

clamp the workpiece firmly so that it does not slip during machining. Therefor

vacuum clamping devices are increasingly being used, by means of which

of the workpiece is clamped by suction. The tensioning device or

whose vacuum suction elements are preferably with a central vacuum

source connected, which generates the required negative pressure. This is about

Valve elements passed on to the workpiece. This is a sure fixie

workpiece possible. Such clamping devices can be table or

be designed like a console and part of the machine tool

form themselves, that is, their work table or work consoles are made by one

such device itself formed. Alternatively, it is also possible to do such

to design directions as separate attachments that already exist on one

which work table or an existing work console of a tool bar

be placed on the processing machine. The holder of these devices can

also take place by means of negative pressure, for which purpose the underside thereof

is trained.

Neben dem Halten zwecks Bearbeitung eines Gegenstandes kommen solche VorÂ­

richtungen aber auch als Transportvorrichtungen zum Einsatz. Auch hier wird der

Gegenstand mittels des oder der Vakuumansaugelemente angesaugt und gehalÂ­

tert, die Vorrichtung wird dann, beispielsweise mittels eines Krans oder eines

Portals oder dergleichen zusammen mit dem angesaugten Gegenstand verfahren.In addition to holding for the purpose of processing an object, there are such

directions but also used as transport devices. Here too the

Object sucked and held by means of the vacuum suction element or elements

tert, the device is then, for example by means of a crane or a

Move portals or the like together with the suctioned object.

Ein Problem bereitet jedoch der Umstand, dass hÃ¤ufig unterschiedliche WerkstÃ¼Â­

cke zu bearbeiten sind, also WerkstÃ¼cke unterschiedlicher Form und GrÃ¶Ãe. Jedes

WerkstÃ¼ck ist aber individuell zu spannen. Sind an der Spannvorrichtung mehÂ­

rere Vakuumansaugelemente, beispielsweise einhundert Ã¼ber eine relativ groÃe

FlÃ¤che verteilt vorgesehen, so werden bei wechselndem WerkstÃ¼ck jeweils unterÂ­

schiedliche Vakuumansaugelemente zum Spannen des Gegenstands benÃ¶tigt.One problem, however, is the fact that often different workshops

to be processed, i.e. workpieces of different shapes and sizes. Each

Â However, the workpiece must be clamped individually. Are more on the jig

Other vacuum suction elements, for example one hundred over a relatively large one

The surface is distributed, so when the workpiece changes, under

different vacuum suction elements needed to clamp the object.

Entsprechendes gilt fÃ¼r eine Anordnung mehrerer Spannvorrichtungen nebeneinÂ­

ander, die die SpannflÃ¤che bilden, wobei jede einzelne Spannvorrichtung ihrerÂ­

seits ein oder mehrere Vakuumansaugelemente aufweisen kann. Da alle VakuÂ­

umansaugelemente mit ihrer AnsaugflÃ¤che in einer Ebene liegen, besteht die GeÂ­

fahr, dass beim Bearbeiten eines kleineren WerkstÃ¼cks mit dem Werkzeug die

SpannflÃ¤che eines daneben liegenden Vakuumansaugelements unbeabsichtigter

Weise beschÃ¤digt wird, so dass dieses zerstÃ¶rt ist und nicht mehr zum Spannen

verwendet werden kann.The same applies to an arrangement of several clamping devices next to each other

other, which form the clamping surface, each individual clamping device their

can have one or more vacuum suction elements. Since all vacu

umansaugelemente lie with their suction surface in one plane, there is Ge

drive that when machining a smaller workpiece with the tool

Unintentional clamping surface of an adjacent vacuum suction element

Way is damaged so that it is destroyed and no longer to tension

can be used.

Der Erfindung liegt damit das Problem zugrunde, eine Spannvorrichtung anÂ­

zugeben, die hier Abhilfe schafft.The invention is therefore based on the problem of a tensioning device

admit that helps here.

Zur LÃ¶sung dieses Problems ist bei einer Spannvorrichtung der eingangs geÂ­

nannten Art erfindungsgemÃ¤Ã vorgesehen, dass das Vakuumansaugelement ein

den Vakuumkanal verlÃ¤ngerndes Auflageelement mit einem Dichtelement zum

Abdichten des Vakuumkanals zum Gegenstand hin und ein mittels einer SteueÂ­

rungseinrichtung ansteuerbares Bewegungsmittel zum Bewegen des AuflageeleÂ­

ments zwischen einer Ein- und einer Ausfahrstellung, in welcher der Gegenstand

aufnehmbar ist, aufweist.To solve this problem is the ge at a jig

mentioned type provided according to the invention that the vacuum suction element

the vacuum channel extending support element with a sealing element for

Sealing the vacuum channel to the object and one by means of a control

approximately controllable movement means for moving the support element

between an entry and an exit position, in which the object

is recordable.

Die erfindungsgemÃ¤Ãe Spannvorrichtung zeichnet sich dadurch aus, dass das den

Gegenstand tragende Auflageelement samt seinem Dichtelement gesteuert im

Bedarfsfall ausgefahren und in eine Ausfahrstellung gebracht wird, in welcher es

arretiert wird und den Gegenstand aufnehmen kann. Aus einem Verbund an VaÂ­

kuumansaugelementen - gleich ob diese in einer gemeinsamen Spannvorrichtung

angeordnet sind, oder ob mehrere separate Spannvorrichtungen, eine Anordnung

bildend, nebeneinander gestellt sind - kÃ¶nnen also diejenigen bezogen auf die

WerkstÃ¼ckgrÃ¶Ãe und -form benÃ¶tigten Auflageelemente ausgefahren werden.

Diese kÃ¶nnen so gewÃ¤hlt werden, dass sie zum einen hinreichend vom Rand des

WerkstÃ¼cks, das beispielsweise mit einem FrÃ¤skopf bearbeitet werden soll,

beabstandet sind, zum anderen wird durch das Ausfahren erreicht, dass die

SpannflÃ¤che in eine hÃ¶herliegende Ebene verlegt wird, das heiÃt, der Gegenstand

ist bezÃ¼glich der nichtbetÃ¤tigten Vakuumansaugelemente bzw. Auflageelemente

angehoben. Dadurch ist ausgeschlossen, dass beim Bearbeiten beispielsweise

des WerkstÃ¼ckrandes ein daneben liegendes Auflageelement bzw. das VakuumÂ­

ansaugelement selbst unbeabsichtigter Weise beschÃ¤digt wird. FÃ¼r den Bediener

besteht also der besondere Vorteil, jeden Gegenstand individuell spannen zu kÃ¶nÂ­

nen und auch zÃ¼gig bearbeiten zu kÃ¶nnen, ohne besondere SicherheitsvorkehÂ­

rungen hinsichtlich eines etwaigen BeschÃ¤digens benachbarter Auflageelemente

bzw. Vakuumansaugelemente zu treffen. Alternativ kann das Bewegungsmittel

auch ein elektromagnetisches Mittel sein, umfassend einen oder mehrere elektroÂ­

magnetische Hubmagnete, Ã¼ber die das Auflageelement bewegt wird und die Ã¼ber

die Steuerungseinrichtung gesteuert werden.The tensioning device according to the invention is characterized in that the

Object-bearing support element together with its sealing element controlled in

If necessary, extended and brought into an extended position in which it

is locked and can pick up the object. From a network of Va

vacuum suction elements - whether they are in a common clamping device

are arranged, or whether several separate clamping devices, an arrangement

educational, are placed side by side - so can those related to the

Workpiece size and shape required support elements are extended.

These can be chosen so that they are sufficiently far from the edge of the

Â Workpiece that is to be machined with a milling head, for example,

are spaced apart, on the other hand, the extension ensures that the

Rake is moved to a higher level, that is, the object

is with regard to the non-actuated vacuum suction elements or support elements

raised. This prevents that, for example, when editing

an adjacent support element or the vacuum of the workpiece edge

suction element itself is accidentally damaged. For the operator

So there is the special advantage of being able to tension each object individually

and also to be able to process them quickly without any special security measures

with regard to possible damage to adjacent support elements

or vacuum suction elements. Alternatively, the moving means

also be an electromagnetic means comprising one or more electro

magnetic lifting magnets, over which the support element is moved and over

the control device can be controlled.

GemÃ¤Ã einer ersten erfindungsgemÃ¤Ãen AusfÃ¼hrungsform ist das BewegungsÂ­

mittel ein elektrisches BetÃ¤tigungsmittel umfassend einen Elektromotor, insbesonÂ­

dere einen Servomotor, mittels welchem das Auflageelement samt Dichtelement

ausgefahren werden kann. Der Elektromotor treibt zweckmÃ¤Ãigerweise eine GeÂ­

windespindel an, die mit dem Auflageelement in einer Spindelaulnahme gekoppelt

ist. Zur Vermeidung eines Mitdrehens des bevorzugt zylindrischen AuflageeleÂ­

ments ist die Gewindespindel zweckmÃ¤Ãigerweise auÃermittig in der SpindelaufÂ­

nahme gefÃ¼hrt.According to a first embodiment of the invention, this is movement

means an electrical actuating means comprising an electric motor, in particular

a servomotor, by means of which the support element together with the sealing element

can be extended. The electric motor expediently drives a Ge

windspindel coupled with the support element in a spindle recess

is. To avoid rotating the preferably cylindrical support element

The threaded spindle is expediently off-center in the spindle run

led.

GemÃ¤Ã einer Erfindungsalternative kann vorgesehen sein, dass das BewegungsÂ­

mittel ein pneumatisches oder hydraulisches BetÃ¤tigungsmittel umfassend einen

ein- oder doppelseitig wirkenden Zylinder, der mit einem entsprechenden BeÂ­

triebsmittel beaufschlagbar ist, ist. Das Ausfahren erfolgt in diesem Fall dadurch,

dass der Zylinder Ã¼ber die Steuerungseinrichtung - sind mehrere VakuumansaugÂ­

elemente in einer Spannvorrichtung integriert, ist zweckmÃ¤Ãigerweise eine zentÂ­

rale, sÃ¤mtliche Steuerungsaufgaben Ã¼bernehmende Steuerungseinrichtung vorgeÂ­

sehen - durch Zufuhr des entsprechenden Betriebsmittels (im Falle eines pneuÂ­

matischen BetÃ¤tigungsmittels Pressluft, im Falle eines hydraulischen BetÃ¤tigungsmittels

eine HydraulikflÃ¼ssigkeit) angesteuert und das Auflageelement ausÂ­

gefahren wird. Zum Ansteuern bzw. zum ZufÃ¼hren des Betriebsmittels sind erfinÂ­

dungsgemÃ¤Ã ein oder mehrere Ã¼ber die Steuerungseinrichtung steuerbare VentilÂ­

elemente vorgesehen.According to an alternative of the invention it can be provided that the movement

means a pneumatic or hydraulic actuating means comprising one

single or double-acting cylinder, which with a corresponding loading

propellant is acted upon. In this case, the extension takes place by

that the cylinder over the control device - are several vacuum suction

elements integrated in a clamping device, is expediently a cent

rale control device taking over all control tasks

see - by supplying the appropriate equipment (in the case of a pneu

matic actuating means compressed air, in the case of a hydraulic actuating means

Â a hydraulic fluid) and the support element

is driven. To control or to feed the equipment are invented

In accordance with the invention one or more valve controllable via the control device

elements provided.

Wie bereits ausgefÃ¼hrt ist das Auflageelement zweckmÃ¤Ãigerweise zumindest im

Bereich unterhalb des Dichtelements im Wesentlichen zylindrisch ausgebildet,

wobei das Dichtelement am oder im Bereich des oberen Randes vorgesehen ist.

SelbstverstÃ¤ndlich ist es auch mÃ¶glich, den oberen Bereich des Auflageelements

viereckig oder quadratisch oder mehreckig auszubilden und auch das DichteleÂ­

ment entsprechend zu formen, was es ermÃ¶glicht, bei entsprechend enger AneiÂ­

nanderreihung der Vakuumansaugelemente die Dichtelemente der einzelnen AnÂ­

saugelemente aneinander anschlieÃen zu lassen und so eine fast geschlossene

SpannflÃ¤che zu bilden. Besonders zweckmÃ¤Ãig ist es, wenn am Auflageelement

auÃenseitig ein Konus ausgebildet ist, der in der Ausfahrstellung an einem festÂ­

stehenden Gegenkonus anliegt. Auf diese Weise wird in der Ausfahrstellung eine

Zentrierung erreicht.As already stated, the support element is expediently at least in

Area below the sealing element is essentially cylindrical,

the sealing element being provided on or in the region of the upper edge.

Of course, it is also possible to use the upper area of the support element

to be square or square or polygonal and also the seal

shape accordingly, which makes it possible, with a correspondingly narrow anei

lining up the vacuum suction elements, the sealing elements of each individual

to have suction elements connected to each other and thus an almost closed one

To form clamping surface. It is particularly useful if on the support element

a cone is formed on the outside, which is fixed to one in the extended position

standing cone. In this way, in the extended position

Centering reached.

Im Hinblick auf die aufzunehmende Last ist es zweckmÃ¤Ãig, wenn das AuflageÂ­

element aus einem Vollmaterial gebildet ist, in dem ein den Vakuumkanal verlÃ¤nÂ­

gernder Hohlkanal und gegebenenfalls, wenn das BetÃ¤tigungsmittel ein ElektroÂ­

motor ist, eine Aufnahme fÃ¼r die Spindel vorgesehen ist. In diese Aufnahme greift

oder tritt die Spindel ein, wenn das Auflageelement eingefahren wird. Dabei beÂ­

steht natÃ¼rlich die MÃ¶glichkeit, diese Aufnahme selbst mit einem Innengewinde zu

versehen, in welches die Spindel mit ihrem AuÃengewinde eingeschraubt wird, die

Aufnahme bildet also hier die Spindelaufnahme. NatÃ¼rlich kann auch eine sepaÂ­

rate Spindelaufnahme vorgesehen sein. Das Dichtelement ist zweckmÃ¤Ãigerweise

aus Gummi oder Kunststoff gebildet, wobei sichergestellt sein muss, dass diese

hinreichend flexibel ist und sich dichtend an die AnlageflÃ¤che des zu spannenden

Gegenstandes anliegt.With regard to the load to be absorbed, it is useful if the support

element is formed from a solid material, in which one extends the vacuum channel

annealing hollow channel and, if necessary, if the actuating means is an electric

motor, a receptacle for the spindle is provided. Reaches into this recording

or the spindle enters when the support element is retracted. Thereby be

there is, of course, the possibility of this recording even with an internal thread

provided, into which the spindle is screwed with its external thread, the

In this case, the holder forms the spindle holder. Of course, a sepa

rate spindle mount can be provided. The sealing element is expedient

made of rubber or plastic, it must be ensured that this

is sufficiently flexible and seals itself against the contact surface of the to be exciting

Object is present.

Das Auflageelement selbst ist zweckmÃ¤Ãigerweise lÃ¶sbar angeordnet. Dies bringt

den besonderen Vorteil mit sich, dass im Falle eines versehentlichen BeschÃ¤digens

des Auflageelements - sei es durch eine fehlerhafte Bewegung des BearÂ­

beitungswerkzeugs oder durch eine fehlerhafte Handhabung des aufzunehmenÂ­

den Gegenstands oder dergleichen - das Auflageelement samt Dichtelement auf

einfache Weise ausgetauscht werden kann und ein neues Auflageelement samt

Dichtelement befestigt wird. Das Auflageelement bildet also ein VerschleiÃeleÂ­

ment, das im Bedarfsfall mit wenigen Handgriffen ausgetauscht werden kann. Das

jeweilige Vakuumansaugelement ist sofort wieder einsetzbar, eine aufwendige

Reparatur wird hierdurch vorteilhaft vermieden. Die gesamte BearbeitungsmaÂ­

schine ist damit sofort wieder einsatzfÃ¤hig.The support element itself is expediently arranged releasably. This brings

the particular advantage that in the event of accidental damage

Â of the support element - be it due to incorrect movement of the bear

processing tool or incorrect handling of the record

the object or the like - the support element together with the sealing element

can be easily replaced and a new support element including

Sealing element is attached. The support element thus forms a wear element

ment that can be replaced in just a few steps if necessary. The

the respective vacuum suction element can be used again immediately, a complex one

This advantageously avoids repairs. The entire machining dimension

This means that the machine can be used again immediately.

Besonders vorteilhaft ist es, wenn das Auflageelement erst im Wesentlichen mit

Erreichen der Ausfahrendstellung mit dem Vakuumkanal des VakuumansaugeleÂ­

ments, welcher wiederum direkt oder indirekt mit einer externen Unterdruckquelle

gekoppelt ist, gekoppelt wird. Dies bietet den wesentlichen Vorteil, dass die UnterÂ­

druckquelle die Spannvorrichtung generell mit Unterdruck beaufschlagen Kann,

wobei aber die Auflageelemente gegenÃ¼ber dem vakuumelementseitigen VakuÂ­

umkanal abgedichtet und entkoppelt sind. Das heiÃt, das Unterdrucksystem ist

insoweit, wenn alle Auflageelemente eingefahren sind, geschlossen. Erst mit

Ausfahren eines Auflageelements erfolgt die Ankopplung desselben an den VakuÂ­

umkanal, nÃ¤mlich dann, wenn es die Ausfahrendstellung erreicht. In diesem Fall

kann dann der Unterdruck an das WerkstÃ¼ck weitergegeben werden. Es wird daÂ­

mit vorteilhaft erreicht, dass also nur die ausgefahrenen Auflageelemente mit UnÂ­

terdruck beaufschlagt sind. Ein weiterer Vorteil ist, dass diesbezÃ¼glich keine sepaÂ­

raten Ventilelemente seitens eines Vakuumansaugelements vorgesehen werden

mÃ¼ssen, die das Auflageelement vom Vakuumkanal abkoppeln mÃ¼ssten.It is particularly advantageous if the support element is essentially only included

Reaching the extended end position with the vacuum channel of the vacuum intake

ment, which in turn directly or indirectly with an external vacuum source

is coupled, is coupled. This offers the main advantage that the sub

pressure source can generally apply negative pressure to the tensioning device,

but with the support elements compared to the vacuum element-side vacuum

are sealed and decoupled. That is, the vacuum system is

insofar as all support elements are retracted, closed. First with

When a support element is extended, it is coupled to the vacuum

umkanal, namely when it reaches the extended end position. In this case

the negative pressure can then be passed on to the workpiece. It will be there

achieved with advantage that only the extended support elements with Un

pressure are applied. Another advantage is that there is no sepa in this regard

advise valve elements provided by a vacuum suction element

need to decouple the support element from the vacuum channel.

Zur ErmÃ¶glichung einer einfachen positionsbezogenen Kanalkopplung ist zweckÂ­

mÃ¤Ãigerweise am Auflageelement eine Ãffnung vorgesehen, die in der AusfahrÂ­

endstellung Ã¼ber ein Dichtmittel abgedichtet mit einer VakuumkanalÃ¶ffnung komÂ­

muniziert. Der Vakuumkanal besitzt also eine endseitige Ãffnung, eine entspreÂ­

chende Ãffnung ist auch am Auflageelement vorgesehen, wobei beide Ãffnungen

in der Ausfahrendstellung einander gegenÃ¼berliegen, so dass der Unterdruck an

das Auflageelement weitergegeben werden kann. Am Vakuumansaugelement

selbst ist zweckmÃ¤Ãigerweise ein mit einer Unterdruckquelle direkt oder indirekt

verbindbarer Vakuumkanal vorgesehen, der mit seiner KanalÃ¶ffnung mit der ÃffÂ­

nung des Auflageelements verbindbar ist. Alternativ dazu ist es auch mÃ¶glich,

dass die Ãffnung des Auflageelements direkt mit einem externen, mit der UnterÂ­

druckquelle direkt oder indirekt verbindbaren Vakuumkanal, der seitens der

Spannvorrichtung an eine wie nachfolgend noch beschrieben wird separaten VorÂ­

richtungsgehÃ¤use oder Vorrichtungsgestell ausgebildet ist, verbindbar ist.To enable a simple position-related channel coupling is the purpose

moderately provided on the support element an opening in the extension

end position sealed with a sealant with a vacuum channel opening com

munited. The vacuum channel therefore has an opening at the end, a corresponding one

The opening is also provided on the support element, with both openings

are opposite each other in the extended position, so that the vacuum is on

the support element can be passed on. On the vacuum suction element

Â itself is expediently one with a vacuum source, directly or indirectly

connectable vacuum channel is provided, the channel opening with the opening

tion of the support element is connectable. Alternatively, it is also possible

that the opening of the support element directly with an external, with the sub

The vacuum source can be connected directly or indirectly to the pressure source

Clamping device to a separate as described below

directional housing or device frame is formed, is connectable.

GemÃ¤Ã einer weiteren zweckmÃ¤Ãigen Erfindungsausgestaltung kann vorgesehen

sein, dass das Vakuumansaugelement bzw. jedes Vakuumansaugelement lÃ¶sbar

an oder in einem Vorrichtungsgestell anordenbar ist. Dies ermÃ¶glicht es mit beÂ­

sonderem Vorteil, insbesondere bei grÃ¶Ãeren, mehrere Vakuumansaugelemente

umfassenden Spannvorrichtungen lediglich diejenigen AufnahmeplÃ¤tze fÃ¼r VakuÂ­

umansaugelemente mit eben solchen zu bestÃ¼cken, die fÃ¼r das Spannen eines

WerkstÃ¼cks auch tatsÃ¤chlich benÃ¶tigt werden. ZusÃ¤tzlich verbleibt als weitere VaÂ­

riationsmÃ¶glichkeit natÃ¼rlich das beliebige Ausfahren der Auflageelemente, so

dass der Bediener insgesamt hinsichtlich der SpannmÃ¶glichkeiten Ã¤uÃerst variabel

arbeiten kann.According to a further expedient embodiment of the invention, provision can be made

be that the vacuum suction element or each vacuum suction element detachable

can be arranged on or in a device frame. With be

special advantage, especially with larger, several vacuum suction elements

comprehensive clamping devices only those places for vacuum

umansaugelemente to be equipped with just those for clamping a

Workpiece are actually needed. In addition, Va remains as a further

Riation possibility of course extending the support elements, so

that the operator as a whole is extremely variable with regard to the clamping options

can work.

Besonders vorteilhaft ist, wenn am Vakuumansaugelement Verbindungsmittel zum

Verbinden desselben in der Einsetzendstellung mit einem gestellseitig vorgeseheÂ­

nen, mit einer Unterdruckquelle direkt oder indirekt verbindbaren Vakuumkanal

und/oder zum Verbinden des Bewegungsmittels mit der Steuerungseinrichtung

und gegebenenfalls mit einer Versorgungseinrichtung zum ZufÃ¼hren eines zum

Betrieb des Bewegungsmittels benÃ¶tigten Betriebsmittels vorgesehen sind. Diese

Verbindungsmittel lassen es mit besonderem Vorteil zu, dass das VakuumanÂ­

saugelement beim Einsetzen bzw. mit Erreichen der Einsetzendstellung automaÂ­

tisch mit sÃ¤mtlichen Betriebselementen wie dem Vakuumkanal, der SteuerungsÂ­

einrichtung oder aber einer Versorgungseinrichtung fÃ¼r das Betriebsmittel gekopÂ­

pelt wird. Zum Einrichten der Vorrichtung werden also die VakuumansaugeleÂ­

mente einfachst in die entsprechenden Aufnahmen ein- bzw. auf die entsprechenÂ­

den Aufnahmen aufgestellt (wozu hinsichtlich der richtigen Kontaktierung eine entÂ­

sprechende Lagekodierung vorgesehen sein kann, die sicherstellt, dass das Vakuumansaugelement

nur in einer bestimmten Stellung eingesetzt werden kann).

Der gesamte Einrichtungsprozess geht also Ã¤uÃerst rasch vonstatten. Die variable

EinrichtungsmÃ¶glichkeit durch einfaches Einstecken der Vakuumansaugelemente

ist auch unabhÃ¤ngig von der Ausgestaltung der Vakuumelemente mit ausfahrbaÂ­

ren Auflageelementen vorteilhaft, beispielsweise bei Vakuumansaugelementen mit

starren Auflageelementen, die dann lediglich mit einem gestellseitig vorgesehenen

Vakuumkanal gekoppelt werden.It is particularly advantageous if connection means to the vacuum suction element

Connect the same in the insertion end position with one provided on the frame

NEN, with a vacuum source directly or indirectly connectable vacuum channel

and / or for connecting the movement means to the control device

and optionally with a supply device for supplying a

Operation of the means of movement required equipment are provided. This

Lanyards allow with particular advantage that the vacuum

Suction element when inserting or when reaching the insert end position automa

table with all operating elements such as the vacuum channel, the control

device or a supply facility for the operating equipment

pelt is. To set up the device, the vacuum suction gels are used

elements in the corresponding recordings or on the corresponding ones

set up the recordings (for which purpose an ent

Talking position coding can be provided, which ensures that the vacuum suction element

Â can only be used in a certain position).

The entire setup process is extremely quick. The variable

Can be set up by simply plugging in the vacuum suction elements

is also independent of the design of the vacuum elements with extendable

Ren support elements advantageous, for example with vacuum suction elements

rigid support elements, which are then only provided with a frame side

Vacuum channel can be coupled.

Die Verbindungsmittel sind zweckmÃ¤Ãigerweise steckerartig ausgebildet und werÂ­

den mit gestellseitig vorgesehenen buchsenartigen GegenstÃ¼cken beim Anordnen

des Vakuumansaugelements an oder im Vorrichtungsgestell automatisch verbunÂ­

den. Dabei kÃ¶nnen am Vorrichtungsgestell ein oder mehrere Leiterverbindungen,

insbesondere gedruckte Leiterbahnen vorgesehen sein, Ã¼ber die das BeweÂ­

gungsmittel mit der Steuerungseinrichtung koppelbar ist. An den LeiterverbindunÂ­

gen sind die entsprechenden, bevorzugt buchsenartigen GegenstÃ¼cke vorgeseÂ­

hen, in die die bevorzugt als einfache Kontaktstecker ausgebildeten VerbinÂ­

dungsmittel des Vakuumansaugelements beim Einsetzen eingreifen. NatÃ¼rlich ist

es auch mÃ¶glich, seitens der Leiterbahnen keine GegenstÃ¼cke vorzusehen, sonÂ­

dern die Verbindungsmittel als beispielsweise federgelagerte Kontaktstempel ausÂ­

zubilden, die beim Einsetzen auf die entsprechenden KontaktflÃ¤chen der LeiterÂ­

bahnen drÃ¼cken.The connecting means are expediently plug-shaped and who

the socket-like counterparts provided on the frame side when arranging

of the vacuum suction element on or in the fixture frame

the. One or more conductor connections,

In particular, printed conductor tracks can be provided, via which the movement

means can be coupled to the control device. At the wire connection

The corresponding, preferably socket-like counterparts are provided

hen, in which the preferably designed as a simple contact plug connector

Intervene with the vacuum suction element when inserting. of course is

it is also possible not to provide counterparts on the part of the conductor tracks, son

the connecting means from, for example, spring-loaded contact stamps

to form when inserted on the corresponding contact surfaces of the conductors

press lanes.

Weiterhin kÃ¶nnen am Vorrichtungsgestell eine oder mehrere VersorgungskanÃ¤le

zum ZufÃ¼hren und/oder AbfÃ¼hren des Betriebsmittels, also beispielsweise der

Pressluft vorgesehen sein. Die Verbindungsmittel am Vakuumansaugelement soÂ­

wie seitens des Vorrichtungsgestells sind dann als entsprechende PneumatiksteÂ­

cker oder Hydraulikstecker ausgebildet.Furthermore, one or more supply channels can be provided on the device frame

to feed and / or discharge the equipment, for example the

Compressed air may be provided. The connecting means on the vacuum suction element like this

then on the part of the device frame are the corresponding pneumatic

or hydraulic plug.

Das Vorrichtungsgestell weist fÃ¼r die erfindungsgemÃ¤Ãe einfache Kontaktierung

zweckmÃ¤Ãigerweise eine Aufnahmeplatte auf, auf welche das oder die VakuumÂ­

elemente aufstellbar sind, und an welcher die Leiterverbindungen und/oder die

VersorgungskanÃ¤le und ggf. die entsprechenden gestellseitigen Verbindungsmittel

vorgesehen sind. GemÃ¤Ã einer ersten Erfindungsausgestaltung des Vorrichtungsgestells

kann an der Aufnahmeplatte auch der gestellseitige Vakuumkanal vorgeÂ­

sehen sein, welcher mit der Unterdruckquelle gekoppelt wird. Dabei ist zweckmÃ¤Â­

Ãigerweise ein Vakuumkanalnetz vorgesehen, wenn sich die Spannvorrichtung in

x- und in y-Richtung erstreckt, wobei jedes Vakuumansaugelement mit dem VakuÂ­

umkanalnetz an der entsprechenden Position verbunden werden kann. Eine ErfinÂ­

dungsalternative sieht demgegenÃ¼ber vor, dass das Vorrichtungsgestell eine obeÂ­

re, eine Durchsteckaufnahme fÃ¼r das Vakuumelement aufweisende Platte umÂ­

fasst, an welcher der gestellseitige Vakuumkanal bzw. das Vakuumkanalnetz im

Falle einer grÃ¶Ãeren Spannvorrichtung vorgesehen ist. Die Halterung des VakuÂ­

umansaugelements erfolgt bei dieser Ausgestaltung vor allem im Bereich der

Durchsteckaufnahme, in welcher es fest und Ã¼ber geeignete Dichtelemente abgeÂ­

dichtet aufgenommen ist. Ist keine solche obere Platte vorgesehen, dann sind

seitens des Vakuumelements und der Aufnahmeplatte entsprechende BefestiÂ­

gungselemente, z. B. Rast- oder Schnappelemente oder dergleichen vorgesehen,

die eine sichere Halterung jedes Vakuumansaugelements ermÃ¶glichen.The device frame has for the simple contacting according to the invention

expediently a mounting plate on which the vacuum or vacuum

elements can be set up, and on which the conductor connections and / or the

Supply channels and, if necessary, the corresponding connection means on the rack

are provided. According to a first inventive embodiment of the device frame

Â can also the frame-side vacuum channel on the mounting plate

be seen, which is coupled to the vacuum source. It is appropriate

A vacuum duct network is usually provided when the tensioning device is in

Extends x and y direction, each vacuum suction element with the vacuum

canal network can be connected at the appropriate position. An inventor

In contrast, the alternative provides that the device frame has a top

right, a push-through receptacle for the plate having the vacuum element

summarizes at which the frame-side vacuum channel or the vacuum channel network in the

In case of a larger clamping device is provided. The holder of the vacuum

Umansaugelements takes place in this embodiment, especially in the area of

Push-through receptacle in which it is fixed and abge via suitable sealing elements

sealed is recorded. If no such top plate is provided, then

appropriate fastening on the part of the vacuum element and the mounting plate

supply elements, e.g. B. locking or snap elements or the like is provided,

which enable a secure mounting of every vacuum suction element.

Wie ausgefÃ¼hrt kann die erfindungsgemÃ¤Ãe Spannvorrichtung als EinzelvorrichÂ­

tung mit nur einem Vakuumansaugelement oder als Mehrfachvorrichtung mit anÂ­

nÃ¤hernd beliebig vielen Vakuumansaugelementen ausgebildet sein. Ist ein besonÂ­

ders groÃes WerkstÃ¼ck zu spannen, das mit einer einzelnen vorhandenen SpannÂ­

vorrichtung nicht gespannt werden kann, hat es sich als besonders zweckmÃ¤Ãig

erwiesen, wenn jede Spannvorrichtung ein Vorrichtungsgestell oder -gehÃ¤use

aufweist, an dem weitere Verbindungsmittel vorgesehen sind, mittels denen ein

gestell- oder gehÃ¤useseitiger Vakuumkanal und/oder die Leiterverbindung(en)

bzw. der oder die VersorgungskanÃ¤le fÃ¼r das Bewegungsmittel zweier VorrichtunÂ­

gen verbindbar sind. Diese ErfindungsausfÃ¼hrung ermÃ¶glicht es also, zwei oder

mehrere Spannvorrichtungen miteinander zu koppeln und die entsprechenden

Betriebsmittel, also den Unterdruck, die elektrischen Steuersignale und ggf. das

Betriebsmittel von Spannvorrichtung zu Spannvorrichtung durchzuschleifen. GeÂ­

mÃ¤Ã einer ersten Erfindungsausgestaltung kÃ¶nnen dabei die Verbindungsmittel

derart ausgebildet sein, dass die Verbindung beim direkten Aneinanderstellen der

Vorrichtung automatisch hergestellt wird. Werden also zwei Gestelle aneinander

geschoben, so verbinden sich die Verbindungsmittel automatisch. Alternativ dazu

ist es natÃ¼rlich auch mÃ¶glich, die jeweiligen KanÃ¤le bzw. Leiterverbindungen mitÂ­

tels geeigneter SchlÃ¤uche oder Kabel zu koppeln, wenn die Spannvorrichtungen

voneinander beabstandet platziert werden.As stated, the tensioning device according to the invention can be used as a single device

device with only one vacuum suction element or as a multiple device

almost any number of vacuum suction elements can be formed. Is a special

to clamp the large workpiece with a single existing clamp

device can not be cocked, it has proven to be particularly useful

proven when each jig is a jig frame or housing

has, on which further connecting means are provided, by means of which a

rack or housing side vacuum channel and / or the conductor connection (s)

or the supply channel or channels for the movement means of two devices

are connectable. This embodiment of the invention therefore enables two or

couple several jigs and the corresponding

Operating resources, i.e. the negative pressure, the electrical control signals and possibly that

Grind through equipment from clamping device to clamping device. Ge

According to a first embodiment of the invention, the connecting means

be designed such that the connection when the

Device is manufactured automatically. So two racks together

pushed, the lanyards connect automatically. Alternatively

Â it is of course also possible to use the respective channels or conductor connections

by means of suitable hoses or cables when the clamping devices

placed apart from each other.

Bei einer Spannvorrichtung, bei der mehrere Vakuumansaugelemente vorgesehen

sind, die in einem gemeinsamen Vorrichtungsgestell gehaltert sind, ist es besonÂ­

ders zweckmÃ¤Ãig, wenn jedes der Auflageelemente der in einer gemeinsamen

Ebene angeordneten Vakuumansaugelemente separat Ã¼ber eine zentrale SteueÂ­

rungseinrichtung steuerbar ist, so dass beliebige Auflageelemente aus dem VerÂ­

bund der Vakuumansaugelemente in die Ausfahrendstellung bringbar und in diese

arretierbar sind. Die zentrale Steuerungseinrichtung steuert also den gesamten

Betrieb der Spannvorrichtung. Vorteilhaft ist es dabei, wenn die SteuerungseinÂ­

richtung zum Ansteuern der Vakuumansaugelemente in AbhÃ¤ngigkeit gespeiÂ­

cherte oder erfasster Informationen bezÃ¼glich des aufzunehmenden Gegenstands

ausgebildet ist, so dass die Auflageelemente in eine gegenstandsbezogene PosiÂ­

tion bringbar sind. Bei dieser Ausgestaltung sind beispielsweise in der SteueÂ­

rungseinrichtung die geometrischen Daten eines bestimmten zu spannenden

WerkstÃ¼cks abgelegt. Soll dieses WerkstÃ¼ck nun gespannt werden, so wird seiÂ­

tens der Steuerungseinrichtung der entsprechende Gegenstand angewÃ¤hlt und

automatisch die zum Spannen desselben erforderlichen Auflageelements ausgeÂ­

fahren. Dabei ist es mÃ¶glich, durch den Bediener den entsprechenden GegensÂ­

tand auszuwÃ¤hlen. Eine zweckmÃ¤Ãige Erfindungsalternative sieht demgegenÃ¼ber

vor, dass Mittel zum Erfassen einer Kennung eines aufzunehmenden GegensÂ­

tands vorgesehen sind, die mit der Steuerungseinrichtung kommunizieren. Hier

wird also seitens der Spannvorrichtung Ã¼ber beispielsweise einen Barcodeleser

oder einen Transponderleser ein entsprechender Barcode oder Transponder, der

am aufzunehmenden WerkstÃ¼ck befestigt ist, eingelesen und automatisch die erÂ­

fasste Information an die Steuerungseinrichtung gegeben, die dann die InformatiÂ­

on auswertet, den Gegenstand in seiner Art bestimmt, die entsprechenden Daten

ausliest oder aus der Information extrahiert und die Auflageelemente entspreÂ­

chend steuert. Alternativ dazu kann das Erfassungsmittel auch eine KameraeinÂ­

richtung zum Aufnehmen des Gegenstands umfassen, die mit der SteuerungseinÂ­

richtung, die ein Mittel zum Verarbeiten des aufgenommenen Bilds zum Erkennen

des Gegenstands und/oder dessen OberflÃ¤chenform aufweist, kommuniziert. Hier

wird ein Bild des Gegenstandes aufgenommen, welches anschlieÃend ausgewerÂ­

tet wird.In a clamping device in which several vacuum suction elements are provided

which are held in a common device frame, it is special

expedient if each of the support elements in a common

Vacuum suction elements arranged separately on a central control

tion device is controllable, so that any support elements from the Ver

The vacuum suction elements can be brought into and into the extended end position

can be locked. The central control device thus controls the whole

Operation of the tensioning device. It is advantageous if the control is

direction for controlling the vacuum suction elements depending on the feed

saved or recorded information regarding the object to be recorded

is formed so that the support elements in an item-related item

tion can be brought. In this configuration, for example, are in the tax

the geometric data of a certain to exciting

Workpiece. If this workpiece is now to be clamped, then

at least the control device selected the corresponding object and

automatically the support element required for tensioning the same

drive. It is possible for the operator to select the appropriate counter

tand select. In contrast, an expedient alternative of invention sees

that means for acquiring an identifier of a counter to be recorded

tands are provided that communicate with the control device. Here

is on the part of the clamping device via, for example, a barcode reader

or a transponder reader a corresponding barcode or transponder that

attached to the workpiece to be picked up, and automatically read it

summarized information given to the control device, which then the Informati

one evaluates, determines the type of object, the corresponding data

reads or extracted from the information and the support elements correspond

controls. Alternatively, the detection means can also be a camera

device for receiving the object, which with the control unit

direction, which is a means of processing the captured image for recognition

Â of the object and / or its surface shape communicates. Here

a picture of the object is taken, which is then evaluated

is tested.

Neben der Spannvorrichtung, die als Einzel- oder als Mehrfachspannvorrichtung

ausgebildet sein kann, betrifft die Erfindung ferner eine Anordnung zum Halten

eines flÃ¤chigen Gegenstandes durch Ansaugen desselben, umfassend mehrere

Spannvorrichtungen mit jeweils einem oder mehreren Vakuumansaugelementen

der vorbeschriebenen Art, sowie eine zentrale, den Betrieb der Vorrichtung steuÂ­

ernden Steuerungseinrichtung. Bei dieser erfindungsgemÃ¤Ãen Anordnung sind

mehrere separate Spannvorrichtungen vorgesehen, die Ã¼ber eine gemeinsame

Steuerungseinrichtung in ihrem Betrieb gesteuert werden. Dabei kann die SteueÂ­

rungseinrichtung zum automatischen Einstellen der Vakuumansaugelemente bzw.

der Auflageelemente in eine gegenstandsbezogene Position in AbhÃ¤ngigkeit einer

eingegebenen oder erfassten Gegenstandsinformation ausgebildet sein, so dass

ein automatisches Einstellen bezogen auf den nachfolgend zu spannenden GeÂ­

genstand mÃ¶glich ist. Die hierfÃ¼r verwendbaren Mittel wurden bereits bezÃ¼glich

der erfindungsgemÃ¤Ãen Spanneinrichtung erwÃ¤hnt.In addition to the clamping device, which as a single or multiple clamping device

can be formed, the invention further relates to an arrangement for holding

of a flat object by sucking the same, comprising several

Clamping devices with one or more vacuum suction elements each

of the type described above, as well as a central, control the operation of the device

control device. In this arrangement according to the invention

Several separate clamping devices are provided, which have a common one

Control device can be controlled in their operation. Thereby the tax

tion device for automatic adjustment of the vacuum suction elements or

the support elements in an object-related position depending on a

entered or recorded object information can be formed so that

an automatic setting based on the following exciting Ge

object is possible. The funds that can be used for this have already been referred to

mentioned the tensioning device according to the invention.

Weitere Vorteile, Merkmale und Einzelheiten der Erfindung ergeben sich aus den

im Folgenden beschriebenen AusfÃ¼hrungsbeispielen sowie anhand der ZeichnunÂ­

gen. Dabei zeigen:Further advantages, features and details of the invention result from the

The exemplary embodiments described below and on the basis of the drawing

Show:

Fig. 1 eine Prinzipdarstellung einer erfindungsgemÃ¤Ãen Spannvorrichtung

einer ersten AusfÃ¼hrungsform, Fig. 1 is a schematic diagram of a clamping apparatus of a first embodiment according to the invention,

Fig. 2 eine Prinzipdarstellung einer erfindungsgemÃ¤Ãen Spannvorrichtung

mit mehreren Vakuumansaugelementen entsprechend Fig. 1, Fig. 2 is a schematic diagram of a clamping device according to the invention with several Vakuumansaugelementen corresponding to FIG. 1,

Fig. 3 eine Aufsicht auf die Spannvorrichtung gemÃ¤Ã Fig. 2, Fig. 3 is a plan view of the clamp apparatus of FIG. 2,

Fig. 4 eine Prinzipdarstellung einer weiteren erfindungsgemÃ¤Ãen SpannÂ­

vorrichtung, und

Fig. 4 is a schematic diagram of another clamping device according to the invention, and

Fig. 5 eine Prinzipansicht zur Darstellung der Lage der am VakuumanÂ­

saugelement befindlichen Verbindungsmittel zum Verbinden desselÂ­

ben zu entsprechenden KanÃ¤len und Leitungen seitens der AufnahÂ­

meplatte. Fig. 5 is a schematic view showing the position of the connecting element located on the vacuum suction element for connecting the same to corresponding channels and lines on the part of the receiving plate.

Fig. 1 zeigt eine erfindungsgemÃ¤Ãe Spannvorrichtung 1, umfassend ein VorrichÂ­

tungsgestell 2 mit einer unteren Aufnahmeplatte und einer oberen Platte 4. In der

oberen Platte 4 ist eine Durchsteckaufnahme 5 vorgesehen, in welche ein VakuÂ­

umansaugelement 6 eingesteckt werden kann, das bodenseitig auf der AufnahÂ­

meplatte 3 aufsitzt. Im Bereich der Durchsteckaufnahme 5 ist ein Dichtmittel 7,

vorzugsweise in Form eines O-Dichtrings vorgesehen, Ã¼ber welches das VakuumÂ­

ansaugelement 6 bezÃ¼glich der oberen Platte 4 abgedichtet ist. Der Durchmesser

der Durchsteckaufnahme 5 ist so bemessen, dass das Vakuumansaugelement

dort fest aufgenommen ist. Das Vakuumansaugelement 6 umfasst ein GehÃ¤use 8,

an dem ein Elektromotor 9, bevorzugt ein Servemotor angeordnet ist. Der ElektÂ­

romotor 9 treibt Ã¼ber eine Rutschkupplung 10 eine Gewindespindel 11 an, die in

einer Spindelaufnahme 12, die mit einem entsprechenden Innengewinde versehen

ist, aufgenommen ist. Die Spindelaufnahme 12 wiederum ist Teil eines AuflageÂ­

elements 13, das beweglich im GehÃ¤use 8 aufgenommen ist. Das Auflageelement

13 besteht aus einem Vollmaterial und besitzt eine Aufnahme 14, in die die GeÂ­

windespindel 11 eingreifen kann, wenn das Auflageelement 13 ausgefahren wird.

Dies erfolgt Ã¼ber den Elektromotor 9, der die Gewindespindel 11 antreibt. Fig. 1

zeigt das Auflageelement in der ausgefahrenen Stellung. Wird die Gewindespindel

in die entgegengesetzte Richtung gedreht, so wird das Auflageelement 13 ins GeÂ­

hÃ¤useinnere eingezogen, da die Spindelaufnahme 12 sich entlang der feststehenÂ­

den Gewindespindel nach unten bewegt. Die Gewindespindel 11 greift beim nach

unten Bewegen in die Aufnahme 14 ein. Hierdurch ist es mÃ¶glich, das AuflageÂ­

element 13 zwischen einer eingezogenen Einfachendstellung und einer ausgefahÂ­

renen Ausfahrendstellung (die in Fig. 1 gezeigt ist) zu bewegen. In der in Fig. 1

gezeigten Stellung ist das Auflageelement 13 arretiert, da es bei Belastung aufÂ­

grund des Eingriffs des AuÃengewindes der Gewindespindel in das Innengewinde

der Spindelaufnahme nicht nach unten rutschen kann.

Fig. 1 shows a clamping device 1 according to the invention, comprising a Vorrich processing frame 2 with a lower mounting plate and an upper plate 4th In the upper plate 4 , a push-through receptacle 5 is provided, into which a vacuum transfer element 6 can be inserted, which sits on the bottom of the receiving plate 3 . In the region of the plug-in receptacle 5 is a sealing means 7, preferably in the form of an O-sealing ring, via which the vacuum suction member 6 with respect to the upper plate is sealed. 4 The diameter of the push-through receptacle 5 is dimensioned such that the vacuum suction element is firmly received there. The vacuum suction element 6 comprises a housing 8 , on which an electric motor 9 , preferably a servo motor, is arranged. The electric motor 9 drives a threaded spindle 11 via a slip clutch 10 , which is received in a spindle receptacle 12 , which is provided with a corresponding internal thread. The spindle holder 12 in turn is part of a support element 13 which is movably received in the housing 8 . The support element 13 consists of a solid material and has a receptacle 14 in which the Ge threaded spindle 11 can engage when the support element 13 is extended. This is done via the electric motor 9 , which drives the threaded spindle 11 . Fig. 1 shows the support element in the extended position. If the threaded spindle is rotated in the opposite direction, the support element 13 is retracted into the interior of the housing, since the spindle receptacle 12 moves downward along the fixed threaded spindle. The threaded spindle 11 engages in the receptacle 14 when moving downward. This makes it possible to move the support element 13 between a retracted single end position and an extended end position (which is shown in FIG. 1). In the position shown in Fig. 1, the support element 13 is locked because it can not slide down under load due to the engagement of the external thread of the threaded spindle in the internal thread of the spindle receptacle.

Der Betrieb des Elektromotors 9 wird Ã¼ber eine externe Steuerungseinrichtung 15

gesteuert. Diese ist mit nicht nÃ¤her gezeigten Leiterbahnen an der Aufnahmeplatte

13 kontaktiert. Die Leiterbahnen werden Ã¼ber steckerartige Verbindungsmittel 16,

die bodenseitig vom Vakuumansaugelement 6 abstehen, kontaktiert. Dies erfolgt

beim Einsetzen des Vakuumansaugelements 6, wobei die Einsetzstellung insoweit

codiert ist, d. h., das Vakuumansaugelement 6 kann nur in einer bestimmten PosiÂ­

tion in die Durchsteckaufnahme 5 eingesteckt werden. Erreicht das VakuumeleÂ­

ment 6 die Aufnahmeplatte 3, so greifen die Verbindungsmittel 16 automatisch in

entsprechende buchsenartige GegenstÃ¼cke 17, an denen wiederum die LeiterÂ­

bahnen enden. Hierdurch wird der Elektromotor 9 mit der Steuerungseinrichtung

15 kontaktiert. Diese kann den Elektromotor nun bei Bedarf ansteuern und somit

steuern, ob das Auflageelement 13 aus- oder eingefahren wird.The operation of the electric motor 9 is controlled by an external control device 15 . This is contacted with conductor tracks, not shown, on the mounting plate 13 . The conductor tracks are contacted via plug-type connecting means 16 , which protrude from the bottom of the vacuum suction element 6 . This takes place when the vacuum suction element 6 is inserted, the insertion position being coded insofar as this means that the vacuum suction element 6 can only be inserted into the push-through receptacle 5 in a certain position. Reaches the vacuum element 6, the receiving plate 3 , the connecting means 16 automatically engage in corresponding socket-like counterparts 17 , on which in turn the conductors end. As a result, the electric motor 9 is contacted with the control device 15 . This can now control the electric motor when required and thus control whether the support element 13 is extended or retracted.

Das Auflageelement 13, das bevorzugt zylindrisch ausgebildet ist, weist an seinem

unteren Abschnitt einen Konus 18 auf, der an einem entsprechenden Gegenkonus

19 des GehÃ¤uses 8 in der Ausfahrendstellung gegengelagert ist, d. h., er wird daÂ­

gegen gepresst. Hierdurch wird eine Zentrierung erzielt. Weiterhin ist die GewinÂ­

despindel 11 auÃermittig in der Spindelaufnahme 12 gefÃ¼hrt, was es verhindert,

dass sich das Auflageelement 13 beim Aus- oder Einfahren mitdreht.The support element 13 , which is preferably cylindrical, has a cone 18 on its lower section, which is counter-mounted on a corresponding counter-cone 19 of the housing 8 in the extended end position, ie it is pressed against it. Centering is achieved in this way. Furthermore, the thread despindel 11 is eccentrically guided in the spindle receptacle 12 , which prevents the support element 13 from rotating when it is extended or retracted.

An der oberen Platte 4 ist ein Vakuum- oder Unterdruckkanal 20 vorgesehen, welÂ­

cher bei grÃ¶Ãeren Spannvorrichtungen netzartig ausgebildet ist. Hierzu besteht die

obere Platte 20 aus zwei Einzelplatten 21, 22, wobei an der einen das Kanalnetz

eingefrÃ¤st ist, die andere dient zum Abdecken desselben. Der Vakuumkanal 20

endet mit einer KanalÃ¶ffnung 23 an der Durchsteckaufnahme 5 im Bereich unterÂ­

halb des Dichtmittels 7. Am GehÃ¤use 8 ist ein weiterer ansaugelementseitiger VaÂ­

kuumkanal 24 vorgesehen, der in der Einsetzstellung wie in Fig. 1 gezeigt mit dem

Vakuumkanal 20 kommuniziert. Der Vakuumkanal 24 ist als Kanalring, der um die

Innenwandung des GehÃ¤uses in diesem Bereich umlÃ¤uft, ausgebildet, von dem

aus ein Stichkanal abgeht, der zum Kanal 20 fÃ¼hrt. Aufgrund der Einsetzcodierung

ist sichergestellt, dass der Stichkanal stets mit dem Vakuumkanal 20 verbunden

wird. Im eingesetzten Zustand ist also der Unterdruck bis in den Vakuumkanal 24

fÃ¼hrbar. Um den Unterdruck nun Ã¼ber das Auflageelement 13, das an seinem obeÂ­

ren Ende ein Dichtelement 25 besitzt, welches die Dichtung zum aufzunehmenden

Gegenstand hin erwirkt, zu fÃ¼hren und damit den Gegenstand zu beaufschlagen

und anzusaugen, ist am aus einem Vollmaterial bestehenden Auflageelement 13

ein Hohlkanal 26 ausgebildet, der Ã¼ber eine Ãffnung 27 an der Seite des AuflageÂ­

elements 13 austritt. Ferner tritt der Hohlkanal 26 auch oberseitig am AuflageeleÂ­

ment, umgeben vom Dichtelement 25 aus, wobei dort zur Verhinderung des EinÂ­

dringens von Staub und Verunreinigungen ein Filterelement (Fig. 3) eingesetzt ist.

Ersichtlich ist die Lage der Ãffnung 27 so gewÃ¤hlt, dass diese dem Vakuumkanal

24 nur dann gegenÃ¼berliegt und folglich der Hohlkanal 26 mit Unterdruck beaufÂ­

schlagt werden kann, wenn das Auflageelement 13 in der Ausfahrendstellung wie

in Fig. 1 gezeigt ist. In dieser Stellung ist also der Hohlkanal 26 mit dem VakuumÂ­

kanal 20 und damit mit der externen Unterdruckquelle gekoppelt. Sobald das AufÂ­

lageelement 13 nach unten eingefahren wird, entfernt sich die Ãffnung 27 vom

Vakuumkanal 24 nach unten, die AuÃenwand des Auflageelements 13 dichtet

dann zum Vakuumkanal 24 hin ab. Hierdurch ist sichergestellt, dass dann, wenn

das Auflageelement 13 nicht in der Ausfahrendstellung ist, das Unterdruck- oder

Vakuumsystem gebildet von dem vorzugsweise netzartigen Vakuumkanal 20 und

dem internen Vakuumkanal 24 geschlossen ist. Erst dann, wenn das AuflageeleÂ­

ment 13 ausgefahren wird und tatsÃ¤chlich benÃ¶tigt wird, wird es an den VakuumÂ­

kanal 20 angekoppelt. Um zu vermeiden, dass sich im eingefahrenen Zustand

Staub oder Schmutz auf dem Auflageelement abscheidet kann ein sich beim EinÂ­

fahren in die Einfahrendstellung automatisch schlieÃendes Verschlussteil, z. B. ein

Lamellenverschluss vorgesehen sein, der oberseitig zumacht. Beim Ausfahren

Ã¶ffnet sich das Verschlussteil automatisch wieder.On the upper plate 4 , a vacuum or vacuum channel 20 is provided, which is net-like in larger clamping devices. For this purpose, the upper plate 20 consists of two individual plates 21 , 22 , one of which has the duct network milled in, the other serves to cover the same. The vacuum channel 20 ends with a channel opening 23 on the push-through receptacle 5 in the area below half of the sealant 7 . On the housing 8 a further suction element-side vacuum channel 24 is provided, which communicates with the vacuum channel 20 in the inserted position as shown in FIG. 1. The vacuum channel 24 is designed as a channel ring, which runs around the inner wall of the housing in this area, from which a branch channel leads, which leads to the channel 20 . The insert coding ensures that the branch channel is always connected to the vacuum channel 20 . In the inserted state, the negative pressure can thus be carried into the vacuum channel 24 . In order to guide the negative pressure now over the support element 13 , which has a sealing element 25 at its upper end, which effects the seal to the object to be picked up, and thus act on the object and suck it in, a hollow channel is formed on the support element 13 consisting of a solid material 26 formed, which exits through an opening 27 on the side of the support element 13 . Furthermore, the hollow channel 26 also occurs on the upper side of the support element, surrounded by the sealing element 25 , a filter element ( FIG. 3) being used there to prevent the ingress of dust and contaminants. As can be seen, the position of the opening 27 is selected such that it is only opposite the vacuum channel 24 and consequently the hollow channel 26 can be subjected to negative pressure when the support element 13 is shown in the extended end position as shown in FIG. 1. In this position, the hollow channel 26 is thus coupled to the vacuum channel 20 and thus to the external vacuum source. As soon as the position element 13 is retracted downwards, the opening 27 moves away from the vacuum channel 24 downwards, the outer wall of the support element 13 then seals off from the vacuum channel 24 . This ensures that when the support element 13 is not in the extended end position, the vacuum or vacuum system formed by the preferably network-like vacuum channel 20 and the internal vacuum channel 24 is closed. Only when the support element 13 is extended and is actually required is it coupled to the vacuum channel 20 . In order to avoid that dust or dirt is deposited on the support element when retracted, a closure part that closes automatically when driving into the retracted end position, for. B. a slat closure can be provided, which closes on the top. The closing part opens again automatically when it is extended.

Bei dem Auflageelement 13, das mit seiner AuÃenseite Ã¼ber geeignete DichteleÂ­

mente 28 nochmals abgedichtet gefÃ¼hrt ist, handelt es sich um ein VerschleiÃeleÂ­

ment, das bei BeschÃ¤digung beispielsweise durch unsachgemÃ¤Ãe Handhabung

des Werkszeugs oder des aufzubringenden Gegenstands nach Entnehmen des

Vakuumansaugelements 6 aus dem Vorrichtungsgestell 2 dem GehÃ¤use 8 entÂ­

nommen werden kann und gegen ein neues, unbeschÃ¤digtes Auflageelement 13

ausgetauscht werden kann. Hierzu ist beispielsweise das GehÃ¤use 8 vom darunter

befindlichen Elektromotor, der in das unten offene GehÃ¤use beispielsweise

eingeschraubt ist, trennbar, so dass das Auflageelement nach unten herausgezoÂ­

gen werden kann. Daneben besteht natÃ¼rlich auch die MÃ¶glichkeit, allein das

Dichtelement 25 im Falle einer BeschÃ¤digung desselben vom Auflageelement 13

zu entfernen.When the support element 13 , which is guided with its outside via suitable Dichtele elements 28 again, it is a Wearele element, which in the case of damage, for example due to improper handling of the tool or the object to be applied after removing the vacuum suction element 6 from the device frame 2 Housing 8 can be removed and can be replaced with a new, undamaged support element 13 . For this purpose, for example, the housing 8 can be separated from the electric motor underneath, which is screwed into the housing which is open at the bottom, for example, so that the support element can be pulled out downwards. In addition, of course, there is also the possibility of removing the sealing element 25 from the support element 13 in the event of damage.

Durch das erfindungsgemÃ¤Ãe modulare und komponentenbasierte Stecksystem,

mittels dem ein Vakuumansaugelement 6 auf einfache Weise in ein VorrichtungsÂ­

gestell 2 eingesteckt werden kann, wobei es beim Einstecken gleichzeitig mit der

Steuerungseinrichtung kontaktiert wird, ist es mÃ¶glich, dass der Anlagenbediener

die Spanneinrichtung, die beispielsweise auf einem Maschinentisch einer FrÃ¤smaÂ­

schine angeordnet ist, problemlos gemÃ¤Ã den Erfordernissen des zu spannenden

WerkstÃ¼cks einzurichten und nur dort mit Vakuumansaugelementen zu bestÃ¼cken,

wo es auch tatsÃ¤chlich fÃ¼r das Spannen des WerkstÃ¼cks aufgrund dessen Form

erforderlich ist. DarÃ¼ber hinaus ist es durch die bewegliche Lagerung des AuflageÂ­

elements mÃ¶glich, das zu bearbeitende WerkstÃ¼ck gegenÃ¼ber der FlÃ¤che der obeÂ­

ren Platte 4 anzuheben, so dass vermieden wird, dass diese beim Bearbeiten des

Gegenstands in irgendeiner Form durch das Werkzeug beschÃ¤digt wird. SchlieÃÂ­

lich bietet die individuelle Ansteuerung jedes Elektromotors bei einer Vielzahl von

in das Vorrichtungsgestell 2 eingesetzten Vakuumansaugelementen 6 die MÃ¶gÂ­

lichkeit, nur gewÃ¼nschte Auflageelemente 13 auszufahren, die dann den GegensÂ­

tand spannen.The modular and component-based plug-in system according to the invention, by means of which a vacuum suction element 6 can be plugged into a device frame 2 in a simple manner, while being plugged into the control device at the same time, it is possible for the system operator to have the clamping device, for example on a Machine table a milling machine is arranged to set up easily according to the requirements of the workpiece to be clamped and only to be equipped with vacuum suction elements where it is actually necessary for clamping the workpiece due to its shape. In addition, the movable mounting of the support element makes it possible to raise the workpiece to be machined relative to the surface of the top plate 4 , so that it is avoided that the tool is damaged in any way when the object is machined. Closing Lich the individual control of each electric motor has in a variety of apparatus used in the frame 2 Vakuumansaugelementen 6 MÃ¶g friendliness, extend only desired support elements 13, which then tand the Gegens tension.

Fig. 2 zeigt eine weitere AusfÃ¼hrungsform einer erfindungsgemÃ¤Ãen SpanneinÂ­

richtung 29, bei welcher ebenfalls ein Vorrichtungsgestell 30 vorgesehen ist, in

dem eine Vielzahl von Vakuumansaugelementen 31 vorgesehen sind. Jedes VaÂ­

kuumansaugelement 31 ist in der beschriebenen Weise einsteckbar bzw. durch

Einstecken kontaktierbar. In der gezeigten AusfÃ¼hrungsform sind die VakuumanÂ­

saugelemente 31 sehr eng aneinander stehend angeordnet, so dass, siehe Fig. 3,

die Dichtelemente 32, die hier im Wesentlichen viereckig ausgebildet sind, direkt

aneinander liegen. In der in Fig. 3 gezeigten Aufsicht sind auch die Filterelemente

33, die den Hohlkanal 26 nach oben hin abschlieÃen, erkennbar.

Fig. 2 shows a further embodiment of a Spannein device 29 according to the invention, in which a device frame 30 is also provided, in which a plurality of vacuum suction elements 31 are provided. Each Va kaugansaugelement 31 can be inserted or contacted by inserting in the manner described. In the embodiment shown, the vacuum suction elements 31 are arranged very close to one another, so that, see FIG. 3, the sealing elements 32 , which here are essentially square, lie directly against one another. The filter elements 33 , which close off the hollow channel 26 at the top, can also be seen in the plan view shown in FIG. 3.

In den Fig. 2 und 3 ist lediglich eine einreihige Spannvorrichtung 29 gezeigt.

NatÃ¼rlich ist die Reihe beliebig verlÃ¤nger- bzw. verbreiterbar, so dass sich eine in

x- und y-Richtung erstreckende Spannvorrichtung ergibt. NatÃ¼rlich besteht auch

die MÃ¶glichkeit, die Vakuumansaugelemente weiter voneinander zu beabstanden,

dies hÃ¤ngt einzig und allein von der Lage der aufnahmeplattenseitigen KontaktieÂ­

rungspositionen zur Verbindung des jeweiligen Elektromotors mit der SteuerungsÂ­

einrichtung ab.In FIGS. 2 and 3, only a single-row clamping device 29 is shown. Of course, the row can be extended or widened as desired, so that there is a clamping device extending in the x and y directions. Of course, there is also the possibility of spacing the vacuum suction elements further apart, this depends solely on the position of the mounting plate-side contact positions for connecting the respective electric motor to the control device.

Fig. 4 zeigt nun eine Prinzipdarstellung einer weiteren Spanneinrichtung 34. Diese

besteht lediglich aus einer Auflageplatte 35, auf die ein Vakuumansaugelement 36

aufgesetzt werden kann. An der Auflageplatte 35, die in Fig. 4 im Schnitt gezeigt

ist, und deren Grundstruktur Fig. 5 zu entnehmen ist, ist zum einen ein Vakuum-

oder Unterdruckkanal 36 vorgesehen, Ã¼ber welchen Unterdruck an das VakuumÂ­

ansaugelement 36 gefÃ¼hrt wird. Weiterhin sind zwei Leiterbahnen 37 vorgesehen,

Ã¼ber die das Vakuumansaugelement 36 mit der zentralen Steuerungseinrichtung

kontaktiert werden kann. Ãber diese Leiterbahnen kÃ¶nnen die jeweiligen SteuerÂ­

signale gegeben werden. Die Aufnahmeplatte 35 ist zweiteilig ausgebildet, um die

KanÃ¤le zu bilden. , FIG. 4 shows a schematic diagram of a further clamping device 34. This consists only of a support plate 35 on which a vacuum suction element 36 can be placed. To the platen 35 shown in Fig. 4 in cross-section, and is shown in 5 the basic structure of Fig., On the one hand a vacuum or negative pressure passage 36 is provided through which negative pressure to the vacuum suction part 36 is guided. Furthermore, two conductor tracks 37 are provided, via which the vacuum suction element 36 can be contacted with the central control device. The respective control signals can be given via these conductor tracks. The receiving plate 35 is formed in two parts to form the channels.

Ferner sind zwei weitere VersorgungskanÃ¤le 38 vorgesehen, Ã¼ber die ein BeÂ­

triebsmittel, hier Pressluft, an das Vakuumansaugelement 36 gefÃ¼hrt werden

kann. Im gezeigten AusfÃ¼hrungsbeispiel besitzt das Vakuumansaugelement 36 ein

zum Ein- und Ausfahren des Auflageelements 39 dienendes Bewegungsmittel,

welches mit Pressluft arbeitet. SÃ¤mtliche KanÃ¤le bzw. Leiterbahnen 36, 37 und 38

werden automatisch beim Aufsetzen des Vakuumansaugelements 36 kontaktiert,

worauf nachfolgend noch eingegangen wird.Furthermore, two further supply channels 38 are provided, via which an operating medium, here compressed air, can be guided to the vacuum suction element 36 . In the exemplary embodiment shown, the vacuum suction element 36 has a movement means which serves to retract and extend the support element 39 and which works with compressed air. All channels or conductor tracks 36 , 37 and 38 are automatically contacted when the vacuum suction element 36 is placed in place , which will be discussed below.

Das Vakuumansaugelement 36 besteht auch hier aus einem GehÃ¤use 40, in bzw.

an dem das Auflageelement 39 nach oben und unten beweglich aufgenommen ist.

In Fig. 4 ist es in der ausgefahrenen Endstellung gezeigt. Zum Bewegen ist hier

ein pneumatisches Bewegungsmittel unter Verwendung eines doppelseitig wirÂ­

kenden Pneumatikzylinders 41 vorgesehen. Das Auflageelement 39 ist an einem

Kolben 42, der hier als Scheibe ausgebildet ist, befestigt, der mit seiner Randwandung

dicht an der Zylinderwandung gefÃ¼hrt ist. Im Zylinderinneren mÃ¼nden zwei

PressluftkanÃ¤le 43, 44, wobei der Kanal 43 unterhalb des Kolbens 42 und der KaÂ­

nal 44 oberhalb des Kolbens 42 mÃ¼ndet. Wird Ã¼ber den Kanal 43 Pressluft eingeÂ­

drÃ¼ckt, so wird der Kolben 42 und mit ihm das Auflageelement 39 nach oben ausÂ­

gefahren. Wird Ã¼ber den Kanal 44 Pressluft eingedrÃ¼ckt, so wird der Kolben 42

und das Auflageelement 39 nach unten gedrÃ¼ckt. In diesem Fall wird der ZylinderÂ­

raum 41 entsprechend entlÃ¼ftet. Zur Steuerung des Zylinderbetriebs bzw. der

Pressluft ist ein 2/4-Wegeventil 45 vorgesehen, welche Ã¼ber eine elektrische MagÂ­

netspule 46 gesteuert wird. Die Magnetspule 46 wiederum ist Ã¼ber geeignete LeiÂ­

tungen 47 und entsprechende steckerartige Verbindungsmittel 48, die bodenseitig

am Vakuumelement 36 austreten, mit entsprechenden buchsenartigen GegenstÃ¼Â­

cken 49 und Ã¼ber diese mit den Leiterbahnen 37 kontaktiert. Hierdurch ist es mÃ¶gÂ­

lich, Ã¼ber die externe Steuerungseinrichtung den Ventilbetrieb und damit die jeÂ­

weilige Stellung des Auflageelements 39 steuern zu kÃ¶nnen.Here too, the vacuum suction element 36 consists of a housing 40 , in or on which the support element 39 is accommodated so that it can move up and down. In Fig. 4 there is shown in the extended end position. To move a pneumatic movement means is provided here using a double-acting pneumatic cylinder 41 . The support element 39 is fastened to a piston 42 , which is designed here as a disk, which is guided with its edge wall close to the cylinder wall. Inside the cylinder open two compressed air channels 43, 44, said channel 43 opens out under the piston 42 and the chan nel 44 above the piston 42nd If compressed air is pressed in via the channel 43 , the piston 42 and with it the support element 39 are moved upwards. If compressed air is pressed in via the channel 44 , the piston 42 and the support element 39 are pressed downward. In this case, the cylinder chamber 41 is vented accordingly. To control the cylinder operation or the compressed air, a 2/4-way valve 45 is provided, which is controlled via an electric magnetic coil 46 . The magnetic coil 46 is in turn via suitable lines 47 and corresponding plug-like connecting means 48 , which emerge from the bottom on the vacuum element 36 , with corresponding socket-like counterparts 49 and is contacted via these with the conductor tracks 37 . This makes it possible to be able to control the valve operation and thus the respective position of the support element 39 via the external control device.

Um nun das Vakuumansaugelement 36 mit der erforderlichen Pressluft beaufÂ­

schlagen zu kÃ¶nnen sind am Vakuumansaugelement bodenseitig abstehende

pneumatische Verbindungsmittel 50 vorgesehen, die beim Aufsetzen auf die AufÂ­

lageplatte 36 mit entsprechenden dort vorgesehenen GegenstÃ¼cken, die wiederÂ­

um mit den PressluftkanÃ¤len 38 verbunden sind, koppeln. Einer der PressluftkaÂ­

nÃ¤le 38 dient als Vorlauf, der andere als RÃ¼cklauf. Es ist hierdurch sichergestellt,

dass also auch die Pressluftversorgung automatisch beim Aufstecken angeÂ­

schlossen wird.In order to be able to strike the vacuum suction element 36 with the required compressed air, pneumatic connection means 50 projecting from the bottom are provided on the vacuum suction element, which, when placed on the support plate 36 , couple with corresponding counterparts provided there, which are again connected to the compressed air channels 38 . One of the compressed air channels 38 serves as a flow, the other as a return. This ensures that the compressed air supply is automatically connected when plugged in.

In entsprechender Weise wird auch der Vakuumkanal 36 mit einem Vakuumkanal

51 am Vakuumansaugelement 36 verbunden. Der Vakuumkanal 36 mÃ¼ndet am

Boden des GehÃ¤uses 40, wo entsprechende Verbindungsmittel 52 vorgesehen

sind, die auch hier in entsprechende GegenstÃ¼cke 53 an der Auflageplatte 35 einÂ­

greifen, welche wiederum mit dem Vakuumkanal 36 verbunden sind.In a corresponding manner, the vacuum duct 36 is connected to a vacuum channel 51 on Vakuumansaugelement 36th The vacuum channel 36 opens at the bottom of the housing 40 , where corresponding connecting means 52 are provided which also engage in corresponding counterparts 53 on the support plate 35 , which in turn are connected to the vacuum channel 36 .

Gezeigt sind ferner die Unterdruckquelle 63, die mit dem Vakuumkanal 62 verÂ­

bunden ist, die Steuerungseinrichtung 64, die mit den Leiterbahnen 37 verbunden

ist, und die Pressluftquelle 65, die mit den PressluftkanÃ¤len 38 verbunden ist.

Also shown are the vacuum source 63 , which is connected to the vacuum channel 62 , the control device 64 , which is connected to the conductor tracks 37 , and the compressed air source 65 , which is connected to the compressed air channels 38 .

Der Vakuumkanal 51 verlÃ¤uft zum oberen Ende des GehÃ¤uses 40 und mÃ¼ndet an

der Innenseite der Aufnahme 54, in welcher das Auflageelement 39 Ã¼ber entspreÂ­

chende Dichtmittel 55 gefÃ¼hrt ist. Am auch hier aus Vollmaterial bestehenden

Auflageelement 39, an dessen Oberseite ebenfalls ein Dichtelement 56 vorgeseÂ­

hen ist, ist ein Hohlkanal 57 vorgesehen, der wiederum eine Ã¤uÃere Ãffnung 58

besitzt. Diese Ãffnung 58 ist derart angeordnet, dass sie in der Ausfahrendstellung

genau gegenÃ¼ber der Ãffnung 59 des Vakuumkanals 51 liegt. Auch hier ist also

sichergestellt, dass der Hohlkanal 57 nur dann mit Unterdruck beaufschlagt wird,

wenn das Auflageelement 39 ausgefahren ist und den Gegenstand aufnehmen

soll. Der Hohlkanal 57 mÃ¼ndet oberseitig (zweckmÃ¤Ãigerweise ist auch dort ein

Filterelement vorgesehen), so dass der Unterdruck an das Ã¼ber das Dichtmittel 56

abgedichtet aufgenommene WerkstÃ¼ck gegeben werden kann.The vacuum channel 51 runs to the upper end of the housing 40 and opens on the inside of the receptacle 54 , in which the support element 39 is guided over corresponding sealing means 55 . On here also made of solid material support element 39 , on the upper side of which a sealing element 56 is also hen, a hollow channel 57 is provided, which in turn has an outer opening 58 . This opening 58 is arranged such that it lies exactly opposite the opening 59 of the vacuum channel 51 in the extended end position . Here too, it is ensured that the hollow channel 57 is only subjected to negative pressure when the support element 39 is extended and is intended to receive the object. The hollow channel 57 opens on the upper side (a filter element is also expediently provided there), so that the negative pressure can be applied to the workpiece which is sealed by the sealing means 56 .

Dabei ist darauf hinzuweisen, dass anstelle des doppelseitig wirkenden Zylinders

41 auch ein einseitig wirkender Zylinder vorgesehen sein kann. In diesem Fall

wÃ¼rde im Zylinderinneren eine Spiralfeder vorgesehen sein, welche derart positioÂ­

niert ist, dass die Feder von oben auf den Kolben drÃ¼ckt und das Auflageelement

39 stets nach unten drÃ¼ckt. Wird also das Auflageelement 39 nicht benÃ¶tigt, so

bleibt es automatisch in der eingefahrenen Stellung, da es Ã¼ber die Feder nach

unten gedrÃ¼ckt wird. Nur dann, wenn es benÃ¶tigt wird, wird Ã¼ber eine entspreÂ­

chende Pressluftleitung von unten Pressluft gegen den Kolbenboden gedrÃ¼ckt,

was dazu fÃ¼hrt, dass diese nach oben fÃ¤hrt, die Feder wird hierbei komprimiert.

Zum Einfahren wiederum wird der Ãberdruck entlÃ¼ftet. Es sind bei dieser AusfÃ¼hÂ­

rungsform lediglich ein Pressluftkanal und ein 1/2-Wegeventil vorzusehen. Auch

eine umgekehrte Wirkungsweise mit unterseitig angeordneter Feder ist denkbar.It should be noted that instead of the double-acting cylinder 41 , a single-acting cylinder can also be provided. In this case, a spiral spring would be provided inside the cylinder, which is positioned such that the spring presses on the piston from above and always presses the support element 39 down. If the support element 39 is not required, it automatically remains in the retracted position since it is pressed down by the spring. Only when it is needed, compressed air is pressed against the piston crown from below via a corresponding compressed air line, which causes it to move upwards, compressing the spring. The excess pressure is vented to retract. In this embodiment, only a compressed air duct and a 1/2 way valve are to be provided. A reverse mode of action with a spring arranged on the underside is also conceivable.

Entsprechend ist die AusfÃ¼hrung, wenn anstelle eines pneumatischen Zylinders 41

ein hydraulischer Zylinder vorgesehen ist. In diesem Fall wird Ã¼ber die KanÃ¤le 38

eine HydraulikflÃ¼ssigkeit zugefÃ¼hrt.The design is corresponding if a hydraulic cylinder is provided instead of a pneumatic cylinder 41 . In this case, a hydraulic fluid is supplied via the channels 38 .

Auch in diesem Fall ist wenngleich nicht nÃ¤her dargestellt das Auflageelement 39

bevorzugt lÃ¶sbar am Kolben 42 befestigt, es bildet auch hier ein VerschleiÃelement,

das auf einfache Weise im Falle einer BeschÃ¤digung ausgetauscht werden

kann. Entsprechendes gilt fÃ¼r das Dichtelement 56.In this case too, the support element 39 is preferably detachably attached to the piston 42 , although it is not shown in detail. Here, too, it forms a wear element that can be easily replaced in the event of damage. The same applies to the sealing element 56 .

Bei dieser AusfÃ¼hrungsform kommt wie beschrieben keine obere Platte zum EinÂ­

satz, die zur seitlichen Fixierung des in Fig. 1 gezeigten Vakuumansaugelements

6 dient. Um hier fÃ¼r eine sichere Befestigung des Vakuumansaugelements 36 zu

sorgen sind entsprechende, nicht gezeigte Befestigungselemente vorgesehen,

beispielsweise in Form einer Rast- oder Schnappverbindung oder dergleichen,

welche zu einem GehÃ¤use 40 und der Aufnahmeplatte 35 wirkt.In this embodiment, as described, no upper plate is used, which serves to laterally fix the vacuum suction element 6 shown in FIG. 1. In order to ensure a secure fastening of the vacuum suction element 36 , corresponding fastening elements, not shown, are provided, for example in the form of a snap-in or snap connection or the like, which acts on a housing 40 and the receiving plate 35 .

FÃ¼r den Fall, dass eine Aufnahmeposition eines Vakuumansaugelements 36 nicht

besetzt wird, wird diese Position mittels eines Blindverschlusses 60 verschlossen,

an dem entsprechende Blindstecker 61 vorgesehen sind, die die elektrischen,

pneumatischen und vakuumkanalseitig vorgesehenen Gegenstecker eingreifen

und so abdichten. Die in die entsprechenden GegenstÃ¼cke 53 der LeiterverbinÂ­

dungen 37 eingreifenden Blindstecker 61 ist festzuhalten, dass diese seitens der

Steuerungseinrichtung als Blindstecker erkannt werden kÃ¶nnen, so dass die SteuÂ­

erungseinrichtung erkennen kann, dass diese Aufnahmeposition nicht besetzt ist.

Ersichtlich bietet auch die Spannvorrichtung 34 dem Benutzer die MÃ¶glichkeit, sie

beliebig mit Vakuumansaugelementen 36 zu bestÃ¼cken. Auch bei der in Fig. 4 geÂ­

zeigten AusfÃ¼hrungsform des Vakuumelements besteht die MÃ¶glichkeit, dieses

zwischen zwei Endstellungen zu verfahren.In the event that a receiving position of a vacuum suction element 36 is not occupied, this position is closed by means of a blind plug 60 , on which corresponding blind plugs 61 are provided, which engage the electrical, pneumatic and vacuum channel-side mating plugs and thus seal them. The blind plug 61 engaging in the corresponding counterparts 53 of the conductor connections 37 is to be noted that these can be recognized by the control device as a blind plug, so that the control device can recognize that this receiving position is not occupied. Obviously, the clamping device 34 also offers the user the possibility of equipping them with vacuum suction elements 36 as desired. In the embodiment of the vacuum element shown in FIG. 4 there is also the possibility of moving it between two end positions.

Nicht nÃ¤her gezeigt sind an dem Vorrichtungsgestell gleich welcher AusfÃ¼hrungsÂ­

form vorgesehene Verbindungsmittel, mittels denen der Vakuumkanal, die LeiterÂ­

verbindungen und im Falle der AusfÃ¼hrungsform gemÃ¤Ã Fig. 4 die PressluftkanÃ¤le

eines Vorrichtungsgestells mit denen eines daneben positionierten VorrichtungsÂ­

gestells verbunden werden kÃ¶nnen. Dies kann Ã¼ber SchlÃ¤uche bzw. Leitungen

erfolgen, die an die entsprechenden Verbindungsmittel (geeignete Stecker und

dergleichen) angeschlossen werden. Alternativ ist es mÃ¶glich, dass zwei VorrichÂ­

tungsgestelle nebeneinander geschoben werden kÃ¶nnen und einander berÃ¼hren,

wodurch die jeweiligen Stecker miteinander kontaktiert werden. Dies ermÃ¶glicht

es, die entsprechenden Signale bzw. Medien "durchzuschleifen".

Not shown in more detail on the device frame, no matter what embodiment, provided connecting means by means of which the vacuum channel, the conductor connections and, in the case of the embodiment according to FIG. 4, the compressed air channels of a device frame can be connected to those of a device frame positioned next to it. This can be done via hoses or lines that are connected to the corresponding connection means (suitable plugs and the like). Alternatively, it is possible that two device racks can be pushed next to each other and touch each other, whereby the respective connector is contacted. This makes it possible to "loop through" the corresponding signals or media.

AbschlieÃend ist darauf hinzuweisen, dass auch die Spanneinrichtung 34 in belieÂ­

biger GrÃ¶Ãe als x- oder x-y-Vorrichtung ausgebildet sein kann. Ferner ist die AnÂ­

bringung von Gegensteckern an der Auflageplatte insbesondere bei der pneumatiÂ­

schen AusfÃ¼hrungsform nicht unbedingt nÃ¶tig. Denn wenn das VakuumansaugÂ­

element aufgesetzt ist, sind die dann als offene Durchbrechungen ausgefÃ¼hrten

AnschlÃ¼sse zum Vakuumkanal und den PressluftkanÃ¤len kontaktiert und abgeÂ­

dichtet. Ist kein Vakuumansaugelement eingesetzt werden die Ãffnungen mit dem

Blindverschluss 60 abgedichtet. Das System ist insgesamt dicht.In conclusion, it should be pointed out that the clamping device 34 can be designed in any size as an x or xy device. Furthermore, the attachment of mating connectors to the support plate is not absolutely necessary, in particular in the case of the pneumatic embodiment. Because when the vacuum suction element is attached, the connections to the vacuum channel and the compressed air channels, which are then designed as open openings, are contacted and sealed. If no vacuum suction element is used, the openings are sealed with the blind plug 60 . The system is tight overall.

Weiterhin ist festzuhalten, dass die erfindungsgemÃ¤Ãen Vorrichtungen auch im

Rahmen von Transportvorrichtungen, die an geeigneten Bewegungseinrichtungen

wie einem Portalkran oder dergleichen angeordnet sind, verwendbar sind.It should also be noted that the devices according to the invention also in the

Framework of transport devices that are attached to suitable movement devices

such as a gantry crane or the like can be used.

SchlieÃlich ist festzustellen, dass als Vorrichtungsgestell oder -gehÃ¤use jedwede

Halterung bzw. Aufnahme zu verstehen ist, in oder an der ein oder mehrere VakuÂ­

umansaugelemente befestigt sind oder werden kÃ¶nnen, beispielsweise eine

mehrteilige Halterung mit ober- und unterseitiger Platte (wie z. B. in Fig. 1 gezeigt)

oder allgemein eine Aufnahmeplatte, auf der die Vakuumansaugelemente aufgeÂ­

setzt werden, oder in der EinsteckÃ¶ffnungen vorgesehen sind, in die die VakuumÂ­

ansaugelemente eingesteckt und dabei ggf. kontaktiert werden. Ferner kÃ¶nnen an

dem Vorrichtungsgestell anstelle der Vakuumansaugelemente auch andere ArÂ­

beitsmittel, z. B. AnschlÃ¤ge oder StÃ¼tzen oder dergleichen befestigt oder eingeÂ­

steckt werden, die ggf. auch entsprechend zu Betriebszwecken kontaktiert werÂ­

den. Insgesamt ist hier ein modulares, komponentenbasiertes Spannsystem anÂ­

gegeben, das aus verschiedenen Einzelkomponenten besteht und ein einfaches

RÃ¼sten und Arbeiten ermÃ¶glicht.Finally, it should be noted that the device frame or housing is to be understood to mean any holder or receptacle in or on which one or more vacuum suction elements are or can be fastened, for example a multi-part holder with a top and bottom plate (such as shown in Fig. 1) or generally a mounting plate on which the vacuum suction elements are set, or are provided in the insertion openings into which the vacuum suction elements are inserted and, if necessary, contacted. Furthermore, other Ar beitsmittel on the device frame instead of the vacuum suction elements, for. B. stops or supports or the like are attached or inserted, which may also be contacted accordingly for operational purposes who the. Overall, a modular, component-based clamping system is specified here, which consists of various individual components and enables easy set-up and work.

## Classifications

- B25B11/005
- B23Q1/03
- B23Q1/032
- B25B11/00
- B25B11/007

## Cited patent documents

- [US-5163793-A](https://patents.google.com/patent/US5163793A/en) — SEA
- [WO-9961206-A1](https://patents.google.com/patent/WO9961206A1/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
