# 10. A pick-up device, for example, for the automatic packaging of products

- **Archive rank:** 10 of 50
- **Publication:** [EP-0989080-A1](https://patents.google.com/patent/EP0989080A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/008236796/publication/EP0989080A1?q=pn%3DEP0989080A1)
- **Publication date:** 2000-03-29
- **Filing date:** 1998-09-23
- **Earliest priority:** 1998-09-23
- **Family:** 8236796
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery

## Parties

- **Applicant / assignee:** FERRERO OHG; FERRERO SPA; SOREMARTEC SA
- **Inventors:** TARDITI MASSIMO

## Abstract

The device (10) includes a gripping head (14) on which a
plurality of gripping elements (24) are mounted for acting
on respective articles (P). The gripping elements (24) are
arranged in at least two groups associated with respective
support structures (29, 30, 34) which can perform a relative
movement in a direction generally perpendicular to the
common plane in which the gripping elements (24) pick up the
articles (P). By bringing about the relative movement
selectively, it is possible to arrange for the articles (P)
picked up in a common starting array to be deposited
arranged on several levels or planes. This capability can
be utilized, for example, in order to place food products
such as confectionery products in respective packages having
a pyramid-like or bell-like shape. The movement for the
arrangement in several planes may be combined with a
movement for changing the relative spatial arrangement of
the gripping elements (24) included in at least one of the
groups.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/4f/c2/15/4fdf35bd8159e4/00210001.png)

![Sketch 1 for EP-0989080-A1](https://patentimages.storage.googleapis.com/4f/c2/15/4fdf35bd8159e4/00210001.png)

[Sketch 2](https://patentimages.storage.googleapis.com/1e/58/dd/28ad9c923c71da/00220001.png)

![Sketch 2 for EP-0989080-A1](https://patentimages.storage.googleapis.com/1e/58/dd/28ad9c923c71da/00220001.png)

[Sketch 3](https://patentimages.storage.googleapis.com/65/2a/1c/e32fd76aeace03/00230001.png)

![Sketch 3 for EP-0989080-A1](https://patentimages.storage.googleapis.com/65/2a/1c/e32fd76aeace03/00230001.png)

[Sketch 4](https://patentimages.storage.googleapis.com/08/47/c1/b2032b25f8d640/00240001.png)

![Sketch 4 for EP-0989080-A1](https://patentimages.storage.googleapis.com/08/47/c1/b2032b25f8d640/00240001.png)

## Claims

### Claim 1 (independent)

A gripping device including a plurality of gripping elements (24) which can be positioned selectively in at least one first position and at least one second position so as to enable articles (P) to be picked up in a first relative spatial arrangement and the same articles (P) to be deposited in a second relative spatial arrangement, characterized in that the gripping elements (24) are arranged in at least two groups with respective associated support structures (29, 30, 34) which can perform a relative movement between at least one first position, in which the gripping elements (24) are substantially coplanar with one another, and at least one second position in which the at least two groups including the gripping elements (24) are offset relative to one another in a direction generally perpendicular to the plane defined by the former coplanar condition.

### Claim 2

A device according to Claim 1, characterized in that drive means (19) are associated with the support structures (29, 30, 34) in order to bring about the relative movement, the drive means including at least one fluid actuator (38).

### Claim 3

A device according to Claim 1 or Claim 2, characterized in that the support structures (29, 30, 34) are of generally plate-like structure and are oriented in a common direction, and in that the relative movement is performed in a direction substantially perpendicular to the said common direction of extent.

### Claim 4

A device according to any one of the preceding claims, characterized in that it includes a first support structure (29) and a second support structure (30) for respective groups of gripping elements (24), as well as drive means (19) acting in the direction of the relative movement, the drive means being coupled to the first support structure (29) and to the second support structure (30) in a direct-drive relationship for the first support structure (29), and in a drive relationship which permits a free relative sliding travel until a relative engagement condition (19a) is reached for the second support structure, the extent of the travel defining the extent of the relative offset of the first support structure (29) and the second support structure (30) in the second position.

### Claim 5

A device according to Claim 4, characterized in that the relative engagement condition is defined by the abutment of an enlarged head portion (19a) of the drive means against the second support structure (30, 30a).

### Claim 6

A device according to any one of the preceding claims, characterized in that it includes at least one group (34) of gripping elements (24) which remains in a substantially fixed position with respect to the direction of the relative movement.

### Claim 7

A device according to any one of the preceding claims, characterized in that the at least two support structures (29, 30, 34) have a generally concentric arrangement.

### Claim 8

A device according to any one of the preceding claims, characterized in that the gripping elements (24) on at least one (30, 34) of the support structures are mounted with a capability for relative movement, so that the relative translational movement of the support structures (29, 30, 34) can be combined with a relative movement of the gripping elements (24) within the respective support structure (30, 34).

### Claim 9

A device according to Claim 1, characterized in that at least one (30) of the support structures has associated actuator means (31) which can be operated selectively in order to move at least one of the gripping elements (24) mounted on the respective support structure (30) between - at least one first respective position which is adopted when the support structures (29, 30, 34) are in the first, substantially coplanar position, and - at least one second respective position which is adopted when the support structures (29, 30, 34) are in the at least one second, offset position.

### Claim 10

A device according to Claim 9, characterized in that the actuator means include at least one plate (30a) having slots (31) the walls of which perform a cam function.

### Claim 11

A device according to Claim 9, characterized in that at least one of the support structures (34) is composed of at least two portions each carrying at least one respective gripping element (24), drive means (35 to 38) being interposed between the at least two portions in order to bring about a relative movement of the at least two portions towards and away from one another in the plane defined by the first coplanar condition.

### Claim 12

A device according to Claim 6 and Claim 11, characterized in that the support structure (34) including the at least two carrying portions carries the at least one group of gripping elements (24) which remain in a substantially fixed position with respect to the direction of relative movement.

### Claim 13

A device according to any one of Claims 9 to 12, characterized in that: - in the at least one first respective position, the gripping elements (24) associated with the support structure (29, 30, 34) are arranged in a matrix-like array, arranged in rows and columns, and - in the at least one second respective position, the gripping elements (24) associated with the support structure (29, 30, 34) are disposed in respective patterns substantially surrounding one another.

### Claim 14

A device according to any one of the preceding claims, characterized in that the gripping elements (24) are gripping elements operating by suction (26).

## Full description

**[0001]**

The present invention relates to a gripping device according to the preamble to Claim 1.

**[0002]**

Gripping devices of this type are known, for example, from US-A-4 832 180 or from EP-A-0 768 254.

**[0003]**

Both of these prior documents describe gripping devices which can be used for handling food products such as, for example, pralines. The devices in question comprise a plurality of grippers (usually vacuum grippers) supported on the structure of the device so as to be movable in manner such that, having picked up the products in a first geometrical configuration, the device can deposit them after bringing them to a second geometrical arrangement different from the first.

**[0004]**

The object of the present invention is to develop further the characteristics of flexibility shown by the solutions described in the above-mentioned prior documents. This development relates in particular to the ability to pick the products up in a flat geometrical configuration in order then to transfer them into a package with several levels, distributing the products at the various levels of the final configuration during transfer.

**[0005]**

According to the present invention, this object is achieved by means of a device having the specific characteristics recited in the following claims.

**[0006]**

The invention will now be described, purely by way of non-limiting example, with reference to the appended drawings, in which:

### Figure 1 is a general perspective view of a device according to the invention,

**[0007]**

Figures 2 and 3 show the arrangement of the products handled by the device of Figure 1, before and after handling, respectively,

**[0008]**

Figure 4 is a view taken on the arrow IV of Figure 1 to give a better illustration of the structure of a portion of the device according to the invention,

**[0009]**

Figure 5 is a side elevational view of the portion of the device of Figure 4 with various elements removed for clarity of illustration,

### Figure 6 is a section taken on the line VI-VI of Figure 5, and

**[0010]**

Figures 7 and 8 show schematically a first and a second position reached in operation by one of the movable members included in the portion of the device shown in Figures 4 to 6.

**[0007]**

In the appended drawings, a device for manipulating articles automatically (a so-called manipulation robot) for use, for example, in a plant for the automatic packaging of food products, is generally indicated 10. Clearly, however, the fields of application of the invention are varied and, in any case, are not limited to the specific area which will be referred to below for clarity and simplicity of description.

**[0008]**

In the use described by way of example, the device 10 is intended to operate between an input conveyor line, indicated A, (for input relative to the device) and an output conveyor line, indicated B (again, relative to the device 10).

**[0009]**

The line A is shown in the drawings in the form of a conveyor line on which a series of moulds M (Figure 2) advances, the moulds having cells H, for example, hemispherical cells, facing upwards and defining an orderly array (for example, with a rectangular grid). In these cells H there are corresponding articles or products P constituted, for example, by spherical pralines bare or, preferably, already contained in corresponding foil wrappers, possibly provided with small cases, etc. (in this connection, see Figure 3 to which explicit reference will be made below).

**[0010]**

Conveyor lines such as those indicated A and B are widely known in the art. The products P may be constituted, for example, by pralines such as those sold by companies of the Ferrero Group under the trade names of Ferrero Rocher, Confetteria Raffaello, Tonus, Giotto, etc.

**[0011]**

In any case, neither the specific geometry of the initial array of products P on the input line A nor the specific characteristics of the products are relevant or essential for the purposes of an understanding or of the implementation of the invention.

**[0012]**

The output line B, on the other hand, is a line on which - in the embodiment shown (which, it is stressed once more, is an example and is not limiting of the invention) - the lower portions or bases C of packages advance, these packages being generally pyramid-shaped in the embodiment shown. The packages in question are usually intended to be closed at the top by a transparent covering also having the shape of a pyramid. In particular, it can be seen from Figure 3 that the bases C also have a generally stepped pyramid or mastaba-like shape having three respective tiers or levels of cells for housing the products P.

**[0013]**

In the embodiment illustrated, the three levels of the base C have cells for housing twelve, eight and four products P, respectively, and hence for an overall total of twenty-four products. This set is usually intended to be completed by a twenty-fifth product located on the tip of the pyramid-shaped formation by known means (not shown).

**[0014]**

The function of the device 10 is basically to pick up the products P from the moulds M of the input line A in which the products are arranged in a matrix-like array (for example, an array with a square, rectangular, or possibly rhomboidal grid, etc.) in order to arrange them, during the transfer movement towards the output line B, in three respective groups each to be inserted in the cells provided on one of the levels of the base C of the package. For example, with reference to the possible configuration mentioned above - the device 10 picks up, from the line A, at least one set of twenty-four products P at a time in order then to arrange them in three groups offset in three different planes and comprising twelve, eight and four products, respectively, the groups being intended to constitute the various levels of the package formed on the output line B.

**[0015]**

The appended drawings relate to a solution of use in which the lines A and B extend side by side (with the same or opposite directions of advance), at least in the region in which the device 10 acts; however, this particular arrangement is purely an example and is certainly not essential for the purposes of the implementation of the invention.

**[0016]**

This also applies to the general configuration of the device 10, which is shown in the form of a robot arm comprising basically, an upright or proximal portion 11 supported by a respective base 12 in an approximately vertical position with the ability to pivot to and fro about a respective horizontal swivel axis located at the lower end of the upright. The upright 11 carries, articulated to its upper end, a transverse or distal portion 13 which projects in a generally bracket-like configuration above the lines A, B, and in turn supports, at its distal end, a gripping head 14 (or actual gripping device) for acting on the products P.

**[0017]**

The robot structure just described has associated drive and control means K (also of known type and therefore not requiring detailed description herein) which impart to the head 14 a cyclic movement comprising the following stages:

**[0022]**

positioning of the gripping head 14 above the input line A and lowering of the gripping elements associated therewith (these elements will be described further below) in order to pick up the products P which are disposed in the moulds M in a planar array;

**[0023]**

lifting of the gripping head 14, consequently picking up the articles P from the line A,

### translation of the head 14 to a position above the output line B,

**[0024]**

lowering and subsequent deposition of the various groups of products P (arranged on several levels, as will be described further below) in the corresponding housing cells provided in the bases C which are disposed on the line B, and

**[0025]**

release of the head 14 from the products P thus deposited and subsequent return to the starting position above the input line A.

**[0018]**

Specific characteristics of the above-mentioned parts and the details relating to the performance of the individual operations described will be explained more fully below.

**[0019]**

It is clear from the general description of the operating cycle of the device 10 that the structure described (the upright 11, the cross-member 13 and the head 14) constitutes only an example of the many possible embodiments of a robot structure of the type described above.

**[0020]**

To cite a possible alternative example, the head 14 could be mounted on the distal end of an arm mounted in a generally flag-like arrangement on an upright located, for example, in a possible meeting or crossing region of the lines A and B (in different planes) so as to be able to move the head 14 to the various positions of the movement described above. The production of such a robot structure constitutes a current solution in the field of robotics techniques and a detailed description of the respective solutions can therefore be considered wholly superfluous and, moreover, is irrelevant per se for the purposes of an understanding of the description of the invention. The articulated arm structure 11, 13 referred to up to now, may thus be replaced by any equivalent handling structure.

**[0021]**

In the embodiment described, the head structure 14 comprises a protective casing 18 having a generally channel or hood-like shape opening downwardly and supported on its generally arcuate outer side (facing upwards) by the arm 13 of the robot structure.

**[0022]**

Inside the casing 18 there is a handling structure comprising two substantially identical elements which are symmetrical with respect to an imaginary median plane of the casing 18. A fluid actuator such as a jack 19, disposed in the said imaginary median plane, acts on the two above-mentioned symmetrical elements simultaneously.

**[0023]**

The symmetrical structure in question enables the head 14 to act simultaneously on two sets of products P. With reference to the numerical values given above (it will remembered, purely by way of example), the head 14 can thus act simultaneously on two sets each of twenty-four products and hence on forty-eight products P to be picked up from the input line A in order to be transferred, arranged in several planes, towards two pyramid-shaped packages C advancing in sequence on the output line B.

**[0024]**

The embodiment illustrated in the drawings relates implicitly to a method of operation in which the lines A and B are stopped momentarily when they are affected by the action of the head 14. In practice, when the head 14 picks up the products P the line A is stationary whilst the line B is advancing two new packages C for receiving the products picked up and, whilst the head 14, having moved to the line B, loads thereon the products P previously picked up, the line B is momentarily stopped. At the same time, the line A advances so as to bring a new set of products P to be picked up to the position for gripping by the head 14.

**[0025]**

Although this embodiment is currently preferred, it is in no way essential. In particular, it is possible to consider configuring the head 14 (and the robot structure which moves it) in a manner such that the head can "follow" the line A and/or the line B during the interaction for picking up or depositing the products P.

**[0026]**

It can also be seen from Figure 2 that, in one possible example of use of the device according to the invention, each mould M comprises four sets of twenty-four cells (and hence ninety-six cells in all) with the sets arranged in an imaginary 2 x 2 matrix. The two portions of the gripping head 14 can therefore act simultaneously on two sets disposed side by side; the return travel of the robot for returning the head 14 to a position above the line A consequently takes place alternately towards two different return positions aligned with one pair of sets of products present in each mould M and with the other.

**[0027]**

Upon this premise, explicit reference will be made in the following description to only one of the two portions of the gripping head 14. It should, however, be understood that the two portions in question are identical, the general symmetry remaining the same.

**[0028]**

In the embodiment illustrated, the head 14 preferably has gripping elements 24 constituted by elements of the type operating at subatmospheric pressure and each comprising, as an active gripping element, a suction-cup 26 of resiliently yielding material. This suction-cup has an axial cavity communicating, through a set of tubes 28, with a source of subatmospheric pressure (for example, a so-called vacuum pump, of known type) mounted, for example, in the base portion of the structure of the device 10.

**[0029]**

In accordance with known criteria (in this connection reference may also be made, for example, to the documents US-A-4 832 180 and EP-A-0 768 254 already cited in the introductory part of the present description) the gripping elements 24 can be brought into contact with the products P to be picked up, thus causing the products P to be held by the suction-cup portions as a result of the activation of the vacuum lines (tubes 28) communicating with the axial cavities of the suction-cup portions 26, so that the products follow the elements 24 during the transfer movement towards the output line B. On the output line B, deactivation of the vacuum lines causes the suction-cup portions 26 of the elements 24 to release the products P which are thus deposited and left in the desired positions on the bases C.

**[0030]**

The activation and de-activation of the gripping elements 24, their movement relative to the head 14 in the manner described further below, and the general movement of the gripping head 14 in accordance with the cycle already described above are brought about automatically in accordance with known criteria by the central processing unit K which supervises the operation of the device. This may, for example, be a programmable unit of the type currently known as a PLC (acronym for Programmable Logic Controller).

**[0031]**

To continue with the description of the gripping elements 24, it will be noted, with regard to the positions in which these elements are mounted on the body of the head 14, that, in each of the two portions of the head 14, they can be thought of as being arranged in three groups which can best be identified from an observation of the views of Figures 5 to 8 in combination.

**[0032]**

Proceeding in imagination from the centre towards the periphery of the array of products P picked up by the head 14 at any particular time, it is possible to recognize first of all a group of elements 24 comprising four elements 24 mounted at the vertices of an imaginary square on a plate 29.

**[0033]**

The plate 29, as well as the twin plate disposed on the other side of the head 14, are mounted so as to be rotatable about respective vertical axes on a support plate 29a having a shape generally approximately comparable to an 8 (or to a biscuit with enlarged ends). The plate 29a is connected, in a central position, to the rod of the actuator 19 in a manner such that, when the actuator is activated, withdrawing its rod upwardly, the support plate 29a is raised and the plates 29 as well as the gripping elements 24 mounted thereon are carried upwards therewith.

**[0034]**

The support plate 29a has openings for the passage of the rods of the elements 24, these rods projecting downwards from the plates 29. The openings extend along defined paths such that, when each plate 29 rotates about its own axis driven by a respective shaft 50 mounted on a plate 30, the rods of the elements 24 and the sides of the openings in the plates 29 and 29a cooperate like cams so that the elements in question, which were originally disposed at the vertices of a square, are arranged at the vertices of a square of larger dimensions, by moving along the path.

**[0035]**

A substantially similar mounting configuration is used for a second group of elements 24, disposed in positions relatively farther out than the elements 24 mounted on the plates 29.

**[0036]**

In the case of this second group of elements 24 a rotary plate 30 is provided (on each side of the head 14 in a generally symmetrical arrangement), supported by a support plate 30a which is also shaped like a figure 8 or a biscuit with enlarged ends, and is intended to cooperate, in a central position, with the rod of the actuator 19.

**[0037]**

However, whereas the support plate 29a (and the plates 29 with the respective elements 24) follow the vertical movements of the rod of the actuator 19 directly, the plate 30a is fitted on the rod in question in a manner such that the rod is free to slide vertically upwards until an enlarged head 19a provided at the lower end of the rod abuts the edge of the opening in which the rod of the actuator 19 extends through the plate 30a. At this point and only at this point, the plate 30a as well as the plates 30 with the respective elements 24 follow the actuator rod in its lifting movement.

**[0038]**

As can easily be understood this "delay" in the upward movement of the plate 30a relative to the plate 29a is intended - and is regulated in a manner such as - to arrange that when the rod of the actuator 19 has been withdrawn to the uppermost position provided for, the plates 29a and 30a and the respective groups of elements 24 are offset in height by the amount required in order to locate the respective products P on the two uppermost steps of the pyramid defined by each package C. Another difference which may be noticed between the first and second groups of elements 24 considered above is that the elements 24 associated with the plates 29 retain their geometrical arrangement at the vertices of a square even after the rotation of the plates 29.

**[0039]**

In contrast, as can best be appreciated from an observation of Figures 6, 7 and 8 in combination, the elements 24 associated with the plate 30 are connected to pairs of blocks 32 (vacuum distributors) clearly visible beneath the plate 30a; two pins are mounted on each block 32, on the opposite side to the elements 24, one pin being perforated and extended for the fitting of the tube 28 and communicating with a distributor chamber of the block 32. These pins extend through respective openings 31 provided in the plate 30a and through a corresponding number of openings formed in the plates 30, and intersecting the former ones. These openings extend along paths defined in a manner such that, when each plate 30 rotates, the rods of the elements 24 and the sides of the openings 31 cooperate like cams so that the elements in question, which were originally disposed at the vertices of an imaginary octagon surrounding the square array of elements 24 mounted on the overlying plate 29 (the arrangement shown in Figure 7) are disposed at the vertices and in intermediate positions on each side of an imaginary square which surrounds the square array of elements mounted on the plate 29 (the arrangement shown in Figure 8). In order to render this movement safer and more uniform, a treated steel blade is preferably disposed between the upper portion of the plate 30 and the pair of pins mounted on the block 32. Otherwise, the kinematic solution is substantially similar to that described in EP-A-0 768 254.

**[0040]**

In the gripping head under examination, the plates 30 are rotated by means of a linkage connected to an element 35 moved by the actuator 38, which will be referred to further below. Even though the linkage connects the kinematic mechanism and the rotary plates 29 and 30 to the movement of C-shaped plates 34, it allows the sets of plates 29-29a, 30-30a to move vertically completely freely.

**[0041]**

Finally, a third group of elements 24 comprises twelve elements 24 which are mounted on two plates 34 with movable parts (that is, capable of movement relative to one another in the manner described below) and which can thus be regarded as being divided into two sub-groups each comprising six elements 24 mounted on one plate 34 and on the other, respectively. The plates 34 are generally C-shaped with a movable end guided, by means of a pin, by a cam formed on a cross-member 51. The movement of the movable end articulated to the plate 34 enables the plate not to interfere with the elements 24 of the plates 30 and their blocks 32 during the horizontal translation; each movable end carries an element 24 and a rubber-tube connector as an attachment for a vacuum line 28. In the starting position corresponding to the position for picking up the products P on the line A (Figure 7), the respective twelve gripping elements 24 are disposed in a rectangular pattern the two longer sides of which include, as a central portion, one of the blocks 32 with which two gripping elements 24 of the second group are associated.

**[0042]**

In particular, it can be seen in Figure 5 that each C-shaped plate 34 is supported by an element 35 extending upwardly and comprising a pair of sleeves 36 mounted for sliding on respective cylindrical horizontal guides 37 disposed one above the other. The movement of the sleeves 36 on the guides 37 takes place under the action of a respective actuator 38 visible on the top left-hand side of Figure 5.

**[0043]**

An important characteristic of the solution according to the invention is that the gripping elements 24 included in the three groups described above can perform a relative translational movement in a direction generally perpendicular to the common plane in which the gripping elements 24 (and, in particular, their suction-cup-like gripping portions 26) lie when the products P are picked up from the line A.

**[0044]**

This capability for relative movement results from the following facts:

**[0053]**

the plates 29 on which the elements 24 in the most central positions are situated are connected directly to the rod of the actuator 19 - by the plate 29a - so that they can follow the vertical translational movement thereof;

**[0054]**

the plates 30, on which the elements 24 in positions relatively farther out are situated also follow the movement of the rod of the actuator 19 but only from the moment at which the enlarged head 19a engages the plate 30a, so as to be located in the desired position, offset in height relative to the plates 29, and

**[0055]**

the plates 34 and the elements 24 carried thereby perform no vertical translational movement so that, when the actuator 19 is withdrawn fully upwards, the respective elements 24 are offset (downwards) relative to the elements 24 carried by the plates 30 by an amount equal to the height of the lowest step of the pyramid of the package C.

**[0045]**

The set of elements indicated above is consequently generally movable between:

**[0057]**

a first position, which may be defined as the position for picking up the products P, in which all of the gripping elements 24 are substantially coplanar with one another or, in any case, are in a position such that the gripping portions 26 mounted thereon are kept in a coplanar condition so that the products P arranged in a flat array on the moulds M advancing on the line A can be picked up, and

**[0058]**

a second position, which can be defined as the position for depositing the products P, in which the aforesaid portions reach positions in which they are offset in height so that the gripping portions 26 of the respective gripping elements 24 are disposed in three orderly groups in positions corresponding to the three planes of the pyramid-like structure to be formed on the bases C located on the line B.

**[0046]**

In contrast with the solutions described in the prior documents cited in the introductory portion of the description, during the movement from the line A to the line B, the gripping elements 26 do not therefore retain the coplanar or substantially coplanar condition reached when the products P are picked up from the line A but, on the contrary, perform a so to speak "vertical" relative translational movement (relative to the plane of the starting array) which is intended to arrange them on several planes corresponding precisely to the various planes of the base C.

**[0047]**

Clearly, however, the solution according to the invention should not be understood as being limited to the possible application to the pyramid-like structure of the bases C shown in the appended drawings. The solution according to the invention may in fact be implemented, in general, in order to give rise to a three-dimensional array of products having the most varied characteristics, starting with a flat array. For example, the solution according to the invention may be used to fill a package in which the products P are disposed in a generally bell-shaped, spherical, or tree-shaped configuration.

**[0048]**

In the embodiment illustrated by way of example in the appended drawings, the vertical translational movement of the various groups of gripping elements 24 is in fact also combined, for at least some of the elements 24, with a change in the relative positions of the gripping elements included in a single starting group or array.

**[0049]**

Thus, in the embodiment illustrated (but in possible variants of the invention the solution could be different) the elements 24 mounted on the plates 29 and on the plates 30 change their relative arrangement at least partially during the transfer from the line A to the line B.

**[0050]**

As already stated, this result can be achieved by forming the support structure 32 in a manner substantially similar to that described in US-A-4 832 180 or EP-A-0 768 254.

**[0051]**

In any case, the specific methods of bringing about these movements may be considered known per se and can easily be inferred from the prior documents already mentioned above.

**[0052]**

With regard to the capability for relative movement of the two plates 34 on which the gripping elements 24 for gripping the products P of the outermost row of the array picked up from the line A are located, the relative movement takes place substantially in the direction of a relative movement towards one another of the two plate-like portions 34 which - as already stated - have a generally C-shaped configuration opening towards one another. This movement, which is brought about by the actuator 38 is intended, in the embodiment illustrated, to enable the respective group of products P which was originally picked up in an approximately rectangular pattern to be deposited in a square pattern.

**[0053]**

Clearly, the principle of the relative movement remaining the same, the solutions described may be exchanged and combined both with one another and with other solutions otherwise known to an expert in the art in order to achieve maximum versatility and flexibility in the combination of the vertical movement described above with the horizontal movement for re-arranging the elements 24 and hence the products P carried thereby within the respective configuration.

**[0054]**

The principle of the invention remaining the same, the details of construction and forms of embodiment may consequently be varied widely with respect to those described and illustrated, without thereby departing from the scope of the present invention as defined in the appended claims.

## Classifications

- B65B5/08
- B65B35/38
- B65B35/38
- B65B5/105
- B65G47/91
- B65G47/918

## Cited patent documents

- [EP-0239547-A1](https://patents.google.com/patent/EP0239547A1/en) — SEA
- [EP-0550114-A1](https://patents.google.com/patent/EP0550114A1/en) — SEA
- [EP-0657373-A2](https://patents.google.com/patent/EP0657373A2/en) — SEA
- [EP-0768254-A1](https://patents.google.com/patent/EP0768254A1/en) — APP,SEA
- [US-3168204-A](https://patents.google.com/patent/US3168204A/en) — SEA
- [US-4832180-A](https://patents.google.com/patent/US4832180A/en) — APP

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
