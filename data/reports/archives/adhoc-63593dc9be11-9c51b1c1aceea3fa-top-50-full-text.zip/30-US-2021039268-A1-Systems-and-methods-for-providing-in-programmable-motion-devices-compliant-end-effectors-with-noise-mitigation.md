# 30. Systems and methods for providing, in programmable motion devices, compliant end effectors with noise mitigation

- **Archive rank:** 30 of 50
- **Publication:** [US-2021039268-A1](https://patents.google.com/patent/US20210039268A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/072193582/publication/US20210039268A1?q=pn%3DUS20210039268A1)
- **Publication date:** 2021-02-11
- **Filing date:** 2020-08-05
- **Earliest priority:** 2019-08-08
- **Family:** 72193582
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus

## Parties

- **Applicant / assignee:** BERKSHIRE GREY INC
- **Inventors:** ANDERSON BRETTON

## Abstract

A vacuum cup is disclosed for use in a programmable motion device. The vacuum cup includes an open inlet for coupling to a vacuum source, and a vacuum cup lip on a portion of the vacuum cup that generally surrounds the open inlet. The vacuum cup lip includes an inner surface that defines the open outlet through which a vacuum may be provided, and includes noise mitigation features on an outer surface of the vacuum cup lip.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/ec/b8/77/cd50a701efcc0d/US20210039268A1-20210211-D00000.png)

![Sketch 1 for US-2021039268-A1](https://patentimages.storage.googleapis.com/ec/b8/77/cd50a701efcc0d/US20210039268A1-20210211-D00000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/06/39/49/a687735bf1da4a/US20210039268A1-20210211-D00001.png)

![Sketch 2 for US-2021039268-A1](https://patentimages.storage.googleapis.com/06/39/49/a687735bf1da4a/US20210039268A1-20210211-D00001.png)

[Sketch 3](https://patentimages.storage.googleapis.com/5d/39/78/cf960b4da9a8e8/US20210039268A1-20210211-D00002.png)

![Sketch 3 for US-2021039268-A1](https://patentimages.storage.googleapis.com/5d/39/78/cf960b4da9a8e8/US20210039268A1-20210211-D00002.png)

[Sketch 4](https://patentimages.storage.googleapis.com/31/47/de/18f2180130b2d3/US20210039268A1-20210211-D00003.png)

![Sketch 4 for US-2021039268-A1](https://patentimages.storage.googleapis.com/31/47/de/18f2180130b2d3/US20210039268A1-20210211-D00003.png)

[Sketch 5](https://patentimages.storage.googleapis.com/e2/b0/d7/73af149f520395/US20210039268A1-20210211-D00004.png)

![Sketch 5 for US-2021039268-A1](https://patentimages.storage.googleapis.com/e2/b0/d7/73af149f520395/US20210039268A1-20210211-D00004.png)

[Sketch 6](https://patentimages.storage.googleapis.com/a4/d3/f7/3926fb4369b383/US20210039268A1-20210211-D00005.png)

![Sketch 6 for US-2021039268-A1](https://patentimages.storage.googleapis.com/a4/d3/f7/3926fb4369b383/US20210039268A1-20210211-D00005.png)

[Sketch 7](https://patentimages.storage.googleapis.com/ea/6a/90/9ae4412edaf7ec/US20210039268A1-20210211-D00006.png)

![Sketch 7 for US-2021039268-A1](https://patentimages.storage.googleapis.com/ea/6a/90/9ae4412edaf7ec/US20210039268A1-20210211-D00006.png)

[Sketch 8](https://patentimages.storage.googleapis.com/72/10/a7/55f3f2d4c12676/US20210039268A1-20210211-D00007.png)

![Sketch 8 for US-2021039268-A1](https://patentimages.storage.googleapis.com/72/10/a7/55f3f2d4c12676/US20210039268A1-20210211-D00007.png)

[Sketch 9](https://patentimages.storage.googleapis.com/d0/5a/75/3777e97de46e87/US20210039268A1-20210211-D00008.png)

![Sketch 9 for US-2021039268-A1](https://patentimages.storage.googleapis.com/d0/5a/75/3777e97de46e87/US20210039268A1-20210211-D00008.png)

## Claims

### Claim 1 (independent)

A vacuum cup for use in a programmable motion device, said vacuum cup comprising an open inlet for coupling to a vacuum source, and a vacuum cup lip on a portion of the vacuum cup that generally surrounds the open inlet, said vacuum cup lip including an inner surface that defines the open outlet through which a vacuum may be provided, and including noise mitigation features on an outer surface of the vacuum cup lip.

### Claim 2

The vacuum cup as claimed in claim 1, wherein vacuum cup lip is formed of a flexible polymeric material.

### Claim 3

The vacuum cup as claimed in claim 1, wherein said noise mitigation features are formed of a polymeric material.

### Claim 4

The vacuum cup as claimed in claim 1, wherein vacuum cup lip is formed of a flexible polymeric material.

### Claim 5

The vacuum cup as claimed in claim 1, wherein said noise mitigation features encircle the vacuum cup lip in a discontinuous manner.

### Claim 6

The vacuum cup as claimed in claim 1, wherein said noise mitigation features include protrusions from the vacuum cup lip on the outer surface of the vacuum cup lip.

### Claim 7

The vacuum cup as claimed in claim 6, wherein said protrusions are positioned alternate internal ribs on an inner surface of the vacuum cup lip.

### Claim 8

The vacuum cup as claimed in claim 1, wherein said vacuum cup includes a flexible bellows portion.

### Claim 9

The vacuum cup as claimed in claim 1, wherein said vacuum cup is generally conically shaped.

### Claim 10 (independent)

A vacuum cup for use in a programmable motion device, said vacuum cup comprising an open inlet for coupling to a vacuum source, a vacuum cup lip on a portion of the vacuum cup that is generally opposite the open inlet, and a vacuum cup open outlet through which a vacuum may be provided, said vacuum cup including a plurality of protrusions on an outer surface of the vacuum cup lip.

### Claim 11

The vacuum cup as claimed in claim 10, wherein vacuum cup is formed of a flexible polymeric material.

### Claim 12

The vacuum cup as claimed in claim 10, wherein said plurality of protrusions are formed of a polymeric material.

### Claim 13

The vacuum cup as claimed in claim 10, wherein vacuum cup is formed of a flexible elastomeric material.

### Claim 14

The vacuum cup as claimed in claim 10, wherein said plurality of protrusions encircle the vacuum cup open outlet in a discontinuous manner.

### Claim 15

The vacuum cup as claimed in claim 10, wherein said plurality of protrusions include at least partially generally spherical protrusions.

### Claim 16

The vacuum cup as claimed in claim 15, wherein said plurality of protrusions are positioned alternate internal ribs on an inner surface of the vacuum cup lip.

### Claim 17

The vacuum cup as claimed in claim 10, wherein said vacuum cup includes a flexible bellows portion.

### Claim 18

The vacuum cup as claimed in claim 10, wherein said vacuum cup is generally conically shaped.

### Claim 19

The vacuum cup as claimed in claim 10, wherein the plurality of protrusions provide that the vacuum cup lip includes alternating areas of relatively thin and relatively thicker lip thicknesses.

### Claim 20 (independent)

A method of providing a vacuum source in a programmable motion device, said method comprising: coupling the vacuum source to open inlet of a vacuum cup, said vacuum cup including noise mitigation features on an outer surface of the vacuum cup; and providing a vacuum cup open outlet through which the vacuum may be provided.

### Claim 21

The method as claimed in claim 20, wherein said noise mitigation features are formed of a polymeric material.

### Claim 22

The method as claimed in claim 20, wherein said noise mitigation features are formed of an elastomeric material.

### Claim 23

The method as claimed in claim 20, wherein said noise mitigation features encircle the vacuum cup open outlet in a discontinuous manner.

### Claim 24

The method as claimed in claim 20, wherein said noise mitigation features include protrusions from the vacuum cup on the outer surface of the vacuum cup.

### Claim 25

The method as claimed in claim 24, wherein said protrusions are positioned alternate internal ribs on an inner surface of the vacuum cup.

### Claim 26

The method as claimed in claim 20, wherein said vacuum cup includes a flexible bellows portion.

### Claim 27

The method as claimed in claim 20, wherein said noise mitigation features alter a resonance of the open outlet of the vacuum cup.

### Claim 28

The method as claimed in claim 20, wherein the method further includes damping a resonance of a lip of the vacuum cup while the vacuum is provided through the open outlet.

### Claim 29

The method as claimed in claim 28, wherein the method further includes providing a vacuum pressure at the end effector of no more than about 50,000 Pascals below atmospheric

### Claim 30 (independent)

A system for providing automated processing of objects, said system comprising a programmable motion device including an end effector that is coupled to a vacuum source, said end effector including a vacuum cup that includes noise mitigation features on an outer surface of the vacuum cup.

### Claim 31

The system as claimed in claim 30, wherein said noise mitigation features encircle a vacuum cup lip in a discontinuous manner.

### Claim 32

The system as claimed in claim 30, wherein said noise mitigation features include protrusions from a vacuum cup lip on the outer surface of the vacuum cup.

### Claim 33

The system as claimed in claim 32, wherein said protrusions are positioned alternate internal ribs on an inner surface of the vacuum cup.

### Claim 34

The system as claimed in claim 30, wherein said vacuum cup includes a flexible bellows portion.

### Claim 35

The system as claimed in claim 30, wherein the vacuum source provides a maximum air flow rate at the end effector of at least about 100 cubic feet per minute.

### Claim 36

The system as claimed in claim 30, wherein the vacuum source provides a vacuum pressure at the end effector of no more than about 50,000 Pascals below atmospheric.

## Full description

### Priority

**[p0001]**

The present application claims priority to U.S. Provisional Patent Application Ser. No. 62/884,359 filed Aug. 8, 2019, the disclosure of which is hereby incorporated by reference in its entirety.

### Background

**[p0002]**

The invention generally relates to programmable motion systems and relates in particular to end-effectors for programmable motion devices (e.g., robotic systems) for use in object processing such as object sortation or order fulfillment. End-effectors for robotic systems may be employed, for example, in certain applications to select and grasp an object, and then move the acquired object very quickly to a new location. End-effectors should be designed to quickly and easily select and grasp an object from a jumble of dissimilar objects, and should be designed to securely grasp an object during movement. Certain end-effectors, when used on different objects of different physical sizes, weights and materials, may have limitations regarding how securely they may grasp an acquired object during rapid movement, particularly rapid acceleration and deceleration (both angular and linear). Many end-effectors employ vacuum pressure for acquiring and securing objects for transport and/or subsequent operations by robotic systems that include articulated arms. Other techniques for acquiring and securing objects involve electrostatic attraction, magnetic attraction, needles for penetrating objects such as fabrics, fingers that squeeze an object, hooks that engage and lift a protruding feature of an object, and collets that expand in an opening of an object, among other techniques.

**[p0003]**

In applications where vacuum pressure is used to acquire and secure objects, an end-effector may include a vacuum cup having a compliant lip that contacts the object to be grasped. The compliant lip may be formed of a polymeric or elastomeric material that is flexible enough to allow it to adapt to variations in surface structures. The lip may facilitate creating a seal with a surface despite irregularities such as bumps and texture on the surface. The flexibility allows the vacuum cup to conform to the shape of objects or to wrap around corners of objects to create an adequate seal for acquiring and securing the object. When a good seal is not created between a flexible vacuum cup and an object however, (due for example, to the nature of the product or because the vacuum cup is overhanging an edge of the object), the portion of the lip of the vacuum cup that is not well sealed may contribute to making noise, sometimes a substantial amount of noise, and the noise level may be above safe limits if human personnel are in close proximity to the programmable motion device. Other types of end-effectors, however, including vacuum cups with less flexible lips (in addition to those using electrostatic attraction, magnetic attraction, needles for penetrating objects such as fabrics, fingers that squeeze an object, hooks that engage and lift a protruding feature of an object, and collets that expand in an opening of an object), are less effective at acquiring and moving a wide variety of objects.

**[p0004]**

There remains a need therefore, for an end-effector system in a programmable motion system that may select and grasp any of a wide variety of objects, and then move the acquired objects very quickly to a new location while not producing an unacceptable level of noise.

### Summary

**[p0005]**

In accordance with an aspect, the invention provides a vacuum cup for use in a programmable motion device. The vacuum cup includes an open inlet for coupling to a vacuum source, and a vacuum cup lip on a portion of the vacuum cup that generally surrounds the open inlet. The vacuum cup lip includes an inner surface that defines the open outlet through which a vacuum may be provided, and includes noise mitigation features on an outer surface of the vacuum cup lip. In accordance with another aspect, the invention provides a vacuum cup for use in a programmable motion device. The vacuum cup includes an open inlet for coupling to a vacuum source, a vacuum cup lip on a portion of the vacuum cup that is generally opposite the open inlet, and an open outlet through which a vacuum may be provided. The vacuum cup includes a plurality of protrusions on an outer surface of the vacuum cup lip. In accordance with yet another aspect, the invention provides a method of providing a vacuum source in a programmable motion device. The method includes coupling the vacuum source to open inlet of a vacuum cup, said vacuum cup including noise mitigation features on an outer surface of the vacuum cup, and providing a vacuum cup open outlet through which the vacuum may be provided.

**[p0006]**

In accordance with a further aspect, the invention provides a system for providing automated processing of objects. The system includes a programmable motion device including an end-effector that is coupled to a vacuum source. The end-effector includes a vacuum cup that includes noise mitigation features on an outer surface of the vacuum cup.

### Brief Description Of The Drawings

**[p0007]**

The following description may be further understood with reference to the accompanying drawings in which: FIG. 1 shows an illustrative diagrammatic view of an automated object processing system in accordance with an aspect of the present invention; FIG. 2 shows an illustrative diagrammatic view of an underside of an end-effector in accordance with an aspect of the invention that is partially grasping an object; FIGS. 3A and 3B show illustrative diagrammatic views of a vacuum end-effector in accordance with the prior art from a side view ( FIG. 3A ) and from below ( FIG. 3B ); FIGS. 4A and 4B show an illustrative diagrammatic partial side views of a portion of a vacuum cup lip initially overhanging an object ( FIG. 4A ), and subsequently undergoing resonance causing noise ( FIG. 4B ); FIG. 5 shows an illustrative diagrammatic view of an end-effector for use in an automated object processing system in accordance with an aspect of the invention that includes pairs of noise mitigation features;

**[p0008]**

FIG. 6 shows an illustrative diagrammatic view of an end-effector for use in an automated object processing system in accordance with another aspect of the invention including larger noise mitigation features; FIG. 7 shows an end-effector for use in an automated object processing system in accordance with another aspect of the invention including sets of three noise mitigation features; FIG. 8 shows an end-effector for use in an automated object processing system in accordance with an aspect of the invention including wedge-shaped noise mitigation features; FIGS. 9A and 9B show an end-effector for use in an automated object processing system in accordance with an aspect of the invention including cylindrical-shaped noise mitigation features from above ( FIG. 9A ) and from below ( FIG. 9B ); FIG. 10 shows an illustrative diagrammatic partial side view of the end-effector of FIG. 5 ; FIG. 11 shows an illustrative diagrammatic underside view of the end-effector of FIG. 9B while undergoing resonance; and

**[p0009]**

FIG. 12 shows an illustrative diagrammatic underside view of an end-effector in accordance with an aspect of the present invention that includes large semi-spherical protrusions as noise mitigation features. The drawings are shown for illustrative purposes only.

### Detailed Description

**[p0010]**

In high airflow vacuum applications, a vacuum is provided that has an airflow of at least about 100 cubic feet per minute, and a vacuum pressure at the end effector of no more than about 65,000 Pascals below atmospheric (e.g., about 50,000 Pascals below atmospheric or 7.25 psi). Applicants have discovered that when such a high airflow vacuum is provided that does not create a good seal (again, due for example to the nature of the product or because the vacuum cup overhangs an edge of the object), the lip may vibrate from the high airflow creating a loud (sometimes whistling) noise. In accordance with various aspects, the invention provides a vacuum cup for a programmable motion device that include integral noise mitigation features. In accordance with further specific aspects, the noise mitigation features may include any of protrusions, lands, rises, relief features, and/or bumps that extend from a non-object contacting side of the lip of a vacuum cup. Surprisingly, the use of such features reduces the noise generated by a compliant vacuum cup when used in a high airflow application.

**[p0011]**

In accordance with various aspects, the noise mitigation features increase the mass of the vacuum cup on the outer rim, but do not negatively decrease the flexibility of the material of the vacuum cup lip. Such noise mitigation features are believed to reduce the frequency at which the vacuum cup lip vibrates when subject to the high vacuum flowrate, while not adversely affecting the stiffness of the vacuum cup lip, which is important to providing the compliance (flexibility) needed to create a seal in a wide variety of applications. The invention involves adding material to a top side of a lip of a molded vacuum cup, which may be presented as small protrusions or bumps (features) encircling the top side of the lip of the cup in accordance with various aspects. The distance between each of the features, as well as the circumference(es) and height(s) and/or length(s), width(s), and height(s) of the features may vary in accordance with various aspects, together with the material of the vacuum cup lip, the thickness of the lip of the cup and the size (diameter) of the circumference of the centers of the circle of features, as well as the angle (complex or linear) of the widening of the lip of the vacuum cup within bounds of various aspects of the invention that provide sufficient flexibility to engage a good seal on a variety of objects, yet also provide a sufficient quantity of sufficiently distributed outer mass features on the top side of a lip of a vacuum cup.

**[p0012]**

For example, a vacuum cup of an end effector may have an innermost diameter (vacuum passage) of about 0.5 inches to about 1.5 inches, while a lip of the vacuum cup may have an outer diameter of about 1.5 inches to about 4.5 inches. A high flow vacuum may be provided, e.g., by a blower, having a vacuum pressure at the end effector of no more than about 65,000 Pascals below atmospheric (e.g., about 50,000 Pascals below atmospheric or 7.25 psi). FIG. 1 for example, shows a system 10 including a programmable motion device 12 having an end effector 14 in accordance with an aspect of the present invention. A vacuum source 16 is coupled to the end effector 14 via a hose 18 , and the programmable motion device 12 is programmed to select objects 20 , 22 , 24 from an input area 26 (including for example a belted conveyor 28 ), and to provide selected objects to an output area 30 that includes, for example, one or more output boxes 32 under the control of one or more computer processing systems 34 . Operation of the programmable motion device (e.g., robot) 12 , including for example, current jobs and future intended movements or needs of the robot 12 , may be displayed on a monitor 36 , and an override stop switch 38 may also be provided for safety purposes.

**[p0013]**

FIG. 2 shows an underside of a vacuum cup 40 of the end effector 14 , wherein the vacuum cup 40 is grasping an object 42 such that a seal is not formed against the object because the vacuum cup extends over an edge of the object. Using the high flow vacuum of embodiments of the present invention (e.g., about 50,000 Pascals below atmospheric), the object is grasped and maintained by the vacuum cup. FIGS. 3A and 3B show a vacuum cup 50 in accordance with the prior art. The vacuum cup 50 includes an attachment portion 52 for attaching to an end effector section, a flexible bellows portion 54 , and a flexible flanged portion 56 for creating a seal against objects. The inner surface of the flexible flanged portion 56 includes ribs 58 spaced radially inward of an outer lip 59 of the vacuum cup. The ribs 58 support the flanged portion (i.e., keep the flanged portion from collapsing onto an object), when under the force of a sealed vacuum against an object. With reference to FIGS. 4A and 4B , when a seal is not created by the end vacuum cup 50 on an object 42 (e.g., because the object is grasped near an edge of the object), although the object may be able to be lifted by the force of the high flow vacuum passing between the ribs 58 (as shown in FIG. 4A ), the overhanging portion of the vacuum cup lip 59 may be drawn toward the object 42 (as shown in FIG. 4B ). Under select circumstances (e.g., the flexibility/stiffness of the flexible lip, the thickness of the flexible lip, the air flow rate, and the shape and volume of the open area that is not contacting the object), the vacuum c

**[p0013]**

up lip may vibrate, causing substantial noise.

**[p0014]**

FIG. 5 shows a vacuum cup 60 in accordance with an aspect of the present invention. The vacuum cup 60 includes an attachment portion 62 for attaching to an end effector section, a flexible bellows portion 64 , and a flexible flanged portion 66 for creating a seal against objects. The inner surface of the flexible flanged portion 66 includes ribs 67 spaced radially inward of an outer lip 69 of the vacuum cup. The vacuum cup 60 further includes noise mitigation features 68 in the form of partial spheres that are spaced from one another along a circumference of the vacuum cup lip. The noise mitigation features may be formed of, for example, silicone adhesive. The noise mitigation features may be evenly spaced with respect to the ribs 67 such that two features are provided (on the top) between ribs (on the bottom). FIG. 6 shows a vacuum cup 70 in accordance with another aspect of the present invention that includes single, larger features associated with ribs. Similarly, the vacuum cup 70 includes an attachment portion 72 for attaching to an end effector section, a flexible bellows portion 74 , and a flexible flanged portion 76 for creating a seal against objects. The inner surface of the flexible flanged portion 76 includes ribs 77 spaced radially inward of an outer lip 79 of the vacuum cup. The vacuum cup 70 further includes noise mitigation features 78 in the form of fewer larger spheres than the embodiment of FIG. 5 that are spaced from one another along a circumference of the vacuum cup lip. The noise mitigation features may be formed of, for example, silicone adhesive. Th

**[p0014]**

e noise mitigation features may be evenly spaced with respect to the ribs 67 such that one feature is provided (on the top) between ribs (on the bottom).

**[p0015]**

FIG. 7 shows a vacuum cup 80 in accordance with a further aspect of the present invention that incudes differently sized features. The vacuum cup 80 includes an attachment portion 82 for attaching to an end effector section, a flexible bellows portion 84 , and a flexible flanged portion 86 for creating a seal against objects. The inner surface of the flexible flanged portion 86 includes ribs 87 spaced radially inward of an outer lip 89 of the vacuum cup. The vacuum cup 80 further includes noise mitigation features 85 , 88 in the form of spheres that are spaced from one another along a circumference of the vacuum cup lip. The noise mitigation features may be formed of, for example, silicone adhesive. The noise mitigation features may be evenly spaced with respect to the ribs 87 such that three features of two different sizes are provided (on the top) between ribs (on the bottom). FIG. 8 shows a vacuum cup 90 in accordance with another aspect of the present invention that includes edge-shaped features. Similarly, the vacuum cup 90 includes an attachment portion 92 for attaching to an end effector section, a flexible bellows portion 94 , and a flexible flanged portion 96 for creating a seal against objects. The inner surface of the flexible flanged portion 96 includes ribs 97 spaced radially inward of an outer lip 99 of the vacuum cup. The vacuum cup 90 further includes noise mitigation features 98 in the form of wedges that are spaced from one another along a circumference of the vacuum cup lip. The noise mitigation features may be formed of, for example, silicone adhesive. T

**[p0015]**

he noise mitigation features may be evenly spaced with respect to the ribs 97 such that one feature is provided (on the top) between ribs (on the bottom).

**[p0016]**

FIGS. 9A and 9B show a vacuum cup 100 in accordance with a further aspect of the present invention that includes cylindrically-shaped features. The vacuum cup 100 includes an attachment portion 102 for attaching to an end effector section, a flexible bellows portion 104 , and a flexible flanged portion 106 for creating a seal against objects. The inner surface of the flexible flanged portion 106 includes ribs 107 spaced radially inward of an outer lip 109 of the vacuum cup. The vacuum cup 100 further includes noise mitigation features 108 in the form of cylinders that are spaced from one another along a circumference of the vacuum cup lip. The noise mitigation features may be formed of, for example, silicone adhesive. The noise mitigation features may be evenly spaced with respect to the ribs 107 such that two features are provided (on the top side) between ribs (on the bottom side). With further reference to FIG. 10 , in accordance with the above aspects of the present invention, when a seal is not made between a vacuum cup (e.g., 60 ) and an object 42 , the noise mitigation features (e.g., 68 ) near the vacuum cup lip (e.g., 69 ) dampen the vibration of the vacuum cup lip, significantly reducing noise. Each of the noise mitigation features also discussed above (e.g., 68 , 78 , 85 , 88 , 98 ) may function similarly to reduce noise. Further, certain types of noise mitigation features (such as those discussed above with respect to FIGS. 9A and 9 B), may contact each other as shown in FIG. 11 when the lip moves inward due to a high vacuum flow, further contributing to noise m

**[p0016]**

itigation.

**[p0017]**

The noise mitigation features may, for example, range from about 0.008 cubic centimeters to about 1.75 cubic centimeters, and may preferably each be less than about 1 cubic centimeter in volume in certain embodiments. The noise mitigation features may also be formed of any of a silicone based adhesive, epoxy-based adhesive, or other polymeric material. FIG. 12 shows vacuum cup similar to that of FIG. 6 with larger noise mitigation features. In particular, FIG. 12 shows a vacuum cup 110 in accordance with another aspect of the present invention that includes larger partial spherically-shaped features. Similarly, the vacuum cup 110 includes an attachment portion 112 for attaching to an end effector section, a flexible bellows portion 114 , and a flexible flanged portion 116 for creating a seal against objects. The inner surface of the flexible flanged portion 116 includes ribs 117 spaced radially inward of an outer lip 119 of the vacuum cup. The vacuum cup 110 further includes larger noise mitigation features 118 in the form of large spheres that are spaced from one another along a circumference of the vacuum cup lip. The noise mitigation features may be formed of, for example, silicone adhesive. The noise mitigation features may be evenly spaced with respect to the ribs 117 such that one feature is provided (on the top) between ribs (on the bottom).

**[p0018]**

In accordance with various embodiments therefore, the invention provides a system for providing automated processing of objects, where the system includes a programmable motion device including an end effector that is coupled to a vacuum source, with the end effector including a vacuum cup that includes noise mitigation features on an outer surface thereof. Those skilled in the art will appreciate that numerous modifications and variations may be made to the above disclosed embodiments without departing from the spirit and scope of the present invention.

## Figure captions

- **Figure 1:** FIG. 1 shows an illustrative diagrammatic view of an automated object processing system in accordance with an aspect of the present invention;
- **Figure 2:** FIG. 2 shows an illustrative diagrammatic view of an underside of an end-effector in accordance with an aspect of the invention that is partially grasping an object;
- **Figure 3A:** FIGS. 3A and 3B show illustrative diagrammatic views of a vacuum end-effector in accordance with the prior art from a side view ( FIG. 3A ) and from below ( FIG. 3B );
- **Figure 4A:** FIGS. 4A and 4B show an illustrative diagrammatic partial side views of a portion of a vacuum cup lip initially overhanging an object ( FIG. 4A ), and subsequently undergoing resonance causing noise ( FIG. 4B );
- **Figure 5:** FIG. 5 shows an illustrative diagrammatic view of an end-effector for use in an automated object processing system in accordance with an aspect of the invention that includes pairs of noise mitigation features;
- **Figure 6:** FIG. 6 shows an illustrative diagrammatic view of an end-effector for use in an automated object processing system in accordance with another aspect of the invention including larger noise mitigation features;
- **Figure 7:** FIG. 7 shows an end-effector for use in an automated object processing system in accordance with another aspect of the invention including sets of three noise mitigation features;
- **Figure 8:** FIG. 8 shows an end-effector for use in an automated object processing system in accordance with an aspect of the invention including wedge-shaped noise mitigation features;
- **Figure 9A:** FIGS. 9A and 9B show an end-effector for use in an automated object processing system in accordance with an aspect of the invention including cylindrical-shaped noise mitigation features from above ( FIG. 9A ) and from below ( FIG. 9B );
- **Figure 10:** FIG. 10 shows an illustrative diagrammatic partial side view of the end-effector of FIG. 5 ;
- **Figure 11:** FIG. 11 shows an illustrative diagrammatic underside view of the end-effector of FIG. 9B while undergoing resonance; and
- **Figure 12:** FIG. 12 shows an illustrative diagrammatic underside view of an end-effector in accordance with an aspect of the present invention that includes large semi-spherical protrusions as noise mitigation features.

## Classifications

- B25J15/0616
- B25J15/0683
- B25J15/0683
- B25J15/0683
- B25J15/06
- B25J15/0683
- B25J9/14
- B25J9/14
- B25J9/14

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
