# 03. Unterdruckhandhabungseinrichtung zum Ansaugen, Anheben, Verlagern, Absenken und/oder Absetzen von Gegenständen

- **Archive rank:** 3 of 50
- **Publication:** [DE-102020133624-A1](https://patents.google.com/patent/DE102020133624A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/077499714/publication/DE102020133624A1?q=pn%3DDE102020133624A1)
- **Publication date:** 2022-06-15
- **Filing date:** 2020-12-15
- **Earliest priority:** 2020-12-15
- **Family:** 77499714
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo

## Parties

- **Applicant / assignee:** SCHMALZ J GMBH
- **Inventors:** FREY MATTHIAS

## Abstract

Die Erfindung betrifft eine Unterdruckhandhabungseinrichtung (2) zum Ansaugen, Anheben, Verlagern, Absenken und/oder Absetzen von Gegenständen, die als kollaborierender Roboter (4) ausgebildet ist, umfassend: eine unterdruckerzeugende Einrichtung (42) oder eine Anschlussschnittstelle zu einer Unterdruckversorgungseinrichtung, eine Robotersteuereinrichtung (26), mehrere gelenkig miteinander verbundene und/oder translatorisch zueinander stellbare Glieder (16, 18) die einen Roboterarm (20) bilden, mehrere Antriebseinrichtungen (24, 25) zum Bewegen der gelenkig miteinander verbundenen Glieder (16, 18) oder der translatorisch zueinander stellbaren Glieder des Roboterarms (20) gegeneinander, wobei die bewegbaren Glieder (16, 18) des Roboterarms vertikal oberhalb eines Aufenthaltsbereichs einer Bedienperson im kollaborierenden Betrieb des Roboters (4) angeordnet sind, eine Sauggreifereinrichtung (36), an welche ein Sauggreifer (38) anschließbar ist oder die einen Sauggreifer (38) bildet oder umfasst, an welchem der zu handhabende Gegenstand ansaugbar ist, wobei die Sauggreifereinrichtung (36) Steuerorgane für die Steuerung der Zuführung von Unterdruck zu einem Sauggreifer (38) umfasst, einen unterdruckbeaufschlagbaren Hubschlauch (30) als translatorischen Antrieb zur Ausführung einer vertikalen Stellbewegung entlang einer Z-Achse (32),
 mit einer ersten Anbindungsschnittstelle des Hubschlauchs (30) zu einem Glied (14) des Roboters (4) und mit einer zweiten Anbindungsschnittstelle (34) des Hubschlauchs (30) zu der Sauggreifereinrichtung (36), wobei der Hubschlauch (30) biege- und verwindungssteif ausgebildet ist, so dass durch den Roboter (4) veranlasste Bewegungen quer zur Z-Achse (32) nicht zu einer Pendelbewegung der Sauggreifereinrichtung (36) mit dem angesaugten Gegenstand führen können, wobei die Sauggreifereinrichtung (36) wahlweise für automatischen Steuerungsablauf durch die Robotersteuereinrichtung (26) und wahlweise für die manuelle Bedienung durch eine Bedienperson ausgebildet ist und hierfür manuelle Bedienelemente (46) aufweist.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/d8/b6/7e/88a9a232826a8b/DE102020133624A1_0001.png)

![Sketch 1 for DE-102020133624-A1](https://patentimages.storage.googleapis.com/d8/b6/7e/88a9a232826a8b/DE102020133624A1_0001.png)

## Claims

### Claim 1 (independent)

Unterdruckhandhabungseinrichtung (2) zum Ansaugen, Anheben, Verlagern, Absenken und/oder Absetzen von Gegenständen, die als kollaborierender Roboter (4) ausgebildet ist, umfassend: eine unterdruckerzeugende Einrichtung (42) oder eine Anschlussschnittstelle zu einer Unterdruckversorgungseinrichtung, eine Robotersteuereinrichtung (26), mehrere gelenkig miteinander verbundene und/oder translatorisch zueinander stellbare Glieder (16, 18) die einen Roboterarm (20) bilden, mehrere Antriebseinrichtungen (24, 25) zum Bewegen der gelenkig miteinander verbundenen Glieder (16, 18) oder der translatorisch zueinander stellbaren Glieder des Roboterarms (20) gegeneinander, wobei die bewegbaren Glieder (16, 18) des Roboterarms vertikal oberhalb eines Aufenthaltsbereichs einer Bedienperson im kollaborierenden Betrieb des Roboters (4) angeordnet sind, eine Sauggreifereinrichtung (36), an welche ein Sauggreifer (38) anschließbar ist oder die einen Sauggreifer (38) bildet oder umfasst, an welchem der zu handhabende Gegenstand ansaugbar ist, wobei die Sauggreifereinrichtung (36) Steuerorgane für die Steuerung der Zuführung von Unterdruck zu einem Sauggreifer (38) umfasst, einen unterdruckbeaufschlagbaren Hubschlauch (30) als translatorischen Antrieb zur Ausführung einer vertikalen Stellbewegung entlang einer Z-Achse (32), mit einer ersten Anbindungsschnittstelle des Hubschlauchs (30) zu einem Glied (14) des Roboters (4) und mit einer zweiten Anbindungsschnittstelle (34) des Hubschlauchs (30) zu der Sauggreifereinrichtung (36), wobei der Hubschlauch (30) biege- und verwindungssteif ausgebildet ist, so dass durch den Roboter (4) veranlasste Bewegungen quer zur Z-Achse (32) nicht zu einer Pendelbewegung der Sauggreifereinrichtung (36) mit dem angesaugten Gegenstand führen können, wobei die Sauggreifereinrichtung (36) wahlweise für automatischen Steuerungsablauf durch die Robotersteuereinrichtung (26) und wahlweise für die manuelle Bedienung durch eine Bedienperson ausgebildet ist und hierfür manuelle Bedienelemente (46) aufweist.Vacuum handling device (2) for sucking in, lifting, moving, lowering and/or setting down objects, which is designed as a collaborative robot (4), comprising: a vacuum-generating device (42) or a connection interface to a vacuum supply device, a robot controller (26), several links (16, 18) which are articulated to one another and/or can be adjusted translationally to one another and which form a robot arm (20), a plurality of drive means (24, 25) for moving the articulated members (16, 18), or the limbs of the robot arm (20) that can be adjusted translationally relative to one another, wherein the movable members (16, 18) of the robot arm are arranged vertically above a location area of an operator in collaborative operation of the robot (4), a suction gripper device (36) to which a suction gripper (38) can be connected or which forms or includes a suction gripper (38) on which the object to be handled can be sucked, wherein the suction gripper device (36) comprises control elements for controlling the supply of vacuum to a suction gripper (38), a lifting hose (30) that can be subjected to negative pressure as a translational drive for executing a vertical adjustment movement along a Z-axis (32), with a first connection interface of the lifting tube (30) to a member (14) of the robot (4) and with a second connection interface (34) of the lifting tube (30) to the suction gripper device (36), wherein the lifting tube (30) is designed to be resistant to bending and torsion, so that movements transverse to the Z-axis (32) caused by the robot (4) cannot lead to a pendulum movement of the suction gripper device (36) with the sucked-on object, wherein the suction gripper device (36) is optionally designed for automatic control sequence by the robot control device (26) and optionally for manual operation by an operator and has manual operating elements (46) for this purpose.

### Claim 2

Unterdruckhandhabungseinrichtung nach Anspruch 1, dadurch gekennzeichnet, dass bei oder innerhalb des Hubschlauchs (30) eine die vertikale Z-Achse versteifende längenverstellbare, insbesondere teleskopierende Führungseinrichtung (39) vorgesehen ist.vacuum handling device claim 1 , characterized in that at or within the lifting tube (30) a length-adjustable, in particular telescoping guide device (39) is provided which stiffens the vertical Z-axis.

### Claim 3

Unterdruckhandhabungseinrichtung nach Anspruch 1 oder 2, gekennzeichnet durch manuelle Bedienelemente (46) der Sauggreifereinrichtung (36), die mit der Robotersteuereinrichtung (26) derart zusammenwirken, dass über diese manuellen Bedienelemente (46) auf die Robotersteuereinrichtung (26) Einfluss genommen werden kann.vacuum handling device claim 1 or 2 , characterized by manual operating elements (46) of the suction gripper device (36), which interact with the robot control device (26) in such a way that these manual operating elements (46) can be used to influence the robot control device (26).

### Claim 4

Unterdruckhandhabungseinrichtung nach Anspruch 3, dadurch gekennzeichnet, dass über die manuellen Bedienelemente (46) die Robotersteuereinrichtung (26) dazu veranlasst werden kann, den Roboterarm (20) in einen Handführbetrieb zu versetzen, in welchem ein handgeführtes Bewegen des Roboterarms (20) und seiner Glieder (16, 18) zugelassen ist.vacuum handling device claim 3 , characterized in that the manual operating elements (46) can be used to cause the robot control device (26) to set the robot arm (20) to manual operation, in which manual movement of the robot arm (20) and its limbs (16, 18 ) is allowed.

### Claim 5

Unterdruckhandhabungseinrichtung nach Anspruch 3 oder 4, dadurch gekennzeichnet, dass über die manuellen Bedienelemente (46) die Robotersteuereinrichtung (26) veranlasst werden kann, einen Bewegungs-Lernmodus zu aktivieren, bei dem der Roboter (4) das handgeführte Bewegen als Bewegungsmuster für einen Arbeitsbetrieb erlernt.vacuum handling device claim 3 or 4 , characterized in that the manual operating elements (46) can be used to cause the robot control device (26) to activate a movement learning mode in which the robot (4) learns hand-guided movement as a movement pattern for a working operation.

### Claim 6

Unterdruckhandhabungseinrichtung nach einem oder mehreren der vorstehenden Ansprüche, dadurch gekennzeichnet, dass die Sauggreifereinrichtung (36) eine Ventileinrichtung umfasst, die sowohl durch die Robotersteuereinrichtung (26) als auch durch die manuellen Bedienelemente (46) bei der Sauggreifereinrichtung (36) ansteuerbar oder betätigbar ist.Vacuum handling device according to one or more of the preceding claims, characterized in that the suction gripper device (36) comprises a valve device which can be controlled or actuated both by the robot control device (26) and by the manual operating elements (46) in the suction gripper device (36).

### Claim 7

Unterdruckhandhabungseinrichtung nach einem oder mehreren der vorstehenden Ansprüche, dadurch gekennzeichnet, dass sie als Wand- oder Säulenschwenkkrananordnung (6) mit, vorzugsweise in einer horizontalen Ebene (12), schwenkbaren Kranarmen (10, 14) ausgebildet ist, welche die Glieder (16, 18) des Roboters bilden.Vacuum handling device according to one or more of the preceding claims, characterized in that it is designed as a wall or pillar slewing crane arrangement (6) with slewing crane arms (10, 14), preferably in a horizontal plane (12), which the members (16, 18 ) of the robot.

### Claim 8

Unterdruckhandhabungseinrichtung nach einem oder mehreren der vorstehenden Ansprüche, dadurch gekennzeichnet, dass der Hubschlauch (30) an einem endständigen Kranarm (14) angeordnet ist.Vacuum handling device according to one or more of the preceding claims, characterized in that the lifting tube (30) is arranged on a terminal crane arm (14).

### Claim 9

Unterdruckhandhabungseinrichtung nach einem oder mehreren der vorstehenden Ansprüche, dadurch gekennzeichnet, dass die Sauggreifereinrichtung (36) um die Z-Achse (32) drehbar bezüglich eines nächstliegenden Glieds (18) des Roboterarms (20) angeordnet ist.Vacuum handling device according to one or more of the preceding claims, characterized in that the suction gripper device (36) is arranged to be rotatable about the Z-axis (32) with respect to a nearest link (18) of the robot arm (20).

### Claim 10

Unterdruckhandhabungseinrichtung nach einem oder mehreren der vorstehenden Ansprüche, gekennzeichnet durch ein manuelles Bedienelement (46) in Form eines Handgriffs (48), der an und bezüglich der Sauggreifereinrichtung (36) schwenkbar angeordnet ist.Vacuum handling device according to one or more of the preceding claims, characterized by a manual operating element (46) in the form of a handle (48) which is arranged pivotably on and with respect to the suction gripper device (36).

### Claim 11

Unterdruckhandhabungseinrichtung nach einem oder mehreren der vorstehenden Ansprüche, dadurch gekennzeichnet, dass eine Wegmesseinrichtung (56) zur Ermittlung einer Position der Sauggreifereinrichtung (36) entlang der Z-Achse (32) vorgesehen ist.Vacuum handling device according to one or more of the preceding claims, characterized in that a path measuring device (56) is provided for determining a position of the suction gripper device (36) along the Z axis (32).

### Claim 12

Unterdruckhandhabungseinrichtung nach einem oder mehreren der vorstehenden Ansprüche, dadurch gekennzeichnet, dass das eine Unterdruckmesseinrichtung (58) zur Ermittlung eines Unterdrucks innerhalb des Hubschlauchs (30) vorgesehen ist.Vacuum handling device according to one or more of the preceding claims, characterized in that the one vacuum measuring device (58) is provided for determining a vacuum within the lifting tube (30).

### Claim 13

Unterdruckhandhabungseinrichtung nach einem oder mehreren der vorstehenden Ansprüche, dadurch gekennzeichnet, dass ein Proportionalventil (60) bei dem Hubschlauch (30) vorgesehen ist, zur Steuerung eines Anhebens, Absenkens oder Haltens des Hubschlauchs und der Sauggreifereinrichtung (36).Vacuum handling device according to one or more of the preceding claims, characterized in that a proportional valve (60) is provided at the lifting tube (30) for controlling a raising, lowering or holding of the lifting tube and the suction gripper device (36).

### Claim 14

Unterdruckhandhabungseinrichtung nach einem oder mehreren der vorstehenden Ansprüche, dadurch gekennzeichnet, dass eine Absperreinrichtung (62) im Strömungsweg zwischen dem unterdruckführenden Hubschlauch (30) und der Sauggreifereinrichtung (36) vorgesehen ist.Vacuum handling device according to one or more of the preceding claims, characterized in that a shut-off device (62) is provided in the flow path between the vacuum-carrying lifting hose (30) and the suction gripper device (36).

### Claim 15

Unterdruckhandhabungseinrichtung nach einem oder mehreren der vorstehenden Ansprüche, dadurch gekennzeichnet, dass bei der Sauggreifereinrichtung (36) ein Ventil (64) zur Unterstützung eines Ablegens angesaugter Gegenstände oder zur Verhinderung eines Anhebens des Hubschlauchs (30) und der Sauggreifereinrichtung (36) beim Ansaugen eines Gegenstands vorgesehen ist.Vacuum handling device according to one or more of the preceding claims, characterized in that the suction gripper device (36) has a valve (64) to support the depositing of sucked-up objects or to prevent the lifting tube (30) and the suction gripper device (36) from being lifted when an object is sucked in is provided.

### Claim 16

Unterdruckhandhabungseinrichtung nach einem oder mehreren der vorstehenden Ansprüche, dadurch gekennzeichnet, dass die Robotersteuereinrichtung (26) eine Drehzahlsteuereinrichtung umfasst, um die unterdruckerzeugende Einrichtung (42) anzusteuern.Vacuum handling device according to one or more of the preceding claims, characterized in that the robot control device (26) comprises a speed control device in order to control the vacuum-generating device (42).

### Claim 17

Unterdruckhandhabungseinrichtung nach einem oder mehreren der vorstehenden Ansprüche, dadurch gekennzeichnet, dass die Robotersteuereinrichtung (26) ausgebildet ist, um als Eingangsgröße eine Position der Sauggreifereinrichtung (36) entlang der Z-Achse (32) und eines Unterdrucks innerhalb des Hubschlauchs (30) zu erhalten und über Steuerausgänge Steuersignale an wenigstens ein Steuerorgan im Bereich der Sauggreifereinrichtung (36) oder des Hubschlauchs (30) und insbesondere auch an die unterdruckerzeugende Einrichtung (42) zu geben.Vacuum handling device according to one or more of the preceding claims, characterized in that the robot control device (26) is designed to receive a position of the suction gripper device (36) along the Z-axis (32) and a vacuum within the lifting tube (30) as an input variable and to send control signals via control outputs to at least one control element in the area of the suction gripper device (36) or the lifting tube (30) and in particular also to the device (42) that generates a vacuum.

## Full description

The invention relates to a vacuum handling device (2) for sucking in, lifting, moving, lowering and/or setting down objects, which is designed as a collaborating robot (4), comprising: a vacuum-generating device (42) or a connection interface to a vacuum supply device, a robot control device (26), several links (16, 18) which are articulated to one another and/or can be adjusted translationally to one another and form a robot arm (20), several drive devices (24, 25) for moving the articulated links (16, 18) or the translationally mutually adjustable links of the robot arm (20), the movable links (16, 18) of the robot arm being arranged vertically above an area where an operator is in collaborative operation of the robot (4), a suction gripper device (36) to which a suction gripper (38 ) can be connected or which forms a suction pad (38) or on which the object to be handled can be sucked, the suction gripper device (36) comprising control elements for controlling the supply of vacuum to a suction gripper (38), a lifting hose (30) that can be subjected to vacuum as a translatory drive for executing a vertical adjustment movement along a Z - axis (32), with a first connection interface of the lifting tube (30) to a member (14) of the robot (4) and with a second connection interface (34) of the lifting tube (30) to the suction gripper device (36), wherein the lifting tube ( 30) is designed to be resistant to bending and torsion, so that movements transverse to the Z-axis (32) caused by the robot (4) cannot

The invention relates to a vacuum handling device for sucking in, lifting, moving, lowering and setting down objects, which is designed as a collaborative robot.

Vacuum handlers have become widely known. They typically include a vacuum-generating device or a connection interface to a vacuum-carrying supply, a suction gripper device that can be raised, lowered, and displaced, to which a suction gripper can be connected or which forms or includes a suction gripper, to which the object to be handled can be sucked. To carry out the lifting movement, a lifting tube that can be contracted under the effect of negative pressure or motor-driven cable pulls or swiveling load-bearing crane arms are used in a known manner. Robots are also used, in particular handling robots, with a robot arm having several articulated links, in order to carry out handling tasks of the type mentioned at the outset, in particular in order to carry out such handling tasks automatically or with greater force or greater speed than an operator can perform manually , So hand-held, operation of such a vacuum handling device would be possible.

It is also already known to train industrial robots as so-called “collaborating robots”. This means that the robot is operated in a common or overlapping work area of an operator and that interactions between the operator and the robot also take place or can take place.

The present invention is based on the object of further developing a handling device of the type mentioned at the outset such that it can be used in a more diverse manner.

eine unterdruckerzeugende Einrichtung oder eine Anschlussschnittstelle zu einer Unterdruckversorgungseinrichtung,

eine Robotersteuereinrichtung, mehrere gelenkig miteinander verbundene und/oder translatorisch zueinander stellbare Glieder die einen Roboterarm bilden, mehrere Antriebseinrichtungen zum Bewegen der gelenkig miteinander verbundenen Glieder oder der translatorisch zueinander stellbaren Glieder des Roboterarms gegeneinander, wobei die bewegbaren Glieder des Roboterarms vertikal oberhalb eines Aufenthaltsbereichs einer Bedienperson im kollaborierenden Betrieb des Roboters angeordnet sind,

eine Sauggreifereinrichtung, an welche ein Sauggreifer anschließbar ist oder die einen Sauggreifer bildet oder umfasst, an welchem der zu handhabende Gegenstand ansaugbar ist,

wobei die Sauggreifereinrichtung Steuerorgane für die Steuerung der Zuführung von Unterdruck zu einem Sauggreifer umfasst,

einen unterdruckbeaufschlagbaren Hubschlauch als translatorischen Antrieb zur Ausführung einer vertikalen Stellbewegung entlang einer Z-Achse,

mit einer ersten Anbindungsschnittstelle des Hubschlauchs zu einem Glied des Roboters und mit einer zweiten Anbindungsschnittstelle des Hubschlauchs zu der Sauggreifereinrichtung,

wobei der Hubschlauch biege- und verwindungssteif ausgebildet ist, so dass durch den Roboter veranlasste Bewegungen quer zur Z-Achse nicht zu einer Pendelbewegung der Sauggreifereinrichtung mit dem angesaugten Gegenstand führen können,

wobei die Sauggreifereinrichtung wahlweise für automatischen Steuerungsablauf durch die Robotersteuerung und wahlweise für die manuelle Bedienung durch eine Bedienperson ausgebildet ist und hierfür manuelle Bedienelemente aufweist.

a vacuum-generating device or a connection interface to a vacuum supply device,

a robot control device, a plurality of links which are articulated to one another and/or can be adjusted translationally to one another and which form a robot arm, a plurality of drive devices for moving the links which are connected to one another in an articulated manner or the links of the robot arm which can be adjusted translationally to one another, with the movable links of the robot arm being positioned vertically above an area where an operator is present are arranged in the collaborative operation of the robot,

a suction gripper device to which a suction gripper can be connected or which forms or includes a suction gripper on which the object to be handled can be sucked,

wherein the suction gripper device comprises control elements for controlling the supply of vacuum to a suction gripper,

a lifting hose that can be subjected to negative pressure as a translational drive for executing a vertical adjustment movement along a Z-axis,

with a first connection interface of the lifting tube to a member of the robot and with a second connection interface of the lifting tube to the suction gripper device,

wherein the lifting tube is designed to be resistant to bending and torsion, so that movements transverse to the Z-axis caused by the robot cannot lead to a pendulum movement of the suction gripper device with the object being sucked up,

wherein the suction gripper device is optionally designed for an automatic control process by the robot controller and optionally for manual operation by an operator and has manual operating elements for this purpose.

According to the invention, it is therefore proposed to integrate a collaborating robot into the vacuum handling device, with its driven limbs of the robot arm always remaining vertically above the area where the operator is located, so that collaborative operation with the presence of an operator can always be carried out safely or at least with little risk. In contrast, a vertical Z-axis of the robot or the vacuum handling device that extends into the area where the operator is located is not formed by a directly drivable member of the robot, but by the drive through the contractible lifting tube. Although this engages the vertical Z-axis in the area where the operator is, the risk of injury is reduced by using the lifting hose that can be subjected to negative pressure, even with heavy objects to be handled, because vacuum lifting devices operated by a contractible lifting hose do not lead to a detachment of a sucked-in object and its falling even in the event of disruptions in the vacuum operation, but the suction gripper device only lowers at a leisurely speed. The use of a lifting tube as a translatory drive along the vertical Z-axis is therefore suitable for collaborative operation of the handling device. As a result, higher loads can be handled, in particular up to 120 kg, in particular up to 110 kg, in particular up to 100 kg.

Due to the fact that the lifting tube is designed to be resistant to bending and torsion, which can be realized by a corresponding design of the lifting tube itself or by integrating a rigid length-adjustable, in particular telescopic, guide device in the lifting tube, in particular inside the lifting tube, fully automatic operation is also possible of the handling device is possible because there is no difficult-to-control pivoting or oscillating movement of the suction gripper device with the object being sucked up. However, it also proves to be advantageous in collaborative, ie hand-guided or hand-assisted operation of the device.

Overall, the vacuum handling device designed according to the invention is therefore suitable either for automated operation of all components of the device, including the suction gripper device that can be raised and lowered, or for manual operation by an operator. The previously mentioned manual operating elements in the suction gripper device can include or mean a manually grippable handle in a wide variety of designs, by means of which the operator can manually guide the suction gripper device together with the suction gripper and the sucked-on object, i.e. can initiate forces for the translatory movement of the suction gripper device. In an expedient and known manner, such a handle can also be pivotably connected to the suction gripper device. Furthermore, the manual operating elements mentioned include electrical or mechanical elements, in particular keys, input displays or touch-sensitive fields and/or levers for actuating the control elements of the suction gripper device, i.e. in particular a valve unit accommodated therein for controlling the supply of vacuum to a connected suction gripper.

According to a further preferred embodiment of the vacuum handling device, manual operating elements are provided in the suction gripper device, which interact with the robot control device in such a way that the robot control device can be influenced via the manual operating elements.

According to a preferred embodiment of the invention, it is further provided that the manual operating elements can be used to cause the robot control device to put the robot arm into manual operation, in which manual movement of the robot arm and its limbs is permitted. Such manual operation (often referred to as "free drive" mode) allows the operator to move the robot into a desired working configuration without having to control the robot's limbs.

In particular, it is also conceivable and advantageous that the robot control device can be prompted via the manual operating elements to activate a movement learning mode in which the robot learns hand-guided movement as a movement pattern for a working operation. In this way, the operator can enter the desired movement into the robot in manual operation, so that the robot “learns” this movement and later executes it automatically.

Such manual operation should only be possible in a controlled and intentional manner, so it typically requires release by a so-called “enabling device” for its activation. For this purpose, what is known as an "enabling switch" can be provided on the robot, with which the aforementioned manual operation can be activated. Such an enabling switch can be provided, for example, on a control panel of the robot itself. In contrast, it has proven to be advantageous if the enabling switch is provided in the area of the suction gripper device, ie in the area of manual access by the operator, so that such a transition to manual operation can be carried out comfortably. In particular, buttons or touch-sensitive fields can be provided in the area of the suction gripper device, by means of which this approval can be given or an approval switch can be actuated.

However, independently of this, it is also conceivable and advantageous if the operator can interact with the robot control device via operating elements on the suction gripper device, i.e. in particular operating parameters, in particular dependent on physical parameters of the objects to be handled, can be entered. This can be done by connecting via a suitable bus system.

It has proven to be particularly advantageous if, in the suction gripper device, an operating section comprising operating elements is designed in a shape and size that can be gripped by hand, so that all operating elements can be reached and operated when the operating section is gripped.

This proves to be particularly advantageous when the operator carries out a hand-guided movement in a movement-learning mode as a movement pattern to be learned for a work operation. This allows the operator to perform a required manipulation of the controls during hand guidance to activate or keep activated a motion learning mode while exerting force to manually guide the robot. This further increases the ease of use.

Operating safety and operating comfort can be further increased by the robot providing feedback on its current operating mode. For this purpose, any type of signal output device can be provided, which can be designed in particular such that an optical and/or acoustic and/or haptic signal is output to the operator when manual operation or a movement learning mode is activated. In this manual operation, at least some or optionally all of the mutually adjustable and drive-connected links of the robot are in the non-driven, idle state, so that the robot or the vacuum handling device or its suction gripper device can be guided by hand with as little resistance as possible.

The suction gripper device expediently comprises a valve device which, in a preferred embodiment, can be controlled or actuated both by the robot control device and by the manual operating elements in the suction gripper device. In particular, a proportional valve can be controlled by a manual operating element, so that its degree of opening can be changed. In particular, the valve device can be designed with a valve that can be actuated mechanically directly by means of a manual operating element.

The robot or the robot kinematics can be implemented in any way in the vacuum handling device according to the invention. In particular, robots with Scara kinematics, portal kinematics, classic 6-axis kinematics, delta kinematics or cable kinematics come into question.

It can prove particularly advantageous if the vacuum handling device is designed as a wall or column-mounted jib crane arrangement with crane arms which can be slewed, preferably in a horizontal plane, and which form the limbs of the robot. - Especially with such an arrangement, it proves to be advantageous if the lifting tube is arranged on a terminal crane arm.

In order to implement a further axis of the handling device or of the robot, it has proven to be advantageous if the suction gripper device is arranged such that it can rotate about the Z-axis with respect to a nearest link of the robot arm. A storage device and drive device required for this can be provided either in the area of the suction gripper device or in the area of the adjacent link of the robot arm. In particular, the lifting tube itself can be rotated via the first or second connection interface. In particular, linear guide or rotary guide devices, in particular with drive devices that can be controlled by the robot control device, can be provided parallel to the lifting tube or preferably inside the lifting tube.

In particular, to support an automatic control sequence by the robot control device, it has proven to be advantageous if a path measuring device is provided for determining a position of the suction gripper device along the Z-axis. This path measuring device is expediently arranged or aligned in the area of the lifting tube and parallel thereto. It can be designed in any way, in particular it can comprise an encodable rope pulley or a laser-based distance measuring device. The distance can be measured, for example, between an upper reference point in the area of the robot limbs and a lower reference point in the area of the suction gripper device.

Furthermore, a vacuum measuring device for determining a vacuum inside the lifting tube can advantageously be provided. For this purpose, a vacuum sensor is expediently arranged in a vacuum-carrying area of the lifting tube, in particular close to the suction gripper device.

It also proves to be advantageous if a proportional valve is provided on the lifting tube to control the lifting, lowering or holding of the lifting tube and the suction gripper device. By activating the proportional valve, more or less leakage air can be introduced into the lifting hose, so that even with a lifting, lowering or holding of the lifting hose of the suction gripper device can be carried out with a substantially constant suction power of the vacuum-generating device.

It also proves to be advantageous if a shut-off device is provided in the flow path between the vacuum-carrying lifting hose and the suction gripper device. As a result, the suction gripper device or a suction side of the suction gripper device that can be subjected to negative pressure can be decoupled from the negative pressure in the lifting tube, which can support the rapid setting down of an object that has been sucked up.

It can also be provided that a valve is provided in the suction gripper device to support the detachment of objects that have been sucked in or to prevent the lifting tube and the suction gripper device from being lifted when an object is sucked in. The above-mentioned shut-off device and also the above-mentioned valve can be assigned to the valve device already mentioned at the outset in the suction gripper device. They can be controlled both by means of manual operating elements in the suction gripper device and in an automatic control sequence by the robot control device, depending on whether manual operation by the operator or an automatic control sequence by the robot control device or an actual mixed form is carried out. In the latter case, a master/slave configuration is then expediently provided.

In order to control the vacuum-generating device, i.e. to specify, control and/or regulate a volume flow or mass flow, i.e. in the broadest sense of the vacuum performance of the vacuum-generating device, it has proven to be advantageous if the robot control device includes a speed control device in order to control the vacuum-generating device.

It has also proven to be advantageous if the robot control device is designed to receive a position of the suction gripper device along the Z-axis and a negative pressure within the lifting tube as an input variable, and to send control signals via control outputs to at least one control element in the area of the suction gripper device or the lifting tube and in particular also to be given to the vacuum-generating device. The above-mentioned control element can be the above-mentioned shut-off device in the flow path between the lifting tube and the suction gripper device or the valves of the valve device of the suction gripper device.
Further features, details and advantages of the invention result from the appended patent claims and from the drawing and the following description of an embodiment of the vacuum handling device according to the invention.

1 eine schematische Seitenansicht einer erfindungsgemäßen Unterdruckhandhabungseinrichtung.

1 a schematic side view of a vacuum handling device according to the invention.

1 shows a vacuum handling device 2 for sucking in, lifting, moving, lowering and setting down objects, which is designed as a collaborative robot 4 according to the invention. The vacuum handling device 2 is designed as a column-mounted jib crane arrangement 6 . It comprises a stationary column 8 extending in the vertical direction, on which a first horizontal crane arm 10 is articulated so that it can pivot in a horizontal plane 12 at the top. At the end of the first horizontal crane arm 10, a second horizontal crane arm 14 is also pivoted in the horizontal plane 12 or parallel thereto. The first and the second crane arm 10, 14 form mutually pivotable members 16, 18, which form a robot arm 20 of the collaborative robot 4. For the articulated pivot connection of the crane arms 10, 14 or the links 16, 18 of the robot arm 20, pivot bearing arrangements 22, 23 and their pivot drive devices 24, 25 are indicated only schematically. They can be controlled by a robot control device 26 that is only indicated.

A contractible lifting tube 30 is connected to the free end of terminal link 18 of robot arm 20 via a first connection interface 28, which extends downward along a vertical Z-axis 32 and is connected to a suction gripper device 36 via a second connection interface 34. A suction gripper 38 of any type and design can be connected to the suction gripper device 36, which suction gripper is designed or selected according to the objects to be handled in the work task at hand.

The contractible lifting tube 30 or one of the Z-axis 32 formed by it is designed to be torsion-resistant so that the suction gripper device 36 with the object sucked on it cannot vibrate, so that the vacuum handling device 2 can also be operated fully automatically. As explained at the outset, this can be achieved by designing the lifting tube 30 itself to be torsionally rigid. In the case shown as an example, however, inside the lifting tube 30 there is a length-adjustable, in particular telescopic, guide direction 39, which prevents deflection of the suction gripper device 36 transversely to the Z-axis 32. At the same time, this guide device 39 can also be used to supply control lines to the suction gripper device 36 .

In order to form a further axis of the collaborating robot 4 , the suction gripper device 36 is designed to be rotatable by preferably 720° about the Z axis 32 with respect to the terminal link 18 of the robot arm 20 in the horizontal plane 12 . A further pivot bearing arrangement 40 can be formed for this purpose, for example in the region of the first or second connection interface 28 , 34 of the lifting tube 30 . The lifting tube 30, which can be contracted by applying negative pressure, acts as a drive along the Z-axis 32.

A vacuum-generating device 42 , in particular in the form of a blower, is provided for the vacuum application, from which a vacuum-loadable and vacuum-carrying line 44 leads away and communicates with the lifting tube 30 . Typically, the interior of the lifting tube 30 is subjected to a negative pressure that is suitable for operation and can be predetermined by the negative pressure-generating device 42 or its control device. This control device can interact with the robot control device 26 or be formed by it. The movement of the suction gripper device 36 in the Z-direction 32, ie lifting, lowering, and also sucking or detaching an object, is initiated or carried out by actuating a valve device provided in the area of the suction gripper device 36. This valve device can be controlled and actuated both by the robot control device 26 and by manual operation by an operator. For this purpose, the operator stays in an area vertically below the kinematics of the robot 14, ie below its robot arm 20. For this purpose, the suction gripper device 36 has manual operating elements 46 in the broadest sense. In the case shown as an example, a manual operating element 46 is provided in the form of a manually grippable handle 48 which is pivotably articulated on an actuating arm 50 which is in turn pivotable and which forms a type of drawbar for the suction gripper device 36 . Handle 48 and actuating arm 50 can be pivoted about a respective horizontal axis of rotation, so that the user can easily adapt different lifting heights of suction gripper device 36 . The manual controls 46 can also include buttons or touch-sensitive fields for manual operation, or mechanical actuators, such as levers or rotary handles for controlling and actuating components of the suction pad device 36, i.e. in particular its valve device, or for interaction with the robot control device 26. This Communication can be wireless or wired in any way.

To further maintain operational safety, optional safety room scanners 52 can be provided, and a schematically indicated contact switch 54 is provided as an example.

A path measuring device 56 is provided in the area of the lifting tube 30 and is indicated in the figure in order to provide input variables, in particular for the automated control sequence by the robot control device. A position of the suction gripper device 36 along the Z-axis 32 is determined with it. A schematically indicated negative pressure measuring device 58 for determining the negative pressure inside the lifting tube 30 is also provided. A respective measuring output of displacement measuring device 56 and of vacuum measuring device 58 is connected to an input of robot control device 26 . Any data and signal communication can be used for this.

The control elements mentioned at the outset for controlling the supply of negative pressure to the suction gripper 38 or for controlling the negative pressure in the lifting tube 30 comprise a proportional valve 60 for controlling a negative pressure within the lifting tube in order to lift the lifting tube (30) and the suction gripper device (36), lower or hold. A blocking device 62 is also indicated schematically, which is provided in the flow path between the vacuum-carrying lifting hose 30 and the suction gripper device 36, by means of which the suction gripper device 36 and its suction gripper 38 can be decoupled from the negative pressure within the lifting hose 30 so that an object that has been sucked up can be set down quickly .

Further valves 64 can be provided in the area of the suction gripper device 36 in order to support the setting down of a sucked-up object or to prevent the lifting tube and the suction gripper device from being lifted too quickly when an object is sucked on.

As already mentioned at the beginning, the robot control device 26 is designed to receive input variables and to send control signals from them to at least one control element in the area of the suction gripper device 36 or the lifting tube 30 and preferably also to the device 42 that generates a vacuum, in order to thereby have an automated control sequence by the robot control device 26 to execute.

The handling device 2 according to the invention enables fully automated robot operation as well as hand-guided or hand-assisted operation by an operator. In particular, the above-mentioned interactions between the operator and the robot control device 26 are possible, i.e. in particular the change to manual operation, in particular in a movement learning mode, in order to enter intended movement patterns in the robot and its control device 26 . In particular, it is also possible or conceivable, purely by way of example, that the colloboration between the robot and the operator is such that some tasks, in particular a displacement task to be carried out in the horizontal plane, are carried out by the robot and the robot controller 26, while other tasks, in particular the lifting and lowering operation of the suction gripper device 36 and/or actuation of the valve device for sucking up and/or setting down an object, can be carried out manually by the operator.

It has proven to be particularly advantageous that the lifting tube is designed to be rigid and torsion-resistant in the broad sense initially understood, so that a movement initiated by the robot transversely to the Z-axis 32 does not lead to a pendulum movement of the suction gripper device 36 along with the suction gripper 38 and the object being sucked up . This increases the operational reliability and in itself enables robot-guided or robot-assisted operation using robot kinematics designed above the area where the operator is located.

## Classifications

- B25J9/044
- B25J1/00
- B25J13/02
- B25J15/0625
- B25J18/02
- B25J18/025
- B25J9/14
- B25J9/144
- B25J9/20
- B66C1/0212
- B66C1/0293
- B66C23/027
- G05B2219/40202

## Cited patent documents

- [DE-10046539-A1](https://patents.google.com/patent/DE10046539A1/en) — UNKNOWN
- [DE-102016206866-A1](https://patents.google.com/patent/DE102016206866A1/en) — UNKNOWN
- [DE-19628095-B4](https://patents.google.com/patent/DE19628095B4/en) — UNKNOWN
- [DE-19817801-C1](https://patents.google.com/patent/DE19817801C1/en) — UNKNOWN
- [DE-202005008248-U1](https://patents.google.com/patent/DE202005008248U1/en) — UNKNOWN
- [EP-2999654-B1](https://patents.google.com/patent/EP2999654B1/en) — UNKNOWN
- [WO-2019110843-A1](https://patents.google.com/patent/WO2019110843A1/en) — UNKNOWN

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
