# 08. Clamping device

- **Archive rank:** 8 of 50
- **Publication:** [KR-20230075567-A](https://patents.google.com/patent/KR20230075567A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/086544060/publication/KR20230075567A?q=pn%3DKR20230075567A)
- **Publication date:** 2023-05-31
- **Filing date:** 2021-11-23
- **Earliest priority:** 2021-11-23
- **Family:** 86544060
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery

## Parties

- **Applicant / assignee:** CHOI TAE KWANG
- **Inventors:** CHOI TAE KWANG

## Abstract

Disclosed is a clamping device capable of easily supporting an attachment object or easily releasing the support of an attachment object. The clamping device includes: a first pole piece assembly including a first pole piece having a plurality of first action surfaces and capable of providing a magnetic path, and a first coil wound around the first pole piece; a second pole piece assembly spaced apart from the first pole piece assembly and including a second pole piece having a plurality of second action surfaces and capable of providing a magnetic path, and a second coil wound around the second pole piece; and a clamp movably disposed between the first pole piece assembly and the second pole piece assembly. The clamp clamps an object supported on a support or releases the clamping for an object while being in contact with the plurality of first action surfaces or the plurality of second action surfaces by controlling the current applied to the first coil and the second coil.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/09/7a/bd/b1bb58babbcbf2/pat00001.png)

![Sketch 1 for KR-20230075567-A](https://patentimages.storage.googleapis.com/09/7a/bd/b1bb58babbcbf2/pat00001.png)

[Sketch 2](https://patentimages.storage.googleapis.com/ff/94/12/fd6613c2835e3d/pat00002.png)

![Sketch 2 for KR-20230075567-A](https://patentimages.storage.googleapis.com/ff/94/12/fd6613c2835e3d/pat00002.png)

[Sketch 3](https://patentimages.storage.googleapis.com/0b/6c/65/76600560298d11/pat00003.png)

![Sketch 3 for KR-20230075567-A](https://patentimages.storage.googleapis.com/0b/6c/65/76600560298d11/pat00003.png)

[Sketch 4](https://patentimages.storage.googleapis.com/64/69/18/b146ca58f6e3a3/pat00004.png)

![Sketch 4 for KR-20230075567-A](https://patentimages.storage.googleapis.com/64/69/18/b146ca58f6e3a3/pat00004.png)

[Sketch 5](https://patentimages.storage.googleapis.com/58/9c/4a/da22acdfd5a908/pat00005.png)

![Sketch 5 for KR-20230075567-A](https://patentimages.storage.googleapis.com/58/9c/4a/da22acdfd5a908/pat00005.png)

[Sketch 6](https://patentimages.storage.googleapis.com/fd/3b/bd/e3e7acec3bb033/pat00006.png)

![Sketch 6 for KR-20230075567-A](https://patentimages.storage.googleapis.com/fd/3b/bd/e3e7acec3bb033/pat00006.png)

[Sketch 7](https://patentimages.storage.googleapis.com/8c/3c/dd/02e9e0f6f7e707/pat00007.png)

![Sketch 7 for KR-20230075567-A](https://patentimages.storage.googleapis.com/8c/3c/dd/02e9e0f6f7e707/pat00007.png)

[Sketch 8](https://patentimages.storage.googleapis.com/45/73/00/6108027d7f9e2c/pat00008.png)

![Sketch 8 for KR-20230075567-A](https://patentimages.storage.googleapis.com/45/73/00/6108027d7f9e2c/pat00008.png)

[Sketch 9](https://patentimages.storage.googleapis.com/99/d7/a4/1cb7dea1ab186e/pat00009.png)

![Sketch 9 for KR-20230075567-A](https://patentimages.storage.googleapis.com/99/d7/a4/1cb7dea1ab186e/pat00009.png)

[Sketch 10](https://patentimages.storage.googleapis.com/32/de/93/adb0a861319f39/pat00010.png)

![Sketch 10 for KR-20230075567-A](https://patentimages.storage.googleapis.com/32/de/93/adb0a861319f39/pat00010.png)

[Sketch 11](https://patentimages.storage.googleapis.com/89/60/3a/04f18c4d613692/pat00011.png)

![Sketch 11 for KR-20230075567-A](https://patentimages.storage.googleapis.com/89/60/3a/04f18c4d613692/pat00011.png)

[Sketch 12](https://patentimages.storage.googleapis.com/3e/23/99/71231109abd982/pat00012.png)

![Sketch 12 for KR-20230075567-A](https://patentimages.storage.googleapis.com/3e/23/99/71231109abd982/pat00012.png)

[Sketch 13](https://patentimages.storage.googleapis.com/83/9c/94/13c3275c2fa67b/pat00013.png)

![Sketch 13 for KR-20230075567-A](https://patentimages.storage.googleapis.com/83/9c/94/13c3275c2fa67b/pat00013.png)

[Sketch 14](https://patentimages.storage.googleapis.com/22/95/88/3ba0fb7e4f969a/pat00014.png)

![Sketch 14 for KR-20230075567-A](https://patentimages.storage.googleapis.com/22/95/88/3ba0fb7e4f969a/pat00014.png)

[Sketch 15](https://patentimages.storage.googleapis.com/e4/87/b0/8e18c167a6c729/pat00015.png)

![Sketch 15 for KR-20230075567-A](https://patentimages.storage.googleapis.com/e4/87/b0/8e18c167a6c729/pat00015.png)

[Sketch 16](https://patentimages.storage.googleapis.com/0a/c7/ec/5e300646aa150b/pat00016.png)

![Sketch 16 for KR-20230075567-A](https://patentimages.storage.googleapis.com/0a/c7/ec/5e300646aa150b/pat00016.png)

[Sketch 17](https://patentimages.storage.googleapis.com/a9/9f/dd/b26a3eca8ce374/pat00017.png)

![Sketch 17 for KR-20230075567-A](https://patentimages.storage.googleapis.com/a9/9f/dd/b26a3eca8ce374/pat00017.png)

[Sketch 18](https://patentimages.storage.googleapis.com/7a/12/7a/7f4e3de35c3fb2/pat00018.png)

![Sketch 18 for KR-20230075567-A](https://patentimages.storage.googleapis.com/7a/12/7a/7f4e3de35c3fb2/pat00018.png)

[Sketch 19](https://patentimages.storage.googleapis.com/5a/02/ed/f9d99f0d1946b8/pat00019.png)

![Sketch 19 for KR-20230075567-A](https://patentimages.storage.googleapis.com/5a/02/ed/f9d99f0d1946b8/pat00019.png)

[Sketch 20](https://patentimages.storage.googleapis.com/27/30/d6/7c3d91a2b35871/pat00020.png)

![Sketch 20 for KR-20230075567-A](https://patentimages.storage.googleapis.com/27/30/d6/7c3d91a2b35871/pat00020.png)

[Sketch 21](https://patentimages.storage.googleapis.com/7b/ec/eb/48d2b8732c5a90/pat00021.png)

![Sketch 21 for KR-20230075567-A](https://patentimages.storage.googleapis.com/7b/ec/eb/48d2b8732c5a90/pat00021.png)

[Sketch 22](https://patentimages.storage.googleapis.com/51/9b/46/e2355fab00069d/pat00022.png)

![Sketch 22 for KR-20230075567-A](https://patentimages.storage.googleapis.com/51/9b/46/e2355fab00069d/pat00022.png)

[Sketch 23](https://patentimages.storage.googleapis.com/4f/41/4e/273008366aa6bd/pat00023.png)

![Sketch 23 for KR-20230075567-A](https://patentimages.storage.googleapis.com/4f/41/4e/273008366aa6bd/pat00023.png)

[Sketch 24](https://patentimages.storage.googleapis.com/39/7e/bd/5bb4eed116d2ad/pat00024.png)

![Sketch 24 for KR-20230075567-A](https://patentimages.storage.googleapis.com/39/7e/bd/5bb4eed116d2ad/pat00024.png)

[Sketch 25](https://patentimages.storage.googleapis.com/25/16/d5/e211eb28ea8de7/pat00025.png)

![Sketch 25 for KR-20230075567-A](https://patentimages.storage.googleapis.com/25/16/d5/e211eb28ea8de7/pat00025.png)

[Sketch 26](https://patentimages.storage.googleapis.com/0c/c2/8c/2dea6c0510e5f9/pat00026.png)

![Sketch 26 for KR-20230075567-A](https://patentimages.storage.googleapis.com/0c/c2/8c/2dea6c0510e5f9/pat00026.png)

[Sketch 27](https://patentimages.storage.googleapis.com/b5/4c/37/6a2711dc7f6042/pat00027.png)

![Sketch 27 for KR-20230075567-A](https://patentimages.storage.googleapis.com/b5/4c/37/6a2711dc7f6042/pat00027.png)

[Sketch 28](https://patentimages.storage.googleapis.com/b8/71/49/1a1f44234c6514/pat00028.png)

![Sketch 28 for KR-20230075567-A](https://patentimages.storage.googleapis.com/b8/71/49/1a1f44234c6514/pat00028.png)

## Claims

### Claim 1 (independent)

Claims (19)

### Claim 2 (independent)

Translated from Korean

### Claim 3 (independent)

ëìì²´ë¥¼ ì§ì§íë ì§ì§ë;

### Claim 4 (independent)

ë³µìì ì 1 ìì©ë©´ì ê°ê³ ìê¸°ì ì¸ ê²½ë¡ë¥¼ ì ê³µ ê°ë¥í ì 1 í´í¼ì¤ì, ìê¸° ì 1 í´í¼ì¤ì ê°ê¸´ ì 1 ì½ì¼ì êµ¬ë¹í ì 1 í´í¼ì¤ ì´ì

### Claim 5 (independent)

ë¸ë¦¬;

### Claim 6 (independent)

ìê¸° ì 1 í´í¼ì¤ ì´ì

### Claim 7 (independent)

ë¸ë¦¬ì ì´ê²©ëë©°, ë³µìì ì 2 ìì©ë©´ì ê°ê³ ìê¸°ì ì¸ ê²½ë¡ë¥¼ ì ê³µ ê°ë¥í ì 2 í´í¼ì¤ì, ìê¸° ì 2 í´í¼ì¤ì ê°ê¸´ ì 2 ì½ì¼ì êµ¬ë¹í ì 2 í´í¼ì¤ ì´ì

### Claim 8 (independent)

ë¸ë¦¬; ë°

### Claim 9 (independent)

ìê¸° ì 1 í´í¼ì¤ ì´ì

### Claim 10 (independent)

ë¸ë¦¬ì ìê¸° ì 2 í´í¼ì¤ ì´ì

### Claim 11 (independent)

ë¸ë¦¬ ì¬ì´ì ì´ë ê°ë¥íê² ë°°ì¹ëë í´ë¨í;ë¥¼ í¬í¨íê³ ,

### Claim 12 (independent)

ìê¸° í´ë¨íë, ìê¸° ì 1 ì½ì¼ ë° ìê¸° ì 2 ì½ì¼ì ì¸ê°ëë ì ë¥ì ì ì´ì ìí´, ìê¸° ë³µìì ì 1 ìì©ë©´ì ì ì´íê±°ë ìê¸° ë³µìì ì 2 ìì©ë©´ì ì ì´íë©´ì ìê¸° ì§ì§ëì ì§ì§ë ìê¸° ëìì²´ë¥¼ í´ë¨ííê±°ë ìê¸° ëìì²´ì ëí í´ë¨íì í´ì íë í´ë¨í ì¥ì¹.a support for supporting an object;

### Claim 13 (independent)

a first pole piece assembly comprising a first pole piece having a plurality of first acting surfaces and capable of providing a magnetic path, and a first coil wound around the first pole piece;

### Claim 14 (independent)

a second pole piece assembly spaced apart from the first pole piece assembly, including a second pole piece having a plurality of second acting surfaces and capable of providing a magnetic path, and a second coil wound around the second pole piece; and

### Claim 15 (independent)

A clamp movably disposed between the first pole piece assembly and the second pole piece assembly;

### Claim 16 (independent)

The clamp is in contact with the plurality of first acting surfaces or the plurality of second acting surfaces by controlling the current applied to the first coil and the second coil, while holding the object supported by the support. A clamping device for clamping or releasing the clamping of the object.

### Claim 17 (independent)

ì²­êµ¬í­ 1ì ìì´ì,

### Claim 18 (independent)

ìê¸° í´ë¨íë, ìê¸° ë³µìì ì 1 ìì©ë©´ì ì ì´íì¬ ìê¸° ì 1 í´í¼ì¤ ì´ì

### Claim 19 (independent)

ë¸ë¦¬ì ìê¸° íë£¨íë¥¼ íì±íê±°ë ìê¸° ë³µìì ì 2 ìì©ë©´ì ì ì´íì¬ ìê¸° ì 2 í´í¼ì¤ ì´ì

### Claim 20

ë¸ë¦¬ì ìê¸° íë£¨íë¥¼ íì±íë í´ë¨í ì¥ì¹The method of claim 1,

### Claim 21 (independent)

The clamp contacts the plurality of first acting surfaces to form a magnetic closed loop with the first pole piece assembly or contacts the plurality of second acting surfaces to form a magnetic closed loop with the second pole piece assembly. clamping device

### Claim 22 (independent)

ì²­êµ¬í­ 2ì ìì´ì,

### Claim 23 (independent)

ìê¸° í´ë¨íë,

### Claim 24 (independent)

ìê¸° ì 1 ìì©ë©´ ëë ìê¸° ì 2 ìì©ë©´ì ì ì´ ê°ë¥íë©°, ìê¸°ì ì¸ ê²½ë¡ë¥¼ ì ê³µíë ë³µìì ìì±ì²´;

### Claim 25 (independent)

ìê¸° ë³µìì ìì±ì²´ ì¬ì´ì ë°°ì¹ëê³ , ìê¸° ì 1 í´í¼ì¤ í¹ì ìê¸° ì 2 í´í¼ì¤ì ìê¸° íë£¨íë¥¼ íì±íë ë©ì¸ ìêµ¬ìì; ë°

### Claim 26

ìê¸° ë³µìì ìì±ì²´ì ì°ê²°ëê³ , ìê¸° ë³µìì ìì±ì²´ì ì´ëì ëìíì¬ ìê¸° ëìì²´ë¥¼ ê°ìíë ê°ìì²´;ë¥¼ í¬í¨íë í´ë¨í ì¥ì¹.The method of claim 2,

### Claim 27 (independent)

The clamp,

### Claim 28 (independent)

a plurality of magnetic bodies capable of contacting the first acting surface or the second acting surface and providing a magnetic path;

### Claim 29 (independent)

a main permanent magnet disposed between the plurality of magnetic bodies and forming a closed magnetic loop with the first pole piece or the second pole piece; and

### Claim 30 (independent)

Clamping device comprising a; pressurizing body connected to the plurality of magnetic bodies and pressurizing the target object in response to the movement of the plurality of magnetic bodies.

### Claim 31 (independent)

ì²­êµ¬í­ 3ì ìì´ì,

### Claim 32 (independent)

ìê¸° ê°ìì²´ë,

### Claim 33 (independent)

ìê¸° ì§ì§ëì íì  ê°ë¥íê² ê²°í©ëë ì§ì§ë¡ë; ë°

### Claim 34 (independent)

ìê¸° ì§ì§ë¡ëì ì¼ì¸¡ë©´ìì ëì¶ëë ê°ìëê¸°;ë¥¼ í¬í¨íê³ ,

### Claim 35

ìê¸° ê°ìëê¸°ì íë¨ë¶ì ìê¸° ì§ì§ëì ìë¨ë¶ ì¬ì´ì ê°ê²©ì, ìê¸° ëìì²´ì ëê» ì´íì ê¸¸ì´ë¡ íì±ëë í´ë¨í ì¥ì¹.The method of claim 3,

### Claim 36 (independent)

The pressure body,

### Claim 37 (independent)

a support rod rotatably coupled to the support; and

### Claim 38 (independent)

Including; a pressing protrusion protruding from one side of the support rod,

### Claim 39 (independent)

The clamping device wherein the gap between the lower end of the pressing protrusion and the upper end of the support is formed to a length less than or equal to the thickness of the object.

### Claim 40 (independent)

ì²­êµ¬í­ 4ì ìì´ì,

### Claim 41

ìê¸° í´ë¨íë, ìê¸° ì 1 í´í¼ì¤ì ìê¸° íë£¨íë¥¼ íì±íë©° ìê³ë°©í¥ì¼ë¡ íì íê±°ë, ìê¸° ì 2 í´í¼ì¤ì ìê¸° íë£¨íë¥¼ íì±íë©° ë°ìê³ë°©í¥ì¼ë¡ íì  ê°ë¥í í´ë¨í ì¥ì¹. The method of claim 4,

### Claim 42 (independent)

The clamp is capable of rotating clockwise while forming a magnetic closed loop with the first pole piece, or rotating counterclockwise while forming a magnetic closed loop with the second pole piece.

### Claim 43 (independent)

ì²­êµ¬í­ 3ì ìì´ì,

### Claim 44

ìê¸° í´ë¨íë, ìê¸° ì 1 í´í¼ì¤ì ìê¸° íë£¨íë¥¼ íì±íë©° ìê¸° ì 1 ìì©ë©´ì í¥í´ ì¬ë¼ì´ë© ì´ëíê±°ë, ìê¸° ì 2 í´í¼ì¤ì ìê¸° íë£¨íë¥¼ íì±íë©° ìê¸° ì 2 ìì©ë©´ì í¥íì¬ ì¬ë¼ì´ë© ì´ë ê°ë¥í í´ë¨í ì¥ì¹. The method of claim 3,

### Claim 45 (independent)

The clamp forms a magnetic closed loop with the first pole piece and slides toward the first acting surface, or forms a magnetic closed loop with the second pole piece and slides toward the second acting surface. Device.

### Claim 46 (independent)

ì²­êµ¬í­ 6ì ìì´ì,

### Claim 47 (independent)

ìê¸° í´ë¨íë, ìì¸¡ë¨ì´ ê°ê° ìê¸° ì 1 í´í¼ì¤ì ìê¸° ì 2 í´í¼ì¤ì ì°ê²°ëë ë ì¼;ì ë í¬í¨íê³ ,

### Claim 48

ìê¸° ë³µìì ìì±ì²´ë, ìê¸° ë ì¼ì ì´ë ê°ë¥íê² ê²°í©ëë í´ë¨í ì¥ì¹.The method of claim 6,

### Claim 49 (independent)

The clamp further includes a rail having both ends connected to the first pole piece and the second pole piece, respectively,

### Claim 50 (independent)

The plurality of magnetic bodies are clamping devices movably coupled to the rail.

### Claim 51 (independent)

ì²­êµ¬í­ 7ì ìì´ì,

### Claim 52 (independent)

ìê¸° ê°ìì²´ë,

### Claim 53 (independent)

ìê¸° ë³µìì ìì±ì²´ì ê²°í©ëë©°, ìê¸° ì§ì§ëì ë´ë¶ì ì´ë ê°ë¥íê² ì½ì

### Claim 54 (independent)

ëë ì§ì§ë¡ë; ë°

### Claim 55 (independent)

ìê¸° ì§ì§ë¡ëì ì¼ì¸¡ë©´ìì íí¥ ê²½ì¬ì§ê² ëì¶ëë ê°ìëê¸°;ë¥¼ í¬í¨íê³ ,

### Claim 56

ìê¸° ê°ìëê¸°ì íë¨ë¶ì ìê¸° ì§ì§ëì ìë¨ë¶ ì¬ì´ì ê°ê²©ì, ìê¸° ëìì²´ì ëê»ì ëìëë ê¸¸ì´ë¡ íì±ëë í´ë¨í ì¥ì¹.The method of claim 7,

### Claim 57 (independent)

The pressure body,

### Claim 58 (independent)

a support rod coupled to the plurality of magnetic bodies and movably inserted into the support; and

### Claim 59 (independent)

Including; a pressure protrusion protruding obliquely downward from one side of the support rod,

### Claim 60 (independent)

A gap between the lower end of the pressing protrusion and the upper end of the support is formed to a length corresponding to the thickness of the object.

### Claim 61 (independent)

ì²­êµ¬í­ 3ì ìì´ì,

### Claim 62 (independent)

ìê¸° ì 2 í´í¼ì¤ë,

### Claim 63 (independent)

ì¸¡ë¶ê° ìê¸° ì 2 ìì©ë©´ì¸ ì 1 ë°ë;

### Claim 64 (independent)

ìê¸° ì 1 ë°ëìì ì°ì¥ëê³ , ìê¸° ì 2 ì½ì¼ì´ ê°ê¸°ë ì 2 ë°ë; ë°

### Claim 65 (independent)

ìê¸° ì 2 ë°ëìì ìê¸° ì 1 ë°ëì ëëíê² ì°ì¥ëê³ , ìê¸° ì 1 ë°ëë³´ë¤ ìê¸° ì§ì§ëì ê°ê¹ê² ë°°ì¹ëë©°, ì¸¡ë¶ê° ìê¸° ì 2 ìì©ë©´ì¸ ì 3 ë°ë;ë¥¼ í¬í¨íë©°,

### Claim 66

ìê¸° ì 3 ë°ëë, ìê¸° ì 1 ë°ëì ê¸¸ì´ë³´ë¤ ê¸¸ê² íì±ëë í´ë¨í ì¥ì¹.The method of claim 3,

### Claim 67 (independent)

The second pole piece,

### Claim 68 (independent)

a first body whose side portion is the second acting surface;

### Claim 69 (independent)

a second body extending from the first body and around which the second coil is wound; and

### Claim 70 (independent)

A third body extending parallel to the first body from the second body, disposed closer to the support than the first body, and having a side portion of the second acting surface;

### Claim 71 (independent)

The clamping device of the third body is formed longer than the length of the first body.

### Claim 72 (independent)

ì²­êµ¬í­ 9ì ìì´ì,

### Claim 73 (independent)

ìê¸° ì 1 ë°ëì ìê¸° ì 3 ë°ëë, ê°ê°ì ìê¸° ì 2 ìì©ë©´ì´ ìí¥ ê²½ì¬ì§ í

### Claim 74

ì´í¼ë©´ì¼ë¡ íì±ëë í´ë¨í ì¥ì¹.The method of claim 9,

### Claim 75 (independent)

The clamping device of the first body and the third body, wherein each of the second acting surfaces is formed as an upwardly inclined tapered surface.

### Claim 76 (independent)

ì²­êµ¬í­ 3 ë´ì§ ì²­êµ¬í­ 8 ì¤ ì´ë í í­ì ìì´ì,

### Claim 77 (independent)

ìê¸° ì 1 í´í¼ì¤ ì´ì

### Claim 78 (independent)

ë¸ë¦¬ë,

### Claim 79 (independent)

ì 1 ë³´ì¡°ìì©ë©´ì ê°ê³ ìê¸° ì 1 í´í¼ì¤ì ëí¥ëë©°, ìê¸° ì 1 í´í¼ì¤ë³´ë¤ ìê¸° ì§ì§ëì ë ê°ê¹ê² ë°°ì¹ëë ì 1 ë³´ì¡°í´í¼ì¤;

### Claim 80 (independent)

ìê¸° ì 1 í´í¼ì¤ì ìê¸° ì 1 ë³´ì¡°í´í¼ì¤ì ê²°í©ëë ì 1 ê³ ì  ìêµ¬ìì; ë°

### Claim 81

ìê¸° ì 1 í´í¼ì¤ì ìê¸° ì 1 ë³´ì¡°í´í¼ì¤ ì¬ì´ì ë°°ì¹ëê³ , ìê¸° ì 1 ì½ì¼ì íë¥´ë ì ë¥ì ìí´ íì  ê°ë¥í ì 1 íì  ìêµ¬ìì;ì ë í¬í¨íë í´ë¨í ì¥ì¹.The method according to any one of claims 3 to 8,

### Claim 82 (independent)

The first pole piece assembly,

### Claim 83 (independent)

a first auxiliary pole piece having a first auxiliary action surface, facing the first pole piece, and disposed closer to the support than the first pole piece;

### Claim 84 (independent)

a first fixed permanent magnet coupled to the first pole piece and the first auxiliary pole piece; and

### Claim 85 (independent)

The clamping device further includes a first rotating permanent magnet disposed between the first pole piece and the first auxiliary pole piece and rotatable by a current flowing through the first coil.

### Claim 86 (independent)

ì²­êµ¬í­ 11ì ìì´ì,

### Claim 87 (independent)

ìê¸° ì 2 í´í¼ì¤ ì´ì

### Claim 88 (independent)

ë¸ë¦¬ë,

### Claim 89 (independent)

ì 2 ë³´ì¡°ìì©ë©´ì ê°ê³ ìê¸° ì 2 í´í¼ì¤ì ëí¥ëë©° ìê¸° ì 2 í´í¼ì¤ë³´ë¤ ìê¸° ì§ì§ëì ë ê°ê¹ê² ë°°ì¹ëë ì 2 ë³´ì¡°í´í¼ì¤;

### Claim 90 (independent)

ìê¸° ì 2 í´í¼ì¤ì ìê¸° ì 2 ë³´ì¡°í´í¼ì¤ì ê²°í©ëë ì 2 ê³ ì  ìêµ¬ìì; ë°

### Claim 91

ìê¸° ì 2 í´í¼ì¤ì ìê¸° ì 2 ë³´ì¡°í´í¼ì¤ ì¬ì´ì ë°°ì¹ëê³ , ìê¸° ì 2 ì½ì¼ì íë¥´ë ì ë¥ì ìí´ íì  ê°ë¥í ì 2 íì  ìêµ¬ìì;ì ë í¬í¨íë í´ë¨í ì¥ì¹.The method of claim 11,

### Claim 92 (independent)

The second pole piece assembly,

### Claim 93 (independent)

a second auxiliary pole piece that has a second auxiliary action surface, is opposed to the second pole piece, and is disposed closer to the support than the second pole piece;

### Claim 94 (independent)

a second fixed permanent magnet coupled to the second pole piece and the second auxiliary pole piece; and

### Claim 95 (independent)

The clamping device further includes a second rotating permanent magnet disposed between the second pole piece and the second auxiliary pole piece and rotatable by a current flowing through the second coil.

### Claim 96 (independent)

ì²­êµ¬í­ 12ì ìì´ì,

### Claim 97 (independent)

ìê¸° ì 2 ë³´ì¡°í´í¼ì¤ë, ìê¸° ì 2 í´í¼ì¤ë³´ë¤ ë ê¸´ ê¸¸ì´ë¥¼ ê°ì§ë©°,

### Claim 98 (independent)

ìê¸° ì 2 ìì©ë©´ê³¼ ìê¸° ì 2 ë³´ì¡°ìì©ë©´ì, ê°ê° ìí¥ ê²½ì¬ì§ í

### Claim 99

ì´í¼ë©´ì¼ë¡ íì±ëë í´ë¨í ì¥ì¹.The method of claim 12,

### Claim 100 (independent)

The second auxiliary pole piece has a longer length than the second pole piece,

### Claim 101 (independent)

The second acting surface and the second auxiliary acting surface are each formed as an upwardly inclined tapered surface.

### Claim 102 (independent)

ì²­êµ¬í­ 11ì ìì´ì,

### Claim 103 (independent)

ìê¸° í´ë¨íë, ìì¸¡ë¨ì´ ê°ê° ìê¸° ì 1 ë³´ì¡°í´í¼ì¤ì ìê¸° ì 2 ë³´ì¡°í´í¼ì¤ì ì°ê²°ëë ë³´ì¡°ë ì¼;ì ë í¬í¨íê³ ,

### Claim 104

ìê¸° ë³µìì ìì±ì²´ë, ê°ê°ì´ ìê¸° ë ì¼ ë° ìê¸° ë³´ì¡°ë ì¼ì ì íì§ ì´ë ê°ë¥íê² ê²°í©ëë í´ë¨í ì¥ì¹.The method of claim 11,

### Claim 105 (independent)

The clamp further includes an auxiliary rail having both ends connected to the first auxiliary pole piece and the second auxiliary pole piece, respectively,

### Claim 106 (independent)

The plurality of magnetic bodies, each clamping device coupled to the forward and backward movement to the rail and the auxiliary rail.

### Claim 107 (independent)

ëìì²´ê° ìì°© ê°ë¥í ì§ì§ë;

### Claim 108 (independent)

ìì©ë©´ì ê°ë í´í¼ì¤ë¤ê³¼, ìê¸° í´í¼ì¤ë¤ ì¤ ì ì´ë ì´ë íëì ê°ê¸°ë ì½ì¼ê³¼, ìê¸° í´í¼ì¤ë¤ ì¬ì´ì ê³ ì ëë ê³ ì ììê³¼, ìê¸° í´í¼ì¤ë¤ ì¬ì´ì ë°°ì¹ëê³ ìê¸° ì½ì¼ì íë¥´ë ì ë¥ì ìí´ íì  ê°ë¥í íì ììì êµ¬ë¹í ìê¸°ë ¥ ì ì´ëª¨ë;

### Claim 109 (independent)

ì ì´ë ì¼ë¶ê° ìê¸° ì§ì§ëì ë´ë¶ì ì´ë ê°ë¥íê² ë°°ì¹ëë í´ë¨í; ë°

### Claim 110 (independent)

ìê¸° í´ë¨íë¥¼ íì± ë°ì´ì´ì¤ìí¤ë íì±ë ¥ ì ì´ëª¨ë;ì í¬í¨íê³ ,

### Claim 111 (independent)

ìê¸° í´ë¨íë, ìê¸° ì½ì¼ì ì¸ê°ëë ì ë¥ì ì ì´ì ìí´, ìê¸° í´í¼ì¤ë¤ê³¼ ìê¸° íë£¨íë¥¼ íì±íë©° ì 1 ë°©í¥ì¼ë¡ ì´ëíê±°ë, ìê¸° ìê¸° íë£¨í í´ì ì ìê¸° íì±ë ¥ ì ì´ëª¨ëì íì±ë ¥ì ìí´ ìê¸° ì 1 ë°©í¥ê³¼ ë°ëëë ì 2 ë°©í¥ì¼ë¡ ë¹ê²¨ì§ëë¡ êµ¬ì±ëë í´ë¨í ì¥ì¹.a support on which a subject can be seated;

### Claim 112 (independent)

pole pieces having a working surface, a coil wound around at least one of the pole pieces, a stationary magnet fixed between the pole pieces, and a current disposed between the pole pieces and flowing through the coil Magnetic force control module having a rotatable rotating magnet;

### Claim 113 (independent)

At least a portion of the clamp movably disposed inside the support; and

### Claim 114 (independent)

Including; elastic force control module for elastically biasing the clamp;

### Claim 115 (independent)

The clamp forms a magnetic closed loop with the pole pieces by control of the current applied to the coil and moves in a first direction, or when the magnetic closed loop is released, the first clamp is moved in the first direction by the elastic force of the elastic force control module. A clamping device configured to be pulled in a second direction opposite to the direction.

### Claim 116 (independent)

ì²­êµ¬í­ 15ì ìì´ì,

### Claim 117 (independent)

ìê¸° íì±ë ¥ ì ì´ëª¨ëì, ìê¸° ì§ì§ëì íë¶ì ë°°ì¹ëê³ ê²½ì¬ë©´ì ê°ë ì§ì§ì²´ì, ì¼ë¨ì´ ìê¸° ì§ì§ì²´ì ê²½ì¬ë©´ì ì°ê²°ëê³ íë¨ì´ ìê¸° í´ë¨íì ê²°í©ëë©° ì ì¥ ìì¶ ê°ë¥í íì±ì²´ë¥¼ í¬í¨íê³ ,

### Claim 118

ìê¸° í´ë¨íë, ìê¸° í´í¼ì¤ë¤ê³¼ ìê¸° íë£¨íë¥¼ íì±íë©° ìê³ë°©í¥ì¼ë¡ íì íê±°ë, ìê¸° íë£¨í í´ì ì ìê¸° íì±ë ¥ ì ì´ëª¨ëì íì±ë ¥ì ìí´ ë°ìê³ë°©í¥ì¼ë¡ íì íë í´ë¨í ì¥ì¹. The method of claim 15

### Claim 119 (independent)

The elastic force control module includes a support disposed below the support and having an inclined surface, and an elastic body having one end connected to the inclined surface of the support and the other end coupled to the clamp and capable of being stretched and contracted,

### Claim 120 (independent)

The clamp forms a magnetic closed loop with the pole pieces and rotates clockwise, or rotates counterclockwise by the elastic force of the elastic force control module when the magnetic closed loop is released.

### Claim 121 (independent)

ì²­êµ¬í­ 16ì ìì´ì,

### Claim 122 (independent)

ìê¸° íì±ë ¥ ì ì´ëª¨ëì, ìê¸° ì§ì§ëì íë¶ì ë°°ì¹ëë ì§ì§ì²´ì, ì¼ë¨ì´ ìê¸° ì§ì§ì²´ì ê²°í©ëê³ íë¨ì´ ìê¸° í´í¼ì¤ë¤ì ê²°í©ëë ë ì¼ê³¼, ì¼ë¨ì´ ìê¸° ì§ì§ì²´ì ê³ ì ëê³ íë¨ì´ ìê¸° í´ë¨íì ê²°í©ëë©° ì ì¥ ìì¶ ê°ë¥í íì±ì²´ë¥¼ í¬í¨íê³ ,

### Claim 123

ìê¸° í´ë¨íë, ìê¸° ë ì¼ì ì íì§ ì´ë ê°ë¥íê² ê²°í©ëë©°, ìê¸° í´í¼ì¤ë¤ê³¼ ìê¸° íë£¨íë¥¼ íì±íë©° ìê¸° ìì©ë©´ì í¥íë ë°©í¥ì¼ë¡ ì¬ë¼ì´ë© ì´ëíê±°ë, ìê¸° íë£¨í í´ì ì ìê¸° íì±ë ¥ ì ì´ëª¨ëì íì±ë ¥ì ìí´ ìê¸° ì§ì§ì²´ë¥¼ í¥íë ë°©í¥ì¼ë¡ ì¬ë¼ì´ë© ì´ëíë í´ë¨í ì¥ì¹. The method of claim 16

### Claim 124 (independent)

The elastic force control module includes a support body disposed below the support body, a rail having one end coupled to the support body and the other end coupled to the pole pieces, one end fixed to the support body and the other end coupled to the clamp, and elongation. Including a retractable elastic body,

### Claim 125 (independent)

The clamp is coupled to the rail to be able to move forward and backward, and forms a magnetic closed loop with the pole pieces and slides in a direction toward the working surface, or when the magnetic closed loop is released, by the elastic force of the elastic force control module. A clamping device that slides in a direction toward the support.

### Claim 126 (independent)

ëìì²´ë¥¼ í´ë¨ííë ì¥ì¹ë¡ì,

### Claim 127 (independent)

ê°ê° ìì©ë©´ì ê°ë ë³µìì í´í¼ì¤;

### Claim 128 (independent)

ìê¸° ë³µìì í´í¼ì¤ ì¤ ì ì´ë ì´ë íëì ê°ê¸°ë ì½ì¼;

### Claim 129 (independent)

ìê¸° ë³µìì í´í¼ì¤ ì¬ì´ì ê³ ì ëë ê³ ì ìì;

### Claim 130 (independent)

ìê¸° ë³µìì í´í¼ì¤ ì¬ì´ìì ìê¸° ê³ ì ììê³¼ ì´ê²© ë°°ì¹ëê³ , ìê¸° ì½ì¼ì íë¥´ë ì ë¥ì ì ì´ì ìí´ íì  ê°ë¥í íì ìì; ë°

### Claim 131 (independent)

ìê¸° ë³µìì í´í¼ì¤ ì¬ì´ì ë°°ì¹ëê³ , ìê¸° ì½ì¼ì ì¸ê°ëë ì ë¥ì ì ì´ ìí´ ê°ê°ì ìê¸° ìì©ë©´ì ì ì´í ìê¸° ëìì²´ì ë´ë¶ë¡ ì½ì

### Claim 132 (independent)

ê°ë¥í ì½ì

### Claim 133 (independent)

ëê¸°ë¥¼ êµ¬ë¹íë ê³ ì ë;ë¥¼ í¬í¨íë í´ë¨í ì¥ì¹.As a device for clamping an object,

### Claim 134 (independent)

a plurality of pole pieces each having a working surface;

### Claim 135 (independent)

a coil wound around at least one of the plurality of pole pieces;

### Claim 136 (independent)

a fixed magnet fixed between the plurality of pole pieces;

### Claim 137 (independent)

a rotating magnet spaced apart from the stationary magnet between the plurality of pole pieces and rotatable by controlling current flowing through the coil; and

### Claim 138 (independent)

A clamping device comprising: a fixing table disposed between the plurality of pole pieces and having an insertion protrusion insertable into the target object in contact with each of the working surfaces by controlling a current applied to the coil.

### Claim 139 (independent)

ì²­êµ¬í­ 18ì ìì´ì,

### Claim 140 (independent)

ìê¸° ì½ì

### Claim 141 (independent)

ëê¸°ë, ìê¸° ëìì²´ì ì¤ì¬ë¶ë¥¼ ê´íµíë ê´íµíì ì½ì

### Claim 142

ëë í´ë¨í ì¥ì¹.The method of claim 18

### Claim 143 (independent)

The insertion protrusion is a clamping device that is inserted into a through hole penetrating the center of the object.

## Full description

**[p0001]**

ELECTRICITYELECTRIC ELEMENTSMAGNETS; INDUCTANCES; TRANSFORMERS; SELECTION OF MATERIALS FOR THEIR MAGNETIC PROPERTIESMagnetsPermanent magnets [PM]Magnetic circuits with PM for power or force generationPM holding devicesPERFORMING OPERATIONS; TRANSPORTINGMACHINE TOOLS; METAL-WORKING NOT OTHERWISE PROVIDED FORDETAILS, COMPONENTS, OR ACCESSORIES FOR MACHINE TOOLS, e.g. ARRANGEMENTS FOR COPYING OR CONTROLLING; MACHINE TOOLS IN GENERAL CHARACTERISED BY THE CONSTRUCTION OF PARTICULAR DETAILS OR COMPONENTS; COMBINATIONS OR ASSOCIATIONS OF METAL-WORKING MACHINES, NOT DIRECTED TO A PARTICULAR RESULTDevices holding, supporting, or positioning work or tools, of a kind normally removable from the machineDevices for holding work using magnetic or electric force acting directly on the workStationary devicesStationary devices using permanent magnetsPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by magnetic meansELECTRICITYELECTRIC ELEMENTSMAGNETS; INDUCTANCES; TRANSFORMERS; SELECTION OF MATERIALS FOR THEIR MAGNETIC PROPERTIESMagnetsPermanent magnets [PM]Means for releasing the attractive force

**[p0002]**

Description Translated from Korean í´ë¨í ì¥ì¹{Clamping device}Clamping device {Clamping device} ë³¸ ë°ëª ì í´ë¨í ì¥ì¹ì ê´í ê²ì¼ë¡, ëì± ìì¸íê²ë ìê¸°ë ¥ì ì ì´íì¬ ëìì²´ë¥¼ ì§ì§í ì ìë í´ë¨í ì¥ì¹ì ê´í ê²ì´ë¤.The present invention relates to a clamping device, and more particularly, to a clamping device capable of supporting an object by controlling a magnetic force. ìêµ¬ìì ìí¬íë© ì¥ì¹(permanent magnet work-holding device)ì ê°ì ìì±ì²´ë¥¼ ì´ì©í í´ë¨í ì¥ì¹ë ì² ê³¼ ê°ì ìì± ë¬¼ì§(magnetic material)ë¡ êµ¬ì±ë ë¶ì°© ëìì²´ë¥¼ ìê¸°ë ¥ì ì´ì©íì¬ ë¶ì°©ìí¤ëë° ì¬ì©ëë ì¥ì¹ë¡ì, ì¬ì¶ê¸°ì ê¸í í´ë¨í, íë ì¤ê¸°ì ê¸í í´ë¨í, ê³µì ê¸°ê³ì ì² ë±ì ë¶ì°©ëë ë´ë¶ ì¥ì¹ ë±ì¼ë¡ ëë¦¬ ì¬ì©ëê³ ìë¤.A clamping device using a magnetic material, such as a permanent magnet work-holding device, is a device used to attach an attachment object made of a magnetic material such as iron using magnetic force, and is used for clamping a mold of an injection molding machine. , mold clamping of press machines, internal devices attached to chucks of machine tools, etc. are widely used.

**[p0003]**

ì´ë¬í ìì±ì²´ë¥¼ ì´ì©í í´ë¨í ì¥ì¹ë, í´ë¨í ììë ìêµ¬ììì ê°í ìê¸°ë ¥ì ì´ì©íì¬ ìì±ì²´ì¸ ë¶ì°© ëìì²´ë¥¼ ìì©ë©´ì ë¶ì°©ìí¤ê³ , í´ë¨íì í´ì í ììë ìì©ë©´ì¼ë¡ ìêµ¬ììì ìê¸° íë¦ì´ íì±ëì§ ìëë¡ íì¬ ë¶ì°© ëìì²´ë¥¼ ìì©ë©´ì¼ë¡ë¶í° ë¨ì´ë¨ë¦°ë¤.In the clamping device using such a magnetic material, when clamping, the magnetic object to be attached is attached to the working surface by using the strong magnetic force of the permanent magnet, and when releasing the clamping, the magnetic flow of the permanent magnet is not formed on the working surface. Move the object away from the working surface. ì¢ ëì ìì±ì²´ë¥¼ ì´ì©í í´ë¨í ì¥ì¹ë ìêµ¬ììì íì ì ìí´ ì¥ì¹ ë´ë¶ì ìê¸° íë¦ì ë³ê²½íì¬, ë¶ì°© ëìì²´ë¥¼ íë©(ì¦, í´ë¨í)íê±°ë í¹ì ë¶ì°© ëìì í´ë¨íì í´ì íìë¤.A clamping device using a conventional magnetic material changes the magnetic flow inside the device by rotation of a permanent magnet to hold (ie, clamp) an object to be attached or release the clamping of the object to be attached.

**[p0004]**

íì§ë§, ì¢ ëì ìì±ì²´ë¥¼ ì´ì©í í´ë¨í ì¥ì¹ë ê·¸ ìíì ê¸¸ì´ê° ìëì ì¼ë¡ ê¸¸ê² íì±ëë ë¬¸ì ê° ìë¤. ì¦, ìì±ì²´ë¥¼ ì´ì©í í´ë¨í ì¥ì¹ì í¬ê¸°ê° ì ì²´ì ì¼ë¡ í¬ê² íì±ëë ë¬¸ì ê° ìë¤. ì´ì, ì¢ ëì ìì±ì²´ë¥¼ ì´ì©í í´ë¨í ì¥ì¹ë ì¤ì¹ ê³µê°ì ëì´ê° íìí êµ¬ì¡° ë±ìë ì ì©ì´ ë ì ìë ë±, ì¢ ëì ìì±ì²´ë¥¼ ì´ì©í í´ë¨í ì¥ì¹ê° ì ì©ë ì ìë êµ¬ì¡°ê° ê³µê°ì ì¼ë¡ í¬ê² ì íëë ë¬¸ì ê° ìë¤.However, the clamping device using a conventional magnetic material has a problem in that the upper and lower lengths are relatively long. That is, there is a problem in that the size of the clamping device using the magnetic material is formed to be large as a whole. Accordingly, there is a problem in that a structure to which a conventional clamping device using a magnetic material can be applied is greatly limited in space, such as that the clamping device using a conventional magnetic material cannot be applied to a structure having a narrow height of an installation space.

**[p0005]**

ëí, ì¢ ëì ìì±ì²´ë¥¼ ì´ì©í í´ë¨í ì¥ì¹ë ë¶ì°© ëìì²´ë¥¼ ìì©ë©´ì ì§ì  ë¶ì°©íì¬ í´ë¨ííë¯ë¡, ë¶ì°© ëìì²´ì ìì©ë©´ ì¬ì´ì ê³µê¸° ì¤ ë¶ì íë ë¯¸ì¸ë¨¼ì§ê° ì½ì ë ê²½ì°, ê·¸ ë¶ì°©ë ¥ì´ ì½íëë ë¬¸ì ê° ìë¤. In addition, since the clamping device using a conventional magnetic material directly attaches and clamps the attachment object to the working surface, when fine dust floating in the air is inserted between the attachment object and the working surface, the adhesion is weakened.

### Krkr

**[p0006]**

10-2011-0044681 10-2011-0044681 AA ë³¸ ë°ëª ì ìê¸°ì ê°ì ë¬¸ì ì ì í´ê²°íê¸° ìí ê²ì¼ë¡ì, ë¶ì°© ëìì²´ë¥¼ ì©ì´íê² ì§ì§íê±°ë ë¶ì°© ëìì²´ì ì§ì§ë¥¼ ì©ì´íê² í´ì í ì ìë í´ë¨í ì¥ì¹ë¥¼ ì ê³µíë¤. The present invention is to solve the above problems, and provides a clamping device capable of easily supporting an attachment target object or easily releasing support of an attachment target object. ëí, ëì´ê° ë®ì íìí ê³µê°ìë ì¤ì¹ë ì ìë í´ë¨í ì¥ì¹ë¥¼ ì ê³µíë¤.In addition, a clamping device that can be installed in a narrow space with a low height is provided. ìê¸° ê³¼ì ë¥¼ í´ê²°íê¸° ìí ë³¸ ë°ëª ì ì 1 ì¤ìì ë´ì§ ì 4 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ë, ëìì²´ë¥¼ ì§ì§íë ì§ì§ë; ë³µìì ì 1 ìì©ë©´ì ê°ê³ ìê¸°ì ì¸ ê²½ë¡ë¥¼ ì ê³µ ê°ë¥í ì 1 í´í¼ì¤ì, ìê¸° ì 1 í´í¼ì¤ì ê°ê¸´ ì 1 ì½ì¼ì êµ¬ë¹í ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬; ìê¸° ì 1 í´í¼ì¤ ì´ì

**[p0007]**

ë¸ë¦¬ì ì´ê²©ëë©°, ë³µìì ì 2 ìì©ë©´ì ê°ê³ ìê¸°ì ì¸ ê²½ë¡ë¥¼ ì ê³µ ê°ë¥í ì 2 í´í¼ì¤ì, ìê¸° ì 2 í´í¼ì¤ì ê°ê¸´ ì 2 ì½ì¼ì êµ¬ë¹í ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬; ë° ìê¸° ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬ì ìê¸° ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬ ì¬ì´ì ì´ë ê°ë¥íê² ë°°ì¹ëë í´ë¨í;ë¥¼ í¬í¨íê³ , ìê¸° í´ë¨íë, ìê¸° ì 1 ì½ì¼ ë° ìê¸° ì 2 ì½ì¼ì ì¸ê°ëë ì ë¥ì ì ì´ì ìí´, ìê¸° ë³µìì ì 1 ìì©ë©´ì ì ì´íê±°ë ìê¸° ë³µìì ì 2 ìì©ë©´ì ì ì´íë©´ì ìê¸° ì§ì§ëì ì§ì§ë ìê¸° ëìì²´ë¥¼ í´ë¨ííê±°ë ìê¸° ëìì²´ì ëí í´ë¨íì í´ì íë¤.Clamping devices according to the first to fourth embodiments of the present invention for solving the above problems include: a support for supporting an object; a first pole piece assembly comprising a first pole piece having a plurality of first acting surfaces and capable of providing a magnetic path, and a first coil wound around the first pole piece; a second pole piece assembly spaced apart from the first pole piece assembly, including a second pole piece having a plurality of second acting surfaces and capable of providing a magnetic path, and a second coil wound around the second pole piece; and a clamp movably disposed between the first pole piece assembly and the second pole piece assembly, wherein the clamp controls the current applied to the first coil and the second coil, The object supported by the support is clamped or the clamping of the object is released while contacting the plurality

**[p0007]**

of first action surfaces or the plurality of second action surfaces.

**[p0008]**

ìê¸° í´ë¨íë, ìê¸° ë³µìì ì 1 ìì©ë©´ì ì ì´íì¬ ìê¸° ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬ì ìê¸° íë£¨íë¥¼ íì±íê±°ë ìê¸° ë³µìì ì 2 ìì©ë©´ì ì ì´íì¬ ìê¸° ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬ì ìê¸° íë£¨íë¥¼ íì±íë¤.The clamp contacts the plurality of first acting surfaces to form a magnetic closed loop with the first pole piece assembly or contacts the plurality of second acting surfaces to form a magnetic closed loop with the second pole piece assembly. . ìê¸° í´ë¨íë, ìê¸° ì 1 ìì©ë©´ ëë ìê¸° ì 2 ìì©ë©´ì ì ì´ ê°ë¥íë©°, ìê¸°ì ì¸ ê²½ë¡ë¥¼ ì ê³µíë ë³µìì ìì±ì²´; ìê¸° ë³µìì ìì±ì²´ ì¬ì´ì ë°°ì¹ëê³ , ìê¸° ì 1 í´í¼ì¤ í¹ì ìê¸° ì 2 í´í¼ì¤ì ìê¸° íë£¨íë¥¼ íì±íë ë©ì¸ ìêµ¬ìì; ë° ìê¸° ë³µìì ìì±ì²´ì ì°ê²°ëê³ , ìê¸° ë³µìì ìì±ì²´ì ì´ëì ëìíì¬ ìê¸° ëìì²´ë¥¼ ê°ìíë ê°ìì²´;ë¥¼ íë¤.The clamp may include a plurality of magnetic bodies capable of contacting the first acting surface or the second acting surface and providing a magnetic path; a main permanent magnet disposed between the plurality of magnetic bodies and forming a closed magnetic loop with the first pole piece or the second pole piece; and a pressing body connected to the plurality of magnetic bodies and pressurizing the target object in response to the movement of the plurality of magnetic bodies.

**[p0009]**

ìê¸° ê°ìì²´ë, ìê¸° ì§ì§ëì íì  ê°ë¥íê² ê²°í©ëë ì§ì§ë¡ë; ë° ìê¸° ì§ì§ë¡ëì ì¼ì¸¡ë©´ìì ëì¶ëë ê°ìëê¸°;ë¥¼ í¬í¨íê³ , ìê¸° ê°ìëê¸°ì íë¨ë¶ì ìê¸° ì§ì§ëì ìë¨ë¶ ì¬ì´ì ê°ê²©ì, ìê¸° ëìì²´ì ëê» ì´íì ê¸¸ì´ë¡ íì±ëë¤. The pressing body includes a support rod rotatably coupled to the support; and a pressing protrusion protruding from one side of the support rod, wherein a distance between a lower end of the pressing protrusion and an upper end of the support is formed to a length equal to or less than the thickness of the object. ìê¸° í´ë¨íë, ìê¸° ì 1 í´í¼ì¤ì ìê¸° íë£¨íë¥¼ íì±íë©° ìê³ë°©í¥ì¼ë¡ íì íê±°ë, ìê¸° ì 2 í´í¼ì¤ì ìê¸° íë£¨íë¥¼ íì±íë©° ë°ìê³ë°©í¥ì¼ë¡ íì  ê°ë¥íë¤. The clamp may rotate clockwise while forming a magnetic closed loop with the first pole piece, or rotate counterclockwise while forming a magnetic closed loop with the second pole piece.

**[p0010]**

ìê¸° í´ë¨íë, ìê¸° ì 1 í´í¼ì¤ì ìê¸° íë£¨íë¥¼ íì±íë©° ìê¸° ì 1 ìì©ë©´ì í¥í´ ì¬ë¼ì´ë© ì´ëíê±°ë, ìê¸° ì 2 í´í¼ì¤ì ìê¸° íë£¨íë¥¼ íì±íë©° ìê¸° ì 2 ìì©ë©´ì í¥íì¬ ì¬ë¼ì´ë© ì´ë ê°ë¥íë¤.The clamp forms a magnetic closed loop with the first pole piece and slides toward the first acting surface, or forms a magnetic closed loop with the second pole piece and slides toward the second acting surface. . ìê¸° í´ë¨íë, ìì¸¡ë¨ì´ ê°ê° ìê¸° ì 1 í´í¼ì¤ì ìê¸° ì 2 í´í¼ì¤ì ì°ê²°ëë ë ì¼;ì ë í¬í¨íê³ ,The clamp further includes a rail having both ends connected to the first pole piece and the second pole piece, respectively, ìê¸° ë³µìì ìì±ì²´ë, ìê¸° ë ì¼ì ì´ë ê°ë¥íê² ê²°í©ëë¤.The plurality of magnetic bodies are movably coupled to the rail. ìê¸° ê°ìì²´ë, ìê¸° ë³µìì ìì±ì²´ì ê²°í©ëë©°, ìê¸° ì§ì§ëì ë´ë¶ì ì´ë ê°ë¥íê² ì½ì

**[p0011]**

ëë ì§ì§ë¡ë; ë° ìê¸° ì§ì§ë¡ëì ì¼ì¸¡ë©´ìì íí¥ ê²½ì¬ì§ê² ëì¶ëë ê°ìëê¸°;ë¥¼ í¬í¨íê³ , ìê¸° ê°ìëê¸°ì íë¨ë¶ì ìê¸° ì§ì§ëì ìë¨ë¶ ì¬ì´ì ê°ê²©ì, ìê¸° ëìì²´ì ëê»ì ëìëë ê¸¸ì´ë¡ íì±ëë¤.The pressing body may include a support rod coupled to the plurality of magnetic bodies and movably inserted into the support rod; and a pressure protrusion protruding obliquely downward from one side of the support rod, wherein a distance between a lower end of the pressure protrusion and an upper end of the support is formed to a length corresponding to the thickness of the object. ìê¸° ì 2 í´í¼ì¤ë, ì¸¡ë¶ê° ìê¸° ì 2 ìì©ë©´ì¸ ì 1 ë°ë; ìê¸° ì 1 ë°ëìì ì°ì¥ëê³ , ìê¸° ì 2 ì½ì¼ì´ ê°ê¸°ë ì 2 ë°ë; ë° ìê¸° ì 2 ë°ëìì ìê¸° ì 1 ë°ëì ëëíê² ì°ì¥ëê³ , ìê¸° ì 1 ë°ëë³´ë¤ ìê¸° ì§ì§ëì ê°ê¹ê² ë°°ì¹ëë©°, ì¸¡ë¶ê° ìê¸° ì 2 ìì©ë©´ì¸ ì 3 ë°ë;ë¥¼ í¬í¨íë©°, ìê¸° ì 3 ë°ëë, ìê¸° ì 1 ë°ëì ê¸¸ì´ë³´ë¤ ê¸¸ê² íì±ëë¤. The second pole piece may include a first body whose side is the second acting surface; a second body extending from the first body and around which the second coil is wound; And a third body extending parallel to the first body from the second body, disposed closer to the support than the first body, and having a side portion of the second acting surface, wherein the third body includes, It is formed longer than the length of the first body.

**[p0012]**

ìê¸° ì 1 ë°ëì ìê¸° ì 3 ë°ëë, ê°ê°ì ìê¸° ì 2 ìì©ë©´ì´ ìí¥ ê²½ì¬ì§ í ì´í¼ë©´ì¼ë¡ íì±ëë¤. In the first body and the third body, each of the second acting surfaces is formed as a tapered surface inclined upward. ìê¸° ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬ë, ì 1 ë³´ì¡°ìì©ë©´ì ê°ê³ ìê¸° ì 1 í´í¼ì¤ì ëí¥ëë©°, ìê¸° ì 1 í´í¼ì¤ë³´ë¤ ìê¸° ì§ì§ëì ë ê°ê¹ê² ë°°ì¹ëë ì 1 ë³´ì¡°í´í¼ì¤; ìê¸° ì 1 í´í¼ì¤ì ìê¸° ì 1 ë³´ì¡°í´í¼ì¤ì ê²°í©ëë ì 1 ê³ ì  ìêµ¬ìì; ë° ìê¸° ì 1 í´í¼ì¤ì ìê¸° ì 1 ë³´ì¡°í´í¼ì¤ ì¬ì´ì ë°°ì¹ëê³ , ìê¸° ì 1 ì½ì¼ì íë¥´ë ì ë¥ì ìí´ íì  ê°ë¥í ì 1 íì  ìêµ¬ìì;ì ë í¬í¨íë¤.The first pole piece assembly includes: a first auxiliary pole piece having a first assisting surface, facing the first pole piece, and disposed closer to the support than the first pole piece; a first fixed permanent magnet coupled to the first pole piece and the first auxiliary pole piece; and a first rotating permanent magnet disposed between the first pole piece and the first auxiliary pole piece and rotatable by a current flowing through the first coil.

**[p0013]**

ìê¸° ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬ë, ì 2 ë³´ì¡°ìì©ë©´ì ê°ê³ ìê¸° ì 2 í´í¼ì¤ì ëí¥ëë©° ìê¸° ì 2 í´í¼ì¤ë³´ë¤ ìê¸° ì§ì§ëì ë ê°ê¹ê² ë°°ì¹ëë ì 2 ë³´ì¡°í´í¼ì¤; ìê¸° ì 2 í´í¼ì¤ì ìê¸° ì 2 ë³´ì¡°í´í¼ì¤ì ê²°í©ëë ì 2 ê³ ì  ìêµ¬ìì; ë° ìê¸° ì 2 í´í¼ì¤ì ìê¸° ì 2 ë³´ì¡°í´í¼ì¤ ì¬ì´ì ë°°ì¹ëê³ , ìê¸° ì 2 ì½ì¼ì íë¥´ë ì ë¥ì ìí´ íì  ê°ë¥í ì 2 íì  ìêµ¬ìì;ì ë í¬í¨íë¤.The second pole piece assembly includes: a second auxiliary pole piece having a second assisting surface, facing the second pole piece, and disposed closer to the support than the second pole piece; a second fixed permanent magnet coupled to the second pole piece and the second auxiliary pole piece; and a second rotating permanent magnet disposed between the second pole piece and the second auxiliary pole piece and rotatable by a current flowing through the second coil. ìê¸° ì 2 ë³´ì¡°í´í¼ì¤ë, ìê¸° ì 2 í´í¼ì¤ë³´ë¤ ë ê¸´ ê¸¸ì´ë¥¼ ê°ì§ë©°, ìê¸° ì 2 ìì©ë©´ê³¼ ìê¸° ì 2 ë³´ì¡°ìì©ë©´ì, ê°ê° ìí¥ ê²½ì¬ì§ í

**[p0014]**

ì´í¼ë©´ì¼ë¡ íì±ëë¤.The second auxiliary pole piece has a longer length than the second pole piece, and the second acting surface and the second auxiliary acting surface are each formed as an upwardly inclined tapered surface. ìê¸° í´ë¨íë, ìì¸¡ë¨ì´ ê°ê° ìê¸° ì 1 ë³´ì¡°í´í¼ì¤ì ìê¸° ì 2 ë³´ì¡°í´í¼ì¤ì ì°ê²°ëë ë³´ì¡°ë ì¼;ì ë í¬í¨íê³ , ìê¸° ë³µìì ìì±ì²´ë, ê°ê°ì´ ìê¸° ë ì¼ ë° ìê¸° ë³´ì¡°ë ì¼ì ì íì§ ì´ë ê°ë¥íê² ê²°í©ëë¤.The clamp further includes auxiliary rails having both ends connected to the first auxiliary pole piece and the second auxiliary pole piece, respectively, and the plurality of magnetic bodies move forward and backward on the rail and the auxiliary rail, respectively. possibly combined ìê¸° ê³¼ì ë¥¼ í´ê²°íê¸° ìí ë³¸ ë°ëª ì ì 5 ì¤ìì ë´ì§ ì 6 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ë, ëìì²´ê° ìì°© ê°ë¥í ì§ì§ë; ìì©ë©´ì ê°ë í´í¼ì¤ë¤ê³¼, ìê¸° í´í¼ì¤ë¤ ì¤ ì ì´ë ì´ë íëì ê°ê¸°ë ì½ì¼ê³¼, ìê¸° í´í¼ì¤ë¤ ì¬ì´ì ê³ ì ëë ê³ ì ììê³¼, ìê¸° í´í¼ì¤ë¤ ì¬ì´ì ë°°ì¹ëê³ ìê¸° ì½ì¼ì íë¥´ë ì ë¥ì ìí´ íì  ê°ë¥í íì ììì êµ¬ë¹í ìê¸°ë ¥ ì ì´ëª¨ë; ì ì´ë ì¼ë¶ê° ìê¸° ì§ì§ëì ë´ë¶ì ì´ë ê°ë¥íê² ë°°ì¹ëë í´ë¨í; ë° ìê¸° í´ë¨íë¥¼ íì± ë°ì´ì´ì¤ìí¤ë íì±ë ¥ ì ì´ëª¨ë;ì í¬í¨íê³ , ìê¸° í´ë¨íë, ìê¸° ì½ì¼ì ì¸ê°ëë ì ë¥ì ì ì´ì ìí´, ìê¸° í´í¼ì¤ë¤ê³¼ ìê¸° íë£¨íë¥¼ íì±í

**[p0014]**

ë©° ì 1 ë°©í¥ì¼ë¡ ì´ëíê±°ë, ìê¸° ìê¸° íë£¨í í´ì ì ìê¸° íì±ë ¥ ì ì´ëª¨ëì íì±ë ¥ì ìí´ ìê¸° ì 1 ë°©í¥ê³¼ ë°ëëë ì 2 ë°©í¥ì¼ë¡ ë¹ê²¨ì§ëë¡ êµ¬ì±ëë¤.A clamping device according to the fifth to sixth embodiments of the present invention for solving the above problems includes a support on which an object can be seated; pole pieces having a working surface, a coil wound around at least one of the pole pieces, a stationary magnet fixed between the pole pieces, and a current disposed between the pole pieces and flowing through the coil Magnetic force control module having a rotatable rotating magnet; At least a portion of the clamp movably disposed inside the support; and an elastic force control module for elastically biasing the clamp, wherein the clamp moves in a first direction while forming a magnetic closed loop with the pole pieces by controlling the current applied to the coil, or When the closed loop is released, the elastic force of the elastic force control module is configured to be pulled in a second direction opposite to the first direction.

**[p0015]**

ìê¸° íì±ë ¥ ì ì´ëª¨ëì, ìê¸° ì§ì§ëì íë¶ì ë°°ì¹ëê³ ê²½ì¬ë©´ì ê°ë ì§ì§ì²´ì, ì¼ë¨ì´ ìê¸° ì§ì§ì²´ì ê²½ì¬ë©´ì ì°ê²°ëê³ íë¨ì´ ìê¸° í´ë¨íì ê²°í©ëë©° ì ì¥ ìì¶ ê°ë¥í íì±ì²´ë¥¼ í¬í¨íê³ , ìê¸° í´ë¨íë, ìê¸° í´í¼ì¤ë¤ê³¼ ìê¸° íë£¨íë¥¼ íì±íë©° ìê³ë°©í¥ì¼ë¡ íì íê±°ë, ìê¸° íë£¨í í´ì ì ìê¸° íì±ë ¥ ì ì´ëª¨ëì íì±ë ¥ì ìí´ ë°ìê³ë°©í¥ì¼ë¡ íì íë¤. The elastic force control module includes a supporter disposed below the supporter and having an inclined surface, and an elastic body having one end connected to the inclined surface of the supporter and the other end coupled to the clamp and capable of being stretched and contracted, the clamp comprising: the pole piece It forms a magnetic closed loop and rotates clockwise, or rotates counterclockwise by the elastic force of the elastic force control module when the magnetic closed loop is released. ìê¸° íì±ë ¥ ì ì´ëª¨ëì, ìê¸° ì§ì§ëì íë¶ì ë°°ì¹ëë ì§ì§ì²´ì, ì¼ë¨ì´ ìê¸° ì§ì§ì²´ì ê²°í©ëê³ íë¨ì´ ìê¸° í´í¼ì¤ë¤ì ê²°í©ëë ë ì¼ê³¼, ì¼ë¨ì´ ìê¸° ì§ì§ì²´ì ê³ ì ëê³ íë¨ì´ ìê¸° í´ë¨íì ê²°í©ëë©° ì ì¥ ìì¶ ê°ë¥í íì±ì²´ë¥¼ í¬í¨íê³ , ìê¸° í´ë¨íë, ìê¸° ë ì¼ì ì íì§ ì´ë ê°ë¥íê² ê²°í©ëë©°, ìê¸° í´í¼ì¤ë¤ê³¼ ìê¸° íë£¨íë¥¼ íì±íë©° ìê¸° ìì©ë©´ì í¥íë ë°©í¥ì¼ë¡ ì¬ë¼ì´ë© ì´ëíê±°ë, ìê¸° íë£¨í í´ì ì ìê¸° íì±ë ¥ ì ì´ëª¨ëì íì±ë

**[p0015]**

¥ì ìí´ ìê¸° ì§ì§ì²´ë¥¼ í¥íë ë°©í¥ì¼ë¡ ì¬ë¼ì´ë© ì´ëíë¤. The elastic force control module includes a support body disposed below the support body, a rail having one end coupled to the support body and the other end coupled to the pole pieces, one end fixed to the support body and the other end coupled to the clamp, and elongation. A contractible elastic body is included, and the clamp is coupled to the rail to be movable forward and backward, forms a magnetic closed loop with the pole pieces, and slides in a direction toward the working surface, or releases the magnetic closed loop. The elastic force of the elastic force control module slides in a direction toward the support.

**[p0016]**

ìê¸° ê³¼ì ë¥¼ í´ê²°íê¸° ìí ë³¸ ë°ëª ì ì 7 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ë, ëìì²´ë¥¼ í´ë¨ííë ì¥ì¹ë¡ì, ê°ê° ìì©ë©´ì ê°ë ë³µìì í´í¼ì¤; ìê¸° ë³µìì í´í¼ì¤ ì¤ ì ì´ë ì´ë íëì ê°ê¸°ë ì½ì¼; ìê¸° ë³µìì í´í¼ì¤ ì¬ì´ì ê³ ì ëë ê³ ì ìì; ìê¸° ë³µìì í´í¼ì¤ ì¬ì´ìì ìê¸° ê³ ì ììê³¼ ì´ê²© ë°°ì¹ëê³ , ìê¸° ì½ì¼ì íë¥´ë ì ë¥ì ì ì´ì ìí´ íì  ê°ë¥í íì ìì; ë° ìê¸° ë³µìì í´í¼ì¤ ì¬ì´ì ë°°ì¹ëê³ , ìê¸° ì½ì¼ì ì¸ê°ëë ì ë¥ì ì ì´ ìí´ ê°ê°ì ìê¸° ìì©ë©´ì ì ì´í ìê¸° ëìì²´ì ë´ë¶ë¡ ì½ì ê°ë¥í ì½ì ëê¸°ë¥¼ êµ¬ë¹íë ê³ ì ë;ë¥¼ í¬í¨íë¤.A clamping device according to a seventh embodiment of the present invention for solving the above problems is a device for clamping an object, comprising: a plurality of pole pieces each having a working surface; a coil wound around at least one of the plurality of pole pieces; a fixed magnet fixed between the plurality of pole pieces; a rotating magnet spaced apart from the stationary magnet between the plurality of pole pieces and rotatable by controlling current flowing through the coil; and a fixing table disposed between the plurality of pole pieces and having an insertion protrusion insertable into the target object contacting each of the working surfaces by controlling a current applied to the coil.

**[p0017]**

ìê¸° ì½ì ëê¸°ë, ìê¸° ëìì²´ì ì¤ì¬ë¶ë¥¼ ê´íµíë ê´íµíì ì½ì ëë¤.The insertion protrusion is inserted into a through hole penetrating the center of the object. ë³¸ ë°ëª ì ë°ë¥´ë©´, ìì©ë©´ì ëìì²´ë¥¼ ì§ì  ì ì´ìì¼ ì§ì§íì§ ìê³ , í´ë¨íë¥¼ ì´ì©íì¬ ë¶ì°© ëìì²´ë¥¼ ì§ì§íë¯ë¡ ë¶ì°© ëìì²´ë¥¼ ë ê²¬ê³ íê² ì§ì§í ì ìë¤.According to the present invention, since the target object is supported using a clamp instead of directly contacting and supporting the target object on the working surface, the target object can be supported more firmly. ëí, í´ë¨í ì¥ì¹ë¥¼ ì¤ì¹í¨ì ìì´ ì¤ì¹ ê³µê°ì í¬ê¸°ì ì ì½ì ë°ì§ ìì¼ë¯ë¡, ê³µê° íì©ì±ì í¥ììí¬ ì ìë¤.In addition, since the installation of the clamping device is not restricted by the size of the installation space, space utilization can be improved. ëí, ì ì ì ë ¥ì¼ë¡ íì  ììì íì ìì¼ ìì±ì²´ë¥¼ ìì ì ì¼ë¡ ì§ì§í ì ìì¼ë¯ë¡, ìê¸°ë ¥ ì ì´ ì¥ì¹ì ê°ë í¨ì¨ì±ì í¥ììí¬ ì ìë¤.In addition, since the magnetic body can be stably supported by rotating the rotating magnet with little power, the operating efficiency of the magnetic force control device can be improved.

**[p0018]**

ë 1a ë´ì§ ë 1dë ë³¸ ë°ëª ì ì 1 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ë¥¼ ê°ëµì ì¼ë¡ ëìí ëë©´. ë 2a ë´ì§ ë 2dë ë³¸ ë°ëª ì ì 2 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ë¥¼ ê°ëµì ì¼ë¡ ëìí ëë©´. ë 3a ë´ì§ ë 3dë ë³¸ ë°ëª ì ì 3 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ë¥¼ ê°ëµì ì¼ë¡ ëìí ëë©´. ë 4a ë´ì§ ë 4dë ë³¸ ë°ëª ì ì 4 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ë¥¼ ê°ëµì ì¼ë¡ ëìí ëë©´. ë 5a ë´ì§ ë 5dë ë³¸ ë°ëª ì ì 5 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ë¥¼ ê°ëµì ì¼ë¡ ëìí ëë©´. ë 6a ë´ì§ ë 6dë ë³¸ ë°ëª ì ì 6 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ë¥¼ ê°ëµì ì¼ë¡ ëìí ëë©´. ë 7a ë´ì§ ë 7dë ë³¸ ë°ëª ì ì 7 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ë¥¼ ê°ëµì ì¼ë¡ ëìí ëë©´.1A to 1D schematically show a clamping device according to a first embodiment of the present invention; 2a to 2d schematically show a clamping device according to a second embodiment of the present invention;

**[p0019]**

3a to 3d schematically show a clamping device according to a third embodiment of the present invention; 4a to 4d schematically show a clamping device according to a fourth embodiment of the present invention; 5A to 5D schematically show a clamping device according to a fifth embodiment of the present invention; 6A to 6D schematically show a clamping device according to a sixth embodiment of the present invention; 7a to 7d schematically show a clamping device according to a seventh embodiment of the present invention; ì´íììë ì²¨ë¶ë ëë©´ì ì°¸ì¡°íì¬ ë¤ìí ì¤ììë¥¼ ë³´ë¤ ìì¸íê² ì¤ëª íë¤. ë³¸ ëª ì¸ìì ê¸°ì¬ë ì¤ììë ë¤ìíê² ë³íë ì ìë¤. í¹ì í ì¤ììê° ëë©´ìì ë¬ì¬ëê³ ìì¸í ì¤ëª ìì ìì¸íê² ì¤ëª ë ì ìë¤. ê·¸ë¬ë, ì²¨ë¶ë ëë©´ì ê°ìë í¹ì í ì¤ììë ë¤ìí ì¤ììë¥¼ ì½ê² ì´í´íëë¡ íê¸° ìí ê²ì¼ ë¿ì´ë¤. ë°ë¼ì, ì²¨ë¶ë ëë©´ì ê°ìë í¹ì  ì¤ììì ìí´ ê¸°ì ì  ì¬ìì´ ì íëë ê²ì ìëë©°, ë°ëª

**[p0020]**

ì ì¬ì ë° ê¸°ì ë²ìì í¬í¨ëë ëª¨ë ê· ë±ë¬¼ ëë ëì²´ë¬¼ì í¬í¨íë ê²ì¼ë¡ ì´í´ëì´ì¼ íë¤.Hereinafter, various embodiments will be described in more detail with reference to the accompanying drawings. The embodiments described in this specification may be modified in various ways. Certain embodiments may be depicted in the drawings and described in detail in the detailed description. However, specific embodiments disclosed in the accompanying drawings are only intended to facilitate understanding of various embodiments. Therefore, the technical idea is not limited by the specific embodiments disclosed in the accompanying drawings, and it should be understood to include all equivalents or substitutes included in the spirit and technical scope of the invention. ë³¸ ëª ì¸ììì, ì´ë¤ êµ¬ì± ììê° ë¤ë¥¸ êµ¬ì± ìì âìâì íì±ëì´ ìë¤ê³ ê¸°ì¬ë ê²½ì°ë, ìê¸° ì´ë¤ êµ¬ì± ìì ë° ìê¸° ë¤ë¥¸ êµ¬ì± ìì ì¬ì´ì ë ë¤ë¥¸ êµ¬ì± ììê° ìë ê²½ì°ë¥¼ ë°°ì íì§ ìëë¤. ì¦, ìê¸° ì´ë¤ êµ¬ì± ììë ìê¸° ë¤ë¥¸ êµ¬ì± ììì ì§ì  ì ì´íì¬ íì±ëê±°ë, ëë ìê¸° ì´ë¤ êµ¬ì± ìì ë° ìê¸° ë¤ë¥¸ êµ¬ì± ìì ì¬ì´ì ë ë¤ë¥¸ êµ¬ì± ììê° ê°ì¬ë ì ìë¤.In this specification, when it is described that a certain component is formed âonâ another component, the case where another component exists between the certain component and the other component is not excluded. That is, the certain component may be formed in direct contact with the other componen

**[p0020]**

t, or another component may be interposed between the certain component and the other component.

**[p0021]**

ì 1, ì 2 ë±ê³¼ ê°ì´ ììë¥¼ í¬í¨íë ì©ì´ë ë¤ìí êµ¬ì±ììë¤ì ì¤ëª íëë° ì¬ì©ë ì ìì§ë§, ì´ë¬í êµ¬ì±ììë¤ì ìì í ì©ì´ì ìí´ íì ëì§ë ìëë¤. ìì í ì©ì´ë íëì êµ¬ì±ììë¥¼ ë¤ë¥¸ êµ¬ì±ììë¡ë¶í° êµ¬ë³íë ëª©ì ì¼ë¡ë§ ì¬ì©ëë¤.Terms including ordinal numbers, such as first and second, may be used to describe various components, but these components are not limited by the above terms. The terminology described above is only used for the purpose of distinguishing one component from another. ë³¸ ëª ì¸ììì, "í¬í¨íë¤" ëë "ê°ì§ë¤" ë±ì ì©ì´ë ëª ì¸ììì ê¸°ì¬ë í¹ì§, ì«ì, ë¨ê³, ëì, êµ¬ì±ìì, ë¶í ëë ì´ë¤ì ì¡°í©í ê²ì´ ì¡´ì¬í¨ì ì§ì íë ¤ë ê²ì´ì§, íë ëë ê·¸ ì´ìì ë¤ë¥¸ í¹ì§ë¤ì´ë ì«ì, ë¨ê³, ëì, êµ¬ì±ìì, ë¶í ëë ì´ë¤ì ì¡°í©í ê²ë¤ì ì¡´ì¬ ëë ë¶ê° ê°ë¥ì±ì ë¯¸ë¦¬ ë°°ì íì§ ìë ê²ì¼ë¡ ì´í´ëì´ì¼ íë¤. ì´ë¤ êµ¬ì±ììê° ë¤ë¥¸ êµ¬ì±ììì "ì°ê²°ëì´" ìë¤ê±°ë "ì ìëì´" ìë¤ê³ ì¸ê¸ë ëìë, ê·¸ ë¤ë¥¸ êµ¬ì±ììì ì§ì ì ì¼ë¡ ì°ê²°ëì´ ìê±°ë ëë ì ìëì´ ìì ìë ìì§ë§, ì¤ê°ì ë¤ë¥¸ êµ¬ì±ììê° ì¡´ì¬í ìë ìë¤ê³ ì´í´ëì´ì¼ í ê²ì´ë¤. ë°ë©´ì, ì´ë¤ êµ¬ì±ììê° ë¤ë¥¸ êµ¬ì±ììì "ì§ì  ì°ê²°ëì´" ìë¤ê±°ë "ì§ì  ì ìëì´" ìë¤ê³ ì¸ê¸ë ëìë, ì¤ê°ì ë¤ë¥¸ êµ¬ì±ììê° ì¡´ì¬íì§ ìë ê²ì¼ë¡ ì´í´ëì´ì¼ í ê²ì´ë¤

**[p0021]**

.In this specification, terms such as "comprise" or "having" are intended to indicate that there is a feature, number, step, operation, component, part, or combination thereof described in the specification, but one or more other features It should be understood that the presence or addition of numbers, steps, operations, components, parts, or combinations thereof is not precluded. It is understood that when an element is referred to as being "connected" or "connected" to another element, it may be directly connected or connected to the other element, but other elements may exist in the middle. It should be. On the other hand, when an element is referred to as âdirectly connectedâ or âdirectly connectedâ to another element, it should be understood that no other element exists in the middle.

**[p0022]**

íí¸, ë³¸ ëª ì¸ììì ì¬ì©ëë êµ¬ì±ììì ëí "ëª¨ë" ëë "ë¶"ë ì ì´ë íëì ê¸°ë¥ ëë ëìì ìííë¤. ê·¸ë¦¬ê³ , "ëª¨ë" ëë "ë¶"ë íëì¨ì´, ìíí¸ì¨ì´ ëë íëì¨ì´ì ìíí¸ì¨ì´ì ì¡°í©ì ìí´ ê¸°ë¥ ëë ëìì ìíí ì ìë¤. ëí, í¹ì  íëì¨ì´ìì ìíëì´ì¼ íê±°ë ì ì´ë íëì íë¡ì¸ììì ìíëë "ëª¨ë" ëë "ë¶"ë¥¼ ì ì¸í ë³µìì "ëª¨ëë¤" ëë ë³µìì "ë¶ë¤"ì ì ì´ë íëì ëª¨ëë¡ íµí©ë ìë ìë¤. ë¨ìì ííì ë¬¸ë§¥ì ëª ë°±íê² ë¤ë¥´ê² ë»íì§ ìë í, ë³µìì ííì í¬í¨íë¤.Meanwhile, a âmoduleâ or âunitâ for a component used in this specification performs at least one function or operation. Also, a âmoduleâ or âunitâ may perform a function or operation by hardware, software, or a combination of hardware and software. In addition, a plurality of âmodulesâ or âunitsâ other than âmodulesâ or âunitsâ to be executed in specific hardware or to be executed in at least one processor may be integrated into at least one module. Singular expressions include plural expressions unless the context clearly dictates otherwise.

**[p0023]**

ê·¸ ë°ìë, ë³¸ ë°ëª ì ì¤ëª í¨ì ìì´ì, ê´ë ¨ë ê³µì§ ê¸°ë¥ í¹ì êµ¬ì±ì ëí êµ¬ì²´ì ì¸ ì¤ëª ì´ ë³¸ ë°ëª ì ìì§ë¥¼ ë¶íìíê² íë¦´ ì ìë¤ê³ íë¨ëë ê²½ì°, ê·¸ì ëí ìì¸í ì¤ëª ì ì¶ì½íê±°ë ìëµíë¤.In addition, in describing the present invention, if it is determined that a detailed description of a related known function or configuration may unnecessarily obscure the subject matter of the present invention, the detailed description thereof will be abbreviated or omitted. ë³¸ ë°ëª ì ì¤ììë¤ì ë°ë¥¸ í´ë¨í ì¥ì¹ë ìê¸°ë ¥ì ì´ì©íì¬ ëìì²´ë¥¼ ì§ì§í ì ìë ì¥ì¹ì ê´í ê²ì´ë¤.A clamping device according to embodiments of the present invention relates to a device capable of supporting an object using magnetic force. ë 1a ë´ì§ ë 1dë ë³¸ ë°ëª ì ì 1 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ë¥¼ ê°ëµì ì¼ë¡ ëìí ëë©´ì´ë¤.1A to 1D are diagrams schematically showing a clamping device according to a first embodiment of the present invention.

**[p0024]**

ì°ì , ë 1aë¥¼ ì°¸ì¡°íì¬, ë³¸ ë°ëª ì ì 1 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ì êµ¬ì¡°ë¥¼ êµ¬ì²´ì ì¼ë¡ ì¤ëª íë¤.First, with reference to FIG. 1A, the structure of the clamping device according to the first embodiment of the present invention will be described in detail. ë³¸ ë°ëª ì ì 1 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹(100)ë ëìì²´(10)ë¥¼ ì§ì§íë ì§ì§ë(110), ë³µìì ì 1 ìì©ë©´(121a,121b)ì ê°ê³ ìê¸°ì ì¸ ê²½ë¡ë¥¼ ì ê³µ ê°ë¥í ì 1 í´í¼ì¤(121)ì, ì 1 í´í¼ì¤(121)ì ê°ê¸´ ì 1 ì½ì¼(122)ì êµ¬ë¹í ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(120), ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(120)ì ì´ê²©ëë©° ë³µìì ì 2 ìì©ë©´(131a,131b)ì ê°ê³ ìê¸°ì ì¸ ê²½ë¡ë¥¼ ì ê³µ ê°ë¥í ì 2 í´í¼ì¤(131)ì, ì 2 í´í¼ì¤(131)ì ê°ê¸´ ì 2 ì½ì¼(132)ì êµ¬ë¹í ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(130) ë° ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(120)ì ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(130) ì¬ì´ì ì´ë ê°ë¥íê² ë°°ì¹ëë í´ë¨í(140)ë¥¼ í¬í¨í ì ìë¤. The clamping device 100 according to the first embodiment of the present invention has a support 110 for supporting an object 10 and a first pole piece capable of providing a magnetic path having a plurality of first working surfaces 121a and 121b. 121, a first pole piece assembly 120 having a first coil 122 wound around the first pole piece 121, spaced apart from the first pole piece assembly 120 and a plurality of second acting surfaces ( A second pole piece assembly 130 having a second pole piece 131 having 131a and 131b and capable of providing a magnetic path, and a second coil 13

**[p0024]**

2 wound around the second pole piece 131; A clamp 140 movably disposed between the pole piece assembly 120 and the second pole piece assembly 130 may be included.

**[p0025]**

ì¬ê¸°ì, í´ë¨í(140)ë ì 1 ì½ì¼(122) ë° ì 2 ì½ì¼(132)ì ì¸ê°ëë ì ë¥ì ì ì´ì ìí´ ë³µìì ì 1 ìì©ë©´(121a,121b)ì ì ì´íê±°ë ë³µìì ì 2 ìì©ë©´(131a,131b)ì ì ì´íë©´ì, ì§ì§ë(110)ì ì§ì§ë ëìì²´(10)ë¥¼ í´ë¨ííê±°ë ëìì²´(10)ì ëí í´ë¨íì í´ì í ì ìë¤. ì¦, í´ë¨í(140)ë ì¸ê°ëë ì ë¥ì ì ì´ì ìí´ ì 1 ë°©í¥ì¼ë¡ ì´ëíë©° ëìì²´(10)ì ëí í´ë¨í(140)ì ëí í´ë¨íì í´ì íê±°ë, ì 2 ë°©í¥ì¼ë¡ ì´ëíë©° ëìì²´(10)ì ëí í´ë¨íì í ì ìë¤.Here, the clamp 140 contacts the plurality of first acting surfaces 121a and 121b or the plurality of second acting surfaces 131a by controlling the current applied to the first coil 122 and the second coil 132. While contacting , 131b), the object 10 supported by the support 110 may be clamped or the clamping of the object 10 may be released. That is, the clamp 140 moves in the first direction by the control of the applied current and releases the clamping of the clamp 140 to the object 10, or moves in the second direction and clamps the object 10 to the object 10. can do.

**[p0026]**

íí¸, ë³¸ ë°ëª ì ì 1 ì¤ììë¥¼ ì¤ëª í¨ì ìì´ì, íê¸°ìì ê¸°ì¬ëë ì 1 ë°©í¥ì ìê³ë°©í¥ì¸ ê²½ì°ë¥¼ ììì ì¼ë¡ ì¤ëª íê³ , ì 2 ë°©í¥ì ë°ìê³ë°©í¥ì¸ ê²½ì°ë¥¼ ììì ì¼ë¡ ì¤ëª íë¤.On the other hand, in describing the first embodiment of the present invention, the first direction described below is exemplarily described as a clockwise direction, and the second direction is exemplarily described as a counterclockwise direction. ì§ì§ë(110)ë ì¼ë°©í¥(ì´í ì°ì¥ë°©í¥ì´ë¼ í¨)ì¼ë¡ ì°ì¥ëë©°, ëìì²´(10)ê° ìì°©ë ì ìë¤. ìë¥¼ ë¤ì´, ì§ì§ë(110)ë ì°ì¥ë°©í¥ì ë°ë¼ ì°ì¥ëê³ , ìíë°©í¥ì¼ë¡ ìì ì ëì´ë¥¼ ê°ë ì§ì¡ë©´ì²´ì íë ì´í¸ íìì¼ë¡ ë§ë ¨ë ì ìë¤. ì¬ê¸°ì, ìíë°©í¥ì, ì°ì¥ë°©í¥ì ëíì¬ ìì§íê² ì§êµíë ë°©í¥ì¼ ì ìë¤. ëí, ì§ì§ë(110)ë ê·¸ íì± ì¬ì§ì´ ë°ìì±(åç£æ§, diamagnetic)ì ì¬ì§ë¡ íì±ë ì ìë¤. ì¦, ì§ì§ë(110)ë ë°ìì±ì²´ë¡ íì±ëì´, íì íë ì 1 í´í¼ì¤ ì´ì

**[p0027]**

ë¸ë¦¬(120) ë° ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(130)ì ìê¸° íë¦ì´ ëìì²´(10)ë¡ ì ë¬ëë ìê¸° ê°ì­ íìì ë°©ì§í ì ìë¤.The support 110 extends in one direction (hereinafter referred to as an extension direction), and the object 10 may be seated thereon. For example, the support 110 may be provided in a rectangular parallelepiped plate shape extending along an extension direction and having a predetermined height in a vertical direction. Here, the up-and-down direction may be a direction orthogonal to the extension direction. In addition, the support 110 may be formed of a diamagnetic material. That is, the support 110 is formed of a diamagnetic material to prevent a magnetic interference phenomenon in which magnetic flows of the first pole piece assembly 120 and the second pole piece assembly 130, which will be described later, are transmitted to the object 10. . ëí, ì§ì§ë(110)ë ê·¸ ì¤ì¬ë¶ì ìíë¡ ê´íµë ì½ì í(111)ì´ íì±ë ì ìë¤. ì½ì

**[p0028]**

í(111)ìë íì íë í´ë¨í(140)ì ê°ìì²´(143)ê° ì´ë ê°ë¥íê² ì½ì ë ì ìë¤. In addition, the support 110 may have an insertion hole 111 penetrating vertically at its center. A pressing body 143 of a clamp 140 to be described later may be movably inserted into the insertion hole 111 . ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(120)ë ì§ì§ë(110)ì íë¶ì ë°°ì¹ëë©°, ì ë¥ë¥¼ ì¸ê°ë°ì í´ë¨í(140)ë¥¼ ì 1 ë°©í¥(ì¦, ìê³ë°©í¥)ì¼ë¡ íì ìí¬ ì ìë¤. íê¸°ììë, ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(120)ê° ì°ì¥ë°©í¥ì ê¸°ì¤ì¼ë¡ ëë©´ì ì¢ì¸¡ì ë°°ì¹ëë ê²½ì°ë¥¼ ììì ì¼ë¡ ì¤ëª íë¤. ëí, ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(120)ê° ì§ì§ë(110)ì íë¶ì ê²°í©ëë ê²½ì°ë¥¼ ììì ì¼ë¡ ì¤ëª íë©°, ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(120)ë ì§ì§ë(110)ì íë¶ì ìì ê°ê²© ì´ê²©ëì´ ê¸°í êµ¬ì¡°ë¬¼ì ìí´ ì§ì§ë ìë ìë¤. ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(120)ë ì 1 í´í¼ì¤(121) ë° ì 1 ì½ì¼(122)ì í¬í¨í ì ìë¤. The first pole piece assembly 120 is disposed below the support 110 and receives current to rotate the clamp 140 in a first direction (ie, clockwise direction). In the following, a case in which the first pole piece assembly 120 is disposed on the left side of the drawing based on the extension direction will be described as an example. In addition, a case in which the first pole piece assembly 120 is coupled to the lower portion of the support 110 will be described as an example, and the first pole piece assembly 120 is spaced apart from the lower portion of the support 110 b

**[p0028]**

y a predetermined distance to other structures. may be supported by The first pole piece assembly 120 may include a first pole piece 121 and a first coil 122 .

**[p0029]**

ì 1 í´í¼ì¤(121)ë ìê¸°ê° íë¥¼ ì ìë ê²½ë¡ë¥¼ íì±í ì ìë¤. ìë¥¼ ë¤ì´, ì 1 í´í¼ì¤(121)ë ì² ê³¼ ê°ì ê°ìì±ì²´ë¡ êµ¬ì±ë ì ìë¤. ì´ì, ì 1 í´í¼ì¤(121)ìë ìê¸°ê° íë¥¼ ì ìì¼ë©°, íì íë í´ë¨í(140)ì ìê¸° íë£¨íë¥¼ íì±í ì ìë¤. The first pole piece 121 can form a path through which magnetism can flow. For example, the first pole piece 121 may be made of a ferromagnetic material such as iron. Accordingly, magnetism may flow through the first pole piece 121, and a magnetic closed loop may be formed with the clamp 140 described later. ì 1 í´í¼ì¤(121)ë ì§ì§ë(110)ì íë¶ì ê²°í©ëë©° ì°ì¥ë°©í¥ì¼ë¡ ì°ì¥ë ì 1 íí¸(121c), ì 1 íí¸(121c)ìì íì¸¡(ì¦, ìíë°©í¥)ì¼ë¡ ì°ì¥ëë ì 2 íí¸(121d) ë° ì 1 íí¸(121c)ì ëí¥ëëë¡ ì 2 íí¸(121d)ì íë¶ìì ì°ì¥ë°©í¥ì¼ë¡ ì°ì¥ëë ì 3 íí¸(121e)ë¥¼ í¬í¨í ì ìë¤. ì¦, ì 1 í´í¼ì¤(121)ë ì 2 íí¸(121d)ë¥¼ ê¸°ì¤ì¼ë¡ ì 2 íí¸(121d)ì ìë¶ ë° íë¶ìì ì 1 íí¸(121c) ë° ì 3 íí¸(121e)ê° ì°ì¥ë°©í¥ì¼ë¡ ëì¶ë ì ìë¤. ìë¥¼ ë¤ì´, ì 1 í´í¼ì¤(121)ë 'ã·'ì íìì¼ë¡ íì±ë ì ìë¤. The first pole piece 121 is coupled to the lower portion of the support 110 and includes a first part 121c extending in an extension direction, and a second part extending downward (ie, up and down) from the first part 121c ( 121d) and a third part 121e extending in an extension direction from the lower part of the second part 121d to face the first part 121c.

**[p0029]**

That is, in the first pole piece 121, the first part 121c and the third part 121e may protrude from the upper and lower portions of the second part 121d based on the second part 121d in the extension direction. there is. For example, the first pole piece 121 may be formed in a 'c' shape.

**[p0030]**

ëí, ì 1 í´í¼ì¤(121)ë íì íë í´ë¨í(140)ì ì ì´í ì ìëë¡, ë³µìì ì 1 ìì©ë©´(121a,121b)ì ê°ì§ ì ìë¤. ì¬ê¸°ì, ë³µìì ì 1 ìì©ë©´(121a,121b)ì ëë©´ì ì 1 í´í¼ì¤(121) ì 1 íí¸(121c)ì ì°ì¸¡ë©´ ë° ì 1 í´í¼ì¤(121) ì 3 íí¸(121e)ì ì°ì¸¡ë©´ì¼ ì ìë¤. íê¸°ììë, ì 1 íí¸(121c)ì ì°ì¸¡ë©´ì ì¼ ì 1 ìì©ë©´(121a)ì´ë¼ íê³ , ì 1 í´í¼ì¤(121) ì 3 íí¸(121e)ì ì°ì¸¡ë©´ì í ì 1 ìì©ë©´(121b)ì´ë¼ íë¤.In addition, the first pole piece 121 may have a plurality of first working surfaces 121a and 121b to contact a clamp 140 to be described later. Here, the plurality of first working surfaces 121a and 121b may be the right side of the first part 121c of the first pole piece 121 and the right side of the third part 121e of the first pole piece 121 in the drawing. . In the following, the right side of the first part 121c is referred to as one first acting surface 121a, and the right side of the third part 121e of the first pole piece 121 is referred to as the other first acting surface 121b.

**[p0031]**

ë³µìì ì 1 ìì©ë©´(121a,121b)ì ìê¸° íë¦ì´ íì±ëë©´, ë³µìì ì 1 ìì©ë©´(121a,121b)ì íì íë í´ë¨í(140)ê° ì ì´ ë° ì§ì§ë ì ìë¤. ì¦, ë³µìì ì 1 ìì©ë©´(121a,121b)ìì ìê¸° íë¦ì´ ë°ì°ëë©°, í´ë¨í(140)ì ì¸ë ¥ì ê°í ì ìê³ , í´ë¨í(140)ë¥¼ ë¹ê²¨ ë³µìì ì 1 ìì©ë©´(121a,121b)ì í¡ì°©ìí¬ ì ìë¤. ì¬ê¸°ì, "ìê¸° íë¦ì ë°ì°"ì´ë ë³µìì ì 1 ìì©ë©´(121a,121b)(ëë, íì ëë ë³µìì ì 2 ìì©ë©´(131a,131b))ì¼ë¡ë¶í° ì¸ë¶ë¡ ìê¸° íë¦ì´ íì±ëë ê²½ì° ë° ì¸ë¶ë¡ë¶í° ë³µìì ì 1 ìì©ë©´(121a,121b)(ëë, ì 2 ìì©ë©´(131a,131b))ì í¥í´ ìê¸° íë¦ì´ íì±ëë ê²½ì°ë¥¼ ëª¨ë í¬í¨íë¤.When magnetic flow is formed on the plurality of first acting surfaces 121a and 121b, a clamp 140 described later may contact and support the plurality of first acting surfaces 121a and 121b. That is, the magnetic flow is diverged from the plurality of first working surfaces 121a and 121b, and an attractive force can be applied to the clamp 140, and the clamp 140 is pulled to be attracted to the plurality of first working surfaces 121a and 121b. can make it Here, "divergence of magnetic flow" means a case where magnetic flow is formed from the plurality of first acting surfaces 121a and 121b (or a plurality of second acting surfaces 131a and 131b described later) to the outside and a plurality of times from the outside. It includes all cases in which magnetic flow is formed toward the first acting surfaces 121a and 121b (or the second acting surf

**[p0031]**

aces 131a and 131b).

**[p0032]**

ì 1 ì½ì¼(122)ì ì 1 í´í¼ì¤(121)ì ê°ê¸°ë©°, ì 1 í´í¼ì¤(121)ì ìê¸° íë¦ì ë°ììí¬ ì ìë¤. ìë¥¼ ë¤ì´, ì 1 ì½ì¼(122)ì ì 1 í´í¼ì¤(121)ì ì 2 íí¸(121d)ì ê°ê¸¸ ì ìë¤. íì§ë§, ì 1 ì½ì¼(122)ì ì 1 í´í¼ì¤(121)ì ì 1 íí¸(121c) í¹ì ì 1 í´í¼ì¤(121)ì ì 3 íí¸(121e)ì ê°ê¸¸ ìë ìë¤.The first coil 122 is wound around the first pole piece 121 and can generate magnetic flow in the first pole piece 121 . For example, the first coil 122 may be wound around the second part 121d of the first pole piece 121 . However, the first coil 122 may be wound around the first part 121c of the first pole piece 121 or the third part 121e of the first pole piece 121 . ì 1 ì½ì¼(122)ì ì ë¥ê° íë¥´ë©´, ìíë¥´ì ì¤ë¥¸ëì¬ ë²ì¹(Ampere's right-handed screw rule)ì ìí´ ì¼ì í ë°©í¥ì¼ë¡ ìê¸° íë¦ì´ íì±ëê³ , ì 1 ì½ì¼(122)ì´ ê°ê¸´ ì 1 í´í¼ì¤(121) ì 2 íí¸(121d)ìë ìê¸° íë¦ì ë°©í¥ì ë°ë¼ Nê·¹ê³¼ Sê·¹ì´ íì±ëë¤. ì¦, ì 1 ì½ì¼(122)ì´ ê°ê¸´ ì 1 í´í¼ì¤(121) ì 2 íí¸(121d)ë ì ìì(é»ç£ç³)ì ì­í ì ìííë êµ¬ì±ì¼ë¡ ë³¼ ì ìë¤.When current flows through the first coil 122, a magnetic flow is formed in a certain direction according to Ampere's right-handed screw rule, and the first pole piece 121 around which the first coil 122 is wound ) The N pole and the S pole are formed in the second part 121d according to the direction of the magnetic flow. That is, the second part 121d of the first pole piece 121 around which the first coil

**[p0032]**

122 is wound can be regarded as a configuration that serves as an electromagnet.

**[p0033]**

ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(130)ë ì§ì§ë(110)ì íë¶ìì ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(120)ì ì´ê²©ëì´ ë°°ì¹ëë©°, ì ë¥ë¥¼ ì¸ê°ë°ì í´ë¨í(140)ë¥¼ ì 2 ë°©í¥(ì¦, ë°ìê³ë°©í¥)ì¼ë¡ íì ìí¬ ì ìë¤. íê¸°ììë, ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(130)ê° ì°ì¥ë°©í¥ì ê¸°ì¤ì¼ë¡ ëë©´ì ì°ì¸¡ì ë°°ì¹ëë ê²½ì°ë¥¼ ììì ì¼ë¡ ì¤ëª íë¤. ëí, ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(130)ê° ì§ì§ë(110)ì íë¶ì ê²°í©ëë ê²½ì°ë¥¼ ììì ì¼ë¡ ì¤ëª íë©°, ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(130)ë ì§ì§ë(110)ì íë¶ì ìì ê°ê²© ì´ê²©ëì´ ê¸°í êµ¬ì¡°ë¬¼ì ìí´ ì§ì§ë ìë ìë¤. ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(130)ë ì 2 í´í¼ì¤(131) ë° ì 2 ì½ì¼(132)ì í¬í¨í ì ìë¤.The second pole piece assembly 130 is disposed at the bottom of the support 110 and spaced apart from the first pole piece assembly 120, and receives current to move the clamp 140 in the second direction (ie, counterclockwise). can be rotated In the following, a case in which the second pole piece assembly 130 is disposed on the right side of the drawing based on the extension direction will be described as an example. In addition, a case in which the second pole piece assembly 130 is coupled to the lower portion of the support 110 will be described as an example, and the second pole piece assembly 130 is spaced apart from the lower portion of the support 110 by a predetermined distance to other structures. may be supported by The second pole piece assembly 130 may include a second pole piece 131 and a second coil 132 .

**[p0034]**

ì 2 í´í¼ì¤(131)ë ìê¸°ê° íë¥¼ ì ìë ê²½ë¡ë¥¼ íì±í ì ìë¤. ìë¥¼ ë¤ì´, ì 2 í´í¼ì¤(131)ë ì² ê³¼ ê°ì ê°ìì±ì²´ë¡ êµ¬ì±ë ì ìë¤. ì´ì, ì 2 í´í¼ì¤(131)ìë ìê¸°ê° íë¥¼ ì ìì¼ë©°, íì íë í´ë¨í(140)ì ìê¸° íë£¨íë¥¼ íì±í ì ìë¤. The second pole piece 131 can form a path through which magnetism can flow. For example, the second pole piece 131 may be made of a ferromagnetic material such as iron. Accordingly, magnetism may flow through the second pole piece 131, and a magnetic closed loop may be formed with the clamp 140 described later. ì 2 í´í¼ì¤(131)ë ì§ì§ë(110)ì íë¶ì ê²°í©ëë©° ì°ì¥ë°©í¥ì¼ë¡ ì°ì¥ë ì 1 ë°ë(131c), ì 1 ë°ë(131c)ìì íì¸¡(ì¦, ìíë°©í¥)ì¼ë¡ ì°ì¥ëë ì 2 ë°ë(131d) ë° ì 1 ë°ë(131c)ì ëí¥ëëë¡ ì 2 ë°ë(131d)ì íë¶ìì ì°ì¥ë°©í¥ì¼ë¡ ì°ì¥ëë ì 3 ë°ë(131e)ë¥¼ í¬í¨í ì ìë¤. ì¦, ì 2 í´í¼ì¤(131)ë ì 2 ë°ë(131d)ë¥¼ ê¸°ì¤ì¼ë¡ ì 2 ë°ë(131d)ì ìë¶ ë° íë¶ìì ì 1 ë°ë(131c) ë° ì 3 ë°ë(131e)ê° ì 1 í´í¼ì¤ ì´ì

**[p0035]**

ë¸ë¦¬(120)ë¥¼ í¥íì¬ ëì¶ë ì ìë¤. ìë¥¼ ë¤ì´, ì 2 í´í¼ì¤(131)ë 'ã·'ì íìì¼ë¡ íì±ë ì ìë¤.The second pole piece 131 is coupled to the lower portion of the support 110 and includes a first body 131c extending in an extension direction, and a second body extending downward (ie, up and down) from the first body 131c ( 131d) and a third body 131e extending in an extension direction from the lower part of the second body 131d to face the first body 131c. That is, in the second pole piece 131, the first body 131c and the third body 131e are formed in the upper and lower parts of the second body 131d based on the second body 131d as a first pole piece assembly ( 120). For example, the second pole piece 131 may be formed in a 'c' shape. ì¬ê¸°ì, ì 2 í´í¼ì¤(131)ë ì 1 ë°ë(131c)ì ì°ì¥ë°©í¥ ê¸¸ì´ê° ì 3 ë°ë(131e)ì ì°ì¥ë°©í¥ ê¸¸ì´ë³´ë¤ ê¸¸ ì ìë¤. íì íë, í´ë¨í(140)ë ì§ì§ë(110)ì íì  ê°ë¥íê² ê²°í©ëì´ ì§ì§ë(110)ë¥¼ ì¤ì¬ì¼ë¡ ì¼ì  ê°ëë¥¼ íì (ì¦, íë)í ì ìë¤. ì¦, í´ë¨í(140)ë ìì£¼ë°©í¥ì ëíì¬, ê·¸ íë¨ë¶ë¥¼ í¥í ìë¡ ë ë§ì ë³ìê°ì ê°ê² ëë¤. ì´ì, ì 2 í´í¼ì¤(131)ì ì 1 ë°ë(131c)ê° ì 3 ë°ë(131e)ë³´ë¤ ê¸¸ê² íì±ëë¯ë¡, ì 2 ë°©í¥(ì¦, ë°ìê³ë°©í¥)ì¼ë¡ íì íë í´ë¨í(140)ì ì ì´í ì ìë¤. Here, in the second pole piece 131, the length of the first body 131c in the extension direction may be longer than the length of the third body 131e in the extension direction. The clamp 140 , which will be

**[p0035]**

described later, is rotatably coupled to the support 110 and can rotate (ie rotate) at a predetermined angle around the support 110 . That is, the clamp 140 has a larger displacement value toward the lower end in the circumferential direction. Accordingly, since the first body 131c of the second pole piece 131 is longer than the third body 131e, it can contact the clamp 140 rotating in the second direction (ie, counterclockwise). .

**[p0036]**

ëí, ì 2 í´í¼ì¤(131)ë íì íë í´ë¨í(140)ì ì ì´íë ë³µìì ì 2 ìì©ë©´(131a,131b)ì ê°ì§ ì ìë¤. ì¬ê¸°ì, ë³µìì ì 2 ìì©ë©´(131a,131b)ì ëë©´ì ì 2 í´í¼ì¤(131) ì 1 ë°ë(131c)ì ì¢ì¸¡ë©´ ë° ì 2 í´í¼ì¤(131) ì 3 ë°ë(131e)ì ì¢ì¸¡ë©´ì¼ ì ìë¤. íê¸°ììë, ì 2 í´í¼ì¤(131) ì 1 ë°ë(131c)ì ì¢ì¸¡ë©´ì´ ì¼ ì 2 ìì©ë©´(131a)ì´ë¼ íê³ , ì 2 í´í¼ì¤(131) ì 3 ë°ë(131e)ì ì¢ì¸¡ë©´ì´ í ì 2 ìì©ë©´(131a)ì´ë¼ íë¤.In addition, the second pole piece 131 may have a plurality of second working surfaces 131a and 131b contacting a clamp 140 to be described later. Here, the plurality of second acting surfaces 131a and 131b may be the left side of the first body 131c of the second pole piece 131 and the left side of the third body 131e of the second pole piece 131 in the drawing. there is. In the following, the left side of the first body 131c of the second pole piece 131 is referred to as one second acting surface 131a, and the left side of the third body 131e of the second pole piece 131 is referred to as the other side. 2 is referred to as the working surface 131a.

**[p0037]**

ë³µìì ì 2 ìì©ë©´(131a,131b)ì ìê¸° íë¦ì´ íì±ëë©´, ë³µìì ì 2 ìì©ë©´(131a,131b)ì íì íë í´ë¨í(140)ê° ì ì´ ë° ì§ì§ë ì ìë¤. ì¦, ë°ìë ìê¸° íë¦ì´ ë³µìì ì 2 ìì©ë©´(131a,131b)ìì ë°ì°ëë©°, í´ë¨í(140)ì ì¸ë ¥ì ê°í ì ìê³ , í´ë¨í(140)ë¥¼ ë¹ê²¨ ë³µìì ì 2 ìì©ë©´(131a,131b)ì í¡ì°©ìí¬ ì ìë¤. When magnetic flow is formed on the plurality of second acting surfaces 131a and 131b, a clamp 140 described below may contact and support the plurality of second acting surfaces 131a and 131b. That is, the generated magnetic flow diverges from the plurality of second acting surfaces 131a and 131b, can apply an attractive force to the clamp 140, and pulls the clamp 140 to form a plurality of second acting surfaces 131a and 131b. can be adsorbed on. ì¬ê¸°ì, ë³µìì ì 2 ìì©ë©´(131a,131b)ì ìí¥ ê²½ì¬ì§ ê²½ì¬ë©´ì¼ë¡ íì±ë ì ìë¤. ì¦, ì¼ ì 2 ìì©ë©´(131a)ì íì±íë ì 1 ë°ë(131c)ì ì¢ì¸¡ë©´ê³¼, í ì 2 ìì©ë©´(131b)ì íì±íë ì 3 ë°ë(131e)ì ì¢ì¸¡ë©´ì´ ìí¥ ê²½ì¬ì§ í

**[p0038]**

ì´í¼ë©´ì¼ë¡ íì±ë ì ìë¤. ì´ì, ìì í ë°ì ê°ì´ í´ë¨í(140)ê° íì í ë, ë³µìì ì 2 ìì©ë©´(131a,131b)ì´ íì íë í´ë¨í(140)ì ë©´ì ì´í ì ìë¤. Here, the plurality of second acting surfaces 131a and 131b may be formed as upwardly inclined inclined surfaces. That is, the left surface of the first body 131c forming one second acting surface 131a and the left surface of the third body 131e forming the other second acting surface 131b are tapered surfaces inclined upward. can be formed as Therefore, as described above, when the clamp 140 rotates, the plurality of second acting surfaces 131a and 131b may come into surface contact with the rotating clamp 140 . ì 2 ì½ì¼(132)ì ì 2 í´í¼ì¤(131)ì ê°ê¸°ë©°, ì 2 í´í¼ì¤(131)ì ìê¸° íë¦ì ë°ììí¬ ì ìë¤. ìë¥¼ ë¤ì´, ì 2 ì½ì¼(132)ì ì 2 í´í¼ì¤(131)ì ì 2 ë°ë(131d)ì ê°ê¸¸ ì ìë¤. íì§ë§, ì 2 ì½ì¼(132)ì ì 2 í´í¼ì¤(131)ì ì 1 ë°ë(131c) í¹ì ì 2 í´í¼ì¤(131)ì ì 3 ë°ë(131e)ì ê°ê¸¸ ìë ìë¤.The second coil 132 is wound around the second pole piece 131 and can generate magnetic flow in the second pole piece 131 . For example, the second coil 132 may be wound around the second body 131d of the second pole piece 131 . However, the second coil 132 may be wound around the first body 131c of the second pole piece 131 or the third body 131e of the second pole piece 131 .

**[p0039]**

ì 2 ì½ì¼(132)ì ì ë¥ê° íë¥´ë©´, ìíë¥´ì ì¤ë¥¸ëì¬ ë²ì¹(Ampere's right-handed screw rule)ì ìí´ ì¼ì í ë°©í¥ì¼ë¡ ìê¸° íë¦ì´ íì±ëê³ , ì 2 ì½ì¼(132)ì´ ê°ê¸´ ì 2 í´í¼ì¤(131) ì 2 ë°ë(131d)ìë ìê¸° íë¦ì ë°©í¥ì ë°ë¼ Nê·¹ê³¼ Sê·¹ì´ íì±ëë¤. ì¦, ì 2 ì½ì¼(132)ì´ ê°ê¸´ ì 2 í´í¼ì¤(131) ì 2 ë°ë(131d)ë ì ìì(é»ç£ç³)ì ì­í ì ìííë êµ¬ì±ì¼ë¡ ë³¼ ì ìë¤.When current flows through the second coil 132, a magnetic flow is formed in a certain direction according to Ampere's right-handed screw rule, and the second pole piece 131 around which the second coil 132 is wound ) The N pole and the S pole are formed in the second body 131d according to the direction of the magnetic flow. That is, the second body 131d of the second pole piece 131 around which the second coil 132 is wound can be regarded as a configuration that serves as an electromagnet. í´ë¨í(140)ë ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(120)ì ì 2 í´í¼ì¤ ì´ì

**[p0040]**

ë¸ë¦¬(130) ì¬ì´ì ì´ë ê°ë¥íê² ë°°ì¹ë ì ìë¤. ë³¸ ë°ëª ì ì 1 ì¤ììììë í´ë¨í(140)ê° ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(120)ì ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(130) ì¬ì´ìì íì  ì´ë ê°ë¥íê² ë°°ì¹ëë ê²½ì°ë¥¼ ììì ì¼ë¡ ì¤ëª íë¤. í´ë¨í(140)ë ë³µìì ì 1 ìì©ë©´(121a,121b)ì ì ì´íì¬ ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(120)ì ìê¸° íë£¨íë¥¼ íì±íê±°ë, ë³µìì ì 2 ìì©ë©´(131a,131b)ì ì ì´íì¬ ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(130)ì ìê¸° íë£¨íë¥¼ íì±í ì ìë¤. í´ë¨í(140)ë ë³µìì ìì±ì²´(141), ë©ì¸ ìêµ¬ìì(142) ë° ê°ìì²´(143)ë¥¼ í¬í¨í ì ìë¤. The clamp 140 may be movably disposed between the first pole piece assembly 120 and the second pole piece assembly 130 . In the first embodiment of the present invention, a case in which the clamp 140 is disposed to be rotated between the first pole piece assembly 120 and the second pole piece assembly 130 will be described as an example. The clamp 140 contacts the plurality of first working surfaces 121a and 121b to form a magnetic closed loop with the first pole piece assembly 120, or contacts the plurality of second working surfaces 131a and 131b to form a magnetic closed loop. A magnetic closed loop with the two pole piece assembly 130 may be formed. The clamp 140 may include a plurality of magnetic bodies 141 , a main permanent magnet 142 and a pressure body 143 .

**[p0041]**

ë³µìì ìì±ì²´(141)ë ë³µìì ì 1 ìì©ë©´(121a,121b) ëë ë³µìì ì 2 ìì©ë©´(131a,131b)ì ì ì´ ê°ë¥íë©°, ìê¸°ì ì¸ ê²½ë¡ë¥¼ ì ê³µí ì ìë¤. ë³µìì ìì±ì²´(141)ë ë³µìì ì 1 ìì©ë©´(121a,121b) ëë ë³µìì ì 2 ìì©ë©´(131a,131b)ìì ë°ì°ëë ìê¸° íë¦ì ì°ê²°íì¬ ìê¸°ê° íë¥¼ ì ìë ê²½ë¡ë¥¼ íì±í ì ìëë¡, ì² ê³¼ ê°ì ê°ìì±ì²´ë¡ êµ¬ì±ë ì ìë¤. ìë¥¼ ë¤ì´, ë³µìì ìì±ì²´(141)ë ì ì¡ë©´ì²´ë¡ ë§ë ¨ë ì ìë¤.The plurality of magnetic bodies 141 may contact the plurality of first working surfaces 121a and 121b or the plurality of second working surfaces 131a and 131b and may provide a magnetic path. The plurality of magnetic bodies 141 connect magnetic flows emitted from the plurality of first acting surfaces 121a and 121b or the plurality of second acting surfaces 131a and 131b to form a path through which the magnetism can flow, It may be composed of a ferromagnetic material such as iron. For example, the plurality of magnetic bodies 141 may be provided in a regular hexahedron shape.

**[p0042]**

ë©ì¸ ìêµ¬ìì(142)ì ë³µìì ìì±ì²´(141) ì¬ì´ì ë°°ì¹ëë©°, ìë¶ ë° íë¶ê° ë³µìì ìì±ì²´(141)ì ê°ê° ê²°í©ë ì ìë¤. ë©ì¸ ìêµ¬ìì(142)ì ì ììì¼ë¡ ë§ë ¨ëê±°ë, í¹ì ì ì´ë ì¼ë¶ê° ìì±ì í¬í¨íë ìêµ¬ììì¼ë¡ ë§ë ¨ë ì ìë¤. ì¦, ë©ì¸ ìêµ¬ìì(142)ì ì ë¥ë¥¼ ê³µê¸ë°ì Nê·¹ í¹ì Sê·¹ ì¤ ì´ë íëì ê·¹ì±ì ê°ì§ëë¡ íì±ëê±°ë, ìêµ¬ì ì¼ë¡ Nê·¹, Sê·¹ì ê°ì§ëë¡ íì±ë ì ìë¤. íê¸°ììë ë©ì¸ ìêµ¬ììì´ ìêµ¬ì ì¼ë¡ Nê·¹, Sê·¹ì ê°ì§ëë¡ íì±ëë ê²½ì°ë¥¼ ììì ì¼ë¡ ì¤ëª íë¤. ëí, ë©ì¸ ìêµ¬ìì(142)ì Nê·¹ì ë³µìì ìì±ì²´(141) ì¤ ìë¶ì ìì¹í ì¼ ìì±ì²´(141a)ì ì°ê²°ëê³ , ë©ì¸ ìêµ¬ìì(142)ì Sê·¹ì ë³µìì ìì±ì²´(141) ì¤ íë¶ì ìì¹í í ìì±ì²´(141b)ì ì°ê²°ë ì ìë¤. The main permanent magnet 142 is disposed between the plurality of magnetic bodies 141, and upper and lower portions may be coupled to the plurality of magnetic bodies 141, respectively. The main permanent magnet 142 may be provided as an electromagnet, or as a permanent magnet at least partially including magnetism. That is, the main permanent magnet 142 may be formed to have either an N pole or an S pole by receiving current, or to have an N pole or an S pole permanently. In the following, a case in which the main permanent magnet is permanently formed to have an N pole and an S pole will be described as an example. In addition, the N pole of the main permanent magnet 142 is connected to one

**[p0042]**

magnetic body 141a located in the upper part of the plurality of magnetic bodies 141, and the S pole of the main permanent magnet 142 is connected to the lower one of the plurality of magnetic bodies 141. It may be connected to the other magnetic body 141b located thereon.

**[p0043]**

ê°ìì²´(143)ë ë³µìì ìì±ì²´ì ì°ê²°ëê³ , ë³µìì ìì±ì²´(141)ì ì´ëì ëìíì¬ ì§ì§ë(110)ì ìì°©ë ëìì²´(10)ë¥¼ ê°ìí ì ìë¤. ì¦, ë³µìì ìì±ì²´(141) ë° ë©ì¸ ìêµ¬ìì(142)ì´ ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(120) ëë ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(130)ì íì±íë ìê¸° íë£¨íë¥¼ íµí´, ì 1 ë°©í¥(ì¦, ìê³ë°©í¥) ëë ì 2 ë°©í¥(ì¦, ë°ìê³ë°©í¥)ì¼ë¡ íì í ë, ê°ìì²´(143)ë ë³µìì ìì±ì²´(141) ë° ë©ì¸ ìêµ¬ìì(142)ê³¼ í¨ê» ì 1 ë°©í¥(ì¦, ìê³ë°©í¥) ëë ì 2 ë°©í¥(ì¦, ë°ìê³ë°©í¥)ì¼ë¡ íì íë©° ëìì²´(10)ë¥¼ í´ë¨ííê±°ë í´ë¨íì í´ì í ì ìë¤. ê°ìì²´(143)ë ì§ì§ë¡ë(143a) ë° ê°ìëê¸°(143b)ë¥¼ í¬í¨í ì ìë¤.The pressing body 143 is connected to a plurality of magnetic bodies, and may press the target object 10 seated on the support 110 in response to the movement of the plurality of magnetic bodies 141 . That is, through a magnetic closed loop formed between the plurality of magnetic bodies 141 and the main permanent magnet 142 and the first pole piece assembly 120 or the second pole piece assembly 130, in the first direction (ie, clockwise direction) ) or when rotating in the second direction (ie, counterclockwise direction), the pressing body 143 is coupled with the plurality of magnetic bodies 141 and the main permanent magnet 142 in the first direction (ie, clockwise direction) or the second direction. It rotates in a direction (ie, counterclockwise direction) to clamp or release the clamping of the object 10 . The pre

**[p0043]**

ssing body 143 may include a support rod 143a and a pressing protrusion 143b.

**[p0044]**

ì§ì§ë¡ë(143a)ë ìíë¡ ì°ì¥ëë©°, ì§ì§ë(110)ì ì½ì í(111)ì íì  ê°ë¥íê² ë°°ì¹ë ì ìë¤. ì§ì§ë¡ë(143a)ë ê·¸ ì¤ì¬ë¶ê° ì½ì í(111)ì ë°°ì¹ëê³ , ê·¸ ìë¶ê° ì§ì§ë(110)ì ìì¸¡ì¼ë¡ ëì¶ëë©°, ê·¸ íë¶ê° ì§ì§ë(110)ì íë¶ë¡ ëì¶ë ì ìë¤. ìì»¨ë°, ì§ì§ë¡ë(143a)ë íì í(143c)ì êµ¬ë¹í ì ìê³ , íì í(143c)ì íµí´ ì§ì§ë(110)ì íì  ê°ë¥íê² ê²°í©ë ì ìë¤. íì§ë§, ì§ì§ë¡ë(143a)ê° ì§ì§ë(110)ì íì  ê°ë¥íê² ê²°í©ëë êµ¬ì¡°ë ì´ì íì ëì§ ìëë¤. The support rod 143a extends vertically and may be rotatably disposed in the insertion hole 111 of the support 110 . The support rod 143a may have a central portion disposed in the insertion hole 111 , an upper portion thereof protruding upward from the support rod 110 , and a lower portion thereof protruding downward from the support rod 110 . For example, the support rod 143a may include a rotation pin 143c and may be rotatably coupled to the support 110 through the rotation pin 143c. However, the structure in which the support rod 143a is rotatably coupled to the support 110 is not limited thereto.

**[p0045]**

ê°ìëê¸°(143b)ë ì§ì§ë¡ë(143a)ì ì¼ì¸¡ë©´ìì ëì¶ëë©°, ì§ì§ë(110)ì ìì°©ë ëìì²´(10)ì ìë¶ë¥¼ ê°ìí ì ìë¤. ìë¥¼ ë¤ì´, ê°ìëê¸°(143b)ë ì§ì§ë¡ë(143a)ì ìë¨ë¶ìì ì°ì¥ë°©í¥ì¼ë¡ ì°ì¥ë ë§ë íìì¼ë¡ íì±ë ì ìë¤. The pressing protrusion 143b protrudes from one side of the support rod 143a and can press the upper portion of the object 10 seated on the support 110 . For example, the pressing protrusion 143b may be formed in a rod shape extending in an extension direction from the upper end of the support rod 143a. íí¸, í´ë¨í(140)ì ë³µìì ìì±ì²´(141)ê° ë³µìì ì 1 ìì©ë©´(121a,121b)ì ì ì´ë ìíìì, ê°ìëê¸°(143b)ì íë¨ë¶ì ì§ì§ë(110)ì ìë¨ë¶ ì¬ì´ì ê°ê²©ì´ ëìì²´(10)ì ëê» ì´íì ê¸¸ì´ë¡ íì±ë ì ìë¤. ì´ì, í´ë¨í(140)ê° ì 1 ë°©í¥(ì¦, ìê³ë°©í¥)ì¼ë¡ íì íë©°, ê°ìëê¸°(143b)ì íë¶ê° ëìì²´(10)ì ìë¶ë¥¼ ê°ìí ì ìë¤. Meanwhile, in a state in which the plurality of magnetic bodies 141 of the clamp 140 are in contact with the plurality of first acting surfaces 121a and 121b, the distance between the lower end of the pressing protrusion 143b and the upper end of the support 110 is (10) may be formed in a length less than the thickness. Accordingly, the clamp 140 rotates in the first direction (ie, clockwise direction), and the lower portion of the pressing protrusion 143b may press the upper portion of the object 10 .

**[p0046]**

íê¸°ììë, ë 1a ë´ì§ ë 1dë¥¼ ì°¸ì¡°íì¬, í´ë¨í ì¥ì¹(100)ë¡ ëìì²´(10)ë¥¼ í´ë¨ííë ê³¼ì ì ê´í´ ì¤ëª íë¤. In the following, a process of clamping the object 10 with the clamping device 100 will be described with reference to FIGS. 1A to 1D. ë¨¼ì , ë 1aë¥¼ ì°¸ì¡°íë©´, ì 1 ì½ì¼(122) ë° ì 2 ì½ì¼(132)ì ì ìì´ ì¸ê°ëì§ ìì ì ë¥ê° íë¥´ì§ ìì ì ìë¤. ì´ë, ë©ì¸ ìêµ¬ìì(142)ì Nê·¹ê³¼ ì¸ì í ì 1 ë°ë(131c)ë Sê·¹ì¼ë¡ ìíëê³ , ë©ì¸ ìêµ¬ìì(142)ì Sê·¹ê³¼ ì¸ì í ì 3 ë°ë(131e)ë Nê·¹ì¼ë¡ ìíë ì ìë¤. ì´ì, ë 1aì ëìë ì ì ê³¼ ê°ì´, ë©ì¸ ìêµ¬ìì(142), ë³µìì ìì±ì²´(141), ì 2 í´í¼ì¤(131)ì ì 1 ë°ë(131c), ì 2 í´í¼ì¤(131)ì ì 2 ë°ë(131d), ì 2 í´í¼ì¤(131)ì ì 3 ë°ë(131e)ë¥¼ ë°ë¼ íëì ìê¸° íë£¨íê° íì±ë ì ìë¤. ë°ë¼ì, í´ë¨í(140)ê° ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(130)ì ì ì´ë ìí, ì¦ í´ë¨í(140)ê° ì 2 ë°©í¥(ì¦, ë°ìê³ë°©í¥)ì¼ë¡ íì ë ìíê° ë ì ìë¤.First, referring to FIG. 1A , since power is not applied to the first coil 122 and the second coil 132, current may not flow. At this time, the first body 131c adjacent to the N pole of the main permanent magnet 142 may be magnetized to the S pole, and the third body 131e adjacent to the S pole of the main permanent magnet 142 may be magnetized to the N pole. there is. Accordingly, as shown in the dotted line shown in FIG. 1A, the main permanent magnet 142, the plurality of magnetic bodies 141, the first body 13

**[p0046]**

1c of the second pole piece 131, the second One magnetic closed loop may be formed along the body 131d and the third body 131e of the second pole piece 131 . Accordingly, the clamp 140 may come into contact with the second pole piece assembly 130, that is, the clamp 140 may be rotated in the second direction (ie, counterclockwise direction).

**[p0047]**

ë 1bë¥¼ ì°¸ì¡°íë©´, ì 1 ì½ì¼(122)ì ì ë¥ê° íë¥´ëë¡ ì 1 ì½ì¼(122)ì ì ì´í ì ìë¤. ì´ì, ì 1 í´í¼ì¤(121) ì 2 íí¸(121d)ì ê°ê¸´ ì 1 ì½ì¼(122)ì ê¸°ì¤ì¼ë¡, ì 1 í´í¼ì¤(121) ì 2 íí¸(121d)ì íë¶ë Nê·¹ì¼ë¡ ìíëê³ , ì 1 í´í¼ì¤(121) ì 2 íí¸(121d)ì ìë¶ë Sê·¹ì¼ë¡ ìíë ì ìë¤. ëí, ì 2 ì½ì¼(132)ì ì ë¥ê° íë¥´ëë¡ ì 2 ì½ì¼(132)ì ì ì´í ì ìë¤. ì´ì, ì 2 í´í¼ì¤(131) ì 2 ë°ë(131d)ì ê°ê¸´ ì 2 ì½ì¼(132)ì ê¸°ì¤ì¼ë¡, ì 2 ë°ë(131d)ì íë¶ ë° ì 3 ë°ë(131e)ë Sê·¹ì¼ë¡ ìíëê³ , ì 2 ë°ë(131d)ì ìë¶ ë° ì 1 ë°ë(131c)ë Nê·¹ì¼ë¡ ìíë ì ìë¤. ì´ì, Nê·¹ì¼ë¡ ìíë ì 1 ë°ë(131c)ì ì¸ì í ë©ì¸ ìêµ¬ìì(142)ì Nê·¹ ì¬ì´ì ì²ë ¥ì´ ë°ìíê³ , Sê·¹ì¼ë¡ ìíë ì 3 ë°ë(131e)ì ì¸ì í ë©ì¸ ìêµ¬ìì(142)ì Sê·¹ ì¬ì´ì ì²ë ¥ì´ ë°ìí ì ìë¤. ë°ë¼ì, í´ë¨í(140)ê° ì 2 í´í¼ì¤ ì´ì

**[p0048]**

ë¸ë¦¬(130)ë¡ë¶í° ë°ë ¤ëê³ , ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(120)ì ìê¸° íë£¨íë¥¼ íì±íë©° ì 1 ë°©í¥(ì¦, ìê³ë°©í¥)ì¼ë¡ íì í ì ìë¤. Referring to FIG. 1B , the first coil 122 may be controlled so that current flows through the first coil 122 . Accordingly, based on the first coil 122 wound around the second part 121d of the first pole piece 121, the lower part of the second part 121d of the first pole piece 121 is magnetized to the N pole, The upper part of the second part 121d of the first pole piece 121 may be magnetized to the S pole. In addition, the second coil 132 may be controlled so that current flows through the second coil 132 . Accordingly, based on the second coil 132 wound around the second body 131d of the second pole piece 131, the lower part of the second body 131d and the third body 131e are magnetized to the S pole, The upper part of the second body 131d and the first body 131c may be magnetized to the N pole. Accordingly, a repulsive force is generated between the first body 131c magnetized to the N pole and the N pole of the main permanent magnet 142 adjacent to the third body 131e magnetized to the S pole and the main permanent magnet 142 adjacent to the third body 131e magnetized to the S pole. A repulsive force may occur between the S poles of Accordingly, the clamp 140 can be pushed out of the second pole piece assembly 130, form a magnetic closed loop with the first pole piece assembly 120, and can rotate in the first direction (ie, clockwise direction).

**[p0049]**

ë 1cë¥¼ ì°¸ì¡°íë©´, í´ë¨í(140)ê° ì 1 ë°©í¥(ì¦, ìê³ë°©í¥)ì¼ë¡ íì íë©°, ë³µìì ìì±ì²´(141)ê° ë³µìì ì 1 ìì©ë©´(121a,121b)ì ì ì´ë ì ìë¤. ì´ì, ë 1cì ëìë ì ì ê³¼ ê°ì´, ë©ì¸ ìêµ¬ìì(142), ë³µìì ìì±ì²´(141), ì 1 í´í¼ì¤(121) ì 1 íí¸(121c), ì 1 í´í¼ì¤(121) ì 2 íí¸(121d), ì 1 í´í¼ì¤(121) ì 3 íí¸(121e)ë¥¼ ë°ë¼ íëì ìê¸° íë£¨íê° íì±ë ì ìë¤. ë³µìì ìì±ì²´(141)ì íì ì ëìíì¬, í´ë¨í(140)ì ê°ìì²´(143)ë ì 1 ë°©í¥(ì¦, ìê³ë°©í¥)ì¼ë¡ íì íê³ , ì§ì§ë(110)ì ìì°©ë ëìì²´(10)ë¥¼ ê°ìí ì ìë¤. ì¦, ê°ìì²´(143)ê° ëìì²´(10)ë¥¼ í´ë¨íí ì ìë¤. Referring to FIG. 1C , the clamp 140 rotates in a first direction (ie, clockwise direction), and the plurality of magnetic bodies 141 may come into contact with the plurality of first working surfaces 121a and 121b. Accordingly, as shown in the dotted line shown in FIG. 121d), one magnetic closed loop may be formed along the third part 121e of the first pole piece 121 . Corresponding to the rotation of the plurality of magnetic bodies 141, the pressing body 143 of the clamp 140 also rotates in the first direction (ie, clockwise direction) to press the object 10 seated on the support 110. can That is, the pressing body 143 may clamp the target object 10 .

**[p0050]**

ì´í, ì 1 ì½ì¼(122)ì ì ë¥ê° íë¥´ì§ ìëë¡ ì ì´íì¬ë, ìì í ìê¸° íë£¨íë¥¼ íµí´ í´ë¨í(140)ê° ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(120)ì ì ì´ë ìíë¥¼ ì ì§í ì ìë¤. ì´ì ëìíì¬, ê°ìì²´(143)ë ëìì²´(10)ì í´ë¨íì ì ì§í ì ìë¤.Thereafter, even if current is controlled not to flow through the first coil 122 , the state in which the clamp 140 is in contact with the first pole piece assembly 120 can be maintained through the magnetic closed loop described above. Correspondingly, the pressing body 143 may also maintain the clamping of the target object 10 . ë 1dë¥¼ ì°¸ì¡°íë©´, ì 1 ì½ì¼(122)ì ì ë¥ê° íë¥´ëë¡ ì 1 ì½ì¼(122)ì ì ì´í ì ìë¤. ì´ì, ì 1 í´í¼ì¤(121) ì 2 íí¸(121d)ì íë¶ë Sê·¹ì¼ë¡ ìíëê³ , ì 1 í´í¼ì¤(121) ì 2 íí¸(121d)ì ìë¶ë Nê·¹ì¼ë¡ ìíë ì ìë¤. ì´ì, Nê·¹ì¼ë¡ ìíë ì 1 í´í¼ì¤(121) ì 1 íí¸(121c)ì ì¸ì í ë©ì¸ ìêµ¬ìì(142)ì Nê·¹ ì¬ì´ì ì²ë ¥ì´ ë°ìíê³ , Sê·¹ì¼ë¡ ìíë ì 1 í´í¼ì¤(121) ì 3 íí¸(121e)ì ì¸ì í ë©ì¸ ìêµ¬ìì(142)ì Sê·¹ ì¬ì´ì ì²ë ¥ì´ ë°ìí ì ìë¤. Referring to FIG. 1D , the first coil 122 may be controlled so that current flows through the first coil 122 . Accordingly, the lower portion of the second part 121d of the first pole piece 121 may be magnetized to the S pole, and the upper portion of the second part 121d of the first pole piece 121 may be magnetized to the N pole. Accordingly, a repulsive force is generated between the first part 12

**[p0050]**

1c of the first pole piece 121 magnetized to the N pole and the N pole of the adjacent main permanent magnet 142, and the first pole piece 121 magnetized to the S pole A repulsive force may be generated between the third part 121e and the south pole of the adjacent main permanent magnet 142 .

**[p0051]**

íí¸, ì 1 ì½ì¼(122)ì ì ë¥ê° íë¥´ëë¡ ì ì´í¨ê³¼ ëìì, ì 2 ì½ì¼(132)ì ì ë¥ê° íë¥´ëë¡ ì 2 ì½ì¼(132)ì ì ì´í ì ìë¤. ì´ì, ì 2 ë°ë(131d)ì íë¶ ë° ì 3 ë°ë(131e)ë Nê·¹ì¼ë¡ ìíëê³ , ì 2 ë°ë(131d)ì ìë¶ ë° ì 1 ë°ë(131c)ë Sê·¹ì¼ë¡ ìíë ì ìë¤. ë°ë¼ì, ë³µìì ìì±ì²´(141)ê° ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(120)ë¡ë¶í° ë°ë ¤ëê³ , ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(130)ì ìê¸° íë£¨íë¥¼ íì±íë©° ì 2 ë°©í¥(ì¦, ë°ìê³ë°©í¥)ì¼ë¡ íì í ì ìë¤. ë³µìì ìì±ì²´(141)ì íì ì ëìíì¬, ê°ìì²´(143)ë ì 2 ë°©í¥(ì¦, ë°ìê³ë°©í¥)ì¼ë¡ íì íë©° ëìì²´(10)ì í´ë¨íì í´ì í ì ìë¤. ì´í, ëìì²´(10)ë¥¼ ì§ì§ë(110)ì ì¸ë¶ë¡ ì´ë°íì¬, í´ë¨í ì¥ì¹(100)ë¡ë¶í° ëìì²´(10)ë¥¼ ë¶ë¦¬ìí¬ ì ìë¤.Meanwhile, the second coil 132 may be controlled so that the current flows through the second coil 132 while controlling the current to flow through the first coil 122 . Accordingly, the lower part of the second body 131d and the third body 131e may be magnetized to the N pole, and the upper part of the second body 131d and the first body 131c may be magnetized to the S pole. Accordingly, the plurality of magnetic materials 141 can be pushed out of the first pole piece assembly 120, form a magnetic closed loop with the second pole piece assembly 130, and rotate in the second direction (ie, counterclockwise direction). there is. Corresponding to the rotation of the plurality of magnetic bodies 141, the pressing body 143 may

**[p0051]**

also rotate in the second direction (ie, counterclockwise direction) to release the clamping of the object 10. Thereafter, the object 10 may be transported to the outside of the support 110 to separate the object 10 from the clamping device 100 .

**[p0052]**

ë 2a ë´ì§ ë 2dë ë³¸ ë°ëª ì ì 2 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ë¥¼ ê°ëµì ì¼ë¡ ëìí ëë©´ì´ë¤. 2A to 2D are views schematically showing a clamping device according to a second embodiment of the present invention. íê¸°ììë ë³¸ ë°ëª ì ì¤ììë¤ ì¤ ì 2 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ì êµ¬ì¡°ë¥¼ ì¤ëª íë¤. ì´ë, ë³¸ ë°ëª ì ì 1 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ì ëì¼í êµ¬ì¡°ì ê´í ì¤ëª ì ìëµíê¸°ë¡ íë¤.In the following, the structure of the clamping device according to the second embodiment of the embodiments of the present invention will be described. At this time, description of the same structure as the clamping device according to the first embodiment of the present invention will be omitted. ë³¸ ë°ëª ì ì 2 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹(200)ë ì§ì§ë(210), ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(220), ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(230) ë° í´ë¨í(240)ë¥¼ í¬í¨í ì ìë¤.The clamping device 200 according to the second embodiment of the present invention may include a support 210 , a first pole piece assembly 220 , a second pole piece assembly 230 and a clamp 240 .

**[p0053]**

íí¸, ë³¸ ë°ëª ì ì 2 ì¤ììë¥¼ ì¤ëª í¨ì ìì´ì, íê¸°ìì ê¸°ì¬ëë ì 1 ë°©í¥ì ìì í ì°ì¥ë°©í¥ ì¤ ì 1 ìì©ë©´ì í¥íë ë°©í¥ì¸ ê²½ì°ë¥¼ ììì ì¼ë¡ ì¤ëª íê³ , ì 2 ë°©í¥ì ìì í ì°ì¥ë°©í¥ ì¤ ì 2 ìì©ë©´ì í¥íë ë°©í¥ì¸ ê²½ì°ë¥¼ ììì ì¼ë¡ ì¤ëª íë¤.On the other hand, in describing the second embodiment of the present invention, the first direction described below is exemplarily described in the case of extending toward the first acting surface among the above-mentioned extension directions, and the second direction is the above-mentioned extension direction. Among the directions, the case of the direction toward the second acting surface will be described as an example. ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(230)ë ì 2 í´í¼ì¤(231) ì 1 ë°ë(231c)ì ì°ì¥ë°©í¥ ê¸¸ì´ì ì 2 í´í¼ì¤(231) ì 3 ë°ë(231e)ì ì°ì¥ë°©í¥ ê¸¸ì´ë ëì¼íê² íì±ë ì ìë¤. In the second pole piece assembly 230, the length of the first body 231c of the second pole piece 231 in the extending direction and the length of the third body 231e of the second pole piece 231 in the extending direction may be the same. there is.

**[p0054]**

í´ë¨í(240)ë ìì¸¡ë¨ì´ ê°ê° ì 1 í´í¼ì¤(221)ì ì 2 í´í¼ì¤(231)ì ì°ê²°ëë ë ì¼(244)ì ë í¬í¨í ì ìë¤. ë ì¼(244)ì ì°ì¥ë°©í¥ì ë°ë¼ ì°ì¥ëë©°, ì¼ë¨ì´ ë³µìì ì 1 ìì©ë©´(221a,221b)ì ì°ê²°ëê³ , íë¨ì´ ë³µìì ì 2 ìì©ë©´(231a,231b)ì ì°ê²°ë ì ìë¤. ì¬ê¸°ì, ë ì¼(244)ì ë³µìê°ë¡ ë§ë ¨ë ìë ìë¤. The clamp 240 may further include rails 244 having both ends connected to the first pole piece 221 and the second pole piece 231 , respectively. The rail 244 extends along the extension direction, and one end may be connected to the plurality of first acting surfaces 221a and 221b and the other end may be connected to the plurality of second acting surfaces 231a and 231b. Here, a plurality of rails 244 may be provided. ëí, ë³µìì ìì±ì²´(241a,241b)ë ë³µìì ë ì¼(244)ì ê°ê° ì´ë ê°ë¥íê² ê²°í©ë ì ìë¤. ì¦, ë³µìì ìì±ì²´(241a,241b)ë ë³µìì ë ì¼(244)ì ì°ì¥ë°©í¥ì ë°ë¼, ì íì§ ì¬ë¼ì´ë© ì´ëí ì ìë¤. In addition, the plurality of magnetic bodies 241a and 241b may be movably coupled to the plurality of rails 244 , respectively. That is, the plurality of magnetic bodies 241a and 241b may slide forward and backward along the extending direction of the plurality of rails 244 .

**[p0055]**

íê¸°ììë, ë 2a ë´ì§ ë 2dë¥¼ ì°¸ì¡°íì¬, í´ë¨í ì¥ì¹(200)ë¡ ëìì²´(20)ë¥¼ í´ë¨ííë ê³¼ì ì ê´í´ ì¤ëª íë¤. In the following, a process of clamping the object 20 with the clamping device 200 will be described with reference to FIGS. 2A to 2D. ë¨¼ì , ë 2aë¥¼ ì°¸ì¡°íë©´, ì 1 ì½ì¼(222) ë° ì 2 ì½ì¼(232)ì ì ìì´ ì¸ê°ëì§ ìì ì ë¥ê° íë¥´ì§ ìì ì ìë¤. ë©ì¸ ìêµ¬ìì(242)ì Nê·¹ê³¼ ì¸ì í ì 1 ë°ë(231c)ë Sê·¹ì¼ë¡ ìíëê³ , ë©ì¸ ìêµ¬ìì(242)ì Sê·¹ê³¼ ì¸ì í ì 3 ë°ë(231e)ë Nê·¹ì¼ë¡ ìíë ì ìë¤. ì´ì, ë 2aì ëìë ì ì ê³¼ ê°ì´, ë©ì¸ ìêµ¬ìì(242), ë³µìì ìì±ì²´(241a,241b), ì 1 í´í¼ì¤(221) ì 1 íí¸, ì 1 í´í¼ì¤(221) ì 2 íí¸, ì 1 í´í¼ì¤(221) ì 3 íí¸ë¥¼ ë°ë¼ íëì ìê¸° íë£¨íê° íì±ë ì ìë¤. ë°ë¼ì, í´ë¨í(240)ê° ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(220)ì ì ì´í ìí, ì¦ í´ë¨í(240)ê° ì 1 ë°©í¥ì¼ë¡ ì¬ë¼ì´ë© ì´ëë ìíê° ë ì ìë¤. íí¸, ì§ì§ë¡ë(243a)ë ì½ì

**[p0056]**

í(211)ë´ì ë°°ì¹ë ìíì¼ ì ìë¤.First, referring to FIG. 2A , since power is not applied to the first coil 222 and the second coil 232, current may not flow. The first body 231c adjacent to the N pole of the main permanent magnet 242 may be magnetized to the S pole, and the third body 231e adjacent to the S pole of the main permanent magnet 242 may be magnetized to the N pole. Accordingly, as shown in the dotted line shown in FIG. 2A, the main permanent magnet 242, the plurality of magnetic bodies 241a and 241b, the first part of the first pole piece 221, the second part of the first pole piece 221, and the second part of the first pole piece 221 One magnetic closed loop may be formed along the third part of one pole piece 221 . Accordingly, a state in which the clamp 240 contacts the first pole piece assembly 220, that is, a state in which the clamp 240 slides in the first direction may be obtained. Meanwhile, the support rod 243a may be disposed within the insertion hole 211 .

**[p0057]**

ë 2bë¥¼ ì°¸ì¡°íë©´, ì 1 ì½ì¼(222)ì ì ë¥ê° íë¥´ëë¡ ì 1 ì½ì¼(222)ì ì ì´í ì ìë¤. ì´ì, ì 1 í´í¼ì¤(221) ì 2 íí¸ì íë¶ë Sê·¹ì¼ë¡ ìíëê³ , ì 1 í´í¼ì¤(221) ì 2 íí¸ì ìë¶ë Nê·¹ì¼ë¡ ìíë ì ìë¤. ì´ì, Nê·¹ì¼ë¡ ìíë ì 1 í´í¼ì¤(221) ì 1 íí¸ì ì¸ì í ë©ì¸ ìêµ¬ìì(242)ì Nê·¹ ì¬ì´ì ì²ë ¥ì´ ë°ìíê³ , Sê·¹ì¼ë¡ ìíë ì 1 í´í¼ì¤(221) ì 3 íí¸(221e)ì ì¸ì í ë©ì¸ ìêµ¬ìì(242)ì Sê·¹ ì¬ì´ì ì²ë ¥ì´ ë°ìí ì ìë¤. ë°ë¼ì, í´ë¨í(240)ê° ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(220)ë¡ë¶í° ë°ë ¤ë ì ìë¤. ì¦, ì§ì§ë¡ë(243a)ê° ì½ì í(211) ë´ìì ì ì§íê³ , ì§ì§ë¡ë(243a)ì ì´ëì ëìíì¬, ê°ìëê¸°(243b)ë ì ì§í ì ìë¤.Referring to FIG. 2B , the first coil 222 may be controlled so that current flows through the first coil 222 . Accordingly, the lower part of the second part of the first pole piece 221 may be magnetized to the S pole, and the upper part of the second part of the first pole piece 221 may be magnetized to the N pole. Accordingly, a repulsive force is generated between the first part of the first pole piece 221 magnetized to the N pole and the N pole of the adjacent main permanent magnet 242, and the third part of the first pole piece 221 magnetized to the S pole. A repulsive force may occur between 221e and the south pole of the adjacent main permanent magnet 242 . Thus, the clamp 240 can be pushed out of the first pole piece assembly 220 . That is, the support rod 243a advances within the inse

**[p0057]**

rtion hole 211, and the pressing protrusion 243b may also advance in response to the movement of the support rod 243a.

**[p0058]**

ëí, ì 1 ì½ì¼(222)ì ì ë¥ê° íë¥´ëë¡ ì ì´í¨ê³¼ ëìì, ì 2 ì½ì¼(232)ì ì ë¥ê° íë¥´ëë¡ ì 2 ì½ì¼(232)ì ì ì´í ì ìë¤. ì´ì, ì 2 ë°ë(231d)ì íë¶ ë° ì 3 ë°ë(231e)ë Nê·¹ì¼ë¡ ìíëê³ , ì 2 ë°ë(231d)ì ìë¶ ë° ì 1 ë°ë(231c)ë Sê·¹ì¼ë¡ ìíë ì ìë¤. ì´ì, í´ë¨í(240)ê° ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(230)ì ìê¸° íë£¨íë¥¼ íì±íë©° ì 2 ë°©í¥ì¼ë¡ ì¬ë¼ì´ë© ì´ëí ì ìë¤. ì¦, ë³µìì ìì±ì²´(241a,241b)ê° ë³µìì ì 1 ìì©ë©´(221a,221b)ì¼ë¡ë¶í° ì´ê²©ëë©° ë³µìì ë ì¼(244)ì ë°ë¼ ì 2 ë°©í¥ì¼ë¡ ì¬ë¼ì´ë© ì´ëí ì ìë¤. In addition, the second coil 232 may be controlled so that the current flows through the second coil 232 while controlling the current to flow through the first coil 222 . Accordingly, the lower part of the second body 231d and the third body 231e may be magnetized to the N pole, and the upper part of the second body 231d and the first body 231c may be magnetized to the S pole. Accordingly, the clamp 240 can slide in the second direction while forming a magnetic closed loop with the second pole piece assembly 230 . That is, the plurality of magnetic materials 241a and 241b are spaced apart from the plurality of first acting surfaces 221a and 221b and can slide along the plurality of rails 244 in the second direction.

**[p0059]**

ë 2cë¥¼ ì°¸ì¡°íë©´, ë³µìì ìì±ì²´(241a,241b)ê° ì 2 ë°©í¥ì¼ë¡ ì¬ë¼ì´ë© ì´ëíë©°, ë³µìì ìì±ì²´(241a,241b)ê° ë³µìì ì 2 ìì©ë©´(231a,231b)ì ë©´ì ì´ë ì ìë¤. ì´ì, ë 2cì ëìë ì ì ê³¼ ê°ì´, ë©ì¸ ìêµ¬ìì(242), ë³µìì ìì±ì²´(241a,241b), ì 2 í´í¼ì¤(231) ì 1 ë°ë(231c), ì 2 í´í¼ì¤(231) ì 2 ë°ë(231d), ì 2 í´í¼ì¤(231) ì 3 ë°ë(231e)ë¥¼ ë°ë¼ íëì ìê¸° íë£¨íê° íì±ë ì ìë¤. ë³µìì ìì±ì²´(241a,241b)ì ì´ëì ëìíì¬, ì§ì§ë¡ë(243a) ë° ê°ìëê¸°(243b)ë ì 2 ë°©í¥ì¼ë¡ ì¬ë¼ì´ë© ì´ëíë©°, ì§ì§ë(210)ì ìì°©ë ëìì²´(20)ë¥¼ ê°ìí ì ìë¤. ì¦, ê°ìì²´(243)ê° ëìì²´(20)ë¥¼ í´ë¨íí ì ìë¤. Referring to FIG. 2C , the plurality of magnetic bodies 241a and 241b slide in the second direction, and the plurality of magnetic bodies 241a and 241b may come into surface contact with the plurality of second working surfaces 231a and 231b. Therefore, as shown in the dotted line shown in FIG. 2C, the main permanent magnet 242, the plurality of magnetic bodies 241a and 241b, the second pole piece 231, the first body 231c, the second pole piece 231, the second One magnetic closed loop may be formed along the body 231d, the second pole piece 231 and the third body 231e. In response to the movement of the plurality of magnetic bodies 241a and 241b, the support rod 243a and the pressure protrusion 243b also slide in the second direction, and can press the object 20 seated on the support 210. . That is, the pressing body 243 may clam

**[p0059]**

p the target object 20 .

**[p0060]**

ì´í, ì 2 ì½ì¼(232)ì ì ë¥ê° íë¥´ì§ ìëë¡ ì ì´íì¬ë, ìì í ìê¸° íë£¨íë¥¼ íµí´ í´ë¨í(240)ê° ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(230)ì ì ì´ë ìíë¥¼ ì ì§í ì ìë¤. ì´ì ëìíì¬, ê°ìì²´(243)ë ëìì²´(20)ì í´ë¨íì ì ì§í ì ìë¤.Thereafter, even if current is controlled not to flow through the second coil 232 , the state in which the clamp 240 is in contact with the second pole piece assembly 230 can be maintained through the magnetic closed loop described above. Correspondingly, the pressing body 243 may also maintain the clamping of the target object 20 . ë 2dë¥¼ ì°¸ì¡°íë©´, ì 2 ì½ì¼(232)ì ì ë¥ê° íë¥´ëë¡ ì 2 ì½ì¼(232)ì ì ì´í ì ìë¤. ì´ì, ì 2 í´í¼ì¤(231) ì 2 ë°ë(231d)ì íë¶ë Sê·¹ì¼ë¡ ìíëê³ , ì 2 í´í¼ì¤(231) ì 2 ë°ë(231d)ì ìë¶ë Nê·¹ì¼ë¡ ìíë ì ìë¤. ì´ì, Nê·¹ì¼ë¡ ìíë ì 2 í´í¼ì¤(231) ì 1 ë°ë(231c)ì ì¸ì í ë©ì¸ ìêµ¬ìì(242)ì Nê·¹ ì¬ì´ì ì²ë ¥ì´ ë°ìíê³ , Sê·¹ì¼ë¡ ìíë ì 2 í´í¼ì¤(231) ì 3 ë°ë(231e)ì ì¸ì í ë©ì¸ ìêµ¬ìì(242)ì Sê·¹ ì¬ì´ì ì²ë ¥ì´ ë°ìí ì ìë¤. Referring to FIG. 2D , the second coil 232 may be controlled so that current flows through the second coil 232 . Accordingly, the lower part of the second body 231d of the second pole piece 231 may be magnetized to the S pole, and the upper part of the second body 231d of the second pole piece 231 may be magnetized to the N pole. Accordingly, a repulsive force is generated between the first body 23

**[p0060]**

1c of the second pole piece 231 magnetized to the N pole and the N pole of the adjacent main permanent magnet 242, and the second pole piece 231 magnetized to the S pole A repulsive force may be generated between the third body 231e and the S pole of the adjacent main permanent magnet 242 .

**[p0061]**

íí¸, ì 1 ì½ì¼(222)ìë ì ë¥ê° íë¥´ëë¡ ì 1 ì½ì¼(222)ì ì ì´í ì ìë¤. ì´ì, ì 1 í´í¼ì¤(221) ì 2 íí¸(221d)ì íë¶ ë° ì 3 íí¸(221e)ë Nê·¹ì¼ë¡ ìíëê³ , ì 1 í´í¼ì¤(221) ì 2 íí¸(221d)ì ìë¶ ë° ì 1 íí¸(221c)ë Sê·¹ì¼ë¡ ìíë ì ìë¤. ë°ë¼ì, ë³µìì ìì±ì²´(241a,241b)ê° ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(230)ë¡ë¶í° ë°ë ¤ëê³ , ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(220)ì ìê¸° íë£¨íë¥¼ íì±íë©° ì 1 ë°©í¥ì¼ë¡ ì¬ë¼ì´ë© ì´ëí ì ìë¤. ë³µìì ìì±ì²´(241a,241b)ì ì´ëì ëìíì¬, ê°ìì²´(243)ë ì 1 ë°©í¥ì¼ë¡ ì¬ë¼ì´ë© ì´ëíë©° ëìì²´(20)ì í´ë¨íì í´ì í ì ìë¤. ì´í, ëìì²´(20)ë¥¼ ì§ì§ë(210)ì ì¸ë¶ë¡ ì´ë°íì¬, í´ë¨í ì¥ì¹(200)ë¡ë¶í° ëìì²´(20)ë¥¼ ë¶ë¦¬ìí¬ ì ìë¤.Meanwhile, the first coil 222 may be controlled so that current also flows through the first coil 222 . Accordingly, the lower part of the second part 221d and the third part 221e of the first pole piece 221 are magnetized to the N pole, and the upper part of the second part 221d and the first part of the first pole piece 221 221 (221c) can be magnetized to the south pole. Accordingly, the plurality of magnetic bodies 241a and 241b are pushed out of the second pole piece assembly 230 and form a magnetic closed loop with the first pole piece assembly 220 to slide in the first direction. Corresponding to the movement of the plurality of magnetic bodies 241a and 241b, the pressing body 243 may also slide in the first direction and release the clamping of

**[p0061]**

the object 20. Thereafter, the object 20 may be transported to the outside of the support 210 to separate the object 20 from the clamping device 200 .

**[p0062]**

ë 3a ë´ì§ ë 3dë ë³¸ ë°ëª ì ì 3 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ë¥¼ ê°ëµì ì¼ë¡ ëìí ëë©´ì´ë¤. íê¸°ììë ë³¸ ë°ëª ì ì¤ììë¤ ì¤ ì 3 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ì êµ¬ì¡°ë¥¼ ì¤ëª íë¤. ì´ë, ë³¸ ë°ëª ì ì 1 ì¤ìì ë´ì§ ì 2 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ì ëì¼í êµ¬ì¡°ì ê´í ì¤ëª ì ìëµíê¸°ë¡ íë¤.3A to 3D are views schematically showing a clamping device according to a third embodiment of the present invention. In the following, the structure of the clamping device according to the third embodiment of the embodiments of the present invention will be described. At this time, description of the same structure as the clamping device according to the first to second embodiments of the present invention will be omitted. ë³¸ ë°ëª ì ì 3 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹(300)ë ì§ì§ë(310), ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(320), ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(330) ë° í´ë¨í(340)ë¥¼ í¬í¨í ì ìë¤.The clamping device 300 according to the third embodiment of the present invention may include a support 310 , a first pole piece assembly 320 , a second pole piece assembly 330 and a clamp 340 .

**[p0063]**

íí¸, ë³¸ ë°ëª ì ì 3 ì¤ììë¥¼ ì¤ëª í¨ì ìì´ì, íê¸°ìì ê¸°ì¬ëë ì 1 ë°©í¥ì ìê³ë°©í¥ì¸ ê²½ì°ë¥¼ ììì ì¼ë¡ ì¤ëª íê³ , ì 2 ë°©í¥ì ë°ìê³ë°©í¥ì¸ ê²½ì°ë¥¼ ììì ì¼ë¡ ì¤ëª íë¤.On the other hand, in describing the third embodiment of the present invention, the first direction described below will be exemplarily described as a clockwise direction, and the second direction will be exemplarily described as a counterclockwise direction. ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(320)ì ì 1 í´í¼ì¤(321)ë ì°ì¥ë°©í¥ì¼ë¡ ì°ì¥ë ë§ë íìì¼ë¡ íì±ë ì ìë¤. ëí, ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(320)ë ì 1 í´í¼ì¤(321)ê³¼ ì 1 ì½ì¼(322)ì ëíì¬, ì 1 ë³´ì¡°í´í¼ì¤(323), ì 1 ê³ ì  ìêµ¬ìì(334) ë° ì 1 íì  ìêµ¬ìì(335)ì ë í¬í¨í ì ìë¤. The first pole piece 321 of the first pole piece assembly 320 may be formed in a rod shape extending in an extension direction. In addition, the first pole piece assembly 320 includes a first auxiliary pole piece 323, a first fixed permanent magnet 334 and a first rotating permanent magnet in addition to the first pole piece 321 and the first coil 322. A magnet 335 may be further included.

**[p0064]**

ì 1 ë³´ì¡°í´í¼ì¤(323)ë ì°ì¥ë°©í¥ì¼ë¡ ì°ì¥ëê³ , ì¸¡ë¶ì ì 1 ë³´ì¡°ìì©ë©´(323a)ì ê°ì§ ì ìë¤. ëí, ì 1 ë³´ì¡°í´í¼ì¤(323)ë ì 1 í´í¼ì¤(321)ë³´ë¤ ì§ì§ë(310)ì ë ê°ê¹ê² ë°°ì¹ëê³ , ì 1 í´í¼ì¤(321)ì ëí¥ë ì ìë¤. ì¦, ì 1 ë³´ì¡°í´í¼ì¤(323)ë ëë©´ì ì 1 í´í¼ì¤(321)ë³´ë¤ ìì¸¡ì ë°°ì¹ë ì ìë¤.The first auxiliary pole piece 323 may extend in an extension direction and have a first auxiliary action surface 323a on a side portion. In addition, the first auxiliary pole piece 323 may be disposed closer to the support 310 than the first pole piece 321 and may face the first pole piece 321 . That is, the first auxiliary pole piece 323 may be disposed above the first pole piece 321 in the drawing. ëí, ì 1 ë³´ì¡°í´í¼ì¤(323)ë ìê¸°ê° íë¥¼ ì ìë ê²½ë¡ë¥¼ íì±í ì ìë¤. ìë¥¼ ë¤ì´, ì 1 ë³´ì¡°í´í¼ì¤(323)ë ì² ê³¼ ê°ì ê°ìì±ì²´ë¡ êµ¬ì±ë ì ìë¤. ì´ì, ì 1 í´í¼ì¤(321)ìë ìê¸°ê° íë¥¼ ì ìì¼ë©°, íì íë í´ë¨í(340)ì ìê¸° íë£¨íë¥¼ íì±í ì ìë¤. In addition, the first auxiliary pole piece 323 may form a path through which magnetism may flow. For example, the first auxiliary pole piece 323 may be made of a ferromagnetic material such as iron. Accordingly, magnetism may flow through the first pole piece 321, and a magnetic closed loop may be formed with the clamp 340 to be described later.

**[p0065]**

ì 1 ê³ ì  ìêµ¬ìì(334)ì ì 1 í´í¼ì¤(321)ì ì 1 ë³´ì¡°í´í¼ì¤(323) ì¬ì´ì ë°°ì¹ëë©°, ìë¶ ë° íë¶ê° ì 1 í´í¼ì¤(321)ì ì 1 ë³´ì¡°í´í¼ì¤(323)ì ê°ê° ê²°í©ë ì ìë¤. ì 1 ê³ ì  ìêµ¬ìì(334)ì ìêµ¬ì ì¼ë¡ Nê·¹ ë° Sê·¹ì ê°ì§ëë¡ íì±ëë©°, Sê·¹ì ì 1 ë³´ì¡°í´í¼ì¤(323)ì ì°ê²°ëê³ , Nê·¹ì ì 1 í´í¼ì¤(321)ì ì°ê²°ë ì ìë¤.The first fixed permanent magnet 334 is disposed between the first pole piece 321 and the first auxiliary pole piece 323, and the upper and lower parts are the first pole piece 321 and the first auxiliary pole piece 323. can be combined with each other. The first fixed permanent magnet 334 is permanently formed to have an N pole and an S pole, the S pole can be connected to the first auxiliary pole piece 323, and the N pole can be connected to the first pole piece 321. there is. ì 1 íì  ìêµ¬ìì(335)ì ì 1 í´í¼ì¤(321)ì ì 1 ë³´ì¡°í´í¼ì¤(323) ì¬ì´ì ë°°ì¹ëê³ , ì 1 í´í¼ì¤(321)ì ê°ê¸´ ì 1 ì½ì¼(322)ì íë¥´ë ì ë¥ì ìí´ íì í ì ìë¤. ì 1 íì  ìêµ¬ìì(335)ì ì 1 ê³ ì  ìêµ¬ìì(334)ì ê¸°ì¤ì¼ë¡ ì°ì¥ë°©í¥ì¼ë¡ ì´ê²© ë°°ì¹ë ì ìë¤. ì¦, ì 1 íì  ìêµ¬ìì(335)ì ëë©´ì ì 1 ê³ ì  ìêµ¬ìì(334)ì ì¢ì¸¡ì ë°°ì¹ë ì ìë¤. ì´ì, ì 1 íì  ìêµ¬ìì(335)ì´ ì 1 ê³ ì  ìêµ¬ìì(334)ê³¼ ìíë°©í¥ì ë°ë¼ ë°°ì¹ë ê²½ì°ë³´ë¤, ì 1 í´í¼ì¤ ì´ì

**[p0066]**

ë¸ë¦¬(320)ì ëì´ê° ìëì ì¼ë¡ ê°ìë ì ìì¼ë©°, í´ë¨í ì¥ì¹(300)ì ì ì²´ í¬ê¸°ê° ì»´í©í¸íê² íì±ë ì ìë¤. ì 1 íì  ìêµ¬ìì(335)ì ìêµ¬ì ì¼ë¡ Nê·¹ ë° Sê·¹ì ê°ì§ëë¡ íì±ë ì ìì¼ë©°, íì ì ìí´ Nê·¹ Sê·¹ì ë°°ì¹ê° ë°ë ì ìë¤. The first rotating permanent magnet 335 is disposed between the first pole piece 321 and the first auxiliary pole piece 323, and is driven by a current flowing in the first coil 322 wound around the first pole piece 321. can rotate The first rotating permanent magnets 335 may be spaced apart from the first fixed permanent magnets 334 in an extension direction. That is, the first rotating permanent magnet 335 may be disposed on the left side of the first fixed permanent magnet 334 in the drawing. Therefore, the height of the first pole piece assembly 320 can be relatively reduced compared to the case where the first rotating permanent magnet 335 and the first fixed permanent magnet 334 are arranged vertically, and the clamping device ( 300) can be compactly formed. The first rotating permanent magnet 335 may be permanently formed to have an N pole and an S pole, and the arrangement of the N pole and the S pole may be changed by rotation.

**[p0067]**

íí¸, ì 1 íì  ìêµ¬ìì(335)ì ê·¸ Sê·¹ì´ ì 1 í´í¼ì¤(321)ì ê·¼ì íë©° ì 1 í´í¼ì¤(321)ì ìê¸°ì ì¼ë¡ ì°ê²°ëê³ , ê·¸ Nê·¹ì´ ì 1 ë³´ì¡°í´í¼ì¤(323)ì ê·¼ì íë©° ì 1 ë³´ì¡°í´í¼ì¤(323)ì ìê¸°ì ì¼ë¡ ì°ê²°ëë ì 1 ìì¹(ë 3a ì°¸ì¡°)ì, ê·¸ Nê·¹ì´ ì 1 í´í¼ì¤(321)ì ê·¼ì íì¬ ì 1 í´í¼ì¤(321)ì ìê¸°ì ì¼ë¡ ì°ê²°ëê³ , ê·¸ Sê·¹ì´ ì 1 ë³´ì¡°í´í¼ì¤(323)ì ê·¼ì íì¬ ì 1 ë³´ì¡°í´í¼ì¤(323)ì ìê¸°ì ì¼ë¡ ì°ê²°ëë ì 2 ìì¹(ë 3c ì°¸ì¡°) ì¬ì´ìì íì  ê°ë¥íê² ë°°ì¹ëë¤.On the other hand, the first rotating permanent magnet 335 has its S pole close to the first pole piece 321 and is magnetically connected to the first pole piece 321, and its N pole is the first auxiliary pole piece 323. ) and magnetically connected to the first auxiliary pole piece 323 (see FIG. 3A), and the N pole is close to the first pole piece 321, so that the first pole piece 321 and It is magnetically connected and is rotatably disposed between the second position (see FIG. 3c) where the S pole is close to the first auxiliary pole piece 323 and magnetically connected to the first auxiliary pole piece 323. .

**[p0068]**

ì 1 íì  ìêµ¬ìì(335)ì´ ì 1 í´í¼ì¤(321) ëë ì 1 ë³´ì¡°í´í¼ì¤(323)ì "ìê¸°ì ì¼ë¡ ì°ê²°ëë¤"ë ê²ì, ì 1 íì  ìêµ¬ìì(335)ì´ ì 1 í´í¼ì¤(321) ëë ì 1 ë³´ì¡°í´í¼ì¤(323)ì ì§ì ì , ë¬¼ë¦¬ì ì¼ë¡ ì ì´ëì§ ìëë¼ë ì 1 íì  ìêµ¬ìì(335)ì ìí´ ì 1 í´í¼ì¤(321) ëë ì 1 ë³´ì¡°í´í¼ì¤(323)ì ìê¸°ì ì¸ íë¦ì´ íì±ë ì ìì ì ëë¡ ì´ê²©ë ê²ì í¬í¨íë¤. The fact that the first rotating permanent magnet 335 is âmagnetically connectedâ with the first pole piece 321 or the first auxiliary pole piece 323 means that the first rotating permanent magnet 335 is the first pole piece ( 321) or the first auxiliary pole piece 323, the first pole piece 321 or the first auxiliary pole piece 323 is not directly or physically contacted by the first rotating permanent magnet 335. Including those spaced apart enough to form. ìë¥¼ ë¤ì´, ì 1 íì  ìêµ¬ìì(335)ì´ ì 1 í´í¼ì¤(321) ëë ì 1 ë³´ì¡°í´í¼ì¤(323)ì ì ì´í ë ë°ìíë ìê¸° íë¦ì ì¸ê¸°ì ë¹í´, A% ì´ìì ì¸ê¸°ì ìê¸° íë¦ì´ ì 1 í´í¼ì¤(321) ëë ì 1 ë³´ì¡°í´í¼ì¤(323)ì íì±ëë ê²½ì°, ì 1 íì  ìêµ¬ìì(335)ê³¼ ì 1 í´í¼ì¤(321) ëë ì 1 ë³´ì¡°í´í¼ì¤(323)ë ìê¸°ì ì¼ë¡ ì°ê²°ëìë¤ê³ í ì ìë¤. ì¬ê¸°ì, Aë 80, 70, 60, 50, 40, 30, 20 ë±ì¼ ì ìë¤.For example, compared to the intensity of magnetic flow generated when the first rotating permanent magnet 335 contacts the first pole piece 321 or the first auxiliary pole piece 323, the magnetic fl

**[p0068]**

ow has an intensity of A% or more. When formed on the first pole piece 321 or the first auxiliary pole piece 323, the first rotating permanent magnet 335 and the first pole piece 321 or the first auxiliary pole piece 323 are magnetically can be said to be connected. Here, A may be 80, 70, 60, 50, 40, 30, 20 or the like.

**[p0069]**

ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(330)ì ì 2 í´í¼ì¤(331)ë ì°ì¥ë°©í¥ì¼ë¡ ì°ì¥ë ë§ë íìì¼ë¡ íì±ë ì ìë¤. ëí, ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(330)ë ì 2 í´í¼ì¤(331)ê³¼ ì 2 ì½ì¼(332)ì ëíì¬, ì 2 ë³´ì¡°í´í¼ì¤(333), ì 2 ê³ ì  ìêµ¬ìì(334) ë° ì 2 íì  ìêµ¬ìì(335)ì ë í¬í¨í ì ìë¤. The second pole piece 331 of the second pole piece assembly 330 may be formed in a rod shape extending in an extension direction. In addition, the second pole piece assembly 330 includes a second auxiliary pole piece 333, a second fixed permanent magnet 334, and a second rotating permanent magnet in addition to the second pole piece 331 and the second coil 332. A magnet 335 may be further included. ì 2 ë³´ì¡°í´í¼ì¤(333)ë ì°ì¥ë°©í¥ì¼ë¡ ì°ì¥ëê³ , ì¸¡ë¶ì ì 2 ë³´ì¡°ìì©ë©´(333a)ì ê°ì§ ì ìë¤. ëí, ì 2 ë³´ì¡°í´í¼ì¤(333)ë ì 2 í´í¼ì¤(331)ë³´ë¤ ì§ì§ë(310)ì ë ê°ê¹ê² ë°°ì¹ëê³ , ì 2 í´í¼ì¤(331)ì ëí¥ë ì ìë¤. ì¦, ì 2 ë³´ì¡°í´í¼ì¤(333)ë ëë©´ì ì 2 í´í¼ì¤(331)ë³´ë¤ ìì¸¡ì ë°°ì¹ë ì ìë¤.The second auxiliary pole piece 333 extends in an extension direction and may have a second auxiliary action surface 333a on a side portion. In addition, the second auxiliary pole piece 333 may be disposed closer to the support 310 than the second pole piece 331 and may face the second pole piece 331 . That is, the second auxiliary pole piece 333 may be disposed above the second pole piece 331 in the drawing.

**[p0070]**

ëí, ì 2 ë³´ì¡°í´í¼ì¤(333)ë ìê¸°ê° íë¥¼ ì ìë ê²½ë¡ë¥¼ íì±í ì ìë¤. ìë¥¼ ë¤ì´, ì 2 ë³´ì¡°í´í¼ì¤(333)ë ì² ê³¼ ê°ì ê°ìì±ì²´ë¡ êµ¬ì±ë ì ìë¤. ì´ì, ì 2 í´í¼ì¤(331)ìë ìê¸°ê° íë¥¼ ì ìì¼ë©°, íì íë í´ë¨í(340)ì ìê¸° íë£¨íë¥¼ íì±í ì ìë¤.In addition, the second auxiliary pole piece 333 may form a path through which magnetism may flow. For example, the second auxiliary pole piece 333 may be made of a ferromagnetic material such as iron. Accordingly, magnetism may flow through the second pole piece 331, and a magnetic closed loop may be formed with the clamp 340 to be described later. ëí, ì 2 ë³´ì¡°í´í¼ì¤(333)ë ì 2 í´í¼ì¤(331)ë³´ë¤ ê¸´ ê¸¸ì´ë¡ íì±ë ì ìë¤. ì¬ê¸°ì, ì 2 ë³´ì¡°ìì©ë©´(333a)ì ìí¥ ê²½ì¬ì§ ê²½ì¬ë©´ì¼ë¡ íì±ë ì ìë¤. ì¦, ì 2 ë³´ì¡°ìì©ë©´(333a)ì íì±íë ì 2 ë³´ì¡°í´í¼ì¤(333)ì ì¢ì¸¡ë©´ì´ ìí¥ ê²½ì¬ì§ í ì´í¼ë©´ì¼ë¡ íì±ë ì ìë¤. Also, the second auxiliary pole piece 333 may be formed to have a longer length than the second pole piece 331 . Here, the second auxiliary action surface 333a may be formed as an upwardly inclined inclined surface. That is, the left side of the second auxiliary pole piece 333 forming the second auxiliary action surface 333a may be formed as an upwardly inclined tapered surface.

**[p0071]**

ì 2 ê³ ì  ìêµ¬ìì(334)ì ì 2 í´í¼ì¤(331)ì ì 2 ë³´ì¡°í´í¼ì¤(333) ì¬ì´ì ë°°ì¹ëë©°, ìë¶ ë° íë¶ê° ì 2 í´í¼ì¤(331)ì ì 2 ë³´ì¡°í´í¼ì¤(333)ì ê°ê° ê²°í©ë ì ìë¤. ì 2 ê³ ì  ìêµ¬ìì(334)ì ìêµ¬ì ì¼ë¡ Nê·¹ ë° Sê·¹ì ê°ì§ëë¡ íì±ëë©°, ê·¸ Sê·¹ì ì 2 ë³´ì¡°í´í¼ì¤(333)ì ì°ê²°ëê³ , ê·¸ Nê·¹ì ì 2 í´í¼ì¤(331)ì ì°ê²°ë ì ìë¤.The second fixed permanent magnet 334 is disposed between the second pole piece 331 and the second auxiliary pole piece 333, and the upper and lower parts are the second pole piece 331 and the second auxiliary pole piece 333. can be combined with each other. The second fixed permanent magnet 334 is permanently formed to have an N pole and an S pole, the S pole is connected to the second auxiliary pole piece 333, and the N pole is connected to the second pole piece 331. can be connected ì 2 íì  ìêµ¬ìì(335)ì ì 2 í´í¼ì¤(331)ì ì 2 ë³´ì¡°í´í¼ì¤(333) ì¬ì´ì ë°°ì¹ëê³ , ì 2 í´í¼ì¤(331)ì ê°ê¸´ ì 2 ì½ì¼(332)ì íë¥´ë ì ë¥ì ìí´ íì ë ì ìë¤. ì 2 íì  ìêµ¬ìì(335)ì ì 2 ê³ ì  ìêµ¬ìì(334)ì ê¸°ì¤ì¼ë¡ ì°ì¥ë°©í¥ì¼ë¡ ì´ê²© ë°°ì¹ë ì ìë¤. ì¦, ì 2 íì  ìêµ¬ìì(335)ì ëë©´ì ì 2 ê³ ì  ìêµ¬ìì(334)ì ì°ì¸¡ì ë°°ì¹ë ì ìë¤. ì´ì, ì 2 í´í¼ì¤ ì´ì

**[p0072]**

ë¸ë¦¬(330)ì ëì´ê° ìëì ì¼ë¡ ê°ìë ì ìì¼ë©°, í´ë¨í ì¥ì¹(300)ì ì ì²´ í¬ê¸°ê° ì»´í©í¸íê² íì±ë ì ìë¤. ì 2 íì  ìêµ¬ìì(335)ì ìêµ¬ì ì¼ë¡ Nê·¹ ë° Sê·¹ì ê°ì§ëë¡ íì±ë ì ìì¼ë©°, íì ì ìí´ Nê·¹ Sê·¹ì ë°°ì¹ê° ë°ë ì ìë¤. The second rotating permanent magnet 335 is disposed between the second pole piece 331 and the second auxiliary pole piece 333, by the current flowing in the second coil 332 wound around the second pole piece 331. can be rotated The second rotating permanent magnets 335 may be spaced apart from the second fixed permanent magnets 334 in an extension direction. That is, the second rotating permanent magnet 335 may be disposed on the right side of the second fixed permanent magnet 334 in the drawing. Accordingly, the height of the second pole piece assembly 330 can be relatively reduced, and the overall size of the clamping device 300 can be compactly formed. The second rotating permanent magnet 335 may be permanently formed to have an N pole and an S pole, and the arrangement of the N pole and the S pole may be changed by rotation.

**[p0073]**

íí¸, ì 2 íì  ìêµ¬ìì(335)ì ê·¸ Nê·¹ì´ ì 2 í´í¼ì¤(331)ì ê·¼ì íë©° ì 2 í´í¼ì¤(331)ì ìê¸°ì ì¼ë¡ ì°ê²°ëê³ , ê·¸ Sê·¹ì´ ì 2 ë³´ì¡°í´í¼ì¤(333)ì ê·¼ì íë©° ì 2 ë³´ì¡°í´í¼ì¤(333)ì ìê¸°ì ì¼ë¡ ì°ê²°ëë ì 2 ìì¹(ë 3a ì°¸ì¡°)ì, ê·¸ Sê·¹ì´ ì 2 í´í¼ì¤(331)ì ê·¼ì íì¬ ì 2 í´í¼ì¤(331)ì ìê¸°ì ì¼ë¡ ì°ê²°ëê³ , ê·¸ Nê·¹ì´ ì 2 ë³´ì¡°í´í¼ì¤(333)ì ê·¼ì íì¬ ì 2 ë³´ì¡°í´í¼ì¤(333)ì ìê¸°ì ì¼ë¡ ì°ê²°ëë ì 2 ìì¹(ë 3c ì°¸ì¡°) ì¬ì´ìì íì  ê°ë¥íê² ë°°ì¹ëë¤.On the other hand, the N pole of the second rotating permanent magnet 335 is close to the second pole piece 331 and is magnetically connected to the second pole piece 331, and its S pole is the second auxiliary pole piece 333. ) and is magnetically connected to the second auxiliary pole piece 333 (see FIG. 3A), and the S-pole is close to the second pole piece 331, so that the second pole piece 331 and It is magnetically connected and is rotatably disposed between a second position (see FIG. 3c) where the N pole is close to the second auxiliary pole piece 333 and magnetically connected to the second auxiliary pole piece 333. .

**[p0074]**

ì 2 íì  ìêµ¬ìì(335)ì´ ì 2 í´í¼ì¤(331) ëë ì 2 ë³´ì¡°í´í¼ì¤(333)ì "ìê¸°ì ì¼ë¡ ì°ê²°ëë¤"ë ê²ì, ì 2 íì  ìêµ¬ìì(335)ì´ ì 2 í´í¼ì¤(331) ëë ì 2 ë³´ì¡°í´í¼ì¤(333)ì ì§ì ì , ë¬¼ë¦¬ì ì¼ë¡ ì ì´ëì§ ìëë¼ë ì 2 íì  ìêµ¬ìì(335)ì ìí´ ì 2 í´í¼ì¤(331) ëë ì 2 ë³´ì¡°í´í¼ì¤(333)ì ìê¸°ì ì¸ íë¦ì´ íì±ë ì ìì ì ëë¡ ì´ê²©ë ê²ì í¬í¨íë¤. The fact that the second rotating permanent magnet 335 is âmagnetically connectedâ with the second pole piece 331 or the second auxiliary pole piece 333 means that the second rotating permanent magnet 335 is the second pole piece ( 331) or the second auxiliary pole piece 333, even if it is not in direct or physical contact, a magnetic flow is generated in the second pole piece 331 or the second auxiliary pole piece 333 by the second rotating permanent magnet 335. Including those spaced apart enough to form. ìë¥¼ ë¤ì´, ì 2 íì  ìêµ¬ìì(335)ì´ ì 2 í´í¼ì¤(331) ëë ì 2 ë³´ì¡°í´í¼ì¤(333)ì ì ì´í ë ë°ìíë ìê¸° íë¦ì ì¸ê¸°ì ë¹í´, A% ì´ìì ì¸ê¸°ì ìê¸° íë¦ì´ ì 2 í´í¼ì¤(331) ëë ì 2 ë³´ì¡°í´í¼ì¤(333)ì íì±ëë ê²½ì°, ì 2 íì  ìêµ¬ìì(335)ê³¼ ì 2 í´í¼ì¤(331) ëë ì 2 ë³´ì¡°í´í¼ì¤(333)ë ìê¸°ì ì¼ë¡ ì°ê²°ëìë¤ê³ í ì ìë¤. ì¬ê¸°ì, Aë 80, 70, 60, 50, 40, 30, 20 ë±ì¼ ì ìë¤.For example, compared to the intensity of magnetic flow generated when the second rotating permanent magnet 335 contacts the second pole piece 331 or

**[p0074]**

the second auxiliary pole piece 333, the magnetic flow has an intensity of A% or more. When formed on the second pole piece 331 or the second auxiliary pole piece 333, the second rotating permanent magnet 335 and the second pole piece 331 or the second auxiliary pole piece 333 are magnetically can be said to be connected. Here, A may be 80, 70, 60, 50, 40, 30, 20 or the like.

**[p0075]**

í´ë¨í(340)ì ìì±ì²´(341)ë ë¨ìê°ë¡ íì±ë ì ìì¼ë©°, ìíë¡ ì°ì¥ë ë§ë íìì¼ë¡ ë§ë ¨ë ì ìë¤. ëí, ìì±ì²´(341)ë ìê¸°ê° íë¥¼ ì ìë ê²½ë¡ë¥¼ íì±í ì ìê³ , ìì»¨ë° ìì±ì²´(341)ë ì² ê³¼ ê°ì ê°ìì±ì²´ë¡ êµ¬ì±ë ì ìë¤. ëí, ìì±ì²´(341)ë ì 2 ìì©ë©´(331a) ë° ì 2 ë³´ì¡°ìì©ë©´(333a)ì ëìì ë©´ì ì´í ì ìë ê¸¸ì´ë¡ íì±ë ì ìë¤. The magnetic body 341 of the clamp 340 may be formed in a singular number and may be provided in a rod shape extending vertically. In addition, the magnetic material 341 may form a path through which magnetism may flow, and for example, the magnetic material 341 may be made of a ferromagnetic material such as iron. In addition, the magnetic material 341 may be formed with a length capable of making surface contact with the second acting surface 331a and the second auxiliary acting surface 333a at the same time. íê¸°ììë, ë 3a ë´ì§ ë 3dë¥¼ ì°¸ì¡°íì¬, í´ë¨í ì¥ì¹(300)ë¡ ëìì²´(30)ë¥¼ í´ë¨ííë ê³¼ì ì ê´í´ ì¤ëª

**[p0076]**

íë¤. In the following, a process of clamping the object 30 with the clamping device 300 will be described with reference to FIGS. 3A to 3D. ë¨¼ì , ë 3aë¥¼ ì°¸ì¡°íë©´, ì 1 ì½ì¼(322)ì ì ìì´ ì¸ê°ëì§ ìì ìíì¼ ì ìë¤. ì¬ê¸°ì, ì 1 í´í¼ì¤(321) ì¤ ì 1 ê³ ì  ìêµ¬ìì(334)ì Nê·¹ê³¼ ì¸ì í ë¶ë¶ì Sê·¹ì¼ë¡ ìíëê³ , ì 1 í´í¼ì¤(321) ì¤ ì 1 ê³ ì  ìêµ¬ìì(334)ì Nê·¹ê³¼ ìëì ì¼ë¡ ë¨¼ ë¶ë¶, ì¦ ì 1 íì  ìêµ¬ìì(335)ê³¼ ì¸ì íë ë¶ë¶ì Nê·¹ì¼ë¡ ìíë ì ìë¤. ë°ë©´, ì 1 ë³´ì¡°í´í¼ì¤(323) ì¤ ì 1 ê³ ì  ìêµ¬ìì(334)ì Sê·¹ê³¼ ì¸ì í ë¶ë¶ì Nê·¹ì¼ë¡ ìíëê³ , ì 1 ë³´ì¡°í´í¼ì¤(323) ì¤ ì 1 ê³ ì  ìêµ¬ìì(334)ì Sê·¹ê³¼ ìëì ì¼ë¡ ë¨¼ ë¶ë¶, ì¦ ì 1 íì  ìêµ¬ìì(335)ê³¼ ì¸ì íë ë¶ë¶ì Sê·¹ì¼ë¡ ìíë ì ìë¤. ì´ì, ì 1 íì  ìêµ¬ìì(335)ì ê·¸ Nê·¹ì´ ìì¸¡ì ë°°ì¹ëê³ , ê·¸ Sê·¹ì´ íì¸¡ì ë°°ì¹ë ì ìë¤. ë°ë¼ì, ë 3aì ëìë ì ì ê³¼ ê°ì´, ì 1 ê³ ì  ìêµ¬ìì(334), ì 1 í´í¼ì¤(321), ì 1 íì  ìêµ¬ìì(335), ì 1 ë³´ì¡°í´í¼ì¤(323)ë¥¼ íµí´, ìê¸° íë£¨íê° íì±ë ì ìë¤. First, referring to FIG. 3A , power may not be applied to the first coil 322 . Here, a portion of the first pole piece 321 adjacent to the N pole of the first fixed permanent magnet 334 is magnetized to the S pole, and the N pole of the first fixed permanent magnet 334 among the first pole pieces 321 is magnetized. A part relatively far from , that is, a part adjacent to the first rotating permanent

**[p0076]**

magnet 335 may be magnetized to the N pole. On the other hand, a portion of the first auxiliary pole piece 323 adjacent to the S pole of the first fixed permanent magnet 334 is magnetized to the N pole, and the portion of the first auxiliary pole piece 323 adjacent to the S pole of the first fixed permanent magnet 334 A portion relatively far from the S pole, that is, a portion adjacent to the first rotating permanent magnet 335 may be magnetized to the S pole. Accordingly, the N pole of the first rotating permanent magnet 335 may be disposed on the upper side and the S pole may be disposed on the lower side. Therefore, as shown in the dotted line shown in FIG. 3A, through the first fixed permanent magnet 334, the first pole piece 321, the first rotating permanent magnet 335, and the first auxiliary pole piece 323, the magnetic lung Loops may form.

**[p0077]**

ëí, ì 2 ì½ì¼(332)ìë ì ìì´ ì¸ê°ëì§ ìì ìíì¼ ì ìë¤. ë 3aì ëìë ì ì ê³¼ ê°ì´, ì 2 ê³ ì  ìêµ¬ìì(334), ì 2 í´í¼ì¤(331), ìì±ì²´(341), ì 2 ë³´ì¡°í´í¼ì¤(333)ë¥¼ íµí´, ìê¸° íë£¨íê° íì±ë ì ìë¤. ëí, ì 2 íì  ìêµ¬ìì(335)ì ê·¸ Sê·¹ì´ ì 2 ë³´ì¡°í´í¼ì¤(333)ì ê·¼ì íì¬ ì 2 ë³´ì¡°í´í¼ì¤(333)ì ìê¸°ì ì¼ë¡ ì°ê²°ëê³ , ê·¸ Nê·¹ì´ ì 2 í´í¼ì¤(331)ì ê·¼ì íì¬ ì 2 í´í¼ì¤(331)ì ìê¸°ì ì¼ë¡ ì°ê²°ë ì ìë¤. ì´ì, ë 3aì ëìë ì ì ê³¼ ê°ì´, ì 2 íì  ìêµ¬ìì(335), ì 2 í´í¼ì¤(331), ìì±ì²´(341), ì 2 ë³´ì¡°í´í¼ì¤(333)ë¥¼ íµí´, ìê¸° íë£¨íê° íì±ë ì ìë¤.Also, power may not be applied to the second coil 332 . As shown in the dotted line shown in FIG. 3A, a magnetic closed loop may be formed through the second fixed permanent magnet 334, the second pole piece 331, the magnetic body 341, and the second auxiliary pole piece 333. . In addition, the S pole of the second rotating permanent magnet 335 is magnetically connected to the second auxiliary pole piece 333 by being close to the second auxiliary pole piece 333, and the N pole thereof is the second pole piece ( 331) and may be magnetically connected to the second pole piece 331. Accordingly, as shown in the dotted line shown in FIG. 3A, a magnetic closed loop is formed through the second rotating permanent magnet 335, the second pole piece 331, the magnetic body 341, and the second auxiliary pole piece 333. can

**[p0078]**

ë 3bë¥¼ ì°¸ì¡°íë©´, ì 1 ì½ì¼(322) ë° ì 2 ì½ì¼(332)ì ì ë¥ê° íë¥´ëë¡, ì 1 ì½ì¼(322) ë° ì 2 ì½ì¼(332)ì ì ì´í ì ìë¤. ì 2 ì½ì¼(332)ì ì ë¥ê° íë¥´ë©´, ì 2 í´í¼ì¤(331) ì¤ ì 2 ê³ ì  ìêµ¬ìì(334)ê³¼ ì¸ì í ë¶ë¶ìë Sê·¹ì´ íì±ëê³ , ì 2 í´í¼ì¤(331) ì¤ ì 2 íì  ìêµ¬ìì(335)ê³¼ ì¸ì í ë¶ë¶ìë Nê·¹ì´ íì±ë ì ìë¤. ì´ì, ì 2 íì  ìêµ¬ìì(335)ê³¼ ì 2 í´í¼ì¤(331) ì¬ì´ì ì²ë ¥ì´ ë°ìíë©°, ì 2 íì  ìêµ¬ìì(335)ì´ íì í ì ìë¤. ì´ì, ì 2 íì  ìêµ¬ìì(335)ì ê·¸ Sê·¹ì ë°°ì¹ê° ì 2 í´í¼ì¤(331)ì ì¸ì íê² ë°°ì¹ëê³ , ê·¸ Nê·¹ì ë°°ì¹ê° ì 2 ë³´ì¡°í´í¼ì¤(333)ì ì¸ì íê² ë°°ì¹ë ì ìë¤. ì´ì, ì 2 ìì©ë©´(331a) ë° ì 2 ë³´ì¡°ìì©ë©´(333a)ì¼ë¡ë¶í° ìê¸°ì íë¦ì´ ë°ì°ëë ê²ì´ ì¤ë¨ëê³ , ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(330)ì ìì±ì²´(341) ì¬ì´ì ìê¸° íë£¨íê° í´ì ë ì ìë¤.Referring to FIG. 3B , the first coil 322 and the second coil 332 may be controlled so that current flows through the first coil 322 and the second coil 332 . When current flows through the second coil 332, an S pole is formed at a portion adjacent to the second stationary permanent magnet 334 among the second pole pieces 331, and the second rotating permanent magnet among the second pole pieces 331 An N pole may be formed at a portion adjacent to (335). Accordingly, a repulsive force is generated between the second rotating permanent magnet 335 and the second pole piece 331, and the second rotating permanent magnet

**[p0078]**

335 can rotate. Accordingly, the second rotating permanent magnet 335 may have its S pole disposed adjacent to the second pole piece 331 and its N pole disposed adjacent to the second auxiliary pole piece 333. there is. Accordingly, the divergence of magnetic flow from the second acting surface 331a and the second auxiliary acting surface 333a is stopped, and the magnetic closed loop between the second pole piece assembly 330 and the magnetic body 341 is released. can

**[p0079]**

ë°ë©´, ì 1 ì½ì¼(322)ì ì ë¥ê° íë¥´ë©´, ì 1 í´í¼ì¤(321) ì¤ ì 1 ê³ ì  ìêµ¬ìì(334)ê³¼ ì¸ì í ë¶ë¶ìë Nê·¹ì´ íì±ëê³ , ì 1 í´í¼ì¤(321) ì¤ ì 1 íì  ìêµ¬ìì(335)ê³¼ ì¸ì í ë¶ë¶ìë Sê·¹ì´ íì±ë ì ìë¤. ì´ì, ì 1 íì  ìêµ¬ìì(335)ê³¼ ì 1 í´í¼ì¤(321) ì¬ì´ì ì²ë ¥ì´ ë°ìíë©°, ì 1 íì  ìêµ¬ìì(335)ì´ íì ë ì ìë¤. ì´ì, ì 1 íì  ìêµ¬ìì(335)ì ê·¸ Sê·¹ì ë°°ì¹ê° ì 1 ë³´ì¡°í´í¼ì¤(323)ì ì¸ì íê² ë°°ì¹ëê³ , ê·¸ Nê·¹ì ë°°ì¹ê° ì 1 í´í¼ì¤(321)ì ì¸ì íê² ë°°ì¹ë ì ìë¤. ì´ì, ì 1 ìì©ë©´(321a) ë° ì 1 ë³´ì¡°ìì©ë©´(323a)ì¼ë¡ë¶í° ìê¸°ì íë¦ì´ ë°ì°ëê³ , ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(320)ì ìì±ì²´(341) ì¬ì´ì ìê¸° íë£¨íê° íì±ë ì ìë¤. ë°ë¼ì, í´ë¨í(340)ê° ì 1 ë°©í¥(ì¦, ìê³ë°©í¥)ì¼ë¡ íì ë ì ìë¤.On the other hand, when current flows through the first coil 322, an N pole is formed at a portion adjacent to the first fixed permanent magnet 334 among the first pole pieces 321, and the first rotation among the first pole pieces 321 An S pole may be formed at a portion adjacent to the permanent magnet 335 . Accordingly, a repulsive force is generated between the first rotating permanent magnet 335 and the first pole piece 321, and the first rotating permanent magnet 335 can be rotated. Accordingly, the first rotating permanent magnet 335 may have its S pole disposed adjacent to the first auxiliary pole piece 323 and its N pole disposed adjacent to the first pole piece 321. there is. Acco

**[p0079]**

rdingly, magnetic flow may be diverged from the first acting surface 321a and the first auxiliary acting surface 323a, and a magnetic closed loop may be formed between the first pole piece assembly 320 and the magnetic body 341. Accordingly, the clamp 340 can be rotated in the first direction (ie, clockwise).

**[p0080]**

ë 3cë¥¼ ì°¸ì¡°íë©´, ìì±ì²´(341)ê° ìê³ë°©í¥ì¼ë¡ íì íë©°, ì 1 ìì©ë©´(321a) ë° ì 1 ë³´ì¡°ìì©ë©´(323a)ì ì ì´í ì ìë¤. ì¦, ìì±ì²´(341)ê° ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(320)ì íì±ë ìê¸° íë£¨íë¤ì íµí´ ì 1 ë°©í¥(ì¦, ìê³ë°©í¥)ì ë°ë¼ ë¹ê²¨ì§ë©°, ì 1 ìì©ë©´(321a) ë° ì 1 ë³´ì¡°ìì©ë©´(323a)ì ì ì´ë ì ìë¤. ë 3cì ëìë ì ì ê³¼ ê°ì´, ì 1 ê³ ì  ìêµ¬ìì(334), ì 1 í´í¼ì¤(321), ìì±ì²´(341), ì 1 ë³´ì¡°í´í¼ì¤(323)ë¥¼ íµí´, íëì ìê¸° íë£¨íê° íì±ë ì ìë¤. ëí, ë 3cì ëìë ì ì ê³¼ ê°ì´, ì 1 íì  ìêµ¬ìì(335), ì 1 í´í¼ì¤(321), ìì±ì²´(341), ì 1 ë³´ì¡°í´í¼ì¤(323)ë¥¼ íµí´, ë¤ë¥¸ íëì ìê¸° íë£¨íê° íì±ë ì ìë¤. ì´ì, ìê¸° íë£¨íë¤ì´ íì±ëë©´ ì 1 ì½ì¼(322)ì ì¸ê°ë ì ìì ì ê±°íì¬ë ìê¸° íë£¨íë¤ì´ ì ì§ëë¯ë¡, ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(320)ê° ìì±ì²´(341)ì í¡ì°©ì ì ì§í ì ìë¤. ë°ë¼ì, ìì±ì²´(341)ì ì 1 ë°©í¥(ì¦, ìê³ë°©í¥)ì¼ë¡ì íì ì ëìíì¬, ê°ìì²´(343)ì ì§ì§ë¡ë(343a) ë° ê°ìëê¸°(342b)ê° íì í(343c)ì íì  ê°ë¥íê² ì§ì§ë ìíìì ì 1 ë°©í¥(ì¦, ìê³ë°©í¥)ì¼ë¡ íì ëê³ , ì§ì§ë(310)ì ìì°©ë ëìì²´(30)ë¥¼ í´ë¨íí ì ìë¤. ì´í, ì ì§ëë ìê¸° íë£¨íë¤ì ìí´, ê°ìì²´(343)ê° ëìì²´(30)ì í´ë¨íì ì ì§í ì ìë¤. Referring to FIG. 3C , the magnetic material 341 rotates in a clockwise direction and may contact the first acting surface 321a and

**[p0080]**

the first auxiliary acting surface 323a. That is, the magnetic material 341 is pulled along the first direction (ie, clockwise direction) through the magnetic closed loops formed with the first pole piece assembly 320, and the first acting surface 321a and the first auxiliary acting surface ( 323a). As shown in the dotted line shown in FIG. 3C, one magnetic closed loop is formed through the first fixed permanent magnet 334, the first pole piece 321, the magnetic body 341, and the first auxiliary pole piece 323. can In addition, as shown in the dotted line shown in FIG. 3C, another magnetic closed loop is formed through the first rotating permanent magnet 335, the first pole piece 321, the magnetic body 341, and the first auxiliary pole piece 323. can be formed. Accordingly, when the magnetic closed loops are formed, the magnetic closed loops are maintained even when the voltage applied to the first coil 322 is removed, so that the first pole piece assembly 320 can maintain the attraction of the magnetic material 341 . Therefore, in response to the rotation of the magnetic body 341 in the first direction (ie, clockwise direction), the support rod 343a and the pressing protrusion 342b of the pressing body 343 are rotatable on the rotation pin 343c. In the supported state, the object 30 rotated in the first direction (ie, clockwise direction) and seated on the support 310 may be clamped. Thereafter, the pressure body 343 may maintain the clamping of the target object 30 by the magnetic closed loops that are maintained.

**[p0081]**

íí¸, ë 3cì ëìë ì ì ê³¼ ê°ì´, ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(330)ë ì 2 ê³ ì  ìêµ¬ìì(334), ì 2 í´í¼ì¤(331), ì 2 íì  ìêµ¬ìì(335), ì 2 ë³´ì¡°í´í¼ì¤(333)ë¥¼ íµí´, ìê¸° íë£¨íë¥¼ íì±í ì ìë¤. Meanwhile, as indicated by the dotted line in FIG. 3C, the second pole piece assembly 330 includes a second fixed permanent magnet 334, a second pole piece 331, a second rotating permanent magnet 335, and a second auxiliary pole. Through the piece 333, a magnetic closed loop can be formed. ë 3dë¥¼ ì°¸ì¡°íë©´, ì 1 ì½ì¼(322) ë°ì 2 ì½ì¼(332)ì ì ë¥ê° íë¥´ëë¡, ì 1 ì½ì¼(322) ë° ì 2 ì½ì¼(332)ì ì ì´í ì ìë¤. ì 1 ì½ì¼(322)ì ì ë¥ê° íë¥´ë©´, ì 1 í´í¼ì¤(321) ì¤ ì 1 ê³ ì  ìêµ¬ìì(334)ê³¼ ì¸ì í ë¶ë¶ìë Sê·¹ì´ íì±ëê³ , ì 1 í´í¼ì¤(321) ì¤ ì 1 íì  ìêµ¬ìì(335)ê³¼ ì¸ì í ë¶ë¶ìë Nê·¹ì´ íì±ë ì ìë¤. ì´ì, ì 1 íì  ìêµ¬ìì(335)ê³¼ ì 1 í´í¼ì¤(321) ì¬ì´ì ì²ë ¥ì´ ë°ìíë©°, ì 1 íì  ìêµ¬ìì(335)ì´ íì ë ì ìë¤. ì´ì, ì 1 íì  ìêµ¬ìì(335)ì ê·¸ Sê·¹ì ë°°ì¹ê° ì 1 í´í¼ì¤(321)ì ì¸ì íê² ë°°ì¹ëê³ , ê·¸ Nê·¹ì ë°°ì¹ê° ì 1 ë³´ì¡°í´í¼ì¤(323)ì ì¸ì íê² ë°°ì¹ë ì ìë¤. ì´ì, ì 1 ìì©ë©´(321a) ë° ì 1 ë³´ì¡°ìì©ë©´(323a)ì¼ë¡ë¶í° ìê¸°ì íë¦ì´ ë°ì°ëë ê²ì´ ì¤ë¨ëê³ , ì 1 í´í¼ì¤ ì´ì

**[p0082]**

ë¸ë¦¬(320)ì ìì±ì²´(341) ì¬ì´ì ìê¸° íë£¨íê° í´ì ë ì ìë¤.Referring to FIG. 3D , the first coil 322 and the second coil 332 may be controlled so that current flows through the first coil 322 and the second coil 332 . When current flows through the first coil 322, an S pole is formed at a portion adjacent to the first fixed permanent magnet 334 among the first pole pieces 321, and the first rotating permanent magnet among the first pole pieces 321 An N pole may be formed at a portion adjacent to (335). Accordingly, a repulsive force is generated between the first rotating permanent magnet 335 and the first pole piece 321, and the first rotating permanent magnet 335 can be rotated. Accordingly, the first rotating permanent magnet 335 may have its S pole disposed adjacent to the first pole piece 321 and its N pole disposed adjacent to the first auxiliary pole piece 323. there is. Accordingly, divergence of magnetic flow from the first acting surface 321a and the first auxiliary acting surface 323a is stopped, and the magnetic closed loop between the first pole piece assembly 320 and the magnetic body 341 is released. can

**[p0083]**

ë°ë©´, ì 2 ì½ì¼(332)ì ì ë¥ê° íë¥´ë©´, ì 2 í´í¼ì¤(331) ì¤ ì 2 ê³ ì  ìêµ¬ìì(334)ê³¼ ì¸ì í ë¶ë¶ìë Nê·¹ì´ íì±ëê³ , ì 2 í´í¼ì¤(331) ì¤ ì 2 íì  ìêµ¬ìì(335)ê³¼ ì¸ì í ë¶ë¶ìë Sê·¹ì´ íì±ë ì ìë¤. ì´ì, ì 2 íì  ìêµ¬ìì(335)ê³¼ ì 2 í´í¼ì¤(331) ì¬ì´ì ì²ë ¥ì´ ë°ìíë©°, ì 2 íì  ìêµ¬ìì(335)ì´ íì í ì ìë¤. ì´ì, ì 2 íì  ìêµ¬ìì(335)ì ê·¸ Sê·¹ì ë°°ì¹ê° ì 2 ë³´ì¡°í´í¼ì¤(333)ì ì¸ì íê² ë°°ì¹ëê³ , ê·¸ Nê·¹ì ë°°ì¹ê° ì 2 í´í¼ì¤(331)ì ì¸ì íê² ë°°ì¹ë ì ìë¤. ì´ì, ì 2 ìì©ë©´(331a) ë° ì 2 ë³´ì¡°ìì©ë©´(333a)ì¼ë¡ë¶í° ìê¸°ì íë¦ì´ ë°ì°ëê³ , ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(330)ì ìì±ì²´(341) ì¬ì´ì ìê¸° íë£¨íê° íì±ë ì ìë¤. ë°ë¼ì, í´ë¨í(340)ê° ì 2 ë°©í¥(ì¦, ë°ìê³ë°©í¥)ì¼ë¡ íì íë©°, ê°ìì²´(343)ê° ëìì²´(30)ì í´ë¨íì í´ì í ì ìë¤.On the other hand, when current flows through the second coil 332, an N pole is formed at a portion adjacent to the second fixed permanent magnet 334 among the second pole pieces 331, and the second rotation among the second pole pieces 331 An S pole may be formed at a portion adjacent to the permanent magnet 335 . Accordingly, a repulsive force is generated between the second rotating permanent magnet 335 and the second pole piece 331, and the second rotating permanent magnet 335 can rotate. Accordingly, the second rotating permanent magnet 335 may have its S pole disposed adjacent to the second auxiliary pole piece 333 and i

**[p0083]**

ts N pole disposed adjacent to the second pole piece 331. there is. Accordingly, magnetic flow may be diverged from the second acting surface 331a and the second auxiliary acting surface 333a, and a magnetic closed loop may be formed between the second pole piece assembly 330 and the magnetic body 341. Accordingly, the clamp 340 rotates in the second direction (ie, counterclockwise direction), and the pressing body 343 may release the clamping of the object 30 .

**[p0084]**

ë 4a ë´ì§ ë 4dë ë³¸ ë°ëª ì ì 4 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ë¥¼ ê°ëµì ì¼ë¡ ëìí ëë©´ì´ë¤.4A to 4D are views schematically showing a clamping device according to a fourth embodiment of the present invention. íê¸°ììë ë³¸ ë°ëª ì ì¤ììë¤ ì¤ ì 4 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ì êµ¬ì¡°ë¥¼ ì¤ëª íë¤. ì´ë, ë³¸ ë°ëª ì ì 1 ì¤ìì ë´ì§ ì 3 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ì ëì¼í êµ¬ì¡°ì ê´í ì¤ëª ì ìëµíê¸°ë¡ íë¤.In the following, the structure of the clamping device according to the fourth embodiment among the embodiments of the present invention will be described. At this time, description of the same structure as the clamping device according to the first to third embodiments of the present invention will be omitted. ë³¸ ë°ëª ì ì 4 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹(400)ë ì§ì§ë(410), ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(420), ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(430) ë° í´ë¨í(440)ë¥¼ í¬í¨í ì ìë¤.The clamping device 400 according to the fourth embodiment of the present invention may include a support 410 , a first pole piece assembly 420 , a second pole piece assembly 430 and a clamp 440 .

**[p0085]**

íí¸, ë³¸ ë°ëª ì ì 4 ì¤ììë¥¼ ì¤ëª í¨ì ìì´ì, íê¸°ìì ê¸°ì¬ëë ì 1 ë°©í¥ì ìì í ì°ì¥ë°©í¥ ì¤ ì 1 ìì©ë©´ì í¥íë ë°©í¥ì¸ ê²½ì°ë¥¼ ììì ì¼ë¡ ì¤ëª íê³ , ì 2 ë°©í¥ì ìì í ì°ì¥ë°©í¥ ì¤ ì 2 ìì©ë©´ì í¥íë ë°©í¥ì¸ ê²½ì°ë¥¼ ììì ì¼ë¡ ì¤ëª íë¤.On the other hand, in describing the fourth embodiment of the present invention, the first direction described below is exemplarily described in the case of extending toward the first acting surface among the above-mentioned extension directions, and the second direction is the above-mentioned extension direction. Among the directions, the case of the direction toward the second acting surface will be described as an example. í´ë¨í(440)ë ìì¸¡ë¨ì´ ê°ê° ì 1 ë³´ì¡°í´í¼ì¤(423)ì ì 2 ë³´ì¡°í´í¼ì¤(433)ì ì°ê²°ëë ë³´ì¡°ë ì¼(445)ì ë í¬í¨í ì ìë¤. ë³´ì¡°ë ì¼(445)ì ì°ì¥ë°©í¥ì ë°ë¼ ì°ì¥ëë©°, ì¼ë¨ì´ ì 1 ë³´ì¡°ìì©ë©´(423a)ì ì°ê²°ëê³ , íë¨ì´ ì 2 ë³´ì¡°ìì©ë©´(433a)ì ì°ê²°ë ì ìë¤. ì¦, ë³´ì¡°ë ì¼(445)ì´ ì 1 ë³´ì¡°í´í¼ì¤(423)ì ì 2 ë³´ì¡°í´í¼ì¤(433)ë¥¼ ì°ê²°íê³ , ë ì¼(444)ì´ ì 1 í´í¼ì¤(421)ì ì 2 í´í¼ì¤(431)ë¥¼ ì°ê²°í ì ìë¤.The clamp 440 may further include auxiliary rails 445 having both ends connected to the first auxiliary pole piece 423 and the second auxiliary pole piece 433, respectively. The auxiliary rail 445 extends along the extension direction, and one end may be connected to the first auxiliary action surface 423a and the other end may be c

**[p0085]**

onnected to the second auxiliary action surface 433a. That is, the auxiliary rail 445 connects the first auxiliary pole piece 423 and the second auxiliary pole piece 433, and the rail 444 connects the first pole piece 421 and the second pole piece 431. can connect

**[p0086]**

íí¸, ìì±ì²´(441)ë ë¨ìê°ë¡ íì±ëë©°, ë ì¼(444) ë° ë³´ì¡°ë ì¼(445)ì ì´ë ê°ë¥íê² ê²°í©ë ì ìë¤. ì¦, ìì±ì²´(441)ë ë ì¼(444) ë° ë³´ì¡°ë ì¼(445)ì ì°ì¥ë°©í¥ì ë°ë¼, ì íì§ ì¬ë¼ì´ë© ì´ëí ì ìë¤. On the other hand, the magnetic body 441 is formed in a singular number, and may be movably coupled to the rail 444 and the auxiliary rail 445 . That is, the magnetic material 441 may slide forward and backward along the extension direction of the rail 444 and the auxiliary rail 445 . íê¸°ììë, ë 4a ë´ì§ ë 4dë¥¼ ì°¸ì¡°íì¬, í´ë¨í ì¥ì¹(400)ë¡ ëìì²´(40)ë¥¼ í´ë¨ííë ê³¼ì ì ê´í´ ì¤ëª íë¤. In the following, a process of clamping the object 40 with the clamping device 400 will be described with reference to FIGS. 4A to 4D. ë¨¼ì , ë 4aë¥¼ ì°¸ì¡°íë©´, ì 1 ì½ì¼(422)ì ì ìì´ ì¸ê°ëì§ ìì ìíì¼ ì ìë¤. ì¦, ë 4aì ëìë ì ì ê³¼ ê°ì´, ì 1 ê³ ì  ìêµ¬ìì(424), ì 1 í´í¼ì¤(421), ìì±ì²´(441), ì 1 ë³´ì¡° í´í¼ì¤(423)ë¥¼ íµí´, ìê¸° íë£¨íê° íì±ë ì ìë¤. ëí, ì 1 íì  ìêµ¬ìì(425)ì ê·¸ Sê·¹ì´ ì 1 í´í¼ì¤(421)ì ê·¼ì íë©° ì 1 í´í¼ì¤(421)ì ìê¸°ì ì¼ë¡ ì°ê²°ëê³ , ê·¸ Nê·¹ì´ ì 1 ë³´ì¡°í´í¼ì¤(423)ì ê·¼ì íë©° ì 1 ë³´ì¡°í´í¼ì¤(423)ì ìê¸°ì ì¼ë¡ ì°ê²°ë ì ìë¤. ì´ì, ë 4aì ëìë ì ì ê³¼ ê°ì´, ì 1 íì  ìêµ¬ìì(425), ì 1 í´í¼ì¤(421), ìì±ì²´(441), ì 1 ë³´ì¡°í´í¼ì¤(423)ë¥¼ íµí´, ìê¸° íë£¨íê° íì±ë ì ìë¤. ì¦, í´ë¨í(440)ê° ì 1

**[p0086]**

í´í¼ì¤ ì´ì

**[p0087]**

ë¸ë¦¬(420)ì ì 1 ìì©ë©´(421a) ë° ì 1 ë³´ì¡°ìì©ë©´(423a)ì í¡ì°©ë ìíì¼ ì ìë¤.First, referring to FIG. 4A , power may not be applied to the first coil 422 . That is, as shown in the dotted line shown in FIG. 4A, a magnetic closed loop is formed through the first fixed permanent magnet 424, the first pole piece 421, the magnetic body 441, and the first auxiliary pole piece 423. can In addition, the S pole of the first rotating permanent magnet 425 is close to the first pole piece 421 and is magnetically connected to the first pole piece 421, and the N pole thereof is the first auxiliary pole piece 423 ) and may be magnetically connected to the first auxiliary pole piece 423. Accordingly, as shown in the dotted line shown in FIG. 4A, a magnetic closed loop is formed through the first rotating permanent magnet 425, the first pole piece 421, the magnetic body 441, and the first auxiliary pole piece 423. can That is, the clamp 440 may be adsorbed to the first acting surface 421a and the first auxiliary acting surface 423a of the first pole piece assembly 420 .

**[p0088]**

ëí, ì 2 ì½ì¼(432)ìë ì ìì´ ì¸ê°ëì§ ìì ìíì¼ ì ìë¤. ì¬ê¸°ì, ì 2 í´í¼ì¤(431) ì¤ ì 2 ê³ ì  ìêµ¬ìì(434)ì Nê·¹ê³¼ ì¸ì í ë¶ë¶ì Sê·¹ì¼ë¡ ìíëê³ , ì 2 í´í¼ì¤(431) ì¤ ì 2 ê³ ì  ìêµ¬ìì(434)ì Nê·¹ê³¼ ìëì ì¼ë¡ ë¨¼ ë¶ë¶, ì¦ ì 2 íì  ìêµ¬ìì(435)ê³¼ ì¸ì íë ë¶ë¶ì Nê·¹ì¼ë¡ ìíë ì ìë¤. ë°ë©´, ì 2 ë³´ì¡°í´í¼ì¤(433) ì¤ ì 2 ê³ ì  ìêµ¬ìì(434)ì Sê·¹ê³¼ ì¸ì í ë¶ë¶ì Nê·¹ì¼ë¡ ìíëê³ , ì 1 ë³´ì¡°í´í¼ì¤(423) ì¤ ì 2 ê³ ì  ìêµ¬ìì(434)ì Sê·¹ê³¼ ìëì ì¼ë¡ ë¨¼ ë¶ë¶, ì¦ ì 2 íì  ìêµ¬ìì(435)ê³¼ ì¸ì íë ë¶ë¶ì Sê·¹ì¼ë¡ ìíë ì ìë¤. ì´ì, ì 2 íì  ìêµ¬ìì(435)ì ê·¸ Nê·¹ì´ ìì¸¡ì ë°°ì¹ëê³ , ê·¸ Sê·¹ì´ íì¸¡ì ë°°ì¹ë ì ìë¤. ë°ë¼ì, ë 4aì ëìë ì ì ê³¼ ê°ì´, ì 2 ê³ ì  ìêµ¬ìì(434)ì´ ì 2 í´í¼ì¤(431), ì 2 íì  ìêµ¬ìì(435), ì 2 ë³´ì¡°í´í¼ì¤(433)ë¥¼ íµí´, ìê¸° íë£¨íê° íì±ë ì ìë¤. Also, power may not be applied to the second coil 432 . Here, a portion of the second pole piece 431 adjacent to the N pole of the second fixed permanent magnet 434 is magnetized to the S pole, and the N pole of the second fixed permanent magnet 434 among the second pole pieces 431 is magnetized. A part relatively far from , that is, a part adjacent to the second rotating permanent magnet 435 may be magnetized to the N pole. On the other hand, a portion of the second auxiliary pole piece 433 adjacent to the S pole of the second fixed permanent magnet 434 is

**[p0088]**

magnetized to the N pole, and the second auxiliary pole piece 423 of the second fixed permanent magnet 434 is magnetized. A portion relatively far from the S pole, that is, a portion adjacent to the second rotating permanent magnet 435 may be magnetized to the S pole. Accordingly, the N pole of the second rotating permanent magnet 435 may be disposed on the upper side and the S pole may be disposed on the lower side. Therefore, as shown in the dotted line shown in FIG. 4A, the second fixed permanent magnet 434 passes through the second pole piece 431, the second rotating permanent magnet 435, and the second auxiliary pole piece 433 to close the magnetic field. Loops may form.

**[p0089]**

ë 4bë¥¼ ì°¸ì¡°íë©´, ì 1 ì½ì¼(422) ë° ì 2 ì½ì¼(432)ì ì ë¥ê° íë¥´ëë¡, ì 1 ì½ì¼(422) ë° ì 2 ì½ì¼(432)ì ì ì´í ì ìë¤. ì 1 ì½ì¼(422)ì ì ë¥ê° íë¥´ë©´, ì 1 í´í¼ì¤(421) ì¤ ì 1 ê³ ì  ìêµ¬ìì(424)ê³¼ ì¸ì í ë¶ë¶ìë Nê·¹ì´ íì±ëê³ , ì 1 í´í¼ì¤(421) ì¤ ì 1 íì  ìêµ¬ìì(425)ê³¼ ì¸ì í ë¶ë¶ìë Sê·¹ì´ íì±ë ì ìë¤. ì´ì, ì 1 íì  ìêµ¬ìì(425)ê³¼ ì 1 í´í¼ì¤(421) ì¬ì´ì ì²ë ¥ì´ ë°ìíë©°, ì 1 íì  ìêµ¬ìì(425)ì´ íì í ì ìë¤. ì´ì, ì 1 íì  ìêµ¬ìì(425)ì ê·¸ Sê·¹ì ë°°ì¹ê° ì 1 ë³´ì¡°í´í¼ì¤(423)ì ì¸ì íê² ë°°ì¹ëê³ , ê·¸ Nê·¹ì ë°°ì¹ê° ì 1 í´í¼ì¤(421)ì ì¸ì íê² ë°°ì¹ë ì ìë¤. ì´ì, ì 1 ìì©ë©´(421a) ë° ì 1 ë³´ì¡°ìì©ë©´(423a)ì¼ë¡ë¶í° ìê¸°ì íë¦ì´ ë°ì°ëë ê²ì´ ì¤ë¨ëê³ , ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(420)ì ìì±ì²´(441) ì¬ì´ì ìê¸° íë£¨íê° í´ì ë ì ìë¤.Referring to FIG. 4B , the first coil 422 and the second coil 432 may be controlled so that current flows through the first coil 422 and the second coil 432 . When current flows through the first coil 422, an N pole is formed at a portion adjacent to the first fixed permanent magnet 424 among the first pole pieces 421, and the first rotating permanent magnet among the first pole pieces 421 An S pole may be formed at a portion adjacent to 425. Accordingly, a repulsive force is generated between the first rotating permanent magnet 425 and the first pole piece 421, and the first rotating permanent magnet 425 may rotate

**[p0089]**

. Accordingly, the first rotating permanent magnet 425 may have its S pole disposed adjacent to the first auxiliary pole piece 423 and its N pole disposed adjacent to the first pole piece 421. there is. Accordingly, the divergence of magnetic flow from the first acting surface 421a and the first auxiliary acting surface 423a is stopped, and the magnetic closed loop between the first pole piece assembly 420 and the magnetic body 441 is released. can

**[p0090]**

ë°ë©´, ì 2 ì½ì¼(432)ì ì ë¥ê° íë¥´ë©´, ì 2 í´í¼ì¤(431) ì¤ ì 2 ê³ ì  ìêµ¬ìì(434)ê³¼ ì¸ì í ë¶ë¶ìë Nê·¹ì´ íì±ëê³ , ì 2 í´í¼ì¤(431) ì¤ ì 2 íì  ìêµ¬ìì(435)ê³¼ ì¸ì í ë¶ë¶ìë Sê·¹ì´ íì±ë ì ìë¤. ì´ì, ì 2 íì  ìêµ¬ìì(435)ê³¼ ì 2 í´í¼ì¤(431) ì¬ì´ì ì²ë ¥ì´ ë°ìíë©°, ì 2 íì  ìêµ¬ìì(435)ì´ íì í ì ìë¤. ì´ì, ì 2 íì  ìêµ¬ìì(435)ì ê·¸ Sê·¹ì ë°°ì¹ê° ì 2 ë³´ì¡°í´í¼ì¤(433)ì ì¸ì íê² ë°°ì¹ëê³ , ê·¸ Nê·¹ì ë°°ì¹ê° ì 2 í´í¼ì¤(431)ì ì¸ì íê² ë°°ì¹ë ì ìë¤. ì´ì, ì 2 ìì©ë©´(431a) ë° ì 2 ë³´ì¡°ìì©ë©´(433a)ì¼ë¡ë¶í° ìê¸°ì íë¦ì´ ë°ì°ëê³ , ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(430)ì ìì±ì²´(441) ì¬ì´ì ìê¸° íë£¨íê° íì±ë ì ìë¤. ë°ë¼ì, í´ë¨í(440)ê° ì 2 ë°©í¥(ì¦, ì 2 ìì©ë©´(431a) ë° ì 2 ë³´ì¡°ìì©ë©´(433a)ì í¥íë ë°©í¥)ì¼ë¡ ì¬ë¼ì´ë© ì´ëí ì ìë¤.On the other hand, when current flows through the second coil 432, an N pole is formed at a portion adjacent to the second fixed permanent magnet 434 among the second pole pieces 431, and the second rotation among the second pole pieces 431 An S pole may be formed at a portion adjacent to the permanent magnet 435 . Accordingly, a repulsive force is generated between the second rotating permanent magnet 435 and the second pole piece 431, and the second rotating permanent magnet 435 may rotate. Accordingly, the second rotating permanent magnet 435 may have its S pole disposed adjacent to the second auxiliary pole piece 43

**[p0090]**

3 and its N pole disposed adjacent to the second pole piece 431. there is. Accordingly, magnetic flow may be diverged from the second acting surface 431a and the second auxiliary acting surface 433a, and a magnetic closed loop may be formed between the second pole piece assembly 430 and the magnetic body 441. Accordingly, the clamp 440 can slide in the second direction (ie, the direction toward the second acting surface 431a and the second auxiliary acting surface 433a).

**[p0091]**

ë 4cë¥¼ ì°¸ì¡°íë©´, ìì±ì²´(441)ê° ì 2 ë°©í¥ì¼ë¡ ì´ëíë©°, ì 2 ìì©ë©´(431a) ë° ì 2 ë³´ì¡°ìì©ë©´(433a)ì ì ì´í ì ìë¤. ì¦, ìì±ì²´(441)ê° ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(430)ì íì±ë ìê¸° íë£¨íë¤ì íµí´ ì 2 ë°©í¥ì ë°ë¼ ë¹ê²¨ì§ë©°, ì 2 ìì©ë©´(431a) ë° ì 2 ë³´ì¡°ìì©ë©´(433a)ì ì ì´ë ì ìë¤. ì¬ê¸°ì, ë 4cì ëìë ì ì ê³¼ ê°ì´, ì 2 ê³ ì  ìêµ¬ìì(434), ì 2 í´í¼ì¤(431), ìì±ì²´(441), ì 2 ë³´ì¡°í´í¼ì¤(433)ë¥¼ íµí´, íëì ìê¸° íë£¨íê° íì±ë ì ìë¤. ëí, ë 4cì ëìë ì ì ê³¼ ê°ì´, ì 2 íì  ìêµ¬ìì(435), ì 2 í´í¼ì¤(431), ìì±ì²´(441), ì 2 ë³´ì¡°í´í¼ì¤(433)ë¥¼ íµí´, ë¤ë¥¸ íëì ìê¸° íë£¨íê° íì±ë ì ìë¤. ì´ì, ìê¸° íë£¨íë¤ì´ íì±ëë©´ ì 2 ì½ì¼(432)ì ì¸ê°ë ì ìì ì ê±°íì¬ë ìê¸° íë£¨íë¤ì´ ì ì§ëë¯ë¡, ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(430)ê° ìì±ì²´(441)ì í¡ì°©ì ì ì§ìí¬ ì ìë¤. ë°ë¼ì, ìì±ì²´(441)ì ì 2 ë°©í¥ì¼ë¡ì ì¬ë¼ì´ë© ì´ëì ëìíì¬, ê°ìì²´(443)ê° ì 2 ë°©í¥ì¼ë¡ ì¬ë¼ì´ë© ì´ëíê³ , ì§ì§ë(410)ì ìì°©ë ëìì²´(40)ë¥¼ í´ë¨íí ì ìë¤. ì¦, ì§ì§ë¡ë(443a)ê° ì½ì

**[p0092]**

í(310a) ë´ìì ì ì§íë©°, ê°ìëê¸°(443b)ê° ëìì²´(40)ë¥¼ í´ë¨íí ì ìë¤. ì´í, ì ì§ëë ìê¸° íë£¨íë¤ì ìí´, ê°ìì²´(443)ê° ëìì²´(40)ì í´ë¨íì ì ì§í ì ìë¤. Referring to FIG. 4C , the magnetic material 441 moves in the second direction and may contact the second acting surface 431a and the second auxiliary acting surface 433a. That is, the magnetic material 441 can be pulled along the second direction through the magnetic closed loops formed with the second pole piece assembly 430 and come into contact with the second acting surface 431a and the second auxiliary acting surface 433a. there is. Here, as shown in the dotted line shown in FIG. 4C, one magnetic closed loop is formed through the second fixed permanent magnet 434, the second pole piece 431, the magnetic body 441, and the second auxiliary pole piece 433. can be formed In addition, as shown in the dotted line shown in FIG. 4C, another magnetic closed loop is formed through the second rotating permanent magnet 435, the second pole piece 431, the magnetic body 441, and the second auxiliary pole piece 433. can be formed. Accordingly, when the magnetic closed loops are formed, the magnetic closed loops are maintained even when the voltage applied to the second coil 432 is removed, so that the second pole piece assembly 430 can maintain the attraction of the magnetic body 441 . Accordingly, in response to the sliding movement of the magnetic body 441 in the second direction, the pressing body 443 may slide in the second direction and clamp the target object 40

**[p0092]**

seated on the support 410 . That is, the support rod 443a advances in the insertion hole 310a, and the pressing protrusion 443b may clamp the object 40. Thereafter, the pressing body 443 may maintain the clamping of the target object 40 by the maintained magnetic closed loops.

**[p0093]**

ë 4dë¥¼ ì°¸ì¡°íë©´, ì 1 ì½ì¼(422) ë° ì 2 ì½ì¼(432)ì ì ë¥ê° íë¥´ëë¡, ì 1 ì½ì¼(422) ë° ì 2 ì½ì¼(432)ì ì ì´í ì ìë¤. ì 2 ì½ì¼(432)ì ì ë¥ê° íë¥´ë©´, ì 2 í´í¼ì¤(431) ì¤ ì 2 ê³ ì  ìêµ¬ìì(434)ê³¼ ì¸ì í ë¶ë¶ìë Sê·¹ì´ íì±ëê³ , ì 2 í´í¼ì¤(431) ì¤ ì 2 íì  ìêµ¬ìì(435)ê³¼ ì¸ì í ë¶ë¶ìë Nê·¹ì´ íì±ë ì ìë¤. ì´ì, ì 2 íì  ìêµ¬ìì(435)ê³¼ ì 2 í´í¼ì¤(431) ì¬ì´ì ì²ë ¥ì´ ë°ìíë©°, ì 2 íì  ìêµ¬ìì(435)ì´ íì ë ì ìë¤. ì´ì, ì 2 íì  ìêµ¬ìì(435)ì ê·¸ Sê·¹ì ë°°ì¹ê° ì 2 í´í¼ì¤(431)ì ì¸ì íê² ë°°ì¹ëê³ , ê·¸ Nê·¹ì ë°°ì¹ê° ì 2 ë³´ì¡°í´í¼ì¤(433)ì ì¸ì íê² ë°°ì¹ë ì ìë¤. ì´ì, ì 2 ìì©ë©´(431a) ë° ì 2 ë³´ì¡°ìì©ë©´(433a)ì¼ë¡ë¶í° ìê¸°ì íë¦ì´ ë°ì°ëë ê²ì´ ì¤ë¨ëê³ , ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬(430)ì ìì±ì²´(441) ì¬ì´ì ìê¸° íë£¨íê° í´ì ë ì ìë¤.Referring to FIG. 4D , the first coil 422 and the second coil 432 may be controlled so that current flows through the first coil 422 and the second coil 432 . When current flows through the second coil 432, an S pole is formed at a portion adjacent to the second stationary permanent magnet 434 among the second pole pieces 431, and the second rotating permanent magnet among the second pole pieces 431 An N pole may be formed at a portion adjacent to 435. Accordingly, a repulsive force is generated between the second rotating permanent magnet 435 and the second pole piece 431, and the second rotating permanent magnet 4

**[p0093]**

35 can be rotated. Accordingly, the second rotating permanent magnet 435 may have its S pole disposed adjacent to the second pole piece 431 and its N pole disposed adjacent to the second auxiliary pole piece 433. there is. Accordingly, the divergence of magnetic flow from the second acting surface 431a and the second auxiliary acting surface 433a is stopped, and the magnetic closed loop between the second pole piece assembly 430 and the magnetic body 441 is released. can

**[p0094]**

ë°ë©´, ì 1 ì½ì¼(422)ì ì ë¥ê° íë¥´ë©´, ì 1 í´í¼ì¤(421) ì¤ ì 1 ê³ ì  ìêµ¬ìì(424)ê³¼ ì¸ì í ë¶ë¶ìë Sê·¹ì´ íì±ëê³ , ì 1 í´í¼ì¤(421) ì¤ ì 1 íì  ìêµ¬ìì(425)ê³¼ ì¸ì í ë¶ë¶ìë Nê·¹ì´ íì±ë ì ìë¤. ì´ì, ì 1 íì  ìêµ¬ìì(425)ê³¼ ì 1 í´í¼ì¤(421) ì¬ì´ì ì²ë ¥ì´ ë°ìíë©°, ì 1 íì  ìêµ¬ìì(425)ì´ íì ë ì ìë¤. ì´ì, ì 1 íì  ìêµ¬ìì(425)ì ê·¸ Sê·¹ì ë°°ì¹ê° ì 1 í´í¼ì¤(421)ì ì¸ì íê² ë°°ì¹ëê³ , ê·¸ Nê·¹ì ë°°ì¹ê° ì 1 ë³´ì¡°í´í¼ì¤(423)ì ì¸ì íê² ë°°ì¹ë ì ìë¤. ì´ì, ì 1 ìì©ë©´(421a) ë° ì 1 ë³´ì¡°ìì©ë©´(423a)ì¼ë¡ë¶í° ìê¸°ì íë¦ì´ ë°ì°ëê³ , ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬(420)ì ìì±ì²´(441) ì¬ì´ì ìê¸° íë£¨íê° íì±ë ì ìë¤. ë°ë¼ì, í´ë¨í(440)ê° ì 2 ë°©í¥ì¼ë¡ ì¬ë¼ì´ë© ì´ëíë©°, ê°ìì²´(443)ê° ëìì²´(40)ì í´ë¨íì í´ì í ì ìë¤.On the other hand, when current flows through the first coil 422, an S pole is formed at a portion of the first pole piece 421 adjacent to the first fixed permanent magnet 424, and the first rotation of the first pole piece 421 An N pole may be formed at a portion adjacent to the permanent magnet 425 . Accordingly, a repulsive force is generated between the first rotating permanent magnet 425 and the first pole piece 421, and the first rotating permanent magnet 425 can be rotated. Accordingly, the first rotating permanent magnet 425 may have its S pole disposed adjacent to the first pole piece 421 and its N pole disposed adjacent to th

**[p0094]**

e first auxiliary pole piece 423. there is. Accordingly, magnetic flow may be diverged from the first acting surface 421a and the first auxiliary acting surface 423a, and a magnetic closed loop between the first pole piece assembly 420 and the magnetic body 441 may be formed. Accordingly, the clamp 440 slides in the second direction, and the pressing body 443 may release the clamping of the object 40 .

**[p0095]**

ë 5a ë´ì§ ë 5dë ë³¸ ë°ëª ì ì 5 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ë¥¼ ê°ëµì ì¼ë¡ ëìí ëë©´ì´ë¤.5A to 5D are views schematically showing a clamping device according to a fifth embodiment of the present invention. íê¸°ììë ë³¸ ë°ëª ì ì¤ììë¤ ì¤ ì 5 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ì êµ¬ì¡°ë¥¼ ì¤ëª íë¤. ì´ë, ë³¸ ë°ëª ì ì 1 ì¤ìì ë´ì§ ì 4 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ì ëì¼í êµ¬ì¡°ì ê´í ì¤ëª ì ìëµíê¸°ë¡ íë¤.In the following, the structure of the clamping device according to the fifth embodiment among the embodiments of the present invention will be described. At this time, description of the same structure as the clamping device according to the first to fourth embodiments of the present invention will be omitted. ë³¸ ë°ëª ì ì 5 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹(500)ë ì§ì§ë(510), ìê¸°ë ¥ ì ì´ëª¨ë(520), íì±ë ¥ ì ì´ëª¨ë(530) ë° í´ë¨í(540)ë¥¼ í¬í¨í ì ìë¤.The clamping device 500 according to the fifth embodiment of the present invention may include a support 510, a magnetic force control module 520, an elastic force control module 530, and a clamp 540.

**[p0096]**

íí¸, ë³¸ ë°ëª ì ì 5 ì¤ììë¥¼ ì¤ëª í¨ì ìì´ì, íê¸°ìì ê¸°ì¬ëë ì 1 ë°©í¥ì ìê³ë°©í¥ì¸ ê²½ì°ë¥¼ ììì ì¼ë¡ ì¤ëª íê³ , ì 2 ë°©í¥ì ë°ìê³ë°©í¥ì¸ ê²½ì°ë¥¼ ììì ì¼ë¡ ì¤ëª íë¤. ëí, ë³¸ ë°ëª ì ì 5 ì¤ììë¥¼ ì¤ëª í¨ì ìì´ì, ì§ì§ë(510), ìê¸°ë ¥ ì ì´ëª¨ë(520) ë° í´ë¨í(540)ì ì 3 ì¤ìì ë´ì§ ì 5 ì¤ììì ë°ë¥¸ ì§ì§ë, ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬, ë° í´ë¨íì ëì¼í êµ¬ì¡°ì¼ ì ìë¤. ì´ì, íê¸°ììë ì§ì§ë(510), ìê¸°ë ¥ ì ì´ëª¨ë(520) ë° í´ë¨í(540)ì êµ¬ì¡°ì ê´í ì¤ëª ì ìëµíë¤. ëí, íê¸°ìì ìê¸°ë ¥ ì ì´ëª¨ë(520)ì ì¤ëª í¨ì ìì´, í´í¼ì¤ë¤ ì¤ ì§ì§ë(510)ì ë ì¸ì í í´í¼ì¤ë¥¼ ë³´ì¡°í´í¼ì¤(523)ë¼ íë©°, ê·¸ ìì©ë©´ì ë³´ì¡°ìì©ë©´(511a)ì´ë¼ íë¤. ë°ë©´, í´í¼ì¤ë¤ ì¤ ì§ì§ë(510)ë¡ë¶í° ìëì ì¼ë¡ ë©ê² ë°°ì¹ë í´í¼ì¤ë¥¼ í´í¼ì¤(521)ë¼ íë¤.On the other hand, in describing the fifth embodiment of the present invention, the first direction described below will exemplarily describe a clockwise direction, and the second direction will exemplarily describe a counterclockwise direction. In addition, in describing the fifth embodiment of the present invention, the support 510, the magnetic force control module 520, and the clamp 540 are the support according to the third to fifth embodiments, the first pole piece assembly, And it may have the same structure as the clamp. Therefore, in the following description of the structure of the support 510, the magnetic for

**[p0096]**

ce control module 520 and the clamp 540 will be omitted. In addition, in describing the magnetic force control module 520 below, a pole piece more adjacent to the support 510 among the pole pieces is referred to as an auxiliary pole piece 523, and its working surface is referred to as an auxiliary acting surface 511a. . On the other hand, among the pole pieces, a pole piece disposed relatively far from the support 510 is referred to as a pole piece 521 .

**[p0097]**

íì±ë ¥ ì ì´ëª¨ë(530)ì ì§ì§ì²´(531)ì íì±ì²´(532)ë¥¼ í¬í¨í ì ìë¤. The elastic force control module 530 may include a support 531 and an elastic body 532 . ì§ì§ì²´(531)ë ì§ì§ë(510)ì íë¶ì ë°°ì¹ëë©°, íì±ì²´(532)ì ì¼ë¨ì´ ì§ì§ëë ë¶ë¶ì¼ ì ìë¤. ì§ì§ì²´(531)ë ì§ì§ë(510)ì íë©´ì ê²°í©ë ì ìë¤. ëí, ì§ì§ì²´(531)ë ìê¸°ë ¥ ì ì´ëª¨ë(520)ê³¼ ë§ì£¼ë³´ë ì¼ë©´ì´ ìí¥ ê²½ì¬ì§ ê²½ì¬ë©´ì¼ë¡ íì±ë ì ìë¤. ë³¸ ë°ëª ì ì 5 ì¤ììì ë°ë¥¸ í´ë¨í(540)ë ì§ì§ë(510)ì íì  ê°ë¥íê² ê²°í©ëë©°, ì 1 ë°©í¥(ì¦, ìê³ë°©í¥) í¹ì ì 2 ë°©í¥(ì¦, ë°ìê³ë°©í¥)ì¼ë¡ íì ë ì ìë¤. ì´ì, ì§ì§ì²´(531)ì ì¸¡ë©´ë¤ ì¤ ìê¸°ë ¥ ì ì´ëª¨ë(520)ê³¼ ë§ì£¼ë³´ë ì¼ë©´ì´ ìí¥ ê²½ì¬ì§ ê²½ì¬ë©´ì¼ë¡ íì±ëë¯ë¡, íì íë í´ë¨í(540)ì ë©´ëë©´ì¼ë¡ ë§ì£¼ë³´ê² ë°°ì¹ë ì ìë¤.The support 531 is disposed under the support 510 and may be a portion where one end of the elastic body 532 is supported. The support 531 may be coupled to the lower surface of the support 510 . In addition, the support 531 may be formed as an upwardly inclined surface facing the magnetic force control module 520 . The clamp 540 according to the fifth embodiment of the present invention is rotatably coupled to the support 510 and can be rotated in a first direction (ie, clockwise direction) or a second direction (ie, counterclockwise direction). . Accordingly, since one side of the side surface of the support 531 facing the magnetic force control module 520

**[p0097]**

is formed as an inclined surface inclined upward, it may be disposed to face the rotating clamp 540 face to face.

**[p0098]**

íì±ì²´(532)ë ì¼ë¨ì´ ì§ì§ì²´(531)ì ê²½ì¬ë©´ì ì°ê²°ëê³ , íë¨ì´ í´ë¨í(540)ì ìì±ì²´(541)ì ê²°í©ë ì ìë¤. íê¸°ììë, ìì±ì²´(541)ê° ë¨ìë¡ íì±ëë ê²½ì°ë¥¼ ììì ì¼ë¡ ì¤ëª íë¤. ëí, íì±ì²´(532)ë ì ì¥ ìì¶ ê°ë¥íê² íì±ë ì ìë¤. ì¬ê¸°ì, íì±ì²´(532)ë ìì±ì²´(541)ë¥¼ ì§ì§ì²´(531)ë¥¼ í¥íì¬ ë¹ê¸°ëë¡ íì ê°í ì ìë¤. ìë¥¼ ë¤ì´, íì±ì²´(532)ë ì¸ì¥ì¤íë§ì¼ë¡ ë§ë ¨ë ì ìë¤. ì´ì, ìì±ì²´(541)ì ì¸ë ¥ì´ ê°í´ì§ì§ ìì ê²½ì°, ìì±ì²´(541)ë íì±ì²´(532)ì íì±ë ¥ì ìí´ ì§ì§ì²´(531)ë¥¼ í¥í´ ë¹ê²¨ì§ ìíë¥¼ ì ì§í ì ìë¤.One end of the elastic body 532 may be connected to the inclined surface of the support body 531 and the other end may be coupled to the magnetic body 541 of the clamp 540 . In the following, a case in which the magnetic material 541 is formed singularly will be described as an example. In addition, the elastic body 532 may be formed to be stretchable and contractible. Here, the elastic body 532 may apply force to pull the magnetic body 541 toward the support body 531 . For example, the elastic body 532 may be provided as a tension spring. Accordingly, when no external force is applied to the magnetic body 541 , the magnetic body 541 may maintain a state in which it is pulled toward the support body 531 by the elastic force of the elastic body 532 .

**[p0099]**

íê¸°ììë, ë 5a ë´ì§ ë 5dë¥¼ ì°¸ì¡°íì¬, í´ë¨í ì¥ì¹(500)ë¡ ëìì²´(50)ë¥¼ í´ë¨ííë ê³¼ì ì ê´í´ ì¤ëª íë¤. In the following, a process of clamping the object 50 with the clamping device 500 will be described with reference to FIGS. 5A to 5D. ë¨¼ì , ë 5aë¥¼ ì°¸ì¡°íë©´, í´ë¨í(540)ë íì±ì²´(532)ì íì±ë ¥ì ìí´ ì§ì§ì²´(531)ë¥¼ í¥í´ ë¹ê²¨ì ¸ ìì ì ìë¤. ëí, ìê¸°ë ¥ ì ì´ëª¨ë(520)ì ì½ì¼(522)ìë ì ìì´ ì¸ê°ëì§ ìì ìíì¼ ì ìë¤. í´í¼ì¤(521) ì¤ ê³ ì ìì(524)ì Sê·¹ê³¼ ì¸ì í ë¶ë¶ì Nê·¹ì¼ë¡ ìíëê³ , í´í¼ì¤(521) ì¤ ê³ ì ìì(524)ì Sê·¹ê³¼ ìëì ì¼ë¡ ë¨¼ ë¶ë¶, ì¦ íì ìì(525)ê³¼ ì¸ì íë ë¶ë¶ì Sê·¹ì¼ë¡ ìíë ì ìë¤. ë°ë©´, ë³´ì¡°í´í¼ì¤(521) ì¤ ê³ ì ìì(524)ì Nê·¹ê³¼ ì¸ì í ë¶ë¶ì Sê·¹ì¼ë¡ ìíëê³ , ë³´ì¡°í´í¼ì¤(521) ì¤ ê³ ì ìì(524)ì Nê·¹ê³¼ ìëì ì¼ë¡ ë¨¼ ë¶ë¶, ì¦ íì ìì(525)ê³¼ ì¸ì íë ë¶ë¶ì Nê·¹ì¼ë¡ ìíë ì ìë¤. ì´ì, íì ìì(525)ì ê·¸ Sê·¹ì´ ìì¸¡ì ë°°ì¹ëê³ , ê·¸ Nê·¹ì´ íì¸¡ì ë°°ì¹ë ì ìë¤. ë°ë¼ì, ë 5aì ëìë ì ì ê³¼ ê°ì´, ê³ ì ìì(524), í´í¼ì¤(521), íì ìì(525), ë³´ì¡°í´í¼ì¤(521)ë¥¼ íµí´, ìê¸° íë£¨íê° íì±ë ì ìë¤. First, referring to FIG. 5A , the clamp 540 may be pulled toward the support body 531 by the elastic force of the elastic body 532 . In addition, power may not be applied to the coil 522 of the magnetic force control module 520 . A portion of the pole piece 521 adjace

**[p0099]**

nt to the S pole of the stationary magnet 524 is magnetized to the N pole, and a portion of the pole piece 521 relatively far from the S pole of the stationary magnet 524, that is, the rotating magnet 525 A portion adjacent to may be magnetized to the S pole. On the other hand, a part of the auxiliary pole piece 521 adjacent to the N pole of the stator magnet 524 is magnetized to the S pole, and a part of the auxiliary pole piece 521 relatively far from the N pole of the stator magnet 524, that is, rotation A portion adjacent to the magnet 525 may be magnetized to the N pole. Accordingly, the S pole of the rotating magnet 525 may be disposed on the upper side and the N pole may be disposed on the lower side. Accordingly, a magnetic closed loop may be formed through the stator magnet 524, the pole piece 521, the rotating magnet 525, and the auxiliary pole piece 521 as indicated by the dotted line in FIG. 5A.

**[p0100]**

ë 5bë¥¼ ì°¸ì¡°íë©´, ì½ì¼(522)ì ì ë¥ê° íë¥´ëë¡ ì ì´í ì ìë¤. ì½ì¼(522)ì ì ë¥ê° íë¥´ë©´, í´í¼ì¤(521) ì¤ ê³ ì ìì(524)ê³¼ ì¸ì í ë¶ë¶ìë Sê·¹ì´ íì±ëê³ , í´í¼ì¤(521) ì¤ íì ìì(525)ê³¼ ì¸ì í ë¶ë¶ìë Nê·¹ì´ íì±ë ì ìë¤. ì´ì, íì ìì(525)ê³¼ í´í¼ì¤(521) ì¬ì´ì ì²ë ¥ì´ ë°ìíë©°, íì ìì(525)ì´ íì í ì ìë¤. ì´ì, íì ìì(525)ì ê·¸ Nê·¹ì ë°°ì¹ê° ë³´ì¡°í´í¼ì¤(521)ì ì¸ì íê² ë°°ì¹ëê³ , ê·¸ Sê·¹ì ë°°ì¹ê° í´í¼ì¤(521)ì ì¸ì íê² ë°°ì¹ë ì ìë¤. ì´ì, ìì©ë©´(521a) ë° ë³´ì¡°ìì©ë©´(523a)ì¼ë¡ë¶í° ìê¸°ì íë¦ì´ ë°ì°ëê³ , ìê¸°ë ¥ ì ì´ëª¨ë(520)ê³¼ ìì±ì²´(541) ì¬ì´ì ìê¸° íë£¨íê° íì±ë ì ìë¤. ë°ë¼ì, í´ë¨í(540)ê° ì 1 ë°©í¥(ì¦, ìê³ë°©í¥)ì¼ë¡ íì í ì ìë¤. ì´ë, íì±ë ìê¸° íë£¨íì ìí ì¸ë ¥ì íì±ì²´(532)ê° ìì±ì²´(541)ì ê°íë ì¸ë ¥ë³´ë¤ í´ ì ìë¤. ì¦, ìê¸°ë ¥ ì ì´ëª¨ë(520)ì ìí´ íì±ë ìê¸° íë£¨íì ìê¸°ë ¥ì´ íì±ì²´(532)ì íì±ë ¥ë³´ë¤ í´ ì ìë¤. Referring to FIG. 5B , current may be controlled to flow through the coil 522 . When current flows through the coil 522, an S pole is formed in a portion of the pole piece 521 adjacent to the stator magnet 524, and an N pole is formed in a portion of the pole piece 521 adjacent to the rotating magnet 525. can Accordingly, a repulsive force is generated between the rotating magnet 525 and the pole piece 521, and the rotating magnet 525 may rotate. Accordingly

**[p0100]**

, the N pole of the rotating magnet 525 may be disposed adjacent to the auxiliary pole piece 521 and the S pole may be disposed adjacent to the pole piece 521 . Accordingly, the flow of magnetism is diverged from the acting surface 521a and the auxiliary acting surface 523a, and a magnetic closed loop may be formed between the magnetic force control module 520 and the magnetic body 541. Accordingly, the clamp 540 may rotate in the first direction (ie, clockwise). At this time, the attractive force due to the formed magnetic closed loop may be greater than the attractive force applied to the magnetic body 541 by the elastic body 532 . That is, the magnetic force of the magnetic closed loop formed by the magnetic force control module 520 may be greater than the elastic force of the elastic body 532 .

**[p0101]**

ë 5cë¥¼ ì°¸ì¡°íë©´, ìì±ì²´(541)ê° ì 1 ë°©í¥(ì¦, ìê³ë°©í¥)ì¼ë¡ íì íë©°, ìì©ë©´(521a) ë° ë³´ì¡°ìì©ë©´(523a)ì ì ì´í ì ìë¤. ì¦, ìì±ì²´(541)ê° ìê¸°ë ¥ ì ì´ëª¨ë(520)ê³¼ íì±ë ìê¸° íë£¨íë¤ì íµí´ ì 1 ë°©í¥(ì¦, ìê³ë°©í¥)ì ë°ë¼ ë¹ê²¨ì§ë©°, ìì©ë©´(521a) ë° ë³´ì¡°ìì©ë©´(523a)ì ì ì´ë ì ìë¤. ì¬ê¸°ì, ë 5cì ëìë ì ì ê³¼ ê°ì´, ê³ ì ìì(524), í´í¼ì¤(521), ìì±ì²´(541), ë³´ì¡°í´í¼ì¤(521)ë¥¼ íµí´, íëì ìê¸° íë£¨íê° íì±ë ì ìë¤. ëí, ë 5cì ëìë ì ì ê³¼ ê°ì´, íì ìì(525), í´í¼ì¤(521), ìì±ì²´(541), ë³´ì¡°í´í¼ì¤(521)ë¥¼ íµí´, ë¤ë¥¸ íëì ìê¸° íë£¨íê° íì±ë ì ìë¤. ì´ì, ìê¸° íë£¨íë¤ì´ íì±ëë©´ ì½ì¼(522)ì ì¸ê°ë ì ìì ì ê±°íì¬ë ìê¸° íë£¨íë¤ì´ ì ì§ëë¯ë¡, ìê¸°ë ¥ ì ì´ëª¨ë(520)ì´ ìì±ì²´(541)ì í¡ì°©ì ì ì§í ì ìë¤. ìì±ì²´(541)ì ì 1 ë°©í¥(ì¦, ìê³ë°©í¥)ì¼ë¡ì íì ì ëìíì¬, ê°ìì²´(542)ê° ì 1 ë°©í¥(ì¦, ìê³ë°©í¥)ì¼ë¡ íì íê³ , ì§ì§ë(510)ì ìì°©ë ëìì²´(50)ë¥¼ í´ë¨íí ì ìë¤. ì¦, ì§ì§ë¡ë(542a)ê° íì í(534a)ì íì  ê°ë¥íê² ì§ì§ë ìíìì íì íë©°, ê°ìëê¸°(542b)ê° ëìì²´(50)ë¥¼ ëë¬ì¤ ì ìë¤. ì´í, ì ì§ëë ìê¸° íë£¨íë¤ì ìí´, ê°ìì²´(542)ê° ëìì²´(50)ì í´ë¨íì ì ì§í ì ìë¤. íí¸, ì 1 ë°©í¥(ì¦, ìê³ë°©í¥)ì¼ë¡ íì íë ìì±ì²´(541)ì ìí´, íì±ì²´(532)ê° ì ì¥ë ì ìë¤. Referring to

**[p0101]**

FIG. 5C , the magnetic material 541 rotates in a first direction (ie, clockwise direction) and may contact the working surface 521a and the auxiliary working surface 523a. That is, the magnetic material 541 is pulled along the first direction (ie, clockwise direction) through the magnetic closed loops formed with the magnetic force control module 520, and may come into contact with the action surface 521a and the auxiliary action surface 523a. there is. Here, as shown in the dotted line shown in FIG. 5C, one magnetic closed loop may be formed through the stator magnet 524, the pole piece 521, the magnetic body 541, and the auxiliary pole piece 521. In addition, as shown in the dotted line shown in FIG. 5C, another magnetic closed loop may be formed through the rotating magnet 525, the pole piece 521, the magnetic body 541, and the auxiliary pole piece 521. Accordingly, when the magnetic closed loops are formed, the magnetic force control module 520 can maintain the adsorption of the magnetic material 541 because the magnetic closed loops are maintained even when the voltage applied to the coil 522 is removed. Corresponding to the rotation of the magnetic body 541 in the first direction (ie, clockwise direction), the pressing body 542 rotates in the first direction (ie, clockwise direction), and the object 50 seated on the support 510 ) can be clamped. That is, the support rod 542a rotates while being rotatably supported by the rotation pin 534a, and the pressing protrusion 542b can press the object 50. Thereafter, the pressing body 542 may maintain the clamping of the targe

**[p0101]**

t object 50 by the maintained magnetic closed loops. Meanwhile, the elastic body 532 may be extended by the magnetic body 541 rotating in the first direction (ie, clockwise direction).

**[p0102]**

ë 5dë¥¼ ì°¸ì¡°íë©´, ì½ì¼(522)ì ì ë¥ê° íë¥´ëë¡ ì ì´í ì ìë¤. ì½ì¼(522)ì ì ë¥ê° íë¥´ë©´, í´í¼ì¤(521) ì¤ ê³ ì ìì(524)ê³¼ ì¸ì í ë¶ë¶ìë Nê·¹ì´ íì±ëê³ , í´í¼ì¤(521) ì¤ íì ìì(525)ê³¼ ì¸ì í ë¶ë¶ìë Sê·¹ì´ íì±ë ì ìë¤. ì´ì, íì ìì(525)ê³¼ í´í¼ì¤(521) ì¬ì´ì ì²ë ¥ì´ ë°ìíë©°, íì ìì(525)ì´ íì í ì ìë¤. ì´ì, íì ìì(525)ì ê·¸ Nê·¹ì ë°°ì¹ê° í´í¼ì¤(521)ì ì¸ì íê² ë°°ì¹ëê³ , ê·¸ Sê·¹ì ë°°ì¹ê° ë³´ì¡°í´í¼ì¤(521)ì ì¸ì íê² ë°°ì¹ë ì ìë¤. ì´ì, ìì©ë©´(521a) ë° ë³´ì¡°ìì©ë©´(523a)ì¼ë¡ë¶í° ìê¸°ì íë¦ì´ ë°ì°ëë ê²ì´ ì¤ë¨ëê³ , ìê¸°ë ¥ ì ì´ëª¨ë(520)ê³¼ ìì±ì²´(541) ì¬ì´ì ìê¸° íë£¨íê° í´ì ë ì ìë¤. ìê¸° íë£¨íê° í´ì ëë©´, ìì±ì²´(541)ë íì±ì²´(532)ì íì±ë ¥ì ìí´ ë¹ê²¨ì§ë©°, ì§ì§ì²´(531)ë¥¼ í¥í´ ì 2 ë°©í¥(ì¦, ë°ìê³ë°©í¥)ì¼ë¡ íì í ì ìë¤. ì´ì, í´ë¨í(540)ê° ì 2 ë°©í¥(ì¦, ë°ìê³ë°©í¥)ì¼ë¡ íì íë©°, ê°ìì²´(542)ê° ëìì²´(50)ì í´ë¨íì í´ì í ì ìë¤.Referring to FIG. 5D , current may be controlled to flow through the coil 522 . When a current flows through the coil 522, an N pole is formed in a portion of the pole piece 521 adjacent to the stator magnet 524, and an S pole is formed in a portion of the pole piece 521 adjacent to the rotating magnet 525. can Accordingly, a repulsive force is generated between the rotating magnet 525 and the pole piece 521, and the rotating magnet 525 may rotate. Acco

**[p0102]**

rdingly, the N pole of the rotating magnet 525 may be disposed adjacent to the pole piece 521 and the S pole may be disposed adjacent to the auxiliary pole piece 521 . Accordingly, divergence of magnetic flow from the acting surface 521a and the auxiliary acting surface 523a is stopped, and the magnetic closed loop between the magnetic force control module 520 and the magnetic body 541 can be released. When the magnetic closed loop is released, the magnetic body 541 is pulled by the elastic force of the elastic body 532 and may rotate toward the support body 531 in a second direction (ie, counterclockwise direction). Accordingly, the clamp 540 rotates in the second direction (ie, counterclockwise direction), and the pressing body 542 may release the clamping of the object 50 .

**[p0103]**

ë 6a ë´ì§ ë 6dë ë³¸ ë°ëª ì ì 6 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ë¥¼ ê°ëµì ì¼ë¡ ëìí ëë©´ì´ë¤. 6A to 6D are views schematically showing a clamping device according to a sixth embodiment of the present invention. íê¸°ììë ë³¸ ë°ëª ì ì¤ììë¤ ì¤ ì 6 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ì êµ¬ì¡°ë¥¼ ì¤ëª íë¤. ì´ë, ë³¸ ë°ëª ì ì 1 ì¤ìì ë´ì§ ì 5 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ì ëì¼í êµ¬ì¡°ì ê´í ì¤ëª ì ìëµíê¸°ë¡ íë¤.In the following, the structure of the clamping device according to the sixth embodiment among the embodiments of the present invention will be described. At this time, description of the same structure as the clamping device according to the first to fifth embodiments of the present invention will be omitted. ë³¸ ë°ëª ì ì 6 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹(600)ë ì§ì§ë(610), ìê¸°ë ¥ ì ì´ëª¨ë(620), íì±ë ¥ ì ì´ëª¨ë(630) ë° í´ë¨í(640)ë¥¼ í¬í¨í ì ìë¤.The clamping device 600 according to the sixth embodiment of the present invention may include a support 610, a magnetic force control module 620, an elastic force control module 630, and a clamp 640.

**[p0104]**

íí¸, ëí, ë³¸ ë°ëª ì ì 6 ì¤ììë¥¼ ì¤ëª í¨ì ìì´ì, ìê¸°ë ¥ ì ì´ëª¨ë(620)ì ëë©´ì ì°ì¸¡ì ë°°ì¹ëê³ , íì±ë ¥ ì ì´ëª¨ë(630)ì ëë©´ì ì¢ì¸¡ì ë°°ì¹ëë ê²½ì°ë¥¼ ììì ì¼ë¡ ì¤ëª íë¤. ëí, ë³¸ ë°ëª ì ì 6 ì¤ììë¥¼ ì¤ëª í¨ì ìì´ì, íê¸°ìì ê¸°ì¬ëë ì 1 ë°©í¥ì ì§ì§ì²´ë¥¼ í¥íë ë°©í¥ì¸ ê²½ì°ë¥¼ ììì ì¼ë¡ ì¤ëª íê³ , ì 2 ë°©í¥ì ìì©ë©´ ë° ë³´ì¡°ìì©ë©´ì í¥íë ë°©í¥ì¸ ê²½ì°ë¥¼ ììì ì¼ë¡ ì¤ëª íë¤. Meanwhile, in describing the sixth embodiment of the present invention, a case in which the magnetic force control module 620 is disposed on the right side in the drawing and the elastic force control module 630 is disposed in the left side in the drawing will be exemplarily described. . In addition, in describing the sixth embodiment of the present invention, the case in which the first direction described below is directed toward the support is illustratively described, and the second direction is directed toward the acting surface and the auxiliary acting surface. is described by way of example.

**[p0105]**

ì§ì§ì²´(631)ë ìê¸°ë ¥ ì ì´ëª¨ë(620)ì í¥íë ì¼ì¸¡ë©´ì´ íë©´ì¼ë¡ íì±ë ì ìë¤. One side of the support 631 facing the magnetic force control module 620 may be formed as a flat surface. ëí, íì±ì²´(632)ë ë³µìê°ë¡ ë§ë ¨ë ì ìë¤. ë³µìì íì±ì²´(632) ì¤ ì¼ íì±ì²´(632a)ë ì¼ë¨ì´ ì§ì§ì²´(631)ì ê²°í©ëê³ , íë¨ì´ ìì±ì²´(641)ì ê²°í©ë ì ìë¤. ëí, ì¼ íì±ì²´(632a)ì ë´ì ë ì¼(643)ì´ ì½ì ë ì ìë¤. ëí, ë³µìì íì±ì²´(632) ì¤ í íì±ì²´(632b)ë ì¼ë¨ì´ ì§ì§ì²´(631)ì ê²°í©ëê³ , íë¨ì´ ìì±ì²´(641)ì ê²°í©ë ì ìë¤. ì¬ê¸°ì, í íì±ì²´(632) ë´ì íì ëë ë³´ì¡°ë ì¼(644)ì´ ì½ì ë ì ìì¼ë©°, í íì±ì²´(632)ë ì¼ íì±ì²´(632)ë³´ë¤ ì§ì§ë(610)ë¡ë¶í° ë¨¼ ìì¹ì ë°°ì¹ë ì ìë¤. ìì»¨ë°, í íì±ì²´(632)ë ëë©´ì ì¼ íì±ì²´(632)ë³´ë¤ íì¸¡ì ë°°ì¹ë ì ìë¤.In addition, a plurality of elastic bodies 632 may be provided. One elastic body 632a among the plurality of elastic bodies 632 may have one end coupled to the support 631 and the other end coupled to the magnetic body 641 . Also, a rail 643 may be inserted into one elastic body 632a. In addition, one end of another elastic body 632b among the plurality of elastic bodies 632 may be coupled to the support body 631 and the other end may be coupled to the magnetic body 641 . Here, an auxiliary rail 644 described below may be inserted into the other elastic body 632 , and the other elastic body 632 may be disposed at a position farther from the support 610

**[p0105]**

than the one elastic body 632 . For example, another elastic body 632 may be disposed lower than one elastic body 632 in the drawing.

**[p0106]**

í´ë¨í(640)ë ì¼ë¨ì´ ì§ì§ì²´(631)ì ê²°í©ëê³ , íë¨ì´ ë³´ì¡°í´í¼ì¤(623)ì ì°ê²°ëë ë³´ì¡°ë ì¼(644)ì ë í¬í¨í ì ìë¤. The clamp 640 may further include an auxiliary rail 644 having one end coupled to the support 631 and the other end connected to the auxiliary pole piece 623 . íí¸, ìì±ì²´(641)ë ë¨ìê°ë¡ íì±ëë©°, ë ì¼(643) ë° ë³´ì¡°ë ì¼(644)ì ì´ë ê°ë¥íê² ê²°í©ë ì ìë¤. ì¦, ìì±ì²´(641)ë ë ì¼(643) ë° ë³´ì¡°ë ì¼(644)ì ì°ì¥ë°©í¥ì ë°ë¼, ì íì§ ì¬ë¼ì´ë© ì´ëí ì ìë¤. On the other hand, the magnetic body 641 is formed in a singular number, and may be movably coupled to the rail 643 and the auxiliary rail 644 . That is, the magnetic material 641 may slide forward and backward along the extension direction of the rail 643 and the auxiliary rail 644 . íê¸°ììë, ë 6a ë´ì§ ë 6dë¥¼ ì°¸ì¡°íì¬, í´ë¨í ì¥ì¹(600)ë¡ ëìì²´(60)ë¥¼ í´ë¨ííë ê³¼ì ì ê´í´ ì¤ëª íë¤. In the following, a process of clamping the object 60 with the clamping device 600 will be described with reference to FIGS. 6A to 6D.

**[p0107]**

ë¨¼ì , ë 6aë¥¼ ì°¸ì¡°íë©´, í´ë¨í(640)ë íì±ì²´(632)ì íì±ë ¥ì ìí´ ì§ì§ì²´(631)ë¥¼ í¥í´ ë¹ê²¨ì ¸ ìì ì ìë¤. ëí, ìê¸°ë ¥ ì ì´ëª¨ë(620)ì ì½ì¼(622)ìë ì ìì´ ì¸ê°ëì§ ìì ìíì¼ ì ìë¤. ë³´ì¡°í´í¼ì¤(623) ì¤ ê³ ì ìì(624)ì Sê·¹ê³¼ ì¸ì í ë¶ë¶ì Nê·¹ì¼ë¡ ìíëê³ , ë³´ì¡°í´í¼ì¤(623) ì¤ ê³ ì ìì(624)ì Sê·¹ê³¼ ìëì ì¼ë¡ ë¨¼ ë¶ë¶, ì¦ íì ìì(625)ê³¼ ì¸ì íë ë¶ë¶ì Sê·¹ì¼ë¡ ìíë ì ìë¤. ë°ë©´, í´í¼ì¤(621) ì¤ ê³ ì ìì(624)ì Nê·¹ê³¼ ì¸ì í ë¶ë¶ì Sê·¹ì¼ë¡ ìíëê³ , í´í¼ì¤(621) ì¤ ê³ ì ìì(624)ì Nê·¹ê³¼ ìëì ì¼ë¡ ë¨¼ ë¶ë¶, ì¦ íì ìì(625)ê³¼ ì¸ì íë ë¶ë¶ì Nê·¹ì¼ë¡ ìíë ì ìë¤. ì´ì, íì ìì(625)ì ê·¸ Nê·¹ì´ ìì¸¡ì ë°°ì¹ëê³ , ê·¸ Sê·¹ì´ íì¸¡ì ë°°ì¹ë ì ìë¤. ë°ë¼ì, ê³ ì ìì(624)ì´ í´í¼ì¤(621), íì ìì(625), ë³´ì¡°í´í¼ì¤(623)ë¥¼ íµí´, ë 6aì ëìë ì ì ê³¼ ê°ì´, ìê¸° íë£¨íë¥¼ íì±í ì ìë¤. First, referring to FIG. 6A , the clamp 640 may be pulled toward the support 631 by the elastic force of the elastic body 632 . In addition, power may not be applied to the coil 622 of the magnetic force control module 620 . A part of the auxiliary pole piece 623 adjacent to the S pole of the stationary magnet 624 is magnetized to the N pole, and a part of the auxiliary pole piece 623 relatively far from the S pole of the stationary magnet 624, that is, the rotating magnet ( 625) may be magnetized to the S pole. On the other hand, a portio

**[p0107]**

n of the pole piece 621 adjacent to the N pole of the stator magnet 624 is magnetized to the S pole, and a portion of the pole piece 621 relatively far from the N pole of the stator magnet 624, that is, the rotating magnet ( 625) may be magnetized to the N pole. Accordingly, the N pole of the rotating magnet 625 may be disposed on the upper side and the S pole may be disposed on the lower side. Accordingly, the stator magnet 624 may form a magnetic closed loop through the pole piece 621, the rotating magnet 625, and the auxiliary pole piece 623, as shown in the dotted line shown in FIG. 6A.

**[p0108]**

ë 6bë¥¼ ì°¸ì¡°íë©´, ì½ì¼(622)ì ì ë¥ê° íë¥´ëë¡ ì ì´í ì ìë¤. ì½ì¼(622)ì ì ë¥ê° íë¥´ë©´, í´í¼ì¤(621) ì¤ ê³ ì ìì(624)ê³¼ ì¸ì í ë¶ë¶ìë Nê·¹ì´ íì±ëê³ , í´í¼ì¤(621) ì¤ íì ìì(625)ê³¼ ì¸ì í ë¶ë¶ìë Sê·¹ì´ íì±ë ì ìë¤. ì´ì, íì ìì(625)ê³¼ í´í¼ì¤(621) ì¬ì´ì ì²ë ¥ì´ ë°ìíë©°, íì ìì(625)ì´ íì í ì ìë¤. ì´ì, íì ìì(625)ì ê·¸ Sê·¹ì ë°°ì¹ê° ë³´ì¡°í´í¼ì¤(623)ì ì¸ì íê² ë°°ì¹ëê³ , ê·¸ Nê·¹ì ë°°ì¹ê° í´í¼ì¤(621)ì ì¸ì íê² ë°°ì¹ë ì ìë¤. ì´ì, ìì©ë©´(621a) ë° ë³´ì¡°ìì©ë©´(623a)ì¼ë¡ë¶í° ìê¸°ì íë¦ì´ ë°ì°ëê³ , ìê¸°ë ¥ ì ì´ëª¨ë(620)ê³¼ ìì±ì²´(641) ì¬ì´ì ìê¸° íë£¨íê° íì±ë ì ìë¤. ë°ë¼ì, í´ë¨í(640)ê° ì 2 ë°©í¥ì¼ë¡ ì¬ë¼ì´ë© ì´ëí ì ìë¤. Referring to FIG. 6B , current may be controlled to flow through the coil 622 . When a current flows through the coil 622, an N pole is formed in a portion of the pole piece 621 adjacent to the stator magnet 624, and an S pole is formed in a portion of the pole piece 621 adjacent to the rotating magnet 625. can Accordingly, a repulsive force is generated between the rotating magnet 625 and the pole piece 621, and the rotating magnet 625 may rotate. Accordingly, the S pole of the rotating magnet 625 may be disposed adjacent to the auxiliary pole piece 623 and the N pole may be disposed adjacent to the pole piece 621 . Accordingly, the flow of magnetism is diverged from the acting surface 621a and the auxiliary acting surface

**[p0108]**

623a, and a magnetic closed loop between the magnetic force control module 620 and the magnetic body 641 may be formed. Accordingly, the clamp 640 may slide in the second direction.

**[p0109]**

ì´ë, íì±ë ìê¸° íë£¨íì ìí ì¸ë ¥ì íì±ì²´(632)ì ì¸ë ¥ë³´ë¤ í´ ì ìë¤. ì¦, ìê¸°ë ¥ ì ì´ëª¨ë(620)ì ìí´ íì±ë ìê¸° íë£¨íì ìê¸°ë ¥ì´ íì±ì²´(632)ì íì±ë ¥ë³´ë¤ í´ ì ìë¤. At this time, the attractive force due to the formed magnetic closed loop may be greater than the attractive force of the elastic body 632 . That is, the magnetic force of the magnetic closed loop formed by the magnetic force control module 620 may be greater than the elastic force of the elastic body 632 . ë 6cë¥¼ ì°¸ì¡°íë©´, ìì±ì²´(641)ê° ì 2 ë°©í¥ì¼ë¡ ì¬ë¼ì´ë© ì´ëíë©°, ìì©ë©´(621a) ë° ë³´ì¡°ìì©ë©´(623a)ì ì ì´í ì ìë¤. ì¦, ìì±ì²´(641)ê° ìê¸°ë ¥ ì ì´ëª¨ë(620)ê³¼ íì±ë ìê¸° íë£¨íë¤ì íµí´ ì 2 ë°©í¥ì ë°ë¼ ë¹ê²¨ì§ë©°, ìì©ë©´(621a) ë° ë³´ì¡°ìì©ë©´(623a)ì ì ì´ë ì ìë¤. ì¬ê¸°ì, ë 6cì ëìë ì ì ê³¼ ê°ì´, ê³ ì ìì(624), í´í¼ì¤(621), ìì±ì²´(641), ë³´ì¡°í´í¼ì¤(623)ë¥¼ íµí´, íëì ìê¸° íë£¨íê° íì±ë ì ìë¤. ëí, ë 6cì ëìë ì ì ê³¼ ê°ì´, íì ìì(625), í´í¼ì¤(621), ìì±ì²´(641), ë³´ì¡°í´í¼ì¤(623)ë¥¼ íµí´, ë¤ë¥¸ íëì ìê¸° íë£¨íê° íì±ë ì ìë¤. ì´ì, ìê¸° íë£¨íë¤ì´ íì±ëë©´ ì½ì¼(622)ì ì¸ê°ë ì ìì ì ê±°íì¬ë ìê¸° íë£¨íë¤ì´ ì ì§ëë¯ë¡, ìê¸°ë ¥ ì ì´ëª¨ë(620)ì´ ìì±ì²´(641)ì í¡ì°©ì ì ì§í ì ìë¤. ìì±ì²´(641)ì ì 2 ë°©í¥ì¼ë¡ì ì¬ë¼ì´ë© ì´ëì ëìíì¬, ê°ìì²´(642)ê° ì 2 ë°©í¥ì¼ë¡ ì¬ë¼ì

**[p0109]**

´ë© ì´ëíê³ , ì§ì§ë(610)ì ìì°©ë ëìì²´(60)ë¥¼ í´ë¨íí ì ìë¤. ì¦, ì§ì§ë¡ë(642a)ê° ì½ì

**[p0110]**

í(610a) ë´ë¥¼ ì ì§íë©°, ê°ìëê¸°(642a)ê° ëìì²´(60)ë¥¼ ê°ìí ì ìë¤. ì´í, ì ì§ëë ìê¸° íë£¨íë¤ì ìí´, ê°ìì²´(642)ê° ëìì²´(60)ì í´ë¨íì ì ì§í ì ìë¤. Referring to FIG. 6C , the magnetic material 641 slides in the second direction and may contact the acting surface 621a and the auxiliary acting surface 623a. That is, the magnetic material 641 is pulled along the second direction through magnetic closed loops formed with the magnetic force control module 620, and may come into contact with the action surface 621a and the auxiliary action surface 623a. Here, as shown in the dotted line shown in FIG. 6C, one magnetic closed loop may be formed through the stator magnet 624, the pole piece 621, the magnetic body 641, and the auxiliary pole piece 623. In addition, as shown in the dotted line shown in FIG. 6C, another magnetic closed loop may be formed through the rotating magnet 625, the pole piece 621, the magnetic body 641, and the auxiliary pole piece 623. Accordingly, when the magnetic closed loops are formed, the magnetic force control module 620 can maintain the adsorption of the magnetic material 641 because the magnetic closed loops are maintained even when the voltage applied to the coil 622 is removed. In response to the sliding movement of the magnetic body 641 in the second direction, the pressing body 642 may slide in the second direction and clamp the object 60 seated on the support 610 . That is, the support rod 642a advances in the insertion hole 610a, and the pressing protrusion 642a may press the objec

**[p0110]**

t 60. Thereafter, the pressing body 642 may maintain the clamping of the target object 60 by the maintained magnetic closed loops.

**[p0111]**

íí¸, ì 2 ë°©í¥ì¼ë¡ ì¬ë¼ì´ë© ì´ëíë ìì±ì²´(641)ì ìí´, íì±ì²´(632)ê° ì ì¥ë ì ìë¤. Meanwhile, the elastic body 632 may be extended by the magnetic body 641 sliding in the second direction. ë 6dë¥¼ ì°¸ì¡°íë©´, ì½ì¼(622)ì ì ë¥ê° íë¥´ëë¡ ì ì´í ì ìë¤. ì½ì¼(622)ì ì ë¥ê° íë¥´ë©´, í´í¼ì¤(621) ì¤ ê³ ì ìì(624)ê³¼ ì¸ì í ë¶ë¶ìë Sê·¹ì´ íì±ëê³ , í´í¼ì¤(621) ì¤ íì ìì(625)ê³¼ ì¸ì í ë¶ë¶ìë Nê·¹ì´ íì±ë ì ìë¤. ì´ì, íì ìì(625)ê³¼ í´í¼ì¤(621) ì¬ì´ì ì²ë ¥ì´ ë°ìíë©°, íì ìì(625)ì´ íì í ì ìë¤. ì´ì, íì ìì(625)ì ê·¸ Sê·¹ì ë°°ì¹ê° í´í¼ì¤(621)ì ì¸ì íê² ë°°ì¹ëê³ , ê·¸ Nê·¹ì ë°°ì¹ê° ë³´ì¡°í´í¼ì¤(623)ì ì¸ì íê² ë°°ì¹ë ì ìë¤. ì´ì, ìì©ë©´(621a) ë° ë³´ì¡°ìì©ë©´(623a)ì¼ë¡ë¶í° ìê¸°ì íë¦ì´ ë°ì°ëë ê²ì´ ì¤ë¨ëê³ , ìê¸°ë ¥ ì ì´ëª¨ë(620)ê³¼ ìì±ì²´(641) ì¬ì´ì ìê¸° íë£¨íê° í´ì ë ì ìë¤. Referring to FIG. 6D , current may be controlled to flow through the coil 622 . When current flows through the coil 622, an S pole is formed in a portion of the pole piece 621 adjacent to the stator magnet 624, and an N pole is formed in a portion of the pole piece 621 adjacent to the rotating magnet 625. can Accordingly, a repulsive force is generated between the rotating magnet 625 and the pole piece 621, and the rotating magnet 625 may rotate. Accordingly, the S pole of the rotating magnet 625 may be disposed adjacent to the pole piece 621 and the N pole may be d

**[p0111]**

isposed adjacent to the auxiliary pole piece 623 . Accordingly, divergence of magnetic flow from the action surface 621a and the auxiliary action surface 623a is stopped, and the magnetic closed loop between the magnetic force control module 620 and the magnetic body 641 can be released.

**[p0112]**

ìê¸° íë£¨íê° í´ì ëë©´, ìì±ì²´(641)ë íì±ì²´(632)ì íì±ë ¥ì ìí´ ë¹ê²¨ì§ë©°, ì§ì§ì²´(631)ë¥¼ í¥í´ ì 1 ë°©í¥ì¼ë¡ ì¬ë¼ì´ë© ì´ëí ì ìë¤. ì´ì, í´ë¨í(640)ê° ì 1 ë°©í¥ì¼ë¡ ì¬ë¼ì´ë© ì´ëíë©°, ê°ìì²´(642)ê° ëìì²´(60)ì í´ë¨íì í´ì í ì ìë¤.When the magnetic closed loop is released, the magnetic body 641 is pulled by the elastic force of the elastic body 632 and can slide toward the support body 631 in the first direction. Accordingly, the clamp 640 slides in the first direction, and the pressing body 642 may release the clamping of the object 60 . ë 7a ë´ì§ ë 7dë ë³¸ ë°ëª ì ì 7 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ë¥¼ ê°ëµì ì¼ë¡ ëìí ëë©´ì´ë¤.7A to 7D are diagrams schematically showing a clamping device according to a seventh embodiment of the present invention. íê¸°ììë ë³¸ ë°ëª ì ì¤ììë¤ ì¤ ì 7 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ì êµ¬ì¡°ë¥¼ ì¤ëª íë¤. ì´ë, ë³¸ ë°ëª

**[p0113]**

ì ì 1 ì¤ìì ë´ì§ ì 6 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹ì ëì¼í êµ¬ì¡°ì ê´í ì¤ëª ì ìëµíê¸°ë¡ íë¤.In the following, the structure of the clamping device according to the seventh embodiment among the embodiments of the present invention will be described. At this time, description of the same structure as the clamping device according to the first to sixth embodiments of the present invention will be omitted. ë³¸ ë°ëª ì ì 7 ì¤ììì ë°ë¥¸ í´ë¨í ì¥ì¹(700)ë ê°ê° ìì©ë©´ì ê°ë ë³µìì í´í¼ì¤(710), ë³µìì í´í¼ì¤(710) ì¤ ì ì´ë ì´ë íëì ê°ê¸°ë ì½ì¼(720), ë³µìì í´í¼ì¤(710) ì¬ì´ì ê³ ì ëë ê³ ì ìì(730), ë³µìì í´í¼ì¤(710) ì¬ì´ìì ê³ ì ìì(730)ê³¼ ì´ê²© ë°°ì¹ëê³ ì½ì¼(720)ì íë¥´ë ì ë¥ì ì ì´ì ìí´ íì  ê°ë¥í íì ìì(740) ë° ë³µìì í´í¼ì¤(710) ì¬ì´ì ë°°ì¹ëê³ ì½ì¼(720)ì ì¸ê°ëë ì ë¥ì ì ì´ ìí´ ê°ê°ì ìì©ë©´ë¤(ì¦, ì¼ ìì©ë©´(711a), í ìì©ë©´(712b))ì ì ì´í ëìì²´(70)ì ë´ë¶ë¡ ì½ì

**[p0114]**

ê°ë¥í ì½ì ëê¸°(751)ë¥¼ êµ¬ë¹íë ê³ ì ë(750)ë¥¼ í¬í¨í ì ìë¤.The clamping device 700 according to the seventh embodiment of the present invention includes a plurality of pole pieces 710 each having a working surface, a coil 720 wound around at least one of the plurality of pole pieces 710, and a plurality of poles. A stator magnet 730 fixed between the pieces 710, a rotating magnet 740 disposed apart from the stator magnet 730 between a plurality of pole pieces 710 and rotatable by control of the current flowing through the coil 720 and an object contacting each of the working surfaces (ie, one working surface 711a, the other working surface 712b) by controlling the current disposed between the plurality of pole pieces 710 and applied to the coil 720 ( 70) may include a fixing table 750 having an insertion protrusion 751 insertable into the inside. íí¸, ë³¸ ë°ëª ì ì 7 ì¤ììë¥¼ ì¤ëª í¨ì ìì´ì, ëìì²´(70)ë ê·¸ ì¤ì¬ë¶ì ìíë¡ ê´íµë ê´íµí(71)ì´ íì±ë ê²½ì°ë¥¼ ììì ì¼ë¡ ì¤ëª

**[p0115]**

íë¤. ëí, ë³¸ ë°ëª ì ì 7 ì¤ììë¥¼ ì¤ëª í¨ì ìì´ì, ë³µìì í´í¼ì¤(710), ì½ì¼(720), ê³ ì ìì(730), íì ìì(740)ì ìì í ì 3 ì¤ìì ë´ì§ ì 4 ì¤ììì ë°ë¥¸ ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬ ë° ì 5 ì¤ìì ë´ì§ ì 6 ì¤ììì ë°ë¥¸ ìê¸°ë ¥ ì ì´ëª¨ëê³¼ ëì¼í êµ¬ì¡°ì¼ ì ìë¤. ì´ì, ë³µìì í´í¼ì¤(710), ì½ì¼(720), ê³ ì ìì(730), íì ìì(740)ì êµ¬ì¡°ì ê´í ì¤ëª ì ìëµíë¤. íí¸, íê¸°ìì, ì½ì¼(720)ì ë³µìê°ë¡ ë§ë ¨ëë©°, ë³µìì ì½ì¼(720)ì´ ë³µìì í´í¼ì¤(710)ì ê°ê° ê°ê¸´ ê²½ì°ë¥¼ ììì ì¼ë¡ ì¤ëª íë¤. ëí, ë³µìì í´í¼ì¤(710) ì¤ ëë©´ì ì¢ì¸¡ì ë°°ì¹ëë í´í¼ì¤ë¥¼ ì¼ í´í¼ì¤(711)ë¼ íë©°, ëë©´ì ì¢ì¸¡ì ë°°ì¹ëë í´í¼ì¤ë¥¼ í í´í¼ì¤(712)ë¼ íë¤. ëí, ì¼ í´í¼ì¤(711)ì ìì©ë©´ì ì¼ ìì©ë©´(711a)ì´ë¼ íê³ , í í´í¼ì¤(712)ì ìì©ë©´ì í ìì©ë©´(712a)ì´ë¼ íë¤.On the other hand, in describing the seventh embodiment of the present invention, a case in which a through hole 71 penetrating up and down is formed in the center of the object 70 will be described as an example. In addition, in describing the seventh embodiment of the present invention, the plurality of pole pieces 710, coils 720, stationary magnets 730, and rotating magnets 740 are used in the third to fourth embodiments described above. It may have the same structure as the first pole piece assembly according to and the magnetic force control module according to the fifth to sixth embodiments. Accordingly, desc

**[p0115]**

riptions of the structures of the plurality of pole pieces 710, the coil 720, the stator magnet 730, and the rotating magnet 740 will be omitted. Meanwhile, in the following, a case in which a plurality of coils 720 are provided and each of the plurality of coils 720 is wound around a plurality of pole pieces 710 will be described as an example. In addition, among the plurality of pole pieces 710, a pole piece disposed on the left side in the drawing is referred to as one pole piece 711, and a pole piece disposed on the left side in the drawing is referred to as another pole piece 712. In addition, the working surface of one pole piece 711 is referred to as one working surface 711a, and the working surface of the other pole piece 712 is referred to as the other working surface 712a.

**[p0116]**

ê³ ì ë(750)ë ê·¸ ì ì´ë ì¼ë¶(ì¦, ì½ì ëê¸°(751))ê° ëìì²´(70)ì ê´íµí(71)ì ì½ì ê°ë¥íë©°, ëìì²´(70)ì ì¢ì° ì´ëì ì íí ì ìë¤. ê³ ì ë(750)ë ë³µìì í´í¼ì¤(710)ë¤ ì¬ì´ì ê°ê²©ë³´ë¤ ì§§ê±°ë ê°ì ê¸¸ì´ë¡ íì±ë ì ìë¤. ì½ì ëê¸°(751)ë ê³ ì ë(750)ì ìë¶ë¡ ëì¶ë ì ìë¤. ì¬ê¸°ì, ì½ì ëê¸°(751)ë ìì©ë©´ë³´ë¤ ìì¸¡ì¼ë¡ ë ëì¶ë ì ìë¤. At least a portion of the holder 750 (ie, the insertion protrusion 751) can be inserted into the through hole 71 of the object 70, and can restrict left and right movement of the object 70. The fixing table 750 may be formed to have a length equal to or shorter than the distance between the plurality of pole pieces 710 . The insertion protrusion 751 may protrude upward from the fixing table 750 . Here, the insertion protrusion 751 may protrude more upward than the working surface. íê¸°ììë, ë 7a ë´ì§ ë 7dë¥¼ ì°¸ì¡°íì¬, í´ë¨í ì¥ì¹(700)ë¡ ëìì²´(70)ë¥¼ í´ë¨ííë ê³¼ì ì ê´í´ ì¤ëª

**[p0117]**

íë¤. In the following, a process of clamping the object 70 with the clamping device 700 will be described with reference to FIGS. 7A to 7D. ë¨¼ì , ë 7aë¥¼ ì°¸ì¡°íë©´, ì½ì¼(720)ìë ì ìì´ ì¸ê°ëì§ ìì ìíì¼ ì ìë¤. ì¼ í´í¼ì¤(711) ì¤ ê³ ì ìì(730)ì Nê·¹ê³¼ ì¸ì í ë¶ë¶ì Sê·¹ì¼ë¡ ìíëê³ , ì¼ í´í¼ì¤(711) ì¤ ê³ ì ìì(730)ì Nê·¹ê³¼ ìëì ì¼ë¡ ë¨¼ ë¶ë¶, ì¦ íì ìì(740)ê³¼ ì¸ì íë ë¶ë¶ì Nê·¹ì¼ë¡ ìíë ì ìë¤. ë°ë©´, í í´í¼ì¤(712) ì¤ ê³ ì ìì(730)ì Sê³¼ ì¸ì í ë¶ë¶ì Nì¼ë¡ ìíëê³ , í í´í¼ì¤(712) ì¤ ê³ ì ìì(730)ì Sê·¹ê³¼ ìëì ì¼ë¡ ë¨¼ ë¶ë¶, ì¦ íì ìì(740)ê³¼ ì¸ì íë ë¶ë¶ì Sê·¹ì¼ë¡ ìíë ì ìë¤. ì´ì, íì ìì(740)ì ê·¸ Nê·¹ì´ ì¼ í´í¼ì¤(711)ì ì¸ì íê² ë°°ì¹ëê³ , ê·¸ Sê·¹ì´ í í´í¼ì¤(712)ì ì¸ì íê² ë°°ì¹ë ì ìë¤. ë°ë¼ì, ë 7aì ëìë ì ì ê³¼ ê°ì´, ê³ ì ìì(730), ì¼ í´í¼ì¤(711), íì ìì(740), í í´í¼ì¤(712)ë¥¼ íµí´, ìê¸° íë£¨íê° íì±ë ì ìë¤. First, referring to FIG. 7A , power may not be applied to the coil 720 . A portion of one pole piece 711 adjacent to the N pole of the stationary magnet 730 is magnetized to the S pole, and a portion of one pole piece 711 relatively far from the N pole of the stationary magnet 730, that is, a rotating magnet ( 740) may be magnetized to the N pole. On the other hand, the part adjacent to S of the stator magnet 730 of the other pole piece 712 is magnetized to N, and the part relatively far from the S

**[p0117]**

pole of the stator magnet 730 of the other pole piece 712, that is, the rotating magnet ( 740) may be magnetized to the S pole. Thus, the rotating magnet 740 may have its N pole disposed adjacent to one pole piece 711 and its S pole disposed adjacent to the other pole piece 712. Accordingly, a magnetic closed loop may be formed through the stator magnet 730, one pole piece 711, the rotating magnet 740, and the other pole piece 712, as indicated by the dotted line shown in FIG. 7A.

**[p0118]**

ë 7bë¥¼ ì°¸ì¡°íë©´, ì½ì¼(720)ì ì ë¥ê° íë¥´ëë¡ ì ì´í ì ìë¤. ì½ì¼(720)ì ì ë¥ê° íë¥´ë©´, ì¼ í´í¼ì¤(711) ì¤ ê³ ì ìì(730)ê³¼ ì¸ì í ë¶ë¶ìë Nê·¹ì´ íì±ëê³ , ì¼ í´í¼ì¤(711) ì¤ íì ìì(740)ê³¼ ì¸ì í ë¶ë¶ìë Sê·¹ì´ íì±ë ì ìë¤. ì´ì, íì ìì(740)ê³¼ ì¼ í´í¼ì¤(711) ì¬ì´ì ì²ë ¥ì´ ë°ìíë©°, íì ìì(740)ì´ íì í ì ìë¤. ì´ì, íì ìì(740)ì ê·¸ Sê·¹ì ë°°ì¹ê° í í´í¼ì¤(712)ì ì¸ì íê² ë°°ì¹ëê³ , ê·¸ Nê·¹ì ë°°ì¹ê° ì¼ í´í¼ì¤(711)ì ì¸ì íê² ë°°ì¹ë ì ìë¤. ì´ì, ì¼ ìì©ë©´(711a) ë° í ìì©ë©´(712a)ì¼ë¡ë¶í° ìê¸°ì íë¦ì´ ë°ì°ëê³ , ì¼ í´í¼ì¤(711) ë° í í´í¼ì¤(712)ì ëìì²´(70) ì¬ì´ì ìê¸° íë£¨íê° íì±ëë©°, ëìì²´(70)ê° ì¼ ìì©ë©´(711a) ë° í ìì©ë©´(712a)ì í¡ì°©ë ì ìë¤. ì´ë, ëìì²´(70)ì ê´íµí(71)ì ì½ì ëê¸°(751)ê° ì½ì ë ì ìë¤. ì´ì, ëìì²´(70)ì ì¢ì° ì´ëì´ ì íëë©°, í´ë¨í ì¥ì¹(700)ì í´ë¨íë ì ìë¤. Referring to FIG. 7B , current may be controlled to flow through the coil 720 . When current flows through the coil 720, an N pole is formed at a portion adjacent to the stator magnet 730 among one pole piece 711, and an S pole is formed at a portion adjacent to the rotating magnet 740 among one pole piece 711. can be formed Accordingly, a repulsive force is generated between the rotating magnet 740 and one pole piece 711, and the rotating magnet 740 may rotate. Accordingly, the S pole of the rotating magnet 740 m

**[p0118]**

ay be disposed adjacent to the other pole piece 712 and the N pole disposed adjacent to one pole piece 711 . Accordingly, magnetic flow is diverged from one acting surface 711a and the other acting surface 712a, and a magnetic closed loop is formed between one pole piece 711 and the other pole piece 712 and the object 70, The target object 70 may be adsorbed to one working surface 711a and the other working surface 712a. At this time, the insertion protrusion 751 may be inserted into the through hole 71 of the object 70 . Accordingly, left and right movement of the object 70 is restricted, and it may be clamped to the clamping device 700 .

**[p0119]**

ë 7cë¥¼ ì°¸ì¡°íë©´, ê³ ì ìì(730), ì¼ í´í¼ì¤(711), ëìì²´(70), ì½ì ëê¸°(751), í í´í¼ì¤(712)ë¥¼ íµí´, ë 7cì ëìë ì ì ê³¼ ê°ì´, íëì ìê¸° íë£¨íê° íì±ë ì ìë¤. ëí, íì ìì(740), ì¼ í´í¼ì¤(711), ëìì²´(70), ì½ì ëê¸°(751), í í´í¼ì¤(712)ë¥¼ íµí´, ë 7cì ëìë ì ì ê³¼ ê°ì´, ë¤ë¥¸ íëì ìê¸° íë£¨íê° íì±ë ì ìë¤. ì´ì, ìê¸° íë£¨íë¤ì´ íì±ëë©´ ì½ì¼(720)ì ì¸ê°ë ì ìì ì ê±°íì¬ë ìê¸° íë£¨íë¤ì´ ì ì§ëë¯ë¡, ì¼ ìì©ë©´(711a) ë° í ìì©ë©´(712a)ì ëìì²´(70)ì í¡ì°©ì ì ì§ìí¬ ì ìë¤.Referring to FIG. 7C, as shown in the dotted line shown in FIG. A magnetic closed loop may be formed. In addition, through the rotating magnet 740, one pole piece 711, the object 70, the insertion protrusion 751, and the other pole piece 712, as shown in the dotted line shown in FIG. can be formed. Therefore, when the magnetic closed loops are formed, even if the voltage applied to the coil 720 is removed, the magnetic closed loops are maintained, so that the object 70 can be attracted to one working surface 711a and the other working surface 712a. can

**[p0120]**

ë 7dë¥¼ ì°¸ì¡°íë©´, ì½ì¼(720)ì ì ë¥ê° íë¥´ëë¡ ì ì´í ì ìë¤. ì½ì¼(720)ì ì ë¥ê° íë¥´ë©´, ì¼ í´í¼ì¤(711) ì¤ ê³ ì ìì(730)ê³¼ ì¸ì í ë¶ë¶ìë Sê·¹ì´ íì±ëê³ , ì¼ í´í¼ì¤(711) ì¤ íì ìì(740)ê³¼ ì¸ì í ë¶ë¶ìë Nê·¹ì´ íì±ë ì ìë¤. ì´ì, íì ìì(740)ê³¼ ì¼ í´í¼ì¤(711) ì¬ì´ì ì²ë ¥ì´ ë°ìíë©°, íì ìì(740)ì´ íì ë ì ìë¤. ì´ì, íì ìì(740)ì ê·¸ Nê·¹ì ë°°ì¹ê° í í´í¼ì¤(712)ì ì¸ì íê² ë°°ì¹ëê³ , ê·¸ Sê·¹ì ë°°ì¹ê° ì¼ í´í¼ì¤(711)ì ì¸ì íê² ë°°ì¹ë ì ìë¤. ì´ì, ì¼ ìì©ë©´(711a) ë° í ìì©ë©´(712a)ì¼ë¡ë¶í° ìê¸°ì íë¦ì´ ë°ì°ëë ê²ì´ ì¤ë¨ëê³ , ì¼ í´í¼ì¤(711) ë° í í´í¼ì¤(712)ì ëìì²´(70) ì¬ì´ì ìê¸° íë£¨íê° í´ì ë ì ìë¤. ìê¸° íë£¨íê° í´ì ëë©´, ëìì²´(70)ë ì½ì ëê¸°(751)ë¡ë¶í° ì´íëì´ ë¶ë¦¬ë ì ìë¤.Referring to FIG. 7D , current may be controlled to flow through the coil 720 . When current flows through the coil 720, an S pole is formed at a portion adjacent to the stator magnet 730 among one pole piece 711, and a N pole is formed at a portion adjacent to the rotating magnet 740 among one pole piece 711. can be formed Thus, a repulsive force is generated between the rotating magnet 740 and one pole piece 711, and the rotating magnet 740 can be rotated. Accordingly, the N pole of the rotating magnet 740 may be disposed adjacent to the other pole piece 712 and the S pole may be disposed adjacent to one pole piece 711 . Accordingly, the diverge

**[p0120]**

nce of magnetic flow from one acting surface 711a and the other acting surface 712a is stopped, and a magnetic closed loop between one pole piece 711 and the other pole piece 712 and the object 70 is formed. can be released When the magnetic closed loop is released, the object 70 may be separated from the insertion protrusion 751 .

**[p0121]**

ì´ì²ë¼, ìì©ë©´ì ëìì²´ë¥¼ ì ì´ìì¼ ì§ì§íì§ ìê³ , í´ë¨íë¥¼ ì´ì©íì¬ ë¶ì°© ëìì²´ë¥¼ ì§ì§íë¯ë¡ ë¶ì°© ëìì²´ë¥¼ ë ê²¬ê³ íê² ì§ì§í ì ìë¤. ëí, í´ë¨í ì¥ì¹ë¥¼ ì¤ì¹íëë° ìì´ ì¤ì¹ ê³µê°ì í¬ê¸°ì ì ì½ì ë°ì§ ìì¼ë¯ë¡ ê³µê° íì©ì±ì í¥ììí¬ ì ìë¤. ëí, ì ì ì ë ¥ì¼ë¡ íì  ììì íì ìì¼ ìì±ì²´ë¥¼ ìì ì ì¼ë¡ íë©í ì ìì¼ë¯ë¡, ìê¸°ë ¥ ì ì´ ì¥ì¹ì ê°ë í¨ì¨ì±ì í¥ììí¬ ì ìë¤.As such, since the target object is supported using a clamp instead of contacting the target object to the action surface, the target object to be attached can be supported more firmly. In addition, since the size of the installation space is not restricted in installing the clamping device, space utilization can be improved. In addition, since the magnetic material can be stably held by rotating the rotating magnet with little power, the operating efficiency of the magnetic force control device can be improved.

**[p0122]**

ì´ì ì²¨ë¶ë ëë©´ì ì°¸ì¡°íì¬ ë³¸ ë°ëª ì ì¤ììë¤ì ëì± ìì¸íê² ì¤ëª íìì¼ë, ë³¸ ë°ëª ì ë°ëì ì´ë¬í ì¤ììë¡ êµ­íëë ê²ì ìëê³ , ë³¸ ë°ëª ì ê¸°ì ì¬ìì ë²ì´ëì§ ìë ë²ì ë´ìì ë¤ìíê² ë³í ì¤ìë ì ìë¤. ë°ë¼ì, ë³¸ ë°ëª ì ê°ìë ì¤ììë¤ì ë³¸ ë°ëª ì ê¸°ì ì¬ìì ì ííê¸° ìí ê²ì´ ìëë¼ ì¤ëª íê¸° ìí ê²ì´ê³ , ì´ë¬í ì¤ììì ìíì¬ ë³¸ ë°ëª ì ê¸°ì ì¬ìì ë²ìê° ì íëë ê²ì ìëë¤. ê·¸ë¬ë¯ë¡, ì´ììì ê¸°ì í ì¤ììë¤ì ëª¨ë ë©´ìì ììì ì¸ ê²ì´ë©° ì íì ì´ ìë ê²ì¼ë¡ ì´í´í´ì¼ë§ íë¤. ë³¸ ë°ëª ì ë³´í¸ ë²ìë ìëì ì²­êµ¬ë²ìì ìíì¬ í´ìëì´ì¼ íë©°, ê·¸ì ëë±í ë²ì ë´ì ìë ëª¨ë ê¸°ì ì¬ìì ë³¸ ë°ëª ì ê¶ë¦¬ë²ìì í¬í¨ëë ê²ì¼ë¡ í´ìëì´ì¼ í ê²ì´ë¤.Although the embodiments of the present invention have been described in more detail with reference to the accompanying drawings, the present invention is not necessarily limited to these embodiments, and may be variously modified and implemented without departing from the technical spirit of the present invention. . Therefore, the embodiments disclosed in the present invention are not intended to limit the technical idea of the present invention, but to explain, and the scope of the technical idea of the present invention is not limited by these embodiments. Therefore, it should be understood that the embodiments described above are illustrative in all respects a

**[p0122]**

nd not restrictive. The protection scope of the present invention should be construed according to the claims below, and all technical ideas within the equivalent range should be construed as being included in the scope of the present invention.

**[p0123]**

100, 200, 300, 400, 500, 600, 700: í´ë¨í ì¥ì¹ 110, 210, 310, 410, 510, 610: ì§ì§ë 120, 220, 320, 420: ì 1 í´í¼ì¤ ì´ì ë¸ë¦¬ 130, 230, 330, 430: ì 2 í´í¼ì¤ ì´ì ë¸ë¦¬ 140, 240, 340, 440, 540, 640: í´ë¨í100, 200, 300, 400, 500, 600, 700: clamping device 110, 210, 310, 410, 510, 610: support 120, 220, 320, 420: first pole piece assembly 130, 230, 330, 430: second pole piece assembly 140, 240, 340, 440, 540, 640: clamp

## Classifications

- H01F7/0252
- H01F7/0252
- B23Q3/154
- B23Q3/1546
- B23Q3/1546
- B66C1/04
- B66C1/04
- B66C1/04
- H01F7/02
- H01F7/04
- H01F7/04
- H01F7/04

## Cited patent documents

- [KR-20110044681-A](https://patents.google.com/patent/KR20110044681A/en) — APP

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
