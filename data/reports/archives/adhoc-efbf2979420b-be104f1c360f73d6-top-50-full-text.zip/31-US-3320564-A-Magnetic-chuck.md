# 31. Magnetic chuck

- **Archive rank:** 31 of 50
- **Publication:** [US-3320564-A](https://patents.google.com/patent/US3320564A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/023760940/publication/US3320564A?q=pn%3DUS3320564A)
- **Publication date:** 1967-05-16
- **Filing date:** 1965-03-29
- **Earliest priority:** 1965-03-29
- **Family:** 23760940
- **Text status:** source text incomplete — use the office links above
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** ERIEZ MFG CO

## Abstract

_No abstract was available from the queried sources._

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/98/54/45/1c996e533250b9/US3320564-drawings-page-1.png)

![Sketch 1 for US-3320564-A](https://patentimages.storage.googleapis.com/98/54/45/1c996e533250b9/US3320564-drawings-page-1.png)

[Sketch 2](https://patentimages.storage.googleapis.com/2a/a3/57/1c8b216b02e6be/US3320564-drawings-page-2.png)

![Sketch 2 for US-3320564-A](https://patentimages.storage.googleapis.com/2a/a3/57/1c8b216b02e6be/US3320564-drawings-page-2.png)

## Claims

_Claims were not available from the queried sources._

## Full description

PERFORMING OPERATIONS; TRANSPORTINGMACHINE TOOLS; METAL-WORKING NOT OTHERWISE PROVIDED FORDETAILS, COMPONENTS, OR ACCESSORIES FOR MACHINE TOOLS, e.g. ARRANGEMENTS FOR COPYING OR CONTROLLING; MACHINE TOOLS IN GENERAL CHARACTERISED BY THE CONSTRUCTION OF PARTICULAR DETAILS OR COMPONENTS; COMBINATIONS OR ASSOCIATIONS OF METAL-WORKING MACHINES, NOT DIRECTED TO A PARTICULAR RESULTDevices holding, supporting, or positioning work or tools, of a kind normally removable from the machineDevices for holding work using magnetic or electric force acting directly on the workStationary devicesStationary devices using permanent magnetsPERFORMING OPERATIONS; TRANSPORTINGGRINDING; POLISHINGMACHINES, DEVICES, OR PROCESSES FOR GRINDING OR POLISHING; DRESSING OR CONDITIONING OF ABRADING SURFACES; FEEDING OF GRINDING, POLISHING, OR LAPPING AGENTSComponent parts such as frames, beds, carriages, headstocksWork supports, e.g. adjustable steadiesWork supports, e.g. adjustable steadies axially supporting turning workpieces, e.g. magnetically, pneumatically

Description

May 16, 1%"? w. F. sosEY ETAL MAGNETIC CHUCK 2 Sheets-Sheet 1 Filed March 29, 1965 INVENTORS WILLIAM F. SOSEY BY EMERSON J. TENPAS May 16, 1967 w; F. SOSEY ETAL 3,320,564

MAGNETIC CHUCK Filed March 29, 1965 2 Sheets-Sheet 2 w 'lllli H INVENTORS WILLIAM F. SOSEY BY EMERSON J.TENPAS woz zhw United States Patent 3,320,564 MAGNETIQ CHUCK William F. Sosey and Emerson J. Tenpas, Erie, Pa., assignors to Eriez Manufacturing Co., Erie, Pa., a corporation of Pennsylvania Filed Mar. 29, 1965, Ser. No. 443,476 1 Claim. (Cl. 335-285) This invention relates to magnetic chucks and, more particularly, to an improved magnetic chuck in combination with a removing means for removing parts therefrom.

To facilitate holding fragile steel rings or discs during cleaning, grinding, finishing, and bufiing operation, a permanent magnet holding device has been developed and proved in actual operation.

This permanent magnetic holding device enables a machine operator to hold the part to be machined by the magnetic action of the chuck. The part can be held without slipping either vertically, horizontally, or above or below the holding magnet. An improved feature of the chuck makes it possible to remove a part from the chuck without damaging or distorting the part. With the structure disclosed, the part is forceably and completely removed from the magnetic circuit, whereas in other prior chucks where magnets are merely turned off, the part would tend to remain or dangle on the base of the magnet because the induced current would continue to hold the part to a certain extent until the contact was broken by some physical means. of a magnetic field can be demonstrated by dangling two paper clips, one above the other, from a magnet. Remove the magnet slowly and carefully, and it will be found that the lower clip will still be held in place to the upper until the lower clip is removed by physical force.

It is, accordingly, an object of the invention to provide an unusually strong ring type magnet with a flat surface which can be used to contact and control a flat ring of steel or the like.

Another object of the invention is to provide a ring magnet with a multiple circular field which permits additional holding forces.

Still another object of the invention is to provide a magnet that will facilitate removal of work from the magnet, such as steel rings, by means of a stripping ring.

A further object of the invention is to provide an assembly, including a ring magnet and a stripper, using a pusher screw which will push uniformly against the steel ring until the ring is beyond the limits of the magnetic field.

It is another object of the invention to provide a locating pin in a magnetic chuck which aligns and locates the steel parts for proper positioning.

With the above and other objects in view, the present invention consists of the combination and arrangement of parts hereinafter more fully described, illustrated in the accompanying drawing and more particularly pointed out in the appended claim, it being understood that changes may be made in the form, size, proportions, and minor details of construction Without departing from the spirit or sacrificing any of the advantages of the invention.

In the drawings:

FIG. 1 is a bottom view of a magnetic chuck according to the invention;

FIG. 2 is a cross sectional view taken on line 2-2 of FIG. 1;

FIG. 3 is a bottom view similar to FIG. 1 of another embodiment of the invention; and

This action' FIG. 4 is a cross sectional view taken on line 4-4 of FIG. 3.

Now with more particular reference to the drawings, in FIGS. 1 and 2 a magnetic chuck 12 is shown. The chuck has a relatively annular shaped member, which may be considered to be generally cylindrical in shape. The cylindrical portion 19 of the annular member has an annular groove 20 in it, which may be countergrooved at 21. The generally cylindrical chuck housing is made of magnetic material. The annular groove 20 receives the magnetic pressings 11, which may be made of ceramic permanent magnetic material of a well known kind, and they may have dimensions of, for example, 1 X /2 x 1 7 inches. These magnetic pressings are distributed around the chuck and polarized as shown, and the pole ring 14 which is made of magnetic material is supported over the top of these magnetic pressings to hold them in place.

The epoxy resin 22 and 23 is poured into the space around each side of the magnetic pressings between the magnetic pressings and the grooves, and this holds the magnetic pressings in place. The ring 14 is held in place by means of the fiat head screws 17 some of which are threaded into the epoxy resin between magnetic pressings 11, as well as into some of the magnetic pressings and the retainer rods 13 are screwed into the device as shown. The retainer ring 18 is fitted into a counterbore in the housing, and retainer ring 18 may provide a locating barrier for supporting a part therein.

Now with reference to the embodiment of the invention shown in FIGS. 3 and 4, a housing having a body 112 having a generally annular shaped groove therein is shown. The groove 120 is counter-grooved at 121 and the magnetic pressings 111 are fitted thereinto similar to that in the embodiment shown in FIG. 1. The pole ring 114 is made of magnetic material, such as steel, and is in the form of a part of a plate. The pole ring 114 is supported on top of the magnetic pressings by means of the flat headed screws 119, and the pole ring 114 and magnetic pressings are held in place by means of screws 116 that overlie drive pin retainer rods 113.

The body has the collar threadably received thereon. This collar may be unthreaded by inserting a suitable tool in the spaced holes 132 around the outer periphery. As the collar is unthreaded, it will move the work piece attached, so that the face will move in plane parallel to the plane of face 151 on the chuck, and the collar 130 will force the work piece out of engagement with the magnetic holding surface.

The lock plate bars 118 are in the form of spaced lugs locked to the body of the housing by set screws 117. It will be noted that the ring like chuck is generally cylindrical in shape and that a very powerful annular magnetic field results at the face of the chuck. This magnetic field will force a part from the chuck by a force applied uniformly around the chuck.

The foregoing specification sets forth the invention in its prefered practical forms but the structure shown is capable of modification within a range of equivalents without departing from the invention which is to be understood is broadly novel as is commensurate with the appended claim.

The embodiments of the invention in which an exclusive property or privilege is claimed are defined as follows:

A magnetic chuck comprising a generally cylindrical housing made of magnetic material having a hollow central part, a part of the outside of said housing being threaded about its outer periphery,

a collar threadably supported on said housing generally concentric tosaid housing and having a face parallel to one face of said cylindrical housing,

said threads comprising means to move said collar with its face flush with the end of said housing and to move said collar past the end of said housing to force articles attracted to said magnetic chuck away from said chuck with a substantially equally distributed force,

a groove in said cylindrical housing extending into an end thereof and concentric to said hollow central part, a

permanent magnet material in said groove with one end of said permanent magnet material adjacent said magnetic material at the bottom of said groove,

non-magnetic material in said groove on each side of said permanent magnet material holding said permanent magnet material in spaced relation to the edges defining said groove.

References Cited by the Examiner BERNARD A. GILI-IEANY, Primary Examiner.

G. HARRIS, Assistant Examiner.

## Classifications

- B23Q3/1546
- B23Q3/1546
- B24B41/061
- B24B41/061

## Cited patent documents

- [US-2179625-A](https://patents.google.com/patent/US2179625A/en) — SEA
- [US-2953970-A](https://patents.google.com/patent/US2953970A/en) — SEA
- [US-2954257-A](https://patents.google.com/patent/US2954257A/en) — SEA
- [US-3142006-A](https://patents.google.com/patent/US3142006A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
