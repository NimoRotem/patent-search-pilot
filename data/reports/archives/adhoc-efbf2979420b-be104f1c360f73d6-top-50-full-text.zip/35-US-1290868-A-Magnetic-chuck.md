# 35. Magnetic chuck.

- **Archive rank:** 35 of 50
- **Publication:** [US-1290868-A](https://patents.google.com/patent/US1290868A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/003358427/publication/US1290868A?q=pn%3DUS1290868A)
- **Publication date:** 1919-01-14
- **Filing date:** 1916-06-15
- **Earliest priority:** 1916-06-15
- **Family:** 3358427
- **Text status:** source text incomplete — use the office links above
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** PERSONS ARTER MACHINE COMPANY

## Abstract

_No abstract was available from the queried sources._

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/15/f5/34/f9db112fdcbfa3/US1290868-drawings-page-1.png)

![Sketch 1 for US-1290868-A](https://patentimages.storage.googleapis.com/15/f5/34/f9db112fdcbfa3/US1290868-drawings-page-1.png)

[Sketch 2](https://patentimages.storage.googleapis.com/55/7c/15/4e38ed67ed99ce/US1290868-drawings-page-2.png)

![Sketch 2 for US-1290868-A](https://patentimages.storage.googleapis.com/55/7c/15/4e38ed67ed99ce/US1290868-drawings-page-2.png)

[Sketch 3](https://patentimages.storage.googleapis.com/39/5c/72/8c7f6f5e7ad6f1/US1290868-drawings-page-3.png)

![Sketch 3 for US-1290868-A](https://patentimages.storage.googleapis.com/39/5c/72/8c7f6f5e7ad6f1/US1290868-drawings-page-3.png)

## Claims

_Claims were not available from the queried sources._

## Full description

PERFORMING OPERATIONS; TRANSPORTINGMACHINE TOOLS; METAL-WORKING NOT OTHERWISE PROVIDED FORDETAILS, COMPONENTS, OR ACCESSORIES FOR MACHINE TOOLS, e.g. ARRANGEMENTS FOR COPYING OR CONTROLLING; MACHINE TOOLS IN GENERAL CHARACTERISED BY THE CONSTRUCTION OF PARTICULAR DETAILS OR COMPONENTS; COMBINATIONS OR ASSOCIATIONS OF METAL-WORKING MACHINES, NOT DIRECTED TO A PARTICULAR RESULTDevices holding, supporting, or positioning work or tools, of a kind normally removable from the machineDevices for holding work using magnetic or electric force acting directly on the workStationary devicesStationary devices using electromagnetsPERFORMING OPERATIONS; TRANSPORTINGMACHINE TOOLS; METAL-WORKING NOT OTHERWISE PROVIDED FORDETAILS, COMPONENTS, OR ACCESSORIES FOR MACHINE TOOLS, e.g. ARRANGEMENTS FOR COPYING OR CONTROLLING; MACHINE TOOLS IN GENERAL CHARACTERISED BY THE CONSTRUCTION OF PARTICULAR DETAILS OR COMPONENTS; COMBINATIONS OR ASSOCIATIONS OF METAL-WORKING MACHINES, NOT DIRECTED TO A PARTICULAR RESULTDevices holding, supporting, or positioning work or tools, of a kind normally removable from the machineDevices for holding work using magnetic or electric force acting directly on the workRotary devices

Description

W. ARTER.

MAGNETIC CHUCK.

APPLICATION FILED JUNE 15. 1916.

Patented Jan. 14,1919.

3 SHEETS-SHEET 1.

Wvmvrma @Mflmg fir? Tia M W. ARTER.

MAGNETIC CHUCK.

APPLICATION FILED JUNE 15. 1916.

Patented Jan. 14,1919.

3 SHEETS-SHEET 2.

Fig. 3.

W. ARTER.

MAGNETIC CHUCK. APPLICATION ElLED JUNE 15. 916.

1,290,868. Patented Jan. 14, 1919.

UNITED STATES PATENT OFFICE.

WILLIAM ARTER, 0F WORCESTER, MASSACHUSETTS, ASSIGNOR TO THE PERSONS-ARTER MACHINE COMPANY, OF WORCESTER, MASSACHUSETTS, A CORPORATION OF MASSA- CHUSETTS.

MAGNETIC CHUCK.

Specification of Letters Patent.

Patented Jan. 14, 1919.

Application filed June 15. 1916. Serial N 0. 103.896.

To all whom it may concern:

Be it known that I, WILLIAM ARTER, a subject of the King of Great Britain, residing at 540 Salisbury street, Worcester, in the county of Worcester and State of Massachusetts, have invented certain Improvements in Magnetic Chucks, of which the following description, in connection with the accompanying drawings, is a specific-ation, like reference characters on the drawquire relatively few stock parts for different sizes of chucks, which shall be efficient, and will hold small pieces of work securely on its face.

A convenient embodiment of the invention will now be described, reference being made to the accompanying drawings, in which Figure 1 is a plan view of a magnetic chuck embodying this invention;

Fig. 2 is a vertical, sectional view taken substantially on the line 2-2 of Fig. 1, the

across the face of the chuck and are magnetizing coil at the right of the figure,

and the chuck foot at the left of the figure I being shown in planes lying in front of that on which the greater part of the section is taken;

Fig. 3 is a construction Fig. 4 is an end view of one of the central core and pole members, Fig. 5 is a side view of the member shown in Fig. 4, and

Fig. 6 is a horizontal cross sectional view taken substantially on the line 6 6, Fig. 2. The chuck shown in the drawings includes a frame 2 of substantially rectangular shape having an upper work supporting face through which a series of long narrow slots are formed. These slots extend transversely Se po io plan view of a modified chuck arated by narrow bars 4 that form pieces for the chuck. Inclosed' within the frame 2 are two cylindrical core members 6,

which are exact duplicates of each other. Each of these core members has a horizontal rectangular plate-like extension 7 formed on its upper end, and a series of pole pieces or tips 8 extend upwardly from each part 7 and are positioned in the slots formed between the bars 4 of the frame. The two sets of pole pieces 4 and 8 are magnetically separated from each other by thin strips 10 of non-magnetic material of some kind such, for instance, as copper, brass or, more preferably, some of the non-magnetic alloys such as those known as white metal alloys.

This material is run into a molten condition,

while the chuck is supported in an inverted position, and after it has hardened the upper work supporting face of the chuck is machined. Certain of these alloys expand upon cooling and, therefore, are particularly adapted for use in a chuck of this character.

Both the core members 6 and the frame 2 are securely bolted to a baseplate 12. These parts 2, 6 and 12 are, of course, made of material suitable for this purpose as, for instance, soft iron. Two circular magnetizing coils 14 encircle the respective core members 6 and lie between the baseplate 12 and the parts 7. The baseplate 12 isgrooved as indicated at 16 to receive the leads 18 for the magnetizing coils 14 and a bushing 19 in the wall of the frame 2 insulates these leads from the chuck. I

It will .be evident that the construction above described provides a chuck in which the work supporting face is broken up into a great number of relatively small sections having opposite polarities so that a very small piece of metal will bridge so much of the magnetic gap that it will be held very securely on the face of the chuck. Furthermore, it should be noted that it is necessary merely to duplicate the central core piece and the magnetizing coil, and to provide a frame of the proper dimensions to make a chuck of any required length. While the frame piece also could be made to be duplicated, it usually is preferable to make this frame in one piece, since great stiffness and rigidity is required in a chuck of this kind,

and this properly is obtained more easily and with greater certainty by using an integral frame piece. The cores and magnetizmg coils, however, are standard for all lengths of chuck. The frame and core parts arerso designed that they can be cast easily, the magnetizing coil being of circular form can be economically manufactured and the entire chuck requires but very little machine 5 work. The central-core member 6, it will be noted, has its pole tips or projections 8 so arranged that they form, in outline, substantially a rectangle.

The chucks of this kind are much used 10 in machine tools such, for instance, as grinding and milling machines which are so organized that they furnish an alternative path for the magnetic fliix. This not only tends to reduce the efficiency of the chuck but also is a source of annoyance since the metal chips and filings which are removed from the work tend to adhere to the tool or adjacent parts of the machine. in order to overcome this objection li prefer to magnetically insulate the chuck from the support on which it rests; and for this purpose ll provide the chuck with non-magnetic feet 20, as best shown in Fig. 2.. These feet may be made of copper, brass, fiber or any suit- 2 able non-magnetic material and the live parts of the chuck so far away from the support on which the chuck rests that the alternative path ordinarilyprovided by the machine has'a reluctance so great that it is negligible. These feet are also of advantage in raising the chuck 05 its support and forming the free flow under it of the cutting compounds sometimes used in grinding. l'f clamps are used to secure the chuck to the support, pieces 22 of non-magnetic material, similar to that from which the feet 20 are made, may be placed between the clamps and the parts would be engaged by the clamps and per- 40 form the same functions as'the feet 20.

The chuck also may be provided with the usual lining strips24, 26and 28, which are sometimesused on devices of thischaracter .to aid the workman in properly placing the work on the faceof the chuck. The chuck shown also has a T-shaped slot 30 to receive a suitable shaped clamping, bolt which also may be used to hold a work locating member .or'to clamp non-magnetic material on the chuck whenever desired.

The construction shown in Fig. 3 comprises an outer annular chuck member and a central chuck member of a difierent form,

'the latter-member being constructedin accordance withiny pending application, Ser.

No. 48,018, filed August 30, 1915, and the former member being constructed on the same general principles the chuck shown in Figs-land 2. Two pole pieces 32 and 34: 60 of the central chuck member are so shaped 1 that theybreak up the work supporting face F of this chuck into very small sections, and the chuck 'thus will hold securely a very smallpiece of work. The outer chuck mem 3.5- ber comprises an annular frame. 2 made in construction. This arrangement permits the they hold "its upper end projecting beyond the periof the chuck that otherwise 'netizing coil encircling said core member.

the same way that the frame 2 of-the chuck in Fig. 1 ismade except for the change in the shape. The core pieces 6'. are like the core pieces 6 of the chuck shown in Fig. 1, except that the pole tips 8 instead of extending arallel with each other extend radially o? the frame piece 2, the slots in which these pieces are positioned, of course, extending radially also. In the construction shown each core piece 6 carries 4: pole extensions or'tips 8. The magnetizing coil 14: is like that used inthe construction first described, and the chuck is also provided with a basepla-te underlying the entire chuck use of a stock chuck of a small size for the center of a large chuck, and thus provides a construction that not only is economical to manufacture but is very efficient. Having thus described my'invention What I claim as new and desire to secure by Let ters Patent of the United States is:

' 1. A. magnetic chuck, comprising a frame having a work supporting surface provided with a series of narrow slots extending across it transversely and separated-by bars forming pole pieces, a plurality of cores positioned side by side in said frame, each of said cores having a plate-like extension at phery of the core, a series of narrow pole pieces projecting upwardly from said extension and positioned in said slots, a magnetizing coil encircling each of said cores, non

magnetic material separating the pole pieces 10( of said cores from said bars, and a b-a'seplate to which said cores and frame are secured.

2. A magnetic chuck, comprising a core member having a platelike extension at its upper end and a series of long narrow polo pieces projecting. upwardly side by side from said extension, a frame in which said core memberis'positioned, said frame having a plurality of slots extending across its work supporting face and separated from each other by narrow bars, said pole pieces being located in said slots, non-magnetic material separating said pole pieces from the ad acent parts of the said frame, and a mag- 3. A magnetic chuck, comprising an annular frame having ai-work'supporting face provided with a series of narrow slots extending radially across it and separated by bars forming pole pieces, a plurality of cores positioned in said frame, each of said cores aving .a series of narrow pole pieces projecting upwardly therefrom and positioned in said slots, a magnetizing coil encircling each of. said cores, non magnetic material 12 separating the pole pieces of said cores from said bars, and. a 'basepla-te' magnetically connecting said cores and the frame together.

QA magnetic chuck, comprising an annular frame having a work supporting face 1% provided with a series of narrow slots extending radially across it and separated by bars forming pole pieces, a plurality of cores positioned in said frame, each of said cores having a series of narrow pole pieces pro jecting upwardly therefrom and positioned in said slots, a magnetizing coil encircling each of said cores, non-magnetic material separating the pole pieces of said cores from said bars, and a circular chuck member located centrally in said frame and having two pole pieces shaped to break up the surface of said member into relatively small sections, and a baseplate for said chuck.

5. A device of the character described, comprising a plurality of magnetic chucks arranged concentrically with reference to each other, each having pole pieces, magnetic circuits, and magnetizing means independent of the other, and a common base for said plurality of chucks.

6. A magnetic chuck comprising a core 7 member of substantially circular cross sec- Corrections in Letters Patent No. 1,290,868..

tion, having a plate-like extension at its upper end projecting at all sides beyond the periphery of the core, and having a series of long narrow pole pieces rising from said plate and lying sideby side, a frame in which said core member is positioned, said frame having a plurality of slots extending across its Work supporting face and separated from each other by narrow bars, said pole pieces being located in said slots, nonmagnetic material separating said pole pieces from said bars and a magnetizing coil encircling said core member.

' 7. A magnetic chuck comprising a core member of substantially circular horizontal cross section, sald member having a substantially rectangular platelike extension at its [sun] upper end projecting at all sides beyond the periphery of said core, a series of long narrow pole pieces projecting upwardly side by side from said extension and extending substantially from one side to the other of said extension, a frame in Which said core member is positioned, said frame having a plurality of slots extending across its work supporting face and separated from each other y narrow bars, said pole pieces being located in said slots, a magnetizing coil encircling said core member and lying under said platelike extension, non-magnetic material separating said pole pieces from the adjacent parts of said frame, and a base to which said core and frame are secured.

8. A magnetic chuck comprising an outer frame, an inner core member, two sets of pole pieces of opposite polarities formed respectively on said frame and core member and forming the Work supporting face of the chuck, non-magnetic material separating said sets of pole pieces, a magnetizing coil encircling said core member, a base to Which said core and frame are'secured, and feet on said base to support it.

9. A magnetic chuck comprising an outer frame, an inner core member, two sets of pole pieces,of opposite polarities formed respectively on said frame and core member and forming the work supporting face of the chuck, non-magnetic material separating said sets of pole pieces, a magnetizing coil encircling said core member, a base to which said core and frame are secured, and feet set into said base and removably secured thereto.

In testimony whereof I have signed my name to this specification.

WILLIAM ARTER.

It is hereby certified that in Letters Patent No.- 1,290, 868, granted January 14, 1919, upon the application of William Arter, of' Worcester, Massachusetts, for an improvement. in "Magnetic Chucks, errors appear in the printed specification requiring correction as follows: Page 1, line 70, after the word into insert the words place in; same page, line 106, for the word properly read property; and that the said Letters Patent should be read with these corrections therein that the same may conform to the record of the case in the Patent Ofiice.

Signed and sealed-this25th day of March, A. 1)., 1919.

R. F. WHITEHEAD,

Acting Gommissioner of Patents.

## Classifications

- B23Q3/152
- B23Q3/1543
- B23Q3/1543
- B23Q3/152

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
