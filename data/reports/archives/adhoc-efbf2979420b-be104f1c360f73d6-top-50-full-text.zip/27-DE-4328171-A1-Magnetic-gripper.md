# 27. Magnetic gripper

- **Archive rank:** 27 of 50
- **Publication:** [DE-4328171-A1](https://patents.google.com/patent/DE4328171A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/006495718/publication/DE4328171A1?q=pn%3DDE4328171A1)
- **Publication date:** 1995-02-23
- **Filing date:** 1993-08-21
- **Earliest priority:** 1993-08-21
- **Family:** 6495718
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** KRUPP AG HOESCH KRUPP
- **Inventors:** KIENEMUND ALBRECHT PAUL DIPL P

## Abstract

The invention relates to a magnetic gripper for manual and automatic handling of objects, in particular of toroidal tape cores. The various designs of known magnetic grippers have a series of disadvantages, for example with respect to the individualisation of the objects, the geometrical delimitation of the magnetic force effect, the control with time of the magnetic effect and the like. Permanent magnets (15, 16) are therefore arranged between two soft iron pole shoes (10, 11), which are separated by an air gap (12), in such a manner that by moving at least one of the permanent magnets (16) a magnetic field compensation or the excitation of a magnetic field in the pole shoes (10, 11) can be switched alternately. &lt;IMAGE&gt;

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-4328171-A1/ops000.png)

![Sketch 1 for DE-4328171-A1](https://nimo.iptorch.com/refdrawing/DE-4328171-A1/ops000.png)

## Claims

### Claim 1 (independent)

Claims (8)

### Claim 2 (independent)

Translated from German Magnetgreifer fÃ¼r manuelles und automatisches Handhaben von

### Claim 4 (independent)

Objekten insbesondere von Ringbandkernen, dadurch

### Claim 5 (independent)

gekennzeichnet, daÃ zwischen zwei durch einen Luftspalt (12)

### Claim 6 (independent)

getrennten Polschuhen (10, 11) Permanentmagnete (15, 16)

### Claim 7 (independent)

derart angeordnet sind, daÃ durch Bewegung mindestens eines

### Claim 8 (independent)

der Permanentmagnete (16) eine Magnetfeldkompensation oder die

### Claim 9 (independent)

Erregung eines Magnetfeldes in den Polschuhen (10, 11)

### Claim 10

alternativ einstellbar ist.1. Magnetic gripper for manual and automatic handling of objects, in particular toroidal cores, characterized in that permanent magnets ( 15 , 16 ) are arranged between two pole shoes ( 10 , 11 ) separated by an air gap ( 12 ) such that at least one of the permanent magnets is moved ( 16 ) magnetic field compensation or the excitation of a magnetic field in the pole pieces ( 10 , 11 ) is alternatively adjustable. Magnetgreifer nach Anspruch 1, gekennzeichnet durch zwei

### Claim 12 (independent)

Permanentmagnete (15, 16), von denen einer (16) drehbar

### Claim 13

gelagert ist.2. Magnetic gripper according to claim 1, characterized by two permanent magnets ( 15 , 16 ), one of which (16) is rotatably mounted. Magnetgreifer nach Anspruch 2, dadurch gekennzeichnet, daÃ die

### Claim 15 (independent)

beiden Permanentmagnete (15, 16) aneinanderliegend und durch

### Claim 16

einen Luftspalt (18) getrennt angeordnet sind.3. Magnetic gripper according to claim 2, characterized in that the two permanent magnets ( 15 , 16 ) are arranged adjacent to one another and separated by an air gap ( 18 ). Magnetgreifer nach Anspruch 2 oder 3, dadurch gekennzeichnet,

### Claim 18 (independent)

daÃ die Permanentmagnete (15, 16) so groÃ sind und eine solche

### Claim 19 (independent)

Magnetisierung (19, 20) aufweisen, daÃ eine Kompensation des

### Claim 20

magnetischen Gesamtfeldes mÃ¶glich ist.4. Magnetic gripper according to claim 2 or 3, characterized in that the permanent magnets ( 15 , 16 ) are so large and have such a magnetization ( 19 , 20 ) that compensation of the overall magnetic field is possible. Magnetgreifer nach einem der AnsprÃ¼che 2 bis 4, dadurch

### Claim 22 (independent)

gekennzeichnet, daÃ der drehbar gelagerte Permanentmagnet (16)

### Claim 23 (independent)

mit einer Drehvorrichtung, beispielsweise einem Motor (17)

### Claim 24

gekoppelt ist.5. Magnetic gripper according to one of claims 2 to 4, characterized in that the rotatably mounted permanent magnet ( 16 ) is coupled to a rotating device, for example a motor ( 17 ). Magnetgreifer nach einem der AnsprÃ¼che 1 bis 5, dadurch

### Claim 26 (independent)

gekennzeichnet, daÃ die Polschuhe (10, 11) jeweils an ihrer

### Claim 27 (independent)

den Dauermagneten (15, 16) abgewandten Seite der Geometrie des

### Claim 28 (independent)

zu greifenden Objektes angepaÃt, beispielsweise konisch

### Claim 29

verjÃ¼ngt ausgebildet sind.6. Magnetic gripper according to one of claims 1 to 5, characterized in that the pole shoes ( 10 , 11 ) are each adapted on their side facing away from the permanent magnet ( 15 , 16 ) to the geometry of the object to be gripped, for example are conically tapered. Magnetgreifer nach einem der AnsprÃ¼che 1 bis 6, dadurch

### Claim 31 (independent)

gekennzeichnet, daÃ die Polschuhe (10, 11) an ihrem weiteren

### Claim 32 (independent)

Ende jeweils eine Ausnehmung aufweisen, in der die

### Claim 33

Permanentmagnete (15, 16) gelagert sind.7. Magnetic gripper according to one of claims 1 to 6, characterized in that the pole shoes ( 10 , 11 ) each have a recess at their further end, in which the permanent magnets ( 15 , 16 ) are mounted. Magnetgreifer nach einem der AnsprÃ¼che 1 bis 7, dadurch

### Claim 35 (independent)

gekennzeichnet, daÃ der untere der Permanentmagnete (15)

### Claim 36 (independent)

gegenÃ¼ber der AuflageflÃ¤che der Polschuhe (10, 11) magnetisch

### Claim 37 (independent)

isoliert ist, vorzugsweise durch eine zwischengelegte

### Claim 38

Messingplatte (14).8. Magnetic gripper according to one of claims 1 to 7, characterized in that the lower of the permanent magnets ( 15 ) is magnetically isolated from the bearing surface of the pole shoes ( 10 , 11 ), preferably by an interposed brass plate ( 14 ).

## Full description

**[p0001]**

ELECTRICITYELECTRIC ELEMENTSMAGNETS; INDUCTANCES; TRANSFORMERS; SELECTION OF MATERIALS FOR THEIR MAGNETIC PROPERTIESMagnetsPermanent magnets [PM]Magnetic circuits with PM for power or force generationMagnetic suspension or levitationPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating electrostatic or magnetic grippersPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by magnetic means

**[p0002]**

Description Translated from German Die Erfindung betrifft einen Magnetgreifer fÃ¼r manuelles und automatisches Handhaben von Objekten insbesondere von Ringbandkernen.The invention relates to a magnetic gripper for manual and automatic handling of objects, in particular of Toroidal cores. Zum Greifen und Transportieren von Ringbandkernen werden magnetische Dipole verwendet, die einen groÃen FeldschluÃ Ã¼ber Luft aufweisen und bei AnnÃ¤herung an ein Objekt gleich mehrere im Umkreis des magnetischen Feldes liegende Objekte anziehen. Dies macht es nachteiligerweise erforderlich, die Objekte vom Greifer wieder zu vereinzeln. Zum Abtrennen einzelner oder mehrerer angezogener Objekte mÃ¼ssen diese entweder mechanisch unter hÃ¤ufig erheblichem Kraftaufwand abgezogen werden oder es muÃ bei der Verwendung von Elektromagneten eine Stromabschaltung erfolgen, welche wiederum unerwÃ¼nschte InduktionsstrÃ¶me auslÃ¶sen kann. Daher werden als Lasthebemagnete Dauermagnetsysteme wegen ihrer grÃ¶Ãeren Sicherheit anstelle von elektrisch erregten

**[p0003]**

Systemen zunehmend bevorzugt. Zur elektrischen Schaltung der Dauermagnete ist auch bereits vorgeschlagen worden, den DauermagnetfluÃ zeitweilig von den PolflÃ¤chen zu verdrÃ¤ngen, die Dipole ab- und anschlieÃend wieder aufzumagnetisieren oder eine HÃ¤lfte des Dauermagnetmaterials umzupolen.For gripping and transporting toroidal cores uses magnetic dipoles that have a large field closure across Have air and several when approaching an object attract objects lying around the magnetic field. This makes it disadvantageously necessary to remove the objects from the To separate the gripper again. To separate individual or of several attracted objects must either be mechanical be withdrawn with considerable effort or often must be switched off when using electromagnets take place, which in turn trigger unwanted induction currents can. Therefore, permanent magnet systems are used as lifting magnets their greater safety instead of being electrically excited Systems increasingly preferred. For the electrical circuit of the

**[p0004]**

Permanent magnets have also been proposed To temporarily displace permanent magnetic flux from the pole faces Dipoles and then magnetize them again or a Reverse half of the permanent magnet material. Zum Entstapeln von Platinen ist ein Magnetsystem mit zwei unterschiedlichen Polteilungen bekannt, bei dem zum "Ansaugen" der Platine ein elektromagnetischer Teil aktiviert wird und fÃ¼r das Halten bzw. den Weitertransport der magnetischen Platine ein permanentmagnetischer Teil ausgenutzt wird. Hiermit will man den Vorteil nutzen, daÃ nur zu einem ganz bestimmten Zeitpunkt, nÃ¤mlich wÃ¤hrend des Ansaugens, ein kurzer StromstoÃ benÃ¶tigt wird. Die Permanentmagnete fÃ¼hren den magnetischen FluÃ derart durch die Eisenplatinen, daÃ sich dieser jeweils an der Systembodenplatte selbst behindert, was dazu fÃ¼hrt, daÃ kein StreufluÃ erzeugt wird. Diese in der DE 38 22 842 C1 beschriebene AusfÃ¼hrung ist jedoch zum einen fÃ¼r andere AnwendungsfÃ¤lle konzipiert, zum anderen verhÃ¤ltnismÃ¤Ãig aufwendig.For unstacking boards, there is a magnet system with two

**[p0005]**

different pole pitches known, for the "suction" the board an electromagnetic part is activated and for holding or further transport of the magnetic circuit board permanent magnetic part is used. With this you want that Take advantage that only at a very specific point in time, namely during the suction, a short current surge is required becomes. The permanent magnets guide the magnetic flux in this way Â through the iron boards that this each on the System base plate itself hindered, which means that no Leakage flux is generated. This in DE 38 22 842 C1 described execution is, however, on the one hand for others Conceived use cases, on the other hand proportionately complex. Es ist Aufgabe der vorliegenden Erfindung, einen Magnetgreifer zu schaffen, der einfach und kostengÃ¼nstig aufgebaut, zuverlÃ¤ssig schaltbar und in der Lage ist, Objekte, zum Beispiel Ringbandkerne einzeln anzuheben.It is an object of the present invention to provide a magnetic gripper to create a structure that is simple and inexpensive,

**[p0006]**

reliably switchable and capable of objects, for example Lift the toroidal cores individually. Diese Aufgabe wird durch den Magnetgreifer nach Anspruch 1 gelÃ¶st, der erfindungsgemÃ¤Ã dadurch gekennzeichnet ist, daÃ zwischen zwei durch einen Luftspalt getrennten Polschuhen Permanentmagnete derart angeordnet sind, daÃ durch Bewegung mindestens eines der Permanentmagnete eine Magnetfeldkompensation oder die Erregung eines Magnetfeldes in den Polschuhen alternativ einstellbar ist. Der erfindungsgemÃ¤Ãe Magnetgreifer verzichtet vollstÃ¤ndig auf Elektromagnete und arbeitet allein mit Permanentmagneten. Die Magnetfeldkompensation erfolgt durch Antiparallelstellung der magnetischen Dipole Ã¼ber eine Drehbewegung, so daÃ das notwendige Drehmoment wegen der Scherbewegung zu den Kraftlinien sehr gering ausfÃ¤llt, also keine hohen AnriebskrÃ¤fte fÃ¼r die Drehmechanik aufgewendet werden mÃ¼ssen.This object is achieved by the magnetic gripper according to claim 1 solved, which is characterized according to the invention in that

**[p0007]**

between two pole pieces separated by an air gap Permanent magnets are arranged so that by movement at least one of the permanent magnets Magnetic field compensation or the excitation of a magnetic field in the pole pieces are alternatively adjustable. The invention Magnetic grippers completely dispense with electromagnets and works with permanent magnets alone. The Magnetic field compensation is carried out by placing the magnetic dipoles via a rotary motion, so that necessary torque due to the shear movement to the lines of force turns out to be very low, so no high driving forces for the Rotary mechanism must be used. Weiterbildungen der Erfindung sind in den UnteransprÃ¼chen 2 bis 10 beschrieben.Further developments of the invention are in the subclaims 2 to 10 described. So besteht der Magnetgreifer im einfachsten Fall aus zwei Permanentmagneten, von denen einer drehbar gelagert ist. Bei Antiparallelstellung ist die Reluktanz, nÃ¤mlich der Widerstand, den der magnetische FluÃ erfÃ¤hrt, durch beide Dipole minimal, so

**[p0008]**

daÃ in den Weicheisen-Polschuhen kein Feld vorhanden ist. Stellt man die Permanentmagnete parallel, so addieren sich beide Felder. Da die Reluktanz Ã¼ber Luft erheblich grÃ¶Ãer als Ã¼ber den Weicheisenkern mit einem kleinen Luftspalt ist, bilden sich magnetische Feldlinien Ã¼ber den einen Polschuh, den Ringbandkern und Ã¼ber den anderen Polschuh zum Magneten aus, d. h., der Ringbandkern schlieÃt die magnetischen Polschuhe kurz. Da der hierbei auftretende magnetische StreufluÃ minimal ist, wird auch nur der kurzschlieÃende Magnetkern angezogen, wÃ¤hrend die daneben- oder darunterliegenden Kerne liegen bleiben. Stellt man die Permanentmagnete wieder antiparallel, verschwindet der magnetische FluÃ in den Polschuhen, so daÃ der Ringbandkern abfÃ¤llt.In the simplest case, the magnetic gripper consists of two Permanent magnets, one of which is rotatably mounted. At Antiparallel is reluctance, namely resistance, that the magnetic flux experiences minimally through both dipoles, so that there is no field in the soft iron pole shoes. Poses

**[p0009]**

if the permanent magnets are parallel, both add up Fields. Because the reluctance over air is considerably larger than over the Â Soft iron core with a small air gap is formed magnetic field lines over one pole piece, the toroidal core and over the other pole piece to the magnet, d. i.e. the Toroidal band shorts the magnetic pole shoes. Since the magnetic stray flux occurring here is minimal, too only the short-circuiting magnetic core attracted while the cores lying next to or underneath remain. One poses the permanent magnets anti-parallel again, the disappears magnetic flux in the pole pieces, so that the toroidal core falls off. Nach einer weiteren Ausgestaltung der Erfindung werden die beiden Permanentmagnete aneinanderliegend und durch einen Luftspalt getrennt angeordnet. Da vorzugsweise nur einer der Permanentmagnete gedreht wird, wird dies zweckmÃ¤Ãigerweise der obere sein. Die Drehung gegenÃ¼ber dem darunterliegenden Permanentmagnet erfolgt durch den Luftspalt verschleiÃfrei. Zur einfacheren Abstimmung werden gleich groÃe und eine gleiche

**[p0010]**

Magnetisierung aufweisende Permanentmagnete verwendet, mit denen eine Kompensation des magnetischen Gesamtfeldes mÃ¶glich ist. Der drehbar gelagerte Permanentmagnet wird bevorzugt mit einem Motor oder einem pneumatischen Antrieb gekoppelt sein, um die Drehbewegung automatisieren zu kÃ¶nnen.According to a further embodiment of the invention two permanent magnets adjacent to each other and by one Air gap arranged separately. Since preferably only one of the Permanent magnet is rotated, this is conveniently the be upper. The rotation relative to the one below Permanent magnet is wear-free through the air gap. For easier tuning will be the same size and the same Permanent magnets with magnetization are used with which compensation of the total magnetic field is possible. Of the Rotatable permanent magnet is preferred with a motor or be coupled to a pneumatic drive to the To be able to automate rotary motion. Eine weitere Verbesserung der Magnetgreifer-Wirkung ergibt sich durch eine optimierte Gestaltung der Polschuhe. Vorzugsweise

**[p0011]**

sind diese - beim Greifen von Ringbandkernen - jeweils an ihrer den Dauermagneten abgewandten Seite der Geometrie des zu greifenden Objektes angepaÃt, beispielsweise konisch verjÃ¼ngt ausgebildet, so daÃ der magnetische KraftfluÃ zur Polspitze hin "verdichtet" werden kann. Werden die Polschuhe an ihrem betreffenden Ende im Querschnitt halbkreis- oder kreissegmentfÃ¶rmig ausgebildet, wobei die sich parallel im Abstand gegenÃ¼berliegenden FlÃ¤chen eben sind, erreicht man, bezogen auf die durch den Luftspalt gebildete Spiegelachse, eine Achsensymmetrie der magnetischen FluÃlinien, die ein gleichmÃ¤Ãiges Anheben der Ringbandkerne ohne StreufluÃerscheinung gewÃ¤hrleistet. Diese Wirkung wird noch verstÃ¤rkt, wenn die AuÃenmantelflÃ¤che der Polschuhe an ihrem sich verjÃ¼ngenden Ende eine KrÃ¼mmung aufweist, die etwa gleich der KrÃ¼mmung des aufzunehmenden Ringbandkerninnenmantels ist.There is a further improvement in the magnetic gripper effect through an optimized design of the pole shoes. Preferably

**[p0012]**

they are - when gripping toroidal cores - on theirs the permanent magnet facing away from the geometry of the adapted object, for example tapered conically trained so that the magnetic force flow towards the pole tip can be "condensed". Will the pole pieces on your relevant end in cross section semicircular or circular segment-shaped, which are parallel in Planes are flat, you can reach based on the mirror axis formed by the air gap, a Axis symmetry of the magnetic flux lines, the one even lifting of the toroidal cores without Â Litter flux appearance guaranteed. This effect will still be there reinforced when the outer surface of the pole pieces on their tapered end has a curvature that is approximately the same the curvature of the toroidal inner jacket to be accommodated. An ihrem entgegengesetzt liegenden Ende besitzen die Polschuhe jeweils eine Ausnehmung, in der die Permanentmagnete gelagert sind. Hierbei ist der untere der Permanentmagnete gegenÃ¼ber der AuflageflÃ¤che der Polschuhe magnetisch isoliert, vorzugsweise

**[p0013]**

durch eine zwischengelagerte Messingplatte.The pole shoes have at their opposite end each have a recess in which the permanent magnets are mounted are. Here, the lower one of the permanent magnets is opposite Contact surface of the pole pieces magnetically insulated, preferably through an intermediate brass plate. Ein AusfÃ¼hrungsbeispiel der Erfindung ist in der Zeichnung dargestellt, die einen Querschnitt durch einen erfindungsgemÃ¤Ãen Magnetgreifer fÃ¼r Ringbandkerne zeigt.An embodiment of the invention is in the drawing shown a cross section through an inventive Magnetic gripper for toroidal tape cores shows. Der dargestellte Magnetgreifer besteht im wesentlichen aus zwei Polschuhen 10, 11, die eine nach unten hin sich verjÃ¼ngende Form aufweisen. Zwischen den Polschuhen 10 und 11 befindet sich ein Luftspalt 12 mit einer Ã¼ber seine LÃ¤nge gesehen konstanten Breite. In einer Querschnittsansicht der Polschuhspitzen wird jeder der Polschuhe eine Kreissegmentform haben. Die Spitzen der Polschuhe tauchen in die mittlere Ãffnung eines Ringbandkernes

**[p0014]**

13 ein, wobei sich im Idealfall die gekrÃ¼mmten PolschuhauÃenmÃ¤ntel ringfÃ¶rmig an den Ringbandkerninnenmantel anlegen.The magnetic gripper shown consists essentially of two pole pieces 10 , 11 , which have a shape that tapers towards the bottom. Between the pole pieces 10 and 11 there is an air gap 12 with a width that is constant over its length. In a cross-sectional view of the pole piece tips, each of the pole pieces will have a circular segment shape. The tips of the pole pieces are immersed in the central opening of a ring band core 13 , the curved outer pole piece shells ideally forming a ring against the ring band core inner layer. Im oberen, der Polschuhenspitze entgegengesetzten Bereich besitzt der Magnetgreifer eine Ausnehmung, auf deren Grund in Ã¼bereinandergestapelter Reihenfolge eine Messingplatte 14, ein erster feststehender Dipol 15 und ein drehbarer Dipol 16 angeordnet sind. Der obere Dipol kann mittels eines motorisch oder pneumatisch antreibbaren Drehzylinders 17 jeweils um 180Â°

**[p0015]**

geschwenkt werden. Zwischen den beiden Dipolen (Permanentmagneten 15 und 16) befindet sich ein schmaler Luftspalt 18, wodurch die Drehung des Dipoles 16 gegen den Dipol 15 verschleiÃfrei erfolgt. In the upper area opposite the pole shoe tip, the magnetic gripper has a recess, on the base of which a brass plate 14 , a first fixed dipole 15 and a rotatable dipole 16 are arranged in a stacked order. The upper dipole can be pivoted through 180 Â° in each case by means of a rotating cylinder 17 which can be driven by a motor or pneumatically. There is a narrow air gap 18 between the two dipoles (permanent magnets 15 and 16 ), as a result of which the rotation of the dipole 16 against the dipole 15 takes place without wear. In der dargestellten Anordnung besitzen beide Permanentmagnete 15 und 16 einen magnetischen KraftfluÃ in Richtung der Pfeile 19 und 20, sie sind also gleichgerichtet. Dies fÃ¼hrt zu einer Addition der Felder. Da die Reluktanz Ã¼ber dem Luftspalt 12 erheblich grÃ¶Ãer ist als Ã¼ber dem Polschuh-Weicheisenkern-

**[p0016]**

Polschuh-Weg, ergibt sich ein durch die Pfeile 21 bis 25 verdeutlichter kurzgeschlossener magnetischer FluÃ. Der magnetische KurzschluÃ bedingt auch, daÃ der auÃerhalb des Magnetgreifers und des Ringbandkernes 13 liegende magnetische StreufluÃ minimal ist. Das Magnetfeld wirkt praktisch nur auf den Ringbandkern 13. Stellt man die Permanentmagnete 15 und 16 nach Drehung um 180Â° antiparallel, heben sich die Felder auf, d. h., der magnetische FluÃ durch die Polschuhe 10 und 11 und damit den Ringbandkern 13 verschwindet, so daÃ sich der Ringbandkern 13 von den Polschuhen 10, 11 lÃ¶st.In the arrangement shown, both permanent magnets 15 and 16 have a magnetic force flow in the direction of arrows 19 and 20 , so they are rectified. This leads to an addition of the fields. Since the reluctance across the air gap 12 is considerably greater than over the pole shoe soft iron core pole shoe path, a short-circuited magnetic flux is indicated by the arrows 21 to 25 . The magnetic short circuit also means that the magnetic stray flux lying outside the magnetic gripper and the toroidal core 13 is minimal. The magnetic field practically acts only on the toroidal core 13 . If the permanent magnets 15 and 16 are set antiparallel after rotation by 180 Â°, the fields cancel each other out, ie the magnetic flux through the pole shoes 10 and 11 and thus the toroidal core 13 disappears, so that the toroidal core 13 is separated from the pole shoes 10 , 11 solves.

**[p0017]**

FÃ¼r den Fall, daÃ die Ringbandkerne eine vieleckige Innenkontur haben, kann die AuÃenmantelform der Polschuhe 10, 11 auch dieser andersartigen Innenmantelkontur angepaÃt sein.In the event that the toroidal cores have a polygonal inner contour, the outer jacket shape of the pole shoes 10 , 11 can also be adapted to this different type of inner jacket contour.

## Classifications

- H01F7/0236
- H01F7/0236
- B65G47/92
- B65G47/92
- B65G47/92
- B65G47/92
- B66C1/04
- B66C1/04
- B66C1/04
- B66C1/04
- H01F7/02
- H01F7/02

## Cited patent documents

- [DD-148844-A1](https://patents.google.com/patent/DD148844A1/en) — SEA
- [DE-1065592-B](https://patents.google.com/patent/DE1065592B/en) — SEA
- [DE-1121242-B](https://patents.google.com/patent/DE1121242B/en) — SEA
- [DE-1152488-B](https://patents.google.com/patent/DE1152488B/en) — SEA
- [DE-1156629-B](https://patents.google.com/patent/DE1156629B/en) — SEA
- [DE-1197994-B](https://patents.google.com/patent/DE1197994B/en) — SEA
- [DE-1236413-B](https://patents.google.com/patent/DE1236413B/en) — SEA
- [DE-2161141-B2](https://patents.google.com/patent/DE2161141B2/en) — SEA
- [DE-2737344-A1](https://patents.google.com/patent/DE2737344A1/en) — SEA
- [DE-3212464-A1](https://patents.google.com/patent/DE3212464A1/en) — SEA
- [DE-3220801-A1](https://patents.google.com/patent/DE3220801A1/en) — SEA
- [DE-3628544-A1](https://patents.google.com/patent/DE3628544A1/en) — SEA
- [DE-881702-C](https://patents.google.com/patent/DE881702C/en) — SEA
- [GB-2036445-A](https://patents.google.com/patent/GB2036445A/en) — SEA
- [SU-1692803-A1](https://patents.google.com/patent/SU1692803A1/en) — SEA
- [SU-346085-A1](https://patents.google.com/patent/SU346085A1/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
