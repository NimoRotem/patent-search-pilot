# 21. Magnetic body holding device

- **Archive rank:** 21 of 50
- **Publication:** [JP-2002059328-A](https://patents.google.com/patent/JP2002059328A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/018740073/publication/JP2002059328A?q=pn%3DJP2002059328A)
- **Publication date:** 2002-02-26
- **Filing date:** 2000-08-22
- **Earliest priority:** 2000-08-22
- **Family:** 18740073
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** SHINWA IND

## Abstract

PROBLEM TO BE SOLVED: To provide a magnetic body holding device capable of suppressing as much as possible the deformation of a magnetic body caused by the holding of the magnetic body when the magnetic body is held in order to cut the magnetic body. SOLUTION: This magnetic body holding device HS1 for holding the magnetic body in order to cut the magnetic body comprises a base HB1 and magnetic projections PF which switch a state of generating the magnetism on a surface on the magnetic body side on the base with a state of generating no magnetism and have an abutting part PT provided on the surface on the magnetic body side on the base and abutted on the magnetic body. Elasticity is given between the base and the projections, the abutting part is protruded from the surface on the magnetic body side on the base, and the projections can be put into a linear motion substantially in the direction orthogonal to a plane formed by arbitrary three points present on the surface on the magnetic body side on the base.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/JP-2002059328-A/ops000.png)

![Sketch 1 for JP-2002059328-A](https://nimo.iptorch.com/refdrawing/JP-2002059328-A/ops000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/JP-2002059328-A/ops001.png)

![Sketch 2 for JP-2002059328-A](https://nimo.iptorch.com/refdrawing/JP-2002059328-A/ops001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/JP-2002059328-A/ops002.png)

![Sketch 3 for JP-2002059328-A](https://nimo.iptorch.com/refdrawing/JP-2002059328-A/ops002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/JP-2002059328-A/ops003.png)

![Sketch 4 for JP-2002059328-A](https://nimo.iptorch.com/refdrawing/JP-2002059328-A/ops003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/JP-2002059328-A/ops004.png)

![Sketch 5 for JP-2002059328-A](https://nimo.iptorch.com/refdrawing/JP-2002059328-A/ops004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/JP-2002059328-A/ops005.png)

![Sketch 6 for JP-2002059328-A](https://nimo.iptorch.com/refdrawing/JP-2002059328-A/ops005.png)

## Claims

### Claim 1

【請求項１】 磁性体を切削加工するために、上記磁性体を保持する磁性体保持装置において、 上記磁性体を載置する基台と；上記基台における上記磁性体側の面に磁気を発生させる状態と、上記磁気を発生させない状態とを切り換える切換え手段と；上記基台における上記磁性体側の面に設けられ、上記磁性体と当接する当接部と、磁性とを具備する第１の突起と；上記基台と上記第１の突起との間に弾性を付与する弾性付与手段と；を有し、上記基台における上記磁性体側の面から上記当接部が突出し、上記基台における上記磁性体側の面に存在する任意の３点によって形成される平面に対して略直角方向に、上記第１の突起が直線運動可能であることを特徴とする磁性体保持装置。

### Claim 2

【請求項２】 請求項１において、 上記基台における上記磁性体側の面に設けられ、上記磁性体と当接する当接部を具備し、上記基台との間において弾性が付与されていない第２の突起を有し、上記基台における上記磁性体側の面から上記第２の突起の当接部が突出していることを特徴とする磁性体保持装置。

### Claim 3

【請求項３】 磁性体を切削加工するために、上記磁性体を保持する磁性体保持装置において、 上記磁性体を載置する基台と；上記基台における上記磁性体側の面に磁気を発生させる状態と、上記磁気を発生させない状態とを切り換える切換え手段と；上記基台における上記磁性体側の面に設けられ、磁性を具備するブロックと；上記ブロックにおける上記磁性体側の面に設けられ、上記磁性体と当接する当接部と、磁性とを具備する第１の突起と；上記ブロックと上記突起との間に弾性を付与する弾性付与手段と；を有し、上記ブロックにおける上記磁性体側の面から上記当接部が突出し、上記基台における上記磁性体側の面に存在する任意の３点によって形成される平面に対して略直角方向に、上記第１の突起が直線運動可能であることを特徴とする磁性体保持装置。

### Claim 4

【請求項４】 請求項３において、 上記ブロックにおける上記磁性体側の面に設けられ、上記磁性体と当接する当接部を具備し、上記ブロックとの間において弾性が付与されていない第２の突起を有し、上記ブロックにおける上記磁性体側の面から上記第２の突起の当接部が突出していることを特徴とする磁性体保持装置。

### Claim 5

【請求項５】 請求項１〜請求項４のいずれか１項において、 上記第１の突起が具備する当接部と、上記第２の突起が具備する当接部とのうちの少なくとも一方の当接部が、凸面で構成されていることを特徴とする磁性体保持装置。

### Claim 6

【請求項６】 磁性体を切削加工するために、上記磁性体を保持する磁性体保持装置において、 上記磁性体を載置する基台と；上記基台における上記磁性体側の面に磁気を発生させる状態と、上記磁気を発生させない状態とを切り換える切換え手段と；上記基台における上記磁性体側の面に設けられ、磁性を具備する第３の突起と；上記磁性体と当接する当接部を具備し、磁性を具備し、上記第３の突起の少なくとも一部を覆う第１の突起カバーと；上記第３の突起と上記第１の突起カバーとの間に弾性を付与する弾性付与手段と；を有し、上記基台における上記磁性体側の面に対し、上記第１の突起カバーの当接部が上記磁性体側に位置し、上記基台における上記磁性体側の面に存在する任意の３点によって形成される平面に対して略直角方向に、上記第１の突起カバーが直線運動可能であることを特徴とする磁性体保持装置。

### Claim 7

【請求項７】 請求項６において、 上記磁性体と当接する当接部を具備し、上記第３の突起との間において弾性が付与されていない第２の突起カバーを有し、上記基台における上記磁性体側の面に対し、上記第２の突起カバーの当接部が上記磁性体側に位置していることを特徴とする磁性体保持装置。

### Claim 8

【請求項８】 請求項６または請求項７において、 上記第１の突起カバーが具備する当接部と、上記第２の突起カバーが具備する当接部とのうちの少なくとも一方の当接部が、凸面で構成されていることを特徴とする磁性体保持装置。

## Full description

Description

Translated from Japanese

ãçºæã®è©³ç´°ãªèª¬æãDETAILED DESCRIPTION OF THE INVENTION

ãï¼ï¼ï¼ï¼ã[0001]

ãçºæã®å±ããæè¡åéãæ¬çºæã¯ãç£æ§ãå

·åããã¯

ã¼ã¯ããã©ã¤ã¹å å·¥ç­ããå ´åãä¸è¨ã¯ã¼ã¯ãä¿æãã

ã¯ã¼ã¯ä¿æè£

ç½®ã«é¢ãããBACKGROUND OF THE INVENTION 1. Field of the Invention The present invention relates to a work holding device that holds a work having magnetism when the work is milled or the like.

ãï¼ï¼ï¼ï¼ã[0002]

ãå¾æ¥ã®æè¡ãå³ï¼ï¼ã¯ãå¾æ¥ã®ç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼

ï¼ã«ãã£ã¦ãç£æ§ä½ãä¿æãããã®ä¿æãããç£æ§ä½ã

ååå å·¥ãã¦ããç¶æ

ãç¤ºãæè¦å³ã§ããã2. Description of the Related Art FIG. 14 shows a conventional magnetic material holding device HS1.

0 is a perspective view showing a state in which the magnetic material is held by 0 and the held magnetic material is being cut.

ãï¼ï¼ï¼ï¼ãå¾æ¥ãæ­£é¢ãã©ã¤ã¹ç¤ç­ã®å·¥ä½æ©æ¢°ã«ãã

ã¦ãç£æ§ä½ï¼·ï¼ï¼ï¼ãã¨ãã°é¼ï¼ãååå å·¥ããå ´åã

å·¥ä½æ©æ¢°ã®ãã¼ãã«ï¼´ï½ï¼ï¼ã«è¨­ãããã¦ããç£æ§ä½ä¿

æè£

ç½®ï¼¨ï¼³ï¼ï¼ï¼ãã¨ãã°ãã°ããããã£ãã¯ï¼ãæã

ãå¹³é¢ï¼¨ï¼³ï¼ï¼ï½ã«ãä¸è¨ç£æ§ä½ï¼·ï¼ï¼ãç£æ°ã«ãã£ã¦

å¸çãä¿æãããConventionally, in a machine tool such as a face milling machine, when cutting a magnetic material W10 (for example, steel),

The magnetic body W10 is magnetically attracted and held on a flat surface HS10a of a magnetic body holding device HS10 (for example, a magnet chuck) provided on a table Tb10 of a machine tool.

ãï¼ï¼ï¼ï¼ãããã¦ãä¸è¨ç£æ§ä½ãååããåç©ï¼å³ç¤º

ããï¼ãå

·åããã«ãã¿ã¼ï¼£ï¼´ï¼ï¼ãç¢å°ï¼¡ï¼²ï¼ï¼ã®æ¹

åã«åè»¢ããã¤ã¤ãç¢å°ï¼¡ï¼²ï¼ï¼ã®æ¹åã«ç§»åãããç£

æ§ä½ï¼·ï¼ï¼ãååå å·¥ããããªãããã®ååå å·¥ã«ãã

ãåãè¾¼ã¿éã¯ããÎï½ãã¨ããã[0004] Then, while rotating a cutter CT10 provided with a cutting tool (not shown) for cutting the magnetic body in the direction of arrow AR10, the cutter CT10 is moved in the direction of arrow AR11 to cut the magnetic body W10. Note that the cut amount in this cutting is âÎtâ.

ãï¼ï¼ï¼ï¼ãå³ï¼ï¼ã¯ãç£æ§ä½ï¼·ï¼ï¼ãååããå ´åã«

ããã¦ããã®ç£æ§ä½ã®æåç­ãç¤ºãå³ã§ãããFIG. 15 is a view showing the behavior of the magnetic material W10 when cutting the magnetic material W10.

ãï¼ï¼ï¼ï¼ãå³ï¼ï¼ï¼ï¼ï¼ã§ã¯ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼

ï¼ãç£æ§ä½ï¼·ï¼ï¼ãä¿æããåã®ç¶æ

ãè¡¨ããç£æ§ä½ï¼·

ï¼ï¼ã¯ãä¸æ´é¢ï¼·ï¼ï¼ï½ãï¼·ï¼ï¼ï½ãå

·åããããªãã

ä¸æ´é¢ï¼·ï¼ï¼ï½ãï¼·ï¼ï¼ï½ã¨ã¯ãå¹³é¢ã§ãªãé¢ã§ãããIn FIG. 15A, a magnetic material holding device HS1 is shown.

0 indicates a state before the magnetic body W10 is held. Magnetic material W

Reference numeral 10 includes irregular surfaces W10a and W10b. In addition,

The irregular surfaces W10a and W10b are non-planar surfaces.

ãï¼ï¼ï¼ï¼ãå³ï¼ï¼ï¼ï¼ï¼ã§ã¯ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼

ï¼ãç£æ§ä½ï¼·ï¼ï¼ãä¿æããç¶æ

ãè¡¨ããç£æ°ã«ãã£

ã¦ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ï¼ãæããå¹³é¢ï¼¨ï¼³ï¼ï¼ï½

ã«ãç£æ§ä½ï¼·ï¼ï¼ãå¸çããããããã¦ãç£æ§ä½ï¼·ï¼ï¼

ãå

·åããåæ§ãããç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ï¼ãå

·åã

ãåæ§ã®ã»ããé«ãã®ã§ãç£æ§ä½ï¼·ï¼ï¼ã®ä¸æ´é¢ï¼·ï¼ï¼

ï½ãï¼·ï¼ï¼ï½ã¯ãå¹³é¢ï¼¨ï¼³ï¼ï¼ï½ã«ç¿ã£ã¦å¤å½¢ããã»ã¼

å¹³é¢ï¼·ï¼ï¼ï½âãï¼·ï¼ï¼ï½âã®ç¶æ

ã«ãªããIn FIG. 15 (2), a magnetic material holding device HS1

0 indicates a state where the magnetic body W10 is held. Due to magnetism, the plane HS10a of the magnetic material holding device HS10

Then, the magnetic body W10 is adsorbed. And the magnetic body W10

Since the rigidity of the magnetic material holding device HS10 is higher than the rigidity of the magnetic material W10, the irregular surface W10 of the magnetic material W10

a and W10b are deformed following the plane HS10a, and are substantially in the state of the planes W10a 'and W10b'.

ãï¼ï¼ï¼ï¼ãå³ï¼ï¼ï¼ï¼ï¼ã§ã¯ãç£æ§ä½ï¼·ï¼ï¼ã®ååç¶

æ

ãç¤ºããç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ï¼ãç£æ§ä½ï¼·ï¼ï¼ãä¿

æããã«ãã¿ã¼ï¼£ï¼´ï¼ï¼ãç¢å°ï¼¡ï¼²ï¼ï¼ã®ããã«åè»¢ã

ãªãããç¢å°ï¼¡ï¼²ï¼ï¼æ¹åã«ç§»åããåãè¾¼ã¿éÎï½ã

ããç£æ§ä½ï¼·ï¼ï¼ãååãã¦ãããç£æ§ä½ï¼·ï¼ï¼ã®å¹³é¢

ï¼·ï¼ï¼ï½âããã«ãã¿ã¼ï¼£ï¼´ï¼ï¼ãåãè¾¼ã¿éÎï½ã ã

ååãããã¨ã«ãã£ã¦ãå¹³é¢ï¼·ï¼ï¼ï½ãç¾ãããFIG. 15C shows a cutting state of the magnetic body W10. The magnetic material holding device HS10 holds the magnetic material W10, and the cutter CT10 moves in the direction of the arrow AR11 while rotating as shown by the arrow AR10, and cuts the magnetic material W10 by the cutting amount Ît. The plane W10c appears when the cutter CT10 cuts the plane W10a â² of the magnetic body W10 by the cutting amount Ît.

ãï¼ï¼ï¼ï¼ãå³ï¼ï¼ï¼ï¼ï¼ã§ã¯ãç£æ§ä½ï¼·ï¼ï¼ã®ååã

çµäºããç´å¾ã®ç¶æ

ãç¤ºããããªãã¡ãç£æ§ä½ä¿æè£

ç½®

ï¼¨ï¼³ï¼ï¼ãç£æ§ä½ï¼·ï¼ï¼ãä¿æããã«ãã¿ã¼ï¼£ï¼´ï¼ï¼ã

ç¢å°ï¼¡ï¼²ï¼ï¼ããã«åè»¢ããªãããç¢å°ï¼¡ï¼²ï¼ï¼æ¹åã«

ç§»åããåãè¾¼ã¿éÎï½ã ããç£æ§ä½ï¼·ï¼ï¼ãååãçµ

ãã£ãç¶æ

ãç¤ºããç£æ§ä½ï¼·ï¼ï¼ããåãè¾¼ã¿éÎï½ã

ãååãããã¨ã«ãã£ã¦å¹³é¢ï¼·ï¼ï¼ï½ãç¾ããããã®å¹³

é¢ï¼·ï¼ï¼ï½ã¯ãã«ãã¿ã¼ï¼£ï¼´ï¼ï¼ã§ååããé¢ãªã®ã§ã»

ã¼å¹³é¢ã«ãªã£ã¦ãããFIG. 15D shows a state immediately after the cutting of the magnetic body W10 is completed. That is, the magnetic material holding device HS10 holds the magnetic material W10, the cutter CT10 rotates in the direction of the arrow AR11 while rotating as shown by the arrow AR10, and the magnetic material W10 has been cut by the cutting amount Ît. The plane W10c appears by cutting the magnetic body W10 by the cut amount Ît. Since the plane W10c is a plane cut by the cutter CT10, the plane W10c is substantially flat.

ãï¼ï¼ï¼ï¼ãå³ï¼ï¼ï¼ï¼ï¼ã§ã¯ãä¸è¨ååããç£æ§ä½ï¼·

ï¼ï¼ããç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ï¼ã®ç£æ°ããªãããç£æ§

ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ï¼ããé¢ããç¶æ

ãç¤ºããããã«ãã£

ã¦ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ï¼ã®å

·åããå¹³é¢ï¼¨ï¼³ï¼ï¼ï½

ããç£æ§ä½ï¼·ï¼ï¼ãé¢ãããããã¦ãå³ï¼ï¼ï¼ï¼ï¼ã«ã

ãã¦å¤å½¢ããç£æ§ä½ï¼·ï¼ï¼ãããã¨ã®ç¶æ

ï¼ç£æ§ä½ä¿æ

è£

ç½®ï¼¨ï¼³ï¼ï¼ã®ç£æ°ã¨ç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ï¼ã«è¨­ãã

ãã¦ããå¹³é¢ï¼¨ï¼³ï¼ï¼ï½ã¨ã«ãã£ã¦å¤å½¢ãåããªãç¶

æ

ï¼ã«ãã©ããããã«ãã£ã¦ãå³ï¼ï¼ï¼ï¼ï¼ã«ç¤ºãå¹³é¢

ï¼·ï¼ï¼ï½âã¯ãä¸æ´é¢ï¼·ï¼ï¼ï½ã«ãã©ããå³ï¼ï¼ï¼ï¼ï¼

ã«ç¤ºãå¹³é¢ï¼·ï¼ï¼ï½ã¯ãä¸æ´é¢ï¼·ï¼ï¼ï½âã«å¤å½¢ãããIn FIG. 15 (5), the cut magnetic material W

10 shows a state where the magnetism of the magnetic material holding device HS10 is turned off and the magnetic material holding device HS10 is separated from the magnetic material holding device HS10. Thereby, the plane HS10a of the magnetic material holding device HS10 is provided.

Is separated from the magnetic body W10. Then, the magnetic body W10 deformed in FIG. 15 (2) returns to the original state (a state where the magnetic body W10 is not deformed by the magnetism of the magnetic body holding device HS10 and the plane HS10a provided on the magnetic body holding device HS10). . As a result, the plane W10b â² shown in FIG. 15 (4) returns to the irregular surface W10b, and FIG.

Is transformed into an irregular surface W10c â².

ãï¼ï¼ï¼ï¼ã[0011]

ãçºæãè§£æ±ºãããã¨ããèª²é¡ãã¨ããã§ãç£æ§ä½ï¼·ï¼

ï¼ãååå å·¥ãããã¨ã«ãã£ã¦å¾ãããé¢ã¯ãã§ããã

ãç²¾åº¦è¯ãå å·¥ããã¦ããï¼æ­£é¢ãã©ã¤ã¹å å·¥ã«ãã£ã¦

ã¯ãå¹³é¢ã«å å·¥ããã¦ããï¼ãã¨ãæã¾ããããã®çç±

ã¯ãä¸è¨å å·¥ãããç£æ§ä½ã®å å·¥é¢ã®ç²¾åº¦ãæªãã¨ãä¸

è¨å å·¥ãããç£æ§ä½ãä»ã®æ©æ¢°ãè£

ç½®ã®æ§æé¨åã¨ãã¦

ä½¿ç¨ããå ´åãä¸è¨ä»ã®æ©æ¢°ã®ç²¾åº¦ã«æªå½±é¿ãããã¼ã

ããã§ãããThe magnetic material W1

It is desirable that the surface obtained by cutting 0 is processed as accurately as possible (in the case of face milling, it is processed into a flat surface). The reason for this is that if the accuracy of the machined surface of the machined magnetic material is poor, when the machined magnetic material is used as a component of another machine or device, the accuracy of the other machine is adversely affected. It is.

ãï¼ï¼ï¼ï¼ãå¾æ¥ä¾ã«ããã°ãç£æ§ä½ï¼·ï¼ï¼ãååå å·¥

ããããã«ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ï¼ãç£æ§ä½ï¼·ï¼ï¼ã

ä¿æããå ´åãç£æ§ä½ï¼·ï¼ï¼ããç£æ§ä½ä¿æï¼¨ï¼³ï¼ï¼ã®

æããå¹³é¢ï¼¨ï¼³ï¼ï¼ï½ã«ç¿ã£ã¦å¤å½¢ãã¦ãã¾ãã¨ããå

é¡ããããAccording to the conventional example, when the magnetic material holding device HS10 holds the magnetic material W10 in order to cut the magnetic material W10, the magnetic material W10 is deformed following the plane HS10a of the magnetic material holding HS10. There is a problem of doing it.

ãï¼ï¼ï¼ï¼ãããã¦ãç£æ§ä½ï¼·ï¼ï¼ã®ä¸æ´é¢ï¼·ï¼ï¼ï½ã

ååãããã¨ã«ãã£ã¦ãå¹³é¢ãå¾ããã«ããããããã

å¹³é¢ãå¾ããã¨ãã§ããªãã[0013] Although it is desired to obtain a flat surface by cutting the irregular surface W10a of the magnetic body W10,

You cannot get a plane.

ãï¼ï¼ï¼ï¼ããªããä¸è¨åé¡ã¯ãæ­£é¢ãã©ã¤ã¹å å·¥ä»¥å¤

ã®ä»¥å¤ã®ååå å·¥ï¼ãã¨ãã°ããã¬ã¼ãå å·¥ãç åå

å·¥ããã®ä»ã®å¹³é¢ãå½¢æããããã®å å·¥ããã¼ãªã³ã°ç­

ã®ç©´å å·¥ãã¿ã¼ãã³ã°å å·¥ï¼ã«ããã¦ãçããåé¡ã§ã

ãã[0014] The above-mentioned problem is also caused by cutting other than face milling (for example, planar machining, grinding, machining for forming other flat surfaces, boring or other hole machining, turning machining). It is.

ãï¼ï¼ï¼ï¼ãæ¬çºæã¯ãç£æ§ä½ãååå å·¥ããããã«ã

ãã®ç£æ§ä½ãä¿æããå ´åããã®ä¿æã«ãã£ã¦çããä¸

è¨ç£æ§ä½ã®å¤å½¢ãæ¥µåãããããã¨ãã§ããç£æ§ä½ä¿æ

è£

ç½®ãæä¾ãããã¨ãç®çã¨ãããThe present invention provides a method for cutting a magnetic material.

An object of the present invention is to provide a magnetic body holding device that can minimize deformation of the magnetic body caused by the holding when holding the magnetic body.

ãï¼ï¼ï¼ï¼ã[0016]

ãèª²é¡ãè§£æ±ºããããã®ææ®µãæ¬çºæã¯ãç£æ§ä½ãåå

å å·¥ããããã«ãä¸è¨ç£æ§ä½ãä¿æããç£æ§ä½ä¿æè£

ç½®

ã«ããã¦ãä¸è¨ç£æ§ä½ãè¼ç½®ããåºå°ã¨ãä¸è¨åºå°ã«ã

ããä¸è¨ç£æ§ä½å´ã®é¢ã«ç£æ°ãçºçãããç¶æ

ã¨ãä¸è¨

ç£æ°ãçºçãããªãç¶æ

ã¨ãåãæããåæãææ®µã¨ã

ä¸è¨åºå°ã«ãããä¸è¨ç£æ§ä½å´ã®é¢ã«è¨­ããããä¸è¨ç£

æ§ä½ã¨å½æ¥ããå½æ¥é¨ã¨ç£æ§ã¨ãå

·åããç¬¬ï¼ã®çªèµ·

ã¨ãä¸è¨åºå°ã¨ä¸è¨ç¬¬ï¼ã®çªèµ·ã¨ã®éã«å¼¾æ§ãä»ä¸ãã

å¼¾æ§ä»ä¸ææ®µã¨ãæããä¸è¨åºå°ã«ãããä¸è¨ç£æ§ä½å´

ã®é¢ããä¸è¨å½æ¥é¨ãçªåºããä¸è¨åºå°ã«ãããä¸è¨ç£

æ§ä½å´ã®é¢ã«å­å¨ããä»»æã®ï¼ç¹ã«ãã£ã¦å½¢æãããå¹³

é¢ã«å¯¾ãã¦ç¥ç´è§æ¹åã«ãä¸è¨ç¬¬ï¼ã®çªèµ·ãç´ç·éåå¯

è½ãªç£æ§ä½ä¿æè£

ç½®ã§ãããAccording to the present invention, there is provided a magnetic material holding apparatus for holding a magnetic material, for cutting a magnetic material, the base on which the magnetic material is mounted, and the base in the base. Switching means for switching between a state in which magnetism is generated on the surface on the side of the magnetic body and a state in which the magnetism is not generated,

A first projection provided on a surface of the base on the side of the magnetic body, the first projection having a magnet and a contact portion that is in contact with the magnetic body; and providing elasticity between the base and the first projection. The contact portion protrudes from the surface of the base on the side of the magnetic body, with respect to a plane formed by any three points present on the surface of the base on the side of the magnetic body. This is a magnetic body holding device in which the first protrusion can move linearly in a substantially right angle direction.

ãï¼ï¼ï¼ï¼ãã¾ããæ¬çºæã¯ãç£æ§ä½ãååå å·¥ããã

ãã«ãä¸è¨ç£æ§ä½ãä¿æããç£æ§ä½ä¿æè£

ç½®ã«ããã¦ã

ä¸è¨ç£æ§ä½ãè¼ç½®ããåºå°ã¨ãä¸è¨åºå°ã«ãããä¸è¨ç£

æ§ä½å´ã®é¢ã«ç£æ°ãçºçãããç¶æ

ã¨ãä¸è¨ç£æ°ãçºç

ãããªãç¶æ

ã¨ãåãæããåæãææ®µã¨ãä¸è¨åºå°ã«

ãããä¸è¨ç£æ§ä½å´ã®é¢ã«è¨­ããããç£æ§ãå

·åããã

ã­ãã¯ã¨ãä¸è¨ãã­ãã¯ã«ãããä¸è¨ç£æ§ä½å´ã®é¢ã«è¨­

ããããä¸è¨ç£æ§ä½ã¨å½æ¥ããå½æ¥é¨ã¨ç£æ§ã¨ãå

·åã

ãç¬¬ï¼ã®çªèµ·ã¨ãä¸è¨ãã­ãã¯ã¨ä¸è¨çªèµ·ã¨ã®éã«å¼¾æ§

ãä»ä¸ããå¼¾æ§ä»ä¸ææ®µã¨ãæããä¸è¨ãã­ãã¯ã«ãã

ãä¸è¨ç£æ§ä½å´ã®é¢ããä¸è¨å½æ¥é¨ãçªåºããä¸è¨åºå°

ã«ãããä¸è¨ç£æ§ä½å´ã®é¢ã«å­å¨ããä»»æã®ï¼ç¹ã«ãã£

ã¦å½¢æãããå¹³é¢ã«å¯¾ãã¦ç¥ç´è§æ¹åã«ãä¸è¨ç¬¬ï¼ã®çª

èµ·ãç´ç·éåå¯è½ãªç£æ§ä½ä¿æè£

ç½®ã§ãããFurther, the present invention provides a magnetic material holding device for holding the above magnetic material for cutting a magnetic material.

A base on which the magnetic body is mounted; switching means for switching between a state in which magnetism is generated on the surface of the base on the magnetic body side and a state in which no magnetism is generated; and a surface of the base on the magnetic body side A first projection having magnetism, a block provided with magnetism, a contact portion provided on a surface of the block on the side of the magnetic body, which is in contact with the magnetic body, and a first projection having magnetism. And an elasticity imparting means for imparting elasticity between the magnetic body side, wherein the abutting portion protrudes from the surface on the magnetic body side of the block, and is formed by any three points present on the magnetic body side surface of the base. A magnetic body holding device in which the first protrusion is capable of linearly moving in a direction substantially perpendicular to the plane of the magnetic body.

ãï¼ï¼ï¼ï¼ãã¾ããæ¬çºæã¯ãç£æ§ä½ãååå å·¥ããã

ãã«ãä¸è¨ç£æ§ä½ãä¿æããç£æ§ä½ä¿æè£

ç½®ã«ããã¦ã

ä¸è¨ç£æ§ä½ãè¼ç½®ããåºå°ã¨ãä¸è¨åºå°ã«ãããä¸è¨ç£

æ§ä½å´ã®é¢ã«ç£æ°ãçºçãããç¶æ

ã¨ãä¸è¨ç£æ°ãçºç

ãããªãç¶æ

ã¨ãåãæããåæãææ®µã¨ãä¸è¨åºå°ã«

ãããä¸è¨ç£æ§ä½å´ã®é¢ã«è¨­ããããç£æ§ãå

·åããç¬¬

ï¼ã®çªèµ·ã¨ãä¸è¨ç£æ§ä½ã¨å½æ¥ããå½æ¥é¨ãå

·åããç£

æ§ãå

·åããä¸è¨ç¬¬ï¼ã®çªèµ·ã®å°ãªãã¨ãä¸é¨ãè¦ãç¬¬

ï¼ã®çªèµ·ã«ãã¼ã¨ãä¸è¨ç¬¬ï¼ã®çªèµ·ã¨ä¸è¨ç¬¬ï¼ã®çªèµ·ã«

ãã¼ã¨ã®éã«å¼¾æ§ãä»ä¸ããå¼¾æ§ä»ä¸ææ®µã¨ãæããä¸

è¨åºå°ã«ãããä¸è¨ç£æ§ä½å´ã®é¢ã«å¯¾ããä¸è¨ç¬¬ï¼ã®çª

èµ·ã«ãã¼ã®å½æ¥é¨ãä¸è¨ç£æ§ä½å´ã«ä½ç½®ããä¸è¨åºå°ã«

ãããä¸è¨ç£æ§ä½å´ã®é¢ã«å­å¨ããä»»æã®ï¼ç¹ã«ãã£ã¦

å½¢æãããå¹³é¢ã«å¯¾ãã¦ç¥ç´è§æ¹åã«ãä¸è¨ç¬¬ï¼ã®çªèµ·

ã«ãã¼ãç´ç·éåå¯è½ãªç£æ§ä½ä¿æè£

ç½®ã§ãããAccording to the present invention, there is provided a magnetic material holding apparatus for holding the above magnetic material for cutting the magnetic material.

A base on which the magnetic body is mounted; switching means for switching between a state in which magnetism is generated on the surface of the base on the magnetic body side and a state in which no magnetism is generated; and a surface of the base on the magnetic body side A third protrusion provided with a magnetic member, a first protrusion cover including a contact portion that comes into contact with the magnetic body, provided with magnetism, and covering at least a part of the third protrusion; An elasticity providing means for providing elasticity between the third protrusion and the first protrusion cover, wherein a contact portion of the first protrusion cover with respect to a surface of the base on the magnetic body side; Is located on the magnetic body side, and the first projection cover can linearly move in a direction substantially perpendicular to a plane formed by any three points present on the magnetic body side surface of the base. It is a holding device.

ãï¼ï¼ï¼ï¼ã[0019]

ãçºæã®å®æ½ã®å½¢æ

ããã³å®æ½ä¾ãï¼»ç¬¬ï¼ã®å®æ½ä¾ï¼½å³

ï¼ã¯ãæ¬çºæã®ç¬¬ï¼ã®å®æ½ä¾ã§ããç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³

ï¼ã®æè¦å³ã§ãããDESCRIPTION OF THE PREFERRED EMBODIMENTS [First Embodiment] FIG. 1 shows a magnetic material holding apparatus HS according to a first embodiment of the present invention.

1 is a perspective view of FIG.

ãï¼ï¼ï¼ï¼ãå³ï¼ï¼ï¼ï¼ã¯ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã®å¹³

é¢å³ã§ãããå³ï¼ï¼ï¼ï¼ã¯ãå³ï¼ï¼ï¼ï¼ã®ï¼©ï¼©ï½âï¼©ï¼©

ï½âããè¦ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã®æ­é¢å³ã§ãããFIG. 2A is a plan view of the magnetic material holding device HS1, and FIG. 2B is a diagram IIa-II of FIG.

It is sectional drawing of the magnetic material holding | maintenance apparatus HS1 seen from a '.

ãï¼ï¼ï¼ï¼ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã¯ãæ­£é¢ãã©ã¤ã¹ç¤

ç­ã®å·¥ä½æ©æ¢°ã®ãã¼ãã«ï¼´ï½ï¼ã«è¨­ãããã¦ããããã

ã¦ãç£æ§ä½ï¼ãã¨ãã°é¼ãéãé³ç©ï¼ããååå å·¥ï¼ã

ã¨ãã°æ­£é¢ãã©ã¤ã¹å å·¥ï¼ããããã«ãç£æ§ä½ä¿æè£

ç½®

ï¼¨ï¼³ï¼ã¯ãç£æ§ä½ãè£ç½®ããåºå°ï¼¨ï¼¢ï¼ã¨ããã­ãã¯ï¼¢

ï¼ã¨ãçªèµ·ï¼°ï¼´ï¼ã¨ãçªèµ·ï¼°ï¼¦ï¼ã¨ãå§ç¸®ããï¼³ï¼°ï¼ã¨

ãæãããThe magnetic material holding device HS1 is provided on a table Tb1 of a machine tool such as a face milling machine. Then, in order to perform cutting (for example, face milling) on a magnetic body (for example, steel, iron, or casting), the magnetic body holding device HS1 includes a base HB1 on which the magnetic body is placed and a block B.

1, a projection PT1, a projection PF1, and a compression spring SP1.

ãï¼ï¼ï¼ï¼ãåºå°ï¼¨ï¼¢ï¼ã«è¨­ãããã¦ããå¹³é¢ï¼¨ï¼¢ï¼ï½

ã¯ãéç£æ§ä½ã§ããã»ãã¬ã¼ã¿ï¼³ï¼¥ï¼ã«ãã£ã¦ãï¼®æ¥µã®

ç£æ°ãçºçããã¨ãªã¢ï¼®ï¼ã¨ï¼³æ¥µã®ç£æ°ãçºçããã¨ãª

ã¢ï¼³ï¼ã¨ã«åºåããã¦ãããããã¦ãç£æ°çºçã¨ãªã¢ï¼®

ï¼ãï¼³ï¼ã«ç£æ°ãçºçãããç¶æ

ã¨ãç£æ°ãçºçãããª

ãç¶æ

ã¨ãåãæãããã¨ãã§ããããã«ãªã£ã¦ãããThe plane HB1a provided on the base HB1

Is divided into an N-pole generating area N1 and an S-pole generating area S1 by a non-magnetic separator SE1. And the magnetic generation area N

1. It is possible to switch between a state in which magnetism is generated in S1 and a state in which magnetism is not generated.

ãï¼ï¼ï¼ï¼ããã­ãã¯ï¼¢ï¼ã¯ãåºå°ï¼¨ï¼¢ï¼ã®å¹³é¢ï¼ç£æ§

ä½å´ã®é¢ï¼ï¼¨ï¼¢ï¼ï½ã«è¨­ãããï¼å³ç¤ºããªããã«ãã«ã

ã£ã¦åºå°ï¼¨ï¼¢ï¼ã«åºå®ããï¼ãç£æ§ãå

·åããææï¼ã

ã¨ãã°ãéãé¼ãé³ç©ï¼ã«ãã£ã¦æ§æããã¦ãããã¾

ãããã­ãã¯ï¼¢ï¼ã¯ãçªèµ·ï¼°ï¼´ï¼ãï¼°ï¼¦ï¼ãå

¥ãè¾¼ãå­

ãå

·åãããThe block B1 is provided on a plane (magnetic body side) HB1a of the base HB1 (fixed to the base HB1 by bolts (not shown)) and is made of a material having magnetism (for example, iron, steel, casting). It is configured. The block B1 has a hole into which the protrusions PT1 and PF1 enter.

ãï¼ï¼ï¼ï¼ãçªèµ·ï¼°ï¼´ï¼ã¯ããã­ãã¯ï¼¢ï¼ãæããé¢

ï¼ç£æ§ä½å´ã®é¢ï¼ï¼¢ï¼ï½ã«è¨­ããããç£æ§ãå

·åããæ

æï¼ãã¨ãã°é¼ãéãé³ç©ï¼ã«ãã£ã¦æ§æããã¦ããã

ã¾ããçªèµ·ï¼°ï¼´ï¼ã¯ãç£æ§ä½ã¨å½æ¥ããå½æ¥é¨ï¼°ï¼´ï¼ï½

ãå

·åããé¢ï¼¢ï¼ï½ãããå½æ¥é¨ï¼°ï¼´ï¼ï½ãçªåºãã¦ã

ããã¾ããå½æ¥é¨ï¼°ï¼´ï¼ï½ã¯ãçªèµ·ï¼°ï¼´ï¼ã®ä¸é¨ã«é¢å

ãï¼°ï¼´ï¼ï½ãæ½ããã¨ã«ãã£ã¦æ§æããã¦ãããThe protrusion PT1 is provided on a surface (magnetic surface side) B1a of the block B1 and is made of a material having magnetism (for example, steel, iron, or a casting).

Further, the protrusion PT1 has a contact portion PT1a that contacts the magnetic body.

, And the contact portion PT1a protrudes from the surface B1a. Further, the contact portion PT1a is configured by performing chamfering PT1c on a part of the projection PT1.

ãï¼ï¼ï¼ï¼ãããã«ãçªèµ·ï¼°ï¼´ï¼ã¯ãå¹³é¢ï¼¨ï¼¢ï¼ï½ã«å¯¾

ãã¦ãã»ã¼ç´è§æ¹åã«ç´ç·éåã§ããããã«ãªã£ã¦ã

ããããªãã¡ãçªèµ·ï¼°ï¼´ï¼ãå

·åããåç­é¢ã¨ããã­ã

ã¯ï¼¢ï¼ã«è¨­ãããã¦ããå­ã¨ã«ãã£ã¦ã¬ã¤ããããçªèµ·

ï¼°ï¼´ï¼ããç¢å°ï¼¡ï¼²ï¼ãï¼¡ï¼²ï¼ã®æ¹åã«ç´ç·éåããã

ãã«ãªã£ã¦ãããFurther, the projection PT1 can linearly move in a direction substantially perpendicular to the plane HB1a. That is, the projection PT1 is guided by the cylindrical surface of the projection PT1 and the hole provided in the block B1, and the projection PT1 linearly moves in the directions of the arrows AR1 and AR2.

ãï¼ï¼ï¼ï¼ããªãããã­ãã¯ï¼¢ï¼ã«è¨­ãããã¦ããå­ã®

ç´å¾ã¨ãçªèµ·ï¼°ï¼´ï¼ãå

·åããåç­é¨ã®ç´å¾ã¨ã®å·®ã¯ã

ï¼ï¼Î¼ï½ãï¼ï¼ï¼Î¼ï½ç¨åº¦ã§ãããã¨ãæã¾ããããã

ã¦ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã«ç£æ§ä½ãè¼ç½®ãããç£æ°çº

çã¨ãªã¢ï¼®ï¼ãï¼³ï¼ã«ç£æ°ãçºçãããå ´åããã­ãã¯

ï¼¢ï¼ã¨çªèµ·ï¼°ï¼´ï¼ã¨ã®ä¸é¨ãæ¥è§¦ããããã«ãªã£ã¦ã

ããThe difference between the diameter of the hole provided in the block B1 and the diameter of the cylindrical portion of the projection PT1 is as follows.

It is desirable that it is about 10 Î¼m to 100 Î¼m. When a magnetic material is placed on the magnetic material holding device HS1 and magnetism is generated in the magnetism generating areas N1 and S1, a part of the block B1 and the projection PT1 come into contact with each other.

ãï¼ï¼ï¼ï¼ãããã¦ãåºå°ï¼¨ï¼¢ï¼ã¨ãç£æ°çºçã¨ãªã¢ï¼®

ï¼ã«è¨­ãããã¦ãããã­ãã¯ï¼¢ï¼ã¨ããã®ãã­ãã¯ã«ï¼¢

ï¼ã«æ¥è§¦ããçªèµ·ï¼°ï¼´ï¼ã¨ãç£æ°çºçã¨ãªã¢ï¼³ï¼è¨­ãã

ãã¦ãããã­ãã¯ï¼¢ï¼ã¨ããã®ãã­ãã¯ã«ï¼¢ï¼ã«æ¥è§¦ã

ãçªèµ·ï¼°ï¼´ï¼ã¨ãç£æ§ä½ã¨ã«ãã£ã¦ãéç£è·¯ãæ§æãã

ãããã«ãªã£ã¦ãããThen, the base HB1 and the magnetic generation area N

1 and a block B1

1, a block B1 provided with the magnetism generating area S1, a protrusion PT1 contacting the block B1 with this block, and a magnetic body constitute a closed magnetic path.

ãï¼ï¼ï¼ï¼ãã¾ãããã­ãã¯ï¼¢ï¼ã¨çªèµ·ï¼°ï¼´ï¼ã¨ã®é

ã¯ãå§ç¸®ããï¼³ï¼°ï¼ã«ãã£ã¦å¼¾æ§ãä»ä¸ããã¦ãããThe elasticity is provided between the block B1 and the projection PT1 by a compression spring SP1.

ãï¼ï¼ï¼ï¼ãããªãã¡ããã­ãã¯ï¼¢ï¼ã®å­ã®åºé¨ï¼¢ï¼ï½

ã¨çªèµ·ï¼°ï¼´ï¼ã«è¨­ãããã¦ããå­ã®åºé¨ï¼°ï¼´ï¼ï½ã¨ã®é

ã«ã¯ãå§ç¸®ããï¼³ï¼°ï¼ãè¨­ãããã¦ãããçªèµ·ï¼°ï¼´ï¼ã«

å¯¾ãã¦ãç¢å°ï¼¡ï¼²ï¼ã®æ¹åã«åãå ããã¨ãå§ç¸®ããï¼³

ï¼°ï¼ãå§ç¸®ãããçªèµ·ï¼°ï¼´ï¼ãï¼¡ï¼²ï¼ã®æ¹åã«ç§»åãã

ä¸è¨åãåãå»ãã¨ãå§ç¸®ããï¼³ï¼°ï¼ãä¼¸ã³ã¦ãã¨ã«æ»

ããçªèµ·ï¼°ï¼´ï¼ãç¢å°ï¼¡ï¼²ï¼ã®æ¹åã«ãå§ç¸®ããï¼³ï¼°ï¼

ãä¼¸ã³ããã¾ã§ãç§»åããããã«ãªã£ã¦ãããThat is, the bottom B1b of the hole of the block B1

A compression spring SP1 is provided between the projection PT1 and the bottom PT1b of the hole provided in the projection PT1, and when a force is applied to the projection PT1 in the direction of arrow AR2, the compression spring S1 is pressed.

P1 is compressed, the projection PT1 moves in the direction of AR2,

When the above-mentioned force is removed, the compression spring SP1 returns to its original state, and the projection PT1 moves in the direction of the arrow AR1.

It moves until it is fully extended.

ãï¼ï¼ï¼ï¼ããªããå§ç¸®ããï¼³ï¼°ï¼ãä¼¸ã³ãã£ãç¶æ

ã«

ããã¦ã¯ãçªèµ·ï¼°ï¼´ï¼ã®å½æ¥é¨ï¼°ï¼´ï¼ï½ã¯ãçªèµ·ï¼°ï¼¦ï¼

ã®å½æ¥é¨ï¼°ï¼¦ï¼ï½ããããå¯¸æ³ï½ï¼ã ãçªåºãã¦ãããWhen the compression spring SP1 is fully extended, the contact portion PT1a of the projection PT1 is in contact with the projection PF1.

Projecting from the contact portion PF1a by the dimension h1.

ãï¼ï¼ï¼ï¼ãçªèµ·ï¼°ï¼¦ï¼ã¯ãç£æ§ä½ã«å½æ¥ããå½æ¥é¨ï¼°

ï¼¦ï¼ï½ãå

·åãããã­ãã¯ï¼¢ï¼ãæããé¢ï¼¢ï¼ï½ã«è¨­ã

ãããé¢ï¼¢ï¼ï½ãããå½æ¥é¨ï¼°ï¼¦ï¼ï½ãçªåºãã¦ããã

ã¾ããå½æ¥é¨ï¼°ï¼¦ï¼ï½ã¯ãçªèµ·ï¼°ï¼¦ï¼ã®ä¸é¨ã«é¢åãï¼°

ï¼¦ï¼ï½ãæ½ããã¨ã«ãã£ã¦æ§æããã¦ãããThe protrusion PF1 has a contact portion P that contacts the magnetic body.

F1a is provided on the surface B1a of the block B1, and the contact portion PF1a protrudes from the surface B1a.

Further, the contact portion PF1a has a chamfer P on a part of the protrusion PF1.

It is configured by applying F1c.

ãï¼ï¼ï¼ï¼ãã¾ããçªèµ·ï¼°ï¼¦ï¼ãå

·åããããï¼°ï¼¦ï¼ï½

ã¨ãã­ãã¯ï¼¢ï¼ã®é¢ï¼¢ï¼ï½ã¨ãæ¥è§¦ããã¾ã§ãçªèµ·ï¼°ï¼¦

ï¼ã®åç­é¨ãããã­ãã¯ï¼¢ï¼ã«è¨­ãããã¦ããå­ã«å

¥ã

è¾¼ãããã«ãªã£ã¦ããããªãããã­ãã¯ï¼¢ï¼ã¨çªèµ·ï¼°ï¼¦

ï¼ã¨ã®éã«ã¯ãä¸è¨éã«å¼¾æ§ãä»ä¸ããå§ç¸®ããï¼³ï¼°ï¼

ã¯è¨­ãããã¦ããªãããããã£ã¦ãå³ï¼ï¼ï¼ï¼ã«ç¤ºãå¯¸

æ³ï½ï¼ãå¤åããªãããã«ãªã£ã¦ãããThe flange PF1d provided on the projection PF1

Until the surface and the surface B1a of the block B1 contact each other, the protrusion PF

One cylindrical portion enters a hole provided in the block B1. The block B1 and the protrusion PF

1, a compression spring SP1 for providing elasticity between the above.

Is not provided. Therefore, the dimension h2 shown in FIG. 2B does not change.

ãï¼ï¼ï¼ï¼ããªããçªèµ·ï¼°ï¼¦ï¼ã¯ãç£æ§ä½ã§æ§æããã

ãã¨ãæã¾ããããã®çç±ã¯ãç£æ°çºçã¨ãªã¢ï¼®ï¼ãï¼³

ï¼ã«ç£æ°ãçºçãããå ´åãåºå°ï¼¨ï¼¢ï¼ã¨ããã­ãã¯ï¼¢

ï¼ã¨ãçªèµ·ï¼°ï¼¦ï¼ã¨ãåºå°ã«è¼ç½®ãããç£æ§ä½ã¨ã«ãã£

ã¦ãéç£è·¯ãæ§æãããã°ãä¸è¨ç£æ§ä½ãä¿æãããã

ã®ä¿æåãå¢ããããã§ãããIt is desirable that the protrusion PF1 be made of a magnetic material. The reason is that the magnetic generation areas N1, S

When the magnetism is generated in the base 1, the base HB1 and the block B

This is because, if a closed magnetic circuit is formed by the first, the protrusion PF1, and the magnetic body mounted on the base, the holding force for holding the magnetic body increases.

ãï¼ï¼ï¼ï¼ãæ¬¡ã«ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ç­ã®åä½ã«ã¤

ãã¦èª¬æãããNext, the operation of the magnetic material holding device HS1 and the like will be described.

ãï¼ï¼ï¼ï¼ãå³ï¼ãå³ï¼ã¯ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ãç£

æ§ä½ãä¿æãããã®ä¿æãããç£æ§ä½ãååããå ´åã«

ãããä¸è¨ç£æ§ä½ã®æåç­ãç¤ºãå³ã§ãããFIGS. 3 to 5 are diagrams showing the behavior of the magnetic material when the magnetic material holding device HS1 holds the magnetic material and cuts the held magnetic material.

ãï¼ï¼ï¼ï¼ãå³ï¼ï¼ï¼ï¼ã§ã¯ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã

ç£æ§ä½ï¼·ï¼ãä¿æããåã®ç¶æ

ãç¤ºããç£æ§ä½ï¼·ï¼ã¯ã

ä¸æ´é¢ï¼·ï¼ï½ãï¼·ï¼ï½ãå

·åããããªããä¸è¨ç¶æ

ã§

ã¯ãåºå°ï¼¨ï¼¢ï¼ã«è¨­ãããã¦ããå¹³é¢ï¼¨ï¼¢ï¼ï½ã®ç£æ°çº

çã¨ãªã¢ï¼®ï¼ãï¼³ï¼ã«ã¯ç£æ°ãçºçãã¦ããªããFIG. 3A shows a state before the magnetic material holding device HS1 holds the magnetic material W1. The magnetic body W1 is

It has irregular surfaces W1a and W1b. In this state, no magnetism is generated in the magnetism generating areas N1 and S1 of the plane HB1a provided on the base HB1.

ãï¼ï¼ï¼ï¼ãå³ï¼ï¼ï¼ï¼ã§ã¯ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼

ããç£æ§ä½ï¼·ï¼ãä¿æããç£æ§ä½ï¼·ï¼ãå å·¥ï¼æ­£é¢ãã©

ã¤ã¹å å·¥ï¼ããã«ãã¿ã¼ï¼£ï¼´ï¼ããç£æ§ä½ï¼·ï¼ãååã

ãåã®ç¶æ

ãç¤ºããå³ï¼ï¼ï¼ï¼ã«ç¤ºãç¶æ

ãããç£æ§ä½

ï¼·ï¼ããç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã®æ¹åã«ãä¸æ´é¢ï¼·ï¼ï½

ãå½æ¥é¨ï¼°ï¼¦ï¼ï½ã«æ¥è§¦ããã¾ã§ç§»åããããã®ç§»åé

ç¨ã§ãå¯¸æ³ï½ï¼ã ãçªåºãã¦ããå½æ¥é¨ï¼°ï¼´ï¼ï½ã«ä¸æ´

é¢ï¼·ï¼ï½ãæ¥è§¦ããæ¥è§¦ããã¾ã¾ãçªèµ·ï¼°ï¼´ï¼ã¯ç´ç·é

åãããã®éåã«ãã£ã¦å§ç¸®ããï¼³ï¼°ï¼ãç¸®ããIn FIG. 3 (2), the magnetic material holding device HS1

Shows the state before the cutter CT1 holding the magnetic body W1 and processing the magnetic body W1 (front milling) cuts the magnetic body W1. From the state shown in FIG. 3A, the magnetic material W1 is moved in the direction of the magnetic material holding device HS1 to the irregular surface W1b.

Moves until it contacts the contact part PF1a. In this movement process, the irregular surface W1b comes into contact with the contact portion PT1a projecting by the dimension h1, and the projection PT1 linearly moves while being in contact with the contact portion PT1a, and the compression spring SP1 is contracted by this movement.

ãï¼ï¼ï¼ï¼ãä¸æ´é¢ï¼·ï¼ï½ãï¼ã¤ã®çªèµ·ï¼°ï¼¦ï¼ã®å½æ¥é¨

ï¼°ï¼¦ï¼ï½ã«æ¥è§¦ããã¨ãç£æ§ä½ï¼·ï¼ã®ç§»åãæ­¢ã¾ããã

ã®ç§»åãæ­¢ã¾ã£ãç¶æ

ã«ããã¦ãå§ç¸®ããï¼³ï¼°ï¼ã®å¼¾æ§

ã«ãã£ã¦ãä¸æ´é¢ï¼·ï¼ï½ã¨çªèµ·ï¼°ï¼´ï¼ã®å½æ¥é¨ï¼°ï¼´ï¼ï½

ã¨ãæ¥è§¦ãã¦ããããªãããï¼ã¤ã®çªèµ·ï¼°ï¼¦ï¼ãã¨ãã

ã®ã¯ãï¼ã¤ã®çªèµ·ï¼°ï¼¦ï¼ã®å½æ¥é¨ï¼°ï¼¦ï¼ï½ã®ããããã

æããï¼ç¹ã«ãã£ã¦ãç£æ§ä½ï¼·ï¼ã®ä½ç½®ãå®ã¾ãããã§

ãããWhen the irregular surface W1b contacts the contact portion PF1a of the three projections PF1, the movement of the magnetic body W1 stops. In a state where the movement is stopped, the contact portion PT1a between the irregular surface W1b and the projection PT1 is formed by the elasticity of the compression spring SP1.

Is in contact with The reason why the three projections PF1 are used is that the position of the magnetic body W1 is determined by three points of each of the contact portions PF3a of the three projections PF1.

ãï¼ï¼ï¼ï¼ãã¾ããå§ç¸®ããï¼³ï¼°ï¼ã«ãã£ã¦ãçªèµ·ï¼°ï¼´

ï¼ããç£æ§ä½ï¼·ï¼ããåºå°ï¼¨ï¼¢ï¼ã®å¹³é¢ï¼¨ï¼¢ï¼ï½ããé¢

ãæ¹åã«æã¡ä¸ããããã«ãªã£ã¦ããããç£æ§ä½ï¼·ï¼ã®

ééï¼ç£æ§ä½ï¼·ï¼ã®è³ªéã¨éåå éåº¦ã¨ã®ç©ï¼ããå§ç¸®

ããï¼³ï¼°ï¼ãçºçããåãããå¤§ããã®ã§ãç£æ§ä½ï¼·ï¼

ã¯æã¡ããããªããThe compression spring SP1 causes the protrusion PT

1 lifts the magnetic body W1 in a direction away from the plane HB1a of the base HB1, but the weight of the magnetic body W1 (the product of the mass of the magnetic body W1 and the gravitational acceleration) is reduced by the compression spring SP1. Since the force is larger than the generated force, the magnetic material W1

Does not go up.

ãï¼ï¼ï¼ï¼ãç¶ãã¦ãå¹³é¢ï¼¨ï¼¢ï¼ï½ã«è¨­ãããã¦ããç£

æ°çºçã¨ãªã¢ï¼®ï¼ãï¼³ï¼ã«ç£æ°ãçºçãããã¨ãç£æ°çº

çã¨ãªã¢ï¼®ï¼ãï¼®æ¥µã«ãªããç£æ°çºçã¨ã¢ãªã¢ï¼³ï¼ãï¼³

æ¥µã«ãªããï¼®æ¥µã¨ï¼³æ¥µã¨ã®éã«ç£æï¼·ï½ï¼ãçãããã®

ç£æï¼·ï½ï¼ãããã­ãã¯ï¼¢ï¼ãçªèµ·ï¼°ï¼´ï¼ãï¼°ï¼¦ï¼ãç£

æ§ä½ï¼·ï¼ãè²«ããããã¦ããã®ç£æï¼·ï½ï¼ãã£ã¦ãç£æ§

ä½ï¼·ï¼ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã«ä¿æããããSubsequently, when the magnetism is generated in the magnetism generating areas N1 and S1 provided on the plane HB1a, the magnetism generating area N1 becomes the N pole and the magnetism generating area S1 becomes the S pole.

The magnetic flux Wb1 is generated between the N pole and the S pole, and the magnetic flux Wb1 penetrates the block B1, the protrusions PT1, PF1, and the magnetic body W1. The magnetic body W1 is held by the magnetic body holding device HS1 by the magnetic flux Wb1.

ãï¼ï¼ï¼ï¼ãããã¦ãå³ï¼ï¼ï¼ï¼ã«ç¤ºãããã«ãçªèµ·ï¼°

ï¼´ï¼ããä¸æ´é¢ï¼·ï¼ï½ã«ç¿ã£ã¦ç§»åããç£æ§ä½ï¼·ï¼ã®ä½

ç½®ãå®å®ãããã®å¾ã«ç£æï¼·ï½ï¼ãçºçããã®ã§ãç£æ§

ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ãç£æ§ä½ï¼·ï¼ãä¿æããå ´åãç£æ§ä½

ï¼·ï¼ã®ä¸æ´é¢ï¼·ï¼ï½ãï¼·ï¼ï½ã®å¤å½¢ãæ¥µåãããããã¨

ãã§ãããThen, as shown in FIG.

T1 moves following the irregular surface W1b, and the position of the magnetic body W1 is stabilized, and thereafter the magnetic flux Wb1 is generated. Therefore, when the magnetic body holding device HS1 holds the magnetic body W1, the irregular surface of the magnetic body W1 is formed. The deformation of W1a and W1b can be suppressed as much as possible.

ãï¼ï¼ï¼ï¼ãå³ï¼ï¼ï¼ï¼ã§ã¯ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã«

ä¿æãããç£æ§ä½ï¼·ï¼ãååå å·¥ãã¦ããç¶æ

ãç¤ºãã

ã«ãã¿ã¼ï¼£ï¼´ï¼ãç¢å°ï¼¡ï¼²ï¼ã®ããã«åè»¢ããªãããç¢

å°ï¼¡ï¼²ï¼ãç¤ºãæ¹åã«ç§»åããç£æ§ä½ï¼·ï¼ãååå å·¥ã

ã¦ããããã®ååå å·¥ã«ããã¦ãåãè¾¼ã¿éÎï½ï¼ã

ããç£æ§ä½ï¼·ï¼ãååãããååå¾ã«å¹³é¢ï¼·ï¼ï½ãç¾ã

ããFIG. 4A shows a state where the magnetic material W1 held by the magnetic material holding device HS1 is being cut.

While rotating as indicated by arrow AR3, cutter CT1 moves in the direction indicated by arrow AR4, and cuts magnetic body W1. In this cutting process, the magnetic body W1 is cut by the cutting amount Ît1, and a plane W1c appears after the cutting.

ãï¼ï¼ï¼ï¼ãå³ï¼ï¼ï¼ï¼ã§ã¯ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã«

ä¿æãããç£æ§ä½ï¼·ï¼ã®ååå å·¥ãçµäºããç´å¾ã®ç¶æ



ãç¤ºããä¸æ´é¢ï¼·ï¼ï½ã«ä»£ãã£ã¦ååå å·¥ãããå¹³é¢ï¼·

ï¼ï½ãç¾ããããªããã®ç¶æ

ã«ããã¦ãç£æï¼·ï½ï¼ã¯å­

å¨ãã¦ãããFIG. 4B shows a state immediately after the cutting of the magnetic material W1 held by the magnetic material holding device HS1 is completed. Plane W machined in place of irregular surface W1a

1c appears. Note that the magnetic flux Wb1 still exists in this state.

ãï¼ï¼ï¼ï¼ãå³ï¼ã¯ãååå å·¥ãçµäºããç£æ§ä½ï¼·ï¼

ããç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ããé¢ããç¶æ

ãç¤ºãå³ã§ã

ããFIG. 5 shows the magnetic body W1 that has been cut.

Is a diagram showing a state in which is separated from the magnetic material holding device HS1.

ãï¼ï¼ï¼ï¼ãå¹³é¢ï¼¨ï¼¢ï¼ï½ã«è¨­ãããã¦ããç£æ°çºçã¨

ãªã¢ï¼®ï¼ãï¼³ï¼ããç£æ°ãçºçããªãç¶æ

ã«ããã¨ãç£

æï¼·ï½ï¼ãç¡ããªããç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã«ããç£æ§

ä½ï¼·ï¼ã®å¸å¼åãç¡ããªããWhen no magnetism is generated from the magnetism generating areas N1 and S1 provided on the plane HB1a, the magnetic flux Wb1 disappears, and the attraction of the magnetic body W1 by the magnetic body holding device HS1 disappears.

ãï¼ï¼ï¼ï¼ãããã¦ãå³ï¼ï¼ï¼ï¼ã«ç¤ºãããã«ãç£æ§ä½

ï¼·ï¼ãå¤å½¢ãããã«ä¿æããã®ã§ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³

ï¼ã«ããå¸å¼åãé¤å»ãã¦ããå¹³é¢ï¼·ï¼ï½ã¯ãå¤å½¢ãã

ã«ã»ã¼å¹³é¢ã®ç¶æ

ãä¿ã¤ãã¨ãã§ããããªããä¸æ´é¢ï¼·

ï¼ï½ã¯ãå³ï¼ï¼ï¼ï¼ã«ããã¦ç¤ºããç¶æ

ã¨ã»ã¼åãç¶æ



ï¼é¢å½¢ç¶ã®å¤åã¯ã»ã¨ãã©ç¡ãç¶æ

ï¼ã§ãããThen, as shown in FIG. 3 (2), since the magnetic body W1 is held without being deformed, the magnetic body holding device HS

Even if the suction force by 1 is removed, the plane W1c can be kept substantially flat without being deformed. The irregular surface W

1b is substantially the same as the state shown in FIG. 3A (a state in which there is almost no change in the surface shape).

ãï¼ï¼ï¼ï¼ãå³ï¼ã¯ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã«ç£æ§ä½ã

åãä»ããç¶æ

ãç¤ºãå¹³é¢å³ã§ãããFIG. 6 is a plan view showing a state where a magnetic material is attached to the magnetic material holding device HS1.

ãï¼ï¼ï¼ï¼ãå³ï¼ï¼ï¼ï¼ã§ã¯ãç£æ§ä½ï¼·ï¼ãç£æ§ä½ä¿æ

è£

ç½®ï¼¨ï¼³ï¼ãããããå°ããå ´åãç¤ºããå³ï¼ï¼ï¼ï¼ã§

ã¯ãç£æ§ä½ï¼·ï¼ãç£æ§ä½ç£æ§ä½ï¼·ï¼ãããããã«å°ãã

å ´åãç¤ºããFIG. 6A shows a case where the magnetic material W2 is slightly smaller than the magnetic material holding device HS1, and FIG. 6B shows a case where the magnetic material W3 is smaller than the magnetic material W2. .

ãï¼ï¼ï¼ï¼ãããã¦ãç£æ§ä½ï¼·ï¼ãï¼·ï¼ã®å¤§ããã«å¾ã£

ã¦ãçªèµ·ï¼°ï¼¦ï¼ã®ä½ç½®ãå¤ãã¦ãããç£æ§ä½ï¼·ï¼ã®ãµã¤

ãºã«å¾ã£ã¦ãçªèµ·ï¼°ï¼¦ï¼ã®ä½ç½®ãå¤ããçç±ã¯ãç£æ§ä½

ä¿æè£

ç½®ï¼¨ï¼³ï¼ã«å¯¾ãã¦ãç£æ§ä½ï¼·ï¼ãï¼·ï¼ãã§ããã

ãå®å®ããç¶æ

ã§ä¿æããããã«ããããã§ãããããª

ãã¡ãç£æ§ä½ï¼·ï¼ãç£æ§ä½ï¼·ï¼ã®éå¿ã¨ãï¼ã¤ã®çªèµ·ï¼°

ï¼¦ï¼ã§å½¢æãããä¸è§å½¢ã®éå¿ã¨ãã§ããã ãä¸è´ãã

ãããã«çªèµ·ï¼°ï¼¦ï¼ã®ä½ç½®ãå¤ãããThe position of the projection PF1 is changed according to the size of the magnetic bodies W1 and W2. The reason for changing the position of the protrusion PF1 according to the size of the magnetic body W1 is to hold the magnetic bodies W2 and W3 in the magnetic body holding device HS1 in a state as stable as possible. That is, the center of gravity of the magnetic body W2 or the magnetic body W3 and the three protrusions P

The position of the projection PF1 is changed so that the center of gravity of the triangle formed by F1 matches as much as possible.

ãï¼ï¼ï¼ï¼ãããã§ãçªèµ·ï¼°ï¼¦ï¼ã¨çªèµ·ï¼°ï¼´ï¼ã¨ã¯ãã»

ã¼åä¸ç´å¾ã®åç­é¨ï¼ãã­ãã¯ï¼¢ï¼ã«è¨­ãããã¦ããå­

ã«æ¿å

¥ãããåç­é¨ï¼ãæããã®ã§ããã­ãã¯ï¼¢ï¼ã«è¨­

ããããå­ã«ãçªèµ·ï¼°ï¼¦ï¼ãï¼°ï¼´ï¼ãæãå·®ãããã ã

ã§ãçªèµ·ï¼°ï¼¦ï¼ãï¼°ï¼´ï¼ã®ä½ç½®ãç°¡åã«å¤ãããã¨ãã§

ããç£æ§ä½ã®ãµã¤ãºãå¤ãã£ãå ´åã®æ®µåããå®¹æã«ãª

ãããªããä¸è¨æãå·®ããããéã«ãå·¥å

·é¡ãç¨ããå¿

è¦ã¯ãªããHere, since the projections PF1 and PT1 have a cylindrical portion having substantially the same diameter (a cylindrical portion inserted into the hole provided in the block B1), the projection provided in the hole provided in the block B1 is provided. The positions of the protrusions PF1 and PT1 can be easily changed only by inserting and removing the PF1 and PT1, thereby facilitating the setup when the size of the magnetic material changes. In addition, it is not necessary to use tools when performing the above insertion and removal.

ãï¼ï¼ï¼ï¼ãå³ï¼ã¯ãç£æ§ä½ä¿æè£

ç½®ã«ï¼¨ï¼³ï¼ã«ã¹ãã

ãã¼ï¼³ï¼´ï¼ãè¨­ããç¶æ

ãç¤ºãå³ã§ãããFIG. 7 is a diagram showing a state in which a stopper ST1 is provided on the HS1 in the magnetic material holding device.

ãï¼ï¼ï¼ï¼ãå³ï¼ï¼ï¼ï¼ã§ã¯ãã¹ãããã¼ï¼³ï¼´ï¼ãè¨­ã

ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã®å¹³é¢å³ãè¡¨ããå³ï¼ï¼ï¼ï¼ã§

ã¯ãå³ï¼ï¼ï¼ï¼ã®ï¼¶ï¼©ï¼©ï½âï¼¶ï¼©ï¼©ï½âããè¦ãç£æ§ä½

ä¿æè£

ç½®ï¼¨ï¼³ï¼ã®æ­é¢å³ãè¡¨ããå³ï¼ï¼ï¼ï¼ã§ã¯ãå³ï¼

ï¼ï¼ï¼ã®ï¼¶ï¼©ï¼©ï½âï¼¶ï¼©ï¼©ï½âããè¦ãç£æ§ä½ä¿æè£

ç½®

ï¼¨ï¼³ï¼ã®æ­é¢å³ãè¡¨ããFIG. 7A shows a plan view of a magnetic material holding device HS1 provided with a stopper ST1, and FIG. 7B shows a magnetic material holding device viewed from VIIa-VIIa 'in FIG. 7A. FIG. 7C is a cross-sectional view of HS1, and FIG.

FIG. 7A is a cross-sectional view of the magnetic material holding device HS1 viewed from VIIb-VIIb â² of (1).

ãï¼ï¼ï¼ï¼ãã¹ãããã¼ï¼³ï¼´ï¼ã¯ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³

ï¼ã®åºå°ï¼¨ï¼¢ï¼ã®å´é¢ï¼¨ï¼¢ï¼ï½ãï¼¨ï¼¢ï¼ï½ã«åºå®ããã

ã¹ãããã¼ï¼³ï¼´ï¼ã®ä¸é¨ããç£æ§ä½ï¼·ï¼ã®å´é¢ï¼·ï¼ï½ã

ï¼·ï¼ï½

ã«æ¥ããä½ç½®ã«è¨­ãããã¦ãããThe stopper ST1 is a magnetic material holding device HS

The base HB1 is fixed to the side surfaces HB1b and HB1c of the base HB1,

Part of the stopper ST1 is a side surface W1d of the magnetic body W1,

It is provided at a position in contact with W1e.

ãï¼ï¼ï¼ï¼ãã¹ãããã¼ï¼³ï¼´ï¼ãè¨­ããçç±ã¯ãç£æ§ä½

ï¼·ï¼ã®ååä¸­ã«ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã®ä¿æåã ãã§

ã¯ãç£æ§ä½ï¼·ï¼ãä¿æã§ããªããªã£ãã¨ãã«ãç£æ§ä½ï¼·

ï¼ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ãããããªãããã«ãããã

ã§ããããããã£ã¦ãç£æ§ä½ï¼·ï¼ã®å´é¢ï¼·ï¼ï½ãï¼·ï¼ï½

ãï¼³ï¼´ï¼ã«æ¥è§¦ãããç¶æ

ã§ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã

ç£æ§ä½ï¼·ï¼ãä¿æãããã¨ãæã¾ãããThe reason for providing the stopper ST1 is that when the magnetic material W1 cannot be held by the holding force of the magnetic material holding device HS1 alone during cutting of the magnetic material W1, the magnetic material W

This is to prevent 1 from deviating from the magnetic material holding device HS1. Therefore, the side surfaces W1d, W1e of the magnetic body W1

It is desirable that the magnetic body holding device HS1 holds the magnetic body W1 in a state where the magnetic body W1 is in contact with ST1.

ãï¼ï¼ï¼ï¼ãããã¦ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ãç£æ§ä½ï¼·

ï¼ãä¿æããå ´åãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã®åºå°ï¼¨ï¼¢ï¼

ã«è¨­ãããã¦ããå¹³é¢ï¼¨ï¼¢ï¼ï½ã«å¯¾ãã¦ãçªèµ·ï¼°ï¼´ï¼ã

ã»ã¼ç´è§æ¹åã«ç§»åããã®ã§ãçªèµ·ï¼°ï¼´ï¼ãä¸è¨ç´è§æ¹

åã«ç§»åãã¦ããç£æ§ä½ï¼·ï¼ãæ¨ªæ¹åï¼ãã¨ãã°ç¢å°ï¼¡

ï¼²ï¼ãï¼¡ï¼²ï¼ãï¼¡ï¼²ï¼ãç¤ºãæ¹åï¼ã«ããããã¨ããª

ãããããã£ã¦ãç£æ§ä½ï¼·ï¼ãä¿æããå ´åãç£æ§ä½ï¼·

ï¼ãã¹ãããã¼ï¼³ï¼´ï¼ã«æ¥è§¦ããã¦ä¿æãããã¨ãå®¹æ

ã§ãããThen, the magnetic material holding device HS1 is

1, the base HB1 of the magnetic material holding device HS1

The protrusion PT1 moves in a direction substantially perpendicular to the plane HB1a provided in the magnetic member W1. Therefore, even if the protrusion PT1 moves in the perpendicular direction, the magnetic body W1 moves in the lateral direction (for example, arrow A).

R5, AR6, AR7). Therefore, when holding the magnetic body W1, the magnetic body W

It is easy to hold the contact member 1 in contact with the stopper ST1.

ãï¼ï¼ï¼ï¼ãã¾ããç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ãç£æ§ä½ï¼·ï¼

ãä¿æããå ´åãçªèµ·ï¼°ï¼´ï¼ãä¸è¨ç´è§æ¹åã«ç§»åãã¦

ããç£æ§ä½ï¼·ï¼ãæ¨ªæ¹åã«ããããã¨ããªãã®ã§ãç£æ§

ä½ï¼·ï¼ã«æ¨ªæ¹åã®ããã«å¯¾å¿ããã¦ãã«ãã¿ã¼ï¼£ï¼´ï¼ã®

ä½ç½®ãèª¿æ´ããå¿

è¦ããªããFurther, the magnetic material holding device HS1 is provided with the magnetic material W1.

Is held, the magnetic body W1 does not shift in the horizontal direction even if the projection PT1 moves in the right-angle direction. Therefore, the position of the cutter CT1 is adjusted in accordance with the horizontal shift of the magnetic substance W1. No need.

ãï¼ï¼ï¼ï¼ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã«ããã°ããã­ãã¯

ï¼¢ï¼åå£«ã®éã®æºã«ååå±ãå

¥ãè¾¼ãã§ãããã­ãã¯ï¼¢

ï¼åå£«ã®éã®æºãä¸æ¹åã«é

åããã¦ããã®ã§ãä¸è¨å

åå±ããã­ãã¯ï¼¢ï¼ã«ã²ã£ãããã«ãããä¸è¨ååå±ã

ç°¡åã«é¤å»ãããã¨ãã§ãããAccording to the magnetic material holding device HS1, even if cutting chips enter the groove between the blocks B1, the block B

Since the grooves between the chips 1 are arranged in one direction, the cutting chips are not easily caught by the block B1, and the cutting chips can be easily removed.

ãï¼ï¼ï¼ï¼ããã¨ãã°ãå§ç¸®ã¨ã¢ã¼ãããã­ãã¯ï¼¢ï¼å

å£«ã®éã®æºã«å¹ãè¾¼ãã ãã§ããã­ãã¯ï¼¢ï¼åå£«ã®éã®

æºã«å

¥ãããã ååå±ãé¤å»ãããã¨ãã§ãããFor example, only by blowing compressed air into the groove between the blocks B1, cutting chips entering the groove between the blocks B1 can be removed.

ãï¼ï¼ï¼ï¼ãã¾ããçªèµ·ï¼°ï¼´ï¼ãï¼°ï¼¦ï¼ãããã­ãã¯ï¼¢

ï¼ã®å¹³é¢ï¼¢ï¼ï½ããçªåºãã¦ãããããã®çªåºéãï¼ï¼

ï½ï½ç¨åº¦ãªã®ã§ãçªèµ·ï¼°ï¼´ï¼ãï¼°ï¼¦ï¼ã«ååå±ãã²ã£ã

ããã«ããååå±ãã²ã£ããã£ãã¨ãã¦ããå§ç¸®ã¨ã¢ã¼

ãå¹ãä»ããã ãã§ãé¤å»ã§ããããªããä¸è¨çªåºéã

ï¼ï½ï½ç¨åº¦ã¾ã§å°ãªããããã¨ãå¯è½ã§ããããã®ãã

ã«ããã¨ãååå±ããçªèµ·ï¼°ï¼´ï¼ãï¼°ï¼¦ï¼ã«ä¸å±¤ã²ã£ã

ããã«ãããªããThe projections PT1 and PF1 are connected to the block B

1 protrudes from the flat surface B1a.

Since it is about mm, the chips PT1 and PF1 are hardly caught by cutting chips, and even if the chips are caught, they can be removed only by blowing compressed air. The protrusion amount can be reduced to about 2 mm. In this case, cutting chips are less likely to be caught on the projections PT1 and PF1.

ãï¼ï¼ï¼ï¼ãã¾ããæ¢å­ã®ãã°ããããã£ãã¯ã«ããã­

ãã¯ï¼¢ï¼ãçªèµ·ï¼°ï¼´ï¼ãï¼°ï¼¦ï¼ãå§ç¸®ããï¼³ï¼°ï¼ç­ãå

ãã¤ãããã¨ã«ãã£ã¦ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ãè£½ä½ã

ããã¨ãã§ãããããªãã¡ãæ¢å­è¨­åã§ãããã°ããã

ãã£ãã¯ãä½¿ç¨ãããã®ãã°ããããã£ãã¯ã«éãã¸å­

ãå å·¥ããç­ã®ããããªä¸è¨ãã°ããããã£ãã¯ã®æ¹é

ã«ãã£ã¦ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ãå®ä¾¡ã«è£½ä½ãããã¨

ãã§ãããThe magnetic body holding device HS1 can be manufactured by attaching the block B1, the projections PT1, PF1, the compression spring SP1, and the like to an existing magnet chuck. That is, the magnetic material holding device HS1 can be manufactured at low cost by using a magnet chuck, which is an existing facility, and slightly modifying the magnet chuck, for example, by forming a female screw hole in the magnet chuck.

ãï¼ï¼ï¼ï¼ãããã«ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã«ããã°ã

çªèµ·ï¼°ï¼´ï¼ã¨ãã­ãã¯ï¼¢ï¼ã¨ã®éã«å¼¾æ§ãä»ä¸ããææ®µ

ã¨ãã¦ãæ§é ãç°¡åãªå§ç¸®ããï¼³ï¼°ï¼ãä½¿ç¨ãã¦ããã®

ã§ãé

ç®¡ãé

ç·ç­ã®ã¹ãã¼ã¹ãä¸è¦ã§ããããããã£

ã¦ãçªèµ·ï¼°ï¼´ï¼åå£«ã®ããããå°ãããããã¨ãå®¹æã«

ã§ããããã¨ãã°ãçªèµ·ï¼°ï¼´ï¼ãç´å¾ï¼ï¼ï½ï½ã®ãã³ã§

ãããªãã°ãçªèµ·ï¼°ï¼´ï¼åå£«ã®ããããï¼ï¼ï½ï½ç¨åº¦ã¾

ã§å°ãããããã¨ãã§ããã¾ãããã¨ãã°ãçªèµ·ï¼°ï¼´ï¼

ãç´å¾ï¼ï¼ï½ï½ã®ãã³ã§ãããªãã°ãçªèµ·ï¼°ï¼´ï¼åå£«ã®

ããããï¼ï¼ï½ï½ç¨åº¦ã¾ã§å°ãããããã¨ãã§ãããFurther, according to the magnetic material holding device HS1,

As a means for imparting elasticity between the projection PT1 and the block B1, the compression spring SP1 having a simple structure is used, so that no space is required for piping, wiring, and the like, and therefore, the pitch between the projections PT1 is reduced. Can be easily done. For example, if the projection PT1 is a pin having a diameter of 20 mm, the pitch between the projections PT1 can be reduced to about 25 mm.

Is a pin having a diameter of 10 mm, the pitch between the protrusions PT1 can be reduced to about 13 mm.

ãï¼ï¼ï¼ï¼ãããã¦ãçªèµ·ï¼°ï¼´ï¼åå£«ã®ããããå°ãã

ããã°ãç£æ§ä½ãæ¯ãããã¤ã³ããå¤ããªãã®ã§ãåå

å å·¥ä¸­ã®ååæµæã«ãã£ã¦çºçããç£æ§ä½ã®å¤å½¢ãå°ãª

ããããã¨ãã§ããããããã£ã¦ãç£æ§ä½ã®åã¿ãå°ã

ãç­ãåæ§ã®å°ãªãç£æ§ä½ãååå å·¥ããã¨ãã«ãä¸è¨

ç£æ§ä½ã®å¤å½¢ãæ¥µåãããããã¨ãã§ãããIf the pitch between the projections PT1 is reduced, the number of points for supporting the magnetic material increases, so that deformation of the magnetic material caused by cutting resistance during cutting can be reduced. Therefore, when cutting a magnetic material having low rigidity such as a small thickness of the magnetic material, deformation of the magnetic material can be suppressed as much as possible.

ãï¼ï¼ï¼ï¼ãï¼»ç¬¬ï¼ã®å®æ½ä¾ï¼½å³ï¼ã¯ãæ¬çºæã®ç¬¬ï¼ã®

å®æ½ä¾ã§ããç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã®æè¦å³ã§ããã[Second Embodiment] FIG. 8 is a perspective view of a magnetic material holding device HS2 according to a second embodiment of the present invention.

ãï¼ï¼ï¼ï¼ãå³ï¼ï¼ï¼ï¼ã¯ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã®å¹³

é¢å³ã§ãããå³ï¼ï¼ï¼ï¼ã¯ãå³ï¼ï¼ï¼ï¼ã®ï¼©ï¼¸ï½âï¼©ï¼¸

ï½âããè¦ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã®æ­é¢å³ã§ãããFIG. 9A is a plan view of the magnetic material holding device HS2, and FIG. 9B is a plan view of the magnetic material holding device HS2 shown in FIG. 9A.

It is sectional drawing of the magnetic material holding | maintenance apparatus HS2 seen from a '.

ãï¼ï¼ï¼ï¼ãç¬¬ï¼ã®å®æ½ä¾ã¯ãç¬¬ï¼ã®å®æ½ä¾ã«ããã¦ã

ãã­ãã¯ï¼¢ï¼ãåé¤ããçªèµ·ï¼°ï¼´ï¼ãï¼°ï¼¦ï¼ãåºå°ï¼¨ï¼¢

ï¼ã«è¨­ããä¾ã§ãããThe second embodiment is different from the first embodiment in that

The block B1 is deleted, and the protrusions PT2 and PF2 are mounted on the base HB.

2 is provided.

ãï¼ï¼ï¼ï¼ãããªãã¡ãåºå°ï¼¨ï¼¢ï¼ãæããå¹³é¢ï¼¨ï¼¢ï¼

ï½ã«ãçªèµ·ï¼°ï¼´ï¼ãè¨­ããããçªèµ·ï¼°ï¼´ï¼ã«è¨­ãããã¦

ããå½æ¥é¨ï¼°ï¼´ï¼ï½ãå¹³é¢ï¼¨ï¼¢ï¼ï½ããçªåºãã¦ããã

ããã«ãçªèµ·ï¼°ï¼´ï¼ãå¹³é¢ï¼¨ï¼¢ï¼ï½ã«å¯¾ãã¦ãã»ã¼ç´è§

æ¹åã«ç´ç·éåã§ããããã«ãªã£ã¦ãããã¾ããåºå°ï¼¨

ï¼¢ï¼ã¨çªèµ·ï¼°ï¼´ï¼ã¨ã®éã¯ãå§ç¸®ããï¼³ï¼°ï¼ã«ãã£ã¦å¼¾

æ§ãä»ä¸ããã¦ãããThat is, the plane HB2 of the base HB2

a, a projection PT2 is provided, and a contact portion PT2a provided on the projection PT2 protrudes from the plane HB2a.

Further, the projection PT2 can linearly move in a direction substantially perpendicular to the plane HB2a. Also, base H

Elasticity is provided between B2 and the projection PT2 by a compression spring SP2.

ãï¼ï¼ï¼ï¼ãã¾ããçªèµ·ï¼°ï¼¦ï¼ããåºå°ï¼¨ï¼¢ï¼ã®å¹³é¢ï¼¨

ï¼¢ï¼ï½ã«è¨­ãããã¦ãããå¹³é¢ï¼¨ï¼¢ï¼ï½ããå½æ¥é¨ï¼°ï¼¦

ï¼ãçªåºãã¦ãããThe protrusion PF2 is also provided on the plane H of the base HB2.

B2a, and a contact portion PF from the plane HB2a.

2 are protruding.

ãï¼ï¼ï¼ï¼ãããã¦ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã¯ãç£æ§ä½

ä¿æè£

ç½®ï¼¨ï¼³ï¼ã¨ã»ã¼åæ§ã®åä½ãããããã«ãªã£ã¦ã

ããThe magnetic material holding device HS2 operates almost in the same manner as the magnetic material holding device HS1.

ãï¼ï¼ï¼ï¼ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã«ããã°ããã­ãã¯

ï¼¢ï¼ãå­å¨ããªãã®ã§ãè£

ç½®èªä½ã®æ§é ãç°¡ç´ åã§ãã

è£½ä½è²»ç¨ãå®ä¾¡ã«ãããã¨ãã§ãããã¾ããåºå°ï¼¨ï¼¢ï¼

ã®å¹³é¢ï¼¨ï¼¢ï¼ï½ã«ãã­ãã¯ï¼¢ï¼ã®ãããªçªåºç©ãå­å¨ã

ããçªèµ·ï¼°ï¼´ï¼ãï¼°ï¼¦ï¼ããåºå°ï¼¨ï¼¢ï¼ã®å¹³é¢ï¼¨ï¼¢ï¼ï½

ããçªåºãã¦ããã ããªã®ã§ãååå±ã®é¤å»ãç£æ§ä½ä¿

æè£

ç½®ï¼¨ï¼³ï¼ã«æ¯ã¹ä¸å±¤å®¹æã«ãªããAccording to the magnetic material holding device HS2, since the block B1 does not exist, the structure of the device itself can be simplified,

Production costs can be reduced. In addition, base HB2

There is no protrusion such as the block B1 on the plane HB2a of the base HB2a, and the projections PT2 and PF2 are on the plane HB2a of the base HB2.

, It is easier to remove cutting chips than the magnetic material holding device HS1.

ãï¼ï¼ï¼ï¼ãï¼»ç¬¬ï¼ã®å®æ½ä¾ï¼½å³ï¼ï¼ã¯ãæ¬çºæã®ç¬¬ï¼

ã®å®æ½ä¾ã§ããç£æ§ä½ä¿æè£

ç½®ãç¤ºãæ­é¢å³ã§ããã[Third Embodiment] FIG. 10 shows a third embodiment of the present invention.

It is sectional drawing which shows the magnetic body holding apparatus which is an Example of.

ãï¼ï¼ï¼ï¼ãç¬¬ï¼ã®å®æ½ä¾ã¯ãç¬¬ï¼ã®å®æ½ä¾ã«ããã¦ã

ç£æ§ä½ï¼·ï¼ãæ®µå·®ï¼·ï¼ï½ãæããå ´åãç£æ§ä½ä¿æè£

ç½®

ãç£æ§ä½ï¼·ï¼ãä¿æããä¾ã§ãããThe third embodiment is different from the first embodiment in that

This is an example in which the magnetic body holding device holds the magnetic body W4 when the magnetic body W4 has a step W4d.

ãï¼ï¼ï¼ï¼ãå³ï¼ï¼ï¼ï¼ï¼ã«ç¤ºãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼¢ï¼

ã¯ãåºå°ï¼¨ï¼¢ï¼ã«æ®µå·®ï¼¨ï¼¢ï¼ï½ãè¨­ãããã¨ã«ãã£ã¦ã

æ®µå·®ï¼·ï¼ï½ãæããç£æ§ä½ï¼·ï¼ãä¿æãããã¾ããå³ï¼

ï¼ï¼ï¼ï¼ã«ç¤ºãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼¢ï¼ã¯ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼¢ï¼ã®å¤å½¢ä¾ã§ãããäºãã«å½¢ç¶ã®ç°ãªããã­ã¯ï¼¢

ï¼ãï¼¢ï¼ãç¨ãã¦ãæ®µå·®ï¼·ï¼ï½ãæããç£æ§ä½ï¼·ï¼ãä¿

æãããThe magnetic material holding device HB3 shown in FIG.

By providing a step HB3d on the base HB3,

The magnetic body W4 having the step W4d is held. FIG.

The magnetic material holding device HB4 shown in FIG. 0 (2) is a modified example of the magnetic material holding device HB3,

3, a magnetic body W4 having a step W4d is held by using B4.

ãï¼ï¼ï¼ï¼ããªããç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ãï¼¨ï¼³ï¼ã¯ã

ç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã¨ã»ã¼åæ§ã®åä½ãããããã«ãª

ã£ã¦ãããThe magnetic material holding devices HS3 and HS4 are

The operation is substantially the same as that of the magnetic material holding device HS1.

ãï¼ï¼ï¼ï¼ãï¼»ç¬¬ï¼ã®å®æ½ä¾ï¼½å³ï¼ï¼ã¯ãä¸è¨åç£æ§ä½

ä¿æè£

ç½®ã«ããã¦ãçªèµ·ï¼°ï¼´ï¼ãï¼°ï¼´ï¼ã®å½¢ç¶ã®å¤å½¢ä¾

ãç¤ºãå³ã§ããã[Fourth Embodiment] FIG. 11 is a view showing a modification of the shapes of the projections PT1 to PT3 in each of the magnetic material holding devices.

ãï¼ï¼ï¼ï¼ãç¬¬ï¼ã®å®æ½ä¾ã¯ãä¸è¨ç¬¬ï¼ã®å®æ½ä¾ãä¸è¨

ç¬¬ï¼ã®å®æ½ä¾ã«ããã¦ãçªèµ·ï¼°ï¼´ï¼ãï¼°ï¼´ï¼ã®å½¢ç¶ç­ã

å¤æ´ããä¾ã§ãããThe fourth embodiment is an example in which the shapes and the like of the projections PT1 to PT3 in the first to third embodiments are changed.

ãï¼ï¼ï¼ï¼ãå³ï¼ï¼ï¼ï¼ï¼ã«ããã¦ã¯ããã­ãã¯ï¼¢ï¼ã«

è¨­ãããã¦ããé¢ï¼¢ï¼ï½ã®è¿åã«ããã¹ãã·ã¼ã«ï¼¤ï¼³ï¼

ãè¨­ããååå±ãå¾®ç´°ãªã´ããããã­ãã¯ï¼¢ï¼ã¨çªèµ·ï¼°

ï¼´ï¼ã¨ãæºåããé¨åã«å

¥ãã«ããããã«ãã¦ãããå

åå±ãå¾®ç´°ãªã´ãç­ãå

¥ãã«ããããã«ãããã¨ã«ãã£

ã¦ãçªèµ·ï¼°ï¼´ï¼ãåããªããªããã¨ãé²ããã¨ãã§ã

ããIn FIG. 11A, the dust seal DS5 is provided near the surface B5a provided on the block B5.

Block B5 and projection P

T5 does not easily enter the sliding part. By making it difficult for cutting chips, fine dust and the like to enter, it is possible to prevent the protrusion PT5 from becoming immobile.

ãï¼ï¼ï¼ï¼ãã¾ãããã¹ãã·ã¼ã«ï¼¤ï¼³ï¼ãè¨­ããä»£ãã

ã«ããã¨ãã°ï¼¶ãªã³ã°ï¼ç»é²åæ¨ï¼ç­ã®ã·ã¼ãªã³ã°ãªã³

ã°ï¼³ï¼²ï¼ããè¨­ãã¦ããããInstead of providing the dust seal DS5, a sealing ring SR5 such as a V-ring (registered trademark) may be provided.

ãï¼ï¼ï¼ï¼ãå³ï¼ï¼ï¼ï¼ï¼ã«ããã¦ã¯ãçªèµ·ï¼°ï¼´ï¼ã«è¨­

ãããã¦ããå½æ¥é¨ï¼°ï¼´ï¼ï½ã®å½¢ç¶ããçé¢ã®ä¸é¨ãç¨

ãã¦æ§æããããã«ãã¦ãããIn FIG. 11B, the shape of the contact portion PT6a provided on the projection PT6 is configured using a part of the spherical surface.

ãï¼ï¼ï¼ï¼ãå³ï¼ï¼ï¼ï¼ï¼ã«ããã¦ã¯ãçªèµ·ï¼°ï¼´ï¼ã«è¨­

ãããã¦ããå½æ¥é¨ï¼°ï¼´ï¼ï½ã®é¢ç©ããæºåé¨ã®ç´å¾ï¼°

ï¼´ï¼ï½ã«ãããæ­é¢ç©ãããå°ãããã¦ãããIn FIG. 11 (3), the area of the contact portion PT7a provided on the projection PT7 is changed by the diameter P of the sliding portion.

It is smaller than the cross-sectional area at T7d.

ãï¼ï¼ï¼ï¼ããã®ããã«ãå½æ¥é¨ã®å½¢ç¶ãå¤æ´ããç£æ§

ä½ã¨çªèµ·ã¨ã®æ¥è§¦é¢ç©ãå°ãªããªãããã«ããçç±ã¯ã

ç£æ§ä½ã®ä¸æ´é¢ãçªèµ·ã®å½æ¥é¨ã«æ¥è§¦ããå ´åãä¸è¨ä¸

æ´é¢ã®å¤å½¢éãæ¥µåå°ãªãããããã§ãããThe reason why the shape of the contact portion is changed so that the contact area between the magnetic body and the projection is reduced is as follows.

This is because when the irregular surface of the magnetic material comes into contact with the contact portion of the projection, the amount of deformation of the irregular surface is reduced as much as possible.

ãï¼ï¼ï¼ï¼ããªããç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã®çªèµ·ï¼°ï¼´ï¼

ã«ãããå½æ¥é¨ï¼°ï¼´ï¼ï½ãå³ï¼ï¼ï¼ï¼ï¼ã«ç¤ºãå½æ¥é¨ï¼°

ï¼´ï¼ï½ãå³ï¼ï¼ï¼ï¼ï¼ã«ç¤ºãå½æ¥é¨ï¼°ï¼´ï¼ï½ã¯ãå¸é¢ã§

æ§æãããå½æ¥é¨ã®ä¾ã§ãããThe protrusion PT1 of the magnetic material holding device HS1

Contact portion PT1a, the contact portion P shown in FIG.

T6a, the contact portion PT7a shown in FIG. 11 (3) is an example of a contact portion formed of a convex surface.

ãï¼ï¼ï¼ï¼ãå³ï¼ï¼ï¼ï¼ï¼ã¯ãçªèµ·ï¼°ï¼´ï¼ã®æ­é¢å½¢ç¶ã

åè§å½¢ã¨ãããã®ã§ããããªããçªèµ·ã®æ­é¢å½¢ç¶ãã

åãåè§å½¢ä»¥å¤ã®å½¢ç¶ï¼ãã¨ãã°ãå

­è§å½¢ï¼ã«ãã¦ãã

ããFIG. 11 (4) shows the projection PT8 having a square cross section. The cross-sectional shape of the projection is

The shape may be a shape other than a circle and a square (for example, a hexagon).

ãï¼ï¼ï¼ï¼ãã¾ããå³ï¼ï¼ï¼ï¼ï¼ãå³ï¼ï¼ï¼ï¼ï¼ã«ãã

ã¦ç¤ºããçªèµ·ã®å½¢ç¶ã¯ãçªèµ·ï¼°ï¼¦ï¼ãï¼°ï¼¦ï¼ã«ããã¦ã

æ¡ç¨ãããã¨ãã§ãããThe projection shapes shown in FIGS. 11 (2) to 11 (4) can be adopted for the projections PF1 to PF3.

ãï¼ï¼ï¼ï¼ãä¸è¨åå®æ½ä¾ã§ã¯ãåºå°ï¼¨ï¼¢ï¼ãï¼¨ï¼¢ï¼ã«

å¹³é¢ï¼¨ï¼¢ï¼ï½ãï¼¨ï¼¢ï¼ï½ãããããè¨­ãããã¦ãããã

ãããã®å¹³é¢ï¼¨ï¼¢ï¼ï½ãï¼¨ï¼¢ï¼ï½ãå¹³é¢ã§ãªãããã¨ã

ã°å¸é¢ãå¹é¢ç­ã®æ²é¢ã§ãã£ã¦ãããããã®å ´åãä¸è¨

æ²é¢å

ã«å­å¨ããä»»æã®ï¼ç¹ã§å½¢æãããå¹³é¢ã«å¯¾ã

ã¦ãçªèµ·ï¼°ï¼´ï¼ãï¼°ï¼´ï¼ãï¼°ï¼´ï¼ãï¼°ï¼´ï¼ãã»ã¼ç´ç·é

åãããIn the above embodiments, the bases HB1 to HB4 are provided with the planes HB1a to HB4a, respectively.

These planes HB1a to HB4a are not planes, but may be curved surfaces such as convex surfaces and concave surfaces. In this case, the projections PT1 to PT3 and PT5 to PT8 make a substantially linear movement with respect to a plane formed by any three points existing in the curved surface.

ãï¼ï¼ï¼ï¼ãã¾ããä¸è¨åå®æ½ä¾ã«ããã¦ãçªèµ·ï¼°ï¼¦ï¼

ãï¼°ï¼¦ï¼ãåé¤ãã¦ãããããã®å ´åããã¨ãã°åºå°ï¼¨

ï¼¢ï¼ã®å¹³é¢ï¼¨ï¼¢ï¼ï½ã«å­å¨ããæå®ã®ï¼ã¤ã®ç¹ããä¸è¨

çªèµ·ï¼°ï¼¦ï¼ãï¼°ï¼¦ï¼ã«ä»£ãã£ã¦ä½ç¨ãããIn each of the above embodiments, the protrusion PF1

PF3 may be deleted. In this case, for example, the base H

Three predetermined points existing on the plane HB1a of B1 act instead of the protrusions PF1 to PF3.

ãï¼ï¼ï¼ï¼ãï¼»ç¬¬ï¼ã®å®æ½ä¾ï¼½å³ï¼ï¼ï¼ï¼ï¼ã¯ãç£æ§ä½

ä¿æè£

ç½®ï¼¨ï¼³ï¼ã®å¹³é¢å³ã§ãããå³ï¼ï¼ï¼ï¼ï¼ã¯ãå³ï¼

ï¼ï¼ï¼ï¼ã®ï¼¸ï¼©ï¼©ï½âï¼¸ï¼©ï¼©ï½âããè¦ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã®æ­é¢å³ã§ããã[Fifth Embodiment] FIG. 12A is a plan view of a magnetic material holding device HS5, and FIG.

It is sectional drawing of the magnetic material holding | maintenance apparatus HS5 seen from XIIa-XIIa 'of 2 (1).

ãï¼ï¼ï¼ï¼ãå³ï¼ï¼ã¯ãå³ï¼ï¼ï¼ï¼ï¼ã®ï¼¸ï¼©ï¼©ï¼©é¨ã«ã

ããç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã®é¨åæ¡å¤§å³ã§ãããFIG. 13 is a partially enlarged view of the magnetic material holding device HS5 in the portion XIII of FIG. 12 (2).

ãï¼ï¼ï¼ï¼ãç£æ§ä½ãååå å·¥ããããã«ãç£æ§ä½ãä¿

æããç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã¯ãç£æ§ä½ãè£ç½®ããåºå°

ï¼¨ï¼¢ï¼ã¨ãçªèµ·ï¼°ï¼²ï¼ã¨ãçªèµ·ã«ãã¼ï¼°ï¼£ï¼ã¨ãå§ç¸®ã

ãï¼³ï¼°ï¼ã¨ãæãããTo cut the magnetic material, the magnetic material holding device HS5 for holding the magnetic material has a base HB5 on which the magnetic material is placed, a protrusion PR1, a protrusion cover PC1, and a compression spring SP9. .

ãï¼ï¼ï¼ï¼ãåºå°ï¼¨ï¼¢ï¼ã«è¨­ãããã¦ããå¹³é¢ï¼¨ï¼¢ï¼ï½

ã¯ãéç£æ§ä½ã§ããã»ãã¬ã¼ã¿ï¼³ï¼¥ï¼ã«ãã£ã¦ãï¼®æ¥µã®

ç£æ°ãçºçããã¨ãªã¢ï¼®ï¼ã¨ï¼³æ¥µã®ç£æ°ãçºçããã¨ãª

ã¢ï¼³ï¼ã¨ã«åºåããã¦ãããããã¦ãç£æ°çºçã¨ãªã¢ï¼®

ï¼ãï¼³ï¼ã«ç£æ°ãçºçãããç¶æ

ã¨ãç£æ°ãçºçãããª

ãç¶æ

ã¨ãåãæãããã¨ãã§ããããã«ãªã£ã¦ãããA plane HB5a provided on the base HB5

Is divided by a separator SE3, which is a non-magnetic material, into an area N3 for generating N-pole magnetism and an area S3 for generating S-pole magnetism. And the magnetic generation area N

3. A state in which magnetism is generated in S3 and a state in which magnetism is not generated can be switched.

ãï¼ï¼ï¼ï¼ãçªèµ·ï¼°ï¼²ï¼ã¯ãåºå°ï¼¨ï¼¢ï¼ã«è¨­ãããã¦ã

ãå¹³é¢ï¼ç£æ§ä½å´ã®é¢ï¼ï¼¨ï¼¢ï¼ï½ã«è¨­ããããç£æ§ãå

·

åããææï¼ãã¨ãã°é¼ãéãé³ç©ï¼ã«ãã£ã¦æ§æãã

ã¦ããããªããçªèµ·ï¼°ï¼²ï¼ã¯ããã«ãï¼å³ç¤ºããï¼ã«ã

ã£ã¦ãåºå°ï¼¨ï¼¢ï¼ã«åºå®ããã¦ãããã¾ããç£æ§ä½ä¿æ

è£

ç½®ï¼¨ï¼³ï¼ã«ããã¦ã¯ãåºå°ï¼¨ï¼¢ï¼ã«ãç´æ¥ãçªèµ·ï¼°ï¼²

ï¼ãè¨­ãã¦ããããåºå°ï¼¨ï¼¢ï¼ã¨çªèµ·ï¼°ï¼²ï¼ã¨ã®éã«ã

ãã­ãã¯ï¼å³ç¤ºããï¼ãè¨­ãã¦ããããããªãã¡ãçªèµ·

ï¼°ï¼²ï¼ãä¸è¨ãã­ãã¯ã«åºå®ãããã®ãã­ãã¯ãåºå°ï¼¨

ï¼¢ï¼ã«è¨­ãããã¦ããå¹³é¢ï¼¨ï¼¢ï¼ï½ã«åºå®ããããã«ã

ã¦ããããThe projection PR1 is provided on a plane (surface on the magnetic body side) HB5a provided on the base HB5, and is made of a material having magnetism (for example, steel, iron, or casting). The projection PR1 is fixed to the base HB5 by a bolt (not shown). In the magnetic material holding device HS5, the protrusion PR is directly attached to the base HB5.

1 is provided between the base HB5 and the protrusion PR1.

Blocks (not shown) may be provided. That is, the protrusion PR1 is fixed to the block, and this block is

You may make it fix to the plane HB5a provided in B5.

ãï¼ï¼ï¼ï¼ãçªèµ·ã«ãã¼ï¼°ï¼£ï¼ã¯ãç£æ§ãå

·åããçªèµ·

ï¼°ï¼²ï¼ã®å°ãªãã¨ãä¸é¨ãè¦ããç£æ§ä½ã¨å½æ¥ããå½æ¥

é¨ï¼°ï¼£ï¼ï½ãå

·åãããããã¦ãå¹³é¢ï¼¨ï¼¢ï¼ï½ã«å¯¾ãã

å½æ¥é¨ï¼°ï¼£ï¼ï½ãä¸è¨ç£æ§ä½å´ã«ä½ç½®ãã¦ãããã¾ãã

å½æ¥é¨ï¼°ï¼£ï¼ï½ã¯ãçªèµ·ã«ãã¼ï¼°ï¼£ï¼ã®ä¸é¨ã«é¢åãï¼°

ï¼£ï¼ï½ãæ½ããã¨ã«ãã£ã¦æ§æããã¦ãããThe protrusion cover PC1 has magnetism, covers at least a part of the protrusion PR1, and has a contact portion PC1a that comes into contact with the magnetic material. And, with respect to the plane HB5a,

The contact portion PC1a is located on the magnetic body side. Also,

The contact portion PC1a has a chamfer P on a part of the projection cover PC1.

It is configured by applying C1c.

ãï¼ï¼ï¼ï¼ãããã«ãçªèµ·ã«ãã¼ï¼°ï¼£ï¼ã¯ãå¹³é¢ï¼¨ï¼¢ï¼

ï½ã«å¯¾ãã¦ãã»ã¼ç´è§æ¹åã«ç´ç·éåã§ããããã«ãªã£

ã¦ãããããªãã¡ãçªèµ·ï¼°ï¼²ï¼ãå

·åããåç­é¢ã¨ãçª

èµ·ã«ãã¼ï¼°ï¼£ï¼ã«è¨­ãããã¦ããå­ã¨ã«ãã£ã¦ã¬ã¤ãã

ããçªèµ·ã«ãã¼ï¼°ï¼£ï¼ããç¢å°ï¼¡ï¼²ï¼ãï¼¡ï¼²ï¼ã®æ¹åã«

ç´ç·éåããããã«ãªã£ã¦ãããFurther, the projection cover PC1 is provided with a flat surface HB5.

It can be moved linearly in a direction substantially perpendicular to a. That is, the projection PR1 is guided by the cylindrical surface of the projection PR1 and the hole provided in the projection cover PC1, and the projection cover PC1 linearly moves in the directions of arrows AR8 and AR9.

ãï¼ï¼ï¼ï¼ããªããçªèµ·ã«ãã¼ï¼°ï¼£ï¼ã«è¨­ãããã¦ãã

å­ã®ç´å¾ã¨ãçªèµ·ï¼°ï¼²ï¼ãå

·åããåç­é¨ã®ç´å¾ã¨ã®å·®

ã¯ãï¼ï¼Î¼ï½ãï¼ï¼ï¼Î¼ï½ç¨åº¦ã§ãããã¨ãæã¾ããã

ããã¦ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã«ç£æ§ä½ãè¼ç½®ãããç£

æ°çºçã¨ãªã¢ï¼®ï¼ãï¼³ï¼ã«ç£æ°ãçºçãããå ´åãçªèµ·

ï¼°ï¼²ï¼ã¨çªèµ·ã«ãã¼ï¼°ï¼£ï¼ã¨ã®ä¸é¨ãæ¥è§¦ããããã«ãª

ã£ã¦ãããIt is preferable that the difference between the diameter of the hole provided in the projection cover PC1 and the diameter of the cylindrical portion of the projection PR1 is about 10 Î¼m to 100 Î¼m.

When a magnetic material is placed on the magnetic material holding device HS5 and magnetism is generated in the magnetism generating areas N3 and S3, the protrusion PR1 and a part of the protrusion cover PC1 come into contact with each other.

ãï¼ï¼ï¼ï¼ãããã¦ãåºå°ï¼¨ï¼¢ï¼ã¨ãç£æ°çºçã¨ãªã¢ï¼®

ï¼ã«è¨­ãããã¦ããçªèµ·ï¼°ï¼²ï¼ã¨ããã®çªèµ·ï¼°ï¼²ï¼ã«æ¥

è§¦ããçªèµ·ã«ãã¼ï¼°ï¼£ï¼ã¨ãç£æ°çºçã¨ãªã¢ï¼³ï¼è¨­ãã

ãã¦ããçªèµ·ï¼°ï¼²ï¼ã¨ããã®çªèµ·ï¼°ï¼²ï¼ã«æ¥è§¦ããçªèµ·

ã«ãã¼ï¼°ï¼£ï¼ã¨ãç£æ§ä½ã¨ã«ãã£ã¦ãéç£è·¯ãæ§æãã

ãããã«ãªã£ã¦ãããThen, the base HB5 and the magnetic generation area N

3, a projection cover PC1 contacting the projection PR1, a projection PR3 provided on the magnetism generating area S3, a projection cover PC1 contacting the projection PR1, and a magnetic material. A road is to be constructed.

ãï¼ï¼ï¼ï¼ãã¾ããçªèµ·ï¼°ï¼²ï¼ã¨çªèµ·ã«ãã¼ï¼°ï¼£ï¼ã¨ã®

éã¯ãå§ç¸®ããï¼³ï¼°ï¼ã«ãã£ã¦å¼¾æ§ãä»ä¸ããã¦ãããThe elasticity is provided between the projection PR1 and the projection cover PC1 by a compression spring SP9.

ãï¼ï¼ï¼ï¼ãããªãã¡ãçªèµ·ï¼°ï¼²ï¼ã«è¨­ãããã¦ããåº

é¨ï¼°ï¼²ï¼ï½ã¨çªèµ·ã«ãã¼ï¼°ï¼£ï¼ã«è¨­ãããã¦ããå­ã®åº

é¨ï¼°ï¼£ï¼ï½ã¨ã®éã«ã¯ãå§ç¸®ããï¼³ï¼°ï¼ãè¨­ãããã¦ã

ããçªèµ·ã«ãã¼ï¼°ï¼£ï¼ã«å¯¾ãã¦ãç¢å°ï¼¡ï¼²ï¼ã®æ¹åã«å

ãå ããã¨ãå§ç¸®ããï¼³ï¼°ï¼ãå§ç¸®ãããçªèµ·ã«ãã¼ï¼°

ï¼£ï¼ãï¼¡ï¼²ï¼ã®æ¹åã«ç§»åããä¸è¨åãåãå»ãã¨ãå§

ç¸®ããï¼³ï¼°ï¼ãä¼¸ã³ã¦ãã¨ã«æ»ããçªèµ·ã«ãã¼ï¼°ï¼£ï¼ã

ç¢å°ï¼¡ï¼²ï¼ã®æ¹åã«ãå§ç¸®ããï¼³ï¼°ï¼ãä¼¸ã³ããã¾ã§ã

ç§»åããããã«ãªã£ã¦ãããThat is, a compression spring SP9 is provided between the bottom portion PR1b provided on the projection PR1 and the bottom portion PC1b of the hole provided on the projection cover PC1, and the compression spring SP9 is provided on the projection cover PC1 with an arrow. When a force is applied in the direction of AR9, the compression spring SP9 is compressed, and the projection cover P

When C1 moves in the direction of AR9 and removes the above-mentioned force, the compression spring SP9 expands and returns to its original state, and the projection cover PC1 moves in the direction of arrow AR8 until the compression spring SP9 extends completely.

It is designed to move.

ãï¼ï¼ï¼ï¼ããªããå§ç¸®ããï¼³ï¼°ï¼ãä¼¸ã³ãã£ãç¶æ

ã«

ããã¦ã¯ãçªèµ·ã«ãã¼ï¼°ï¼£ï¼ã®å½æ¥é¨ï¼°ï¼£ï¼ï½ã¯ãçªèµ·

ï¼°ï¼£ï¼ã®å½æ¥é¨ï¼°ï¼£ï¼ï½ããããæå®ã®å¯¸æ³ã ãçªåºã

ã¦ãããWhen the compression spring SP9 is fully extended, the contact portion PC1a of the projection cover PC1 protrudes by a predetermined dimension from the contact portion PC2a of the projection PC2.

ãï¼ï¼ï¼ï¼ãçªèµ·ã«ãã¼ï¼°ï¼£ï¼ã¯ãç£æ§ä½ã«å½æ¥ããå½

æ¥é¨ï¼°ï¼£ï¼ï½ãå

·åããåºå°ï¼¨ï¼¢ï¼ã«è¨­ãããã¦ããå¹³

é¢ï¼¨ï¼¢ï¼ï½ã«å¯¾ããå½æ¥é¨ï¼°ï¼£ï¼ï½ãä¸è¨ç£æ§ä½å´ã«ä½

ç½®ãã¦ãããã¾ããå½æ¥é¨ï¼°ï¼£ï¼ï½ã¯ãçªèµ·ã«ãã¼ï¼°ï¼£

ï¼ã®ä¸é¨ã«é¢åãï¼°ï¼£ï¼ï½ãæ½ããã¨ã«ãã£ã¦æ§æãã

ã¦ãããThe projection cover PC2 has a contact portion PC2a that contacts the magnetic material, and the contact portion PC2a is located on the magnetic material side with respect to the plane HB5a provided on the base HB5. Further, the contact portion PC2a is provided with a projection cover PC.

2 is provided with a chamfered PC 2c.

ãï¼ï¼ï¼ï¼ãã¾ããçªèµ·ã«ãã¼ï¼°ï¼£ï¼ãå

·åããç«¯é¨ï¼°

ï¼£ï¼ï½ã¨å¹³é¢ï¼¨ï¼¢ï¼ï½ã¨ãæ¥è§¦ããã¾ã§ãçªèµ·ã«ãã¼ï¼°

ï¼£ï¼ããçªèµ·ï¼°ï¼²ï¼ãè¦ãããã«ãªã£ã¦ããããªããçª

èµ·ï¼°ï¼²ï¼ã¨çªèµ·ã«ãã¼ï¼°ï¼£ï¼ã¨ã®éã«ã¯ãå¼¾æ§ãä»ä¸ã

ãå§ç¸®ããï¼³ï¼°ï¼ã¯è¨­ãããã¦ããªãããããã£ã¦ãå½

æ¥é¨ï¼°ï¼£ï¼ï½ã¨å¹³é¢ï¼¨ï¼¢ï¼ï½ã¨ã®éã®å¯¸æ³ãå¤åããªã

ããã«ãªã£ã¦ãããThe end P of the projection cover PC2 is provided.

Until C2d contacts the plane HB5a, the projection cover P

C2 covers the projection PR1. Note that no compression spring SP9 for providing elasticity is provided between the protrusion PR1 and the protrusion cover PC2. Therefore, the dimension between the contact portion PC2a and the plane HB5a does not change.

ãï¼ï¼ï¼ï¼ãã¾ããçªèµ·ã«ãã¼ï¼°ï¼£ï¼ã¯ãç£æ§ä½ã§æ§æ

ããããã¨ãæã¾ããããã®çç±ã¯ãç£æ°çºçã¨ãªã¢ï¼®

ï¼ãï¼³ï¼ã«ç£æ°ãçºçãããå ´åãåºå°ï¼¨ï¼¢ï¼ã¨ãçªèµ·

ï¼°ï¼²ï¼ã¨ãçªèµ·ã«ãã¼ï¼°ï¼£ï¼ã¨ãåºå°ã«è¼ç½®ããããç£

æ§ä½ã¨ã«ãã£ã¦ãéç£è·¯ãæ§æãããã°ãä¸è¨ç£æ§ä½ã

ä¿æããããã®ä¿æåãå¢ããããã§ãããIt is desirable that the projection cover PC2 be made of a magnetic material. The reason is that the magnetic generation area N

3. When magnetism is generated in S3, if the base HB5, the projection PR1, the projection cover PC2, and the magnetic body placed on the base constitute a closed magnetic circuit, the magnetic body is held. This is because the holding force for performing the operation increases.

ãï¼ï¼ï¼ï¼ãããã¦ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã¯ãç£æ§ä½

ä¿æè£

ç½®ï¼¨ï¼³ï¼ã¨ã»ã¼åæ§ã®åä½ãããããã«ãªã£ã¦ã

ããThe magnetic material holding device HS5 operates substantially the same as the magnetic material holding device HS1.

ãï¼ï¼ï¼ï¼ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã«ããã°ãå½æ¥é¨ï¼°

ï¼£ï¼ï½ãï¼°ï¼£ï¼ï½ãä¸å´ï¼å¹³é¢ï¼¨ï¼¢ï¼ï½ã«å¯¾ãã¦ç£æ§ä½

ã®æ¹åã§ããç¢å°ï¼¡ï¼²ï¼ã®æ¹åãä¸å´ï¼ã«ããåºå°ï¼¨ï¼¢

ï¼å´ãä¸å´ï¼ç£æ§ä½ã«å¯¾ãã¦å¹³é¢ï¼¨ï¼¢ï¼ï½ã®æ¹åã§ãã

ç¢å°ï¼¡ï¼²ï¼ã®æ¹åãä¸å´ï¼ã«ãã¦ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³

ï¼ãä½¿ç¨ããå ´åãçªèµ·ï¼°ï¼²ï¼ã«çªèµ·ã«ãã¼ï¼°ï¼£ï¼ãï¼°

ï¼£ï¼ããã¶ãã£ã¦ããã®ã§ãååå±ãå¾®ç´°ãªã´ãããæº

åé¨ï¼³ï¼¬ï¼ã«å

¥ãã«ãããAccording to the magnetic material holding device HS5, the contact portion P

C1a, PC2a are set to the upper side (the direction of the arrow AR8, which is the direction of the magnetic body with respect to the plane HB5a, is set to the upper side), and the base HB is set.

5 side (the direction of the arrow AR9 which is the direction of the plane HB5a with respect to the magnetic body is the lower side), and the magnetic body holding device HS

5, when the projection PR1 is used, the projection covers PC1, P

Since C2 is covered, cutting chips and fine dust are less likely to enter the sliding portion SL1.

ãï¼ï¼ï¼ï¼ããªããç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼¢ï¼ã«ããã¦ãæº

åé¨ï¼³ï¼¬ï¼ã«ååå±ãå¾®ç´°ãªã´ããå

¥ãã«ããããã«ã

ãããã«ãçªèµ·ï¼°ï¼²ï¼ã¨çªèµ·ã«ãã¼ï¼°ï¼£ï¼ã¨ã®éã«ãã¹

ãã·ã¼ã«ã¾ãã¯ã·ã¼ãªã³ã°ãªã³ã°ãè¨­ãã¦ããããIn the magnetic material holding device HB5, a dust seal or a sealing ring may be provided between the projection PR1 and the projection cover PC1 in order to prevent cutting chips and fine dust from entering the sliding portion SL1. Good.

ãï¼ï¼ï¼ï¼ãã¾ããå½æ¥é¨ï¼°ï¼£ï¼ï½ãï¼°ï¼£ï¼ï½ã®å½¢ç¶ã¨

ãã¦ãå³ï¼ï¼ï¼ï¼ï¼ãï¼ï¼ï¼ã«ç¤ºããããªå½¢ç¶ï¼ãã¨ã

ã°çé¢ã®ä¸é¨ãç¨ããå½¢ç¶ï¼ãæ¡ç¨ãã¦ããããThe shapes of the contact portions PC1a and PC2a may be as shown in FIGS. 11 (2) to 11 (4) (for example, a shape using a part of a spherical surface).

ãï¼ï¼ï¼ï¼ãã¾ããçªèµ·ï¼°ï¼²ï¼ã®æ­é¢å½¢ç¶ããå³ï¼ï¼

ï¼ï¼ï¼ã«ç¤ºãããã«ãåè§å½¢ã¨ãã¦ããããã¾ããåè§

å½¢ä»¥å¤ã®å½¢ç¶ï¼ãã¨ãã°å

­è§å½¢ï¼ã¨ãã¦ãããããã

ã«ãä¸è¨æ­é¢å½¢ç¶ã«åããã¦ãçªèµ·ã«ãã¼ï¼°ï¼£ï¼ãï¼°ï¼£

ï¼ã«è¨­ãããã¦ããå­ï¼ä¸è¨çªèµ·ã¨åµåããå­ï¼ã®æ­é¢

å½¢ç¶ãå¤ãããã¨ã«ãªããããã«ãçªèµ·ã«ãã¼ï¼°ï¼£ï¼ã

ï¼°ï¼£ï¼ã®å¤å½¢ã®æ­é¢å½¢ç¶ããåè§å½¢ãå

­è§å½¢ç­ãæ¡ç¨ã

ããã¨ãã§ãããThe sectional shape of the projection PR1 is shown in FIG.

As shown in (4), it may be rectangular. Further, the shape may be a shape other than a square (for example, a hexagon). Further, the projection covers PC1, PC

The cross-sectional shape of the hole provided in 2 (the hole fitted with the protrusion) also changes. Further, the projection cover PC1,

The cross section of the outer shape of the PC 2 may be a square, a hexagon, or the like.

ãï¼ï¼ï¼ï¼ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã§ã¯ãåºå°ï¼¨ï¼¢ï¼ã«

å¹³é¢ï¼¨ï¼¢ï¼ï½ãè¨­ãããã¦ãããããã®å¹³é¢ï¼¨ï¼¢ï¼ï½ã

å¹³é¢ã§ãªãããã¨ãã°å¸é¢ãå¹é¢ç­ã®æ²é¢ã§ãã£ã¦ãã

ãããã®å ´åãä¸è¨æ²é¢å

ã«å­å¨ããä»»æã®ï¼ç¹ã§å½¢æ

ãããå¹³é¢ã«å¯¾ãã¦ãçªèµ·ã«ãã¼ï¼°ï¼£ï¼ãã»ã¼ç´ç·éå

ãããIn the magnetic material holding device HS5, the base HB5 is provided with the flat surface HB5a, but the flat surface HB5a is not limited to a flat surface, and may be a curved surface such as a convex surface or a concave surface. In this case, the projection cover PC1 makes a substantially linear motion with respect to a plane formed by any three points existing in the curved surface.

ãï¼ï¼ï¼ï¼ãã¾ããç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã«ããã¦ãçª

èµ·ã«ãã¼ï¼°ï¼£ï¼ãåé¤ãã¦ãããããã®å ´åãçªèµ·ã«ã

ã¼ï¼°ï¼£ï¼ã®ã¿ã§ç£æ§ä½ãæ¯ãããIn the magnetic material holding device HS5, the projection cover PC2 may be omitted. In this case, the magnetic body is supported only by the projection cover PC1.

ãï¼ï¼ï¼ï¼ãä¸è¨åå®æ½ä¾ã«ããã¦ãå§ç¸®ããï¼³ï¼°ï¼ã

ï¼³ï¼°ï¼ãï¼³ï¼°ï¼ãï¼³ï¼°ï¼ã¯ããã­ãã¯ãåºå°ã¨çªèµ·ã®é

ã«å¼¾æ§ãä»ä¸ããå¼¾æ§ä½ã®ä¾ã§ãããå§ç¸®ããã®ä»£ãã

ã«ãã¨ã¢ã¼ãæ¿ãããã´ã ç­ãæ¡ç¨ãããã¨ãã§ãããIn each of the above embodiments, the compression springs SP1 to SP1 are used.

SP3, SP5 to SP9 are examples of an elastic body that imparts elasticity between the block, the base, and the projection, and air, a leaf spring, rubber, or the like can be used instead of the compression spring.

ãï¼ï¼ï¼ï¼ãä¸è¨åå®æ½ä¾ã«ããã¦ãåºå°ã«ãããç£æ§

ä½å´ã®é¢ã«ç£æ°ãçºçãããç¶æ

ã¨ãç£æ°ãçºçãããª

ãç¶æ

ã¨ãåãæããå ´åãé»ç£ãã°ããããæ°¸é»ç£ã

ã°ããããæ©æ¢°å¼ã«ç£æ°ã®çºçããªã³ãªããããã°ãã

ããç¨ãããã¨ãã§ãããIn each of the above embodiments, when switching between a state in which magnetism is generated on the surface of the base on the side of the magnetic body and a state in which magnetism is not generated, an electromagnetic magnet, a permanent electromagnetic magnet, and mechanical generation of magnetism are turned on and off. A magnet can be used.

ãï¼ï¼ï¼ï¼ããªããä¸è¨æ°¸é»ç£ãã°ãããã¨ã¯ãéé»æ

ç£æ°ãçºçããããééé»æã«ç£æ°ãçºçãããã°ãã

ããã¾ãã¯ãï¼ã¤ã®ãã«ã¹é»æµãæµããã¨ã«ãã£ã¦ãç£

æ°ãçºçããç¶æ

ãä¿æããæ¬¡ã®ï¼ã¤ã®ãã«ã¹é»æµãæµ

ããã¨ã«ãã£ã¦ãç£æ°ãçºçãããªãç¶æ

ãä¿æããã

ãã«åãæãããã¨ãã§ãããã°ãããã§ãããThe permanent electromagnetic magnet is a magnet that does not generate magnetism when energized and generates magnetism when not energized, or maintains a state where magnetism is generated by passing one pulse current. Is a magnet that can be switched to maintain a state in which no magnetism is generated by passing one pulse current.

ãï¼ï¼ï¼ï¼ãä¸è¨åå®æ½ä¾ã§ã¯ãç£æ§ä½ã®æããä¸æ´é¢

ãä½¿ã£ã¦ä¿æããå ´åã«ã¤ãã¦èª¬æããããå¹³é¢ä¿æã

ãå ´åã«ãä¸è¨åå®æ½ä¾ãé©ç¨ãããã¨ãã§ãããIn each of the above embodiments, the case where the magnetic material is held by using the irregular surface has been described. However, the above embodiments can also be applied to the case where the magnetic material is held in a plane.

ãï¼ï¼ï¼ï¼ãä¸è¨åå®æ½ä¾ã¯ãæ­£é¢ãã©ã¤ã¹å å·¥ä»¥å¤ã®

ä»¥å¤ã®ååå å·¥ï¼ãã¨ãã°ããã¬ã¼ãå å·¥ãç åå å·¥ã

ãã®ä»ã®å¹³é¢ãå½¢æããããã®å å·¥ããã¼ãªã³ã°ç­ã®ç©´

å å·¥ãã¿ã¼ãã³ã°å å·¥ï¼ã«ãé©ç¨ãããã¨ãã§ãããIn each of the above embodiments, cutting other than face milling (for example, planar machining, grinding,

It can also be applied to other processes for forming a flat surface, boring such as boring, and turning.

ãï¼ï¼ï¼ï¼ã[0113]

ãçºæã®å¹æãæ¬çºæã«ããã°ãç£æ§ä½ãååå å·¥ãã

ããã«ããã®ç£æ§ä½ãä¿æããå ´åããã®ä¿æã«ãã£ã¦

çããä¸è¨ç£æ§ä½ã®å¤å½¢ãæ¥µåãããããã¨ãã§ããã¨

ããå¹æãå¥ãããAccording to the present invention, when the magnetic material is held for cutting the magnetic material, the deformation of the magnetic material caused by the holding can be minimized.

ãå³é¢ã®ç°¡åãªèª¬æã[Brief description of the drawings]

ãå³ï¼ãæ¬çºæã®ç¬¬ï¼ã®å®æ½ä¾ã§ããç£æ§ä½ä¿æè£

ç½®ï¼¨

ï¼³ï¼ã®æè¦å³ã§ãããFIG. 1 is a magnetic body holding device H according to a first embodiment of the present invention.

It is a perspective view of S1.

ãå³ï¼ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã®å¹³é¢å³ãæ­é¢å³ã§ã

ããFIG. 2 is a plan view and a cross-sectional view of the magnetic material holding device HS1.

ãå³ï¼ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ãç£æ§ä½ãä¿æãããã®

ä¿æãããç£æ§ä½ãååããå ´åã«ãããä¸è¨ç£æ§ä½ã®

æåç­ãç¤ºãå³ã§ãããFIG. 3 is a view showing the behavior of the magnetic material when the magnetic material holding device HS1 holds the magnetic material and cuts the held magnetic material.

ãå³ï¼ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ãç£æ§ä½ãä¿æãããã®

ä¿æãããç£æ§ä½ãååããå ´åã«ãããä¸è¨ç£æ§ä½ã®

æåç­ãç¤ºãå³ã§ãããFIG. 4 is a view showing the behavior of the magnetic material when the magnetic material holding device HS1 holds the magnetic material and cuts the held magnetic material.

ãå³ï¼ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ãç£æ§ä½ãä¿æãããã®

ä¿æãããç£æ§ä½ãååããå ´åã«ãããä¸è¨ç£æ§ä½ã®

æåç­ãç¤ºãå³ã§ãããFIG. 5 is a view showing the behavior of the magnetic material when the magnetic material holding device HS1 holds the magnetic material and cuts the held magnetic material.

ãå³ï¼ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã«ç£æ§ä½ãåãä»ããç¶

æ

ãç¤ºãå¹³é¢å³ã§ãããFIG. 6 is a plan view showing a state where a magnetic body is attached to the magnetic body holding device HS1.

ãå³ï¼ãç£æ§ä½ä¿æè£

ç½®ã«ï¼¨ï¼³ï¼ã«ã¹ãããã¼ï¼³ï¼´ï¼ã

è¨­ããç¶æ

ãç¤ºãå³ã§ãããFIG. 7 is a diagram showing a state in which a stopper ST1 is provided on HS1 in the magnetic material holding device.

ãå³ï¼ãæ¬çºæã®ç¬¬ï¼ã®å®æ½ä¾ã§ããç£æ§ä½ä¿æè£

ç½®ï¼¨

ï¼³ï¼ã®æè¦å³ã§ãããFIG. 8 shows a magnetic body holding device H according to a second embodiment of the present invention.

It is a perspective view of S2.

ãå³ï¼ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã®å¹³é¢å³ãæ­é¢å³ã§ã

ããFIG. 9 is a plan view and a cross-sectional view of the magnetic material holding device HS2.

ãå³ï¼ï¼ãæ¬çºæã®ç¬¬ï¼ã®å®æ½ä¾ã§ããç£æ§ä½ä¿æè£

ç½®

ï¼¨ãç¤ºãæ­é¢å³ã§ãããFIG. 10 is a sectional view showing a magnetic body holding device H according to a third embodiment of the present invention.

ãå³ï¼ï¼ãä¸è¨åç£æ§ä½ä¿æè£

ç½®ã«ããã¦ãçªèµ·ï¼°ï¼´ï¼

ãï¼°ï¼´ï¼ã®å½¢ç¶ã®å¤å½¢ä¾ãç¤ºãå³ã§ãããFIG. 11 is a cross-sectional view of each of the magnetic material holding devices.

It is a figure which shows the modification of shape of -PT3.

ãå³ï¼ï¼ãç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ã®å¹³é¢å³ãæ­é¢å³ã§ã

ããFIG. 12 is a plan view and a sectional view of a magnetic material holding device HS5.

ãå³ï¼ï¼ãå³ï¼ï¼ï¼ï¼ï¼ã®ï¼¸ï¼©ï¼©ï¼©é¨ã«ãããç£æ§ä½ä¿

æè£

ç½®ï¼¨ï¼³ï¼ã®é¨åæ¡å¤§å³ã§ãããFIG. 13 is a partially enlarged view of a magnetic material holding device HS5 in a portion XIII of FIG. 12 (2).

ãå³ï¼ï¼ãå¾æ¥ã®ç£æ§ä½ä¿æè£

ç½®ï¼¨ï¼³ï¼ï¼ã«ãã£ã¦ãç£

æ§ä½ãä¿æãããã®ä¿æãããç£æ§ä½ãååå å·¥ãã¦ã

ãç¶æ

ãç¤ºãæè¦å³ã§ãããFIG. 14 is a perspective view showing a state in which a magnetic body is held by a conventional magnetic body holding device HS10 and the held magnetic body is being cut.

ãå³ï¼ï¼ãç£æ§ä½ï¼·ï¼ï¼ãååããå ´åã«ããã¦ããã®

ç£æ§ä½ã®æåç­ãç¤ºãå³ã§ãããFIG. 15 is a diagram showing the behavior of the magnetic body when cutting the magnetic body W10.

ãç¬¦å·ã®èª¬æã[Explanation of symbols]

ï¼¨ï¼³ï¼ãï¼¨ï¼³ï¼â¦ç£æ§ä½ä¿æè£

ç½®ã ï¼¨ï¼¢ï¼ãï¼¨ï¼¢ï¼â¦åºå°ã ï¼¨ï¼¢ï¼ï½ãï¼¨ï¼¢ï¼ï½ãï¼¨ï¼¢ï¼ï½ãï¼¨ï¼¢ï¼ï½ãï¼¨ï¼¢ï¼ï½â¦

å¹³é¢ã ï¼¢ï¼ãï¼¢ï¼â¦ãã­ãã¯ã ï¼¢ï¼ï½â¦é¢ã ï¼®ï¼ãï¼®ï¼ãï¼®ï¼ãï¼³ï¼ãï¼³ï¼ãï¼³ï¼â¦ç£æ°çºçã¨ãª

ã¢ã ï¼°ï¼´ï¼ãï¼°ï¼´ï¼ãï¼°ï¼´ï¼ãï¼°ï¼´ï¼ãï¼°ï¼¦ï¼ãï¼°ï¼¦ï¼ãï¼°

ï¼²ï¼â¦çªèµ·ã ï¼°ï¼£ï¼ãï¼°ï¼£ï¼â¦çªèµ·ã«ãã¼ã ï¼°ï¼´ï¼ï½ãï¼°ï¼´ï¼ï½ãï¼°ï¼´ï¼ï½ãï¼°ï¼´ï¼ï½ãï¼°ï¼´ï¼ï½ã

ï¼°ï¼¦ï¼ï½ãï¼°ï¼¦ï¼ï½ã ï¼°ï¼£ï¼ï½ãï¼°ï¼£ï¼ï½â¦å½æ¥é¨ã ï¼³ï¼°ï¼ãï¼³ï¼°ï¼ãï¼³ï¼°ï¼ãï¼³ï¼°ï¼â¦å§ç¸®ããã ï¼·ï¼ãï¼·ï¼â¦ç£æ§ä½ã ï¼·ï½ï¼â¦ç£æãHS1 to HS5: Magnetic material holding device, HB1 to HB5: Base, HB1a, HB2a, HB3b, HB3c, HB5a ...

Plane, B1 to B8 ... block, B1a ... plane, N1, N2, N3, S1, S2, S3 ... magnetic generation area, PT1 to PT3, PT5 to PT8, PF1 to PF3, P

R1 ... projection, PC1, PC2 ... projection cover, PT1a, PT2a, PT6a, PT7a, PT8a,

PF1a, PF2a, PC1a, PC2a: contact portion, SP1 to SP3, SP5 to SP9: compression spring, W1 to W4: magnetic material, Wb1: magnetic flux.

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
