# 36. magnetic gripper

- **Archive rank:** 36 of 50
- **Publication:** [DE-202005006793-U1](https://patents.google.com/patent/DE202005006793U1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/2020050067931/publication/DE202005006793U1?q=pn%3DDE202005006793U1)
- **Publication date:** 2005-07-21
- **Filing date:** 2005-04-25
- **Earliest priority:** 2005-04-25
- **Family:** DE-202005006793-U1
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery

## Abstract

magnetic gripper
(10) for gripping and handling ferromagnetic workpieces (26),
with a housing
(18), one in the housing
(18) arranged magnets and a pneumatic connection (20) for working fluid
for moving the magnet in the housing
(18), the case
(18) an end face (22) facing the workpiece (26) to be gripped
characterized in that on the end face (22)
a shoe (24) is placed.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-202005006793-U1/pdf000.png)

![Sketch 1 for DE-202005006793-U1](https://nimo.iptorch.com/refdrawing/DE-202005006793-U1/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-202005006793-U1/pdf001.png)

![Sketch 2 for DE-202005006793-U1](https://nimo.iptorch.com/refdrawing/DE-202005006793-U1/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/DE-202005006793-U1/pdf002.png)

![Sketch 3 for DE-202005006793-U1](https://nimo.iptorch.com/refdrawing/DE-202005006793-U1/pdf002.png)

## Claims

### Claim 1 (independent)

Claims (12)

### Claim 2 (independent)

Translated from German

### Claim 3 (independent)

Magnetgreifer (10) zum Ergreifen und

### Claim 4 (independent)

Handhaben von ferromagnetischen WerkstÃ¼cken (26), mit einem

### Claim 5 (independent)

GehÃ¤use

### Claim 6 (independent)

(18), einem im GehÃ¤use

### Claim 7 (independent)

(18) angeordneten Magneten und einem Pneumatikanschluss (20)

### Claim 8 (independent)

fÃ¼r Arbeitsfluid

### Claim 9 (independent)

zum Bewegen des Magneten im GehÃ¤use

### Claim 10 (independent)

(18), wobei das GehÃ¤use

### Claim 11 (independent)

(18) eine dem zu ergreifenden WerkstÃ¼ck (26) zugewandte

### Claim 12 (independent)

StirnflÃ¤che (22)

### Claim 13 (independent)

aufweist, dadurch gekennzeichnet, dass auf die StirnflÃ¤che (22)

### Claim 14 (independent)

ein Schuh (24) aufgesetzt ist.Magnetic gripper ( 10 ) for gripping and handling ferromagnetic workpieces ( 26 ), with a housing ( 18 ), one in the housing ( 18 ) and a pneumatic connection ( 20 ) for working fluid for moving the magnet in the housing ( 18 ), the housing ( 18 ) a workpiece to be gripped ( 26 ) facing end face ( 22 ), characterized in that on the end face ( 22 ) a shoe ( 24 ) is attached.

### Claim 15

Magnetgreifer nach Anspruch 1, dadurch gekennzeichnet,

### Claim 16 (independent)

dass der Schuh (24) auf den die StirnflÃ¤che (22) umgebenden

### Claim 17 (independent)

Rand (46) des GehÃ¤uses (18)

### Claim 18

aufrastbar ist.Magnetic gripper according to claim 1, characterized in that the shoe ( 24 ) on the end face ( 22 ) surrounding edge ( 46 ) of the housing ( 18 ) is latched.

### Claim 19

Magnetgreifer nach Anspruch 1 oder 2, dadurch gekennzeichnet,

### Claim 20 (independent)

dass der Schuh (24) eine Greifplatte (28) und

### Claim 21 (independent)

an dieser angeordnete, in Richtung des GehÃ¤uses (18) abragende,

### Claim 22

abgewinkelte Laschen (32) aufweist.Magnetic gripper according to claim 1 or 2, characterized in that the shoe ( 24 ) a gripping plate ( 28 ) and arranged at this, in the direction of the housing ( 18 ) projecting, angled Tabs ( 32 ) having.

### Claim 23

Magnetgreifer nach Anspruch 3, dadurch gekennzeichnet,

### Claim 24 (independent)

dass die Laschen (32) mit Rastelementen (38) versehen

### Claim 25 (independent)

sind, die am GehÃ¤use

### Claim 26

(18) verrasten.Magnetic gripper according to claim 3, characterized in that the tabs ( 32 ) with locking elements ( 38 ) are provided on the housing ( 18 ) lock.

### Claim 27

Magnetgreifer nach Anspruch 4, dadurch gekennzeichnet,

### Claim 28 (independent)

dass die Rastelemente (38) von in Richtung des GehÃ¤uses (18)

### Claim 29

vorspringenden Noppen (40) gebildet werden.Magnetic gripper according to claim 4, characterized in that the latching elements ( 38 ) from in the direction of the housing ( 18 ) projecting pimples ( 40 ) are formed.

### Claim 30

Magnetgreifer nach einem der vorhergehenden AnsprÃ¼che, dadurch

### Claim 31 (independent)

gekennzeichnet, dass das GehÃ¤use

### Claim 32 (independent)

eine Rastaufnahme (42), insbesondere eine Ringnut (44)

### Claim 33 (independent)

zur Aufnahme von Rastelementen (38) des Schuhs (24)

### Claim 34

aufweist.Magnetic gripper according to one of the preceding claims, characterized in that the housing has a latching receptacle ( 42 ), in particular an annular groove ( 44 ) for receiving locking elements ( 38 ) of the shoe ( 24 ) having.

### Claim 35

Magnetgreifer nach einem der vorhergehenden AnsprÃ¼che, dadurch

### Claim 36 (independent)

gekennzeichnet, dass der Schuh (24) mit einem BetÃ¤tigungselement

### Claim 37 (independent)

(36) zum Aufsetzen und Abnehmen vom GehÃ¤use (18) versehen

### Claim 38

ist.Magnetic gripper according to one of the preceding claims, characterized in that the shoe ( 24 ) with an actuating element ( 36 ) for mounting and removing from the housing ( 18 ) is provided.

### Claim 39

Magnetgreifer nach Anspruch 7, dadurch gekennzeichnet,

### Claim 40 (independent)

dass das BetÃ¤tigungselement

### Claim 41 (independent)

(36) von einem von einer Lasche (32) abragenden

### Claim 42 (independent)

FlÃ¼gel

### Claim 43

(34) gebildet wird.Magnetic gripper according to claim 7, characterized in that the actuating element ( 36 ) from one of a tab ( 32 ) projecting wings ( 34 ) is formed.

### Claim 44

Magnetgreifer nach einem der vorhergehenden AnsprÃ¼che, dadurch

### Claim 45 (independent)

gekennzeichnet, dass die StirnflÃ¤che

### Claim 46

(22) mit unterschiedlichen Schuhen (24) bestÃ¼ckbar ist.Magnetic gripper according to one of the preceding claims, characterized in that the end face ( 22 ) with different shoes ( 24 ) can be equipped.

### Claim 47

Magnetgreifer nach Anspruch 9, dadurch gekennzeichnet,

### Claim 48

dass die Schuhe (24) unterschiedliche Dicken aufweisen.Magnetic gripper according to claim 9, characterized in that the shoes ( 24 ) have different thicknesses.

### Claim 49

Magnetgreifer nach Anspruch 9 oder 10, dadurch gekennzeichnet,

### Claim 50

dass die Schuhe (24) beschichtet sind.Magnetic gripper according to claim 9 or 10, characterized in that the shoes ( 24 ) are coated.

### Claim 51 (independent)

Magnetgreifer nach einem der AnsprÃ¼che 9 bis

### Claim 52 (independent)

11, dadurch gekennzeichnet, dass die Schuhe (24) Greifplatten

### Claim 53 (independent)

(28) aus unterschiedlichen Materialien, insbesondere Kunststoff

### Claim 54

aufweisen.Magnetic gripper according to one of claims 9 to 11, characterized in that the shoes ( 24 ) Gripping plates ( 28 ) made of different materials, in particular plastic.

## Full description

**[p0001]**

ELECTRICITYELECTRIC ELEMENTSMAGNETS; INDUCTANCES; TRANSFORMERS; SELECTION OF MATERIALS FOR THEIR MAGNETIC PROPERTIESMagnetsPermanent magnets [PM]Magnetic circuits with PM for power or force generationPM holding devices Description Translated from German Die Erfindung betrifft einen Magnetgreifer zum Ergreifen und Handhaben von ferromagnetischen WerkstÃ¼cken, mit einem GehÃ¤use, einem im GehÃ¤use angeordneten Magneten und einem Pneumatikanschluss fÃ¼r Arbeitsfluid zum Bewegen des Magneten im GehÃ¤use, wobei das GehÃ¤use eine dem zu ergreifenden WerkstÃ¼ck zugewandte StirnflÃ¤che aufweist.The The invention relates to a magnetic gripper for gripping and handling ferromagnetic workpieces, with a housing, one in the housing arranged magnets and a pneumatic connection for working fluid for moving the magnet in the housing, the case a workpiece to be gripped facing end face having. Ein derartiger Magnetgreifer ist zum Beispiel aus der DE 199 51 703 A1 bekannt. Mit diesen Magnetgreifern werden ferromagnetische WerkstÃ¼cke ergriffen,

**[p0002]**

so dass sie angehoben werden kÃ¶nnen. Zum LÃ¶sen des WerkstÃ¼cks vom Magnetgreifer wird der Magnet im GehÃ¤use des Magnetgreifers verlagert, so dass das aus der StirnflÃ¤che des GehÃ¤uses austretende magnetische Feld abgeschwÃ¤cht oder abgelenkt wird.Such a magnetic gripper is for example from DE 199 51 703 A1 known. With these magnetic grippers ferromagnetic workpieces are gripped so that they can be lifted. To release the workpiece from the magnetic gripper, the magnet is displaced in the housing of the magnetic gripper, so that the magnetic field emerging from the end face of the housing is attenuated or deflected. Es hat sich gezeigt, dass mit derartigen Magnetgreifern GegenstÃ¤nde zwar optimal ergriffen und transportiert werden kÃ¶nnen, dass aber mitunter das Magnetfeld beziehungsweise die StÃ¤rke oder Richtung des Magnetfelds auf den zu ergreifenden Gegenstand eingestellt werden sollte, um optimale Greif- und Transportergebnisse erzielen zu kÃ¶nnen.It has been shown that with such magnetic grippers objects though

**[p0003]**

can be optimally grasped and transported, but sometimes the magnetic field or the strength or direction of the magnetic field on the object to be gripped should be adjusted to optimum gripping and transport results to achieve. Der Erfindung liegt daher die Aufgabe zugrunde, einen Magnetgreifer der eingangs genannten Art derart weiterzubilden, dass dessen aus der StirnflÃ¤che austretende Magnetfeld auf das zu ergreifende WerkstÃ¼ck eingestellt oder auf ein WerkstÃ¼ck abgestimmt werden kann.Of the Invention is therefore based on the object, a magnetic gripper of the type mentioned in such a way that its from the face exiting magnetic field adjusted to the workpiece to be gripped or tuned to a workpiece can be. Diese Aufgabe wird mit einem Magnetgreifer der eingangs genannten Art erfindungsgemÃ¤Ã dadurch gelÃ¶st, dass auf die StirnflÃ¤che ein Schuh aufgesetzt wird.These Task is with a magnetic gripper of the type mentioned according to the invention thereby solved, that on the frontal area a shoe is put on. Beim erfindungsgemÃ¤Ãen Magnetgreifer wird

**[p0004]**

das WerkstÃ¼ck nicht direkt mit der StirnflÃ¤che des GehÃ¤uses gegriffen, d.h. die StirnflÃ¤che liegt nicht direkt am WerkstÃ¼ck an, sondern auf die StirnflÃ¤che wird zuvor ein Schuh aufgesetzt, Ã¼ber welchen das Magnetfeld gezielt gesteuert wird. Mittels des Schuhs kÃ¶nnen zum Beispiel die Feldlinien konzentriert oder gestreut werden oder das Magnetfeld kann teilweise abgeschirmt werden, wodurch die GreifkrÃ¤fte verringert werden. Auf diese Weise kÃ¶nnen auch empfindliche WerkstÃ¼cke gegriffen werden, ohne dass sich diese verformen. AuÃerdem wird durch den Schuh die StirnflÃ¤che des Magnetgreifers geschont, was z.B. bei sehr scharfkantigen WerkstÃ¼cken von Bedeutung ist.At the Magnetic gripper according to the invention is the workpiece not directly with the face of the housing gripped, i. the face is not directly on the workpiece but on the face before a shoe is placed, on which the magnetic field is controlled specifically. By means of the shoe, for example, the field lines concentrated or scattered or the magnetic field can be partial

**[p0005]**

be shielded, whereby the gripping forces are reduced. On this way you can also sensitive workpieces be gripped without these deform. In addition, will through the shoe the face the magnetic gripper spared what e.g. for very sharp-edged workpieces of importance is. Bei einem bevorzugten AusfÃ¼hrungsbeispiel ist der Schuh auf den die StirnflÃ¤che umgebenden Rand des GehÃ¤uses aufrastbar. Der Schuh weist also wenigstens zwei Abschnitte auf, nÃ¤mlich einen Abschnitt, Ã¼ber welchen er am zu ergreifenden WerkstÃ¼ck anliegt, und einen Abschnitt, der zur Verbindung des Schuhs mit dem GehÃ¤use dient. Dieser zweite Abschnitt ist vorzugsweise als Rastmittel ausgebildet, so dass der Schuh ohne Werkzeug und manuell am GehÃ¤use befestigt werden kann. Es ist aber auch denkbar, dass der Schuh nach Art eines Bajonettverschlusses zuerst axial aufs GehÃ¤use aufgeschoben und durch eine geringe Verdrehung fixiert wird. Eine andere MÃ¶glichkeit der Befestigung des Schuhs am GehÃ¤use besteht darin, dass der Schuh Ã¼ber Klettvorrichtungen oder Fixierschrauben befestigt wird. Der Schuh

**[p0006]**

kann auch aufgeschraubt werden.at a preferred embodiment the shoe on the face surrounding edge of the housing snapped. The shoe thus has at least two sections, namely a section about which it rests on the workpiece to be gripped, and a section, which serves to connect the shoe to the housing. This second section is preferably designed as a locking means, so that the shoe without Tool and manual on the housing can be attached. It is also conceivable that the shoe first pushed axially onto the housing in the manner of a bayonet catch and is fixed by a slight twist. Another possibility the attachment of the shoe to the housing is that the Shoe over Velcro or fixing screws is attached. The shoe can also be screwed on. Bei einem bevorzugten AusfÃ¼hrungsbeispiel weist der Schuh eine Greifplatte und daran angeformte, in Richtung des GehÃ¤uses abragende, abgewinkelte Laschen auf. Der Schuh besitzt im Wesentlichen die Form eines Deckels und Ã¼bergreift die komplette StirnflÃ¤che. Es ist aber auch denkbar, dass der Schuh DurchbrÃ¼che aufweist, so dass er lediglich einen

**[p0007]**

Teil der StirnflÃ¤che Ã¼bergreift und quasi lediglich als Abstandshalter dient. Der Schuh ist zum Beispiel ein Blechbiegeteil und besteht bei einem AusfÃ¼hrungsbeispiel aus Aluminium, wobei die Laschen im Wesentlichen rechtwinklig abgebogen sind und weg vom WerkstÃ¼ck von der Greifplatte abragen.at a preferred embodiment the shoe is a gripping plate and molded to it, in the direction of housing protruding, angled tabs on. The shoe essentially has the shape of a lid and overlaps the complete face. But it is also conceivable that the shoe has breakthroughs, so that he only one Part of the front surface overlaps and virtually serves only as a spacer. The shoe is for Example, a bent sheet metal part and consists in one embodiment made of aluminum, wherein the tabs bent substantially at right angles are and away from the workpiece protrude from the gripping plate. Um den Schuh einfach manuell und ohne Werkzeug auf das GehÃ¤use aufrasten und von diesem wieder abnehmen zu kÃ¶nnen, sind die Laschen des Schuhs mit Rastelementen versehen, die am GehÃ¤use verrasten. Eine derartige

**[p0008]**

Rastverbindung bietet auch den Vorteil, dass der Schuh eine eindeutige Position einnimmt und das Verrasten dem Benutzer anzeigt, dass der Schuh korrekt am GehÃ¤use sitzt.Around Simply snap the shoe onto the housing manually and without tools and to be able to remove from this again are the tabs of the Shoe provided with locking elements that lock on the housing. Such Locking connection also offers the advantage that the shoe has a unique position occupies and the locking indicates to the user that the shoe correct on the housing sitting. Dabei werden die Rastelemente von in Richtung des GehÃ¤uses vorspringenden Noppen gebildet. Derartige Noppen sind einfach herstellbar, indem sie zum Beispiel aus den Laschen ausgeprÃ¤gt beziehungsweise auf die Laschen aufgeformt werden. Sie kÃ¶nnen auch in Form eines Niets mit Linsenkopf aufgebracht werden.there be the locking elements of projecting in the direction of the housing knobs educated. Such pimples are easy to produce by adding to Example from the tabs pronounced

**[p0009]**

or be formed on the tabs. You can also be applied in the form of a rivet with Linsenkopf. Bei einem bevorzugten AusfÃ¼hrungsbeispiel ist der Schuh mit einem BetÃ¤tigungselement zum Aufsetzen und Abnehmen vom GehÃ¤use versehen. Dieses BetÃ¤tigungselement wird zum Beispiel von einem von der Lasche abragenden FlÃ¼gel gebildet, Ã¼ber welchen die Lasche geringfÃ¼gig verformt (vom GehÃ¤use weggebogen) und dadurch die Verrastung gelÃ¶st werden kann.at a preferred embodiment the shoe with an actuator for putting on and taking off the housing. This actuator is formed, for example, by a protruding from the tab wing, over which the tab slightly deformed (from the housing weggebogen) and thereby the locking can be solved. Wie bereits erwÃ¤hnt, ist die StirnflÃ¤che mit unterschiedlichen Schuhen bestÃ¼ckbar, so dass auf diese Weise die Magnetkraft gezielt an das WerkstÃ¼ck angepasst werden kann. AuÃerdem kann zwischen den Schuh und die StirnflÃ¤che eine Distanzplatte oder ein Abschirmelement eingesetzt werden, so dass mit gleichen Schuhen

**[p0010]**

das Magnetfeld dennoch unterschiedlich beeinflusst werden kann.As already mentioned, the end face can be equipped with different shoes, so that in this way the magnetic force can be specifically adapted to the workpiece. In addition, between The shoe and the end face a spacer plate or a shielding are used, so that with same shoes, the magnetic field can still be influenced differently. Eine einfache Variante sieht vor, dass die Greifplatte mit Schuhen unterschiedlicher Dicke bestÃ¼ckt wird. AuÃerdem kÃ¶nnen die Schuhe mit verschiedenen Materialien beschichtet sein. Dadurch kÃ¶nnen auch gezielt QuerkrÃ¤fte aufgenommen werden, indem zum Beispiel eine Elastomer-Beschichtung aufgebracht wird, die ein Abrutschen des gegriffenen WerkstÃ¼cks verhindert.A simple variant provides that the gripping plate with shoes of different Thickness fitted becomes. Furthermore can the shoes be coated with different materials. This can also be done specifically lateral forces be absorbed by, for example, an elastomeric coating

**[p0011]**

is applied, which prevents slipping of the gripped workpiece. AuÃerdem kÃ¶nnen die Schuhe aus unterschiedlichen Materialien, zum Beispiel aus ferromagnetischem Material oder aus Aluminium, Messing oder auch aus Kunststoff hergestellt sein. Ferner kann die dem WerkstÃ¼ck zugewandte OberflÃ¤che der Greifplatte glatt oder strukturiert sein.In addition, the Shoes made of different materials, for example ferromagnetic Material or made of aluminum, brass or plastic be. Furthermore, the workpiece facing surface the gripping plate be smooth or structured. Weitere Vorteile, Merkmale und Einzelheiten der Erfindung ergeben sich aus den UnteransprÃ¼chen sowie der nachfolgenden Beschreibung, in der unter Bezugnahme auf die Zeichnung ein besonders bevorzugtes AusfÃ¼hrungsbeispiel im Einzelnen beschrieben ist. Dabei kÃ¶nnen die in der Zeichnung dargestellten sowie in der Beschreibung und in den AnsprÃ¼chen erwÃ¤hnten Merkmale jeweils einzeln fÃ¼r sich oder in beliebiger Kombination erfindungswesentlich sein.Further Advantages, features and details of the invention will become apparent

**[p0012]**

the dependent claims as well as the following description, with reference to FIG the drawing a particularly preferred embodiment in detail is described. It can those shown in the drawing and in the description and in the claims mentioned Features individually for themselves or be essential to the invention in any combination. In der Zeichnung zeigen:In show the drawing: 1 eine perspektivische Ansicht eines Magnetgreifers auf die Einspannstelle; 1 a perspective view of a magnetic gripper on the clamping point; 2 eine perspektivische Ansicht des Magnetgreifers auf die mit einem Schuh bestÃ¼ckte Stirnseite; und 2 a perspective view of the magnetic gripper on the equipped with a shoe end face; and 3 eine Seitenansicht des Magnetgreifers. 3 a side view of the magnetic gripper. Die 1 zeigt einen insgesamt mit 10 bezeichneten Magnetgreifer, der an seiner RÃ¼ckseite 12 einen axial abragenden Zapfen 14 aufweist, an welchem er zum Beispiel an einem Roboterarm oder dergleichen befestigt werden kann. HierfÃ¼r dienen Befestigungs- und Kontermuttern 16 oder andere geeignete

**[p0013]**

Befestigungsmittel. Die RÃ¼ckseite 12 ist in ein topffÃ¶rmiges GehÃ¤use 18 eingeschraubt, in welchem sich unter anderem ein (nicht dargestellter) Magnet befindet, der mittels eines Arbeitsfluides (Druckluft oder Unterdruck) innerhalb des GehÃ¤uses 18 bewegt werden kann. Zum ZufÃ¼hren des Arbeitsfluides dient ein Pneumatikanschluss 20, der von der MantelflÃ¤che des GehÃ¤uses 18 abragt.The 1 shows a total of 10 designated magnetic gripper, on its back 12 an axially projecting pin 14 to which it can be attached, for example, to a robot arm or the like. For this serve fastening and locknuts 16 or other suitable fastening means. The backside 12 is in a cup-shaped housing 18 screwed, in which inter alia, a (not shown) magnet is, by means of a working fluid (compressed air or negative pressure) within the housing 18 can be moved. For supplying the working fluid is a pneumatic connection 20 coming from the lateral surface of the housing 18 protrudes. Der RÃ¼ckseite 12 gegenÃ¼berliegend befindet sich eine StirnflÃ¤che 22,

**[p0014]**

die von einem Schuh 24 Ã¼bergriffen ist. Sowohl die StirnflÃ¤che 22 als auch der Schuh 24 sind einem zu ergreifenden WerkstÃ¼ck 26 zugewandt, welches in der 1 lediglich beispielhaft als ferromagnetische Platte dargestellt ist.The back 12 opposite there is an end face 22 that of a shoe 24 is overrun. Both the face 22 as well as the shoe 24 are a workpiece to be picked up 26 facing, which in the 1 merely exemplified as ferromagnetic plate. Dieser Schuh 24 weist eine die StirnflÃ¤che 22 des Magnetgreifers 10 Ã¼berdeckende Greifplatte 28 auf, an deren Rand 30 in regelmÃ¤Ãigen AbstÃ¤nden Laschen 32 angeordnet sind, die im Wesentlichen rechtwinklig von der Greifplatte 28 abragen und sich im Wesentlichen parallel zur MantelflÃ¤che des GehÃ¤uses 18 und weg vom WerkstÃ¼ck 26 erstrecken. Zwei der Laschen 32 sind an ihrem freien Ende mit einem nach auÃen abgewinkelten FlÃ¼gel 34 versehen, der ein BetÃ¤tigungselement 36 bildet, an welchem die Lasche 32 mit einem Finger geringfÃ¼gig weg vom GehÃ¤use 18 abgebogen

**[p0015]**

werden kann. Dabei kommt eine an der Lasche 32 vorgesehene, ein Rastelement 38 bildende Noppe 40 auÃer Eingriff mit einer, eine Rastaufnahme 42 bildenden Ringnut 44. Diese Ringnut 44 ist in den die StirnflÃ¤che 22 umgebenden Rand 46 des GehÃ¤uses 18 eingeformt.This shoe 24 has a face 22 of the magnetic gripper 10 overlapping gripping plate 28 on, at the edge 30 at regular intervals tabs 32 are arranged, which are substantially perpendicular from the gripping plate 28 protrude and substantially parallel to the lateral surface of the housing 18 and away from the workpiece 26 extend. Two of the tabs 32 are at their free end with an outwardly angled wing 34 provided, which is an actuating element 36 forms, on which the tab 32 with one finger slightly away from the case 18 can be bent. Here comes one on the tab 32 provided, a locking element 38 forming knob 40 out of engagement with one, a locking receptacle 42 forming annular groove 44 , This ring groove 44 is in the the face 22 surrounding edge 46 of the housing 18 formed.

**[p0016]**

Aus der 3 ist erkennbar, dass die Greifplatte 28 mit einer Beschichtung 48 versehen ist, die zum Beispiel von einem Elastomer gebildet wird. Auf diese Weise kÃ¶nnen beim Transport des WerkstÃ¼cks 26 problemlos QuerkrÃ¤fte abgestÃ¼tzt werden. AuÃerdem kann der Magnetgreifer 10 mit unterschiedlichen Schuhen 24 mit unterschiedlich dicken Beschichtungen 48, oder unterschiedlich dicken Greifplatten 28 bestÃ¼ckt werden, wodurch gezielt das aus der StirnflÃ¤che 22 austretende Magnetfeld, insbesondere dessen StÃ¤rke/oder Richtung, gesteuert wird. AuÃerdem kÃ¶nnen die Schuhe 24 aus unterschiedlichen Materialien bestehen oder die Greifplatte 28 DurchbrÃ¼che aufweisen.From the 3 it can be seen that the gripping plate 28 with a coating 48 is provided, which is formed for example by an elastomer. In this way, when transporting the workpiece 26 transverse forces can be supported without difficulty. In addition, the magnetic gripper 10 with different shoes 24 with different thick coatings 48 , or different thickness gripping plates 28 be fitted, which specifically from the face 22 exiting magnetic field, in particular its strength / or direction, is controlled. In addition, the shoes can 24 made of different materials or the gripping plate 28 Have breakthroughs.

## Classifications

- H01F7/0252

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
