# 34. Faceplate for magnetic chuck

- **Archive rank:** 34 of 50
- **Publication:** [JP-2007301640-A](https://patents.google.com/patent/JP2007301640A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/038836027/publication/JP2007301640A?q=pn%3DJP2007301640A)
- **Publication date:** 2007-11-22
- **Filing date:** 2006-05-08
- **Earliest priority:** 2006-05-08
- **Family:** 38836027
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** KANETEC CO LTD

## Abstract

&lt;P&gt;PROBLEM TO BE SOLVED: To dispense with soldering in a faceplate for a magnetic chuck releasably attracting a magnetic body such as a workpiece.  &lt;P&gt;SOLUTION: This faceplate includes a plurality of first pole shoes disposed at some interval apart in a first direction and being long in a second direction crossing with the first direction, a plurality of second pole shoes each disposed between the adjoining first pole shoes and being long in the second direction, and a plurality of spacers each disposed between the adjoining first and second pole shoes for connecting the first and second pole shoes, connecting the both pole shoes and restricting a working face attracting the magnetic body cooperating with the first and second pole shoes. Each spacer is manufactured of a non-magnetic synthetic resin material.  &lt;P&gt;COPYRIGHT: (C)2008,JPO&amp;INPIT

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/3b/a4/f3/3023a0a4c5ba96/2007301640-3.png)

![Sketch 1 for JP-2007301640-A](https://patentimages.storage.googleapis.com/3b/a4/f3/3023a0a4c5ba96/2007301640-3.png)

[Sketch 2](https://patentimages.storage.googleapis.com/da/ad/5c/41e37bfbd99658/2007301640-4.png)

![Sketch 2 for JP-2007301640-A](https://patentimages.storage.googleapis.com/da/ad/5c/41e37bfbd99658/2007301640-4.png)

[Sketch 3](https://patentimages.storage.googleapis.com/12/e1/cc/ff1f06bc74e118/2007301640-5.png)

![Sketch 3 for JP-2007301640-A](https://patentimages.storage.googleapis.com/12/e1/cc/ff1f06bc74e118/2007301640-5.png)

[Sketch 4](https://patentimages.storage.googleapis.com/bd/7b/f4/0055d8043e9394/2007301640-6.png)

![Sketch 4 for JP-2007301640-A](https://patentimages.storage.googleapis.com/bd/7b/f4/0055d8043e9394/2007301640-6.png)

## Claims

### Claim 1

第１の方向に間隔をおいて配置されかつ前記第１の方向と交差する第２の方向に長い複数の第１の磁極片と、それぞれが隣り合う第１の磁極片の間に配置されかつ前記第２の方向に長い複数の第２の磁極片と、該第１及び第２の磁極片を結合させるべくそれぞれが隣り合う第１及び第２の磁極片の間に配置されて両磁極片を結合させる複数のスペーサであって磁性体を吸着する作業面を前記第１及び第２の磁極片と共同して規定するスペーサとを含み、前記スペーサは非磁性の合成樹脂である、磁気チャック用面板。

### Claim 2

前記複数の第１の磁極片は、前記隣り合う２つの第１の磁極片が前記作業面の側と反対側の箇所において連結部により一体的に連結されて、該連結部と共に磁極片ブロックに形成されている、請求項１に記載の磁気チャック用面板。

### Claim 3

さらに、上向きのコ字状をした非磁性の複数のコマ部材であってそれぞれが隣り合う第１及び第２の磁極片の間にあって前記第２の磁極片の前記作業面と反対の側の箇所を受け入れた複数のコマ部材を含む、請求項１に記載の磁気チャック用面板。

## Full description

Description

Translated from Japanese

æ¬çºæã¯ãå·¥ä½ç©ã®ãããªç£æ§ä½ãè§£é¤å¯è½ã«å¸çããç£æ°ãã£ãã¯ã®ããã®é¢æ¿ã«é¢ããã

Â Â The present invention relates to a face plate for a magnetic chuck that releasably attracts a magnetic material such as a workpiece.

ç£æ°ãã£ãã¯ã®ï¼ã¤ã¨ãã¦ãä¸ç«¯éæ¾ã®ãã¦ã¸ã³ã°ã¨ãè©²ãã¦ã¸ã³ã°å

ã«é

ç½®ãããç£ç³è£

ç½®ã¨ãåè¨ãã¦ã¸ã³ã°ã®éæ¾ç«¯ã«é

ç½®ãããé¢æ¿ã§ãã£ã¦ç£æ§ä½ãå¸çããä½æ¥­é¢ãè¦å®ããé¢æ¿ã¨ãå«ããã®ãããï¼ä¾ãã°ãç¹è¨±æç®ï¼ï¼ã

Â Â As one of the magnetic chucks, a housing having one end opened, a magnet device disposed in the housing, and a face plate that is disposed at the open end of the housing and that defines a work surface that adsorbs a magnetic body. Some include (for example, Patent Document 1).

ç¹è¨±ç¬¬ï¼ï¼ï¼ï¼ï¼ï¼ï¼å·å

¬å ±Japanese Patent No. 3808167

ä¸è¨å¾æ¥ã®ç£æ°ãã£ãã¯ã«ããã¦ãé¢æ¿ã¯ãç¬¬ï¼ã®æ¹åã«ééãããã¦äº¤äºã«é

ç½®ãããã¤ç¬¬ï¼ã®æ¹åã¨äº¤å·®ããç¬¬ï¼ã®æ¹åã«é·ãè¤æ°ã®ç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçã¨ããããããç¬¬ï¼ã®æ¹åã«é£ãåãç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçã®éã«é

ç½®ãããéç£æ§ã®è¤æ°ã®ã¹ãã¼ãµã¨ãå«ãã

Â Â In the conventional magnetic chuck, the face plates are alternately arranged at intervals in the first direction, and a plurality of first and second magnetic pole pieces that are long in the second direction intersecting the first direction, and Includes a plurality of nonmagnetic spacers disposed between first and second pole pieces adjacent in the first direction.

ä¸è¨ã®ãããªå¾æ¥ã®é¢æ¿ã«ããã¦ã¯ãã¹ãã¼ãµã¨ãã¦é»é

æ¿ãç¨ãã¦ãããã¨ãããåã¹ãã¼ãµãããã®é£ã®ç£æ¥µçã«æ¥çããæ¥çå¤ã¨ãã¦ãéãå«ãåç°ãç¨ãã¦ããããã®ãããå¾æ¥ã®é¢æ¿ã¯ãç åæ¶²ã«å¾®éã®éãæº¶ãåºãåé¡ããã£ãã

Â Â In the conventional face plate as described above, since a brass plate is used as a spacer, solder containing lead is used as an adhesive for adhering each spacer to the adjacent pole piece. For this reason, the conventional face plate has a problem that a small amount of lead dissolves into the grinding fluid.

ã¾ããå¾æ¥ã®é¢æ¿ã§ã¯ãï¼ï¼ï¼Â°ï¼£ç¨åº¦ã«å ç±æº¶èãããåç°ãç£æ¥µçã¨é»é

æ¿ã¨ã®éã«æµãè¾¼ããã¨ã«ãããç£æ¥µçã¨é»é

æ¿ã¨ãæ¥åããããå¾ãªãã

Â Â Further, in the conventional face plate, the magnetic pole piece and the brass plate have to be joined by pouring the solder heated and melted to about 300 Â° C. between the pole piece and the brass plate.

æ¬çºæã®ç®çã¯ãåç°ãç¨ããå¿

è¦æ§ãç¡ãããã¨ã«ããã

Â Â An object of the present invention is to eliminate the need to use solder.

æ¬çºæã«ä¿ãé¢æ¿ã¯ãç¬¬ï¼ã®æ¹åã«ééãããã¦é

ç½®ãããã¤åè¨ç¬¬ï¼ã®æ¹åã¨äº¤å·®ããç¬¬ï¼ã®æ¹åã«é·ãè¤æ°ã®ç¬¬ï¼ã®ç£æ¥µçã¨ããããããé£ãåãç¬¬ï¼ã®ç£æ¥µçã®éã«é

ç½®ãããã¤åè¨ç¬¬ï¼ã®æ¹åã«é·ãè¤æ°ã®ç¬¬ï¼ã®ç£æ¥µçã¨ãè©²ç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçãçµåãããã¹ããããããé£ãåãç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçã®éã«é

ç½®ããã¦ä¸¡ç£æ¥µçãçµåãããè¤æ°ã®ã¹ãã¼ãµã§ãã£ã¦ç£æ§ä½ãå¸çããä½æ¥­é¢ãåè¨ç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçã¨å

±åãã¦è¦å®ããã¹ãã¼ãµã¨ãå«ããåè¨åã¹ãã¼ãµã¯éç£æ§ã®åææ¨¹èææã§è£½ä½ããã¦ããã

Â Â A face plate according to the present invention includes a plurality of first magnetic pole pieces that are spaced apart in a first direction and that are long in a second direction intersecting the first direction, and first magnetic poles adjacent to each other. A plurality of second pole pieces arranged between the pieces and extending in the second direction, and between the first and second pole pieces adjacent to each other to couple the first and second pole pieces And a plurality of spacers for coupling the two magnetic pole pieces and defining a working surface for adsorbing the magnetic material in cooperation with the first and second magnetic pole pieces. Each of the spacers is made of a nonmagnetic synthetic resin material.

åè¨è¤æ°ã®ç¬¬ï¼ã®ç£æ¥µçã¯ãåè¨é£ãåãï¼ã¤ã®ç¬¬ï¼ã®ç£æ¥µçãåè¨ä½æ¥­é¢ã®å´ã¨åå¯¾å´ã®ç®æã«ããã¦å°ãªãã¨ãï¼ã¤ã®é£çµé¨ã«ããä¸ä½çã«é£çµããã¦ãè©²é£çµé¨ã¨å

±ã«ç£æ¥µçãã­ãã¯ã«å½¢æããã¦ãã¦ãããã

Â Â In the plurality of first magnetic pole pieces, the two adjacent first magnetic pole pieces are integrally connected by at least one connecting portion at a position opposite to the work surface side, and the magnetic poles together with the connecting portions are provided. It may be formed in one block.

é¢æ¿ã¯ãããã«ãä¸åãã®ã³å­ç¶ãããéç£æ§ã®è¤æ°ã®ã³ãé¨æã§ãã£ã¦ãããããé£ãåãç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçã®éã«ãã£ã¦åè¨ç¬¬ï¼ã®ç£æ¥µçã®åè¨ä½æ¥­é¢ã¨åå¯¾ã®å´ã®ç®æãåãå

¥ããè¤æ°ã®ã³ãé¨æãå«ããã¨ãã§ããã

Â Â The face plate is further a plurality of non-magnetic pieces having an upward U-shape, each being between adjacent first and second magnetic pole pieces and opposite to the work surface of the second magnetic pole piece. A plurality of piece members that receive the side portions can be included.

ã¹ãã¼ãµã¨ãã¦ãé»é

æ¿ã®ä»£ããã«éç£æ§ã®åææ¨¹èãç¨ãã¦ãããããåç°ãç¨ããå¿

è¦ããªãã

Â Â Since a nonmagnetic synthetic resin is used as the spacer instead of the brass plate, it is not necessary to use solder.

é£ãåãç¬¬ï¼ã®ç£æ¥µçãä½æ¥­é¢ã®å´ã¨åå¯¾å´ã®ç®æã«ããã¦å°ãªãã¨ãï¼ã¤ã®é£çµé¨ã«ããä¸ä½çã«é£çµããã¦ãé£çµé¨ã¨å

±ã«ç£æ¥µçãã­ãã¯ã«å½¢æããã¦ããã¨ãé£ãåãç¬¬ï¼ã®ç£æ¥µçã®ä½ç½®é¢ä¿ãå®å®åãããããç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçéã¸ã®æ¨¹èã®é

ç½®ä½æ¥­ãæ¨¹èã«ããç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçã®çµåä½æ¥­ç­ãå®¹æã«ãªãã

Â Â When adjacent first magnetic pole pieces are integrally connected by at least one connecting portion at a position opposite to the work surface, and are formed in the magnetic pole piece block together with the connecting portion, the adjacent first magnetic pole pieces Since the positional relationship between the pieces is stabilized, it is easy to place resin between the first and second magnetic pole pieces, and to join the first and second magnetic pole pieces with the resin.

é¢æ¿ã¯ãããã«ãä¸åãã®ã³å­ç¶ãããéç£æ§ã®è¤æ°ã®ã³ãé¨æã§ãã£ã¦ãããããé£ãåãç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçã®éã«ãã£ã¦ç¬¬ï¼ã®ç£æ¥µçã®ä½æ¥­é¢ã¨åå¯¾ã®å´ã®ç®æãåãå

¥ããè¤æ°ã®ã³ãé¨æãå«ããªãã°ãç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçã®ä½ç½®é¢ä¿ãå®å®åãããããç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçéã¸ã®æ¨¹èã®é

ç½®ä½æ¥­ãæ¨¹èã«ããç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçã®çµåä½æ¥­ç­ãããå®¹æã«ãªãã

Â Â The face plate is further a plurality of non-magnetic pieces having an upward U-shape, each being between the adjacent first and second magnetic pole pieces on the side opposite to the work surface of the second magnetic pole piece. If a plurality of piece members that have received the points are included, the positional relationship between the first and second magnetic pole pieces is stabilized, so that the resin placement operation between the first and second magnetic pole pieces, the first resin is used. In addition, the connecting work of the second magnetic pole pieces becomes easier.

ä»¥ä¸ãå³é¢ã«ç¤ºãæ¬çºæã®é¢æ¿ãç¨ããç£æ°ãã£ãã¯ã®å®æ½ä¾ã«ã¤ãã¦èª¬æããã

Â Â Embodiments of a magnetic chuck using the face plate of the present invention shown in the drawings will be described below.

å³ï¼ãå³ï¼ãåç

§ããã«ãç£æ°ãã£ãã¯ï¼ï¼ã¯ãå¹³é¢é·æ¹å½¢ãããç®±åã®æ¬ä½ï¼ï¼ã¨ãæ¬ä½ï¼ï¼ã®ä¸ã«é

ç½®ãããå¹³é¢é·æ¹å½¢ãããå¹³æ¿ç¶ã®é¢æ¿ï¼ï¼ã¨ãé¢æ¿ï¼ï¼ã«é

ç½®ãããã³å­ç¶ã®è¤æ°ã®ã³ãé¨æï¼ï¼ã¨ãå«ãã

Â Â 1 to 4, the magnetic chuck 10 is arranged on a box-shaped main body 12 having a flat rectangular shape, a flat face plate 14 having a flat rectangular shape disposed on the main body 12, and the face plate 14. And a plurality of U-shaped piece members 16.

æ¬ä½ï¼ï¼ã¯ãå¹³æ¿ç¶ã®åºé¨åã³åºé¨ã®å¨ç¸ããç«ã¡ä¸ããå¨å£é¨ï¼ï¼ï½ã«ããä¸æ¹ã«éå£ããç®±å½¢ã®ãã¦ã¸ã³ã°ï¼ï¼ãåããç£æçºçæºï¼å³ç¤ºããï¼ããã¦ã¸ã³ã°ï¼ï¼å

ã«é

ç½®ãã¦ããããã¦ã¸ã³ã°ï¼ï¼ã¯ãæ¬ä½ï¼ï¼ã®é·ææ¹åï¼ç¬¬ï¼ã®æ¹åï¼ã«é·ãç´°ç®±ã®å½¢ã«è£½ä½ããã¦ããã

Â Â The main body 12 includes a box-shaped housing 18 opened upward by a flat bottom portion and a peripheral wall portion 18 a rising from the peripheral edge of the bottom portion, and a magnetic flux generation source (not shown) is disposed in the housing 18. The housing 18 is manufactured in the shape of a narrow box that is long in the longitudinal direction (first direction) of the main body 12.

ç£æçºçæºã¯ãéå¿ã¨ãã®éå¿ã«å·»ãããå±ç£ã³ã¤ã«ã¨ãåããé»ç£ç³è£

ç½®ãè¤æ°ã®åºå®æ°¸ä¹

ç£ç³ã¨è¤æ°ã®å¯åç£ç³ã¨ãåããæ°¸ä¹

ç£ç³è£

ç½®ãé»ç£ç³è£

ç½®ã¨æ°¸ä¹

ç£ç³å±¤å¤ã¨ãåããæ°¸é»ç£ç³è£

ç½®ç­ãé©å®ãªç£ç³è£

ç½®ãç¨ãããã¨ãã§ããã

Â Â The magnetic flux generation source includes an electromagnet device including an iron core and an exciting coil wound around the iron core, a permanent magnet device including a plurality of fixed permanent magnets and a plurality of movable magnets, and an electromagnet device and a permanent magnet layer value. Appropriate magnet devices such as permanent electromagnet devices can be used.

ããããä»¥ä¸ã®èª¬æã§ã¯ããã¦ã¸ã³ã°ï¼ï¼å

ã«ãã£ã¦ãã¦ã¸ã³ã°ï¼ï¼ã®å¹

æ¹åï¼ç¬¬ï¼ã®æ¹åï¼ä¸­å¤®é¨ããã¦ã¸ã³ã°ï¼ï¼ã®é·ææ¹åï¼ç¬¬ï¼ã®æ¹åï¼ã¸ä¼¸ã³ãéå¿ã¨ãè©²éå¿ã«å·»ãæããããå±ç£ã³ã¤ã«ã¨ãåããé»ç£ç³è£

ç½®ãç¨ãããã¦ãããã®ã¨ããã

Â Â However, in the following description, an iron core that is in the housing 18 and extends in the longitudinal direction (first direction) of the housing 18 in the width direction (second direction) of the housing 18 is wound around the iron core. It is assumed that an electromagnet device including an exciting coil is used.

ãã¦ã¸ã³ã°ï¼ï¼ã¨éå¿ã¨ã¯ãç£æ§ææã§ä½ããã¦ãããã¾ãéå¿ã®ä¸æ¹ã®ç£æ¥µé¢ã¨ãã¦ã¸ã³ã°ï¼ï¼ã®åºé¨ã¨ã«ããã¦ç£æ°çã«æ¥ç¶ããã¦ãããé¢æ¿ï¼ï¼ã¯ããã¦ã¸ã³ã°ï¼ï¼ã®éæ¾ç«¯ãééããããã«ãã¦ã¸ã³ã°ï¼ï¼ã®ä¸ã«é

ç½®ããã¦ããã¦ã¸ã³ã°ï¼ï¼ã«åºå®ããã¦ããã

Â Â The housing 18 and the iron core are made of a magnetic material, and are magnetically connected to one magnetic pole surface of the iron core and the bottom of the housing 18. The face plate 14 is disposed on the housing 18 so as to close the open end of the housing 18 and is fixed to the housing 18.

é¢æ¿ï¼ï¼ã¯ãããã®é·ææ¹åï¼ç¬¬ï¼ã®æ¹åï¼ã«ééãããã¦é

ç½®ããã¦é¢æ¿ï¼ï¼ã®å¹

æ¹åï¼ç¬¬ï¼ã®æ¹åï¼ã«ä¼¸ã³ãè¤æ°ã®ç¬¬ï¼ã®ç£æ¥µçï¼ï¼ã¨ããããããç¬¬ï¼ã®æ¹åã«é£ãåãç¬¬ï¼ã®ç£æ¥µçï¼ï¼ã®éã«é

ç½®ããã¦ç¬¬ï¼ã®æ¹åã«ä¼¸ã³ãè¤æ°ã®ç¬¬ï¼ã®ç£æ¥µçï¼ï¼ã¨ããããããç¬¬ï¼ã®æ¹åã«é£ãåãç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçï¼ï¼åã³ï¼ï¼ã®éã«é

ç½®ãããè¤æ°ã®ã¹ãã¼ãµï¼ï¼ã¨ãå«ãã

Â Â The face plate 14 has a plurality of first magnetic pole pieces 20 arranged in the longitudinal direction (first direction) of the face plate 14 and extending in the width direction (second direction) of the face plate 14. A plurality of second magnetic pole pieces 22 disposed between the first magnetic pole pieces 20 adjacent in the direction and extending in the second direction, and the first and second magnetic pole pieces 20 adjacent to each other in the first direction. And a plurality of spacers 24 disposed between the first and second spacers 22.

ç¬¬ï¼ã®ç£æ¥µçï¼ï¼ã¯ããã¦ã¸ã³ã°ï¼ï¼ã®å¨å£é¨ã«ç£æ°çã«æ¥ç¶ããã¦ããããç£æçºçæºã®éå¿ããç£æ°çã«çµ¶ç¸ããã¦ãããç¬¬ï¼ã®ç£æ¥µçï¼ï¼ã¯ãç£æçºçæºã®éå¿ã®ä»æ¹ã®æ¥µé¢ã«ç£æ°çã«æ¥ç¶ããã¦ãããããã¦ã¸ã³ã°ï¼ï¼ã®å¨å£é¨ããç£æ°çã«çµ¶ç¸ããã¦ããã

Â Â The first magnetic pole piece 20 is magnetically connected to the peripheral wall portion of the housing 18, but is magnetically insulated from the iron core of the magnetic flux generation source. The second magnetic pole piece 22 is magnetically connected to the other pole face of the iron core of the magnetic flux generation source, but is magnetically insulated from the peripheral wall portion of the housing 18.

ç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçï¼ï¼åã³ï¼ï¼ã¨ã¹ãã¼ãµï¼ï¼ã¨ã¯ãç£æ§ä½ãå¸çããä½æ¥­é¢ãæ¬ä½ï¼ï¼ã¨åå¯¾å´ã«å

±åãã¦å½¢æãã¦ããã

Â Â The first and second magnetic pole pieces 20 and 22 and the spacer 24 jointly form a work surface for attracting the magnetic material on the side opposite to the main body 12.

ç¬¬ï¼ã®ç£æ¥µçï¼ï¼ã¯ãç¬¬ï¼ã®æ¹åã«é£ãåãï¼ã¤ã®ç¬¬ï¼ã®ç£æ¥µçï¼ï¼ãæ¬ä½ï¼ï¼å´ã®ç®æã«ããã¦é£çµé¨ï¼ï¼ã«ããä¸ä½çã«é£çµããã¦ãé£çµé¨ï¼ï¼ã¨å

±ã«ç£æ¥µçãã­ãã¯ã«å½¢æããã¦ããã

Â Â The first magnetic pole piece 20 is formed by connecting two first magnetic pole pieces 20 adjacent to each other in the first direction integrally by a connecting portion 26 at a position on the main body 12 side, and forming the magnetic pole piece block together with the connecting portion 26. Has been.

å³ç¤ºã®ä¾ã§ã¯ãé£ãåãï¼ã¤ã®ç¬¬ï¼ã®ç£æ¥µçï¼ï¼ã¯ãï¼ã¤ã®é£çµé¨ï¼ï¼ã«ããä¸ä½çã«é£çµããã¦ãããããããé£ãåãï¼ã¤ã®ç¬¬ï¼ã®ç£æ¥µçï¼ï¼ã¯ãå°ãªãã¨ãï¼ã¤ã®é£çµé¨ï¼ï¼ã«ããä¸ä½çã«é£çµããã¦ããã°ããã

Â Â In the illustrated example, two adjacent first magnetic pole pieces 20 are integrally connected by three connecting portions 26. However, the two adjacent first magnetic pole pieces 20 may be integrally connected by at least one connecting portion 26.

åã³ãé¨æï¼ï¼ã¯ãç¬¬ï¼ã®æ¹åã«é£ãåãï¼ã¤ã®ç¬¬ï¼ã®ç£æ¥µçï¼ï¼ã®éã«ãã£ã¦é£çµé¨ï¼ï¼ã®ä¸ã«ãç¬¬ï¼ã®ç£æ¥µçï¼ï¼ãä¸æ¹ããåãå

¥ããç¶æ

ã«ãããªãã¡ä¸æ¹ã«éæ¾ããç¶æ

ã«é

ç½®ããã¦ããã

Â Â Each piece member 16 is located between two first magnetic pole pieces 20 adjacent to each other in the first direction and receives the second magnetic pole piece 22 from above on the connecting portion 26, that is, a state where it opens upward. Is arranged.

ç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçï¼ï¼åã³ï¼ï¼ã¨é£çµé¨ï¼ï¼ã¨ã¯ãç£æ§ææã§è£½ä½ããã¦ãããããã«å¯¾ããã³ãé¨æï¼ï¼ã¨ã¹ãã¼ãµï¼ï¼ã¨ã¯ãç¬¬ï¼ã®æ¹åã«é£ãåãç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçï¼ï¼åã³ï¼ï¼ã®ç£æ°çéé¢ã®ããã«éç£æ§ææã§è£½ä½ããã¦ããã

Â Â The first and second magnetic pole pieces 20 and 22 and the connecting portion 26 are made of a magnetic material. On the other hand, the top member 16 and the spacer 24 are made of a nonmagnetic material for magnetic isolation of the first and second magnetic pole pieces 20 and 22 adjacent in the first direction.

ç¬¬ï¼ã®æ¹åã«é£ãåãç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçï¼ï¼åã³ï¼ï¼ã®ééã¯ãã³ãé¨æï¼ï¼ã¨ã¹ãã¼ãµï¼ï¼ã«ããæå®ã®å¤ã«ç¶­æããã¦ããã

Â Â The interval between the first and second magnetic pole pieces 20 and 22 adjacent to each other in the first direction is maintained at a predetermined value by the piece member 16 and the spacer 24.

åã¹ãã¼ãµï¼ï¼ã¯ãç¬¬ï¼ã®æ¹åã«é£ãåãç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçï¼ï¼åã³ï¼ï¼ãç¸äºã«æ¥çããæ©è½ãæããããã®ãããã¹ãã¼ãµï¼ï¼ã¯ãé£ãåãç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçï¼ï¼åã³ï¼ï¼ã®éã«å

å¡«ãããéç£æ§ã®åææ¨¹èææã§è£½ä½ããã¦ãããåææ¨¹èææã¨ãã¦ã¯ãç±å¯å¡æ§åã³ç±ç¡¬åæ§ã®ãããã®æ¨¹èã§ãã£ã¦ãããã

Â Â Each spacer 24 has a function of adhering the first and second magnetic pole pieces 20 and 22 adjacent to each other in the first direction. For this reason, the spacer 24 is made of a nonmagnetic synthetic resin material filled between the adjacent first and second magnetic pole pieces 20 and 22. The synthetic resin material may be either thermoplastic or thermosetting resin.

å³ç¤ºã®ä¾ã§ã¯ãé¢æ¿ï¼ï¼ã¯ãæå®ã®åãå¯¸æ³ãæããæ¿ä½ã®ä¸é¢ã®å´ããæå®ã®æ·±ãå¯¸æ³åã³ä¸å®ã®ãããã®è¤æ°ã®ç¬¬ï¼ã®æºãè¨­ãã¦è©²ç¬¬ï¼ã®æºã®éã®é¨ä½åã³é¢æ¿ã®é·ææ¹åä¸¡ç«¯ã®é¨ä½ãç¬¬ï¼ã®ç£æ¥µçï¼ï¼ã¨ããã¾ããæ¿ä½ã®ä¸é¢ã®å´ã«ãã£ã¦ãã¦ã¸ã³ã°ï¼ï¼å

ã®éå¿ã®ä¸é¢ã¨å¯¾åããé¨ä½ã«ç¬¬ï¼ã®æ¹åã¸ä¼¸ã³ãã¤ç¬¬ï¼ã®æºã«é£éããç¬¬ï¼ã®æºãå½¢æããç¬¬ï¼ã®æºå

ã«ç¬¬ï¼ã®ç£æ¥µçï¼ï¼ãåå®¹ããç¬¬ï¼ã®ç£æ¥µçï¼ï¼ãéå¿ã«ç£æ°çã«æ¥è§¦ãããã¹ãç¬¬ï¼ã®ç£æ¥µçï¼ï¼ã®ä¸é¨ãç¬¬ï¼ã®æºããçªåºãããç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçï¼ï¼ï¼ï¼ï¼ã®éã«ã¹ãã¼ãµï¼ï¼ãå

å¡«ããææ³ã«ããå½¢æããã¦ããã

Â Â In the example shown in the drawing, the face plate 14 is provided with a plurality of first grooves having a predetermined depth dimension and a constant pitch from the upper surface side of the plate body having a predetermined thickness dimension. The first pole piece 20 is the first pole piece 20 at both ends in the longitudinal direction of the portion and the face plate, and extends in the first direction to a portion on the lower surface side of the plate body and facing the upper surface of the iron core in the housing 18. The second magnetic pole piece 22 is formed so that the second magnetic pole piece 22 is accommodated in the first groove, and the second magnetic pole piece 22 is magnetically brought into contact with the iron core. Is protruded from the second groove, and the spacer 24 is filled between the first and second magnetic pole pieces 20 and 22.

ããè©³ç´°ã«ã¯ãé¢æ¿ï¼ï¼ã¯ãä»¥ä¸ã®ããã«è£½ä½ãããã¨ãã§ããã

Â Â More specifically, the face plate 14 can be manufactured as follows.

å

ããæ¿ä½ã«ååå å·¥åã³ç ç£¨å å·¥ãæ½ããã¨ã«ãããç¬¬ï¼ã®ç£æ¥µçï¼ï¼ã¨é£çµé¨ï¼ï¼ã¨ãåããç£æ¥µçãã­ãã¯ãè£½ä½ãããã

Â Â First, a magnetic pole piece block including the first magnetic pole piece 20 and the connecting portion 26 is manufactured by cutting and polishing the plate body.

æ¬¡ãã§ãåã³ãé¨æï¼ï¼ãé£ãåãç¬¬ï¼ã®ç£æ¥µçï¼ï¼ã®éã«ãã£ã¦é£çµé¨ï¼ï¼ã®ä¸ã«é

ç½®ãããã¨å

±ã«ãåç¬¬ï¼ã®ç£æ¥µçï¼ï¼ãé£ãåãç¬¬ï¼ã®ç£æ¥µçï¼ï¼ã®éã«ãã£ã¦ã³ãé¨æï¼ï¼ã«åµåãããç¶æ

ã«é

ç½®ãããã

Â Â Next, each of the top members 16 is disposed between the adjacent first magnetic pole pieces 20 and on the connecting portion 26, and each of the second magnetic pole pieces 22 is disposed between the adjacent first magnetic pole pieces 20 to be the top member. 16 is arranged in a state of being fitted to the 16.

æ¬¡ãã§ãã¨ãã­ã·ç³»ã®æ¨¹èã®ããã«ãç¡¬è³ªã§éç£æ§ã®åææ¨¹èææãé£ãåãç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçï¼ï¼åã³ï¼ï¼ã®éã«æ³¨å

¥ããªãã¡å

å¡«ãããããããã®åææ¨¹èãç¡¬åãããã¨ã«ãããé£ãåãç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçï¼ï¼åã³ï¼ï¼ãæ¥åãããã¨å

±ã«ãã¹ãã¼ãµï¼ï¼ãå½¢æãããã

Â Â Next, a hard, non-magnetic synthetic resin material such as an epoxy resin is injected or filled between the adjacent first and second magnetic pole pieces 20 and 22. When these synthetic resins are cured, the adjacent first and second magnetic pole pieces 20 and 22 are joined, and the spacer 24 is formed.

ã¹ãã¼ãµï¼ï¼ç¨ã®åææ¨¹èã¨ãã¦ãç¹ã«ç±è¨å¼µä¿æ°ãå°ããç±ç¡¬åæ§æ¨¹èãç¨ãããã¨ãã§ããã

Â Â As the synthetic resin for the spacer 24, a thermosetting resin having a particularly small thermal expansion coefficient can be used.

æ¨¹èã®å

å¡«æãé£ãåãç¬¬ï¼ã®ç£æ¥µçï¼ï¼ã®ä½ç½®é¢ä¿ä¸¦ã³ã«é£ãåãç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µï¼ï¼åã³ï¼ï¼ã®ä½ç½®é¢ä¿ãå®å®ãã¦ãããããç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçï¼ï¼åã³ï¼ï¼éã¸ã®æ¨¹èã®é

ç½®ä½æ¥­ãæ¨¹èã«ããç¬¬ï¼åã³ç¬¬ï¼ã®ç£æ¥µçï¼ï¼åã³ï¼ï¼ã®çµåä½æ¥­ç­ãå®¹æã«ãªãã

Â Â Since the positional relationship between the adjacent first magnetic pole pieces 20 and the positional relationship between the adjacent first and second magnetic poles 20 and 22 are stable when the resin is filled, the first and second magnetic pole pieces 20 and 22 are stable. The arrangement | positioning operation | work of resin in between, the joint operation | work of the 1st and 2nd magnetic pole pieces 20 and 22 by resin, etc. become easy.

æ¬¡ãã§ãä½æ¥­é¢ã¨åå¯¾å´ã«ç©ºéãå­å¨ããå ´åã¯ããã®ãããªç©ºéã«ã¦ã¬ã¿ã³æ¨¹èã®ããã«è»è³ªã§èæ°´æ§ãæããåææ¨¹èææãå

å¡«ããããè»è³ªã®åææ¨¹èææã®å

å¡«ã«ãããã¹ãã¼ãµï¼ï¼ã®ã¯ã©ãã¯çºçæãçé¢å¥é¢çºçæã®é²æ°´æ§ãé«ããªãã

Â Â Next, when a space exists on the side opposite to the work surface, such a space is filled with a soft and water-resistant synthetic resin material such as urethane resin. By filling the soft synthetic resin material, the waterproofness when the spacer 24 is cracked or when the interface peeling occurs is enhanced.

ãã®å¾ãä½æ¥­é¢åã³ããã¨åå¯¾å´ã®é¢ã®ä»ä¸ãå å·¥ãè¡ãããã

Â Â Thereafter, finishing of the work surface and the surface on the opposite side is performed.

ä¸è¨ã®ããã«è£½ä½ãããé¢æ¿ï¼ï¼ã¯ãç¬¬ï¼ã®ç£æ¥µçï¼ï¼ããã¦ã¸ã³ã°ï¼ï¼ã®ç¿çé¨ï¼ï¼ï½ã®ä¸é¢ã«æ¥è§¦ããç¬¬ï¼ã®ç£æ¥µçï¼ï¼ãç£æçºçå¨ã®ç£æ¥µã®ä»æ¹ã®é¢ã«æ¥è§¦ããç¶æ

ã«ãæ¬ä½ï¼ï¼ã«åé¢å¯è½ã«çµåããã¦ãç£æ°ãã£ãã¯ï¼ï¼ã«çµã¿ç«ã¦ãããã

Â Â In the face plate 14 manufactured as described above, the first magnetic pole piece 20 is in contact with the upper surface of the learning part 18a of the housing 18, and the second magnetic pole piece 22 is in contact with the other face of the magnetic pole of the magnetic flux generator. The magnetic chuck 10 is assembled to the main body 12 in a separable manner.

é¢æ¿ï¼ï¼ã«ããã°ãã¹ãã¼ãµï¼ï¼ã¨ãã¦ãé»é

æ¿ã®ä»£ããã«éç£æ§ã®åææ¨¹èãç¨ãã¦ãããããåç°ãç¨ããå¿

è¦ããªãããã®ãããä»¥ä¸ã®ãããªæè¡çå¹æãå¥ããã

Â Â According to the face plate 14, since the nonmagnetic synthetic resin is used as the spacer 24 instead of the brass plate, it is not necessary to use solder. For this reason, there exist the following technical effects.

åç°ãç¨ããå ´åãï¼ï¼ï¼Â°ï¼£ãè¶

ããå ç±å¦çãå¿

è¦ã§ããããæ¨¹èã®å ´åãï¼ï¼ï¼Â°ï¼£ä»¥ä¸ã®å ç±å¦çã§ãããããã«ãããé¢æ¿ï¼ï¼ã«æ®å­ããç±å¿åãèããä½æ¸ããã

Â Â When solder is used, heat treatment exceeding 300 Â° C. is necessary, but in the case of resin, heat treatment at 100 Â° C. or less is sufficient. Thereby, the thermal stress remaining on the face plate 14 is remarkably reduced.

åç°ãç¨ããå ´åãé»é

æ¿ã®æ¥åæã«ç¨ãããã©ãã¯ã¹ãæ¥åé¢ã«æ®å­ããããã«ããä½æ¥­é¢ã«ãã³ãçºçãããããããæ¨¹èãç¨ããã¨ãè

é£æ§ç©è³ªãæ®çãããä½æ¥­é¢ã«è

é£ãçããªãã

Â Â When solder is used, the flux used when the brass plates are joined remains on the joining surface, thereby causing rust on the work surface. However, when the resin is used, no corrosive substance remains and the work surface does not corrode.

éãç¨ããªãåç°ãå­å¨ãããããã®ãããªåç°ãç¨ããã¨ãéå

¥ãåç°ã¨æ¯è¼ãã¦æ¿¡ãæ§ãæªããããæ¥åä¸è¯ãæ®çãã©ãã¯ã¹ã®å¢å ã®åé¡ãçããåè³ªã®ä½ä¸ãæãã

Â Â There are solders that do not use lead, but if such solders are used, the wettability is poor compared to lead-containing solders, causing problems such as poor bonding and an increase in residual flux, leading to a reduction in quality.

éç£æ§åéã¯ãããã¨ç£æ¥µã¨ã®ã¤ãªã³åå¾åã®ç¸éããé»é£ãçãããã¨ããããã¾ãéå±ã¤ãªã³ãç åæ¶²ã«æº¶ãåºãã¦é·æéã®ä½¿ç¨ã«ããã¦ç£æ¥µã«å¯¾ãæ®µå·®ï¼å¹ã¿ï¼ãçãããããããæ¨¹èãç¨ããã¨ããã®ãããªç¾è±¡ãçºçããªãã

Â Â In the nonmagnetic alloy, galvanic corrosion may occur due to the difference in ionization tendency between this and the magnetic pole, and metal ions are dissolved in the grinding fluid, and a step (dent) is formed with respect to the magnetic pole in long-term use. However, when resin is used, such a phenomenon does not occur.

ç£æ°ãã£ãã¯ï¼ï¼ã®ä½¿ç¨æãéå¿ã®å´ãä¾ãã°ï¼³æ¥µã¨ãªãããã«å±ç£ã³ã¤ã«ï¼ï¼ã«é»æµãä¾çµ¦ããããããã«ãããç¬¬ï¼ã®ç£æ¥µçï¼ï¼ã¯éå¿åã³ãã¦ã¸ã³ã°ï¼ï¼ã®å¨å£é¨ï¼ï¼ï½ãä»ãã¦ï¼®ã«ä»å¢ãããç¬¬ï¼ã®ç£æ¥µçï¼ï¼ã¯éå¿ãä»ãã¦ï¼³ã«ä»å¢ãããã

Â Â When the magnetic chuck 10 is used, a current is supplied to the exciting coil 20 so that the iron core side is, for example, the S pole. Accordingly, the first magnetic pole piece 20 is biased to N via the iron core and the peripheral wall portion 18a of the housing 18, and the second magnetic pole piece 22 is biased to S via the iron core.

ä¸è¨ã®çµæãé¢æ¿ï¼ï¼ã®ä½æ¥­é¢ãå±ç£ç¶æ

ã«ããããç£æ§ä½ã¯ä½æ¥­é¢ã«å¸çããããå±ç£ã³ã¤ã«ï¼ï¼ã¸ã®é»æµã®ä¾çµ¦ãåæ­¢ãããã¨ãä½æ¥­é¢ãéå±ç£ç¶æ

ã«ããããå¸çããã¦ããç£æ§ä½ãè§£æ¾ãããã

Â Â As a result, the work surface of the face plate 14 is in an excited state, and the magnetic material is attracted to the work surface. When the supply of current to the exciting coil 20 is stopped, the work surface is brought into a non-excited state, and the attracted magnetic body is released.

æ¬çºæã¯ãä¸è¨å®æ½ä¾ã«éå®ãããããã®è¶£æ¨ãé¸è±ããªãéããç¨®ã

å¤æ´ãããã¨ãã§ããã

Â Â The present invention is not limited to the above embodiments, and various modifications can be made without departing from the spirit of the present invention.

æ¬çºæã®é¢æ¿ãåããç£æ°ãã£ãã¯ã®ä¸å®æ½ä¾ãç¤ºããä¸é¨ãåè§£ããæè¦å³ã§ããã1 is a partially exploded perspective view showing an embodiment of a magnetic chuck provided with a face plate of the present invention.

å³ï¼ã«ç¤ºãé¢æ¿ãããã®åºé¢ã®å´ããç¤ºãæè¦å³ã§ãããIt is a perspective view which shows the faceplate shown in FIG. 1 from the bottom face side.

å³ï¼ã«ç¤ºãé¢æ¿ãããã®ç¬¬ï¼ã®æ¹åã«ãããã³ãé¨æã®é

ç½®ç®æéã®ç®æã§åæ­ããæ¡å¤§æ­é¢å³ã§ãããIt is the expanded sectional view which cut | disconnected the faceplate shown in FIG. 1 in the location between the arrangement | positioning locations of the piece member in the 2nd direction.

å³ï¼ã«ç¤ºãé¢æ¿ãããã®ã³ãé¨æã®é

ç½®ç®æã§åæ­ããæ¡å¤§æ­é¢å³ã§ãããIt is the expanded sectional view which cut | disconnected the face plate shown in FIG. 1 in the arrangement | positioning location of this piece member.

ç¬¦å·ã®èª¬æExplanation of symbols

ï¼ï¼ ç£æ°ãã£ãã¯

ï¼ï¼ æ¬ä½

ï¼ï¼ é¢æ¿

ï¼ï¼ ã³ãé¨æ

ï¼ï¼ ãã¦ã¸ã³ã°

ï¼ï¼ ç¬¬ï¼ã®ç£æ¥µç

ï¼ï¼ ç¬¬ï¼ã®ç£æ¥µç

ï¼ï¼ ã¹ãã¼ãµ

ï¼ï¼ é£çµé¨

DESCRIPTION OF SYMBOLS 10 Magnetic chuck 12 Main body 14 Face plate 16 Frame member 18 Housing 20 1st magnetic pole piece 22 2nd magnetic pole piece 24 Spacer 26 Connection part

## Cited patent documents

- [JP-S5075485-A](https://patents.google.com/patent/JPS5075485A/en) — EXA
- [JP-S5884831-A](https://patents.google.com/patent/JPS5884831A/en) — EXA
- [JP-S6212524-Y2](https://patents.google.com/patent/JPS6212524Y2/en) — SEA
- [JP-S62136332-A](https://patents.google.com/patent/JPS62136332A/en) — SEA
- [JP-S63251139-A](https://patents.google.com/patent/JPS63251139A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
