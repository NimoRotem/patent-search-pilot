# 44. Gripping device for transferring a magnetic dipole rod

- **Archive rank:** 44 of 50
- **Publication:** [US-2023173689-A1](https://patents.google.com/patent/US20230173689A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/075801583/publication/US20230173689A1?q=pn%3DUS20230173689A1)
- **Publication date:** 2023-06-08
- **Filing date:** 2021-04-30
- **Earliest priority:** 2020-05-07
- **Family:** 75801583
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery

## Parties

- **Applicant / assignee:** BAYER AG
- **Inventors:** WITSCH DANIEL

## Abstract

The invention relates to a gripping device for transferring a magnetic dipole rod as well as to a robot with a robot arm, to which the gripping device is attached. The invention furthermore relates to a magazine for providing one or more magnetic dipole rods, to a system for transferring a magnetic dipole rod, and to the use of the system. The gripping device for a magnetic dipole rod has a metal bolt made of a ferromagnetic material, the diameter of which is smaller than the diameter of the magnetic dipole rod. The metal bolt can assume at least two different positions, wherein the dipole rod adheres to the front end of the metal bolt in the first position and is stripped off from the front end of the metal rod during the transition into the second position.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/72/48/53/8b5c57f786840f/US20230173689A1-20230608-D00000.png)

![Sketch 1 for US-2023173689-A1](https://patentimages.storage.googleapis.com/72/48/53/8b5c57f786840f/US20230173689A1-20230608-D00000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/47/52/e5/b60c1b2c38fa18/US20230173689A1-20230608-D00001.png)

![Sketch 2 for US-2023173689-A1](https://patentimages.storage.googleapis.com/47/52/e5/b60c1b2c38fa18/US20230173689A1-20230608-D00001.png)

[Sketch 3](https://patentimages.storage.googleapis.com/26/74/ec/accceaac2041f9/US20230173689A1-20230608-D00002.png)

![Sketch 3 for US-2023173689-A1](https://patentimages.storage.googleapis.com/26/74/ec/accceaac2041f9/US20230173689A1-20230608-D00002.png)

[Sketch 4](https://patentimages.storage.googleapis.com/d7/3e/d7/01f3dac444b500/US20230173689A1-20230608-D00003.png)

![Sketch 4 for US-2023173689-A1](https://patentimages.storage.googleapis.com/d7/3e/d7/01f3dac444b500/US20230173689A1-20230608-D00003.png)

[Sketch 5](https://patentimages.storage.googleapis.com/8a/04/db/c6e74cb1602070/US20230173689A1-20230608-D00004.png)

![Sketch 5 for US-2023173689-A1](https://patentimages.storage.googleapis.com/8a/04/db/c6e74cb1602070/US20230173689A1-20230608-D00004.png)

[Sketch 6](https://patentimages.storage.googleapis.com/b8/d2/ed/70d9925a598daf/US20230173689A1-20230608-D00005.png)

![Sketch 6 for US-2023173689-A1](https://patentimages.storage.googleapis.com/b8/d2/ed/70d9925a598daf/US20230173689A1-20230608-D00005.png)

## Claims

### Claim 1

A gripping device for a magnetic dipole rod, having a metal bolt made of a ferromagnetic material with a front end and a rear end, the diameter of which is smaller than the diameter of the magnetic dipole rod, wherein the metal bolt can assume at least two different positions, and the dipole rod adheres to the front end of the metal bolt in a first position and is stripped off from the front end of the metal bolt during the transition into a second position. 2 . The gripping device according to claim 1 , wherein the gripping device has a housing with a channel which has an open end and a section, referred to as the bolt guide section, the diameter of which is smaller than the diameter of the magnetic dipole rod; wherein the metal bolt is mounted in the channel so as to be movable in the longitudinal direction and, in the first position, the front end of the metal bolt is situated in a region of the open end of the channel and, in the second position, the front end of the metal bolt is situated in the bolt guide section. 3 . The gripping device according to claim 2 , wherein the channel has, between the open end thereof and the bolt guide section, a channel section, referred to as a receiving section, the diameter of which is matched to the magnetic dipole rod in such a way that the rod can be received into the receiving section with sufficient clearance. 4 . The gripping device according to claim 3 , wherein the metal bolt can assume a further position, in which the front end of the metal bolt is situated in the receiving section. 5 . The gripping device claim 3 , wherein the length of the receiving section is in a range of from 80% to 150% of the length of the magnetic dipole rod, and the diameter of the receiving section is from 102% to 120% of the diameter of the magnetic dipole rod. 6 . The gripping device according to claim 1 , wherein a rear end of the metal bolt is connected to a means for producing a translational movement. 7 . The gripping device according to claim 6 , wherein the means for producing a translational movement is a motor, optionally a linear motor, stepping motor or a servo motor with a corresponding transmission. 8 . The gripping device according to, claim 2 wherein a rear end of the metal bolt has a widening, and the channel has a further section, the diameter and cross section of which are matched to the diameter and cross section of the widening, and the length of which is dimensioned in such a way that the metal bolt can assume the positions according to claim 1 . 9 . The gripping device according to, claim 3 wherein there is a magnetic sensor on the outside of the housing in a region of the receiving section. 10 . A robot having a robot arm to which the gripping device according to claim 1 is attached in a fixed or removable manner. 11 . The robot according to claim 10 , wherein the robot comprises a control system for controlling the robot arm and the gripping device. 12 . A magazine for providing one or more magnetic dipole rods, comprising a plate comprising a non-magnetic material with a top side and a bottom side, wherein the top side has one or more wells with a depth C and the diameters of the wells are matched to the one or more magnetic dipole rods in such a way that the magnetic dipole rod or rods can be received into the wells with a large clearance. 13 . The magazine according to claim 12 , wherein the depth C of the wells is in a range of from 0.5 mm to 2.5 mm less than the length of the one or more magnetic dipole rods. 14 . The magazine according to claim 12 , wherein the diameter of the wells is in a range of from 105% to 220% of the diameter of the one or more magnetic dipole rods. 15 . The magazine according to claim 12 , wherein the diameter of the wells is in a range of from 1 mm to 2.5 mm greater than the diameter of the one or more magnetic dipole rods. 16 . The magazine according to claim 12 , wherein the wells are arranged in regular rows and columns, wherein the minimum spacing of the individual wells with respect to one another corresponds to at least three times, optionally at least four times, and particularly optionally at least five times the diameter of the one or more magnetic dipole rods. 17 . A system for transferring a magnetic dipole rod, having a robot with a robot arm according to claim 10 and a magazine for providing one or more magnetic dipole rods, comprising a plate comprising a non-magnetic material with a top side and a bottom side, wherein the top side has one or more wells with a depth C and the diameters of the wells are matched to the one or more magnetic dipole rods in such a way that the magnetic dipole rod or rods can be received into the wells with a large clearance. 18 . A product comprising the system according to claim 17 for transferring a magnetic dipole rod.

## Full description

**[p0001]**

The invention relates to a gripping device for transferring a magnetic dipole rod as well as to a robot with a robot arm, to which the gripping device is attached. The invention furthermore relates to a magazine for providing one or more magnetic dipole rods, to a system for transferring a magnetic dipole rod, and to the use of the system. For many chemical experiments, the mixing of liquids with a magnetic stirrer is the preferred method for ensuring good mixing. The liquid is placed in one or more sample containers on a plate, under which a magnet rotates at a controllable speed. This magnet acts on a second, usually rod-shaped magnet, the magnetic dipole rod, located in the sample container and sets the liquid in motion via the said rod. The magnetic dipole rod is usually encased in plastic, e.g. PTFE, or glass in order to reduce friction and make it chemically inert. In everyday laboratory practice, many sample containers are nowadays prepared in parallel for tests. In this process, microtitre plates, each of which has around a hundred or even more wells, play a major role. A typical example are 96-well microtitre plates. The wells of a microtitre plate are each supplied with a liquid sample. This is done automatically throughout in order to cope with a high throughput in a short time,

**[p0002]**

It is difficult to handle magnetic dipole rods in automated processes since, depending on the design, they may be very small, e.g. just 10 mm long with a diameter of 3 mm. Their surface is generally slippery since they are coated with Teflon, for example. In addition, a number of magnetic dipole rods adhere to one another owing to their magnetism. The magnetic properties, in particular, do not allow any of the customary separation methods, for example by means of vibratory feeders or sorting screws. Moreover, because of their small size, reliable handling of the magnetic dipole rods by universal mechanical-clamping grippers is difficult. In addition, there is the fact that pre-fitting sample containers with magnetic dipole rods manually may not be possible, depending on the process. Owing to the magnetism of the magnetic dipole rods, laboratory equipment (e.g. scales) will be disturbed if after the positioning of the magnetic dipole rods in the sample container, the predetermined amount of liquid sample is introduced.

**[p0003]**

Various types of robots have been in use for several years in the automation of processes in the laboratory, for example in the field of medical technology or analysis or in the field of molecular biology and human diagnostics. The systems in question are predominantly systems in which an actuating end of the robot arm is arranged so as to be linearly movable along three spatial axes running substantially orthogonally to one another (Cartesian XYZ systems). Such systems are sold by Tecan, Beckmann, Canberra Packard and Rosys, for example, in various designs with different numbers of robot arms. In addition, however, there are also systems on sale in which a robot arm holder can be moved linearly along a rail. An upper arm part of the robot arm is arranged pivotably on this robot arm holder, and a lower arm part of the robot arm is arranged pivotably on the upper arm part. Such systems are offered by CRS in Canada and by Zymark in the USA, for example, and are well established in the laboratory sector. Other known robot types which are suitable in conjunction with the invention are the horizontal jointed arm robot (SCARA robot=Selective Compliance Assembly Robot Arm) (manufacturers: ABB Robotics, Dürr AG, Bosch Rexroth, Adept Technology, KUKA AG, for example) or an articulated arm robot.

**[p0004]**

In all these systems, it must be possible to couple the robot arm to a whole series of different functional units in order to be able to process the samples in the desired manner It is the object of the present invention to provide a gripping device for connection to a robot arm which is known per se and which is suitable for handling magnetic dipole rods in an automated manner in order in this way to make sample preparation more effective. According to the invention, this object is achieved by a gripping device for a magnetic dipole rod, a robot having a gripping device for a magnetic dipole rod, a magazine for providing magnetic dipole rods, and a system for transferring a magnetic dipole rod, as well as the use thereof. Gripping Device The gripping device for a magnetic dipole rod has a ferromagnetic metal bolt. The diameter of the metal bolt is smaller than the diameter of the magnetic dipole rod. At the front end of the metal bolt, there is an adhesion region for the magnetic dipole rod. The adhesion between the metal bolt and the magnetic dipole rod is effected by the magnetic force. The adhesion region is distinguished from the other regions of the metal bolt solely by the fact that only the adhesion region comes into contact with the magnetic dipole rod. The metal bolt can assume at least two different positions, wherein the dipole rod adheres to the front end of the metal bolt in the first position and is stripped off from the front end of the metal bolt during the transition into the second position.

**[p0005]**

Preferably, the metal bolt is movably mounted in a channel and can be moved in its longitudinal direction between the first position, the receiving position, and the second position, the delivery position, for the magnetic dipole rod. As an option, the metal bolt can assume a holding position, which lies between the receiving position and the delivery position. The channel is situated in a housing and has an open end. The channel has a section, referred to as the bolt guide section, the diameter of which is smaller than the diameter of the magnetic dipole rod. The diameter of the bolt guide section is matched to the diameter of the metal bolt in such a way that the latter is movable in the bolt guide section and is guided by the walls of the bolt guide section. In the receiving position, the adhesion region of the metal bolt is situated in the region of the open end of the channel and, in the delivery position, the adhesion region is situated in the bolt guide section. When the front end of the metal bolt is situated in the region of the open end of the channel and the adhesion region comes into the vicinity of a magnetic dipole rod, the magnetic dipole rod remains stuck to the adhesion region of the metal bolt on account of the magnetic force. If the metal bolt is retracted in the channel and brought into the second position, in which the adhesion region is situated in the bolt guide section, the magnetic dipole rod cannot follow and is separated from the adhesion region.

**[p0006]**

In a preferred embodiment, there is, between the open end of the channel and the bolt guide section, a section, referred to as the receiving section, the diameter of which is matched to the diameter of the magnetic dipole rod in such a way that the latter can be received into the receiving section with sufficient clearance. The diameter of the receiving section is preferably dimensioned in such a way that the diameter of the receiving section is from 102% to 120% of the diameter of the magnetic dipole rod. The reduction of the diameter of the channel from the receiving section to the bolt guide section results in an edge, which is referred to below as the stripping edge. The length of the receiving section is preferably dimensioned in such a way that the length of the receiving section is in a range of from 80 to 150% of the length of the magnetic dipole rod. In this embodiment, the metal bolt can also assume a position in the channel in which the adhesion region is situated in the receiving section. This is the holding position.

**[p0007]**

The rear end of the metal bolt is connected to a means for producing a translational movement for advancing and retracting the metal bolt in the channel The means for producing the translational movement may comprise a linear motor, a stepping motor or a servo motor, possibly with a corresponding transmission. In a further embodiment, the rear end of the metal bolt has a widening of its diameter, it being possible for the metal bolt to have a circular, square, octagonal or any other desired cross section in the region of the widening. In this case, the bolt guide section is adjoined in the channel by what is referred to as a retraction section, which has an enlarged diameter, corresponding to the widening, in comparison with the bolt guide section and a cross section appropriately matched to the metal bolt, resulting in an edge, which is referred to below as the stop edge, between the retraction section and the bolt guide section. In the receiving position, one side of the widening would then rest against the stop edge and define the maximum possible movement of the metal bolt in the direction of the open end of the channel Furthermore, the connection to a motor shaft, for example a screw thread, can also be situated in the widening of the metal bolt.

**[p0008]**

As an option, a sensor or switch that responds to a magnetic field can be mounted on the outside of the housing in the region of the receiving section of the channel in order to detect whether there is a magnetic dipole rod in the receiving section. Such a switch can be a reed contact, for example. The gripping device can be connected to the arm of a robot in a fixed or removable manner Robot The invention also relates to a robot with a robot arm, to which the above-described gripping device is attached in a fixed or removable manner. The robot preferably comprises a control system for controlling the robot arm and the gripping device. Control is effected via a control system/controller with programmed control logic which is connected via known electronic communication possibilities to the robot arm, on the one hand, and to the electronic components of the gripping device, on the other hand. The control system comprises a processor, a memory and the communication component. The positions of the magazine and of the wells are also stored, as are the target positions to which the magnetic dipole rods are to be transported.

**[p0009]**

The movement of the metal bolt in the various phases of the transfer of the magnetic dipole rod is controlled by an interaction between a sensor system connected to the motor and the motor control. A position controller is used for this purpose. An initial position of the motor and thus of the metal bolt is determined by means of an end position sensor, and on this basis the motor moves the metal bolt into the receiving position, holding position and delivery position after appropriate activation by the motor control electronics. The initial position can correspond to the delivery position. If a magnetic sensor is mounted on the outside of the channel in the region of the receiving section, its signals are likewise processed by means of the control logic. Magazine The magnetic dipole rods are preferably provided in a magazine. The magazine comprises a plate made of a non-magnetic material with a top side and a bottom side. The diameter of the wells is dimensioned in such a way that the magnetic dipole rods stand more or less upright in the wells, that is to say have a large clearance. For this purpose, the diameter of the wells should be in a range of from 105% to 220% of the diameter of the magnetic dipole rods. The larger the diameter of the wells, the easier and faster the manual loading of the magazine. The diameter of the wells should preferably be in a range of from 1 mm to 2.5 mm greater than the diameter of a magnetic dipole rod.

**[p0010]**

The depth of the wells should preferably be in a range of from 0.5 mm to 2.5 mm less than the length of a magnetic dipole rod. The wells in the magazine are preferably arranged in regular rows and columns. In this case, a minimum spacing of the individual wells with respect to one another should be maintained to ensure that several magnetic dipole rods are not simultaneously attracted by the metal bolt of the gripping device when the latter is situated above a well. The minimum spacing should be greater, the greater the magnetic strength of the magnetic dipole rods. The diameter of the magnetic dipole rods provides a certain orientation. The minimum spacing of the individual wells with respect to one another should correspond to at least three times, preferably four times and particularly preferably five times, the diameter of a magnetic dipole rod. System The invention furthermore relates to a system for transferring a magnetic dipole rod, having an above-described robot with a robot arm, to which the gripping device according to the invention is attached, and an above-described magazine.

**[p0011]**

Use To carry out a transfer of a magnetic dipole rod into a target container, use is made of the system for transferring a magnetic dipole rod, having an above-described robot with a robot arm, to which the gripping device according to the invention is attached, and an above-described magazine. The transfer is carried out as described below: The robot arm is used to move the gripping device with the open end of the channel over a well of the magazine in which there is a magnetic dipole rod. The metal bolt is in the receiving position. When the open end of the channel and thus the front end of the metal bolt is situated in the immediate vicinity of the well, the magnetic dipole rod is aligned vertically. If the spacing between the front end of the metal bolt and the magnetic dipole rod falls below a minimum, one end of the magnetic dipole rod adheres to the adhesion region at the front end of the metal bolt. The metal bolt is then retracted into the holding position and thus pulls the magnetic dipole rod into the receiving section of the channel. If there is a magnetic sensor on the outside of the receiving section, it would now detect the presence of the magnetic dipole rod in the channel The robot arm moves the gripping device over the target position. The metal bolt is now retracted into the delivery position. During this process, the magnetic dipole rod strikes against the stripping edge and is separated from the adhesion region at the front end of the metal bolt.

**[p0012]**

Following the force of gravity, the magnetic dipole rod falls vertically into the target position. Any magnetic sensor that might be present would now detect that there is no longer a magnetic dipole rod in the receiving section. In this way, magnetic dipole rods can be successively transferred from the magazine to a target position. The transfer of magnetic dipole rods can be carried out automatically with a system according to the invention.

### Figures And Examples

**[p0013]**

The present invention provides a possibility for automated sample preparation with magnetic dipole rods, which can be carried out with a robot. The invention is explained in greater detail using an exemplary embodiment and with reference to the attached drawings. FIG. 1 shows a gripping device according to the invention; FIG. 2 shows a control system for the gripping device; FIG. 3 shows a side view of a magazine for magnetic dipole rods; FIG. 4 shows a plan view of a magazine for magnetic dipole rods; FIGS. 5 a - 5 i show the mode of operation of the gripping device

### Reference Signs

**[p0014]**

10 —gripping device 15 —magnetic dipole rod 20 —bolt housing 21 —channel 22 —open end 23 —receiving section 24 —stripping edge 25 —bolt guide section 26 —retraction section 27 —stop edge 30 —metal bolt 31 —adhesion region 32 —connection 35 —magnetic sensor 40 —motor housing 41 —connecting plate 42 —motor 43 —motor shaft 46 —end piece 45 —microswitch 44 —actuating lever 46 —contact 47 —adjusting screw 50 —magazine 51 —top side 52 —bottom side 53 —well 55 —target vessel 60 —control system 61 —control logic 62 —position controller 64 —digital input electronics 65 —motor control electronics 66 —digital input electronics 67 —end position sensor 422 —linear motor 355 —reed sensor 70 —robot arm FIG. 1 shows the gripping device 10 according to the invention. It comprises a bolt housing 20 , a connecting plate 41 , to which the bolt housing 20 is attached, and a motor housing 40 , which is attached to the opposite side of the connecting plate 41 from the bolt housing 20 . The bolt housing 20 has a channel 21 which is subdivided into three sections: receiving section 23 , bolt guide section 25 and retraction section 26 . The channel has an open end 22 on one side, and its side opposite the open end 22 ends at the connecting plate 41 . The dimensions of the receiving section are such that it can accommodate a magnetic dipole rod 15 with sufficient clearance. Sufficient clearance means that the diameter of the receiving section is dimensioned in such a way that it corresponds to the maximum diameter of a dipole rod 15 , taking into account the statistical scatter of the underlying prod

**[p0014]**

uction process of the dipole rods 15 used and any adhering impurities, plus an air gap of at least 0.2 mm.

**[p0015]**

Since the diameter of the receiving section 23 is greater than the diameter of the bolt guide section 25 , there is a stripping edge 24 between the receiving section 23 and the bolt guide section 25 . The stripping edge 24 prevents the magnetic dipole rod 15 from being introduced into the bolt guide section 25 . In the embodiment shown here, the diameter of the retraction section 26 is greater than the diameter of the bolt guide section 25 , and therefore a stop edge 27 is formed between the retraction section 26 and the bolt guide section 25 . There is a magnetic sensor 35 on the outside of the bolt housing 20 in the region of the receiving section. A metal bolt 30 is movably mounted in the channel 21 . The front end of the metal bolt 30 , which points to the open end of the channel 22 , is referred to below as the adhesion region 31 . Since the metal bolt 30 consists of a ferromagnetic material, a magnetic dipole rod 15 can adhere to the adhesion region 31 . The opposite end of the metal bolt 30 from the adhesion region 31 forms the connection 32 to the motor shaft 43 . In the embodiment shown, the metal bolt 30 has an enlarged diameter (widening) in the region of the connection 32 to the motor shaft 43 . This is matched to the inside diameter of the retraction section 26 and allows a maximum movement of the metal bolt 30 in the direction of the open end of the channel 21 up to the position at which the connection 23 to the motor shaft 43 strikes against the stop edge 27 . In this position, the adhesion region 31 is in the region of the open end 22 of the channel 21 ( FIG

**[p0015]**

S. 5 a - c ).

**[p0016]**

The motor housing 40 is situated on the opposite side of the connecting plate 41 from the bolt housing 20 . The connecting plate 41 has an opening (not shown here), through which the motor shaft 43 projects into the retraction section 26 of the channel 21 . The motor housing 40 has a motor 42 with a motor shaft 43 as well as a microswitch 45 and some of the electronic components according to FIG. 2 (the latter are not shown). The microswitch has an actuating lever 44 , which can be connected to a contact 46 when pressure is applied to the actuating lever. The microswitch 45 is arranged in the region of the end piece 46 of the motor shaft 43 in such a way that the end piece 46 of the motor shaft 43 actuates the microswitch 45 by pressure on the actuating lever 44 in a specific retracted position of the motor shaft 43 . This retracted position can be adjusted by means of the adjusting screw 47 . The distance between the motor 42 and the microswitch 45 can be adjusted with the adjusting screw 47 .

**[p0017]**

During a first adjustment travel of the motor 42 , the motor shaft 43 is brought into the retracted position, in which the microswitch 45 is actuated by pressure on the actuating lever 44 . As soon as the controller receives this signal, this position of the motor shaft 43 is stored as the zero position of the shaft. All the movement steps of the motor shaft 43 are calculated from this zero position. The motor 42 or the motor controller detects the current position of the motor on the basis of the incremental encoder/motor or the internal position controller (without sensor). FIG. 2 provides an overview of the control system 60 for the gripping device 10 according to the invention. It comprises a processor and a memory, which are not shown separately. The processor is suitable for executing a program code which controls the gripping device 10 in accordance with the sequence shown in FIGS. 5 a - h. Corresponding programming is familiar to a person skilled in the art.

**[p0018]**

The program code contains the control logic 61 . The latter coordinates the control commands to the robot arm 70 , to which the gripping device 10 is connected, and the position controller 62 for the motor 42 , which moves the metal bolt 30 . In the exemplary embodiment, the motor 42 is a linear motor 422 . The position controller receives signals from the end position sensor 67 via the digital input electronics 66 . The end position sensor 67 is nothing other than the functional description of the microswitch 45 . The position of the motor shaft 43 or of the end piece 46 of the motor shaft 43 in which the latter makes contact with the microswitch 45 is the initial position/end position for the movement of the motor 42 , 422 and thus of the metal bolt 30 into the various predetermined positions, such as the receiving position, the holding position and the delivery position. In the embodiment shown here, the end position corresponds to the delivery position of the metal bolt 30 . By means of the adjusting screw 47 , these different positions can be adjusted, i.e. pushed forward or backward. The position controller controls the linear motor 422 and thus the positioning of the metal bolt 30 via the motor control electronics 65 (encoder/incremental encoder).

**[p0019]**

The control logic 61 receives input signals from the reed sensor 355 present in the exemplary embodiment as to whether or not a magnetic dipole rod 15 is currently in the receiving section 23 of the channel 21 . If there is one or no magnetic dipole rod 15 in the receiving section at the wrong time, the control system 60 could respond accordingly. FIG. 3 and FIG. 4 show the magazine 50 for the magnetic dipole rods 15 from the side and from the top, respectively. The magazine 50 is a plate made of a non-magnetic material with a top side 51 and a bottom side 52 . The magazine 50 has wells 53 on its top side 51 . The wells 53 are arranged in regular rows 1 m and columns 1 n. The magnetic dipole rods 15 are more or less upright in the wells 53 since the diameter A of the wells is in a range of from 110% to 220% of the diameter of the magnetic dipole rods 15 . Or in other words, the diameter of the wells A is in a range of from 1 mm to 2.5 mm greater than the diameter of a magnetic dipole rod 15 .

**[p0020]**

The distance of the bottom 54 of the wells from the top side 51 of the magazine 50 (=depth C) is in a range of from 0.5 mm to 2.5 mm less than the length of a magnetic dipole rod. This leads to a corresponding projection B of dipole rods 15 beyond the top side 51 of the magazine 50 . FIGS. 5 a - 5 h show the sequence of the transfer of a magnetic dipole rod and delivery into a target container 55 . The magnetic dipole rod 15 is situated in the well 53 of a magazine 50 . The gripping device 10 is attached to a movable arm of a robot (not shown). The magazine 50 and the target container 55 are situated at predetermined positions in space. The metal bolt 30 is in the receiving position. The adhesion region 31 of the metal bolt 30 is situated in the region of the open end 22 of the channel 21 . The connection 32 to the motor shaft 43 is resting against the stop edge 27 . The arm of a robot is used to move the gripping device 10 with the open end 22 of the channel 21 over a well 53 of the magazine 50 in which there is a magnetic dipole rod 15 ( FIG. 5 a ).

**[p0021]**

In the next step, the gripping device 10 is lowered by the arm of a robot, with the result that the adhesion region 31 is situated directly above a magnetic dipole rod 15 . The magnetic dipole rod 15 is aligned vertically, following the magnetic force, while the adjacent magnetic dipole rod 15 is not affected ( FIG. 5 b ) because of the greater distance from the metal bolt 30 . If, after a further slight lowering of the gripping device 10 , the distance between the adhesion region 31 and the magnetic dipole rod 15 falls below a minimum, the magnetic dipole rod 15 adheres with its upper end to the adhesion region 31 ( FIG. 5 c ). Now the motor 42 is activated in order to retract the metal bolt 30 from the receiving position into the holding position with the aid of the motor shaft 43 and thus to bring the magnetic dipole rod 15 into the receiving section 23 of the channel 21 ( FIG. 5 d ). The magnetic sensor 35 which is present on the outside of the receiving section 23 detects the presence of the magnetic dipole rod 15 in the receiving section 23 of the channel 21 ( FIG. 5 e ).

**[p0022]**

The arm of a robot now moves the gripping device 10 over the target container 55 ( FIG. 5 f ). Now the motor 42 is activated in order to retract the metal bolt 30 from the holding position into the delivery position with the aid of the motor shaft 43 ( FIG. 5 g ). While the metal bolt 30 is being retracted into the delivery position, in which the adhesion region 31 is situated in the bolt guide section 25 , the magnetic dipole rod 15 strikes against the stripping edge 24 and is separated from the adhesion region 31 . Following the force of gravity, the magnetic dipole rod 15 falls vertically into the target container 55 . The magnetic sensor 35 detects that there is no longer a magnetic dipole rod 15 in the receiving section 23 . The receiving section 23 and the stripping edge 24 are shown on an enlarged scale in FIG. 5 i .

## Figure captions

- **Figure 1:** FIG. 1 shows a gripping device according to the invention;
- **Figure 2:** FIG. 2 shows a control system for the gripping device;
- **Figure 3:** FIG. 3 shows a side view of a magazine for magnetic dipole rods;
- **Figure 4:** FIG. 4 shows a plan view of a magazine for magnetic dipole rods;
- **Figure 5:** FIGS. 5 a - 5 i show the mode of operation of the gripping device
- **Figure 1:** FIG. 1 shows the gripping device 10 according to the invention. It comprises a bolt housing 20 , a connecting plate 41 , to which the bolt housing 20 is attached, and a motor housing 40 , which is attached to the opposite side of the connecting plate 41 from the bolt housing 20 .
- **Figure 2:** FIG. 2 provides an overview of the control system 60 for the gripping device 10 according to the invention. It comprises a processor and a memory, which are not shown separately. The processor is suitable for executing a program code which controls the gripping device 10 in accordance with the sequence shown in FIGS. 5 a - h. Corresponding programming is familiar to a person skilled in the art.
- **Figure 5:** In the next step, the gripping device 10 is lowered by the arm of a robot, with the result that the adhesion region 31 is situated directly above a magnetic dipole rod 15 . The magnetic dipole rod 15 is aligned vertically, following the magnetic force, while the adjacent magnetic dipole rod 15 is not affected ( FIG. 5 b ) because of the greater distance from the metal bolt 30 .
- **Figure 5:** If, after a further slight lowering of the gripping device 10 , the distance between the adhesion region 31 and the magnetic dipole rod 15 falls below a minimum, the magnetic dipole rod 15 adheres with its upper end to the adhesion region 31 ( FIG. 5 c ).
- **Figure 5:** Now the motor 42 is activated in order to retract the metal bolt 30 from the receiving position into the holding position with the aid of the motor shaft 43 and thus to bring the magnetic dipole rod 15 into the receiving section 23 of the channel 21 ( FIG. 5 d ).
- **Figure 5:** The magnetic sensor 35 which is present on the outside of the receiving section 23 detects the presence of the magnetic dipole rod 15 in the receiving section 23 of the channel 21 ( FIG. 5 e ).
- **Figure 5:** The arm of a robot now moves the gripping device 10 over the target container 55 ( FIG. 5 f ).
- **Figure 5:** Now the motor 42 is activated in order to retract the metal bolt 30 from the holding position into the delivery position with the aid of the motor shaft 43 ( FIG. 5 g ).
- **Figure 5:** The receiving section 23 and the stripping edge 24 are shown on an enlarged scale in FIG. 5 i .

## Classifications

- B25J15/0608
- B25J15/0608
- B25J15/0608
- B01F33/452
- B01F33/452
- B25J11/00
- B25J15/0071
- B25J15/0095
- B25J15/02
- B25J15/0491
- B25J15/06
- B25J9/16
- B25J9/1664
- B25J9/1664

## Cited patent documents

- [US-2006119119-A1](https://patents.google.com/patent/US20060119119A1/en) — SEA
- [US-2008315055-A1](https://patents.google.com/patent/US20080315055A1/en) — SEA
- [US-2009144968-A1](https://patents.google.com/patent/US20090144968A1/en) — SEA
- [US-2015273468-A1](https://patents.google.com/patent/US20150273468A1/en) — SEA
- [US-2017222506-A1](https://patents.google.com/patent/US20170222506A1/en) — SEA
- [US-6079091-A](https://patents.google.com/patent/US6079091A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
