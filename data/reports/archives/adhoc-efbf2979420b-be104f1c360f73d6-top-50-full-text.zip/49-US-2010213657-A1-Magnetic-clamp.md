# 49. Magnetic clamp

- **Archive rank:** 49 of 50
- **Publication:** [US-2010213657-A1](https://patents.google.com/patent/US20100213657A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/039200069/publication/US20100213657A1?q=pn%3DUS20100213657A1)
- **Publication date:** 2010-08-26
- **Filing date:** 2007-09-04
- **Earliest priority:** 2006-09-18
- **Family:** 39200069
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery

## Parties

- **Applicant / assignee:** SRB CONSTRUCTION TECHNOLOGIES
- **Inventors:** SLADOJEVIC ROBERT

## Abstract

A magnetic clamp has a housing, the housing defining a base for resting on a work surface. An adjustable friction reducing arrangement is associated with the base of the housing. The friction reducing arrangement is movable relative to the base between a first position in which the friction reducing arrangement reduces an area of contact between the base of the housing and the work surface and a second position in which the area of contact between the base of the housing and the work surface is increased.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/a2/73/d7/5b21a3d270a78d/US20100213657A1-20100826-D00000.png)

![Sketch 1 for US-2010213657-A1](https://patentimages.storage.googleapis.com/a2/73/d7/5b21a3d270a78d/US20100213657A1-20100826-D00000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/12/e5/df/f5413494c97665/US20100213657A1-20100826-D00001.png)

![Sketch 2 for US-2010213657-A1](https://patentimages.storage.googleapis.com/12/e5/df/f5413494c97665/US20100213657A1-20100826-D00001.png)

[Sketch 3](https://patentimages.storage.googleapis.com/69/0e/f7/05247c8a41264a/US20100213657A1-20100826-D00002.png)

![Sketch 3 for US-2010213657-A1](https://patentimages.storage.googleapis.com/69/0e/f7/05247c8a41264a/US20100213657A1-20100826-D00002.png)

[Sketch 4](https://patentimages.storage.googleapis.com/e0/27/df/ac1c27b7d77293/US20100213657A1-20100826-D00003.png)

![Sketch 4 for US-2010213657-A1](https://patentimages.storage.googleapis.com/e0/27/df/ac1c27b7d77293/US20100213657A1-20100826-D00003.png)

[Sketch 5](https://patentimages.storage.googleapis.com/8e/64/ae/7ea8fa9de91c80/US20100213657A1-20100826-D00004.png)

![Sketch 5 for US-2010213657-A1](https://patentimages.storage.googleapis.com/8e/64/ae/7ea8fa9de91c80/US20100213657A1-20100826-D00004.png)

## Claims

### Claim 1 (independent)

A clamp, which comprising: a housing, the housing defining a base for resting on a work surface; and an adjustable friction reducing arrangement associated with the base of the housing, the friction reducing arrangement being movable relative to the base between a first position and a second position such that when the housing is on the work surface and the friction reducing arrangement is in the first position an area of contact between the base of the housing and the work surface is reduced relative to when the friction reducing arrangement is in the second position.

### Claim 2

The clamp of claim 1 further comprising: a magnet housed in the housing.

### Claim 3

The clamp of claim 2 wherein the magnet is displaceably arranged within the housing.

### Claim 4

The clamp of claim 3 further comprising: an operating member arranged on the housing for displacing the magnet relative to the housing between an active state in which the magnet exerts a clamping force for clamping the housing to the work surface and an inactive state in which the magnet exerts a residual force smaller than the clamping force.

### Claim 5

The clamp of claim 1 wherein the friction reducing arrangement comprises a plurality of friction reducing elements.

### Claim 6

The clamp of claim 5 wherein each friction reducing element is a retractable element.

### Claim 7

The clamp of claim 6 wherein each friction reducing element is a retractable pin carried by the base, the pin being movable relative to the base between a normally extended position and a retracted position.

### Claim 8

The clamp of claim 7 wherein each friction reducing element defines a foot, and wherein when each foot rests on the work surface and each friction reducing element is in an extended position so that at least a part of the base of the housing is elevated above the work surface.

### Claim 9

The clamp of claim 5 wherein each friction reducing element is displaceably received in a receiving formation defined in the base of the housing.

### Claim 10

The clamp of claim 5 wherein an urging means is associated with each friction reducing element to urge the friction reducing element to an extended position.

### Claim 11

The clamp of claim 10 wherein each urging means is in the form of a spring aligned with an associated friction reducing element.

## Full description

### Background

**[p0001]**

1. Technical Field This disclosure relates, generally, to the clamping of elements during the fabrication of concrete slabs. More particularly, the disclosure relates to a magnetic clamp. 2. Description of the Related Art Manufacture of concrete slabs and structures is now commonly effected by pre-casting techniques. Pre-cast manufacture of concrete panels and structures is becoming the preferred method for many construction applications including industrial, commercial and retail applications. Typically, pre-casting of a concrete panel or other concrete member is performed on a steel bed. Edge or perimeter molds are used to produce concrete slabs and structures of a certain shape. These molds are commonly referred to as sideforms. Magnetic clamps, to which the sideforms are attached, are used to secure the sideforms in position on a steel bed. The magnetic clamp exerts an extremely large clamping force to secure the magnetic clamp in position on the steel bed and to inhibit movement of the sideform relative to the steel bed. Due to the magnitude of the clamping force, the magnetic clamp usually has a means for controlling the magnetic attraction between the magnetic clamp and the steel bed. Once the clamping force exceeds a predetermined magnitude, it becomes difficult to adjust the position of the magnetic clamp relative to the steel bed.

**[p0002]**

Furthermore, a magnetic clamp is quite heavy which also increases the difficulty of adjusting the position of the magnetic clamp relative to the steel bed.

### Brief Summary

**[p0003]**

According to one embodiment of the invention, there is provided a magnetic clamp which comprises: a housing, the housing defining a base for resting on a work surface; and an adjustable friction reducing arrangement associated with the base of the housing, the friction reducing arrangement being movable relative to the base between a first position in which the friction reducing arrangement reduces an area of contact between the base of the housing and the work surface and a second position in which the area of contact between the base of the housing and the work surface is increased. A magnet may be housed in the housing. The magnet may be displaceably arranged within the housing. The clamp may include an operating member arranged on the housing for displacing the magnet relative to the housing between an active state in which the magnet exerts a clamping force for clamping the housing to the work surface and an inactive state in which the magnet exerts a residual force smaller than the clamping force.

**[p0004]**

The friction reducing arrangement may comprise a plurality of friction reducing elements. Each friction reducing element may be a retractable element. In one preferred embodiment, each friction reducing element is a retractable pin carried by the base, the pin being movable relative to the base between a normally extended position and a retracted position. The area of contact between the housing and the work surface may be reduced when each friction reducing element is in its extended position and, conversely, the area of contact between the housing and the work surface may be maximized when each friction reducing element is in its retracted position. Each friction reducing element may define a foot which rests on the work surface when the friction reducing element is in its extended position so that at least a part of the base of the housing is elevated above the work surface. Further, each friction reducing element may be displaceably received in a receiving formation defined in the base of the housing. Each receiving formation may be arranged adjacent to a periphery of the base.

**[p0005]**

When each friction reducing element is in its retracted position, the foot of the friction reducing element may be received in its associated receiving formation to be substantially flush with a surface of the base. An urging means may be associated with each friction reducing element to urge the friction reducing element to its extended position. Each urging means may be in the form of a spring, and more particularly, a coil spring co-axially aligned with its associated friction reducing element.

### Brief Description Of The Several Views Of The Drawings

**[p0006]**

An embodiment of the invention is now described with reference to the accompanying drawings, in which: FIG. 1 shows, in partial cross-section, a side view of a magnetic clamp in accordance with an embodiment of the invention; FIG. 2 shows an enlarged, cross-sectional view of detail I-I of FIG. 1 ; FIG. 3 shows a side view of the magnetic clamp on a work surface with a friction reducing arrangement in an extended position; FIG. 4 shows a side view of the magnetic clamp on the work surface with the friction reducing arrangement in a retracted position; FIG. 5 shows a perspective view, from below, of the magnetic clamp; and FIG. 6 shows a bottom view of the magnetic clamp.

### Detailed Description

**[p0007]**

Throughout this specification the word “comprise”, or variations such as “comprises” or “comprising”, will be understood to imply the inclusion of a stated element, integer or step, or group of elements, integers or steps, but not the exclusion of any other element, integer or step, or group of elements, integers or steps. In the drawings, reference numeral 10 generally designates a magnetic clamp, in accordance with an embodiment of the invention, for clamping elements such as sideforms (not shown) to a work surface in the form of a steel bed 11 ( FIGS. 3 and 4 ). The magnetic clamp 10 includes a housing 12 which defines a base 14 . The magnetic clamp 10 also includes an adjustable friction reducing arrangement 15 carried on the base 14 of the housing 12 . The friction reducing arrangement 15 comprises a plurality of friction reducing elements, each in the form of a pin 16 , arranged in the base 14 . In the illustrated embodiment, the friction reducing arrangement 15 includes four pins 16 . However, it will be appreciated that any number of pins 16 may be employed. Each pin 16 is movable relative to the base 14 between a first, extended position ( FIGS. 1 , 2 , 3 and 5 ) in which the pins 16 reduce an area of contact between the housing 12 and the steel bed 11 and a second, retracted position ( FIG. 4 ) in which the area of contact between the housing 12 and the steel bed 11 is maximized.

**[p0008]**

The housing 12 houses a magnet 18 ( FIGS. 5 and 6 ) for magnetically clamping the housing 12 to the steel bed 11 . The housing 12 carries an operating handle 20 which acts on the magnet 18 such that movement of the handle 20 causes a corresponding movement of the magnet 18 inside the housing 12 . Movement of the handle 20 to a first orientation (as shown in FIGS. 1 , 3 and 5 ) causes retraction of the magnet 18 relative to the housing 12 so that the magnet 18 is in an inactive state. In its inactive state, the magnet 18 exerts a reduced, residual magnetic force on the steel bed 11 so that the assembly 10 can be positioned in a desired position on the steel bed 11 . The magnitude of the residual magnetic force is such that, once the magnet 18 has been positioned on the steel bed 11 , the magnetic force is sufficiently strong to maintain the housing 12 in the desired position on the steel bed 11 . When the handle 20 is moved to a second orientation (as shown in FIG. 4 ) the magnet 18 is moved to its operative, clamping position in which an operatively lower surface of the magnet 18 lies substantially flush with the base 14 .

**[p0009]**

In this clamping position, the magnet 18 is able to exert a clamping force to clamp the housing 12 to the steel bed 11 securely. The housing 12 defines an operatively lower surface 22 having a plurality of receiving formations, each of which is in the form of a bore 24 ( FIG. 2 ). Each bore 24 slidably receives one of the pins 16 of the friction reducing arrangement 15 . Each bore 24 is arranged adjacent a periphery 26 ( FIGS. 5 and 6 ) of the lower surface 22 of the housing 12 and extends substantially perpendicularly to the lower surface 22 of the housing 12 into a wall of the housing 12 . Each pin 16 is a one-piece unit formed of a rigid material, such as a metal, and comprises a foot 28 , a boss 30 and a spigot 32 ( FIG. 2 ). Each pin 16 is slidably received in its associated bore 24 such that it can slide between its extended and retracted positions. Each boss 30 is sized to provide a snug sliding fit for the pin 16 in its associated bore 24 . When the pin 16 is in its extended position, its associated foot 28 is proud of the lower surface 22 of the base 14 . Conversely, when the pin 16 is in its retracted position, its associated foot 28 is substantially flush with the lower surface 22 of the housing 12 .

**[p0010]**

An urging means in the form of a spring 34 is arranged in each bore 24 . Each spring 34 has a first end 36 which abuts an end wall 38 of its associated bore 24 and a second end 40 which is mounted on the spigot 32 of its associated pin 16 . Each spring 34 is arranged so that it is biased to urge its associated pin 16 to its extended position. In use, the magnetic clamp 10 is used to clamp sideforms (not shown) to the steel bed 11 , the sideforms being used to form a mold for casting a concrete panel. It will be appreciated by those skilled in the art that, in order to enhance the support for the sideforms which the magnetic clamp 10 provides, the magnetic clamp 10 is formed of materials which give rise to the clamp 10 having a substantial weight. Due to the action of the springs 34 acting on the pins 16 to urge each pin 16 to its associated extended position in which the foot 28 of each pin 16 is proud of the lower surface 22 of the base 14 , the housing 12 is supported on the pins 16 when the magnetic clamp 10 is initially placed on the work surface 11 . Thus, the springs 34 have a sufficient spring force to overcome the weight of the clamp 10 at least when the magnet 18 is in its inactive state. The base 14 of the housing 12 is elevated above the steel bed 11 . In addition, the combined spring force of the springs 34 is also sufficient to support the housing 12 against the action of the residual magnetic force exerted by the magnet 18 when the magnet 18 is in its inactive state.

**[p0011]**

Accordingly, with the pins 16 in their extended position, the area of contact with the steel bed 11 is determined by a surface area of the foot 28 of each of the pins 16 . The combined surface area of the feet 28 is small relative to the surface area of the base 14 of the housing 12 and, as a consequence, reduces a resistance to maneuvering the housing 12 relative to the steel bed 11 to enable a user to position the clamp 10 , carrying its associated sideform, in the desired position on the steel bed 11 . In particular, minor adjustments to the position of the sideform relative to the steel bed 11 can be easily made when the pins 16 are in their extended position. Once the sideform has been positioned, the user exerts a downward force on the housing 12 against the action of the springs 34 to urge the housing 12 towards the steel bed 11 until each pin 16 is received in its associated bore 24 and the base 14 of the housing 12 comes into contact with the steel bed 11 . When this occurs, the residual magnetic force of the magnet 18 is sufficiently increased to hold the clamp 10 in position against the action of the springs 34 .

**[p0012]**

The base 14 of the housing 12 , together with the surface area of the foot 28 of each pin 16 , forms an increased area of contact between the housing 12 and the steel bed 11 . This increased area of contact results in a higher resistance to movement being generated between the housing 12 and the steel bed 11 . Additional minor adjustments to the positioning of the sideform can now be made by tapping the housing 12 . Once the sideform is in its final desired position, the operating handle 20 is moved to its second orientation to displace the magnet 18 and bring it into its active state. In its active state, the magnet 18 exerts its clamping force which securely clamps the housing 12 and the sideform to the steel bed 11 . It is accordingly an advantage of a preferred embodiment of the invention to provide a magnetic clamp 10 which facilitates positioning of the clamp 10 on a work surface and allows minor positioning of the magnetic clamp 10 to be more easily effected such that more accurate manufacturing tolerances of the panels can be achieved.

**[p0013]**

It will be appreciated by persons skilled in the art that numerous variations and/or modifications may be made to the invention as shown in the specific embodiments without departing from the spirit or scope of the invention as broadly described. The present embodiments are, therefore, to be considered in all respects as illustrative and not restrictive. These and other changes can be made to the embodiments in light of the above-detailed description. In general, in the following claims, the terms used should not be construed to limit the claims to the specific embodiments disclosed in the specification and the claims, but should be construed to include all possible embodiments along with the full scope of equivalents to which such claims are entitled. Accordingly, the claims are not limited by the disclosure.

## Figure captions

- **Figure 1:** FIG. 1 shows, in partial cross-section, a side view of a magnetic clamp in accordance with an embodiment of the invention;
- **Figure 2:** FIG. 2 shows an enlarged, cross-sectional view of detail I-I of FIG. 1 ;
- **Figure 3:** FIG. 3 shows a side view of the magnetic clamp on a work surface with a friction reducing arrangement in an extended position;
- **Figure 4:** FIG. 4 shows a side view of the magnetic clamp on the work surface with the friction reducing arrangement in a retracted position;
- **Figure 5:** FIG. 5 shows a perspective view, from below, of the magnetic clamp; and
- **Figure 6:** FIG. 6 shows a bottom view of the magnetic clamp.
- **Figure 4:** When the handle 20 is moved to a second orientation (as shown in FIG. 4 ) the magnet 18 is moved to its operative, clamping position in which an operatively lower surface of the magnet 18 lies substantially flush with the base 14 .

## Classifications

- B25B11/002
- B25B11/002
- B25B11/00
- B28B7/0017
- B28B7/0017
- B28B7/002
- B28B7/002

## Cited patent documents

- [JP-H04313593-A](https://patents.google.com/patent/JPH04313593A/en) — PRS
- [US-2005116131-A1](https://patents.google.com/patent/US20050116131A1/en) — PRS
- [US-2005258319-A1](https://patents.google.com/patent/US20050258319A1/en) — PRS
- [US-2007131829-A1](https://patents.google.com/patent/US20070131829A1/en) — PRS
- [US-2502672-A](https://patents.google.com/patent/US2502672A/en) — PRS
- [US-2709292-A](https://patents.google.com/patent/US2709292A/en) — PRS
- [US-2946360-A](https://patents.google.com/patent/US2946360A/en) — PRS
- [US-2954257-A](https://patents.google.com/patent/US2954257A/en) — PRS
- [US-3014751-A](https://patents.google.com/patent/US3014751A/en) — PRS
- [US-3319989-A](https://patents.google.com/patent/US3319989A/en) — PRS
- [US-3507473-A](https://patents.google.com/patent/US3507473A/en) — PRS
- [US-3648961-A](https://patents.google.com/patent/US3648961A/en) — PRS
- [US-3917216-A](https://patents.google.com/patent/US3917216A/en) — PRS
- [US-3926404-A](https://patents.google.com/patent/US3926404A/en) — PRS
- [US-4159097-A](https://patents.google.com/patent/US4159097A/en) — PRS
- [US-4634359-A](https://patents.google.com/patent/US4634359A/en) — PRS
- [US-4726560-A](https://patents.google.com/patent/US4726560A/en) — PRS
- [US-5066936-A](https://patents.google.com/patent/US5066936A/en) — PRS
- [US-5146816-A](https://patents.google.com/patent/US5146816A/en) — PRS
- [US-5282603-A](https://patents.google.com/patent/US5282603A/en) — PRS
- [US-5993365-A](https://patents.google.com/patent/US5993365A/en) — PRS
- [US-6202978-B1](https://patents.google.com/patent/US6202978B1/en) — PRS
- [US-6276657-B1](https://patents.google.com/patent/US6276657B1/en) — PRS
- [US-6434894-B2](https://patents.google.com/patent/US6434894B2/en) — PRS
- [US-6471273-B1](https://patents.google.com/patent/US6471273B1/en) — PRS
- [US-6477816-B1](https://patents.google.com/patent/US6477816B1/en) — PRS
- [US-6547209-B1](https://patents.google.com/patent/US6547209B1/en) — PRS
- [US-6733059-B2](https://patents.google.com/patent/US6733059B2/en) — PRS
- [US-6742759-B2](https://patents.google.com/patent/US6742759B2/en) — PRS
- [US-6837473-B2](https://patents.google.com/patent/US6837473B2/en) — PRS
- [US-6854777-B2](https://patents.google.com/patent/US6854777B2/en) — PRS
- [US-6969056-B2](https://patents.google.com/patent/US6969056B2/en) — PRS
- [US-7419131-B2](https://patents.google.com/patent/US7419131B2/en) — PRS
- [US-7548147-B2](https://patents.google.com/patent/US7548147B2/en) — PRS
- [US-7850142-B2](https://patents.google.com/patent/US7850142B2/en) — PRS
- [US-7887022-B2](https://patents.google.com/patent/US7887022B2/en) — PRS
- [US-8002234-B2](https://patents.google.com/patent/US8002234B2/en) — PRS
- [US-8292242-B2](https://patents.google.com/patent/US8292242B2/en) — PRS
- [US-8322699-B2](https://patents.google.com/patent/US8322699B2/en) — PRS
- [US-RE26710-E](https://patents.google.com/patent/USRE26710E/en) — PRS

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
