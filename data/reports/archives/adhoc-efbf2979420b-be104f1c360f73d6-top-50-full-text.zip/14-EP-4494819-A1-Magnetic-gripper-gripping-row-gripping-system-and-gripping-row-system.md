# 14. Magnetic gripper, gripping row, gripping system and gripping row system

- **Archive rank:** 14 of 50
- **Publication:** [EP-4494819-A1](https://patents.google.com/patent/EP4494819A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/091829974/publication/EP4494819A1?q=pn%3DEP4494819A1)
- **Publication date:** 2025-01-22
- **Filing date:** 2024-07-04
- **Earliest priority:** 2023-07-20
- **Family:** 91829974
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** SCHMALZ J GMBH
- **Inventors:** CLAUSS JOHANNES; MÖGINGER HELMUT; WENNAGEL DANIEL

## Abstract

Die Erfindung betrifft einen Magnetgreifer (10) zum Greifen einer Batteriezelle, aufweisend eine Anlagefläche (12) zum Kontaktieren der zu greifenden Batteriezelle, einen Magnet zur Bereitstellung einer Magnetwirkung an der Anlagefläche zum Zweck des Greifens der Batteriezelle, und eine Mehrzahl von Zentrierelementen (22) zum Führen der Batteriezelle zur Anlagefläche, wobei die Mehrzahl von Zentrierelementen als Auskragungen ausgebildet ist, die kronenartig um die Anlagefläche angeordnet sind und sich jeweils zumindest abschnittsweise in eine von der Anlagefläche wegführende Richtung erstrecken. Die Erfindung betrifft auch eine Greifreihe, ein Greifsystem sowie ein Greifreihensystem.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/EP-4494819-A1/000.png)

![Sketch 1 for EP-4494819-A1](https://nimo.iptorch.com/refdrawing/EP-4494819-A1/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/EP-4494819-A1/001.png)

![Sketch 2 for EP-4494819-A1](https://nimo.iptorch.com/refdrawing/EP-4494819-A1/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/EP-4494819-A1/002.png)

![Sketch 3 for EP-4494819-A1](https://nimo.iptorch.com/refdrawing/EP-4494819-A1/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/EP-4494819-A1/003.png)

![Sketch 4 for EP-4494819-A1](https://nimo.iptorch.com/refdrawing/EP-4494819-A1/003.png)

## Claims

### Claim 1 (independent)

Magnetgreifer (10) zum Greifen einer Batteriezelle (50), insbesondere einer Batterierundzelle, aufweisend: - eine Anlagefläche (12) zum Kontaktieren der zu greifenden Batteriezelle (50), und - einen Magnet (20) zur Bereitstellung einer Magnetwirkung an der Anlagefläche (12) zum Zweck des Greifens der Batteriezelle (50),gekennzeichnet durch eine Mehrzahl von Zentrierelementen (22) zum Führen der Batteriezelle (50) zur Anlagefläche (12), wobei die Mehrzahl von Zentrierelementen (22) als Auskragungen ausgebildet ist, die kronenartig um die Anlagefläche (12) angeordnet sind und sich jeweils zumindest abschnittsweise in eine von der Anlagefläche (12) wegführende Richtung (24) erstrecken.

### Claim 2

Magnetgreifer (10) nach Anspruch 1, wobei die Mehrzahl von Zentrierelementen (22) von der Anlagefläche (12) beabstandet ist.

### Claim 3

Magnetgreifer (10) nach einem der Ansprüche 1 oder 2, wobei die Mehrzahl von Zentrierelementen (22) durch einen Aufsatz (37) bereitgestellt ist, welcher auf ein Gehäuse (39) des Magnetgreifers (10) aufsetzbar ist.

### Claim 4 (independent)

Magnetgreifer (10) nach einem der vorherigen Ansprüche, wobei die Mehrzahl von Zentrierelementen (22) aus einem nicht magnetisierbaren Material gebildet ist.

### Claim 5 (independent)

Magnetgreifer (10) nach einem der vorherigen Ansprüche, wobei die Mehrzahl von Zentrierelementen (22) einen Aufnahmeraum (32) für die zu greifende Batteriezelle (50) definieren.

### Claim 6 (independent)

Magnetgreifer (10) nach einem der vorherigen Ansprüche, wobei jedes Zentrierelement (22) eine Einführungsschräge (36) zum Führen der Batteriezelle (50) zur Anlagefläche (12) aufweist.

### Claim 7 (independent)

Magnetgreifer (10) nach einem der vorherigen Ansprüche, wobei der Magnetgreifer (10) eine Manipulator-Schnittstelle (40) zum Befestigen des Magnetgreifers (10) an einem Manipulator aufweist, wobei die Manipulator-Schnittstelle (40) und die Anlagefläche (12) voneinander elektrisch isoliert sind.

### Claim 8

Magnetgreifer (10) nach Anspruch 7, wobei der Magnetgreifer (10) eine Adapterplatte (38) mit der Manipulator-Schnittstelle (40) aufweist, wobei die Adapterplatte (38) aus einem elektrisch isolierenden Material gebildet ist.

### Claim 9

Magnetgreifer (10) nach Anspruch 8, wobei die Adapterplatte (38) zumindest einen Anschluss zum Anschließen einer Versorgungsleitung an der Adapterplatte (38) für das Betreiben des Magnetgreifers (10) und/oder zumindest eine Öffnung zum Durchführen einer Versorgungsleitung durch die Adapterplatte (38) hindurch für das Betreiben des Magnetgreifers (10) und/oder eine Aussparung (48) zum Vorbeiführen einer Versorgungsleitung an der Adapterplatte (38) vorbei für das Betreiben des Magnetgreifers (10) aufweist.

### Claim 10 (independent)

Magnetgreifer (10) nach einem der vorherigen Ansprüche, wobei der Magnetgreifer (10) eine Nut (46) zum Aufnehmen eines Sensors und/oder einer Versorgungsleitung aufweist.

### Claim 11

Greifreihe (150), aufweisend eine Mehrzahl von Magnetgreifern (10), die jeweils nach einem der voranstehenden Ansprüche ausgebildet sind, wobei die Mehrzahl von Magnetgreifern (10) nebeneinander angeordnet sind.

### Claim 12

Greifsystem (100), aufweisend einen Magnetgreifer (10) nach einem der Ansprüche 1 bis 10 und die Batteriezelle (50), wobei in einer Greifkonfiguration die Batteriezelle (50) mittels des Magnetgreifers (10) gegriffen ist, wobei in der Greifkonfiguration die Batteriezelle (50) von der Mehrzahl der Zentrierelementen (22) umgeben ist.

### Claim 13

Greifsystem (100) nach Anspruch 12, wobei in der Greifkonfiguration die Mehrzahl von Zentrierelementen (22) und die Batteriezelle (50) in radialer Richtung eine formschlüssige Verbindung bilden.

### Claim 14

Greifreihensystem (200), aufweisend eine Mehrzahl von Greifsystemen (100), die jeweils nach Anspruch 12 oder 13 ausgebildet sind, wobei die Mehrzahl von Greifsystemen (100) nebeneinander angeordnet sind.

## Full description

**[p0001]**

Die Erfindung betrifft einen Magnetgreifer zum Greifen einer Batteriezelle, eine Greifreihe, ein Greifsystem und ein Greifreihensystem. Magnetgreifer zum Greifen von Batteriezellen sind aus dem Stand der Technik grundsätzlich bekannt. Solche Magnetgreifer weisen üblicherweise eine Anlagefläche zum Kontaktieren der zu greifenden Batteriezelle und einen Magnet zur Bereitstellung einer Magnetwirkung an der Anlagefläche zum Zweck des Greifens der Batteriezelle auf. CN 210392833 U zeigt einen Magnetgreifer zum Greifen eines Batteriekerns. Der Magnetgreifer hat eine magnetische Backe mit einer Greifrille, die dazu verwendet wird, um den Batteriekern anzuziehen. In einem gegriffenen Zustand liegt der Batteriekern mit einem Abschnitt der Mantelfläche an der Backe an. Eine Anlagefläche ist dabei an eine Außenkontur der Mantelfläche des Batteriekerns angepasst. Die bekannten Lösungen sind jedoch vergleichsweise massiv aufgebaut und erfordern es üblicherweise, die Batterie in einer bestimmten Richtung an die Anlagefläche heranzuführen, was einen Greifvorgang kompliziert. Zudem besteht Verbesserungsbedarf hinsichtlich einer sicheren Handhabung der Batterie im gegriffenen Zustand.

**[p0002]**

Es ist Aufgabe der vorliegenden Erfindung, einen Magnetgreifer zum Greifen einer Batteriezelle bereitzustellen, der konstruktiv einfach aufgebaut ist und ein sicheres und zuverlässiges Greifen der Batteriezelle ermöglicht. Weiter ist es Aufgabe der vorliegenden Erfindung, eine Greifreihe, ein Greifsystem und ein Greifreihensystem bereitzustellen, die jeweils einen derartigen Magnetgreifer aufweisen. Diese Aufgabe wird erfindungsgemäß durch einen Magnetgreifer mit den Merkmalen des Anspruchs 1 gelöst. Vorteilhafte Ausgestaltungen und Weiterbildungen der Erfindung ergeben sich aus den abhängigen Ansprüchen. Ein erfindungsgemäßer Magnetgreifer ist zum Greifen einer Batteriezelle, insbesondere einer Batterierundzelle, ausgebildet. Der Magnetgreifer weist eine Anlagefläche, einen Magnet und eine Mehrzahl von Zentrierelementen auf. Die Anlagefläche ist zum Kontaktieren der zu greifenden Batteriezelle ausgebildet. Der Magnet ist zur Bereitstellung einer Magnetwirkung an der Anlagefläche zum Zweck des Greifens der Batteriezelle ausgebildet. Die Mehrzahl, insbesondere 3, 4 oder 6, von Zentrierelementen ist zum Führen der Batteriezelle zur Anlagefläche und insbesondere zum Zentrieren der Batteriezelle an der Anlagefläche ausgebildet. Die Zentrierelemente sind als Auskragungen ausgebildet. Die Zentrierelemente sind kronenartig um die Anlagefläche angeordnet. Die Zentrierelemente erstrecken sich jeweils zumindest abschnittsweise in eine von der Anlagefläche wegführende, insbesondere wegzeigende, Richtung erstrecken.

**[p0003]**

Die vorgeschlagene Ausgestaltung ermöglicht es, mit vergleichsweise geringem konstruktiven Aufwand, eine Batteriezelle auf einfache Weise sicher und zuverlässig zu greifen. Vorteilhafterweise kann die Batteriezelle beim Überführen in einen gegriffenen Zustand an mindestens einem Zentrierelement entlanggleiten und wird dabei von dem Zentrierelement relativ zu der Anlagefläche positioniert. Dadurch, dass die Zentrierelemente kronenartig um die Anlagefläche angeordnet sind, wird die Batteriezelle beim Führen zu der Anlagefläche insbesondere automatisch zentriert. Die Batteriezelle muss insofern nicht exakt relativ zu der Anlagefläche positioniert werden, was einen Greifprozess erleichtert. In einem gegriffenen Zustand ist die Batteriezelle dann von der Mehrzahl von Zentrierelementen in einer radialen Richtung umgeben, so dass bei einer Bewegung des Magnetgreifers, beispielsweise mittels eines Manipulators, ein ungewolltes Verlagern der gegriffenen Batteriezelle verhindert wird. Vorzugsweise wird die Batteriezelle derart positioniert, dass eine Stirnseite der Batteriezelle der Anlagefläche gegenüberliegend angeordnet ist. Wenn die Stirnseite der Batteriezelle der Anlagefläche gegenüberliegend angeordnet ist, kann die Batteriezelle optimal von dem Magnetgreifer gegriffen werden. Die vorgeschlagene Ausgestaltung der Zentrierelemente als Auskragungen ist auf konstruktiv einfache und kostengünstige Weise realisierbar. Zudem nimmt der vorgeschlagene Magnetgreifer nur einen vergleichsweise geringen Bauraum ein.

**[p0004]**

Die Batteriezelle kann als Akkumulator bezeichnet werden. Die Batteriezelle kann ein Akkumulator sein. Die Batteriezelle kann ferromagnetisch ausgebildet sein. Die Batterierundzelle kann eine zylinderförmige Form aufweisen. Der Magnet kann ein Elektromagnet oder ein Permanentmagnet sein. Der Magnet kann aus mehreren Teilen zusammengesetzt sein. Der Magnet kann derart angeordnet sein, dass eine Magnetisierungsrichtung des Magneten orthogonal zu einer Längsrichtung des Magnetgreifers verläuft. Unter Magnetwirkung kann verstanden werden, dass der Magnet ein Magnetfeld erzeugt, das dazu ausgebildet ist, die Batteriezelle mit einer Magnetkraft zum Zweck des Greifens der Batteriezelle zu beaufschlagen, insbesondere wenn die Batteriezelle die Anlagefläche kontaktiert. Der Magnetgreifer kann einen Aktivzustand und einen Passivzustand aufweisen. In dem Aktivzustand kann der Magnet ein die Anlagefläche durchdringendes Magnetfeld erzeugen, das dazu ausgebildet ist, die zu greifende Batteriezelle mit einer auf die Anlagefläche gerichteten Magnetkraft zu beaufschlagen, die vorzugsweise größer als eine Gewichtskraft der Batteriezelle ist. In dem Passivzustand kann der Magnet kein Magnetfeld erzeugen oder zumindest kein Magnetfeld erzeugen, das dazu ausgebildet ist, die zu greifende Batteriezelle mit einer auf die Anlagefläche gerichteten Magnetkraft zu beaufschlagen, die größer als eine Gewichtskraft der Batteriezelle ist.

**[p0005]**

Unter der Anlagefläche wird insbesondere eine Fläche des Magnetgreifers verstanden, an welcher die gegriffene Batteriezelle anliegt. Die Anlagefläche kann als Kontaktfläche bezeichnet werden. Die Anlagefläche kann eben ausgebildet sein. Die Anlagefläche kann eine Stirnfläche des Magnetgreifers zumindest abschnittsweise bilden. Die Anlagefläche kann an einem Ende des Magnetgreifers angeordnet sein. Die Mehrzahl von Zentrierelementen und die Anlagefläche können an einer Stirnseite des Magnetgreifers angeordnet sein. Die Mehrzahl von Zentrierelementen und die Anlagefläche sind vorzugsweise getrennt voneinander ausgebildet. Keines der Zentrierelemente kann die Anlagefläche aufweisen. Unter Auskragung kann ein Zapfen, eine Zinne, ein Vorsprung oder ein Dom verstanden werden. Kronenartig kann bedeuten, dass die Mehrzahl von Zentrierelementen um die Anlagefläche, insbesondere gleichmäßig, verteilt angeordnet sind. Mit anderen Worten, die Anlagefläche kann von der Mehrzahl von Zentrierelementen in einer radialen Richtung umgeben sein. Alternativ oder zusätzlich kann die Mehrzahl von Zentrierelementen umfangmäßig, insbesondere und gleichmäßig, verteilt um eine Längsachse des Magnetgreifers angeordnet sein.

**[p0006]**

Die Richtung kann einen geraden, insbesondere zur Anlagefläche senkrechten, Verlauf aufweisen. Die Richtung kann parallel zu der Längsachse des Magnetgreifers sein. Die Richtung kann von dem Magnet wegführen, insbesondere wegzeigen. Der Magnetgreifer kann einen oder mehrere Anwesenheitssensoren aufweisen, die dazu ausgebildet sind, zu erfassen, ob sich die Batteriezelle an der Anlagefläche befindet und/oder an der Anlagefläche anliegt. Der Anwesenheitssensor kann als optischer Sensor oder als induktiver Sensor, insbesondere als Magnetfeldsensor, vorzugsweise Hall-Sensor, ausgebildet sein. In einer vorteilhaften Weiterbildung des Magnetgreifers kann die Mehrzahl von Zentrierelementen von der Anlagefläche beabstandet sein. Ein Abstand zwischen der Anlagefläche und jedem Zentrierelement kann gleich oder größer sein als 1%, insbesondere 2% oder 3%, eines Umkreisradius eines Querschnitts des Magnetgreifers. In einer vorteilhaften Weiterbildung des Magnetgreifers kann die Mehrzahl von Zentrierelementen durch einen Aufsatz bereitgestellt sein, welcher auf ein Gehäuse des Magnetgreifers aufsetzbar, insbesondere aufsteckbar oder aufschraubbar, ist. Eine solche Ausgestaltung ermöglicht es, die Zentrierelemente auf einfache Weise, bspw. bei Verschleiß, auszutauschen. Der Aufsatz kann beispielsweise durch ein Kunststoff-Spritzgussteil bereitgestellt sein. Die Anlagefläche kann durch den Aufsatz bereitgestellt sein. Die Anlagefläche kann auch von dem Aufsatz separat bereitgestellt sein.

**[p0007]**

In einer vorteilhaften Weiterbildung des Magnetgreifers kann die Mehrzahl von Zentrierelementen aus einem nicht magnetisierbaren Material gebildet sein. Vorteilhafterweise wird durch das nicht magnetisierbare Material ein Entstehen einer Magnetkraft in Richtung der Zentrierelemente verhindert, so dass beim Überführen in den gegriffenen Zustand die Batteriezelle mit einer Magnetkraft in Richtung der Anlagefläche beaufschlagt ist. Das nicht magnetisierbare Material kann ein Kunststoff, beispielsweise ein Polyamid, sein. In einer Weiterbildung des Magnetgreifers können die Mehrzahl von Zentrierelementen und ein die Anlagefläche bereitstellender Anlageabschnitt des Magnetgreifers aus unterschiedlichen Materialien gebildet sein. Der Anlageabschnitt kann aus einem magnetisierbaren Material gebildet sein. Der Anlageabschnitt kann Eisen aufweisen. In einer Weiterbildung des Magnetgreifers können die Mehrzahl von Zentrierelementen einen Aufnahmeraum für die zu greifende Batteriezelle definieren. Der Aufnahmeraum kann zylinderförmig ausgebildet sein. Die Mehrzahl von Zentrierelementen kann eine Öffnung definieren, durch die hindurch die Batteriezelle in den Aufnahmeraum einsetzbar ist. Die Öffnung kann kreisförmig ausgebildet sein.

**[p0008]**

In einer Weiterbildung des Magnetgreifers kann jedes Zentrierelement eine Einführungsschräge zum Führen der Batteriezelle zur Anlagefläche aufweisen. Die Einführungsschräge kann dazu ausgebildet sein, dass die Batteriezelle beim Überführen in den gegriffenen Zustand die Einführungsschräge entlang gleitet und durch das Entlanggleiten der Einführungsschräge zu der Anlagefläche geführt wird. Vorzugsweise wird die Batteriezelle derart zur Anlagefläche geführt, dass eine Stirnseite der Batteriezelle der Anlagefläche gegenüberliegend angeordnet ist. Die Einführungsschräge und die Richtung können zwischen sich einen Winkel von 5° bis 30°, insbesondere 10° bis 20°, aufweisen. In einer Weiterbildung des Magnetgreifers kann die Anlagefläche kreisringförmig ausgebildet sein. Eine derartige Ausbildung der Anlagefläche kann besonders vorteilhaft für das Greifen der Batteriezelle sein. In einer Weiterbildung des Magnetgreifers kann eine Oberfläche der Mehrzahl von Zentrierelementen zumindest teilweise oder abschnittsweise eine Mantelfläche des Magnetgreifers bilden. Die Mehrzahl von Zentrierelementen können an einem äußersten Randbereich eines Querschnitts des Magnetgreifers angeordnet sein.

**[p0009]**

In einer Weiterbildung des Magnetgreifers kann der Magnetgreifer eine Manipulator-Schnittstelle zum Befestigen des Magnetgreifers an einem Manipulator, bspw. Roboter, aufweisen. Die Manipulator-Schnittstelle und die Anlagefläche sind vorzugsweise voneinander elektrisch isoliert. Die Manipulator-Schnittstelle kann vorteilhafterweise ein besonders einfaches und schnelles Anschließen des Magnetgreifers an einen Manipulator ermöglichen. Durch die elektrische Isolierung der Manipulator-Schnittstelle und der Anlagefläche voneinander kann verhindert werden, dass eine gegriffene Batteriezelle sich über den Magnetgreifer entlädt. Die Manipulator-Schnittstelle kann als Schnellkupplung, bspw. in Form eines Bajonettverschlusses, ausgebildet sein. Die Manipulator-Schnittstelle kann zum werkzeuglosen Befestigen des Magnetgreifers an dem Manipulator und/oder zum werkzeuglosen Lösen des Magnetgreifers von dem Manipulator ausgebildet sein. Der Manipulator kann ein Roboterarm sein. In einer Weiterbildung des Magnetgreifers kann der Magnetgreifer eine Adapterplatte mit der Manipulator-Schnittstelle aufweisen. Die Adapterplatte ist vorzugsweise aus einem elektrisch isolierenden Material, insbesondere zum elektrischen Isolieren der Manipulator-Schnittstelle von der Anlagefläche, gebildet. Das Material der Adapterplatte und das Material der Mehrzahl von Zentrierelementen kann das gleiche sein. Das Material der Adapterplatte kann ein Kunststoff, insbesondere ein Polyamid, sein. Die Adapterplatte und die Anlagefläche können an entgegengesetzten Enden des Magnetgreifers angeordnet sein. Die Adapter

**[p0009]**

platte kann zumindest teilweise eine Stirnseite des Magnetgreifers bilden.

**[p0010]**

In einer Weiterbildung des Magnetgreifers kann die Adapterplatte zumindest einen Anschluss zum Anschließen einer Versorgungsleitung an der Adapterplatte für das Betreiben des Magnetgreifers und/oder zumindest eine Öffnung zum Durchführen einer Versorgungsleitung durch die Adapterplatte hindurch für das Betreiben des Magnetgreifers und/oder eine Aussparung zum Vorbeiführen einer Versorgungsleitung an der Adapterplatte vorbei für das Betreiben des Magnetgreifers auf. Durch eine Anordnung des Anschlusses, der Öffnung und/oder der Aussparung an der Adapterplatte kann vorteilhafterweise eine besonders kompakte Bauweise des Magnetgreifers erreicht werden. Die Versorgungsleitung kann eine Druckluftleitung zum Versorgen des Magnetgreifers mit Druckluft, eine Stromleitung zum Versorgen des Magnetgreifers mit Strom oder eine Sensorleitung zum Anschließen eines Sensors des Magnetgreifers an eine Auswerteeinheit zum Auswerten des angeschlossenen Sensors sein. Der Anschluss kann zum Anschließen einer Mehrzahl von Versorgungsleitungen an der Adapterplatte für das Betreiben des Magnetgreifers ausgebildet sein. Die Öffnung kann zum Durchführen einer Mehrzahl von Versorgungsleitungen durch die Adapterplatte hindurch für das Betreiben des Magnetgreifers ausgebildet sein. Die Aussparung kann zum Vorbeiführen einer Mehrzahl von Versorgungsleitungen an der Adapterplatte vorbei für das Betreiben des Magnetgreifers ausgebildet sein.

**[p0011]**

In einer Weiterbildung des Magnetgreifers kann der Magnetgreifer eine Nut zum Aufnehmen eines Sensors und/oder einer Versorgungsleitung aufweisen. Die Nut kann als Kabelkanal wirken oder bezeichnet werden. Die Nut kann sich parallel zu der Längsachse des Magnetgreifers erstrecken. Die Nut kann sich von der Anlagefläche bis zu der Adapterplatte erstrecken. Die eingangs genannte Aufgabe wird auch durch eine Greifreihe umfassend eine Mehrzahl von zuvor beschriebenen Magnetgreifern gelöst. Die Mehrzahl von Magnetgreifern sind, insbesondere linear, nebeneinander angeordnet. Die Mehrzahl von Magnetgreifern kann derart nebeneinander angeordnet sein, dass alle Anlageflächen der Mehrzahl von Magnetgreifer in einer einzigen Ebene liegen. Der Magnetgreifer kann keine Störkontur aufweisen, wodurch vorteilhafterweise eine besonders kompakte Greifreihe gebildet werden kann. Zwei benachbarte Batteriezellen können somit mit einem geringen Abstand von beispielsweise lediglich 1,6 Millimeter zueinander gegriffen werden.

**[p0012]**

Die eingangs genannte Aufgabe wird auch durch ein Greifsystem umfassend einen zuvor beschriebenen Magnetgreifer und eine Batteriezelle gelöst. In einer Greifkonfiguration ist die Batteriezelle mittels des Magnetgreifers gegriffen. In der Greifkonfiguration ist die Batteriezelle, insbesondere in einer radialen Richtung der Batteriezelle, von der Mehrzahl der Zentrierelementen umgeben. Durch das Umgeben der Batteriezelle von der Mehrzahl der Zentrierelementen können vorteilhafterweise erhöhte Querkräfte auf die Batteriezelle wirken, ohne dass diese infolge eines Auftretens der Querkräfte die Greifkonfiguration ungewollt verlässt. In der Greifkonfiguration kann eine Längsachse der Batteriezelle gleich einer Längsachse des Magnetgreifers sein. In der Greifkonfiguration kann die Batteriezelle durch die Magnetwirkung mit einer Magnetkraft gegen die Anlagefläche beaufschlagt sein. In der Greifkonfiguration kann die Batteriezelle nicht durch die Magnetwirkung gegen die Mehrzahl von Zentrierelementen mit einer Kraft beaufschlagt sein.

**[p0013]**

Eine Kontur der Anlagefläche kann zumindest teilweise einer Kontur der Batteriezelle folgen. Die Kontur der Anlagefläche kann als Negativkontur der Batteriezelle bezeichnet werden. In einer Weiterbildung des Greifsystems können in der Greifkonfiguration die Mehrzahl von Zentrierelementen und die Batteriezelle in radialer Richtung eine formschlüssige Verbindung bilden. Dadurch wird vorteilhafterweise ein besonders sicheres und zuverlässiges Greifen der Batteriezelle erreicht. Die eingangs genannte Aufgabe wird auch durch ein Greifreihensystem umfassend eine Mehrzahl von zuvor beschriebenen Greifsystemen auf. Die Mehrzahl von Greifsystemen sind, insbesondere linear, nebeneinander angeordnet. Die Mehrzahl von Magnetgreifern kann derart nebeneinander angeordnet sein, dass alle Anlageflächen der Mehrzahl von Magnetgreifer in einer einzigen Ebene liegen. Die Erfindung wird im Folgenden anhand der Figuren näher erläutert. Es zeigen: Fig. 1 eine schematische Seitenansicht eines Magnetgreifers zum Greifen einer Batteriezelle,

**[p0014]**

Fig. 2 eine weitere schematische Seitenansicht des Magnetgreifers von Fig. 1 , Fig. 3 eine schematische Schnittansicht des Magnetgreifers entlang einer Schnittlinie III-III gemäß Fig. 2 , Fig. 4 Fig. 5 Fig. 6 eine schematische Seitenansicht eines Greifsystems mit dem Magnetgreifer von Fig. 1 bis 5 , Fig. 7 eine schematische Draufsicht auf eine Greifreihe mit einer Mehrzahl von in Fig. 1 bis 5 gezeigten Magnetgreifern, Fig. 8 eine schematische Seitenansicht eines Greifreihensystems mit einer Mehrzahl von in Fig. 6 gezeigten Greifsystemen, und Fig. 9 eine schematische Schrägansicht des Greifreihensystems von Fig. 8 . Fig. 1 bis 5 zeigen einen Magnetgreifer 10 zum Greifen einer Batteriezelle (in den Figuren 1 bis 5 nicht dargestellt). Der Magnetgreifer 10 hat eine Anlagefläche 12. Die Anlagefläche 12 ist zum Kontaktieren der zu greifenden Batteriezelle ausgebildet. Eine mit dem Magnetgreifer 10 gegriffene Batteriezelle liegt insbesondere gegen die Anlagefläche 12 an. Die Anlagefläche 12 ist im Beispiel kreisringförmig ausgebildet, siehe Fig. 5 . Eine Aussparung 13 der Anlagefläche 12 kann dazu ausgebildet sein, einen Pluspol der Batteriezelle abschnittsweise aufzunehmen. Die Anlagefläche 12 ist eben ausgebildet. Die Anlagefläche 12 verläuft senkrecht zu einer Längsachse 14 des Magnetgreifers 10.

**[p0015]**

Die Anlagefläche 12 wird von einem Anlageabschnitt 16 des Magnetgreifers 10 bereitgestellt. Der Anlageabschnitt 16 ist vorzugsweise aus einem magnetisierbaren Material gebildet. Die Anlagefläche 12 bildet zumindest abschnittsweise eine Stirnfläche des Magnetgreifers 10. Die Anlagefläche 12 ist an einem Ende 18 des Magnetgreifers 10 angeordnet. Der Magnetgreifer 10 hat einen Magnet 20. Der Magnet 20 ist zur Bereitstellung einer Magnetwirkung an der Anlagefläche 12 zum Zweck des Greifens der Batteriezelle ausgebildet. Im Beispiel ist der Magnet 20 als Permanentmagnet ausgebildet. Der Magnet 20 ist derart innerhalb des Magnetgreifers 10 angeordnet, dass eine Magnetisierungsrichtung des Magneten 20 orthogonal zu der Längsachse 14 des Magnetgreifers 10 verläuft. Der Magnet 20 ist innerhalb des Magnetgreifers 10 in Richtung der Längsachse 14 verschiebbar angeordnet. Der Magnet 20 kann zwischen einem Aktivzustand und einem Passivzustand, insbesondere durch Verschieben des Magneten entlang der Längsachse 14, überführt werden. In Fig. 3 ist der Passivzustand dargestellt.

**[p0016]**

In dem Aktivzustand liegt der Magnet 20 vorzugsweise gegen eine Wandung des Magnetgreifers 10 an, welche den Anlageabschnitt 16 bildet. In dem Aktivzustand des Magnetgreifers 10 durchdringt ein nicht dargestelltes Magnetfeld des Magneten 20 die Anlagefläche 12 derart, dass die zu greifende Batteriezelle mit einer auf die Anlagefläche 12 gerichtete Magnetkraft beaufschlagt ist, die größer als eine Gewichtskraft der Batteriezelle ist. In dem Passivzustand ist der Magnet 20 von der Wandung derart beabstandet, dass das Magnetfeld die zu greifende Batteriezelle nicht mit einer auf die Anlagefläche 12 gerichtete Magnetkraft beaufschlägt, die größer als die Gewichtskraft der Batteriezelle ist. Der Magnetgreifer 10 hat eine Mehrzahl von Zentrierelementen 22. In dem dargestellten Beispiel der Fig. 1 bis 5 hat der Magnetgreifer 10 insgesamt vier Zentrierelemente 22. Die Zentrierelemente 22 sind als Auskragungen ausgebildet. Vorzugsweise sind die Zentrierelemente 22 aus einem nicht magnetisierbaren Material gebildet, bspw. Polyamid.

**[p0017]**

Die Zentrierelemente 22 und die Anlagefläche 12 sind an dem Ende 18 des Magnetgreifers 10 angeordnet. Die Zentrierelemente 22 sind von der Anlagefläche 12 mit einem Abstand 26 beabstandet, siehe Fig. 5 . Die Zentrierelemente 22 sind kronenartig um die Anlagefläche 12 angeordnet. Die Anlagefläche 12 ist von den Zentrierelementen 22 in radialer Richtung umgeben. Die Zentrierelemente 22 sind beispielhaft umfangmäßig und gleichmäßig verteilt um die Längsachse 14 des Magnetgreifers 10 angeordnet. Die Zentrierelemente 22 erstecken sich jeweils zumindest abschnittsweise in eine von der Anlagefläche 12 wegführende Richtung 24. Die Richtung 24 ist parallel zu der Längsachse 14. Die Richtung 24 führt von dem Magnet 20 weg. Die Zentrierelemente 22 sind an einem äußersten Randbereich eines Querschnitts des Magnetgreifers 10 angeordnet. Eine Oberfläche 28 der Zentrierelementen 22 bildet abschnittsweise eine Mantelfläche 30 des Magnetgreifers 10, siehe Fig. 5 . Die Zentrierelemente 22 definieren einen Aufnahmeraum 32 für die zu greifende Batteriezelle, siehe Fig. 2 . Die Zentrierelemente 22 definieren eine Öffnung 34, durch die hindurch die Batteriezelle in den Aufnahmeraum 32 einsetzbar ist.

**[p0018]**

Die Zentrierelemente 22 sind zum Führen der Batteriezelle zur Anlagefläche 12 und zum Zentrieren der Batteriezelle an der Anlagefläche 12 ausgebildet. Jedes Zentrierelement 22 hat eine Einführungsschräge 36 zum Führen der Batteriezelle zu der Anlagefläche 12. Jede Einführungsschräge 36 ist dazu ausgebildet, dass die Batteriezelle beim Überführen in den gegriffenen Zustand die Einführungsschräge 36 entlanggleiten kann, bis eine Längsachse der Batteriezelle und die Längsachse 14 deckungsgleich angeordnet sind. Jede Einführungsschräge 36 erstreckt sich von einem Ende des Zentrierelements 22 bis zu einer halben Länge des Zentrierelements 22. Die Einführungsschräge 36 und die Richtung 24 bilden zwischen sich einen Winkel von beispielhaft 15°. In dem dargestellten Beispiel sind die Zentrierelemente 22 beispielhaft durch einen Aufsatz 37 bereitgestellt, welcher auf ein Gehäuse 39 des Magnetgreifers 10 aufsetzbar, insbesondere aufsteckbar, ist. Der Aufsatz 37 kann beispielsweise als Kunststoff-Spritzgussteil ausgebildet sein.

**[p0019]**

Der Magnetgreifer 10 hat eine Adapterplatte 38 mit einer Manipulator-Schnittstelle 40. Die Adapterplatte 38 ist aus einem elektrisch isolierenden Material zum elektrischen Isolieren der Manipulator-Schnittstelle 40 von der Anlagefläche 12 gebildet. Das Material der Adapterplatte 38 kann beispielsweise ein Polyamid sein. Die Adapterplatte 38 und die Anlagefläche 12 sind an entgegengesetzten Enden des Magnetgreifers 10 angeordnet. Die Adapterplatte 38 bildet zumindest teilweise eine Stirnseite 42 des Magnetgreifers 10. Im Beispiel ermöglicht die Manipulator-Schnittstelle 40 das Herstellen einer Schraubverbindung zwischen dem Magnetgreifer 10 und einem nicht gezeigten Manipulator. Die Manipulator-Schnittstelle 40 hat vier Durchgangslöcher zum Befestigen des Magnetgreifers 10 an den Manipulator mittels Schrauben, siehe Fig. 4 . Bei nicht dargestellten Ausgestaltungen sind auch andere Verbindungsmechanismen denkbar, bspw. eine BajonettVerbindung oder eine Steckverbindung. Die Adapterplatte 38 hat zwei Anschlüsse 44 zum Anschließen von Druckluftleitungen für das Betreiben des Magnetgreifers 10. Jeder der beiden Anschlüsse 44 hat eine Längsachse, die parallel zu der Längsachse 14 des Magnetgreifers 10 angeordnet ist. Über die beiden Anschlüsse 44 kann der Magnetgreifer 10 mit Druckluft versorgt werden. Wird der eine Anschluss 44 mit Druckluft beaufschlagt, wird der Magnetgreifer 10 in den Aktivzustand überführt. Wird der andere Anschluss 44 mit Druckluft beaufschlagt, wird der Magnetgreifer 10 in den Passivzustand überführt.

**[p0020]**

Der Magnetgreifer 10 hat zwei Nuten 46, die jeweils zum Aufnehmen eines Sensors und/oder einer Versorgungsleitung ausgebildet sind, siehe Fig. 4 . Die beiden Nuten 46 sind an gegenüberliegenden Seiten des Magnetgreifers 10 angeordnet. Die beiden Nuten 46 erstrecken sich parallel zu der Längsachse 14 des Magnetgreifers 10. Die Adapterplatte 38 hat zwei Aussparungen 48, wobei jede Aussparung 48 mit einer der beiden Nuten 46 fluchtet. Aufgrund den beiden Aussparungen 48 ragt die Adapterplatte 38 nicht in einen lichten Querschnitt der Nuten 46. Dadurch kann beispielsweise ein nicht dargestelltes Kabel von einer der beiden Nuten 46 geführt und an der Adapterplatte 38 ungehindert vorbeigeführt sein. Fig. 6 zeigt ein Greifsystem 100. Das Greifsystem 100 weist den zuvor beschriebenen Magnetgreifer 10 und die Batteriezelle 50 auf. Die Batteriezelle 50 ist als Batterierundzelle ausgebildet. Die Batteriezelle 50 hat eine zylinderförmige Form. Die Batteriezelle 50 ist zumindest abschnittsweise ferromagnetisch ausgebildet.

**[p0021]**

Im dargestellten Beispiel der Fig. 6 ist der Magnetgreifer 10 in dem Aktivzustand. Die Batteriezelle 50 ist innerhalb des Aufnahmeraums 32 angeordnet. Die Batteriezelle 50 liegt an der Anlagefläche 12 an. Das Magnetfeld des Magneten 20 durchdringt die Anlagefläche 12 und beaufschlagt die Batteriezelle 50 mit einer auf die Anlagefläche 12 gerichtete Magnetkraft, die größer als eine Gewichtskraft der Batteriezelle 50 ist. Mit anderen Worten, die Batteriezelle 50 ist von dem Magnetgreifer 10 in einer Greifkonfiguration gegriffen. In der Greifkonfiguration ist eine Längsachse 52 der Batteriezelle 50 gleich der Längsachse 14 des Magnetgreifers 10. In der Greifkonfiguration ist die Batteriezelle 10 in radialer Richtung von den Zentrierelementen 22 unter Bildung einer formschlüssigen Verbindung umgeben. Fig. 7 zeigt eine Greifreihe 150 zum gleichzeitigen Greifen miteinander verblockter Batteriezellen. Die Greifreihe 150 ist aus einer Mehrzahl von zuvor beschriebenen Magnetgreifern 10 gebildet. In dem dargestellten Beispiel besteht die Greifreihe 150 aus sechs Magnetgreifer 10. In einem alternativen Ausführungsbeispiel kann die Greifreihe mehr oder weniger Magnetgreifern aufweisen.

**[p0022]**

Alle Magnetgreifer 10 der Greifreihe 150 sind vorzugsweise zueinander baugleich. Die Magnetgreifer 10 sind linear nebeneinander angeordnet. Die Magnetgreifer 10 sind derart nebeneinander angeordnet, dass die Anlageflächen 12 aller Magnetgreifer 10 in einer einzigen Ebene liegen. Die Nuten 46 von zwei benachbarten Magnetgreifern 10 sind einander gegenüberliegend angeordnet. Zwischen zwei benachbarten Magnetgreifern 10 besteht vorzugsweise kein berührender Kontakt. Fig. 8 und 9 zeigen ein Greifreihensystem 200. Das Greifreihensystem 200 hat eine Mehrzahl von zuvor beschriebenen Greifsystemen 100. In dem dargestellten Beispiel besteht das Greifreihensystem 200 aus sechs Greifsystemen 100. In einem alternativen Ausführungsbeispiel kann das Greifreihensystem mehr oder weniger Greifsysteme aufweisen. Alle Greifsysteme 100 des Greifreihensystems 200 sind im Beispiel zueinander baugleich. Die Magnetgreifer 10 sind linear nebeneinander angeordnet. Die Magnetgreifer 10 sind derart nebeneinander angeordnet, dass die Anlageflächen 12 aller Magnetgreifer 10 in einer einzigen Ebene liegen. Die Nuten 46 von zwei benachbarten Magnetgreifern 10 sind einander gegenüberliegend angeordnet. Zwischen zwei benachbarten Magnetgreifern 10 besteht insbesondere kein berührender Kontakt.

## Classifications

- B25J15/0608
- B25J15/0608
- B25J15/00
- B25J15/00
- B25J15/0061
- B25J15/0061
- B25J15/009
- B25J15/009
- B25J15/04
- B25J15/04
- B25J15/04
- B25J15/04
- B25J15/06
- B25J15/06
- B25J19/00
- B25J19/00
- B25J19/0033
- B25J19/0033
- B65G47/92
- B65G47/92
- B65G47/92
- B65G47/92

## Cited patent documents

- [CN-112388661-A](https://patents.google.com/patent/CN112388661A/en) — SEA
- [CN-210392833-U](https://patents.google.com/patent/CN210392833U/en) — APP
- [DE-102019003454-A1](https://patents.google.com/patent/DE102019003454A1/en) — SEA
- [EP-0154227-A1](https://patents.google.com/patent/EP0154227A1/en) — SEA
- [EP-3532855-B1](https://patents.google.com/patent/EP3532855B1/en) — SEA
- [JP-H05177574-A](https://patents.google.com/patent/JPH05177574A/en) — SEA
- [US-2012133371-A1](https://patents.google.com/patent/US20120133371A1/en) — SEA
- [US-2021031317-A1](https://patents.google.com/patent/US20210031317A1/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
