# 29. Magnetic substance holding device

- **Archive rank:** 29 of 50
- **Publication:** [US-9969061-B2](https://patents.google.com/patent/US9969061B2/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/056407125/publication/US9969061B2?q=pn%3DUS9969061B2)
- **Publication date:** 2018-05-15
- **Filing date:** 2015-03-05
- **Earliest priority:** 2015-01-21
- **Family:** 56407125
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus

## Parties

- **Applicant / assignee:** CHOI TAE KWANG
- **Inventors:** CHOI TAE KWANG

## Abstract

A magnetic substance holding device includes: a first pole piece assembly comprising at least one first pole piece, at least two second pole pieces, and at least two first permanent magnets; a second pole piece assembly comprising at least one third pole piece, at least two fourth pole pieces, and at least two second permanent magnets; a coil; and a control device. The first pole piece assembly and/or the second pole piece assembly is configured to be movable such that they are switched between a first arrangement in which the second faces of the first pole piece assembly are spaced apart from the first faces of the second pole piece assembly, and a second arrangement in which the second faces of the first pole piece assembly come in contact with the first faces of the second pole piece assembly. The control device controls holding and detaching of a workpiece on and from the first faces of the first pole piece assembly or the second faces of the second pole piece assembly, by way of controlling electric current applied to the coil to switch between the first arrangement and the second arrangement.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-9969061-B2/000.png)

![Sketch 1 for US-9969061-B2](https://nimo.iptorch.com/refdrawing/US-9969061-B2/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/US-9969061-B2/001.png)

![Sketch 2 for US-9969061-B2](https://nimo.iptorch.com/refdrawing/US-9969061-B2/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/US-9969061-B2/002.png)

![Sketch 3 for US-9969061-B2](https://nimo.iptorch.com/refdrawing/US-9969061-B2/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/US-9969061-B2/003.png)

![Sketch 4 for US-9969061-B2](https://nimo.iptorch.com/refdrawing/US-9969061-B2/003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/US-9969061-B2/004.png)

![Sketch 5 for US-9969061-B2](https://nimo.iptorch.com/refdrawing/US-9969061-B2/004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/US-9969061-B2/005.png)

![Sketch 6 for US-9969061-B2](https://nimo.iptorch.com/refdrawing/US-9969061-B2/005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/US-9969061-B2/006.png)

![Sketch 7 for US-9969061-B2](https://nimo.iptorch.com/refdrawing/US-9969061-B2/006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/US-9969061-B2/007.png)

![Sketch 8 for US-9969061-B2](https://nimo.iptorch.com/refdrawing/US-9969061-B2/007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/US-9969061-B2/008.png)

![Sketch 9 for US-9969061-B2](https://nimo.iptorch.com/refdrawing/US-9969061-B2/008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/US-9969061-B2/009.png)

![Sketch 10 for US-9969061-B2](https://nimo.iptorch.com/refdrawing/US-9969061-B2/009.png)

[Sketch 11](https://nimo.iptorch.com/refdrawing/US-9969061-B2/010.png)

![Sketch 11 for US-9969061-B2](https://nimo.iptorch.com/refdrawing/US-9969061-B2/010.png)

[Sketch 12](https://nimo.iptorch.com/refdrawing/US-9969061-B2/011.png)

![Sketch 12 for US-9969061-B2](https://nimo.iptorch.com/refdrawing/US-9969061-B2/011.png)

[Sketch 13](https://nimo.iptorch.com/refdrawing/US-9969061-B2/012.png)

![Sketch 13 for US-9969061-B2](https://nimo.iptorch.com/refdrawing/US-9969061-B2/012.png)

[Sketch 14](https://nimo.iptorch.com/refdrawing/US-9969061-B2/013.png)

![Sketch 14 for US-9969061-B2](https://nimo.iptorch.com/refdrawing/US-9969061-B2/013.png)

[Sketch 15](https://nimo.iptorch.com/refdrawing/US-9969061-B2/014.png)

![Sketch 15 for US-9969061-B2](https://nimo.iptorch.com/refdrawing/US-9969061-B2/014.png)

## Claims

### Claim 1 (independent)

A magnetic substance holding device for holding and detaching a workpiece that is a magnetic substance, the device comprising: a first pole piece assembly comprising at least one first pole piece having a first face and a second face, the first pole piece being a magnetic substance, at least two second pole pieces, each of the second pole pieces having a first face and a second face and being a magnetic substance, and at least two first permanent magnets, one of a N-pole and a S-pole of each of the first permanent magnets being in contact with the first pole piece while the other of the N-pole and the S-pole thereof being in contact with the second pole pieces, respectively; a second pole piece assembly comprising at least one third pole piece having a first face and a second face, the third pole piece being a magnetic substance, at least two fourth pole pieces, each of the fourth pole pieces having a first face and a second face and being a magnetic substance, and at least two second permanent magnets, each one pole of opposite polarity to that of the poles of the first permanent magnets in contact with the first pole piece is in contact with the third pole piece while the pole of same polarity as that of the poles of the first permanent magnets in contact with the first pole piece is in contact with the fourth pole pieces, respectively, wherein the first face of the third pole piece faces the second face of the first pole piece while the first face of each of the fourth pole pieces faces the second face of a respective one of the second pole pieces; at least one coil wound around at least one of the first pole piece or the third pole piece; and a control device controlling electric current applied to the coil, wherein at least one of the first pole piece assembly or the second pole piece assembly is configured to be movable such that the first pole piece assembly and the second pole piece assembly are switched between a first arrangement in which the second faces of the first pole piece assembly are spaced apart from the first faces of the second pole piece assembly, and a second arrangement in which the second faces of the first pole piece assembly come in contact with the first faces of the second pole piece assembly, and wherein the control device controls holding and detaching of a workpiece on and from the first faces of the first pole piece assembly or the second faces of the second pole piece assembly, by way of controlling electric current applied to the coil to switch between the first arrangement and the second arrangement.

### Claim 2

The magnetic substance holding device of claim 1 , further comprising: a base having a contact face and the base being a magnetic substance, the contact face facing the first faces of the first pole piece assembly, wherein the first faces of the first pole piece assembly come in contact with the contact face of the base when the first pole piece assembly and the second pole piece assembly are in the first arrangement, and the first faces of the first pole piece assembly are spaced apart from the contact face of the base when the first pole piece assembly and the second pole piece assembly are in the second arrangement.

### Claim 3

The magnetic substance holding device of claim 1 , further comprising: a base having a contact face and the base being a magnetic substance, wherein the base is disposed such that the contact face is in contact with the first faces of the first pole piece assembly.

### Claim 4 (independent)

A magnetic substance holding device for holding and detaching a workpiece that is a magnetic substance, the device comprising: a first pole piece assembly comprising at least one first pole piece having a first face and a second face, the first pole piece being a magnetic substance, at least two second pole pieces, each of the second pole pieces having a first face and a second face and being a magnetic substance, and at least two first permanent magnets, one of a N-pole and a S-pole of each of the first permanent magnets being in contact with the first pole piece while the other of the N-pole and the S-pole thereof being in contact with the second pole pieces, respectively; a second pole piece assembly comprising at least one third pole piece having a first face and a second face, the third pole piece being a magnetic substance, at least two fourth pole pieces, each of the fourth pole pieces having a first face and a second face and being a magnetic substance, and at least two second permanent magnets, each one pole of opposite polarity to that of the poles of the first permanent magnets in contact with the first pole piece is in contact with the third pole piece while the pole of same polarity as that of the poles of the first permanent magnets in contact with the first pole piece is in contact with the fourth pole pieces, respectively, wherein the first face of the third pole piece faces the second face of the first pole piece while the first face of each of the fourth pole pieces faces the second face of a respective one of the second pole pieces; a connection pole piece assembly comprising at least one first connection pole piece having a first face and a second face and being a magnetic substance, and at least two second connection pole pieces, each of the second connection pole pieces having a first face and a second face and being a magnetic substance, wherein the second face of the first connection pole piece faces the first face of the first pole pieces, and the second face of each of the second connection pole pieces faces the first face of the respective one of the second pole pieces; at least one coil wound around at least one of the first pole piece or the third pole piece; and a control device controlling electric current applied to the coil, wherein at least one of the first pole piece assembly, the second pole piece assembly or the connection pole piece assembly is configured to be movable such that the first pole piece assembly, the second pole piece assembly and the connection pole piece assembly are switched between a first arrangement in which the second faces of the first pole piece assembly are spaced apart from the first faces of the second pole piece assembly while the first faces of the first pole piece assembly come in contact with the second faces of the connection pole piece assembly, and a second arrangement in which the second faces of the first pole piece assembly come in contact with the first faces of the second pole piece assembly while the first faces of the first pole piece assembly are spaced apart from the second faces of the connection pole piece assembly, and wherein the control device controls holding and detaching of a workpiece on and from the first faces of the connection pole piece assembly or the second faces of the second pole piece assembly, by way of controlling electric current applied to the coil to switch between the first arrangement and the second arrangement.

### Claim 5

The magnetic substance holding device of claim 4 , wherein the first faces of the connection pole piece assembly and the second faces of the second pole piece assembly are configured to hold and detach a single workpiece.

### Claim 6

The magnetic substance holding device of claim 5 , wherein the first pole piece assembly is movable along a plane extended from the second faces of the second pole piece assembly and the first faces of the connection pole piece assembly.

### Claim 7

The magnetic substance holding device of claim 4 , wherein at least two first permanent magnets are disposed between the first pole piece and each of the second pole pieces, and at least two second permanent magnets are disposed between the third pole piece and each of the fourth pole pieces.

### Claim 8

The magnetic substance holding device of claim 7 , wherein the first permanent magnets are disposed in a line between the first pole piece and each of the second pole pieces, and the second permanent magnets are disposed in a line between the third pole piece and each of the fourth pole pieces.

### Claim 9

The magnetic substance holding device of claim 1 , wherein the first pole piece assembly comprises at least two first pole pieces, the second pole piece assembly comprises at least two third pole pieces, at least one first permanent magnet is disposed between each of the first pole piece and a respective one of the second pole pieces, and at least one second permanent magnet is disposed between each of the third pole piece and a respective one of the fourth pole pieces.

### Claim 10

The magnetic substance holding device of claim 1 , wherein an area of the first face of each of the fourth pole pieces is smaller than an area of the second face of a respective one of the second pole pieces, and an area of the second face of each of the fourth pole pieces is smaller than an area of the first face of a respective one of the fourth pole pieces.

### Claim 11

The magnetic substance holding device of claim 2 , further comprising: a rail bolt fixed to the first pole piece assembly and to the base while penetrating the second pole piece assembly so that the second pole piece assembly slides along the rail bolt.

### Claim 12

The magnetic substance holding device of claim 4 , further comprising: a rail bolt fixed to the first pole piece assembly and to the connection pole piece assembly while penetrating the second pole piece assembly so that the second pole piece assembly slides along the rail bolt.

### Claim 13

The magnetic substance holding device of claim 4 , wherein the first pole piece assembly comprises at least two first pole pieces, the second pole piece assembly comprises at least two third pole pieces, at least one first permanent magnet is disposed between each of the first pole piece and a respective one of the second pole pieces, and at least one second permanent magnet is disposed between each of the third pole piece and a respective one of the fourth pole pieces.

### Claim 14

The magnetic substance holding device of claim 4 , wherein an area of the first face of each of the fourth pole pieces is smaller than an area of the second face of a respective one of the second pole pieces, and an area of the second face of each of the fourth pole pieces is smaller than an area of the first face of a respective one of the fourth pole pieces.

## Full description

### Cross-Reference To Related Applications

**[p0001]**

This application claims the priority of Korean Patent Application No. 10-2015-0010094 filed on Jan. 21, 2015, in the Korean Intellectual Property Office, the disclosure of which is incorporated herein by reference.

### Background Of The Invention

**[p0002]**

Field of the Invention The present invention relates to a magnetic substance holding device, and more particularly to a magnetic substance holding device that controls magnetic fluxes from permanent magnets to thereby obtain strong holding force, to easily switch between holding and detaching, and to minimize residual magnetism. Description of the Related Art A magnetic substance holding device such as a permanent magnet workholding device is used to attach thereto a workpiece made of a magnetic material such as iron using magnetic force. Nowadays, such a magnetic substance holding device is widely used as an internal device attached to a mold clamping unit of an injection molding machine, a mold clamping unit of a press machine, a chuck of a machine tool, and so on. The basic principle of such a magnetic substance holding device is that it attaches a magnetic workpiece to a holding face using strong magnetic force from a permanent magnet, and detaches the magnetic workpiece from the holding face by controlling the magnetic flux from the permanent magnet so that no magnetic flux flows through the holding face.

**[p0003]**

The method for controlling the magnetic flux from the permanent magnet may include rotating another permanent magnet which is rotatably installed to control the magnetic flux, employing an additional electromagnet to control the magnet flux, or the like. The applicant of the present invention has already proposed a magnetic substance holding device employing an additional electromagnet (see Korean Patent No. 1319052, titled “MAGNETIC SUBSTANCE HOLDING DEVICE USING PERMANENT MAGNET ENERGY CONTROL,” published on Oct. 17, 2013). In addition, the applicant of the present invention has proposed an improved magnetic substance holding device (see Korean Patent Laid-open Publication No. 10-2014-0124739, titled “MAGNETIC SUBSTANCE HOLDING DEVICE,” published on Oct. 27, 2014). The magnetic substance holding device disclosed in the Korean Patent No. 1319052 to the applicant of the present invention includes coils around pole pieces instead of an additional electromagnet, and accordingly has advantages in that strong holding force can be obtained in a simple structure, magnetic force from a permanent magnet can be controlled with small electric current at the time of switching between holding and detaching, and strong holding force can be obtained in a smaller space.

**[p0004]**

However, there is still a challenge for such a magnet substance holding device to minimize residual magnetism that attracts a workpiece even after it is detached. In short, as more permanent magnets are used for increasing holding force, it becomes more difficult to control magnetic fluxes and residual magnetism becomes lager, thereby harming the usability.

### Summary Of The Invention

**[p0005]**

In view of the above, an object of the present invention is to provide a magnetic substance holding device that controls magnetic fluxes from permanent magnets to thereby obtain strong holding force, to easily switch between holding and detaching, and to minimize residual magnetism. It should be noted that objects of the present invention are not limited to the above-mentioned object; and other objects of the present invention will be apparent to those skilled in the art from the following descriptions. According to an aspect of the present invention, there is provided a magnetic substance holding device for holding and detaching a workpiece that is a magnetic substance, the device comprising: a first pole piece assembly comprising at least one first pole piece having a first face and a second face, the first pole piece being a magnetic substance, at least two second pole pieces, each of the second pole pieces having a first face and a second face and being a magnetic substance, and at least two first permanent magnets, one of an N-pole and an S-pole of each of the first permanent magnets being in contact with the first pole piece while the other of the N-pole and the S-pole thereof being in contact with the second pole pieces, respectively; a second pole piece assembly comprising at least one third pole piece having a first face and a second face, the third pole piece being a magnetic substance, at least two fourth pole pieces, each of the fourth pole pieces having a first face and a second face and being a magnetic substance, and at least two second permanent magnets, the

**[p0005]**

ir each pole of opposite polarity to that of the poles of the first permanent magnets in contact with the first pole piece is in contact with the third pole piece while the pole of same polarity to that of the poles of the first permanent magnets in contact with the first pole piece is in contact with the fourth pole pieces, respectively; wherein the first face of the third pole piece faces the second face of the first pole piece while the first face of each of the fourth pole pieces faces the second face of a respective one of the second pole pieces; at least one coil wound around the first pole piece and/or the third pole piece; and a control device controlling electric current applied to the coil, wherein the first pole piece assembly and/or the second pole piece assembly is configured to be movable such that they are switched between a first arrangement in which the second faces of the first pole piece assembly are spaced apart from the first faces of the second pole piece assembly, and a second arrangement in which the second faces of the first pole piece assembly come in contact with the first faces of the second pole piece assembly, and wherein the control device controls holding and detaching of a workpiece on and from the first faces of the first pole piece assembly or the second faces of the second pole piece assembly, by way of controlling electric current applied to the coil to switch between the first arrangement and the second arrangement.

**[p0006]**

The device may further comprise: a base having a contact face and being a magnetic substance, the contact face facing the first faces of the first pole piece assembly. The first faces of the first pole piece assembly come in contact with the contact face of the base when the first pole piece assembly and the second pole piece assembly are in the first arrangement, and the first faces of the first pole piece assembly are spaced apart from the contact face of the base when the first pole piece assembly and the second pole piece assembly are in the second arrangement. The device may further comprise: a base having a contact face and being a magnetic substance, wherein the base is disposed such that its contact face is in contact with the first faces of the first pole piece assembly. According to an aspect of the present invention, there is provided a magnetic substance holding device for holding and detaching a workpiece that is a magnetic substance, the device comprising: a first pole piece assembly comprising at least one first pole piece having a first face and a second face, the first pole piece being a magnetic substance, at least two second pole pieces, each of the second pole pieces having a first face and a second face and being a magnetic substance, and at least two first permanent magnets, one of an N-pole and an S-pole of each of the first permanent magnets being in contact with the first pole piece while the other of the N-pole and the S-pole thereof being in contact with the second pole pieces, respectively; a second pole piece assembly comprising at least one thi

**[p0006]**

rd pole piece having a first face and a second face, the third pole piece being a magnetic substance, at least two fourth pole pieces, each of the fourth pole pieces having a first face and a second face and being a magnetic substance, and at least two second permanent magnets, their each one pole of opposite polarity to that of the poles of the first permanent magnets in contact with the first pole piece is in contact with the third pole piece while the pole of same polarity to that of the poles of the first permanent magnets in contact with the first pole piece is in contact with a respective one of the fourth pole pieces; wherein the first face of the third pole piece faces the second face of the first pole piece while the first face of each of the fourth pole pieces faces the second face of a respective one of the second pole pieces; a connection pole piece assembly comprising at least one first connection pole piece having a first face and a second face and being a magnetic substance, and at least two second connection pole pieces, each of the second connection pole pieces having a first face and a second face and being a magnetic substance; wherein the second face of the first connection pole piece faces the first face of the first pole pieces, and the second face of each of the second connection pole pieces faces the first face of the respective one of the second pole pieces; at least one coil wound around the first pole piece and/or the third pole piece; and a control device controlling electric current applied to the coil, wherein at least one least one of the firs

**[p0006]**

t pole piece assembly, the second pole piece assembly and the connection pole piece assembly is configured to be movable such that they are switched between a first arrangement in which the second faces of the first pole piece assembly are spaced apart from the first faces of the second pole piece assembly while the first faces of the first pole piece assembly come in contact with the second faces of the connection pole piece assembly, and a second arrangement in which the second faces of the first pole piece assembly come in contact with the first faces of the second pole piece assembly while the first faces of the first pole piece assembly are spaced apart from the second faces of the connection pole piece assembly, and wherein the control device controls holding and detaching of a workpiece on and from the first faces of the connection pole piece assembly or the second faces of the second pole piece assembly, by way of controlling electric current applied to the coil to switch between the first arrangement and the second arrangement.

**[p0007]**

The first faces of the connection pole piece assembly and the second faces of the second pole piece assembly may be configured to hold and detach a single workpiece. The first pole piece assembly may be movable along a plane extended from the second faces of the second pole piece assembly and the first faces of the connection pole piece assembly. At least two first permanent magnets may be disposed between the first pole piece and each of the second pole pieces, and at least two second permanent magnets may be disposed between the third pole piece and each of the fourth pole pieces. The first permanent magnets may be disposed in a line between the first pole piece and each of the second pole pieces, and the second permanent magnets may be disposed in a line between the third pole piece and each of the fourth pole pieces. The first pole piece assembly may comprise at least two first pole pieces, the second pole piece assembly may comprise at least two third pole pieces, at least one first permanent magnet may be disposed between each of the first pole piece and a respective one of the second pole pieces, and at least one second permanent magnet may be disposed between each of the third pole piece and a respective one of the fourth pole pieces.

**[p0008]**

An area of the first face of each of the fourth pole pieces may be smaller than an area of the second face of a respective one of the second pole pieces, and the area of the second face of each of the fourth pole pieces may be smaller than an area of the first face of a respective one of the fourth pole pieces. The device may further comprise: a rail bolt fixed to the first pole piece assembly and to the base while penetrating the second pole piece assembly so that the second pole piece assembly slides along the rail bolt. The device may further comprise: a rail bolt fixed to the first pole piece assembly and to the connection pole piece assembly while penetrating the second pole piece assembly so that the second pole piece assembly slides along the rail bolt. According to the magnetic substance holding device of the present invention, residual magnetism when a workpiece has been detached therefrom can be minimized. In addition, by disposing coils around pole pieces instead of an additional electromagnet, strong holding force can be obtained in a simple structure, magnetic force from a permanent magnet can be controlled with small electric current at the time of switching between holding and detaching, and strong holding force can be obtained in a smaller space.

### Brief Description Of The Drawings

**[p0009]**

The above and other aspects, features and other advantages of the present invention will be more clearly understood from the following detailed description taken in conjunction with the accompanying drawings, in which: FIGS. 1A to 1F are schematic cross-sectional views of a magnetic substance holding device according to an exemplary embodiment of the present invention; FIG. 2 is a schematic cross-sectional view of a magnetic substance holding device according to another exemplary embodiment of the present invention; FIGS. 3A to 3C are schematic cross-sectional views of a magnetic substance holding device according to yet another exemplary embodiment of the present invention; FIGS. 4A to 4D are a schematic perspective view and side cross-sectional views of a magnetic substance holding device according to still another exemplary embodiment of the present invention; and FIGS. 5A and 5B are schematic, side cross-sectional views of a magnetic substance holding device according to variants of the magnetic substance holding device shown in FIGS. 4A to 4D .

### Detailed Description Of The Preferred Embodiment

**[p0010]**

Advantages and features of the present invention and methods to achieve them will become apparent from the descriptions of exemplary embodiments herein below with reference to the accompanying drawings. However, the present invention is not limited to exemplary embodiments disclosed herein but may be implemented in various different ways. The exemplary embodiments are provided for making the disclosure of the present invention thorough and for fully conveying the scope of the present invention to those skilled in the art. It is to be noted that the scope of the present invention is defined only by the claims. The figures, dimensions, ratios, angles, numbers of elements given in the drawings are merely illustrative and are not limiting. Further, in describing the present invention, descriptions on well-known technologies may be omitted in order not to obscure the gist of the present invention. It is to be noticed that the terms “comprising,” “having,” “including” and so on, used in the description and claims, should not be interpreted as being restricted to the means listed thereafter unless specifically stated otherwise. Where an indefinite or definite article is used when referring to a singular noun, e.g. “a,” “an,” “the,” this includes a plural of that noun unless specifically stated otherwise.

**[p0011]**

In describing elements, they are interpreted as including error margins even without explicit statements. In describing positional relationship, such as “an element A on an element B,” “an element A above an element B,” “an element A below an element B” and “an element A next to an element B,” another element C may be disposed between the elements A and B unless the term “directly” or “immediately” is explicitly used. As used herein, a phrase “an element A on an element B” refers to that the element A may be disposed directly on the element B and/or the element A may be disposed indirectly on the element B via another element C. Like reference numerals denote like elements throughout the descriptions. Although terms such as first, second, etc. are used to distinguish arbitrarily between the elements such terms describe and these terms are not necessarily intended to indicate temporal or other prioritization of such elements. Theses terms are used to merely distinguish one element from another. Accordingly, as used herein, a first element may be a second element within the technical scope of the present invention.

**[p0012]**

The drawings are not to scale and the relative dimensions of various elements in the drawings are depicted schematically and not necessarily to scale. Features of various exemplary embodiments of the present invention may be combined partially or totally. As will be clearly appreciated by those skilled in the art, technically various interactions and operations are possible. Various exemplary embodiments can be practiced individually or in combination. Hereinafter, magnetic substance holding devices according to exemplary embodiments of the present invention will be described with reference to the accompanying drawings. At first, the basic configuration and operating principle of a magnetic substance holding device of the present invention will be described. FIGS. 1A to 1F are schematic cross-sectional views of a magnetic substance holding device according to an exemplary embodiment of the present invention. In particular, FIGS. 1E and 1F are schematic cross-sectional views of a magnetic substance holding device according to a variant of the magnetic substance holding device shown in FIGS. 1A to 1D .

**[p0013]**

Referring to FIGS. 1A to 1D , the magnetic substance holding device 1000 includes a first pole piece assembly 1100 , a second pole piece assembly 1200 , coils 1300 , a base 1400 , and a control device (not shown). The first pole piece assembly 1100 includes at least one first pole piece 1110 , at least two second pole pieces 1120 , and at least two first permanent magnets 1130 . The first pole piece 1110 is a magnetic substance and has a first face 1111 and a second face 1112 . Further, each of the second pole pieces 1120 is a magnetic substance and has a first face 1121 and a second face 1122 . The N-pole or the S-pole of each of the first permanent magnets 1130 is in contact with the first piece 1110 while the S-pole or the N-pole thereof is in contact with the respective second pole pieces 1120 . For example, as shown in FIGS. 1A to 1D , the N-pole of each of the first permanent magnets 1130 may be in contact with the first pole piece 1110 while the S-pole thereof may be in contact with the respective second pole pieces 1120 . The poles of the first permanent magnets 1130 may be disposed in the opposite direction.

**[p0014]**

The second pole piece assembly 1200 includes at least one third pole piece 1210 , at least two fourth pole pieces 1220 , and at least two second permanent magnets 1230 . The third pole piece 1210 is a magnetic substance and has a first face 1211 and a second face 1212 . Further, each of the fourth pole pieces 1220 is a magnetic substance and has a first face 1221 and a second face 1222 . Between the N-pole and the S-pole of each of the second permanent magnets 1130 , the pole of opposite polarity to that of the poles of the first permanent magnets in contact with the first pole piece 1110 is in contact with the third pole piece 1210 while the other pole is in contact with a respective one of the fourth pole pieces 1120 . The first pole piece assembly 1100 and the second pole piece assembly 1200 are arranged so that the first face 1211 of the third pole piece 1210 can come in contact with and be spaced apart from the second face 1112 of the first pole piece 1110 (i.e., they face each other) while the first face 1221 of each of the fourth pole pieces 1220 can come in contact with and be spaced apart from the second face 1122 of a respective one of the second pole pieces 1120 (i.e., they face each other).

**[p0015]**

The coils 1300 may be wound around the first pole piece 1110 and/or the third pole piece 1210 . Coils 1310 and 1320 may be wound around the first pole piece 1110 and the third pole piece 1210 , respectively, as shown in FIGS. 1A to 1D , or may be wound around only the first pole piece 1110 or only the third pole piece 1210 , although not shown in the drawings. The coils 1310 and 1320 are wound around magnetic substances and affect magnetic fluxes in the magnetic substances by magnetizing the magnetic substances upon application of electric current. The coils 1310 and 1320 are disposed so that they can affect a magnetic flux passing through the first face 1111 of the first pole piece 1110 and a magnetic flux passing through the second face 1212 of the third pole piece 1210 , respectively. The coil 1310 may be disposed closer than the first permanent magnet 1130 to the first face 1111 of the first pole piece 1110 as shown in FIG. 1A to 1D , or may be disposed more distant than the first permanent magnet 1130 from the first face 1111 of the first pole piece 1110 . The coil 1320 may be disposed closer than the second permanent magnet 1230 to the second face 1212 of the third pole piece 1210 as shown in FIG. 1A to 1D , or may be disposed more distant than the second permanent magnet 1230 from the second face 1212 of the third pole piece 1210 .

**[p0016]**

Although each of the coils 1310 and 1320 is wound around the first and third pole pieces, respectively, in FIGS. 1A to 1D , two or more coils may be wound around the first and third pole pieces, respectively. In addition, it is beneficial to dispose the coils 1310 and 1320 between the second permanent magnets 1230 and the second faces 1212 and 1222 of the second pole piece assembly 1200 for the purpose of controlling magnetic flux. In addition, coils 1310 and 1320 may be disposed between the first permanent magnets 1130 and the first faces 1111 and 1121 of the first pole piece assembly 1100 . Such disposal of the coils 1310 and 1320 may be applied to other exemplary embodiments. The coils 1310 and 1320 are connected to the control device. The control device controls (the direction or intensity of) electric current applied to the coils 1310 and 1320 . As used herein, electric current refers to direct current (DC). The base 1400 has a contact face 1401 and is a magnetic substance. The base 1400 is disposed so that it can come in contact with and be spaced apart from the first faces 1111 and 1121 of the first pole piece assembly 1100 (i.e., they face each other). The contact face 1401 of the base 1400 may be in contact with the first faces 1111 and 1121 of the first pole piece assembly 1100 so that the base 1400 may move together with the first pole piece assembly 1100 or may be stationary.

**[p0017]**

At least one of the first pole piece assembly 1100 , the second pole piece assembly 1200 and the base 1400 is movable, so that a first arrangement in which the second faces 1112 and 1122 of the first pole piece assembly 1100 are spaced apart from the first faces 1211 and 1221 of the second pole piece assembly 1200 , respectively, while the first faces 1111 and 1121 of the first pole piece assembly 1100 come in contact with the contact face 1401 of the base 1400 (the arrangement shown in FIGS. 1C and 1D ), and a second arrangement in which the second faces 1112 and 1122 of the first pole piece assembly 1100 come in contact with the first faces 1211 and 1221 of the second pole piece assembly 1200 , respectively, while the first faces 1111 and 1121 of the first pole piece assembly 1100 are spaced apart from the contact face 1401 of the base 1400 (the arrangement shown in FIGS. 1A and 1B ) are switched between each other. Specifically, only the first pole piece 1100 or only the second pole piece 1200 may be movable, or both of the first and second pole pieces 1100 and 1200 may be movable. In the following descriptions, only the first pole piece assembly 1100 is movable in exemplary embodiments for the sake of convenience in description. However, it is to be understood that the present invention is not limited thereto.

**[p0018]**

Referring to FIGS. 1A to 1D , rail bolts 1001 and 1002 are fixed to the first pole piece assembly 1100 and to the base 1400 and penetrate the second pole piece assembly 1200 , so that the second pole piece assembly 1200 slides along the rail bolts 1001 and 1002 by magnetic force. Namely, the first pole piece 1110 may slide along the rail bolt 1001 in the axial direction, as the rail bolt 1001 is fixed to the base 1400 and to the third pole piece 1210 while passing through the first pole piece 1110 . Further, the second pole pieces 1120 may slide along the rail bolts 1002 , as the rail bolts 1002 fixed to the base 1400 and to the fourth pole pieces 1220 pass through the second pole pieces 1120 . The rail bolts 1001 and 1002 are non-magnetic substances and thus no magnetic flux may be created through the rail bolts 1001 and 1002 . The rail bolts 1001 and 1002 may be fixed to the first pole piece assembly 1100 and to the base 1400 by screwing them thereinto. On the other hand, the rail bolts 1001 and 1002 may be fixed to at least one of the first pole piece assembly 1100 , the second pole piece assembly 1200 and the base 1400 , so that the others may slide along the rail bolts 1001 and 1002 .

**[p0019]**

The control device adjusts (the direction or amplitude of) electric current applied to the coils 1310 and 1320 to thereby control the direction and the intensity of magnetic fluxes passing through the coils 1310 and 1320 . Referring to FIG. 1A , when the first pole piece assembly 1100 and the second pole piece assembly 1200 are in the second arrangement in which they are in contact with each other, with no electric current applied from the control device to the coils 1310 and 1320 , a magnetic flux flows inside the magnetic circuit through the second faces 1112 and 1122 of the first pole piece assembly 1100 and the first faces 1211 and 1221 of the second pole piece assembly 1200 , as indicated by the dashed lines. In this instance, almost no magnetic flux passes through the first faces 1111 and 1121 of the first pole piece assembly 1100 and the second faces 1212 and 1222 of the second pole piece assembly 1200 . The magnetic fluxes passing through the first faces 1111 and 1121 of the first pole piece assembly 1100 and the second faces 1212 and 1222 of the second pole piece assembly 1200 are proportional to the difference in magnetic forces (magnetic energies) between the first permanent magnets 1130 and the second permanent magnets 1230 . Therefore, in the arrangement shown in FIG. 1A , attractive forces between the first faces 1111 and 1121 of the first pole piece assembly 1100 and the base 1400 are minimized, and a workpiece, which is a magnetic substance, is not held on the second faces 1212 and 1222 of the second pole piece assembly 1200 (Throughout the drawings, a workp

**[p0019]**

iece that is not held by the device is indicated by a dashed line).

**[p0020]**

On the other hand, when the control device applies electric current to the coils 1310 and 1320 as shown in FIG. 1B , the magnetic fluxes between the first permanent magnets 1130 and the second permanent magnets 1230 through the second faces 1112 and 1122 of the first pole piece assembly 1100 and the first faces 1211 and 1221 of the second pole piece assembly 1200 become weak and are eventually disconnected. When this happens, the first pole piece assembly 1100 slides along the rail bolts 1001 and 1002 by magnetic force, so that the first faces 1111 and 1121 of the first pole piece assembly 1100 come in contact with the contact face 1401 of the base 1400 , while the second faces 1212 and 1222 of the second pole piece assembly 1200 come in contact with a workpiece 1 which is a magnetic substance. As a result, magnetic fluxes passing through the base 1400 and the workpiece 1 are created as indicated by the dashed lines in FIG. 1C , so that the base 1400 is attached to the first faces 1111 and 1122 of the first pole piece assembly 1100 by stronger magnetic force, while the workpiece 1 is held on the second faces 1212 and 1222 of the second pole piece assembly 1200 .

**[p0021]**

Thereafter, as shown in FIG. 1C , the magnetic fluxes once formed through the base 1400 and the workpiece 1 are not broken but remain even if electric current is no more applied to the coils 1310 and 1320 . Further, since no magnetic flux is formed passing through the second faces 1112 and 1122 of the first pole piece assembly 1100 and the first faces 1211 and 1221 of the second pole piece assembly 1200 , the first pole piece assembly 1100 and the second pole piece assembly 1200 can be spaced apart from each other. Later on, as shown in FIG. 1D , by applying electric current to the coils 1310 and 1320 in the opposite direction to that shown in FIG. 1B , it is possible to detach the base 1400 and the workpiece 1 from the first pole piece assembly 1100 and the second pole piece assembly 1200 again. When electric current is applied to the coils 1310 and 1320 in the direction shown in FIG. 1D , the magnetic fluxes passing through the first faces 1111 and 1121 of the first pole piece assembly 1100 and the second faces 1211 and 1222 of the second pole piece assembly 1200 become weak and are eventually disconnected. Accordingly, the first pole piece assembly 1100 slides along the rail bolts 1001 and 1002 by magnetic force, so that the first pole piece assembly 1100 and the second pole piece assembly 1200 are switched to the second arrangement as shown in FIG. 1A , and the magnetic flux as shown in FIG. 1A can be restored.

**[p0022]**

In addition, the separation distance by which the base 1400 in the first arrangement is spaced apart from the first faces 1111 and 1121 of the first pole piece assembly 1100 also has to be determined appropriately. If the distance is too distant, the base 1400 may not be attached to the first faces 1111 and 1121 of the first pole piece assembly 1100 even when electric current is applied to the coils 1310 and 1320 . On the other hand, if the distance is too close, the base 1400 may be attached to the first faces 1111 and 1121 of the first pole piece assembly 1100 even when electric current is not applied to the coils 1310 and 1320 . Therefore, in view of the above, the separation distance between the base 1400 in the first arrangement and the first faces 1111 and 1121 has to be adjusted such that the base 1400 is attached to the first faces 1111 and 1121 of the first pole piece assembly 1100 only when certain amount of electric current is applied to the coils 1310 and 1320 . The distance may be adjusted empirically or experimentally, taking into account the intensity of the magnetic force induced by the coils 1310 and 1320 , or the like.

**[p0023]**

In short, the control device adjusts electric current applied to the coils 1310 and 1320 to thereby control the direction and intensity of the magnetic fluxes passing through the coils 1310 and 1320 . By doing so, the first pole piece assembly 1100 , the second pole piece assembly 1200 and the base 1400 can be switched between the first arrangement and the second arrangement, and the direction and intensity of the magnetic fluxes passing through the first faces 1111 and 1121 of the first pole piece assembly 1100 and the second faces 1212 and 1222 of the second pole piece assembly 1200 can be controlled. As a result, the workpiece 1 , which is a magnetic substance, can be held on and detached from the second faces 1212 and 1222 of the second pole piece assembly 1200 . Referring back to FIG. 1A , when the workpiece is detached from the magnetic substance holding device 1000 thus configured, the magnetic fluxes from the permanent magnets 1130 and 1230 flow only inside the magnetic circuit, so that it is possible to leave almost zero or completely no residual magnetism toward the outside. (This effect can be maximized when the first permanent magnets 1130 and the second permanent magnets 1230 have the equal magnetic force (magnetic energy).) Further, in this structure, permanent magnets can be placed closely together, and thus stronger holding force can be obtained.

**[p0024]**

Referring to FIGS. 1E and 1F , at least two first pole pieces 1110 ′ and at least two third pole pieces 1210 ′ can be disposed. In this instance, at least one first permanent magnets 1130 ′ may be disposed between a first pole piece 1110 ′ a and the respective one of the second pole pieces 1120 ′ while at least one first permanent magnet 1130 ′ may be disposed between a first pole piece 1110 ′ b and the respective one of the second pole pieces 1120 ′. Further, at least one second permanent magnets 1230 ′ may be disposed between a third pole piece 1210 ′ a and the respective one of the fourth pole pieces 1220 ′ while at least one first permanent magnet 1230 ′ may be disposed between a third pole piece 1210 ′ b and the respective one of the fourth pole pieces 1220 ′. With this configuration, magnetic fluxes in each of the first pole pieces 1110 ′ a and 1110 ′ b and each of the third pole pieces 1210 ′ a and 1210 ′ b are not superposed on one another. Namely, magnetic fluxes each created from the first permanent magnets 1130 ′ or the second permanent magnets 1230 ′ may be formed so that they are not superposed on one another in any of the pole pieces 1110 ′ a , 1110 ′ b , 1210 ′ a and 1210 ′ b . Further, each of the rail bolts 1001 ′ penetrates a respective one of the first pole pieces 1110 ′ and is fixed to a respective one of the third pole pieces 1210 ′, thereby guiding the movement of the first pole piece assembly 1100 ′.

**[p0025]**

The first pole pieces 1110 ′ a and 1110 ′ b may be spaced apart from each other, and the third pole pieces 1210 ′ a and 1210 ′ b may be spaced apart from each other, as shown in FIGS. 1E and 1F . However, they may be in contact with each other. Further, the magnetic substance holding device 1000 according to this exemplary embodiment may further include means for further reducing residual magnetism. The means for further reducing residual magnetism will be described in detail below. When the first pole piece assembly 1100 and the second pole piece assembly 1200 are in the second arrangement as shown in FIG. 1 A, residual magnetism is created in a such manner that a part of the magnetic flux flowing in the magnetic circuits (indicated by the dashed lines) comes out of the circuits to affect the workpiece 1 . Therefore, in order to eliminate residual magnetism, it is necessary to enhance the magnetic circuits as shown in FIG. 1A while making it difficult for magnetic fluxes to come out of the circuit.

**[p0026]**

Referring to FIGS. 1A to 1D , the area of the first faces of the four pole pieces 1220 may be smaller than the area of the second faces 1122 of the second pole pieces 1120 , and the area of the second faces 1222 of the fourth pole pieces 1220 may be smaller than the first faces 1221 of the fourth pole pieces 1220 . In other words, the thickness of the second pole pieces 1120 close to the second faces 1122 may be larger than the thickness of the four pole pieces 1220 close to the first faces 1221 , and the thickness of the fourth pole pieces 1220 close to the second face 1222 may be smaller than the thickness of the four pole pieces 1220 close to the first faces 1221 . With this configuration, the magnetic flux from the second permanent magnet 1230 is facilitated more toward the first faces 1211 and 1221 of the second pole piece assembly 1200 than toward the second faces 1212 and 1222 . Namely, it is possible to eliminate residual magnetism by way of making it difficult to form magnetic fluxes toward the second faces 1212 and 1222 of the second pole piece assembly 1200 . It is to be understood that such features can be applied to other exemplary embodiments.

**[p0027]**

On the other hand, it is desirable to shape inner faces of the third pole piece 1210 and the fourth pole pieces 1220 to be straight, to facilitate magnetic fluxes between the second permanent magnets 1230 and the workpiece 1 so that attaching force can be enhanced. Hereinafter, various exemplary embodiments of the present invention which are modifications of the structure shown in FIGS. 1A to 1D will be described. FIG. 2 is a schematic cross-sectional view of a magnetic substance holding device according to another exemplary embodiment of the present invention. Referring to FIG. 2 , the magnetic substance holding device 2000 includes a first pole piece assembly 2100 , a second pole piece assembly 2200 , coils 2300 , and a control device (not shown). The first pole piece assembly 2100 , the second pole piece assembly 2200 and the coils 2300 are identical to the first pole piece assembly 1100 , the second pole piece assembly 1200 and the coils 1300 shown in FIGS. 1A to 1D ; and, therefore, the redundant descriptions will be omitted. The magnetic substance holding device 2000 according to this exemplary embodiment is different from the magnetic substance holding device 1000 shown in FIGS. 1A to 1D in that the base 1400 has been eliminated and that a workpiece 2 can also be held on and detached from the first faces 2111 and 2121 of the first pole piece assembly 2100 .

**[p0028]**

The first pole piece assembly 2100 and the second pole piece assembly 2200 is movable so that they can be switched between the first arrangement in which they are spaced apart from each other and the second arrangement in which they come in contact with each other. The first pole piece assembly 2100 and the second pole piece assembly 2200 may move in various manners known in the art, such as by using bolts and counter-bores. When the first pole piece assembly 2100 and the second pole piece assembly 2200 are in the first arrangement, the workpieces 1 and 2 are detached from the device. When the first pole piece assembly 2100 and the second pole piece assembly 2200 are in the second arrangement, the workpieces 1 and 2 are held on two sides of the device. FIGS. 3A to 3C are schematic cross-sectional views of a magnetic substance holding device according to yet another exemplary embodiment of the present invention. Referring to FIGS. 3A to 3C , the magnetic substance holding device 3000 includes a first pole piece assembly 3100 , a second pole piece assembly 3200 , coils 3300 , a connection pole piece assembly 3400 , and a control device (not shown).

**[p0029]**

The first pole piece assembly 3100 , the second pole piece assembly 3200 and the coils 3300 are identical to the first pole piece assembly 1100 , the second pole piece assembly 1200 and the coils 1300 shown in FIGS. 1A to 1D ; and, therefore, the redundant descriptions will be omitted. The connection pole piece assembly 3400 includes at least one first connection pole piece 3410 , and at least two second connection pole pieces 3420 . The first connection pole piece 3410 is a magnetic substance and has a first face 3411 and a second face 3412 . Further, each of the second connection pole pieces 3420 is a magnetic substance and has a first face 3421 and a second face 3422 . The connection pole piece assembly 3400 is arranged so that the second face 3412 of the first connection pole piece 3410 can come in contact with and be spaced apart from the first face 3111 of the first pole piece 3110 (i.e., they face each other) while the second face 3422 of each of the second connection pole pieces 3420 can come in contact with and be spaced apart from the first face 3121 of a respective one of the second pole pieces 3120 (i.e., they face each other).

**[p0030]**

At least one of the first pole piece assembly 3100 , the second pole piece assembly 3200 and the connection pole piece assembly 3400 are movable so that the first faces 3111 and 3121 of the first pole piece assembly 3100 come in contact with the second faces 3412 and 3422 of the connection pole piece assembly 3400 , respectively, for a first arrangement in which the first pole piece assembly 3100 is spaced apart from the second pole piece assembly 3200 (the arrangement shown in FIG. 3C ), while the first faces 3111 and 3121 of the first pole piece assembly 3100 are spaced apart from the second faces 3412 and 3422 of the connection pole piece assembly 3400 , respectively, for a second arrangement in which the first pole piece assembly 3100 comes in contact with the second pole piece assembly 3200 (the arrangement shown in FIGS. 3A and 3B ). Referring to FIGS. 3A to 3C , rail bolts 3001 and 3002 are fixed to the first pole piece assembly 3100 and the connection pole piece assembly 3400 and penetrate the second pole piece assembly 3200 , so that the second pole piece assembly 3200 slides along the rail bolts 3001 and 3002 by magnetic force. Namely, the first pole piece 3110 may slide along the rail bolt 3001 in the axial direction, as the rail bolt 3001 is fixed to the connection pole piece assembly 3400 and to the third pole piece 3210 while penetrating the first pole piece 3110 . Further, the second pole pieces 3120 may slide along the rail bolts 3002 in the axial direction, as the rail bolts 3002 are fixed to the connection pole piece assembly 3400 and to the fourth pole pi

**[p0030]**

eces 3220 while penetrating the second pole pieces 3120 . On the other hand, the rail bolts 3001 and 3002 may be fixed to at least one of the first pole piece assembly 3100 , the second pole piece assembly 3200 and the connection pole pieces assembly 3400 , so that the others may slide along the rail bolts 3001 and 3002 .

**[p0031]**

Referring to FIG. 3A , when the first pole piece assembly 3100 and the second pole piece assembly 3200 are in the second arrangement, with no current applied to the coils 3310 and 3320 , a magnetic flux flows inside the magnetic circuit in the first pole piece assembly 3100 and the second pole piece assembly 3200 and does not pass through the first faces 3111 and 3121 of the first pole piece assembly 3100 and the second faces 3212 and 3222 of the second pole piece assembly 3200 , and thus workpieces cannot be held on neither upper side nor lower side of the device. Then, when electric current in the direction indicated in FIG. 3B is applied to the coils 3310 and 3320 , the magnetic flux between the first pole piece assembly 3100 and the second pole piece assembly 3200 is disconnected, and a magnetic flux passing through the second faces 3212 and 3222 of the second pole piece assembly 3200 becomes strong, so that the workpiece 2 can be held on the side close to the second pole piece assembly 3200 . On the contrary, since the first pole piece assembly 3100 is spaced apart from the connection pole piece assembly 3400 , a magnetic flux passing through the first faces 3411 and 3421 of the connection pole piece assembly 3400 is almost zero, and thus a workpiece can hardly be held on the first faces 3411 and 3421 of the connection pole piece assembly 3400 .

**[p0032]**

Thereafter, when the amplitude of the electric current applied to the coils 3310 and 3320 in the direction indicated in FIG. 3B rises above a predetermine value, the first pole piece assembly 3100 slides along the rail bolts 3001 and 3002 by magnetic force to be in contact with the connection pole piece assembly 3400 . As a result, the first pole piece assembly 3100 and the second pole piece assembly 3200 are in the first arrangement. When the first pole piece assembly 3100 is in the first arrangement as shown in FIG. 3C , magnetic fluxes from the first permanent magnets 3130 pass through the workpiece 1 , and thus the workpiece 1 can be held on the upper side as well. Then, the magnetic fluxes once formed remain even if electric current is no more applied to the coils 3310 and 3320 , as indicated by the dashed lines in FIG. 3C . Accordingly, the workpiece 1 is held on the first faces 3411 and 3421 of the connection pole piece assembly 3400 while the workpiece 2 is held on the second faces 3212 and 3222 of the second pole piece assembly 3200 .

**[p0033]**

In order to detach the workpieces 1 and 2 from the first pole piece assembly 3100 and from the second pole piece assembly 3200 , respectively, by applying electric current in the opposite direction to that of FIG. 3B to the coils 3310 and 3320 so that the first pole piece assembly 3100 slides along the rail bolts 3001 and 3002 by magnetic force, the first pole piece assembly 3100 and the second pole piece assembly 3200 are placed in the second arrangement as shown in FIG. 3A to thereby restore the magnetic flux shown in FIG. 3A . The magnetic substance holding device 3000 according to this exemplary embodiment has an advantage in that it can hold workpieces 1 and 2 on both sides. In addition, at the time of detaching as shown in FIG. 3A , the connection pole piece assembly 3400 is spaced apart from the first pole piece assembly 2100 , and a magnetic flux flows only inside the magnetic circuit in the first pole piece assembly 3100 and the second pole piece assembly 3200 , leaving almost no residual magnetism.

**[p0034]**

In short, the control device adjusts electric current applied to the coils 3310 and 3320 to thereby control the direction and intensity of the magnetic fluxes passing through the coils 3310 and 3320 . By doing so, the first pole piece assembly 3100 , the second pole piece assembly 3200 and the connection pole piece assembly 3400 can be switched between the first arrangement and the second arrangement, and the direction and intensity of the magnetic fluxes passing through the first faces 3111 and 3121 of the first pole piece assembly 3100 and the second faces 3211 and 3221 of the second pole piece assembly 3200 can be controlled. As a result, the workpieces 1 and 2 , which are magnetic substances, can be held on and detached from the second faces 3212 and 3222 of the second pole piece assembly 3200 and the first faces 3411 and 3421 of the connection pole piece assembly 3400 . Although not shown in the drawings, at least two first connection pole pieces 1410 ′ may be disposed, like the first pole pieces 1110 ′ or the third pole pieces 1210 ′ shown in FIG. 2 . By doing so, magnetic fluxes in the first connection pole pieces 1410 ′ may not be superposed with each another. Namely, magnetic fluxes each created from the first permanent magnets 1130 ′ or the second permanent magnets 1230 ′ may be formed so that they are not superposed on one another in any of the first connection pole pieces 1410 ′. The first connection pole pieces 1410 ′ may be spaced apart from each other or may be in contact with each other.

**[p0035]**

FIGS. 4A to 4D are a schematic perspective view and side cross-sectional views of a magnetic substance holding device according to another exemplary embodiment of the present invention; and FIGS. 5A and 5B are schematic, side cross-sectional views of a magnetic substance holding device according to variants of the magnetic substance holding device shown in FIGS. 4A to 4D . Specifically, FIG. 4A is a perspective view conceptually showing the magnetic substance holding device shown in FIGS. 4B to 4D and FIGS. 5A and 5B . FIGS. 4B (a), 4 C(a), 4 D(a), 5 A(a) and 5 B(a) are cross-sectional views taken along line A-A of FIG. 4A . FIGS. 4B (b), 4 C(b), 4 D(b), 5 A(b) and 5 B(b) are cross-sectional views taken along line B-B of FIG. 4A . FIGS. 4B (c), 4 C(c), 4 D(c), 5 A(c) and 5 B(c) are cross-sectional views taken along line C-C of FIG. 4A . Referring to FIGS. 4A to 4D , the magnetic substance holding device 4000 according to this exemplary embodiment includes a first pole piece assembly 4100 , a second pole piece assembly 4200 , coils 4300 , a connection pole piece assembly 4400 , and a control device (not shown).

**[p0036]**

The first pole piece assembly 4100 , the second pole piece assembly 4200 , the coils 4310 and 4320 the connection pole piece assembly 4400 are identical to the first pole piece assembly 3100 , the second pole piece assembly 3200 , the coils 3310 and 3320 and the connection pole piece assembly 3400 shown in FIGS. 3A to 3C ; and, therefore, redundant descriptions thereon will be omitted. The feature of this exemplary embodiment lies in the locations of the first pole piece assembly 4100 , the second pole piece assembly 4200 and the connection pole piece assembly 4300 , which are different from the locations of the first pole piece assembly 3100 , the second pole piece assembly 3200 and the connection pole piece assembly 3300 shown in FIGS. 3A to 3C . The first pole piece assembly 4100 , the second pole piece assembly 4200 and the connection pole piece assembly 4400 all are adapted to hold and detach a single workpiece 1 . In this exemplary embodiment, the first faces 4411 and 4421 of the connection pole piece assembly 4400 and the second faces 4212 and 4222 of the second pole piece assembly 4200 are configured to have a plane shape. However, they may have different shapes depending on the shape of the workpiece 1 .

**[p0037]**

Further, the first pole piece assembly 4100 is movable along a plane extended from the second faces 4212 and 4222 of the second pole piece assembly 4200 and the first faces 4411 and 4421 of the connection pole piece assembly 4400 . In other words, the first pole piece assembly 4100 is movable in the horizontal direction. The second faces 4212 and 4222 of the second pole pieces assembly 4200 may be perpendicular to the first faces 4211 and 4221 of the second pole piece assembly 4200 . Further, the first faces 4411 and 4421 of the connection pole piece assembly 4400 may be perpendicular to the second faces 4412 and 4422 of the connection pole pieces assembly 4400 . As shown in FIGS. 4A to 4D , the second faces 4412 and 4422 of the connection pole piece assembly 4400 face the first faces 4211 and 4221 of the second pole piece assembly 4200 , respectively, with the first pole piece assembly 4100 therebetween. Referring to FIG. 4B , when the first pole piece assembly 4100 and the second pole piece assembly 4200 are in the second arrangement in which they are in contact with each other, with no electric current applied from the control device to the coils 4310 and 4320 , a magnetic flux flows inside the magnetic circuit through the second faces 1112 and 1122 of the first pole piece assembly 1100 and the first faces 1211 and 1221 of the second pole piece assembly 1200 , as indicated by the dashed lines shown in FIGS. 4B (b) and 4 B(c). Therefore, in the arrangement shown in FIG. 4B , a workpiece is held neither on the first faces 4411 and 4421 of the connection pole piece assembly

**[p0037]**

4400 nor on the second faces 4212 and 4222 of the second pole piece assembly 4200 .

**[p0038]**

On the other hand, when the control device applies electric current to the coils 4310 and 4320 as shown in FIG. 4C , the magnetic fluxes passing through the second faces 4112 and 4122 of the first pole piece assembly 4100 and the first faces 4211 and 4221 of the second pole piece assembly 4200 are disconnected, and magnetic fluxes passing through the second faces 4212 and 4222 of the second pole piece assembly 4200 become strong, so that the workpiece 1 can be held on the side close to the second pole piece assembly 4200 . On the contrary, since the first pole piece assembly 4100 is spaced apart from the connection pole piece assembly 4400 , magnetic fluxes passing through the first faces 4411 and 4421 of the connection pole piece assembly 4400 are almost zero, and thus a workpiece can hardly be held on the first faces 4411 and 4421 of the connection pole piece assembly 4400 . Thereafter, when the amplitude of the electric current applied to the coils 3310 and 3320 in the direction indicated in FIG. 4C rises above a predetermine value, the first pole piece assembly 4100 moves along the rail bolts 4001 and 4002 by magnetic force to be in contact with the connection pole piece assembly 4400 . As a result, the first pole piece assembly 4100 , the second pole piece assembly 4200 and the connection pole piece assembly are in the first arrangement. When the first pole piece assembly 4100 is in the first arrangement as shown in FIG. 4D , magnetic fluxes from the first permanent magnets 4130 pass through the workpiece 1 , and thus the workpiece 1 can be held on the first faces 4411

**[p0038]**

and 4421 of the connection pole piece assembly 4400 as well.

**[p0039]**

Then, the magnetic fluxes once formed remain even if electric current is no more applied to the coils 4310 and 4320 , as indicated by the dashed lines in FIG. 4D . Accordingly, the workpiece 1 is held on the second faces 4212 and 4222 of the second pole piece assembly 4200 and the first faces 4411 and 4421 of the connection pole piece assembly 4400 . The magnetic substance holding device 4000 according to this exemplary embodiment has an advantage in that it can hold workpieces 1 and 2 on both sides. In addition, at the time of detaching as shown in FIG. 4B , the connection pole piece assembly 4400 is spaced apart from the first pole piece assembly 4100 , and a magnetic flux flows only inside the magnetic circuit in the first pole piece assembly 4100 and the second pole piece assembly 4200 , leaving almost no residual magnetism. In addition, the magnetic substance holding device 4000 according to the present invention may be modified to have stronger holding force by disposing multiple permanent magnets 4130 and 4230 on one another.

**[p0040]**

Referring to FIG. 5A , at least two first permanent magnets 4130 ′ may be disposed between the first pole piece 4110 ′ and each of the second pole pieces 4120 ′, and at least two permanent magnets 4230 ′ may be disposed between the third pole piece 4210 ′ and each of the fourth pole pieces 4220 ′. The first permanent magnets 4130 ′ in contact with the respective second pole pieces 4120 ′ are disposed such that their the poles of the same polarity are in contact with the same pole piece(s) (the first pole piece 4110 ′ or the second pole pieces 4120 ′). The first permanent magnets 4130 ′ in contact with the respective second pole pieces 4120 ′ may be disposed on one another so that they can generate a strong magnetic flux as if they were a single permanent magnet. Further, the second permanent magnets 4230 ′ in contact with respective the fourth pole pieces 4220 ′ are disposed such that their poles of the same polarity are in contact with the same pole piece(s) (the third pole piece 4210 ′ or the fourth pole pieces 4220 ′). Further, the second permanent magnets 4230 ′ in contact with the respective fourth pole pieces 4220 ′ may be disposed on one another.

**[p0041]**

The permanent magnets 4130 ′ and 4230 ′ with their poles of the same polarity in contact with the same pole pieces may be disposed in a quadrangular shape as shown in FIG. 5A or may be disposed in a line as shown in FIG. 5B . The numbers and layouts of the permanent magnets 4130 ′, 4230 ′, 4130 ″ and 4230 ″ are not limited to those shown in FIGS. 5A and 5B , but may vary depending on design choices. As described above, the magnetic substance holding devices 4000 ′ and 4000 ″ according to the variants may have more permanent magnets 4130 ′, 4230 ′, 4130 ′ and 4230 ′ per volume, so that holding force can be increased. According to the magnetic substance holding devices ( 1000 to 4000 ) of the present invention, residual magnetism can be minimized when a workpiece is detached. In addition, by disposing coils around pole pieces instead of an additional electromagnet, strong holding force can be obtained in a simple structure, magnetic force from a permanent magnet can be controlled with small electric current at the time of switching between holding and detaching, and strong holding force can be obtained in a smaller space.

**[p0042]**

Thus far, exemplary embodiments of the present invention have been described in detail with reference to the accompanying drawings. However, the present invention is not limited to the exemplary embodiments, and modifications and variations can be made thereto without departing from the technical idea of the present invention. Accordingly, the exemplary embodiments described herein are merely illustrative and are not intended to limit the scope of the present invention. The technical idea of the present invention is not limited by the exemplary embodiments. Therefore, it should be understood that the above-described embodiments are not limiting but illustrative in all aspects. The scope of protection sought by the present invention is defined by the appended claims and all equivalents thereof are construed to be within the true scope of the present invention.

## Figure captions

- **Figure 1A:** FIGS. 1A to 1F are schematic cross-sectional views of a magnetic substance holding device according to an exemplary embodiment of the present invention;
- **Figure 2:** FIG. 2 is a schematic cross-sectional view of a magnetic substance holding device according to another exemplary embodiment of the present invention;
- **Figure 3A:** FIGS. 3A to 3C are schematic cross-sectional views of a magnetic substance holding device according to yet another exemplary embodiment of the present invention;
- **Figure 4A:** FIGS. 4A to 4D are a schematic perspective view and side cross-sectional views of a magnetic substance holding device according to still another exemplary embodiment of the present invention; and
- **Figure 5A:** FIGS. 5A and 5B are schematic, side cross-sectional views of a magnetic substance holding device according to variants of the magnetic substance holding device shown in FIGS. 4A to 4D .
- **Figure 1A:** FIGS. 1A to 1F are schematic cross-sectional views of a magnetic substance holding device according to an exemplary embodiment of the present invention. In particular, FIGS. 1E and 1F are schematic cross-sectional views of a magnetic substance holding device according to a variant of the magnetic substance holding device shown in FIGS. 1A to 1D .
- **Figure 1A:** Referring to FIGS. 1A to 1D , the magnetic substance holding device 1000 includes a first pole piece assembly 1100 , a second pole piece assembly 1200 , coils 1300 , a base 1400 , and a control device (not shown).
- **Figure 1A:** The coils 1300 may be wound around the first pole piece 1110 and/or the third pole piece 1210 . Coils 1310 and 1320 may be wound around the first pole piece 1110 and the third pole piece 1210 , respectively, as shown in FIGS. 1A to 1D , or may be wound around only the first pole piece 1110 or only the third pole piece 1210 , although not shown in the drawings.
- **Figure 1A:** Although each of the coils 1310 and 1320 is wound around the first and third pole pieces, respectively, in FIGS. 1A to 1D , two or more coils may be wound around the first and third pole pieces, respectively.
- **Figure 1E:** The first pole pieces 1110 ′ a and 1110 ′ b may be spaced apart from each other, and the third pole pieces 1210 ′ a and 1210 ′ b may be spaced apart from each other, as shown in FIGS. 1E and 1F . However, they may be in contact with each other.
- **Figure 1A:** Hereinafter, various exemplary embodiments of the present invention which are modifications of the structure shown in FIGS. 1A to 1D will be described.
- **Figure 2:** FIG. 2 is a schematic cross-sectional view of a magnetic substance holding device according to another exemplary embodiment of the present invention.
- **Figure 2:** Referring to FIG. 2 , the magnetic substance holding device 2000 includes a first pole piece assembly 2100 , a second pole piece assembly 2200 , coils 2300 , and a control device (not shown).
- **Figure 3A:** FIGS. 3A to 3C are schematic cross-sectional views of a magnetic substance holding device according to yet another exemplary embodiment of the present invention.
- **Figure 3A:** Referring to FIGS. 3A to 3C , the magnetic substance holding device 3000 includes a first pole piece assembly 3100 , a second pole piece assembly 3200 , coils 3300 , a connection pole piece assembly 3400 , and a control device (not shown).
- **Figure 1A:** The first pole piece assembly 3100 , the second pole piece assembly 3200 and the coils 3300 are identical to the first pole piece assembly 1100 , the second pole piece assembly 1200 and the coils 1300 shown in FIGS. 1A to 1D ; and, therefore, the redundant descriptions will be omitted.
- **Figure 3C:** Then, the magnetic fluxes once formed remain even if electric current is no more applied to the coils 3310 and 3320 , as indicated by the dashed lines in FIG. 3C . Accordingly, the workpiece 1 is held on the first faces 3411 and 3421 of the connection pole piece assembly 3400 while the workpiece 2 is held on the second faces 3212 and 3222 of the second pole piece assembly 3200 .
- **Figure 4A:** Referring to FIGS. 4A to 4D , the magnetic substance holding device 4000 according to this exemplary embodiment includes a first pole piece assembly 4100 , a second pole piece assembly 4200 , coils 4300 , a connection pole piece assembly 4400 , and a control device (not shown).
- **Figure 4D:** Then, the magnetic fluxes once formed remain even if electric current is no more applied to the coils 4310 and 4320 , as indicated by the dashed lines in FIG. 4D . Accordingly, the workpiece 1 is held on the second faces 4212 and 4222 of the second pole piece assembly 4200 and the first faces 4411 and 4421 of the connection pole piece assembly 4400 .
- **Figure 5A:** Referring to FIG. 5A , at least two first permanent magnets 4130 ′ may be disposed between the first pole piece 4110 ′ and each of the second pole pieces 4120 ′, and at least two permanent magnets 4230 ′ may be disposed between the third pole piece 4210 ′ and each of the fourth pole pieces 4220 ′.

## Classifications

- B23Q3/06
- B23Q3/1543
- B25B11/002
- B25B11/002
- B23Q2703/02
- B23Q2703/12
- B23Q3/154
- B23Q3/1543
- B23Q3/1543
- B23Q3/1543
- B25B11/00
- H01F2007/085
- H01F2007/085
- H01F7/02
- H01F7/02
- H01F7/02
- H01F7/0231
- H01F7/0252
- H01F7/0252
- H01F7/0257
- H01F7/0257
- H01F7/08
- H01F7/20
- H01F7/206
- H01F7/206

## Cited patent documents

- [US-2008290973-A1](https://patents.google.com/patent/US20080290973A1/en) — SEA
- [US-2010013583-A1](https://patents.google.com/patent/US20100013583A1/en) — SEA
- [US-2010301532-A1](https://patents.google.com/patent/US20100301532A1/en) — SEA
- [US-2011272537-A1](https://patents.google.com/patent/US20110272537A1/en) — SEA
- [US-2013135067-A1](https://patents.google.com/patent/US20130135067A1/en) — SEA
- [US-2014049347-A1](https://patents.google.com/patent/US20140049347A1/en) — SEA
- [US-2014361860-A1](https://patents.google.com/patent/US20140361860A1/en) — SEA
- [US-2015279541-A1](https://patents.google.com/patent/US20150279541A1/en) — SEA
- [US-2015287510-A1](https://patents.google.com/patent/US20150287510A1/en) — SEA
- [US-2015367484-A1](https://patents.google.com/patent/US20150367484A1/en) — SEA
- [US-2017103839-A1](https://patents.google.com/patent/US20170103839A1/en) — SEA
- [US-2017133136-A1](https://patents.google.com/patent/US20170133136A1/en) — SEA
- [US-3316514-A](https://patents.google.com/patent/US3316514A/en) — SEA
- [US-3336551-A](https://patents.google.com/patent/US3336551A/en) — SEA
- [US-3386156-A](https://patents.google.com/patent/US3386156A/en) — SEA
- [US-3854711-A](https://patents.google.com/patent/US3854711A/en) — SEA
- [US-4471331-A](https://patents.google.com/patent/US4471331A/en) — SEA
- [US-4663602-A](https://patents.google.com/patent/US4663602A/en) — SEA
- [US-4847582-A](https://patents.google.com/patent/US4847582A/en) — SEA
- [US-6489871-B1](https://patents.google.com/patent/US6489871B1/en) — SEA
- [US-7619499-B2](https://patents.google.com/patent/US7619499B2/en) — SEA
- [US-7782164-B2](https://patents.google.com/patent/US7782164B2/en) — SEA
- [US-7940149-B2](https://patents.google.com/patent/US7940149B2/en) — SEA
- [WO-2009069146-A1](https://patents.google.com/patent/WO2009069146A1/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
