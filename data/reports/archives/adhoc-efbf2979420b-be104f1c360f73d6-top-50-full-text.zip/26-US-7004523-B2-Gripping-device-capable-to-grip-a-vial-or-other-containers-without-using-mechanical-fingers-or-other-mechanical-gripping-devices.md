# 26. Gripping device capable to grip a vial or other containers without using mechanical fingers or other mechanical gripping devices

- **Archive rank:** 26 of 50
- **Publication:** [US-7004523-B2](https://patents.google.com/patent/US7004523B2/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/032851027/publication/US7004523B2?q=pn%3DUS7004523B2)
- **Publication date:** 2006-02-28
- **Filing date:** 2004-02-05
- **Earliest priority:** 2003-02-06
- **Family:** 32851027
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** VIRIDIS S A E
- **Inventors:** PEDRAZZINI GIANANDREA

## Abstract

It is described a gripping device for vials or similar containers, comprising a tubular body attached to one end of a movable supporting vertical shaft and gripping means associated to said tubular body. Said gripping means comprise non-mechanical gripping members, able to be connected with one end of a vial or container by face-to-face soft contact.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-7004523-B2/000.png)

![Sketch 1 for US-7004523-B2](https://nimo.iptorch.com/refdrawing/US-7004523-B2/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/US-7004523-B2/001.png)

![Sketch 2 for US-7004523-B2](https://nimo.iptorch.com/refdrawing/US-7004523-B2/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/US-7004523-B2/002.png)

![Sketch 3 for US-7004523-B2](https://nimo.iptorch.com/refdrawing/US-7004523-B2/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/US-7004523-B2/003.png)

![Sketch 4 for US-7004523-B2](https://nimo.iptorch.com/refdrawing/US-7004523-B2/003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/US-7004523-B2/004.png)

![Sketch 5 for US-7004523-B2](https://nimo.iptorch.com/refdrawing/US-7004523-B2/004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/US-7004523-B2/005.png)

![Sketch 6 for US-7004523-B2](https://nimo.iptorch.com/refdrawing/US-7004523-B2/005.png)

## Claims

### Claim 1 (independent)

Gripping device for containers, said gripping device comprising a tubular body attached to one end of a movable supporting vertical shaft and gripping means associated with said tubular body, said gripping means comprise non-mechanical gripping members able to be connected with one end of a container by face-to-face soft contact, said gripping members comprise a permanent magnet axially movable inside the tubular body by a piston housed in a cylinder, the tubular body being made of a diamagnetic material, the permanent magnet being movable between a rest position in a housing receptacle and a work position inside a ferromagnetic iron device engageable by face-to-face soft contact with a ferromagnetic iron insert attached to said one end of the container.

### Claim 2

Gripping device according to claim 1 , wherein said ferromagnetic iron device is an iron receptacle.

### Claim 3

Gripping device according to claim 1 , further comprising an optical fiber optic sensor arranged inside the tubular body for electromagnetic data transmission.

### Claim 4 (independent)

Gripping device for a container, said gripping device comprising a gripping member provided with an external tubular body of diamagnetic material and a permanent magnet movable within the tubular body between a rest position inside a ferromagnetic iron receptacle and a work position inside a ferromagnetic iron body, and a container provided with a ferromagnetic iron insert attached to one end of the container, the permanent magnet being engageable in face-to-face contact with the ferromagnetic iron insert of the container.

## Full description

**[p0001]**

This is a complete application claiming benefit of provisional 60/446,338 filed Feb. 6, 2003.

### Field Of The Invention

**[p0002]**

The present invention relates to a gripping device capable of gripping a vial or other containers without using mechanical fingers or other mechanical gripping devices.

### Background Of The Invention

**[p0003]**

Storing biological samples (vials) presents many and complex problems especially if this is done manually at iltra-low temperatures, such as −80° C. and −190° C. The critical aspects of the sample storing process are represented almost exclusively by the positive sample identification (ID code) and the sample handling operations based upon the “in and out motions” of the vial to and from the storage area (“deep freezer”). An automated process is then advisable but, in this case, sophisticated devices and a structured environment are required to maximize the rate “number of vials/volume of the deep freezer”. So the risks are different and serious: loss of sample integrity, loss of sample ID that is equivalent to the loss of the sample itself, dangerous handling process, biohazard. Actually the gripping operations are made by mechanical gripping devices with all the problems mentioned before.

### Summary Of The Invention

**[p0004]**

The object of the present invention is to provide a gripper device capable of gripping one vial at a time and bringing the operations associated with the vial handling to a very low risk level. Accordingly, such object is achieved by a gripping device for vials or similar containers, comprising a tubular body attached to one end of a movable supporting vertical shaft and gripping means associated with said tubular body, characterized in that said gripping means comprise non-mechanical gripping members able to be connected with one end of a vial or container by face-to-face soft contact. The advantage of such a device is that vials may be handled gently and stored side by side leaving a minimum space among them, space that would be necessary in case mechanical gripping fingers are used.

### Brief Description Of The Drawings

**[p0005]**

Embodiments of the present invention will now be described by way of example only, with reference to the accompanying drawings, in which: FIG. 1 is a axial-sectional view showing a first embodiment of a gripping device according to the present invention, which is provided with gripping members including a permanent magnet shown in rest position in a housing receptacle; FIG. 2 is an axial-sectional view like FIG. 1 with the permanent magnet in a middle transitional position; FIG. 3 is an axial-sectional view like FIGS. 1–2 with the permanent magnet in a work position; FIG. 4 is a cross-sectional view taken on the line IV—IV of FIG. 1 ; FIG. 5 is a perspective view showing another embodiment of the gripping device according to the present invention; FIG. 6 is an axial-sectional view of the gripping device of FIG. 5 .

### Detailed Description Of The Preferred Embodiments

**[p0006]**

In FIGS 1 – 4 a gripping device 50 is shown comprising a cylindrical body 1 of diamagnetic material (for example stainless steel or anodized aluminum) in which a premanent magnet 2 is axially movable by means of a piston housed in a gas cylinder 3 between a rest position in a “U” shaped ARMCO ferromagnetic material iron receptacle 4 and a work position inside an ARMCO ferromagnetic material iron device 5 . “ARMCO” means any ferromagnetic material with a very low magnetic hysteresis. The ARMCO ferromagnetic material iron device 5 consists of two legs 6 between which a plastic resin 7 is provided that incorporates an optical fiber sensor 8 for electromagnetic data transmission to an external monitoring station (not shown). A vial 9 has on the top a vial cap 20 which comprises a vial cap 10 with an ARMCO ferromagnetic material iron top cap insert 11 . The gripping device 50 is connected with a movable supporting vertical shaft 14 by means of a supporting body 12 .

**[p0007]**

When magnetic coupling is not required (rest position, FIG. 1 ) the permanent magnet 2 is kept at the upper position into the “U” shaped ARMCO ferromagnetic material iron receptacle 4 that is a real magnetic shield that annuls the magnetic field generated by said permanent magnet itself. On the contrary, when a vial 9 is to be gripped, the gripping device 50 is moved toward the vial 9 , in particular the bottom end of the gripping device is approached to the top of the cap 20 where the ARMCO ferromagnetic material iron insert 11 is located. When approaching the top of the vial 9 , an optical signal, through the optical fiber 8 , monitors said approach and, when the vertical shaft approach is completed, the piston of the cylinder 3 ( FIG. 2 ) will move the permanent magnet 2 down between the two ARMCO ferromagnetic material iron legs 6 (work position, FIG. 3 ). Such a movement allows the magnetic field generated by the magnet 2 to be conveyed to the top 11 of the cap 20 of the vial 9 and the magnetic gripping of the vial is obtained without any mechanical engagement.

**[p0008]**

The gripping device vertical shaft 14 is then moved upwards while the optical signal monitors that the vial cap 20 keeps facing the gripping device. The optical signal should detects if the vial cap 20 is missed during this vertical lifting and/or other following movements, so if there is evidence that the vial 9 has been lost, an error signal is generated for further investigation. If no problems occurs, after the vial 9 has been settled in its new location, the cylinder 3 will move the permanent magnet 2 upwards again into the ARMCO ferromagnetic material iron receptacle 4 and the gripping capability is lost. The shaft may now move away leaving the vial 9 at the new location. Also in this case the optical signal monitors that the dropping of the vial 9 into its new location has occurred correctly. By means of the optical fiber 8 it is possible to read correctly without mistake a dot matrix code engraved on the vial by an engraving tool such as a CO 2 laser source equipped with appropriate optical lenses and galvanometers to drive the optical laser beam.

**[p0009]**

An alternative to the magnetic gripping process is represented by a gripping device (second embodiment, FIGS. 5 and 6 ) that uses the ambient pressure in order to grip a vial 9 . Such a solution makes use of a vacuum device. In this case the top 11 of the vial cap 20 has the surface shape that matches with a suction cap 18 arranged at the lower end of a conical body 15 attached to a support body 17 . A pipe 16 passing through the bodies 15 and 17 and the supporting shaft connects the suction cap 18 to a vacuum generator (not shown) located outside of the cold chamber in which the vials are located. By generating vacuum it is possible to grip the vial 9 . Such a solution is preferable when the container is a glass bulb (ampule) that has generally a conic shaped top instead of a planar cap. An alternative to the optical fiber sensor is represented by a metal detector sensor (proximity sensor in case the top of the vial cap 20 is metallic) to monitor the coupling process between the gripping device and the vial 9 itself.

## Figure captions

- **Figure 1:** FIG. 1 is a axial-sectional view showing a first embodiment of a gripping device according to the present invention, which is provided with gripping members including a permanent magnet shown in rest position in a housing receptacle;
- **Figure 2:** FIG. 2 is an axial-sectional view like FIG. 1 with the permanent magnet in a middle transitional position;
- **Figure 3:** FIG. 3 is an axial-sectional view like FIGS. 1–2 with the permanent magnet in a work position;
- **Figure 4:** FIG. 4 is a cross-sectional view taken on the line IV—IV of FIG. 1 ;
- **Figure 5:** FIG. 5 is a perspective view showing another embodiment of the gripping device according to the present invention;
- **Figure 6:** FIG. 6 is an axial-sectional view of the gripping device of FIG. 5 .
- **Figure 1:** When magnetic coupling is not required (rest position, FIG. 1 ) the permanent magnet 2 is kept at the upper position into the “U” shaped ARMCO ferromagnetic material iron receptacle 4 that is a real magnetic shield that annuls the magnetic field generated by said permanent magnet itself.
- **Figure 5:** An alternative to the magnetic gripping process is represented by a gripping device (second embodiment, FIGS. 5 and 6 ) that uses the ambient pressure in order to grip a vial 9 .

## Classifications

- B01L9/50
- B01L9/50
- B01L3/14
- B01L3/5082
- B01L3/5082
- B01L9/00
- B25J15/06
- B25J15/06
- B25J15/06
- B25J15/0608
- B25J15/0608
- B25J15/0616
- B25J15/0616
- B65G2201/0258
- B65G2201/0258
- B66C1/04
- G01N2035/0405
- G01N2035/0405
- G01N2035/0406
- G01N2035/0406
- G01N2035/041
- G01N2035/041
- G01N2035/0465
- G01N2035/0465
- G01N2035/0477
- G01N2035/0477
- G01N35/00
- G01N35/0099
- G01N35/0099
- G01N35/04
- G01N35/04
- G01N35/04
- Y10S294/907
- Y10S294/907

## Cited patent documents

- [US-1739752-A](https://patents.google.com/patent/US1739752A/en) — SEA
- [US-4813729-A](https://patents.google.com/patent/US4813729A/en) — SEA
- [US-5348359-A](https://patents.google.com/patent/US5348359A/en) — SEA
- [US-5678696-A](https://patents.google.com/patent/US5678696A/en) — SEA
- [US-5845950-A](https://patents.google.com/patent/US5845950A/en) — SEA
- [US-6015175-A](https://patents.google.com/patent/US6015175A/en) — SEA
- [US-6086125-A](https://patents.google.com/patent/US6086125A/en) — SEA
- [US-6453543-B1](https://patents.google.com/patent/US6453543B1/en) — SEA
- [US-6538544-B1](https://patents.google.com/patent/US6538544B1/en) — SEA
- [US-6612633-B1](https://patents.google.com/patent/US6612633B1/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
