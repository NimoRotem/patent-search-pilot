# 22. Magnetische Werkstückspannvorrichtung

- **Archive rank:** 22 of 50
- **Publication:** [DE-102019202743-A1](https://patents.google.com/patent/DE102019202743A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/072046195/publication/DE102019202743A1?q=pn%3DDE102019202743A1)
- **Publication date:** 2020-09-03
- **Filing date:** 2019-02-28
- **Earliest priority:** 2019-02-28
- **Family:** 72046195
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** PROMESS GES FÜR MONTAGE- UND PRÜFSYSTEME MBH
- **Inventors:** ACKERT PATRICK

## Abstract

Die Erfindung betrifft eine magnetische Werkstückspannvorrichtung (1) für ein Freiformwerkstück (6), umfassend einen Auflagekörper (2) mit einer stetigen Auflagefläche (4) zur Anlage am Freiformwerkstück (6) und eine Magnetfeldquelle (3) zur Erzeugung eines Magnetfeldes, wobei die Werkstückspannvorrichtung (1) von einem Spannzustand (8) zur Fixierung des Freiformwerkstücks (6) in einen Lösezustand (10) zum Lösen des Freiformwerkstücks (6) von der Auflagefläche (4) umschaltbar ausgestaltet ist, und wobei sich das Magnetfeld im Spannzustand (8) vom Magnetfeld im Lösezustand (10) unterscheidet. Durch die Stetigkeit wird eine durchgehende, sich ohne Unterbrechung fortsetzende Auflagefläche (4) geschaffen, sodass sich ein höherer Spielraum für die Positionierung eines Spannpunkts vom Freiformwerkstück ergibt.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/59/5c/7b/ca2913b1d2a38e/DE102019202743A1_0001.png)

![Sketch 1 for DE-102019202743-A1](https://patentimages.storage.googleapis.com/59/5c/7b/ca2913b1d2a38e/DE102019202743A1_0001.png)

[Sketch 2](https://patentimages.storage.googleapis.com/ef/aa/e6/52932520ab9407/DE102019202743A1_0002.png)

![Sketch 2 for DE-102019202743-A1](https://patentimages.storage.googleapis.com/ef/aa/e6/52932520ab9407/DE102019202743A1_0002.png)

[Sketch 3](https://patentimages.storage.googleapis.com/af/a5/f3/7b9bc447fb6d10/DE102019202743A1_0003.png)

![Sketch 3 for DE-102019202743-A1](https://patentimages.storage.googleapis.com/af/a5/f3/7b9bc447fb6d10/DE102019202743A1_0003.png)

[Sketch 4](https://patentimages.storage.googleapis.com/b1/2a/2e/a3de9df92d2043/DE102019202743A1_0004.png)

![Sketch 4 for DE-102019202743-A1](https://patentimages.storage.googleapis.com/b1/2a/2e/a3de9df92d2043/DE102019202743A1_0004.png)

[Sketch 5](https://patentimages.storage.googleapis.com/8c/ed/4f/5a54a1b3e20261/DE102019202743A1_0005.png)

![Sketch 5 for DE-102019202743-A1](https://patentimages.storage.googleapis.com/8c/ed/4f/5a54a1b3e20261/DE102019202743A1_0005.png)

[Sketch 6](https://patentimages.storage.googleapis.com/a4/18/ff/ab044b9aa99501/DE102019202743A1_0006.png)

![Sketch 6 for DE-102019202743-A1](https://patentimages.storage.googleapis.com/a4/18/ff/ab044b9aa99501/DE102019202743A1_0006.png)

## Claims

### Claim 1

Magnetische Werkstückspannvorrichtung (1) für ein Freiformwerkstück (6), umfassend einen Auflagekörper (2) mit einer stetigen Auflagefläche (4) zur Anlage am Freiformwerkstück (6) und mit einer Magnetfeldquelle zur Erzeugung eines Magnetfeldes, wobei die Werkstückspannvorrichtung (1) von einem Spannzustand (8) zur Fixierung des Freiformwerkstücks (6) in einen Lösezustand (10) zum Lösen des Freiformwerkstücks (6) von der Auflagefläche (4) umschaltbar ausgestaltet ist und wobei sich das Magnetfeld im Spannzustand vom Magnetfeld im Lösezustand unterscheidet.

### Claim 2

Magnetische Werkstückspannvorrichtung (1) nach Anspruch 1, wobei wenigstens ein separates magnetisierbares Hilfselement (9) vorgesehen ist, das ausgestaltet ist, das Freiformwerkstück (6) zwischen Hilfselement (9) und Auflagefläche (4) anzuordnen.

### Claim 3

Magnetische Werkstückspannvorrichtung (1) nach Anspruch 1 oder 2, wobei der Auflagekörper (2) wiederholt lösbar ausgestaltet ist.

### Claim 4

Magnetische Werkstückspannvorrichtung (1) nach Anspruch 3, wobei der Auflagekörper (2) auf einem wiederholt lösbar ausgestalteten Spannaufsatz geformt ist.

### Claim 5

Magnetische Werkstückspannvorrichtung (1) nach einem der Ansprüche 1 bis 4, wobei zum Schalten zwischen Spannzustand (8) und Lösezustand (10) ein Antrieb (22) vorgesehen ist.

### Claim 6

Magnetische Werkstückspannvorrichtung (1) nach Anspruch 5, wobei Antrieb (22) und Magnetfeldquelle (3) in einem gemeinsamen Gehäuse (20) zu einem Schaltmodul (21) integriert sind.

### Claim 7

Magnetische Werkstückspannvorrichtung (1) nach Anspruch 6, wobei der Auflagekörper (2) Teil eines Spannmoduls (33) ist, das wiederholt lösbar mit dem Schaltmodul (21) verbunden ist.

### Claim 8

Magnetische Werkstückspannvorrichtung (1) nach einem der Ansprüche 1 bis 7, wobei sich die Auflagefläche (4) verjüngt.

### Claim 9

Magnetische Werkstückspannvorrichtung (1) nach einem der Ansprüche 1 bis 8, wobei die Auflagefläche (4) auf einen Auflagepunkt (41) zuläuft.

### Claim 10

Magnetische Werkstückspannvorrichtung (1) nach einem der Ansprüche 1 bis 9, wobei die Auflagefläche (4) zumindest abschnittsweise einen nicht ferromagnetischen Abschnitt (34) aufweist.

### Claim 11

Magnetische Werkstückspannvorrichtung (1) nach Anspruch 10, wobei das Spannmodul (33) zwei von dem nicht ferromagnetischen Abschnitt (34) getrennte Polschuhe (30) aufweist.

### Claim 12

Werkstückspannvorrichtung (1) nach Anspruch 11, wobei sich der Auflagepunkt (41) im nicht ferromagnetischen Abschnitt (32) der Auflagefläche (4) befindet.

### Claim 13

Magnetische Werkstückspannvorrichtung (1) nach einem der Ansprüche 1 bis 12, wobei der Auflagekörper (2) einen magnetischen Pol (53) bildet.

### Claim 14

Magnetische Werkstückspannvorrichtung (1) nach einem der Ansprüche 1 bis 13, wobei die Werkstückspannvorrichtung (1) einen Kraftaufnehmer (66) zum Erfassen der auf das Freiformwerkstück (6) wirkenden Spannkraft aufweist.

### Claim 15

Magnetische Werkstückspannvorrichtung (1) nach Anspruch 14, wobei die Werkstückspannvorrichtung (1) mit einer Regelung zum Regeln der auf das Freiformwerkstück (6) wirkenden Spannkraft anhand eines vom Kraftaufnehmer (66) ausgegebenen Messwertes versehen ist.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGMACHINE TOOLS; METAL-WORKING NOT OTHERWISE PROVIDED FORDETAILS, COMPONENTS, OR ACCESSORIES FOR MACHINE TOOLS, e.g. ARRANGEMENTS FOR COPYING OR CONTROLLING; MACHINE TOOLS IN GENERAL CHARACTERISED BY THE CONSTRUCTION OF PARTICULAR DETAILS OR COMPONENTS; COMBINATIONS OR ASSOCIATIONS OF METAL-WORKING MACHINES, NOT DIRECTED TO A PARTICULAR RESULTDevices holding, supporting, or positioning work or tools, of a kind normally removable from the machineDevices for holding work using magnetic or electric force acting directly on the workStationary devicesStationary devices using electromagnetsPERFORMING OPERATIONS; TRANSPORTINGMACHINE TOOLS; METAL-WORKING NOT OTHERWISE PROVIDED FORDETAILS, COMPONENTS, OR ACCESSORIES FOR MACHINE TOOLS, e.g. ARRANGEMENTS FOR COPYING OR CONTROLLING; MACHINE TOOLS IN GENERAL CHARACTERISED BY THE CONSTRUCTION OF PARTICULAR DETAILS OR COMPONENTS; COMBINATIONS OR ASSOCIATIONS OF METAL-WORKING MACHINES, NOT DIRECTED TO A PARTICULAR RESULTDevices holding, supporting, or positioning work or tools, of a kind normally removable from the machineDevices holding, supporting, or positioning work or tools, of a kind normally removable from the machine for mounting on a work-table, tool-slide, or analogous partAuxiliary devices, e.g. bolsters, extension membersConstructional elements used for constructing work holdersPERFORMING OPERATIONS; TRANSPORTINGHAND TOOLS; PORTABLE POWER-DRIVEN TOOLS; MANIPULATORSTOOLS OR BENCH DEVICES NOT OTHERWISE PROVIDED FOR, FOR FASTENING, CONNECTING, DISENGAGING, OR HOLDINGWork holders not covered by any preceding group in the subclass, e.g. magnetic work holders, vacuum work holdersMagnetic work holders

Description

Translated from German

Die Erfindung betrifft eine magnetische WerkstÃ¼ckspannvorrichtung fÃ¼r ein FreiformwerkstÃ¼ck.The invention relates to a magnetic workpiece clamping device for a free-form workpiece.

FreiformwerkstÃ¼cke kÃ¶nnen jede mÃ¶gliche Form annehmen. Im Rahmen der Fertigung mÃ¼ssen derartige FreiformwerkstÃ¼cke hÃ¤ufig fÃ¼r eine Verarbeitung, Bearbeitung oder Vermessung im Raum fixiert werden. Um wiederholbare Ergebnisse zu erhalten, ist eine reproduzierbare Fixierung notwendig. Bei einer hohen Variantenvielfalt mÃ¼ssen sich viele unterschiedliche FreiformwerkstÃ¼cke gleichermaÃen gut spannen lassen. In der Praxis stellt die LÃ¶sung dieser Anforderungen den Fachmann vor eine Herausforderung, zumal das FreiformwerkstÃ¼ck durch das Spannen nicht verformt werden darf.Freeform workpieces can take any shape. In the context of production, such free-form workpieces often have to be fixed in space for processing, machining or measurement. A reproducible fixation is necessary to get repeatable results. With a large number of variants, it must be possible to clamp many different freeform workpieces equally well. In practice, solving these requirements poses a challenge for the specialist, especially since the freeform workpiece must not be deformed by clamping.

Daher ist es die Aufgabe der Erfindung, eine WerkstÃ¼ckspannvorrichtung fÃ¼r beliebige FreiformwerkstÃ¼cke zu schaffen, die ein beschÃ¤digungsfreies und reproduzierbares Spannen ermÃ¶glicht.It is therefore the object of the invention to create a workpiece clamping device for any free-form workpieces that enables damage-free and reproducible clamping.

Die Aufgabe wird erfindungsgemÃ¤Ã gelÃ¶st durch eine magnetische WerkstÃ¼ckspannvorrichtung fÃ¼r ein FreiformwerkstÃ¼ck, umfassend einen AuflagekÃ¶rper mit einer stetigen AuflageflÃ¤che zur Anlage am FreiformwerkstÃ¼ck und eine Magnetfeldquelle zur Erzeugung eines Magnetfeldes, wobei die WerkstÃ¼ckspannvorrichtung von einem Spannzustand zur magnetischen Fixierung des FreiformwerkstÃ¼cks in einen LÃ¶sezustand zum LÃ¶sen des FreiformwerkstÃ¼cks von der AuflageflÃ¤che umschaltbar ausgestaltet ist, und wobei sich das Magnetfeld im Spannzustand vom Magnetfeld im LÃ¶sezustand unterscheidet.The object is achieved according to the invention by a magnetic workpiece clamping device for a free-form workpiece, comprising a support body with a continuous contact surface for contact with the free-form workpiece and a magnetic field source for generating a magnetic field, the workpiece clamping device from a clamping state for magnetic fixation of the free-form workpiece to a release state for releasing the free-form workpiece is designed to be switchable from the support surface, and wherein the magnetic field in the tensioned state differs from the magnetic field in the released state.

Durch die erfindungsgemÃ¤Ãe LÃ¶sung kann eine hohe FlexibilitÃ¤t erreicht werden. Das FreiformwerkstÃ¼ck liegt mit einem zum Spannen des FreiformwerkstÃ¼cks vorgesehenen Spannpunkt auf der stetigen AuflageflÃ¤che auf. Durch die Stetigkeit wird eine durchgehende, sich ohne Unterbrechung fortsetzende AuflageflÃ¤che geschaffen, sodass sich ein hÃ¶herer Spielraum fÃ¼r die Positionierung des Spannpunktes ergibt. Folglich kann verhindert werden, dass der Spannpunkt, beispielsweise aufgrund von unterschiedlichen Formen und GrÃ¶Ãen von verschiedenen FreiformwerkstÃ¼cken, im Spannzustand sich an einer undefinierten Stelle befindet. Dadurch bietet die erfindungsgemÃ¤Ãe WerkstÃ¼ckspannvorrichtung eine hohe FlexibilitÃ¤t bei der Anwendung und kann unabhÃ¤ngig von der GrÃ¶Ãe und Form des FreiformwerkstÃ¼cks und Spannbereichs eingesetzt werden. DarÃ¼ber hinaus kann durch das Schalten zwischen Spannzustand und LÃ¶sezustand eine benutzerfreundliche Bedienung erreicht werden, da keine groÃe Kraft zum LÃ¶sen des FreiformwerkstÃ¼cks aufgewendet werden muss. Folglich kann ein Verbiegen des FreiformwerkstÃ¼cks, insbesondere eines flexiblen FreiformwerkstÃ¼cks verhindert werden.The solution according to the invention enables a high degree of flexibility to be achieved. The free-form workpiece rests on the continuous support surface with a clamping point provided for clamping the free-form workpiece. The continuity creates a continuous support surface that continues without interruption, so that there is greater scope for positioning the clamping point. Consequently, it can be prevented that the clamping point is located at an undefined point in the clamping state, for example due to different shapes and sizes of different freeform workpieces. As a result, the workpiece clamping device according to the invention offers a high degree of flexibility in use and can be used regardless of the size and shape of the free-form workpiece and clamping area. In addition, by switching between the clamping state and the released state, user-friendly operation can be achieved, since no great force has to be used to release the free-form workpiece. Consequently, bending of the free-form workpiece, in particular of a flexible free-form workpiece, can be prevented.

Im Folgenden sind Weiterbildungen angefÃ¼hrt, die unabhÃ¤ngig voneinander beliebig miteinander kombinierbar sind und jeweils fÃ¼r sich betrachtet vorteilhaft sind.In the following, further developments are listed which can be combined with one another as desired independently of one another and are each advantageous considered individually.

Die erfindungsgemÃ¤Ãe LÃ¶sung beschrÃ¤nkt sich zwar auf eine magnetische WerkstÃ¼ckspannvorrichtung fÃ¼r FreiformwerkstÃ¼cke. Dies stellt in der Praxis jedoch nur eine geringe EinschrÃ¤nkung dar, da insbesondere im Karosseriebau unter anderem magnetisierbare FreiformwerkstÃ¼cke verwendet werden.The solution according to the invention is limited to a magnetic workpiece clamping device for free-form workpieces. In practice, however, this is only a minor restriction, since, among other things, magnetizable free-form workpieces are used, especially in bodywork.

Selbst wenn das FreiformwerkstÃ¼ck aus einem nicht magnetisierbaren Material geformt sein sollte, kann wenigstens ein magnetisierbares Hilfselement vorgesehen sein, das ausgestaltet ist, das FreiformwerkstÃ¼ck zwischen Hilfselement und AuflageflÃ¤che anzuordnen. Das Hilfselement kann beispielsweise mit dem FreiformwerkstÃ¼ck auf einer von der AuflageflÃ¤che abgewandten Seite angeordnet sein. Vorzugsweise kann im LÃ¶sezustand wenigstens ein Hilfselement von dem FreiformwerkstÃ¼ck gelÃ¶st oder lÃ¶sbar sein. Im Spannzustand kann wenigstens ein Hilfselement von dem Magnetfeld zur AuflageflÃ¤che angezogen werden und das FreiformwerkstÃ¼ck somit zwischen AuflageflÃ¤che und dem wenigstens einen Hilfselement einklemmen. Ein derartiges Hilfselement kann beispielsweise ein magnetischer oder eisenhaltiger KÃ¶rper sein, der von der restlichen WerkstÃ¼ckspannvorrichtung magnetisch angezogen werden kann. Vorzugsweise kann der KÃ¶rper als Kugel ausgestaltet sein.Even if the free-form workpiece should be formed from a non-magnetizable material, at least one magnetizable auxiliary element can be provided, which is designed to arrange the free-form workpiece between the auxiliary element and the support surface. The auxiliary element can for example be arranged with the freeform workpiece on a side facing away from the support surface. Preferably, in the released state, at least one auxiliary element can be detached or detachable from the free-form workpiece. In the clamping state, at least one auxiliary element can be attracted by the magnetic field to the support surface and the free-form workpiece can thus be clamped between the support surface and the at least one auxiliary element. Such an auxiliary element can for example be a magnetic or iron-containing body which can be magnetically attracted by the rest of the workpiece clamping device. The body can preferably be designed as a ball.

Die stetige AuflageflÃ¤che kann planar sein. Vorzugsweise kann sich die stetige AuflageflÃ¤che jedoch insbesondere in Richtung zum FreiformwerkstÃ¼ck und/oder zum Hilfselement verjÃ¼ngen. Die AuflageflÃ¤che kann sich in Richtung weg von der Magnetfeldquelle verjÃ¼ngen.The continuous support surface can be planar. Preferably, however, the continuous support surface can taper in particular in the direction of the free-form workpiece and / or the auxiliary element. The support surface can taper in the direction away from the magnetic field source.

Die stetige AuflageflÃ¤che kann insbesondere punktfÃ¶rmig auf einen Auflagepunkt zulaufen. Beispielsweise kann die AuflageflÃ¤che eine konische, pyramidale oder spitze Form aufweisen. Vorzugsweise kann die AuflageflÃ¤che konvex gewÃ¶lbt sein. Durch diese auf einen Auflagepunkt zulaufende Form kann erreicht werden, dass das FreiformwerkstÃ¼ck punktfÃ¶rmig auf der AuflageflÃ¤che aufliegt anstatt flÃ¤chig. Dadurch kann die FlexibilitÃ¤t der WerkstÃ¼ckspannvorrichtung weiter verbessert werden.The continuous support surface can, in particular, taper towards a support point in punctiform fashion. For example, the support surface can have a conical, pyramidal or pointed shape. The support surface can preferably be curved in a convex manner. As a result of this shape tapering towards a support point, it can be achieved that the freeform workpiece rests punctually on the support surface instead of flat. As a result, the flexibility of the workpiece clamping device can be further improved.

GemÃ¤Ã einer weiteren vorteilhaften Ausgestaltung kann die AuflageflÃ¤che eine ellipsoidische Form aufweisen, beispielsweise kann die konvexe AuflageflÃ¤che eine Kalottenform aufweisen. Vorzugsweise kann die Form der AuflageflÃ¤che rotationssymmetrisch um eine Mittelachse sein. Die Mittelachse kann dabei einen Scheitel, der ein lokales Maximum der AuflageflÃ¤che bildet, schneiden. Durch die ellipsoidische, gar kalottenfÃ¶rmige AuflageflÃ¤che bietet sich eine groÃe VielfÃ¤ltigkeit an Positionen, an denen das FreiformwerkstÃ¼ck auf der AuflageflÃ¤che aufliegen kann. Dadurch kann die FlexibilitÃ¤t der WerkstÃ¼ckspannvorrichtung weiter erhÃ¶ht werden. Vorzugsweise kann die AuflageflÃ¤che die Form einer Halbkugel aufweisen, wodurch ein mÃ¶glichst einfacher Aufbau erreicht werden kann. Alternativ dazu kann die AuflageflÃ¤che auch als Hyperboloid geformt sein.According to a further advantageous embodiment, the bearing surface can have an ellipsoidal shape, for example the convex bearing surface can have a spherical shape. Preferably, the shape of the support surface be rotationally symmetrical about a central axis. The central axis can intersect a vertex that forms a local maximum of the support surface. The ellipsoidal, even dome-shaped support surface offers a wide variety of positions at which the free-form workpiece can rest on the support surface. This allows the flexibility of the workpiece clamping device to be increased further. The support surface can preferably have the shape of a hemisphere, whereby the simplest possible structure can be achieved. Alternatively, the support surface can also be shaped as a hyperboloid.

GemÃ¤Ã einer weiteren vorteilhaften Ausgestaltung kann als Magnetfeldquelle wenigstens ein schaltbare Magneteinheit vorgesehen sein, der im Spannzustand ein stÃ¤rkeres magnetisches Feld verursacht als im LÃ¶sezustand. Dadurch kann das FreiformwerkstÃ¼ck oder Hilfselement im Spannzustand stark magnetisiert werden und zur Anlage an der AuflageflÃ¤che gegen die WerkstÃ¼ckspannvorrichtung gezogen werden. Die Spannkraft, mit der das FreiformwerkstÃ¼ck oder Hilfselement im Spannzustand gespannt wird, kann durch den schaltbaren Magneten justiert werden, wodurch eine BeschÃ¤digung und/oder ungewollte Deformation des FreiformwerkstÃ¼ckes verhindert werden kann. Die Justierung kann beispielsweise durch VerÃ¤nderung einer Rotationsposition eines Magneten, insbesondere innerhalb einer mechanischen Schaltmagneteinheit erfolgen. Alternativ dazu oder auch zusÃ¤tzlich kann die Spannkraft mit einem Elektromagneten eingestellt werden.According to a further advantageous embodiment, at least one switchable magnet unit can be provided as the magnetic field source, which causes a stronger magnetic field in the tensioned state than in the released state. As a result, the free-form workpiece or auxiliary element can be strongly magnetized in the clamping state and drawn against the workpiece clamping device to rest on the support surface. The clamping force with which the free-form workpiece or auxiliary element is clamped in the clamping state can be adjusted by the switchable magnet, whereby damage and / or unwanted deformation of the free-form workpiece can be prevented. The adjustment can take place, for example, by changing a rotational position of a magnet, in particular within a mechanical switching magnet unit. Alternatively or in addition, the clamping force can be adjusted with an electromagnet.

Beispielsweise kann die schaltbare Magneteinheit auch ein Elektromagnet sein, der durch Bestromung einer Spule betrieben werden kann. Die Verwendung eines Elektromagneten zum Steuern der MagnetfeldstÃ¤rke kann besonders vorteilhaft sein, da dadurch ein gradueller Anstieg der MagnetfeldstÃ¤rke mÃ¶glich ist und die Spannkraft, mit der das FreiformwerkstÃ¼ck gespannt wird, somit genau einstellbar ist. Die Spannkraft kann demnach je nach Anwendungsfall variiert werden, wodurch sich die FlexibilitÃ¤t der WerkstÃ¼ckspannvorrichtung weiter verbessert.For example, the switchable magnet unit can also be an electromagnet that can be operated by energizing a coil. The use of an electromagnet to control the magnetic field strength can be particularly advantageous, since this enables a gradual increase in the magnetic field strength and the clamping force with which the free-form workpiece is clamped can thus be precisely adjusted. The clamping force can therefore be varied depending on the application, which further improves the flexibility of the workpiece clamping device.

Eine einfachere Konstruktion kann beispielsweise mit einer schaltbaren Magneteinheit bzw. einem beweglichen Dauermagneten erreicht werden, der beim Spannzustand ein stÃ¤rkeres magnetisches Feld verursacht als im LÃ¶sezustand. Beispielsweise kann die WerkstÃ¼ckspannvorrichtung wenigstens zwei relativ zueinander bewegliche Dauermagneten aufweisen, bei denen die gleichen Pole im LÃ¶sezustand sich gegenÃ¼berliegend, vorzugsweise diametral zueinander angeordnet sind. Die Dauermagneten kÃ¶nnen durch das Umschalten in den Spannzustand derart bewegt werden, dass jeweils die gleichen Pole Ã¼berlappend angeordnet sind und somit einen grÃ¶Ãeren gemeinsamen Magneten mit einem stÃ¤rkeren, insbesondere Ã¤uÃeren, Magnetfeld ergeben.A simpler construction can be achieved, for example, with a switchable magnet unit or a movable permanent magnet, which causes a stronger magnetic field in the tensioned state than in the released state. For example, the workpiece clamping device can have at least two permanent magnets which can be moved relative to one another and in which the same poles are arranged opposite one another in the released state, preferably diametrically to one another. The permanent magnets can be moved by switching to the clamping state in such a way that the same poles are arranged overlapping and thus result in a larger common magnet with a stronger, in particular external, magnetic field.

Insbesondere kann eine Schaltmagneteinheit wenigstens drei aneinander gereihte Magnete aufweisen, wobei der mittlere Magnet rotierbar gehalten ist. Die Ã¤uÃeren Magnete kÃ¶nnen vorzugsweise sich Ã¼berlappende Pole aufweisen. Durch die Rotation des mittleren Magnets kÃ¶nnen seine Pole stÃ¤rker mit den Polen der Ã¤uÃeren Magneten Ã¼berlappen und somit das magnetische Feld verstÃ¤rken.In particular, a switching magnet unit can have at least three magnets arranged in a row, the middle magnet being held in a rotatable manner. The outer magnets can preferably have overlapping poles. The rotation of the central magnet allows its poles to overlap more strongly with the poles of the outer magnets and thus strengthen the magnetic field.

Zum Schalten zwischen LÃ¶sezustand und Spannzustand kann ein Antrieb, insbesondere ein Motorantrieb, vorgesehen sein, wodurch die Bedienung der WerkstÃ¼ckspannvorrichtung weiter vereinfacht werden kann. Das Spannen eines FreiformwerkstÃ¼cks kann somit auch leicht automatisiert werden, beispielsweise durch eine Zeitschaltung fÃ¼r den Antrieb. Der Antrieb kann in einer Ausgestaltung ein Elektroantrieb sein, der beim Spannzustand eine Magnetspule bestromt. Alternativ dazu oder auch zusÃ¤tzlich kann der Motorantrieb eine Welle aufweisen, die mit wenigstens einem Magneten rotationsstarr gekoppelt ist. In einer besonders vorteilhaften Ausgestaltung kann der Motorantrieb bei Bedarf vom Magneten entkoppelt werden. Dadurch kann beispielsweise je nach Anwendungsfall eine unterschiedliche Anzahl von Magneten mit der Welle gekoppelt werden, wodurch die StÃ¤rke des Magnetfeldes und somit die auf das FreiformwerkstÃ¼ck wirkende Spannkraft variiert werden kann. Als Antrieb kann beispielsweise eine FormgedÃ¤chtnislegierung oder Piezoaktor verwendet werden. Der Antrieb kann handhabbar sein und beispielsweise als Hebel, Drehgriff oder Knopf ausgebildet sein. Vorzugsweise ist durch den Antrieb ein gradueller Anstieg des Magnetfeldes mÃ¶glich, beispielsweise kann durch den Antrieb die Rotationsposition eines Dauermagneten verÃ¤ndert werden.A drive, in particular a motor drive, can be provided for switching between the released state and the clamping state, whereby the operation of the workpiece clamping device can be further simplified. The clamping of a free-form workpiece can therefore also be easily automated, for example by a timer for the drive. In one embodiment, the drive can be an electric drive, which energizes a magnetic coil when it is tensioned. As an alternative to this or in addition, the motor drive can have a shaft which is coupled to at least one magnet in a rotationally rigid manner. In a particularly advantageous embodiment, the motor drive can be decoupled from the magnet if necessary. As a result, for example, depending on the application, a different number of magnets can be coupled to the shaft, whereby the strength of the magnetic field and thus the clamping force acting on the freeform workpiece can be varied. A shape memory alloy or a piezo actuator, for example, can be used as the drive. The drive can be manageable and can be designed, for example, as a lever, rotary handle or button. A gradual increase in the magnetic field is preferably possible through the drive, for example the rotational position of a permanent magnet can be changed by the drive.

Um die Bedienung weiter zu vereinfachen, kann der Antrieb motorisiert sein. Der Antrieb kann vorzugsweise einen Schrittmotor aufweisen, der dadurch automatisch, beispielsweise mit einem Steuerungsinterface, gesteuert werden kann.To further simplify operation, the drive can be motorized. The drive can preferably have a stepper motor, which can thereby be controlled automatically, for example with a control interface.

Der Antrieb kann von der Magnetfeldquelle entkoppelt sein, beispielsweise kann der Antrieb eine externe Stromquelle sein, mit dem die Magnetfeldquelle ferngesteuert werden kann. Vorzugsweise jedoch kann der Antrieb und die Magnetfeldquelle in einem gemeinsamen GehÃ¤use zu einem Schaltmodul integriert sein. Dadurch ist die magnetische Funktion auf das Schaltmodul beschrÃ¤nkt und kann bei einem Fehler leicht repariert bzw. ausgewechselt werden. Das Schaltmodul kann durch den Zusammenbau von Antrieb und Magnetfeldquelle besonders kompakt und portabel sein.The drive can be decoupled from the magnetic field source, for example the drive can be an external power source with which the magnetic field source can be remotely controlled. Preferably, however, the drive and the magnetic field source can be integrated in a common housing to form a switching module. As a result, the magnetic function is limited to the switching module and can easily be repaired or replaced in the event of a fault. The switching module can be particularly compact and portable due to the assembly of drive and magnetic field source.

Der AuflagekÃ¶rper kann Teil eines Spannmoduls sein, das wiederholt lÃ¶sbar, beispielsweise durch eine Schraubverbindung, mit der Magnetfeldquelle, insbesondere dem Schaltmodul, verbunden ist. Somit kann ohne groÃe UmstÃ¤nde das Spannmodul und folglich der AuflagekÃ¶rper unabhÃ¤ngig von der Magnetfeldquelle ausgetauscht werden. Dadurch kann je nach Form und GrÃ¶Ãe des FreiformwerkstÃ¼cks ein komplementÃ¤r dazu ausgestaltetes Spannmodul verwendet werden. The support body can be part of a tensioning module that is repeatedly detachably connected to the magnetic field source, in particular the switching module, for example by a screw connection. In this way, the clamping module and consequently the support body can be exchanged independently of the magnetic field source without much ado. As a result, depending on the shape and size of the free-form workpiece, a clamping module configured to be complementary to it can be used.

Das Spannmodul kann beispielsweise als HÃ¼lse ausgeformt sein, die in verschiedenen Positionen relativ zur Magnetfeldquelle mit der Magnetfeldquelle, insbesondere dem Schaltmodul verbunden sein kann. Beispielsweise kann eine BajonettfÃ¼hrung vorgesehen sein, mit der das Spannmodul in verschiedenen Stufen am Schaltmodul angeordnet sein kann. Die FÃ¼hrung kann zumindest zwei Stufen aufweisen, in denen das Spannmodul arretiert werden kann. Vorzugsweise kann die FÃ¼hrung einseitig offen sein und somit vom Spannmodul abnehmbar ausgestaltet sein.The clamping module can for example be shaped as a sleeve which can be connected to the magnetic field source, in particular the switching module, in different positions relative to the magnetic field source. For example, a bayonet guide can be provided with which the clamping module can be arranged in different stages on the switching module. The guide can have at least two stages in which the clamping module can be locked. The guide can preferably be open on one side and thus be designed to be removable from the clamping module.

Der AuflagekÃ¶rper kann insbesondere individuell an das zu spannende FreiformwerkstÃ¼ck angepasst sein und kann durch 3D-Druck oder spanende Fertigung hergestellt sein. Dadurch ist eine einfache Produktion des AuflagekÃ¶rpers, insbesondere der AuflageflÃ¤che mÃ¶glich. Der AuflagekÃ¶rper kann das hÃ¼lsenfÃ¶rmige Spannmodul einseitig verschieÃen. Zur Aufnahme der Magnetfeldquelle zumindest im Spannzustand kann der AuflagekÃ¶rper eine an die Form der Magnetfeldquelle angepasste Einbuchtung auf der von der AuflageflÃ¤che abgewandten Seite aufweisen, in die sich die Magnetfeldquelle zumindest im Spannzustand anschmiegen kann.The support body can in particular be individually adapted to the free-form workpiece to be clamped and can be produced by 3D printing or machining. This enables simple production of the support body, in particular the support surface. The support body can close the sleeve-shaped clamping module on one side. To accommodate the magnetic field source at least in the clamped state, the support body can have an indentation adapted to the shape of the magnetic field source on the side facing away from the support surface, into which the magnetic field source can nestle at least in the clamped state.

Das Spannmodul kann dabei in der ersten Stufe derart angeordnet sein, dass sich die Magnetfeldquelle in der Einbuchtung befindet und in unmittelbarer NÃ¤he zur AuflageflÃ¤che angeordnet ist, sodass das Magnetfeld der Magnetfeldquelle auf das auf der AuflageflÃ¤che angeordnete FreiformwerkstÃ¼ck und/oder Hilfselement wirken kann. Im LÃ¶sezustand kann das Spannmodul in der zweiten Stufe angeordnet sein, in der die AuflageflÃ¤che von der Magnetfeldquelle beabstandet ist, sodass das von der Magnetfeldquelle verursachte Magnetfeld eine minimale Spannkraft auf das FreiformwerkstÃ¼ck und/oder Hilfselement ausÃ¼bt. Dadurch kann mit dieser vorteilhaften Ausgestaltung eine Schaltung zwischen LÃ¶sezustand und Spannzustand durch Ãnderung der relativen Position der AuflageflÃ¤che zur Magnetfeldquelle erzeugt werden.The clamping module can be arranged in the first stage in such a way that the magnetic field source is located in the indentation and is arranged in close proximity to the support surface so that the magnetic field of the magnetic field source can act on the freeform workpiece and / or auxiliary element arranged on the support surface. In the released state, the clamping module can be arranged in the second stage, in which the support surface is spaced from the magnetic field source, so that the magnetic field caused by the magnetic field source exerts a minimal clamping force on the free-form workpiece and / or auxiliary element. As a result, with this advantageous embodiment, a switch between the released state and the tensioned state can be generated by changing the position of the bearing surface relative to the magnetic field source.

Die Magnetfeldquelle kann hierbei bevorzugt austauschbar sein, sodass je nach Bedarf eine unterschiedlich starke Magnetfeldquelle eingesetzt werden kann.The magnetic field source can preferably be exchangeable so that a magnetic field source of different strengths can be used as required.

Die WerkstÃ¼ckspannvorrichtung kann beispielsweise eine Mehrzahl an unterschiedlichen Spannmodulen aufweisen, die jeweils wiederholt lÃ¶sbar mit der Magnetfeldquelle verbunden werden kÃ¶nnen.The workpiece clamping device can, for example, have a plurality of different clamping modules, each of which can be repeatedly detachably connected to the magnetic field source.

Alternativ dazu oder auch zusÃ¤tzlich kann der AuflagekÃ¶rper wiederholt lÃ¶sbar mit der Magnetfeldquelle verbunden sein. Insbesondere kann der AuflagekÃ¶rper wiederholt lÃ¶sbar im Spannmodul angeordnet sein. Beispielsweise kann das Spannmodul wenigstens ein Kopplungselement zum Koppeln des AuflagekÃ¶rpers mit der Magnetfeldquelle, insbesondere mit dem Schaltmodul, aufweisen. Das Kopplungselement kann mit einer Kupplung, vorzugsweise einer Schnellkupplung versehen sein, mit der der AuflagekÃ¶rper schnell und einfach mit dem Kopplungselement verbunden werden kann. Dadurch kann je nach Bedarf der AuflagekÃ¶rper ausgetauscht werden.As an alternative to this or in addition, the support body can be repeatedly detachably connected to the magnetic field source. In particular, the support body can be repeatedly detachably arranged in the clamping module. For example, the tensioning module can have at least one coupling element for coupling the support body to the magnetic field source, in particular to the switching module. The coupling element can be provided with a coupling, preferably a quick-release coupling, with which the support body can be connected to the coupling element quickly and easily. This allows the support body to be exchanged as required.

Die WerkstÃ¼ckspannvorrichtung kann vorzugsweise zumindest zwei wenigstens in Form und/oder GrÃ¶Ãe unterschiedliche AuflagekÃ¶rper aufweisen, die je nach Form und GrÃ¶Ãe des FreiformwerkstÃ¼cks eingesetzt werden kÃ¶nnen. Beispielsweise kann der AuflagekÃ¶rper auf einem Spannaufsatz geformt sein, der wiederholt lÃ¶sbar mit der Magnetfeldquelle, insbesondere dem Kopplungselement verbunden ist. Der Spannaufsatz kann mit der Kupplung schnell und einfach verbunden werden. Vorzugsweise kann die Orientierung, mit der der Spannaufsatz mit dem Kopplungselement verbunden ist, einstellbar sein. So kann beispielsweise das Kopplungselement eine schalenfÃ¶rmige Aufnahme aufweisen, in die der Spannaufsatz eingesetzt werden kann. Vorzugsweise kann der Spannaufsatz durch das Magnetfeld im Spannzustand mit dem Kopplungselement starr verbunden sein. FÃ¼r die WerkstÃ¼ckspannvorrichtung kÃ¶nnen zumindest zwei wenigstens in Form und GrÃ¶Ãe voneinander unterschiedliche SpannaufsÃ¤tze vorgesehen sein.The workpiece clamping device can preferably have at least two support bodies which are at least different in shape and / or size and which can be used depending on the shape and size of the free-form workpiece. For example, the support body can be formed on a clamping attachment which is repeatedly detachably connected to the magnetic field source, in particular the coupling element. The clamping attachment can be connected to the coupling quickly and easily. The orientation with which the clamping attachment is connected to the coupling element can preferably be adjustable. For example, the coupling element can have a shell-shaped receptacle into which the clamping attachment can be inserted. Preferably, the clamping attachment can be rigidly connected to the coupling element by the magnetic field in the clamping state. For the workpiece clamping device, at least two clamping attachments that differ from one another at least in terms of shape and size can be provided.

Um das LÃ¶sen des magnetisierbaren FreiformwerkstÃ¼ckes von der AuflageflÃ¤che im LÃ¶sezustand weiter zu vereinfachen, ist es besonders vorteilhaft, wenn die WerkstÃ¼ckspannvorrichtung im LÃ¶sezustand im Wesentlichen nicht magnetisch ist. Mit im Wesentlichen nicht magnetisch ist hierbei gemeint, dass das Magnetfeld im LÃ¶sezustand eine so geringe magnetische Anziehungskraft auf das FreiformwerkstÃ¼ck und/oder das wenigstens eine Hilfselement ausÃ¼bt, sodass es einfach und ohne hohen zusÃ¤tzlichen Kraftaufwand mÃ¶glich ist, das FreiformwerkstÃ¼ck zu lÃ¶sen.In order to further simplify the release of the magnetizable free-form workpiece from the support surface in the released state, it is particularly advantageous if the workpiece clamping device is essentially non-magnetic in the released state. Essentially non-magnetic here means that the magnetic field in the released state exerts such a low magnetic force of attraction on the free-form workpiece and / or the at least one auxiliary element that it is possible to release the free-form workpiece easily and without a great deal of additional force.

GemÃ¤Ã einer weiteren vorteilhaften Ausgestaltung kann die AuflageflÃ¤che zumindest Abschnittsweise von einem nicht magnetischen, insbesondere nicht ferromagnetischen, Material geformt sein, beispielsweise Aluminium oder einer Aluminiumlegierung. Das nicht ferromagnetische Material ist insbesondere im LÃ¶sezustand remanenzfrei, wodurch es keine Restmagnetisiserung aufweist, die auf das FreiformwerkstÃ¼ck und/oder das Hilfselement wirken kann. Dadurch kann das FreiformwerkstÃ¼ck im LÃ¶sezustand besonders leicht von der AuflageflÃ¤che entfernt werden, da von dem nicht ferromagnetischen Material keine direkte magnetische Anziehungskraft auf das FreiformwerkstÃ¼ck und/oder das Hilfselement ausgeÃ¼bt wird.According to a further advantageous embodiment, the support surface can be formed at least in sections from a non-magnetic, in particular non-ferromagnetic, material be, for example aluminum or an aluminum alloy. The non-ferromagnetic material is remanent-free, in particular in the released state, as a result of which it does not have any residual magnetization that can act on the free-form workpiece and / or the auxiliary element. As a result, the free-form workpiece can be removed particularly easily from the support surface in the released state, since the non-ferromagnetic material does not exert a direct magnetic force of attraction on the free-form workpiece and / or the auxiliary element.

Beispielsweise kann die AuflageflÃ¤che komplett aus einem nicht magnetischen, insbesondere nicht ferromagnetischen, Material geformt sein. In diesem Fall kann die Magnetfeldquelle zum Beispiel ein Elektromagnet sein, wobei die AuflageflÃ¤che zwischen FreiformflÃ¤che und Magnetfeldquelle angeordnet sein kann.For example, the support surface can be formed completely from a non-magnetic, in particular non-ferromagnetic, material. In this case, the magnetic field source can be an electromagnet, for example, wherein the bearing surface can be arranged between the free-form surface and the magnetic field source.

In einer weiteren vorteilhaften Ausgestaltung kann die WerkstÃ¼ckspannvorrichtung zwei von einem nicht ferromagnetischen Abschnitt voneinander getrennte Polschuhe aufweisen. Die Polschuhe kÃ¶nnen zumindest im Spannzustand entgegengesetzt polarisiert sein, sodass die beiden Polschuhe sich in einem Magnetkreis befinden. Vorzugsweise kann zwischen den Polschuhen die Magnetfeldquelle angeordnet sein, die zumindest im Spannzustand die Polschuhe stÃ¤rker magnetisiert als im LÃ¶sezustand. Die Polschuhe kÃ¶nnen insbesondere aus einem ferromagnetischen Material geformt sein, beispielsweise aus Eisen, damit diese durch Schalten in den Spannzustand stÃ¤rker magnetisiert werden kÃ¶nnen. Die Polschuhe kÃ¶nnen zusammen mit dem nicht ferromagnetischen Abschnitt das Kopplungselement bilden. In diesem Fall kann das Kopplungselement als eine PolergÃ¤nzung wirken, die das von der Magnetfeldquelle erzeugte Magnetfeld vergrÃ¶Ãert.In a further advantageous embodiment, the workpiece clamping device can have two pole shoes separated from one another by a non-ferromagnetic section. The pole pieces can be polarized in opposite directions, at least in the tensioned state, so that the two pole pieces are in a magnetic circuit. Preferably, the magnetic field source can be arranged between the pole pieces, which at least in the tensioned state magnetizes the pole pieces more strongly than in the released state. The pole shoes can in particular be formed from a ferromagnetic material, for example iron, so that they can be more strongly magnetized by switching to the tensioned state. The pole shoes can form the coupling element together with the non-ferromagnetic section. In this case, the coupling element can act as a pole complement, which increases the magnetic field generated by the magnetic field source.

Die Polschuhe und der nicht ferromagnetische Abschnitt kÃ¶nnen jeweils ein Segment des AuflagekÃ¶rpers aufweisen, sodass beim Zusammensetzen der Polschuhe und des nicht ferromagnetischen Abschnittes der stetige AuflagekÃ¶rper geformt wird. Die jeweiligen Segmente und die Polschuhe bzw. der nicht ferromagnetische Abschnitt kÃ¶nnen vorzugsweise einstÃ¼ckig als monolithische Komponenten geformt sein.The pole shoes and the non-ferromagnetic section can each have a segment of the support body so that the continuous support body is formed when the pole shoes and the non-ferromagnetic section are assembled. The respective segments and the pole shoes or the non-ferromagnetic section can preferably be formed in one piece as monolithic components.

Um eine besonders verschleiÃfeste Ausgestaltung der WerkstÃ¼ckspannvorrichtung zu erhalten, kÃ¶nnen die Polschuhe und der nicht ferromagnetische Abschnitt bÃ¼ndig zueinander angeordnet sein. Dadurch kÃ¶nnen scharfe ÃbergÃ¤nge verhindert werden, die beispielsweise beim Entlanggleiten zu einem verstÃ¤rkten Abrieb des FreiformwerkstÃ¼ckes fÃ¼hren kÃ¶nnen.In order to obtain a particularly wear-resistant design of the workpiece clamping device, the pole shoes and the non-ferromagnetic section can be arranged flush with one another. As a result, sharp transitions can be prevented, which, for example, can lead to increased abrasion of the freeform workpiece when sliding along.

FÃ¼r einen mÃ¶glichst einfachen Aufbau der WerkstÃ¼ckspannvorrichtung und Auslegung des magnetischen Feldes kÃ¶nnen die Polschuhe symmetrisch, insbesondere spiegelsymmetrisch, zueinander angeordnet sein.For the simplest possible construction of the workpiece clamping device and design of the magnetic field, the pole shoes can be arranged symmetrically, in particular mirror-symmetrically, to one another.

GemÃ¤Ã einer bevorzugten Ausgestaltung kann die AuflageflÃ¤che von den Polschuhen und dem nicht ferromagnetischen Abschnitt gebildet sein. Dadurch kann Ã¼ber die Polschuhe ein stÃ¤rkerer Magnetkreis erzeugt werden, der von dem FreiformwerkstÃ¼ck und/oder dem Hilfselement geschlossen wird. Der direkte Kontakt mit den Polschuhen kann zu einer besonders stabilen Spannung des FreiformwerkstÃ¼ckes und/oder des Hilfselements fÃ¼hren. Da die Polschuhe jedoch von dem nicht ferromagnetischen Abschnitt getrennt sind in dieser Ausgestaltung, die zusammen mit den Polschuhen die AuflageflÃ¤che bildet, ist das Magnetfeld bestrebt, sich Ã¼ber das FreiformwerkstÃ¼ck und/oder dem Hilfselement, anstatt direkt zwischen den Polschuhen auszugleichen.According to a preferred embodiment, the bearing surface can be formed by the pole pieces and the non-ferromagnetic section. As a result, a stronger magnetic circuit can be generated via the pole shoes, which is closed by the free-form workpiece and / or the auxiliary element. The direct contact with the pole pieces can lead to a particularly stable tension of the free-form workpiece and / or the auxiliary element. However, since the pole pieces are separated from the non-ferromagnetic section in this embodiment, which forms the bearing surface together with the pole pieces, the magnetic field tries to balance itself over the free-form workpiece and / or the auxiliary element instead of directly between the pole pieces.

GemÃ¤Ã einer weiteren vorteilhaften Ausgestaltung kann sich der Auflagepunkt vorzugsweise im nicht ferromagnetischen Abschnitt befinden. Dadurch kann ein direkter Kontakt zwischen FreiformwerkstÃ¼ck und magnetisiertem Polschuh verhindert werden. Insbesondere im LÃ¶sezustand kann das FreiformwerkstÃ¼ck einfach gelÃ¶st werden, da der nicht ferromagnetische Abschnitt remanenzfrei ist.According to a further advantageous embodiment, the support point can preferably be located in the non-ferromagnetic section. This prevents direct contact between the freeform workpiece and the magnetized pole piece. In particular in the released state, the free-form workpiece can be released easily, since the non-ferromagnetic section is remanent-free.

Der nicht ferromagnetische Abschnitt kann vorzugsweise den Scheitel der sich verjÃ¼ngenden AuflageflÃ¤che bilden. Mit Scheitel ist hierbei ein lokales Maximum der Kontur der AuflageflÃ¤che gemeint, das weiter hinausragt als die benachbarten Abschnitte der Polschuhe. Wenn die AuflageflÃ¤che beispielsweise eine Hyperbel oder Ellipsenform aufweist, kann der Scheitel als Punkt mit der maximalen KrÃ¼mmung definiert werden. Dadurch kann weiter verhindert werden, dass das Magnetfeld sich direkt zwischen den Polschuhen ausgleicht, sondern Ã¼ber das gespannte FreiformwerkstÃ¼ck, wodurch die Spannkraft der WerkstÃ¼ckspannvorrichtung weiter verstÃ¤rkt und einfacher ausgelegt werden kann. Der nicht ferromagnetische Abschnitt kann insbesondere bei gespanntem FreiformwerkstÃ¼ck von den MagnetleitkÃ¶rpern zum Leiten des magnetischen Feldes umgeben sein. Die MagnetleitkÃ¶rper kÃ¶nnen zumindest im Spannzustand einen geschlossenen Kreis formen.The non-ferromagnetic section can preferably form the apex of the tapered support surface. The apex here means a local maximum of the contour of the bearing surface that protrudes further than the adjacent sections of the pole shoes. For example, if the supporting surface has a hyperbola or elliptical shape, the vertex can be defined as a point with the maximum curvature. This can further prevent the magnetic field from being equalized directly between the pole pieces, but rather via the clamped free-form workpiece, as a result of which the clamping force of the workpiece clamping device can be further increased and designed more simply. The non-ferromagnetic section can be surrounded by the magnetic guide bodies for guiding the magnetic field, in particular when the free-form workpiece is clamped. The magnetically conductive bodies can form a closed circle, at least in the tensioned state.

Der nicht ferromagnetische Abschnitt kann bevorzugt als Scheibe eines Kugelsegmentes oder Kugel geformt sein. Insbesondere kann die Kugelsegmentscheibe eine Schnittebene von dem Kugelsegment senkrecht zur Schnittebene des Kugelsegmentes von einer Kugel darstellen. The non-ferromagnetic section can preferably be shaped as a disk of a spherical segment or sphere. In particular, the spherical segment disk can represent a sectional plane of the spherical segment perpendicular to the sectional plane of the spherical segment of a sphere.

Das Kugelsegment kann die AuflageflÃ¤che bilden und kann insbesondere als Halbkugel geformt sein. Die Kugelsegmentscheibe kann vorzugsweise den Scheitel des Kugelsegmentes bilden, wobei die Kugelsegmentscheibe den von der Schnittebene des Kugelsegmentes von der Kugel am weitesten entfernten Punkt des Kugelsegmentes formt.The spherical segment can form the bearing surface and can in particular be shaped as a hemisphere be. The spherical segment disk can preferably form the apex of the spherical segment, the spherical segment disk forming the point of the spherical segment which is furthest away from the plane of intersection of the spherical segment.

Die Polschuhe kÃ¶nnen zumindest abschnittsweise als Segment eines Kugelsegmentes oder einer Kugel geformt sein. Insbesondere kÃ¶nnen die Segmente eine Schnittebene vom Kugelsegment im Wesentlichen senkrecht zur Schnittebene des Kugelsegmentes von der Kugel aufweisen. Die Segmente kÃ¶nnen durch die Scheibe voneinander getrennt sein und gemeinsam die Form des Kugelsegmentes ergeben. Die Segmente kÃ¶nnen vorzugsweise symmetrisch zueinander angeordnet sein.The pole shoes can be shaped at least in sections as a segment of a spherical segment or a sphere. In particular, the segments can have a sectional plane from the spherical segment essentially perpendicular to the sectional plane of the spherical segment from the sphere. The segments can be separated from one another by the disk and together result in the shape of the spherical segment. The segments can preferably be arranged symmetrically to one another.

In einer weiteren vorteilhaften Ausgestaltung kann die Spannkraft mit der das FreiformwerkstÃ¼ck gespannt wird messbar sein und durch eine VerÃ¤nderung des Magnetfeldes beinflusst werden. HierfÃ¼r kann die WerkstÃ¼ckspannvorrichtung einen Kraftaufnehmer zur Ermittlung des Betriebszustandes aufweisen. Insbesondere kann der Kraftaufnehmer derart ausgestaltet sein, die auf das FreiformwerkstÃ¼ck im Spannzustand ausgeÃ¼bte Spannkraft zu erfassen. Der Kraftaufnehmer kann beispielsweise einen FederkÃ¶rper aufweisen, der durch das auf das FreiformwerkstÃ¼ck im Spannzustand wirkende Magnetfeld elastisch verformt werden kann. Die Verformung des FederkÃ¶rpers kann zum Beispiel Ã¼ber Dehnungsmessstreifen, deren elektrischer Widerstand sich mit der Dehnung Ã¤ndert, gemessen werden und in eine elektrische Spannung umgewandelt werden und letztendlich in einen Kraftmesswert umgerechnet werden. Alternativ dazu kann die Verformung des FederkÃ¶rpers durch kapazitive Sensoren aufgenommen werden. Durch den Kraftaufnehmer kann die Spannkraft genau widergegeben werden und damit die Reproduzierbarkeit der Lage des FreiformwerkstÃ¼ckes im Spannzustand weiter verbessert werden.In a further advantageous embodiment, the clamping force with which the freeform workpiece is clamped can be measured and influenced by a change in the magnetic field. For this purpose, the workpiece clamping device can have a force transducer for determining the operating state. In particular, the force transducer can be designed in such a way that it detects the clamping force exerted on the free-form workpiece in the clamping state. The force transducer can, for example, have a spring body which can be elastically deformed by the magnetic field acting on the free-form workpiece in the clamping state. The deformation of the spring body can, for example, be measured using strain gauges, the electrical resistance of which changes with the extension, and converted into an electrical voltage and ultimately converted into a force measurement value. Alternatively, the deformation of the spring body can be recorded by capacitive sensors. The clamping force can be precisely reproduced by the force transducer and thus the reproducibility of the position of the free-form workpiece in the clamping state can be further improved.

GemÃ¤Ã einer weiteren vorteilhaften Ausgestaltung kann der Kraftaufnehmer eine elektrische Auswerteeinheit zum Erfassen des Betriebszustandes der WerkstÃ¼ckspannvorrichtung sein. Damit kann beispielsweise widergegeben werden, ob das FreiformwerkstÃ¼ck und/oder das Hilfselement Ã¼berhaupt auf der AuflageflÃ¤che aufliegt. Die Auswerteeinheit kann derart konstruiert sein, dass sie die zeitliche Ableitung der Spannung und/oder des Stroms einer Spule ausgibt. Durch den zeitlichen Verlauf dieser zeitlichen Ableitung kann der Betriebszustand genau widergegeben werden. Das FreiformwerkstÃ¼ck und/oder das Hilfselement wirkt dabei wie ein Anker und die AuflageflÃ¤che wie ein Joch. Die Bewegung des FreiformwerkstÃ¼ckes und/oder des Hilfselements zur AuflageflÃ¤che hin induziert eine Gegenspannung, wodurch der Spulenstrom absinkt. SchlÃ¤gt das FreiformwerkstÃ¼ck an der AuflageflÃ¤che an, stoppt die Bewegung und der Spulenstrom steigt wieder. Dieser Verlauf kann durch die elektrische Auswerteeinheit widergegeben werden.According to a further advantageous embodiment, the force transducer can be an electrical evaluation unit for detecting the operating state of the workpiece clamping device. In this way it can be shown, for example, whether the free-form workpiece and / or the auxiliary element is actually resting on the support surface. The evaluation unit can be constructed in such a way that it outputs the time derivative of the voltage and / or the current of a coil. The operating state can be accurately reproduced through the temporal course of this temporal derivation. The free-form workpiece and / or the auxiliary element acts like an anchor and the support surface acts like a yoke. The movement of the free-form workpiece and / or the auxiliary element towards the support surface induces a counter-voltage, as a result of which the coil current drops. If the freeform workpiece hits the support surface, the movement stops and the coil current increases again. This course can be reproduced by the electrical evaluation unit.

Vorzugsweise kann die WerkstÃ¼ckspannvorrichtung einen Signalgeber aufweisen, der die vom Kraftaufnehmer gemessene auf das FreiformwerkstÃ¼ck wirkende Spannkraft, beispielsweise durch eine LED Anzeige, an den widergibt.The workpiece clamping device can preferably have a signal transmitter, which reproduces the clamping force acting on the freeform workpiece, for example by means of an LED display, on the force transducer.

FÃ¼r eine vereinfachte Bedienung und zum Vermeiden einer BeschÃ¤digung des zu spannenden FreiformwerkstÃ¼cks kann die WerkstÃ¼ckspannvorrichtung mit einer Regelung der auf das FreiformwerkstÃ¼ck wirkenden Spannkraft anhand des vom Kraftaufnehmer erfassten Messwertes versehen sein. Die Regelung kann insbesondere den Antrieb steuern, sodass die vom Kraftaufnehmer erfasste, auf das FreiformwerkstÃ¼ck wirkende Spannkraft auf einen vorgegebenen Referenzwert gefahren wird.For simplified operation and to avoid damage to the freeform workpiece to be clamped, the workpiece clamping device can be provided with a control of the clamping force acting on the freeform workpiece based on the measured value recorded by the force transducer. The regulation can in particular control the drive so that the clamping force, which is detected by the force transducer and acting on the freeform workpiece, is driven to a predetermined reference value.

Wenigstens ein Magnet zum Einstellen des Magnetfeldes kann austauschbar in der WerkstÃ¼ckspannvorrichtung gehalten werden. Dadurch kÃ¶nnen unterschiedlich starke Magneten bei unterschiedlichen Anwendungen eingesetzt werden, wodurch sich die FlexibilitÃ¤t der WerkstÃ¼ckspannvorrichtung weiter verbessert.At least one magnet for setting the magnetic field can be held interchangeably in the workpiece clamping device. As a result, magnets of different strengths can be used in different applications, which further improves the flexibility of the workpiece clamping device.

Im Folgenden ist die Erfindung anhand von AusfÃ¼hrungsbeispielen mit Bezug auf die beigefÃ¼gten Figuren exemplarisch nÃ¤her beschrieben. In den Figuren sind Elemente, die einander hinsichtlich Aufbau und/oder Funktion entsprechen, mit denselben Bezugszeichen versehen.In the following, the invention is described in greater detail using exemplary embodiments with reference to the accompanying figures. In the figures, elements that correspond to one another in terms of structure and / or function are provided with the same reference symbols.

Die bei den einzelnen AusfÃ¼hrungsbeispielen gezeigten und beschriebenen Merkmalskombinationen dienen lediglich zur ErlÃ¤uterung. Nach MaÃgabe der obigen AusfÃ¼hrungen kann auf ein Merkmal eines AusfÃ¼hrungsbeispiels verzichtet werden, wenn es auf dessen technischen Effekt bei einer bestimmten Anwendung nicht ankommt. Umgekehrt kann nach MaÃgabe der obigen AusfÃ¼hrungen bei einem AusfÃ¼hrungsbeispiel ein weiteres Merkmal hinzugefÃ¼gt werden, wenn dessen technischer Effekt fÃ¼r eine bestimmte Anwendung vorteilhaft oder notwendig sein sollte.The combinations of features shown and described in the individual exemplary embodiments serve only for explanation. In accordance with the above statements, a feature of an exemplary embodiment can be dispensed with if its technical effect is not important in a specific application. Conversely, in accordance with the above statements, a further feature can be added in an exemplary embodiment if its technical effect should be advantageous or necessary for a particular application.

Es zeigen:

1 eine schematische Perspektivansicht einer ersten beispielhaften Ausgestaltung einer erfindungsgemÃ¤Ãen WerkstÃ¼ckspannvorrichtung;

2 eine schematische Frontalansicht der in 1 dargestellten WerkstÃ¼ckspannvorrichtung;

3 eine schematische Perspektivansicht eines Spannmoduls der in 1 und 2 dargestellten WerkstÃ¼ckspannvorrichtung;

4 eine schematische Perspektivansicht einer zweiten beispielhaften Ausgestaltung einer erfindungsgemÃ¤Ãen WerkstÃ¼ckspannvorrichtung;

5 eine schematische Perspektivansicht einer dritten beispielhaften Ausgestaltung einer erfindungsgemÃ¤Ãen WerkstÃ¼ckspannvorrichtung; und

6 eine schematische Perspektivansicht einer vierten beispielhaften Ausgestaltung einer erfindungsgemÃ¤Ãen WerkstÃ¼ckspannvorrichtung.

Show it:

1 a schematic perspective view of a first exemplary embodiment of a workpiece clamping device according to the invention;

2 a schematic front view of the in 1 workpiece clamping device shown;

3 a schematic perspective view of a clamping module of FIG 1 and 2 workpiece clamping device shown;

4th a schematic perspective view of a second exemplary embodiment of a workpiece clamping device according to the invention;

5 a schematic perspective view of a third exemplary embodiment of a workpiece clamping device according to the invention; and

6th a schematic perspective view of a fourth exemplary embodiment of a workpiece clamping device according to the invention.

ZunÃ¤chst wird eine erste beispielhafte Ausgestaltung einer erfindungsgemÃ¤Ãen magnetischen WerkstÃ¼ckspannvorrichtung 1 anhand der 1 und 2 nÃ¤her erlÃ¤utert.First, a first exemplary embodiment of a magnetic workpiece clamping device according to the invention is presented 1 based on 1 and 2 explained in more detail.

Die magnetische WerkstÃ¼ckspannvorrichtung 1 umfasst einen AuflagekÃ¶rper 2 mit einer stetigen AuflageflÃ¤che 4 zur Anlage eines FreiformwerkstÃ¼cks 6, welches schematisch in 1 und 2 dargestellt ist. Weiterhin umfasst die WerkstÃ¼ckspannvorrichtung 1 eine Magnetfeldquelle 3 zur Erzeugung eines Magnetfeldes. Die WerkstÃ¼ckspannvorrichtung 1 kann von einem Spannzustand 8 zur Fixierung des FreiformwerkstÃ¼cks 6 in einen LÃ¶sezustand 10 zum LÃ¶sen des FreiformwerkstÃ¼cks 6 von der AuflageflÃ¤che 4 umschaltbar ausgestaltet sein. Dabei unterscheidet sich das von der Magnetfeldquelle 3 erzeugte Magnetfeld im Spannzustand 8 vom Magnetfeld im LÃ¶sezustand 10. Vorzugsweise, ist das Magnetfeld im Spannzustand 8 grÃ¶Ãer als im LÃ¶sezustand 10. Das FreiformwerkstÃ¼ck 6 kann mit einem zum Spannen des FreiformwerkstÃ¼cks 6 vorgesehenen Spannpunkt 7 auf der stetigen AuflageflÃ¤che 4 aufliegen. Durch die Stetigkeit der AuflageflÃ¤che 4 wird eine durchgehende, sich ohne Unterbrechung fortsetzende AuflageflÃ¤che 4 geschaffen, wodurch sich ein hoher Spielraum fÃ¼r die Positionierung des Spannpunktes 7 ergibt.The magnetic workpiece clamping device 1 comprises a support body 2 with a constant contact surface 4th for creating a freeform workpiece 6th , which is shown schematically in 1 and 2 is shown. Furthermore, the workpiece clamping device comprises 1 a magnetic field source 3 to generate a magnetic field. The workpiece clamping device 1 may be of a tension state 8th to fix the freeform workpiece 6th in a release state 10 for loosening the free-form workpiece 6th from the support surface 4th be designed to be switchable. This differs from the magnetic field source 3 generated magnetic field in the clamping state 8th from the magnetic field in the dissolved state 10 . Preferably, the magnetic field is in the tensioned state 8th greater than in the dissolved state 10 . The free-form workpiece 6th can with one for clamping the freeform workpiece 6th provided clamping point 7th on the steady contact surface 4th rest. Due to the continuity of the contact surface 4th becomes a continuous support surface that continues without interruption 4th created, which creates a lot of leeway for the positioning of the clamping point 7th results.

Das FreiformwerkstÃ¼ck 6 kann magnetisierbar sein und beispielsweise aus einem ferromagnetischem Material geformt sein, wie Eisen oder einer Eisenlegierung. Im Bereich des Karosseriebaus kann das FreiformwerkstÃ¼ck 6 ein Metallblech sein, welches beispielsweise zur Geometriemessung festgespannt wird. Alternativ dazu kann das FreiformwerkstÃ¼ck 6 auch nicht magnetisierbar sein. Hierbei kann ein Hilfselement 9, beispielsweise ein magnetischer und/oder eisenhaltiger KÃ¶rper 11, vorgesehen sein, wobei das Hilfselement 9, derart ausgestaltet ist, dass das FreiformwerkstÃ¼ck 6 zwischen AuflageflÃ¤che 4 und Hilfselement 9 angeordnet ist. Im Spannzustand 8 kann das Hilfselement 9 in Richtung zur AuflageflÃ¤che 4 angezogen werden und das FreiformwerkstÃ¼ck 6 somit zwischen Hilfselement 9 und AuflageflÃ¤che 4 einklemmen.The free-form workpiece 6th can be magnetizable and formed, for example, from a ferromagnetic material such as iron or an iron alloy. In the area of the body shop, the free-form workpiece 6th be a metal sheet, which is clamped for example for geometry measurement. Alternatively, the free-form workpiece 6th also not be magnetizable. Here an auxiliary element 9 , for example a magnetic and / or ferrous body 11 , be provided, the auxiliary element 9 , is designed such that the freeform workpiece 6th between support surface 4th and auxiliary element 9 is arranged. In the tensioned state 8th can the auxiliary element 9 in the direction of the support surface 4th are tightened and the freeform workpiece 6th thus between auxiliary element 9 and support surface 4th pinch.

Durch das Schalten zwischen Spann- und LÃ¶sezustand 8, 10 kann eine gewÃ¼nschte Spannkraft beim Spannzustand 8 eingestellt werden und beim LÃ¶sezustand 10 die Spannkraft minimal sein. Dadurch ist es mÃ¶glich, ohne hohen Kraftaufwand das FreiformwerkstÃ¼ck 6 von der AuflageflÃ¤che 4 zu lÃ¶sen.By switching between the clamping and release states 8th , 10 can achieve a desired clamping force in the clamping state 8th be set and in the release state 10 the tension must be minimal. This makes it possible to remove the free-form workpiece without a great deal of force 6th from the support surface 4th to solve.

Vorzugsweise kann die Spannkraft, mit der das FreiformwerkstÃ¼ck 6 im Spannzustand 8 gespannt wird, individuell fÃ¼r verschiedene FreiformwerkstÃ¼cke 6 einstellbar sein, sodass eine Verspannung des FreiformwerkstÃ¼cks 6 vermieden werden kann. Die Verspannung kann zu einem Wegspringen des FreiformwerkstÃ¼cks 6 beim Umschalten von dem Spannzustand 8 in den LÃ¶sezustand 10 fÃ¼hren. Dies kann zu einer Diskrepanz zwischen einem tatsÃ¤chlichen Spannpunkt und dem zum Spannen vorgesehenen Spannpunkt 7 fÃ¼hren, wodurch eine VerfÃ¤lschung einer Geometriemessung entstehen kann.The clamping force with which the freeform workpiece 6th in the tensioned state 8th is clamped, individually for different freeform workpieces 6th be adjustable, so that a bracing of the freeform workpiece 6th can be avoided. The tension can cause the freeform workpiece to jump away 6th when switching from the clamping state 8th in the release state 10 to lead. This can lead to a discrepancy between an actual clamping point and the clamping point intended for clamping 7th lead, which can lead to a falsification of a geometry measurement.

Zumindest ein Magnet 12 kann als Magnetfeldquelle 3 vorgesehen sein zum Induzieren des Magnetfelds 14. Der Magnet 12 ist vorzugsweise schaltbar. Beispielsweise kann der Magnet 12 ein Dauermagnet 16 mit einem Nordpol N und einem gegenÃ¼berliegenden SÃ¼dpol S sein. Der Dauermagnet 16 kann beispielsweise zusammen mit zumindest einem weiteren Dauermagneten (nicht gezeigt) in einem GehÃ¤use 20 angeordnet sein und ein Schaltmodul 21 bilden. Das GehÃ¤use 20 kann hierfÃ¼r eine Kammer 28 aufweisen, in der die Magnetfeldquelle 3, in dieser beispielhaften Ausgestaltung die zwei Dauermagneten 16, eingesetzt ist. Die Kammer 28 ist mit einer Ãffnung 30 versehen, durch die der Antrieb 22 in die Kammer 28 eingesetzt werden kann. Der Antrieb 22 kann zusammen mit der Magnetfeldquelle 3 in dem GehÃ¤use 20 zu dem Schaltmodul 21 integriert sein. Der Antrieb 22 kann handhabbar sein und ist in dieser beispielhaften Ausgestaltung als Drehgriff 23 ausgebildet. Das Schaltmodul 21 ist vorzugsweise mit Indikatoren 25 versehen, die mit der MagnetfeldstÃ¤rke korrespondieren und dem Benutzer somit die MÃ¶glichkeit geben, die Spannkraft genauer einzustellen. Die Indikatoren 25 sind ringfÃ¶rmig koaxial zum Drehgriff 23 angeordnet und sind durch kreisfÃ¶rmige Ãffnungen 27 gebildet. Der Drehgriff 23 ragt aus der Ãffnung 30 heraus und verschlieÃt die Ãffnung 30, und weist einen Zeiger 31 auf, der sich radial von der Ãffnung 30 Ã¼ber einen imaginÃ¤ren Ring, an dessen Umfang die Indikatoren 25 verteilt sind, hinweg erstreckt. Der Zeiger 31 kann mit einer Sperre versehen sein, die beispielsweise in eine der Ãffnungen 27 hineingreift und den Drehgriff in dieser Position arretiert, um ein versehentliches Umschalten des Zustands der WerkstÃ¼ckspannvorrichtung 1 zu verhindern.At least a magnet 12 can be used as a magnetic field source 3 be provided for inducing the magnetic field 14th . The magnet 12 is preferably switchable. For example, the magnet 12 a permanent magnet 16 with a north pole N and an opposite south pole S. The permanent magnet 16 can, for example, together with at least one further permanent magnet (not shown) in a housing 20th be arranged and a switching module 21st form. The case 20th can do this with a chamber 28 have in which the magnetic field source 3 , in this exemplary embodiment the two permanent magnets 16 , is used. The chamber 28 is with an opening 30th provided through which the drive 22nd into the chamber 28 can be used. The drive 22nd can work together with the magnetic field source 3 in the case 20th to the switching module 21st be integrated. The drive 22nd can be manageable and in this exemplary embodiment is a twist grip 23 educated. The switching module 21st is preferably with indicators 25th provided, which correspond to the magnetic field strength and thus give the user the opportunity to adjust the clamping force more precisely. The indicators 25th are ring-shaped coaxial to the rotary handle 23 arranged and are through circular openings 27 educated. The twist grip 23 protrudes from the opening 30th out and seal the opening 30th , and assigns a pointer 31 on that extends radially from the opening 30th over an imaginary ring, on the circumference of which the indicators 25th are distributed, extends away. The pointer 31 can be provided with a lock, for example in one of the openings 27 reaches into it and locks the rotary handle in this position to prevent accidental switching of the status of the workpiece clamping device 1 to prevent.

Die Magnetfeldquelle 3 ist in 2 zu sehen. In der 2 ist der Drehgriff 23 entfernt, um einen Blick auf den in die in der Kammer 28 angeordnete Magnetfeldquelle 3 zu erlauben. Die Magnetfeldquelle ist von zwei Dauermagneten 16 gebildet, die relativ zueinander rotierbar angeordnet sind, wobei im Spannzustand 8 die Nordpole N und SÃ¼dpole S der Dauermagneten 16 sich stÃ¤rker Ã¼berlappen und einen grÃ¶Ãeren gemeinsamen Nordpol N und SÃ¼dpol S ergeben. Wie zu sehen ist, gibt es verschiedene SpannzustÃ¤nde 8, die erreicht werden kÃ¶nnen, wobei die Ãberlappung der entsprechenden Pole bei zunehmendem Rang des Spannzustandes 8 zunimmt. Bei dem maximalen Spannzustand, bei dem die maximale MagnetfeldstÃ¤rke erreicht wird, kÃ¶nnen die gleich polarisierten Pole der Dauermagneten 16 komplett Ã¼berlappen.The magnetic field source 3 is in 2 to see. In the 2 is the twist grip 23 away to a Look at the one in the chamber 28 arranged magnetic field source 3 to allow. The magnetic field source is from two permanent magnets 16 formed, which are arranged rotatably relative to one another, wherein in the tensioned state 8th the north poles N and south poles S of the permanent magnets 16 overlap more strongly and result in a larger common north pole N and south pole S. As can be seen, there are different tension states 8th that can be achieved, with the overlap of the corresponding poles with increasing rank of the tension state 8th increases. At the maximum clamping state, in which the maximum magnetic field strength is reached, the poles of the permanent magnets with the same polarization can 16 completely overlap.

Folglich kann im Spannzustand 8 ein stÃ¤rkeres Magnetfeld 14 erzeugt werden als im LÃ¶sezustand. Die relative Rotation zwischen den Dauermagneten 16 kann beispielsweise dadurch erreicht werden, indem ein Dauermagnet 16 mit dem Antrieb 22, wie zum Beispiel eine rotierbare Welle 24, gekoppelt ist.Consequently, in the tensioned state 8th a stronger magnetic field 14th than in the dissolved state. The relative rotation between the permanent magnets 16 can for example be achieved by using a permanent magnet 16 with the drive 22nd , such as a rotatable shaft 24 , is coupled.

Der AuflagekÃ¶rper 2 ist in dieser beispielhaften Ausgestaltung von zwei zueinander spiegelsymmetrisch angeordneten Polschuhen 30 und einem nicht ferromagnetischen Abschnitt 32, der aus einem nicht ferromagnetischen Material 34, beispielsweise Aluminium, geformt ist und die beiden Polschuhe 30 voneinander trennt, gebildet. Dabei bildet der ferromagnetische Abschnitt 32 eine Symmetrieebene, an der die Polschuhe 30 symmetrisch zueinander angeordnet sind. Der AuflagekÃ¶rper 2 ist Teil eines wiederholt vom Schaltmodul 21 lÃ¶sbaren Spannmoduls 33. Das Spannmodul 33 umfasst neben dem AuflagekÃ¶rper 2 ein Kopplungselement 35, mit dem das Spannmodul 33 mit dem Schaltmodul 33 gekoppelt werden kann. FÃ¼r die WerkstÃ¼ckvorrichtung 1 kÃ¶nnen wenigstens zwei sich in zumindest Form und/oder GrÃ¶Ãe unterscheidende Spannmodule 33 vorgesehen sein, die je nach Bedarf mit dem Schaltmodul 21 gekoppelt werden kÃ¶nnen.The support body 2 is in this exemplary embodiment of two pole pieces arranged mirror-symmetrically to one another 30th and a non-ferromagnetic section 32 made of a non-ferromagnetic material 34 , for example aluminum, is formed and the two pole pieces 30th separates from each other, formed. The ferromagnetic section forms 32 a plane of symmetry on which the pole pieces 30th are arranged symmetrically to each other. The support body 2 is part of a repeat of the switch module 21st detachable clamping module 33 . The clamping module 33 includes in addition to the support body 2 a coupling element 35 with which the clamping module 33 with the switching module 33 can be coupled. For the workpiece fixture 1 at least two clamping modules that differ in at least shape and / or size 33 be provided, depending on your needs with the switching module 21st can be coupled.

Das Spannmodul 33 der in 1 und 2 dargestellten Ausgestaltung ist in 3 losgelÃ¶st von dem Schaltmodul 33 gezeigt. Das Kopplungselement 35 kann hierbei komplementÃ¤r zum AuflagekÃ¶rper 2 ausgebildet sein. Sprich das Kopplungselement 35 kann zwei magnetisierbare PolergÃ¤nzungen 37, die jeweils einen Fortsatz der Polschuhe 30 bilden, aufweisen, die von einem nicht ferromagnetischen StÃ¼ck 39 voneinander getrennt sind.The clamping module 33 the in 1 and 2 The configuration shown is in 3 detached from the switching module 33 shown. The coupling element 35 can be complementary to the support body 2 be trained. Say the coupling element 35 can have two magnetizable pole extensions 37 each having an extension of the pole pieces 30th form, having that of a non-ferromagnetic piece 39 are separated from each other.

Die PolergÃ¤nzungen 37 weisen jeweils eine L-Form auf, mit einer Basis 36 und einem von der Basis 36 im Wesentlichen senkrecht wegerstreckenden Arm 38. Die Basen 36 sind mit ihren von den Armen 38 entfernten StirnflÃ¤chen 40 zueinander gerichtet und schlagen an gegenÃ¼berliegenden FlÃ¤chen (nicht gezeigt) des ferromagnetischen StÃ¼cks 39 an. Zusammen ergeben die PolergÃ¤nzungen 37 mit dem nicht ferromagnetischen StÃ¼ck 39 einen im Wesentlichen U-fÃ¶rmigen Querschnitt, der das GehÃ¤use 20 zumindest abschnittsweise umgreifen kann.The pole supplements 37 each have an L-shape with a base 36 and one from the base 36 substantially perpendicular arm 38 . The bases 36 are with theirs from arms 38 distant end faces 40 facing each other and striking opposite surfaces (not shown) of the ferromagnetic piece 39 on. Together they add up to the pole 37 with the non-ferromagnetic piece 39 a substantially U-shaped cross-section showing the housing 20th can reach around at least in sections.

Die Arme 38 der PolergÃ¤nzungen 37 kÃ¶nnen mit ihren von den Basen 36 abgewandten FlÃ¤chen 40 auf einer Befestigungsebene 42 aufliegen. Die Polschuhe 30 mitsamt den PolergÃ¤nzungen 37 kÃ¶nnen aus einem magnetisierbaren, insbesondere ferromagnetischen Material geformt sein. Beim Umschalten in den Spannzustand 44 werden die Polschuhe 30 und entsprechenden PolergÃ¤nzungen 37 entgegengesetzt polarisiert. FÃ¼r den Fall, dass die Befestigungsebene 42 ebenfalls aus einem magnetisierbaren, insbesondere ferromagnetischen Material geformt ist, kann die Befestigungsebene 42 einen Magnetkreis schlieÃen und die WerkstÃ¼ckspannvorrichtung 1 somit magnetisch auf der Befestigungsebene 42 fixieren.The poor 38 of pole extensions 37 can with their from the bases 36 facing away surfaces 40 on a mounting level 42 rest. The pole shoes 30th including the pole extensions 37 can be formed from a magnetizable, in particular ferromagnetic material. When switching to the clamping state 44 become the pole pieces 30th and corresponding pole extensions 37 polarized in opposite directions. In the event that the mounting level 42 is also formed from a magnetizable, in particular ferromagnetic material, the mounting plane 42 close a magnetic circuit and the workpiece clamping device 1 thus magnetic on the mounting level 42 fix.

Die Polschuhe 30 und der nicht ferromagnetische Abschnitt 32 kÃ¶nnen vorzugsweise starr zusammengefÃ¼gt sein, beispielsweise kÃ¶nnen sie miteinander verklebt, vernietet, verschraubt oder verschweiÃt sein. Der Vorteil einer lÃ¶sbaren Verbindung, wie das Verschrauben, ist hierbei, dass bei VerschleiÃ eines einzelnen Teiles das einzelne Teil unabhÃ¤ngig vom Rest ausgetauscht werden kann.The pole shoes 30th and the non-ferromagnetic section 32 can preferably be rigidly joined together, for example they can be glued, riveted, screwed or welded together. The advantage of a detachable connection, such as screwing, is that if an individual part is worn, the individual part can be replaced independently of the rest.

In dieser beispielhaften Ausgestaltung ist der AuflagekÃ¶rper 2 mit aus der von der Befestigungsebene 42 abgewandten Seite 46 des Kopplungselements 35 hervorragenden Hervorhebungen 44 gebildet, die zusammen eine stetige AuflageflÃ¤che bilden. HierfÃ¼r sind die von den PolergÃ¤nzungen hervorragenden Polschuhe 30 als Segmente 54 einer Halbkugel gebildet, die zusammen mit dem aus dem nicht ferromagnetischen StÃ¼ck 39 hervorragenden, nicht ferromagnetischen Abschnitt 32 eine konvex gewÃ¶lbte Kalottenform 48 bilden.In this exemplary embodiment, the support body is 2 with from the from the mounting level 42 remote side 46 of the coupling element 35 excellent highlighting 44 formed, which together form a continuous support surface. The pole pieces, which are excellent from the pole supplements, are used for this 30th as segments 54 a hemisphere formed together with that from the non-ferromagnetic piece 39 excellent, non-ferromagnetic section 32 a convex dome shape 48 form.

Die AuflageflÃ¤che 4 lÃ¤uft somit auf einen Auflagepunkt 41 zu, der einen Scheitel 50, d.h. in diesem Fall den von der Befestigungsebene 42 am weitesten entfernten Punkt, bildet. Der Auflagepunkt 41 befindet sich vorzugsweise im nicht ferromagnetischen Abschnitt 32, wodurch ein einfaches LÃ¶sen des FreiformwerkstÃ¼cks 6 im LÃ¶sezustand 10 ermÃ¶glicht werden kann. The supporting surface 4th thus runs on a support point 41 too, the one parting 50 , ie in this case that of the mounting plane 42 at the most distant point. The support point 41 is preferably located in the non-ferromagnetic section 32 , which makes it easy to loosen the free-form workpiece 6th in the dissolved state 10 can be made possible.

Der nicht ferromagnetische Abschnitt 32 ist in der Regel remanenzfrei, sodass keine Restmagnetisierung im LÃ¶sezustand 10 auf das FreiformwerkstÃ¼ck 6 und/oder das Hilfselement 9 wirkt. Durch die sich verjÃ¼ngende AuflageflÃ¤che 4, insbesondere die Kalottenform der AuflageflÃ¤che 4, kann das FreiformwerkstÃ¼ck 6 punktfÃ¶rmig auf der AuflageflÃ¤che 4 aufliegen und sich Ã¼ber die Form des AuflagekÃ¶rpers 2 ausgleichen. Dadurch kann weiter gewÃ¤hrleistet werden, dass, unabhÃ¤ngig von der Form und dem Spannbereich des FreiformwerkstÃ¼cks 6, das FreiformwerkstÃ¼ck 6 mit der WerkstÃ¼ckspannvorrichtung 1 beschÃ¤digungsfrei gespannt werden kann.The non-ferromagnetic section 32 is usually remanence-free, so that no residual magnetization in the released state 10 on the freeform workpiece 6th and / or the auxiliary element 9 works. Due to the tapering support surface 4th , especially the dome shape of the support surface 4th , the freeform workpiece can 6th punctiform on the support surface 4th rest and look over the shape of the support body 2 balance. This can further ensure that, regardless of the shape and the clamping range of the free-form workpiece 6th , the free-form workpiece 6th with the workpiece clamping device 1 can be tensioned without damage.

Die Teile des AuflagekÃ¶rpers 2 kÃ¶nnen monolithisch mit den korrespondierenden Teilen des Kopplungselements 35 gebildet sein. Alternativ dazu kann der AuflagekÃ¶rper 2 wiederholt lÃ¶sbar mit dem Kopplungselement 35 verbunden sein. Beispielsweise kann das Kopplungselement 35 mit einer Schale versehen sein, in die der AuflagekÃ¶rper 2 eingesetzt werden kann. Der AuflagekÃ¶rper 2 kann dabei zum Beispiel durch das Magnetfeld zumindest im Spannzustand 8 starr in der Schale gehalten sein. Somit ist ein einfacher Austausch des AuflagekÃ¶rpers 2 mÃ¶glich, womit je nach Form und GrÃ¶Ãe des FreiformwerkstÃ¼cks 6 ein korrespondierender AuflagekÃ¶rper 2 eingesetzt werden kann.The parts of the support body 2 can be monolithic with the corresponding parts of the coupling element 35 be educated. Alternatively, the support body 2 repeatedly releasable with the coupling element 35 be connected. For example, the coupling element 35 be provided with a shell in which the support body 2 can be used. The support body 2 can, for example, through the magnetic field, at least in the tensioned state 8th be held rigidly in the shell. This makes it easy to replace the support body 2 possible, depending on the shape and size of the freeform workpiece 6th a corresponding support body 2 can be used.

Vorzugsweise ist das Spannmodul 33 mit dem Schaltmodul 21 starr und wiederholt lÃ¶sbar verbunden, beispielsweise durch eine Schraubverbindung. HierfÃ¼r weist das Kopplungselement 35 die Arme 38 durchsetzende, zueinander gerichtete DurchgangsÃ¶ffnungen 43 auf.The clamping module is preferably 33 with the switching module 21st rigidly and repeatedly releasably connected, for example by a screw connection. For this purpose, the coupling element 35 the poor 38 penetrating, mutually directed through openings 43 on.

Der Ãbergang zwischen den Polschuhen 30 und der Scheibe 52 ist vorzugsweise bÃ¼ndig, damit keine scharfen Kanten entstehen, die zu einer BeschÃ¤digung des FreiformwerkstÃ¼cks fÃ¼hren kÃ¶nnten.The transition between the pole pieces 30th and the disc 52 is preferably flush so that there are no sharp edges that could damage the freeform workpiece.

Wie in 2 zu sehen ist, liegt das FreiformwerkstÃ¼ck 6 im Spannzustand 8 punktfÃ¶rmig auf der AuflageflÃ¤che 4 auf. Ãber die polarisierten Polschuhe 30, mitsamt der PolergÃ¤nzungen 37, kann ein Magnetfeld 14 erzeugt werden, die das FreiformwerkstÃ¼ck 6 und/oder das Hilfselement 9 magnetisieren. Das FreiformwerkstÃ¼ck 6 und/oder Hilfselement 9 wird somit durch das Magnetfeld 14 angezogen und schlieÃt einen Magnetkreis. Dadurch kann das FreiformwerkstÃ¼ck 6 gespannt werden. Der nicht ferromagnetische Abschnitt 32 kann dabei verhindern, dass das Magnetfeld sich direkt zwischen den Polschuhen 30 ausgleicht und kann somit die Effizienz der WerkstÃ¼ckspannvorrichtung 1 erhÃ¶hen. Die Spannkraft, mit der das FreiformwerkstÃ¼ck 6 gespannt wird, kann somit genauer ausgelegt werden und ein Ãberspannen verhindert werden.As in 2 can be seen, the freeform workpiece lies 6th in the tensioned state 8th punctiform on the support surface 4th on. About the polarized pole pieces 30th , including the pole additions 37 , can be a magnetic field 14th are generated that the freeform workpiece 6th and / or the auxiliary element 9 magnetize. The free-form workpiece 6th and / or auxiliary element 9 is thus caused by the magnetic field 14th attracted and closes a magnetic circuit. This allows the freeform workpiece 6th be excited. The non-ferromagnetic section 32 can prevent the magnetic field from moving directly between the pole pieces 30th compensates and can thus increase the efficiency of the workpiece clamping device 1 increase. The clamping force with which the freeform workpiece 6th is tensioned, can thus be designed more precisely and over-tensioning can be prevented.

Im LÃ¶sezustand 10 sind die Polschuhe 30 nicht mehr, oder zumindest schwÃ¤cher, magnetisiert, sodass die Spannkraft nachlÃ¤sst und das FreiformwerkstÃ¼ck 6 ohne hohen Kraftaufwand von der AuflageflÃ¤che 4 gelÃ¶st werden kann.In the dissolved state 10 are the pole pieces 30th no longer, or at least weaker, magnetized, so that the clamping force decreases and the freeform workpiece 6th without great effort from the support surface 4th can be solved.

In 4 ist eine weitere vorteilhafte Ausgestaltung der erfindungsgemÃ¤Ãen WerkstÃ¼ckspannvorrichtung 1 gezeigt.In 4th is a further advantageous embodiment of the workpiece clamping device according to the invention 1 shown.

Die in 4 gezeigte AusfÃ¼hrungsform unterscheidet sich von der vorherigen AusfÃ¼hrungsform in ihrem Spannmodul 33.In the 4th The embodiment shown differs from the previous embodiment in its clamping module 33 .

Der AuflagekÃ¶rper 2 kann hierbei an einen Spannaufsatz 45 geformt sein, insbesondere die Spitze des Spannaufsatzes 45 bilden. Der Spannaufsatz 45 kann im Wesentlichen stiftfÃ¶rmig sein, mit einem lÃ¤nglichen GrundkÃ¶rper 47, dessen eines Ende 49 mit dem AuflagekÃ¶rper 2 versehen ist und dessen anderes Ende mit dem Kopplungselement 35 gekoppelt werden kann. HierfÃ¼r kann das Kopplungselement 35 eine Kupplung 51 aufweisen, insbesondere eine Schnellkupplung, in die der Spannaufsatz 45 eingesteckt werden kann. Die WerkstÃ¼ckspannvorrichtung 1 kann wenigstens zwei sich unterscheidende SpannaufsÃ¤tze 45 aufweisen, die sich wenigstens in Form und/oder GrÃ¶Ãe unterscheiden. Vorzugsweise kann der Spannaufsatz 45 im Spannzustand 8 von dem Magnetfeld starr am Kopplungselement 35 gehalten werden.The support body 2 can be attached to a clamping attachment 45 be shaped, especially the tip of the clamping attachment 45 form. The clamping attachment 45 can be essentially pin-shaped with an elongated body 47 , its one end 49 with the support body 2 is provided and the other end with the coupling element 35 can be coupled. The coupling element 35 a clutch 51 have, in particular a quick coupling, into which the clamping attachment 45 can be plugged in. The workpiece clamping device 1 can have at least two different clamping attachments 45 have that differ at least in shape and / or size. Preferably, the clamping attachment 45 in the tensioned state 8th from the magnetic field rigidly on the coupling element 35 being held.

Der AuflagekÃ¶rper 2 ist zylinderfÃ¶rmig angeordnet, wobei die AuflageflÃ¤che 4 konisch zulÃ¤uft. Der AuflagekÃ¶rper 2 kann hierbei zumindest im Spannzustand 8 einen magnetischen Pol 53 bilden, der beispielsweise das Hilfselement 9 als Gegenpol magnetisch anzieht. Alternativ dazu kann der AuflagekÃ¶rper 2 aus einem nicht ferromagnetischen Material geformt sein. In diesem Fall kann das Magnetfeld von den PolergÃ¤nzungen 37 auf das FreiformwerkstÃ¼ck 6 und/oder Hilfselement 9 wirken und magnetisch anziehen.The support body 2 is arranged in a cylindrical shape, with the bearing surface 4th tapers conically. The support body 2 can here at least in the tensioned state 8th a magnetic pole 53 form, for example, the auxiliary element 9 attracts magnetically as the opposite pole. Alternatively, the support body 2 be formed from a non-ferromagnetic material. In this case the magnetic field can come from the pole complements 37 on the freeform workpiece 6th and / or auxiliary element 9 act and attract magnetically.

Die Hervorhebungen 44 an den PolergÃ¤nzungen 37 und dem nicht ferromagnetischen StÃ¼ck 39 sind kreissegmentfÃ¶rmig und ergeben zusammen eine ringfÃ¶rmige Manschette 55, die die Kupplung 51 schÃ¼tzend umgibt.The highlights 44 at the pole extensions 37 and the non-ferromagnetic piece 39 are circular segment-shaped and together form an annular collar 55 who have favourited the clutch 51 protectively surrounds.

Nun ist mit Bezug auf 5 eine weitere vorteilhafte Ausgestaltung der erfindungsgemÃ¤Ãen WerkstÃ¼ckspannvorrichtung 1 gezeigt.Now is related to 5 a further advantageous embodiment of the workpiece clamping device according to the invention 1 shown.

In dieser Ausgestaltung ist der AuflagekÃ¶rper 2 einstÃ¼ckig gebildet und weist die stetige konvex gewÃ¶lbte AuflageflÃ¤che 4 auf. Der AuflagekÃ¶rper 2 ist mit einer Kammer 28 versehen, in die die Magnetfeldquelle 3, in diesem Fall der Magnet 12 eingesetzt ist, sodass die AuflageflÃ¤che 4 zwischen Magnet 12 und FreiformwerkstÃ¼ck 6 angeordnet ist. Der Magnet 12 kann beispielsweise ein schaltbarer Elektromagnet 60 sein, der durch eine Stromzufuhr ein Ã¤uÃeres Magnetfeld erzeugt bzw. verstÃ¤rkt. Dadurch kann die MagnetfeldstÃ¤rke in AbhÃ¤ngigkeit des zugefÃ¼hrten Stromes graduell eingestellt werden. Der Benutzer kann somit eine sehr hohe Genauigkeit bei der Einstellung der Spannkraft im Spannzustand 8 erhalten und eine Ãberspannung des FreiformwerkstÃ¼ckes 6 verhindern. Weiterhin kann die Reproduzierbarkeit der Blechlage weiter verbessert werden.In this embodiment, the support body is 2 Formed in one piece and has the continuous convex support surface 4th on. The support body 2 is with a chamber 28 provided in which the magnetic field source 3 , in this case the magnet 12 is inserted so that the support surface 4th between magnet 12 and freeform workpiece 6th is arranged. The magnet 12 can for example be a switchable electromagnet 60 be that generates or amplifies an external magnetic field by a power supply. This allows the magnetic field strength to be gradually adjusted as a function of the current supplied. The user can thus achieve a very high level of accuracy when setting the clamping force in the clamping state 8th received and an overvoltage of the Freeform workpiece 6th prevent. Furthermore, the reproducibility of the sheet metal layer can be further improved.

Der AuflagekÃ¶rper 2 ist mittels einer Flanschverbindung 62 mit einer Befestigungseinheit 64 zur mechanischen Befestigung der WerkstÃ¼ckspannvorrichtung 1 auf der Befestigungsebene 42 verbunden.The support body 2 is by means of a flange connection 62 with a fastening unit 64 for mechanical fastening of the workpiece clamping device 1 on the mounting level 42 connected.

Der AuflagekÃ¶rper 2 ist vorzugsweise aus einem nicht magnetischen, insbesondere nicht ferromagnetischen Material 34 geformt, beispielsweise Aluminium oder austenitischer Stahl. Dadurch kann das FreiformwerkstÃ¼ck 6 leichter von der AuflageflÃ¤che 4 gelÃ¶st werden im LÃ¶sezustand 10, da von der AuflageflÃ¤che 4 kein oder nur ein sehr schwaches magnetisches Feld erzeugt wird, welches das FreiformwerkstÃ¼ck 6 und/oder Hilfselement 9 anzieht. Dies ist besonders bei flexiblen FreiformwerkstÃ¼cken 6 vorteilhaft, da somit verhindert werden kann, dass das FreiformwerkstÃ¼ck 6 beim LÃ¶sen verbogen wird.The support body 2 is preferably made of a non-magnetic, in particular non-ferromagnetic material 34 shaped, for example aluminum or austenitic steel. This allows the freeform workpiece 6th easier from the support surface 4th be solved in the released state 10 because of the support surface 4th no or only a very weak magnetic field is generated, which the freeform workpiece 6th and / or auxiliary element 9 attracts. This is especially true for flexible freeform workpieces 6th advantageous, since this can prevent the free-form workpiece 6th is bent when loosening.

Weiterhin weist die WerkstÃ¼ckspannvorrichtung 1 einen Kraftaufnehmer 66 auf, der mit dem Magneten 12 verbunden ist, sich in Richtung von der AuflageflÃ¤che 4 weg erstreckt und mit einem zwischen AuflagekÃ¶rper 2 und Befestigungseinheit 64 angeordneten Flanschteil 68 verbunden ist. Alternativ dazu kann der Kraftaufnehmer 66 auch direkt an der Befestigungseinheit 64 montiert sein.Furthermore, the workpiece clamping device 1 a force transducer 66 on the one with the magnet 12 is connected in the direction of the support surface 4th extends away and with an intermediate support body 2 and fastening unit 64 arranged flange part 68 connected is. Alternatively, the force transducer 66 also directly on the fastening unit 64 be mounted.

Der Kraftaufnehmer 66 kann derart ausgestaltet sein, dass er die auf das magnetisierbare FreiformwerkstÃ¼ck 6 im Spannzustand 8 ausgeÃ¼bte Spannkraft erfasst. Der Kraftaufnehmer 6 kann beispielsweise einen FederkÃ¶rper aufweisen, der durch das auf das FreiformwerkstÃ¼ck 6 im Spannzustand wirkende Magnetfeld elastisch verformt werden kann. Die Verformung des FederkÃ¶rpers kann zum Beispiel Ã¼ber Dehnungsmessstreifen, deren elektrischer Widerstand sich mit der Dehnung Ã¤ndert, gemessen werden und in eine elektrische Spannung umgewandelt werden und letztendlich in einen Kraftmesswert umgerechnet werden. Alternativ dazu kann die Verformung des FederkÃ¶rpers durch kapazitive Sensoren aufgenommen werden. Durch den Kraftaufnehmer 66 kann die Spannkraft genau widergegeben werden und damit die Reproduzierbarkeit der Lage des FreiformwerkstÃ¼ckes 6 im Spannzustand weiter verbessert werden.The force transducer 66 can be designed in such a way that it moves onto the magnetizable free-form workpiece 6th in the tensioned state 8th exerted tension recorded. The force transducer 6th can, for example, have a spring body, which by the on the freeform workpiece 6th in the tensioned state acting magnetic field can be elastically deformed. The deformation of the spring body can, for example, be measured using strain gauges, the electrical resistance of which changes with the expansion, and converted into an electrical voltage and ultimately converted into a force measurement value. Alternatively, the deformation of the spring body can be recorded by capacitive sensors. Through the force transducer 66 the clamping force can be precisely reproduced and thus the reproducibility of the position of the freeform workpiece 6th can be further improved in the tensioned state.

Alternativ dazu oder auch zusÃ¤tzlich kann der Kraftaufnehmer auch als elektrische Auswerteeinheit ausgebildet sein zum Erfassen des Betriebszustandes der WerkstÃ¼ckspannvorrichtung 1. Damit kann beispielsweise widergegeben werden, ob das FreiformwerkstÃ¼ck Ã¼berhaupt auf der AuflageflÃ¤che 4 aufliegt. Die Auswerteeinheit kann derart konstruiert sein, dass sie die zeitliche Ableitung der Spannung und/oder des Stroms des Elektromagneten 60 ausgibt. Durch den zeitlichen Verlauf dieser zeitlichen Ableitung kann der Betriebszustand genau wiedergegeben werden. Das FreiformwerkstÃ¼ck 6 wirkt dabei wie ein Anker und die AuflageflÃ¤che 4 wie ein Joch. Die Bewegung des FreiformwerkstÃ¼ckes 6 zur AuflageflÃ¤che 4 hin induziert eine Gegenspannung, wodurch der Strom absinkt. SchlÃ¤gt das FreiformwerkstÃ¼ck an der AuflageflÃ¤che an, stoppt die Bewegung und der Strom steigt wieder. Dieser Verlauf kann durch die elektrische Auswerteeinheit widergegeben werden.As an alternative to this or in addition, the force transducer can also be designed as an electrical evaluation unit for recording the operating state of the workpiece clamping device 1 . This can be used, for example, to show whether the free-form workpiece is actually on the support surface 4th rests. The evaluation unit can be constructed in such a way that it derives the voltage and / or the current of the electromagnet over time 60 issues. The operating status can be reproduced precisely through the time course of this time derivative. The free-form workpiece 6th acts like an anchor and the support surface 4th like a yoke. The movement of the free-form workpiece 6th to the support surface 4th hin induces a counter voltage, which causes the current to drop. If the freeform workpiece hits the support surface, the movement stops and the current rises again. This course can be reproduced by the electrical evaluation unit.

In 6 ist eine weitere vorteilhafte Ausgestaltung der erfindungsgemÃ¤Ãen WerkstÃ¼ckspannvorrichtung 1 gezeigt.In 6th is a further advantageous embodiment of the workpiece clamping device according to the invention 1 shown.

Die WerkstÃ¼ckspannvorrichtung 1 weist einen zylinderfÃ¶rmigen FuÃ 70 auf, der an einem Ende auf der Befestigungsebene 42 aufliegt. Am von der Befestigungsebene 42 entfernten Ende ist der FuÃ 70 mit einem Lager 72 zur Lagerung der Magnetfeldquelle 3 versehen. Die Magnetfeldquelle 3 kann beispielsweise ein kugelfÃ¶rmiger Permanentmagnet sein. HierfÃ¼r ist das Lager im Wesentlichen schalenfÃ¶rmig ausgestaltet, sodass die Magnetfeldquelle 3 frei rotierbar im Lager 72 gehalten werden kann. Die Magnetfeldquelle 3 kann auf der Befestigungsebene aus dem Lager 72 herausragen, beispielsweise kann ein Kugelsegment der kugelfÃ¶rmigen Magnetfeldquelle 3 aus dem Lager 72 herausragen. Um ein Herausfallen der Magnetfeldquelle 3 aus dem Lager 72 zu verhindern, kann die Magnetfeldquelle 3 mit einem Dichtring 74 versehen sein, der in eine Hinterschneidung 76 im Lager 72 eingreift.The workpiece clamping device 1 has a cylindrical base 70 on that at one end on the mounting plane 42 rests. On from the mounting plane 42 far end is the foot 70 with a warehouse 72 for storing the magnetic field source 3 Mistake. The magnetic field source 3 can for example be a spherical permanent magnet. For this purpose, the bearing is designed essentially in the shape of a shell, so that the magnetic field source 3 freely rotatable in the warehouse 72 can be held. The magnetic field source 3 can be taken from the warehouse at the mounting level 72 protrude, for example a spherical segment of the spherical magnetic field source 3 from the warehouse 72 stick out. To a falling out of the magnetic field source 3 from the warehouse 72 can prevent the magnetic field source 3 with a sealing ring 74 be provided in an undercut 76 in stock 72 intervenes.

Der FuÃ 70 und das Lager 72 sind vorzugsweise aus dem nicht ferromagnetischen Material 34 geformt, sodass sie keinen Einfluss auf das Magnetfeld 14 ausÃ¼ben. Dadurch kann anhand der Wahl der Magnetfeldquelle 3 die Spannkraft im Spannzustand genauer eingeschÃ¤tzt werden.The foot 70 and the camp 72 are preferably made of the non-ferromagnetic material 34 shaped so that they do not affect the magnetic field 14th exercise. This can be based on the choice of magnetic field source 3 the clamping force in the clamping state can be estimated more precisely.

Das Spannmodul 33 kann eine zur Befestigungsebene 42 geÃ¶ffnete HÃ¼lse 78 sein, die auf den FuÃ 70 aufgesetzt werden kann. HierfÃ¼r ist der Innendurchmesser der HÃ¼lse 78 grÃ¶Ãer als der AuÃendurchmesser des FuÃes 70. Am von der Befestigungsebene 42 abgewandten Ende der HÃ¼lse 78, ist die HÃ¼lse 78 von dem AuflagekÃ¶rper 2 verschlossen. Der AuflagekÃ¶rper 2 kann vorzugsweise einstÃ¼ckig mit der HÃ¼lse 78 ausgeformt sein, beispielsweise als 3D-Druck WerkstÃ¼ck. Alternativ dazu kann die HÃ¼lse 78 und/oder der AuflagekÃ¶rper in der spannenden Fertigung hergestellt sein. Dadurch kann ganz einfach und mit hoher Genauigkeit eine an das FreiformwerkstÃ¼ck 6 individuell angepasste AuflageflÃ¤che 4 geformt werden.The clamping module 33 can one to the mounting level 42 opened sleeve 78 be that on the foot 70 can be put on. This is the inside diameter of the sleeve 78 larger than the outside diameter of the foot 70 . On from the mounting plane 42 remote end of the sleeve 78 , is the sleeve 78 from the support body 2 locked. The support body 2 may preferably be integral with the sleeve 78 be shaped, for example as a 3D printed workpiece. Alternatively, the sleeve 78 and / or the support body can be produced in the exciting production. As a result, one can be attached to the freeform workpiece very easily and with high accuracy 6th individually adapted support surface 4th be shaped.

Der AuflagekÃ¶rper 2 ist auf der zur Magnetfeldquelle 3 gerichteten Seite mit einer Einbuchtung 80 versehen, in die zumindest im Spannzustand 8 der aus dem Lager 72 hinausragende Teil der Magnetfeldquelle 3 eingesetzt sein kann. Dadurch befindet sich die Magnetfeldquelle in ausreichender NÃ¤he zur AuflageflÃ¤che 4, sodass das von der Magnetfeldquelle 3 verursachte Magnetfeld 14 auf das auf der AuflageflÃ¤che 4 anliegende FreiformwerkstÃ¼ck 6 und/oder das Hilfselement 9 wirkt.The support body 2 is on the to the magnetic field source 3 facing side with an indentation 80 provided, at least in the tensioned state 8th of the from the warehouse 72 protruding part of the magnetic field source 3 can be used. This means that the magnetic field source is in sufficient proximity to the support surface 4th so that from the magnetic field source 3 caused magnetic field 14th on the one on the support surface 4th adjacent free-form workpiece 6th and / or the auxiliary element 9 works.

Zum Versperren der relativen Position der AuflageflÃ¤che 4 zur Magnetfeldquelle 3 ist eine Verriegelung vorgesehen. Die HÃ¼lse 78 kann hierbei mit einer FÃ¼hrung 82, insbesondere einer BajonettfÃ¼hrung 84, versehen sein, die zur Befestigungsebene 42 hin geÃ¶ffnet ist. Der FuÃ 70 kann eine von seiner MantelflÃ¤che herausragende Hervorhebung 86 aufweisen, die in die FÃ¼hrung 82 eingreift.To block the relative position of the support surface 4th to the magnetic field source 3 a lock is provided. The sleeve 78 can do this with a guide 82 , especially a bayonet guide 84 , be provided to the mounting plane 42 is open. The foot 70 can be a highlight protruding from its outer surface 86 exhibit that in the lead 82 intervenes.

Die BajonettfÃ¼hrung 84 weist zumindest zwei Einschnitte 88 auf, in denen die Hervorhebung 86 eingesetzt werden kann und eine Bewegung des Spannmoduls 33 zur Befestigungsebene 42 hin oder von ihr weg gesperrt wird. Dadurch kann die relative Position der AuflageflÃ¤che 4 und der Magnetfeldquelle 3 in zumindest zwei Positionen eingestellt werden. Die Einschnitte 88 sind parallel zueinander angeordnet, voneinander beabstandet und erstrecken sich quer von der FÃ¼hrung 82 weg. Die Einschnitte 88 sind derart voneinander beabstandet, sodass ein Einschnitt nÃ¤her zur AuflageflÃ¤che 4 angeordnet ist als der andere.The bayonet guide 84 has at least two incisions 88 on where the highlighting 86 can be used and a movement of the clamping module 33 to the mounting level 42 is blocked towards or away from it. This allows the relative position of the support surface 4th and the magnetic field source 3 can be set in at least two positions. The cuts 88 are arranged parallel to one another, spaced from one another and extend transversely from the guide 82 path. The cuts 88 are spaced from one another so that an incision is closer to the support surface 4th is arranged than the other.

In einer ersten Position 90, die in 6 dargestellt ist, ist die Hervorhebung 86 in dem nÃ¤her zur AuflageflÃ¤che 4 gelegenen Einschnitt 88 eingesetzt. Dadurch ist die AuflageflÃ¤che 4 in der NÃ¤he zu der Magnetfeldquelle 3 angeordnet, sodass das Magnetfeld 14 der Magnetfeldquelle 3 auf das FreiformwerkstÃ¼ck 6 und/oder das Hilfselement 9 einwirken kann. Daher befindet sich die WerkstÃ¼ckspannvorrichtung 1 in der ersten Position 90 im Spannzustand 8.In a first position 90 , in the 6th is shown is the highlighting 86 in which closer to the support surface 4th located incision 88 used. This is the support surface 4th close to the source of the magnetic field 3 arranged so that the magnetic field 14th the magnetic field source 3 on the freeform workpiece 6th and / or the auxiliary element 9 can act. Therefore the workpiece clamping device is located 1 in the first position 90 in the tensioned state 8th .

In einer zweiten Position 92, ist die Hervorhebung 87 in der von der AuflageflÃ¤che 4 weiter entfernten Einschnitt 88 eingesetzt. Dadurch wird die AuflageflÃ¤che 4 von der Magnetfeldquelle 3 weg versetzt, sodass das Magnetfeld 14 der Magnetfeldquelle 3 eine geringe bis gar keine Spannkraft auf das FreiformwerkstÃ¼ck 6 und/oder Hilfselement 9 ausÃ¼bt, wodurch das FreiformwerkstÃ¼ck 6 einfach und ohne Verbiegen gelÃ¶st werden kann. Folglich befindet sich die WerkstÃ¼ckspannvorrichtung 1 in der zweiten Position 92 im LÃ¶sezustand 10.In a second position 92 , is the emphasis 87 in the from the supporting surface 4th more distant incision 88 used. This creates the supporting surface 4th from the magnetic field source 3 offset away so that the magnetic field 14th the magnetic field source 3 little to no clamping force on the freeform workpiece 6th and / or auxiliary element 9 exerts, whereby the freeform workpiece 6th can be released easily and without bending. Consequently, the workpiece clamping device is located 1 in the second position 92 in the dissolved state 10 .

Durch diese Ausgestaltung kann auf einen schaltbaren Magneten verzichtet werden, da das Schalten zwischen LÃ¶sezustand und Schaltzustand durch die VerÃ¤nderung der relativen Position der AuflageflÃ¤che und der Magnetfeldquelle zueinander gesteuert wird. Es kann jedoch auch zusÃ¤tzlich ein schaltbarer Magnet als Magnetfeldquelle eingesetzt werden, wodurch dem Benutzer verschiedene MÃ¶glichkeiten gegeben werden kÃ¶nnen zwischen den ZustÃ¤nden zu schalten.With this configuration, a switchable magnet can be dispensed with, since switching between the release state and the switching state is controlled by changing the relative position of the support surface and the magnetic field source to one another. However, a switchable magnet can also be used as a magnetic field source, whereby the user can be given various options to switch between the states.

BezugszeichenlisteList of reference symbols

11

WerkstÃ¼ckspannvorrichtungWorkpiece clamping device

22

AuflagekÃ¶rperSupport body

33

MagnetfeldquelleMagnetic field source

44th

AuflageflÃ¤cheSupport surface

66th

FreiformwerkstÃ¼ckFreeform workpiece

77th

SpannpunktTension point

88th

SpannzustandState of tension

99

HilfselementAuxiliary element

1010

LÃ¶sezustandRelease state

1111

KÃ¶rperbody

1212

Magnetmagnet

1414th

MagnetfeldMagnetic field

1616

DauermagnetPermanent magnet

2020th

GehÃ¤usecasing

2121st

SchaltmodulSwitch module

2222nd

Antriebdrive

2323

DrehgriffTwist grip

2525th

Indikatorindicator

2626th

GehÃ¤usecasing

2727

Ãffnungenopenings

2828

Kammerchamber

3030th

PolschuhePole pieces

3131

Zeigerpointer

3232

nicht ferromagnetischer Abschnittnon-ferromagnetic section

3333

SpannmodulClamping module

3434

nicht ferromagnetisches Materialnon-ferromagnetic material

3535

KopplungselementCoupling element

3636

BasisBase

3737

PolergÃ¤nzungPole completion

3838

Armpoor

3939

nicht ferromagnetisches StÃ¼cknot ferromagnetic piece

4040

FlÃ¤chesurface

4141

AuflagepunktSupport point

4242

BefestigungsebeneMounting level

4343

DurchgangsÃ¶ffnungenThrough openings

4444

HervorhebungEmphasis

4545

SpannaufsatzClamping attachment

4646

Seitepage

4747

GrundkÃ¶rperBase body

4848

KalottenformDome shape

4949

EndeThe End

5050

ScheitelParting

5151

Kupplungcoupling

5252

Scheibedisc

5353

magnetischer Polmagnetic pole

5454

Segmentsegment

5555

Manschettecuff

6060

ElektromagnetElectromagnet

6262

FlanschverbindungFlange connection

6464

BefestigungseinheitFastening unit

6666

KraftaufnehmerForce transducers

6868

FlanschteilFlange part

7070

FuÃfoot

7272

Lagercamp

7474

DichtringSealing ring

7676

HinterschneidungUndercut

7878

HÃ¼lseSleeve

8080

Einbuchtungindentation

8282

FÃ¼hrungguide

8484

BajonettfÃ¼hrungBayonet guide

8686

HervorhebungEmphasis

8888

Einschnittincision

9090

erste Positionfirst position

9292

zweite Positionsecond position

## Classifications

- B23Q3/1543
- B23Q3/1543
- B23Q3/103
- B23Q3/103
- B23Q3/15
- B23Q3/15
- B25B11/00
- B25B11/00
- B25B11/002
- B25B11/002

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
