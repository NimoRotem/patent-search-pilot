# 30. In-/uitschakelbare magnetische grijper.

- **Archive rank:** 30 of 50
- **Publication:** [NL-2009798-C2](https://patents.google.com/patent/NL2009798C2/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/047603985/publication/NL2009798C2?q=pn%3DNL2009798C2)
- **Publication date:** 2014-05-14
- **Filing date:** 2012-11-13
- **Earliest priority:** 2012-11-13
- **Family:** 47603985
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** GOUDSMIT MAGNETIC SYSTEMS B V
- **Inventors:** JACOBS AD

## Abstract

_No abstract was available from the queried sources._

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf000.png)

![Sketch 1 for NL-2009798-C2](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf001.png)

![Sketch 2 for NL-2009798-C2](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf002.png)

![Sketch 3 for NL-2009798-C2](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf003.png)

![Sketch 4 for NL-2009798-C2](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf004.png)

![Sketch 5 for NL-2009798-C2](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf005.png)

![Sketch 6 for NL-2009798-C2](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf006.png)

![Sketch 7 for NL-2009798-C2](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf007.png)

![Sketch 8 for NL-2009798-C2](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf008.png)

![Sketch 9 for NL-2009798-C2](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf009.png)

![Sketch 10 for NL-2009798-C2](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf009.png)

[Sketch 11](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf010.png)

![Sketch 11 for NL-2009798-C2](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf010.png)

[Sketch 12](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf011.png)

![Sketch 12 for NL-2009798-C2](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf011.png)

[Sketch 13](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf012.png)

![Sketch 13 for NL-2009798-C2](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf012.png)

[Sketch 14](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf013.png)

![Sketch 14 for NL-2009798-C2](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf013.png)

[Sketch 15](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf014.png)

![Sketch 15 for NL-2009798-C2](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf014.png)

[Sketch 16](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf015.png)

![Sketch 16 for NL-2009798-C2](https://nimo.iptorch.com/refdrawing/NL-2009798-C2/pdf015.png)

## Claims

### Claim 1 (independent)

Claims (7)

### Claim 2

Translated from Dutch In-/uitschakelbare magnetische grijper (1; 51) omvattende een behuizing (3) met daarin een cilindrische ruimte (5), waarin een permanente magneet (9) verschuifbaar is tussen een werkpositie waarin de magneet in een eerste deel (13) van 5 de cilindrische ruimte nabij een eerste uiteinde (15) van de ruimte aanwezig is, en een rustpositie waarin de magneet in een tweede deel (17) van de ruimte nabij het andere, tweede uiteinde (19) van de ruimte aanwezig is, met het kenmerk, dat de behuizing (3) geheel of in hoofdzaak van magnetisch materiaal is, dat de magneet (9) in een richting (11) haaks op de begrenzingswand (31) van de cilindrische ruimte (5) is 10 gemagnetiseerd, en dat tussen het eerste en tweede deel (13, 17) van de cilindrische ruimte (5) de wand (23) van de behuizing is voorzien van een eerste magnetische weerstand (21; 53) voor magneetflux, en de wand van het eerste deel (13) van de ruimte op twee tegenover elkaar aanwezig plaatsen aan weerszijde van de cilindrische ruimte is voorzien van een tweede en een derde magnetische weerstand (25, 27; 55, 57), waarbij 15 de magneet (9) niet verdraaibaar is in de cilindrische ruimte (5) en de magnetisatierichting (11) haaks of nagenoeg haaks staat op de verbindingslijn tussen de tweede en een derde magnetische weerstand (25, 27; 55, 57).A switchable magnetic grab (1; 51) comprising a housing (3) with a cylindrical space (5) therein, in which a permanent magnet (9) is slidable between a working position in which the magnet in a first part (13) of the cylindrical space is present near a first end (15) of the space, and a rest position in which the magnet is present in a second part (17) of the space near the other, second end (19) of the space, with characterized in that the housing (3) is wholly or substantially of magnetic material, that the magnet (9) is magnetized in a direction (11) perpendicular to the boundary wall (31) of the cylindrical space (5), and that between the first and second part (13, 17) of the cylindrical space (5) the wall (23) of the housing is provided with a first magnetic resistor (21; 53) for magnetic flux, and the wall of the first part (13) ) of the space at two opposite locations on either side of the cylindrical space has a second and a third magnetic resistor (25, 27; 55, 57), wherein the magnet (9) is not rotatable in the cylindrical space (5) and the magnetization direction (11) is perpendicular or substantially perpendicular to the connecting line between the second and a third magnetic resistor (25, 27; 55 , 57). Magnetische grijper (1; 51) volgens conclusie 1, met het kenmerk, dat de eerste magnetische weerstand (21; 53) zich over de hele omtrek van de behuizing 20 uitstrekt.A magnetic gripper (1; 51) according to claim 1, characterized in that the first magnetic resistor (21; 53) extends over the entire circumference of the housing 20.

### Claim 3

Magnetische grijper (1; 51) volgens conclusie 1 of 2, met het kenmerk, dat de tweede en derde magnetische weerstanden (25, 27; 55, 57) zich vanaf het eerste uiteinde (15) tot aan de eerste weerstand (21) uitstrekken.Magnetic gripper (1; 51) according to claim 1 or 2, characterized in that the second and third magnetic resistors (25, 27; 55, 57) extend from the first end (15) to the first resistor (21) ) extend.

### Claim 4

Magnetische grijper (1) volgens conclusie 1, 2 of 3, met het kenmerk, dat 25 de eerste en/of tweede en/of derde magnetische weerstand (21, 25, 27) is/zijn gevormd door een verdunning van de wand (23).4. Magnetic gripper (1) as claimed in claim 1, 2 or 3, characterized in that the first and / or second and / or third magnetic resistance (21, 25, 27) is / are formed by a dilution of the wall (23).

### Claim 5

Magnetische grijper (51) volgens conclusie 1, 2 of 3, met het kenmerk, dat de eerste en/of tweede en/of derde magnetische weerstand (53, 5, 57) is/zijn gevormd doordat ter plaatse van de weerstand de wand van niet magnetisch materiaal is.A magnetic gripper (51) according to claim 1, 2 or 3, characterized in that the first and / or second and / or third magnetic resistor (53, 5, 57) is / are formed in that at the location of the resistor wall is made of non-magnetic material.

### Claim 6

Magnetische grijper (1; 51) volgens Ã©Ã©n der voorgaande conclusies, met het kenmerk, dat in de cilindrische begrenzingswand (31) ten minste Ã©Ã©n zich in axiale richting uitstrekkende groef (29) aanwezig is en de magneet (9) deel uitmaakt van een zuiger (7) die is voorzien van een uitsteeksel (33) dat in de groef steekt en in de groef verplaatsbaar is.Magnetic gripper (1; 51) according to one of the preceding claims, characterized in that at least one groove (29) extending in axial direction is present in the cylindrical boundary wall (31) and the magnet (9) forms part of a piston (7) provided with a protrusion (33) which protrudes into the groove and is displaceable in the groove.

### Claim 7

Magnetische grijper (1; 51) volgens Ã©Ã©n der voorgaande conclusies, met het kenmerk, dat ter plaatse van het eerste uiteinde (15) de behuizing (3) een bodem (43) omvat die de cilindrische ruimte (5) aan dit uiteinde afsluit en dat in de wand (23) van de behuizing nabij het eerste uiteinde een opening (47) aanwezig is voor het 5 aansluiten van een pneumatische leiding.A magnetic gripper (1; 51) according to any one of the preceding claims, characterized in that at the location of the first end (15) the housing (3) comprises a bottom (43) which the cylindrical space (5) at this end and that an opening (47) is provided in the wall (23) of the housing near the first end for connecting a pneumatic line.

## Full description

**[p0001]**

PERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating electrostatic or magnetic grippersPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by magnetic means

**[p0002]**

Description Translated from Dutch In-/uitschakelbare magnetische grijper BESCHRIJVING: 5Switchable magnetic grabber DESCRIPTION: 5 Gebied van de uitvindingFIELD OF THE INVENTION De uitvinding heeft betrekking op een In-/uitschakelbare magnetische grijper omvattende een behuizing met daarin een cilindrische ruimte, waarin een 10 permanente magneet verschuifbaar is tussen een werkpositie waarin de magneet in een eerste deel van de cilindrische ruimte nabij een eerste uiteinde van de ruimte aanwezig is, en een rustpositie waarin de magneet in een tweede deel van de ruimte nabij het andere, tweede uiteinde van de ruimte aanwezig is.The invention relates to a switch-on / off magnetic gripper comprising a housing with a cylindrical space therein, in which a permanent magnet is slidable between a working position in which the magnet is present in a first part of the cylindrical space near a first end of the space and a rest position in which the magnet is present in a second part of the space near the other, second end of the space.

**[p0003]**

15 Stand van de techniekPrior art Een dergelijke magnetische grijper is bekend uit EP 0 079 807 Al. Deze bekende magnetische grijper heeft een behuizing met daarin een verschuifbare, als zuiger uitgevoerde magneet. In de onderste stand loopt de magneetflux door de bodem 20 van de behuizing en kan een last opgenomen worden. Met bij voorkeur perslucht wordt de magneet weg geschoven van de bodem zodat de magneetflux niet meer door de bodem loopt. De last wordt zo losgelaten. De behuizing van dit concept is in niet magnetisch materiaal uitgevoerd en heeft geen taak in het doorlaten van de magneetflux.Such a magnetic gripper is known from EP 0 079 807 A1. This known magnetic gripper has a housing with a slidable magnet designed as a piston therein. In the lower position, the magnet flux runs through the bottom 20 of the housing and a load can be picked up. With preferably compressed air, the magnet is pushed away from the bottom so that the magnet flux no longer runs through the bottom. The load is released in this way. The housing of this concept is made of non-magnetic material and has no task in transmitting the magnetic flux.

**[p0004]**

2525 Samenvatting van de uitvindingSummary of the invention Een doel van de uitvinding is het verschaffen van een magnetische grijper van de in de aanhef omschreven soort die net zoals de bekende magnetische 30 grijper een eenvoudige en dus goedkopen bouwwijze heeft maar daarbij een grotere aantrekkingskracht ofwel hefvermogen heeft dan de bekende magneet. Hiertoe is de magnetische grijper volgens de uitvinding gekenmerkt, doordat de behuizing geheel of in hoofdzaak van magnetisch materiaal is, dat de magneet in een richting haaks op de begrenzingswand van de cilindrische ruimte is gemagnetiseerd, en dat tussen het eerste 2 en tweede deel van de cilindrische ruimte de wand van de behuizing is voorzien van een eerste magnetische weerstand voor magneetflux, en de wand van het eerste deel van de ruimte op twee tegenover elkaar aanwezig plaatsen aan weerszijde van de cilindrische ruimte is voorzien van een tweede en een derde magnetische weerstand, waarbij de 5 magneet niet verdraaibaar is in de cilindrische ruimte en de magnetisatierichting haaks of nagenoeg haaks staat op de verbindingslijn tussen de tweede en een derde magnetische weerstand. Onder een magnetische weerstand wordt hier een weerstand tegen het doorlaten van magneetflux verstaan.It is an object of the invention to provide a magnetic gripper of the type described in the preamble which, just like the known magnetic gripper, has a simple and therefore inexpensive construction method but has a greater attraction or lifting capacity than the known magnet. To this end, the magnetic gripper according to the invention i

**[p0004]**

s characterized in that the housing is wholly or substantially of magnetic material, that the magnet is magnetized in a direction perpendicular to the boundary wall of the cylindrical space, and that between the first 2 and second part of the cylindrical space the wall of the housing is provided with a first magnetic resistance for magnetic flux, and the wall of the first part of the space at two opposite locations on either side of the cylindrical space is provided with a second and a third magnetic resistance, wherein the magnet is not rotatable in the cylindrical space and the magnetization direction is perpendicular or substantially perpendicular to the connecting line between the second and a third magnetic resistor. A magnetic resistance is here understood to mean a resistance to the passage of magnetic flux.

**[p0005]**

Doordat de in de permanente magneet gegenereerde magneetflux direct 10 door de behuizing wordt doorgeleid naar de last en daarbij nergens onderbroken wordt door een luchtspleet (hetgeen wel het geval is bij de bekende magnetische grijper waar de bodem gezien dient te worden als een luchtspleet) is de grijper volgens de uitvinding sterker dan de bekende grijper. De opbouw van de grijper is voorts eenvoudig, waardoor de grijper goedkoop is te produceren.Because the magnetic flux generated in the permanent magnet is directly passed through the housing to the load and is not interrupted anywhere by an air gap (which is the case with the known magnetic gripper where the bottom is to be seen as an air gap), the gripper according to the invention stronger than the known gripper. The construction of the gripper is furthermore simple, whereby the gripper can be produced cheaply. 15 Bij voorkeur strekt de eerste magnetische weerstand zich over de hele omtrek van de behuizing uit, zodat magneetflux niet ongewenst deels via een magnetische kortsluiting ongehinderd door geleid wordt.The first magnetic resistance preferably extends over the entire circumference of the housing, so that magnetic flux is not undesirably passed through unhindered, in part, via a magnetic short circuit.

**[p0006]**

Voorts strekken bij voorkeur de tweede en derde magnetische weerstanden zich vanaf het eerste uiteinde tot aan de eerste weerstand uit, ook weer om 20 te voorkomen dat magneetflux ongewenst deels via een magnetische kortsluiting ongehinderd door geleid wordt.Furthermore, the second and third magnetic resistors preferably extend from the first end to the first resistor, again in order to prevent that magnetic flux is undesirably partially passed through unhindered through a magnetic short circuit. Een uitvoeringsvorm van de magnetische grijper volgens de uitvinding is gekenmerkt, doordat de eerste en/of tweede en/of derde magnetische weerstand is/zijn gevormd door een verdunning van de wand.An embodiment of the magnetic gripper according to the invention is characterized in that the first and / or second and / or third magnetic resistance is / are formed by a dilution of the wall. 25 Een andere uitvoeringsvorm van de magnetische grijper volgens de uitvinding is gekenmerkt, doordat de eerste en/of tweede en/of derde magnetische weerstand is/zijn gevormd doordat ter plaatse van de weerstand de wand van niet magnetisch materiaal is.Another embodiment of the magnetic gripper according to the invention is characterized in that the first and / or second and / or third magnetic resistance is / are formed because the wall of non-magnetic material is located at the location of the resistance.

**[p0007]**

Een verdere uitvoeringsvorm van de magnetische grijper volgens de 30 uitvinding waarbij op eenvoudige wijze is voorkomen dat de magneet kan verdraaien is gekenmerkt, doordat in de cilindrische begrenzingswand ten minste Ã©Ã©n zich in axiale richting uitstrekkende groef aanwezig is en de magneet deel uitmaakt van een zuiger die is voorzien van een uitsteeksel dat in de groef steekt en in de groef verplaatsbaar is.A further embodiment of the magnetic gripper according to the invention in which it is prevented in a simple manner that the magnet can rotate is characterized in that at least one groove extending in axial direction is present in the cylindrical boundary wall and the magnet forms part of a piston which is provided with a protrusion which protrudes into the groove and is displaceable in the groove. 33 Nog een verdere uitvoeringsvorm van de magnetische grijper volgens de uitvinding is gekenmerkt, doordat ter plaatse van het eerste uiteinde de behuizing een bodem omvat die de cilindrische ruimte aan dit uiteinde afsluit en dat in de wand van de behuizing nabij het eerste uiteinde een opening aanwezig is voor het aansluiten van een 5 pneumatische leiding. Hierdoor kan de zuiger eenvoudig met behulp van perslucht verplaatst worden. Bij voorkeur is ook ter plaatse van het tweede deel een opening in de wand aanwezig voor het aansluiten van een verdere pneumatische leiding.A still further embodiment of the magnetic gripper according to the invention is characterized in that at the location of the first end the housing comprises a bottom which closes off the cylindrical spa

**[p0007]**

ce at this end and that an opening is present in the wall of the housing near the first end for connecting a pneumatic line. This allows the piston to be easily moved using compressed air. Preferably, an opening is also present in the wall at the location of the second part for connecting a further pneumatic line.

**[p0008]**

Beknopte omschrijving van de tekeningen 10Brief description of the drawings 10 Hieronder zal de uitvinding nader worden toegelicht aan de hand van in de tekeningen weergegeven uitvoeringsvoorbeelden van de magnetische grijper volgens de uitvinding. Hierbij toont:The invention will be explained in more detail below with reference to exemplary embodiments of the magnetic gripper according to the invention shown in the drawings. Hereby shows: Figuur 1 een deels opengewerkt aanzicht in perspectief van een eerste 15 uitvoeringsvorm van de magnetische grijper volgens de uitvinding;Figure 1 shows a partly cut-away perspective view of a first embodiment of the magnetic gripper according to the invention; Figuur 2 een deels opengewerkt aanzicht in perspectief van een tweede uitvoeringsvorm van de magnetische grijper volgens de uitvinding;Figure 2 shows a partly cut-away perspective view of a second embodiment of the magnetic gripper according to the invention; Figuur 3 de zuiger met de permanente magneet van de grijper;Figure 3 shows the piston with the permanent magnet of the gripper;

**[p0009]**

Figuur 4 een opengewerkte schematische weergave van de grijper met de 20 zuiger in werkpositie; enFigure 4 shows a cut-away schematic representation of the gripper with the piston in working position; and Figuur 5 een opengewerkte schematische weergave van de grijper met de zuiger in rustpositie.Figure 5 shows a cut-away schematic representation of the gripper with the piston in the rest position. Gedetailleerde omschrijving van de tekeningen 25Detailed description of the drawings 25 In figuur 1 is een deels opengewerkt aanzicht in perspectief van een eerste uitvoeringsvorm van de magnetische grijper volgens de uitvinding weergegeven. De magnetische grijper 1 heeft een behuizing 3 met daarin een cilindrische ruimte 5, alsmede een in de ruimte verschuifbare zuiger 7. De zuiger is samengesteld uit een 30 cirkelcilindrische permanente magneet 9 die diametraal gemagnetiseerd is. De magnetisatierichting is met een pijl 11 aangegeven. De magneet 9 is verschuifbaar tussen een werkpositie, waarin de magneet in een eerste deel 13 van de cilindrische ruimte 5 nabij een eerste uiteinde 15 van de ruimte aanwezig is, en een rustpositie, 4 waarin de magneet 9 in een tweede deel 17 van de ruimte nabij het andere, tweede uiteinde 19 van de ruimte aanwezig is.Figure 1 shows a partly cut-away perspective view of a first embodiment of the magnetic gripper according to the invention. The magnetic gripper 1 has a housing 3 with a cylindrical space 5 therein, as well as a piston 7 which is slidable in the space. The piston is composed of a circular cylindrical permanent magnet 9 that is diametri

**[p0009]**

cally magnetized. The magnetization direction is indicated by an arrow 11. The magnet 9 is slidable between a working position in which the magnet is present in a first part 13 of the cylindrical space 5 near a first end 15 of the space, and a rest position 4 in which the magnet 9 is located in a second part 17 of the space is present near the other, second end 19 of the space.

**[p0010]**

De behuizing 3 is van magnetisch materiaal, en de magneet 9 is in een richting haaks op de begrenzingswand van de cilindrische ruimte gemagnetiseerd.The housing 3 is made of magnetic material, and the magnet 9 is magnetized in a direction perpendicular to the boundary wall of the cylindrical space. 5 Tussen het eerste en tweede deel 13, 17 van de cilindrische ruimte, aangegeven met 21, is de wand 23 bevindt zich een magnetische weerstand 21 die gevormd is door een over de hele omtrek aanwezige verdunning van de behuizing. Voorts is de wand van het eerste deel 13 van de ruimte 5 op twee tegenover elkaar aanwezig plaatsen voorzien van een tweede en een derde magnetische weerstand 25 en 27 die gevormd zijn door aan 10 weerszijde van de cilindrische ruimte aanwezige verdunningen van de wand 23 die zich uitstrekken vanaf het eerste uiteinde 15 tot aan de eerste magnetische weerstand 21. Deze verdunningen zijn gevormd door afplatting van de behuizing 3. Deze verdunningen vormen trechters voor de magneetflux zodat slechts een beperkte magneetflux deze verdunningen kan passeren en de magneetflux zijn weg door delen 15 van de behuizing met een grotere wanddikte zal zoeken.Between the first and second parts 13, 17 of the cylindrical space, indicated by 21, the wall 23 is a magnetic resistor 21 which is formed by a dilution of the housing present over the entire circumference. Furthermore, the wall of the first part 13 of the space 5 is provided at two opposite locations with a second and a third magnetic resistor 25 and 27 which are formed by dilutions of the wall 23 which are presen

**[p0010]**

t on either side of the cylindrical space. extending from the first end 15 to the first magnetic resistor 21. These dilutions are formed by flattening of the housing 3. These dilutions form funnel for the magnetic flux so that only a limited magnet flux can pass through these dilutions and the magnetic flux are eliminated through portions 15 of the housing with a larger wall thickness will search.

**[p0011]**

In het tweede deel 17 van de cilindrische ruimte 5 op twee diametraal tegenover elkaar aanwezige plaatsen, zijn zich in axiale richting uitstrekkende groeven 29 in de cilindrische begrenzingswand 31 aanwezig. In deze groeven zijn op de zuiger 7 aanwezige uitsteeksels 33, zie ook figuur 2, verschuifbaar waardoor de zuiger 7 en de 20 daarvan deel uitmakende magneet 9 niet verdraaibaar zijn in de behuizing. De permanente magneet 9 is diametraal gemagnetiseerd, pijl 11, waarbij de magnetisatierichting 11 haaks of nagenoeg haaks staat op de verbindingslijn tussen beide plaatsen 25 en 27. Hierdoor vormen zich aan het eerste uiteinde 15 een magnetische noordpool 35 en zuidpool 37.In the second part 17 of the cylindrical space 5 at two diametrically opposed locations, grooves 29 extending in axial direction are present in the cylindrical boundary wall 31. In these grooves, projections 33 present on the piston 7, see also Figure 2, are slidable, as a result of which the piston 7 and the magnet 9 forming part thereof are not rotatable in the housing. The permanent magnet 9 is diametrically magnetized, arrow 11, wherein the magnetization direction 11 is perpendicular or substantially perpendicular to the connecting line between both locations 25 and 27. A magnetic north pole 35 and south pole 37 hereby form at the first end 15.

**[p0012]**

25 In figuur 2 is een deels opengewerkt aanzicht in perspectief van een tweede uitvoeringsvorm van de magnetische grijper volgens de uitvinding weergegeven. Alle onderdelen die gelijk zijn an die van de eerste uitvoeringsvorm zijn met dezelfde verwijzingscijfers aangeduid. Bij deze grijper 51 zijn de weerstanden 53, 55 en 57 gevormd doordat delen van de wand 23 van niet magnetisch materiaal zijn. 30 Deze delen kunnen aan de rest van de behuizing gelijmd gelast of geslodeerd zijn of kunnen in de behuizing geklemd (door bijvoorbeeld met bouten delen van de behuizing met elkaar te verbinden) of opgesloten zijn (door bijvoorbeeld de met elkaar in contact zijnde zijden van een profilering, bijvoorbeeld zwaluwstaart, te voorzien).Figure 2 shows a partly cut-away perspective view of a second embodiment of the magnetic gripper according to the invention. All parts that are the same as those of the first embodiment are designated with the same reference numerals. With this gripper 51, the resistors 53, 55 and 57 are formed in that parts of the wall 23 are made of non-magnetic material. These parts can be welded or welded to the rest of the housing or can be clamped in the housing (for example by connecting parts of the housing to each other with bolts) or be confined (for example by the sides of a contact that are in contact with each other) profiling, for example dovetail).

**[p0013]**

55 In figuur 3 is de zuiger 7 van de grijper in detail weergegeven. Aan de axiale uiteinden van de cirkelcilindrische magneet 9 zijn opsluitdelen 39 en 41 aanwezig. De uitsteeksels 33 maken deel uit van het bovenste opsluitdeel 41.Figure 3 shows the piston 7 of the gripper in detail. Locking members 39 and 41 are provided at the axial ends of the circular cylindrical magnet 9. The protrusions 33 form part of the upper retaining part 41. De behuizing 3 heeft voorts een bodem 43 van niet magnetisch materiaal 5 die de cilindrische ruimte 5 aan het eerste uiteinde 15 afsluit, zie figuur 1, en een deksel 45 die de cilindrische ruimte 5 aan het tweede uiteinde 19 afsluit. Nabij het eerste uiteinde 15 en ter plaatse van het tweede deel 17 van de cilindrische ruimte zijn openingen 47 en 49 in de wand 23 van de behuizing 3 aanwezig voor het aansluiten van pneumatische leidingen voor het verplaatsen van de zuiger 7.The housing 3 further has a bottom 43 of non-magnetic material 5 which closes the cylindrical space 5 at the first end 15, see figure 1, and a cover 45 which closes the cylindrical space 5 at the second end 19. Near the first end 15 and at the location of the second part 17 of the cylindrical space, openings 47 and 49 are present in the wall 23 of the housing 3 for connecting pneumatic lines for displacing the piston 7.

**[p0014]**

10 In de figuren 4 en 5 is een kwart van de grijper schematisch weergegeven ter verduidelijking van de werking van de grijper 1. Deze afbeeldingen zijn het resultaat van een flux berekening met eindige elementen software. In figuur 4 is de magneet 9 in de werkpositie weergegeven, waarbij de magneet zich in het eerste deel 13 van de cilindrische ruimte 5 bevindt. In de delen 51 en 53 ter plaatse van de verdunningen is de 15 wand 23 verzadigd met magneetflux. Door de geringe wanddikte ter plaatse van de verdunningen zal de wand daar slechts weinig magneetflux doorlaten en daarom zal de magneetflux een ander pad zoeken. Naar boven is de wand 23 cilindrisch ingesnoerd zodat ook daar een dunne wand ontstaat. Hierdoor zal de magneetflux door de dikkere wanddelen 55 van de stalen behuizing 3 naar de last 57 gaan. Plaatst men nu de grijper 20 met de onderkant (uiteinde 15) op een stalen last 57 dan zal de magneetflux zijn weg zoeken door deze stalen last, waardoor de last magnetisch wordt vastgegrepen. Uit berekeningen volgt dat in het deel 59 de magneetflux hoger is dan de aangrenzende delen 61 waar de magneetflux weer groter is dan de delen 63. In de niet gearceerde delen van de wand 23 en de last 57 is nauwelijks enige magneetflux aanwezig. In deze 25 figuur is te zien dat de magneetflux door de last gaat en de last dus tegen de grijper aangetrokken wordt.In figures 4 and 5, a quarter of the gripper is schematically shown to clarify the operation of the gripper 1. These images are the result of a flux calculation with finite element software. Figure 4 shows the magnet 9 in the w

**[p0014]**

orking position, the magnet being in the first part 13 of the cylindrical space 5. In the parts 51 and 53 at the location of the dilutions, the wall 23 is saturated with magnetic flux. Due to the small wall thickness at the location of the dilutions, the wall there will only allow little magnetic flux to pass and therefore the magnetic flux will look for another path. The wall 23 is cylindrically constricted upwards so that a thin wall is formed there too. As a result, the magnet flux will go through the thicker wall parts 55 of the steel housing 3 to the load 57. If one now places the gripper 20 with its underside (end 15) on a steel load 57, the magnetic flux will find its way through this steel load, whereby the load is magnetically grasped. It follows from calculations that in the part 59 the magnet flux is higher than the adjacent parts 61 where the magnet flux is again greater than the parts 63. In the non-shaded parts of the wall 23 and the load 57 hardly any magnet flux is present. In this figure it can be seen that the magnetic flux passes through the load and the load is therefore attracted to the gripper.

**[p0015]**

Beweegt men nu de zuiger met perslucht naar boven tot in het tweede deel 17 van de ruimte 5 waar de wand 23 overal even dik is, dan volgt uit berekeningen dat daar de magneetflux volledig wordt kortgesloten wordt door de dikke wand en de 30 grijper is uitgeschakeld. Dit is in figuur 5 aangegeven waarin de magneet 9 in de rustpositie is weergegeven. In de gearceerde delen 65 en 67 is magneetflux aanwezig, terwijl in de overige delen nauwelijks magneetflux aanwezig is. Hieruit is te zien dat de magneetflux zich in de dikke wand 23 concentreert en daarmee de magneet kortsluit. In de last 57 loopt geen flux waardoor de last afvalt.If the piston is now moved upwards with compressed air into the second part 17 of the space 5 where the wall 23 is the same everywhere, it follows from calculations that since the magnetic flux is completely short-circuited by the thick wall and the gripper is switched off . This is indicated in Figure 5, in which the magnet 9 is shown in the rest position. Magnetic flux is present in the shaded parts 65 and 67, while hardly any magnetic flux is present in the other parts. It can be seen from this that the magnetic flux concentrates in the thick wall 23 and thus short-circuits the magnet. No flux runs in the load 57, so that the load falls off.

**[p0016]**

66 Hoewel in het voorgaande de uitvinding is toegelicht aan de hand van de tekeningen, dient te worden vastgesteld dat de uitvinding geenszins tot de in de tekeningen getoonde uitvoeringsvorm is beperkt. De uitvinding strekt zich mede uit tot alle van de in de tekeningen getoonde uitvoeringsvorm afwijkende uitvoeringsvormen 5 binnen het door de conclusies gedefinieerde kader.Although in the foregoing the invention has been elucidated with reference to the drawings, it should be noted that the invention is by no means limited to the embodiment shown in the drawings. The invention also extends to all embodiments deviating from the embodiment shown in the drawings within the scope defined by the claims.

## Classifications

- B65G47/92
- B65G47/92
- B65G47/92
- B65G47/92
- B66C1/04
- B66C1/04
- B66C1/04
- B66C1/04

## Cited patent documents

- [DE-102006004295-A1](https://patents.google.com/patent/DE102006004295A1/en) — SEA
- [GB-928879-A](https://patents.google.com/patent/GB928879A/en) — SEA
- [US-2009027149-A1](https://patents.google.com/patent/US20090027149A1/en) — SEA
- [US-5525950-A](https://patents.google.com/patent/US5525950A/en) — SEA
- [WO-2004070391-A1](https://patents.google.com/patent/WO2004070391A1/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
