# 13. Greifvorrichtung zum Greifen von ferromagnetischen Gegenständen

- **Archive rank:** 13 of 50
- **Publication:** [DE-102016111908-B4](https://patents.google.com/patent/DE102016111908B4/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/060662252/publication/DE102016111908B4?q=pn%3DDE102016111908B4)
- **Publication date:** 2018-01-11
- **Filing date:** 2016-06-29
- **Earliest priority:** 2016-06-29
- **Family:** 60662252
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus

## Parties

- **Applicant / assignee:** SCHMALZ J GMBH
- **Inventors:** MÜNZNER KAY; STAHL TOBIAS; STORZ MICHAEL

## Abstract

Eine Greifvorrichtung (10&#39;&#39;) zum Greifen von ferromagnetischen Gegenständen, mit einem Magneten (12), der durch einen Aktor (14) zwischen einer Aktivstellung zum Greifen der Gegenstände und einer Passivstellung verlagerbar ist, ist im Hinblick auf hohe Haltekräfte und insbesondere auch geringe Resthaltekräfte derart ausgestaltet und weitergebildet, dass ein Polschuh (16&#39;&#39;) mit einer Anlagefläche (18) für die zu greifenden Gegenstände vorgesehen ist, dass der Polschuh (16&#39;&#39;) ein ferromagnetisches Material aufweist, dass der Magnet (12&#39;) den Polschuh (16&#39;&#39;) bezüglich einer Längsachse (20) nach außen zumindest teilweise umgibt und dass der Magnet (12) relativ zum Polschuh (16&#39;&#39;) entlang der Längsachse (20) verlagerbar ist.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-102016111908-B4/000.png)

![Sketch 1 for DE-102016111908-B4](https://nimo.iptorch.com/refdrawing/DE-102016111908-B4/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-102016111908-B4/001.png)

![Sketch 2 for DE-102016111908-B4](https://nimo.iptorch.com/refdrawing/DE-102016111908-B4/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/DE-102016111908-B4/002.png)

![Sketch 3 for DE-102016111908-B4](https://nimo.iptorch.com/refdrawing/DE-102016111908-B4/002.png)

## Claims

### Claim 1 (independent)

Claims (13)

### Claim 2 (independent)

Translated from German

### Claim 3 (independent)

Greifvorrichtung (10, 10', 10'') zum Greifen von ferromagnetischen GegenstÃ¤nden, mit einem Magneten (12, 12'), der durch einen Aktor (14) zwischen einer Aktivstellung zum Greifen der GegenstÃ¤nde und einer Passivstellung verlagerbar ist, wobei ein Polschuh (16, 16', 16'') mit einer AnlageflÃ¤che (18) fÃ¼r die zu greifenden GegenstÃ¤nde vorgesehen ist, und wobei der Polschuh (16, 16', 16'') ein ferromagnetisches Material aufweist, und wobei der Magnet (12, 12') den Polschuh (16, 16', 16'') bezÃ¼glich einer LÃ¤ngsachse (20) nach auÃen zumindest teilweise umgibt und wobei der Magnet (12, 12') relativ zum Polschuh (16, 16', 16'') entlang der LÃ¤ngsachse (20) verlagerbar ist, dadurch gekennzeichnet, dass der Magnet (12, 12') bei Verlagerung zwischen der Aktivstellung und der Passivstellung um die LÃ¤ngsachse (20) eine Drehbewegung durchfÃ¼hrt.Gripping device ( 10 . 10 ' . 10 '' ) for gripping ferromagnetic objects, with a magnet ( 12 . 12 ' ), which is controlled by an actuator ( 14 ) is displaceable between an active position for gripping the articles and a passive position, wherein a pole piece ( 16 . 16 ' . 16 '' ) with a contact surface ( 18 ) is provided for the objects to be gripped, and wherein the pole piece ( 16 . 16 ' . 16 '' ) comprises a ferromagnetic material, and wherein the magnet ( 12 . 12 ' ) the pole piece ( 16 . 16 ' . 16 '' ) with respect to a longitudinal axis ( 20 ) at least partially surrounds the outside and wherein the magnet ( 12 . 12 ' ) relative to the pole piece ( 16 . 16 ' . 16 '' ) along the longitudinal axis ( 20 ) is displaceable, characterized in that the magnet ( 12 . 12 ' ) in the case of displacement between the active position and the passive position about the longitudinal axis ( 20 ) performs a rotational movement.

### Claim 4

Greifvorrichtung (10, 10', 10'') nach Anspruch 1, dadurch gekennzeichnet, dass der Magnet (12, 12') eine Magnetisierungsrichtung (22) von wenigstens einem Nordpol (24) zu wenigstens einem SÃ¼dpol (26) aufweist. Gripping device ( 10 . 10 ' . 10 '' ) according to claim 1, characterized in that the magnet ( 12 . 12 ' ) a magnetization direction ( 22 ) of at least one north pole ( 24 ) to at least one south pole ( 26 ) having.

### Claim 5

Greifvorrichtung (10, 10', 10'') nach Anspruch 2, dadurch gekennzeichnet, dass die Magnetisierungsrichtung (22) orthogonal zur LÃ¤ngsachse (20) verlÃ¤uft. Gripping device ( 10 . 10 ' . 10 '' ) according to claim 2, characterized in that the direction of magnetization ( 22 ) orthogonal to the longitudinal axis ( 20 ) runs.

### Claim 6

Greifvorrichtung (10, 10', 10'') nach einem der voranstehenden AnsprÃ¼che, dadurch gekennzeichnet, dass der Polschuh (16, 16', 16'') parallel zu oder entlang der LÃ¤ngsachse (20) in mehrere, vorzugsweise zwei, Bestandteile (28, 30) geteilt ist und dass die Bestandteile (28, 30) voneinander beabstandet sind.Gripping device ( 10 . 10 ' . 10 '' ) according to one of the preceding claims, characterized in that the pole piece ( 16 . 16 ' . 16 '' ) parallel to or along the longitudinal axis ( 20 ) into several, preferably two, components ( 28 . 30 ) and that the components ( 28 . 30 ) are spaced from each other.

### Claim 7

Greifvorrichtung (10, 10', 10'') nach Anspruch 4, dadurch gekennzeichnet, dass die Beabstandung (32) zwischen den Bestandteilen (28, 30) durch eine Einlage (34) aus nicht ferromagnetischem Material ausgefÃ¼llt ist.Gripping device ( 10 . 10 ' . 10 '' ) according to claim 4, characterized in that the spacing ( 32 ) between the components ( 28 . 30 ) through an insert ( 34 ) is filled out of non-ferromagnetic material.

### Claim 8

Greifvorrichtung (10, 10', 10'') nach einem der voranstehenden AnsprÃ¼che, wobei die Greifvorrichtung (10, 10', 10'') ein GehÃ¤use (40) aufweist, dadurch gekennzeichnet, dass der Polschuh (16, 16', 16'') durch mindestens ein Zwischenelement, das ein nicht ferromagnetisches Material aufweist, vom GehÃ¤use (40) getrennt ist.Gripping device ( 10 . 10 ' . 10 '' ) according to any one of the preceding claims, wherein the gripping device ( 10 . 10 ' . 10 '' ) a housing ( 40 ), characterized in that the pole piece ( 16 . 16 ' . 16 '' ) by at least one intermediate element, which has a non-ferromagnetic material, from the housing ( 40 ) is disconnected.

### Claim 9

Greifvorrichtung (10, 10', 10'') nach einem der voranstehenden AnsprÃ¼che, dadurch gekennzeichnet, dass sich der Polschuh (16, 16', 16'') in seinem Querschnitt entlang der LÃ¤ngsachse (20) von der AnlageflÃ¤che (18) weg verjÃ¼ngt.Gripping device ( 10 . 10 ' . 10 '' ) according to one of the preceding claims, characterized in that the pole piece ( 16 . 16 ' . 16 '' ) in its cross section along the longitudinal axis ( 20 ) from the contact surface ( 18 ) Tapered away.

### Claim 10

Greifvorrichtung (10, 10', 10'') nach einem der voranstehenden AnsprÃ¼che, dadurch gekennzeichnet, dass der Polschuh (16, 16', 16'') an der AnlageflÃ¤che (18) ein Reibring aufweist.Gripping device ( 10 . 10 ' . 10 '' ) according to one of the preceding claims, characterized in that the pole piece ( 16 . 16 ' . 16 '' ) at the contact surface ( 18 ) has a friction ring.

### Claim 11

Greifvorrichtung (10, 10', 10'') nach einem der voranstehenden AnsprÃ¼che, dadurch gekennzeichnet, dass der Magnet (12, 12') als Ring, als Kreisabschnitt, als Hufeisenmagnet oder als Stabmagnet ausgebildet ist.Gripping device ( 10 . 10 ' . 10 '' ) according to one of the preceding claims, characterized in that the magnet ( 12 . 12 ' ) is designed as a ring, as a circular section, as a horseshoe magnet or as a bar magnet.

### Claim 12

Greifvorrichtung (10, 10', 10'') nach einem der voranstehenden AnsprÃ¼che, dadurch gekennzeichnet, dass der Magnet (12, 12') in der Aktivstellung an oder nahe einer Ebene angeordnet ist, in der die AnlageflÃ¤che (18) verlÃ¤uft. Gripping device ( 10 . 10 ' . 10 '' ) according to one of the preceding claims, characterized in that the magnet ( 12 . 12 ' ) is arranged in the active position at or near a plane in which the contact surface ( 18 ) runs.

### Claim 13

Greifvorrichtung (10, 10', 10'') nach einem der voranstehenden AnsprÃ¼che, dadurch gekennzeichnet, dass bei Vorliegen der Aktivstellung das der AnlageflÃ¤che (18) zugewandte untere Ende des Magneten (12, 12') von einer Ebene, in der die AnlageflÃ¤che (18) verlÃ¤uft, um einen Mindestabstand beabstandet ist.Gripping device ( 10 . 10 ' . 10 '' ) according to one of the preceding claims, characterized in that in the presence of the active position of the contact surface ( 18 ) facing the lower end of the magnet ( 12 . 12 ' ) from a plane in which the contact surface ( 18 ) is spaced by a minimum distance.

### Claim 14

Greifvorrichtung (10, 10', 10'') nach einem der voranstehenden AnsprÃ¼che, dadurch gekennzeichnet, dass der Magnet (12, 12') in der Passivstellung von der AnlageflÃ¤che (18) weg verlagert ist, so dass der Magnet (12, 12') den Polschuh (16, 16', 16'') nicht oder nur an einem distalen Abschnitt (38) des Polschuhs umgibt.Gripping device ( 10 . 10 ' . 10 '' ) according to one of the preceding claims, characterized in that the magnet ( 12 . 12 ' ) in the passive position of the contact surface ( 18 ) is shifted away so that the magnet ( 12 . 12 ' ) the pole piece ( 16 . 16 ' . 16 '' ) or only at a distal portion ( 38 ) of the pole piece surrounds.

### Claim 15

Greifvorrichtung (10, 10', 10'') nach einem der voranstehenden AnsprÃ¼che, dadurch gekennzeichnet, dass der Aktor (14) als pneumatische Kolben-Zylinder-Einheit (41) oder als elektrischer Antrieb ausgebildet ist.Gripping device ( 10 . 10 ' . 10 '' ) according to one of the preceding claims, characterized in that the actuator ( 14 ) as a pneumatic piston-cylinder unit ( 41 ) or is designed as an electric drive.

## Full description

**[p0001]**

PERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating electrostatic or magnetic grippersELECTRICITYELECTRIC ELEMENTSMAGNETS; INDUCTANCES; TRANSFORMERS; SELECTION OF MATERIALS FOR THEIR MAGNETIC PROPERTIESMagnetsPermanent magnets [PM]Magnetic circuits with PM for power or force generationPM holding devicesLifting, pick-up magnetic objectsELECTRICITYELECTRIC ELEMENTSMAGNETS; INDUCTANCES; TRANSFORMERS; SELECTION OF MATERIALS FOR THEIR MAGNETIC PROPERTIESMagnetsPermanent magnets [PM]Means for releasing the attractive force Description Translated from German

**[p0002]**

Die Erfindung betrifft eine Greifvorrichtung zum Greifen von ferromagnetischen GegenstÃ¤nden, mit einem Magneten, der durch einen Aktor zwischen einer Aktivstellung zum Greifen der GegenstÃ¤nde und einer Passivstellung verlagerbar ist.The invention relates to a gripping device for gripping ferromagnetic objects, with a magnet which is displaceable by an actuator between an active position for gripping the articles and a passive position. Aus der DE 20 2005 004 456 U1 ist z.B. eine Greifvorrichtung mit einem lÃ¤ngsverschieblich in einem GehÃ¤use gefÃ¼hrten Magneten bekannt. Wird der Magnet aus dem GehÃ¤use herausgeschoben, lassen sich ferromagnetische WerkstÃ¼cke greifen. Durch Einziehen des Magneten in das GehÃ¤use kann das anhaftende WerkstÃ¼ck gelÃ¶st werden, wobei die Stirnseite des GehÃ¤uses als Abstreifer fÃ¼r das WerkstÃ¼ck dient. Ein schaltbarer Dauermagnet fÃ¼r die Verwendung in einem Lasthebesystem mit den Merkmalen des Oberbegriffs des Anspruchs 1 ist in der DE 15 14 732 A beschrieben. Die EP 0 129 127 A1 beschreibt einen Magnetgreifer mit umschaltbaren Magneten, aufweisend einen Permanentmagneten und einem verschiebbaren Anker. Bei den bekannten Greifvorrichtungen besteht Raum fÃ¼r Optimierungen, insbesondere hinsichtlich einem Aufnehmen und Ablegen eines WerkstÃ¼cks.From the DE 20 2005 004 456 U1 For example, a gripping device with a longitudinally displaceable guided in a housing magnet is known. If the magnet is pushed out of the housing, ferromagnetic workpieces can be gripped. By pulling the magnet into the housing, the adhering workpiece can be released, wh

**[p0002]**

erein the end face of the housing serves as a scraper for the workpiece. A switchable permanent magnet for use in a load lifting system having the features of the preamble of claim 1 is in DE 15 14 732 A described. The EP 0 129 127 A1 describes a magnetic gripper with switchable magnet, comprising a permanent magnet and a displaceable armature. In the known gripping devices there is room for optimizations, in particular with regard to picking up and depositing a workpiece.

**[p0003]**

Der Erfindung liegt die Aufgabe zugrunde, eine Greifvorrichtung mit hohen HaltekrÃ¤ften und insbesondere auch geringen ResthaltekrÃ¤ften zu schaffen. Ein geringer Krafteinsatz beim Aktivieren/Deaktivieren der Greifvorrichtung ist wÃ¼nschenswert.The invention has for its object to provide a gripping device with high holding forces and in particular low residual holding forces. A small amount of force in activating / deactivating the gripping device is desirable. Die Erfindung lÃ¶st die Aufgabe durch eine Greifvorrichtung mit den Merkmalen des Anspruchs 1. Die Greifvorrichtung dient zum Greifen und insbesondere auch zum Anheben von ferromagnetischen GegenstÃ¤nden mit einem Magneten. Der Magnet ist durch einen Aktor zwischen einer Aktivstellung zum Greifen der GegenstÃ¤nde und einer Passivstellung zum Loslassen verlagerbar.The invention solves the problem by a gripping device having the features of claim 1. The gripping device is used for gripping and in particular for lifting ferromagnetic objects with a magnet. The magnet is displaceable by an actuator between an active position for gripping the objects and a passive position for releasing.

**[p0004]**

Bei der Greifvorrichtung ist ein Polschuh mit einer AnlageflÃ¤che fÃ¼r die zu greifenden GegenstÃ¤nde vorgesehen, wobei der Polschuh ein ferromagnetisches Material aufweist, und wobei der Magnet den Polschuh bezÃ¼glich einer LÃ¤ngsachse nach auÃen zumindest teilweise umgibt und der Magnet relativ zum Polschuh entlang der LÃ¤ngsachse verlagerbar ist.In the gripping device, a pole shoe is provided with a contact surface for the objects to be gripped, wherein the pole piece comprises a ferromagnetic material, and wherein the magnet at least partially surrounds the pole piece outwardly relative to a longitudinal axis and the magnet is displaceable relative to the pole piece along the longitudinal axis. Dies hat den Vorteil, dass vergleichsweise hohe MagnetkrÃ¤fte zur Handhabung schwerer Lasten erreicht werden kÃ¶nnen. Durch Vorsehen der AnlageflÃ¤che am Polschuh kann die Greifvorrichtung durch Verlagerung des Magnets von der Aktivstellung in die Passivstellung verbracht werden, so dass gegriffene GegenstÃ¤nde auf einfache Weise losgelassen werden kÃ¶nnen.This has the advantage that comparatively high magnetic forces for handling heavy loads can be achieved. By providing the contact surface on the pole piece, the gripping device can be moved by shifting the magnet from the active position to the passive position, so that gripped objects can be released in a simple manner.

**[p0005]**

Der Magnet fÃ¼hrt bei Verlagerung zwischen der Aktivstellung und der Passivstellung um die LÃ¤ngsachse eine Drehbewegung durch. Damit ist eine Hubbewegung mit einer Drehbewegung kombiniert. Zwischen Aktivstellung und Passivstellung fÃ¼hrt der Magnet eine Drehbewegung von maximal 90Â° um die LÃ¤ngsachse aus, entlang der der Magnet verlagerbar ist. Dadurch kÃ¶nnen ResthaltekrÃ¤fte reduziert werden, insbesondere dann, wenn der Polschuh einen ggf. durch eine Einlage gefÃ¼llten Spalt aufweist. Zum Erreichen einer Drehbewegung kann der Magnet in einer, insbesondere am Polschuh oder am GehÃ¤use der Greifvorrichtung ausgebildeten, KulissenfÃ¼hrung oder durch einen Drehmotor gefÃ¼hrt sein. The magnet performs at displacement between the active position and the passive position about the longitudinal axis by a rotary motion. This combines a lifting movement with a rotary movement. Between active position and passive position of the magnet performs a rotational movement of a maximum of 90 Â° about the longitudinal axis, along which the magnet is displaced. As a result, residual holding forces can be reduced, in particular if the pole shoe has a gap possibly filled by an insert. To achieve a rotational movement of the magnet may be performed in a, in particular on the pole piece or on the housing of the gripping device formed, slotted guide or by a rotary motor.

**[p0006]**

Der Polschuh ist vorzugsweise aus ferromagnetischem Material ausgebildet. Dieses Material sollte eine mÃ¶glichst geringe magnetische Remanenz aufweisen, um ein zeitnahes Ablegen oder Aufnehmen von GegenstÃ¤nden zu ermÃ¶glichen.The pole piece is preferably formed from ferromagnetic material. This material should have the lowest possible magnetic remanence in order to enable a timely depositing or picking up objects. Der Magnet ist vorzugsweise als Permanentmagnet ausgebildet. In Bezug auf den Magneten ist zudem denkbar, dass dieser mehrere Nordpole und mehrere SÃ¼dpole aufweist.The magnet is preferably designed as a permanent magnet. In terms of the magnet is also conceivable that this has several north poles and several south poles. Der Magnet umgibt den Polschuh bezÃ¼glich einer LÃ¤ngsachse nach auÃen zumindest teilweise. Dabei ist denkbar, dass der Magnet den Polschuh Ã¼ber zumindest 30 Prozent, vorzugsweise Ã¼ber zumindest 50 Prozent, seines Mantels oder AuÃenumfangs umgibt. Da der Polschuh entlang der LÃ¤ngsachse eine grÃ¶Ãere HÃ¶he als der Magnet aufweisen kann, sind die voranstehenden Angaben nicht zwingend mit einem Umgeben der AuÃenflÃ¤che des Polschuhs gleichzusetzen. Im Rahmen einer bevorzugten Ausgestaltung kann der Magnet den Polschuh vollstÃ¤ndig umgeben, beispielsweise im Falle eines kreiszylindrischen Polschuhs Ã¼ber einen Winkel von 360 Â°(Grad).The magnet surrounds the pole piece at least partially outward with respect to a longitudinal axis. It is conceivable that the magnet surrounds the pole piece over at least 30 percent, preferably over at least 50

**[p0006]**

percent, of its jacket or outer circumference. Since the pole piece along the longitudinal axis may have a greater height than the magnet, the above information is not necessarily equated with surrounding the outer surface of the pole piece. Within the scope of a preferred embodiment, the magnet can completely surround the pole piece, for example in the case of a circular-cylindrical pole shoe over an angle of 360 Â° (degrees).

**[p0007]**

Im Konkreten weist der Magnet eine Magnetisierungsrichtung von wenigstens einem Nordpol zu wenigstens einem SÃ¼dpol auf.Concretely, the magnet has a magnetization direction from at least one north pole to at least one south pole. Die Magnetisierungsrichtung ist eine Vorzugsrichtung, entlang welcher im rÃ¤umlichen Mittel die Feldlinien von Nordpol nach SÃ¼dpol verlaufen.The direction of magnetization is a preferred direction along which the field lines run from the north pole to the south pole in the spatial average. Im Rahmen einer bevorzugten Ausgestaltung kann die Magnetisierungsrichtung orthogonal zur LÃ¤ngsachse verlaufen. Damit lÃ¤sst sich mithilfe des Polschuhs Ã¼ber eine definierte FlÃ¤che eine hohe Kraftwirkung erreichen.In a preferred embodiment, the magnetization direction can be orthogonal to the longitudinal axis. This can be achieved using the pole piece over a defined area a high force effect. Der Polschuh kann parallel zu der LÃ¤ngsachse oder entlang der LÃ¤ngsachse in mehrere Bestandteile, vorzugsweise in zwei Bestandteile, geteilt sein und die Bestandteile kÃ¶nnen voneinander beabstandet sein. So kann zwischen den Bestandteilen ein Spalt, beispielsweise ein Luftspalt, vorgesehen sein. Durch diese Ausgestaltung mit einer Beabstandung oder einem Spalt, wodurch in Aktivstellung des Magneten dessen Magnetfeld weitergeleitet wird, ist beim Deaktivieren der Greifvorrichtung vergleichsweise wenig Energie erforderlich. Dabei werden keine oder allenfalls vernachlÃ¤ssigbar geringe ResthaltekrÃ¤fte erzeugt. Eine mehrteilige Ausgestaltung des Polschuhs ist denkbar. Im

**[p0007]**

Falle zweier Bestandteile kÃ¶nnen diese zwei HÃ¤lften des Polschuhs bilden.The pole piece can be divided into several components, preferably two components, parallel to the longitudinal axis or along the longitudinal axis, and the components can be spaced apart from one another. So can between the Components a gap, for example, an air gap, be provided. By this configuration with a spacing or a gap, whereby the magnetic field is forwarded in the active position of the magnet, when disabling the gripping device comparatively little energy is required. No or at most negligible residual power is generated. A multi-part design of the pole piece is conceivable. In the case of two components, these can form two halves of the pole piece.

**[p0008]**

In vorteilhafter Weise kann die Beabstandung zwischen den Bestandteilen durch eine Einlage aus nicht ferromagnetischem Material ausgefÃ¼llt sein. Auf diese Weise ist die Beabstandung oder der Spalt zwischen den Bestandteilen vor UmwelteinflÃ¼ssen geschÃ¼tzt, wobei in Aktivstellung des Magneten dessen Magnetfeld weiterhin weitergeleitet wird. Als nicht ferromagnetisches Material kann beispielsweise Kunststoff oder Aluminium dienen. Eine einteilige Ausgestaltung des Polschuhs ist denkbar (Sandwichbauweise), so dass der Polschuh als ein Bauteil vorzugsweise mit durchgehender AuÃenflÃ¤che gehandhabt werden kann.Advantageously, the spacing between the components may be filled by an insert of non-ferromagnetic material. In this way, the spacing or the gap between the components is protected from environmental influences, wherein in the active position of the magnet whose magnetic field is further forwarded. As a non-ferromagnetic material can serve for example plastic or aluminum. A one-piece design of the pole piece is conceivable (sandwich construction), so that the pole piece can be handled as a component, preferably with a continuous outer surface.

**[p0009]**

Im Konkreten kann die Greifvorrichtung ein GehÃ¤use aufweisen. Der Polschuh kann durch mindestens ein Zwischenelement, das ein nicht ferromagnetisches Material aufweist, vom GehÃ¤use getrennt sein. Damit ist der Polschuh nicht unmittelbar, sondern mittels eines Zwischenelements am GehÃ¤use befestigt. Dadurch sind Polschuh und GehÃ¤use voneinander magnetisch entkoppelt, so dass eine ggf. auf das GehÃ¤use wirkende Magnetkraft nicht oder nur in vernachlÃ¤ssigbarer Weise auf den Polschuh einwirkt. Das GehÃ¤use kann auch als âMagnetgehÃ¤useâ bezeichnet werden.Specifically, the gripping device may comprise a housing. The pole piece may be separated from the housing by at least one intermediate element comprising a non-ferromagnetic material. Thus, the pole piece is not attached directly, but by means of an intermediate element on the housing. As a result, pole piece and housing are magnetically decoupled from one another, so that any magnetic force acting on the housing does not or only negligibly acts on the pole piece. The housing may also be referred to as a "magnet housing".

**[p0010]**

Das GehÃ¤use kann den Magnet und den Polschuh zumindest teilweise aufnehmen. UnabhÃ¤ngig davon kann das GehÃ¤use an seiner MantelflÃ¤che Nuten zur Befestigung, beispielsweise von Sensoren, aufweisen. Das GehÃ¤use kann aus nicht ferromagnetischem Material ausgebildet sein, beispielsweise Aluminium oder Kunststoff.The housing may at least partially accommodate the magnet and the pole piece. Regardless, the housing on its lateral surface grooves for attachment, for example, sensors have. The housing may be formed of non-ferromagnetic material, such as aluminum or plastic. Im Rahmen einer bevorzugten Ausgestaltung kann sich der Polschuh in seinem Querschnitt entlang der LÃ¤ngsachse von der AnlageflÃ¤che weg verjÃ¼ngen. Auf diese Weise lÃ¤sst sich eine hohe Magnetkraft zur Handhabung schwerer Lasten erreichen, wobei durch die VerjÃ¼ngung beim Deaktivieren der Greifvorrichtung vergleichsweise wenig Energie erforderlich ist. Dabei werden keine oder allenfalls vernachlÃ¤ssigbar geringe ResthaltekrÃ¤fte erzeugt. Der Polschuh kann infolge der VerjÃ¼ngung kegelfÃ¶rmig (kreisfÃ¶rmiger Querschnitt) oder trapezfÃ¶rmig (rechteckiger Querschnitt) ausgebildet sein.In the context of a preferred embodiment, the pole piece can taper in its cross section along the longitudinal axis of the contact surface away. In this way, a high magnetic force for handling heavy loads can be achieved, whereby comparatively little energy is required by the taper when disabling the gripping device. No or at most negligible residual power is generated. The pole piece may be conical (circular cross section) or tra

**[p0010]**

pezoidal (rectangular cross section) due to the taper.

**[p0011]**

Alternativ oder ergÃ¤nzend zur voranstehend beschriebenen QuerschnittsverjÃ¼ngung kann am Polschuh entlang der LÃ¤ngsachse von der AnlageflÃ¤che weg eine MaterialÃ¤nderung von einem ferromagnetischen Material zu einem nicht ferromagnetischen Material ausgebildet sein. Im Konkreten kann der Polschuh â bezogen auf die AnlageflÃ¤che â einen proximalen Abschnitt bestehend aus einem ferromagnetischen Material und einen sich â an der von der AnlageflÃ¤che abgewandten Seite des proximalen Abschnitts â an den proximalen Abschnitt anschlieÃenden distalen Abschnitt aus einem nicht ferromagnetischen Material aufweisen, beispielsweise aus Aluminium oder Kunststoff.Alternatively or in addition to the cross-sectional tapering described above, a material change from a ferromagnetic material to a non-ferromagnetic material can be formed on the pole shoe along the longitudinal axis away from the contact surface. Specifically, the pole piece may have a proximal section consisting of a ferromagnetic material and a distal section of a non-ferromagnetic material adjoining the proximal section, for example, made of a ferromagnetic material and on the side of the proximal section facing away from the contact surface Aluminum or plastic.

**[p0012]**

Vorteilhafterweise kann der Polschuh an der AnlageflÃ¤che einen Reibring aufweisen. Damit ist eine Relativbewegung zwischen dem gegriffenen Gegenstand und dem Polschuh des Magneten weitestgehend verhindert.Advantageously, the pole piece can have a friction ring on the contact surface. For a relative movement between the gripped object and the pole piece of the magnet is largely prevented. Im Konkreten kann der Magnet als Ring, insbesondere als Kreisring, als Kreisabschnitt oder Bogenabschnitt, als Hufeisenmagnet oder als Stabmagnet ausgebildet sein. Damit kann die Greifvorrichtung auf die zu handhabenden GegenstÃ¤nde abgestimmt werden. Der Magnet kann an einer Magnethalterung befestigt sein, die zur Verlagerung des Magneten, beispielsweise mittels eines Aktors, dienen kann.Specifically, the magnet may be formed as a ring, in particular as a circular ring, as a circular section or arc section, as a horseshoe magnet or as a bar magnet. Thus, the gripping device can be matched to the objects to be handled. The magnet can be fastened to a magnet holder which can serve to displace the magnet, for example by means of an actuator.

**[p0013]**

In vorteilhafter Weise kann der Magnet in der Aktivstellung an oder nahe einer Ebene angeordnet sein, in der die AnlageflÃ¤che verlÃ¤uft. MagnetkrÃ¤fte kÃ¶nnen dann durch den Polschuh auf den zu greifenden Gegenstand ausgeÃ¼bt werden. Mit anderen Worten kann der Magnet in Aktivstellung in einem bezogen auf die AnlageflÃ¤che proximalen Abschnitt des Polschuhs angeordnet sein. Bei dem proximalen Abschnitt kann es sich â entlang der LÃ¤ngsachse gesehen â um einen an die AnlageflÃ¤che angrenzenden Teil des Polschuhs handeln. An der von der AnlageflÃ¤che abgewandten Seite des proximalen Abschnitts kann sich ein distaler Abschnitt des Polschuhs anschlieÃen. Dabei kann es sich um einen zweiten Teil oder eine zweite HÃ¤lfte des Polschuhs handeln.Advantageously, the magnet can be arranged in the active position at or near a plane in which the contact surface extends. Magnetic forces can then be exerted by the pole piece on the object to be gripped. In other words, the magnet can be arranged in the active position in a relation to the contact surface proximal portion of the pole piece. The proximal section may be - viewed along the longitudinal axis - a part of the pole shoe which adjoins the contact surface. On the side of the proximal section facing away from the abutment surface, a distal section of the pole shoe may follow. It may be a second part or a second half of the pole piece.

**[p0014]**

Vorteilhafter Weise kann bei Vorliegen der Aktivstellung das der AnlageflÃ¤che zugewandte untere Ende des Magneten von einer Ebene, in der die AnlageflÃ¤che verlÃ¤uft, um einen Mindestabstand beabstandet sein. Dadurch wird ein Abstandsspalt, zum Beispiel ein Luftspalt, gebildet. Dies erleichtert ein Loslassen eines Gegenstands von der Greifvorrichtung. Es kann ein Einlegeelement aus nicht ferromagnetischem Material, insbesondere aus Aluminium oder Kunststoff, im Abstandsspalt vorgesehen sein (Abstandshalteplatte). Dadurch ist der Abstandsspalt durch ein Einlegeelement gefÃ¼llt, so dass auch einzelne Abschnitte eines ergriffenen Gegenstands nicht bis zum Magneten gelangen kÃ¶nnen. Dies trÃ¤gt zu einem zuverlÃ¤ssigen Loslassen von GegenstÃ¤nden bei. Das Einlegeelement kann einen scheibenfÃ¶rmigen Querschnitt aufweisen.Advantageously, in the presence of the active position, the lower end of the magnet facing the contact surface can be spaced from a plane in which the contact surface extends by a minimum distance. As a result, a clearance gap, for example an air gap, is formed. This facilitates releasing an object from the gripping device. It may be an insert element made of non-ferromagnetic material, in particular of aluminum or plastic, be provided in the clearance gap (spacer plate). As a result, the gap gap is filled by an insert element, so that individual sections of a seized The object can not reach the magnet. This contributes to a reliable letting go of objects. The insert element may have a disk-shaped cross section.

**[p0015]**

GemÃ¤Ã einer bevorzugten Ausgestaltung kann der Magnet in der Passivstellung von der AnlageflÃ¤che weg verlagert sein, so dass der Magnet den Polschuh nicht oder nur an einem distalen Abschnitt des Polschuhs umgibt. Dabei kann es sich â entlang der LÃ¤ngsachse gesehen â um einen "oberen Teil" oder die "obere HÃ¤lfte" des Polschuhs handeln. Ein Loslassen eines Gegenstands von der Greifvorrichtung ist damit erleichtert.According to a preferred embodiment, the magnet may be displaced away from the contact surface in the passive position, so that the magnet does not surround the pole piece or only at a distal portion of the pole piece. It may be - seen along the longitudinal axis - to an "upper part" or the "upper half" of the pole piece. Releasing an object from the gripping device is thus facilitated. ZweckmÃ¤Ãigerweise kann der Aktor als pneumatische Kolben-Zylinder-Einheit oder als elektrischer Antrieb ausgebildet sein. Der elektrische Antrieb kann als Elektromotor oder als Hubmagnet (Elektromagnet/Spule) ausgefÃ¼hrt sein. Dies ist von Vorteil, wenn keine Druckluft/kein Unterdruck vorhanden ist. Ein netzunabhÃ¤ngiger Betrieb ist mÃ¶glich. Bei einer pneumatischen Kolben-Zylinder-Einheit kann an der Greifvorrichtung auf elektrische Energie verzichtet werden.Conveniently, the actuator can be designed as a pneumatic piston-cylinder unit or as an electric drive. The electric drive can be designed as an electric motor or as a solenoid (solenoid / coil). This is an advantage if there is no compressed air / no vacuum. Off-grid operation is possible. In a pneumatic piston-cyli

**[p0015]**

nder unit, electrical energy can be dispensed with at the gripping device.

**[p0016]**

Der Polschuh kann insbesondere als ein sich entlang einer MittellÃ¤ngsachse erstreckender KÃ¶rper ausgebildet sein. Die MittellÃ¤ngsachse kann parallel zur LÃ¤ngsachse ausgebildet sein. Dabei kann der Polschuh einen kreisfÃ¶rmigen oder elliptischen Querschnitt aufweisen. Ebenfalls denkbar ist, dass der Polschuh einen rechteckfÃ¶rmigen oder quadratischen Querschnitt aufweist.The pole piece can in particular be designed as a body extending along a central longitudinal axis. The central longitudinal axis may be formed parallel to the longitudinal axis. In this case, the pole piece may have a circular or elliptical cross section. It is also conceivable that the pole piece has a rectangular or square cross-section. Die Erfindung wird im Folgenden anhand der Figuren nÃ¤her erlÃ¤utert. Es zeigen:The invention will be explained in more detail below with reference to FIGS. Show it: 1, 2 in schematischen Darstellungen eine erste AusfÃ¼hrungsform einer Greifvorrichtung; 1 . 2 in schematic representations, a first embodiment of a gripping device;

**[p0017]**

3, 4 in schematischen Darstellungen eine zweite AusfÃ¼hrungsform einer Greifvorrichtung; und 3 . 4 in schematic representations, a second embodiment of a gripping device; and 5, 6 in schematischen Darstellungen eine dritte AusfÃ¼hrungsform einer Greifvorrichtung. 5 . 6 in schematic representations, a third embodiment of a gripping device. Dabei zeigt die jeweils erste Figur (1, 3 und 5) die Aktivstellung des Magneten und die jeweils zweite Figur (2, 4 und 6) die Passivstellung.The first figure ( 1 . 3 and 5 ) the active position of the magnet and the respective second figure ( 2 . 4 and 6 ) the passive position. 1 und 2 zeigen eine Greifvorrichtung zum Greifen und Anheben von ferromagnetischen GegenstÃ¤nden, die insgesamt mit dem Bezugszeichen 10 bezeichnet ist. 1 and 2 show a gripping device for gripping and lifting of ferromagnetic objects, denoted overall by the reference numeral 10 is designated. Die Greifvorrichtung 10 weist einen Magneten 12 auf, der durch einen Aktor (nicht dargestellt) zwischen einer Aktivstellung (siehe 1) und einer Passivstellung (siehe 2) verlagerbar ist.The gripping device 10 has a magnet 12 on, by an actuator (not shown) between an active position (see 1 ) and a passive position (see 2 ) is displaceable.

**[p0018]**

Die Greifvorrichtung 10 weist einen Polschuh 16 mit einer AnlageflÃ¤che 18 fÃ¼r die zu greifenden GegenstÃ¤nde auf. Der Polschuh 16 weist ein ferromagnetisches Material auf.The gripping device 10 has a pole piece 16 with a contact surface 18 for the objects to be picked up. The pole piece 16 has a ferromagnetic material. Der Magnet 12 umgibt den Polschuh 16 bezÃ¼glich einer LÃ¤ngsachse 20 nach auÃen. Der Magnet 12 ist relativ zum Polschuh 16 entlang der LÃ¤ngsachse 20 verlagerbar.The magnet 12 surrounds the pole piece 16 with respect to a longitudinal axis 20 outward. The magnet 12 is relative to the pole piece 16 along the longitudinal axis 20 displaced. Der Magnet 12 weist eine Magnetisierungsrichtung 22 von wenigstens einem Nordpol 24 zu wenigstens einem SÃ¼dpol 26 auf. Die Magnetisierungsrichtung 22 verlÃ¤uft orthogonal zur LÃ¤ngsachse 20.The magnet 12 has a magnetization direction 22 from at least one north pole 24 to at least one south pole 26 on. The magnetization direction 22 runs orthogonal to the longitudinal axis 20 ,

**[p0019]**

Der Polschuh 16 ist parallel zu der LÃ¤ngsachse 20 in zwei Bestandteile oder HÃ¤lften 28, 30 geteilt und die Bestandteile 28, 30 sind voneinander beabstandet. Zwischen den Bestandteilen 28, 30 befindet sich ein Spalt oder eine Beabstandung 32.The pole piece 16 is parallel to the longitudinal axis 20 in two parts or halves 28 . 30 divided and the ingredients 28 . 30 are spaced from each other. Between the ingredients 28 . 30 there is a gap or a gap 32 , Die Beabstandung 32 zwischen den Bestandteilen 28, 30 ist durch eine Einlage 34 aus nicht ferromagnetischem Material ausgefÃ¼llt. Dabei kann der Polschuh 16 einteilig ausgebildet sein (Sandwichbauweise). The spacing 32 between the components 28 . 30 is through a deposit 34 made of non-ferromagnetic material. In this case, the pole piece 16 be formed in one piece (sandwich construction). Der Magnet 12 ist als Kreisring ausgebildet. Der Magnet 12 ist in der Aktivstellung (siehe 1) an oder nahe einer Ebene angeordnet, in der die AnlageflÃ¤che 18 verlÃ¤uft. Mit anderen Worten kann sich der Magnet 12 in der Aktivstellung in einem bezogen auf die AnlageflÃ¤che 18 proximalen Abschnitt 36 befinden. The magnet 12 is designed as a circular ring. The magnet 12 is in the active position (see 1 ) are arranged at or near a plane in which the contact surface 18 runs. In other words, the magnet can 12 in the active position in a relative to the contact surface 18 proximal section 36 are located.

**[p0020]**

Im Konkreten kann bei Vorliegen der Aktivstellung das der AnlageflÃ¤che 18 zugewandte untere Ende des Magneten 12 von der Ebene, in der die AnlageflÃ¤che 18 verlÃ¤uft, um einen Mindestabstand beabstandet sein.Concretely, in the presence of the active position of the contact surface 18 facing lower end of the magnet 12 from the plane in which the contact surface 18 runs, spaced by a minimum distance. Der Magnet 12 ist in der Passivstellung (siehe 2) von der AnlageflÃ¤che 18 weg verlagert, so dass der Magnet 12 den Polschuh 16 nicht oder nur an einem distalen Abschnitt 38 des Poolschuhs 16 umgibt.The magnet 12 is in the passive position (see 2 ) from the contact surface 18 shifted away, leaving the magnet 12 the pole piece 16 not or only at a distal section 38 of the pool shoe 16 surrounds. Der Magnet 12 kann bei Verlagerung zwischen der Aktivstellung und der Passivstellung um die LÃ¤ngsachse 20 eine Drehbewegung durchfÃ¼hren (nicht dargestellt).The magnet 12 can with displacement between the active position and the passive position about the longitudinal axis 20 perform a rotary motion (not shown).

**[p0021]**

Der Polschuh 16 weist einen kreisfÃ¶rmigen Querschnitt auf und ist als senkrechter Kreiszylinder ausgebildet.The pole piece 16 has a circular cross-section and is formed as a vertical circular cylinder. 3 und 4 zeigen eine zweite AusfÃ¼hrungsform einer Greifvorrichtung 10' zum Greifen und Anheben von ferromagnetischen GegenstÃ¤nden. 3 and 4 show a second embodiment of a gripping device 10 ' for gripping and lifting ferromagnetic objects. Die zweite AusfÃ¼hrungsform entspricht zu weiten Teilen der ersten AusfÃ¼hrungsform, so dass auf die dortige Beschreibung verwiesen wird. Gleiche oder funktional gleiche Komponenten sind mit identischen Bezugszeichen versehen.The second embodiment corresponds to much of the first embodiment, so that reference is made to the description there. The same or functionally identical components are provided with identical reference numerals. Abweichend von der ersten AusfÃ¼hrungsform weist die zweite AusfÃ¼hrungsform einen ringfÃ¶rmigen Magneten 12' auf, der in Richtung der LÃ¤ngsachse gesehen einen rechteckigen Querschnitt aufweist. Unlike the first embodiment, the second embodiment has an annular magnet 12 ' on, seen in the direction of the longitudinal axis has a rectangular cross-section.

**[p0022]**

Der Polschuh 16' weist einen rechteckigen Querschnitt auf und ist als senkrechter Zylinder mit rechteckigem Querschnitt ausgebildet. Der Polschuh 16' ist parallel zu der LÃ¤ngsachse 20 in zwei Bestandteile 28', 30' geteilt und die Bestandteile 28', 30' sind voneinander beabstandet. Die Beabstandung oder der Spalt 32' ist durch eine Einlage 34' aus nicht ferromagnetischem Material ausgefÃ¼llt.The pole piece 16 ' has a rectangular cross section and is designed as a vertical cylinder with a rectangular cross section. The pole piece 16 ' is parallel to the longitudinal axis 20 in two parts 28 ' . 30 ' divided and the ingredients 28 ' . 30 ' are spaced from each other. The spacing or the gap 32 ' is through a deposit 34 ' made of non-ferromagnetic material. Die erste und die zweite AusfÃ¼hrungsform der Greifvorrichtung kÃ¶nnen weitere Komponenten umfassen, die in den AnsprÃ¼chen, insbesondere in den AnsprÃ¼chen 6, 7, 8 und 14, sowie im allgemeinen Beschreibungsteil beschrieben sind.The first and second embodiments of the gripping device may comprise further components which are described in the claims, in particular in claims 6, 7, 8 and 14, as well as in the general description part.

**[p0023]**

5 und 6 zeigen eine dritte AusfÃ¼hrungsform einer Greifvorrichtung 10'' zum Greifen und Anheben von ferromagnetischen GegenstÃ¤nden. 5 and 6 show a third embodiment of a gripping device 10 '' for gripping and lifting ferromagnetic objects. Die dritte AusfÃ¼hrungsform entspricht zu weiten Teilen der ersten AusfÃ¼hrungsform, so dass auf die dortige Beschreibung verwiesen wird. Gleiche oder funktional gleiche Komponenten sind mit identischen Bezugszeichen versehen.The third embodiment corresponds to much of the first embodiment, so that reference is made to the description there. The same or functionally identical components are provided with identical reference numerals. Die Greifvorrichtung 10'' weist ein GehÃ¤use 40 auf. Das GehÃ¤use 40 nimmt den Magnet 12 und den Polschuh 16 in seinem Inneren auf. Der Polschuh 16'' ist durch mindestens ein Zwischenelement (nicht dargestellt), das ein nicht ferromagnetisches Material aufweist, vom GehÃ¤use 40 getrennt.The gripping device 10 '' has a housing 40 on. The housing 40 take the magnet 12 and the pole piece 16 in its interior. The pole piece 16 '' is by at least one intermediate element (not shown), which has a non-ferromagnetic material from the housing 40 separated.

**[p0024]**

Der Polschuh 16'' verjÃ¼ngt sich in seinem Querschnitt entlang der LÃ¤ngsachse 20 von der AnlageflÃ¤che 18 weg. Der Polschuh 16'' weist einen kreisfÃ¶rmigen Querschnitt auf und ist kegelfÃ¶rmig ausgebildet.The pole piece 16 '' tapers in its cross section along the longitudinal axis 20 from the contact surface 18 path. The pole piece 16 '' has a circular cross-section and is cone-shaped. Bei Vorliegen der Aktivstellung (siehe 5) ist das der AnlageflÃ¤che 18 zugewandte untere Ende des Magneten 12 von der Ebene, in der die AnlageflÃ¤che 18 verlÃ¤uft, um einen Mindestabstand beabstandet sein. Es wird ein Abstandsspalt, zum Beispiel ein Luftspalt, gebildet. Ein Einlegeelement 39 aus nicht ferromagnetischem Material ist im Abstandsspalt angeordnet (Abstandshalteplatte). Das Einlegeelement 39 weist einen scheibenfÃ¶rmigen Querschnitt auf.In the presence of the active position (see 5 ) is that of the contact surface 18 facing lower end of the magnet 12 from the plane in which the contact surface 18 runs, spaced by a minimum distance. A clearance gap, for example an air gap, is formed. An insert element 39 made of non-ferromagnetic material is arranged in the gap (spacer plate). The insert element 39 has a disc-shaped cross-section.

**[p0025]**

Der Magnet 12 ist als Kreisring ausgebildet und an einer Magnethalterung 42 zur Verlagerung des Magneten 12 befestigt.The magnet 12 is designed as a circular ring and a magnetic holder 42 for shifting the magnet 12 attached. Der Magnet 12 ist durch einen Aktor 14 zwischen der Aktivstellung zum Greifen der GegenstÃ¤nde (siehe 5) und einer Passivstellung (siehe 6) verlagerbar. Der Aktor 14 ist als pneumatische Kolben-Zylinder-Einheit 41 ausgebildet. Die Magnethalterung 42 kann als Kolben dienen, der im Zylinder 44 verlagert werden kann. The magnet 12 is by an actor 14 between the active position for gripping the objects (see 5 ) and a passive position (see 6 ) relocatable. The actor 14 is as a pneumatic piston-cylinder unit 41 educated. The magnetic holder 42 can serve as a piston in the cylinder 44 can be relocated. Zur BetÃ¤tigung des Kolbens sind pneumatische DruckanschlÃ¼sse 46, 48 vorgesehen. Durch Beaufschlagen der DruckanschlÃ¼sse 46, 48 mit Druckluft oder Unterdruck lÃ¤sst sich der Kolben im Zylinder 44 verlagern. Dadurch kann der Magnet 12 in die Aktivstellung oder die Passivstellung verbracht werden.To operate the piston are pneumatic pressure connections 46 . 48 intended. By applying the pressure connections 46 . 48 With compressed air or negative pressure, the piston can be in the cylinder 44 relocate. This can cause the magnet 12 be moved to the active position or the passive position.

**[p0026]**

Der Polschuh 16'' kann parallel zur LÃ¤ngsachse 20 in mehrere Bestandteile geteilt sein und die Bestandteile kÃ¶nnen voneinander beabstandet sein. Die Beabstandung oder der Spalt kann durch eine Einlage aus nicht ferromagnetischem Material ausgefÃ¼llt sein.The pole piece 16 '' can be parallel to the longitudinal axis 20 be divided into several components and the components may be spaced apart. The spacing or gap may be filled by an insert of non-ferromagnetic material.

## Classifications

- B65G47/92
- B65G47/92
- B65G47/92
- B65G47/92
- B66C1/04
- B66C1/04
- H01F7/0257
- H01F7/0257
- H01F7/04
- H01F7/04
- H01F7/04
- H01F7/04

## Cited patent documents

- [DE-102012215797-A1](https://patents.google.com/patent/DE102012215797A1/en) — SEA
- [DE-1514732-A1](https://patents.google.com/patent/DE1514732A1/en) — SEA
- [DE-202005004456-U1](https://patents.google.com/patent/DE202005004456U1/en) — SEA
- [EP-0129127-A1](https://patents.google.com/patent/EP0129127A1/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
