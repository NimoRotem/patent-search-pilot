# 20. Control method for electromagnetic chuck device, and electromagnetic chuck device

- **Archive rank:** 20 of 50
- **Publication:** [JP-2018149648-A](https://patents.google.com/patent/JP2018149648A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/063681096/publication/JP2018149648A?q=pn%3DJP2018149648A)
- **Publication date:** 2018-09-27
- **Filing date:** 2017-03-14
- **Earliest priority:** 2017-03-14
- **Family:** 63681096
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery

## Parties

- **Applicant / assignee:** JTEKT CORP

## Abstract

PROBLEM TO BE SOLVED: To provide a control method for an electromagnetic chuck device that is able to exhibit sufficient gripping force without deforming a work piece in a case where a work piece is gripped on a face plate by means of attraction using magnetic force, and to provide an electromagnetic chuck device.SOLUTION: A control method for an electromagnetic chuck device 60 attracts a work piece W by magnetic pole parts 71 to 78. The electromagnetic chuck device comprises at least three pairs of attraction support members 62, 63. Each pair of attraction support members are arranged such that a border between adjacent magnetic pole parts are sandwiched by these members. The control method comprises: a first step S20 in which each pair of attraction support members in which second flat faces 62c, 63c are in contact with a target attraction face Wa is checked while first flat faces 62a, 63a are respectively kept fixed to the respective upper faces of the corresponding adjacent magnetic pole parts; and a second step S40 in which respective magnetic pole parts to which each corresponding pair of attraction support members 62, 63 whose contacts with the target attraction face Wa have been checked is controlled by a control device 64 to generate a magnetic force, and the second flat faces 62c, 63c and the target attraction face Wa are attracted.SELECTED DRAWING: Figure 3

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/0e/2f/16/737bae791350e5/2018149648-3.png)

![Sketch 1 for JP-2018149648-A](https://patentimages.storage.googleapis.com/0e/2f/16/737bae791350e5/2018149648-3.png)

[Sketch 2](https://patentimages.storage.googleapis.com/15/38/4b/dd920716c4c4e2/2018149648-4.png)

![Sketch 2 for JP-2018149648-A](https://patentimages.storage.googleapis.com/15/38/4b/dd920716c4c4e2/2018149648-4.png)

[Sketch 3](https://patentimages.storage.googleapis.com/b9/df/c0/08e166595e786a/2018149648-5.png)

![Sketch 3 for JP-2018149648-A](https://patentimages.storage.googleapis.com/b9/df/c0/08e166595e786a/2018149648-5.png)

[Sketch 4](https://patentimages.storage.googleapis.com/5e/09/83/d860e6b2319fea/2018149648-6.png)

![Sketch 4 for JP-2018149648-A](https://patentimages.storage.googleapis.com/5e/09/83/d860e6b2319fea/2018149648-6.png)

[Sketch 5](https://patentimages.storage.googleapis.com/93/59/8a/52dd64ed6fa70b/2018149648-7.png)

![Sketch 5 for JP-2018149648-A](https://patentimages.storage.googleapis.com/93/59/8a/52dd64ed6fa70b/2018149648-7.png)

[Sketch 6](https://patentimages.storage.googleapis.com/cd/8d/94/a442b8bc76d409/2018149648-8.png)

![Sketch 6 for JP-2018149648-A](https://patentimages.storage.googleapis.com/cd/8d/94/a442b8bc76d409/2018149648-8.png)

[Sketch 7](https://patentimages.storage.googleapis.com/f8/e7/f7/0bc034b4a4dd0e/2018149648-9.png)

![Sketch 7 for JP-2018149648-A](https://patentimages.storage.googleapis.com/f8/e7/f7/0bc034b4a4dd0e/2018149648-9.png)

[Sketch 8](https://patentimages.storage.googleapis.com/f7/a8/cc/cf0eeede415d7c/2018149648-10.png)

![Sketch 8 for JP-2018149648-A](https://patentimages.storage.googleapis.com/f7/a8/cc/cf0eeede415d7c/2018149648-10.png)

[Sketch 9](https://patentimages.storage.googleapis.com/14/fa/3a/416c7ead33c1ea/2018149648-11.png)

![Sketch 9 for JP-2018149648-A](https://patentimages.storage.googleapis.com/14/fa/3a/416c7ead33c1ea/2018149648-11.png)

[Sketch 10](https://patentimages.storage.googleapis.com/27/e2/00/28d5b1d00639a4/2018149648-12.png)

![Sketch 10 for JP-2018149648-A](https://patentimages.storage.googleapis.com/27/e2/00/28d5b1d00639a4/2018149648-12.png)

[Sketch 11](https://patentimages.storage.googleapis.com/c2/00/63/5e7fb68306794c/2018149648-13.png)

![Sketch 11 for JP-2018149648-A](https://patentimages.storage.googleapis.com/c2/00/63/5e7fb68306794c/2018149648-13.png)

[Sketch 12](https://patentimages.storage.googleapis.com/a9/a0/92/428073d53db465/2018149648-14.png)

![Sketch 12 for JP-2018149648-A](https://patentimages.storage.googleapis.com/a9/a0/92/428073d53db465/2018149648-14.png)

[Sketch 13](https://patentimages.storage.googleapis.com/e7/29/50/86db62ba26e61a/2018149648-15.png)

![Sketch 13 for JP-2018149648-A](https://patentimages.storage.googleapis.com/e7/29/50/86db62ba26e61a/2018149648-15.png)

## Claims

### Claim 1 (independent)

Claims (5)

### Claim 2 (independent)

Translated from Japanese

### Claim 3 (independent)

é»ç£ãã£ãã¯æ¬ä½ã®é¢æ¿ä¸é¢ã«å½¢æãããè¤æ°ã®ç£æ¥µé¨ãåããå¶å¾¡è£

### Claim 4 (independent)

ç½®ãå¶å¾¡ããåè¨ç£æ¥µé¨ã®ç£æ°åã«ãã£ã¦å·¥ä½ç©ãå¸çããé»ç£ãã£ãã¯è£

### Claim 5 (independent)

ç½®ã®å¶å¾¡æ¹æ³ã§ãã£ã¦ã

### Claim 6 (independent)

åè¨é»ç£ãã£ãã¯è£

### Claim 7 (independent)

ç½®ã¯ã

### Claim 8 (independent)

åè¨é¢æ¿ä¸é¢ã§ããåè¨ç£æ¥µé¨ã®ä¸é¢ã«ããã¦åå¯¾åé¢ãæå®ã®ééãæãã¦å¯¾åãé

### Claim 9 (independent)

ç½®ãããä¸å¯¾ã®å¸çæ¯æé¨æãå°ãªãã¨ãï¼çµåãã

### Claim 10 (independent)

ååè¨ä¸å¯¾ã®å¸çæ¯æé¨æããããããåè¨è¤æ°ã®ç£æ¥µé¨ã®ãã¡ã®é£ãåãç°ãªãç¨®é¡ã®ç£æ¥µé¨éã®å¢çãæãã§é

### Claim 11 (independent)

ç½®ãããååè¨ä¸å¯¾ã®å¸çæ¯æé¨æã®åç¬¬ä¸å¹³é¢ããåè¨é£ãåãç£æ¥µé¨ã®åä¸é¢ã«æ¥è§¦ããç¶æ

### Claim 12 (independent)

ã«ããã¦ã

### Claim 13 (independent)

åè¨å¶å¾¡æ¹æ³ã¯ã

### Claim 14 (independent)

åè¨åç¬¬ä¸å¹³é¢ã¨èåããåç¬¬äºå¹³é¢ãåããååè¨ä¸å¯¾ã®å¸çæ¯æé¨æã®ãã¡åè¨åç¬¬äºå¹³é¢ãåè¨å·¥ä½ç©ã®è¢«å¸çé¢ã¨æ¥è§¦ããä¸å¯¾ã®å¸çæ¯æé¨æãç¢ºèªããç¬¬ä¸å·¥ç¨ã¨ã

### Claim 15 (independent)

åè¨ç¬¬ä¸å·¥ç¨ã«ããã¦ãåè¨è¢«å¸çé¢ã¨ã®æ¥è§¦ãç¢ºèªãããåè¨ä¸å¯¾ã®å¸çæ¯æé¨æãåºå®ãããåè¨ç£æ¥µé¨ãåè¨å¶å¾¡è£

### Claim 16 (independent)

ç½®ãå¶å¾¡ãã¦åè¨ç£æ°åãçºçãããæ¥è§¦ããåè¨ç¬¬äºå¹³é¢ã¨åè¨è¢«å¸çé¢ã¨ãå¸çãããç¬¬äºå·¥ç¨ã¨ã

### Claim 17 (independent)

ãåããé»ç£ãã£ãã¯è£

### Claim 18 (independent)

ç½®ã®å¶å¾¡æ¹æ³ã

### Claim 19 (independent)

A method for controlling an electromagnetic chuck device comprising a plurality of magnetic pole portions formed on the upper surface of a face plate of an electromagnetic chuck body, and for attracting a workpiece by the magnetic force of the magnetic pole portions controlled by a control device,

### Claim 20 (independent)

The electromagnetic chuck device includes:

### Claim 21 (independent)

At least three pairs of suction support members, each of which faces each other with a predetermined gap on the top surface of the magnetic pole portion that is the top surface of the face plate, are provided,

### Claim 22 (independent)

Each of the pair of suction support members is disposed across a boundary between different types of adjacent magnetic pole portions of the plurality of magnetic pole portions, and each first plane of each of the pair of suction support members is adjacent to the adjacent In a state where it contacts each upper surface of the matching magnetic pole part,

### Claim 23 (independent)

The control method is:

### Claim 24 (independent)

Among the pair of suction support members having the second planes facing away from the first planes, a second pair of suction support members in which each second plane comes into contact with the surface to be suctioned of the workpiece is confirmed. One process,

### Claim 25 (independent)

In the first step, the control device generates the magnetic force by controlling the magnetic pole portion to which the pair of suction support members confirmed to be in contact with the attracted surface is fixed. A second step of adsorbing a flat surface and the adsorbed surface;

### Claim 26 (independent)

A method for controlling an electromagnetic chuck device comprising:

### Claim 27 (independent)

åè¨ç¬¬ä¸å·¥ç¨ã«ããã¦ã

### Claim 28 (independent)

åè¨åç¬¬äºå¹³é¢ããåè¨å·¥ä½ç©ã®åè¨è¢«å¸çé¢ã¨æ¥è§¦ããåè¨ä¸å¯¾ã®å¸çæ¯æé¨æã¯ã»ã³ãµã«ãã£ã¦ç¢ºèªãããè«æ±é

### Claim 29 (independent)

ï¼ã«è¨è¼ã®é»ç£ãã£ãã¯è£

### Claim 30 (independent)

ç½®ã®å¶å¾¡æ¹æ³ã

### Claim 31

In the first step, The method of controlling an electromagnetic chuck device according to claim 1, wherein the pair of suction support members in which each of the second planes comes into contact with the suction target surface of the workpiece is confirmed by a sensor.

### Claim 33 (independent)

åè¨ç¬¬äºå·¥ç¨ã«ããã¦ã

### Claim 34 (independent)

åè¨ç£æ°åã¯ãå å·¥ã®ç¨®é¡ã«åºã¥ãã¦å¸çåãå¤æ´ãããè«æ±é

### Claim 35 (independent)

ï¼ã«è¨è¼ã®é»ç£ãã£ãã¯è£

### Claim 36 (independent)

ç½®ã®å¶å¾¡æ¹æ³ã

### Claim 37 (independent)

In the second step,

### Claim 38

The method of controlling an electromagnetic chuck device according to claim 2, wherein the magnetic force changes the attractive force based on a type of processing.

### Claim 39 (independent)

åè¨ã»ã³ãµã¯ãï¼¡ï¼¥ã»ã³ãµã§ãããè«æ±é

### Claim 40 (independent)

ï¼åã¯ï¼ã«è¨è¼ã®é»ç£ãã£ãã¯è£

### Claim 41 (independent)

ç½®ã®å¶å¾¡æ¹æ³ã

### Claim 42

Â Â The method for controlling an electromagnetic chuck device according to claim 2, wherein the sensor is an AE sensor.

### Claim 43 (independent)

é»ç£ãã£ãã¯æ¬ä½ã®é¢æ¿ä¸é¢ã«å½¢æãããè¤æ°ã®ç£æ¥µé¨ãåããå¶å¾¡è£

### Claim 44 (independent)

ç½®ã«å¶å¾¡ãããåè¨ç£æ¥µé¨ã®ç£æ°åã«ãã£ã¦å·¥ä½ç©ãåè¨é¢æ¿ä¸é¢ã«å¸çããé»ç£ãã£ãã¯è£

### Claim 45 (independent)

ç½®ã§ãã£ã¦ã

### Claim 46 (independent)

åè¨é»ç£ãã£ãã¯è£

### Claim 47 (independent)

ç½®ã¯ãåè¨é¢æ¿ä¸é¢ã§ããåè¨ç£æ¥µé¨ã®ä¸é¢ã«ããã¦åå¯¾åé¢ãæå®ã®ééãæãã¦å¯¾åãé

### Claim 48 (independent)

ç½®ãããä¸å¯¾ã®å¸çæ¯æé¨æãå°ãªãã¨ãï¼çµåãã

### Claim 49 (independent)

ååè¨ä¸å¯¾ã®å¸çæ¯æé¨æã¯ã

### Claim 50 (independent)

ããããåè¨è¤æ°ã®ç£æ¥µé¨ã®ãã¡ã®é£ãåãç°ãªãç¨®é¡ã®ç£æ¥µé¨éã®å¢çãæãã§é

### Claim 51 (independent)

ç½®ããã

### Claim 52 (independent)

ååè¨ä¸å¯¾ã®å¸çæ¯æé¨æã®åç¬¬ä¸å¹³é¢ããåè¨é£ãåãç£æ¥µé¨ã®åä¸é¢ã«æ¥è§¦ãã

### Claim 53 (independent)

åè¨å¶å¾¡è£

### Claim 54 (independent)

ç½®ã¯ã

### Claim 55 (independent)

åè¨åç¬¬ä¸å¹³é¢ã¨èåããåç¬¬äºå¹³é¢ãåããååè¨ä¸å¯¾ã®å¸çæ¯æé¨æã®ãã¡åè¨åç¬¬äºå¹³é¢ãåè¨å·¥ä½ç©ã®è¢«å¸çé¢ã¨æ¥è§¦ããä¸å¯¾ã®å¸çæ¯æé¨æãç¢ºèªããç¬¬ä¸å¦çé¨ã¨ã

### Claim 56 (independent)

åè¨ç¬¬ä¸å¦çé¨ã«ããã¦ãåè¨è¢«å¸çé¢ã¨ã®æ¥è§¦ãç¢ºèªãããåè¨ä¸å¯¾ã®å¸çæ¯æé¨æãåºå®ãããåè¨ç£æ¥µé¨ãå¶å¾¡ãã¦åè¨ç£æ°åãçºçãããæ¥è§¦ããåè¨ç¬¬äºå¹³é¢ã¨åè¨è¢«å¸çé¢ã¨ãå¸çãããç¬¬äºå¦çé¨ã¨ã

### Claim 57 (independent)

ãåãããé»ç£ãã£ãã¯è£

### Claim 58 (independent)

ç½®ã

### Claim 59 (independent)

An electromagnetic chuck device comprising a plurality of magnetic pole portions formed on an upper surface of a face plate of an electromagnetic chuck main body, and for attracting a workpiece to the upper surface of the face plate by a magnetic force of the magnetic pole portions controlled by a control device,

### Claim 60 (independent)

The electromagnetic chuck device includes at least three pairs of suction support members in which the opposing surfaces are arranged to face each other with a predetermined gap on the upper surface of the magnetic pole portion that is the upper surface of the face plate,

### Claim 61 (independent)

Each of the pair of adsorption support members includes:

### Claim 62 (independent)

Each of the plurality of magnetic pole portions is arranged across a boundary between different types of magnetic pole portions adjacent to each other,

### Claim 63 (independent)

Each first plane of each of the pair of suction support members is in contact with each upper surface of the adjacent magnetic pole part,

### Claim 64 (independent)

The control device includes:

### Claim 65 (independent)

Among the pair of suction support members having the second planes facing away from the first planes, a second pair of suction support members in which each second plane comes into contact with the surface to be suctioned of the workpiece is confirmed. A processing unit;

### Claim 66 (independent)

In the first processing part, the magnetic force is generated by controlling the magnetic pole part to which the pair of suction support members confirmed to be in contact with the attracted surface is fixed, A second processing unit for adsorbing the surface to be adsorbed;

### Claim 67 (independent)

An electromagnetic chuck device comprising:

## Full description

**[p0001]**

Description Translated from Japanese æ¬çºæã¯ãé»ç£ãã£ãã¯è£ ç½®ã®å¶å¾¡æ¹æ³ãåã³é»ç£ãã£ãã¯è£ ç½®ã«é¢ããã Â Â The present invention relates to an electromagnetic chuck device control method and an electromagnetic chuck device. å¾æ¥ãå·¥ä½ç©ã«å¯¾ãã¦ååãåã¯ç åç­ã®å å·¥ãè¡ãªãå ´åã«é»ç£æ°ã«ããå¸çåï¼ç£æ°å¸å¼åï¼ãå©ç¨ãã¦å·¥ä½ç©ãé¢æ¿ä¸ã«åºå®ããé»ç£ãã£ãã¯è£ ç½®ã®æè¡ãããããã®ãããªé»ç£ãã£ãã¯è£ ç½®ã§ã¯ãéå¸¸ãï¼æ¥µãï¼ï¼æ¥µã®æ¥µç£ãç¨ããå·¥ä½ç©ã«ç£æãéãã¦ç£æ°åãçºçãããå·¥ä½ç©ãé¢æ¿ä¸ã®å ¨é¢ã§å¸çãå¼·åºã«åºå®ããããã®ãããå·¥ä½ç©ã®è¢«å¸çé¢ã®å¹³é¢åº¦ããã¾ãè¯ããªãå ´åãå·¥ä½ç©ã¨ç´æ¥æ¥ãã¦ããªãæ¥µç£ã®é¨åã«ããã¦ããå·¥ä½ç©ã¯é»ç£ãã£ãã¯è£ ç½®ã«ãã£ã¦å¸çããé¢æ¿ã®å½¢ç¶ã«å£ãå¤å½¢ãã¦ãã¾ãå ´åãããããã®å ´åãå·¥ä½ç©ãå¤å½¢ããç¶æ

**[p0002]**

ã®ã¾ã¾ãè¢«å¸çé¢ä»¥å¤ã®é¢ãå å·¥ãããã®ã§ãé»ç£ãã£ãã¯è£ ç½®ã«ããå¸çãè§£é¤ããéã«ã¯ãææããã¦ããå¤å½¢ãéæ¾ãããå·¥ä½ç©ã®å å·¥é¢ãå¤å½¢ãã¦ãã¾ãèãããã Â Â 2. Description of the Related Art Conventionally, there is a technique of an electromagnetic chuck device that fixes a workpiece on a face plate by using an electromagnetic attraction force (magnetic attraction force) when cutting or grinding the workpiece. In such an electromagnetic chuck device, an 8-pole or 10-pole magnetic field is usually used to generate a magnetic force through the magnetic flux, and the work piece is attracted and firmly fixed on the entire surface of the face plate. For this reason, when the flatness of the attracted surface of the workpiece is not so good, the workpiece is attracted by the electromagnetic chuck device and deforms in accordance with the shape of the face plate even in the portion of the polar magnet that is not in direct contact with the workpiece. There is a case. In this case, since the surface other than the attracted surface is processed while the workpiece is deformed, the restrained deformation is released when the suction by the electromagnetic chuck device is released, and the workpiece processing surface May be deformed.

**[p0003]**

ã¾ããããã­ã³ã°ãã¬ã¼ãï¼å¸çæ¯æé¨æï¼ã¨å¼ç§°ãããé¨æãç¨ãã¦å·¥ä½ç©ãæ¯æããæ¹æ³ãããããªããããã­ã³ã°ãã¬ã¼ãã¨ã¯ãé»ç£ãã£ãã¯è£ ç½®ã®é¢æ¿ã¨å·¥ä½ç©ã®è¢«å¸çé¢ã¨ã®éã«ä»å¨ãããç£æ§ä½ãããªãé¨æã§ããï¼ããã­ã³ã°ãã¬ã¼ãã®ä¸ä¾ã¨ãã¦ã¯ãä¸è¨ç¹è¨±æç®ï¼ãï¼ãããï¼ã Â Â There is also a method of supporting a workpiece using a member called a backing plate (suction support member). Note that the backing plate is a member made of a magnetic material interposed between the face plate of the electromagnetic chuck device and the attracted surface of the workpiece (examples of the backing plate include Patent Documents 1 to 5 below). ããã­ã³ã°ãã¬ã¼ãã¯ãå·¥ä½ç©ã®å¸çé¢ãåµ©ä¸ãããé¨æã§ããããã£ã¦ãå å·¥è£ ç½®ï¼ç åç¤ï¼ãã·ãã³ã°ã»ã³ã¿ãªã©ï¼ã«ãã£ã¦å·¥ä½ç©ã®å¸çé¢ä»è¿ã¾ã§å å·¥ããã¨ãã«ãå å·¥è£

**[p0004]**

ç½®ã®å·¥å ·ããé»ç£ãã£ãã¯ã®å¸çé¢ã¨æ¥è§¦ï¼ç ´æï¼ãããã¨ãé²ããã¨ãã§ãããã¾ããå·¥ä½ç©ãé»ç£ãã£ãã¯ã«ç´æ¥å¸çãããã¨ãå·¥ä½ç©ã¨é»ç£ãã£ãã¯ã®å¸çé¢ã¨ãç´æ¥æ¥è§¦ãã¦é»ç£ãã£ãã¯ã®å¸çè¡¨é¢ãå¤å½¢ï¼ç ´æï¼ããå¹³é¢åº¦ãä¿ã¦ãªããªããã¨ããããããã«å¯¾ããå·¥ä½ç©ãããã­ã³ã°ãã¬ã¼ãã§æ¯æãããã¨ã«ããé»ç£ãã£ãã¯ã®å¸çè¡¨é¢ã®å¤å½¢ï¼ç ´æï¼ãé²æ­¢ãããã¨ãã§ããã Â Â The backing plate is a member that raises the suction surface of the workpiece. Therefore, it is possible to prevent the tool of the processing device from coming into contact (damaged) with the suction surface of the electromagnetic chuck when processing up to the vicinity of the suction surface of the workpiece by a processing device (grinding machine, machining center, etc.). Further, when the workpiece is directly attracted to the electromagnetic chuck, the workpiece and the attracting surface of the electromagnetic chuck may be in direct contact with each other, and the attracting surface of the electromagnetic chuck may be deformed (damaged), and the flatness may not be maintained. On the other hand, deformation (breakage) of the attracting surface of the electromagnetic chuck can be prevented by supporting the workpiece with the backing plate.

**[p0005]**

ç¹éå¹³ï¼âï¼ï¼ï¼ï¼ï¼å·å ¬å ±JP-A-6-31602 ç¹éï¼ï¼ï¼ï¼âï¼ï¼ï¼ï¼ï¼ï¼å·å ¬å ±JP 2016-112650 A ç¹è¨±ç¬¬ï¼ï¼ï¼ï¼ï¼ï¼ï¼å·å ¬å ±Japanese Patent No. 5416527 ç¹éï¼ï¼ï¼ï¼âï¼ï¼ï¼ï¼ï¼å·å ¬å ±JP 2001-25910 A ç¹éï¼ï¼ï¼ï¼âï¼ï¼ï¼ï¼ï¼ï¼å·å ¬å ±JP, 2014-213424, A ããããªãããä¸è¿°ããå¾æ¥ã®å¯¾ç­æ¹æ³ã§ã¯ãåããã­ã³ã°ãã¬ã¼ãããï¼³æ¥µåã¯ï¼®æ¥µã®ããããã®ç£æ¥µã®ä¸ã«é ç½®ãã¦ããããã®ãããªé ç½®ã§ã¯ãããã­ã³ã°ãã¬ã¼ãããä¾ãã°ãé¢æ¿ã®å¨æ¹åã«ããã¦ï¼³æ¥µâï¼®æ¥µâï¼³æ¥µã®é ã«é ç½®ããå ´åãæå¾ã®ç£æ¥µï¼ï¼³æ¥µï¼ã¨åãã®ç£æ¥µï¼ï¼³æ¥µï¼ã¨ã¯å¿ ãåãç£æ¥µã®çµã¿åããã¨ãªãããã®ãããï¼³æ¥µâï¼³æ¥µéã§ã¯ç£è·¯ãå½¢æã§ãããçºçããç£æ°åãä½ä¸ããå·¥ä½ç©ã«å¯¾ããååãªå¸çåï¼ææåï¼ãå¾ãããªãã¨ããèª²é¡ããããã¾ããå·¥ä½ç©ãå¸çï¼ææï¼ããå ´åã«å·¥ä½ç©ãå¤å½¢ããã¨ããèª²é¡ãããã

**[p0006]**

Â Â However, in the conventional countermeasure method described above, each backing plate is arranged on either the S pole or the N pole. In such an arrangement, for example, when the backing plate is arranged in the order of S pole â N pole â S pole in the circumferential direction of the face plate, the last magnetic pole (S pole) and the first magnetic pole (S pole) are always the same. A combination of magnetic poles. For this reason, a magnetic path cannot be formed between the S pole and the S pole, the generated magnetic force is reduced, and there is a problem that a sufficient attracting force (gripping force) on the workpiece cannot be obtained. Further, there is a problem that the workpiece is deformed when the workpiece is sucked (gripped). æ¬çºæã¯ããã®ãããªäºæ ã«éã¿ã¦ãªããããã®ã§ãããç£æ°åã«ããå¸çã«ãã£ã¦é¢æ¿ä¸ã«å·¥ä½ç©ãææããå ´åã«ããã¦ãå·¥ä½ç©ãå¤å½¢ããããä¸ã¤ååãªææåãçºæ®ãããã¨ãå¯è½ãªé»ç£ãã£ãã¯è£

**[p0007]**

ç½®ã®å¶å¾¡æ¹æ³ãåã³é»ç£ãã£ãã¯è£ ç½®ãæä¾ãããã¨ãç®çã¨ããã Â Â The present invention has been made in view of such circumstances, and when gripping a workpiece on a face plate by adsorption by magnetic force, the workpiece is not deformed and sufficient gripping force can be exhibited. It is an object of the present invention to provide an electromagnetic chuck device control method that can be used, and an electromagnetic chuck device. ä¸è¨èª²é¡ãè§£æ±ºãããããè«æ±é ï¼ã®é»ç£ãã£ãã¯è£ ç½®ã®å¶å¾¡æ¹æ³ã¯ãé»ç£ãã£ãã¯æ¬ä½ã®é¢æ¿ä¸é¢ã«å½¢æãããè¤æ°ã®ç£æ¥µé¨ãåããå¶å¾¡è£ ç½®ãå¶å¾¡ããåè¨ç£æ¥µé¨ã®ç£æ°åã«ãã£ã¦å·¥ä½ç©ãå¸çããå¶å¾¡æ¹æ³ã§ãããåè¨é»ç£ãã£ãã¯è£ ç½®ã¯ãåè¨é¢æ¿ä¸é¢ã§ããåè¨ç£æ¥µé¨ã®ä¸é¢ã«ããã¦åå¯¾åé¢ãæå®ã®ééãæãã¦å¯¾åãé ç½®ãããä¸å¯¾ã®å¸çæ¯æé¨æãå°ãªãã¨ãï¼çµåããååè¨ä¸å¯¾ã®å¸çæ¯æé¨æããããããåè¨è¤æ°ã®ç£æ¥µé¨ã®ãã¡ã®é£ãåãç°ãªãç¨®é¡ã®ç£æ¥µé¨éã®å¢çãæãã§é

**[p0008]**

ç½®ãããååè¨ä¸å¯¾ã®å¸çæ¯æé¨æã®åç¬¬ä¸å¹³é¢ããåè¨é£ãåãç£æ¥µé¨ã®åä¸é¢ã«æ¥è§¦ããç¶æ ã«ããã¦ãåè¨å¶å¾¡æ¹æ³ã¯ãåè¨åç¬¬ä¸å¹³é¢ã¨èåããåç¬¬äºå¹³é¢ãåããååè¨ä¸å¯¾ã®å¸çæ¯æé¨æã®ãã¡åè¨åç¬¬äºå¹³é¢ãåè¨å·¥ä½ç©ã®åè¨è¢«å¸çé¢ã¨æ¥è§¦ããä¸å¯¾ã®å¸çæ¯æé¨æãç¢ºèªããç¬¬ä¸å·¥ç¨ã¨ãåè¨ç¬¬ä¸å·¥ç¨ã«ããã¦ãåè¨è¢«å¸çé¢ã¨ã®æ¥è§¦ãç¢ºèªãããåè¨ä¸å¯¾ã®å¸çæ¯æé¨æãåºå®ãããåè¨ç£æ¥µé¨ãåè¨å¶å¾¡è£ ç½®ãå¶å¾¡ãã¦åè¨ç£æ°åãçºçãããæ¥è§¦ããåè¨ç¬¬äºå¹³é¢ã¨åè¨è¢«å¸çé¢ã¨ãå¸çãããç¬¬äºå·¥ç¨ã¨ããåããã Â Â In order to solve the above-mentioned problem, a method for controlling an electromagnetic chuck device according to claim 1 includes a plurality of magnetic pole portions formed on the upper surface of the face plate of the electromagnetic chuck main body, and a workpiece by the magnetic force of the magnetic pole portions controlled by the control device. It is the control method which adsorbs. The electromagnetic chuck device includes at least three pairs of suction support members in which the opposing surfaces are opposed to each other with a predetermined gap on the top surface of the magnetic pole portion that is the top surface of the face plate, and each of the pair of suction support members Members are respectively disposed across a boundary between different types of magnetic pole portions adjacent to each other among the plurality of

**[p0008]**

magnetic pole portions, and each first plane of each of the pair of suction support members corresponds to each upper surface of the adjacent magnetic pole portions. In the state of contacting, the control method is configured such that each second plane of the pair of suction support members provided with each second plane facing away from each first plane is the surface to be sucked of the workpiece. A first step of confirming a pair of suction support members that come into contact with the control unit, and the control unit including the magnetic pole portion to which the pair of suction support members confirmed to be in contact with the attracted surface in the first step is fixed Control to generate the magnetic force It is allowed, and a second step of adsorbing the said second plane and said attaching object face in contact.

**[p0009]**

ãã®ããã«ããã®å¶å¾¡æ¹æ³ã§ã¯ãå·¥ä½ç©ãæªç åç¶æ ã§ãããå ¨ä½ã«æ­ªã¿ãããå¯è½æ§ã®ããå ´åãç¬¬ä¸å·¥ç¨ã«ããã¦ãå·¥ä½ç©ãä¸å¯¾ã®å¸çæ¯æé¨æã®ä¸é¢ã«è¼ç½®ãããç¶æ ã§ãå·¥ä½ç©ãæ¥è§¦ããé¨åãç¢ºèªãããã®å¾ãç¬¬äºå·¥ç¨ã«ããã¦ãå·¥ä½ç©ãæ¥è§¦ããé¨åã®ã¿ç£æ°åãçºçãããå·¥ä½ç©ãå¸çã«ãã£ã¦åºå®ããããã®ãããå·¥ä½ç©ãæ­ªã¾ãããã¨ãªããè¢«å¸çé¢ã«èåããç«¯é¢ï¼åºæºé¢ï¼ã®å å·¥ãè¯å¥½ã«ã§ããããã£ã¦ãå å·¥ããåºæºé¢ï¼ç«¯é¢ï¼ãåºæºã¨ãå å·¥ãããã¨ã§ãå å·¥ç²¾åº¦ã®é«ãå·¥ä½ç©ãå¾ãããã Â Â As described above, in this control method, when the workpiece is in an unground state and there is a possibility that the entire workpiece is distorted, the workpiece is placed on the upper surfaces of the pair of suction support members in the first step. In the second step, the magnetic force is generated only in the portion where the workpiece contacts, and the workpiece is fixed by suction. For this reason, the end surface (reference surface) facing away from the attracted surface can be satisfactorily processed without distorting the workpiece. Therefore, a workpiece with high machining accuracy can be obtained by machining using the machined reference surface (end surface) as a reference.

**[p0010]**

ã¾ããä¸è¨èª²é¡ãè§£æ±ºãããããè«æ±é ï¼ã®é»ç£ãã£ãã¯è£ ç½®ã¯ãé»ç£ãã£ãã¯æ¬ä½ã®é¢æ¿ä¸é¢ã«å½¢æãããè¤æ°ã®ç£æ¥µé¨ãåããå¶å¾¡è£ ç½®ã«å¶å¾¡ãããåè¨ç£æ¥µé¨ã®ç£æ°åã«ãã£ã¦å·¥ä½ç©ãåè¨é¢æ¿ä¸é¢ã«å¸çããé»ç£ãã£ãã¯è£ ç½®ã§ãã£ã¦ãåè¨é»ç£ãã£ãã¯è£ ç½®ã¯ãåè¨é¢æ¿ä¸é¢ã§ããåè¨ç£æ¥µé¨ã®ä¸é¢ã«ããã¦åå¯¾åé¢ãæå®ã®ééãæãã¦å¯¾åãé ç½®ãããä¸å¯¾ã®å¸çæ¯æé¨æãå°ãªãã¨ãï¼çµåããååè¨ä¸å¯¾ã®å¸çæ¯æé¨æã¯ãããããåè¨è¤æ°ã®ç£æ¥µé¨ã®ãã¡ã®é£ãåãç°ãªãç¨®é¡ã®ç£æ¥µé¨éã®å¢çãæãã§é ç½®ãããååè¨ä¸å¯¾ã®å¸çæ¯æé¨æã®åç¬¬ä¸å¹³é¢ããåè¨é£ãåãç£æ¥µé¨ã®åä¸é¢ã«æ¥è§¦ããåè¨å¶å¾¡è£ ç½®ã¯ãåè¨åç¬¬ä¸å¹³é¢ã¨èåããåç¬¬äºå¹³é¢ãåããååè¨ä¸å¯¾ã®å¸çæ¯æé¨æã®ãã¡åè¨åç¬¬äºå¹³é¢ãåè¨å·¥ä½ç©ã®åè¨è¢«å¸çé¢ã¨æ¥è§¦ããä¸å¯¾ã®å¸çæ¯æé¨æãç¢ºèªããç¬¬ä¸å¦çé¨ã¨ãåè¨ç¬¬ä¸å¦çé¨ã«ããã¦ãåè¨è¢«å¸çé¢ã¨ã®æ¥è§¦ãç¢ºèªãããåè¨ä¸å¯¾ã®å¸çæ¯æé¨æãåºå®ãããåè¨ç£æ¥µé¨ãå¶å¾¡ãã¦åè¨ç£æ°åãçºçãããæ¥è§¦ããåè¨ç¬¬äºå¹³é¢ã¨åè¨è¢«å¸çé¢ã¨ãå¸çãããç¬¬äºå¦çé¨ã¨ããåãããããã«ãããä¸è¨è«æ±é

**[p0011]**

ï¼ã§èª¬æããå¶å¾¡æ¹æ³ã«ãã£ã¦å¾ãããã®ã¨åãå¹æãå¥ããé»ç£ãã£ãã¯è£ ç½®ãå¾ãããã Â Â In order to solve the above problem, the electromagnetic chuck device according to claim 5 includes a plurality of magnetic pole portions formed on the upper surface of the face plate of the electromagnetic chuck main body, and the workpiece is controlled by the magnetic force of the magnetic pole portions controlled by the control device. On the upper surface of the face plate, wherein the electromagnetic chuck device has a pair of suction surfaces in which the opposing surfaces are arranged to face each other with a predetermined gap on the upper surface of the magnetic pole portion, which is the upper surface of the face plate. At least three sets of support members are provided, and each of the pair of suction support members is disposed across a boundary between different types of adjacent magnetic pole portions of the plurality of magnetic pole portions, and each of the pair of suction support members Each first plane is in contact with each upper surface of the adjacent magnetic pole portion, and the control device is configured to select each of the pair of suction support members including each second plane facing away from the first plane. The second plane is A first processing unit that confirms a pair of adsorption support members that are in contact with the adsorbed surface of the crop, and the pair of adsorption support members that are confirmed to be in contact with the adsorbed surface are fixed in the first processing unit. An

**[p0011]**

d a second processing unit that controls the magnetic pole portion to generate the magnetic force and attracts the contacted second plane and the attracted surface. Thus, an electromagnetic chuck device having the same effect as that obtained by the control method described in claim 1 can be obtained.

**[p0012]**

æ¬å®æ½å½¢æ ã«ä¿ãç åç¤ã®å ¨ä½æ§æãç¤ºãæ¦ç¥å³ã§ãããIt is the schematic which shows the whole structure of the grinding machine which concerns on this embodiment. ï¼§è»¸ç·ãéãå³ï¼ã®é»ç£ãã£ãã¯æ¬ä½é¨ååã³å³ï¼ã®é»ç£ãã£ãã¯æ¬ä½é¨åã®æ­é¢å³ã§ããï¼å³ï¼ã«ããã¦ã¯ãIIâIIç¢è¦æ­é¢å³ï¼ãIt is sectional drawing of the electromagnetic chuck main-body part of FIG. 1 which passes along a G-axis, and the electromagnetic chuck main-body part of FIG. 3 (in FIG. 3, II-II arrow sectional drawing). å³ï¼ã®ç åç¤ã«åããããé»ç£ãã£ãã¯æ¬ä½ã®æ¡å¤§å¹³é¢å³ã§ãããFIG. 2 is an enlarged plan view of an electromagnetic chuck main body provided in the grinding machine of FIG. 1. å³ï¼ã«ãããä¸å¯¾ã®å¸çæ¯æé¨æã®æ¡å¤§å³ã§ãããIt is an enlarged view of a pair of adsorption | suction support member in FIG. å³ï¼ã«ãããï¼±è¦å³ã§ãããFIG. 5 is a Q view in FIG. 4. å³ï¼ã«ãããä¸å¯¾ã®å¸çæ¯æé¨æãæ§æããåé¨ãèª¬æããå³ã§ãããIt is a figure explaining each part which comprises a pair of adsorption | suction support member in FIG.

**[p0013]**

å·¥ä½ç©ãæ¯æãããä¸å¯¾ã®å¸çæ¯æé¨æã«ãããæ¯æé¨ãèª¬æããå³ã§ãããIt is a figure explaining the support part in a pair of adsorption | suction support member in which a workpiece is supported. æ¯æé¨ã«ãããææè§åº¦ã¨å·¥ä½ç©ã®å¤å½¢éã¨ã®é¢ä¿ãç¤ºãã°ã©ãã§ãããIt is a graph which shows the relationship between the holding | grip angle in a support part, and the deformation amount of a workpiece. ä¸å¯¾ã®å¸çæ¯æé¨æã®éã®ééã¨å·¥ä½ç©ãééããç£æå¯åº¦ã¨ã®é¢ä¿ãç¤ºãã°ã©ãã§ãããIt is a graph which shows the relationship between the clearance gap between a pair of adsorption | suction support members, and the magnetic flux density which passes a workpiece. ä¸å¯¾ã®å¸çæ¯æé¨æã¨å·¥ä½ç©ã¨ã®éãééããç£æãèª¬æããå³ã§ãããIt is a figure explaining the magnetic flux which passes between a pair of adsorption | suction support members and a workpiece. é»ç£ãã£ãã¯è£

**[p0014]**

ç½®ã®ä½ç¨ãèª¬æãããã­ã¼ãã£ã¼ãã§ãããIt is a flowchart explaining the effect | action of an electromagnetic chuck apparatus. å¤å½¢ä¾ï¼ã«ãããä¸å¯¾ã®å¸çæ¯æé¨æã¨ãææè§åº¦ã¨ãèª¬æããå³ã§ãããIt is a figure explaining a pair of adsorption support member in modification 2, and a grasping angle. å¤å½¢ä¾ï¼ã«ãããä¸å¯¾ã®å¸çæ¯æé¨æã¨ãææè§åº¦ã¨ãèª¬æããå³ã§ãããIt is a figure explaining a pair of adsorption support member in modification 3, and a grasping angle. ï¼ï¼ï¼ç¬¬ä¸å®æ½å½¢æ ï¼ ï¼ï¼âï¼ï¼ç åç¤ã®æ§æï¼ ä»¥ä¸ãæ¬çºæã«ä¿ãé»ç£ãã£ãã¯è£ ç½®ï¼ï¼ï¼ä¿æè£ ç½®ã«ç¸å½ããï¼ããå·¥ä½ç©ï¼·ã«å¯¾ãã¦ç åãè¡ãªãç åç¤ï¼ã«é©ç¨ããç¬¬ä¸å®æ½å½¢æ ã«ã¤ãã¦èª¬æããããªããå³ï¼ã«ããã¦ã¯ãæ°´å¹³é¢ã§ç´äº¤ããæ¹åãï¼¸è»¸ç·æ¹ååã³ï¼¹è»¸ç·æ¹åã¨ããï¼¸è»¸ç·æ¹ååã³ï¼¹è»¸ç·æ¹åã«ç´äº¤ããæ¹åãï¼ºè»¸ç·æ¹åã¨ããã

**[p0015]**

<1. First embodiment> (1-1. Configuration of grinding machine) Hereinafter, a first embodiment in which an electromagnetic chuck device 60 (corresponding to a holding device) according to the present invention is applied to a grinding machine 1 that grinds a workpiece W will be described. In FIG. 1, the direction orthogonal to the horizontal plane is defined as the X axis direction and the Y axis direction, and the direction orthogonal to the X axis direction and the Y axis direction is defined as the Z axis direction. å³ï¼ãå³ï¼ã«ç¤ºãããã«ãç åç¤ï¼ã¯ããããï¼ã¨ãã³ã©ã ï¼ã¨ããã¼ãã«ï¼ã¨ãç ¥ç³è»ï¼ï¼ç ¥ç³ã«ç¸å½ï¼ã¨ãä¸»è»¸å°ï¼ï¼ã¨ãé»ç£ãã£ãã¯è£ ç½®ï¼ï¼ã¨ããåãããã³ã©ã ï¼åã³ãã¼ãã«ï¼ã¯ãããï¼ä¸ã«è¨­ãããããã¾ããæ¬å®æ½å½¢æ ã«ããã¦ã¯ãå·¥ä½ç©ï¼·ã¯ãåç°ç¶ã®é¨æã¨ãã¦èª¬æããããã ããå·¥ä½ç©ï¼·ã®å½¢ç¶ã¯ãããã¾ã§ä¸ä¾ã§ãã£ã¦ãåç°ã«éå®ããããã®ã§ã¯ãªãã

**[p0016]**

Â Â As shown in FIGS. 1 to 3, the grinding machine 1 includes a bed 2, a column 3, a table 5, a grinding wheel 9 (corresponding to a grinding wheel), a headstock 40, and an electromagnetic chuck device 60. . The column 3 and the table 5 are provided on the bed 2. In the present embodiment, the workpiece W is described as an annular member. However, the shape of the workpiece W is merely an example, and is not limited to a circular ring. å³ï¼ã«ç¤ºãããã«ãã³ã©ã ï¼ã¯ãç ¥ç³è»ï¼ï¼ç ¥ç³ï¼ããã¼ãã«ï¼ä¸ã«ãããå·¥ä½ç©ï¼·ã®ç åä½ç½®ã«å¯¾ãé²éå¯è½ï¼ç¸å¯¾ç§»åå¯è½ï¼ã¨ãªããããããï¼ä¸ã«é ç½®ããããã³ã©ã ï¼ã¯ãé§åæ©æ§ï¼ï¼¡ã«ãã£ã¦ãï¼¸è»¸ç·æ¹åã«å¾å¾©ç§»åï¼é²éï¼å¯è½ã«æ§æããããå³ï¼ã«ç¤ºãããã«ãã³ã©ã ï¼ã®å´é¢ã«ã¯ãé§åæ©æ§ï¼ï¼ã«ãã£ã¦ãï¼ºè»¸ç·æ¹åã«æéï¼é²éï¼å¯è½ãªç ¥ç³å°ï¼ãåãããç ¥ç³å°ï¼ã¯ãé§åæ©æ§ï¼ï¼ã«ãã£ã¦ãï¼ºè»¸ç·åãã«åè»¢é§åå¯è½ãªã­ã¼ã¿ãªã¼åã®ç ¥ç³è»ï¼ï¼ç ¥ç³ã«ç¸å½ï¼ãåãããç ¥ç³è»ï¼ã¯ãä¸æ¹ã«å»¶ã³ãä¿æè»¸ï¼ï¼ã®ä¸ç«¯ã«ä¿æãããã

**[p0017]**

Â Â As shown in FIG. 1, the column 3 is disposed on the bed 2 so that the grinding wheel 9 (grinding wheel) can move forward and backward (relatively movable) with respect to the grinding position of the workpiece W on the table 5. The column 3 is configured to be capable of reciprocating (advancing and retreating) in the X axis direction by the drive mechanism 3A. As shown in FIG. 1, a grindstone table 4 that can be moved up and down (advanced and retracted) in the Z-axis direction by a drive mechanism 31 is provided on the side surface of the column 3. The grinding wheel base 4 includes a rotary grinding wheel 9 (corresponding to a grinding wheel) that can be driven to rotate around the Z-axis by a drive mechanism 32. The grinding wheel 9 is held at the lower end of a holding shaft 33 extending downward. å³ï¼ã«ç¤ºãããã«ãä¸»è»¸å°ï¼ï¼ã¯ãä¸»è»¸æ¬ä½ï¼ï¼ã¨ãï¼ºè»¸ç·æ¹åã¨å¹³è¡ãªï¼§è»¸ç·åãã«åè»¢å¯è½ãªå·¥ä½ä¸»è»¸ï¼ï¼ã¨ãåããããªããå³ï¼ã¯ãå³ï¼ã«ç¤ºãé»ç£ãã£ãã¯è£

**[p0018]**

ç½®ï¼ï¼ãåããé»ç£ãã£ãã¯æ¬ä½ï¼ï¼ã®å¹³é¢è¦ã«ãããIIâIIç¢è¦æ­é¢å³ã§ãããä¸»è»¸æ¬ä½ï¼ï¼ã«ã¯ãå³ç¥ã®é§åæ©æ§ãå èµããããå·¥ä½ä¸»è»¸ï¼ï¼ã¯ãä¸»è»¸æ¬ä½ï¼ï¼ãåããé§åæ©æ§ã«ãã£ã¦ï¼§è»¸ç·åãã«åè»¢å¯è½ã¨ãªãããä¸»è»¸æ¬ä½ï¼ï¼ã«åãä»ãããããå·¥ä½ä¸»è»¸ï¼ï¼ã¯ãä¸»è»¸æ¬ä½ï¼ï¼ã®ä¸ç«¯ããè¥å¹²çªåºãã¦åãä»ãããããããã¦ãå·¥ä½ä¸»è»¸ï¼ï¼ã®ä¸ç«¯ã«ã¯é»ç£ãã£ãã¯æ¬ä½ï¼ï¼ãåºå®ãããã Â Â As shown in FIG. 2, the headstock 40 includes a main spindle body 41 and a work spindle 42 that can rotate around a G axis parallel to the Z axis direction. 2 is a cross-sectional view taken along arrow II-II in a plan view of the electromagnetic chuck main body 61 provided in the electromagnetic chuck device 60 shown in FIG. The main spindle body 41 incorporates a drive mechanism (not shown). The work spindle 42 is attached to the spindle main body 41 so as to be rotatable around the G axis by a drive mechanism provided in the spindle main body 41. The work spindle 42 is attached so as to slightly protrude from the upper end of the spindle body 41. An electromagnetic chuck body 61 is fixed to the upper end of the work spindle 42.

**[p0019]**

ãã¼ãã«ï¼ã¯ãé»ç£ãã£ãã¯æ¬ä½ï¼ï¼ãé ç½®ãããä½ç½®ã«è²«éç©´ï¼ï¼ãåãããè²«éç©´ï¼ï¼ã«ã¯ãä¸»è»¸å°ï¼ï¼ã®å·¥ä½ä¸»è»¸ï¼ï¼ããæ¿éããããããã¦ãä¸»è»¸æ¬ä½ï¼ï¼ããè²«éç©´ï¼ï¼ã«å¯¾å¿ãããã¼ãã«ï¼ã®è£é¢ã«åºå®ããããããã¦ãé»ç£ãã£ãã¯æ¬ä½ï¼ï¼ã¯ãå·¥ä½ä¸»è»¸ï¼ï¼ã¨ã¨ãã«ï¼§è»¸ç·åãã«åè»¢ããã Â Â The table 5 includes a through hole 52 at a position where the electromagnetic chuck main body 61 is disposed. The work spindle 42 of the head stock 40 is inserted into the through hole 52. Then, the main spindle body 41 is fixed to the back surface of the table 5 corresponding to the through hole 52. The electromagnetic chuck main body 61 rotates around the G axis along with the work spindle 42. ï¼ï¼âï¼ï¼é»ç£ãã£ãã¯è£ ç½®ï¼ä¿æè£ ç½®ï¼ã®æ§æï¼ æ¬¡ã«ãæ¬çºæã«ä¿ãé»ç£ãã£ãã¯è£ ç½®ï¼ï¼ï¼ä¿æè£ ç½®ï¼ã®æ§æã«ã¤ãã¦ãå³ï¼ï¼å³ï¼ãå³ï¼ï¼ã«åºã¥ãè©³ç´°ã«èª¬æãããé»ç£ãã£ãã¯è£

**[p0020]**

ç½®ï¼ï¼ã¯ãé»ç£ãã£ãã¯æ¬ä½ï¼ï¼ã¨ãï¼çµã®ä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã¨ãå¶å¾¡è£ ç½®ï¼ï¼ã¨ããåãããæ¬çºæã«ä¿ãï¼çµã®ä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã¯ãé»ç£ãã£ãã¯æ¬ä½ï¼ï¼ã®é¢æ¿ï¼ï¼ï½ä¸é¢ã«è¨­ããããã (1-2. Configuration of electromagnetic chuck device (holding device)) Next, the configuration of the electromagnetic chuck device 60 (holding device) according to the present invention will be described in detail with reference to FIGS. The electromagnetic chuck device 60 includes an electromagnetic chuck main body 61, eight pairs of suction support members 62 and 63, and a control device 64. The eight pairs of suction support members 62 and 63 according to the present invention are provided on the upper surface of the face plate 61 a of the electromagnetic chuck main body 61. é»ç£ãã£ãã¯æ¬ä½ï¼ï¼ã¯ãä¾ãã°éç³»ã®ç£æ§ææã«ãã£ã¦ãåºé¨ã§ããé¢æ¿ï¼ï¼ï½ãä¸å´ã«ãã¦æåºç­ç¶ã«å½¢æããããã¤ã¾ããé¢æ¿ï¼ï¼ï½ã¯ãé»ç£ãã£ãã¯æ¬ä½ï¼ï¼ã®è»¸ç·æ¹åããè¦ãå ´åãå¤å¨ãåå½¢ã§å½¢æãããã

**[p0021]**

Â Â The electromagnetic chuck main body 61 is formed in a bottomed cylindrical shape with a face plate 61a which is a bottom portion, for example, of an iron-based magnetic material. That is, the outer surface of the face plate 61a is circular when viewed from the axial direction of the electromagnetic chuck main body 61. å³ï¼ã«ç¤ºãããã«ãæ¬å®æ½å½¢æ ã§ã¯é¢æ¿ï¼ï¼ï½ã®ä¸é¢ã«ãï¼åï¼è¤æ°ã«ç¸å½ï¼ã®ç£æ¥µé¨ï¼ï¼ãï¼ï¼ãåãããåç£æ¥µé¨ï¼ï¼ãï¼ï¼ã¯ãé¢æ¿ï¼ï¼ï½ã®ï¼§è»¸ç·ï¼ä¸»è»¸ç·ãä¸­å¿è»¸ç·ï¼åãã§å¨æ¹åã«ç­è§åº¦ééã§åå²ãããããããæç¶ã«å½¢æããããï¼åã®ç£æ¥µé¨ï¼ï¼ãï¼ï¼ã®ä¸é¢é«ãã¯å ¨ã¦åä¸ã§ããã Â Â As shown in FIG. 3, in the present embodiment, eight (corresponding to a plurality) magnetic pole portions 71 to 78 are provided on the upper surface of the face plate 61a. Each magnetic pole part 71-78 is divided | segmented at equal angular intervals in the circumferential direction around the G-axis line (main axis line, center axis line) of the face plate 61a, and each is formed in a fan shape. The top surface heights of the eight magnetic pole portions 71 to 78 are all the same.

**[p0022]**

ãªããä»¥éãç£æ¥µé¨ï¼ï¼ãï¼ï¼ã®åä¸é¢ãä¸é¢ï¼ï¼ï½ãï¼ï¼ï½ã¨ãããã¾ããåå²ãããåç£æ¥µé¨ï¼ï¼ãï¼ï¼ã®éã®å¢çï¼ç·ï¼ãå¢çï¼ï¼ï¼¬ãï¼ï¼ï¼¬ã¨ããããã®ã¨ããï¼ï¼ï¼¬ã¯ãç£æ¥µé¨ï¼ï¼ã¨ç£æ¥µé¨ï¼ï¼ã¨ã®éã®å¢çï¼ç·ï¼ã§ãããã¾ããå¢çï¼ï¼ï¼¬ã¯ãç£æ¥µé¨ï¼ï¼ã¨ç£æ¥µé¨ï¼ï¼ã¨ã®éã®å¢çï¼ç·ï¼ã§ãããä»ã®ç£æ¥µé¨ï¼ï¼ãï¼ï¼ã¨ä»ã®å¢çï¼ï¼ï¼¬ãï¼ï¼ï¼¬ã¨ã®é¢ä¿ãåæ§ã§ããã Â Â Hereinafter, the upper surfaces of the magnetic pole portions 71 to 78 are referred to as upper surfaces 71a to 78a. The boundaries (lines) between the divided magnetic pole portions 71 to 78 are defined as boundaries 71L to 78L. At this time, 71 </ b> L is a boundary (line) between the magnetic pole part 71 and the magnetic pole part 72. The boundary 78 </ b> L is a boundary (line) between the magnetic pole part 78 and the magnetic pole part 71. The same applies to the relationship between the other magnetic pole portions 72 to 77 and the other boundaries 72L to 77L.

**[p0023]**

é¢æ¿ï¼ï¼ï½ã®ä¸é¢ã¨ãç£æ¥µé¨ï¼ï¼ãï¼ï¼ã®ä¸é¢ï¼ï¼ï½ãï¼ï¼ï½ã¨ã¯åä¸é¢ã§ãããï¼åã®ç£æ¥µé¨ï¼ï¼ãï¼ï¼ã¯ãå¶å¾¡è£ ç½®ï¼ï¼ã®å¶å¾¡ã«ãã£ã¦å³ç¥ã®ã³ã¤ã«ã«ããããé»æµãä¾çµ¦ãããã¨åã ç£åããããç£åãããï¼åã®ç£æ¥µé¨ï¼ï¼ãï¼ï¼ã§ã¯ãå³ï¼ã«ç¤ºãããã«ï¼³æ¥µåã³ï¼®æ¥µãå¨æ¹åã«äº¤äºã«å½¢æãããããªãããã®æ æ§ã«éãããå³ï¼ã«ç¤ºãï¼³æ¥µãï¼®æ¥µã¨ããï¼®æ¥µãï¼³æ¥µã¨ããããã«å¶å¾¡ãã¦ãããã Â Â The upper surface of the face plate 61a and the upper surfaces 71a to 78a of the magnetic pole portions 71 to 78 are the same surface. The eight magnetic pole portions 71 to 78 are magnetized when current is supplied to coils (not shown) under the control of the control device 64. In the magnetized eight magnetic pole portions 71 to 78, S poles and N poles are alternately formed in the circumferential direction as shown in FIG. Note that the present invention is not limited to this mode, and control may be performed so that the S pole shown in FIG. 3 is the N pole and the N pole is the S pole.

**[p0024]**

ãã ããå¾ã«è©³è¿°ããããæ¬å®æ½å½¢æ ã«ããã¦ã¯ãæªå å·¥ï¼æªç åï¼ç¶æ ã®å·¥ä½ç©ï¼·ã®ç«¯é¢ï¼è¢«å¸çé¢ï¼·ï½ï¼ãç£æ¥µé¨ï¼ï¼ãï¼ï¼ã®ç£æ°åã«ãã£ã¦ãå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ã«å¸çãããå ´åã«ã¯ãå·¥ä½ç©ï¼·ã®è¢«å¸çé¢ï¼·ï½ãå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ã«è¼ç½®ããã¨ãã«ãè¢«å¸çé¢ï¼·ï½ãæ¥è§¦ããå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ç£æ¥µé¨ã®ã¿ãå¶å¾¡è£ ç½®ï¼ï¼ã«ãã£ã¦å¶å¾¡ããç£åãããã Â Â However, as will be described in detail later, in this embodiment, the suction support members 62 and 63 are applied to the end surface (surface to be attracted Wa) of the unprocessed (unground) workpiece W by the magnetic force of the magnetic pole portions 71 to 78. When the suction surface Wa of the workpiece W is placed on the top surfaces of the suction support members 62 and 63, only the magnetic pole portions of the suction support members 62 and 63 that are in contact with the suction surface Wa. Is controlled by the control device 64 and magnetized.

**[p0025]**

ã¾ããå å·¥æ¸ã¿ï¼ç åæ¸ã¿ï¼ç¶æ ã§ãããæå®ã®å¹³é¢åº¦ãç¢ºä¿ãããå·¥ä½ç©ï¼·ã®ç«¯é¢ï¼è¢«å¸çé¢ï¼·ï½ï¼ãç£æ¥µé¨ï¼ï¼ãï¼ï¼ã®ç£æ°åã«ãã£ã¦ãå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ã«å¸çãããå ´åã«ã¯ãå¶å¾¡è£ ç½®ï¼ï¼ã®å¶å¾¡ã«ãã£ã¦ãå ¨ã¦ã®ç£æ¥µé¨ï¼ï¼ãï¼ï¼ã«ç£æ°åãçºçãããããªããé»ç£ãã£ãã¯æ¬ä½ï¼ï¼ã¯ãå é¨ã«é»ç£ã³ã¤ã«ç­ãåããããå ¬ç¥ã§ããã®ã§ããã®æ§æãåã³ä½åã«ã¤ãã¦ã®è©³ç´°ãªèª¬æã¯çç¥ããã Â Â Further, the upper surfaces of the suction support members 62 and 63 are processed by the magnetic force of the magnetic pole portions 71 to 78 on the end surface (surface to be attracted Wa) of the workpiece W that has been processed (ground) and has a predetermined flatness. In order to attract the magnetic poles, magnetic force is generated in all the magnetic pole portions 71 to 78 under the control of the control device 64. Although the electromagnetic chuck main body 61 includes an electromagnetic coil and the like inside, the electromagnetic chuck main body 61 is publicly known, and thus detailed description of its configuration and operation is omitted.

**[p0026]**

ï¼ï¼âï¼ï¼ä¸å¯¾ã®å¸çæ¯æé¨æï¼ æ¬å®æ½å½¢æ ã§ã¯ãä¸è¿°ããããã«ãé¢æ¿ï¼ï¼ï½ã®ä¸é¢ã«ä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ãï¼çµåãã¦ãããå³ï¼ã«ç¤ºãããã«ï¼çµã®åå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã¯ãç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ãç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ãç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ãç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ãç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ãç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ãç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½åã³ç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã«ããããè·¨ã£ã¦é ç½®ãããã (1-3. A pair of adsorption support members) In the present embodiment, as described above, eight pairs of suction support members 62 and 63 are provided on the upper surface of the face plate 61a. As shown in FIG. 3, each of the eight sets of suction support members 62, 63 includes upper surfaces 71a, 72a of magnetic pole portions 71, 72, upper surfaces 72a, 73a of magnetic pole portions 72, 73, and upper surfaces 73a, 74a of magnetic pole portions 73, 74. The upper surfaces 74a and 75a of the magnetic pole portions 74 and 75, the upper surfaces 75a and 76a of the magnetic pole portions 75 and 76, the upper surfaces 76a and 77a of the magnetic pole portions 76 and 77, the upper surfaces 77a and 78a of the magnetic pole portions 77 and 78, and the magnetic pole portions 78 and 71. Are disposed so as to straddle the upper surf

**[p0026]**

aces 77a and 78a.

**[p0027]**

ã¤ã¾ããåå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã¯ãå ¨ã¦ã®å¢çï¼ï¼ï¼¬ãï¼ï¼ï¼¬ã®å¨æ¹åä¸¡å´ã«ããããé ç½®ãããããªããå¨æ¹åã¨ã¯ãé¢æ¿ï¼ï¼ï½ã®ä¸­å¿è»¸ç·ï¼§ãä¸­å¿ã¨ããé¢æ¿ï¼ï¼ï½ä¸é¢ã«ãããå¨æ¹åããããã®ã¨ãããä»¥éã®èª¬æã«ããã¦ãèª¬æãªããå¨æ¹åãã¨ã®ã¿è¨è¼ããå ´åã¯ããã®å¨æ¹åã®ãã¨ããããã®ã¨ããã Â Â That is, the suction support members 62 and 63 are respectively disposed on both sides in the circumferential direction of all the boundaries 71L to 78L. The circumferential direction refers to the circumferential direction on the upper surface of the face plate 61a around the central axis G of the face plate 61a. In the following explanation, when only âcircumferential directionâ is described without explanation, it means the circumferential direction. ï¼çµã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã¯ãããããåæ§ã®å½¢ç¶ã«ãã£ã¦å½¢æãããããã£ã¦ãä»¥éã§ã¯ãä¸»ã«ç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã«é

**[p0028]**

ç½®ãããä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ã¿ãåãåºãèª¬æããã Â Â The eight sets of suction support members 62 and 63 are each formed in the same shape. Therefore, hereinafter, only the pair of suction support members 62 and 63 arranged mainly on the upper surfaces 76a and 77a of the magnetic pole portions 76 and 77 will be described. å³ï¼ã«ç¤ºãããã«ãããããèª¬æããå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã¯ãï¼åã®ç£æ¥µé¨ã®ãã¡ã®é£ãåãç£æ¥µé¨ï¼ï¼ï¼ï¼®æ¥µï¼ï¼åã³ç£æ¥µé¨ï¼ï¼ï¼ï¼³æ¥µï¼éã®å¢çï¼ï¼ï¼¬ãæãã§é ç½®ããããã¾ããå³ï¼ï¼å³ï¼ã«ç¤ºãããã«ãä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã¯ãä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ï¼ç¬¬ä¸å¹³é¢ã«ç¸å½ï¼ã¨ãå¯¾åé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¨ãä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ï¼ç¬¬äºå¹³é¢ã«ç¸å½ï¼ã¨ãèåé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¨ãå¾æ¹åå å´é¢ï¼ï¼ï½ ï¼ï¼ï¼ï½ ã¨ãå¾æ¹åå¤å´é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¨ããåããå ­é¢ä½ã®é¨æã§ãããå³ï¼ãå³ï¼ã«ç¤ºãããã«ãä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¯ãç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼ã®åä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¨ããããæ¥è§¦é¢ç©ï¼é¢ç©ï¼ï¼³ï¼ï¼ï¼³ï¼ã§æ¥è§¦ããã

**[p0029]**

Â Â As shown in FIG. 3, the suction support members 62 and 63 described below sandwich a boundary 76 </ b> L between adjacent magnetic pole portions 76 (N poles) and magnetic pole portions 77 (S poles) of the eight magnetic pole portions. It is arranged with. As shown in FIGS. 4 and 5, the pair of suction support members 62 and 63 includes lower surfaces 62 a and 63 a (corresponding to the first plane), opposing surfaces 62 b and 63 b, and upper surfaces 62 c and 63 c (second plane). And a back surface 62d, 63d, a radially inner surface 62e, 63e, and a radially outer surface 62f, 63f. As shown in FIGS. 5 and 6, the lower surfaces 62a and 63a are in contact with the upper surfaces 76a and 77a of the magnetic pole portions 76 and 77 at contact areas (areas) S1 and S1, respectively. å³ï¼ã«ç¤ºãããã«å¯¾åé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¯ãå¢çï¼ï¼ï¼¬ãæãã ç¶æ ã§ãä¸ã¤å¯¾åããåå¯¾åé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ãæå®ã®ééÎ±ï¼ãæããç¶æ ã§ç¸äºã«å¹³è¡ã«é

**[p0030]**

ç½®ããããã¾ãå¯¾åé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¯ãå¢çï¼ï¼ï¼¬åã³é»ç£ãã£ãã¯æ¬ä½ï¼ï¼ã®ä¸­å¿è»¸ç·ãå«ãä»®æ³å¹³é¢ã¨å¹³è¡ã§ãããã Â Â As shown in FIG. 4, the opposing surfaces 62b and 63b are arranged in parallel to each other with the boundary 76L interposed therebetween and the opposing opposing surfaces 62b and 63b having a predetermined gap Î±1. The facing surfaces 62b and 63b are also parallel to a virtual plane including the boundary 76L and the central axis of the electromagnetic chuck main body 61. æå®ã®ééÎ±ï¼ã¯ãä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¨å¹³è¡ã§ä¸ã¤èåããåå¯¾åé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¨ç´äº¤ãé£ç¶ãã¦å½¢æãããä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ï¼å³ï¼ä¸­ã®æç·é¨åç §ï¼ã®ä½ç½®ããé¢æ¿ï¼ï¼ï½ä¸é¢ã«ãããå¨æ¹åã«ããã¦ãç¸äºã«ã§ããã ãæ¥è¿ãããããè¨­å®ããããã®ã§ããã Â Â The predetermined gap Î±1 is parallel to the lower surfaces 62a and 63a and faces backward, and the positions of the upper surfaces 62c and 63c (see hatched portions in FIG. 6) formed continuously perpendicular to the opposing surfaces 62b and 63b, In the circumferential direction on the upper surface of the face plate 61a, it is set so as to be as close as possible to each other.

**[p0031]**

ãªããä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¯ãæ¥è§¦ããå·¥ä½ç©ï¼·ã®è¢«å¸çé¢ï¼·ï½ãå¸çãåºå®ããé¨ä½ã§ãããå³ï¼ã«ç¤ºãããã«ãæ¬å®æ½å½¢æ ã«ããã¦ã¯ãé»ç£ãã£ãã¯æ¬ä½ï¼ï¼ã®ä¸­å¿è»¸ç·æ¹åããè¦ãå ´åãä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã®åé¢ç©ï¼³ï¼ï¼ï¼³ï¼ï¼æç·é¨ï¼ã¯ãä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã®æ¥è§¦é¢ç©ï¼³ï¼ï¼ï¼³ï¼ãããå°ããï¼ï¼³ï¼>ï¼³ï¼ï¼ãä¸ã¤å¢çï¼ï¼ï¼¬å´ã«å¯ã£ã¦é ç½®ããããã¾ããä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã§ã¯ãå¯¾åé¢ï¼ï¼ï½ï¼ï¼ï¼ï½å´ã®è¾ºã¨å¯¾åããå´ã®è¾ºãé¢æ¿ï¼ï¼ï½ã®å¤å¨å´ããä¸­å¿è»¸ç·ï¼ï¼§ï¼ã¨äº¤å·®ããæ¹åã«åãå¾æãã¦å½¢æãããã Â Â The upper surfaces 62c and 63c are portions that suck and fix the attracted surface Wa of the workpiece W that comes into contact therewith. As shown in FIG. 6, in this embodiment, when viewed from the central axis direction of the electromagnetic chuck main body 61, the areas S2, S2 (shaded portions) of the upper surfaces 62c, 63c are the contact areas S1 of the lower surfaces 62a, 63a. , S1 (S1> S2), and arranged closer to the boundary 76L. In addition, the upper surfaces 62c and 63c are formed so that the side opposite to the side facing the opposing surfaces 62b and 63b is inclined from the outer peripheral side of the face plate 61a toward the direction intersecting the central axis (G).

**[p0032]**

ãã®ããã«ãä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ãä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ããå°ããããä¸ã§ãããã«ç¸äºã«æ¥è¿ããããã¨ãã¤ã¾ãæå®ã®ééÎ±ï¼ãå°ãããããã¨ã«ãããå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã«ãã£ã¦å½¢æãããå·¥ä½ç©ï¼·ã®è¢«å¸çé¢ï¼·ï½ï¼ä¸é¢ï¼ãæ¯æããæ¯æé¨ï¼³ï¼°ï¼å³ï¼åç §ï¼ã«å¿ããææè§åº¦Î¸ï¼ãå°ãããããã¨ãã§ããã Â Â As described above, the upper surfaces 62c and 63c are made smaller than the lower surfaces 62a and 63a, and are made closer to each other, that is, the predetermined gap Î±1 is reduced, thereby forming the upper surfaces 62c and 63c of the suction support members 62 and 63. The gripping angle Î¸1 corresponding to the support portion SP (see FIG. 7) that supports the attracted surface Wa (lower surface) of the workpiece W to be performed can be reduced. ãªãããã®ã¨ããæ¯æé¨ï¼³ï¼°ã¨ã¯ãå³ï¼ã«ç¤ºãããã«ãé¢æ¿ï¼ï¼ï½ã®ä¸­å¿è»¸ç·æ¹åããã¿ãå ´åã«ããã¦ãå·¥ä½ç©ï¼·ã®è¢«å¸çé¢ï¼·ï½ã¨ãå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¨ãäº¤å·®ããç¯å²ã®ãã¡ãä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã®éã®ééÎ±ï¼åãå«ãã æç·é¨ã®ç¯å²ããããããã¦ãææè§åº¦Î¸ï¼ã¯ãé¢æ¿ï¼ï¼ï½ã®ä¸­å¿è»¸ç·ï¼ï¼§ï¼ã¨ãä¸­å¿è»¸ç·æ¹åããã¿ãå¤è§å½¢ã®æ¯æé¨ï¼³ï¼°ã®åé ç¹ã¨ããçµãã åç·ååå£«ããªãè§åº¦ã®ãã¡æå¤§ã¨ãªãè§åº¦ããããã®ã¨ããï¼å³ï¼åç

**[p0033]**

§ï¼ã Â Â At this time, as shown in FIG. 7, the support portion SP refers to the surface to be attracted Wa of the workpiece W and the upper surfaces 62c and 63c of the suction support members 62 and 63 when viewed from the central axis direction of the face plate 61a. In the range where and intersect, the hatched range including the gap Î±1 between the upper surfaces 62c and 63c. The gripping angle Î¸1 is the maximum angle among the angles formed by the line segments connecting the center axis (G) of the face plate 61a and the vertices of the polygonal support portions SP viewed from the center axis direction. It shall be (see FIG. 7). ããã«ãããå·¥ä½ç©ï¼·ã®è¢«å¸çé¢ï¼·ï½ï¼ä¸é¢ï¼ããä¾ãã°ãï¼çµã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã«ããï¼ç®æã§å¸çãæ¯æï¼åºå®ï¼ããå ´åã«ã¯ãè¢«å¸çé¢ï¼·ï½ã¯ãå¨æ¹åã«ããã¦ããããææè§åº¦Î¸ï¼ã¨ããååç­ãç¯å²ã§æ¯æãããããã®ãããè¢«å¸çé¢ï¼·ï½ããé¢æ¿ï¼ï¼ï½ã®ä¸é¢ã®åºãç¯å²ã§å¸çåºå®ãããå ´åã«çããããå·¥ä½ç©ï¼·ã®å¤å½¢ãå¹æçã«æå¶ã§ããããªããããã§ãããï¼ç®æã¨ã¯ãï¼å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®åä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ãå

**[p0034]**

¨ã¦è¢«å¸çé¢ï¼·ï½ã¨æ¥è§¦ããç¶æ ããããã®ã¨ããã Â Â As a result, when the surface to be attracted (bottom surface) of the workpiece W is attracted and supported (fixed) at, for example, three locations by three pairs of suction support members 62 and 63, the attracted surface Wa is in the circumferential direction. Are supported within a sufficiently narrow range of gripping angle Î¸1. For this reason, it is possible to effectively suppress deformation of the workpiece W that is likely to occur when the attracted surface Wa is attracted and fixed in a wide range of the upper surface of the face plate 61a. Here, the three locations refer to a state in which the upper surfaces 62c and 63c of the three pairs of suction support members 62 and 63 are all in contact with the attracted surface Wa. ãªããåèã¨ãã¦ææè§åº¦Î¸ï½ï½ ï½ï¼æ¨ªè»¸ï¼ã¨å·¥ä½ç©ï¼·ã®å¤å½¢éï¼ç¸¦è»¸ï¼ã¨ã®é¢ä¿ãå³ï¼ã«ç¤ºããå³ï¼ã®ã°ã©ãã¯ãå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®æ¯æå¹

**[p0035]**

ã®å¤åã«å¯¾ãã¦ã®å·¥ä½ç©ï¼·ã®å¤å½¢éãåæãããã®ã§ãããï¼£ï¼¡ï¼¥è§£æç­ã«ãããã®ã§ããï¼ï¼ç¹æ¯æï¼ï¼çµã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ï¼ãå³ï¼ã®ã°ã©ããç¤ºãããã«ãææè§åº¦Î¸ï¼ã¾ã§ã®éã«ããã¦ã¯ãææè§åº¦Î¸ãå°ããã»ã©å·¥ä½ç©ï¼·ã®å¤å½¢éã¯å°ãããã¨ãããããå¾ã£ã¦æ¬å®æ½å½¢æ ã§è¨­å®ããæå®ã®ææè§åº¦Î¸ï¼ã¯ãï¼ï½ï½ ï½ãææè§åº¦Î¸ï¼ã¾ã§ã®éã§è¨­å®ããããã¨ãå¥½ã¾ããã Â Â For reference, the relationship between the gripping angle Î¸deg (horizontal axis) and the deformation amount (vertical axis) of the workpiece W is shown in FIG. The graph of FIG. 8 is obtained by analyzing the deformation amount of the workpiece W with respect to the change in the support width of the suction support members 62 and 63, and is based on CAE analysis or the like (three-point support; three sets of suction). Support members 62, 63). As shown in the graph of FIG. 8, it can be seen that the deformation amount of the workpiece W is smaller as the grip angle Î¸ is smaller until the grip angle Î¸2. Therefore, the predetermined gripping angle Î¸1 set in the present embodiment is preferably set between 0 deg and the gripping angle Î¸2.

**[p0036]**

ããããªãããæå®ã®ææè§åº¦Î¸ï¼ãå°ãããããããæå®ã®ééÎ±ï¼ãå°ããããã«ãéåº¦ããããã¤ã¾ããæå®ã®ééÎ±ï¼ãå°ããããã¨ãä¾ãã°ãå¸çæ¯æé¨æï¼ï¼ãééããç£æã®ä¸é¨åã¯å¤§é¨åããå¯¾åé¢ï¼ï¼ï½ã¨å¯¾åããå¸çæ¯æé¨æï¼ï¼ã®å¯¾åé¢ï¼ï¼ï½ã«åããæ¼ãã¦ãã¾ãå ´åãããï¼ç©ºæ°ä¸­ç­ã«ç£æãæ¼ããï¼ã Â Â However, there is a limit to reducing the predetermined gap Î±1 in order to reduce the predetermined gripping angle Î¸1. That is, if the predetermined gap Î±1 is too small, for example, a part or most of the magnetic flux passing through the suction support member 62 may leak toward the facing surface 63b of the suction support member 63 facing the facing surface 62b. Yes (magnetic flux leaks into the air). ãªããå¯¾åé¢ï¼ï¼ï½ã¨å¯¾åé¢ï¼ï¼ï½ã¨ã®éã®ééÎ±ï¼æ¨ªè»¸ï¼ã¨ãå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼åã³å·¥ä½ç©ï¼·ãééããç£æå¯åº¦ï¼¢ã®å¤§ããï¼ç¸¦è»¸ï¼ã¨ã®é¢ä¿ãåèã¨ãã¦å³ï¼ã®ã°ã©ãã§ç¤ºããå³ï¼ã®ã°ã©ãã¯ãï¼£ï¼¡ï¼¥è§£æç­ã«ãããã®ã§ãããå³ï¼ã®ã°ã©ããç¤ºãããã«ãééÎ±ãÎ±ï¼ãè¶ããã¾ã§ã¯ãééÎ±ã®å¤§ãããå¢å ããã¨ç£æå¯åº¦ï¼¢ã¯å¢å ãããããã¯ãå¯¾åé¢ï¼ï¼ï½ã¨å¯¾åé¢ï¼ï¼ï½ã¨ã®éãééããç£æã®éï¼æ¼ãç£æéï¼ãæ¸å°ããããã§ãããããããééÎ±ï¼ãè¶ããã¨ç£æå¯åº¦ï¼¢ã¯æ¸å°ãããããã¯ãç£æãééããç£è·¯ã®å

**[p0037]**

¨ä½ã®é·ããé·ããªãæµæã¨ãªãããã§ãããå¾ã£ã¦ãæ¬å®æ½å½¢æ ã§è¨­å®ããæå®ã®ééÎ±ï¼ã¯ãææã®ç£æå¯åº¦ï¼¢ãå¾ãããç¯å²ï¼¡ï½ï¼å ã§è¨­å®ããããã¨ãå¥½ã¾ããã Â Â The relationship between the gap Î± (horizontal axis) between the facing surface 62b and the facing surface 63b and the magnitude (vertical axis) of the magnetic flux density B passing through the suction support members 62 and 63 and the workpiece W is referred to. This is shown in the graph of FIG. The graph of FIG. 9 is based on CAE analysis or the like. As shown in the graph of FIG. 9, the magnetic flux density B increases as the size of the gap Î± increases until the gap Î± exceeds Î±2. This is because the amount of magnetic flux (leakage magnetic flux) passing between the facing surface 62b and the facing surface 63b decreases. However, when the gap Î±2 is exceeded, the magnetic flux density B decreases. This is because the entire length of the magnetic path through which the magnetic flux passes becomes longer and becomes resistance. Accordingly, the predetermined gap Î±1 set in the present embodiment is preferably set within a range Ar1 in which a desired magnetic flux density B is obtained.

**[p0038]**

æå®ã®ééÎ±ï¼åã³æå®ã®ææè§åº¦Î¸ï¼ã¯ãä¸è¨ã®åæ¡ä»¶ãä¸¡ç«ãããããäºåã®æ¤è¨ã«ãã£ã¦äºãæ±ãè¨­å®ããããããã«ãããå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã«ã¯ãè¯å¥½ã«ç£æ°åãçºçãå·¥ä½ç©ï¼·ã«å¯¾ãã¦ååãªå¸çåãå¾ããã¨ãã§ããã Â Â The predetermined gap Î±1 and the predetermined gripping angle Î¸1 are obtained and set in advance by prior examination so as to make the above-described conditions compatible. Thereby, a magnetic force is generated satisfactorily on the upper surfaces 62c and 63c of the adsorption support members 62 and 63, and a sufficient adsorption force for the workpiece W can be obtained. ããã¦ãä¸è¨ã®ããã«å½¢æãããä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ãä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½åã³å¯¾åé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã®åè¾ºãæ¥ç¶ãã¦èåé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ãå¾æ¹åå å´é¢ï¼ï¼ï½ ï¼ï¼ï¼ï½ ãåã³å¾æ¹åå¤å´é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ãå½¢æããããå³ï¼ã«ç¤ºãããã«ãèåé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¯ãåå¯¾åé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã«å¯¾ãã¦ããããå¾æãæããç¶æ

**[p0039]**

ã§èåãã¦å½¢æãããã Â Â Then, the respective sides of the upper surfaces 62c and 63c, the lower surfaces 62a and 63a and the opposing surfaces 62b and 63b formed as described above are connected to each other so that the back surfaces 62d and 63d, the radially inner side surfaces 62e and 63e, and the radially outer surface are connected. Side surfaces 62f and 63f are formed. As shown in FIG. 5, the back-facing surfaces 62d and 63d are formed facing back in a state of being inclined with respect to the facing surfaces 62b and 63b. ã¤ã¾ããèåé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¯ãé»ç£ãã£ãã¯æ¬ä½ï¼ï¼ã®ä¸­å¿è»¸ç·æ¹åã«ããã¦ãä¸æ¹ããä¸æ¹ã«åã£ã¦åå¯¾åé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¨ã®è·é¢ãæ¼¸æ¸ããããå¾æãã¦ãããã¾ããèåé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¯ãé¢æ¿ï¼ï¼ï½ã®å¤å¨å´ããä¸­å¿è»¸ç·ã«åãåå¯¾åé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¨ã®è·é¢ãæ¼¸æ¸ããããå¾æãã¦ããã Â Â That is, the back surfaces 62d and 63d are inclined so that the distance from the opposing surfaces 62b and 63b gradually decreases from the bottom to the top in the central axis direction of the electromagnetic chuck main body 61. Further, the back-facing surfaces 62d and 63d are inclined so that the distance from the opposing surfaces 62b and 63b gradually decreases from the outer peripheral side of the face plate 61a toward the central axis.

**[p0040]**

ãªããä¸è¨æ æ§ã¯ãããã¾ã§ä¸ä¾ã§ãã£ã¦ãå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã¯ãå°ãªãã¨ããä¸é¢ãå¯¾åé¢ãä¸é¢ãåã³èåé¢ãåãã¦ããã°ãã©ã®ããã«å½¢æããã¦ãè¯ããã¾ããä¸è¨ã«ããã¦ãåå¯¾åé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¯ãå¹³è¡ã§ããã¨è¿°ã¹ããããã®æ æ§ã«ã¯éããªããåå¯¾åé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¯ãå¯¾åé¢ï¼ï¼ï½ï¼ï¼ï¼ï½éãééããç£æéãåã³ææè§åº¦Î¸ï¼ç­ãè¨±å®¹ãããç¯å²å ã«å ¥ã£ã¦ããã°ãç¸äºã«å¾ããæãã¦å½¢æããã¦ãè¯ãã Â Â In addition, the said aspect is an example to the last, Comprising: As long as the adsorption | suction support members 62 and 63 are provided with the lower surface, the opposing surface, the upper surface, and the back surface, they may be formed in any way. Moreover, in the above, although each opposing surface 62b and 63b was described as parallel, it is not restricted to this aspect. The opposing surfaces 62b and 63b may be formed with an inclination to each other as long as the amount of magnetic flux passing between the opposing surfaces 62b and 63b, the gripping angle Î¸1 and the like are within the allowable range.

**[p0041]**

ã¾ããé¢æ¿ï¼ï¼ï½ã®ä¸é¢ã«ããã¦ãï¼çµã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ãé ç½®ãããä½ç½®ã¯ãå³ï¼ã«ç¤ºãããã«ãé¢æ¿ï¼ï¼ï½ã®ä¸­å¿è»¸ç·ãä¸­å¿ã¨ããåä¸åå¨ä¸ã§ããããªãããã®ã¨ããï¼çµã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®åä½ç½®ã¯ã©ã®ããã«å®ç¾©ãè¨­å®ãã¦ããããä¾ãã°ãä¸è¿°ããæ¯æé¨ï¼³ï¼°ã®éå¿ããé¢æ¿ï¼ï¼ï½ã®ä¸­å¿è»¸ç·ãä¸­å¿ã¨ããåä¸åå¨ä¸ã«é ç½®ãããããã«ãã¦ãããã Â Â In addition, on the upper surface of the face plate 61a, the positions where the eight sets of suction support members 62 and 63 are arranged are on the same circumference with the central axis of the face plate 61a as the center, as shown in FIG. At this time, the positions of the eight sets of suction support members 62 and 63 may be defined and set in any way. For example, the center of gravity of the support part SP described above may be arranged on the same circumference centered on the central axis of the face plate 61a.

**[p0042]**

ï¼ï¼âï¼ï¼å¶å¾¡è£ ç½®ï¼ å¶å¾¡è£ ç½®ï¼ï¼ã®ä¸é¨ã¯ãé»ç£ãã£ãã¯è£ ç½®ï¼ï¼ãæ§æããã¨ã¨ãã«ãæ©è½çæ§æã¨ãã¦ãã³ã©ã ï¼ã®éãã®å¶å¾¡ãç ¥ç³å°ï¼ã®æéã®å¶å¾¡ãä¸»è»¸å°ï¼ï¼ã®åè»¢ã¨é»ç£ãã£ãã¯æ¬ä½ï¼ï¼ã®å¸å¼ã®å¶å¾¡ãç ¥ç³è»ï¼ã®åè»¢ã®å¶å¾¡ãåã³ãã¼ã¿ããã­ã°ã©ã ã®è¨é²ç­ãè¡ãªããå¶å¾¡è£ ç½®ï¼ï¼ã¯ãäºãè¨­å®ãããå¶å¾¡ãã¼ã¿ã«åºã¥ããåè£ ç½®ãå¶å¾¡ãããã¨ã§ç åãå®æ½ããã (1-4. Control device) A part of the control device 64 constitutes the electromagnetic chuck device 60 and, as functional configurations, controls the feed of the column 3, controls the lifting and lowering of the grindstone table 4, rotates the headstock 40, and sucks the electromagnetic chuck main body 61. Control, control of rotation of the grinding wheel 9, recording of data and programs, and the like are performed. The control device 64 performs grinding by controlling each device based on preset control data.

**[p0043]**

ã¾ããå¶å¾¡è£ ç½®ï¼ï¼ã¯ãç¬¬ä¸å¦çé¨ï¼ï¼ï¼¡ãç¬¬å ­å¦çé¨ï¼ï¼ï¼¦ãåãããç¬¬ä¸å¦çé¨ï¼ï¼ï¼¡ã¯ãå·¥ä½ç©ï¼·ããï¼çµããä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®åç¬¬äºå¹³é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ä¸ã«è¼ç½®ãããã¨ãã«ãå·¥ä½ç©ï¼·ã®è¢«å¸çé¢ï¼·ï½ãæ¥è§¦ããä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã¯ãã©ãã§ãããç¢ºèªï¼ç¹å®ï¼ããã Â Â The control device 64 includes a first processing unit 64A to a sixth processing unit 64F. When the workpiece W is placed on the second flat surfaces 62c and 63c of the eight pairs of suction support members 62 and 63, the first processing unit 64A is brought into contact with the suction surface Wa of the workpiece W. It is confirmed (identified) which of the pair of suction support members 62 and 63 is. å ·ä½çã«ã¯ãä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ããããã«ã¯ãä¾ãã°ï¼¡ï¼¥ã»ã³ãµï¼ï¼ãåãä»ããããï¼å³ï¼åç §ï¼ãããã¦ãå·¥ä½ç©ï¼·ãå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã«è¼ç½®ãããéãä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¨æ¥è§¦ãçºçãããæ¯åãï¼¡ï¼¥ã»ã³ãµï¼ï¼ã«ãã£ã¦æ¤åºãããç¬¬ä¸å¦çé¨ï¼ï¼ï¼¡ã«éä¿¡ããããç¬¬ä¸å¦çé¨ï¼ï¼ï¼¡ã¯ããã®ä¿¡å·ã«åºã¥ããè¢«å¸çé¢ï¼·ï½ã¨ä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ï¼ç¬¬äºå¹³é¢ï¼ã¨ãæ¥è§¦ããå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ãç¹å®ãããããã¦ãç¹å®ããå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ãç¤ºãä¿¡å·ããç¬¬äºå¦çé¨ï¼ï¼ï¼¢ã«éä¿¡ãããã

**[p0044]**

Â Â Specifically, for example, an AE sensor 65 is attached to each of the pair of suction support members 62 and 63 (see FIG. 3). Then, when the workpiece W is placed on the upper surfaces 62c and 63c of the suction support members 62 and 63, the vibration generated in contact with the upper surfaces 62c and 63c is detected by the AE sensor 65 and transmitted to the first processing unit 64A. The Based on this signal, the first processing unit 64A specifies the suction support members 62 and 63 in which the suction target surface Wa and the upper surfaces 62c and 63c (second plane) are in contact with each other. And the signal which shows the specified adsorption | suction support members 62 and 63 is transmitted to the 2nd process part 64B. ç¬¬äºå¦çé¨ï¼ï¼ï¼¢ã¯ãç¬¬ä¸å¦çé¨ï¼ï¼ï¼¡ã«ããã¦ãè¢«å¸çé¢ï¼·ï½ã¨ã®æ¥è§¦ãç¢ºèªãããä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ãåºå®ãããç£æ¥µé¨ãåããã³ã¤ã«ã«éé»ããè©²å½ããç£æ¥µé¨ã«ç£æ°åãçºçããããã¤ã¾ããæ¥è§¦ãæ¤åºãããä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ãåºå®ãããç£æ¥µé¨ï¼ï¼ãï¼ï¼ã®ãã¡ã®ããããã®ç£æ¥µé¨ãå¶å¾¡ãã¦ç£æ°åãçºçããããããã«ãããæ¥è§¦ããä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ï¼ç¬¬äºå¹³é¢ï¼ã¨è¢«å¸çé¢ï¼·ï½ã¨ãå¸çãããã

**[p0045]**

Â Â In the first processing unit 64A, the second processing unit 64B energizes the coil provided in the magnetic pole unit to which the pair of suction support members 62 and 63 that have been confirmed to be in contact with the attracted surface Wa, and the corresponding magnetic pole unit. To generate magnetic force. That is, the magnetic force is generated by controlling any one of the magnetic pole portions 71 to 78 to which the pair of suction support members 62 and 63 in which contact is detected is fixed. Thereby, the upper surfaces 62c and 63c (second plane) and the attracted surface Wa that are in contact with each other are adsorbed. ç¬¬ä¸å¦çé¨ï¼ï¼ï¼£ã¯ãã³ã©ã ï¼ã®éãã®å¶å¾¡ãç ¥ç³å°ï¼ã®æéã®å¶å¾¡ãä¸»è»¸å°ï¼ï¼ã®åè»¢å¶å¾¡ç­ãè¡ãªããå·¥ä½ç©ï¼·ã®è¢«å¸çé¢ï¼·ï½ã¨èåããå·¥ä½ç©ï¼·ã®ç«¯é¢ãç ¥ç³è»ï¼ã«ãã£ã¦ç åå å·¥ããã ç¬¬åå¦çé¨ï¼ï¼ï¼¤ã¯ãç£æ¥µé¨ã®ã³ã¤ã«ã¸ã®éé»ãåæ­¢ãã¦è¢«å¸çé¢ï¼·ï½ã®å¸çãè§£é¤ãããããã¦ãå³ç¥ã®åè»¢è£

**[p0046]**

ç½®ï¼ã­ãããï¼ãå¶å¾¡ãã¦ãç«¯é¢ãå å·¥ãããå·¥ä½ç©ï¼·ãè¡¨è£åè»¢ããããããã«ãããç¬¬ä¸å¦çé¨ï¼ï¼ï¼£ã«ãã£ã¦ç åå å·¥ãããç«¯é¢ãè¢«å¸çé¢ã¨ããããªããå·¥ä½ç©ï¼·ã®è¡¨è£ãåè»¢ããããã¨ãã§ããã°ãåè»¢è£ ç½®ã«ã¯ãã©ã®ãããªè£ ç½®ãç¨ãã¦ãè¯ãã The third processing unit 64C performs control of feeding of the column 3, control of raising and lowering of the grindstone table 4, rotation control of the headstock 40, and the like, and the end surface of the workpiece W facing away from the attracted surface Wa of the workpiece W. Grinding is performed by the grinding wheel 9. The fourth processing unit 64D stops energization of the coil of the magnetic pole part and releases the suction of the attracted surface Wa. Then, a reversing device (robot) (not shown) is controlled so that the workpiece W whose end face is machined is reversed. Thereby, the end surface ground by the third processing unit 64C is set as the attracted surface. In addition, as long as the front and back of the workpiece W can be reversed, any device may be used as the reversing device.

**[p0047]**

ç¬¬äºå¦çé¨ï¼ï¼ï¼¥ã¯ãåç£æ¥µé¨ï¼ï¼ãï¼ï¼ã®åã³ã¤ã«ãéé»å¶å¾¡ããï¼çµå ¨ã¦ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®åä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ãä¸è¨è¢«å¸çé¢ï¼·ï½ã®å ¨é¢ã«å¸çãããããã®ã¨ããè¢«å¸çé¢ï¼·ï½ï¼å¹³é¢ç åç­ããã¦ããï¼ã¯ãè¯å¥½ãªå¹³é¢åº¦ãæãã¦ããããã®ãããå·¥ä½ç©ï¼·ã¯ãï¼çµå ¨ã¦ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã«ãã£ã¦ãæ­ªããã¨ãªãéå¸¸ã«å¼·åºã«å¸çåºå®ãããããã ãããã®æ æ§ã«éãããç¬¬äºå¦çé¨ï¼ï¼ï¼¢ã§å¸çãããï¼çµã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ã¿ã«ãã£ã¦è¢«å¸çé¢ï¼·ï½ãå¸çãã¦ããããè¢«å¸çé¢ï¼·ï½ã¯ãå¹³é¢ç åç­ãè¡ãªã£ã¦ãè¯å¥½ãªå¹³é¢åº¦ãæãã¦ãããããããã«ãã£ã¦ããååå¼·åºã«åºå®ã§ãããåãï¼çµã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ãè¶ ããï¼ãï¼çµã®ä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã«ãã£ã¦è¢«å¸çé¢ï¼·ï½ãå¸çãã¦ãè¯ãã

**[p0048]**

Â Â The fifth processing unit 64E controls energization of the coils of the magnetic pole units 71 to 78, and adsorbs the upper surfaces 62c and 63c of all the eight sets of adsorption support members 62 and 63 to the entire surface of the adsorption surface Wa. At this time, the attracted surface Wa (surface grinding or the like) has a good flatness. For this reason, the workpiece W is adsorbed and fixed very firmly without distortion by all of the eight adsorbing support members 62 and 63. However, the present invention is not limited thereto, and the attracted surface Wa may be adsorbed only by the three sets of adsorbing support members 62 and 63 adsorbed by the second processing unit 64B. Since the surface Wa to be attracted is subjected to surface grinding or the like and has good flatness, it can be fixed sufficiently firmly. Further, the suction surface Wa may be sucked by a pair of four to seven pairs of suction support members 62, 63 exceeding the three pairs of suction support members 62, 63.

**[p0049]**

ç¬¬å ­å¦çé¨ï¼ï¼ï¼¦ã¯ãåã³ã³ã©ã ï¼ã®éãã®å¶å¾¡ãç ¥ç³å°ï¼ã®æéã®å¶å¾¡ãä¸»è»¸å°ï¼ï¼ã®åè»¢å¶å¾¡ç­ãè¡ãªããããã«ãããç¬¬äºå¦çé¨ï¼ï¼ï¼¢ã§è¢«å¸çé¢ï¼·ï½ã¨ããç«¯é¢ãå¤å¨é¢åã³å å¨é¢ç­ãããããç ¥ç³è»ï¼ç­ã«ãã£ã¦ç åå å·¥ããå¶å¾¡ãè¡ãªãã Â Â The sixth processing unit 64F performs again the control of the feed of the column 3, the control of the lifting and lowering of the grindstone table 4, the rotation control of the headstock 40, and the like. As a result, the second processing unit 64B performs control to grind the end surface, outer peripheral surface, inner peripheral surface, and the like as the attracted surface Wa by the grinding wheel 9 or the like. æ¬¡ã«ãç åç¤ï¼ã«ãããå·¥ä½ç©ï¼·ã®æ¬å ¥ãæ¬åºç­ã«ã¤ãã¦èª¬æãããç åå å·¥åã«ããã¦ãå·¥ä½ç©ï¼·ã¯ãé»ç£ãã£ãã¯æ¬ä½ï¼ï¼ã®é¢æ¿ï¼ï¼ï½ä¸ã«åºå®ãããï¼çµããä¸å¯¾ã®åå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®åä¸é¢ï¼ï¼ï½ãï¼ï¼ï½ä¸ã«æ¬å

**[p0050]**

¥ãããï¼å³ï¼åç §ï¼ã Â Â Next, carrying in and out of the workpiece W in the grinding machine 1 will be described. Prior to grinding, the workpiece W is carried onto the upper surfaces 62c and 63c of the eight pairs of suction support members 62 and 63 fixed on the face plate 61a of the electromagnetic chuck main body 61 (see FIG. 3). . ãã®ã¨ããå·¥ä½ç©ï¼·ã®æ¬å ¥ã¯ãå³ç¥ã®ã­ãããã«ããè¡ããããã­ãããã¯ãå·¥ä½ç©ï¼·ã®ä¸­å¿è»¸ç·ãé»ç£ãã£ãã¯æ¬ä½ï¼ï¼ã®åè»¢ä¸­å¿ï¼ä¸­å¿è»¸ç·ï¼ã¨ä¸è´ãããç¶æ ã§ãå·¥ä½ç©ï¼·ãæ¬å ¥ããããæ§æããããã¾ããã­ãããã¯ãå·¥ä½ç©ï¼·ã®è¡¨è£ãåè»¢ãããåè»¢è£ ç½®ãå ¼ã­ããããã«ãã­ãããã¯ãä¾ãã°ããã¹ã¦ã®å å·¥ãçµäºããç åå å·¥çµäºå¾ã®å·¥ä½ç©ï¼·ã®æ¬åºãè¡ãªãããªããå·¥ä½ç©ï¼·ã®æ¬å ¥ãåè»¢åã³æ¬åºã¯ãä½æ¥­è ã®æä½æ¥­ã«ããè¡ãªã£ã¦ãããããã®å ´åã®ä¸è¨ä¸­å¿ä½ç½®åããã¯ãæ²»å

**[p0051]**

·ç­ãç¨ãã¦è¡ãªãã Â Â At this time, the workpiece W is carried in by a robot (not shown). The robot is configured to carry the workpiece W in a state where the center axis of the workpiece W is aligned with the rotation center (center axis) of the electromagnetic chuck main body 61. The robot also serves as a reversing device for reversing the front and back of the workpiece W. Furthermore, for example, the robot also carries out the workpiece W after completion of the grinding process in which all the processes have been completed. The workpiece W may be carried in, reversed, and carried out manually by the operator, and the center alignment in that case is performed using a jig or the like. ä¸è¨ã§èª¬æãããä¾ãã°ã­ãããã«ããæ¬å ¥ã«ãããå·¥ä½ç©ï¼·ã¯ãï¼çµããä¸å¯¾ã®åå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ãï¼ï¼ï½ä¸ã«è¼ç½®ãããããã®ã¨ããï¼çµããä¸å¯¾ã®åå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ãï¼ï¼ï½ã®ãã¡ãéå¸¸ãå°ãªãã¨ãï¼çµã®ä¸é¢ï¼ï¼ï½ãï¼ï¼ï½ä¸ã«è¢«å¸çé¢ï¼·ï½ãæ¥è§¦ãã¦è¼ç½®ãããã

**[p0052]**

Â Â The workpiece W is placed on the upper surfaces 62c and 63c of each of the eight pairs of suction support members 62 and 63 by carrying in, for example, a robot described above. At this time, among the upper surfaces 62c and 63c of the eight pairs of the suction support members 62 and 63, the surface to be sucked Wa is usually placed in contact with at least three sets of the upper surfaces 62c and 63c. ï¼ï¼âï¼ï¼é»ç£ãã£ãã¯è£ ç½®ã®è©³ç´°ã«ã¤ãã¦ï¼ æ¬¡ã«ãé»ç£ãã£ãã¯è£ ç½®ï¼ï¼ã®è©³ç´°ã«ã¤ãã¦èª¬æããããªããä»¥å¾ã«ããã¦ã¯ãèª¬æã®é½åä¸ããã®ã¨ãè¢«å¸çé¢ï¼·ï½ãæ¥è§¦ããã®ã¯ãç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼ãç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼åã³ç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼ã«åºå®ãããï¼çµã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®åä¸é¢ï¼ï¼ï½ãï¼ï¼ï½ã§ããã¨ä»®å®ãã¦èª¬æããã (1-5. Details of electromagnetic chuck device) Next, details of the electromagnetic chuck device 60 will be described. In the following description, for convenience of explanation, the attracted surface Wa is in contact with the magnetic pole portions 71 and 72, the magnetic pole portions 73 and 74, and the three sets of suction support members fixed to the magnetic pole portions 76 and 77. Description will be made assuming that the upper surfaces 62c and 63c of 62 and 63 are the upper surfaces.

**[p0053]**

å¶å¾¡è£ ç½®ï¼ï¼ã®å¶å¾¡ã«ããç£æãééããç£æ¥µé¨ï¼ï¼ï¼ï¼®æ¥µï¼ï¼åã³ç£æ¥µé¨ï¼ï¼ï¼ï¼³æ¥µï¼ã¯ãç¸äºã«ç°ãªãç£æ¥µï¼ï¼®æ¥µã¨ï¼³æ¥µï¼ã®çµã¿åããã§æ§æãããããã®ãããå³ï¼ï¼ã«ç¤ºããããªç£æï½ã®çµè·¯ï¼ç£è·¯ï¼ãç¢ºå®ã«å½¢æããããç£è·¯ã¯ãç£æ¥µé¨ï¼ï¼ï¼ï¼®æ¥µï¼âå¸çæ¯æé¨æï¼ï¼âå·¥ä½ç©ï¼·âå¸çæ¯æé¨æï¼ï¼âç£æ¥µé¨ï¼ï¼ï¼ï¼³æ¥µï¼ã®é ã«å½¢æãããããªããç£æ¥µé¨ï¼ï¼ï¼ï¼³æ¥µï¼ï¼ï¼ï¼ï¼ï¼®æ¥µï¼ãåã³ç£æ¥µé¨ï¼ï¼ï¼ï¼³æ¥µï¼ï¼ï¼ï¼ï¼ï¼®æ¥µï¼ç­ãåæ§ã§ããã Â Â The magnetic pole part 76 (N pole) and the magnetic pole part 77 (S pole) through which the magnetic flux passes under the control of the control device 64 are composed of combinations of different magnetic poles (N pole and S pole). For this reason, the path | route (magnetic path) of the magnetic flux b as shown in FIG. 10 is formed reliably. The magnetic path is formed in the order of magnetic pole part 76 (N pole) â adsorption support member 62 â workpiece W â adsorption support member 63 â magnetic pole part 77 (S pole). The same applies to the magnetic pole portions 71 (S pole) and 72 (N pole) and the magnetic pole portions 73 (S pole) and 74 (N pole).

**[p0054]**

ããã«ãããå°ãªãã¨ãï¼çµã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ãå·¥ä½ç©ï¼·ã®è¢«å¸çé¢ï¼·ï½ã«ï¼ç®æã§æ¥è§¦ãæ¯æããåæ¯æé¨ï¼³ï¼°ã§ã¯ãçºçããç£æ°åã«ãã£ã¦è¢«å¸çé¢ï¼·ï½ãå¼·åºã«å¸çãããããããããã®ã¨ããï¼çµã®åå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼éã§ã¯ãå¯¾åé¢ï¼ï¼ï½ï¼ï¼ï¼ï½éã®ééÎ±ããå°ããªæå®ã®ééÎ±ï¼ã§è¨­å®ããã¦ããããã®ãããããããè¢«å¸çé¢ï¼·ï½ã¨æ¥è§¦ããåä¸é¢ï¼ï¼ï½ãï¼ï¼ï½ãåå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®åå¯¾åé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¨æ¥ç¶ãããå´ãå³ã¡å¢çï¼ï¼ï¼¬å´ã«ããããå¯ã£ã¦å½¢æããããã¨ã«ãªããããã«ãããåè¿°ããããã«åæ¯æé¨ï¼³ï¼°ï¼å³ï¼åç §ï¼ã®ææè§åº¦Î¸ï¼ã¯ååå°ããã Â Â Thereby, in each support part SP which at least 3 sets of adsorption | suction support members 62 and 63 contact and support the to-be-sucked surface Wa of the workpiece W at three places, the to-be-sucked surface Wa is firmly attracted | sucked with the generated magnetic force. The However, at this time, the gap Î± between the opposing surfaces 62b and 63b is set to a small predetermined gap Î±1 between the three sets of the suction support members 62 and 63. Therefore, the upper surfaces 62c and 63c that are in contact with the surface to be attracted Wa are formed close to the side connected to the opposing surfaces 62b and 63b of the suction support members 62 and 63, that is, the boundary 76L side. Become. Thereby, as described above, the gripping

**[p0054]**

angle Î¸1 of each support portion SP (see FIG. 7) is sufficiently small.

**[p0055]**

ãã®ããã«ãå·¥ä½ç©ï¼·ã¯ãæ¯æé¨ï¼³ï¼°ã®ææè§åº¦Î¸ï¼ãååå°ããªãå°ãªãã¨ãï¼çµã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã«ãã£ã¦ãå¨æ¹åã®å°ãªãã¨ãï¼ç®æã§æ¯æããããå¾ã£ã¦ãå·¥ä½ç©ï¼·ã¯ãåæ¯æé¨ï¼³ï¼°ã§ããããå¼·åºã«å¸çããã¦ããããææãã©ã³ã¹åã³ææã«ããæã¿åãæé©ãªç¶æ ã§ãææããã¦ããï¼ææãã©ã³ã¹ï¼å·¥ä½ç©ï¼·ã®éå¿ä½ç½®ãæ¯æç¹ç¾¤ã®å å´ï¼ãææã«ããæã¿åï¼æ¯æç¹ãå·¥ä½ç©ï¼·ã®å½¢ç¶ã«ããæ¯æç¹éã®ããããçããå·¥ä½ç©ï¼·ã¸ã®æã¿åï¼ï¼ããã£ã¦ãå·¥ä½ç©ï¼·ã®å ¨é¢ãå¤å½¢ãããèã¯ä½ããã¾ããå·¥ä½ç©ï¼·ã¯ãä¸è¿°ããããã«ãå°ãªãã¨ãï¼çµã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã«ãã£ã¦å¼·åºã«å¸çä¿æãããããã®ãããè¢«å¸çé¢ï¼·ï½ã¨èåããç«¯é¢ã®ç åå å·¥æã«ãç ¥ç³è»ï¼ã¨ã®æ¥ç¹ã«ããã¦å·¥ä½ç©ï¼·ãç ¥ç³è»ï¼ããç åæµæãåãã¦ãå·¥ä½ç©ï¼·ãå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ã®ç åä½ç½®ãããããèã¯ãªããããã«ãããå·¥ä½ç©ï¼·ã¯ãç²¾åº¦ããç åå å·¥ãããã

**[p0056]**

Â Â In this way, the workpiece W is supported at least at three locations in the circumferential direction by the at least three sets of suction support members 62 and 63 having a sufficiently small gripping angle Î¸1 of the support portion SP. Accordingly, the workpiece W is firmly adsorbed by each support portion SP, but is gripped in a state where the gripping balance and the bending force due to gripping are optimal (the gripping balance (the position of the center of gravity of the workpiece W is supported)). The inside of the point cloud), the bending force due to gripping (the bending force on the workpiece W resulting from the shift between the supporting points due to the shape of the supporting points and the workpiece W)). Therefore, the possibility that the entire surface of the workpiece W is deformed is low. Further, as described above, the workpiece W is firmly sucked and held by at least three pairs of sucking support members 62 and 63. For this reason, even when the workpiece W receives a grinding resistance from the grinding wheel 9 at the contact point with the grinding wheel 9 during grinding of the end surface facing away from the attracted surface Wa, the workpiece W remains on the upper surfaces of the suction support members 62 and 63. There is no possibility of deviation from the grinding position. Thereby, the workpiece W is ground accurately.

**[p0057]**

ï¼ï¼âï¼.é»ç£ãã£ãã¯è£ ç½®ã®å¶å¾¡æ¹æ³ï¼ é»ç£ãã£ãã¯è£ ç½®ï¼ï¼ã®å¶å¾¡æ¹æ³ã«ã¤ãã¦å³ï¼ï¼ã®ãã­ã¼ãã£ã¼ãã«åºã¥ãèª¬æãããå³ï¼ï¼ã®ãã­ã¼ãã£ã¼ãã«ç¤ºãããã«ãã¹ãããï¼³ï¼ï¼ã«ããã¦ãå°ãªãã¨ãä¸¡ç«¯é¢ãæªç åã®å·¥ä½ç©ï¼·ã®ããããã®ç«¯é¢ãåå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ãï¼ï¼ï½ã«ä¸è¿°ããããã«ã­ãããã«ãã£ã¦è¼ç½®ããã (1-6. Control method of electromagnetic chuck device) A control method of the electromagnetic chuck device 60 will be described based on the flowchart of FIG. As shown in the flowchart of FIG. 11, in step S10, at least one end surface of the workpiece W whose both end surfaces are unground is placed on the upper surfaces 62c and 63c of the suction support members 62 and 63 by the robot as described above. To do. ã¹ãããï¼³ï¼ï¼ï¼ç¬¬ä¸å·¥ç¨ï¼ã§ã¯ãä¸é¢ï¼ï¼ï½ãï¼ï¼ï½ã¨å·¥ä½ç©ï¼·ã®è¢«å¸çé¢ï¼·ï½ã¨ã®æ¥è§¦ä½ç½®ãç¬¬ä¸å¦çé¨ï¼ï¼ï¼¡ã«ãã£ã¦ç¢ºèªï¼ç¹å®ï¼ããããå

**[p0058]**

·ä½çã«ã¯ãä¸è¿°ããããã«ãåå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã«ããããè¨­ããããåï¼¡ï¼¥ã»ã³ãµï¼ï¼ããå·¥ä½ç©ï¼·ãåå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ãï¼ï¼ï½ã«è¼ç½®ããéã«çºçããæ¯åãæ¤åºãããæ¬¡ã«ãï¼¡ï¼¥ã»ã³ãµï¼ï¼ãåå¾ããä¿¡å·ãããããç¬¬ä¸å¦çé¨ï¼ï¼ï¼¡ã«éä¿¡ããããããã¦ãç¬¬ä¸å¦çé¨ï¼ï¼ï¼¡ã«ããã¦ãï¼çµã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ãã¡ãå·¥ä½ç©ï¼·ã¨æ¥è§¦ããå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ãç¹å®ãããããªããï¼¡ï¼¥ã»ã³ãµï¼ï¼ã¯å ¬ç¥ã®ã»ã³ãµã§ãããããè©³ç´°ãªèª¬æã«ã¤ãã¦ã¯çç¥ããã Â Â In step S20 (first step), the contact position between the upper surfaces 62c and 63c and the attracted surface Wa of the workpiece W is confirmed (specified) by the first processing unit 64A. Specifically, as described above, when the AE sensors 65 provided on the suction support members 62 and 63 place the workpiece W on the upper surfaces 62c and 63c of the suction support members 62 and 63, respectively. Detect vibrations that occur. Next, the signals acquired by the AE sensor 65 are transmitted to the first processing unit 64A. In the first processing unit 64A, the suction support members 62 and 63 that are in contact with the workpiece W among the eight sets of suction support members 62 and 63 are specified. Since the AE sensor 65 is a known sensor, detailed description thereof is omitted.

**[p0059]**

èª¬æã®ãããã¹ãããï¼³ï¼ï¼ã«ããã¦ãå·¥ä½ç©ï¼·ã®è¢«å¸çé¢ï¼·ï½ã¯ãä¾ãã°ãç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼ãç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼åã³ç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼ã«åºå®ãããï¼çµã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®åä¸é¢ï¼ï¼ï½ãï¼ï¼ï½ã«æ¥è§¦ãã¦ãããã¨ãç¹å®ï¼ç¢ºèªï¼ã§ãããã®ã¨ããã Â Â For explanation, in step S20, the attracted surface Wa of the workpiece W is, for example, three sets of attracting support members 62 and 63 fixed to the magnetic pole portions 71 and 72, the magnetic pole portions 73 and 74, and the magnetic pole portions 76 and 77. It can be specified (confirmed) that the upper surfaces 62c and 63c are in contact with each other. ãã®å ´åãã¹ãããï¼³ï¼ï¼ã«ããã¦ãç¹å®ããç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼ãç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼åã³ç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼ã«åºå®ãããå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®æ å ±ãç¬¬ä¸å¦çé¨ï¼ï¼ï¼¡ããç¬¬äºå¦çé¨ï¼ï¼ï¼¢ã«éä¿¡ãããããã¦ãã¹ãããï¼³ï¼ï¼ï¼ç¬¬äºå·¥ç¨ï¼ã«ããã¦ãç¬¬äºå¦çé¨ï¼ï¼ï¼¢ããç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼ãç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼åã³ç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼ã®åã³ã¤ã«ã«é»æµãä¾çµ¦ï¼éé»ï¼ããã

**[p0060]**

Â Â In this case, in step S30, the information on the suction support members 62 and 63 fixed to the specified magnetic pole portions 71 and 72, the magnetic pole portions 73 and 74, and the magnetic pole portions 76 and 77 is transferred from the first processing portion 64A to the second processing portion 64B. Send to. In step S40 (second step), the second processing unit 64B supplies (energizes) current to the coils of the magnetic pole portions 71 and 72, the magnetic pole portions 73 and 74, and the magnetic pole portions 76 and 77. ããã«ãããåï¼åã®ç£æ¥µé¨ï¼ç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼ãç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼åã³ç£æ¥µé¨ï¼ï¼ï¼ï¼ï¼ï¼åã³ï¼çµï¼ï¼å¯¾ï¼ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ãç£æ°åãã¦å·¥ä½ç©ï¼·ãå¼·åºã«å¸çããããã®ã¨ããå·¥ä½ç©ï¼·ã®è¢«å¸çé¢ï¼·ï½ã¯ãï¼çµï¼ï¼å¯¾ï¼ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ã¿ã«ãã£ã¦å¸çåºå®ãããã Â Â As a result, each of the three magnetic pole portions (the magnetic pole portions 71 and 72, the magnetic pole portions 73 and 74 and the magnetic pole portions 76 and 77) and the three sets (three pairs) of the suction support members 62 and 63 are magnetized to form the workpiece W. Adsorbs firmly. At this time, the attracted surface Wa of the workpiece W is adsorbed and fixed only by the three sets (three pairs) of the adsorbing support members 62 and 63.

**[p0061]**

ãã®ããããã¨ããæªç åç¶æ ã®è¢«å¸çé¢ï¼·ï½ãå¤å½¢ãæ­ªãã§ãã¦ããæ¥è§¦ãã¦ããªãé¨åãå¼·å¶çã«å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã«å¸çããã¦å¤å½¢ããããã¨ã¯ãªããä»¥éããã®å·¥ä½ç©ï¼·ã®ä½ç½®ãç åä½ç½®ã¨ç§°ããã¹ãããï¼³ï¼ï¼ã§ã¯ããã®ç åä½ç½®ã«ããã¦ãè¢«å¸çé¢ï¼·ï½ã¨èåããç«¯é¢ã«å¯¾ãã¦ç åãè¡ãªãããã Â Â For this reason, even if the to-be-adsorbed surface Wa in an unground state is deformed and distorted, a portion that is not in contact is forcibly adsorbed and deformed by the upper surfaces 62c and 63c of the adsorption support members 62 and 63. Absent. Hereinafter, the position of the workpiece W is referred to as a grinding position. In step S50, grinding is performed on the end face facing away from the attracted surface Wa at this grinding position. æ¬¡ã«ãã¹ãããï¼³ï¼ï¼ã§ã¯ãä¸è¨ç«¯é¢ã«å¯¾ããç åãçµäºããå¾ãç¬¬åå¦çé¨ï¼ï¼ï¼¤ã®å¶å¾¡ã«ãã£ã¦ãå³ç¥ã®åè»¢è£

**[p0062]**

ç½®ï¼ã­ãããï¼ãä½åãããç åä½ç½®ã«ããã¦å·¥ä½ç©ï¼·ãè¡¨è£ãåè»¢ãããã Â Â Next, in step S60, after the grinding of the end face is completed, a reversing device (robot) (not shown) is operated under the control of the fourth processing unit 64D, and the workpiece W is reversed at the grinding position. æ¬¡ã«ãã¹ãããï¼³ï¼ï¼ã§ã¯ãç¬¬äºå¦çé¨ï¼ï¼ï¼¥ã®å¶å¾¡ã«ãã£ã¦ãåç£æ¥µé¨ï¼ï¼ãï¼ï¼ãåããåã³ã¤ã«ã«éé»ããï¼çµå ¨ã¦ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ãè¢«å¸çé¢ï¼·ï½ã«å¸çãããããªããã¹ãããï¼³ï¼ï¼ã«ããã¦ãå·¥ä½ç©ï¼·ã¯ãæ°ãã«è¢«å¸çé¢ã¨ããé«ãç²¾åº¦ã®å¹³é¢åº¦ãæããç«¯é¢ãï¼çµã®åå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®åä¸é¢ï¼ï¼ï½ãï¼ï¼ï½ã«å¼·åºã«å¸çåºå®ããããã®ãããä¸è¨ã¹ãããï¼³ï¼ï¼ã«ãã£ã¦å·¥ä½ç©ï¼·ãç ¥ç³è»ï¼ããåããç åæµæã«ãã£ã¦é¢æ¿ï¼ï¼ï½ä¸ã§ãããèã¯ãªãã

**[p0063]**

Â Â Next, in step S70, the coils of the magnetic pole portions 71 to 78 are energized under the control of the fifth processing portion 64E, and the upper surfaces 62c and 63c of all the eight suction support members 62 and 63 are attracted to the attracted surface Wa. Adsorb to. In step S70, the work W is firmly fixed to the upper surfaces 62c and 63c of the eight suction support members 62 and 63 with the end surfaces having a high degree of flatness as newly attracted surfaces. . For this reason, there is no possibility that the workpiece W is displaced on the face plate 61a by the grinding resistance that the workpiece W receives from the grinding wheel 9 in the following step S80. ããã¦ãã¹ãããï¼³ï¼ï¼ã§ã¯ãç¬¬å ­å¦çé¨ï¼ï¼ï¼¦ã®å¶å¾¡ã«ãã£ã¦ãåã³ã³ã©ã ï¼ã®éãã®å¶å¾¡ãç ¥ç³å°ï¼ã®æéã®å¶å¾¡ãä¸»è»¸å°ï¼ï¼ã®åè»¢å¶å¾¡ãè¡ãªããããã«ãããç¬¬äºå¦çé¨ï¼ï¼ï¼¢ã§è¢«å¸çé¢ï¼·ï½ã¨ããç«¯é¢ãå¤å¨é¢åã³å å¨é¢ç­ãããããç ¥ç³è»ï¼ç­ã«ãã£ã¦ç åå å·¥ãããããã«ãããå å·¥ç²¾åº¦ã®ããå·¥ä½ç©ï¼·ãå®¹æã«å¾ãããã

**[p0064]**

Â Â In step S80, the control of the sixth processing unit 64F controls the feed of the column 3, the lifting and lowering of the grindstone table 4, and the rotation control of the headstock 40 again. Thereby, the end surface, outer peripheral surface, inner peripheral surface, and the like, which are the attracted surfaces Wa, are ground by the grinding wheel 9 or the like in the second processing unit 64B. Thereby, the workpiece W with good machining accuracy can be easily obtained. ï¼ï¼âï¼ï¼ãã®ä»ã®æ æ§ï¼ ãªããä¸è¨ç¬¬ä¸å®æ½å½¢æ ã«ããã¦ã¯ãç£æ¥µé¨ãï¼æ¥µã¨ãããããããã®æ æ§ã«ã¯éãããç£æ¥µé¨ã¯ãï¼æ¥µä»¥ä¸ãåã³å¶æ°åã§ãããä¸ã¤è£½ä½ãå¯è½ã§ããã°ä½æ¥µã§ãã£ã¦ãããã (1-7. Other aspects) In the first embodiment, the magnetic pole portion has eight poles. However, the present invention is not limited thereto, and the number of magnetic pole portions may be four or more and an even number, and any number of poles may be used as long as it can be manufactured.

**[p0065]**

ã¾ããä¸è¨ç¬¬ä¸å®æ½å½¢æ ã«ããã¦ã¯ãå·¥ä½ç©ï¼·ã®è¢«å¸çé¢ï¼·ï½ã¨ãåå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ãï¼ï¼ï½ã¨ã®æ¥è§¦ããï¼¡ï¼¥ã»ã³ãµï¼ï¼ãç¨ãã¦æ¤åºããæ§æã¨ããããããããã®æ æ§ã«ã¯éããªããè¢«å¸çé¢ï¼·ï½ã¨ä¸é¢ï¼ï¼ï½ãï¼ï¼ï½ã¨ã®æ¥è§¦ã¯ãä½æ¥­è ã®ç®è¦ã«ãã£ã¦è¡ãªã£ã¦ãããããã®å ´åãç®è¦ã§ç¢ºèªããä½æ¥­è ããç¢ºèªããçµæãå³ã¡ä¸é¢ï¼ï¼ï½ãï¼ï¼ï½ãè¢«å¸çé¢ï¼·ï½ã¨æ¥è§¦ããå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ãåºå®ãããç£æ¥µé¨ã®æ å ±ãå¶å¾¡è£ ç½®ï¼ï¼ã®ç¬¬ä¸å¦çé¨ï¼ï¼ï¼¡ã«å ¥åãã¦ããã°ãããããã«ãã£ã¦ãåæ§ã®å¹æãå¾ãããã Â Â In the first embodiment, the contact between the suction surface Wa of the workpiece W and the upper surfaces 62c and 63c of the suction support members 62 and 63 is detected using the AE sensor 65. However, it is not limited to this aspect. The contact between the attracted surface Wa and the upper surfaces 62c and 63c may be made by visual observation by an operator. In this case, the first confirmation process of the control device 64 uses the result of confirmation by the operator who has confirmed visually, that is, the information on the magnetic pole part to which the suction support members 62 and 63 whose upper surfaces 62c and 63c are in contact with the attracted surface Wa are fixed. What is necessary is just to input into the part 64A. This also provides the same effect.

**[p0066]**

ã¾ããå·¥ä½ç©ï¼·ã®è¢«å¸çé¢ï¼·ï½ã¨ãåå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ãï¼ï¼ï½ã¨ã®æ¥è§¦ããï¼¡ï¼¥ã»ã³ãµï¼ï¼ãç¨ãããå¥ã®ã»ã³ãµã«ãã£ã¦æ§æãæ¤åºãã¦ãè¯ããä¾ãã°ãã¨ã¢ã®ã£ããã»ã³ãµãå å­¦ã»ã³ãµã«ãã£ã¦æ¤åºãã¦ããããã¨ã¢ã®ã£ããã»ã³ãµã®å ´åãåå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ãï¼ï¼ï½ã¨ãå·¥ä½ç©ï¼·ã®è¢«å¸çé¢ï¼·ï½ã¨ã®éã«æå®ã®ã¨ã¢å§åããããã¨ã¢ãæ¼ããéããä¸¡è ï¼ä¸é¢ï¼ï¼ï½ãï¼ï¼ï½åã³è¢«å¸çé¢ï¼·ï½ãä»¥å¾åæ§ï¼ã®éã®ééãæ¨å®ããæ¨å®ããééããä¸¡è ãæ¥è§¦ãã¦ãããå¦ããå¤å®ãããã¾ããä¸¡è ã®éã®ééããæ¼ããå ã®æ¼ãéããä¸¡è ãæ¥è§¦ãã¦ãããæ¥è§¦ãã¦ããªãããå¤å®ãã¦ããããããã«ã¯ä¸¡è ã®éã®é»æ°æµæããä¸¡è ãæ¥è§¦ãã¦ãããæ¥è§¦ãã¦ããªãããå¤å®ãã¦ãããã Â Â Further, the contact between the surface to be attracted Wa of the workpiece W and the upper surfaces 62c and 63c of the respective suction support members 62 and 63 may be configured and detected by another sensor without using the AE sensor 65. For example, it may be detected by an air gap sensor or an optical sensor. In the case of an air gap sensor, a predetermined air pressure is applied between the upper surfaces 62c and 63c of the suction support members 62 and 63 and the suctioned surface Wa of the workpiece W, and both (upper surfaces 62c and 63c) from the amount of air leakage. And

**[p0066]**

the attracted surface Wa, and so on) are estimated, and it is determined whether or not both are in contact with the estimated gap. Moreover, you may determine whether both are contacting or not from the leakage amount of the light which leaks from the clearance gap between both. Further, it may be determined whether or not both are in contact with each other from the electrical resistance between them.

**[p0067]**

ã¾ããä¸è¨å®æ½å½¢æ ã«ããã¦ã¯ãã¹ãããï¼³ï¼ï¼ã«ããã¦ãè¢«å¸çé¢ï¼·ï½ã«æ¥è§¦ããå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã¯ï¼çµã§ãããæ¥è§¦ããï¼çµãå¸çãããã®ã¨ãã¦èª¬æããããããããã®æ æ§ã«ã¯ããããªããå®éã«ã¯ãè¢«å¸çé¢ï¼·ï½ã¨å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ä¸é¢ï¼ï¼ï½ãï¼ï¼ï½ã¨ã¯ãï¼çµãè¶ ãã¦æ¥è§¦ããå ´åãããããã®å ´åã¯ãæ¥è§¦ãããã¹ã¦ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã«ç£æ°åãçºçããããå¶å¾¡ããã°ããã Â Â Moreover, in the said embodiment, in step S40, the adsorption | suction support members 62 and 63 which contact the to-be-adsorbed surface Wa are 3 groups, and it demonstrated as what adsorb | sucks 3 groups which contacted. However, this embodiment is not limited. Actually, the surface to be attracted Wa and the upper surfaces 62c and 63c of the suction support members 62 and 63 may contact more than three sets. In that case, what is necessary is just to control so that magnetic force generate | occur | produces in all the adsorption | suction support members 62 and 63 which contacted.

**[p0068]**

ã¾ããä¸è¨ç¬¬ä¸å®æ½å½¢æ ã«ããã¦ã¯ãï¼çµã®åå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã¯ãããããè¢«å¸çé¢ï¼·ï½ã¨æ¥è§¦ããåä¸é¢ï¼ï¼ï½ãï¼ï¼ï½ãåå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®åå¯¾åé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¨æ¥ç¶ãããå´ãå³ã¡å¢çï¼ï¼ï¼¬å´ã«ããããå¯ã£ã¦å½¢æãããããããããã®å½¢æ ã«ã¯éããªããå¤å½¢ä¾ï¼(å³ç¥)ã¨ãã¦ãåå¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã¯ãåä¸é¢ï¼ï¼ï½ãï¼ï¼ï½ããåä¸é¢ï¼ï¼ï½ãï¼ï¼ï½ã¨å¹³è¡ã§ä¸ã¤åãå½¢ç¶ã§å½¢æããã¦ãã¦ãããã Â Â In the first embodiment, each of the three sets of the suction support members 62 and 63 has the upper surfaces 62c and 63c that are in contact with the suction target surface Wa, respectively, and the opposing surfaces 62b and 63b of the suction support members 62 and 63, respectively. And the side to be connected, that is, the boundary 76L side. However, it is not limited to this form. As a first modification (not shown), each of the suction support members 62 and 63 may have an upper surface 62c and 63c that are parallel to the lower surfaces 62a and 63a and have the same shape.

**[p0069]**

ã¾ããå¤å½¢ä¾ï¼ã¨ãã¦ãï¼çµã®åå¸çæ¯æé¨æï¼ï¼ï¼¡ï¼ï¼ï¼ï¼¡ã¯ãå³ï¼ï¼ã«ç¤ºãããã«èåé¢ï¼ï¼ï½ï¼¡ï¼ï¼ï¼ï½ï¼¡ãå¯¾åé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã«å¯¾ãã¦å¾æãã¦ããªãç´æ¹ä½å½¢ç¶ã®é¨æã§ãããããã®å ´åãåæ¯æé¨ï¼³ï¼°ã®ææè§åº¦Î¸ï¼ã¯ãå³ï¼ï¼ã«ç¤ºãé¨åã®è§åº¦ããããã®ã¨ãããããã«ãã£ã¦ããä¸è¨å®æ½å½¢æ ã¨åæ§ã®å¹æãå¾ãããã Â Â Further, as a second modification, the three sets of suction support members 62A and 63A may be rectangular parallelepiped members whose back surfaces 62dA and 63dA are not inclined with respect to the opposing surfaces 62b and 63b as shown in FIG. . In this case, the gripping angle Î¸1 of each support portion SP refers to the angle of the portion shown in FIG. Also by this, the same effect as the above embodiment can be obtained. ã¾ããä¸è¨ç¬¬ä¸å®æ½å½¢æ ã«ããã¦ã¯ãä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã¯ãä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ï¼ç¬¬ä¸å¹³é¢ã«ç¸å½ï¼ã¨ãå¯¾åé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¨ãä¸é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ï¼ç¬¬äºå¹³é¢ã«ç¸å½ï¼ã¨ãèåé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¨ãå¾æ¹åå

**[p0070]**

å´é¢ï¼ï¼ï½ ï¼ï¼ï¼ï½ ã¨ãå¾æ¹åå¤å´é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¨ããåããããå¤å½¢ä¾ï¼ã¨ãã¦ãå¾æ¹åå å´é¢ï¼ï¼ï½ ï¼ï¼ï¼ï½ ãåãã¦ããªãã¦ãããï¼å³ï¼ï¼åç §ï¼ããã®å ´åãåæ¯æé¨ï¼³ï¼°ã®ææè§åº¦Î¸ï¼ã¯ãå³ï¼ï¼ã«ç¤ºãé¨åã®è§åº¦ããããã®ã¨ãããããã«ãã£ã¦ããä¸è¨å®æ½å½¢æ ã¨åæ§ã®å¹æãå¾ãããã Â Â In the first embodiment, the pair of suction support members 62 and 63 includes lower surfaces 62a and 63a (corresponding to the first plane), opposing surfaces 62b and 63b, and upper surfaces 62c and 63c (corresponding to the second plane). ), Back-facing surfaces 62d and 63d, radially inner side surfaces 62e and 63e, and radially outer surfaces 62f and 63f. However, as a third modification, the radially inner side surfaces 62e and 63e are not provided. (See FIG. 13). In this case, the grip angle Î¸1 of each support portion SP is the angle of the portion shown in FIG. Also by this, the same effect as the above embodiment can be obtained.

**[p0071]**

ã¾ããèå å·¥ãä»ä¸ãå å·¥ãªã©å å·¥ã®ç¨®é¡ï¼å·¥ç¨ï¼ã«ãã£ã¦ãç£æ¥µé¨ã®ã³ã¤ã«ã«éé»ããé»å§ãé»æµãªã©ãå¶å¾¡è£ ç½®ï¼ï¼ã§å¶å¾¡ããç£æ°åãå¤æ´ï¼èª¿æ´ï¼ãã¦å å·¥ã®ç¨®é¡ï¼å·¥ç¨ï¼ã«å¿ããæé©ãªææåï¼å¸çåï¼å å·¥ã§å¿ è¦ãªå·¥ä½ç©ã®ä¿æåï¼ãçºçãããããã«ãã¦ããããããã«ãããææåã«ããå·¥ä½ç©ã®å¤å½¢ãé²æ­¢ã§ãããã¾ããå å·¥ã«ä¸è¦ã§ããä½åãªææåãä½æ¸ããããã¨ãã§ããç¡é§ãªã¨ãã«ã®ã¼ãåæ¸ã§ããã Â Â Also, depending on the type (process) of processing such as roughing and finishing, the voltage or current applied to the coil of the magnetic pole portion is controlled by the control device 64, and the magnetic force is changed (adjusted) to change the type of process (process). It is also possible to generate an optimum gripping force (adsorption force; workpiece holding force necessary for processing) according to the above. Thereby, the deformation of the workpiece due to the gripping force can be prevented. In addition, unnecessary gripping force that is unnecessary for processing can be reduced, and wasteful energy can be reduced.

**[p0072]**

ï¼ï¼âï¼ï¼å®æ½å½¢æ ã«ããå¹æï¼ ä¸è¨å®æ½å½¢æ ã«ããã°ãé»ç£ãã£ãã¯è£ ç½®ï¼ï¼ã®å¶å¾¡æ¹æ³ã¯ãé»ç£ãã£ãã¯æ¬ä½ï¼ï¼ã®é¢æ¿ï¼ï¼ï½ä¸é¢ã«å½¢æãããè¤æ°ã®ç£æ¥µé¨ï¼ï¼ãï¼ï¼ãåããå¶å¾¡è£ ç½®ï¼ï¼ãå¶å¾¡ããç£æ¥µé¨ï¼ï¼ãï¼ï¼ã®ç£æ°åã«ãã£ã¦å·¥ä½ç©ï¼·ãå¸çããé»ç£ãã£ãã¯è£ ç½®ï¼ï¼ã®å¶å¾¡æ¹æ³ã§ãããé»ç£ãã£ãã¯è£ ç½®ï¼ï¼ã¯ãé¢æ¿ï¼ï¼ï½ä¸é¢ã§ããç£æ¥µé¨ï¼ï¼ãï¼ï¼ã®ä¸é¢ã«ããã¦åå¯¾åé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ãæå®ã®ééÎ±ï¼ãæãã¦å¯¾åãé ç½®ãããä¸å¯¾ã®å¸çæ¯æé¨æãå°ãªãã¨ãï¼çµåããåä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ããããããè¤æ°ã®ç£æ¥µé¨ï¼ï¼ãï¼ï¼ã®ãã¡ã®é£ãåãç£æ¥µé¨éã®å¢çãæãã§é ç½®ãããåä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®åç¬¬ä¸å¹³é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ããé£ãåãç£æ¥µé¨ã®åä¸é¢ã«æ¥è§¦ãåºå®ãããç¶æ ã«ããã¦ãå¶å¾¡æ¹æ³ã¯ãåç¬¬ä¸å¹³é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¨èåãä¸ã¤åå¯¾åé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¨é£ç¶ãã¦æ¥ç¶ãããåç¬¬äºå¹³é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ãåããåä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ãã¡åç¬¬äºå¹³é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ãå·¥ä½ç©ï¼·ã®è¢«å¸çé¢ï¼·ï½ã¨æ¥è§¦ããä¸å¯¾ã®å¸çæ¯æé¨æãç¢ºèªããç¬¬ä¸å·¥ç¨ï¼ã¹ãããï¼³ï¼ï¼ï¼ã¨ãç¬¬ä¸å·¥ç¨ï¼ã¹ãããï¼³ï¼ï¼ï¼ã«ããã¦ãè¢«å¸çé¢ï¼·ï½ã¨ã®æ¥è§¦ãç¢ºèªãããä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ãåºå®ãããç£æ¥µé¨ãå

**[p0072]**

¶å¾¡è£

**[p0073]**

ç½®ï¼ï¼ãå¶å¾¡ãã¦ç£æ°åãçºçãããæ¥è§¦ããç¬¬äºå¹³é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¨è¢«å¸çé¢ï¼·ï½ã¨ãå¸çãããç¬¬äºå·¥ç¨ï¼ã¹ãããï¼³ï¼ï¼ï¼ã¨ããåããã (1-8. Effects of the embodiment) According to the above embodiment, the method for controlling the electromagnetic chuck device 60 includes the plurality of magnetic pole portions 71 to 78 formed on the upper surface of the face plate 61 a of the electromagnetic chuck main body 61, and the magnetic pole portions 71 to 78 controlled by the control device 64. This is a control method of the electromagnetic chuck device 60 that attracts the workpiece W by magnetic force. The electromagnetic chuck device 60 includes at least three pairs of suction support members in which the opposing surfaces 62b and 63b are arranged to face each other with a predetermined gap Î±1 on the upper surface of the magnetic pole portions 71 to 78 that are the upper surface of the face plate 61a. Each pair of suction support members 62 and 63 is disposed across a boundary between adjacent magnetic pole portions of the plurality of magnetic pole portions 71 to 78, and each first plane 62a of each pair of suction support members 62 and 63 is provided. , 63a is in contact with each upper surface of the adjacent magnetic pole part and fixed, the control method is the back-facing to each first plane 62a, 63a and each continuously connected to each facing surface 62b, 63b. First step of confirming a pair of suction support members in which each of the second planes 62c and 63c contacts the surface to be suctione

**[p0073]**

d Wa of the workpiece W among the pair of suction support members 62 and 63 having the second planes 62c and 63c. (Step S 0) and in the first step (step S20), the control device 64 controls the magnetic pole portion to which the pair of suction support members 62, 63 that are confirmed to be in contact with the attracted surface Wa are controlled to generate a magnetic force. And a second step (step S40) for adsorbing the contacted second flat surfaces 62c and 63c and the attracted surface Wa.

**[p0074]**

ãã®ããã«ãæ¬çºæã«ä¿ãå¶å¾¡æ¹æ³ã§ã¯ãå·¥ä½ç©ï¼·ãæªç åç¶æ ã§ãããå ¨ä½ã«æ­ªã¿ãããå¯è½æ§ã®ããå ´åã«ã¯ãç¬¬ä¸å·¥ç¨ï¼ã¹ãããï¼³ï¼ï¼ï¼ã«ããã¦ãå·¥ä½ç©ï¼·ãåä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã«è¼ç½®ããç¶æ ã§ãå·¥ä½ç©ï¼·ãæ¥è§¦ããé¨åãç¢ºèªãããããã¦ãç¬¬äºå·¥ç¨ï¼ã¹ãããï¼³ï¼ï¼ï¼ã«ããã¦ãå·¥ä½ç©ï¼·ãæ¥è§¦ããé¨åã®ã¿å¸çããåºå®ããã®ã§ããã®å¾ãå·¥ä½ç©ï¼·ãæ­ªã¾ãããã¨ãªããè¢«å¸çé¢ï¼·ï½ã«èåããç«¯é¢ï¼åºæºé¢ï¼ã®å å·¥ãè¯å¥½ã«ã§ããããã®ããã«ãå·¥ä½ç©ï¼·ãæ­ªã¾ãããã¨ãªãåºæºé¢ãå å·¥ã§ãããããå å·¥ããåºæºé¢ï¼ç«¯é¢ï¼ãåºæºã¨ãã¦å å·¥ãããã¨ã§ãå å·¥ç²¾åº¦ã®è¯ãå·¥ä½ç©ï¼·ã®å å·¥ãèªå¨ã«ã§ããã Â Â As described above, in the control method according to the present invention, when the workpiece W is in an unground state and there is a possibility that the entire workpiece is distorted, in the first step (step S20), the workpiece W is paired with each pair. In the state where the workpiece W is placed on the suction support members 62, 63, the portion where the workpiece W contacts is confirmed. In the second step (step S40), only the portion with which the workpiece W comes into contact is sucked and fixed, and thereafter the end surface (reference surface) facing away from the attracted surface Wa without distorting the workpiece W. Good processing. Thus, since the reference surface can be processed without distorting

**[p0074]**

the workpiece W, the workpiece W with high processing accuracy can be freely processed by processing using the processed reference surface (end surface) as a reference.

**[p0075]**

ã¾ããä¸è¨å®æ½å½¢æ ã«ããã°ãç¬¬ä¸å·¥ç¨ï¼ã¹ãããï¼³ï¼ï¼ï¼ã«ããã¦ãåç¬¬äºå¹³é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ããå·¥ä½ç©ï¼·ã®è¢«å¸çé¢ï¼·ï½ã¨æ¥è§¦ããä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã¯ã»ã³ãµã«ãã£ã¦ç¢ºèªãããããã«ãããæ¥è§¦ããä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ãç²¾åº¦ããæ¤åºã§ããã®ã§ãå·¥ä½ç©ï¼·ã®è¢«å¸çé¢ï¼·ï½ãå¸çããæã«ãå¤å½¢ãã¦ãã¾ãèãå¤§å¹ ã«æå¶ã§ãããã¾ããèªååãå¯è½ã¨ãªãå¹ççã§ããã Â Â Moreover, according to the said embodiment, in a 1st process (step S20), a pair of adsorption | suction support member 62,63 which each 2nd planes 62c and 63c contact with the to-be-adsorbed surface Wa of the workpiece W is confirmed with a sensor. To do. As a result, the pair of suction support members 62 and 63 in contact with each other can be detected with high accuracy, so that the possibility of deformation when the suction surface Wa of the workpiece W is sucked can be greatly suppressed. Also, automation is possible and efficient.

**[p0076]**

ã¾ããä¸è¨å®æ½å½¢æ ã«ããã°ãç¬¬äºå·¥ç¨ï¼ã¹ãããï¼³ï¼ï¼ï¼ã«ããã¦ãç£æ°åã¯ãå å·¥ã®ç¨®é¡ã«åºã¥ãã¦å¸çåãå¤æ´ãããããã«ãããå å·¥ã®ç¨®é¡ã«å¿ããé©åãªææåãå¾ãããããã£ã¦ãåå å·¥ã«ããã¦éå¤§ãªææåãçºçãããã¨ãé©åã«æå¶ã§ããã®ã§ææåã«ããå·¥ä½ç©ï¼·ã®å¤å½¢ãè¯å¥½ã«é²æ­¢ã§ãããã¾ããå å·¥ã«ã¨ã£ã¦ä¸è¦ã§ããä½åãªææåãä½æ¸ããããã¨ãã§ããã®ã§ãç¡é§ãªã¨ãã«ã®ã¼ãåæ¸ãããã¨ãã§ããã Â Â Moreover, according to the said embodiment, in a 2nd process (step S40), a magnetic force changes an attraction force based on the kind of process. Thereby, an appropriate gripping force according to the type of processing can be obtained. Therefore, since it can suppress appropriately that excessive gripping force generate | occur | produces in each process, the deformation | transformation of the workpiece W by gripping force can be prevented favorably. Moreover, since unnecessary gripping force that is unnecessary for processing can be reduced, useless energy can be reduced.

**[p0077]**

ã¾ããä¸è¨å®æ½å½¢æ ã«ããã°ãã»ã³ãµã¯ãï¼¡ï¼¥ã»ã³ãµï¼ï¼ã§ãããããã«ãããå®ä¾¡ã§ä¸ã¤ä¿¡é ¼æ§ãé«ãçµæãæå¾ ã§ããã Â Â Further, according to the embodiment, the sensor is the AE sensor 65. Thereby, an inexpensive and highly reliable result can be expected. ã¾ããä¸è¨å®æ½å½¢æ ã«ããã°ãé»ç£ãã£ãã¯è£ ç½®ï¼ï¼ã¯ãé»ç£ãã£ãã¯æ¬ä½ï¼ï¼ã®é¢æ¿ï¼ï¼ï½ä¸é¢ã«å½¢æãããè¤æ°ã®ç£æ¥µé¨ï¼ï¼ãï¼ï¼ãåããå¶å¾¡è£ ç½®ï¼ï¼ã«å¶å¾¡ãããç£æ¥µé¨ï¼ï¼ãï¼ï¼ã®ç£æ°åã«ãã£ã¦å·¥ä½ç©ï¼·ãé¢æ¿ï¼ï¼ï½ä¸é¢ã«å¸çããé»ç£ãã£ãã¯è£ ç½®ï¼ï¼ã§ãããé»ç£ãã£ãã¯è£ ç½®ï¼ï¼ã¯ãé¢æ¿ï¼ï¼ï½ä¸é¢ã§ããç£æ¥µé¨ï¼ï¼ãï¼ï¼ã®ä¸é¢ã«ããã¦åå¯¾åé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ãæå®ã®ééÎ±ï¼ãæãã¦å¯¾åãé ç½®ãããä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ãå°ãªãã¨ãï¼çµåãããåä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã¯ãããããè¤æ°ã®ç£æ¥µé¨ï¼ï¼ãï¼ï¼ã®ãã¡ã®é£ãåãç£æ¥µé¨éã®å¢çãæãã§é

**[p0078]**

ç½®ãããåä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®åç¬¬ä¸å¹³é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ããé£ãåãç£æ¥µé¨ã®åä¸é¢ã«æ¥è§¦ãã¦åºå®ããããå¶å¾¡è£ ç½®ï¼ï¼ã¯ãåç¬¬ä¸å¹³é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¨èåãä¸ã¤åå¯¾åé¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¨é£ç¶ãã¦æ¥ç¶ãããåç¬¬äºå¹³é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ãåããåä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ã®ãã¡åç¬¬äºå¹³é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ãå·¥ä½ç©ï¼·ã®è¢«å¸çé¢ï¼·ï½ã¨æ¥è§¦ããä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ãç¢ºèªããç¬¬ä¸å¦çé¨ï¼ï¼ï¼¡ã¨ãç¬¬ä¸å¦çé¨ï¼ï¼ï¼¡ã«ããã¦ãè¢«å¸çé¢ï¼·ï½ã¨ã®æ¥è§¦ãç¢ºèªãããä¸å¯¾ã®å¸çæ¯æé¨æï¼ï¼ï¼ï¼ï¼ãåºå®ãããç£æ¥µé¨ï¼ï¼ãï¼ï¼ãå¶å¾¡ãã¦ç£æ°åãçºçãããæ¥è§¦ããç¬¬äºå¹³é¢ï¼ï¼ï½ï¼ï¼ï¼ï½ã¨è¢«å¸çé¢ï¼·ï½ã¨ãå¸çãããç¬¬äºå¦çé¨ï¼ï¼ï¼¢ã¨ããåãããããã«ãããä¸è¨ã§èª¬æããå¶å¾¡æ¹æ³ã«ãã£ã¦å¾ãããã®ã¨åãå¹æãå¥ããé»ç£ãã£ãã¯è£

**[p0079]**

ç½®ï¼ï¼ãå¾ãããã Â Â Further, according to the above embodiment, the electromagnetic chuck device 60 includes the plurality of magnetic pole portions 71 to 78 formed on the upper surface of the face plate 61 a of the electromagnetic chuck main body 61, and the magnetic pole portions 71 to 78 controlled by the control device 64. This is an electromagnetic chuck device 60 that attracts the workpiece W to the upper surface of the face plate 61a by magnetic force. The electromagnetic chuck device 60 includes at least three pairs of suction support members 62 and 63 in which the opposing surfaces 62b and 63b are opposed to each other with a predetermined gap Î±1 on the top surface of the magnetic pole portions 71 to 78 that are the top surface of the face plate 61a. Prepare a set. Each pair of suction support members 62 and 63 is disposed across a boundary between adjacent magnetic pole portions of the plurality of magnetic pole portions 71 to 78, and each first flat surface 62a of each pair of suction support members 62 and 63. 63a are fixed in contact with the upper surfaces of adjacent magnetic pole portions. The control device 64 includes a pair of suction support members 62 and 63 each having a second plane 62c and 63c that are connected to the first planes 62a and 63a and are continuously connected to the opposing surfaces 62b and 63b. Among these, the first processing part 64A for confirming the pair of suction support members 62, 63 in which the second flat surfaces 62c, 63c are in contact with the suctioned surface Wa of the workpiece W, and the first process

**[p0079]**

ing part 64A, The magnetic force is generated by controlling the magnetic pole portions 71 to 78 to which the pair of suction support members 62 and 63 that are confirmed to be in contact with each other is fixed, and the contacted second planes 62c and 63c and the attracted surface Wa are attracted. A second processing unit 64B. Thereby, the electromagnetic chuck device 60 having the same effect as that obtained by the control method described above is obtained.

**[p0080]**

ï¼ï¼ï¼ãã®ä»ï¼ ãªããä¸è¨å®æ½å½¢æ ã«ããã¦ã¯ãæ¬çºæã«ä¿ãé»ç£ãã£ãã¯è£ ç½®ï¼ï¼ï¼ä¿æè£ ç½®ï¼ãç åç¤ï¼ã«é©ç¨ãããããã®æ æ§ã«ã¯éããªããé»ç£ãã£ãã¯è£ ç½®ï¼ï¼ã¯ã©ã®ãããªå å·¥æ©ã®ä¿æè£ ç½®ã¨ãã¦é©ç¨ãã¦ããããã¾ããå å·¥æ©ã«éãããé¨åãåºå®ããåºå®å ·ã¨ãã¦ãã©ã®ãããªè£ ç½®ã«ç¨ãã¦ãããããããã«ãã£ã¦ãåæ§ã®å¹æãæå¾ ã§ããã <2. Other> In the above embodiment, the electromagnetic chuck device 60 (holding device) according to the present invention is applied to the grinding machine 1, but the present invention is not limited to this mode. The electromagnetic chuck device 60 may be applied as a holding device for any processing machine. Moreover, you may use for not only a processing machine but what kind of apparatus as a fixing tool which fixes components. The same effect can be expected by these. ã¾ããä¸è¨å®æ½å½¢æ ã«ããã¦ã¯ãé»ç£ãã£ãã¯è£

**[p0081]**

ç½®ï¼ï¼ã®ç£æ¥µé¨ï¼ï¼ãï¼ï¼ã®ç£åã¯ãç£æ¥µç¨é¼æï¼å³ç¥ï¼ã«å·»ããã³ã¤ã«ï¼å³ç¥ï¼ã«éé»ãããã¨ã§å®ç¾ãããã®ã¨ããããããããã®æ æ§ã«ã¯éããªããé»ç£ãã£ãã¯æ¬ä½ï¼ï¼ã®ç£æ¥µé¨ï¼ï¼ãï¼ï¼ã®ç£åã¯ãé»ç£ãã£ãã¯æ¬ä½ï¼ï¼å ã®æ°¸ä¹ ç£ç³ï¼å³ç¥ï¼ãç§»åãããã¨ã«ãã£ã¦å®ç¾ãããæ¹å¼ã®ãã®ã§ããããããã«ãã£ã¦ãåæ§ã®å¹æãå¾ãããã Â Â Moreover, in the said embodiment, the magnetization of the magnetic pole parts 71-78 of the electromagnetic chuck apparatus 60 shall be implement | achieved by supplying with electricity to the coil (not shown) wound around the steel material for magnetic poles (not shown). However, it is not limited to this aspect. Magnetization of the magnetic pole portions 71 to 78 of the electromagnetic chuck main body 61 may be realized by moving a permanent magnet (not shown) in the electromagnetic chuck main body 61. This also provides the same effect.

**[p0082]**

ï¼ï¼ç åç¤ã ï¼ï¼ç ¥ç³è»ï¼ç ¥ç³ï¼ã ï¼ï¼ï¼ä¸»è»¸å°ã ï¼ï¼ï¼å·¥ä½ä¸»è»¸ã ï¼ï¼ï¼é»ç£ãã£ãã¯è£ ç½®ã ï¼ï¼ï¼é»ç£ãã£ãã¯æ¬ä½ã ï¼ï¼ï½ï¼é¢æ¿ã ï¼ï¼ï¼ï¼ï¼ï¼å¸çæ¯æé¨æã ï¼ï¼ï½ï¼ï¼ï¼ï½ï¼ç¬¬ä¸å¹³é¢ï¼ä¸é¢ï¼ã ï¼ï¼ï½ï¼ï¼ï¼ï½ï¼å¯¾åé¢ã ï¼ï¼ï½ï¼ï¼ï¼ï½ï¼ç¬¬äºå¹³é¢ï¼ä¸é¢ï¼ã ï¼ï¼ï¼å¶å¾¡è£ ç½®ã ï¼ï¼ãï¼ï¼ï¼ç£æ¥µé¨ã ï¼ï¼ï¼¬ãï¼ï¼ï¼¬ï¼å¢çã ï¼³ï¼ï¼ï¼³ï¼ï¼é¢ç©ã ï¼·ï¼å·¥ä½ç©ã ï¼³ï¼ï¼ï¼ç¬¬ä¸å·¥ç¨ã ï¼³ï¼ï¼ï¼ç¬¬äºå·¥ç¨ã ï¼ï¼ï¼¡ï¼ç¬¬ä¸å¦çé¨ã ï¼ï¼ï¼¢ï¼ç¬¬äºå¦çé¨ã ï¼ï¼ï¼ã»ã³ãµï¼ï¼¡ï¼¥ã»ã³ãµï¼ã Â Â DESCRIPTION OF SYMBOLS 1; Grinding machine, 9; Grinding wheel (grinding wheel), 40; Main spindle, 42; Work spindle, 60; Electromagnetic chuck device, 61; Electromagnetic chuck body, 61a; Face plate, 62, 63; Adsorption support member, 62a, 63a First plane (lower surface), 62b, 63b; opposing surface, 62c, 63c; second plane (upper surface), 64; control device, 71-78; magnetic pole part, 71L-78L; boundary, S1, S2; W; Workpiece, S20; First step, S40; Second step, 64A; First processing unit, 64B; Second processing unit, 65; Sensor (AE sensor).

## Cited patent documents

- [JP-2001025910-A](https://patents.google.com/patent/JP2001025910A/en) — SEA
- [JP-2011500339-A](https://patents.google.com/patent/JP2011500339A/en) — SEA
- [JP-2017001102-A](https://patents.google.com/patent/JP2017001102A/en) — SEA
- [JP-2017019073-A](https://patents.google.com/patent/JP2017019073A/en) — SEA
- [JP-H055343-U](https://patents.google.com/patent/JPH055343U/en) — SEA
- [JP-H0631627-A](https://patents.google.com/patent/JPH0631627A/en) — SEA
- [US-3340442-A](https://patents.google.com/patent/US3340442A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
