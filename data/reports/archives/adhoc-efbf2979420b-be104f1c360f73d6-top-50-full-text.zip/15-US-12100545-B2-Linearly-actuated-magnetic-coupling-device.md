# 15. Linearly actuated magnetic coupling device

- **Archive rank:** 15 of 50
- **Publication:** [US-12100545-B2](https://patents.google.com/patent/US12100545B2/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/070331264/publication/US12100545B2?q=pn%3DUS12100545B2)
- **Publication date:** 2024-09-24
- **Filing date:** 2019-10-24
- **Earliest priority:** 2018-10-24
- **Family:** 70331264
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** MAGSWITCH TECH INC; MAGSWITCH TECH WORLDWIDE PTY LTD
- **Inventors:** FELTON SHANE N; KARP PAUL; MORTON DAVID H

## Abstract

The present disclosure relates to magnetic coupling devices. More specifically, the present disclosure relates to magnetic coupling devices configured to be linearly actuated and de-actuated.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-12100545-B2/000.png)

![Sketch 1 for US-12100545-B2](https://nimo.iptorch.com/refdrawing/US-12100545-B2/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/US-12100545-B2/001.png)

![Sketch 2 for US-12100545-B2](https://nimo.iptorch.com/refdrawing/US-12100545-B2/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/US-12100545-B2/002.png)

![Sketch 3 for US-12100545-B2](https://nimo.iptorch.com/refdrawing/US-12100545-B2/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/US-12100545-B2/003.png)

![Sketch 4 for US-12100545-B2](https://nimo.iptorch.com/refdrawing/US-12100545-B2/003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/US-12100545-B2/004.png)

![Sketch 5 for US-12100545-B2](https://nimo.iptorch.com/refdrawing/US-12100545-B2/004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/US-12100545-B2/005.png)

![Sketch 6 for US-12100545-B2](https://nimo.iptorch.com/refdrawing/US-12100545-B2/005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/US-12100545-B2/006.png)

![Sketch 7 for US-12100545-B2](https://nimo.iptorch.com/refdrawing/US-12100545-B2/006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/US-12100545-B2/007.png)

![Sketch 8 for US-12100545-B2](https://nimo.iptorch.com/refdrawing/US-12100545-B2/007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/US-12100545-B2/008.png)

![Sketch 9 for US-12100545-B2](https://nimo.iptorch.com/refdrawing/US-12100545-B2/008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/US-12100545-B2/009.png)

![Sketch 10 for US-12100545-B2](https://nimo.iptorch.com/refdrawing/US-12100545-B2/009.png)

[Sketch 11](https://nimo.iptorch.com/refdrawing/US-12100545-B2/010.png)

![Sketch 11 for US-12100545-B2](https://nimo.iptorch.com/refdrawing/US-12100545-B2/010.png)

[Sketch 12](https://nimo.iptorch.com/refdrawing/US-12100545-B2/011.png)

![Sketch 12 for US-12100545-B2](https://nimo.iptorch.com/refdrawing/US-12100545-B2/011.png)

[Sketch 13](https://nimo.iptorch.com/refdrawing/US-12100545-B2/012.png)

![Sketch 13 for US-12100545-B2](https://nimo.iptorch.com/refdrawing/US-12100545-B2/012.png)

[Sketch 14](https://nimo.iptorch.com/refdrawing/US-12100545-B2/013.png)

![Sketch 14 for US-12100545-B2](https://nimo.iptorch.com/refdrawing/US-12100545-B2/013.png)

[Sketch 15](https://nimo.iptorch.com/refdrawing/US-12100545-B2/014.png)

![Sketch 15 for US-12100545-B2](https://nimo.iptorch.com/refdrawing/US-12100545-B2/014.png)

[Sketch 16](https://nimo.iptorch.com/refdrawing/US-12100545-B2/015.png)

![Sketch 16 for US-12100545-B2](https://nimo.iptorch.com/refdrawing/US-12100545-B2/015.png)

[Sketch 17](https://nimo.iptorch.com/refdrawing/US-12100545-B2/016.png)

![Sketch 17 for US-12100545-B2](https://nimo.iptorch.com/refdrawing/US-12100545-B2/016.png)

## Claims

### Claim 1 (independent)

A magnetic coupling device for magnetic coupling to a ferromagnetic workpiece, comprising: a housing having an axis extending between a first end portion of the housing and a second end portion of the housing; a brake supported by the housing; a ferrous piece arranged at least a first distance from the second end portion of the housing; a magnetic platter supported by the housing, the magnetic platter including a plurality of permanent magnet portions interposed between a plurality of ferromagnetic pole piece portions; and wherein the magnetic platter is linearly translatable within the housing along the axis to at least each of a first state and a second state, the magnetic platter being arranged adjacent to the ferrous piece such that the magnetic coupling device establishes a first magnetic circuit through the ferrous piece and provides a first magnetic field at a workpiece contact interface of the magnetic coupling device when the magnetic platter is in the first state and the magnetic platter being arranged spaced apart from the ferrous piece such that the magnetic coupling device provides a second magnetic field at the workpiece contact interface when the magnetic platter is in the second state, the second magnetic field being a non-zero magnetic field strength; and wherein the magnetic coupling device is linearly translatable to a third state, the magnetic platter being arranged between the first state and the second state when the magnetic platter is in the third state and the brake is configured to releasably hold the magnetic platter in the third state.

### Claim 2

The magnetic coupling device of claim 1 , further comprising at least one non-ferromagnetic piece arranged at least a second distance from the second end portion of the housing.

### Claim 3

The magnetic coupling device of claim 1 , wherein the magnetic platter translates a distance of less than or equal to 8 mm.

### Claim 4

The magnetic coupling device of claim 1 , wherein the magnetic coupling device provides a holding force greater than or equal to 0.25 grams per cubic mm of magnetic coupling device.

### Claim 5

The magnetic coupling device of claim 1 , wherein the magnetic coupling device provides a holding force greater than or equal to 0.35 grams per cubic mm of the magnetic platter.

### Claim 6

The magnetic coupling device of claim 1 , wherein the magnetic coupling device provides a holding force greater than or equal to 0.15 grams per square mm of the workpiece contact interface.

### Claim 7

The magnetic coupling device of claim 1 , wherein the workpiece contact interface comprises a plurality of spaced-apart projections.

### Claim 8

The magnetic coupling device of claim 7 , wherein the workpiece contact interface is releasably supported by the housing.

### Claim 9

The magnetic coupling device of claim 1 , wherein the magnetic platter is releasably supported by the housing.

### Claim 10

The magnetic coupling device of claim 1 , wherein the workpiece contact interface has a quadrilateral footprint.

### Claim 11

The magnetic coupling device of claim 10 , wherein the quadrilateral footprint is a rectangular footprint or a square footprint.

### Claim 12

The magnetic coupling device of claim 1 , further comprising a sensing system supported by the housing, the sensing system including at least one sensor which monitors a level of magnetic flux available to the ferromagnetic workpiece at the workpiece contact interface.

### Claim 13

The magnetic coupling device of claim 1 , further comprising an actuator configured to linearly translate the magnetic platter between the first state and the second state.

### Claim 14

The magnetic coupling device of claim 13 , wherein the actuator is at least one of: a pneumatic actuator, a hydraulic actuator, and an electrical actuator.

### Claim 15

The magnetic coupling device of claim 1 , wherein the ferrous piece spans multiple pole piece portions and/or multiple permanent magnet portions.

### Claim 16

A method of coupling and decoupling the magnetic coupling device of claim 1 to the ferromagnetic workpiece, the method comprising the steps of: contacting the ferromagnetic workpiece with the workpiece contact interface of the magnetic coupling device; moving the magnetic platter of the magnetic coupling device from a first separation from the workpiece engagement surface to a second separation from the workpiece engagement surface that is less than the first separation; moving the workpiece from a first position to a second position with the magnetic coupler; and moving the magnetic platter to a third separation from the workpiece engagement surface to decouple the magnetic coupler from the workpiece and to form a magnetic circuit through the ferrous piece within the housing, the third separation being greater than the second separation.

### Claim 17 (independent)

A magnetic coupling device for magnetic coupling to a ferromagnetic workpiece, comprising: a housing having a passageway defining a passageway axis; a brake supported by the housing; a magnetic platter supported by the housing, the magnetic platter being moveable along the passageway axis between a first position and a second position, the magnetic platter including a plurality of permanent magnet portions interposed between a plurality of ferromagnetic pole piece portions, the magnetic platter moveable to a third position intermediate the first position and the second position, the brake operable to releasably hold the magnetic platter in the third position; a workpiece contact interface supported by the housing and adapted to contact the ferromagnetic workpiece; and a magnetic shunt supported by the housing and magnetically accessible from the passageway, wherein with the magnetic platter is in the first position a first magnetic circuit is formed with the magnetic platter and the magnetic shunt and with the magnetic platter in the second position a second magnetic circuit is formed with the magnetic platter and the ferromagnetic workpiece through the workpiece interface.

### Claim 18

The magnetic coupling device of claim 14 , further comprising a sensor which monitors a position of the actuator.

### Claim 19

The magnetic coupling device of claim 1 , wherein the ferrous piece is spaced apart from the workpiece contact interface in both the first state of the magnetic coupling device and the second state of the magnetic coupling device.

### Claim 20

The magnetic coupling device of claim 1 , wherein the ferrous piece is positioned within the housing.

### Claim 21

The magnetic coupling device of claim 1 , wherein the ferrous piece extends vertically, a lower edge of the magnetic platter being above a lower edge of the ferrous piece in the first state and the lower edge of the magnetic platter being below the lower edge of the ferrous piece in the second state.

### Claim 22 (independent)

A magnetic coupling device for magnetic coupling to a ferromagnetic workpiece, comprising: a housing having a passageway defining a passageway axis; a brake supported by the housing; a plurality of projections, each of the plurality of projections being received within the housing and having a surface exposed along a lower end of the housing to form a workpiece contact interface adapted to contact the ferromagnetic workpiece; a magnetic platter supported by the housing, the magnetic platter is linearly translatable within the housing along the passageway axis between a first position and a second position, the magnetic platter including a plurality of permanent magnet portions interposed between a plurality of ferromagnetic pole piece portions; and wherein the magnetic platter is linearly translatable within the housing along the axis to at least each of a first state, a second state, and a third state intermediate the first state and second state, the brake configured to releasably hold the magnetic platter in the third state; in the first state the plurality of ferromagnetic pole piece portions are offset vertically from the plurality of projections with a first one of the plurality of ferromagnetic pole piece portions of the magnetic platter positioned vertically over a first one of the plurality of projections, a second one of the plurality of ferromagnetic pole piece portions of the magnetic platter positioned vertically over a second one of the plurality of projections and completely horizontally offset relative to the first one of the plurality of projections, and a third one of the plurality of ferromagnetic pole piece portions of the magnetic platter positioned vertically over a third one of the plurality of projections and completely horizontally offset relative to the second one of the plurality of projections, and in the second state the plurality of ferromagnetic pole piece portions contact the plurality of projections with the first one of the plurality of ferromagnetic pole piece portions of the magnetic platter positioned vertically over the first one of the plurality of projections and contacting the first one of the plurality of projections, the second one of the plurality of ferromagnetic pole piece portions of the magnetic platter positioned vertically over the second one of the plurality of projections and contacting the second one of the plurality of projections, and the third one of the plurality of ferromagnetic pole piece portions of the magnetic platter positioned vertically over the third one of the plurality of projections and contacting the third one of the plurality of projections and completely to the first side of the first of the plurality of projections, wherein the magnetic coupling device provides a first magnetic field at the workpiece contact interface of the magnetic coupling device when the magnetic platter is in the first state and the magnetic coupling device provides a second magnetic field at the workpiece contact interface when the magnetic platter is in the second state, the second magnetic field being a non-zero magnetic field strength and greater than the first magnetic field of the first state.

### Claim 23

The magnetic coupling device of claim 22 , wherein the plurality of permanent magnet portions and the plurality of ferromagnetic pole piece portions of the magnetic platter form a linear array.

### Claim 24

The magnetic coupling device of claim 22 , further comprising an actuator configured to linearly translate the magnetic platter between the first state and the second state.

### Claim 25

The magnetic coupling device of claim 24 , wherein the actuator is at least one of: a pneumatic actuator, a hydraulic actuator, and an electrical actuator.

### Claim 26

The magnetic coupling device of claim 25 , further comprising a sensor which monitors a position of the actuator.

### Claim 27

The magnetic coupling device of claim 22 , wherein a lower surface of the first one of the plurality of ferromagnetic pole piece portions of the magnetic platter matches an upper surface the first one of the plurality of projections, a lower surface of the second one of the plurality of ferromagnetic pole piece portions of the magnetic platter matches an upper surface the second one of the plurality of projections, and a lower surface of the third one of the plurality of ferromagnetic pole piece portions of the magnetic platter matches an upper surface the third one of the plurality of projections.

## Full description

### Related Applications

**[p0001]**

This application is a national stage application of PCT International Application No. PCT/US2019/057766, filed Oct. 24, 2019, titled LINEARLY ACTUATED MAGNETIC COUPLING DEVICE, which claims the benefit of U.S. Provisional Application No. 62/750,082 filed Oct. 24, 2018, titled LINEARLY ACTUATED MAGNETIC COUPLING DEVICE, the disclosures of which are hereby expressly incorporated by reference herein in their entirety.

### Technical Field

**[p0002]**

The present disclosure relates to magnetic coupling devices. More specifically, the present disclosure relates to magnetic coupling devices configured to be linearly actuated and de-actuated.

### Background

**[p0003]**

Magnetic coupling devices are used to couple a ferromagnetic workpiece to transport the ferromagnetic workpiece from a first location to a second location, hold the ferromagnetic workpiece, and/or lift the ferromagnetic workpiece. An exemplary magnetic coupling device is a switchable magnetic coupling device which may include a magnetic platter that is linearly translatable between an “off” position and an “on” position. When the magnetic platter is in an “on” state, the magnetic coupling device is configured to couple to a ferromagnetic workpiece to perform, for example, lifting operations, material handling, material holding, magnetically latching or coupling objects to one another, among other applications.

### Summary

**[p0004]**

Embodiments included herein relate to magnetic coupling devices configured to be linearly actuated and de-actuated. Embodiments include but are not limited to the following examples. In a first example embodiment, a magnetic coupling device for magnetic coupling to a ferromagnetic workpiece, comprises: a housing having an axis extending between a first end portion of the housing and a second end portion of the housing; a ferrous piece arranged at least a first distance from the second end portion of the housing; a magnetic platter supported by the housing, the magnetic platter including a plurality of permanent magnet portions interposed between a plurality of ferromagnetic pole piece portions; and wherein the magnetic platter is linearly translatable within the housing along the axis to at least each of a first state and a second state, the magnetic platter being arranged adjacent to the ferrous piece such that the magnetic coupling device establishes a first magnetic circuit through the ferrous piece and provides a first magnetic field at a workpiece contact interface of the magnetic coupling device when the magnetic platter is in the first state and the magnetic platter being arranged spaced apart from the ferrous piece such that the magnetic coupling device provides a second magnetic field at the workpiece contact interface when the magnetic platter is in the second state, the second magnetic field being a non-zero magnetic field strength.

**[p0005]**

In a second example embodiment, a method of coupling and decoupling a magnetic coupler to a ferromagnetic workpiece comprises: contacting the ferromagnetic workpiece with a workpiece engagement interface of the magnetic coupler; moving a magnetic platter of the magnetic coupling device from a first separation from the workpiece engagement surface to a second separation from the workpiece engagement surface that is less than the first separation; moving the workpiece from a first position to a second position with the magnetic coupler; and moving the magnetic platter to a third separation from the workpiece engagement surface to decouple the magnetic coupler from the workpiece and to form a magnetic circuit through a ferrous piece within the housing, the third separation being greater than the second separation. In a third example embodiment, a magnetic coupling device for magnetic coupling to a ferromagnetic workpiece, comprises: a housing having a passageway defining a passageway axis; a magnetic platter supported by the housing, the magnetic platter being moveable along the passageway axis between a first position and a second position, the magnetic platter including a plurality of permanent magnet portions interposed between a plurality of ferromagnetic pole piece portions; a workpiece contact interface supported by the housing and adapted to contact the ferromagnetic workpiece; and a magnetic shunt supported by the housing and magnetically accessible from the passageway, wherein with the magnetic platter is in the first position a first magnetic circuit is formed with t

**[p0005]**

he magnetic platter and the magnetic shunt and with the magnetic platter in the second position a second magnetic circuit is formed with the magnetic platter and the ferromagnetic workpiece through the workpiece interface.

**[p0006]**

While multiple embodiments are disclosed, still other embodiments of the present invention will become apparent to those skilled in the art from the following detailed description, which shows and describes illustrative embodiments of the invention. Accordingly, the drawings and detailed description are to be regarded as illustrative in nature and not restrictive.

### Brief Description Of The Drawings

**[p0007]**

FIG. 1 A illustrates a side sectional view of an exemplary magnetic coupling device in an exemplary first, off state positioned on a ferromagnetic workpiece. FIG. 1 B illustrates a front sectional view of the magnetic coupling device of FIG. 1 A . FIG. 1 C illustrates a front view of the magnetic coupling device of FIG. 1 A . FIG. 2 illustrates a front sectional view of the magnetic coupling device of FIGS. 1 A- 1 C in a second, on state. FIG. 3 illustrates a front sectional view of the magnetic coupling device of FIGS. 1 A- 1 C in a third, on state. FIG. 4 illustrates an exploded view of the magnetic coupling device of FIGS. 1 A- 1 C . FIG. 5 illustrates a top sectional view of the magnetic coupling device of FIGS. 1 A- 1 C in a first position on a ferromagnetic workpiece. FIG. 6 illustrates a top sectional view of the magnetic coupling device of FIGS. 1 A- 1 C in a second position on a ferromagnetic workpiece. FIGS. 7 - 13 are exemplary portions of pole plates that can be incorporated into the magnetic coupling device of FIGS. 1 A- 1 C .

**[p0008]**

FIG. 14 illustrates a robotic system including the exemplary magnetic coupling device of FIGS. 1 A- 1 C attached as an end of arm coupler. FIG. 15 illustrates a top sectional view of an exemplary sensor layout of the magnetic coupling device of FIGS. 1 A- 1 C . FIG. 16 illustrates a simplified front elevation view of the magnetic coupling device of FIGS. 1 A- 1 C and no ferromagnetic workpiece in the proximity of the magnetic coupling device of FIGS. 1 A- 1 C . FIG. 17 illustrates a simplified front elevation view of the magnetic coupling device of FIGS. 1 A- 1 C and a ferromagnetic workpiece separated from the magnetic coupling device by a first separation. FIG. 18 illustrates a simplified front elevation view of the magnetic coupling device of FIGS. 1 A- 1 C and a ferromagnetic workpiece separated from the magnetic coupling device. FIG. 19 illustrates a simplified front elevation view of the magnetic coupling device of FIGS. 1 A- 1 C being tilted left-to-right relative to a ferromagnetic workpiece.

**[p0009]**

FIG. 20 illustrates a simplified front elevation view of the magnetic coupling device of FIGS. 1 A- 1 C being tilted front-to-back relative to a ferromagnetic workpiece. FIG. 21 illustrates a simplified front elevation view of the magnetic coupling device of FIGS. 1 A- 1 C contacting a right edge portion of a ferromagnetic workpiece. FIG. 22 illustrates a simplified front elevation view of the magnetic coupling device of FIGS. 1 A- 1 C contacting a central portion of a ferromagnetic workpiece. FIG. 23 illustrates a simplified front elevation view of the magnetic coupling device of FIGS. 1 A- 1 C contacting a ferromagnetic workpiece at a first limit position. FIG. 24 illustrates a simplified front elevation view of the end of arm magnetic coupling device of FIGS. 1 A- 1 C contacting a ferromagnetic workpiece at a second limit position. While the invention is amenable to various modifications and alternative forms, specific embodiments have been shown by way of example in the drawings and are described in detail below. The intention, however, is not to limit the invention to the particular embodiments described. On the contrary, the invention is intended to cover all modifications, equivalents, and alternatives falling within the scope of the invention as defined by the appended claims.

### Detailed Description

**[p0010]**

In the figures as well as in the preceding section of this specification, terms such as ‘upper’, ‘axial’ and other terms of reference are used to facilitate an understanding of the technology here described and are not to be taken as absolute and limiting reference indicators, unless the context indicates otherwise. The terms “couples”, “coupled”, “coupler” and variations thereof are used to include both arrangements wherein the two or more components are in direct physical contact and arrangements wherein the two or more components are not in direct contact with each other (e.g., the components are “coupled” via at least a third component), but yet still cooperate or interact with each other. FIG. 1 A illustrates a side sectional view of an exemplary switchable magnetic coupling device 100 in a first, off state; FIG. 1 B illustrates a front sectional view of magnetic coupling device 100 ; and FIG. 1 C illustrates a front view of magnetic coupling device 100 . FIG. 2 illustrates a front sectional view of the magnetic coupling device of FIGS. 1 A- 1 C in a second, on state. FIG. 3 illustrates a front sectional view of the magnetic coupling device of FIGS. 1 A- 1 C in a third, on state.

**[p0011]**

Magnetic coupling device 100 may be switched between a first, off state (depicted in FIGS. 1 A- 1 C ), a second, on state (depicted in FIG. 2 ), and/or a third, on state. When magnetic coupling device 100 is switched to an on state, a magnetic field produced by magnetic coupling device 100 passes through one or more ferromagnetic workpieces 102 and couples magnetic coupling device 100 to one or more of the ferromagnetic workpieces 102 . When magnetic coupling device 100 is switched to an off state, magnetic field produced by magnetic coupling device 100 is primarily confined within magnetic coupling device 100 and, therefore, magnetic coupling device 100 no longer couples to one or more of the ferromagnetic workpieces 102 . The off state and the on states are discussed in more detail below. Magnetic coupling device 100 may be used as an end of arm (“EOAMT”) unit for a robotic system, such as robotic system 600 (see FIG. 14 ), but may also be used with other lifting, transporting, and/or separating systems for ferromagnetic workpieces 102 . Exemplary lifting and transporting systems include robotic systems, mechanical gantries, crane hoists and additional systems which lift and/or transport ferromagnetic workpieces 102 . Additionally, magnetic coupling device 100 may also be used as part of a stationary fixture for holding at least one part for an operation, such as welding, inspection, and other operations.

**[p0012]**

Referring to FIG. 1 A , magnetic coupling device 100 is positioned on top of ferromagnetic workpieces 102 and includes a workpiece contact interface 104 configured to contact and engage the ferromagnetic workpieces 102 . Workpiece contact interface 104 may be a pole plate 106 . In at least one embodiment, the pole plate 106 includes a plurality of spaced-apart projections 108 as illustrated in FIG. 1 B . In other embodiments, the pole plate 106 does not include spaced-apart projections 108 . The spaced-apart projections 108 may facilitate concentrating more magnetic flux near the workpiece contact interface 104 so that when magnetic coupling device 100 is in an on state, the magnetic flux of the magnetic coupling device 100 primarily passes through the first ferromagnetic workpiece 102 ′. Exemplary aspects of the pole plate 106 and the projections 108 are discussed below. Magnetic coupling device 100 also includes a housing 110 that supports a magnetic platter 112 . Magnetic platter 112 produces the magnetic field that allows magnetic coupling device 100 to couple to ferromagnetic workpieces 102 when the magnetic coupling device 100 is in an on state. In at least one embodiment, magnetic platter 112 is a laminated magnetic platter that includes a plurality of spaced-apart permanent magnet portions 114 and a plurality of pole portions 116 , as shown in FIG. 1 B B. Each of the plurality of spaced-apart permanent magnet portions 114 includes one or more permanent magnets. In one embodiment, each permanent magnet portion 114 includes a single permanent magnet. In another embodi

**[p0012]**

ment, each permanent magnet portion 114 includes a plurality of permanent magnets. Each permanent magnet portion 114 is diametrically magnetized and has a north-pole side and a south-pole side.

**[p0013]**

Each pole portion 116 A is positioned between two of permanent magnet portions 114 and pole portions 116 B are arranged adjacent to one permanent magnet portion 114 . Further, the permanent magnet portions 114 are arranged so that each of the two permanent magnet portions 114 contacting the pole portion 116 A therebetween have either their north pole sides or their south pole sides contacting the pole portion 116 A. When the north-pole sides of the adjacent permanent magnet portions 114 are contacting a pole portion 116 A, the pole portion 116 A is referred to as a north-pole portion. When the south-pole sides of the adjacent permanent magnet portions 114 are contacting a pole portion 116 A, the pole portion 116 A is referred to as a south-pole portion. Similarly, for pole portions 116 B, when the south-pole side of a permanent magnet portion 114 contacts the pole portion 116 B, the pole portion 116 B is referred to as a south-pole portion. Conversely, when the north-pole side of a permanent magnet portion 114 contacts the pole portion 116 B, the pole portion 116 B is referred to as a north-pole portion.

**[p0014]**

In the embodiments shown, the permanent magnet portions 114 are arranged along a horizontal axis 118 . However, in other embodiments, the permanent magnet portions 114 may be arranged in a circular configuration. Furthermore, while the embodiment illustrates magnetic platter 112 including six permanent magnet portions 114 and seven pole portions 116 , other embodiments may include more or fewer permanent magnet portions 114 and pole portions 116 . For example, in one embodiment, magnetic platter 112 may include one permanent magnet portion 114 and two pole portions 116 , where one pole portion 116 is arranged on each side of permanent magnet portion 114 . Due to the configuration of magnetic platter 112 and magnetic coupling device 100 , magnetic coupling device 100 may be have a greater magnetic flux transfer to one or more of the ferromagnetic pieces 102 than conventional embodiments. This results in magnetic coupling device 100 being able to lift more and/or heavier ferromagnetic workpieces 102 per magnetic volume included in magnetic coupling device 100 . For example, the magnetic coupling device 100 may have a holding force of greater than or equal to 0.35 grams of ferromagnetic workpieces 102 per cubic mm of volume of the magnetic coupling device 100 . As another example, the magnetic coupling device 100 may have a holding force of greater than or equal to 0.8 grams of ferromagnetic workpieces 102 per cubic mm of volume of the housing 110 of the magnetic coupling device 100 .

**[p0015]**

To switch magnetic coupling device 100 between a first, off state and a second, on state, magnetic platter 112 is linearly translatable along an axis 120 within an interior cavity 122 of the housing 104 . In embodiments, the axis 120 is a vertical axis 120 . Alternatively, the axis 120 is an axis other than a vertical axis. The axis 120 extends between a first end portion 124 of the housing 104 and a second end portion 126 of the housing 110 . In at least some embodiments, the first end portion 124 is an upper portion of the housing 110 and the second end portion 126 is a lower portion of the housing 110 and may be referred to herein as such. However, in at least some other embodiments, the first end portion 124 is a portion of the housing 110 other than the upper portion of the housing 110 and the second end portion 126 is a portion of the housing 110 other than the lower portion of the housing 110 . When magnetic platter 112 is arranged near the upper portion 124 of the housing 110 , magnetic coupling device 100 is in a first, off state. When magnetic platter 112 is arranged near the lower portion 126 of the housing 110 , magnetic coupling device 100 is in a second, on state. In addition to a first, off state and a second, on state, magnetic platter 112 may be arranged at one or more intermediate positions between the upper portion 124 and the lower portion 126 , as shown in FIG. 3 . An intermediate position may be referred to herein as a third, on state. The third, on state may produce less magnetic flux at the workpiece contact interface 104 than the second, on state, a

**[p0015]**

s discussed below. For example, the third, on state may result in the majority of the magnetic flux extending through only the first workpiece 102 ′ so that only a small amount of magnetic flux extends through the second and third workpieces 102 ″, 102 ′″. As such, the third, on state can facilitate de-stacking workpiece 102 ′ from the workpieces 102 ″, 102 ′″, as illustrated.

**[p0016]**

To translate the magnetic platter 112 along the vertical axis 120 to transition to magnetic coupling device 100 between an on state and off state and vice-versa, magnetic coupling device 100 includes an actuator 128 . In at least one embodiment, actuator 128 is coupled to magnetic platter 112 via an engagement portion 130 and a non-ferromagnetic mounting plate 132 . That is, actuator 128 is coupled to engagement portion 130 which is coupled to non-ferromagnetic mounting plate 132 ; and, non-ferromagnetic mounting plate 132 is coupled to and in contact with magnetic platter 112 . Actuator 128 is configured to impart a force on engagement portion 130 and, in response, engagement portion 130 translates along vertical axis 120 to transition magnetic coupling device 100 from an off state to an on state and vice versa. That is, to transition magnetic coupling device 100 from an off state to an on state, actuator 128 imparts a downward force on engagement portion 130 , which translates to non-ferromagnetic mounting plate 132 and magnetic platter 112 . In response, magnetic platter 112 translates from the upper portion 124 to the lower portion 126 . Conversely, to transition magnetic coupling device 100 from an on state to an off state, actuator 128 imparts an upward force on engagement portion 130 , which translates to non-ferromagnetic mounting plate 132 and magnetic platter 112 . In response, magnetic platter 112 and non-ferromagnetic mounting plate 132 translate from the lower portion 126 to the upper portion 124 .

**[p0017]**

To arrange magnetic platter 112 at a third, on state, actuator 128 may produce a force on engagement portion 130 to translate magnetic platter 112 from the upper portion 124 to the lower portion 126 or vice versa. Then, when the magnetic platter 112 is transitioning from the upper portion 124 to the lower portion 126 or vice versa, a brake 134 arranged within housing 110 and/or within actuator 128 may engage magnetic platter 112 , non-ferromagnetic mounting plate 132 and/or engagement portion 130 and stop magnetic platter 112 at a third, on state, as depicted in FIG. 3 . Exemplary actuators 128 include electrical actuators, pneumatic actuators, hydraulic actuators, and other suitable devices which impart a force on engagement portion 130 . An exemplary pneumatic linear actuator is depicted in FIG. 4 and discussed in more detail in relation thereto. An exemplary electrical actuator is an electric motor with an “unrolled” stator and rotor coupled to the engagement portion 130 . Other exemplary engagement portions and actuators are disclosed in U.S. Pat. No. 7,012,495, titled SWITCHABLE PERMANENT MAGNETIC DEVICE; U.S. Pat. No. 7,161,451, titled MODULAR PERMANENT MAGNET CHUCK; U.S. Pat. No. 8,878,639, titled MAGNET ARRAYS, U.S. Provisional Patent Application No. 62/248,804, filed Oct. 30, 2015, titled MAGNETIC COUPLING DEVICE WITH A ROTARY ACTUATION SYSTEM; and U.S. Provisional Patent Application No. 62/252,435, filed Nov. 7, 2015, titled MAGNETIC COUPLING DEVICE WITH A LINEAR ACTUATION SYSTEM, the entire disclosures of which are herein expressly incorporated by reference.

**[p0018]**

Additionally, or alternatively, actuator 128 may include a controller 136 and/or sensor 138 A. Controller 136 includes a processor 140 with an associated computer readable medium, illustratively memory 142 . Memory 142 includes control logic 144 which when executed by processor 140 causes electronic controller 136 to instruct actuator 128 to move magnetic platter 112 so that magnetic coupling device 100 is in an off state, second on state and/or third on state. For example, sensor 138 A may sense a position of actuator 128 and, in response to a predetermined position sensed by sensor 138 A, which translates to a position of magnetic platter 112 , control logic 144 instructs actuator 128 to stop exerting a force on magnetic platter 112 when magnetic platter 112 reaches a desired position. In at least one embodiment, actuator 128 is a stepper motor and rotary motion of actuator 128 is translated to linear motion of engagement portion 130 via a coupling (e.g., gear) between a shaft of actuator 128 and engagement portion 130 . In these embodiments, sensor 138 A counts the pulses used to drive the stepper motor and determines a position of the shaft of the stepper motor, which is translated to a position of magnetic platter 112 , based on the number of pulses. That is, magnetic platter 112 is moved relative along the vertical axis 120 to a defined position by the steps the motor moves by counting the number of pulses. In another example, a stepper motor is provided that integrates an encoder with the stepper to check that the proper actuation angle is maintained.

**[p0019]**

As another example, magnetic coupling device 100 may include sensor 138 B. Sensor 138 B may measure the position of magnetic platter 112 within the housing 110 . Exemplary sensors 138 B include optical sensors which monitor reflective strips affixed to magnetic platter 112 . Other sensor systems may be used to determine a position of magnetic platter 112 . As even another example, magnetic coupling device 100 may include one or more sensors 138 C (illustrated in FIG. 1 B ). Sensors 138 C may be magnetic flux sensors and positioned generally at one or more positions over pole plate 106 . Exemplary magnetic flux sensors include Hall-effect sensors. Sensors 138 C measure the leakage flux proximate to one or more north and south poles of pole plate 106 . The amount of leakage flux at each sensor 138 C varies based on the position of magnetic platter 112 relative to pole plate 106 and the amount of flux passing through the north and south poles of pole plate 106 , workpiece contact interface 104 to ferromagnetic workpiece 102 . By monitoring the magnetic flux at locations opposite workpiece interface 104 of north and south poles of pole plate 106 , the relative position of magnetic platter 112 may be determined. In embodiments, magnetic coupling device 100 is positioned on top of ferromagnetic workpieces 102 and the magnetic fluxes measured by sensors 138 C as magnetic platter 112 moves from an off state to a second, on state are recorded as a function of position of magnetic platter 112 . Each of the magnetic fluxes are assigned to a desired position of magnetic platter 112 . A

**[p0019]**

n exemplary sensing system having sensors 138 C is disclosed in U.S. patent application Ser. No. 15/964,884, titled Magnetic Coupling Device with at Least One of a Sensor Arrangement and a Degauss Capability, filed Apr. 27, 2018, the entire disclosure of which is expressly incorporated by reference herein.

**[p0020]**

As even another example, magnetic coupling device 100 may include one or more sensors 138 D (illustrated in FIGS. 1 A, 1 B, 1 C, 2 , and 3 ). Sensors 138 D may be magnetic flux sensors and positioned generally adjacent the pole plate 106 . Exemplary magnetic flux sensors include Hall-effect sensors. In at least one example, the sensors 138 D are located adjacent to the ends of one or more of the projections 108 of the pole plate 106 and measure the leakage flux out of the sides of one or more north and south poles of pole plate 106 . The amount of leakage flux at each sensor 138 D varies based on the position of magnetic platter 112 relative to pole plate 106 and the amount of flux passing through the north and south poles of pole plate 106 and the workpiece contact interface 104 to the ferromagnetic workpiece 102 . By monitoring the magnetic flux at locations adjacent to pole plate 106 , the relative position of magnetic platter 112 may be determined. In embodiments, magnetic coupling device 100 is positioned on top of ferromagnetic workpieces 102 and the magnetic fluxes measured by sensors 138 D as magnetic platter 112 moves from an off state to a second, on state are recorded as a function of position of magnetic platter 112 . Each of the magnetic fluxes are assigned to a desired position of magnetic platter 112 . An exemplary sensing system having sensors 138 D is disclosed in U.S. patent application Ser. No. 15/964,884, titled Magnetic Coupling Device with at Least One of a Sensor Arrangement and a Degauss Capability, filed Apr. 27, 2018, the entire disclosure of which

**[p0020]**

is expressly incorporated by reference herein.

**[p0021]**

In at least some embodiments, magnetic coupling device 100 includes a shielding plate 139 (illustrated in FIGS. 1 A, 1 B, 1 C, 2 , and 3 ). The shielding plate 139 may absorb magnetic flux from the magnetic platter 112 and reduce the external field of the magnetic coupling device 100 when the magnetic coupling device 100 is in an off position. The shielding plate 139 may be formed from a high magnetic saturation material that is capable of absorbing a high amount of magnetic flux. In one example, the shielding plate 139 is located external to the housing 110 . The top edge of the shielding plate 139 may be planar with a top surface of the magnetic platter 112 . Additionally, or alternatively, the shielding plate 139 may extend downward along the housing 110 so that a bottom edge of the shielding plate 139 extends past the bottom planar surface of the magnetic platter 112 . The shielding plate 139 can be located on any side of the magnetic coupling device 100 . In at least one example, shielding plates 139 are located on all sides of the magnetic coupling device 100 . In another example, the shielding plates 139 A are only located on faces of the magnetic coupling device 100 that are adjacent to the ends of the permanent magnetic portions 114 , as shown in FIGS. 1 A, 1 C . Stated another way, the shielding plates 139 A may be located on the same side(s) as the sensors 138 D. In another example, the shielding plates 139 B are only located on sides of the magnetic coupling device 110 that extend parallel to the projections 108 , as shown in FIGS. 2 and 3 .

**[p0022]**

In embodiments, the controller 136 changes the state of magnetic coupling device 100 in response to an input signal received from an I/O device 146 . Exemplary input devices include buttons, switches, levers, dials, touch displays, pneumatic valves, soft keys, and communication module. Exemplary output devices include visual indicators, audio indicators, and communication module. Exemplary visual indicators include displays, lights, and other visual systems. Exemplary audio indicators include speakers and other suitable audio systems. In embodiments, device 100 includes simple visual status indicators, in the form of one or more LEDs, which are driven by the processor 140 of control logic 144 , to indicate when a predefined magnetic coupling device 100 status is present or absent (e.g. Red LED on when magnetic coupling device 100 is in a first, off state, Green LED blinking fast when magnetic coupling device 100 is in a second, on state and proximity of ferromagnetic workpiece 102 is detected, Green LED slower blinking with Yellow LED on when contacting ferromagnetic workpiece 102 outside intended specific area (see discussion related to FIGS. 22 - 24 ) on ferromagnetic workpiece 102 (e.g. partially complete magnetic working circuit) and Yellow LED off with steady Green LED on, showing magnetic coupling device 100 engagement within threshold limits, showing safe magnetic coupling state.

**[p0023]**

For example, in one embodiment, magnetic coupling device 100 is coupled to an end of arm of a robotic arm and I/O device 146 is a network interface over which controller 136 receives instructions from a robot controller on when to place magnetic coupling device 100 in one of a first off-state, second on-state, or third on-state. Exemplary network interfaces include a wired network connection and an antenna for a wireless network connection. While the embodiments discussed above relate to electronic, pneumatic, or hydraulic actuation, in alternative embodiments, the magnetic coupling device 100 may be actuated manually by a human operator. Magnetic coupling device 100 may also include one or more ferromagnetic pieces 148 arranged at or near an upper portion 124 of the housing 100 , as illustrated in FIG. 1 A . In at least one embodiment, non-ferromagnetic mounting plate 132 and ferromagnetic pieces 148 are arranged within housing 110 so that non-ferromagnetic mounting plate 132 is located between and in contact with ferromagnetic pieces 148 when magnetic coupling device 100 is in the first, off position. Furthermore, top portions of magnetic platter 112 may be in contact with bottom portions of ferromagnetic pieces 148 . In another exemplary embodiment, the ferromagnetic pieces 148 may extend down the sides of the magnetic platter 112 . In these embodiments, the ferromagnetic pieces 148 may reduce leakage of the magnetic platter 112 by providing additional absorption of the magnetic field generated by the magnetic platter 112 .

**[p0024]**

In at least one embodiment, non-ferromagnetic mounting plate 132 may be made of a non-ferromagnetic material (e.g., aluminum, austenitic stainless steels, etc.). In these embodiments, when magnetic coupling device 100 is in a first, off state and magnetic platter 112 and non-ferromagnetic mounting plate 132 are positioned at or near the upper portion 118 of the housing 104 , one or more circuits between the mounting platter 112 , ferromagnetic pieces 148 and non-ferromagnetic mounting plate 132 is created, as illustrated in FIG. 1 B . Furthermore, when magnetic coupling device 100 is in a first, off state, a gap 150 (of FIG. 1 A ) that comprises air and/or another substance having a low magnetic susceptibility in the interior cavity 116 is between and separates pole plate 106 and magnetic platter 112 . As a result, little or no magnetic flux from the magnetic platter 112 extends to the workpiece contact interface 104 and through the ferromagnetic workpieces 102 when the magnetic coupling device 100 is in the first, off state. Therefore, magnetic coupling device 100 can be separated from ferromagnetic workpieces 102 . Furthermore, most if not all of the magnetic flux from the magnetic platter 112 is contained within the housing 110 due to the circuits between the mounting platter 112 , ferromagnetic pieces 148 and non-ferromagnetic mounting plate 132 .

**[p0025]**

An additional advantage of including ferromagnetic pieces 148 is that the distance of the gap 150 between the bottom of magnetic platter 112 and pole plate 106 can be less than if magnetic coupling device 100 didn&#39;t include a non-ferromagnetic mounting plate 132 and ferromagnetic pieces 148 . That is, one or more circuits created between magnetic platter 112 , ferromagnetic pieces 148 and non-ferromagnetic mounting plate 132 , facilitates confining most if not all of the magnetic flux from magnetic platter 112 within the housing 110 , near the magnetic platter 112 and away from the pole plate 106 . As such, the magnetic flux transferred to the ferromagnetic workpieces 102 by the magnetic coupling device 100 is insufficient to lift one or more of the ferromagnetic workpieces 102 . Stated another way, the magnetic flux may be effectively zero at the bottom of the pole plate 106 and, therefore, effectively no magnetic flux is transferred to the ferromagnetic workpieces 102 by the magnetic coupling device 102 , which reduces the overall required height the magnetic platter 112 needs to travel (see height 182 below) when the magnetic coupling device 102 transitions between an off state and one or more on states.

**[p0026]**

Conversely, if non-ferromagnetic mounting plate 132 and ferromagnetic pieces 148 weren&#39;t included in the magnetic coupling device 102 , less of the magnetic flux from the magnetic platter 112 would be confined within housing 110 and/or near magnetic platter 112 . And, because less magnetic flux would be confined near magnetic platter 112 , the gap 150 between the bottom of magnetic platter 112 and pole plate 106 would have to be greater in order for the magnetic flux not to extend down through the pole plate 106 and couple magnetic coupling device 100 to one or more of the ferromagnetic workpieces 102 . Due to the gap 150 being smaller in the illustrated embodiment, magnetic coupling device 100 can be smaller than other magnetic coupling devices not having these features. As an example, the gap 150 the magnetic platter 112 may travel to transition between the first, off state to the second, on state may be less than or equal to 8 mm. Conversely, to transition from the second, on state to the first, off state, the magnetic platter 112 may travel less than or equal to 8 mm.

**[p0027]**

Another advantage of the illustrated embodiment is that less energy can be used by actuator 128 to translate magnetic platter 112 along the vertical axis 120 within the housing 110 due to the gap 150 being smaller. Even another advantage of the illustrated embodiment, is that it will be less likely magnetic platter 112 will break when actuator 128 translates magnetic platter 112 from the first, off position to the second, on position and magnetic platter 112 comes into contact with pole piece 106 . This is a result of magnetic platter 112 building less momentum during the transition due to the reduced gap 150 . As even another advantage of the illustrated embodiment, in the event magnetic coupling device 100 fails while magnetic coupling device 100 is in an off state, magnetic coupling device 100 will not transition to an on state due to the non-ferromagnetic mounting plate 132 and the ferromagnetic pieces 148 . As such, the magnetic coupling device 100 is safer than a magnetic coupling device that transitions from an off state to an on state when the magnetic coupling device fails. Conversely, in the event magnetic coupling device 100 didn&#39;t include a non-ferromagnetic mounting plate 132 and/or ferromagnetic pieces 148 , magnetic platter 112 may be more likely to transition to an on state due to the lack of magnetic circuit created in the off position.

**[p0028]**

As stated above, when the magnetic platter 106 is positioned at or near the lower portion 126 of the housing 104 , magnetic coupling device 100 is in a second, on state. As illustrated in FIG. 2 , magnetic flux from the magnetic platter 106 extends through one or more of the ferromagnetic workpieces 102 when the magnetic coupling device 100 is in the second, on state. As such, the magnetic coupling device 100 is configured to couple to one or more ferromagnetic workpieces 102 when the magnetic coupling device 100 is in the first, on state. While the magnetic flux lines are illustrated as passing through both ferromagnetic workpieces 102 ′, 102 ″, in some embodiments the magnetic flux lines primarily pass only through the ferromagnetic workpiece 102 ′. When the magnetic flux lines primarily pass through the first ferromagnetic workpiece 102 ′, the magnetic coupling device 100 can be used to de-stack and separate the ferromagnetic workpieces 102 from one another.

**[p0029]**

To facilitate the magnetic flux lines primarily passing through only the first ferromagnetic workpiece 102 ′ when magnetic coupling device 100 is in a second, on state, the magnetic platter 112 may be removable and replaceable, which allows different strength, height, and/or width magnetic platters 112 to be used with the magnetic coupling device 100 . The strength, height, and/or width of the magnetic platter 112 may be selected based on the thickness of the ferromagnetic workpiece 102 so that the ferromagnetic workpieces 102 can be adequately de-stacked and separated from one another when magnetic coupling device 100 is in the second, on position. Additionally or alternatively, the pole plate 106 may be removable and replaceable, which allows different types of pole plates 106 to be used with the magnetic coupling device 100 . For example, the pole plate 106 may be selected based on the type of ferromagnetic workpiece 102 to which the magnetic coupling device 100 is being coupled. For example, the magnetic coupling device 100 may be handling class-a surfaces that cannot be scratched or marred. As a result, a pole plate 106 having rubber (or another material that reduces the likelihood the ferromagnetic workpiece 102 is scratched or marred) arranged on the workpiece contact interface may be selected and incorporated into the magnetic coupling device 100 . As another example, a pole plate 106 having different projections and/or gaps may be selected based on the thickness of the ferromagnetic workpiece 102 to which the magnetic coupling device 100 is being coupled. Additiona

**[p0029]**

l examples of the relevance of the projections and/or gaps is explained in more detail below in relation to FIGS. 7 - 13 .

**[p0030]**

As discussed in more detail below in relation to FIG. 4 , the housing 104 is configured in a manner that allows the magnetic platter 112 and/or the pole plate 106 to be easily removable and replaceable. Additionally, or alternatively, magnetic coupling device 100 may be transition to one or more intermediate states as stated above. For example, magnetic coupling device 100 may transition to a third, on state, as illustrated in FIG. 3 . The third, on state is when magnetic platter 112 is located along the vertical axis 120 between the location of the magnetic platter 112 when the magnetic coupling device 100 is in the first, off state and the location of the magnetic platter 112 when the magnetic coupling device 100 is in the second, on state. In embodiments where the same magnetic platter 112 is being used, less magnetic flux passes through the workpiece contact interface 104 and into the ferromagnetic workpieces 102 when magnetic coupling device 100 is in the third, on state than when the magnetic coupling device 100 is in the second, on state, as illustrated in FIG. 3 . That is, assuming the same strength magnetic platter 112 is being used in the embodiments depicted in FIG. 2 and FIG. 3 , magnetic flux lines pass through both ferromagnetic workpieces 102 ′, 102 ″ in FIG. 2 , whereas magnetic flux lines pass through only ferromagnetic workpiece 102 ′ in FIG. 3 . By being able to be in a third, on state, magnetic coupling device 100 may be able to de-stack different thickness of ferromagnetic workpieces 102 without having to replace magnetic platter 112 with a different st

**[p0030]**

rength magnetic platter 112 .

**[p0031]**

As stated above, the pole plate 106 includes a plurality of projections 108 . Each of the projections 108 acts as a pole extension for a respective pole portion of the pole portions 116 . That is, when the magnetic coupling device 100 is in a second or third, on state, the respective north or south pole of the pole portions 116 extends down through a respective projection 108 . A magnetic circuit is then created that goes from a N pole portion 116 through a respective N-pole projection 108 , through one or more ferromagnetic workpieces 102 , through a S-pole projection 108 , and through a S pole portion 116 . Each permanent magnetic portion creates one of these magnetic circuits when the magnetic coupling device 100 is in an on state. As explained in more detail below in relation to FIGS. 7 - 13 , the size of the projections 108 and the distance therebetween affect the flux transfer to the ferromagnetic workpieces 102 and allow more effective de-stacking of ferromagnetic materials 102 and an increased holding force. For example, in at least some embodiments, to achieve the highest concentration of magnetic flux being transferred through a ferromagnetic piece 102 ′ of the ferromagnetic workpieces 102 and therefore have the greatest likelihood of being able to de-stack the ferromagnetic workpiece 102 ′ from the ferromagnetic workpieces 102 ″, 102 ′″, the size of the projections (e.g., width and height) and the gap therebetween should approximately match the thickness of the ferromagnetic workpieces 102 .

**[p0032]**

To separate the N and S projections 108 , the pole plate 106 may include slots configured to receive one or more non-ferromagnetic pieces 152 (depicted in FIG. 1 B ). The non-ferromagnetic pieces 152 may be arranged within respective envelopes 154 (depicted in FIG. 1 B ) between each of the projections 108 . Due to the non-ferromagnetic pieces 152 , the magnetic circuit created by the permanent magnet portions 114 does not extend substantially through the non-ferromagnetic pieces 152 and, therefore, the N and S projections are separated from one another. Furthermore, as stated above, the projections 108 result in magnetic flux from magnetic platter 112 being nearer the workpiece contact interface 104 than if the pole plate 106 did not include a plurality of projections 108 . Different aspects of the projections 108 facilitating magnetic flux from magnetic platter 112 to be concentrated nearer the workpiece contact interface 104 are discussed below in relation to FIGS. 7 - 13 .

**[p0033]**

Referring to FIG. 4 , an exploded view of the magnetic coupling device 100 is illustrated. As illustrated, the housing 110 includes a lower portion 110 A releasable securable to an upper portion 110 B. The lower portion 110 A may be secured to the upper portion 110 B using one or more screws 156 . The screws 156 may provide easy access to components of magnetic coupling device 110 arranged within the housing 110 , as explained below. Prior to joining the lower portion 110 A and the upper portion 110 B, the lower portion 110 A receives a pole plate 106 . In at least one embodiment, the lower portion 110 A includes recesses/cutouts 158 configured to receive tabs 160 of the pole plate 106 . The tabs 160 facilitate proper positioning of the pole plate 106 within the lower portion 110 A. Proper positioning of the pole plate 106 may facilitate easy replacement of the pole plate 106 in the event a pole plate 106 with different projections 108 than a currently installed pole plate 106 is desired. For example, the lower portion 110 A of the housing 110 can be separated from the upper portion 110 B by removing the screws 156 . Then, the pole plate 106 can be removed from the lower portion 110 A. After which, another pole plate 106 having different projections 108 can be inserted into the lower portion 110 A so that the tabs 160 are received by the recesses/cutouts 158 . Finally, the screws can 156 be used to secure the lower portion 110 A to the upper portion 110 A.

**[p0034]**

In addition to or in alternative to replacing the pole plate 106 , the design of magnetic coupling device 100 also facilitates easy removal and replacement of magnetic platter 112 . For example, as illustrated, the non-ferromagnetic mounting plate 132 is coupled to the magnetic platter 116 via one or more screws 161 . After removing the lower portion 110 A from the upper portion 1106 , the magnetic platter 116 can be lowered along the vertical axis 120 so the screws 161 can be accessed. Once the screws 161 are unscrewed, the magnetic platter 116 can be separated from the non-ferromagnetic mounting plate 132 and exchanged for another magnetic platter 116 . The new magnetic platter 116 can be secured to the non-ferromagnetic mounting plate 132 using the screws 161 . After which, the lower portion 110 A and the upper portion 1106 can be coupled together using the screws 156 . In some instances, the magnetic platter 116 may need to be replaced in the event the magnetic platter 116 is broken or damaged. In other instances, the magnetic platter 116 may need to be replaced with a magnetic platter 116 that produces a stronger or weaker magnetic field. As discussed above, replacing the magnetic platter 116 with a magnetic platter 116 having a stronger or weaker magnetic may facilitate de-stacking the ferromagnetic workpieces 102 . For example, a first magnetic platter 116 may produce enough magnetic flux through the first and second ferromagnetic workpieces 102 ′, 102 ″ to lift both ferromagnetic workpieces 102 ′, 102 ″. However, separating the first ferromagnetic workpiece 102 ′ fr

**[p0034]**

om the second ferromagnetic workpiece 102 ″ may be desirable. In these instances, a second magnetic platter 116 that is weaker than the first magnetic platter 116 and only produce enough magnetic flux through the ferromagnetic workpieces 102 to lift the first ferromagnetic workpiece 102 ′ may replace the first magnetic platter 116 .

**[p0035]**

In the illustrated embodiment, a lower portion 128 A of the actuator 128 is coupled to the housing 110 using one or more screws 162 . As such, the lower portion 128 A acts as a cover to the housing 110 . Further, ferromagnetic pieces 148 are coupled to a bottom portion 128 A of the actuator 128 using the one or more screws 162 . As such, when the magnetic platter 112 and non-ferromagnetic mounting plate 132 are moved to an upper portion of the housing 110 and magnetic coupling device 100 is in the first, off position, magnetic platter 112 and non-ferromagnetic mounting plate 132 are arranged near and/or in contact with the ferromagnetic pieces 148 . Magnetic circuits are then formed from N pole portions 116 of the magnetic platter 112 through one of the ferromagnetic workpieces 148 , through the non-ferromagnetic mounting plate 132 , through the other ferromagnetic workpiece 148 and to S pole portions 116 of the magnetic platter 112 . The circuit results in a number of advantages for the magnetic coupling device 100 , which are discussed above.

**[p0036]**

As illustrated, non-ferromagnetic mounting plate 132 is coupled to the engagement portion 130 with a screw 166 . The engagement portion 130 includes a first portion 130 A and a second portion 130 B, wherein in at least some embodiments, the first portion 130 A has a smaller cross-sectional area than the second portion 1306 . In at least one embodiment, the first portion 130 A extends through a conduit 168 in the bottom portion 128 A and coupled to the non-ferromagnetic mounting plate 132 via the screw 166 . Due to the coupling of the engagement portion 130 to the non-ferromagnetic mounting plate 132 , translation of the engagement portion 130 along the vertical axis 120 will translate the non-ferromagnetic mounting plate 132 and magnetic platter 112 along the vertical axis 120 . To translate the engagement portion 130 along the vertical axis 120 , the actuator 128 may be pneumatically actuated. For example, the actuator&#39;s housing 128 B may include ports 174 including a first port 174 A and a second port 174 B. When air is provided into port 174 A, via an air compressor or otherwise, the pressure within the actuator&#39;s housing 128 B and above the second portion 130 B increases, which results in the engagement portion 130 moving downward along the vertical axis 120 . The translation of the engagement portion 130 results in the magnetic platter 112 moving downward along the vertical axis 120 so the magnetic coupling device 100 is transitioned from a first, off state to a second, on state or a third, on state or from a third, on state to a second, on state. To confine ai

**[p0036]**

r provided into port 174 A within the actuator&#39;s housing 128 B and above engagement portion 130 , actuator 128 may include a cover (not shown) secured to the actuator&#39;s housing 128 B via one or more screws 176 . Additionally, or alternatively, air may be withdrawn from port 174 B in order to reduce the pressure below the second portion 1306 relative to the pressure above the second portion 130 B, which results in the engagement portion 130 moving downward along the vertical axis 120 .

**[p0037]**

Conversely, when air is provided into the port 174 B, the pressure within the actuator&#39;s housing 128 B and below the second portion 130 B increases, which results in the plate moving upward along the vertical axis 120 . The translation of the engagement portion 130 results in the magnetic platter 112 moving upward along the vertical axis 120 so the magnetic coupling device 100 is transitioned from a second, on state to a third, on state or a first, off state or from a third, on state to a first, off state. Additionally, or alternatively, air may be withdrawn from port 174 A in order to reduce the pressure above the second portion 130 B relative to the pressure below the second portion 130 B, which results in the engagement portion 130 moving upward along the vertical axis 120 . In at least some other embodiments, the ports 174 A, 174 B may be formed through the housing 110 B and pressure or a reduction in pressure may be applied to the top of the magnetic platter 112 or the bottom of the magnetic 112 to translate the magnetic platter 112 along the vertical axis 120 .

**[p0038]**

FIGS. 5 and 6 illustrate a top sectional view of the magnetic coupling device of FIGS. 1 A- 1 B in different positions on a ferromagnetic workpiece 102 . Referring to FIG. 5 , the magnetic platter 112 is shown on ferromagnetic workpiece 102 ′. As illustrated, the entirety of the footprint of the magnetic platter 112 has been placed on ferromagnetic workpiece 102 ′. As used herein, the term footprint may be defined as the surface area of the magnetic platter 112 , i.e., the width 180 times the height 182 . It is preferable to have the entire footprint of the magnetic platter 112 to be placed on the ferromagnetic workpiece 102 ′ because the most amount of flux will be transferred from magnetic platter 112 to ferromagnetic workpiece 102 ′. When the entire footprint of the magnetic platter 112 is placed on ferromagnetic workpiece 102 ′, magnetic coupling device 100 may be configured to lift greater than or equal to 22.0 grams of ferromagnetic workpieces 102 per square mm of area of footprint of the magnetic platter 112 .

**[p0039]**

While it is preferable to have the entire footprint of the magnetic platter 112 places on the ferromagnetic workpiece 102 ′, oftentimes magnetic platter 112 will be placed on ferromagnetic workpiece 102 ′ as shown in FIG. 6 . This can occur when magnetic coupling device 100 is attached to an end of arm unit for a robotic system, such as robotic system 600 (of FIG. 14 ), where placement of magnetic platter 112 on ferromagnetic workpiece 102 ′ is being performed using a determined position of the magnetic coupling device 100 , computer vision, and/or some other automated process. In the event magnetic platter 112 is placed on ferromagnetic workpiece 102 ′ as shown in FIG. 6 , the configuration of magnetic platter 112 may offer some advantages. Specifically, there may be a lower likelihood magnetic platter 112 will peel away from ferromagnetic workpiece 102 ′ when magnetic platter 112 lifts ferromagnetic workpiece 102 ′ compared to other magnetic coupling devices. That is, due to multiple permanent magnetic portions 114 being included in the magnetic platter 112 , when the magnetic platter 112 is placed on ferromagnetic workpiece 102 ′ as shown in FIG. 6 , only the left most permanent magnetic portion 114 is off of ferromagnetic workpiece 102 ′. Therefore, five other magnetic circuits are still formed between the magnetic platter 112 and the ferromagnetic workpiece 102 ′. As such, the magnetic platter 112 may still be operating at approximately an 83% capacity (⅚=0.83). Comparatively, if the magnetic platter 112 only included one permanent magnetic portion 114 , one-third of t

**[p0039]**

he magnetic circuit wouldn&#39;t be formed with the ferromagnetic workpiece 102 ′ due to ⅓ of the pole portion being off the ferromagnetic workpiece 102 ′. As such, magnetic platter 112 may be operating at approximately 66% capacity. As another example, in the event a magnetic platter had a circular footprint that included one or more north poles and one or more south poles, and the magnetic platter were only placed partially on the ferromagnetic workpiece 102 , a large portion of one of the poles or multiple poles would be off the ferromagnetic workpiece 102 thereby significantly reducing the holding force of the magnetic platter.

**[p0040]**

As stated above, pole plate 106 may have spaced-apart projections 108 . Referring to FIGS. 7 - 13 are exemplary portions of pole plates 106 and projections 108 that can be incorporated into the magnetic coupling device of FIGS. 1 A- 1 C . FIG. 7 is a side view of a portion of an exemplary portion of a pole plate 200 which can be used as the pole plate 106 . Pole plate 200 includes a plurality of projections 206 arranged on a bottom portion 208 of pole plate 200 . Each of projections 206 are separated by recess portions 210 . Additionally, the plurality of projections 206 collectively form a workpiece contact interface 212 of pole plate 200 . Due to the plurality of projections 206 included in pole plate 200 , a magnetic coupling device including pole plate 200 produces a stronger magnetic field near workpiece contact interface 212 than a magnetic coupling device including a pole plate that does not include the projections 206 . The magnetic field produced near workpiece contact interface 212 may be referred to herein as the shallow magnetic field. Furthermore, by including the plurality of projections 206 on pole plate 200 , a magnetic coupling device including pole plate 200 produces a weaker magnetic field farther away in depth from pole plate 200 than a magnetic coupling device that does not include the projections 206 . The magnetic field produced farther away from the pole plate 200 may be referred to herein as a far-field or deep magnetic field produced by pole plate 200 . Stated another way, a magnetic coupling device including pole plate 200 having projections 206 h

**[p0040]**

as a stronger holding force near workpiece contact interface 212 than a magnetic coupling device including a pole plate with a flush continuous interface that doesn&#39;t include projections 206 .

**[p0041]**

As a result of the projections 206 of pole plate 200 facilitating producing a stronger shallow magnetic field and a weaker far-field magnetic field, the magnetic coupling device including pole plate 200 may be used to de-stack thin ferromagnetic workpieces 102 better than a magnetic coupling device having pole plate without the projections 206 . That is, a magnetic coupling device including a pole plate that doesn&#39;t have the projections 206 may produce a stronger far-field magnetic field that will result in multiple thin ferromagnetic workpieces 102 being coupled to the magnetic coupling device. When trying to obtain a single thin ferromagnetic workpiece 102 from a stacked array of thin ferromagnetic workpieces 102 , this is an undesirable result. As such, instead of using a magnetic coupling device including pole plate without the projections 206 to de-stack ferromagnetic workpieces 102 , a pole plate 200 including the projections 206 may be used. In embodiments, varying the widths 214 of the projections 206 result in different shallow magnetic fields produced by the same magnetic coupling device. For example, as the width 214 of the magnetic projections 206 increases, the shallow magnetic field decreases and the far-field magnetic field increases. As such, to produce a preferred shallow magnetic field for a specific ferromagnetic workpiece 102 , the widths 214 of the projections 206 may have a width within approximately +/−25% the thickness of the ferromagnetic workpiece 102 to be de-stacked. For example, when a magnetic coupling device is de-stacking 2 mm thick ferro

**[p0041]**

magnetic workpieces 102 , the widths 214 of the projections 206 could be approximately 2 mm (e.g., 2 mm+/−25%). In embodiments, this will produce a strong shallow magnetic field between 0 mm and 2 mm depth from workpiece contact interface 212 . In at least one embodiment, however, there may be a limit for producing a preferred shallow magnetic field for some ferromagnetic workpieces 102 having thicknesses less than the limit. That is, for ferromagnetic workpieces 102 having a thickness less than X mm, a preferred shallow magnetic field may be produced by projections 206 having widths 214 that are at a lower limit of X mm but are not less than the lower limit. That is, to produce a preferred magnetic field for a workpiece 102 having a thickness of ½*X mm, the widths 214 of the projections 206 may be at the lower limit of X mm instead of +/−25% of ½*X mm. If, however, the thickness of the ferromagnetic workpiece 102 is X mm or more, then the widths 214 may approximately equal (e.g., +/−25%) the thickness of the ferromagnetic workpieces 102 . Examples of a lower limit may be in the range of 0 mm to 2 mm. However, this is only an example and not meant to be limiting.

**[p0042]**

In at least one embodiment, when a magnetic coupling device including a pole plate 200 is coupling to ferromagnetic workpieces 102 having different thicknesses, a pole plate 200 having widths 214 that is an average of the thickness of the ferromagnetic workpieces 102 may be used to reduce the need to change pole plates. Similar to above, however, a lower limit (e.g., 2.0 mm) may be applied such that if the average thickness of the ferromagnetic workpieces 102 is below the lower limit (i.e., &lt;2.0 mm), the widths 214 may be configured to be the lower limit (i.e., 2.0 mm). In embodiments, varying the depths 216 and/or widths 218 of the recesses 210 result in different shallow magnetic fields produced by the same magnetic coupling device 100 . In embodiments, to produce an appropriate shallow magnetic field for a specific ferromagnetic workpiece 102 , the depths 216 and/or widths 218 of the recesses 210 could be approximately the same (e.g., +/−25%) as the widths 214 of the projections 206 . For example, if the widths 214 of the projections 206 are 2 mm, then the depths 216 and/or widths 218 of the recesses 210 could be approximately 2 mm (e.g., 2 mm+/−25%). In embodiments, this will produce a strong shallow magnetic field between 0 mm and 2 mm depth from contact interface 212 . Similar to above, however, there may be a limit for producing a preferred shallow magnetic field for some ferromagnetic workpieces 102 having thicknesses less than the limit. That is, for ferromagnetic workpieces 102 having a thickness less than X mm, a preferred shallow magnetic field may be produce

**[p0042]**

d by depths 216 and widths 218 that are at a lower limit of X mm but are not less than the lower limit. That is, to produce a preferred magnetic field for a ferromagnetic workpiece 102 having a thickness of ½*X mm, the depths 216 and widths 218 may be at the lower limit of X mm instead of +/−25% of ½*X mm. If, however, the thickness of the ferromagnetic workpiece 102 is X mm or more, then the depths 216 and widths 218 may approximately equal (e.g., +/−25%) the thickness of the ferromagnetic workpiece 102 .

**[p0043]**

Similar to above, when a magnetic coupling device 100 including pole plate 200 is coupling ferromagnetic workpieces 102 having different thicknesses, a pole plate 200 having depths 216 and/or widths 218 of recesses 210 that is an average of the thickness of the ferromagnetic workpieces 102 may be used to reduce the need to change pole plates. Moreover, a lower limit (e.g., 2.0 mm) may be applied such that if the average thickness of the ferromagnetic workpieces 102 is below the lower limit (i.e., &lt;2.0 mm), the depths 216 and widths 218 may be configured to be the lower limit (i.e., 2.0 mm). Pole plate 200 may be releasably coupled to the magnetic coupling device 100 . Therefore, when projections 206 of the pole plate 200 do not have the appropriate widths 214 , depths 216 and/or widths 218 for the ferromagnetic workpiece 102 to which magnetic coupling device 100 is coupling, pole plate 200 may be replaced by a more appropriate pole plate 200 .

**[p0044]**

FIG. 8 is a side view of a portion of another exemplary portion of a pole plate 300 which can be used as the pole plate 106 . Similar to pole plate 200 depicted in FIG. 7 , pole plate 300 includes a plurality of projections 306 arranged on a bottom portion 308 of the pole plate 300 . Each of projections 306 are separated by a recess portion 310 . The plurality of projections 306 collectively form a workpiece contact interface 312 of pole plate 300 . Similar to above, varying the widths 314 of the projections 306 and/or the depths 316 , and/or widths 318 of the recesses 310 result in different shallow magnetic fields produced by the same magnetic coupling device 100 . In embodiments, to produce an appropriate shallow magnetic field for a specific ferromagnetic workpiece 102 , the widths 314 of the projections and/or the depths 316 , and/or widths 318 of the recesses 310 could be approximately the same (e.g., +/−25%) as the thickness of the ferromagnetic workpiece 102 to be coupled to magnetic coupling device 100 . In at least one embodiment, however, there may be a limit for producing a preferred shallow magnetic field for some ferromagnetic workpieces 102 having thicknesses less than the limit. That is, for ferromagnetic workpieces 102 having a thickness less than X mm, a preferred shallow magnetic field may be produced by widths 314 , depths 316 , and/or widths 318 that are at a lower limit of X mm but are not less than the lower limit. That is, to produce a preferred magnetic field for a ferromagnetic workpiece 102 having a thickness of ½*X mm, the widths 314 , depths 316

**[p0044]**

, and/or widths 318 may be at the lower limit of X mm instead of +/−25% of ½*X mm. If, however, the thickness of the ferromagnetic workpiece 102 is X mm or more, then the widths 314 , depths 316 , and/or widths 318 may approximately equal (e.g., +/−25%) the thickness of the ferromagnetic workpiece 102 . Examples of a lower limit may be in the range of 0 mm to 2 mm. However, this is only an example and not meant to be limiting.

**[p0045]**

Alternatively, when a magnetic coupling device including the pole plate 300 is coupling to ferromagnetic workpieces 102 having different thicknesses, a pole plate 300 having widths 314 , depths 316 , and/or widths 318 that is about an average of the thickness of the ferromagnetic workpieces 102 may be used to reduce the need to change pole plates. Similar to above, however, a lower limit (e.g., 2.0 mm) may be applied such that if the average thickness of the ferromagnetic workpieces 102 is below the lower limit (i.e., &lt;2.0 mm), the widths 314 , depths 316 , and/or widths 318 may be configured to be the lower limit (i.e., 2.0 mm). Referring to FIG. 9 , the recess portions 310 between the projections 306 may have a continuous slope profile (the slope is defined at all points, no sharp corners) at their upper extremes. Curved recess portions 310 may have a higher magnetic flux transfer to a ferromagnetic workpiece 102 than a magnetic coupling device including a pole plate that includes recessed portions with sharp corners. In embodiments, to provide a high magnetic flux transfer, the radius of curvature 324 of the curved recess portions 310 may be approximately ½ the width 318 of the recesses 310 . Test data has indicated an improvement greater than 3% may be obtained by including a slope profile of the recess portions 310 that is ½ the width 318 of the recesses 324 .

**[p0046]**

FIG. 10 is a side view of a portion of another exemplary pole plate 400 which can be used as the pole plate 106 . Similar to pole plates 200 , 300 depicted in FIGS. 6 and 7 , respectively, pole plate 400 includes a plurality of projections 406 arranged on a bottom portion 408 of pole plate 400 . Each of the projections 406 are separated by recess portions 410 . The plurality of projections 406 collectively form a workpiece contact interface 412 of pole plate 400 . Similar to above, varying the widths 414 of the projections 406 and/or the depths 416 , and/or widths 418 of the recesses 410 result in different shallow magnetic fields produced by the same magnetic coupling device 100 . In embodiments, to produce an appropriate shallow magnetic field for a specific ferromagnetic workpiece 102 , the widths 414 of the projections 406 and/or the depths 416 , and/or widths 418 of the recesses 410 could be approximately the same (e.g., +/−25%) as the thickness of the ferromagnetic workpiece 102 . In at least one embodiment, however, there may be a limit for producing a preferred shallow magnetic field for some ferromagnetic workpieces 102 having thicknesses less than the limit. That is, for ferromagnetic workpieces 102 having a thickness less than X mm, a preferred shallow magnetic field may be produced by widths 414 , depths 416 , and/or widths 418 that are at a lower limit of X mm but are not less than the lower limit. That is, to produce a preferred magnetic field for a ferromagnetic workpiece 102 having a thickness of ½*X mm, the widths 414 , depths 416 , and/or widths 418 may be

**[p0046]**

at the lower limit of X mm instead of +/−25% of ½*X mm. If, however, the thickness of the ferromagnetic workpiece 102 is X mm or more, then the widths 414 , depths 416 , and/or widths 418 may approximately equal (e.g., +/−25%) the thickness of the ferromagnetic workpiece 102 . Examples of a lower limit may be in the range of 0 mm to 2 mm. However, this is only an example and not meant to be limiting.

**[p0047]**

Alternatively, when a magnetic coupling device including pole plate 400 is coupling to ferromagnetic workpieces 102 having different thicknesses, a pole plate 400 having widths 414 , depths 416 , and/or widths 418 that is an average of the thickness of the ferromagnetic workpieces 102 may be used to reduce the need to change pole plates. Similar to above, however, a lower limit (e.g., 2.0 mm) may be applied such that if the average thickness of the ferromagnetic workpieces 102 is below the lower limit (i.e., &lt;2.0 mm), the widths 414 , depths 416 , and/or widths 418 may be configured to be the lower limit (i.e., 2.0 mm). In embodiments, pole plate 400 may also include compressible members 420 arranged between projections 406 in the recessed portions 410 . In embodiments, the compressible members 420 compresses when magnetic coupling device 100 including the pole plate 400 couples to a ferromagnetic workpiece 102 . Due to the compression of compressible members 420 , static friction between compressible members 420 and the ferromagnetic workpiece 102 is created that is potentially greater than the static friction between the projections 406 and the ferromagnetic workpiece 102 . As such, a ferromagnetic workpiece 102 coupled to a magnetic coupling device 100 including the pole plate 400 may be less like to rotate and translate than if the ferromagnetic workpiece 102 was coupled to a pole plate that didn&#39;t include the compressible members 420 . In embodiments, compressible members 420 may be comprised of an elastic material such as polymers of isoprene, polyurethane, nit

**[p0047]**

rile rubber and/or the like.

**[p0048]**

FIGS. 11 A- 11 B depict another exemplary pole plate 500 which can be used as the pole plate 106 . Similar to the pole plates 200 , 300 , 400 depicted in FIGS. 7 , 8 , 10 pole plate 500 includes a plurality of projections 502 arranged on a bottom portion 504 of pole plate 500 . Each of projections 502 are separated by recess portions 506 . The plurality of projections 502 collectively form a workpiece contact interface 508 of the pole plate 500 . As illustrated, the workpiece contact interface 508 is non-planar. In embodiments, the non-planar workpiece contact interface 508 may facilitate coupling a magnetic coupling device 100 to a ferromagnetic workpiece having a non-planar surface. For example, a magnetic coupling device 100 including pole plate 500 may be used for coupling magnetic coupling device 100 to one or more types of rods, shafts, etc. (e.g., a cam shaft). While the workpiece contact interface 508 includes a curved surface 510 , the workpiece contact interface 508 may have any other type of non-planar surface. For example, the workpiece contact interface 508 may include a similar contour as a ferromagnetic piece to which the magnetic coupling device including the workpiece contact interfaces 508 is intended to couple.

**[p0049]**

Despite having a non-planar workpiece contact interface 508 , varying the widths 512 of the projections 502 and/or the depths 514 , and/or widths 516 of the recesses 506 result in different shallow magnetic fields produced by the same magnetic coupling device. In embodiments, to produce an appropriate shallow magnetic field for a specific ferromagnetic workpiece 102 , the widths 512 of the projections 552 and/or the depths 514 , and/or widths 516 of the recesses 506 could be approximately the same (e.g., +/−25%) as the thickness of the ferromagnetic workpiece 102 . In at least one embodiment, however, there may be a limit for producing a preferred shallow magnetic field for some ferromagnetic workpieces 102 having thicknesses less than the limit. That is, for ferromagnetic workpieces 102 having a thickness less than X mm, a preferred shallow magnetic field may be produced by widths 512 , depths 514 , and/or widths 516 that are at a lower limit of X mm but are not less than the lower limit. That is, to produce a preferred magnetic field for a ferromagnetic workpiece 102 having a thickness of ½*X mm, the widths 512 , depths 514 , and/or widths 516 may be at the lower limit of X mm instead of +/−25% of ½*X mm. If, however, the thickness of the ferromagnetic workpiece 102 is X mm or more, then the widths 512 , depths 514 , and/or widths 516 may approximately equal (e.g., +/−25%) the thickness of the ferromagnetic workpiece 102 . Examples of a lower limit may be in the range of 0 mm to 2 mm. However, this is only an example and not meant to be limiting.

**[p0050]**

Alternatively, when a magnetic coupling device including pole plate 500 is coupling to ferromagnetic workpieces 102 having different thicknesses, a pole plate 500 having widths 512 , depths 514 , and/or widths 516 that is an average of the thickness of the ferromagnetic workpieces 102 may be used to reduce the need to change pole plates. Similar to above, however, a lower limit (e.g., 2.0 mm) may be applied such that if the average thickness of the ferromagnetic workpieces 102 is below the lower limit (i.e., &lt;2.0 mm), the widths 512 , depths 514 , and/or widths 516 may be configured to be the lower limit (i.e., 2.0 mm). FIGS. 12 A- 12 B depict another exemplary pole plate 550 which can be used as the pole plate 106 . Similar to the pole plates 200 , 300 , 400 , 500 depicted in FIGS. 7 , 8 , 10 , 11 A- 11 B , pole plate 550 includes a plurality of projections 552 arranged on a bottom portion 554 of pole plate 550 . Each of projections 552 are separated by recess portions 556 . The plurality of projections 552 collectively form a workpiece contact interface 558 of the pole plate 550 .

**[p0051]**

As illustrated, the workpiece contact interface 558 is non-planar. In embodiments, the non-planar workpiece contact interface 558 may facilitate coupling a magnetic coupling device 100 to a ferromagnetic workpiece having a non-planar surface. For example, a magnetic coupling device including pole plate 550 may be used for coupling magnetic coupling device 100 to one or more edges, corners, etc. of a ferromagnetic workpiece. While the workpiece contact interface 558 includes two downwardly sloping surfaces 560 extending from a center point 562 , the workpiece contact interface 558 may have any other type of non-planar surface. For example, the workpiece contact interface 558 may include a similar contour as a ferromagnetic piece to which the magnetic coupling device including the workpiece contact interfaces 558 is intended to couple. Despite having a non-planar workpiece contact interface 558 , varying the widths 564 of the projections 552 and/or the depths 566 , and/or widths 568 of the recesses 556 result in different shallow magnetic fields produced by the same magnetic coupling device. In embodiments, to produce an appropriate shallow magnetic field for a specific ferromagnetic workpiece 102 , the widths 564 of the projections 552 and/or the depths 566 , and/or widths 568 of the recesses 556 could be approximately the same (e.g., +/−25%) as the thickness of the ferromagnetic workpiece 102 . In at least one embodiment, however, there may be a limit for producing a preferred shallow magnetic field for some ferromagnetic workpieces 102 having thicknesses less than the limi

**[p0051]**

t. That is, for ferromagnetic workpieces 102 having a thickness less than X mm, a preferred shallow magnetic field may be produced by widths 564 , depths 566 , and/or widths 568 that are at a lower limit of X mm but are not less than the lower limit. That is, to produce a preferred magnetic field for a ferromagnetic workpiece 102 having a thickness of ½*X mm, the widths 564 , depths 566 , and/or widths 568 may be at the lower limit of X mm instead of +/−25% of ½*X mm. If, however, the thickness of the ferromagnetic workpiece 102 is X mm or more, then the widths 564 , depths 566 , and/or widths 568 may approximately equal (e.g., +/−25%) the thickness of the ferromagnetic workpiece 102 . Examples of a lower limit may be in the range of 0 mm to 2 mm. However, this is only an example and not meant to be limiting.

**[p0052]**

Alternatively, when a magnetic coupling device including pole plate 550 is coupling to ferromagnetic workpieces 102 having different thicknesses, a pole plate 550 having widths 564 , depths 566 , and/or widths 568 that is an average of the thickness of the ferromagnetic workpieces 102 may be used to reduce the need to change pole plates. Similar to above, however, a lower limit (e.g., 2.0 mm) may be applied such that if the average thickness of the ferromagnetic workpieces 102 is below the lower limit (i.e., &lt;2.0 mm), the widths 564 , depths 566 , and/or widths 568 may be configured to be the lower limit (i.e., 2.0 mm). FIG. 13 is a side of a portion of an exemplary projection 206 . As illustrated, each projection 206 may itself includes projections 206 ′. The projections 206 ′ may further increase the shallow magnetic field and reduce the far-field magnetic field in comparison to if the projection 206 didn&#39;t include the projections 206 ′. In alternative embodiments, the projection 206 may not include the projections 206 ′.

**[p0053]**

Other characteristics of pole plates are described in U.S. Provisional Patent Application No. 62/623,407, filed Jan. 29, 2018, titled MAGNETIC LIFTING DEVICE HAVING POLE SHOES WITH SPACED APART PROJECTIONS, the entire disclosure of which are herein expressly incorporated by reference. In view of validating the foregoing disclosure of FIGS. 7 - 13 , the following average breakaway forces for varying types of pole plates 106 are provided in the following tables. Thickness Pole Plate 1 - Pole Plate 2 - Pole Plate 3 - of Plate Average Break- Average Break- Average Break- (mm) away Force (kg) away Force (kg) away Force (kg) 0.5 15.20 16.13 17.40 0.8 26.80 26.23 26.47 1 49.07 46.70 43.20 2 68.57 65.17 58.00 3 70.47 68.87 61.93 4 70.47 69.87 67.60 5 70.33 69.83 67.73 Referring to FIG. 14 , an exemplary robotic system 600 is illustrated. While a robotic system 600 is depicted in FIG. 14 , the embodiments described in relation thereto may be applied to other types of machines, (e.g., crane hoists, pick and place machines, robotic fixtures, etc.).

**[p0054]**

Robotic system 600 includes electronic controller 136 . Electronic controller 136 includes additional logic stored in associated memory 142 for execution by processor 140 . A robotic movement module 602 is included which controls the movements of a robotic arm 604 . In the illustrated embodiment, robotic arm 604 includes a first arm segment 606 which is rotatable relative to a base about a vertical axis. First arm segment 606 is moveably coupled to a second arm segment 608 through a first joint 610 whereat second arm segment 608 may be rotated relative to first arm segment 606 in a first direction. Second arm segment 608 is moveably coupled to a third arm segment 611 through a second joint 612 whereat third arm segment 611 may be rotated relative to second arm segment 608 in a second direction. Third arm segment 611 is moveably coupled to a fourth arm segment 614 through a third joint 616 whereat fourth arm segment 614 may be rotated relative to third arm segment 611 in a third direction and a rotary joint 618 whereby an orientation of fourth arm segment 614 relative to third arm segment 611 may be altered. Magnetic coupling device 100 is illustratively shown secured to the end of robotic arm 604 . Magnetic coupling device 100 is used to couple a ferromagnetic workpiece 102 (not shown) to robotic arm 604 .

**[p0055]**

In one embodiment, electronic controller 136 by processor 140 executing robotic movement module 602 moves robotic arm 604 to a first pose whereat magnetic coupling device 100 contacts the ferromagnetic workpiece 102 at a first location. Electronic controller 136 by processor 140 executing control logic 144 instructs magnetic device 100 to transition from a first, off state to a second, on state or a third, on state to couple the ferromagnetic workpiece 102 to robotic system 600 . Electronic controller 136 by processor 140 executing robotic movement module 602 moves the ferromagnetic workpiece 102 from the first location to a second, desired, spaced apart location. Once the ferromagnetic workpiece 102 is at the desired second position, electronic controller 136 by processor 140 executing control logic 144 instructs magnetic coupling device 100 to transition from a second, on state to a first, off state to decouple the ferromagnetic workpiece 102 from robotic system 600 . Electronic controller 136 then repeats the process to couple, move, and decouple another ferromagnetic workpiece 102 .

**[p0056]**

In embodiments, control logic 144 may also determine the presence, absence, or other characteristics of ferromagnetic workpieces 102 in relation to magnetic coupling device 100 . To do so, magnetic coupling device 100 may include one or more magnetic field sensors. Referring to FIG. 15 , a representative top sectional view of magnetic coupling device 100 including magnetic field sensors 702 is illustrated. Magnetic field sensor 702 are positioned as described herein with first magnetic field sensor 702 A being positioned in a left side half 704 of the magnetic coupling device 100 and second magnetic field sensor 702 B being positioned in a right-side half 706 of the magnetic coupling device 100 . Additionally, a third magnetic field sensor 702 C is positioned in a front half 708 of the magnetic coupling device 100 and a fourth magnetic field sensor 702 D is positioned in a rear half 710 of the magnetic coupling device 100 . The front half 708 including a first portion 712 of the left side half 704 and a first portion 714 of the right-side half 706 . The rear half 710 including a second portion 716 of the left side half 704 and a second portion 718 of the right-side half 706 . The addition of the third and fourth magnetic field sensors 702 C, 702 D provides additional sensor values which may be used to determine various operating states of the magnetic coupling device 100 . For example, control logic 144 based on the outputs of the four magnetic field sensors may determine an orientation of the workpiece contact interface 104 relative to the ferromagnetic workpiece 102 in tw

**[p0056]**

o rotational axes, such as left-to-right tilt and front-to-back tilt.

**[p0057]**

Turning then to functional blocks of the control logic 144 . The simplest piece of information required about the magnetic coupling device 100 is that of the switching state of the magnetic coupling device 100 , i.e. is the unit in a first, off state, a second, on state, or a partial on state, such as the third, on state. In the first, off state, the magnetic coupling device 100 has extremely little or even no leakage flux. In the second, on state, even on a near perfect magnetic working circuit with a ferromagnetic workpiece 102 , the magnetic coupling device 100 has considerably more leakage flux than in the first, off state. Therefore, in a calibration process, the reading of one or more of the first magnetic field sensors 702 in the off state of the magnetic coupling device 100 can be stored in a memory 142 (see FIG. 15 ) associated with the processor 140 of the control logic 144 as a calibrated or hard coded value, and when the magnetometer reading rises above this first, off-state value, or some offset above this off-state value, the magnetic coupling device 100 can be considered in the second on state or a partial on state, such as the third, on state. When the magnetometer reading is at or close to the calibration stored value, the magnetic coupling device 100 can be considered in the first, off state. In embodiments, through a calibration process, the reading of one or more of the first magnetic field sensors 702 in a desired partial on state may be stored in memory 142 as a calibrated or hard coded value, and when the magnetometer reading rises to a specific store

**[p0057]**

d reading or within some percentage of the specific stored reading, the magnetic coupling device 100 can be considered to be in the corresponding a partial on state, such as the third, on state. In some embodiments, the magnetic field sensors 702 may be supplemented with one or more positional sensors used to determine a position of magnetic platter 112 to calibrate the magnetic coupling device 100 .

**[p0058]**

Another functional block of the control logic 144 may be used to determine if there is a ferromagnetic workpiece 102 underneath only the left side half 704 , only the right-side half 706 or underneath both the left side half 704 and the right-side half 706 when the magnetic coupling device 100 is in an on state. When no target part is present for the magnetic coupling device 100 to magnetically attach to (see FIG. 16 ), there is no ‘true’ (i.e. external working) magnetic circuit through pole plate 106 (see FIG. 1 B ). Assuming that any workpiece 102 is sufficiently spaced apart from the pole plate 106 so as to not distort the magnetic field, the flux would extend through air between the pole portions 116 (of FIG. 1 B ), effectively representing leakage flux. This also causes a high leakage flux to be present at the magnetic field sensors 702 . By storing this “max leakage flux” for a given second, on state or partial on state, such as the third, on state, in memory 142 associated with the processor 140 of the control logic 144 , either hard coded (given that this value would be invariable), or from a calibration run, in normal operation of the magnetic coupling device 100 it is possible to determine if there is a ferromagnetic workpiece 102 present or not, by placing the magnetic coupling device 100 in the second, on state or partial on state, such as the third, on state corresponding to the stored “max leakage flux” reference value and comparing a current sensor output with the stored “max leakage flux” reference value for the on state or the partial on state.

**[p0059]**

In addition to detecting a presence or absence of workpiece 102 , logic control logic 144 may also provide an indication of a spacing of the workpiece contact interface 104 from the workpiece 102 when the presence of a ferromagnetic workpiece 102 is detected (the current sensor value is below the stored “max leakage flux” for presence detection). In embodiments, control logic 144 , is configured to determine if the workpiece contact interface 104 is proximate to the ferromagnetic workpiece 102 . In one example, control logic 144 determines if the workpiece contact interface 104 is proximate to workpiece 102 when the current value for the corresponding sensor 702 falls below a threshold value. The threshold value may be determined and stored in memory 142 during a calibration run and may correspond to a known spacing between the workpiece contact interface 104 and the workpiece 102 (see FIG. 17 ). In one embodiment, a plurality of threshold values is stored on memory 142 , each corresponding to a respective known spacing. The plurality of stored threshold values permits control logic 144 to provide better approximation of the spacing between the workpiece contact interface 104 and the workpiece 102 and to distinguish between a first spacing (see FIG. 17 ) and a second, smaller spacing (see FIG. 18 ). An advantage, among others is that the ability to accurately determine proximity of a workpiece allows a robotic system 600 (see FIG. 14 ) to move at a higher speed until magnetic coupling unit 100 is within a first spacing from workpiece 102 and thereafter move at a slower spee

**[p0059]**

d until contact is made with workpiece 102 . In embodiments, for the various calibrations runs and values discussed herein, separate calibrations runs or values are performed for different types of ferromagnetic materials due to fact that target sensor readings may differ based on the respective size, shape, material, etc. of the target ferromagnetic workpiece.

**[p0060]**

In embodiments, control logic 144 is configured to determine an orientation of the first workpiece contact interface 104 and the second workpiece contact interface 104 relative to the ferromagnetic workpiece 102 . In one example, the orientation of the left side half 704 of the workpiece contact interface 104 and the right-side half 706 of the workpiece contact interface 104 relative to the ferromagnetic workpiece 102 is determined by a comparison of an output of the first magnetic field sensor 702 A and an output of the second magnetic field sensor 702 B. A first spacing between the left side half 704 of the workpiece contact interface 104 and the ferromagnetic workpiece 102 and a second spacing between the right side half 706 of the workpiece contact interface 104 and the ferromagnetic workpiece 102 are determined by control logic 144 to be generally equal when the output of the first magnetic field sensor 702 A and the output of the second magnetic field sensor 702 B satisfy a first criteria. In one example, the first criteria is that the output of the first magnetic field sensor 702 A is within a threshold amount of the output of the second magnetic field sensor 702 B. An example threshold amount is an absolute difference. In another example, the threshold amount is a percentage difference. When the first criteria is satisfied, the left side half 704 and the right-side half 706 of the workpiece contact interface 104 have generally equal spacing relative to the workpiece 102 (see FIG. 18 ). When the first criteria is not satisfied, the left side half 704 and the right-si

**[p0060]**

de half 706 of the workpiece contact interface 104 are angled relative to the workpiece 102 (see FIG. 19 ). If a third and fourth magnetic field sensor are incorporated, such as shown in FIG. 15 , an angle about a pitch axis (see FIG. 20 ) may also be determined in addition to the angle about the roll axis depicted in FIG. 19 . Additionally, or alternatively, the incorporation of a three-dimensional magnetic flux sensor may determine an angle about a pitch axis (see FIG. 20 ) and/or an angle about the roll axis depicted in FIG. 19 .

**[p0061]**

In addition to these device status and workpiece detection capabilities, the presence and specific location of at least two magnetic field sensors 702 in the specified location on the pole plate 106 , provides more advanced feedback. This is because situation-dependent, potentially uneven distribution of leakage flux around the individual pole portions 116 of the pole plate 106 can be sampled, compared and evaluated. In embodiments, in the second, on state (equally applicable to a known partial on state) of the magnetic coupling device 100 , if the left side half 704 of the workpiece contact interface 104 of the pole plate 106 has good contact with a ferromagnetic workpiece 102 , but the right side half 706 of the workpiece contact interface 104 has poor contact with the workpiece 102 (see FIG. 21 ), there will be more leakage flux on the right side half 706 than the left side half 704 . The first magnetic field sensor 702 A above the left side half 704 and the second magnetic field sensor 702 B above the right-side half 706 are able to detect this condition, and the sensor 702 B above the right-side half 706 will return a higher reading than the sensor 702 A above the left side half 704 . In one example, bidirectional Hall Effect sensors are used for sensors 702 . Therefore, by reading each sensor 702 separately and comparing the readings between them, control logic 144 is able to determine that the right-side half 706 has poor contact on the workpiece 102 . In embodiments, the control logic 144 has a functional block to perform such evaluation, implementable in hardware a

**[p0061]**

nd microprocessor software. In one example, control logic 144 determines the right-side half 706 has poor contact when a difference in the readings of the sensor 702 A and the sensor 702 B exceed a stored threshold amount. In another example, the control logic 144 determines the right-side half 706 has poor contact when a difference in the readings of the sensor 702 B and a known, stored value is less than a threshold, where the known stored value may be determined during calibration of the magnetic coupling device 100 .

**[p0062]**

In embodiments, control logic 144 is configured to determine if a placement of the left side half 704 of the workpiece contact interface 104 and the right-side half 706 of the workpiece contact interface 104 relative to the ferromagnetic workpiece 102 are within a target zone 802 on the ferromagnetic workpiece 102 (see FIGS. 22 - 24 ). In one example, the placement of the left side half 704 of the workpiece contact interface 104 and the right side half 706 of the workpiece contact interface 104 relative to the ferromagnetic workpiece 102 are determined by control logic 144 to be within the target zone 802 ( FIGS. 22 - 24 ) of the ferromagnetic workpiece 102 when both an output of the first magnetic field sensor 702 A satisfies a first criteria and an output of the second magnetic field sensor 702 B satisfies a second criteria. An exemplary first criterion is that the output of the first magnetic field sensor 702 A is within a first range of magnetic flux values and an exemplary second criterion is the output of the second magnetic field sensor 702 B is within a second range of magnetic flux values.

**[p0063]**

Referring to FIGS. 22 - 24 , target zone 802 is illustrated. Workpiece 102 is illustrated as a sheet of material having a right end 804 and a left end 806 . Target zone 802 is the portion of workpiece 102 between a first offset 808 from the right end 804 of workpiece 102 and a second offset 810 from the left end 806 of workpiece 102 . In one example, as magnetic coupling device 100 approaches and/or exceeds second offset 810 , the leakage flux associated with the left side half 704 of the workpiece contact interface 104 is higher than the leakage flux associated with the right side half 706 of the workpiece contact interface 104 due to the left side half 704 of the workpiece contact interface 104 approaching left end 806 of workpiece 102 . In similar fashion, as device 100 approaches and/or exceeds first offset 808 , the leakage flux associated with the ride side half 706 of the workpiece contact interface 104 is higher than the leakage flux associated with the left side half 704 of the workpiece contact interface 104 due to the right side half 706 of the workpiece contact interface 104 approaching right end 804 of workpiece 102 . Although shown as a linear target zone 802 , a two-dimensional target zone 802 may be defined for a length and a width of ferromagnetic workpiece 102 . In one example a calibration run is executed wherein device 100 is placed at each of first limit 808 (see FIG. 24 ) and second limit 810 (see FIG. 23 ) and the corresponding leakage flux values for the magnetic flux sensors 702 A, 702 B at both limits are stored in memory 142 . The two leakage flux

**[p0063]**

values stored for the first limit position (see FIG. 24 ) are stored in memory 142 as “Limiting Position 1” (two values, one for each sensor 702 A, 702 B). The two leakage flux values stored for the second limit position (see FIG. 23 ) are stored in memory 142 as “Limiting Position 2” (two values, one for each sensor 702 A, 702 B). In embodiments, the first range of the first criteria are the values between and including Limiting Position 1 and Limiting Position 2 for one of the magnetic field sensors 702 A, 702 B and the second range of the second criteria are the values between and including Limiting Position 1 and Limiting Position 2 for the other of the magnetic field sensors 702 A, 702 B. Assuming the first range of values correspond to the left side half 704 of the workpiece contact interface 104 and the second range of values correspond to the right side half 706 of the workpiece contact interface 104 , control logic 144 determines that a left end of the magnetic coupling device 100 is positioned outside of the target zone 802 when the second criteria is satisfied and the first criteria is not satisfied and likewise that a right end of the magnetic coupling device 100 is positioned outside of the target zone 802 when the first criteria is satisfied and the second criteria is not satisfied.

**[p0064]**

In embodiments, using (storing) ‘Limiting Position 1’ and Limiting Position 2’ calibrated values on memory 142 allows a device user to calibrate the ferromagnetic workpiece 102 present signal to only come on when a specific magnetic work circuit is formed (if calibrated as the same position) or within a range of magnetic working circuits (if calibrated as 2 different positions). The left side half 704 and the right-side half 706 of the workpiece contact interface 104 can either be the equivalent of the “max leakage” position of Limiting Position ½ or it can be outside of that in a greater leakage position. These calibrations are what allow for so called double blank detection (DBD) and part specific or range specific confirmation. The freedom for the left side half 704 and the right-side half 706 of the workpiece contact interface 104 to be outside of the limiting positions is intended to give the user more freedom, especially if they are landing near edges on thinner steel sheets.

**[p0065]**

In embodiments, it is also possible to use this multisensory approach to provide additional device status data. In the above situation, beyond just comparing the two sensor readings to determine a general state of the magnetic coupling device 100 and the presence or absence of a ferromagnetic workpiece 104 in proximity of the workpiece contact interface 104 , by taking more differentiated and precise magnetic field measurements from each sensor 702 when in closer proximity to the ferromagnetic workpiece 102 (i.e. presence already detected, but proximity not yet quantified) and performing calculations on the value of each sensor&#39;s 702 signal and the value of the difference between the magnetometer readings, one can determine the orientation of the magnetic coupling device 100 relative to the ferromagnetic workpiece 102 , such as what angle a magnet gripper including the device 100 is sitting relative to a flat ferromagnetic workpiece 102 . Taking this even further, using calibration runs of magnetic coupling device 100 with respect to a predefined ferromagnetic workpiece 102 having known parameters (size, shape, material, etc.) and by storing into memory 142 of the evaluation circuit data obtained from processing of sensor 702 output signals during the various calibration runs, it is possible to completely determine the orientation and distance to a ferromagnetic workpiece 102 target surface relative to the magnetic coupling device 100 position, even before the workpiece contact interface 104 contacts the ferromagnetic workpiece 102 , in particular if additional magnetic

**[p0065]**

field sensors are placed in locations other than the ones previously specified, such as shown in FIG. 15 . As the magnetic coupling device 100 emits leakage flux in any state, even the off state, very sensitive sensors can respond to small variations in the leakage flux emanating from the pole plate 106 at the sensor detection surfaces in the off state. When a magnetic coupling device 100 in the off state or a known partial on state approaches a ferromagnetic workpiece 102 , then, adequately sensitive magnetometers can indicate proximity to component, and can deliver signals which are converted into control signals for the robotic arm 600 in acting as a sort of “vision” for an otherwise blind robot. As another example, adequately sensitive magnetometers can assist a robotic arm 600 that can only determine its two-dimensional position by determining a distance between the magnetic coupling device 100 and the ferromagnetic workpiece 102 (e.g., a depth between the two). Therefore, the robotic arm 600 may be programmed to decelerate (e.g., linearly or non-linearly) as the magnetic coupling device 100 approaches the ferromagnetic workpiece 102 to avoid a collision.

**[p0066]**

For example, assuming that a total of four magnetometers are present, one at the flux detection surface of the left half side 704 of the workpiece contact interface 104 and one at the flux detection surface of the right half side 706 of the workpiece contact interface 104 , as previously noted, and two additional sensors at other locations, such as shown in FIG. 15 , when moving the magnetic coupling device 100 towards the ferromagnetic workpiece 102 with one of the sensors 702 moving closer (in absolute terms) than the others, leakage flux lines near that sensor 702 would increase in density, focusing themselves toward the ferromagnetic workpiece 102 . In bringing the magnetic coupling device 100 even closer to the ferromagnetic workpiece 102 (without changing spatial attitude and translational direction of the magnetic coupling device 100 coupled to the end of the arm of the robot 600 , the flux lines would redistribute more intensely across the magnetic coupling device 100 , with the density of flux lines on the nearest sensor 702 being inversely proportional to the distance between the sensor 702 and the ferromagnetic workpiece 102 . This produces an even higher reading in the magnetometer over the close-proximity sensor 702 . By comparing the close proximity magnetometer output to the signal output from the other 3 magnetometers, and by evaluating the data one can tell where and how close the ferromagnetic workpiece 102 is to the working faces of the magnetic coupling device 100 , given the known spatial relationships between the sensors 702 and the working face of the

**[p0066]**

workpiece contact interface 104 . As another example, one or more three-dimensional magnetometers could be used to determine how close the ferromagnetic workpiece 102 is to the working faces of the magnetic coupling device 100 .

**[p0067]**

In performing accurate calculations on the outputs of the magnetometers of the magnetic coupling device 100 , other functionalities can be enabled when the magnetic flux source is switched on and contact is established with the ferromagnetic workpiece 102 . There is a direct relationship between the amount of magnetic flux in a working magnetic circuit, and the amount of physical force that the working magnetic circuit can withstand, which in the case of a magnetic coupling device 100 corresponds to the device&#39;s 100 payload. As the leakage flux from a permanent magnet depends on how much of the magnetic flux is ‘consumed’ (i.e. bound) in the primary working circuit, there is a correlation between the leakage flux and the maximum payload that can be sustained by the magnetic coupling device 100 . The processor 140 of the control logic 144 is programmed, in one embodiment, with the appropriate formulae and calibration runs can be performed such that the combined readings of the magnetometers on the magnetic coupling device 100 can be used to derive a more exact holding force of the magnetic coupling device 100 than with known devices. This could be used as (i) a “safety check,” to make sure that the magnetic coupling device 100 is able to lift the ferromagnetic workpiece 102 before being moved by the robot 600 , (ii) the magnetic coupling device 100 is operating at full capacity, and/or (iii) the magnetic coupling device 100 is operating has not been damaged or degraded. Additionally or alternatively, these methods may be used for part specific detection, and/or detection

**[p0067]**

of a range of thicknesses of ferromagnetic workpieces 102 .

**[p0068]**

In all of these situations, the processor 140 of the control logic 144 is responsible for accepting input from each of the magnetometers 702 of the magnetic coupling device 100 and performing calculations and comparisons. The processor 140 then determines various device states based upon the calculations. In embodiments, device 100 communicates the determined device states and feedback points to a robot controller (e.g., 136 of FIG. 14 ). This is handled by either the 24V I/O or a communications module (not shown). Once the feedback has been communicated to the robot controller 136 , the robot controller 136 is then able to adjust an orientation of device 100 and operation to address challenges or issues in operation. It will be appreciated that the control logic 144 comprises the required components to perform isolation, filtering and amplification of signals provided by the sensors for processing by the on-board processor 140 of the magnetic coupling device 100 .

**[p0069]**

Additional details and embodiments about sensing capabilities and sensor arrangements that may be incorporated into magnetic coupling device 100 are disclosed in PCT Patent Application No. PCT/US18/29786, filed Apr. 27, 2018, titled MAGNETIC COUPLING DEVICE WITH AT LEAST ONE OF A SENSOR ARRANGEMENT AND A DEGAUSS CAPABILITY, the entire disclosure of which are herein expressly incorporated by reference. Various modifications and additions can be made to the exemplary embodiments discussed without departing from the scope of the present invention. For example, while the embodiments described above refer to particular features, the scope of this invention also includes embodiments having different combinations of features and embodiments that do not include all of the described features. Accordingly, the scope of the present invention is intended to embrace all such alternatives, modifications, and variations as fall within the scope of the claims, together with all equivalents thereof.

## Figure captions

- **Figure 1:** FIG. 1 A illustrates a side sectional view of an exemplary magnetic coupling device in an exemplary first, off state positioned on a ferromagnetic workpiece.
- **Figure 1:** FIG. 1 B illustrates a front sectional view of the magnetic coupling device of FIG. 1 A .
- **Figure 1:** FIG. 1 C illustrates a front view of the magnetic coupling device of FIG. 1 A .
- **Figure 2:** FIG. 2 illustrates a front sectional view of the magnetic coupling device of FIGS. 1 A- 1 C in a second, on state.
- **Figure 3:** FIG. 3 illustrates a front sectional view of the magnetic coupling device of FIGS. 1 A- 1 C in a third, on state.
- **Figure 4:** FIG. 4 illustrates an exploded view of the magnetic coupling device of FIGS. 1 A- 1 C .
- **Figure 5:** FIG. 5 illustrates a top sectional view of the magnetic coupling device of FIGS. 1 A- 1 C in a first position on a ferromagnetic workpiece.
- **Figure 6:** FIG. 6 illustrates a top sectional view of the magnetic coupling device of FIGS. 1 A- 1 C in a second position on a ferromagnetic workpiece.
- **Figure 7:** FIGS. 7 - 13 are exemplary portions of pole plates that can be incorporated into the magnetic coupling device of FIGS. 1 A- 1 C .
- **Figure 14:** FIG. 14 illustrates a robotic system including the exemplary magnetic coupling device of FIGS. 1 A- 1 C attached as an end of arm coupler.
- **Figure 15:** FIG. 15 illustrates a top sectional view of an exemplary sensor layout of the magnetic coupling device of FIGS. 1 A- 1 C .
- **Figure 16:** FIG. 16 illustrates a simplified front elevation view of the magnetic coupling device of FIGS. 1 A- 1 C and no ferromagnetic workpiece in the proximity of the magnetic coupling device of FIGS. 1 A- 1 C .
- **Figure 17:** FIG. 17 illustrates a simplified front elevation view of the magnetic coupling device of FIGS. 1 A- 1 C and a ferromagnetic workpiece separated from the magnetic coupling device by a first separation.
- **Figure 18:** FIG. 18 illustrates a simplified front elevation view of the magnetic coupling device of FIGS. 1 A- 1 C and a ferromagnetic workpiece separated from the magnetic coupling device.
- **Figure 19:** FIG. 19 illustrates a simplified front elevation view of the magnetic coupling device of FIGS. 1 A- 1 C being tilted left-to-right relative to a ferromagnetic workpiece.
- **Figure 20:** FIG. 20 illustrates a simplified front elevation view of the magnetic coupling device of FIGS. 1 A- 1 C being tilted front-to-back relative to a ferromagnetic workpiece.
- **Figure 21:** FIG. 21 illustrates a simplified front elevation view of the magnetic coupling device of FIGS. 1 A- 1 C contacting a right edge portion of a ferromagnetic workpiece.
- **Figure 22:** FIG. 22 illustrates a simplified front elevation view of the magnetic coupling device of FIGS. 1 A- 1 C contacting a central portion of a ferromagnetic workpiece.
- **Figure 23:** FIG. 23 illustrates a simplified front elevation view of the magnetic coupling device of FIGS. 1 A- 1 C contacting a ferromagnetic workpiece at a first limit position.
- **Figure 24:** FIG. 24 illustrates a simplified front elevation view of the end of arm magnetic coupling device of FIGS. 1 A- 1 C contacting a ferromagnetic workpiece at a second limit position.
- **Figure 4:** As discussed in more detail below in relation to FIG. 4 , the housing 104 is configured in a manner that allows the magnetic platter 112 and/or the pole plate 106 to be easily removable and replaceable.
- **Figure 7:** As stated above, pole plate 106 may have spaced-apart projections 108 . Referring to FIGS. 7 - 13 are exemplary portions of pole plates 106 and projections 108 that can be incorporated into the magnetic coupling device of FIGS. 1 A- 1 C .
- **Figure 7:** In view of validating the foregoing disclosure of FIGS. 7 - 13 , the following average breakaway forces for varying types of pole plates 106 are provided in the following tables.
- **Figure 14:** Referring to FIG. 14 , an exemplary robotic system 600 is illustrated. While a robotic system 600 is depicted in FIG. 14 , the embodiments described in relation thereto may be applied to other types of machines, (e.g., crane hoists, pick and place machines, robotic fixtures, etc.).

## Classifications

- B23Q3/1546
- B25B11/002
- H01F7/02
- H01F7/0257
- H01F7/0257
- H01F7/04
- B23Q3/154
- B23Q3/1546
- B23Q3/1546
- B23Q3/1546
- B25B11/002
- B25B11/002
- B25J15/0608
- B25J15/0608
- B65G47/92
- B65G47/92
- B66C1/04
- B66C1/04
- B66C1/04
- B66C1/04
- B66C1/04
- B66C1/04
- H01F7/02
- H01F7/0226
- H01F7/0226
- H01F7/0236
- H01F7/0236
- H01F7/0242
- H01F7/0242
- H01F7/0257
- H01F7/0257
- H01F7/0257
- H01F7/04
- H01F7/04

## Cited patent documents

- [CN-104137212-A](https://patents.google.com/patent/CN104137212A/en) — APP
- [CN-201092045-Y](https://patents.google.com/patent/CN201092045Y/en) — APP
- [CN-202713101-U](https://patents.google.com/patent/CN202713101U/en) — APP
- [CN-203781619-U](https://patents.google.com/patent/CN203781619U/en) — APP
- [DE-19852376-A1](https://patents.google.com/patent/DE19852376A1/en) — APP
- [DE-202016008504-U1](https://patents.google.com/patent/DE202016008504U1/en) — APP
- [EP-3100289-A1](https://patents.google.com/patent/EP3100289A1/en) — APP
- [GB-1333490-A](https://patents.google.com/patent/GB1333490A/en) — APP
- [GB-1335741-A](https://patents.google.com/patent/GB1335741A/en) — APP
- [GB-1471025-A](https://patents.google.com/patent/GB1471025A/en) — APP
- [GB-152821-A](https://patents.google.com/patent/GB152821A/en) — APP
- [GB-190828300-A](https://patents.google.com/patent/GB190828300A/en) — APP
- [GB-206130-A](https://patents.google.com/patent/GB206130A/en) — APP
- [GB-2292838-A](https://patents.google.com/patent/GB2292838A/en) — APP
- [GB-2312329-A](https://patents.google.com/patent/GB2312329A/en) — APP
- [GB-519466-A](https://patents.google.com/patent/GB519466A/en) — APP
- [JP-2002520829-A](https://patents.google.com/patent/JP2002520829A/en) — APP
- [JP-2013219364-A](https://patents.google.com/patent/JP2013219364A/en) — APP
- [JP-2017509144-A](https://patents.google.com/patent/JP2017509144A/en) — APP
- [JP-2018503257-A](https://patents.google.com/patent/JP2018503257A/en) — APP
- [JP-2021512489-A](https://patents.google.com/patent/JP2021512489A/en) — APP
- [JP-H0319785-A](https://patents.google.com/patent/JPH0319785A/en) — APP
- [JP-H07171726-A](https://patents.google.com/patent/JPH07171726A/en) — APP
- [JP-H0945523-A](https://patents.google.com/patent/JPH0945523A/en) — APP
- [JP-H112367-A](https://patents.google.com/patent/JPH112367A/en) — APP
- [JP-S5193568-U](https://patents.google.com/patent/JPS5193568U/en) — APP
- [JP-S5837107-U](https://patents.google.com/patent/JPS5837107U/en) — APP
- [JP-S6127205-U](https://patents.google.com/patent/JPS6127205U/en) — APP
- [JP-S6165742-A](https://patents.google.com/patent/JPS6165742A/en) — APP
- [KR-101643538-B1](https://patents.google.com/patent/KR101643538B1/en) — APP
- [KR-20080002782-U](https://patents.google.com/patent/KR20080002782U/en) — APP
- [KR-20160035739-A](https://patents.google.com/patent/KR20160035739A/en) — APP
- [NL-2009798-C2](https://patents.google.com/patent/NL2009798C2/en) — APP
- [US-10532791-B2](https://patents.google.com/patent/US10532791B2/en) — APP
- [US-11772214-B2](https://patents.google.com/patent/US11772214B2/en) — APP
- [US-11780039-B2](https://patents.google.com/patent/US11780039B2/en) — APP
- [US-2005012579-A1](https://patents.google.com/patent/US20050012579A1/en) — APP
- [US-2006232367-A1](https://patents.google.com/patent/US20060232367A1/en) — APP
- [US-2011248806-A1](https://patents.google.com/patent/US20110248806A1/en) — APP
- [US-2012277911-A1](https://patents.google.com/patent/US20120277911A1/en) — APP
- [US-2013154389-A1](https://patents.google.com/patent/US20130154389A1/en) — APP
- [US-2013234817-A1](https://patents.google.com/patent/US20130234817A1/en) — APP
- [US-2014049347-A1](https://patents.google.com/patent/US20140049347A1/en) — APP
- [US-2014265690-A1](https://patents.google.com/patent/US20140265690A1/en) — APP
- [US-2014314507-A1](https://patents.google.com/patent/US20140314507A1/en) — APP
- [US-2014340182-A1](https://patents.google.com/patent/US20140340182A1/en) — APP
- [US-2015115848-A1](https://patents.google.com/patent/US20150115848A1/en) — APP
- [US-2017011831-A1](https://patents.google.com/patent/US20170011831A1/en) — APP
- [US-2017372825-A1](https://patents.google.com/patent/US20170372825A1/en) — SEA
- [US-2021031317-A1](https://patents.google.com/patent/US20210031317A1/en) — APP
- [US-2022001501-A1](https://patents.google.com/patent/US20220001501A1/en) — APP
- [US-2023373043-A1](https://patents.google.com/patent/US20230373043A1/en) — APP
- [US-2024058911-A1](https://patents.google.com/patent/US20240058911A1/en) — APP
- [US-2475456-A](https://patents.google.com/patent/US2475456A/en) — APP
- [US-2915682-A](https://patents.google.com/patent/US2915682A/en) — APP
- [US-3079191-A](https://patents.google.com/patent/US3079191A/en) — SEA
- [US-3121193-A](https://patents.google.com/patent/US3121193A/en) — SEA
- [US-3336551-A](https://patents.google.com/patent/US3336551A/en) — SEA
- [US-3477050-A](https://patents.google.com/patent/US3477050A/en) — SEA
- [US-3488536-A](https://patents.google.com/patent/US3488536A/en) — APP
- [US-3893676-A](https://patents.google.com/patent/US3893676A/en) — APP
- [US-4117793-A](https://patents.google.com/patent/US4117793A/en) — APP
- [US-4166261-A](https://patents.google.com/patent/US4166261A/en) — APP
- [US-4408752-A](https://patents.google.com/patent/US4408752A/en) — SEA
- [US-4468649-A](https://patents.google.com/patent/US4468649A/en) — APP
- [US-4837540-A](https://patents.google.com/patent/US4837540A/en) — APP
- [US-5270678-A](https://patents.google.com/patent/US5270678A/en) — APP
- [US-5500631-A](https://patents.google.com/patent/US5500631A/en) — APP
- [US-5818318-A](https://patents.google.com/patent/US5818318A/en) — SEA
- [US-5993365-A](https://patents.google.com/patent/US5993365A/en) — APP
- [US-6231349-B1](https://patents.google.com/patent/US6231349B1/en) — APP
- [US-6538544-B1](https://patents.google.com/patent/US6538544B1/en) — SEA
- [US-7952455-B2](https://patents.google.com/patent/US7952455B2/en) — SEA
- [US-8368494-B2](https://patents.google.com/patent/US8368494B2/en) — SEA
- [US-8892258-B2](https://patents.google.com/patent/US8892258B2/en) — APP
- [US-8917154-B2](https://patents.google.com/patent/US8917154B2/en) — APP
- [US-9324487-B1](https://patents.google.com/patent/US9324487B1/en) — APP
- [US-9601955-B2](https://patents.google.com/patent/US9601955B2/en) — APP
- [US-9613738-B2](https://patents.google.com/patent/US9613738B2/en) — SEA
- [US-9761396-B2](https://patents.google.com/patent/US9761396B2/en) — SEA
- [WO-2012160262-A1](https://patents.google.com/patent/WO2012160262A1/en) — APP
- [WO-2015114220-A1](https://patents.google.com/patent/WO2015114220A1/en) — APP
- [WO-2016005024-A1](https://patents.google.com/patent/WO2016005024A1/en) — APP
- [WO-9607610-A1](https://patents.google.com/patent/WO9607610A1/en) — APP

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
