# 02. Polschuh für einen Magnetgreifer und Magnetgreifer mit Polschuh

- **Archive rank:** 2 of 50
- **Publication:** [DE-102024105114-A1](https://patents.google.com/patent/DE102024105114A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/096659096/publication/DE102024105114A1?q=pn%3DDE102024105114A1)
- **Publication date:** 2025-08-28
- **Filing date:** 2024-02-23
- **Earliest priority:** 2024-02-23
- **Family:** 96659096
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** SCHMALZ J GMBH
- **Inventors:** CLAUSS JOHANNES; EBERHARDT TOBIAS; NÜBEL MICHAEL; POJTINGER MICHAEL; SCHAAF WALTER; STORZ MICHAEL

## Abstract

Polschuh (26, 28) zum Führen eines Magnetfeldanteils eines Magnetgreifers (10) zu einem ferromagnetischen Werkstück (52) für das Greifen des ferromagnetischen Werkstücks (52) mittels des Magnetgreifers (10). Der Polschuh (26, 28) weist auf: eine Befestigungs-Einrichtung (30, 32) zum Befestigen des Polschuhs (26, 28) an einem Gehäuse (12) des Magnetgreifers (10), eine Wirkstruktur (34, 36) zur Magnetfeldlenkung, und eine Werkstück-Kontaktfläche (38, 40) zum Kontaktieren des ferromagnetischen Werkstücks (52). Die Werkstück-Kontaktfläche (38, 40) ist als eine zusammenhängende Fläche ausgebildet.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops000.png)

![Sketch 1 for DE-102024105114-A1](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops001.png)

![Sketch 2 for DE-102024105114-A1](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops002.png)

![Sketch 3 for DE-102024105114-A1](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops003.png)

![Sketch 4 for DE-102024105114-A1](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops004.png)

![Sketch 5 for DE-102024105114-A1](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops005.png)

![Sketch 6 for DE-102024105114-A1](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops006.png)

![Sketch 7 for DE-102024105114-A1](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops007.png)

![Sketch 8 for DE-102024105114-A1](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops008.png)

![Sketch 9 for DE-102024105114-A1](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops009.png)

![Sketch 10 for DE-102024105114-A1](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops009.png)

[Sketch 11](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops010.png)

![Sketch 11 for DE-102024105114-A1](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops010.png)

[Sketch 12](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops011.png)

![Sketch 12 for DE-102024105114-A1](https://nimo.iptorch.com/refdrawing/DE-102024105114-A1/ops011.png)

## Claims

### Claim 1 (independent)

Claims (15)

### Claim 2 (independent)

Translated from German

### Claim 3 (independent)

Polschuh (26, 28) fÃ¼r einen Magnetgreifer (10) zum FÃ¼hren eines Magnetfeldanteils des Magnetgreifers (10) zu einem ferromagnetischen WerkstÃ¼ck (52) fÃ¼r das Greifen des ferromagnetischen WerkstÃ¼cks (52), aufweisend:

### Claim 4 (independent)

- eine Befestigungs-Einrichtung (30, 32) zum Befestigen des Polschuhs (26, 28) an einem GehÃ¤use (12) des Magnetgreifers (10),

### Claim 5 (independent)

- eine Wirkstruktur (34, 36) zur Magnetfeldlenkung, und

### Claim 6 (independent)

- eine WerkstÃ¼ck-KontaktflÃ¤che (38, 40), welche dazu ausgebildet ist, beim Greifen des ferromagnetischen WerkstÃ¼cks (52) an dem ferromagnetischen WerkstÃ¼ck (52) anzuliegen,

### Claim 7 (independent)

- wobei die WerkstÃ¼ck-KontaktflÃ¤che (38, 40) als eine zusammenhÃ¤ngende FlÃ¤che ausgebildet ist.Pole shoe (26, 28) for a magnetic gripper (10) for guiding a magnetic field component of the magnetic gripper (10) to a ferromagnetic workpiece (52) for gripping the ferromagnetic workpiece (52), comprising:

### Claim 8 (independent)

- a fastening device (30, 32) for fastening the pole shoe (26, 28) to a housing (12) of the magnetic gripper (10),

### Claim 9 (independent)

- an active structure (34, 36) for magnetic field steering, and

### Claim 10 (independent)

- a workpiece contact surface (38, 40) which is designed to bear against the ferromagnetic workpiece (52) when gripping the ferromagnetic workpiece (52),

### Claim 11 (independent)

- wherein the workpiece contact surface (38, 40) is designed as a continuous surface.

### Claim 12

Polschuh (26, 28) nach Anspruch 1,

### Claim 13

- wobei die Wirkstruktur (34, 36) derart ausgebildet ist, dass sich eine QuerschnittsflÃ¤che des Polschuhs (26, 28) ausgehend von der WerkstÃ¼ck-KontaktflÃ¤che (38, 40) in Richtung der Befestigungs-Einrichtung (30, 32) vergrÃ¶Ãert.Pole shoe (26, 28) after Claim 1 , - wherein the active structure (34, 36) is designed such that a cross-sectional area of the pole shoe (26, 28) increases starting from the workpiece contact surface (38, 40) in the direction of the fastening device (30, 32).

### Claim 14

Polschuh (26, 28) nach Anspruch 2,

### Claim 15

- wobei die QuerschnittsflÃ¤che sich stetig oder unstetig vergrÃ¶Ãert.Pole shoe (26, 28) after Claim 2 , - where the cross-sectional area increases continuously or discontinuously.

### Claim 16

Polschuh (26, 28) nach Anspruch 2 oder 3,

### Claim 17

- wobei die Wirkstruktur (34, 36) eine stufenartige Ausbildung aufweist.Pole shoe (26, 28) after Claim 2 or 3 , - wherein the active structure (34, 36) has a step-like design.

### Claim 18

Polschuh (26, 28) nach Anspruch 2 oder 3,

### Claim 19

- wobei die Wirkstruktur (34, 36) eine ebene Ausbildung aufweist.Pole shoe (26, 28) after Claim 2 or 3 , - wherein the active structure (34, 36) has a flat design.

### Claim 20

Polschuh (26, 28) nach einem der voranstehenden AnsprÃ¼che,

### Claim 21 (independent)

- wobei die Wirkstruktur (34, 36) eine Anzahl von Ausnehmungen (58) aufweist,

### Claim 22

- wobei jede Ausnehmung (58) eine LÃ¤ngsachse (60) aufweist, entlang der sich die Ausnehmung (58) erstreckt.Pole piece (26, 28) according to one of the preceding claims,

### Claim 23 (independent)

- wherein the active structure (34, 36) has a number of recesses (58),

### Claim 24 (independent)

- wherein each recess (58) has a longitudinal axis (60) along which the recess (58) extends.

### Claim 25

Polschuh (26, 28) nach Anspruch 6,

### Claim 26

- wobei die LÃ¤ngsachsen (60) der Ausnehmungen (58) orthogonal oder parallel zu der WerkstÃ¼ck-KontaktflÃ¤che (38, 40) ausgerichtet sind.Pole shoe (26, 28) after Claim 6 , - wherein the longitudinal axes (60) of the recesses (58) are aligned orthogonally or parallel to the workpiece contact surface (38, 40).

### Claim 27

Polschuh (26, 28) nach Anspruch 6 oder 7,

### Claim 28 (independent)

- wobei mindestens eine Ausnehmung (58) einen kreisfÃ¶rmigen Querschnitt aufweist, und/oder

### Claim 29

- wobei mindestens eine Ausnehmung (58) einen rechteckfÃ¶rmigen Querschnitt aufweist.Pole shoe (26, 28) after Claim 6 or 7 , - wherein at least one recess (58) has a circular cross-section, and/or - wherein at least one recess (58) has a rectangular cross-section.

### Claim 30

Polschuh (26, 28) nach einem der voranstehenden AnsprÃ¼che 6 bis 8,

### Claim 31

- wobei jede Ausnehmung (58) als ein Loch ausgebildet ist, das sich von einer der WerkstÃ¼ck-KontaktflÃ¤che (38, 40) entgegengesetzten Seite des Polschuhs auf die WerkstÃ¼ck-KontaktflÃ¤che (38, 40) zu erstreckt.Pole shoe (26, 28) according to one of the preceding Claims 6 until 8 , - wherein each recess (58) is formed as a hole extending from a side of the pole piece opposite the workpiece contact surface (38, 40) towards the workpiece contact surface (38, 40).

### Claim 32

Polschuh (26, 28) nach einem der voranstehenden AnsprÃ¼che 6 bis 8,

### Claim 33

- wobei jede Ausnehmung (58) als ein Loch ausgebildet ist, die den Polschuh (26, 28) von einer Seite des Polschuhs (26, 28) bis zu einer der Seite entgegengesetzten weiteren Seite des Polschuhs (26, 28) durchdringt.Pole shoe (26, 28) according to one of the preceding Claims 6 until 8 , - wherein each recess (58) is formed as a hole which penetrates the pole shoe (26, 28) from one side of the pole shoe (26, 28) to a further side of the pole shoe (26, 28) opposite the side.

### Claim 34

Polschuh (26, 28) nach einem der voranstehenden AnsprÃ¼che,

### Claim 35

- wobei ein Abstand zwischen der Wirkstruktur (34, 36) und der WerkstÃ¼ck-KontaktflÃ¤che (38, 40) geringer ist als ein Abstand zwischen der Wirkstruktur (34, 36) und der Befestigungs-Einrichtung (30, 32).Pole shoe (26, 28) according to one of the preceding claims,

### Claim 36 (independent)

- wherein a distance between the active structure (34, 36) and the workpiece contact surface (38, 40) is less than a distance between the active structure (34, 36) and the fastening device (30, 32).

### Claim 37

Polschuh (26, 28) nach einem der voranstehenden AnsprÃ¼che,

### Claim 38

- wobei die Wirkstruktur (34, 36) eine Abfolge von Erhebungen (118) und/oder Aussparungen (120) aufweist.Pole shoe (26, 28) according to one of the preceding claims,

### Claim 39 (independent)

- wherein the active structure (34, 36) has a sequence of elevations (118) and/or recesses (120).

### Claim 40

Polschuh (26, 28) nach einem der voranstehenden AnsprÃ¼che 12,

### Claim 41

- wobei die Aussparungen (120) den Polschuh (26, 28) durchdringen.Pole shoe (26, 28) according to one of the preceding Claims 12 , - wherein the recesses (120) penetrate the pole piece (26, 28).

### Claim 42 (independent)

Magnetgreifer (10) fÃ¼r eine Handhabungsvorrichtung zum Greifen eines ferromagnetischen WerkstÃ¼cks (52), aufweisend:

### Claim 43 (independent)

- ein GehÃ¤use (12),

### Claim 44 (independent)

- einen Magneten (16), der in dem GehÃ¤use (12) angeordnet ist und der zwischen einem Greifzustand zum Greifen des ferromagnetischen WerkstÃ¼cks (52) und einem Freigabezustand zum Freigeben des ferromagnetischen WerkstÃ¼cks (52) Ã¼berfÃ¼hrbar ist,

### Claim 45

- einen ersten Polschuh (26) nach einem der voranstehenden AnsprÃ¼che, und

### Claim 46

- einen zweiten Polschuh (28) nach einem der voranstehenden AnsprÃ¼che,

### Claim 47 (independent)

- wobei der erste Polschuh (26) und der zweite Polschuh (28) an dem GehÃ¤use (12) befestigt sind,

### Claim 48 (independent)

- wobei die WerkstÃ¼ck-KontaktflÃ¤che (38) des ersten Polschuhs (26) und die WerkstÃ¼ck-KontaktflÃ¤che (40) des zweiten Polschuhs (28) zusammen eine HalteflÃ¤che (42) des Magnetgreifers (10) bilden.A magnetic gripper (10) for a handling device for gripping a ferromagnetic workpiece (52), comprising:

### Claim 49 (independent)

- a housing (12),

### Claim 50 (independent)

- a magnet (16) arranged in the housing (12) and transferable between a gripping state for gripping the ferromagnetic workpiece (52) and a release state for releasing the ferromagnetic workpiece (52),

### Claim 51

- a first pole piece (26) according to one of the preceding claims, and

### Claim 52

- a second pole piece (28) according to one of the preceding claims,

### Claim 53 (independent)

- wherein the first pole piece (26) and the second pole piece (28) are fastened to the housing (12),

### Claim 54 (independent)

- wherein the workpiece contact surface (38) of the first pole piece (26) and the workpiece contact surface (40) of the second pole piece (28) together form a holding surface (42) of the magnetic gripper (10).

### Claim 55

Magnetgreifer (10) nach Anspruch 14,

### Claim 56

- wobei der Magnetgreifer (10) eine Einstellungs-Einrichtung (142) zum Einstellen eines Polschuh-Abstands (144) zwischen dem ersten Polschuh (26) und dem zweiten Polschuh (28) und/oder zum Einstellen eines Magnet-Abstands (146) zwischen dem Magneten (16) und den beiden Polschuhen (26, 28) aufweist.Magnetic gripper (10) according to Claim 14 , - wherein the magnetic gripper (10) has an adjustment device (142) for adjusting a pole shoe distance (144) between the first pole shoe (26) and the second pole shoe (28) and/or for adjusting a magnet distance (146) between the magnet (16) and the two pole shoes (26, 28).

## Full description

**[p0001]**

PERFORMING OPERATIONS; TRANSPORTINGHAND TOOLS; PORTABLE POWER-DRIVEN TOOLS; MANIPULATORSMANIPULATORS; CHAMBERS PROVIDED WITH MANIPULATION DEVICESGripping heads and other end effectorsGripping heads and other end effectors with vacuum or magnetic holding meansGripping heads and other end effectors with vacuum or magnetic holding means with magnetic holding meansELECTRICITYELECTRIC ELEMENTSMAGNETS; INDUCTANCES; TRANSFORMERS; SELECTION OF MATERIALS FOR THEIR MAGNETIC PROPERTIESMagnetsPermanent magnets [PM]Magnetic circuits with PM for power or force generationPM holding devicesLifting, pick-up magnetic objectsELECTRICITYELECTRIC ELEMENTSMAGNETS; INDUCTANCES; TRANSFORMERS; SELECTION OF MATERIALS FOR THEIR MAGNETIC PROPERTIESMagnetsPermanent magnets [PM]Means for releasing the attractive force Description Translated from German Die Erfindung betrifft einen Polschuh fÃ¼r einen Magnetgreifer, sowie einen Magnetgreifer mit einem solchen Polschuh.The invention relates to a pole shoe for a magnetic gripper, as well as a magnetic gripper with such a pole shoe.

**[p0002]**

Typischerweise verfÃ¼gen Magnetgreifer Ã¼ber einen Magneten zum Erzeugen eines Magnetfelds fÃ¼r das Greifen von ferromagnetischen WerkstÃ¼cken. HÃ¤ufig werden Polschuhe fÃ¼r das FÃ¼hren eines Magnetfeldanteils des Magnetfelds zu dem zu greifenden WerkstÃ¼ck eingesetzt.Magnetic grippers typically have a magnet to generate a magnetic field for gripping ferromagnetic workpieces. Pole shoes are often used to guide a portion of the magnetic field to the workpiece to be gripped. Magnetgreifer und zugehÃ¶rige Polschuhe hierfÃ¼r sind z.B. aus der DE 20 2019 005 976 U1 bekannt. Diese Polschuhe weisen jeweils eine Mehrzahl von VorsprÃ¼ngen und Aussparungen auf. Die Mehrzahl von VorsprÃ¼ngen jedes Polschuhs bilden eine gemeinsame WerkstÃ¼ckkontaktflÃ¤che, d.h. der Polschuh liegt zum Greifen eines WerkstÃ¼cks mit mehreren, unzusammenhÃ¤ngenden Bereichen an dem WerkstÃ¼ck an und die WerkstÃ¼ckkontaktflÃ¤che weist insofern mit Unterbrechungen auf. GemÃ¤Ã der DE 20 2019 005 976 U1 kann durch die VorsprÃ¼nge das Magnetfeld in der NÃ¤he der WerkstÃ¼ckkontaktflÃ¤che konzentriert werden, wodurch dÃ¼nne Bleche entstapelt werden kÃ¶nnen.Magnetic grippers and associated pole shoes for this are available, for example, from DE 20 2019 005 976 U1 These pole shoes each have a plurality of projections and recesses. The plurality of projections of each pole shoe form a common workpiece contact surface, ie, the pole shoe is in contact with the workpiece with several unconnected areas to grip a workpiece and the workpiece contact surface therefore has interruptions. According to the DE 20 2019 005 976

**[p0002]**

U1 The projections allow the magnetic field to be concentrated near the workpiece contact surface, allowing thin sheets to be destacked.

**[p0003]**

Der Erfindung liegt als Aufgabe zugrunde, fÃ¼r das Greifen von ferromagnetischen WerkstÃ¼cken mittels eines Magnetgreifers verbesserte Greifeigenschaften bereitzustellen, insbesondere ein sicheres und/oder schonendes Greifen des ferromagnetischen WerkstÃ¼cks ermÃ¶glichen und auch spezielle Greifaufgaben wie das Entstapeln von Blechen zu lÃ¶sen. The object of the invention is to provide improved gripping properties for gripping ferromagnetic workpieces by means of a magnetic gripper, in particular to enable safe and/or gentle gripping of the ferromagnetic workpiece and also to solve special gripping tasks such as unstacking metal sheets. Die Erfindung lÃ¶st diese Aufgabe durch einen Polschuh mit den Merkmalen des Anspruchs 1 und durch einen Magnetgreifer mit den Merkmalen des Anspruchs 14. Vorteilhafte Ausgestaltungen und Weiterbildungen der Erfindung ergeben sich aus den abhÃ¤ngigen AnsprÃ¼chen.The invention solves this problem by a pole piece having the features of claim 1 and by a magnetic gripper having the features of claim 14. Advantageous embodiments and further developments of the invention emerge from the dependent claims.

**[p0004]**

Ein erfindungsgemÃ¤Ãer Polschuh ist zum FÃ¼hren eines Magnetfeldanteils eines Magnetfelds eines Magnetgreifers zu einem ferromagnetischen WerkstÃ¼ck fÃ¼r das Greifen des ferromagnetischen WerkstÃ¼cks mittels des Magnetgreifers geeignet. Der Polschuh ist dazu ausgebildet, bei einem Magnetgreifer zum Einsatz zu kommen, insbesondere indem der Polschuh an einem GehÃ¤use des Magnetgreifers angeordnet derart ist, dass das Magnetfeld des Magnetgreifers durch den Polschuh zu dem zu greifenden WerkstÃ¼ck gefÃ¼hrt/gelenkt wird. Der Polschuh weist eine Befestigungs-Einrichtung, eine Wirkstruktur und eine WerkstÃ¼ck-KontaktflÃ¤che auf. Die Befestigungs-Einrichtung ist zum Befestigen des Polschuhs an dem GehÃ¤use des Magnetgreifers ausgebildet. Die Wirkstruktur ist zur Magnetfeldlenkung ausgebildet, d.h. Lenkung zumindest eines Anteils des Magnetfelds des Magnetgreifers. Insbesondere kann die Wirkstruktur zur ErhÃ¶hung einer Haltekraft des Magnetgreifers und/oder zur Reduzierung einer Tiefenwirkung des Magnetfeldanteils ausgebildet sein. Die WerkstÃ¼ck-KontaktflÃ¤che ist diejenige FlÃ¤che des Polschuhs, die zum Kontaktieren des ferromagnetischen WerkstÃ¼cks ausgebildet. Die WerkstÃ¼ck-KontaktflÃ¤che ist insofern diejenige FlÃ¤che des Polschuhs, die dazu ausgebildet ist, beim Greifen des ferromagnetischen WerkstÃ¼cks (also wenn der Polschuh mit einem entsprechenden Magnetgreifer verbunden ist) an diesem WerkstÃ¼ck anzuliegen.A pole shoe according to the invention is suitable for guiding a magnetic field component of a magnetic gripper's magnetic field to a ferromagnetic workpiece for gr

**[p0004]**

ipping the ferromagnetic workpiece by means of the magnetic gripper. The pole shoe is designed for use in a magnetic gripper, in particular by arranging the pole shoe on a housing of the magnetic gripper in such a way that the magnetic field of the magnetic gripper is guided/directed by the pole shoe to the workpiece to be gripped. The pole shoe has a fastening device, an active structure, and a workpiece contact surface. The fastening device is designed to fasten the pole shoe to the housing of the magnetic gripper. The active structure is designed for magnetic field steering, i.e., steering at least a portion of the magnetic field of the magnetic gripper. In particular, the active structure can be designed to increase the holding force of the magnetic gripper and/or to reduce the depth effect of the magnetic field component. The workpiece contact surface is the surface of the pole shoe designed to contact the ferromagnetic workpiece. The workpiece contact surface is the surface of the pole piece that is designed to rest on the workpiece when gripping the ferromagnetic workpiece (i.e. when the pole piece is connected to a corresponding magnetic gripper).

**[p0005]**

Die WerkstÃ¼ck-KontaktflÃ¤che ist als eine zusammenhÃ¤ngende FlÃ¤che ausgebildet. Insbesondere ist die WerkstÃ¼ck-KontaktflÃ¤che eine unterbrechungsfreie FlÃ¤che. Weiter vorzugsweise ist die WerkstÃ¼ck-KontaktflÃ¤che ohne LÃ¶cher und/oder ohne Ausnehmungen ausgebildet. Die WerkstÃ¼ck-KontaktflÃ¤che kann insbesondere eine einfach zusammenhÃ¤ngende FlÃ¤che sein.The workpiece contact surface is formed as a continuous surface. In particular, the workpiece contact surface is an uninterrupted surface. Further preferably, the workpiece contact surface is formed without holes and/or recesses. The workpiece contact surface can, in particular, be a simply continuous surface. Die WerkstÃ¼ck-KontaktflÃ¤che kann insbesondere nicht zwei voneinander getrennt ausgebildeten FlÃ¤chen und/oder Bereiche aufweisen. Unter Ausbildung der WerkstÃ¼ck-KontaktflÃ¤che als eine zusammenhÃ¤ngende FlÃ¤che kann verstanden werden, dass zwei beliebige Punkte auf der WerkstÃ¼ck-KontaktflÃ¤che durch eine kontinuierliche Kurve, Linie oder Pfad miteinander verbunden werden kÃ¶nnen, ohne dabei die WerkstÃ¼ck-KontaktflÃ¤che zu verlassen. Mit anderen Worten, die kontinuierliche Kurve, Linie oder Pfad kann innerhalb der WerkstÃ¼ck-KontaktflÃ¤che verlaufen.In particular, the workpiece contact surface cannot comprise two separate surfaces and/or regions. The design of the workpiece contact surface as a continuous surface can be understood as meaning that any two points on the workpiece contact surface can be connected by a continuous curve, line, or path without leaving the workpiece contact surface. In other words,

**[p0005]**

the continuous curve, line, or path can run within the workpiece contact surface.

**[p0006]**

Die WerkstÃ¼ck-KontaktflÃ¤che kann eben ausgebildet sein. Dies kann sinnvoll sein, da bei WerkstÃ¼cken mit Ã¼blichen GrÃ¶ÃenverhÃ¤ltnissen der Anlagebereich fÃ¼r den Polschuh oft zumindest nÃ¤herungsweise eben ist. Auch fÃ¼r das Entstapeln eines Stapels aus magnetischen Blechen o.Ã¤. ist eine ebene WerkstÃ¼ck-AnlageflÃ¤che oftmals sinnvoll. Eine unebene, z.B. gewÃ¶lbte, WerkstÃ¼ck-AnlageflÃ¤che kann hingegen dann sinnvoll sein, wenn das WerkstÃ¼ck an einem entsprechen unebenen, z.B. gewÃ¶lbten, Bereich kontaktiert werden soll.The workpiece contact surface can be flat. This can be useful, since for workpieces of typical dimensions, the contact area for the pole piece is often at least approximately flat. A flat workpiece contact surface is also often useful for unstacking a stack of magnetic sheets or similar materials. An uneven, e.g., curved, workpiece contact surface, on the other hand, can be useful if the workpiece is to be contacted in a correspondingly uneven, e.g., curved, area.

**[p0007]**

Da die WerkstÃ¼ck-KontaktflÃ¤che als zusammenhÃ¤ngende FlÃ¤che ausgebildet ist, kann eine Haltekraft, die beim Greifen eines WerkstÃ¼cks auftritt, gleichmÃ¤Ãig auf eine grÃ¶Ãere FlÃ¤che verteilt werden. Dadurch kann eine gleichmÃ¤Ãigere Druckverteilung auf dem WerkstÃ¼ck erreicht werden, wodurch das WerkstÃ¼ck vor Verformungen oder BeschÃ¤digungen besser geschÃ¼tzt wird.Because the workpiece contact surface is designed as a continuous surface, the holding force that occurs when gripping a workpiece can be distributed evenly over a larger area. This allows for a more even pressure distribution on the workpiece, thereby better protecting the workpiece from deformation or damage. Weiter kÃ¶nnen durch die Ausbildung der WerkstÃ¼ck-KontaktflÃ¤che als zusammenhÃ¤ngende FlÃ¤che eine Anzahl von Kanten, die beim Greifen eines WerkstÃ¼cks gegen das WerkstÃ¼ck anliegen, reduziert werden, wodurch die Gefahr einer BeschÃ¤digung des WerkstÃ¼cks reduziert wird. Dies kann fÃ¼r das Entstapeln von beschichteten Blechen besonders vorteilhaft sein, da die zusammenhÃ¤ngende WerkstÃ¼ck-KontaktflÃ¤che das Risiko einer BeschÃ¤digung der Beschichtung durch eine Kante des Polschuhs reduzieren oder ganz verhindern kann. Dadurch kann der Polschuh ein sowohl sicheres als auch schonendes Greifen des WerkstÃ¼cks ermÃ¶glichen.Furthermore, by forming the workpiece contact surface as a continuous This surface reduces the number of edges that come into contact with the workpiece when gripping it, thereby reducing the risk of damage to the workpiece. This can be particularly advantageous for destacking coa

**[p0007]**

ted sheets, as the continuous workpiece contact surface can reduce or completely prevent the risk of damage to the coating caused by an edge of the pole piece. This allows the pole piece to grip the workpiece both safely and gently.

**[p0008]**

Der Polschuh kann aus einem Material gebildet sein, das die Eigenschaft hat, Magnetfelder zu verstÃ¤rken und/oder zu leiten. Der Polschuh kann aus einem ferromagnetischen Material, insbesondere Eisen, Stahl, Nickel oder Kobalt, gebildet sein.The pole piece may be made of a material that has the property of amplifying and/or conducting magnetic fields. The pole piece may be made of a ferromagnetic material, in particular iron, steel, nickel, or cobalt. Der Polschuh ist vorteilhafterweise einteilig ausgebildet. Mehrteilige Ausgestaltungen sind jedoch auch mÃ¶glich, z.B. um die Montage zu vereinfachen.The pole piece is preferably constructed as a single piece. However, multi-piece designs are also possible, e.g., to simplify assembly. Bei einer Ausgestaltung mit mehreren Komponenten des Polschuhs kann der Polschuh ein ferromagnetisches Material und ein nicht-ferromagnetisches Material aufweisen. GrundsÃ¤tzlich kÃ¶nnen die beiden Materialien einstÃ¼ckig miteinander verbunden sein, insbesondere gemeinsam einen monolithischen KÃ¶rper bilden. Es kann aber auch vorteilhaft sein, dass die beiden Materialien lÃ¶sbar miteinander verbunden sind. Beispielsweise kann das nicht-ferromagnetische Material lÃ¶sbar und wiederverbindbar an dem ferromagnetischen Material angebracht sein.In a configuration with multiple pole piece components, the pole piece can comprise a ferromagnetic material and a non-ferromagnetic material. In principle, the two materials can be integrally connected to one another, in particular, together forming a monolithic body. However, it can also be advantageous for th

**[p0008]**

e two materials to be detachably connected to one another. For example, the non-ferromagnetic material can be detachably and reconnectably attached to the ferromagnetic material.

**[p0009]**

Das nicht-ferromagnetische Material kann beispielsweise ein Kunststoff, insbesondere ein Elastomer, sein. Das nicht-ferromagnetische Material kann die WerkstÃ¼ck-KontaktflÃ¤che bilden. Vorteilhafterweise kann mittels des nicht-ferromagnetischen Materials das WerkstÃ¼ck vor einer BeschÃ¤digung, insbesondere vor Kratzer, geschÃ¼tzt werden.The non-ferromagnetic material can be, for example, a plastic, in particular an elastomer. The non-ferromagnetic material can form the workpiece contact surface. Advantageously, the non-ferromagnetic material can protect the workpiece from damage, in particular from scratches. Beispielsweise kann das nicht-ferromagnetische Material als ein DistanzkÃ¶rper ausgebildet sein. Der DistanzkÃ¶rper kann dazu ausgebildet sein, eine Distanz zwischen der WerkstÃ¼ck-KontaktflÃ¤che und dem ferromagnetischen Material, insbesondere zwischen der WerkstÃ¼ck-KontaktflÃ¤che und der Wirkstruktur, festzulegen. Durch das Festlegen der Distanz kann die Tiefenwirkung des Magnetfeldanteils festlegbar sein.For example, the non-ferromagnetic material can be designed as a spacer. The spacer can be designed to define a distance between the workpiece contact surface and the ferromagnetic material, in particular between the workpiece contact surface and the active structure. By defining the distance, the depth effect of the magnetic field component can be determined.

**[p0010]**

Durch eine VerÃ¤nderung der Distanz kann die Tiefenwirkung des Magnetfeldanteils einstellbar sein. Beispielsweise kann eine Mehrzahl von DistanzkÃ¶rpern mit unterschiedlicher Dicke bereitgestellt werden, wobei die Tiefenwirkung des Magnetfelds durch eine Selektion des DistanzkÃ¶rpers, der eine vorgegebene Dicke aufweist, eingestellt wird.By varying the distance, the depth effect of the magnetic field component can be adjusted. For example, a plurality of spacers of different thicknesses can be provided, with the depth effect of the magnetic field being adjusted by selecting the spacer with a predetermined thickness. Der DistanzkÃ¶rper kann als Elastomerstreifen ausgebildet sein. Der Elastomerstreifen kann mit dem ferromagnetischen Material des Polschuhs verbunden sein, beispielsweise mittels einer Klebverbindung. Vorteilhafterweise kÃ¶nnen mittels des Elastomerstreifens hÃ¶here QuerkrÃ¤fte aufgenommen werden, die beispielsweise bei einer Bewegung des Polschuhs und eines gegriffenen WerkstÃ¼cks auftreten kÃ¶nnen. Dadurch kÃ¶nnen hÃ¶here Prozessgeschwindigkeiten und Anlagen-DurchsÃ¤tze erzielt werden.The spacer can be designed as an elastomer strip. The elastomer strip can be bonded to the ferromagnetic material of the pole piece, for example, by means of an adhesive bond. Advantageously, the elastomer strip can absorb higher transverse forces, which can occur, for example, during movement of the pole piece and a gripped workpiece. This allows for higher process speeds and system throughputs.

**[p0011]**

Der Polschuh ist insbesondere dazu vorgesehen und entsprechend ausgestaltet, mit einem Magneten des Magnetgreifers magnetisch gekoppelt zu sein.The pole shoe is particularly intended and designed to be magnetically coupled to a magnet of the magnetic gripper. Unter dem Lenken oder FÃ¼hren des Magnetfeldanteils des Magnetgreifers zu dem ferromagnetischen WerkstÃ¼ck fÃ¼r das Greifen des ferromagnetischen WerkstÃ¼cks mittels des Magnetgreifers kann verstanden werden, dass ein Anteil des Magnetfelds des Magnetgreifers durch und/oder mittels des Polschuhs umgelenkt, umgeformt und/oder bereichsweise konzentriert wird. Insbesondere kann der gefÃ¼hrte Anteil des Magnetfelds ein fÃ¼r das Greifen des WerkstÃ¼cks erforderlicher oder gewÃ¼nschter Anteil des Magnetfelds sein. Der Magnetfeldanteil kann durch den Polschuh gefÃ¼hrt sein, wenn eine Magnetfeldlinie des Magnetfelds innerhalb des Polschuhs verlÃ¤uft und aus der WerkstÃ¼ck-KontaktflÃ¤che austritt.Steering or guiding the magnetic field component of the magnetic gripper toward the ferromagnetic workpiece for gripping the ferromagnetic workpiece by means of the magnetic gripper can be understood as a portion of the magnetic field of the magnetic gripper being deflected, reshaped, and/or concentrated in certain areas by and/or by means of the pole piece. In particular, the guided portion of the magnetic field can be a portion of the magnetic field required or desired for gripping the workpiece. The magnetic field component can be guided by the pole piece if a magnetic field line of the magnetic field runs within the pole piece and

**[p0011]**

exits the workpiece contact surface.

**[p0012]**

Unter dem Greifen des WerkstÃ¼cks kann verstanden werden, dass der von dem Polschuh gefÃ¼hrte Magnetfeldanteil derart in das WerkstÃ¼ck eingekoppelt wird, dass das WerkstÃ¼ck durch den eingekoppelten Magnetfeldanteil eine Magnetkraft erfÃ¤hrt, die das WerkstÃ¼ck gegen den Polschuh drÃ¼ckt. Die Magnetkraft kann dann insbesondere grÃ¶Ãer sein als eine Gewichtskraft des WerkstÃ¼cks. Anders formuliert, das ferromagnetische WerkstÃ¼ck kann mittels des Magnetgreifers gegriffen sein, wenn der mittels des Polschuhs gefÃ¼hrte Magnetfeldanteil das WerkstÃ¼ck gegen die WerkstÃ¼ck-KontaktflÃ¤che drÃ¼ckt oder presst.Gripping the workpiece can be understood as the magnetic field component guided by the pole piece being coupled into the workpiece in such a way that the workpiece experiences a magnetic force due to the coupled magnetic field component, which presses the workpiece against the pole piece. The magnetic force can then be greater than the weight of the workpiece. In other words, the ferromagnetic workpiece can be gripped by the magnetic gripper if the magnetic field component guided by the pole piece presses or forces the workpiece against the workpiece contact surface.

**[p0013]**

Das ferromagnetische WerkstÃ¼ck kann aus Eisen oder Stahl gebildet sein. Das WerkstÃ¼ck kann ein Blech oder Materialtafel sein. Insbesondere kann eine Breite und/oder eine LÃ¤nge des WerkstÃ¼cks mehr als das FÃ¼nffache, insbesondere das zehnfache, einer Dicke des WerkstÃ¼cks betragen. Die Dicke des WerkstÃ¼cks kann beispielsweise ein Betrag in einem Bereich von 0,5 mm (Millimeter) bis 5 cm (Zentimeter), insbesondere 0,5 mm bis 5 mm, aufweisen. Das WerkstÃ¼ck kann eine Beschichtung aufweisen.The ferromagnetic workpiece can be made of iron or steel. The workpiece can be a sheet or a material panel. In particular, a width and/or a length of the workpiece can be more than five times, in particular ten times, the thickness of the workpiece. The thickness of the workpiece can, for example, be in a range from 0.5 mm (millimeters) to 5 cm (centimeters), in particular 0.5 mm to 5 mm. The workpiece may have a coating. Die Befestigungs-Einrichtung kann mindestens ein Durchgangsloch fÃ¼r das Aufnehmen einer Befestigungsschraube zum Herstellen einer Schraubverbindung zwischen den Polschuh und dem GehÃ¤use des Magnetgreifers aufweisen. Das Durchgangsloch kann als Senkbohrung ausgebildet sein. ZusÃ¤tzlich oder alternativ kann die Befestigungs-Einrichtung mindestens ein Gewinde zum Herstellen einer Schraubverbindung zwischen den Polschuh und dem GehÃ¤use des Magnetgreifers aufweisen.The fastening device can have at least one through-hole for receiving a fastening screw to establish a screw connection between the pole piece and the housing of the magnetic gripper. The through-hole can be de

**[p0013]**

signed as a countersunk bore. Additionally or alternatively, the fastening device can have at least one thread for establishing a screw connection between the pole piece and the housing of the magnetic gripper.

**[p0014]**

Die Befestigungs-Einrichtung kann eine Aufnahme zum Aufnehmen einer Schraubensicherung zum Zweck der Sicherung einer Befestigungsschraube, die in der Befestigungs-Einrichtung eingesetzt ist, aufweisen. Die Aufnahme kann als Senkung ausgebildet sein. Die Schraubensicherung kann als O-Ring ausgebildet sein. Wenn der Polschuh an dem Magnetgreifer befestigt ist, kann die Aufnahme der Befestigung-Einrichtung an einer Seite des Polschuhs angeordnet sein, die dem Magneten des Magnetgreifers zugewandt oder abgewandt ist.The fastening device can have a receptacle for receiving a threadlocker for securing a fastening screw inserted into the fastening device. The receptacle can be designed as a countersunk hole. The threadlocker can be designed as an O-ring. If the pole piece is attached to the magnetic gripper, the receptacle for the fastening device can be arranged on a side of the pole piece that faces or faces away from the magnet of the magnetic gripper. Die Wirkstruktur kann durch eine geometrische Gestaltung des Polschuhs zur gezielten Lenkung der magnetischen Feldlinien gebildet sein. Die geometrische Gestaltung kann mindestens eine AbschrÃ¤gung und/oder mindestens eine Abrundung aufweisen. Die geometrische Gestaltung kann durch das Einbringen von AbsÃ¤tzen, Bohrungen, Ausnehmungen und/oder Stufen gebildet sein.The effective structure can be formed by a geometric design of the pole piece for the targeted guidance of the magnetic field lines. The geometric design can have at least one bevel and/or at least one rounded portion. The geometric design can be formed by the introduct

**[p0014]**

ion of shoulders, holes, recesses, and/or steps.

**[p0015]**

Die Wirkstruktur kann durch eine MaterialanhÃ¤ufung und/oder eine Materialreduktion gebildet sein. Die Wirkstruktur kann durch eine geometrische Form und/oder durch eine Mikrostruktur des Polschuhs gebildet sein. Die Wirkstruktur kann beispielsweise eine Anzahl von KanÃ¤len, eine Anzahl von Schlitzen, eine Anzahl von Vertiefungen und/oder eine Anzahl von Erhebungen aufweisen. Die Wirkstruktur kann als eine periodische Struktur ausgebildet sein.The active structure can be formed by a material accumulation and/or a material reduction. The active structure can be formed by a geometric shape and/or by a microstructure of the pole piece. The active structure can, for example, have a number of channels, a number of slots, a number of depressions, and/or a number of elevations. The active structure can be designed as a periodic structure. Die Wirkstruktur kann fÃ¼r das Kontaktieren des WerkstÃ¼cks ungeeignet sein. Die Wirkstruktur kann, insbesondere nur, fÃ¼r die ErhÃ¶hung der Haltekraft des Magnetgreifers und/oder fÃ¼r die Reduzierung der Tiefenwirkung des Magnetfeldanteils ausgebildet sein. Vorzugsweise ist vorgesehen, dass die Wirkstruktur weder die WerkstÃ¼ck-KontaktflÃ¤che bildet noch die WerkstÃ¼ck-KontaktflÃ¤che aufweist.The active structure may be unsuitable for contacting the workpiece. The active structure may, in particular, be designed solely to increase the holding force of the magnetic gripper and/or to reduce the depth effect of the magnetic field component. Preferably, the active structure neither forms the workpiece contact surface nor comprises the workpiece cont

**[p0015]**

act surface.

**[p0016]**

Die Wirkstruktur kann einen Verlauf des Magnetfeldanteils in dem Polschuh beeinflussen. Durch die Wirkstruktur kann der Verlauf des Magnetfeldanteils in eine Richtung gelenkt oder gebÃ¼ndelt werden. Die Wirkstruktur kann dazu ausgebildet sein, den Magnetfeldanteil von dem Magneten des Magnetgreifers zu der WerkstÃ¼ck-KontaktflÃ¤che zu fÃ¼hren.The active structure can influence the path of the magnetic field component in the pole piece. The active structure can direct or focus the path of the magnetic field component in a specific direction. The active structure can be designed to guide the magnetic field component from the magnet of the magnetic gripper to the workpiece contact surface. Die Wirkstruktur kann dazu dienen, den Magnetfeldanteil zu lenken, was insbesondere auch ein (wenigstens bereichsweises) Fokussieren umfassen kann. Durch das Fokussieren des Magnetfeldanteils kann die Haltekraft des Magnetgreifers erhÃ¶ht werden. Durch das Lenken des Magnetfeldanteils kann eine Tiefenwirkung des Magnetfeldanteils auf das WerkstÃ¼ck reduziert werden. Insbesondere kann die Wirkstruktur die Tiefenwirkung des Magnetfeldanteils auf das WerkstÃ¼ck dadurch reduzieren, dass die Wirkstruktur den Magnetfeldanteil derart lenkt, dass ein Abstand der Magnetfeldlinien des Magnetfeldanteils nach einem Austreten des Magnetfeldanteils aus der WerkstÃ¼ck-KontaktflÃ¤che zu der WerkstÃ¼ck-KontaktflÃ¤che geringer ist als ein Abstand der Magnetfeldlinien des Magnetfeldanteils nach dem Austreten aus der WerkstÃ¼ck-KontaktflÃ¤che zu der WerkstÃ¼ck-KontaktflÃ¤che ohne Wirkstruktur.The active structu

**[p0016]**

re can serve to direct the magnetic field component, which can in particular also comprise (at least regional) focusing. By focusing the magnetic field component, the holding force of the magnetic gripper can be increased. By directing the magnetic field component, a depth effect of the magnetic field component on the workpiece can be reduced. In particular, the active structure can reduce the depth effect of the magnetic field component on the workpiece by directing the magnetic field component in such a way that a distance of the magnetic field lines of the magnetic field component after the magnetic field component emerges from the workpiece contact surface to the workpiece contact surface is smaller than a distance of the magnetic field lines of the magnetic field component after it emerges from the workpiece contact surface to the workpiece contact surface without the active structure.

**[p0017]**

Die Wirkstruktur, insbesondere eine Ausrichtung der Wirkstruktur, kann dazu ausgebildet sein, eine Ausrichtung und/oder ein Fluss des Magnetfeldanteils fÃ¼r das Greifen des WerkstÃ¼cks zu optimieren.The active structure, in particular an orientation of the active structure, can be designed to optimize an orientation and/or a flow of the magnetic field component for gripping the workpiece. Die Wirkstruktur kann zwischen der Befestigungs-Einrichtung und der WerkstÃ¼ck-KontaktflÃ¤che angeordnet sein.The active structure can be arranged between the fastening device and the workpiece contact surface. Die Wirkstruktur kann sich in Richtung zu der WerkstÃ¼ck-KontaktflÃ¤che erstrecken. Insbesondere kann sich die Wirkstruktur von einem der WerkstÃ¼ck-KontaktflÃ¤che entgegengesetzten Ende oder Seite des Polschuhs bis zu der WerkstÃ¼ck-KontaktflÃ¤che erstrecken. Alternativ kann sich die Wirkstruktur von der Befestigungs-Einrichtung bis zu der WerkstÃ¼ck-KontaktflÃ¤che erstrecken.The active structure can extend toward the workpiece contact surface. In particular, the active structure can extend from an end or side of the pole piece opposite the workpiece contact surface to the workpiece contact surface. Alternatively, the active structure can extend from the fastening device to the workpiece contact surface.

**[p0018]**

Die Wirkstruktur kann sich bis zu einem Kontaktbereich des Polschuhs erstrecken. Insbesondere kann sich die Wirkstruktur von dem Kontaktbereich entgegengesetzten Ende oder Seite des Polschuhs bis zu dem Kontaktbereich erstrecken. Alternativ kann sich die Wirkstruktur von der Befestigungs-Einrichtung bis zu dem Kontaktbereich erstrecken. Der Kontaktbereich kann durch die WerkstÃ¼ck-KontaktflÃ¤che begrenzt sein. Der Kontaktbereich kann sich von der WerkstÃ¼ck-KontaktflÃ¤che bis zu hÃ¶chstens 5 mm, vorzugsweise 4 mm, 3 mm, 2 mm oder 1 mm, in einer zur WerkstÃ¼ck-KontaktflÃ¤che orthogonalen Richtung erstrecken.The active structure can extend to a contact area of the pole piece. In particular, the active structure can extend from the end or side of the pole piece opposite the contact area to the contact area. Alternatively, the active structure can extend from the fastening device to the contact area. The contact area can be limited by the workpiece contact surface. The contact area can extend from the workpiece contact surface to a maximum of 5 mm, preferably 4 mm, 3 mm, 2 mm, or 1 mm, in a direction orthogonal to the workpiece contact surface.

**[p0019]**

Die Wirkstruktur kann dazu ausgebildet sein, den Magnetfeldanteil derart zu der WerkstÃ¼ck-KontaktflÃ¤che zu fÃ¼hren, dass der Magnetfeldanteil fÃ¼r das Greifen des WerkstÃ¼cks aus der WerkstÃ¼ck-KontaktflÃ¤che austritt.The active structure can be designed to guide the magnetic field component to the workpiece contact surface in such a way that the magnetic field component for the gripping of the workpiece exits the workpiece contact surface. Die WerkstÃ¼ck-KontaktflÃ¤che kann zum berÃ¼hrenden Kontaktieren des ferromagnetischen WerkstÃ¼cks ausgebildet sein.The workpiece contact surface can be designed to make contact with the ferromagnetic workpiece. Wie bereits angesprochen, kann die WerkstÃ¼ck-KontaktflÃ¤che je nach Anwendungsbereich eben oder gekrÃ¼mmt, insbesondere konvex, ausgebildet sein.As already mentioned, the workpiece contact surface can be flat or curved, in particular convex, depending on the application. Die WerkstÃ¼ck-KontaktflÃ¤che kann ein Ende des Polschuhs bilden.The workpiece contact surface can form one end of the pole piece.

**[p0020]**

Die WerkstÃ¼ck-KontaktflÃ¤che kann von einer Fase oder Abrundung des Polschuhs begrenzt sein. Die Fase oder Abrundung des Polschuhs kann die WerkstÃ¼ck-KontaktflÃ¤che umlaufend umgeben. Durch die Fase oder Abrundung kann eine rechtwinklige Kante vermieden werden. Die Fase kann durch Anfassen der Kante, die die WerkstÃ¼ck-KontaktflÃ¤che begrenzt, hergestellt sein. Die Abrundung kann durch Abrunden der Kante, die die WerkstÃ¼ck-KontaktflÃ¤che begrenzt, hergestellt sein.The workpiece contact surface can be defined by a chamfer or rounded portion of the pole piece. The chamfer or rounded portion of the pole piece can surround the workpiece contact surface all the way around. The chamfer or rounded portion can prevent a right-angled edge. The chamfer can be created by tapping the edge that defines the workpiece contact surface. The rounded portion can be created by rounding the edge that defines the workpiece contact surface. Der Polschuh kann zwei Zentrierbohrungen zum Aufnehmen von Zylinderstifte des Magnetgreifers zum Zweck des Ausrichtens des Polschuhs relativ zu dem GehÃ¤use des Magnetgreifers aufweisen. Insbesondere die beiden Zentrierbohrungen kÃ¶nnen das Ausrichten des Polschuhs wÃ¤hrend dem Befestigen des Polschuhs an dem GehÃ¤use des Magnetgreifers erleichtert.The pole piece can have two centering holes for receiving cylindrical pins of the magnetic gripper for the purpose of aligning the pole piece relative to the housing of the magnetic gripper. In particular, the two centering holes can facilitate the alignment of the pole piece during attachment of the pole piece t

**[p0020]**

o the housing of the magnetic gripper.

**[p0021]**

Ein weiterer Aspekt des Polschuhs kann sein, dass eine geometrische Form des Polschuhs die Wirkstruktur bildet. Die Wirkstruktur kann dazu ausgebildet sein, den Magnetfeldanteil derart zu der WerkstÃ¼ck-KontaktflÃ¤che zu fÃ¼hren, dass der Magnetfeldanteil zum Zweck der ErhÃ¶hung der Haltekraft fokussiert aus der WerkstÃ¼ck-KontaktflÃ¤che austritt. ZusÃ¤tzlich kann die Wirkstruktur dazu ausgebildet sein, den Magnetfeldanteil derart zu der WerkstÃ¼ck-KontaktflÃ¤che zu fÃ¼hren, insbesondere lenken, dass der Magnetfeldanteil mit einer geringeren Tiefenwirkung aus der WerkstÃ¼ck-KontaktflÃ¤che austritt als bei einem Polschuh ohne Wirkstruktur. Dadurch kann der Polschuh ermÃ¶glichen, dass ein WerkstÃ¼ck von einem WerkstÃ¼ck-Stapel, der durch einzelne Ã¼bereinanderliegende plattenfÃ¶rmige WerkstÃ¼cke gebildet ist, mittels des Magnetgreifers gegriffen werden kann, ohne dabei ein darunterliegendes WerkstÃ¼ck zu greifen. Die zusammenhÃ¤ngende WerkstÃ¼ck-KontaktflÃ¤che kann dabei eine BeschÃ¤digung des WerkstÃ¼cks, beispielsweise eine Beschichtung des WerkstÃ¼cks, verhindern.A further aspect of the pole piece can be that a geometric shape of the pole piece forms the active structure. The active structure can be designed to guide the magnetic field component to the workpiece contact surface in such a way that the magnetic field component emerges from the workpiece contact surface in a focused manner for the purpose of increasing the holding force. In addition, the active structure can be designed to guide the magnetic field component to the workpiece contact surface, in particular to d

**[p0021]**

irect it, in such a way that the magnetic field component emerges from the workpiece contact surface with a smaller depth effect than with a pole piece without an active structure. As a result, the pole piece can enable a workpiece to be gripped by the magnetic gripper from a workpiece stack formed by individual, superimposed, plate-shaped workpieces, without gripping an underlying workpiece. The continuous workpiece contact surface can prevent damage to the workpiece, for example, a coating on the workpiece.

**[p0022]**

In einer Weiterbildung des Polschuhs bewirkt die Wirkstruktur, dass eine QuerschnittsflÃ¤che des Polschuhs ausgehend von der WerkstÃ¼ck-KontaktflÃ¤che in Richtung der Befestigungs-Einrichtung sich vergrÃ¶Ãert. Vorteilhafterweise kann dadurch der Magnetfeldanteil auf die WerkstÃ¼ck-KontaktflÃ¤che fokussiert werden. Insbesondere kann die Wirkstruktur bewirken, dass ein Betrag der QuerschnittsflÃ¤che des Polschuhs ausgehend von der WerkstÃ¼ck-KontaktflÃ¤che in Richtung der Befestigungs-Einrichtung sich vergrÃ¶Ãert. Die Richtung kann orthogonal zu der WerkstÃ¼ck-KontaktflÃ¤che ausgerichtet sein.In a further development of the pole piece, the active structure causes the cross-sectional area of the pole piece to increase from the workpiece contact surface toward the fastening device. This advantageously allows the magnetic field component to be focused on the workpiece contact surface. In particular, the active structure can cause the cross-sectional area of the pole piece to increase from the workpiece contact surface toward the fastening device. This direction can be oriented orthogonally to the workpiece contact surface.

**[p0023]**

In einer Weiterbildung des Polschuhs vergrÃ¶Ãert sich die QuerschnittsflÃ¤che des Polschuhs stetig oder unstetig. Unter einer stetigen VergrÃ¶Ãerung der QuerschnittsflÃ¤che kann eine kontinuierliche VergrÃ¶Ãerung der QuerschnittsflÃ¤che verstanden werden. Unter einer unstetigen VergrÃ¶Ãerung der QuerschnittsflÃ¤che kann eine sprungartige oder stufenartige VergrÃ¶Ãerung der QuerschnittsflÃ¤che verstanden werden.In a further development of the pole piece, the cross-sectional area of the pole piece increases continuously or discontinuously. A continuous increase in the cross-sectional area can be understood as a continuous increase in the cross-sectional area. A discontinuous increase in the cross-sectional area can be understood as a sudden or step-like increase in the cross-sectional area. In einer Weiterbildung des Polschuhs weist die Wirkstruktur eine stufenartige Ausbildung auf. Vorteilhafterweise kann eine stufenartige Wirkstruktur besonders einfach hergestellt werden. Die stufenartige Wirkstruktur kann zu der WerkstÃ¼ck-KontaktflÃ¤che einen parallelen Verlauf aufweisen. Die stufenartige Wirkstruktur kann durch eine Anzahl, insbesondere 2, 3, 4 oder 5, von Stufen gebildet sein. Die Stufen kÃ¶nnen durch OberflÃ¤chen des Polschuhs gebildet werden, die parallel und versetzt zueinander angeordnet sind. Die OberflÃ¤chen kÃ¶nnen mit einem gleichen Abstand voneinander beanstandet sein. Mit anderen Worten, die OberflÃ¤chen kÃ¶nnen gleichmÃ¤Ãig voneinander beanstandet sein. Die die stufenartige Wirkstruktur bildenden OberflÃ¤chen des Polschuhs kÃ¶nnen parallel und versetzt

**[p0023]**

zu der WerkstÃ¼ck-KontaktflÃ¤che ausgerichtet sein. Durch die stufenartige Wirkstruktur kann sich die QuerschnittsflÃ¤che des Polschuhs von der WerkstÃ¼ck-KontaktflÃ¤che in Richtung der Befestigungs-Einrichtung unstetig vergrÃ¶Ãern.In a further development of the pole piece, the knitted structure has a step-like design. Advantageously, a step-like knitted structure can be manufactured particularly easily. The step-like knitted structure can have a parallel course to the workpiece contact surface. The step-like knitted structure can be formed by a number, in particular 2, 3, 4 or 5, of steps. The steps can be formed by surfaces of the pole piece that are arranged parallel and offset from one another. The surfaces can be spaced apart at an equal distance from one another. In other words, the surfaces can be evenly spaced from one another. The surfaces of the pole piece forming the step-like knitted structure can be aligned parallel and offset from the workpiece contact surface. Due to the step-like knitted structure, the cross-sectional area of the pole piece can increase discontinuously from the workpiece contact surface towards the fastening device.

**[p0024]**

In einer Weiterbildung des Polschuhs weist die Wirkstruktur eine ebene Ausbildung auf. Durch die ebene Wirkstruktur kann sich die QuerschnittsflÃ¤che des Polschuhs von der WerkstÃ¼ck-KontaktflÃ¤che in Richtung der Befestigungs-Einrichtung stetig vergrÃ¶Ãern. Die ebene Wirkstruktur kann durch eine ebene FlÃ¤che des Polschuhs gebildet sein. Die ebene Wirkstruktur kann sich bis zu der WerkstÃ¼ck-KontaktflÃ¤che erstrecken. Ein Betrag eines Winkels zwischen der ebenen Wirkstruktur und der WerkstÃ¼ck-KontaktflÃ¤che kann ungleich 90Â° sein, insbesondere grÃ¶Ãer als 90Â° sein. Vorzugsweise kann der Winkel zwischen der ebenen Wirkstruktur und der WerkstÃ¼ck-KontaktflÃ¤che einen Betrag aufweisen, der grÃ¶Ãer als 90Â° und kleiner als 180Â° ist. Die ebene Wirkstruktur kann fÃ¼r das Kontaktieren des WerkstÃ¼cks ungeeignet sein. Die ebene Wirkstruktur kann, insbesondere nur, fÃ¼r die ErhÃ¶hung der Haltekraft des Magnetgreifers und/oder fÃ¼r die Reduzierung der Tiefenwirkung des Magnetfeldanteils ausgebildet sein.In a further development of the pole piece, the active structure has a planar configuration. Due to the planar active structure, the cross-sectional area of the pole piece can increase continuously from the workpiece contact surface toward the fastening device. The planar active structure can be formed by a planar surface of the pole piece. The planar active structure can extend to the workpiece contact surface. The angle between the planar active structure and the workpiece contact surface can be different from 90Â°, in particular greater than 90Â°. Preferably, the angle betw

**[p0024]**

een the planar active structure and the workpiece contact surface can be greater than 90Â° and less than 180Â°. The planar active structure can be unsuitable for contacting the workpiece. The planar active structure can, in particular, only be designed to increase the holding force of the magnetic gripper and/or to reduce the depth effect of the magnetic field component.

**[p0025]**

In einer Weiterbildung des Polschuhs weist die Wirkstruktur eine Anzahl, beispielsweise 2, 3, 4, 5, 6 oder 8, von Ausnehmungen auf. Jede Ausnehmung weist eine LÃ¤ngsachse auf, entlang der sich die Ausnehmung erstreckt. Durch die Ausnehmungen kann erreicht werden, dass der Magnetfeldanteil, der von dem Polschuh gefÃ¼hrt ist, in einen die Ausnehmung nicht aufweisenden Bereich des Polschuhs gedrÃ¤ngt wird.In a further development of the pole piece, the active structure has a number of recesses, for example, 2, 3, 4, 5, 6, or 8. Each recess has a longitudinal axis along which the recess extends. The recesses can be used to force the magnetic field component guided by the pole piece into a region of the pole piece that does not have the recess. Die Anzahl von Ausnehmungen kÃ¶nnen in einem Randbereich des Polschuhs angeordnet sein. Der Randbereich kann sich von der WerkstÃ¼ck-KontaktflÃ¤che bis zu einer HÃ¤lfte, vorzugsweise einem Drittel oder einem Viertel, einer LÃ¤nge des Polschuhs erstrecken. Die LÃ¤nge des Polschuhs kann in einer zur WerkstÃ¼ck-KontaktflÃ¤che orthogonalen Richtung gemessen werden. Jede Ausnehmung kann den Polschuh, insbesondere vollstÃ¤ndig, durchdringen.The number of recesses can be arranged in an edge region of the pole piece. The edge region can extend from the workpiece contact surface to one-half, preferably one-third or one-quarter, of the length of the pole piece. The length of the pole piece can be measured in a direction orthogonal to the workpiece contact surface. Each recess can penetrate the pole piece, in particular completely.

**[p0026]**

Die Ausnehmungen oder zumindest eine Anzahl der Ausnehmungen kann mit dem nicht-ferromagnetischen Material des Polschuhs ausgefÃ¼llt sein. Das nicht-ferromagnetische Material kann beispielsweise ein Kunststoff, insbesondere ein Elastomer, sein.The recesses, or at least a number of them, can be filled with the non-ferromagnetic material of the pole piece. The non-ferromagnetic material can be, for example, a plastic, in particular an elastomer. In einer Weiterbildung des Polschuhs sind die LÃ¤ngsachsen der Ausnehmungen orthogonal oder parallel zu der WerkstÃ¼ck-KontaktflÃ¤che ausgerichtet.In a further development of the pole piece, the longitudinal axes of the recesses are aligned orthogonally or parallel to the workpiece contact surface. In einer Weiterbildung des Polschuhs weist mindestens eine Ausnehmung von der Anzahl von Ausnehmung einen kreisfÃ¶rmigen Querschnitt auf. ZusÃ¤tzlich oder alternativ weist mindestens eine Ausnehmung von der Anzahl von Ausnehmung einen rechteckfÃ¶rmigen, insbesondere quadratischen, Querschnitt auf. Vorteilhafterweise kann eine Ausnehmung mit einem kreisfÃ¶rmigen Querschnitt und/oder eine Ausnehmung mit einem rechteckfÃ¶rmigen Querschnitt besonders einfach hergestellt werden.In a further development of the pole piece, at least one of the plurality of recesses has a circular cross-section. Additionally or alternatively, at least one of the plurality of recesses has a rectangular, in particular square, cross-section. Advantageously, a recess with a circular cross-section and/or a recess with a rectangular cross-section can be manufactured parti

**[p0026]**

cularly easily.

**[p0027]**

Vorzugsweise kÃ¶nnen alle Ausnehmungen einen kreisfÃ¶rmigen Querschnitt oder einen rechteckfÃ¶rmigen Querschnitt aufweisen.Preferably, all recesses may have a circular cross-section or a rectangular cross-section. Mindestens eine Ausnehmung von der Anzahl von Ausnehmung kann als ein Loch, insbesondere Bohrung, ausgebildet sein.At least one of the plurality of recesses can be formed as a hole, in particular a bore. Die Durchmesser der Ausnehmungen kÃ¶nnen gleich oder voneinander verschieden sein.The diameters of the recesses can be the same or different. In einer Weiterbildung des Polschuhs ist jede Ausnehmung als ein Loch, insbesondere Bohrung, ausgebildet, das sich von einer der WerkstÃ¼ck-KontaktflÃ¤che entgegengesetzten Seite des Polschuhs auf die WerkstÃ¼ck-KontaktflÃ¤che zu erstreckt.In a further development of the pole shoe, each recess is designed as a hole, in particular a bore, which extends from a side of the pole shoe opposite the workpiece contact surface towards the workpiece contact surface.

**[p0028]**

Jedes Loch kann sich derart von der der WerkstÃ¼ck-KontaktflÃ¤che entgegengesetzten Seite des Polschuhs auf die WerkstÃ¼ck-KontaktflÃ¤che zu erstrecken, dass das Loch nicht bis zu der WerkstÃ¼ck-KontaktflÃ¤che gelangt, insbesondere die WerkstÃ¼ck-KontaktflÃ¤che nicht durchdringt. Alternativ kann sich jedes Loch derart von der der WerkstÃ¼ck-KontaktflÃ¤che entgegengesetzten Seite des Polschuhs auf die WerkstÃ¼ck-KontaktflÃ¤che zu erstrecken, dass das Loch bis zu der WerkstÃ¼ck-KontaktflÃ¤che gelangt, insbesondere die WerkstÃ¼ck-KontaktflÃ¤che durchdringt. Jedes Loch kann einen ebenen Loch-Grund aufweisen.Each hole can extend from the side of the pole piece opposite the workpiece contact surface to the workpiece contact surface in such a way that the hole does not reach the workpiece contact surface, in particular does not penetrate the workpiece contact surface. Alternatively, each hole can extend from the side of the pole piece opposite the workpiece contact surface to the workpiece contact surface in such a way that the hole reaches the workpiece contact surface, in particular penetrates the workpiece contact surface. Each hole can have a flat hole base.

**[p0029]**

Ein Abstand zwischen der WerkstÃ¼ck-KontaktflÃ¤che und dem Loch-Grund kann einen Betrag in einem Bereich von 1 mm bis 5 mm, vorzugsweise 1 mm bis 3 mm, aufweisen.A distance between the workpiece contact surface and the hole bottom may have an amount in a range of 1 mm to 5 mm, preferably 1 mm to 3 mm. Die der WerkstÃ¼ck-KontaktflÃ¤che entgegengesetzte Seite kann ein Ende des Polschuhs bilden. Die der WerkstÃ¼ck-KontaktflÃ¤che entgegengesetzte Seite kann parallel zu der WerkstÃ¼ck-KontaktflÃ¤che verlaufen. Die der WerkstÃ¼ck-KontaktflÃ¤che entgegengesetzte Seite kann durch eine ebene FlÃ¤che des Polschuhs gebildet sein. Die der WerkstÃ¼ck-KontaktflÃ¤che entgegengesetzte Seite kann als eine zusammenhÃ¤ngende FlÃ¤che ausgebildet sein. Jede LÃ¤ngsachse der LÃ¶cher kann orthogonal zu der WerkstÃ¼ck-KontaktflÃ¤che ausgerichtet sein.The side opposite the workpiece contact surface can form one end of the pole piece. The side opposite the workpiece contact surface can run parallel to the workpiece contact surface. The side opposite the workpiece contact surface can be formed by a flat surface of the pole piece. The side opposite the workpiece contact surface can be formed as a continuous surface. Each longitudinal axis of the holes can be aligned orthogonally to the workpiece contact surface.

**[p0030]**

In einer Weiterbildung des Polschuhs ist jede Ausnehmung als ein Loch, insbesondere Bohrung, ausgebildet, die den Polschuh von einer Seite des Polschuhs bis zu einer der Seite entgegengesetzten weiteren Seite des Polschuhs durchdringt. Jedes Loch, insbesondere Bohrung, kann parallel zu der WerkstÃ¼ck-KontaktflÃ¤che ausgerichtet sein. Die Seite und die weitere Seite kÃ¶nnen parallel zueinander verlaufen. Die Seite und die weitere Seite kÃ¶nnen eben ausgebildet sein. Die Seite und die weitere Seite kÃ¶nnen jeweils eine Breitseite des Polschuhs sein. Alternativ kÃ¶nnen die Seite und die weitere Seite jeweils eine Schmalseite des Polschuhs sein. Die Seite und/oder die weitere Seite kÃ¶nnen orthogonal zu der WerkstÃ¼ck-KontaktflÃ¤che verlaufen. Die WerkstÃ¼ck-KontaktflÃ¤che kann nicht an der Seite und/oder der weiteren Seite angeordnet sein.In a further development of the pole shoe, each recess is designed as a hole, in particular a bore, which penetrates the pole shoe from one side of the pole shoe to a further side of the pole shoe opposite the side. Each hole, in particular a bore, can be aligned parallel to the workpiece contact surface. The side and the further side can run parallel to one another. The side and the further side can be flat. The side and the further side can each be a wide side of the pole shoe. Alternatively, the side and the further side can each be a narrow side of the pole shoe. The side and/or the further side can run orthogonally to the workpiece contact surface. The workpiece contact surface cannot be arranged on the side and/or the further side.

**[p0031]**

Ein Abstand zwischen der WerkstÃ¼ck-KontaktflÃ¤che und dem Loch, insbesondere Bohrung, kann einen Betrag in einem Bereich von 1 mm bis 5 mm, vorzugsweise 1 mm bis 3 mm, aufweisen.A distance between the workpiece contact surface and the hole, in particular bore, can have an amount in a range of 1 mm to 5 mm, preferably 1 mm to 3 mm. In einer Weiterbildung des Polschuhs ist ein Abstand zwischen der Wirkstruktur und der WerkstÃ¼ck-KontaktflÃ¤che geringer ist als ein Abstand zwischen der Wirkstruktur und der Befestigungs-Einrichtung.In a further development of the pole shoe, a distance between the active structure and the workpiece contact surface is smaller than a distance between the active structure and the fastening device. In einer Weiterbildung des Polschuhs weist die Wirkstruktur eine Abfolge von Erhebungen und/oder Aussparungen auf. Der Magnetfeldanteil kann in den Erhebungen zumindest teilweise gefÃ¼hrt sein. Durch die Aussparungen kann erreicht werden, dass der Magnetfeldanteil, der von dem Polschuh gefÃ¼hrt ist, in einen die Aussparungen nicht aufweisenden Bereich des Polschuhs gedrÃ¤ngt wird. Insbesondere kann durch die Aussparungen erreicht werden, dass der Magnetfeldanteil, der von dem Polschuh gefÃ¼hrt ist, in die Erhebungen gedrÃ¤ngt wird.In a further development of the pole piece, the active structure has a sequence of elevations and/or recesses. The magnetic field component can be at least partially guided in the elevations. The recesses can be used to force the magnetic field component guided by the pole piece into an area of the pole piece that does not have

**[p0031]**

the recesses. In particular, the recesses can be used to force the magnetic field component guided by the pole piece into the elevations.

**[p0032]**

Die Aussparungen kÃ¶nnen mit dem nicht-ferromagnetischen Material des Polschuhs ausgefÃ¼llt sein. Das nicht-ferromagnetische Material kann beispielsweise ein Kunststoff, insbesondere ein Elastomer, sein.The recesses can be filled with the non-ferromagnetic material of the pole piece. The non-ferromagnetic material can be, for example, a plastic, particularly an elastomer. Die Erhebungen und/oder die Aussparungen kÃ¶nnen gleichmÃ¤Ãig voneinander beanstandet sein. Die Erhebungen und/oder die Aussparungen kÃ¶nnen sich in eine zu der WerkstÃ¼ck-KontaktflÃ¤che orthogonale Richtung erstrecken. Die Erhebungen und/oder die Aussparungen kÃ¶nnen an einer SeitenflÃ¤che, insbesondere eine Breitseite, des Polschuhs angeordnet sein. Zwischen zwei benachbarten Erhebungen kann eine Aussparung angeordnet sein. Zwischen zwei benachbarten Aussparungen kann eine Erhebung angeordnet sein. Die Abfolge kann durch eine abwechselnde oder alternierende Anordnung von Aussparungen und Erhebungen gebildet sein. Die Erhebungen und/oder die Aussparungen kÃ¶nnen jeweils einen rechteckfÃ¶rmigen Querschnitt aufweisen. Jede Aussparung kann als Nut ausgebildet sein. Die Erhebungen und/oder die Aussparungen kÃ¶nnen sich bis zu dem Kontaktbereich erstrecken.The elevations and/or recesses can be evenly spaced from one another. The elevations and/or recesses can extend in a direction orthogonal to the workpiece contact surface. The elevations and/or recesses can be arranged on a side surface, in particular a broad side, of the pole piece. A recess can be arranged between two adjacent elevations. A elevation can

**[p0032]**

be arranged between two adjacent recesses. The sequence can be formed by an alternating or alternating arrangement of recesses and elevations. The elevations and/or recesses can each have a rectangular cross-section. Each recess can be designed as a groove. The elevations and/or recesses can extend as far as the contact area.

**[p0033]**

In einer Weiterbildung des Polschuhs durchdringen die Aussparungen den Polschuh. Dadurch kann ein besonderes effizientes DrÃ¤ngen des Magnetfeldanteils in Bereiche des Polschuhs, welche die Aussparungen nicht aufweisen, ermÃ¶glicht werden. Jede Aussparung kann als Langloch ausgebildet sein.In a further development of the pole piece, the recesses extend through the pole piece. This allows for a particularly efficient displacement of the magnetic field component into areas of the pole piece that do not have the recesses. Each recess can be designed as an elongated hole. Ein erfindungsgemÃ¤Ãer Magnetgreifer fÃ¼r eine Handhabungsvorrichtung zum Greifen eines ferromagnetischen WerkstÃ¼cks weist ein GehÃ¤use und einen Magneten, der in dem GehÃ¤use angeordnet ist, auf. Der Magnet ist zwischen einem Greifzustand zum Greifen des ferromagnetischen WerkstÃ¼cks und einem Freigabezustand zum Freigeben des ferromagnetischen WerkstÃ¼cks Ã¼berfÃ¼hrbar. Weiter weist der Magnetgreifer wenigstens einen ersten Polschuh der zuvor beschriebenen Art und einem zweiten Polschuh der zuvor beschriebenen Art auf. Der erste Polschuh und der zweite Polschuh sind an dem GehÃ¤use befestigt. Die WerkstÃ¼ck-KontaktflÃ¤che des ersten Polschuhs und die WerkstÃ¼ck-KontaktflÃ¤che des zweiten Polschuhs bilden zusammen eine HalteflÃ¤che des Magnetgreifers. Vorteilhafte Ausgestaltungen haben genau zwei der genannte Polschuhe; insbesondere kÃ¶nnen die beiden Polschuhe dann im Wesentlichen gegenÃ¼berliegend an dem GehÃ¤use angeordnet sein, vorzugsweise an jeweiligen SeitenflÃ¤chen des GehÃ¤uses des Magnetgreifers.A

**[p0033]**

magnetic gripper according to the invention for a handling device for gripping a ferromagnetic workpiece comprises a housing and a magnet arranged in the housing. The magnet can be transferred between a gripping state for gripping the ferromagnetic workpiece and a release state for releasing the ferromagnetic workpiece. Furthermore, the magnetic gripper comprises at least one first pole shoe of the type described above and one second pole shoe of the type described above. The first pole shoe and the second pole shoe are fastened to the housing. The workpiece contact surface of the first pole shoe and the workpiece contact surface of the second pole shoe together form a holding surface of the magnetic gripper. Advantageous embodiments have exactly two of said pole shoes; in particular, the two pole shoes can then be arranged substantially opposite one another on the housing, preferably on respective side surfaces of the housing of the magnetic gripper.

**[p0034]**

Die Handhabungsvorrichtung kann als ein Manipulator, beispielsweise in Form eines Roboterarms, ausgebildet sein.The handling device can be designed as a manipulator, for example in the form of a robot arm. Das GehÃ¤use kann einteilig ausgebildet sein oder eine Mehrzahl von GehÃ¤useteile aufweisen, die in einem zusammengesetzten Zustand das GehÃ¤use bilden. Das GehÃ¤use kann nicht magnetisierbar ausgebildet sein. Das GehÃ¤use kann aus einem nicht-ferromagnetischen Material, beispielsweise Aluminium, ausgebildet sein.The housing can be formed as a single piece or comprise a plurality of housing parts that, when assembled, form the housing. The housing can be designed to be non-magnetizable. The housing can be made of a non-ferromagnetic material, for example, aluminum. Der Magnet kann dazu ausgebildet sein, das Magnetfeld zu erzeugen. Der Magnet kann ein Permanentmagnet und/oder ein Elektromagnet sein. Der Magnet kann von dem GehÃ¤use getragen sein. Das GehÃ¤use kann einen Innenraum aufweisen, in dem der Magnet angeordnet ist.The magnet can be configured to generate the magnetic field. The magnet can be a permanent magnet and/or an electromagnet. The magnet can be supported by the housing. The housing can have an interior space in which the magnet is arranged.

**[p0035]**

Der Magnet kann einen Nordpol und einen SÃ¼dpol aufweisen. Das Magnetfeld des Magneten kann sich von dem Nordpol zu dem SÃ¼dpol erstreckt.The magnet may have a north pole and a south pole. The magnet's magnetic field may extend from the north pole to the south pole. Der Magnet kann derart in dem GehÃ¤use angeordnet sein, dass in dem Greifzustand der Nordpol auf den ersten Polschuh und der SÃ¼dpol auf den zweiten Polschuh gerichtet ist.The magnet may be arranged in the housing such that in the gripping state the north pole is directed towards the first pole piece and the south pole is directed towards the second pole piece. In dem Greifzustand kann ein Magnetfeldanteil des Magnetfelds des Magneten mittels den Polschuhen zu der HalteflÃ¤che gefÃ¼hrt sein. In dem Freigabezustand kann der Magnetfeldanteil des Magnetfelds des Magneten nicht mittels den Polschuhen zu der HalteflÃ¤che gefÃ¼hrt sein.In the gripping state, a magnetic field component of the magnet's magnetic field can be guided to the holding surface via the pole pieces. In the release state, the magnetic field component of the magnet's magnetic field cannot be guided to the holding surface via the pole pieces.

**[p0036]**

Der Magnet kann durch eine Translationsbewegung des Magneten zwischen dem Greifzustand und dem Freigabezustand Ã¼berfÃ¼hrbar sein. Die Translationsbewegung kann eine gerade Bewegung sein, insbesondere eine Vertikalbewegung. Beispielsweise kann der Magnet durch eine lineare Verschiebung des Magneten, insbesondere in eine zur LÃ¤ngsachse des Magnetgreifers parallelen Richtung, zwischen dem Greifzustand und dem Freigabezustand Ã¼berfÃ¼hrbar sein. ZusÃ¤tzlich oder alternativ kann der Magnet durch eine Rotationsbewegung des Magneten zwischen dem Greifzustand und dem Freigabezustand Ã¼berfÃ¼hrbar sein.The magnet can be transferred between the gripping state and the release state by a translational movement of the magnet. The translational movement can be a straight movement, in particular a vertical movement. For example, the magnet can be transferred between the gripping state and the release state by a linear displacement of the magnet, in particular in a direction parallel to the longitudinal axis of the magnetic gripper. Additionally or alternatively, The magnet can be transferred between the gripping state and the release state by a rotational movement of the magnet.

**[p0037]**

Der Magnet kann in dem GehÃ¤use linear verschiebbar und/oder drehbeweglich, insbesondere entlang einer LÃ¤ngsachse des Magnetgreifers, gelagert sein.The magnet can be mounted in the housing so as to be linearly displaceable and/or rotatable, in particular along a longitudinal axis of the magnetic gripper. Das ÃberfÃ¼hren von dem Freigabezustand in den Greifzustand kann durch eine lineare Verschiebung des Magneten innerhalb des GehÃ¤uses auf die HalteflÃ¤che zu erfolgen. Das ÃberfÃ¼hren von dem Greifzustand in den Freigabezustand kann durch eine lineare Verschiebung des Magneten innerhalb des GehÃ¤uses von der HalteflÃ¤che weg erfolgen. The transition from the release state to the gripping state can be achieved by a linear displacement of the magnet within the housing toward the holding surface. The transition from the gripping state to the release state can be achieved by a linear displacement of the magnet within the housing away from the holding surface. Die Translationsbewegung und/oder die Rotationsbewegung des Magneten kann pneumatisch, elektrisch, beispielsweise mittels eines Elektromotors oder eines elektrischen Linearantriebs, oder mechanisch, beispielsweise durch BetÃ¤tigung eines Hebels, angetrieben sein. Anders formuliert, der Magnetgreifer kann elektrisch, pneumatisch oder mechanisch aktuiert sein.The translational movement and/or rotational movement of the magnet can be driven pneumatically, electrically, for example, by an electric motor or an electric linear drive, or mechanically, for example, by actuating a lever. In other words, the magnetic gripper can

**[p0037]**

be actuated electrically, pneumatically, or mechanically.

**[p0038]**

Der Magnetgreifer kann einen Aktuator zum ÃberfÃ¼hren des Magneten zwischen dem Greifzustand und dem Freigabezustand aufweisen. Der Aktuator kann dazu ausgebildet sein, die Translationsbewegung und/oder die Rotationsbewegung des Magneten anzutreiben. Der Aktuatoren kann ein Elektromotor, ein Hebel und/oder ein pneumatischer Antrieb sein. Insbesondere kann der Aktuator als Pneumatik-Kolben ausgebildet sein, der mit dem Magneten verbunden ist. Das GehÃ¤use kann einen neuen Pneumatik-Zylinder aufweisen, in dem der Pneumatik-Kolben angeordnet ist.The magnetic gripper can have an actuator for transferring the magnet between the gripping state and the release state. The actuator can be configured to drive the translational movement and/or the rotational movement of the magnet. The actuator can be an electric motor, a lever, and/or a pneumatic drive. In particular, the actuator can be configured as a pneumatic piston connected to the magnet. The housing can have a new pneumatic cylinder in which the pneumatic piston is arranged.

**[p0039]**

Wenn der Magnet durch eine Rotationsbewegung zwischen dem Freigabezustand und dem Greifzustand Ã¼berfÃ¼hrbar ist, kann der Magnet zwei voneinander separat ausgebildete Magnetsegmente aufweisen, die zum ÃberfÃ¼hren zwischen dem Freigabezustand und dem Greifzustand gegeneinander verdreht werden.If the magnet can be transferred between the release state and the gripping state by a rotational movement, the magnet can have two separately formed magnet segments which are rotated against each other for transferring between the release state and the gripping state. Der Magnetgreifer kann eine Mehrzahl von Magneten aufweisen. Wenn der Magnetgreifer die Mehrzahl von Magneten aufweist, kann der Magnetgreifer eine Mehrzahl von ersten Polschuhen und eine Mehrzahl von zweiten Polschuhen aufweisen. Die Anzahl von Magneten, die Anzahl von ersten Polschuhen und die Anzahl von zweiten Polschuhen kÃ¶nnen gleich sein. Insbesondere jedem Magneten des Magnetgreifers kann ein erster Polschuh und ein zweiter Polschuh zugeordnet sein. Entsprechendes kann gelten, wenn der Magnet eine hÃ¶here Segmentierung, beispielsweise grÃ¶Ãer zwei, aufweist.The magnetic gripper can have a plurality of magnets. If the magnetic gripper has a plurality of magnets, the magnetic gripper can have a plurality of first pole pieces and a plurality of second pole pieces. The number of magnets, the number of first pole pieces, and the number of second pole pieces can be the same. In particular, each magnet of the magnetic gripper can be assigned a first pole piece and a second pole piece. The same applies if the magnet ha

**[p0039]**

s a higher segmentation, for example, greater than two.

**[p0040]**

Der Magnetgreifer kann einen Sensor zum Erfassen des Greifzustands und/oder des Freigabezustands aufweisen. Der Sensor kann eine Position des Magneten in dem GehÃ¤use erfassen. Der Magnettreffer kann eine Steuereinrichtung aufweisen, die den Aktuator zum ÃberfÃ¼hren des Magneten zwischen dem Greifzustand und dem Freigabezustand in AbhÃ¤ngigkeit von der erfassten Position des Magneten in dem GehÃ¤use und/oder von dem erfassten Greifzustand oder Freigabezustand ansteuert.The magnetic gripper can have a sensor for detecting the gripping state and/or the release state. The sensor can detect a position of the magnet in the housing. The magnetic gripper can have a control device that controls the actuator for transferring the magnet between the gripping state and the release state depending on the detected position of the magnet in the housing and/or the detected gripping state or release state. Der erste Polschuh und der zweite Polschuh kÃ¶nnen gegenÃ¼berliegend an dem GehÃ¤use angeordnet sein. Der erste Polschuh und der zweite Polschuh kÃ¶nnen an entgegengesetzten Seiten des GehÃ¤uses angeordnet sein. Der erste Polschuh und der zweite Polschuh kÃ¶nnen lÃ¶sbar an dem GehÃ¤use befestigt sein. Insbesondere kÃ¶nnen der erste Polschuh und der zweite Polschuh mittels einer Schraubverbindung an dem GehÃ¤use befestigt sein.The first pole piece and the second pole piece can be arranged opposite one another on the housing. The first pole piece and the second pole piece can be arranged on opposite sides of the housing. The first pole piece and the second pole piece can be releasably atta

**[p0040]**

ched to the housing. In particular, the first pole piece and the second pole piece can be attached to the housing by means of a screw connection.

**[p0041]**

Der erste Polschuh kann derart an dem GehÃ¤use angeordnet sein, dass, wenn der Magnet sich in dem Greifzustand befindet, der erste Polschuh durch den von dem ersten Polschuh gefÃ¼hrten Magnetfeldanteil des Magneten als Nordpol wirkt. Der zweite Polschuh kann derart an dem GehÃ¤use angeordnet sein, dass, wenn der Magnet sich in dem Greifzustand befindet, der zweite Polschuh durch den von dem zweiten Polschuh gefÃ¼hrten Magnetfeldanteil des Magneten als SÃ¼dpol wirkt.The first pole piece can be arranged on the housing such that, when the magnet is in the gripping state, the first pole piece acts as a north pole due to the magnetic field portion of the magnet guided by the first pole piece. The second pole piece can be arranged on the housing such that, when the magnet is in the gripping state, the second pole piece acts as a south pole due to the magnetic field portion of the magnet guided by the second pole piece. Die HalteflÃ¤che kann zum berÃ¼hrenden Kontaktieren des ferromagnetischen WerkstÃ¼cks ausgebildet sein. Die HalteflÃ¤che kann, insbesondere nur, durch die WerkstÃ¼ck-KontaktflÃ¤che des ersten Polschuhs und die WerkstÃ¼ck-KontaktflÃ¤che des zweiten Polschuhs gebildet sein. Vorzugsweise kann nur die HalteflÃ¤che dazu ausgebildet und/oder vorgesehen sein, das ferromagnetische WerkstÃ¼ck zu kontaktieren.The holding surface can be designed for contacting the ferromagnetic workpiece. The holding surface can be formed, in particular, only by the workpiece contact surface of the first pole piece and the workpiece contact surface of the second pole piece. Preferably, only t

**[p0041]**

he holding surface can be designed and/or provided for contacting the ferromagnetic workpiece.

**[p0042]**

Wenn der Magnet sich in dem Greifzustand befindet und das WerkstÃ¼ck von dem Magnetgreifer gegriffen ist, kann auf das WerkstÃ¼ck mittels des Magnetfeldanteils eine Magnetkraft wirken, welche das WerkstÃ¼ck, insbesondere nur, gegen die HalteflÃ¤che drÃ¼ckt oder presst. Die Magnetkraft kann grÃ¶Ãer sein als eine Gewichtskraft des WerkstÃ¼cks.When the magnet is in the gripping state and the workpiece is gripped by the magnetic gripper, a magnetic force can act on the workpiece via the magnetic field component, which pushes or presses the workpiece, in particular only, against the holding surface. The magnetic force can be greater than the weight of the workpiece. Der Magnetgreifer kann elektrisch oder pneumatisch angesteuert sein.The magnetic gripper can be controlled electrically or pneumatically. In einer Weiterbildung des Magnetgreifers weist der Magnetgreifer eine Einstellungs-Einrichtung zum Einstellen eines Polschuh-Abstands zwischen dem ersten Polschuh und dem zweiten Polschuh und/oder zum Einstellen eines Magnet-Abstands zwischen dem Magneten, insbesondere in dem Greifzustand, und den beiden Polschuhen auf.In a further development of the magnetic gripper, the magnetic gripper has an adjustment device for adjusting a pole shoe distance between the first pole shoe and the second pole shoe and/or for adjusting a magnet distance between the magnet, in particular in the gripping state, and the two pole shoes.

**[p0043]**

Das Einstellen des Polschuh-Abstands mittels der Einstellungs-Einrichtung kann beispielsweise durch eine Verschiebung von zumindest einem der beiden Polschuhe in eine zur HalteflÃ¤che parallelen Richtung erfolgen.The adjustment of the pole shoe distance by means of the adjustment device can be carried out, for example, by moving at least one of the two pole shoes in a direction parallel to the holding surface. Das Einstellen des Magnet-Abstands mittels der Einstellungs-Einrichtung kann beispielsweise durch eine Verschiebung von beiden Polschuhe in eine zur HalteflÃ¤che orthogonalen Richtung erfolgen.The adjustment of the magnet distance using the adjustment device can be done, for example, by moving both pole pieces in a direction orthogonal to the holding surface. Das GehÃ¤use kann die Einstellungs-Einrichtung aufweisen. Der erste und zweite Polschuh kÃ¶nnen an der Einstellungs-Einrichtung befestigt sein.The housing may include the adjustment device. The first and second pole pieces may be attached to the adjustment device.

**[p0044]**

Weitere Vorteile und vorteilhafte Ausgestaltungen der Erfindung sind den Figuren, deren Beschreibung und den AnsprÃ¼chen entnehmbar. Alle in den Figuren, deren Beschreibung und den AnsprÃ¼chen offenbarten Merkmale kÃ¶nnen sowohl einzeln als auch in beliebiger Kombination miteinander erfindungswesentlich sein. Es zeigen: 1 eine schematische Darstellung eines Magnetgreifers in einem Freigabezustand, 2 eine schematische Darstellung des Magnetgreifers von 1 in einem Greifzustand, 3 eine SchrÃ¤gansicht einer ersten Variante eines Polschuhs des Magnetgreifers von 1, 4 eine weitere SchrÃ¤gansicht der ersten Variante des Polschuhs von 3, 5 eine Draufsicht auf eine WerkstÃ¼ck-KontaktflÃ¤che der ersten Variante des Polschuhs von 3, 6 eine Schnittansicht der ersten Variante des Polschuhs entlang einer Schnittlinie VI-VI gemÃ¤Ã 5, 7 eine SchrÃ¤gansicht einer zweiten Variante eines Polschuhs des Magnetgreifers von 1, 8 eine SchrÃ¤gansicht einer dritten Variante eines Polschuhs des Magnetgreifers von 1, 9 eine Seitenansicht der dritten Variante des Polschuhs von 8,

**[p0045]**

10 eine Schnittansicht der dritten Variante des Polschuhs entlang einer Schnittlinie X-X gemÃ¤Ã 9, 11 eine SchrÃ¤gansicht einer vierten Variante eines Polschuhs des Magnetgreifers von 1, 12 eine Draufsicht auf einer der WerkstÃ¼ck-KontaktflÃ¤che entgegengesetzten Seite der vierten Variante des Polschuhs von 11, 13 eine Schnittansicht der vierten Variante des Polschuhs entlang einer Schnittlinie XIII-XIII gemÃ¤Ã 12, 14 eine SchrÃ¤gansicht einer fÃ¼nften Variante eines Polschuhs des Magnetgreifers von 1, 15 eine Draufsicht auf die der WerkstÃ¼ck-KontaktflÃ¤che entgegengesetzten Seite der fÃ¼nften Variante des Polschuhs von 14, 16 eine Schnittansicht der fÃ¼nften Variante des Polschuhs entlang einer Schnittlinie XVI-XVI gemÃ¤Ã 15, 17 eine SchrÃ¤gansicht einer sechsten Variante eines Polschuhs des Magnetgreifers von 1, 18 eine weitere SchrÃ¤gansicht der sechsten Variante des Polschuhs von 17, 19 eine Seitenansicht der sechsten Variante des Polschuhs von 17, 20 eine SchrÃ¤gansicht einer siebten Variante eines Polschuhs des Magnetgreifers von 1,

**[p0046]**

21 eine weitere SchrÃ¤gansicht der siebten Variante des Polschuhs von 20, 22 eine Seitenansicht der siebten Variante des Polschuhs von 20, 23 eine Seitenansicht einer achten Variante eines Polschuhs des Magnetgreifers von 1, 24 eine Seitenansicht einer neunten Variante eines Polschuhs des Magnetgreifers von 1, 25 eine Seitenansicht einer zehnten Variante eines Polschuhs des Magnetgreifers von 1, 26 eine SchrÃ¤gansicht einer elften Variante eines Polschuhs des Magnetgreifers von 1, 27 eine weitere SchrÃ¤gansicht der elften Variante des Polschuhs von 26, 28 eine Frontansicht der elften Variante des Polschuhs von 26, 29 eine Schnittansicht der elften Variante des Polschuhs entlang einer Schnittlinie XXIX-XXIX gemÃ¤Ã 28, 30 eine SchrÃ¤gansicht einer zwÃ¶lften Variante eines Polschuhs des Magnetgreifers von 1, 31 eine weitere SchrÃ¤gansicht der zwÃ¶lften Variante des Polschuhs von 30, 32 eine Frontansicht der zwÃ¶lften Variante des Polschuhs von 30, 33 eine Schnittansicht der zwÃ¶lften Variante des Polschuhs entlang einer Schnittlinie XXXIII-XXXIII gemÃ¤Ã 32,

**[p0047]**

34 eine SchrÃ¤gansicht einer dreizehnten Variante eines Polschuhs des Magnetgreifers von 1, 35 eine weitere SchrÃ¤gansicht der dreizehnten Variante des Polschuhs von 34, 36 eine Frontansicht der dreizehnten Variante des Polschuhs von 34, 37 eine Schnittansicht der dreizehnten Variante des Polschuhs entlang einer Schnittlinie XXXVII-XXXVII gemÃ¤Ã 36, 38 eine schematische Seitenansicht des Magnetgreifers von 2, und 39 eine weiter schematische Seitenansicht des Magnetgreifers von 38. Further advantages and advantageous embodiments of the invention can be gathered from the figures, their description, and the claims. All features disclosed in the figures, their description, and the claims can be essential to the invention both individually and in any combination. They show: 1 a schematic representation of a magnetic gripper in a release state, 2 a schematic representation of the magnetic gripper of 1 in a grasping state, 3 an oblique view of a first variant of a pole shoe of the magnetic gripper of 1 ,

**[p0048]**

4 another oblique view of the first variant of the pole piece of 3 , 5 a top view of a workpiece contact surface of the first variant of the pole piece of 3 , 6 a sectional view of the first variant of the pole piece along a section line VI-VI according to 5 , 7 an oblique view of a second variant of a pole shoe of the magnetic gripper of 1 , 8 an oblique view of a third variant of a pole shoe of the magnetic gripper from 1 , 9 a side view of the third variant of the pole piece of 8 , 10 a sectional view of the third variant of the pole piece along a section line XX according to 9 , 11 an oblique view of a fourth variant of a pole shoe of the magnetic gripper of 1 , 12 a plan view of a side opposite the workpiece contact surface of the fourth variant of the pole piece of 11 , 13 a sectional view of the fourth variant of the pole piece along a section line XIII-XIII according to 12 , 14 an oblique view of a fifth variant of a pole shoe of the magnetic gripper from 1 , 15 a plan view of the side opposite the workpiece contact surface of the fifth variant of the pole piece of 14 ,

**[p0049]**

16 a sectional view of the fifth variant of the pole piece along a section line XVI-XVI according to 15 , 17 an oblique view of a sixth variant of a pole shoe of the magnetic gripper of 1 , 18 another oblique view of the sixth variant of the pole piece of 17 , 19 a side view of the sixth variant of the pole piece of 17 , 20 an oblique view of a seventh variant of a pole shoe of the magnetic gripper from 1 , 21 another oblique view of the seventh variant of the pole piece of 20 , 22 a side view of the seventh variant of the pole piece of 20 , 23 a side view of an eighth variant of a pole shoe of the magnetic gripper from 1 , 24 a side view of a ninth variant of a pole shoe of the magnetic gripper from 1 , 25 a side view of a tenth variant of a pole shoe of the magnetic gripper from 1 , 26 an oblique view of an eleventh variant of a pole shoe of the magnetic gripper from 1 , 27 another oblique view of the eleventh variant of the pole piece of 26 , 28 a front view of the eleventh variant of the pole piece of 26 ,

**[p0050]**

29 a sectional view of the eleventh variant of the pole piece along a section line XXIX-XXIX according to 28 , 30 an oblique view of a twelfth variant of a pole shoe of the magnetic gripper from 1 , 31 another oblique view of the twelfth variant of the pole piece of 30 , 32 a front view of the twelfth variant of the pole piece of 30 , 33 a sectional view of the twelfth variant of the pole piece along a section line XXXIII-XXXIII according to 32 , 34 an oblique view of a thirteenth variant of a pole shoe of the magnetic gripper from 1 , 35 another oblique view of the thirteenth variant of the pole piece of 34 , 36 a front view of the thirteenth variant of the pole piece of 34 , 37 a sectional view of the thirteenth variant of the pole piece along a section line XXXVII-XXXVII according to 36 , 38 a schematic side view of the magnetic gripper from 2 , and 39 another schematic side view of the magnetic gripper from 38 . 1 zeigt schematisch einen Magnetgreifer 10 fÃ¼r eine Handhabungsvorrichtung zum Greifen eines ferromagnetischen WerkstÃ¼cks. Der Magnetgreifer 10 hat ein GehÃ¤use 12, dass sich entlang einer LÃ¤ngsachse 14 des GehÃ¤uses 12 erstreckt. Das GehÃ¤use 12 ist nicht magnetisierbar. Das GehÃ¤use 12 ist aus Aluminium gebildet. 1 schematically shows a magnetic gripper 10 for a handling device for gripping a ferromagnetic workpiece. The magnetic gripper 10 has a housing 12 that extends along a longitudinal axis 14 of the housing 12. The housing 12 is non-magnetizable. The housing 12 is made of aluminum.

**[p0051]**

Der Magnetgreifer 10 hat einen Magneten 16, der in dem GehÃ¤use 12 angeordnet ist. Der Magnet 16 ist ein Permanentmagnet. Der Magnet 16 hat einen Nordpol 18 und einen SÃ¼dpol 20. Ein Magnetfeld 22 des Magneten 16 erstreckt sich von dem Nordpol 18 bis zu dem SÃ¼dpol 20. Das Magnetfeld 22 verlÃ¤uft entlang von Magnetfeld-Linien 24. Der Magnet 16 ist derart in dem GehÃ¤use 12 angeordnet, dass der Nordpol 18 und der SÃ¼dpol 20 orthogonal zu der LÃ¤ngsachse 14 ausgerichtet sind.The magnetic gripper 10 has a magnet 16 arranged in the housing 12. The magnet 16 is a permanent magnet. The magnet 16 has a north pole 18 and a south pole 20. A magnetic field 22 of the magnet 16 extends from the north pole 18 to the south pole 20. The magnetic field 22 runs along magnetic field lines 24. The magnet 16 is arranged in the housing 12 such that the north pole 18 and the south pole 20 are aligned orthogonally to the longitudinal axis 14. Der Magnetgreifer 16 hat einen ersten Polschuh 26 und einem zweiten Polschuh 28. Jeder Polschuh 26, 28 ist aus einem ferromagnetischen Material gebildet. In dem dargestellten AusfÃ¼hrungsbeispiel sind die beiden Polschuhe 26, 28 aus Eisen gebildet. Jeder Polschuh 26, 28 ist zur magnetischen Kopplung mit dem Magneten 16 ausgebildet. Jeder Polschuh 26, 28 ist zum FÃ¼hren eines Magnetfeldanteils des Magnetfelds 22 zu dem ferromagnetischen WerkstÃ¼ck fÃ¼r das Greifen des ferromagnetischen WerkstÃ¼cks mittels des Magnetgreifers 10 ausgebildet.The magnetic gripper 16 has a first pole piece 26 and a second pole piece 28. Each pole piece 26, 28 is made of a ferromag

**[p0051]**

netic material. In the illustrated embodiment, the two pole pieces 26, 28 are made of iron. Each pole piece 26, 28 is designed for magnetic coupling to the magnet 16. Each pole piece 26, 28 is designed to guide a magnetic field component of the magnetic field 22 to the ferromagnetic workpiece for gripping the ferromagnetic workpiece by the magnetic gripper 10.

**[p0052]**

Jeder Polschuh 26, 28 ist einteilig ausgebildet. Die beiden Polschuhe 26, 28 sind baugleich. In einem alternativen, nicht dargestellten AusfÃ¼hrungsbeispiel kÃ¶nnen sich die beiden Polschuhe voneinander unterscheiden.Each pole piece 26, 28 is formed as a single piece. The two pole pieces 26, 28 are identical in construction. In an alternative embodiment (not shown), the two pole pieces may differ from each other. Der erste Polschuh 26 und der zweite Polschuh 28 sind an entgegengesetzten Seiten des GehÃ¤uses 12 angeordnet. Der erste Polschuh 26 hat eine Befestigungs-Einrichtung 30 zum Befestigen des ersten Polschuhs 26 an das GehÃ¤use 12. Der zweite Polschuh 28 hat eine Befestigungs-Einrichtung 32 zum Befestigen des zweiten Polschuhs 28 an das GehÃ¤use 12.The first pole piece 26 and the second pole piece 28 are arranged on opposite sides of the housing 12. The first pole piece 26 has a fastening device 30 for fastening the first pole piece 26 to the housing 12. The second pole piece 28 has a fastening device 32 for fastening the second pole piece 28 to the housing 12.

**[p0053]**

Der erste Polschuh 26 und der zweite Polschuh 28 sind jeweils mittels ihrer Befestigungs-Einrichtung 30, 32 an dem GehÃ¤use 12 lÃ¶sbar befestigt. Insbesondere sind die beiden Polschuhe 26, 28 mittels einer Schraubverbindung an dem GehÃ¤use 12 befestigt. Die Schraubverbindung ermÃ¶glicht ein Austauschen der beiden Polschuhe 26, 28.The first pole piece 26 and the second pole piece 28 are each releasably attached to the housing 12 by means of their fastening devices 30, 32. In particular, the two pole pieces 26, 28 are attached to the housing 12 by means of a screw connection. The screw connection enables the two pole pieces 26, 28 to be replaced. Der erste Polschuh 26 hat eine Wirkstruktur 34 zur Magnetfeldlenkung, z.B. zur ErhÃ¶hung einer Haltekraft des Magnetgreifers und/oder zur Reduzierung einer Tiefenwirkung des Magnetfeldanteils. Der zweite Polschuh 28 hat eine Wirkstruktur 36 zur Magnetfeldlenkung, z.B. zur ErhÃ¶hung einer Haltekraft des Magnetgreifers und/oder zur Reduzierung einer Tiefenwirkung des Magnetfeldanteils. Insbesondere sind die Wirkstrukturen 34, 36 jeweils dazu ausgebildet, den von den Polschuhen 26, 28 gefÃ¼hrten Magnetfeldanteil zu fokussieren. Anders formuliert, durch die Wirkstrukturen 34, 36 wird einen Verlauf des Magnetfeldanteils in eine gewÃ¼nschte Richtung gelenkt oder gebÃ¼ndelt.The first pole piece 26 has an active structure 34 for magnetic field steering, e.g., to increase the holding force of the magnetic gripper and/or to reduce the depth effect of the magnetic field component. The second pole piece 28 has an active structure 36 for magnetic

**[p0053]**

field steering, e.g., to increase the holding force of the magnetic gripper and/or to reduce the depth effect of the magnetic field component. In particular, the active structures 34, 36 are each designed to focus the magnetic field component guided by the pole pieces 26, 28. In other words, the active structures 34, 36 direct or focus the magnetic field component in a desired direction.

**[p0054]**

Der erste Polschuh 26 hat eine WerkstÃ¼ck-KontaktflÃ¤che 38 zum Kontaktieren des WerkstÃ¼cks. Die WerkstÃ¼ck-KontaktflÃ¤che 38 des ersten Polschuhs 26 ist als eine zusammenhÃ¤ngende FlÃ¤che ausgebildet. Der zweite Polschuh 28 hat eine WerkstÃ¼ck-KontaktflÃ¤che 40 zum Kontaktieren des WerkstÃ¼cks. Die WerkstÃ¼ck-KontaktflÃ¤che 40 des zweite Polschuh 28 ist als eine zusammenhÃ¤ngende FlÃ¤che ausgebildet.The first pole piece 26 has a workpiece contact surface 38 for contacting the workpiece. The workpiece contact surface 38 of the first pole piece 26 is formed as a continuous surface. The second pole piece 28 has a workpiece contact surface 40 for contacting the workpiece. The workpiece contact surface 40 of the second pole piece 28 is formed as a continuous surface. Die WerkstÃ¼ck-KontaktflÃ¤chen 38, 40 sind jeweils eben ausgebildet. Die WerkstÃ¼ck-KontaktflÃ¤che 38 des ersten Polschuhs 26 bildet ein Ende des ersten Polschuhs 26. Die WerkstÃ¼ck-KontaktflÃ¤che 40 des zweiten Polschuhs 28 bildet ein Ende des zweiten Polschuhs 28.The workpiece contact surfaces 38, 40 are each flat. The workpiece contact surface 38 of the first pole piece 26 forms one end of the first pole piece 26. The workpiece contact surface 40 of the second pole piece 28 forms one end of the second pole piece 28.

**[p0055]**

Die beiden Polschuhe 26, 28 sind derart an dem GehÃ¤use 12 befestigt, dass die WerkstÃ¼ck-KontaktflÃ¤chen 38, 40 der beiden Polschuhe 26, 28 orthogonal zu der LÃ¤ngsachse 14 ausgerichtet sind.The two pole shoes 26, 28 are fastened to the housing 12 in such a way that the workpiece contact surfaces 38, 40 of the two pole shoes 26, 28 are aligned orthogonally to the longitudinal axis 14. Die WerkstÃ¼ck-KontaktflÃ¤che 38 des ersten Polschuhs 26 und die WerkstÃ¼ck-KontaktflÃ¤che 40 des zweiten Polschuhs 28 bilden zusammen eine HalteflÃ¤che 42 des Magnetgreifers 10. Die HalteflÃ¤che 42 kann nur durch die WerkstÃ¼ck-KontaktflÃ¤che 38 des ersten Polschuhs 26 und die WerkstÃ¼ck-KontaktflÃ¤che 40 des zweiten Polschuhs 28 gebildet sein. Die HalteflÃ¤che 42, insbesondere jede WerkstÃ¼ck-KontaktflÃ¤che 38, 40, ist zum berÃ¼hrenden Kontaktieren des ferromagnetischen WerkstÃ¼cks ausgebildet.The workpiece contact surface 38 of the first pole piece 26 and the workpiece contact surface 40 of the second pole piece 28 together form a holding surface 42 of the magnetic gripper 10. The holding surface 42 can be formed only by the workpiece contact surface 38 of the first pole piece 26 and the workpiece contact surface 40 of the second pole piece 28. The holding surface 42, in particular each workpiece contact surface 38, 40, is designed for contacting the ferromagnetic workpiece.

**[p0056]**

Die Wirkstrukturen 34, 36 beeinflussen einen Verlauf des Magnetfeldanteils in den Polschuhen 26, 28. Die Wirkstrukturen 34, 36 sind jeweils dazu ausgebildet, den Magnetfeldanteil von dem Magneten 16 zu den WerkstÃ¼ck-KontaktflÃ¤chen 38, 40 zu fÃ¼hren, insbesondere zu fokussieren.The active structures 34, 36 influence a course of the magnetic field component in the pole pieces 26, 28. The active structures 34, 36 are each designed to guide, in particular to focus, the magnetic field component from the magnet 16 to the workpiece contact surfaces 38, 40. Der Magnet 16 ist zwischen einem Greifzustand zum Greifen des ferromagnetischen WerkstÃ¼cks und einem Freigabezustand zum Freigeben des ferromagnetischen WerkstÃ¼cks Ã¼berfÃ¼hrbar. Das ÃberfÃ¼hren zwischen dem Greifzustand und der Freigabezustand erfolgt durch eine Translationsbewegung des Magneten 16.The magnet 16 can be transferred between a gripping state for gripping the ferromagnetic workpiece and a release state for releasing the ferromagnetic workpiece. The transfer between the gripping state and the release state is achieved by a translational movement of the magnet 16.

**[p0057]**

Die Translationsbewegung ist eine gerade Bewegung. Eine Bewegungsrichtung 44 der geraden Bewegung kann parallel zu der LÃ¤ngsachse 14 ausgerichtet sein. Die gerade Bewegung kann durch eine lineare Verschiebung des Magneten 16 ausgefÃ¼hrt werden.The translational movement is a linear movement. A direction of movement 44 of the linear movement can be aligned parallel to the longitudinal axis 14. The linear movement can be performed by a linear displacement of the magnet 16. Die lineare Verschiebung des Magneten 16 erfolgt mittels eines pneumatischen Antriebs 46 des Magnetgreifers 10. Der pneumatische Antrieb 46 kann einen Kolben, der mit dem Magneten 16 verbunden ist, aufweisen. Das GehÃ¤use 12 hat eine erste Ãffnung 48 und eine zweite Ãffnung 50. Durch die beiden Ãffnungen 48, 50 kann Gas zugefÃ¼hrt werden, um den Kolben und damit den Magneten 16 zwischen dem Freigabezustand und dem Greifzustand Ã¼berzufÃ¼hren.The linear displacement of the magnet 16 is achieved by means of a pneumatic drive 46 of the magnetic gripper 10. The pneumatic drive 46 can comprise a piston connected to the magnet 16. The housing 12 has a first opening 48 and a second opening 50. Gas can be supplied through the two openings 48, 50 to transfer the piston, and thus the magnet 16, between the release state and the gripping state.

**[p0058]**

Durch die Zufuhr von Gas mittels der ersten Ãffnung 48 in einen GehÃ¤useabschnitt oberhalb des Kolbens Ã¼bt das Gas Druck auf eine obere FlÃ¤che des Kolbens aus, wodurch eine nach unten gerichtete Kraft auf den Kolben und damit den Magneten 16 ausgeÃ¼bt wird. Als Reaktion darauf bewegt sich der Kolben und der Magnet 16 entlang der Bewegungsrichtung 44 nach unten, bis der Magnet 16 den Greifzustand einnimmt.By supplying gas through the first opening 48 into a housing section above the piston, the gas exerts pressure on an upper surface of the piston, thereby exerting a downward force on the piston and thus on the magnet 16. In response, the piston and the magnet 16 move downward along the direction of movement 44 until the magnet 16 assumes the gripping state. Durch die Zufuhr von Gas mittels der zweiten Ãffnung 50 in einen GehÃ¤useabschnitt unterhalb des Kolbens Ã¼bt das Gas Druck auf eine untere FlÃ¤che des Kolbens aus, wodurch eine nach oben gerichtete Kraft auf den Kolben und damit den Magneten 16 ausgeÃ¼bt wird. Als Reaktion darauf bewegt sich der Kolben und der Magnet 16 entlang der Bewegungsrichtung 44 nach oben, bis der Magnet 16 den Freigabezustand einnimmt.By supplying gas through the second opening 50 into a housing section below the piston, the gas exerts pressure on a lower surface of the piston, thereby exerting an upward force on the piston and thus on the magnet 16. In response, the piston and the magnet 16 move upward along the direction of movement 44 until the magnet 16 assumes the release state.

**[p0059]**

In 1 ist der Freigabezustand gezeigt. In dem Freigabezustand ist der Magnet 16 innerhalb des GehÃ¤uses 12 derart angeordnet, dass kein Magnetfeldanteil des Magnetfelds 22, der zum Greifen des ferromagnetischen WerkstÃ¼cks geeignet ist, mittels den Polschuhen 26, 28 zu der HalteflÃ¤che 42 gefÃ¼hrt ist. In dem Freigabezustand ist der Magnet 16 nicht zwischen den beiden Polschuhen 26, 28 angeordnet.In 1 The release state is shown. In the release state, the magnet 16 is arranged within the housing 12 such that no magnetic field component of the magnetic field 22 suitable for gripping the ferromagnetic workpiece is guided to the holding surface 42 by means of the pole pieces 26, 28. In the release state, the magnet 16 is not arranged between the two pole pieces 26, 28. In 2 ist der Greifzustand gezeigt. In dem Greifzustand ist der Magnet 16 innerhalb des GehÃ¤uses 12 derart angeordnet, dass ein Magnetfeldanteil des Magnetfelds 22, der zum Greifen des ferromagnetischen WerkstÃ¼cks geeignet ist, mittels den Polschuhen 26, 28 zu der HalteflÃ¤che 42 gefÃ¼hrt ist. In dem Greifzustand ist der Magnet 16 zwischen den beiden Polschuhen 26, 28 angeordnet. In dem Greifzustand wirkt der erste Polschuh 26 als SÃ¼dpol und der zweite Polschuh 28 als Nordpol. In einem alternativen, nicht dargestellten AusfÃ¼hrungsbeispiel wirkt der erste Polschuh als Nordpol und der zweite Polschuh als SÃ¼dpol.In 2 the gripping state is shown. In the gripping state, the magnet 16 is arranged within the housing 12 such that a magnetic field component of the magnetic field 22, which is suitable for gripping the f

**[p0059]**

erromagnetic workpiece, is guided to the holding surface 42 by means of the pole pieces 26, 28. In the gripping state, the magnet 16 is arranged between the two pole pieces 26, 28. In the gripping state, the first pole piece 26 acts as the south pole and the second pole piece 28 acts as the north pole. In an alternative embodiment, not shown, the first pole piece acts as the north pole and the second pole piece acts as the south pole.

**[p0060]**

Weiter zeigt 2 einen Stapel von mehreren WerkstÃ¼cken 52. Die mehreren WerkstÃ¼cke 52 sind Ã¼bereinander angeordnet, insbesondere gestapelt. Dadurch wird ein Stapel aus mehreren WerkstÃ¼cken 52 gebildet.Further shows 2 a stack of several workpieces 52. The several workpieces 52 are arranged one above the other, in particular stacked. This forms a stack of several workpieces 52. Jedes WerkstÃ¼ck 52 ist aus Eisen gebildet. Jedes WerkstÃ¼ck 52 ist ein Blech. Eine Breite und eine LÃ¤nge jedes WerkstÃ¼cks 52 betragen mehr als das FÃ¼nffache einer Dicke des WerkstÃ¼cks 52. In dem dargestellten AusfÃ¼hrungsbeispiel betrÃ¤gt die Dicke jedes WerkstÃ¼cks 52 5 mm. Jedes WerkstÃ¼ck 52 hat eine Beschichtung.Each workpiece 52 is made of iron. Each workpiece 52 is a sheet metal. The width and length of each workpiece 52 are more than five times the thickness of the workpiece 52. In the illustrated embodiment, the thickness of each workpiece 52 is 5 mm. Each workpiece 52 has a coating. Mit dem Magnetgreifer 10 soll das oberste WerkstÃ¼ck 52 von dem Stapel aus mehreren WerkstÃ¼cken 52 gegriffen werden, ohne dabei die Ã¼brigen WerkstÃ¼cke 52 zu greifen. Hierzu wird der Magnet 16 in den Freigabezustand Ã¼berfÃ¼hrt und der Magnetgreifer 10 auf das oberste WerkstÃ¼ck 52 platziert, so dass das oberste WerkstÃ¼ck 52 gegen die HalteflÃ¤che 42 anliegt. Mit anderen Worten, das WerkstÃ¼cks 52 berÃ¼hrt die WerkstÃ¼ck-KontaktflÃ¤che 38 des ersten Polschuhs 26 und die WerkstÃ¼ck-KontaktflÃ¤che 40 des zweiten Polschuhs 28. AnschlieÃend wird der Magnet 16 in den Greifzustand Ã¼berfÃ¼hrt, so dass der von

**[p0060]**

den beiden Polschuhen 26, 28 gefÃ¼hrte Magnetfeldanteils des Magnetfelds 22 ein fÃ¼r das Greifen des WerkstÃ¼cks 52 erforderlicher Anteil des Magnetfelds 22 ist.The magnetic gripper 10 is intended to grip the uppermost workpiece 52 from the stack of multiple workpieces 52 without gripping the remaining workpieces 52. For this purpose, the magnet 16 is transferred to the release state, and the magnetic gripper 10 is placed on the uppermost workpiece 52 such that the uppermost workpiece 52 rests against the holding surface 42. In other words, the workpiece 52 touches the workpiece contact surface 38 of the first pole piece 26 and the workpiece contact surface 40 of the second pole piece 28. The magnet 16 is then transferred to the gripping state, such that the magnetic field component of the magnetic field 22 guided by the two pole pieces 26, 28 is a component of the magnetic field 22 required for gripping the workpiece 52.

**[p0061]**

Durch die Wirkstrukturen 34, 36 wird der Magnetfeldanteil des Magnetfelds 22 derart zu den WerkstÃ¼ck-KontaktflÃ¤chen 38, 40 gefÃ¼hrt, dass auf dem Stapel von mehreren WerkstÃ¼cken 52 eine Magnetkraft wirkt. Die Magnetkraft ist nur fÃ¼r das Greifen des obersten WerkstÃ¼cks 52 geeignet. Mit anderen Worten, die Magnetkraft, die auf das oberste WerkstÃ¼ck 52 wirkt, ist grÃ¶Ãer als eine Gewichtskraft des obersten WerkstÃ¼cks 52. Die Magnetkraft, die auf das unmittelbar unter dem obersten WerkstÃ¼ck 52 liegende WerkstÃ¼ck 52 wirkt, ist fÃ¼r das Greifen dieses WerkstÃ¼cks 52 nicht ausreichend. Mit anderen Worten, die Magnetkraft, die auf das unmittelbar unter dem obersten WerkstÃ¼ck 52 liegende WerkstÃ¼ck 52 wirkt, ist kleiner als die Gewichtskraft dieses WerkstÃ¼cks 52.Through the active structures 34, 36, the magnetic field component of the magnetic field 22 is directed to the Workpiece contact surfaces 38, 40 are guided such that a magnetic force acts on the stack of multiple workpieces 52. The magnetic force is only suitable for gripping the uppermost workpiece 52. In other words, the magnetic force acting on the uppermost workpiece 52 is greater than the weight of the uppermost workpiece 52. The magnetic force acting on the workpiece 52 lying directly beneath the uppermost workpiece 52 is insufficient for gripping this workpiece 52. In other words, the magnetic force acting on the workpiece 52 lying directly beneath the uppermost workpiece 52 is smaller than the weight of this workpiece 52.

**[p0062]**

Durch die Magnetkraft wird das oberste WerkstÃ¼ck 52 gegen die HalteflÃ¤che 42, insbesondere gegen die beiden WerkstÃ¼ck-KontaktflÃ¤chen 38, 40, gedrÃ¼ckt.The magnetic force presses the uppermost workpiece 52 against the holding surface 42, in particular against the two workpiece contact surfaces 38, 40. Durch die Ausbildung der WerkstÃ¼ck-KontaktflÃ¤chen 38, 40 als jeweils zusammenhÃ¤ngende FlÃ¤che, wird erreicht, dass das oberste WerkstÃ¼ck 52 mittels der Magnetkraft flÃ¤chiger gegen die WerkstÃ¼ck-KontaktflÃ¤chen 38, 40 gedrÃ¼ckt wird als bei einem Polschuh ohne zusammenhÃ¤ngender WerkstÃ¼ck-KontaktflÃ¤che. Dadurch kann sich eine gleichmÃ¤Ãigere Druckverteilung auf dem obersten WerkstÃ¼ck 52 ergeben, wodurch die Beschichtung des obersten WerkstÃ¼cks 52 besser vor BeschÃ¤digungen geschÃ¼tzt ist.By designing the workpiece contact surfaces 38, 40 as a continuous surface, the uppermost workpiece 52 is pressed against the workpiece contact surfaces 38, 40 by the magnetic force over a larger area than with a pole piece without a continuous workpiece contact surface. This can result in a more even pressure distribution on the uppermost workpiece 52, which better protects the coating of the uppermost workpiece 52 from damage.

**[p0063]**

In den 3 bis 37 sind verschiedene mÃ¶gliche Varianten des ersten und/oder zweiten Polschuhs 26, 28 gezeigt, wobei fÃ¼r identische und funktionell Ã¤quivalente Elemente gleiche Bezugszeichen verwendet sind, so dass auf die AusfÃ¼hrungen zu den jeweiligen Elementen verwiesen werden kann und im Wesentlichen nur auf die bestehenden Unterschiede der verschiedenen Varianten des dargestellten Polschuhs eingegangen wird.In the 3 to 37 various possible variants of the first and/or second pole shoe 26, 28 are shown, wherein the same reference numerals are used for identical and functionally equivalent elements, so that reference can be made to the explanations for the respective elements and essentially only the existing differences between the various variants of the pole shoe shown are discussed. Aus GrÃ¼nden der Ãbersichtlichkeit werden in diesen Figuren lediglich die Bezugszeichen des ersten Polschuhs 26 verwendet. Der zweite Polschuh 28 kann baugleich zum ersten Polschuhs 26 ausgefÃ¼hrt sein, weshalb in diesem Falle die Beschreibung des ersten Polschuhs 26 entsprechend fÃ¼r den zweiten Polschuh 28 gilt.For reasons of clarity, only the reference numerals of the first pole shoe 26 are used in these figures. The second pole shoe 28 can be constructed identically to the first pole shoe 26, which is why, in this case, the description of the first pole shoe 26 applies accordingly to the second pole shoe 28.

**[p0064]**

3 bis 6 zeigen eine erste Variante des ersten Polschuhs 26 des Magnetgreifers 10. 3 to 6 show a first variant of the first pole shoe 26 of the magnetic gripper 10. 3 zeigt den ersten Polschuhs 26 mit Blickrichtung auf eine Breitseite 54 des ersten Polschuhs 26. 3 shows the first pole piece 26 looking towards a broad side 54 of the first pole piece 26. Die WerkstÃ¼ck-KontaktflÃ¤che 38 verlÃ¤uft orthogonal zu der Breitseite 54. Wenn der erste Polschuh 26 an dem GehÃ¤use 12 befestigt ist, ist die Breitseite 54 dem GehÃ¤use 12 abgewandt.The workpiece contact surface 38 is orthogonal to the broad side 54. When the first pole piece 26 is attached to the housing 12, the broad side 54 faces away from the housing 12. Die Befestigungs-Einrichtung 30 hat zwei DurchgangslÃ¶cher 56. Jedes Durchgangsloch 56 ist fÃ¼r das Aufnehmen einer Befestigungsschraube zum Herstellen der Schraubverbindung zum Zweck des Befestigens des ersten Polschuhs 26 an dem GehÃ¤use 12 geeignet. Jedes Durchgangsloch 56 ist als Senkbohrung ausgebildet.The fastening device 30 has two through holes 56. Each through hole 56 is suitable for receiving a fastening screw for establishing the screw connection for the purpose of fastening the first pole piece 26 to the housing 12. Each through hole 56 is designed as a countersunk bore.

**[p0065]**

Die Wirkstruktur 34 hat eine Anzahl von Ausnehmungen 58. In dem dargestellten AusfÃ¼hrungsbeispiel wird die Wirkstruktur durch sechs Ausnehmungen 58 gebildet. In einem weiteren, nicht dargestellten AusfÃ¼hrungsbeispiel kann die Wirkstruktur durch vier, acht oder zehn Ausnehmungen gebildet sein. Alle Ausnehmungen 58 kÃ¶nnen gleich ausgebildet sein.The active structure 34 has a number of recesses 58. In the illustrated embodiment, the active structure is formed by six recesses 58. In a further embodiment not shown, the active structure can be formed by four, eight, or ten recesses. All recesses 58 can be of the same design. Jede Ausnehmungen 58 weist eine LÃ¤ngsachse 60 auf, entlang der sich die Ausnehmung 58 erstreckt. Die LÃ¤ngsachsen 60 sind parallel und versetzt zueinander ausgerichtet. Die LÃ¤ngsachsen 60 verlaufen parallel zu der WerkstÃ¼ck-KontaktflÃ¤che 38.Each recess 58 has a longitudinal axis 60 along which the recess 58 extends. The longitudinal axes 60 are aligned parallel and offset from one another. The longitudinal axes 60 run parallel to the workpiece contact surface 38.

**[p0066]**

Die LÃ¤ngsachsen 60 kÃ¶nnen eine LÃ¤ngsachsen-Ebene definieren, die parallel und versetzt zu der WerkstÃ¼ck-KontaktflÃ¤che 38 ausgerichtet ist.The longitudinal axes 60 may define a longitudinal axis plane that is aligned parallel and offset to the workpiece contact surface 38. Die Ausnehmungen 58 sind unter Bildung einer Ausnehmungs-Reihe angeordnet. Eine Richtung 62 der Ausnehmungs-Reihe verlÃ¤uft parallel zu der WerkstÃ¼ck-KontaktflÃ¤che 38.The recesses 58 are arranged to form a recess row. A direction 62 of the recess row runs parallel to the workpiece contact surface 38. Jede Ausnehmung 58 hat einen rechteckfÃ¶rmigen, insbesondere quadratischen, Querschnitt.Each recess 58 has a rectangular, in particular square, cross-section. 4 zeigt eine weitere SchrÃ¤gansicht des ersten Polschuhs 26 von 3 mit Blickrichtung auf eine zur Breitseite 54 entgegengesetzten weiteren Breitseite 64. 4 shows another oblique view of the first pole piece 26 of 3 looking towards another broadside 64 opposite broadside 54.

**[p0067]**

Wenn der erste Polschuh 26 an dem GehÃ¤use 12 befestigt ist, ist die weitere Breitseite 64 dem GehÃ¤use 12 zugewandt. Wenn der erste Polschuh 26 an dem GehÃ¤use 12 befestigt ist, kann der erste Polschuh 26 mit einem Bereich der weiteren Breitseite 64 gegen das GehÃ¤use 12 anliegen. Insbesondere kÃ¶nnen Befestigungsschrauben, die in den DurchgangslÃ¶chern 56 angeordnet sind und mit denen der erste Polschuh 26 an dem GehÃ¤use 12 befestigt ist, den Bereich der weiteren Breitseite 64 gegen das GehÃ¤use 12 drÃ¼cken.When the first pole piece 26 is attached to the housing 12, the further broad side 64 faces the housing 12. When the first pole piece 26 is attached to the housing 12, the first pole piece 26 can bear against the housing 12 with a portion of the further broad side 64. In particular, fastening screws arranged in the through-holes 56 and with which the first pole piece 26 is attached to the housing 12 can press the portion of the further broad side 64 against the housing 12. Jedes Durchgangsloch 56 weist eine Senkung 66 auf, die an der weiteren Breitseite 64 angeordnet ist. Anders formuliert, die Senkung 66 ist dem GehÃ¤use 12 zugewandt, wenn der erste Polschuh 26 an dem GehÃ¤use 12 befestigt ist. Die Senkung 66 ist dazu ausgebildet, ein O-Ring aufzunehmen. Der O-Ring kann zum Sichern einer Befestigungsschraube dienen, die in dem Durchgangsloch 56 angeordnet ist.Each through-hole 56 has a countersink 66 arranged on the wider side 64. In other words, the countersink 66 faces the housing 12 when the first pole piece 26 is attached to the housing 12. The counterbore 66 is

**[p0067]**

configured to receive an O-ring. The O-ring can serve to secure a mounting screw disposed in the through-hole 56.

**[p0068]**

Der erste Polschuh 26 hat zwei Zentrierbohrungen 68 zum Aufnehmen von Zylinderstifte des GehÃ¤uses 12. WÃ¤hrend einem Befestigen des ersten Polschuhs 26 an dem GehÃ¤use 12 kÃ¶nnen die Zylinderstifte in die beiden Zentrierbohrungen 68 eingesetzt werden, wodurch ein Ausrichten des ersten Polschuhs 26 relativ zu dem GehÃ¤use 12 erfolgt.The first pole piece 26 has two centering holes 68 for receiving cylindrical pins of the housing 12. During fastening of the first pole piece 26 to the housing 12, the cylindrical pins can be inserted into the two centering holes 68, thereby aligning the first pole piece 26 relative to the housing 12. Der erste Polschuh 26 hat einen gekrÃ¼mmten OberflÃ¤chenabschnitt 70, der an der weiteren Breitseite 64 angeordnet ist. Der gekrÃ¼mmte OberflÃ¤chenabschnitt 70 kann sich bis zur WerkstÃ¼ck-KontaktflÃ¤che 38 erstrecken. Durch den gekrÃ¼mmten OberflÃ¤chenabschnitt 70 kann ein Luftspalt zwischen dem GehÃ¤use 12 und dem ersten Polschuh 26 vermieden werden, wodurch der Magnetfeldanteil des Magnetfelds des Magneten 16 optimal in den ersten Polschuh 26 einkoppelbar ist.The first pole piece 26 has a curved surface section 70 arranged on the further broad side 64. The curved surface section 70 can extend to the workpiece contact surface 38. The curved surface section 70 can prevent an air gap between the housing 12 and the first pole piece 26, thereby optimally coupling the magnetic field component of the magnetic field of the magnet 16 into the first pole piece 26.

**[p0069]**

3 und 4 zeigen, dass die Ausnehmungen 58 den ersten Polschuh 26 durchdringen. Insbesondere durchdringen die Ausnehmungen 58 den ersten Polschuh 26 von der Breitseite 54 bis zu der weiteren Breitseite 64. 3 and 4 show that the recesses 58 penetrate the first pole piece 26. In particular, the recesses 58 penetrate the first pole piece 26 from the broad side 54 to the further broad side 64. Durch die Ausnehmungen 58 wird erreicht, dass der Magnetfeldanteil, der von dem ersten Polschuh 26 gefÃ¼hrt ist und der durch die WerkstÃ¼ck-KontaktflÃ¤che 38 hindurch aus dem ersten Polschuh 26 austritt, in einen Zwischenbereich 72 zwischen den Ausnehmungen 58 gedrÃ¤ngt wird. Dadurch wird der Magnetfeldanteil vor dem Austreten aus der WerkstÃ¼ck-KontaktflÃ¤che 38 mittels den Ausnehmungen 58 fokussiert, wodurch sich eine Haltekraft des Magnetgreifers 10 erhÃ¶ht und eine Tiefenwirkung des Magnetfeldanteils reduziert.The recesses 58 ensure that the magnetic field component guided by the first pole piece 26 and exiting the first pole piece 26 through the workpiece contact surface 38 is forced into an intermediate region 72 between the recesses 58. As a result, the magnetic field component is focused by means of the recesses 58 before exiting the workpiece contact surface 38, thereby increasing the holding force of the magnetic gripper 10 and reducing the depth effect of the magnetic field component.

**[p0070]**

5 zeigt die erste Variante des ersten Polschuhs 26 mit Blickrichtung auf die WerkstÃ¼ck-KontaktflÃ¤che 38. Die WerkstÃ¼ck-KontaktflÃ¤che 38 ist als eine einzige zusammenhÃ¤ngende FlÃ¤che ausgebildet. 5 shows the first variant of the first pole shoe 26 with a view towards the workpiece contact surface 38. The workpiece contact surface 38 is formed as a single, continuous surface. 6 zeigt eine Schnittansicht der ersten Variante des ersten Polschuhs 26 entlang einer Schnittlinie VI-VI gemÃ¤Ã 5. 6 shows a sectional view of the first variant of the first pole piece 26 along a section line VI-VI according to 5 . Jede Ausnehmung 58 hat eine HÃ¶he 74 und eine Breite 76, wobei ein Betrag der HÃ¶he 74 und ein Betrag der Breite 76 gleich sind. Dadurch weist jede Ausnehmung 58 den quadratischen Querschnitt auf.Each recess 58 has a height 74 and a width 76, with an amount of height 74 and an amount of width 76 being equal. Thus, each recess 58 has a square cross-section. Zwei benachbarte Ausnehmungen 58 sind mit einem Abstand 78 voneinander beabstandet. Der Abstand 78 kann gleich der Breite 76 oder gleich der HÃ¶he 74 einer Ausnehmung 58 sein. In dem dargestellten AusfÃ¼hrungsbeispiel ist der Abstand 78 gleich der Breite 76 einer Ausnehmung 58. Alle Ausnehmungen 58 kÃ¶nnen mit einem gleichen Abstand 78 voneinander beabstandet sein.Two adjacent recesses 58 are spaced apart by a distance 78. The distance 78 can be equal to the width 76 or the height 74 of a recess 58. In the illustrated embodiment, the distance 78 is equal to the width 76 of a recess 58. All recesses 58 can be spaced apa

**[p0070]**

rt by the same distance 78.

**[p0071]**

Ein Abstand 80 zwischen den Ausnehmungen 58 und der WerkstÃ¼ck-KontaktflÃ¤che 38 ist geringer als ein Abstand 82 zwischen den Ausnehmungen 58 und der Befestigungs-Einrichtung 30. Der Abstand 80 zwischen den Ausnehmungen 58 und der WerkstÃ¼ck-KontaktflÃ¤che 38 kann einen Betrag in einem Bereich von 1 mm bis 5 mm aufweisen. Der Abstand 82 zwischen den Ausnehmungen 58 und der Befestigungs-Einrichtung 30 kann einen Betrag in einem Bereich von 1 cm bis 6 cm aufweisen.A distance 80 between the recesses 58 and the workpiece contact surface 38 is less than a distance 82 between the recesses 58 and the fastening device 30. The distance 80 between the recesses 58 and the workpiece contact surface 38 can have a value in a range of 1 mm to 5 mm. The distance 82 between the recesses 58 and the fastening device 30 can have a value in a range of 1 cm to 6 cm. Dadurch sind die Ausnehmungen 58 in einem Randbereich 84 des ersten Polschuhs 26 angeordnet, der sich von der WerkstÃ¼ck-KontaktflÃ¤che 38 bis zu einem Drittel einer LÃ¤nge 86 des ersten Polschuhs 26 erstreckt.As a result, the recesses 58 are arranged in an edge region 84 of the first pole shoe 26, which extends from the workpiece contact surface 38 to one third of a length 86 of the first pole shoe 26.

**[p0072]**

7 zeigt eine SchrÃ¤gansicht einer zweiten Variante des ersten Polschuhs 26. Die erste Variante des ersten Polschuhs 26 und die zweite Variante des ersten Polschuhs 26 unterscheiden sich dadurch, dass die Ausnehmungen 58 in der zweiten Variante des ersten Polschuhs 26 als Bohrungen ausgebildet sind. Dadurch weisen die Ausnehmungen 58 einen kreisfÃ¶rmigen Querschnitt auf. Die Ausnehmungen 58 weisen einen gleichen Durchmesser 88 auf. In einem alternativen AusfÃ¼hrungsbeispiel kÃ¶nnen die Ausnehmungen einen voneinander verschiedenen Durchmesser aufweisen. 7 shows an oblique view of a second variant of the first pole piece 26. The first variant of the first pole piece 26 and the second variant of the first pole piece 26 differ in that the recesses 58 in the second variant of the first pole piece 26 are formed as bores. As a result, the recesses 58 have a circular cross-section. The recesses 58 have the same diameter 88. In an alternative embodiment, the recesses can have a different diameter from one another.

**[p0073]**

8 bis 10 zeigen eine dritte Variante des ersten Polschuhs 26 des Magnetgreifers 10. 8 to 10 show a third variant of the first pole shoe 26 of the magnetic gripper 10. 8 zeigt, dass in der dritten Variante des ersten Polschuhs 26 die Wirkstruktur 34 mittels zwei Ausnehmungen 58 gebildet ist. Jede Ausnehmung 58 ist als Bohrungen ausgebildet. Die Ausnehmungen 58 durchdringen den ersten Polschuh 26 von einer Schmalseite 90 des ersten Polschuhs 26 bis zu einer der Schmalseite 90 entgegengesetzten weiteren Schmalseite 92 des ersten Polschuhs 26. 8 shows that in the third variant of the first pole piece 26, the active structure 34 is formed by two recesses 58. Each recess 58 is designed as bores. The recesses 58 penetrate the first pole piece 26 from a narrow side 90 of the first pole piece 26 to a further narrow side 92 of the first pole piece 26 opposite the narrow side 90. Die WerkstÃ¼ck-KontaktflÃ¤che 38 verlÃ¤uft orthogonal zu der Schmalseite 90 und der weiteren Schmalseite 92.The workpiece contact surface 38 runs orthogonally to the narrow side 90 and the further narrow side 92.

**[p0074]**

Die Schmalseite 90 und die weitere Schmalseite 92 verbindet die Breitseite 54 mit der weiteren Breitseite 64. Anders formuliert, die Schmalseite 90 und die weitere Schmalseite 92 sind zwischen der Breitseite 54 und der weiteren Breitseite 64 angeordnet. Die Schmalseite 90 und die weitere Schmalseite 92 weisen jeweils eine Fase 94 auf. Die Fase 94 ist an der Breitseite 54 angeordnet.The narrow side 90 and the further narrow side 92 connect the broad side 54 with the further broad side 64. In other words, the narrow side 90 and the further narrow side 92 are arranged between the broad side 54 and the further broad side 64. The narrow side 90 and the further narrow side 92 each have a chamfer 94. The chamfer 94 is arranged on the broad side 54. 9 zeigt den ersten Polschuhs 26 mit Blick auf die Schmalseite 90 und 10 zeigt eine Schnittansicht des ersten Polschuhs 26 entlang einer Schnittlinie X-X gemÃ¤Ã 9. 9 shows the first pole piece 26 with a view of the narrow side 90 and 10 shows a sectional view of the first pole piece 26 along a section line XX according to 9 .

**[p0075]**

Einer der beiden Ausnehmungen 58 ist durch den gekrÃ¼mmten OberflÃ¤chenabschnitt 70 unterbrochen.One of the two recesses 58 is interrupted by the curved surface section 70. 11 bis 13 zeigen eine vierte Variante des ersten Polschuhs 26 des Magnetgreifers 10. 11 to 13 show a fourth variant of the first pole shoe 26 of the magnetic gripper 10. 11 zeigt, dass in der vierten Variante des ersten Polschuhs 26 die Wirkstruktur 34 mittels sechs Ausnehmungen 58 gebildet ist. Jede Ausnehmung 58 ist als Loch ausgebildet. 11 shows that in the fourth variant of the first pole piece 26, the active structure 34 is formed by six recesses 58. Each recess 58 is designed as a hole. Die Ausnehmungen 58 sind an einer der WerkstÃ¼ck-KontaktflÃ¤che 38 entgegengesetzten Seite 86 angeordnet. Jede Ausnehmung 58 erstreckt sich entlang ihrer LÃ¤ngsachse 60. Die LÃ¤ngsachsen 60 der Ausnehmungen 58 sind orthogonal zu der WerkstÃ¼ck-KontaktflÃ¤che 38 ausgerichtet. Die Ausnehmungen 58 erstrecken sich von der der WerkstÃ¼ck-KontaktflÃ¤che 38 entgegengesetzten Seite 96 auf die WerkstÃ¼ck-KontaktflÃ¤che 38 zu.The recesses 58 are arranged on a side 86 opposite the workpiece contact surface 38. Each recess 58 extends along its longitudinal axis 60. The longitudinal axes 60 of the recesses 58 are aligned orthogonally to the workpiece contact surface 38. The recesses 58 extend from the side 96 opposite the workpiece contact surface 38 toward the workpiece contact surface 38.

**[p0076]**

12 zeigt eine Draufsicht auf den ersten Polschuhs 26 mit Blickrichtung auf die der WerkstÃ¼ck-KontaktflÃ¤che 38 entgegengesetzten Seite 96. Jede Ausnehmung 58 hat einen kreisfÃ¶rmigen Querschnitt. Die Durchmesser 88 der Ausnehmungen 58 unterscheiden sich voneinander. 12 shows a top view of the first pole piece 26, looking toward the side 96 opposite the workpiece contact surface 38. Each recess 58 has a circular cross-section. The diameters 88 of the recesses 58 differ from one another. 13 zeigt eine Schnittansicht des ersten Polschuhs 26 entlang einer Schnittlinie XIII-XIII gemÃ¤Ã 12. Jede Ausnehmung 58 hat einen ebenen Loch-Grund 98. Jede Ausnehmung 58 erstreckt sich derart von der der WerkstÃ¼ck-KontaktflÃ¤che 38 entgegengesetzten Seite 96 auf die WerkstÃ¼ck-KontaktflÃ¤che 38 zu, dass die Ausnehmung 58 die WerkstÃ¼ck-KontaktflÃ¤che 38 nicht durchdringt. Jede Ausnehmung 58, insbesondere jeder Loch-Grund 98, ist von der WerkstÃ¼ck-KontaktflÃ¤che 38 mit dem Abstand 80 beabstandet. 13 shows a sectional view of the first pole piece 26 along a section line XIII-XIII according to 12 Each recess 58 has a flat hole base 98. Each recess 58 extends from the side 96 opposite the workpiece contact surface 38 toward the workpiece contact surface 38 such that the recess 58 does not penetrate the workpiece contact surface 38. Each recess 58, in particular each hole base 98, is spaced from the workpiece contact surface 38 by a distance 80.

**[p0077]**

14 bis 16 zeigen eine fÃ¼nfte Variante des ersten Polschuhs 26 des Magnetgreifers 10. Die Wirkstruktur 34 ist mittels 14 Ausnehmungen 58 gebildet. Jede Ausnehmung 58 ist als Loch mit einem ebenen Loch-Grund 98 ausgebildet. Die Durchmesser 88 der Ausnehmungen 58 sind gleich. Anders formuliert, die Ausnehmungen 58 weisen einen gleichen Durchmesser 88 auf. 14 to 16 show a fifth variant of the first pole piece 26 of the magnetic gripper 10. The active structure 34 is formed by 14 recesses 58. Each recess 58 is designed as a hole with a flat hole base 98. The diameters 88 of the recesses 58 are identical. In other words, the recesses 58 have the same diameter 88. 17 bis 19 zeigen eine sechste Variante des ersten Polschuhs 26 des Magnetgreifers 10. 17 to 19 show a sixth variant of the first pole shoe 26 of the magnetic gripper 10. In der sechsten Variante des ersten Polschuhs 26 ist die Wirkstruktur 34 stufenartig ausgebildet. Die stufenartige Wirkstruktur 34 ist durch eine Anzahl von Stufen 100 gebildet. In dem AusfÃ¼hrungsbeispiel der 17 bis 19 ist die stufenartige Wirkstruktur 34 durch zwei Stufen 100 gebildet. Jede Stufe 100 erstreckt sich von der Schmalseite 90 zu der weiteren Schmalseite 92.In the sixth variant of the first pole piece 26, the active structure 34 is designed in a step-like manner. The step-like active structure 34 is formed by a number of steps 100. In the embodiment of the 17 to 19 The step-like knitted structure 34 is formed by two steps 100. Each step 100 extends from the narrow side 90 to the further narrow side 92.

**[p0078]**

Jede Stufe 100 hat einen zur WerkstÃ¼ck-KontaktflÃ¤che 38 parallelen Verlauf. Jede Stufe 100 wird durch eine OberflÃ¤che 102 des ersten Polschuhs 26 gebildet, die parallel und versetzt zu der WerkstÃ¼ck-KontaktflÃ¤che 38 verlÃ¤uft.Each step 100 extends parallel to the workpiece contact surface 38. Each step 100 is formed by a surface 102 of the first pole piece 26, which extends parallel and offset from the workpiece contact surface 38. Durch die stufenartige Wirkstruktur 34 vergrÃ¶Ãert sich die QuerschnittsflÃ¤che des ersten Polschuhs 26 in eine orthogonal zu der WerkstÃ¼ck-KontaktflÃ¤che 38 verlaufende Richtung, die von der WerkstÃ¼ck-KontaktflÃ¤che 38 auf die Befestigungs-Einrichtung 30 zu gerichtet ist. Das VergrÃ¶Ãern der QuerschnittsflÃ¤che erfolgt unstetig, insbesondere sprungartig. Anders formuliert, durch die stufenartige Wirkstruktur 34 verkleinert sich die QuerschnittsflÃ¤che des ersten Polschuhs 26 unstetig in Richtung auf die WerkstÃ¼ck-KontaktflÃ¤che 38 zu. Durch das Verkleinern der QuerschnittsflÃ¤che kann eine Fokussierung des Magnetfeldanteils erreicht werden, bevor der Magnetfeldanteil durch die WerkstÃ¼ck-KontaktflÃ¤che 38 austritt.Due to the stepped active structure 34, the cross-sectional area of the first pole piece 26 increases in a direction orthogonal to the workpiece contact surface 38, which is directed from the workpiece contact surface 38 toward the fastening device 30. The increase in the cross-sectional area occurs discontinuously, in particular abruptly. In other words, due to the stepped active structure 34, the cross-sectional area of the

**[p0078]**

first pole piece 26 decreases discontinuously in the direction toward the workpiece contact surface 38. By reducing the cross-sectional area, a focusing of the magnetic field component can be achieved before the magnetic field component exits through the workpiece contact surface 38.

**[p0079]**

19 zeigt die sechste Variante des ersten Polschuhs 26 mit Blickrichtung auf die Schmalseite 90. Der erste Polschuhs 26 hat eine Tiefe 104. Die beiden Stufen 100 haben jeweils eine Tiefe 106. Die Tiefen 106 der beiden Stufen 100 sind gleich. Jeder Tiefe 106 der Stufen 100 betrÃ¤gt ein Drittel der Tiefe 104 des ersten Polschuhs 26. 19 shows the sixth variant of the first pole piece 26, viewed from the narrow side 90. The first pole piece 26 has a depth of 104. The two steps 100 each have a depth of 106. The depths 106 of the two steps 100 are equal. Each depth 106 of the steps 100 is one-third of the depth 104 of the first pole piece 26. Die WerkstÃ¼ck-KontaktflÃ¤che 38 hat eine Tiefe 108. Die Tiefe 108 der WerkstÃ¼ck-KontaktflÃ¤che 38 betrÃ¤gt ein Drittel der Tiefe 104 des ersten Polschuhs 26.The workpiece contact surface 38 has a depth of 108. The depth 108 of the workpiece contact surface 38 is one third of the depth 104 of the first pole piece 26. Die beiden Stufen 100 haben jeweils eine AbstufungshÃ¶he 110. Die AbstufungshÃ¶he 110 der beiden Stufen 100 sind gleich. In dem dargestellten AusfÃ¼hrungsbeispiel betrÃ¤gt die AbstufungshÃ¶he 110 1,5 mm. In einem alternativen, nicht dargestellten AusfÃ¼hrungsbeispiel kann die AbstufungshÃ¶he ein Betrag in einem Bereich von 1 mm bis 10 mm, insbesondere 1 mm bis 5 mm, aufweisen.The two steps 100 each have a step height 110. The step height 110 of the two steps 100 is the same. In the illustrated embodiment, the step height 110 is 1.5 mm. In an alternative embodiment not shown, the step height can be in a range from 1 mm to 10 mm,

**[p0079]**

in particular 1 mm to 5 mm.

**[p0080]**

20 bis 22 zeigen eine siebte Variante des ersten Polschuhs 26 des Magnetgreifers 10. 20 to 22 show a seventh variant of the first pole shoe 26 of the magnetic gripper 10. In der siebten Variante des ersten Polschuhs 26 ist die Wirkstruktur 34 eben ausgebildet. Die ebene Wirkstruktur 34 ist durch eine ebene FlÃ¤che 112 gebildet. Die ebene FlÃ¤che 112 weist in Bezug auf die WerkstÃ¼ck-KontaktflÃ¤che 38 einen schrÃ¤gen Verlauf auf. Die ebene FlÃ¤che 112 trifft auf die WerkstÃ¼ck-KontaktflÃ¤che 38 unter Bildung einer Kante 114 des ersten Polschuhs 26. Die Kante 114 erstreckt sich von der Schmalseite 90 zu der weiteren Schmalseite 92. Die Kante 114 ist parallel zu der Breitseite 54 ausgerichtet.In the seventh variant of the first pole piece 26, the active structure 34 is flat. The flat active structure 34 is formed by a flat surface 112. The flat surface 112 has onto the workpiece contact surface 38. The flat surface 112 meets the workpiece contact surface 38, forming an edge 114 of the first pole piece 26. The edge 114 extends from the narrow side 90 to the further narrow side 92. The edge 114 is aligned parallel to the wide side 54.

**[p0081]**

Die Kante 114 kann als stumpfe Kante ausgebildet sein. Unter einer stumpfen Kante kann eine Kante verstanden werden, die durch ein Aufeinandertreffen von WerkstÃ¼ck-KontaktflÃ¤che 38 und ebener FlÃ¤che 112 gebildet wird, wobei ein Betrag eines Winkels 116 zwischen der WerkstÃ¼ck-KontaktflÃ¤che 38 und der ebenen FlÃ¤che 112 grÃ¶Ãer als 90Â° und kleiner als 180Â° ist.The edge 114 can be formed as a blunt edge. A blunt edge can be understood as an edge formed by the intersection of the workpiece contact surface 38 and the flat surface 112, wherein an angle 116 between the workpiece contact surface 38 and the flat surface 112 is greater than 90Â° and less than 180Â°. Die ebene FlÃ¤che 112 ist derart angeordnet, dass sich die QuerschnittsflÃ¤che des ersten Polschuhs 26 in eine orthogonal zur WerkstÃ¼ck-KontaktflÃ¤che 38 verlaufende Richtung, die von der WerkstÃ¼ck-KontaktflÃ¤che 38 auf die Befestigungs-Einrichtung 30 zu gerichtet ist, stetig, insbesondere kontinuierlich, vergrÃ¶Ãert. Anders formuliert, durch die ebene FlÃ¤chen 112 verkleinert sich die QuerschnittsflÃ¤che des ersten Polschuhs 26 stetig in Richtung auf die WerkstÃ¼ck-KontaktflÃ¤che 38 zu. Durch das Verkleinern der QuerschnittsflÃ¤che kann eine Fokussierung des Magnetfeldanteils erreicht werden, bevor der Magnetfeldanteil durch die WerkstÃ¼ck-KontaktflÃ¤che 38 austritt.The flat surface 112 is arranged such that the cross-sectional area of the first pole piece 26 increases steadily, in particular continuously, in a direction orthogonal to the workpiece contact surface 38, which is directed from the workpiece conta

**[p0081]**

ct surface 38 toward the fastening device 30. In other words, the flat surface 112 causes the cross-sectional area of the first pole piece 26 to decrease steadily in the direction toward the workpiece contact surface 38. By reducing the cross-sectional area, a focusing of the magnetic field component can be achieved before the magnetic field component exits through the workpiece contact surface 38.

**[p0082]**

22 zeigt die siebte Variante des ersten Polschuhs 26 mit Blickrichtung auf die Schmalseite 90. Die Tiefe 108 der WerkstÃ¼ck-KontaktflÃ¤che 38 betrÃ¤gt 3,5 mm. Der Winkel 116 zwischen der WerkstÃ¼ck-KontaktflÃ¤che 38 und der ebenen FlÃ¤che 112 betrÃ¤gt 150Â°. 22 shows the seventh variant of the first pole piece 26, viewed from the narrow side 90. The depth 108 of the workpiece contact surface 38 is 3.5 mm. The angle 116 between the workpiece contact surface 38 and the flat surface 112 is 150Â°. 23 zeigt eine achte Variante des Polschuhs 26 mit Blickrichtung auf die Schmalseite 90. Die Tiefe 108 der WerkstÃ¼ck-KontaktflÃ¤che 38 betrÃ¤gt 3,5 mm. Der Winkel 116 zwischen der WerkstÃ¼ck-KontaktflÃ¤che 38 und der ebenen FlÃ¤che 112 betrÃ¤gt 140Â°. 23 shows an eighth variant of the pole piece 26, viewed from the narrow side 90. The depth 108 of the workpiece contact surface 38 is 3.5 mm. The angle 116 between the workpiece contact surface 38 and the flat surface 112 is 140Â°. 24 zeigt eine neunte Variante des Polschuhs 26 mit Blickrichtung auf die Schmalseite 90. Die Tiefe 108 der WerkstÃ¼ck-KontaktflÃ¤che 38 betrÃ¤gt 1,5 mm. Der Winkel 116 zwischen der WerkstÃ¼ck-KontaktflÃ¤che 38 und der ebenen FlÃ¤che 112 betrÃ¤gt 160Â°. 24 shows a ninth variant of the pole piece 26, viewed from the narrow side 90. The depth 108 of the workpiece contact surface 38 is 1.5 mm. The angle 116 between the workpiece contact surface 38 and the flat surface 112 is 160Â°.

**[p0083]**

25 zeigt eine zehnte Variante des Polschuhs 26 mit Blickrichtung auf die Schmalseite 90. Die Tiefe 108 der WerkstÃ¼ck-KontaktflÃ¤che 38 betrÃ¤gt 1,5 mm. Der Winkel 116 zwischen der WerkstÃ¼ck-KontaktflÃ¤che 38 und der ebenen FlÃ¤che 112 betrÃ¤gt 150Â°. 25 shows a tenth variant of the pole piece 26, viewed from the narrow side 90. The depth 108 of the workpiece contact surface 38 is 1.5 mm. The angle 116 between the workpiece contact surface 38 and the flat surface 112 is 150Â°. Die Tiefe der WerkstÃ¼ck-KontaktflÃ¤che 38 kann einen Betrag in einem Bereich von 1 mm bis 4 mm, insbesondere 1,5 mm bis 3,5 mm, aufweisen. Der Winkel 116 zwischen der WerkstÃ¼ck-KontaktflÃ¤che 38 und der ebenen FlÃ¤che 112 kann einen Betrag in einem Bereich von 130Â° bis 170Â°, insbesondere 140Â° bis 160Â°, aufweisen.The depth of the workpiece contact surface 38 can be in a range from 1 mm to 4 mm, in particular 1.5 mm to 3.5 mm. The angle 116 between the workpiece contact surface 38 and the flat surface 112 can be in a range from 130Â° to 170Â°, in particular 140Â° to 160Â°.

**[p0084]**

26 bis 29 zeigen eine elfte Variante des ersten Polschuhs 26 des Magnetgreifers 10. 26 to 29 show an eleventh variant of the first pole shoe 26 of the magnetic gripper 10. Die Wirkstruktur 34 ist im dargestellten Beispiel durch eine Abfolge von Erhebungen 118 und Aussparungen 120 gebildet. Die Abfolge ist dadurch gebildet, dass zwischen zwei benachbarten Erhebungen 118 jeweils eine Aussparung 120 angeordnet ist. Als allgemein vorteilhafte Realisierung der Wirkstruktur 34 kÃ¶nnen stegartige Erhebungen dienen, wofÃ¼r die Erhebungen 118 beispielhafte Realisierungen sind.In the illustrated example, the active structure 34 is formed by a sequence of elevations 118 and recesses 120. The sequence is formed by arranging a recess 120 between each two adjacent elevations 118. A generally advantageous implementation of the active structure 34 can be web-like elevations, for which the elevations 118 are exemplary implementations. Die Aussparungen 120 sind dazu vorgesehen, den Magnetfeldanteil zum FÃ¼hren in die Erhebungen 118 zu drÃ¤ngen. Die Erhebungen 118 sind dazu ausgebildet, den Magnetfeldanteil zu der WerkstÃ¼ck-KontaktflÃ¤che 38 zu fÃ¼hren.The recesses 120 are provided to force the magnetic field component into the elevations 118 for guidance. The elevations 118 are designed to guide the magnetic field component to the workpiece contact surface 38.

**[p0085]**

Die Erhebungen 118 und die Aussparungen 120 sind zwischen der Befestigungs-Einrichtung 30 und der WerkstÃ¼ck-KontaktflÃ¤che 38 angeordnet. Die Erhebungen 118 und die Aussparungen 120 sind, insbesondere nur, an der Breitseite 54 angeordnet. Ein Verlauf jeder Erhebung 118 und jeder Aussparungen 120 ist orthogonal zur der WerkstÃ¼ck-KontaktflÃ¤che 38.The elevations 118 and the recesses 120 are arranged between the fastening device 30 and the workpiece contact surface 38. The elevations 118 and the recesses 120 are arranged, in particular, only on the broad side 54. The course of each elevation 118 and each recess 120 is orthogonal to the workpiece contact surface 38. Jede Erhebung 118 weist eine LÃ¤ngsachse 122 auf, entlang der sich die Erhebung 118 erstreckt. Die LÃ¤ngsachsen 122 der Erhebungen 118 sind parallel und versetzt zueinander ausgerichtet. Die LÃ¤ngsachsen 122 der Erhebungen 118 verlaufen orthogonal zu der WerkstÃ¼ck-KontaktflÃ¤che 38. Die LÃ¤ngsachsen 122 der Erhebungen 118 kÃ¶nnen eine LÃ¤ngsachsen-Ebene definieren, die orthogonal zu der WerkstÃ¼ck-KontaktflÃ¤che 38 ausgerichtet ist.Each protrusion 118 has a longitudinal axis 122 along which the protrusion 118 extends. The longitudinal axes 122 of the protrusions 118 are aligned parallel and offset from one another. The longitudinal axes 122 of the protrusions 118 are orthogonal to the workpiece contact surface 38. The longitudinal axes 122 of the protrusions 118 can define a longitudinal axis plane that is aligned orthogonal to the workpiece contact surface 38.

**[p0086]**

Eine LÃ¤nge 124 der Erhebungen 118 kann einen Wert aufweisen, der in einem Bereich von 50% bis 80%, insbesondere 60% bis 75%, der LÃ¤nge 86 des ersten Polschuhs 26 liegt. In dem dargestellten AusfÃ¼hrungsbeispiel betrÃ¤gt die LÃ¤nge 124 der Erhebungen 118 Zweidrittel der LÃ¤nge des ersten Polschuhs 26.A length 124 of the elevations 118 can have a value that lies in a range of 50% to 80%, in particular 60% to 75%, of the length 86 of the first pole piece 26. In the illustrated embodiment, the length 124 of the elevations 118 is two-thirds of the length of the first pole piece 26. Die Aussparungen 120 sind mit einem Abstand 126 von der WerkstÃ¼ck-KontaktflÃ¤che 38 beabstandet. Der Abstand 126 kann ein Betrag in einem Bereich von 1 mm bis 3 mm aufweisen.The recesses 120 are spaced apart from the workpiece contact surface 38 by a distance 126. The distance 126 can be in a range of 1 mm to 3 mm. 29 zeigt eine Schnittansicht der elften Variante des ersten Polschuhs 26 entlang einer Schnittlinie XXIX-XXIX gemÃ¤Ã 28. 29 shows a sectional view of the eleventh variant of the first pole piece 26 along a section line XXIX-XXIX according to 28 .

**[p0087]**

Jede Aussparung 120 hat eine HÃ¶he 128 und eine Breite 130, wobei ein Betrag der HÃ¶he 128 und ein Betrag der Breite 130 gleich sind. Dadurch weist jede Aussparung 120 einen quadratischen Querschnitt auf.Each recess 120 has a height 128 and a width 130, with an amount of the height 128 and an amount of the width 130 being equal. Thus, each recess 120 has a square cross-section. Zwei benachbarte Aussparungen 120 sind mit einem Abstand 132 voneinander beabstandet. Der Abstand 132 kann gleich einer Breite einer Erhebung 118 sein. Alle Aussparungen 120 kÃ¶nnen mit einem gleichen Abstand 132 voneinander beabstandet sein.Two adjacent recesses 120 are spaced apart by a distance 132. The distance 132 may be equal to the width of a protrusion 118. All recesses 120 may be spaced apart by the same distance 132. Der Abstand 132 zweier benachbarter Aussparungen 120 kann kleiner als die HÃ¶he 128 der Aussparungen 120 sein.The distance 132 between two adjacent recesses 120 may be smaller than the height 128 of the recesses 120.

**[p0088]**

27 und 28 zeigen, dass der erste Polschuh 26 eine Fase 134 aufweist. Die WerkstÃ¼ck-KontaktflÃ¤che 38 ist von der Fase 134 begrenzt. Die Fase 134 umgibt die WerkstÃ¼ck-KontaktflÃ¤che 38 umlaufend. Durch die Fase 134 wird vermieden, dass die WerkstÃ¼ck-KontaktflÃ¤che 38 durch eine Kante, insbesondere eine scharfe Kante, begrenzt ist. 27 and 28 show that the first pole piece 26 has a chamfer 134. The workpiece contact surface 38 is delimited by the chamfer 134. The chamfer 134 circumferentially surrounds the workpiece contact surface 38. The chamfer 134 prevents the workpiece contact surface 38 from being delimited by an edge, in particular a sharp edge. 30 bis 33 zeigen eine zwÃ¶lfte Variante des ersten Polschuhs 26 des Magnetgreifers 10. Im Detail zeigen 30 und 31 jeweils eine SchrÃ¤gansicht, 32 eine Frontansicht und 33 eine Schnittansicht entlang einer Schnittlinie XXXIII-XXXIII gemÃ¤Ã 32. 30 to 33 show a twelfth variant of the first pole shoe 26 of the magnetic gripper 10. In detail 30 and 31 an oblique view each, 32 a front view and 33 a sectional view along a section line XXXIII-XXXIII according to 32 .

**[p0089]**

Die zwÃ¶lfte Variante des ersten Polschuhs 26 und die elfte Variante des ersten Polschuhs 20 unterscheiden sich beispielsweise dadurch, dass die Aussparungen 120 in der zwÃ¶lften Variante des ersten Polschuhs 26 den ersten Polschuh 26 durchdringen. Die Aussparungen 120 durchdringen den ersten Polschuh 26 vollstÃ¤ndig. Anders formuliert, die Aussparungen 120 durchdringen den ersten Polschuh 26 von der Breitseite 54 bis zu der weiteren Breitseite 64.The twelfth variant of the first pole piece 26 and the eleventh variant of the first pole piece 20 differ, for example, in that the recesses 120 in the twelfth variant of the first pole piece 26 penetrate the first pole piece 26. The recesses 120 penetrate the first pole piece 26 completely. In other words, the recesses 120 penetrate the first pole piece 26 from the broad side 54 to the further broad side 64. Weiter hat die zwÃ¶lfte Variante des ersten Polschuhs 26 keine Fase 134. In einem weiteren, nicht dargestellten AusfÃ¼hrungsbeispiel kann der erste Polschuh gemÃ¤Ã der zwÃ¶lften Variante des ersten Polschuhs ausgebildet sein und die Fase aufweisen.Furthermore, the twelfth variant of the first pole shoe 26 has no chamfer 134. In a further embodiment not shown, the first pole shoe can be designed according to the twelfth variant of the first pole shoe and have the chamfer.

**[p0090]**

34 bis 37 zeigen eine dreizehnte Variante des ersten Polschuhs 26 des Magnetgreifers 10. Im Detail zeigen 34 und 35 jeweils eine SchrÃ¤gansicht, 36 eine Frontansicht und 37 eine Schnittansicht entlang einer Schnittlinie XXXVII-XXXVII gemÃ¤Ã 36. 34 to 37 show a thirteenth variant of the first pole shoe 26 of the magnetic gripper 10. In detail 34 and 35 an oblique view each, 36 a front view and 37 a sectional view along a section line XXXVII-XXXVII according to 36 . Die dreizehnte Variante des ersten Polschuhs 26 und die zwÃ¶lfte Variante des ersten Polschuhs 20 unterscheiden sich beispielsweise dadurch, dass jede Aussparung 120 in der dreizehnte Variante des ersten Polschuhs 26 als Langloch ausgebildet ist. Alle LanglÃ¶cher sind gleich ausgebildet.The thirteenth variant of the first pole piece 26 and the twelfth variant of the first pole piece 20 differ, for example, in that each recess 120 in the thirteenth variant of the first pole piece 26 is designed as an elongated hole. All elongated holes are designed identically.

**[p0091]**

36 zeigt, dass jedes Langloch zwei gegenÃ¼berliegende schmale Seiten 136 und zwei gegenÃ¼berliegende LÃ¤ngsseiten 138 hat. Jede schmale Seiten 136 wird durch einen Halbkreis gebildet, dessen Durchmesser gleich eine Breite des Langlochs ist. Die LÃ¤ngsseiten 138 jedes Langloches verlaufen parallel zueinander. 36 shows that each elongated hole has two opposite narrow sides 136 and two opposite long sides 138. Each narrow side 136 is formed by a semicircle whose diameter is equal to the width of the elongated hole. The long sides 138 of each elongated hole run parallel to each other. Die Aussparungen 120 sind derart relativ zueinander angeordnet, dass die LÃ¤ngsseiten 138 parallel zueinander ausgerichtet sind. Die LÃ¤ngsseiten 138 verlaufen orthogonal zu der WerkstÃ¼ck-KontaktflÃ¤che 38.The recesses 120 are arranged relative to one another such that the longitudinal sides 138 are aligned parallel to one another. The longitudinal sides 138 extend orthogonally to the workpiece contact surface 38.

**[p0092]**

Weiter hat die dreizehnte Variante des ersten Polschuhs 26 die Fase 134. Furthermore, the thirteenth variant of the first pole piece 26 has the chamfer 134. 38 und 39 zeigen jeweils eine schematische Ansicht des Magnetgreifers 10 in dem Greifzustand. Der Magnet 16 ist in 38 und 39 jeweils gestrichelt dargestellt. 38 and 39 each show a schematic view of the magnetic gripper 10 in the gripping state. The magnet 16 is in 38 and 39 each shown in dashed lines. Das GehÃ¤use 12 ist mehrteilig ausgebildet. Das GehÃ¤use 12 hat eine mechanische Anbindung 140 zum Befestigen des Magnetgreifers 10 an die Handhabungsvorrichtung. Die Handhabungsvorrichtung kann beispielsweise ein Roboterarm sein. Die mechanische Anbindung 140 ist durch zwei Gewindebohrungen fÃ¼r das Herstellen einer Schraubverbindung zwischen dem Magnetgreifer 10 und der Handhabungsvorrichtung gebildet.The housing 12 is constructed in several parts. The housing 12 has a mechanical connection 140 for attaching the magnetic gripper 10 to the handling device. The handling device can be, for example, a robot arm. The mechanical connection 140 is formed by two threaded holes for establishing a screw connection between the magnetic gripper 10 and the handling device.

**[p0093]**

Die mechanische Anbindung 140 ist in einem Endbereich des Magnetgreifers 10 angeordnet. Der Endbereiche ist an einem den beiden Polschuhen 26, 28 entgegengesetzten Ende des Magnetgreifers 10 angeordnet.The mechanical connection 140 is arranged in an end region of the magnetic gripper 10. The end region is arranged at an end of the magnetic gripper 10 opposite the two pole pieces 26, 28. Der erste Polschuh 26 und der zweite Polschuh 28 sind jeweils entsprechend der in 25 gezeigten zehnten Variante des ersten Polschuhs 26 ausgebildet.The first pole piece 26 and the second pole piece 28 are each arranged in accordance with the 25 shown tenth variant of the first pole piece 26. Der Magnetgreifer 10, insbesondere das GehÃ¤use 12, hat eine Einstellungs-Einrichtung 142 zum Einstellen eines Polschuh-Abstands 144 zwischen dem ersten Polschuh 26 und dem zweiten Polschuh 28 und zum Einstellen eines Magnet-Abstands 146 zwischen dem Magneten 16 in dem Greifzustand und den beiden Polschuhen 26, 28. Durch das Einstellen des Polschuh-Abstands 144 und des Magnet-Abstands 146 kann eine AnteilsgrÃ¶Ãe des Magnetfeldanteils eingestellt werden, die mittels den beiden Polschuhen 26, 28 zu der WerkstÃ¼ck-KontaktflÃ¤che 38 gefÃ¼hrt wird, wenn der Magnet 16 sich in dem Greifzustand befindet.The magnetic gripper 10, in particular the housing 12, has an adjustment device 142 for adjusting a pole shoe distance 144 between the first pole shoe 26 and the second pole shoe 28 and for adjusting a magnet distance 146 between the magnet 16 in the Gripping state and the two pole shoes 26, 28. By adjusting the

**[p0093]**

pole shoe distance 144 and the magnet distance 146, a proportion of the magnetic field component can be adjusted, which is guided to the workpiece contact surface 38 by means of the two pole shoes 26, 28 when the magnet 16 is in the gripping state.

**[p0094]**

Die Einstellungs-Einrichtung 142 kann ein Feststellelement aufweisen zum Feststellen der Einstellungs-Einrichtung 142. Zum VerÃ¤ndern des Polschuh-Abstands 144 und/oder des Magnet-Abstands 146 kann das Feststellelement gelÃ¶st und anschlieÃend der Polschuh-Abstand 144 und/oder der Magnet-Abstand 146 durch Verschieben des ersten Polschuhs 26 und des zweiten Polschuhs 28 eingestellt werden. AnschlieÃend kann das Feststellelement festgestellt werden, um eine ungewollte Verschiebung des ersten Polschuhs 26 und des zweiten Polschuhs 28 zu verhindern.The adjustment device 142 can have a locking element for locking the adjustment device 142. To change the pole shoe spacing 144 and/or the magnet spacing 146, the locking element can be released and then the pole shoe spacing 144 and/or the magnet spacing 146 can be adjusted by moving the first pole shoe 26 and the second pole shoe 28. The locking element can then be locked to prevent unintentional displacement of the first pole shoe 26 and the second pole shoe 28.

**[p0095]**

Das Einstellen des Magnet-Abstands 146 kann durch Verschieben der beiden Polschuhe 26, 28 in eine Richtung erfolgen, die parallel zu der LÃ¤ngsachse 14 des GehÃ¤uses 12 verlÃ¤uft. Das Einstellen des Polschuh-Abstands 144 kann durch Verschieben der beiden Polschuhe 26, 28 in eine Richtung erfolgen, die parallel zu der WerkstÃ¼ck-KontaktflÃ¤che 38 verlÃ¤uft. Beispielsweise kann das Einstellen des Polschuh-Abstands 144 durch ein Auseinanderziehen oder ZusammendrÃ¼cken der beiden Polschuhe 26, 28 erfolgen.The magnet spacing 146 can be adjusted by moving the two pole pieces 26, 28 in a direction parallel to the longitudinal axis 14 of the housing 12. The pole piece spacing 144 can be adjusted by moving the two pole pieces 26, 28 in a direction parallel to the workpiece contact surface 38. For example, the pole piece spacing 144 can be adjusted by pulling the two pole pieces 26, 28 apart or pushing them together. ZITATE ENTHALTEN IN DER BESCHREIBUNGQUOTES CONTAINED IN THE DESCRIPTION Diese Liste der vom Anmelder aufgefÃ¼hrten Dokumente wurde automatisiert erzeugt und ist ausschlieÃlich zur besseren Information des Lesers aufgenommen. Die Liste ist nicht Bestandteil der deutschen Patent- bzw. Gebrauchsmusteranmeldung. Das DPMA Ã¼bernimmt keinerlei Haftung fÃ¼r etwaige Fehler oder Auslassungen.This list of documents submitted by the applicant was generated automatically and is included solely for the convenience of the reader. This list is not part of the German patent or utility model application. The DPMA assumes no liability for any errors or omissions.

**[p0096]**

Zitierte PatentliteraturCited patent literature DE 20 2019 005 976 U1 [0003]DE 20 2019 005 976 U1 [0003]

## Classifications

- B25J15/0608
- B25J15/0608
- B25J15/06
- B25J15/06
- H01F7/02
- H01F7/02
- H01F7/0257
- H01F7/0257
- H01F7/04
- H01F7/04

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
