# 43. A gripping device, a de-palletizing system, a gripping method and a de-palletizing method

- **Archive rank:** 43 of 50
- **Publication:** [WO-2017181337-A1](https://patents.google.com/patent/WO2017181337A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/060115529/publication/WO2017181337A1?q=pn%3DWO2017181337A1)
- **Publication date:** 2017-10-26
- **Filing date:** 2016-04-19
- **Earliest priority:** 2016-04-19
- **Family:** 60115529
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus

## Parties

- **Applicant / assignee:** ABB SCHWEIZ AG; HE GUANGCHUN; QI ZIJIANG; YU DILONG
- **Inventors:** HE GUANGCHUN; QI ZIJIANG; YU DILONG

## Abstract

A gripping device is for taking hold of an article (100) and allowing to transport the article to a desired position, comprising a first clamping unit (1) and a second clamping unit (2). The gripping device further comprises a suction unit (3), wherein the first clamping unit (1) comprises a first clamping board (10) being capable of moving vertically; the second clamping unit (2) comprises a second clamping board (20) being capable of moving horizontally; and the suction unit (3) comprises at least one vacuum sucker (30) being capable of sucking the article (100) to approach the second clamping board (20), therefore making space for the first clamping board (10) to move down until facing the second clamping board (20). Compared with the existing prior arts, the proposed solution enables the gripper to de-palletize irregular corrugated paper reliably, precisely and quickly.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/WO-2017181337-A1/000.png)

![Sketch 1 for WO-2017181337-A1](https://nimo.iptorch.com/refdrawing/WO-2017181337-A1/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/WO-2017181337-A1/001.png)

![Sketch 2 for WO-2017181337-A1](https://nimo.iptorch.com/refdrawing/WO-2017181337-A1/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/WO-2017181337-A1/002.png)

![Sketch 3 for WO-2017181337-A1](https://nimo.iptorch.com/refdrawing/WO-2017181337-A1/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/WO-2017181337-A1/003.png)

![Sketch 4 for WO-2017181337-A1](https://nimo.iptorch.com/refdrawing/WO-2017181337-A1/003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/WO-2017181337-A1/004.png)

![Sketch 5 for WO-2017181337-A1](https://nimo.iptorch.com/refdrawing/WO-2017181337-A1/004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/WO-2017181337-A1/005.png)

![Sketch 6 for WO-2017181337-A1](https://nimo.iptorch.com/refdrawing/WO-2017181337-A1/005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/WO-2017181337-A1/006.png)

![Sketch 7 for WO-2017181337-A1](https://nimo.iptorch.com/refdrawing/WO-2017181337-A1/006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/WO-2017181337-A1/007.png)

![Sketch 8 for WO-2017181337-A1](https://nimo.iptorch.com/refdrawing/WO-2017181337-A1/007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/WO-2017181337-A1/008.png)

![Sketch 9 for WO-2017181337-A1](https://nimo.iptorch.com/refdrawing/WO-2017181337-A1/008.png)

## Claims

### Claim 1 (independent)

A gripping device for taking hold of an article (100) and allowing to transport the article (100) to a desired position, comprising a first clamping unit (1) and a second clamping unit (2) ； characterized in that, the gripping device further comprises a suction unit (3) , wherein the first clamping unit (1) comprises a first clamping board (10) being capable of moving vertically； the second clamping unit (2) comprises a second clamping board (20) being capable of moving horizontally； the first clamping board (10) and the second clamping board (20) are substantially parallel to each other with a gap therebetween to accommodate the article (100) ； the first clamping board (10) and the second clamping board (20) being capable of clamping respective opposed sides of the article (100) so as to grip the article (100) therebetween； and the suction unit (3) comprises at least one vacuum sucker (30) being capable of sucking the article (100) to approach the second clamping board (20) , therefore making space for the first clamping board (10) to move down until facing the second clamping board (20) .

### Claim 2

The gripping device according to claim 1, characterized in that, the first clamping unit (1) further comprises a lifting cylinder (11) , for moving the first clamping board (10) in a vertical direction.

### Claim 3

The gripping device according to claim 1, characterized in that, the first clamping unit (1) further comprises at least one vertical guide rail (12) , for guiding the first clamping board (10) moving along the vertical guide rail (12) .

### Claim 4

The gripping device according to claim 3, characterized in that, the first clamping unit (1) further comprises at least one vertical bracket (13) , each vertical bracket (13) mounting one vertical guide rail (12) thereon.

### Claim 5

The gripping device according to claim 1, characterized in that, the first clamping unit (1) further comprises a bumper (14) , for limiting the predetermined lowest position of the first clamping board (10) and delaying its arrival time to the lowest position.

### Claim 6

The gripping device according to claim 1, characterized in that, the second clamping unit (2) further comprises a clamping cylinder (21) , for moving the second clamping board (20) in a horizontal direction, so as to grip the article (100) between the first clamping board (10) and the second clamping board (20) .

### Claim 7

The gripping device according to claim 6, characterized in that, the second clamping unit (2) further comprises a connector (23) , for connecting the second clamping board (20) to the clamping cylinder (21) .

### Claim 8

The gripping device according to claim 1, characterized in that, the second clamping unit (2) further comprises at least one horizontal guide rail (22) , for guiding the second clamping board (20) moving along the horizontal guide rail (22) .

### Claim 9

The gripping device according to claim 1, characterized in that, the suction unit (3) further comprises a pulling cylinder (31) , for moving the vacuum sucker (30) in a horizontal direction, so as to move the article (100) when it is sucked by the vacuum sucker (30) to approach the second clamping board (20) .

### Claim 10

The gripping device according to claim 1, characterized in that, the suction unit (3) further comprises at least one vacuum generator (32) , each vacuum generator (32) connecting to one vacuum sucker (30) .

### Claim 11

The gripping device according to claim 10, characterized in that, the suction unit (3) further comprises a supporting plate (33) , for mounting the vacuum generator (32) thereon.

### Claim 12

The gripping device according to claim 11, characterized in that, the suction unit (3) further comprises a connecting plate (34) , for mounting the supporting plate (33) to the second clamping board (20) .

### Claim 13

The gripping device according to claim 1, characterized in that, the second clamping board (20) is provided with at least one hole, each hole allowing one vacuum sucker (30) to pass through.

### Claim 14

The gripping device according to claim 1, characterized in that, the gripping device further comprises a coupling plate (40) , for coupling to a robot.

### Claim 15

The gripping device according to claim 1, characterized in that, the first clamping unit (1) and the second clamping unit (2) are both connected to the coupling plate (40) .

### Claim 16

The gripping device according to claim 1, characterized in that, the article (100) is configured to be a box.

### Claim 17

The gripping device according to claim 16, characterized in that, the box (100) comprises a cover.

### Claim 18

A de-palletizing system comprising a robot and the gripping device according to any one of claims 1-17, wherein the gripping device is coupled to the robot and being able to move to a target position by the robot.

### Claim 19

A gripping method by using the gripping device according to any one of claims 1-17, characterized in that, the gripping method comprises the following steps: moving the vacuum sucker (30) to contact the article (100) ； sucking the article (100) by the vacuum sucker (30) ； moving the article (100) by the vacuum sucker (30) to approach the second clamping board (20) , therefore making space for the first clamping board (10) to move down； stopping sucking the article (100) ； moving down the first clamping board (10) until it is facing the second clamping board (20) ； clamping respective opposed sides of the article (100) by the first clamping board (10) and the second clamping board (20) so as to grip the article (100) therebetween.

### Claim 20

The gripping method according to claim 19, characterized in that, after the clamping step, the gripping method further comprises picking up the article (100) and transporting it to a desired position.

### Claim 21

The gripping method according to claim 19, characterized in that, before the sucking step, the gripping method further comprises the following preliminary steps: moving the second clamping board (20) away from the first clamping board (10) ； moving up the first clamping board (10) ； moving the vacuum sucker (30) close to the second clamping board (20) ； moving the gripping device to a preparation position.

### Claim 22

The gripping method according to claim 21, characterized in that, the preparation position is arranged as one side of the article (100) facing the second clamping board (20) and separating from each other, while opposite side of the article (100) adjacent to the bottom end of the first clamping board (10) and allowing the first clamping board (10) to move down.

### Claim 23

A de-palletizing method by using the de-palletizing system according to claim 18, characterized in that, the de-palletizing method comprises the following steps: moving the second clamping board (20) away from the first clamping board (10) ； moving up the first clamping board (10) ； moving the vacuum sucker (30) close to the second clamping board (20) ； moving the gripping device to a preparation position where one side of the article (100) is facing the second clamping board (20) and separating from each other, while opposite side of the article (100) is adjacent to the bottom end of the first clamping board (10) and allowing the first clamping board (10) to move down； moving the vacuum sucker (30) to contact the article (100) ； sucking the article (100) by the vacuum sucker (30) ； moving the article (100) by the vacuum sucker (30) to approach the second clamping board (20) , therefore making space for the first clamping board (10) to move down； stopping sucking the article (100) ； moving down the first clamping board (10) until it is facing the second clamping board (20) ； clamping respective opposed sides of the article (100) by the first clamping board (10) and the second clamping board (20) so as to grip the article (100) therebetween； picking up the article (100) and transporting it to a desired position.

## Full description

**[0001]**

A GRIPPING DEVICE, A DE-PALLETIZING SYSTEM, A GRIPPING METHOD AND A DE-PALLETIZING METHOD

### FIELD OF THE INVENTION

**[0002]**

Embodiments of the present disclosure generally relate to a gripping device, preferably but not exclusively for de-palletizing box with cover, a de-palletizing system comprising the gripping device, preferably but not exclusively with a robot, a gripping method and a de-palletizing method.

### BACKGROUND OF THE INVENTION

**[0003]**

Nowadays, robots are wildly used in many fields. With labor costs increasing and safety consideration, using industrial robots for the production processes has enormous advantages compared with manual work. Using automated equipment or industrial robots to replace human will become the future trend, especially in the de-palletizing industry.

**[0004]**

An intelligent de-palletizing industrial production can be realized by using industrial robots for the production processes such as gripping an article from a storage area and moving it to an assembly area. Basically, industrial robots can be used to control to grasp and move an article. More specifically, the industrial robots can require a gripping device mounted thereon for securely gripping an article and transferring it to the production line.

**[0005]**

In the past, gripping devices have been used to transport articles, e.g. boxes, to desired locations. Generally, as boxes to be gripped or moved are in compact condition, it is difficult to clamp each box from two sides, so traditional gripping devices are designed to catch up boxes from the top. Problems have been encountered in deal with separated boxes (boxes with cover) , because when the cover is picked up from the top, it is difficult to ensure that the main body of the box can also be reliably picked up simultaneously with the cover. Therefore, traditional gripping devices can only achieve integrated boxes gripping and there is a significant restriction in the shape of the separated structure.

**[0006]**

It is known that separated boxes are widely used in the packaging industry for containing the goods, such as meter boxes. As discussed before, it is impossible for traditional gripping devices to handle separated boxes. As a result, in every packaging factory, transferring the separated box to the production line can only rely on manual work. This results in low working efficiency with extra costs.

**[0007]**

Therefore, there is an urgent demand for an automatic separated box de-palletizing system.

### SUMMARY OF THE INVENTION

**[0008]**

To resolve the problem of low working efficiency and high cost of transferring separated boxes manually, an object of the present invention is to provide an intelligent de-palletizing system for handling separated boxes, which also works for integrated boxes.

**[0009]**

To accomplish the foregoing object, according to one aspect of the invention, there is provided a gripping device for taking hold of an article and allowing to transport the article to a desired position, comprising a first clamping unit and a second clamping unit. The gripping device further comprises a suction unit, wherein the first clamping unit comprises a first clamping board being capable of moving vertically； the second clamping unit comprises a second clamping board being capable of moving horizontally； the first clamping board and the second clamping board are substantially parallel to each other with a gap therebetween to accommodate the article； the first clamping board and the second clamping board being capable of clamping respective opposed sides of the article so as to grip the article therebetween； and the suction unit comprises at least one vacuum sucker being capable of sucking the article to approach the second clamping board, therefore making space for the first clamping board to move down until facing the second clamping board.

**[0010]**

According to a preferred embodiment of the present invention, the first clamping unit further comprises a lifting cylinder, for moving the first clamping board in a vertical direction.

**[0011]**

According to a preferred embodiment of the present invention, the first clamping unit further comprises at least one vertical guide rail, for guiding the first clamping board moving along the vertical guide rail.

**[0012]**

According to a preferred embodiment of the present invention, the first clamping unit further comprises at least one vertical bracket, each vertical bracket mounting one vertical guide rail thereon.

**[0013]**

According to a preferred embodiment of the present invention, the first clamping unit further comprises a bumper, for limiting the predetermined lowest position of the first clamping board and delaying its arrival time to the lowest position.

**[0014]**

According to a preferred embodiment of the present invention, the second clamping unit further comprises a clamping cylinder, for moving the second clamping board in a horizontal direction, so as to grip the article between the first clamping board and the second clamping board.

**[0015]**

According to a preferred embodiment of the present invention, the second clamping unit further comprises a connector, for connecting the second clamping board to the clamping cylinder.

**[0016]**

According to a preferred embodiment of the present invention, the second clamping unit further comprises at least one horizontal guide rail, for guiding the second clamping board moving along the horizontal guide rail.

**[0017]**

According to a preferred embodiment of the present invention, the suction unit further comprises a pulling cylinder, for moving the vacuum sucker in a horizontal direction, so as to move the article when it is sucked by the vacuum sucker to approach the second clamping board.

**[0018]**

According to a preferred embodiment of the present invention, the suction unit further comprises at least one vacuum generator, each vacuum generator connecting to one vacuum sucker.

**[0019]**

According to a preferred embodiment of the present invention, the suction unit further comprises a supporting plate, for mounting the vacuum generator thereon.

**[0020]**

According to a preferred embodiment of the present invention, the suction unit further comprises a connecting plate, for mounting the supporting plate to the second clamping board.

**[0021]**

According to a preferred embodiment of the present invention, the second clamping board is provided with at least one hole, each hole allowing one vacuum sucker to pass through.

**[0022]**

According to a preferred embodiment of the present invention, the gripping device further comprises a coupling plate, for coupling to a robot.

**[0023]**

According to a preferred embodiment of the present invention, the first clamping unit and the second clamping unit are both connected to the coupling plate.

**[0024]**

According to a preferred embodiment of the present invention, the article is configured to be a box.

**[0025]**

According to a preferred embodiment of the present invention, the box comprises a cover.

**[0026]**

According to another aspect of the invention, there is provided a de-palletizing system comprising a robot and the gripping device as described above, wherein the gripping device is coupled to the robot and being able to move to a target position by the robot.

**[0027]**

According to another aspect of the invention, there is provided a gripping method by using the gripping device as described above, the gripping method comprises the following steps: moving the vacuum sucker to contact the article； sucking the article by the vacuum sucker； moving the article by the vacuum sucker to approach the second clamping board, therefore making space for the first clamping board to move down； stopping sucking the article； moving down the first clamping board until it is facing the second clamping board； clamping respective opposed sides of the article by the first clamping board and the second clamping board so as to grip the article therebetween.

**[0028]**

According to a preferred embodiment of the present invention, after the clamping step, the gripping method further comprises picking up the article and transporting it to a desired position.

**[0029]**

According to a preferred embodiment of the present invention, before the sucking step, the gripping method further comprises the following preliminary steps: moving the second clamping board away from the first clamping board； moving up the first clamping board； moving the vacuum sucker close to the second clamping board； moving the gripping device to a preparation position.

**[0030]**

According to a preferred embodiment of the present invention, the preparation position is arranged as one side of the article facing the second clamping board and separating from each other, while opposite side of the article adjacent to the bottom end of the first clamping board and allowing the first clamping board to move down.

**[0031]**

According to another aspect of the invention, there is provided a de-palletizing method by using the de-palletizing system as described above, the de-palletizing method comprises the following steps: moving the second clamping board away from the first clamping board； moving up the first clamping board； moving the vacuum sucker close to the second clamping board； moving the gripping device to a preparation position where one side of the article is facing the second clamping board and separating from each other, while opposite side of the article is adjacent to the bottom end of the first clamping board and allowing the first clamping board to move down； moving the vacuum sucker to contact the article； sucking the article by the vacuum sucker； moving the article by the vacuum sucker to approach the second clamping board, therefore making space for the first clamping board to move down； stopping sucking the article； moving down the first clamping board until it is facing the second clamping board； clamping respective opposed sides of the article by the first clamping board and the second clamping board so as to grip the article therebetween； picking up the article and transporting it to a desired position.

**[0032]**

Compared with the existing prior arts, the present invention can provide a de-palletizing system for de-palletizing articles, preferably but not exclusively for separated boxes. The new de-palletizing system enables the gripping device to de-palletize separated boxes precisely and quickly. By using the new solution of de-palletizing separated boxes, the present invention can achieve several advantages as below.

**[0033]**

This new system will improve work efficiency and save manual costs. As the main body of the boxes can be easily apart from the cover when catching from the top, with the present solution of two sides clamping mechanism, boxes with cover can be destacked reliably, precisely and quickly.

**[0034]**

The de-palletizing system structure is simple with convenient maintenance. As every separated box packaging factory may need this de-palletizing system, the system can be quickly switched according to different box model, which has strong adaptability.

**[0035]**

The present invention is in low requirement for the supplied materials with the application of vacuum sucker, which can separate boxes in compact condition that greatly helps to reduce the difficulty of positioning a clamping board into two boxes.

**[0036]**

Other features and advantages of embodiments of the present application will also be understood from the following description of specific exemplary embodiments when read in conjunction with the accompanying drawings, which illustrate, by way of example, the principles of the invention.

### BRIEF DESCRIPTION OF THE DRAWINGS

**[0037]**

The above and other features of the present disclosure will become more apparent through detailed explanation on the embodiments as illustrated in the description with reference to the accompanying drawings, throughout which like reference numbers represent same or similar components and wherein:

**[0038]**

Fig. 1 shows a perspective view of a gripping device according to an embodiment of the present disclosure；

**[0039]**

Fig. 2 shows a front view of a gripping device according to an embodiment of the present disclosure；

**[0040]**

Fig. 3 shows a left view of a gripping device according to an embodiment of the present disclosure；

**[0041]**

Fig. 4 shows a top view of a gripping device according to an embodiment of the present disclosure；

**[0042]**

Fig. 5 illustrates a gripping device in the preparation position according to an embodiment of the present disclosure；

**[0043]**

Fig. 6 shows a front view of a gripping device in the state that the vacuum sucker contacts to the article according to an embodiment of the present disclosure；

**[0044]**

Fig. 7 shows a front view of a gripping device in the state that the article approaches the second clamping board according to an embodiment of the present disclosure；

**[0045]**

Fig. 8 shows a front view of a gripping device in the state that the first clamping board is facing the second clamping board according to an embodiment of the present disclosure；

**[0046]**

Fig. 9 illustrates a gripping device performing the clamping process according to an embodiment of the present disclosure.

**[0047]**

Throughout the figures, same or similar reference numbers indicate same or similar elements.

### DETAILED DESCRIPTION OF PREFERRED EMBODIMENTS

**[0048]**

Hereinafter, solutions as provided the present disclosure will be described in details through embodiments with reference to the accompanying drawings. It should be appreciated that these embodiments are presented only to enable those skilled in the art to better understand and implement the present disclosure, not intended to limit the scope of the present disclosure in any manner.

**[0049]**

Generally, all terms used in the claims are to be interpreted according to their ordinary meaning in the technical field, unless explicitly defined otherwise herein. All references to "a/an/the/said [element, device, component, means, step, etc] " are to be interpreted openly as referring to at least one instance of said element, device, component, means, unit, step, etc., without excluding a plurality of such devices, components, means, units, steps, etc., unless explicitly stated otherwise. Besides, the indefinite article “a/an” as used herein does not exclude a plurality of such steps, units, modules, devices, and objects, and etc.

**[0050]**

Throughout the descriptions of various embodiments of the present application, repeated descriptions of some similar elements will be omitted.

**[0051]**

In general, embodiments of the present application provide a new gripping device for use with a robot to de-palletize articles. As will be apparent from the further discussions below, to improve the work efficiency and reduce unnecessary manual costs, an industrial production system is employed to provide an intelligent sucking and clamping mechanism.

**[0052]**

A de-palletizing system for transporting articles to predetermined locations comprises a robot which carries a gripping device according to the invention. Such gripping device can take hold of the article and move it to a desired target position by the robot. The article may be a box, preferably but not exclusively be a box with cover. A control unit, which may be a general purpose computer, controls the robot in a conventional manner so as to shift the gripping device to a target position. The control unit is also coupled to actuators of the gripping device to control the gripping operation.

**[0053]**

Figs. 1-4 shows a preferred example of the gripping device of the present invention. Fig. 1 is the perspective view, Fig. 2 is the front view, Fig. 3 is the left view and Fig. 4 is the top view of the gripping device. The gripping device comprises a first clamping unit 1, a second clamping unit 2 and a suction unit 3. The first clamping unit 1 comprises a first clamping board 10 which can move vertically. The second clamping unit 2 comprises a second clamping board 20 which can move horizontally. The first clamping board 10 and the second clamping board 20 are substantially parallel to each other with a gap therebetween to accommodate the article 100. The first clamping board 10 and the second clamping board 20 can clamp respective opposed sides of the article 100 so as to grip the article 100 therebetween. The suction unit 3 comprises one or more vacuum suckers, e.g. four suckers to ensure enough suction force. The vacuum suckers can suck the article 100 to approach the second clamping board 20, therefore making space for the first clamping board 10 to move down until facing the second clamping board 20.

**[0054]**

According to some embodiments, the first clamping unit 1 may comprise a lifting cylinder 11, which can move the first clamping board 10 in a vertical direction, as shown in Fig. 3. Moreover, the first clamping unit 1 may comprise one or more vertical guide rails 12, e.g. two rails, for guiding the first clamping board 10 moving along the vertical guide rails 12, as shown in Fig. 3. In addition, the first clamping unit 1 may further comprise one or more vertical brackets 13. Each vertical bracket 13 can mount one vertical guide rail 12 thereon, as shown in Fig. 1.

**[0055]**

In order to better control the movement of the first clamping board 10, the first clamping unit 1 may further comprise a bumper 14, for limiting the predetermined lowest position of the first clamping board 10 and delaying its arrival time to the lowest position, as shown in Fig. 1.

**[0056]**

According to some embodiments, the second clamping unit 2 may comprise a clamping cylinder 21, which can move the second clamping board 20 in a horizontal direction, as shown in Fig. 2. When the gap between the first clamping board 10 and the second clamping board 20 becomes smaller, the article 100 can be gripped therebetween. In addition, the second clamping unit 2 may comprise a connector 23, which can connect the second clamping board 20 to the clamping cylinder 21, as shown in Fig. 1. Moreover, the second clamping unit 2 may comprise one or more horizontal guide rails 22, which can guide the second clamping board 20 moving along the horizontal guide rail 22, as shown in Fig. 2. According to some embodiments, in order to better arrange the suckers, the second clamping board 20 can be provided with holes. Each hole allows one vacuum sucker 30 to pass through.

**[0057]**

According to some embodiments, the suction unit 3 may comprise a pulling cylinder 31, as shown in Fig. 2. The pulling cylinder 31 can move the vacuum sucker 30 in a horizontal direction, so as to move the article 100 when it is sucked by the vacuum sucker 30 to approach the second clamping board 20. In addition, the suction unit 3 may comprise one or more vacuum generators 32, e.g. four generators. Each vacuum generator 32 is connecting to one vacuum sucker 30, as shown in Fig. 1. In order to better position the vacuum generators 32, the suction unit 3 may further comprise a supporting plate 33, for mounting the vacuum generator 32 thereon, as shown in Fig. 1. Moreover, in order to better position the supporting plate 33, the suction unit 3 may further comprise a connecting plate 34, for mounting the supporting plate 33 to the second clamping board 20, as shown in Fig. 2.

**[0058]**

In order to facilitate the movement control, the gripping device may comprise a coupling plate 40, for coupling to a robot. According to some embodiments, the first clamping unit 1 and the second clamping unit 2 can be both connected to the coupling plate 40, as shown in Fig. 1.

**[0059]**

For the person skilled in the art to better understand how to using the de-palletizing system according to the present invention to gripping and de-palletizing the articles, a preferred example is provided referring to Figs. 5-9, showing the steps of sucking and clamping an article.

**[0060]**

Step 1: as shown in Fig. 5, set a gripping device in the preparation status. The preliminary steps includes: moving the second clamping board 20 away from the first clamping board 10； moving up the first clamping board 10； moving the vacuum sucker 30 close to the second clamping board 20； moving the gripping device to a preparation position where one side of the article 100 is facing the second clamping board 20 and separating from each other, while opposite side of the article 100 is adjacent to the bottom end of the first clamping board 10 and allowing the first clamping board 10 to move down.

**[0061]**

Step 2: as shown in Fig. 6, move the vacuum sucker 30 to contact the article 100 and sucking the article 100 by the vacuum sucker 30.

**[0062]**

Step 3: as shown in Fig. 7, move the article 100 by the vacuum sucker 30 to approach the second clamping board 20, therefore making space for the first clamping board 10 to move down. Then stop sucking the article 100.

**[0063]**

Step 4: as shown in Fig. 8, move down the first clamping board 10 until it is facing the second clamping board 20.

**[0064]**

Step 5: as shown in Fig. 9, clamp respective opposed sides of the article 100 by the first clamping board 10 and the second clamping board 20 so as to grip the article 100 therebetween. It is seen that the article 100 can be picked up and transported to a desired position.

**[0065]**

Therefore, the de-palletizing system enables the gripping device to de-palletize separated boxes reliably, precisely and quickly, so as to improve work efficiency and save manual costs.

**[0066]**

Hereinabove, embodiments of the present disclosure have been described in details through embodiments with reference to the accompanying drawings. It should be appreciated that, while this specification contains many specific implementation details, these details should not be construed as limitations on the scope of any invention or of what may be claimed, but rather as descriptions of features that may be specific to particular embodiments of particular inventions. Certain features that are described in this specification in the context of separate embodiments can also be implemented in combination in a single embodiment. Conversely, various features that are described in the context of a single embodiment can also be implemented in multiple embodiments separately or in any suitable sub-combination. Moreover, although features may be described above as acting in certain combinations and even initially claimed as such, one or more features from a claimed combination can in some cases be excised from the combination, and the claimed combination may be directed to a sub-combination or variation of a sub-combination.

**[0067]**

Various modifications, adaptations to the foregoing exemplary embodiments of this disclosure may become apparent to those skilled in the relevant arts in view of the foregoing description, when read in conjunction with the accompanying drawings. Any and all modifications will still fall within the scope of the non-limiting and exemplary embodiments of this disclosure. Furthermore, other embodiments of the disclosures set forth herein will come to mind to one skilled in the art to which these embodiments of the disclosure pertain having the benefit of the teachings presented in the foregoing descriptions and the associated drawings.

**[0068]**

Therefore, it is to be understood that the embodiments of the disclosure are not to be limited to the specific embodiments disclosed and that modifications and other embodiments are intended to be included within the scope of the appended claims. Although specific terms are used herein, they are used in a generic and descriptive sense only and not for purposes of limitation.

## Classifications

- B25J15/0293
- B25J15/06
- B25J15/0616
- B65G2201/025
- B65G47/91
- B65G57/00
- B65G59/00
- B65G61/00

## Cited patent documents

- [CN-103707306-A](https://patents.google.com/patent/CN103707306A/en) — ISR
- [CN-104743356-A](https://patents.google.com/patent/CN104743356A/en) — ISR
- [CN-201058431-Y](https://patents.google.com/patent/CN201058431Y/en) — ISR
- [CN-201634240-U](https://patents.google.com/patent/CN201634240U/en) — ISR
- [CN-201842289-U](https://patents.google.com/patent/CN201842289U/en) — ISR
- [CN-202805189-U](https://patents.google.com/patent/CN202805189U/en) — ISR
- [CN-204160486-U](https://patents.google.com/patent/CN204160486U/en) — ISR
- [JP-H0885087-A](https://patents.google.com/patent/JPH0885087A/en) — ISR
- [JP-H10309686-A](https://patents.google.com/patent/JPH10309686A/en) — ISR

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
