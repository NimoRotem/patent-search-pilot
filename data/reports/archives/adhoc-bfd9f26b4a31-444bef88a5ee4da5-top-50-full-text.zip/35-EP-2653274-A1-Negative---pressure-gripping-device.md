# 35. Negative - pressure gripping device

- **Archive rank:** 35 of 50
- **Publication:** [EP-2653274-A1](https://patents.google.com/patent/EP2653274A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/048082969/publication/EP2653274A1?q=pn%3DEP2653274A1)
- **Publication date:** 2013-10-23
- **Filing date:** 2013-04-08
- **Earliest priority:** 2012-04-19
- **Family:** 48082969
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo

## Parties

- **Applicant / assignee:** KRONES AG
- **Inventors:** EDER CHRISTOPH; KIRSCHNER PETER

## Abstract

The vacuum gripping device (8) has a contact surface (14) for holding objects (16), where the contact surface has a suction opening, which stays in connection with an air duct (22) and a valve (10). The valve has a valve body (26), which is movably arranged within a vacuum chamber (24) located in the air duct. The valve has a modular structure and a sleeve-shaped valve housing (12) with an integrated vacuum chamber for receiving the valve body. The valve body is detachably mounted in the area of the contact surface or a suction plate (18). An independent claim is included for an arrangement for gripping of objects.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/fb/b2/e2/923f80fcfcc8e6/imgf0001.png)

![Sketch 1 for EP-2653274-A1](https://patentimages.storage.googleapis.com/fb/b2/e2/923f80fcfcc8e6/imgf0001.png)

[Sketch 2](https://patentimages.storage.googleapis.com/76/51/8d/2b3824939a7977/imgf0002.png)

![Sketch 2 for EP-2653274-A1](https://patentimages.storage.googleapis.com/76/51/8d/2b3824939a7977/imgf0002.png)

[Sketch 3](https://patentimages.storage.googleapis.com/fb/2b/ec/243274d71952cd/imgf0003.png)

![Sketch 3 for EP-2653274-A1](https://patentimages.storage.googleapis.com/fb/2b/ec/243274d71952cd/imgf0003.png)

[Sketch 4](https://patentimages.storage.googleapis.com/67/28/31/e1596cad173f8e/imgf0004.png)

![Sketch 4 for EP-2653274-A1](https://patentimages.storage.googleapis.com/67/28/31/e1596cad173f8e/imgf0004.png)

[Sketch 5](https://patentimages.storage.googleapis.com/f8/a6/9b/cda105dc29594f/imgf0005.png)

![Sketch 5 for EP-2653274-A1](https://patentimages.storage.googleapis.com/f8/a6/9b/cda105dc29594f/imgf0005.png)

[Sketch 6](https://patentimages.storage.googleapis.com/38/68/84/8827970a60ef4a/imgf0006.png)

![Sketch 6 for EP-2653274-A1](https://patentimages.storage.googleapis.com/38/68/84/8827970a60ef4a/imgf0006.png)

## Claims

### Claim 1 (independent)

Unterdruck-Greifervorrichtung (8) mit einer Kontaktfläche (14) zur Aufnahme von Objekten (16), die wenigstens eine Ansaugöffnung (20) aufweist, die mit einem Luftkanal (22) und einem darin befindlichen Ventil (10) in Verbindung steht, das einen innerhalb einer im Luftkanal (22) befindlichen Unterdruckkammer (24) beweglich angeordneten Ventilkörper (26) mit einer Strömungsblende (28) aufweist, gekennzeichnet durch einen modularen Aufbau des wenigstens einen Ventils (10), das ein hülsenförmiges Ventilgehäuse (12) mit integrierter Unterdruckkammer (24) zur Aufnahme des Ventilkörpers (26) umfasst, welches lösbar im Bereich der Kontaktfläche (14) bzw. Saugplatte (18) montiert ist.A vacuum gripping device (8) having a contact surface (14) for receiving objects (16) having at least one suction port (20) in communication with an air passage (22) and a valve (10) therein a valve body (26) movably arranged within a vacuum chamber (24) located in the air duct (22) and having a flow aperture (28), characterized by a modular construction of the at least one valve (10) having a sleeve-shaped valve housing (12) with integrated vacuum chamber (12). 24) for receiving the valve body (26), which is detachably mounted in the region of the contact surface (14) or suction plate (18).

### Claim 2

Greifvorrichtung nach Anspruch 1, bei der eine mit dem hülsenförmigen Ventilgehäuse (12) korrespondierende Aufnahmeöffnung (36) in der Kontaktfläche (14) oder Saugplatte (18) zur lösbaren Fixierung des Ventilgehäuses (12) vorgesehen ist.Gripping device according to claim 1, wherein a with the sleeve-shaped valve housing (12) corresponding receiving opening (36) in the contact surface (14) or suction plate (18) for releasably fixing the valve housing (12) is provided.

### Claim 3

Greifvorrichtung nach Anspruch 1 oder 2, bei der das Ventilgehäuse (12) mittels einer Rastverbindung in der Kontaktfläche (14) oder Saugplatte (18) montierbar ist.Gripping device according to claim 1 or 2, wherein the valve housing (12) by means of a latching connection in the contact surface (14) or suction plate (18) can be mounted.

### Claim 4

Greifvorrichtung nach einem der Ansprüche 1 bis 3, bei der das Ventilgehäuse (12) eine Aufnahme für den im Ventilgehäuse (12) beweglich angeordneten plattenförmigen Ventilkörper (26) aufweist.Gripping device according to one of claims 1 to 3, wherein the valve housing (12) has a receptacle for the in the valve housing (12) movably arranged plate-shaped valve body (26).

### Claim 5

Greifvorrichtung nach Anspruch 4, bei der das Ventilgehäuse (12) einen in der Aufnahme fixierbaren, insbesondere verrastbaren und gegen eine Haltekraft lösbaren oberen Deckel (60) aufweist, wobei zwischen dem Deckel (60) und der unteren Kontaktfläche (14) der Ventilkörper (26) beweglich angeordnet ist.Gripping device according to Claim 4, in which the valve housing (12) has an upper cover (60) which can be fixed in the receptacle and can be latched and held against a retaining force, the valve body (26) being connected between the cover (60) and the lower contact surface (14) ) is movably arranged.

### Claim 6

Greifvorrichtung nach Anspruch 4 oder 5, bei der das Ventilgehäuse (12) eine konisch zulaufende Innenmantelfläche (52) zur Fixierung des lösbaren und/oder verrastbaren Deckels (60) aufweist.Gripping device according to claim 4 or 5, wherein the valve housing (12) has a tapered inner lateral surface (52) for fixing the detachable and / or latchable lid (60).

### Claim 7

Greifvorrichtung nach einem der Ansprüche 1 bis 6, deren durch mehrere Einschnitte (50) unterbrochene zylindrische Mantelfläche (40) wenigstens zwei Rasthaken (42) bildet, die nach außen weisende Rastnasen (44) zur Verrastung in der Kontaktfläche (14) oder Saugplatte (18) aufweist.Gripping device according to one of claims 1 to 6, whose interrupted by a plurality of incisions (50) cylindrical outer surface (40) at least two latching hooks (42), the outwardly facing latching noses (44) for latching in the contact surface (14) or suction plate (18 ) having.

### Claim 8

Greifvorrichtung nach Anspruch 7, bei der die Rasthaken (42) der Mantelfläche (40) des Ventilgehäuses (12) jeweils weitere Rastnasen (62) aufweisen, die zur Innenmantelfläche (52) weisen und den Deckel (60) im verrasteten Zustand fixieren.Gripping device according to claim 7, wherein the latching hooks (42) of the lateral surface (40) of the valve housing (12) each have further latching lugs (62) facing the inner circumferential surface (52) and fixing the lid (60) in the latched state.

### Claim 9

Greifvorrichtung nach einem der Ansprüche 1 bis 8, bei der das Ventilgehäuse (12) einen Absatz (38, 48) zur Fixierung eines Filters an seiner Stirnfläche aufweist.Gripping device according to one of claims 1 to 8, wherein the valve housing (12) has a shoulder (38, 48) for fixing a filter on its end face.

### Claim 10

Anordnung zum Greifen von Objekten (16), umfassend eine ebene Kontaktfläche (14) oder Saugplatte (18) mit mehreren Greifvorrichtungen (8) bzw. Ventilen (10) gemäß einem der Ansprüche 1 bis 9, die jeweils modular aufgebaut sind und jeweils ein lösbar in der Kontaktfläche (14) oder Saugplatte (18) fixierbares, hülsenartiges Ventilgehäuse (12) mit integrierter Unterdruckkammer (24) zur Aufnahme des Ventilkörpers (26) umfassen.Arrangement for gripping objects (16), comprising a flat contact surface (14) or suction plate (18) with a plurality of gripping devices (8) or valves (10) according to one of claims 1 to 9, each of which has a modular construction and one each detachable in the contact surface (14) or suction plate (18) fixable, sleeve-like valve housing (12) with integrated vacuum chamber (24) for receiving the valve body (26).

## Full description

The present invention relates to a vacuum gripper device (8) having a contact surface (14) for receiving objects (16) having at least one suction opening (20) provided with an air channel (22) and a valve (10) therein Connection having a within a in the air duct (22) located vacuum chamber (24) movably arranged valve body (26) having a flow aperture (28), characterized by a modular construction of the at least one valve (10) having a sleeve-shaped valve housing (12 ) with integrated vacuum chamber (24) for receiving the valve body (26), which is detachably mounted in the region of the contact surface (14).

The present invention relates to a vacuum gripping device having the features of the preamble of claim 1.

There are numerous types of various gripping devices known. A group of gripper devices uses vacuum to pick up objects. Such vacuum gripping devices are often referred to as vacuum grippers. With such grippers, smooth-surfaced objects can be taken up, carried and set down gently again. Known embodiments of these vacuum gripping devices have valve housing with air channels extending therein, at least one vacuum chamber and a valve body arranged therein for closing or releasing an air duct when sucking or depositing the object to be gripped. Such valve variants can be found, for example, in the EP 0 456 884 A2 ,

The DE 697 24 012T2 further discloses a plate-shaped vacuum gripper device having a vacuum chamber connected to a negative pressure generating system. The vacuum plate has a flat lower plate with a plurality of openings, the underside of which is provided with an elastic, airtight bottom. Within the vacuum chamber is a vertically movable ball, which is able to close the opening located in the plate. A bypass channel not captured by the ball should provide a permanent maintenance of the negative pressure in order to lift an article, even if the ball closes the intake passage in the vacuum chamber. As soon as an object to be lifted is detected, the ball drops due to the pressure conditions changing in the vacuum chamber.

A generic vacuum gripping device with a contact surface for receiving objects, which has a plurality of suction ports, which in each case is in communication with an air duct and a valve therein, is finally out of EP 2 361 860 A2 known. There, each of the valves has a valve body movably arranged within the vacuum chamber with a flow diaphragm. In essence, it is a plate-shaped gripper assembly, in which a plurality of such valves are arranged, each having movable valve plate, with which the gripper function is realized.

An object of the present invention is to provide a vacuum gripper device of simple construction and inexpensive to manufacture, to assemble and to maintain, which on the one hand enables a quick suction of articles and objects to be picked up and, on the other hand, their reliable fixation on the gripper device.

To achieve these objects, the present invention proposes a vacuum gripping device with the features of independent claim 1, which has a contact surface for receiving objects and articles, for example. In the form of a lower suction plate, which by placing the gripper device from above with simultaneous Applying a vacuum between the suction plate and the top of the male object to fix the object and thus can absorb. The contact surface or suction plate has at least one suction opening, which is in communication with an air channel and a valve associated with this air channel, which has a valve body arranged movably within a vacuum chamber located in the air channel with a flow aperture. The valve body is preferably substantially free to move between two end positions within the vacuum chamber, so that it can release the openings of the air duct as needed or largely close with the help of the flow restrictor to allow the gripper device to respond sensitively as soon as the contact surface on an upper side of a Object is placed in order to accommodate this with sufficient holding power can. The present invention is essentially modular valve assemblies in which each valve comprises a sleeve for receiving a valve body or a valve plate. Assembled and, for example, mounted in the plate, this creates a valve that is used for flow limitation. By attaching the valve body or valve plate on the holding plate on which a seal is preferably attached, the flow restriction is produced. The sleeve can be inserted into a hole and removed from there again, for example, for maintenance purposes. On the sleeve molded barbs or locking hooks can create a releasable locking connection and prevent the sleeve from falling out of their mounting hole.

The modular valve assembly according to the invention, which essentially comprises a valve sleeve latchable with the contact surface, a support plate or the like, with a valve body movable therein, requires a corresponding receiving opening in the flat or plate-shaped contact surface or in the carrier plate in which the valve sleeve is detachably inserted can be, in particular by a locking connection. To this It is advantageous if the valve housing has a cylindrical contour or a sleeve-like contour. In addition, the valve housing must be shaped so that it forms a receptacle for the plate-shaped valve body. A further advantageous embodiment variant can provide that the valve sleeve has a shoulder for fixing a filter on its end face. This filter can be formed, for example, by a filter disk or the like, which is arranged on the front side on the contact surface with the object to be picked up. The filter serves primarily to prevent the unwanted suction of foreign bodies and particles.

The valve sleeve of the gripping device may in particular have a conically tapered inner lateral surface for fixing the valve body, so that the valve body movably arranged in the valve body or the valve plate is prevented from falling out as soon as the valve sleeve is mounted in the contact surface. In this case, the bore diameter of the sleeve may be smaller than the diameter of the valve plate, which can be achieved by a slight deformation of the shell sides of the valve sleeve after insertion into the corresponding recording of the contact surface. Preferably, however, the valve housing has a fixable in the receptacle, in particular lockable and releasable against a holding force upper lid, which forms an upper limit to the vertical mobility of the valve body or valve plate, so that it is movably disposed between the detachable lid and the lower contact surface , The good mountability of the individual components can, for example, be ensured by the fact that the valve housing has a tapered inner lateral surface for fixing the detachable and / or latchable lid. Thus, in a variant of the gripping device according to the invention whose interrupted by several cuts cylindrical lateral surface form at least three latching hooks, which have outwardly facing locking lugs for latching in the contact surface or suction plate. These latching hooks may possibly have a dual function by suitable barbs or latching hooks on the sleeve can serve to produce the desired releasable latching connection and prevent the valve housing from falling out of the contact surface or support plate. The latching takes place here by elastic deformation of the wall sections of the valve sleeve, which may be slotted in the longitudinal direction, if necessary, or may have suitable recesses in order to facilitate the latching or the release of the latching connection.

In addition, the latching hooks of the lateral surface of the valve housing may each have further locking lugs facing the inner circumferential surface and fix the lid in the latched state. The mountability of the lid is typically only at disassembled, not yet latched in the contact surface or support plate state of the valve housing given because the wall sections for insertion of the valve body and in particular for locking the lid must escape to the outside so that it can be pushed over the inwardly facing further locking lugs in its final position. Once the lid is mounted and holds the valve body and the valve plate in its intended position, designed as latching hook wall portions can yield elastically inward, so that the outer locking lugs can be pushed over the receiving opening in the contact surface or support plate and locked there.

The housing of the modular valve, which is essentially formed by the valve sleeve, can in particular be made of an at least slightly elastically deformable plastic, for example of an injection-molded component. However, the housing may also be formed from a suitable metal such as an aluminum alloy or from a suitable die-cast material.

The invention further comprises an arrangement for gripping objects, which is formed from a flat contact surface with a plurality of valves according to one of the previously described embodiments, which are each modular and each one releasably fixable in the contact surface valve sleeve with integrated vacuum chamber for receiving the valve body or Include valve plate.

The vacuum gripper device according to the invention enables the rapid detection and recording of objects to be gripped. These can be fixed very reliably, which results in particular from the fact that unoccupied suction are largely closed and thus the total vacuum or the entire vacuum built-up does not drop too much or even collapses. The valve body is in a first end position at an upper opening of the opening into the vacuum chamber air duct and closes it largely to the predetermined by the permeable flow aperture air intake. In its first end position, the valve body is sucked by the pressure prevailing in the air channel vacuum to the upper opening of the air channel. In its second end position, the valve body rests on an inner side of the contact surface with the at least one intake opening located therein while largely freeing the opening cross section of the at least one intake opening. The valve body may in particular be formed by a flat valve plate having at least one bore therein as a flow diaphragm. In this variant, the valve body is formed as a flat disc which extends within the Can move vacuum chamber between the two end positions up and down to control the located in the gripper device valve as needed.

The present invention avoids the disadvantages of the known gripping devices, namely the complex assembly of the individual valve assemblies and their poor accessibility for maintenance purposes. The sleeve of the valve according to the invention is a part of the valve assembly. It has, for example, a cylindrical shape and allows the insertion of the valve plate and the attachment of a retaining plate to which a seal is attached. On the end face of the sleeve may be a paragraph in which a filter can be inserted. In order to prevent falling out of the valve plate, the bore is tapered in the direction of paragraph. The structure of the valve assembly can in particular in the EP 2361860 A2 similar valve or correspond. The valve plate of the module according to the invention can not fall into the sleeve, since the bore diameter of the sleeve is smaller than the diameter of the valve plate. A backlash allows clever handling the insertion of the valve plate.

The sleeve has barbs for the valve plate and the heel for the filter element. The barbs prevent the built-in valve assembly from falling out. To facilitate assembly, three grooves are mounted longitudinally. The recesses allow an elastic deformation of the webs on the sleeve. As a result, the assembly (pressing the valve) and disassembly (levering with a flat-head screwdriver) of the valve assembly with little effort is possible.

The modular valve has several advantages and improvements over the prior art, such as improved serviceability of the valve assembly. By "clicking in and out" of the valves, each valve can be levered out of its bore one at a time. Disassembly of a plate, which is responsible for holding the valve plate, is not necessary. Also, the valve assembly is easier to install due to their structure. In addition, the manufacture of the valve assembly can be done in stock. Prefabricated valves allow a cost effective valve.

Fig. 1 zeigt in drei Schnittansichten die verschiedenen Zustände eines erfindungsgemäßen Ventils bei der Annäherung an ein Objekt und bei dessen Kontaktierung.

Fig. 2 zeigt in drei Ansichten den Aufbau eines Ventilgehäuses und seine Montierbarkeit in einer Saugplatte einer Greifvorrichtung.

Fig. 3 zeigt in drei Ansichten die Gestaltung von Einzelkomponenten des Ventilgehäuses gemäß Fig. 2.

Fig. 4 zeigt in insgesamt fünf verschiedenen Ansichten die miteinander verbindbaren Einzelkomponenten des Unterdruckventils.

Fig. 1 shows in three sectional views of the various states of a valve according to the invention in the approach to an object and its contacting.

Fig. 2 shows in three views the construction of a valve housing and its mountability in a suction plate of a gripping device.

Fig. 3 shows in three views the design of individual components of the valve housing according to Fig. 2 ,

Fig. 4 shows in a total of five different views, the interconnectable individual components of the vacuum valve.

For identical or equivalent elements of the invention, identical reference numerals are used. Furthermore, for the sake of clarity, only reference symbols are shown in the individual figures, which are required for the description of the respective figure. The illustrated embodiments are merely examples of how the device or method of the invention may be configured and are not an exhaustive limitation.

Based on the schematic sectional views of Figures 1a, 1b and 1c the basic operation of a vacuum valve 10 is explained, which forms the essential part of a vacuum gripper device 8 not shown here in its entirety. The valve 10 and the gripper device 8 have a valve housing 12 and a lower contact surface 14 arranged thereon for receiving objects 16. This contact surface 14 is referred to in the present context as the lower suction plate 18. The contact surface 14 or suction plate 18 may have a greater extent (see. Fig. 2 ) and preferably a plurality of such valves 10 which are mounted in a regular arrangement and spaced from each other there. In the exemplary embodiment shown, the contact surface 14 has one or more suction openings 20, which communicate with an air channel 22 arranged in the valve housing 12. Between the suction plate 18 and the air channel 22 is a vacuum chamber 24, within which a movably arranged valve body 26 is arranged with a flow aperture 28. The plate-shaped or disc-shaped valve body 26 with the flow aperture 28 arranged centrally therein is designed as a flat valve plate 30 or as a valve plate in the illustrated embodiment, which is delimited both on the upper side of the vacuum chamber 24 and on the lower side, which is bounded by the suction plate 18. can rest in a sealing manner. The valve plate 30 is thus substantially freely movable between two end positions within the vacuum chamber 24, so that it can release or close the opening of the air duct 22 as needed in order to allow the gripper device 8 to respond sensitively as soon as the contact surface 14 is placed on an upper side of the object 16 in order to be able to absorb it with sufficient holding force.

Although the flow aperture 28 in the illustrated embodiment of FIGS. 1a to 1c As a central bore in the valve plate 30 is shown, so this is not a restriction on the possible variety of variants. Basically, the flow restrictor 28 may have any conceivable shape, size and arrangement in the valve plate 30 and in the movable valve body 26. The design of the flow restrictor 28 may depend on the requirements of the particular valve 10 and its design.

The air duct 22 and other, not shown here, air ducts of several such valves 10 is / are connected to a vacuum source. The gripper device 8 may optionally be formed by arranging a plurality of suction openings 20 or valves 10 as a surface gripper, as so-called. Suction spider or as a suction bar o. The like. In the area of the suction openings 20 or around them, elastic elements may be provided for better sealing of the contact surface 14 resting on the objects 16 and their suction openings 20. These optional, not shown here, elastic elements may act as suction cups in cooperation with the intake ports 20.

The valve body 26 and the valve plate 30 is in a first end position (see. Fig. 1a ) at the upper opening of the opening into the vacuum chamber 24 air duct 22 and closes it to the predetermined by the permeable flow aperture 28 air intake. In its first end position, the valve body 26 is sucked by the pressure prevailing in the air duct 22 negative pressure to the upper opening of the air channel 22. In its second end position (cf. Fig. 1 c) the valve body 26 is located on an inner side of the contact surface 14 with the intake openings 20 located therein while largely freeing the opening cross-section of the two intake openings 20.

The representations of the Fig. 1 illustrate the process of contacting and receiving an object 16 by means of the gripper device 8 according to the invention Fig. 1 a is the valve body 26 and the valve plate 30 while at its first, upper end position at the upper opening of the opening into the vacuum chamber 24 air duct 22 and closes it to the cross section of the permeable flow restrictor 28 largely until the contact surface 14 or suction plate 18 from the top to that gripping object 16 is placed (see. Fig. 1 b) whereby the volume of air within the vacuum chamber 24 is largely evacuated via the flow aperture 28 and the valve body 26 and the valve plate 30 falls down into the second end position on the inside of the contact plate 14 or suction plate 18. As a result, the negative pressure for holding and carrying the object 16 is held over the larger cross section of the air channel 22 (cf. Fig. 1c ). For the operation and the basic structure of the valve is otherwise on the EP 2 361 860 A2 directed.

The schematic views of Fig. 2 illustrate a variant of a detachable in the contact plate 14 or suction plate 18 mountable vacuum valve 10, the valve housing 12 a to the object (see. Fig. 1 ) facing and has largely flush with the bottom 32 of the suction plate 18 final frontal contact surface 34. For defined mountability of the valve housing 12 in a corresponding receiving opening 36 of the suction plate 18, the valve 10 and its cylindrically shaped valve housing 12 has a shoulder 38 which has a slightly larger diameter than the diameter of the receiving opening 36 corresponding jacket surface 40 of the valve housing 12 , The side view of Fig. 2a and the perspective rear view of Fig. 2c illustrate the assembled state of the valve housing 12, the cylindrical lateral surface 40 comprises a total of three latching hooks 42, the outwardly facing locking lugs 44 hook or lock in the assembled state on the back 46 of the suction plate 18. During assembly by inserting the valve housing 12 into the receiving opening 36 (see. Fig. 2b ), the latching hooks 42 are bent slightly inward, since the locking lugs 44 must pass through the opening 36. Normally, a plurality of such valves 10 are in receiving openings 36 of the suction plate 18. Die in Fig. 2c shown perspective view of the assembled valve 10 can also recognize an already mounted cover 60, which is inserted in the back of the valve housing 12.

The schematic views of Fig. 3 show in several detail views of an exemplary construction of the valve housing 12, the annular shoulder 38 is provided on the bottom with its frontal contact surface 34 with a recessed heel 48 for insertion of a filter, not shown here. The different views of the Fig. 3a (schematic side view), the Fig. 3b (Section view AA off Fig. 3a ) and the Fig. 3c (Perspective view) illustrate again the components of the valve housing 12. The three views can be the annular shoulder 38 and the three latching hooks 42 recognize with their outwardly facing locking lugs 44. The three latching hooks 42 are each separated by cuts 50, the recesses of the Forming lateral surface 40 of the valve housing 12, in particular the Fig. 3c clearly recognizable. The sections 50 of the lateral surface 40 of the valve housing 12 which are separated from one another by the incisions 50 have a slight elasticity, so that the sections designated as latching hooks 42 for the assembly of the valve housing 12 (cf. Fig. 2b ) can be easily pressed inwards, the outwardly facing locking lugs 44 act on the upper edges of the latching hooks 42 as barbs and accordingly Fig. 2a engage on the back 46 of the contact surface 14 or suction plate 18.

By manufacturing the valve housing 12 from a suitable plastic, the latching hooks 42 have the required for easy mounting in the suction plate 18 elasticity. However, the valve housing 12 may also be formed of a suitable metal such as. An aluminum alloy or of a suitable die-cast material, whereby also the necessary rigidity and elasticity of the latching hook 42 can be secured, provided that the material thickness is selected accordingly.

The in the Fig. 3b Particularly clear tapered inner circumferential surface 52 of the valve housing 12 allows the insertion of the valve plate 30 (see. Fig. 1 ) and its subsequent fixing by a latched in the inner circumferential surface 52 cover 60, which in the inserted state hinted in the Fig. 2c is recognizable. The in the representations of the Fig. 4 in detail recognizable cover (see. Fig. 4b . Fig. 4c ) has a with the inner circumferential surface 52 of the valve housing 12 and with the recesses 50 between the locking hooks 42 corresponding contour so that it is pressed under slight elastic deformation of the latching hooks 42 outwardly into his seat and then below the inner surface 52 facing further locking lugs 62 (cf. Fig. 3c ) can lock. These further locking lugs 62 are located below the outwardly facing locking lugs 44, so that the latching hooks 42 can be easily pushed inward even when the lid 60 inserted when the valve 10 is to be used in the completed state in the receiving opening 36 of the suction plate 18 (see , Fig. 2 ).

The bore diameter of the inner lateral surface 52 is greater than the outer diameter of the valve plate 30 so that it can easily move in the valve housing 12. In contrast, the Au βendurchmesser of the lid 60 is preferably slightly larger than the bore diameter of the inner circumferential surface 52, so that the lid 60 can be kept there under tension and is prevented from falling out. A detectable below the locking hooks 42 and the cuts 50 rear turn 54 (see. Fig. 3c ) forms the further latching lugs 62 on the latching hooks 42 and in the lower

Area of the inner circumferential surface 52 and makes it possible to hold the valve plate 30 in the sleeve of the valve housing 12 by the lid 60 is latched after insertion into the valve housing 12 below the rear turn 54. As mentioned above, the front-side shoulder 48 serves to receive a filter element, not shown here, which can be inserted there. The front suction bore 56 forms the suction port 20 accordingly Fig. 1 , An optional chamfer 58 on the back of the front heel 38 may facilitate disassembly of the valve housing 12 from the suction plate 18, as the chamfer 58 may facilitate or facilitate prying with a slotted screwdriver.

The total of five different views of Fig. 4 show the interconnectable individual components of the vacuum valve 10, which consists essentially of the valve housing 12 (FIG. Fig. 4a ), the valve body 26 in the form of the housing 12 vertically movable valve plate 30 ( Fig. 4b ) and with the valve housing 12 latched lid 60 ( Fig. 4d, Fig. 4e ) is formed.

The Fig. 4a shows a perspective view of the completed and partially assembled valve 10, by the cylindrical valve housing 12, in the inner circumferential surface 52 (see. Fig. 3c ) received valve plate 30 ( Fig. 4b ) and by the back with the other locking lugs 62 of the latching hook 42 latched lid 60 ( Fig. 4d, Fig. 4e ) is formed. The FIGS. 4a and Fig. 3c allow the interrupted by a total of three cuts 50 lateral surface 52 of the valve housing 12, so that a total of three latching hooks 42 for receiving the valve plate 30, for fixing the lid 60 and for locking the entire valve 10 in the contact surface 14 or suction plate 18 are available , In order to be able to releasably latch the valve 10 in the suction plate 18, the three latching hooks interrupted by the three cuts 50 each have outwardly facing latching lugs 44 for latching in the receiving opening 36 of the contact surface 14 or suction plate 18 (cf. Fig. 4a . Fig. 3c ).

As already on the basis of FIGS. 3b and 3c has been explained, the latching hooks 42, which form the shell 40 of the valve housing 12, in the inner circumferential surface 52 each further latching lugs 62 which point to the inner circumferential surface 52, are lower than the outer locking lugs 44 are arranged and the lid 60 in the latched state below Fix back turn 54. As the Figures 4d and 4e clarify, the cover 60 has a contour corresponding to the contour of the valve housing 12 with a total of three short wings 64 having a larger outer diameter than the diameter of the inner circumferential surface 52 of the valve housing 12 so that they each fit into the recesses 50 and received there while the rest Area of the lid 60 corresponds to the inner circumferential surface 52 and can be accommodated largely free of play in the background rotation 54 when the lid 60 is pressed all the way down. The wings 64 are in this position on each of the cylindrical lower portion of the housing shell 40, which is below the rear turn 54 and below the incisions 50 (see. Fig. 3b, Fig. 3c ), so that a lower stop for the inserted lid 60 is formed.

The plate-shaped cover 60 further has a central bore 66, which is surrounded at the bottom facing the valve body 26 by a sealing ring 68, so that the valve body 26 may be sealingly there when no body is sucked on the underside of the valve 10. In this position, the valve body 26 and the valve plate 30 is sucked upwards against the sealing ring 68 of the lid 60, so that only the small central flow aperture 28 remains free from the air openings of the valve plate 30 and allows air to pass (cf. Fig. 4c ). This valve state corresponds to that in the Fig. 1a shown state without directly on the suction plate 18 fitting object 16, so that the lower intake ports 20 are indeed free, but only a small amount of suction through the flow aperture 28 of the valve body 26 can happen. More circular segment-shaped air openings 70 are corresponding in this position Fig. 1a closed at the sealing ring 68 of the lid 60 valve body 26 by the sealing ring 68, so that only a small amount of suction air through the central flow aperture 28 in the valve body 26 and the valve plate 30 can flow.

The invention has been described with reference to a preferred embodiment. However, it will be apparent to those skilled in the art that modifications or changes may be made to the invention without departing from the scope of the following claims.

## Classifications

- B25J15/0625
- B25J15/06
- B65G47/91
- B65G47/91

## Cited patent documents

- [DE-19817217-C1](https://patents.google.com/patent/DE19817217C1/en) — SEA
- [DE-69724012-T2](https://patents.google.com/patent/DE69724012T2/en) — APP
- [EP-0456884-A2](https://patents.google.com/patent/EP0456884A2/en) — APP
- [EP-2361860-A2](https://patents.google.com/patent/EP2361860A2/en) — APP,SEA
- [FR-2709478-A1](https://patents.google.com/patent/FR2709478A1/en) — SEA
- [US-4703966-A](https://patents.google.com/patent/US4703966A/en) — SEA
- [US-4787662-A](https://patents.google.com/patent/US4787662A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
