# 22. Greifeinheit für das Vakuumgehäuse einer Aufnahmevorrichtung

- **Archive rank:** 22 of 50
- **Publication:** [DE-9304906-U1](https://patents.google.com/patent/DE9304906U1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/006891475/publication/DE9304906U1?q=pn%3DDE9304906U1)
- **Publication date:** 1993-09-09
- **Filing date:** 1993-03-31
- **Earliest priority:** 1993-03-31
- **Family:** 6891475
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** KUHNKE GMBH KG H

## Abstract

_No abstract was available from the queried sources._

## Sketches and drawings

_No digitized sketch link was returned._

## Claims

### Claim 1 (independent)

Greifeinheit für das Vakuumgehäuse einer Aufnahmevorrichtung zum Umladen von insbesondere aus Formmassen hergestellten Gegenständen, aufweisend einen an dem Vakuumgehäuse in vertikaler Richtung bewegbar montierten Stößel mit einem Aufnahmesauger an seinem Unterende, wobei der Sauger an das in dem Vakuumgehäuse herrschende Vakuum anschließbar ist, dadurch gekennzeichnet, daß der Stößel (3) aus einem in seiner oberen Endstellung in das Vakuumgehäuse (1) hineinragenden, in dessen Unterwandung (7) gleitend befestigbaren, längeren, oben offenen Zylinderkörper (4) und aus einer Ventileinrichtung (5) besteht, die im Innern des Zylinderkörpers (4) vorgesehen ist und diesen gegenüber seinem Unterende normal geschlossen hält.1. Gripping unit for the vacuum housing of a receiving device for transferring objects made in particular from molding compounds, having a plunger mounted on the vacuum housing so as to be movable in the vertical direction and having a receiving suction device at its lower end, the suction device being connectable to the vacuum prevailing in the vacuum housing, characterized in that the plunger (3) consists of a longer, open-topped cylinder body (4) which, in its upper end position, projects into the vacuum housing (1) and can be slidably fastened in its lower wall (7), and of a valve device (5) which is provided inside the cylinder body (4) and keeps it normally closed relative to its lower end.

### Claim 2

Greifeinheit nach Anspruch 1, dadurch gekennzeichnet, daß sie vertikal frei beweglich ausgebildet ist und daß der Außendurchmesser des Zylinderkörpers (4) so gewählt ist, daß die bei geschlossener Ventileinrichtung (5) aus dem Betriebsunterdruck des Vakuumgehäuses (1) resultierende und auf die Greifeinrichtung (2) wirkende äußere Druckkraft der Atmosphäre wenigstens die lastfreie Greifeinrichtung in ihre obere Endstellung im Vakuumgehäuse (1) zurückbewegt.2. Gripping unit according to claim 1, characterized in that it is designed to be freely movable vertically and that the outer diameter of the cylinder body (4) is selected such that the external pressure force of the atmosphere resulting from the operating negative pressure of the vacuum housing (1) when the valve device (5) is closed and acting on the gripping device (2) moves at least the load-free gripping device back to its upper end position in the vacuum housing (1).

### Claim 3

Greifeinheit nach Anspruch 1 oder 2, dadurch gekennzeichnet, daß die Ventileinrichtung (5) aus einer elektromagnetischen Ventileinrichtung besteht.3. Gripping unit according to claim 1 or 2, characterized in that the valve device (5) consists of an electromagnetic valve device.

### Claim 4

Greifeinheit nach Anspruch 1, 2 oder 3, dadurch gekennzeichnet, daß der Zylinderkörper (4) an seinem Unterende einen Deckelabschluß (8) aufweist, der innenseitig mit einem Ventilsitz (11) für den Ventilkörper (13) der Ventileinrichtung (5) und außenseitig mit einem Stutzen (9) für den Aufnahmesauger (10) versehen ist.

### Claim 104

Gripping unit according to claim 1, 2 or 3, characterized in that the cylinder body (4) has at its lower end a cover closure (8) which is provided on the inside with a valve seat (11) for the valve body (13) of the valve device (5) and on the outside with a nozzle (9) for the receiving suction cup (10). 10 Greifeinheit nach Anspruch 1 mit einem Antrieb, dadurch gekennzeichnet, daß der Antrieb für den Zylinderkörper (4) aus einem in der Oberwandung (19) des Vakuumgehäuses (1) befestigbaren fluidischen Antrieb (20) der Hubzylinderbauart besteht.5. Gripping unit according to claim 1 with a drive, characterized in that the drive for the cylinder body (4) consists of a fluidic drive (20) of the lifting cylinder type which can be fastened in the upper wall (19) of the vacuum housing (1). Greifeinheit nach Anspruch 5, dadurch gekennzeichnet, daß die Ventileinrichtung (5) des Zylinderkörpers (4) aus einer mechanischen Ventileinrichtung besteht, dessen Ventilkörper (30) durch die Kolbenstange (25) des fluidischen Antriebes (20) betätigbar ist.6. Gripping unit according to claim 5, characterized in that the valve device (5) of the cylinder body (4) consists of a mechanical valve device, the valve body (30) of which can be actuated by the piston rod (25) of the fluidic drive (20). Greifeinheit nach Anspruch 6, dadurch gekennzeichnet, daß die mechanische Ventileinrichtung aus einem in Nähe des offenen Oberendes des Zylinderkörpers (4) innen befestigten Ventilsitzring (29) und aus einemk daran anliegenden plattenförmigen, an der Kolbenstange (25) des fluidischen Antriebes (20) befestigten Ventilkörper (30) besteht.7. Gripping unit according to claim 6, characterized in that the mechanical valve device consists of a valve seat ring (29) fastened inside near the open upper end of the cylinder body (4) and of a plate-shaped valve body (30) resting thereon and fastened to the piston rod (25) of the fluidic drive (20). Greifeinheit nach Anspruch 5, 6 oder 7, dadurch gekennzeichnet, daß eine an dem unteren Abschlußbauteil (21) des fluidischen Antriebes (20) und an dem oberen Abschnitt des Zylinderkörpers (4) anliegenden, den Zylinderkörper bei sich abwärts bewegender KoI-8. Gripping unit according to claim 5, 6 or 7, characterized in that a gripping device which is located on the lower end component (21) of the fluidic drive (20) and on the upper section of the cylinder body (4) and which grips the cylinder body when the piston moves downwards benstange (25) des Antriebes (20) nach unten bewegende Druckfeder (33) angeordnet ist.A compression spring (33) is arranged which moves downwards on the drive rod (25) of the drive (20). Greifeinheit nach einem der Ansprüche 5 bis 8, dadurch gekennzeichnet, daß zwischen dem unteren Abschlußbauteil (21) des fluidischen Antriebes (20) und dem Oberende des Zylinderkörpers (4) ein elastischer Dichtungsring (32) vorgesehen ist.9. Gripping unit according to one of claims 5 to 8, characterized in that between the lower end component (21) of the fluidic drive (20) and the upper end of the cylinder body (4) an elastic sealing ring (32) is provided. Greifeinheit nach einem der Ansprüche 5 bis 9, dadurch gekennzeichnet, daß der fluidische Antrieb (20) eine Druckfeder (26) für die Rückstellung der Kolbenstange (25) aufweist.10. Gripping unit according to one of claims 5 to 9, characterized in that the fluidic drive (20) has a compression spring (26) for returning the piston rod (25). Greifeinheit nach einem der Ansprüche 2 bis 10, dadurch gekennzeichnet, daß die Unterwandung (19) des Vakuumgehäuses (1) eine Gleitlagerbuchse (6) für die Aufnahme und Führung des Zylinderkörpers (4) aufweist.11. Gripping unit according to one of claims 2 to 10, characterized in that the bottom wall (19) of the vacuum housing (1) has a plain bearing bush (6) for receiving and guiding the cylinder body (4).

## Full description

PERFORMING OPERATIONS; TRANSPORTINGHAND TOOLS; PORTABLE POWER-DRIVEN TOOLS; MANIPULATORSTOOLS OR BENCH DEVICES NOT OTHERWISE PROVIDED FOR, FOR FASTENING, CONNECTING, DISENGAGING, OR HOLDINGWork holders not covered by any preceding group in the subclass, e.g. magnetic work holders, vacuum work holdersVacuum work holdersVacuum work holders portable, e.g. handheldPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippers

Description

Translated from German

Anmelder: KUHNKE GmbHApplicant: KUHNKE GmbH

LÃ¼tjenburger StraÃe 101

2427 MalenteLÃ¼tjenburger Strasse 101

2427 Malente

Greifeinheit fÃ¼r das VakuumgehÃ¤use

einer AufnahmevorrichtungGripping unit for the vacuum housing

a recording device

Die Erfindung betrifft eine Greifeinheit fÃ¼r das VakuumgehÃ¤use einer

Aufnahmevorrichtung zum Umladen von insbesondere aus Formmassen hergestellten GegenstÃ¤nden, aufweisend einen an dem VakuumgehÃ¤use

in vertikaler Richtung bewegbar montierten StÃ¶Ãel mit einem Aufnahmesauger an seinem Unterende, wobei der Sauger an das in

dem VakuumgehÃ¤use herrschende Vakuum anschlieÃbar ist.The invention relates to a gripping unit for the vacuum housing of a

receiving device for transferring objects made in particular from molding compounds, comprising a plunger mounted on the vacuum housing so as to be movable in the vertical direction and having a receiving suction cup at its lower end, wherein the suction cup can be connected to the vacuum prevailing in the vacuum housing.

Aufnahmevorrichtungen, die mit solchen Greifeinheiten bestÃ¼ckt werden bzw. sind, werden z.B. zum Umladen von aus beispielsweise

keramischen Massen bestehenden Formungen, wie z.B. Teller, Schalen

oder dergleichen, verwendet, die auf eine oder von einer Palette aufge- bzw. abgeladen werden sollen. Das VakuumgehÃ¤use der Aufnahmevorrichtungen

besitzt eine Vielzahl solcher Greifeinheiten, die nach einem vorbestimmten Muster daran angeordnet sind und den

oder die Formlinge ergreifen, wenn das VakuumgehÃ¤use darÃ¼ber abgesenkt worden ist. Dabei setzen sich einige der Greifeinheiten auf

dem oder den Formungen auf, wÃ¤hrend andere freibleiben, weil sich unter ihnen keine Formlinge befinden. Die Greifeinheiten selbst

bestehen aus einem Hubmagnet und einem damit verbundenen StÃ¶Ãel, der an seinem Unterende einen Sauger trÃ¤gt. Der StÃ¶Ãel hat eine

innere Bohrung, die einerseits mit dem Sauger in Verbindung stehtPick-up devices that are or are equipped with such gripping units are used, for example, for reloading moldings made of ceramic masses, such as plates, bowls or the like, which are to be loaded or unloaded onto or from a pallet. The vacuum housing of the pick-up devices has a large number of such gripping units that are arranged on it according to a predetermined pattern and grip the molding or moldings when the vacuum housing has been lowered over it. Some of the gripping units sit on the molding or moldings, while others remain free because there are no moldings underneath them. The gripping units themselves consist of a lifting magnet and a plunger connected to it, which has a suction cup at its lower end. The plunger has an internal bore that is connected to the suction cup on the one hand.

und andererseits an den Unterdruck des VakuumgehÃ¤uses anschlieÃbar

ist. Aufgrund des Hubmagneten kann der StÃ¶Ãel nur einen relativ kleinen Hubweg ausfÃ¼hren, so daÃ die Formlinge in ihrem Erfassungsbereich

nur einen geringen HÃ¶henunterschied aufweisen dÃ¼rfen, der dem Hubweg der StÃ¶Ãel entspricht. Der Anwendungsbereich der

Aufnahmevorrichtungen ist somit begrenzt. Ein weiterer Nachteil besteht darin, daÃ stromstarke Hubmagnete fÃ¼r den StÃ¶Ãel der Greifeinheiten

erforderlich sind, um die Formlinge anheben zu kÃ¶nnen. Demzufolge entwickeln die Hubmagnete eine sehr starke VerlustwÃ¤rme,

die ferner zu unverhÃ¤ltnismÃ¤Ãig vielen HubmagnetausfÃ¤llen fÃ¼hrt, so daÃ die Funktionssicherheit der Aufnahmevorrichtung beeintrÃ¤chtigt

ist. AuÃerdem haben die starken Hubmagnete einen hohen Stromverbrauch zur Folge.and on the other hand can be connected to the vacuum of the vacuum housing. Due to the lifting magnet, the ram can only perform a relatively small stroke, so that the moldings in their gripping area can only have a small height difference that corresponds to the stroke of the ram. The application area of the holding devices is therefore limited. A further disadvantage is that high-current lifting magnets are required for the ram of the gripping units in order to be able to lift the moldings. As a result, the lifting magnets develop a very high level of heat loss, which also leads to a disproportionate number of lifting magnet failures, so that the functional reliability of the holding device is impaired. In addition, the strong lifting magnets result in high power consumption.

Die Aufgabe der Erfindung besteht darin, eine Greifeinheit der einleitend angefÃ¼hrten Art so zu verbessern, daÃ mit ihr grÃ¶Ãere

HÃ¼be durchgefÃ¼hrt werden kÃ¶nnen und daÃ die Funktionssicherheit einer solchen Greifeinheit wesentlich erhÃ¶ht ist.The object of the invention is to improve a gripping unit of the type mentioned in the introduction so that larger strokes can be carried out with it and that the functional reliability of such a gripping unit is significantly increased.

Die LÃ¶sung dieser Aufgabe ist in dem Anspruch 1 angegeben.The solution to this problem is specified in claim 1.

Die erfindungsgemÃ¤Ãe Greifeinheit kann durch einfache Konstruktion

einen grÃ¶Ãeren Hubweg zurÃ¼cklegen, so daÃ mit ihr Formlinge erfaÃt und angehoben werden kÃ¶nnen, deren Erfassungsbereich relativ groÃe

HÃ¶henunterschiede aufweisen, wodurch der Anwendungsbereich einer entsprechend ausgerÃ¼steten Aufnahmevorrichtung erheblich vergrÃ¶Ãert

ist. Im wesentlichen kann die gesamte LÃ¤nge des StÃ¶Ãels der Greifeinheit als Hubweg ausgenutzt werden, da eine Vertikalbewegung des

StÃ¶Ãels mittels eines Hubmagneten entfÃ¤llt. Praktisch hÃ¤ngt die LÃ¤nge des StÃ¶Ãels nur von dem Abstand zwischen Ober- und Unterwand

des VakuumgehÃ¤uses ab, so daÃ im Prinzip sehr lange Hubwege mÃ¶glich sind, die 100 mm und mehr betragen kÃ¶nnen. Ein weite-The gripping unit according to the invention can, thanks to its simple construction, cover a longer stroke, so that it can grip and lift moldings whose gripping range has relatively large height differences, which significantly increases the application area of a suitably equipped holding device. Essentially, the entire length of the gripping unit's ram can be used as a stroke, since vertical movement of the ram by means of a lifting magnet is eliminated. In practice, the length of the ram depends only on the distance between the top and bottom walls of the vacuum housing, so that in principle very long strokes are possible, which can be 100 mm or more. A further

rer Vorteil liegt in der verbesserten Funktionssicherheit der Greifeinheit

bzw. der damit ausgerÃ¼steten Aufnahmevorrichtung, denn wegen der fehlenden starken Hubmagnete sind auch keine entsprechend

groÃe WÃ¤rmeentwicklung und dadurch bedingte FunktionsausfÃ¤lle mehr vorhanden. Dementsprechend ist auch der hohe Stromverbrauch

gesenkt. Wenn die Ventileinrichtung innerhalb des den Aufnahmesauger tragenden ZylinderkÃ¶rpers elektromagnetischer Bauart ist, so

braucht nur die geringe Stromenergie fÃ¼r das Ãffnen und SchlieÃen der Ventileinrichtung aufgebracht zu werden. Des weiteren ist die

erfindungsgemÃ¤Ãe Greifeinheit einfach im Aufbau und kann mit wenigen Bauteilen kostengÃ¼nstig hergestellt werden.Another advantage is the improved functional reliability of the gripping unit or the receiving device equipped with it, because the lack of strong lifting magnets means that there is no longer any correspondingly high heat development and the resulting malfunctions. The high power consumption is also reduced accordingly. If the valve device within the cylinder body carrying the suction cup is of electromagnetic design, only a small amount of electrical energy needs to be applied to open and close the valve device. Furthermore, the gripping unit according to the invention is simple in construction and can be manufactured inexpensively with just a few components.

In einer bevorzugten Ausgestaltung der erfindungsgemÃ¤Ãen Greifeinheit

ist deren stÃ¶Ãelbildender ZylinderkÃ¶rper im AuÃendurchmesser so gewÃ¤hlt, daÃ die bei geschlossener Ventileinrichtung aus dem

Betriebsunterdruck des VakuumgehÃ¤uses resultierende und auf die Greifeinheit wirkende Ã¤uÃere Kraft der AtmosphÃ¤re wenigstens die

lastfreie Greifeinheit anhebt. Hierbei besteht die Ventileinrichtung im Innern des Zylinders vorzugsweise aus einem Elektromagnetventil. In

diesem Fall ist kein besonderer Antrieb fÃ¼r die lastfreie Greifeinheit

erforderlich, um diese wieder in ihre eingezogene obere End- und Ruhestellung zurÃ¼ckzubringen. Dies wird durch den Druckunterschied

bewirkt, der zwischen dem AtmosphÃ¤rendruck auÃerhalb des VakuumgehÃ¤uses und dem demgegenÃ¼ber niedrigeren Betriebsdruck innerhalb

des VakuumgehÃ¤uses gegeben ist, so daÃ die grÃ¶Ãere Ã¤uÃere Kraft die Greifeinheit automatisch in das VakuumgehÃ¤use zurÃ¼ckschiebt.

In a preferred embodiment of the gripping unit according to the invention, the outside diameter of the plunger-forming cylinder body is selected such that the external force of the atmosphere, which results from the operating negative pressure of the vacuum housing when the valve device is closed and acts on the gripping unit, lifts at least the load-free gripping unit. In this case, the valve device inside the cylinder preferably consists of an electromagnetic valve. In this case, no special drive is required for the load-free gripping unit in order to return it to its retracted upper end and rest position. This is brought about by the pressure difference that exists between the atmospheric pressure outside the vacuum housing and the lower operating pressure inside the vacuum housing, so that the greater external force automatically pushes the gripping unit back into the vacuum housing.

Die Erfindung ist nachstehend anhand zweier in den anliegenden Zeichnungen dargestellter AusfÃ¼hrungsbeispiele nÃ¤her erlÃ¤utert. Es

zeigen:The invention is explained in more detail below using two embodiments shown in the accompanying drawings.

Show:

Figur 1 einen vertikalen LÃ¤ngsschnitt durch das erste AusfÃ¼hrungsbeispiel,

Figure 1 shows a vertical longitudinal section through the first embodiment,

Figur 2 einen vertikalen LÃ¤ngsschnitt durch das zweite AusfÃ¼hrungsbeispiel,

Figure 2 shows a vertical longitudinal section through the second embodiment,

Figur 3 einen vertikalen Teilschnitt durch das zweite AusfÃ¼hrungsbeispiel

in vergrÃ¶Ãertem MaÃstab.Figure 3 shows a vertical partial section through the second embodiment

on an enlarged scale.

Die nachstehend im einzelnen erlÃ¤uterten Greifeinheiten werden bei

bekannten Aufnahmevorrichtungen zum Umladen von insbesondere aus Formmassen, z.B. keramischen Formmassen, hergestellten Formungen,

wie z.B. Teller, Schalen und dergleichen, verwendet. Derartige Aufnahmevorrichtungen, die nicht Gegenstand der vorliegenden

Erfindung sind, weisen ein an einem in der HÃ¶he und in der horizontalen

Ebene verstellbaren Schwenkarm angeordnetes VakuumgehÃ¤use 1 auf. Dieses GehÃ¤use wird je nach Betriebsablauf an eine Vakuumquelle

angeschlossen, welche fÃ¼r die Funktion der Greifeinheiten, die nach einem vorbestimmten Muster an dem VakuumgehÃ¤use 1 befestigt

sind, benÃ¶tigt wird.The gripping units explained in detail below are used in known receiving devices for transferring moldings made in particular from molding compounds, e.g. ceramic molding compounds, such as plates, bowls and the like. Such receiving devices, which are not the subject of the present invention, have a vacuum housing 1 arranged on a swivel arm that is adjustable in height and horizontally. Depending on the operating sequence, this housing is connected to a vacuum source, which is required for the function of the gripping units, which are attached to the vacuum housing 1 according to a predetermined pattern.

GemÃ¤Ã dem AusfÃ¼hrungsbeispiel nach Figur 1 besteht die allgemein mit 2 bezeichnete Greifeinheit aus einem StÃ¶Ãel 3, der sich aus

einem ZylinderkÃ¶rper 4 und einer darin angeordneten Ventileinrichtung 5 zusammensetzt. Der aus einem RohrstÃ¼ck hergestellte ZylinderkÃ¶rper

4 ist an seinem Unterende zur vertikalen FÃ¼hrung der Greifeinheit 2 in einer Gleitlagerbuchse 6 gelagert, die wiederum an

der Unterwandung 7 des VakuumgehÃ¤uses 1 befestigt ist. Der ZylinderkÃ¶rper 4 weist an seinem Unterende einen DeckelabschluÃ 8 auf,

der auÃenseitig mit einem Stutzen 9 fÃ¼r die Befestigung eines Aufnahmesaugers 10 versehen ist. Auf der Innenseite ist der Deckel-According to the embodiment shown in Figure 1, the gripping unit, generally designated 2, consists of a plunger 3, which is made up of a cylinder body 4 and a valve device 5 arranged therein. The cylinder body 4, made from a piece of pipe, is mounted at its lower end in a plain bearing bush 6 for vertical guidance of the gripping unit 2, which in turn is attached to the bottom wall 7 of the vacuum housing 1. The cylinder body 4 has a cover closure 8 at its lower end, which is provided on the outside with a nozzle 9 for attaching a suction cup 10. On the inside, the cover

abschluÃ 8 mit einem ringfÃ¶rmigen Ventilsitz 11 versehen, welcher durch die Ventileinrichtung 5 geÃ¶ffnet und verschlossen wird.closure 8 is provided with an annular valve seat 11 which is opened and closed by the valve device 5.

Die Ventileinrichtung 5 besteht vorzugsweise aus einer elektromagnetischen

Ventileinrichtung und wird Ã¼ber elektrische Leitungen 12 mit elektrischer Energie versorgt. Der Anker des Elektromagnetventils

umfaÃt einen VentilkÃ¶rper 13, der mittels einer Druckfeder 14 gegen den Ventilsitz 11 gedruckt wird, wenn das Ventil abgeschaltet

ist, eine elektrische Spule 15, die sich auf einem SpulenkÃ¶rper 16 befindet, und einen Ã¼blichen Kern 17, von dem bei eingeschaltetem

Ventil eine Anzugskraft auf den VentilkÃ¶rper 13 ausgeht. Sowohl der Kern 17 als auch der VentilkÃ¶rper 13 sind mit Bohrungen 18 versehen,

um bei geÃ¶ffnetem Elektromagnetventil einen Unterdruck auf den Sauger 10 wirken zu lassen, wenn dieser auf einem Formling

aufgesetzt hat.The valve device 5 preferably consists of an electromagnetic valve device and is supplied with electrical energy via electrical lines 12. The armature of the electromagnetic valve comprises a valve body 13, which is pressed against the valve seat 11 by means of a compression spring 14 when the valve is switched off, an electrical coil 15, which is located on a coil body 16, and a conventional core 17, from which a tightening force emanates from the valve body 13 when the valve is switched on. Both the core 17 and the valve body 13 are provided with holes 18 in order to allow a negative pressure to act on the suction cup 10 when the electromagnetic valve is open and the suction cup has been placed on a molded part.

Der ZylinderkÃ¶rper 4 erstreckt sich gemÃ¤Ã der Stellung in Figur 1 im Innern des VakuumgehÃ¤uses 1 Ã¼ber eine betrÃ¤chtliche vertikale

Strecke, beispielsweise bis fast zur Oberwandung 19 des GehÃ¤uses 1, so daÃ der StÃ¶Ãel 3 in der Lage ist, einen betrÃ¤chtlichen Hubweg H

zurÃ¼ckzulegen. Damit ist es mÃ¶glich, daÃ auch solche Formlinge aufgenommen werden kÃ¶nnen, die einen betrÃ¤chtlichen HÃ¶henunterschied

an ihren jeweiligen Erfassungsstellen aufweisen. Wie Figur 1 zeigt, kann dieser Hubweg 100 mm und mehr betragen.According to the position in Figure 1, the cylinder body 4 extends inside the vacuum housing 1 over a considerable vertical distance, for example almost to the upper wall 19 of the housing 1, so that the ram 3 is able to cover a considerable stroke H. This makes it possible to pick up even those moldings that have a considerable height difference at their respective pick-up points. As Figure 1 shows, this stroke can be 100 mm or more.

GemÃ¤Ã Figur 1 ist die Greifeinheit 2 ohne Antrieb fÃ¼r ihre vertikale

Bewegung in der Gleitlagerbuchse 6 ausgebildet. Um jedoch eine AufwÃ¤rtsbewegung der Greifeinheit zu erhalten, wird der AuÃendurchmesser

des StÃ¶Ãels 3 bzw. des ZylinderkÃ¶rpers 4 so gewÃ¤hlt, daÃ die Druckdifferenz zwischen Ã¤uÃerem AtmosphÃ¤rendruck und

dem demgegenÃ¼ber niedrigeren Betriebsdruck in den VakuumgehÃ¤use 1 multipliziert mit dem sich aus dem AuÃendurchmesser des Zylin-According to Figure 1, the gripping unit 2 is designed without a drive for its vertical movement in the plain bearing bush 6. However, in order to obtain an upward movement of the gripping unit, the outer diameter of the plunger 3 or the cylinder body 4 is selected so that the pressure difference between the external atmospheric pressure and the lower operating pressure in the vacuum housing 1 is multiplied by the pressure resulting from the outer diameter of the cylinder.

derkÃ¶rpers 4 ergebenden KreisflÃ¤chenwert eine Ã¤uÃere Druckkraft auf

die Einheit 2 ergibt, deren Wert geringfÃ¼gig Ã¼ber dem Wert der Gewichtskraft der Greifeinheit 2 liegt. Dadurch wird die Greifeinheit

automatisch in die in Figur 1 gezeigte obere End- und Ruhestellung bewegt bzw. darin gehalten. Der AuÃendurchmesser des ZylinderkÃ¶rpers

4 kann auch grÃ¶Ãer gewÃ¤hlt werden, so daÃ die Greifeinheit auch dann nach oben bewegt wird, wenn der Sauger 10 eine Last

trÃ¤gt. Nur bei verhÃ¤ltnismÃ¤Ãig groÃen Lasten wird die nach oben wirkende Druckkraft nicht ausreichen, so daÃ die Greifeinheit in der

unteren Endstellung verbleibt. In diesem Fall wird dann das GehÃ¤use 1 entsprechend weit nach oben verfahren, um die von dem oder den

Saugern erfaÃten Formlinge anzuheben.the circular area value of the body 4 results in an external pressure force on the unit 2, the value of which is slightly higher than the value of the weight of the gripping unit 2. This automatically moves the gripping unit into the upper end and rest position shown in Figure 1 or holds it there. The outer diameter of the cylinder body 4 can also be selected to be larger, so that the gripping unit is also moved upwards when the suction cup 10 is carrying a load. Only with relatively large loads will the upward pressure force not be sufficient, so that the gripping unit remains in the lower end position. In this case, the housing 1 is then moved upwards a corresponding distance in order to lift the moldings gripped by the suction cup(s).

Die beschriebene Greifeinheit wird folgendermaÃen betrieben. Wenn das VakuumgehÃ¤use 1 Ã¼ber den zu ergreifenden Formungen in Stellung

gebracht worden ist, wird kurzzeitig das Vakuum in dem GehÃ¤use 1 aufgehoben und die elektromagnetische Ventileinrichtung 5

eingeschaltet, so daÃ sich der VentilkÃ¶rper 13 anhebt. Aufgrund ihres Eigengewichtes senkt sich nun die Greifeinheit 2 ab, wobei der

Sauger 10 gegen den anzuhebenden Formling zur Anlage kommt. Es wird dann wieder ein Vakuum in dem GehÃ¤use 1 erzeugt, welches

auf den Sauger 10 wirkt, der sich daraufhin fest an dem Formling ansetzt. Danach schlieÃt der VentilkÃ¶rper 13. Da in dem GehÃ¤use 1

weiterhin das Vakuum besteht, wird sich die Greifeinheit 2 automatisch in das GehÃ¤use 1 zurÃ¼ckziehen, wenn das Eigengewicht der

Greifeinheit zusammen mit der Gewichtskraft des Formlings dies erlaubt. Das VakuumgehÃ¤use 1 wird dann zum Absetzort bewegt, wo

die Formlinge abgesetzt werden. Durch Ãffnen der Elektromagnetventileinrichtung 5 und Aufhebung des Vakuums in dem GehÃ¤use 1

lÃ¶st sich der Sauger 10 von seinem Formling.The gripping unit described is operated as follows. When the vacuum housing 1 has been positioned over the molds to be gripped, the vacuum in the housing 1 is briefly released and the electromagnetic valve device 5 is switched on so that the valve body 13 is raised. Due to its own weight, the gripping unit 2 now lowers, with the suction cup 10 coming into contact with the molding to be lifted. A vacuum is then generated again in the housing 1, which acts on the suction cup 10, which then firmly attaches itself to the molding. The valve body 13 then closes. Since the vacuum still exists in the housing 1, the gripping unit 2 will automatically retract into the housing 1 if the weight of the gripping unit together with the weight of the molding allows this. The vacuum housing 1 is then moved to the depositing location where the moldings are deposited. By opening the solenoid valve device 5 and removing the vacuum in the housing 1, the suction cup 10 is released from its molding.

Das weitere AusfÃ¼hrungsbeispiel nach den Figuren 2 und 3 unterscheidet

sich von dem ersten AusfÃ¼hrungsbeispiel dadurch, daÃ die innere Ventilrichtung aus einem mechanischen Ventil besteht und daÃ

fÃ¼r die BetÃ¤tigung des StÃ¶Ãels 3 bzw. des ZylinderkÃ¶rpers 4 und des mechanischen Ventils 5 ein fluidischer Zylinderantrieb 20 vorgesehen

ist. Soweit bei diesem Beispiel funktiongsgleiche Bauteile betroffen sind, sind hierfÃ¼r die gleichen Bezugszeichen verwendet.The further embodiment according to Figures 2 and 3 differs from the first embodiment in that the inner valve device consists of a mechanical valve and that a fluidic cylinder drive 20 is provided for the actuation of the tappet 3 or the cylinder body 4 and the mechanical valve 5. Insofar as functionally identical components are concerned in this example, the same reference numerals are used for this.

Der fluidische Zylinderantrieb 20 wird in der Oberwandung 19 des VakuumgehÃ¤uses befestigt, indem dessen unteres ZylinderabschluÃteil

21 mit der Oberwandung 19 z.B. verschraubt wird. Der Antrieb 20 besteht weiter aus dem Zylinderrohr 22, aus dem oberen AbschluÃdeckel

23 mit einem elektromagnetisch betÃ¤tigbaren fluidischen 3/2-Wegeventil 27 ist, aus einem Kolben 24, aus einer mit dem Kolben

verbundenen Kolbenstange 25 und aus einer inneren Druckfeder 26, die sich unten auf dem AbschluÃteil 21 und oben am Kolben 24

abstÃ¼tzt. Die Druckfeder 26 richtet eine Kraft gegen den Kolben 24, die ihn nach oben drÃ¼ckt. Magnetventil 27 zum Einlassen und Auslassen

von Druckfluid weist hierzu einen AnschluÃnippel 28 auf.The fluidic cylinder drive 20 is attached to the upper wall 19 of the vacuum housing by screwing its lower cylinder end part

21 to the upper wall 19, for example. The drive 20 also consists of the cylinder tube 22, the upper end cover

23 with an electromagnetically actuated fluidic 3/2-way valve 27, a piston 24, a piston rod 25 connected to the piston and an internal compression spring 26, which is supported at the bottom on the end part 21 and at the top on the piston 24. The compression spring 26 directs a force against the piston 24, which pushes it upwards. The solenoid valve 27 for letting in and letting out pressure fluid has a connection nipple 28 for this purpose.

Die mechanische Ventileinrichtung 5 ist bei diesem Beispiel in NÃ¤he

des offenen Oberendes des ZylinderkÃ¶rpers 4 vorgesehen und besteht aus einem daran innen befestigten Ventilsitzring 29 und aus einem

daran unten anliegenden plattenfÃ¶rmigen VentilkÃ¶rper 30, der am Unterende der Kolbenstange 25 des Antriebes 20 angeschraubt ist.

Die Kolbenstange erstreckt sich dabei durch eine zentrale Bohrung 31

des unteren AbschluÃteiles 21. Zwischen dem unteren AbschluÃbauteil 21 und dem Oberende des ZylinderkÃ¶rpers 4 ist ein elastischer

Dichtungsring 32 vorgesehen, um eine sichere Abdichtung des Ventils 5 gegenÃ¼ber dem Vakuum in dem VakuumgehÃ¤use 1 sicherzustellen.

Des weiteren ist eine an dem unteren AbschluÃbauteil 21 und an dem Oberende des ZylinderkÃ¶rpers 4 anliegende, den ZylinderkÃ¶rper beiIn this example, the mechanical valve device 5 is provided near the open upper end of the cylinder body 4 and consists of a valve seat ring 29 attached to the inside and a plate-shaped valve body 30 resting on the bottom of the valve seat ring 29, which is screwed to the lower end of the piston rod 25 of the drive 20. The piston rod extends through a central bore 31 of the lower end part 21. An elastic sealing ring 32 is provided between the lower end part 21 and the upper end of the cylinder body 4 in order to ensure a secure seal of the valve 5 against the vacuum in the vacuum housing 1. Furthermore, a sealing ring resting on the lower end part 21 and the upper end of the cylinder body 4, which seals the cylinder body when the piston rod 25 is moved, is provided.

sich abwÃ¤rts bewegender Kolbenstange 25 nach unten bewegende Druckfeder 33 vorgesehen. Diese Druckfeder liegt oben am Bauteil

21 und unten an einem Anschlagring 34 des ZylinderkÃ¶rpers 4 an. SchlieÃlich ist der ZylinderkÃ¶rper 4 und die Druckfeder 33 von einer

SchutzhÃ¼lse 35 umgeben.A compression spring 33 is provided which moves downwards as the piston rod 25 moves downwards. This compression spring rests on the top of the component 21 and on the bottom of a stop ring 34 of the cylinder body 4. Finally, the cylinder body 4 and the compression spring 33 are surrounded by a protective sleeve 35.

Auch in diesem Fall ist der ZylinderkÃ¶rper 4 in der Gleitlagerbuchse

6 der unteren GehÃ¤usewand 7 gefÃ¼hrt. Das Unterende des ZylinderkÃ¶rpers ist in diesem Fall mit dem Stutzen 9 versehen, der den

Aufnahmesauger 10 trÃ¤gt.In this case too, the cylinder body 4 is guided in the plain bearing bush

6 of the lower housing wall 7. The lower end of the cylinder body is in this case provided with the nozzle 9, which carries the suction cup 10.

Die Funktion dieses zweiten AusfÃ¼hrungsbeispieles ist folgende. Wenn das VakuumgehÃ¤use 1 zur Erfassung von Formungen positioniert

worden ist, wird der fluidische Antrieb beaufschlagt, um den Aufnahmesauger 10 mittels des sich absenkenden ZylinderkÃ¶rpers 4

auf den Formling abzusetzen. Hierbei kann das GehÃ¤use 1 schon Vakuum fÃ¼hren. Das Absenken des ZylinderkÃ¶rpers erfolgt durch

dessen Eigengewicht und teilweise durch die UnterstÃ¼tzung der Druckfeder 33. Wenn der Aufnahmesauger 10 aufgesetzt hat, bewegt

sich die Kolbenstange 25 noch weiter nach unten, so daÃ dadurch das mechanische Ventil 5 Ã¶ffnet. Wenn nun das GehÃ¤use 1 Vakuum

fÃ¼hrt, saugt sich der Sauger 10 an dem Formling fest. Der Antrieb 20 wird anschlieÃend in anderer Richtung betÃ¤tigt, so daÃ sich die

Kolbenstange 25, unterstÃ¼tzt durch die Druckfeder 26, nach oben bewegt. Hierbei schlieÃt sich das Ventil 5, so daÃ die Saugkraft des

Saugers 10 erhalten bleibt. Bei weiterer AufwÃ¤rtsbewegung des ZylinderkÃ¶rpers 4 wird der Formling angehoben und in eine obere

Stellung gebracht, die im allgemeinen durch die oberste Stellung des ZylinderkÃ¶rpers 4 bestimmt ist. Danach wird das VakuumgehÃ¤use in

Abladeposition gefahren. Durch Absenken des ZylinderkÃ¶rpers 4 und Ãffnen des Ventils 5 wird der Formling, oder alternativ auch andere

GegenstÃ¤nde, dann abgesetzt.The function of this second embodiment is as follows. When the vacuum housing 1 has been positioned to capture moldings, the fluid drive is actuated to place the suction cup 10 on the molding by means of the lowering cylinder body 4. The housing 1 can already carry a vacuum. The cylinder body is lowered by its own weight and partly by the support of the compression spring 33. When the suction cup 10 has been placed, the piston rod 25 moves even further downwards, thereby opening the mechanical valve 5. When the housing 1 now carries a vacuum, the suction cup 10 sucks itself onto the molding. The drive 20 is then actuated in the other direction, so that the piston rod 25 moves upwards, supported by the compression spring 26. The valve 5 closes here, so that the suction force of the suction cup 10 is maintained. As the cylinder body 4 continues to move upwards, the molded article is lifted and brought into an upper position, which is generally determined by the uppermost position of the cylinder body 4. The vacuum housing is then moved into the unloading position. The molded article, or alternatively other objects, is then deposited by lowering the cylinder body 4 and opening the valve 5.

## Classifications

- B25B11/007
- B25B11/00
- B65G47/91
- B65G47/91

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
