# 06. Auto-release vacuum device

- **Archive rank:** 6 of 50
- **Publication:** [US-2007006940-A1](https://patents.google.com/patent/US20070006940A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/037529459/publication/US20070006940A1?q=pn%3DUS20070006940A1)
- **Publication date:** 2007-01-11
- **Filing date:** 2006-05-09
- **Earliest priority:** 2005-07-11
- **Family:** 37529459
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** ATTEE KEITH S; PERLMAN MAURICE
- **Inventors:** ATTEE KEITH S; PERLMAN MAURICE

## Abstract

A vacuum device for a material handling system includes a vacuum device body and a sealing element. The vacuum device body has a vacuum passageway in which a vacuum is generated in response to activation of a pressurized air supply that forces pressurized air through a venturi device. The sealing element moves to a sealing position to substantially seal the vacuum passageway when the air supply is activated, and is urged toward the sealing position via pressurized air that is diverted from an inlet of the vacuum device to the sealing element. The sealing element moves to substantially vent the vacuum passageway when the air supply is deactivated. The vacuum passageway may be in fluid communication with a vacuum cup, which seals against the object when the sealing element is at the sealing position and the vacuum generating device generates at least a partial vacuum in the vacuum passageway.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-2007006940-A1/000.png)

![Sketch 1 for US-2007006940-A1](https://nimo.iptorch.com/refdrawing/US-2007006940-A1/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/US-2007006940-A1/001.png)

![Sketch 2 for US-2007006940-A1](https://nimo.iptorch.com/refdrawing/US-2007006940-A1/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/US-2007006940-A1/002.png)

![Sketch 3 for US-2007006940-A1](https://nimo.iptorch.com/refdrawing/US-2007006940-A1/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/US-2007006940-A1/003.png)

![Sketch 4 for US-2007006940-A1](https://nimo.iptorch.com/refdrawing/US-2007006940-A1/003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/US-2007006940-A1/004.png)

![Sketch 5 for US-2007006940-A1](https://nimo.iptorch.com/refdrawing/US-2007006940-A1/004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/US-2007006940-A1/005.png)

![Sketch 6 for US-2007006940-A1](https://nimo.iptorch.com/refdrawing/US-2007006940-A1/005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/US-2007006940-A1/006.png)

![Sketch 7 for US-2007006940-A1](https://nimo.iptorch.com/refdrawing/US-2007006940-A1/006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/US-2007006940-A1/007.png)

![Sketch 8 for US-2007006940-A1](https://nimo.iptorch.com/refdrawing/US-2007006940-A1/007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/US-2007006940-A1/008.png)

![Sketch 9 for US-2007006940-A1](https://nimo.iptorch.com/refdrawing/US-2007006940-A1/008.png)

## Claims

### Claim 1 (independent)

An automatic release vacuum device for a material handling system, said automatic release vacuum device comprising: a vacuum device body adapted to connect to a pressurized air supply, said vacuum device body having a vacuum passageway and a venturi nozzle, said pressurized air supply being activatable to supply pressurized air at said venturi nozzle to generate at least a partial vacuum in said vacuum passageway via pressurized air flow through said venturi nozzle; a movable sealing element at said vacuum device body and movable between a sealing position, where said movable sealing element substantially seals said vacuum passageway, and a venting position, where said movable sealing element substantially vents said vacuum passageway; said vacuum device being configured to divert a portion of said pressurized air to said movable sealing element to urge said movable sealing element toward said sealing position when said pressurized air supply is activated; and said movable sealing element being urged toward said venting position when said pressurized air supply is deactivated to substantially vent said vacuum passageway to atmosphere when said pressurized air supply is deactivated.

### Claim 2

The automatic release vacuum device of claim 1 , wherein said pressurized air supply is activatable to force pressurized air through said venturi nozzle to generate the at least partial vacuum in said vacuum passageway by drawing air from said vacuum passageway and into said venturi nozzle via at least one vacuum port of said venturi nozzle.

### Claim 3

The automatic release vacuum device of claim 1 including a noise reducing device at a discharge of said venturi nozzle, said noise reducing device comprising a housing defining a chamber with a conical-shaped diverter element, said housing having a plurality of radially spaced exit openings, whereby air discharged at said venturi nozzle is diverted by said conical-shaped diverter element and flows out through said exit openings of said housing.

### Claim 4

The automatic release vacuum device of claim 1 , wherein said vacuum device body includes a diverter passageway that diverts said portion of said pressurized air, said diverter passageway diverting said portion of said pressurized air to a substantially enclosed cavity at said movable sealing element to urge said movable sealing element toward said sealing position.

### Claim 5

The automatic release vacuum device of claim 4 , wherein said vacuum device body comprises a unitarily formed body, said unitarily formed body having said vacuum passageway and said diverter passageway formed at least partially therethrough.

### Claim 6

The automatic release vacuum device of claim 5 , wherein said automatic release venturi device includes a vacuum cup that is configured to engage an object, said vacuum cup being configured to substantially seal against the object when said movable sealing element is at said sealing position and said venturi nozzle generates at least a partial vacuum in said vacuum passageway.

### Claim 7

The automatic release vacuum device of claim 6 , wherein said venturi nozzle extends through said vacuum passageway so that said vacuum passageway comprises a first passageway portion between said venturi nozzle and said vacuum cup and a second passageway portion between said venturi nozzle and said movable sealing element.

### Claim 8

The automatic release vacuum device of claim 7 , wherein said vacuum device body has a venting port at said second passageway portion that vents said vacuum passageway to atmosphere when said movable sealing element is moved toward said venting position.

### Claim 9

The automatic release vacuum device of claim 4 including a biasing element that functions to urge said movable sealing element toward said venting position, said diverting passageway diverting said portion of said pressurized air to said movable sealing element to at least partially overcome a biasing force of said biasing element to urge said movable sealing element toward said sealing position when said pressurized air supply is activated.

### Claim 10

The automatic release vacuum device of claim 1 , wherein said movable sealing element comprises a flexible membrane element that flexes to engage and disengage a venting port of said vacuum device.

### Claim 11

The automatic release vacuum device of claim 1 , wherein said movable sealing element comprises a piston element that moves along a venting passageway of said vacuum device body between said sealing and venting positions, said venting passageway being in fluid communication with said vacuum passageway when said movable sealing element is in said venting position.

### Claim 12

The automatic release vacuum device of claim 11 , wherein said movable sealing element engages a flexible sealing element located at said venting passageway when in said sealing position.

### Claim 13 (independent)

A vacuum cup assembly of a material handling system, said vacuum cup assembly being engagable with an object and movable to move the object, said vacuum cup assembly comprising: a vacuum device adapted to connect to a pressurized air supply, said vacuum device having a vacuum passageway and a venturi device, said pressurized air supply being activatable to supply pressurized air at said venturi device to draw air from said vacuum passageway, said vacuum device including a movable sealing element for selectively sealing and venting said vacuum passageway; a vacuum cup in fluid communication with said vacuum passageway, said vacuum cup being configured to engage an object; said movable sealing element being movable between a sealing position, where said movable sealing element substantially seals said second vacuum passageway, and a venting position, where said movable sealing element substantially vents said vacuum passageway; a biasing element that urges said movable sealing element toward said venting position; said vacuum device having a diverter passageway configured to divert a portion of said pressurized air to said movable sealing element to urge said movable sealing element toward said sealing position when said pressurized air supply is activated; said biasing element urging said movable sealing element toward said venting position to substantially vent said vacuum passageway when said pressurized air supply is deactivated; and said vacuum cup being configured to substantially seal against the object when said movable sealing device is in said sealing position and said venturi device generates at least a partial vacuum in said vacuum passageway.

### Claim 14

The vacuum cup assembly of claim 13 , wherein said diverter passageway diverts said portion of said pressurized air to a cavity defined at said movable sealing element and at an opposite side of said movable sealing element from said venturi device.

### Claim 15

The vacuum cup assembly of claim 13 , wherein said diverter passageway diverts said portion of said pressurized air to said movable sealing element and said venturi device draws air from said vacuum passageway to create a sufficient pressure differential at said movable sealing element to overcome a biasing force of said biasing element to urge said movable sealing element toward said sealing position when said pressurized air supply is activated.

### Claim 16

The vacuum cup assembly of claim 13 , wherein said vacuum device comprises a unitarily formed body portion, said body portion having said vacuum passageway and said diverter passageway formed at least partially therethrough.

### Claim 17

The vacuum cup assembly of claim 13 , wherein said movable sealing element comprises a piston element that is movable along a venting passageway of said vacuum device, said venting passageway being in fluid communication with said vacuum passageway when said movable sealing element is moved toward said venting position.

### Claim 18

The vacuum cup assembly of claim 17 , wherein said piston element engages a sealing ring at said vacuum passageway when in said sealing position.

### Claim 19

The vacuum cup assembly of claim 18 , wherein said venting passageway includes at least one venting port, said sealing ring being located between said at least one venting port and said venturi device.

### Claim 20

The vacuum cup assembly of claim 13 , wherein said movable sealing element comprises a flexible membrane element that flexes to engage and disengage a venting port of said vacuum device.

### Claim 21

The vacuum cup assembly of claim 13 including a noise reducing device at a discharge of said venturi nozzle, said noise reducing device comprising a housing defining a chamber with a conical-shaped diverter element therein, said housing having a plurality of radially spaced exit openings, whereby air discharged at said venturi nozzle enters said chamber and is diverted by said conical-shaped diverter element and flows out through said exit openings of said housing.

### Claim 22 (independent)

A vacuum cup assembly of a material handling system, said vacuum cup assembly being engagable with an object and movable to move the object, said vacuum cup assembly comprising: a vacuum device adapted to connect to a pressurized air supply, said vacuum device having a vacuum passageway and a venturi nozzle positioned within said vacuum device; a vacuum cup configured to engage an object; said pressurized air supply being activatable to force pressurized air through said venturi nozzle to generate the at least partial vacuum in said vacuum passageway and at said vacuum cup when said vacuum cup is engaged with an object, said pressurized air flowing through said venturi nozzle and drawing air from said vacuum passageway and into said venturi nozzle via at least one vacuum port of said venturi nozzle; a noise reducing device at a discharge of said venturi nozzle, said noise reducing device comprising a housing defining a chamber with a conical-shaped diverter element, said housing having a plurality of radially spaced exit openings, whereby air discharged at said venturi nozzle is diverted by said conical-shaped diverter element and flows out through said exit openings of said housing; and wherein said vacuum cup is configured to substantially seal against the object when said venturi device generates at least a partial vacuum in said vacuum passageway.

### Claim 23

The vacuum cup assembly of claim 22 , wherein said housing of said noise reducing device comprises an outer end and a sidewall that cooperate to define said chamber, said conical-shaped diverter element protruding from said outer end and toward said venturi nozzle, said sidewall attaching said noise reducing device to said vacuum device.

### Claim 24

The vacuum cup assembly of claim 23 , wherein said housing of said noise reducing device includes a curved transition region between said conical-shaped diverter element and said outer end.

### Claim 25

The vacuum cup assembly of claim 24 , wherein said housing includes a curved transition region between said outer end and said sidewall.

### Claim 26

The vacuum cup assembly of claim 23 , wherein said exit openings are formed through said sidewall and generally at said outer end of said housing.

### Claim 27

The vacuum cup assembly of claim 22 including a movable sealing element movable between a sealing position, where said movable sealing element substantially seals said vacuum passageway, and a venting position, where said movable sealing element substantially vents said vacuum passageway, said vacuum device being configured to divert a portion of said pressurized air to said movable sealing element to urge said movable sealing element toward said sealing position when said pressurized air supply is activated, said movable sealing element being urged toward said venting position when said pressurized air supply is deactivated to substantially vent said vacuum passageway to atmosphere when said pressurized air supply is deactivated.

## Full description

### Cross Reference To Related Application

**[p0001]**

The present application claims the benefit of U.S. provisional application Ser. No. 60/698,031, filed Jul. 11, 2005, which is hereby incorporated herein by reference in its entirety.

### Field Of The Invention

**[p0002]**

The present invention relates generally to material handling systems and, more particularly, to vacuum devices for vacuum cup assemblies of material handling systems that are engaged with the objects and substantially sealed thereto via operation of a vacuum source or pneumatic device connected to the vacuum devices.

### Background Of The Invention

**[p0003]**

It is known to provide a material handling system that includes vacuum cups or the like that are adapted to be moved into engagement with an object, such as a substantially flat object or panel or the like, and to lift and move the object to a desired location. Such vacuum cups or suction cups may be moved into engagement with the object, and a vacuum source may be actuated to create a vacuum between the object and the cup such that the object is retained to the cup as it is transported to the targeted area. An example of such a vacuum cup is disclosed in U.S. Pat. No. 4,662,668, which is hereby incorporated herein by reference. The vacuum generated at the cup may be provided by a venturi nozzle, whereby pressurized air is supplied or provided to a venturi nozzle at the cup and the air forced through the venturi nozzle creates a vacuum at the cup to seal the cup to the object surface. The venturi nozzle has an inlet port connected to the air supply and an exit port through which the air is blown. The internal cavity defined by the vacuum cup and object is in fluid communication with the venturi nozzle so that air is drawn out of the cavity as the air is blown through the venturi nozzle. When the air supply is deactivated, the vacuum within the cup cavity may dissipate through the port that connects the vacuum cup cavity to the venturi nozzle and through the exit port. Thus, there may be a delay between when the air supply is deactivated and when the vacuum dissipates a sufficient amount to readily release the vacuum cup from the object.

### Summary Of The Invention

**[p0004]**

The present invention provides an automatic release vacuum device or venturi device, such as for a vacuum cup assembly of a material handling system that is operable to move one or more vacuum cups into engagement with an object and to pick up and move the object to a targeted or desired location. The material handling system may move the vacuum cup into engagement with the object, and may create a vacuum or partial vacuum at a cup cavity, such as via a vacuum source or an air supply or other pneumatic device or the like, to substantially seal the vacuum cup to the object. The vacuum device includes a venting element at a venting port to substantially vent the vacuum or partial vacuum at the vacuum cup to atmosphere when the vacuum source or pneumatic device is deactivated. According to an aspect of the present invention, an automatic release vacuum device or venturi device for a material handling system includes a vacuum device body and a movable sealing element. The vacuum device body is adapted to connect to a pressurized air supply, and includes a vacuum passageway and a vacuum generating device, such as a venturi nozzle or device at or in fluid communication with the vacuum passageway. The pressurized air supply is activatable to supply pressurized air at the vacuum generating device to generate at least a partial vacuum in the vacuum passageway. The movable sealing element is movable between a sealing position, where the movable sealing element substantially seals the vacuum passageway, and a venting position, where the movable sealing element substantially vents the

**[p0004]**

vacuum passageway. The vacuum device is configured to divert a portion of the pressurized air to the movable sealing element to urge the movable sealing element toward the sealing position when the pressurized air supply is activated. The movable sealing element is urged toward the venting position when the pressurized air supply is deactivated to substantially vent the vacuum passageway to atmosphere when the pressurized air supply is deactivated.

**[p0005]**

The vacuum device body includes a diverting passageway that diverts the portion of the pressurized air to a substantially enclosed cavity at the movable sealing element to urge the movable sealing element toward the sealing position. The automatic release vacuum device includes a biasing element that functions to urge the movable sealing element toward the venting position. The diverting passageway diverts the portion of the pressurized air to the movable sealing element to at least partially overcome a biasing force of the biasing element to urge the movable sealing element toward the sealing position when the pressurized air supply is activated. In one form, the movable sealing element may comprise a flexible membrane element that flexes to engage and disengage a venting port of the vacuum device. In another form, the movable sealing element may comprise a piston element that moves along a passageway of the vacuum device body between the sealing and venting positions. The automatic release vacuum device is suitable for and may be configured for use with a vacuum cup assembly of the material handling system, with a vacuum cup of the assembly being configured to engage an object and being movable to move the object when engaged therewith. The vacuum cup is configured to substantially seal against the object when the movable sealing element is at the sealing position and the vacuum generating device generates at least a partial vacuum in the vacuum passageway.

**[p0006]**

According to another aspect of the present invention, a vacuum cup assembly of a material handling system, with the vacuum cup assembly being engagable with an object and movable to move the object, includes a vacuum device, a vacuum cup and a noise reducing device. The vacuum device is adapted to connect to a pressurized air supply and has a vacuum passageway and a venturi nozzle positioned within the vacuum device. The vacuum cup is attached to the vacuum device and is configured to engage an object. The pressurized air supply is activatable to force pressurized air through the venturi nozzle to generate the at least partial vacuum in the vacuum passageway and at the vacuum cup when the vacuum cup is engaged with an object. The pressurized air flows through the venturi nozzle and draws air from the vacuum passageway and into the venturi nozzle via at least one vacuum port of the venturi nozzle. The noise reducing device is located at a discharge of the venturi nozzle and comprises a housing defining a chamber with a conical-shaped diverter element. The housing has a plurality of radially spaced exit openings, whereby air discharged at the venturi nozzle is diverted by the conical-shaped diverter element and flows out through the exit openings of the housing. The vacuum cup is configured to substantially seal against the object when the venturi device generates at least a partial vacuum in the vacuum passageway.

**[p0007]**

The housing of the noise reducing device may include an outer end and a sidewall that cooperate to define the chamber. The conical-shaped diverter element protrudes from the outer end and toward the venturi nozzle. The sidewall may function to attach the noise reducing device to the vacuum device. The housing of the noise reducing device includes a curved transition region between the conical-shaped diverter element and the outer end. The housing includes a curved transition region between the outer end and the sidewall. The exit openings are formed through the sidewall and generally at the outer end of the housing. According to yet another aspect of the present invention, a vacuum cup assembly for a material handling system includes a vacuum cup, a vacuum device and a sealing device or element. The vacuum cup assembly is engagable with an object and movable to move the object. The vacuum cup has a perimeter seal for engaging and substantially sealing at an object surface. The vacuum device is attached to the vacuum cup and is configured to draw air out of a cavity defined by the perimeter seal and the object surface when the vacuum cup is engaged with the object surface. The vacuum device comprises a unitary body and houses a venturi nozzle and defines a vacuum passageway that is in fluid communication with a vacuum port of the venturi nozzle. An inlet of the venturi nozzle is connectable to a pressurized air supply, which is activatable to force air through the venturi nozzle to generate at least a partial vacuum in the vacuum passageway. The vacuum passageway extends thr

**[p0007]**

ough the body and between the vacuum cup and a venting passageway or port of the body. The body defines a diverting passageway that diverts air from the inlet of the venturi nozzle to the sealing element. The diverting passageway diverts air to the sealing element to urge the sealing element toward engagement with the venting port or otherwise toward a sealing position that substantially seals or closes the venting port or passageway. The sealing element is thus movable to substantially close or seal the vacuum passageway when the pressurized air supply is activated and when air flows through the diverting port to the sealing element. The sealing element is movable to disengage from or open the venting port or passageway to substantially vent the vacuum passageway to atmosphere when the vacuum source is deactivated.

**[p0008]**

Therefore, the present invention provides an automatic release vacuum device or venturi device, such as for a vacuum cup assembly of a material handling system that moves the vacuum cup assembly into engagement with an object. A vacuum or partial vacuum generated by the vacuum device may be readily applied to the vacuum cup of the vacuum cup assembly to substantially seal the vacuum cup to the object. When the vacuum source or pressurized air supply or other pneumatic device is reduced or deactivated, the vacuum or partial vacuum within the vacuum cup is readily and rapidly vented to atmosphere via a sealing/venting element of the vacuum device. The sealing/venting element functions to substantially seal or close the vacuum passageway when the vacuum source is activated, and is readily and automatically disengaged or moved to open or vent the vacuum passageway when the vacuum source is deactivated. The sealing/venting element (such as a membrane or piston or the like) of the vacuum device may be engaged against the vacuum device body or other sealing element in response to the vacuum generated within the vacuum device body and in response to pressurized air provided at the sealing/venting element, such that the pressure differential at the sealing/venting element causes the sealing/venting element to substantially seal or close the vacuum passageway. When the vacuum is deactivated, the sealing/venting element may be disengaged from the venting port or other sealing element or may otherwise open or vent the vacuum passageway, such as in response to a biasing element or sprin

**[p0008]**

g, as the vacuum is at least partially reduced and/or as the pressurized air from the diverting passageway is reduced or eliminated. The vacuum at the vacuum cup assembly thus may be automatically and readily vented to atmosphere to release the vacuum cup from the object at the desired or targeted destination or location. The vacuum passageway, diverting passageway and sealing/venting element are positioned or formed within the body of the vacuum device so as to provide an integral vacuum device or auto-release venturi device for the vacuum cup assembly.

**[p0009]**

These and other objects, advantages, purposes and features of the present invention will become apparent upon review of the following specification in conjunction with the drawings.

### Brief Description Of The Drawings

**[p0010]**

FIG. 1 is a side elevation of a vacuum cup assembly with a vacuum device in accordance with the present invention; FIG. 2 is an exploded perspective view of a vacuum device in accordance with the present invention; FIG. 3 is a sectional view of the vacuum device of the present invention; FIG. 4 is an exploded perspective view of another vacuum device in accordance with the present invention, with a piston that is movable to seal or vent the vacuum passageway; FIG. 5 is a sectional view of the vacuum device of FIG. 4 , shown with the piston in a sealing orientation; FIG. 6 is another sectional view of the vacuum device of FIG. 4 , shown with the piston in a venting orientation; FIG. 7 is a perspective view of a venturi silencer useful with a venturi vacuum device; FIG. 8 is an end elevation of the venturi silencer of FIG. 7 ; FIG. 9 is a side elevation of the venturi silencer of FIGS. 7 and 8 ; and FIG. 10 is a sectional view of the venturi silencer taken along the line X-X in FIG. 8 .

### Description Of The Preferred Embodiments

**[p0011]**

Referring now to the drawings and the illustrative embodiments depicted therein, a vacuum cup assembly 10 includes a vacuum cup 12 and an integral automatic release vacuum assembly or venturi assembly or vacuum device 14 operable to create a vacuum or partial vacuum within the vacuum cup 12 when the vacuum cup is engaged with a surface of an object 16 ( FIG. 1 ). The vacuum cup assembly 10 is mountable to a support assembly of a material handling system, which is operable to move the support and vacuum cup assembly (or multiple vacuum cup assemblies or suction cups) into engagement with an object, where the vacuum cup may engage and seal to the object for picking up and moving the object. The material handling system includes a vacuum source or pressurized air supply or pneumatic device for providing or creating a vacuum or partial vacuum at the vacuum cup assembly 10 to substantially vacuum seal the vacuum cup 12 to the object 16 . The vacuum device 14 includes a sealing and venting device or assembly or element 18 that is openable to atmosphere in response to deactivation of the vacuum source or air supply or pneumatic device to substantially vent the vacuum from the vacuum cup when the vacuum source or air supply or pneumatic device is deactivated, as discussed below. In the illustrated embodiment, the vacuum source comprises a venturi device or nozzle that is connected to or in fluid communication with a pressurized air supply, such that when the pressurized air supply is activated, pressurized air flows through the venturi device to generate a vacuum in the vacuum devi

**[p0011]**

ce and vacuum cup, as also discussed below.

**[p0012]**

As shown in FIGS. 2 and 3 , vacuum device 14 includes a vacuum device body or body portion 20 that is preferably unitarily formed and that includes or defines vacuum and venting passageways and ports as described below. For example, the body 20 may be cast or molded or otherwise formed of a metallic material, such as aluminum or the like, or a polymeric material, such as engineering plastic or the like, and may have the passageways bored or drilled through the unitary body to define and connect the appropriate passageways, as discussed below. The vacuum device 14 may be connected to a support arm (not shown) or the like of the material handling device, and may be connected to any type of support arm, without affecting the scope of the present invention. The vacuum cup assembly and material handling system of the present invention may utilize aspects described in U.S. patent application Ser. No. 11/034,046, filed Jan. 12, 2005 by Attee et al. for VACUUM CUP (Attorney Docket CPI01 P-313A); and/or Ser. No. 10/931,637, filed Sep. 1, 2004 by Kniss for ADJUSTABLE MOUNT FOR VACUUM CUP (Attorney Docket CPI01 P-314), which are hereby incorporated herein by reference.

**[p0013]**

As shown in FIG. 3 , body 20 includes or defines a vacuum generating passageway 22 therethrough. Vacuum generating passageway 22 defines an outlet or exit port 23 and an inlet or entry port 24 at opposite ends of the passageway 22 and body 20 . A vacuum generating device 28 is positioned at or in or partially in vacuum generating passageway 22 and is connectable to a vacuum source or air supply tube or pipe 29 ( FIG. 1 ) at inlet port 24 . In the illustrated embodiment, vacuum generating device 28 comprises a venturi nozzle that is positioned along passageway 22 with an outlet end 28 a at outlet port 23 and an inlet or entry end 28 b at or near inlet port 24 . A vacuum passageway 26 connects to and is in fluid communication with vacuum generating passageway 22 and vacuum cup 12 at one end and sealing and venting device 18 at the other end, as discussed below. Vacuum passageway 26 terminates at a vacuum cup connection port 27 for connecting body 20 to vacuum cup 12 .

**[p0014]**

Venturi nozzle 28 includes a nozzle body or body portion 32 and a passageway 34 extending longitudinally along the nozzle body 32 . The nozzle body 32 includes at least one vacuum port 36 to provide fluid communication through nozzle body 32 to passageway 34 . When venturi nozzle 28 is positioned within passageway 22 of body 20 , vacuum port or ports 36 is/are positioned generally at and in fluid communication with vacuum passageway 26 of body 20 . As is known in the vacuum cup and venturi nozzle art, the passageway 34 of venturi nozzle 28 comprises a narrowing and widening passageway to increase the air flow rate through the venturi nozzle 28 when the air supply or source is activated, whereby air flow through the venturi nozzle 28 draws air through vacuum ports 36 and from vacuum passageway 26 to create a vacuum or partial vacuum in the vacuum passageway 26 when the vacuum passageway is not vented, as discussed below. A silencing element or diffusing element 30 and retaining ring 31 may be positioned at outlet end 28 a of nozzle 28 .

**[p0015]**

In the illustrated embodiment of FIGS. 2 and 3 , vacuum passageway 26 of body 20 extends upwardly or outwardly from passageway 22 and venturi nozzle 28 , with sealing and venting device 18 positioned at an outer end of passageway 26 and at an upper end or outer or venting portion 40 of body 20 . Sealing and venting device 18 functions to selectively substantially close and seal vacuum passageway 26 when the air supply is activated and to open or vent vacuum passageway 26 to release or vent the vacuum within the vacuum cup when the vacuum source or air supply is deactivated, as discussed in detail below. As can be seen with reference to FIGS. 2 and 3 , venting portion 40 of body 20 includes a recessed or venting surface 42 within an outer raised ring or cylindrical extension or ring or wall 44 that substantially surrounds venting surface 42 . The outer ring 44 includes a stepped or intermediate surface 46 that is within outer ring 44 and spaced from venting surface 42 . An inner raised ring or cylindrical extension or venting port 48 extends or protrudes outwardly from venting surface 42 and defines an outer end of the vacuum passageway 26 .

**[p0016]**

Body 20 of vacuum device 14 also includes or defines a diverting port or passageway 50 that connects and provides fluid communication between the inlet port 24 of the nozzle passageway 22 to an upper or outer surface or end 44 a of the outer ring 44 at venting portion 40 of body 20 . Body 20 also includes or defines a venting passageway or port 52 that is open to atmosphere at one end 52 a and that is open at its other end 52 b at venting surface 42 of venting portion 40 of body 20 . The sealing and venting device or assembly 18 functions to selectively connect or provide fluid communication between venting port 52 and vacuum passageway 26 to vent the vacuum cup to atmosphere when the vacuum source or air supply is deactivated, as discussed below. As best shown in FIGS. 2 and 3 , sealing and venting device 18 includes a first sealing element 54 , such as a sealing cap or diaphragm, and an outer cap or cover 56 . In the illustrated embodiment of FIGS. 2 and 3 , the sealing element 54 comprises a flexible membrane element or diaphragm. However, the sealing element may comprise other movable means for engaging another sealing element to seal the passageway when the pressurized air supply is activated and to disengage from the other sealing element to vent the passageway when the pressurized air supply is deactivated, such as a movable piston sealing element, as discussed below with respect to FIGS. 4-6 , or other movable element while remaining within the spirit and scope of the present invention. Diaphragm 54 comprises a generally flat disc or flexible or movable sealing elem

**[p0016]**

ent or diaphragm element 54 a and a generally cylindrical wall 54 b surrounding diaphragm element 54 a and extending upwardly therefrom when diaphragm 54 is positioned at venting portion 40 of body 20 as shown in FIG. 3 . Diaphragm element 54 a is a thin flexible membrane that may flex toward and away from the venting port or inner extension or second sealing element 48 during operation of the vacuum cup assembly, as discussed below. In the illustrated embodiment of FIGS. 2 and 3 , cylindrical wall 54 b of diaphragm 54 is attached to or positioned at the lip or step or ledge 46 of outer wall or ring 44 of body 20 .

**[p0017]**

Cover 56 comprises a generally flat disc portion 56 a and a generally cylindrical wall portion 56 b surrounding disc portion 56 a and extending downwardly therefrom when cover 56 is positioned at venting portion 40 of body 20 as shown in FIG. 3 . Disc portion 56 a of cover 56 may include a recessed portion or recess 56 c at its inner surface. In the illustrated embodiment, wall portion 56 b of cover 56 is attached to or positioned at and around the outer wall or ring 44 to substantially encase the outer end of the outer wall or ring 44 and diaphragm 54 within the cover 56 and between cover 56 and body 20 . Cover 56 may be secured to diaphragm 54 so that the diaphragm and cover assembly are mounted to body 20 together, or cover 56 and diaphragm 54 may comprise separate components that are mounted separately to the respective portions of body 20 , without affecting the scope of the present invention. As shown in FIG. 3 , disc portion 56 a of cover 56 may rest on or engage the outer ends of cylindrical wall 54 b of diaphragm 54 , while cylindrical wall 56 b of cover overlaps or encompasses or receives outer cylindrical wall or extension 44 of upper or outer body portion 40 . When cover 56 is positioned over diaphragm 54 , the recess 56 c provides a passageway for fluid communication or air flow between the diverting passageway 50 at the outer end 44 a of the outer cylindrical extension 44 and the area between the cap or cover 56 and the diaphragm element 54 a . When the movable sealing element or diaphragm element 54 a is disengaged from the second sealing element or venting p

**[p0017]**

ort 48 , vacuum passageway 26 is vented to atmosphere via venting passageway 52 to vent the vacuum cup 12 to atmosphere to release the vacuum cup from the object, as discussed below.

**[p0018]**

Sealing and venting device 18 further includes a biasing element or member or spring 58 , which is positioned generally around venting port 48 of body portion 40 and between venting surface 42 and diaphragm element 54 a . Biasing element 58 functions to bias or urge the first or movable sealing element or diaphragm element 54 a away from engagement with second sealing element or venting port 48 , such that air may flow between vacuum passageway 26 and venting passageway 52 when diaphragm element 54 a is disengaged from venting port 48 , as discussed below. As shown in FIGS. 1 and 3 , vacuum cup 12 of vacuum cup assembly 10 is attached to vacuum cup connection port 27 of body 20 and is, in the illustrated embodiment, positioned generally opposite from sealing and venting device 18 and venting portion 40 . Vacuum cup 12 includes a body portion 60 and a perimeter seal portion 62 . Vacuum cup 12 includes an opening for receiving vacuum cup connection port 27 of body 20 . When vacuum cup 12 receives vacuum port 27 , vacuum passageway 26 provides fluid communication between venturi nozzle 28 and a cavity 64 defined by the body portion 60 and perimeter seal 62 of vacuum cup 12 and the surface of the object 16 that is engaged with an engaging end 62 a of the perimeter seal 62 . Vacuum cup 12 may be integrally or unitarily molded from an elastomeric material or may be otherwise formed or molded, without affecting the scope of the present invention. Although shown as a vacuum cup having a bellows style or accordion style perimeter seal, it is envisioned that the vacuum cup may have o

**[p0018]**

ther seal portions (such as a tapered perimeter seal portion or the like, and/or such as a seal portion of the types described in U.S. patent application Ser. No. 11/034,046, filed Jan. 12, 2005 by Attee et al. for VACUUM CUP (Attorney Docket CPI01 P-313A), which is hereby incorporated herein by reference), and/or other types of vacuum cups may be implemented with the material handling device, without affecting the scope of the present invention.

**[p0019]**

Vacuum cup 12 may be attached to or adhered to or molded to or fastened to or otherwise secured to vacuum port 27 of body 20 of vacuum device 14 . In the illustrated embodiment, vacuum port 27 is received in or positioned at or at least partially through the opening at the body portion 60 of vacuum cup 12 . Vacuum passageway 26 allows air to flow from cavity 64 and through vacuum passageway 26 to draw air out of cavity 64 to create a vacuum or partial vacuum within cavity 64 when the air supply is activated. During operation of vacuum cup assembly 10 , pressurized air is supplied at inlet port 24 (such as via a hose or tube 29 or the like) and flows through venturi nozzle 28 and out exit port 23 of body 20 . As the air flows through venturi nozzle 28 , air is drawn through vacuum ports 36 from vacuum passageway 26 and into passageway 34 of nozzle 28 and out the exit port 23 . When the pressurized air flows through the venturi nozzle 28 , a portion of the pressurized air that enters the nozzle at inlet port 24 is diverted through diverting passageway 50 and into recess or cavity 56 c between cover 56 and first sealing element or diaphragm 54 to pressurize the cover and diaphragm assembly, and thereby functions to exert a downward pressure against movable or flexible diaphragm element 54 a to urge the diaphragm element 54 a downward and against the urging of biasing element 58 and into sealing engagement with second sealing element or venting port 48 of venting portion 40 to substantially seal diaphragm element 54 a against venting port 48 . Also, as the air is drawn from vac

**[p0019]**

uum passageway 26 by the venturi nozzle, the diaphragm element 54 a or first sealing element is pulled downward against biasing element 58 and toward engagement with the outer end of second sealing element or venting port 48 to substantially seal or close vacuum passageway 26 . The diverting passageway 50 and cover 56 thus provide pressurized air above diaphragm 54 or at the opposite side of diaphragm 54 from the vacuum passageway 26 , in order to assist in moving or urging diaphragm element 54 a to a sealing position and against venting port 48 at venting portion 40 of body 20 when the vacuum source or air supply is activated. Because pressurized air is provided above or outside of diaphragm 54 while a partial vacuum is provided below or at the inner side of diaphragm 54 , the increased pressure differential at the diaphragm element causes the diaphragm element 54 a to flex into engagement with the venting port to substantially close or seal the vacuum passageway at the venting port. Also, as air is drawn through vacuum port 36 of nozzle 28 from vacuum passageway 26 , a vacuum or partial vacuum is created within the cavity 64 defined by the vacuum cup 12 and the object surface to which the vacuum cup is engaged.

**[p0020]**

When the air supply or vacuum source is substantially reduced or deactivated, pressurized air is no longer forced or blown to and through the venturi nozzle and thus does not flow through diverting passageway 50 to urge diaphragm element 54 a downward or toward the second sealing element. The vacuum or partial vacuum within vacuum passageways 26 and cavity 64 thus may dissipate via venting through ports 36 and exit port 28 a of venturi nozzle 28 . When the diverted pressurized air is no longer present at the first sealing element, the biasing element or member or spring may urge the first sealing element away from the second sealing element and to a venting position so that the vacuum passageway is vented to atmosphere. Thus, when the pressurized air supply is deactivated or reduced, biasing element 58 urges diaphragm element 54 a outward and away from venting port 48 so that vacuum passageway 26 is vented to atmosphere via air flow through venting passageway 52 and around the venting port 48 and into vacuum passageway 26 . The vacuum passageway 26 is formed within body at a sufficient diameter to provide clearance around the venturi nozzle 28 so that the vacuum within cavity 64 of vacuum cup 12 is quickly vented to atmosphere via air flow through the venting passageway 52 and vacuum passageway 26 . The vacuum or partial vacuum within the vacuum cup thus is quickly released or vented after the vacuum source or air supply is deactivated, and does not have the delay in venting that typically occur as the vacuum or partial vacuum slowly dissipates through the ports of the vent

**[p0020]**

uri nozzle of known vacuum cups. The vacuum cup assembly of the present invention thus may be readily removed from the object when the air supply is deactivated.

**[p0021]**

Although shown and described as being a movable or flexible diaphragm element, the first or movable sealing element of the vacuum cup assembly may comprise other sealing means or devices or members or elements, without affecting the scope of the present invention. For example, and with reference to FIGS. 4-6 , a sealing and venting device or assembly or element 118 of a vacuum device 114 of a vacuum cup assembly 110 may comprise a first sealing element or movable sealing element 154 , such as a piston element, that is movable along a venting passageway or upper or outer passageway portion 126 a at or in fluid communication with the vacuum passageway 126 of the body 120 of vacuum device 114 of the vacuum cup assembly 110 to selectively seal and vent the vacuum device and vacuum cup assembly. For example, piston element 154 may engage a second sealing element or portion or seal or ring 155 (such as an elastomeric or rubber sealing ring or the like) positioned at the passageway portion 126 a and at or outward from an upper end of the vacuum passageway 126 , in order to substantially seal the passageway 126 a so that vacuum is generated in the passageway 126 by the venturi device 128 . The piston element 154 may move along the passageway portion 126 a to engage the sealing ring 155 to substantially seal or close the vacuum passageway (as shown in FIG. 5 ) when the pressurized air supply is activated to generate the vacuum, and may move away from the sealing ring 155 to vent the vacuum passageway to atmosphere (as shown in FIG. 6 ) when the pressurized air supply is deactivated

**[p0021]**

or reduced.

**[p0022]**

The rigid or substantially rigid and movable piston element may provide a robust sealing element and may substantially seal the vacuum passageway when engaged with the sealing ring. The vacuum device 114 and vacuum cup assembly 110 may be otherwise substantially similar to the vacuum device 14 and vacuum cup assembly 10 discussed above, such that a detailed discussion of the vacuum devices and vacuum cup assemblies will not be repeated herein. The similar or common components or elements of the vacuum devices and vacuum cup assemblies are shown in FIGS. 4-6 (except the vacuum cup is not shown in FIGS. 4-6 ) with the same reference numbers as used in FIGS. 1-3 , but with 100 added to each of the reference numbers. In the illustrated embodiment of FIGS. 4-6 , piston element 154 comprises a generally cylindrically shaped element that is movable along a generally cylindrical-shaped passageway portion 126 a at or near vacuum passageway 126 (although other cross sectional shapes may be implemented without affecting the scope of the present invention). A lower or engaging end 154 a of piston element 154 may be rounded or curved so as to be partially received in and substantially uniformly engage sealing ring 155 when piston element 154 is urged against the sealing ring 155 (as shown in FIG. 5 ) when the air supply is activated to generate the vacuum or partial vacuum in the vacuum passageway. More particularly, when the air supply is activated (such as a pressurized air supply or pneumatic device 129 that supplies pressurized air to the vacuum device, such as via an air hose or li

**[p0022]**

ne 129 a ), the diverting passageway 150 (formed through the body 120 between an inlet port 124 and an upper or outer end of the venting passageway or passageway portion 126 a ) diverts some of the pressurized input air to the upper or outer area or cavity 126 b ( FIG. 5 ) of passageway portion 126 a (between an outer end 154 b of piston element 154 and a cap or cover 156 of vacuum cup assembly 110 ) and thus at the upper or outer end 154 b of piston element 154 (and at the opposite side of the piston element from the sealing ring and venting port). The diverted portion of the pressurized input air thus provides a downward pressure against the piston element to assist in urging the piston element toward engagement with sealing ring 155 . Thus, when moved to a sealing position, the piston element 154 may substantially seal against the sealing ring 155 to substantially seal and separate or isolate the vacuum passageway from atmosphere. The cap or cover 156 is secured to body 120 , and preferably substantially sealed to the body 120 , at the outer end of venting passageway 126 a , such as via a sealing element 157 , such as an O-ring or the like.

**[p0023]**

Piston element 154 also desirably includes a sliding seal or ring 166 circumferentially around the piston element to seal the piston element within the passageway portion 126 a and to enhance sliding or movement of the piston element 154 along the passageway portion. As can be seen in FIGS. 4-6 , sliding seal 166 is received in a groove 154 c formed circumferentially around piston element 154 and between the curved sealing surface 154 a and the outer end 154 b of piston element 154 . Sliding seal 166 limits air leakage past piston element 154 within passageway 126 a , while allowing substantially unrestricted and smooth movement of piston element within the passageway. Vacuum cup assembly 110 includes a biasing element or urging element or spring 158 that functions to bias or urge piston element 154 outward and away from sealing ring 155 and toward a venting position. In the illustrated embodiment, biasing element or spring 158 is partially received within a passageway or recess 154 d formed longitudinally partially along piston element 154 and protrudes therefrom to engage the venturi nozzle body 128 c or to engage a stop element or plate portion (not shown) at or near the lower or inner end of the passageway portion 126 a and/or upper or outer end of the vacuum passageway 126 . Similar to the vacuum cup assembly 10 described above, the biasing force of the biasing element or spring 158 of vacuum cup assembly 110 may be overcome (and the spring or biasing element thus may be compressed) by the force exerted by the diverted portion of the pressurized inlet air at the upper

**[p0023]**

or outer end 154 b of piston element 154 , and/or by the force exerted by the vacuum or partial vacuum generated within the vacuum passageway.

**[p0024]**

When the vacuum source or pressurized air supply is reduced or deactivated (and the diverted air is reduced or eliminated so that it no longer exerts sufficient pressure or force at the outer end 154 b of piston element 154 to overcome the spring force or biasing force), the biasing force may overcome the vacuum pressure within the vacuum passageway and may move the piston element outward to disengage the piston element from the sealing ring. When the piston element is moved away from the sealing ring so that the curved engaging surface 154 a is remote or spaced from sealing ring 155 , the vacuum passageway is vented (and thus the vacuum or partial vacuum within the vacuum passageway and vacuum cup is vented and thus dissipated). As can be seen in FIGS. 4 and 6 , the body 120 may include passageways or channels or apertures or ports 168 that provide fluid communication or air flow between passageway 126 a and the air or atmosphere surrounding the vacuum cup assembly. The passageways 168 are located above or outward from the sealing ring 155 , and at the opposite side of sealing ring from the venturi device, such that air does not flow through the passageways 168 to vent the vacuum passageway 126 a when piston element 154 is substantially sealed against sealing ring 155 . Thus, when the piston element 154 is moved away from or disengaged from sealing ring 155 , the vacuum passageway is readily vented to atmosphere, such as via air flow through and along channels or grooves or passageways 168 formed or established along the piston passageway portion 126 a and outside of or ab

**[p0024]**

ove the sealing ring 155 . The piston element 154 and sealing ring 155 thus function to substantially seal the vacuum passageway when the air supply is activated so that the venturi device may generate a vacuum or partial vacuum within the vacuum passageway (when the vacuum cup is engaged with an object), and the piston element may move away from the sealing ring to vent the vacuum passageway when the air supply is deactivated or reduced (to assist in releasing the vacuum cup from the object).

**[p0025]**

Although shown and described as having a movable sealing element, such as a piston element or a diaphragm element, that engages a second sealing element, such as a sealing ring or a venting port, that is located remote from the venturi nozzle along the vacuum and venting passageways, it is envisioned that the movable sealing element may be located elsewhere in or at the vacuum device or body where the sealing device selective seals and vents the vacuum passageway in response to the pressurized air supply being activated and deactivated. For example, the movable sealing element may be movably or flexibly located at or generally around the vacuum port 136 of the venturi device 128 . The second sealing device thus may comprise the venturi nozzle body itself and/or the portion of the body at or adjacent to the venturi nozzle body, and the movable sealing element may seal against the venturi device and/or body portion to seal the venting passageway when the pressurized air supply is activated, and may disengage from the venturi device to vent the vacuum passageway when the pressurized air supply is deactivated. Optionally, the movable sealing element, such as a piston element, may include a flexible or compressible or conformable seal (such as an elastomeric or rubber seal) at an engaging surface, and the piston element may move to engage the flexible seal with a sealing surface along the passageway, such as at an end of the vacuum passageway or at the venturi nozzle or elsewhere within the vacuum device, without affecting the scope of the present invention. Other configurations

**[p0025]**

of a movable sealing element and the diverted air supply and biasing element (preferably all of which are within or integral with the body of the vacuum device) may be implemented while remaining within the spirit and scope of the present invention.

**[p0026]**

The movable sealing element thus functions to selectively seal and vent the vacuum passageway of the body. The venting port or ports may be located anywhere along the venting passageway so as to be exposed or in fluid communication with the vacuum passageway when the sealing element is in the venting position. It is envisioned that, if the movable sealing element is not substantially sealed against the walls of the venting passageway as it moves therealong (such as if a movable piston element includes longitudinal passageways along its outer circumferential region), the venting port may be located further along the venting passageway, and may be located at the cap or cover, without affecting the scope of the present invention. Thus, the venting port or ports may be located at various locations, as long as the venting passageway and venting ports are selectively sealed or isolated from the vacuum passageway by the sealing element when the sealing element is moved to the sealing position, and are selectively opened or in fluid communication with the vacuum passageway when the sealing element is moved to the venting position.

**[p0027]**

Optionally, and as shown in FIGS. 4-10 , the vacuum cup assembly may include a venturi silencer device or noise reducing device 210 , which may be located at a discharge end 128 a of venturi device or nozzle 128 to reduce the noise generated by the venturi device during operation of the air supply and vacuum cup assembly. The silencer 210 includes a casing or housing 212 that is mounted or attached to the body 120 of the vacuum device and that defines a cavity or chamber 214 at the discharge end of the venturi device. The housing includes a conical shaped air diverter 216 protruding from an outer end portion 212 a of housing 212 and generally toward the discharge end of the venturi device, and includes a plurality of outlet holes or discharge holes 218 radially spaced around the housing 212 . As best shown in FIGS. 9 and 10 , the housing 212 has an outer end portion 212 a and a cylindrical wall or portion 212 b . Cylindrical wall or portion 212 b cooperates with the outer end portion 212 a of housing 212 to define the cavity 214 through which air flows from the discharge end of the venturi device and out through the holes 218 . The conical diverter 216 protrudes from the end portion 212 a and toward the discharge end of the venturi device when the silencer is attached to the body 120 . The housing 212 preferably has generally smooth transition curves or radii of curvature at the transition regions or junction 212 c between the outer end portion 212 a and the cylindrical wall or portion 212 b , and preferably has generally smooth transition curves or radii of curvature at th

**[p0027]**

e transition regions or junction 212 d between the conical diverter 216 and the outer end portion 212 a . The smooth radii of curvatures at the transition regions 212 c , 212 d provide a substantially smooth transition for the air flow as the air flows along the conical diverter 216 and as the air is diverted radially outward toward and through the smaller, radially spaced apart discharge holes 218 . Thus, the silencer device 210 reduces turbulence in the air flow to reduce the noise generated by the flow of air out of the venturi device.

**[p0028]**

Cylindrical wall or portion 212 b also functions to attach the silencer device 210 to the body of the vacuum device. In the illustrated embodiment of FIGS. 4-6 , cylindrical portion 212 b of housing 212 is formed to receive a narrowed portion 120 a of the body 120 at the discharge end 128 a of the venturi device 128 . The housing 212 of silencer 210 may be press fit over the narrowed end portion 120 a , or may be otherwise attached or secured to the body 120 of the vacuum cup assembly and generally at or near the discharge end of the venturi device or nozzle. The cavity or chamber 214 , the conical-shaped diverter 216 and the curved transitional regions 212 c , 212 d at the outer end portion 212 a of the silencer 210 function to reduce turbulence and absorb some of the noise as the air flows from the discharge end 128 a of the venturi 128 through the cavity 214 and out the discharge openings 218 . The holes 218 , although relatively small, are preferably large enough to allow most debris that may flow through the venturi to pass therethrough, so that the holes limit or substantially preclude obstruction of the air flow through the silencer. Thus, the silencer device of the present invention may achieve reduced noise levels during operation of the air supply and venturi device, while limiting obstruction of the air flow through the silencer device. The present invention thus provides an enhanced silencer over known or conventional types of silencers, which typically include a screen or filter element that is prone to clogging or becoming at least partially obstructed by debr

**[p0028]**

is during use.

**[p0029]**

Therefore, the vacuum cup assembly of the present invention may be engaged with an object and a vacuum or partial vacuum may be created or generated within the vacuum cup to substantially seal the vacuum cup to the object surface. The vacuum cup assembly, and the object substantially sealed thereto, may then be moved to a desired location. When at the targeted destination, the vacuum source or air supply may be deactivated to release or vent the vacuum within the assembly so as to readily release the object from the vacuum cup assembly. The vacuum cup assembly of the present invention thus utilizes a single air line or hose or input and provides both vacuum or suction for sealing against and lifting panels or objects and venting for removal or blow off of panels or objects. The pressurized air enters the inlet or input port and passes through the venturi nozzle to create at least a partial vacuum at the vacuum cup and within the vacuum passageway of the body. During operation of the pressurized air supply, a small amount of pressurized input air is diverted to an area or chamber at or above a movable or flexible sealing element, such as a diaphragm or a piston element. The diverted pressurized air pushes or urges the sealing element downward or toward and against another sealing element (such as an outer portion of the body or a sealing ring or the like) to substantially seal or close the vacuum passageway (or otherwise substantially isolate the vacuum passageway from the atmosphere at the vacuum device), allowing the vacuum to be created in the vacuum passageway and at the

**[p0029]**

vacuum cup. Thus, when the diverted input air is providing pressure above or outside of the first or movable sealing element, the sealing element remains substantially sealed within the vacuum passageway, such that there is a vacuum generated at the vacuum passageway at or below or inside of the sealing element (when the vacuum cup is engaged with an object).

**[p0030]**

When the venturi input air is reduced or shut off, the diverted input air at the outer end or side of the sealing element is reduced or eliminated, thereby allowing the biasing element or spring to move or push or urge the movable or flexible sealing element away from the other sealing element or ring or port to disengage the sealing elements and, thus, to vent the vacuum passageway to atmosphere. When the sealing elements are disengaged, the atmospheric pressure can rapidly enter the vacuum passageway and the vacuum cup, thereby relieving substantially all the vacuum within the vacuum cup and vacuum passageway and releasing or assisting in releasing the panel or object from the vacuum cup. Although shown and described as being implemented with a vacuum cup for sealing the vacuum cup relative to an object, the automatic release venturi device or vacuum device of the present invention may be suitable for use in other material handling applications that may otherwise handle objects or material by generating a vacuum when a pressurized air supply is activated and automatically release or vent the vacuum when the pressurized air supply is deactivated, while remaining within the spirit and scope of the present invention.

**[p0031]**

Therefore, the auto-release venturi device or vacuum device of the present invention provides a vacuum or partial vacuum that may be readily applied to a vacuum cup to substantially seal the vacuum cup to an object, and that may be readily and automatically vented to atmosphere to release the object from the vacuum cup. The sealing and venting device or assembly or element substantially seals the vacuum passageway when the vacuum source is activated to allow the pneumatic device or pressurized air supply to generate or create a vacuum or partial vacuum at the vacuum cup. The sealing and venting device is readily and automatically disengaged when the pneumatic device is deactivated to substantially vent the vacuum passageway to atmosphere to release the object from the vacuum cup. The movable sealing element or membrane or piston element of the venting device may be engaged against a second sealing element or venting port or body or sealing ring or the like (which may be substantially fixed or non-moving relative to the vacuum device body) in response to the diverted pressurized air provided to the movable sealing element at an opposite side of the sealing element from the vacuum passageway and vacuum device or venturi, such that the pressure differential at the sealing element causes the movable sealing element to substantially seal or close the vacuum passageway. When the pressurized air supply is reduced or deactivated and the diverted pressurized air is thus reduced or eliminated, the movable sealing element may disengage from the second sealing element or body or sealin

**[p0031]**

g ring or otherwise move or flex to open or vent the vacuum passageway to atmosphere, such as in response to the biasing element. The vacuum at the vacuum passageway and vacuum cup thus may be readily vented to atmosphere to release the vacuum cup from the object at the desired or targeted destination or location. Preferably, the body of the vacuum device comprises a unitarily formed device, with the vacuum passageway, the venturi passageway, the diverting passageway, and the venting passageway formed or bored at least partially therethrough, and with the sealing elements disposed at or within the body of the vacuum device, such that the vacuum device comprises an integral vacuum device with the sealing element and diverting passageway incorporated or integrated at or in the body of the vacuum device.

**[p0032]**

Changes and modifications to the specifically described embodiments may be carried out without departing from the principles of the present invention, which is intended to be limited only by the scope of the appended claims as interpreted according to the principles of patent law.

## Figure captions

- **Figure 1:** FIG. 1 is a side elevation of a vacuum cup assembly with a vacuum device in accordance with the present invention;
- **Figure 2:** FIG. 2 is an exploded perspective view of a vacuum device in accordance with the present invention;
- **Figure 3:** FIG. 3 is a sectional view of the vacuum device of the present invention;
- **Figure 4:** FIG. 4 is an exploded perspective view of another vacuum device in accordance with the present invention, with a piston that is movable to seal or vent the vacuum passageway;
- **Figure 5:** FIG. 5 is a sectional view of the vacuum device of FIG. 4 , shown with the piston in a sealing orientation;
- **Figure 6:** FIG. 6 is another sectional view of the vacuum device of FIG. 4 , shown with the piston in a venting orientation;
- **Figure 7:** FIG. 7 is a perspective view of a venturi silencer useful with a venturi vacuum device;
- **Figure 8:** FIG. 8 is an end elevation of the venturi silencer of FIG. 7 ;
- **Figure 9:** FIG. 9 is a side elevation of the venturi silencer of FIGS. 7 and 8 ; and
- **Figure 10:** FIG. 10 is a sectional view of the venturi silencer taken along the line X-X in FIG. 8 .

## Classifications

- B25B11/007
- B25J15/0625
- B25B11/007
- B25J15/0616
- B25J15/0616
- B25J15/0633
- B25J15/0633
- B25J15/0675
- B25J15/0675
- B65B31/04
- B65G47/91
- B65G47/91
- F04F5/20
- F04F5/20
- F04F5/52
- F04F5/52
- Y10T137/87893
- Y10T137/87893

## Cited patent documents

- [US-1228690-A](https://patents.google.com/patent/US1228690A/en) — PRS
- [US-2003230694-A1](https://patents.google.com/patent/US20030230694A1/en) — PRS
- [US-2273679-A](https://patents.google.com/patent/US2273679A/en) — PRS
- [US-2523157-A](https://patents.google.com/patent/US2523157A/en) — PRS
- [US-2850279-A](https://patents.google.com/patent/US2850279A/en) — PRS
- [US-3033298-A](https://patents.google.com/patent/US3033298A/en) — PRS
- [US-3152828-A](https://patents.google.com/patent/US3152828A/en) — PRS
- [US-3181563-A](https://patents.google.com/patent/US3181563A/en) — PRS
- [US-3223442-A](https://patents.google.com/patent/US3223442A/en) — PRS
- [US-3272549-A](https://patents.google.com/patent/US3272549A/en) — PRS
- [US-3349927-A](https://patents.google.com/patent/US3349927A/en) — PRS
- [US-3568959-A](https://patents.google.com/patent/US3568959A/en) — PRS
- [US-3694894-A](https://patents.google.com/patent/US3694894A/en) — PRS
- [US-3749353-A](https://patents.google.com/patent/US3749353A/en) — PRS
- [US-3901502-A](https://patents.google.com/patent/US3901502A/en) — PRS
- [US-3921971-A](https://patents.google.com/patent/US3921971A/en) — PRS
- [US-3957296-A](https://patents.google.com/patent/US3957296A/en) — PRS
- [US-3967849-A](https://patents.google.com/patent/US3967849A/en) — PRS
- [US-3970341-A](https://patents.google.com/patent/US3970341A/en) — PRS
- [US-4006929-A](https://patents.google.com/patent/US4006929A/en) — PRS
- [US-4073602-A](https://patents.google.com/patent/US4073602A/en) — PRS
- [US-4121865-A](https://patents.google.com/patent/US4121865A/en) — PRS
- [US-4266904-A](https://patents.google.com/patent/US4266904A/en) — PRS
- [US-4432701-A](https://patents.google.com/patent/US4432701A/en) — PRS
- [US-4451197-A](https://patents.google.com/patent/US4451197A/en) — PRS
- [US-4453755-A](https://patents.google.com/patent/US4453755A/en) — PRS
- [US-4548396-A](https://patents.google.com/patent/US4548396A/en) — PRS
- [US-4600228-A](https://patents.google.com/patent/US4600228A/en) — PRS
- [US-4662668-A](https://patents.google.com/patent/US4662668A/en) — PRS
- [US-4708381-A](https://patents.google.com/patent/US4708381A/en) — PRS
- [US-4747634-A](https://patents.google.com/patent/US4747634A/en) — PRS
- [US-4762354-A](https://patents.google.com/patent/US4762354A/en) — PRS
- [US-4852926-A](https://patents.google.com/patent/US4852926A/en) — PRS
- [US-4957318-A](https://patents.google.com/patent/US4957318A/en) — PRS
- [US-5029383-A](https://patents.google.com/patent/US5029383A/en) — PRS
- [US-5172922-A](https://patents.google.com/patent/US5172922A/en) — PRS
- [US-5188411-A](https://patents.google.com/patent/US5188411A/en) — PRS
- [US-5190332-A](https://patents.google.com/patent/US5190332A/en) — PRS
- [US-5193776-A](https://patents.google.com/patent/US5193776A/en) — PRS
- [US-5211435-A](https://patents.google.com/patent/US5211435A/en) — PRS
- [US-5222854-A](https://patents.google.com/patent/US5222854A/en) — PRS
- [US-5345935-A](https://patents.google.com/patent/US5345935A/en) — PRS
- [US-5609377-A](https://patents.google.com/patent/US5609377A/en) — PRS
- [US-5617338-A](https://patents.google.com/patent/US5617338A/en) — PRS
- [US-6155796-A](https://patents.google.com/patent/US6155796A/en) — PRS
- [US-6213521-B1](https://patents.google.com/patent/US6213521B1/en) — PRS
- [US-6283246-B1](https://patents.google.com/patent/US6283246B1/en) — PRS
- [US-6318533-B1](https://patents.google.com/patent/US6318533B1/en) — PRS
- [US-6364054-B1](https://patents.google.com/patent/US6364054B1/en) — PRS
- [US-6437560-B1](https://patents.google.com/patent/US6437560B1/en) — PRS
- [US-6454333-B2](https://patents.google.com/patent/US6454333B2/en) — PRS
- [US-6502877-B2](https://patents.google.com/patent/US6502877B2/en) — PRS

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
