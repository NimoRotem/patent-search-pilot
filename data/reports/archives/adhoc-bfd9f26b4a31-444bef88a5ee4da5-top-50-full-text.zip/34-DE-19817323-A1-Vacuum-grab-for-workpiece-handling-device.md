# 34. Vacuum grab for workpiece handling device

- **Archive rank:** 34 of 50
- **Publication:** [DE-19817323-A1](https://patents.google.com/patent/DE19817323A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/007865018/publication/DE19817323A1?q=pn%3DDE19817323A1)
- **Publication date:** 1999-10-28
- **Filing date:** 1998-04-18
- **Earliest priority:** 1998-04-18
- **Family:** 7865018
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** SCHMALZ J GMBH
- **Inventors:** SCHMALZ KURT; SCHMALZ WOLFGANG; STOCKBURGER RALF

## Abstract

The grab has a suction plate (12) with elastic sealing lip (20), connected to an underpressure source. The plate is fastened to a connector (24) via a joint with an elastic body (28), which is non-turnably connected to connector and grab (10). A suction channel (42) extends through connector, elastic body, and suction plate. The connector is formed as a flanged sleeve and is screw-fastened to a lifting device. The elastic body consists of an elastomer material, e.g. rubber, and has an integrated webbing insert.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-19817323-A1/ops000.png)

![Sketch 1 for DE-19817323-A1](https://nimo.iptorch.com/refdrawing/DE-19817323-A1/ops000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-19817323-A1/ops001.png)

![Sketch 2 for DE-19817323-A1](https://nimo.iptorch.com/refdrawing/DE-19817323-A1/ops001.png)

## Claims

### Claim 1 (independent)

Sauggreifer (10), mit einer an einer Unterdruckquelle anschließbaren und eine Dichtlippe (20) aus elastischem Material aufweisenden Saugplatte (12), die über ein an ihr angeordnetes Verbindungsstück (24) an einer Hubvorrichtung befestigbar ist, wobei Saugplatte (12) und Verbindungsstück (24) über ein Gelenk (26) taumelfähig miteinander verbunden sind, von dem Gelenkteile (30, 32) sowohl am Verbindungsstück (24) als auch am Sauggreifer (10) gehalten sind, dadurch gekennzeichnet, dass das Gelenk (26) einen elastischen Körper (28) aufweist, der zwischen Verbindungsstück (24) und Sauggreifer (10) angeordnet und mit beiden drehfest verbunden ist.1. Suction pads (10) connectable with a to a vacuum source, a sealing lip (20) of elastic material having suction plate (12) which is attachable to a lifting device on a valve disposed at its connecting piece (24), said suction plate (12) and Connecting piece ( 24 ) are connected to each other in a wobble manner via a joint ( 26 ), of which joint parts ( 30 , 32 ) are held both on the connecting piece ( 24 ) and on the suction pad ( 10 ), characterized in that the joint ( 26 ) has an elastic Body ( 28 ) which is arranged between the connecting piece ( 24 ) and suction pad ( 10 ) and is connected to both in a rotationally fixed manner.

### Claim 2

Sauggreifer nach Anspruch 1, dadurch gekennzeichnet, dass Verbindungsstück (24) und elastischer Körper (28) durch einen die Saugplatte (12) durchdringenden Saugkanal (42) durchsetzt sind.2. Suction gripper according to claim 1, characterized in that the connecting piece ( 24 ) and the elastic body ( 28 ) are penetrated by a suction channel ( 42 ) penetrating the suction plate ( 12 ).

### Claim 3

Sauggreifer nach Anspruch 1 oder 2, dadurch gekennzeichnet, dass der elastische Körper (28) einerseits an der freien Stirnfläche eines endseitigen Außenflansches (30) des Verbindungsstückes (24) und andererseits an einer Befestigungsfläche eines starren Trägers (13) des Sauggreifers (10) gehalten ist, an dem ein die Dichtlippe (20) tragender Saugring befestigt ist.3. suction pad according to claim 1 or 2, characterized in that the elastic body ( 28 ) on the one hand on the free end face of an end outer flange ( 30 ) of the connecting piece ( 24 ) and on the other hand on a fastening surface of a rigid support ( 13 ) of the suction pad ( 10 ) is held on which a suction ring carrying the sealing lip ( 20 ) is attached.

### Claim 4

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass das Verbindungsstück (24) mit der Hubvorrichtung verschraubbar ist.4. Suction gripper according to one of the preceding claims, characterized in that the connecting piece ( 24 ) can be screwed to the lifting device.

### Claim 5

Sauggreifer nach Anspruch 3, dadurch gekennzeichnet, dass die trägerseitige Befestigungsfläche durch die freie Stirnfläche eines endseitigen Außenflansches (32) einer in den Träger (13) abgedichtet eingeschraubten, diesen durchsetzenden Flanschhülse (34) gebildet ist.5. Suction pad according to claim 3, characterized in that the carrier-side fastening surface is formed by the free end face of an end-side outer flange ( 32 ) of a flange sleeve ( 34 ) which is screwed tightly into the carrier ( 13 ) and passes through it.

### Claim 6

Sauggreifer nach Anspruch 5, dadurch gekennzeichnet, dass von der freien Stirnfläche des Außenflansches (30) des Verbindungsstückes (24) axial eine zweite den elastischen Körper (28) mit radialem Abstand durchsetzende Flanschhülse (40) ab- und in die Flanschhülse (34) des Trägers (13) des Sauggreifers (10) hineinragt, die endseitig einen Außenflansch (44) trägt, dem in axialem Abstand innerhalb der Träger-Flanschhülse (34) im Bereich ihres den Außenflansch (32) tragenden Hülsenendes als Anschlag (46) eine Innenringschulter zugeordnet ist.6. suction pad according to claim 5, characterized in that from the free end face of the outer flange ( 30 ) of the connecting piece ( 24 ) axially a second through the elastic body ( 28 ) with a radial distance penetrating flange sleeve ( 40 ) and into the flange sleeve ( 34 ) of the carrier ( 13 ) of the suction gripper ( 10 ) protrudes, which at the end carries an outer flange ( 44 ), one at an axial distance inside the carrier flange sleeve ( 34 ) in the region of its sleeve end carrying the outer flange ( 32 ) as a stop ( 46 ) Inner ring shoulder is assigned.

### Claim 7

Sauggreifer nach Anspruch 6, dadurch gekennzeichnet, dass der Außenflansch (44) der vom Verbindungsstück (24) axial abragenden Flanschhülse (40) einen Außendurchmesser aufweist, der kleiner ist als der Innendurchmesser der Träger-Flanschhülse (34).7. Suction gripper according to claim 6, characterized in that the outer flange ( 44 ) of the axially projecting from the connecting piece ( 24 ) flange sleeve ( 40 ) has an outer diameter which is smaller than the inner diameter of the carrier flange sleeve ( 34 ).

### Claim 8

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass das Verbindungsstück (24) als Flanschhülse ausgebildet ist.8. Suction pad according to one of the preceding claims, characterized in that the connecting piece ( 24 ) is designed as a flange sleeve.

### Claim 9

Sauggreifer nach einem der Ansprüche 3 bis 8, dadurch gekennzeichnet, dass das Verbindungsstück (24) und die von diesem axial abragende Flanschhülse (40) miteinander verschraubt sind.9. Suction pad according to one of claims 3 to 8, characterized in that the connecting piece ( 24 ) and the axially projecting flange sleeve ( 40 ) are screwed together.

### Claim 10

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass der elastische Körper aus Metall besteht und wellrohr- oder balgartig ausgebildet ist.10. suction pad according to one of the preceding claims, characterized in that the elastic body Metal and corrugated pipe or bellows-shaped is.

### Claim 11

Sauggreifer nach einem der Ansprüche 1 bis 10, dadurch gekennzeichnet, dass der elastische Körper (28) aus elastomerem Material, wie Gummi, besteht.11. Suction pad according to one of claims 1 to 10, characterized in that the elastic body ( 28 ) consists of elastomeric material, such as rubber.

### Claim 12

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass in den elastischen Körper (28) wenigstens eine Gewebeeinlage integriert ist. Suction gripper according to one of the preceding claims, characterized in that at least one fabric insert is integrated in the elastic body ( 28 ).

### Claim 13

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass der elastische Körper (28) ringscheibenförmig ausgebildet ist.13. Suction pad according to one of the preceding claims, characterized in that the elastic body ( 28 ) is designed in the form of an annular disk.

### Claim 14

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass beim Betätigen des Gelenks (26) der Gelenkpunkt (48) sich bei zunehmendem Schwenkwinkel (α, β) in Richtung der Werkstückfläche (22) verlagert.14. Suction gripper according to one of the preceding claims, characterized in that when the joint ( 26 ) is actuated, the joint point ( 48 ) moves with increasing pivot angle (α, β) in the direction of the workpiece surface ( 22 ).

## Full description

PERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansSingle lifting units; Only one suction cupPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippersPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansCircular shape

Description

Translated from German

Die Erfindung betrifft einen Sauggreifer in einer im

Oberbegriff des Anspruches 1 erlÃ¤uterten Bauart.The invention relates to a suction pad in a

Preamble of claim 1 explained type.

Sauggreifer dieser AusfÃ¼hrungsform sind bekannt und werden von

der Anmelderin hergestellt und vertrieben.Suction pads of this embodiment are known and are known from

manufactured and distributed by the applicant.

Sie sind derart konzipiert, dass sich ihre durch ein Formteil

aus Gummi bestehende Saugplatte mit ihrer Dichtlippe auch dann

an einer FlÃ¤che eines mittels einer Hubvorrichtung zu

transportierenden WerkstÃ¼ckes durch Ansaugen festlegen lÃ¤sst,

wenn diese FlÃ¤che im Raum so orientiert ist, dass sie, bezogen

auf die Hubrichtung des Sauggreifers, von einer zur

Hubrichtung senkrechten Lage abweicht.

They are designed in such a way that their part is formed

rubber suction plate with its sealing lip even then

on a surface by means of a lifting device

allows the workpiece to be transported to be fixed by suction,

if this surface in the room is oriented so that it is related

on the lifting direction of the suction pad, from one to the

Vertical direction deviates from the stroke direction.

Â

Diese selbsttÃ¤tige Lageanpassung des Sauggreifers an

WerkstÃ¼ckflÃ¤chen wird mittels eines sphÃ¤rischen Gelenkes

erreicht, das einen kugel- oder teilkugelfÃ¶rmigen Gelenkteil

aufweist, der an das freie Ende des den Sauggreifer tragenden

VerbindungsstÃ¼ckes angeformt ist.This automatic position adjustment of the suction pad

Workpiece surfaces are created using a spherical joint

reached that a spherical or partially spherical joint part

has, which to the free end of the suction cup carrying

Connector is molded.

Dieser Gelenkteil ist mit einer zentralen, konischen

Ausnehmung eines in die Saugplatte integrierten, starren

TrÃ¤gers in Eingriff und wird darin durch einen auf den TrÃ¤ger

aufgeschraubten und am sphÃ¤rischen Gelenkteil formschlÃ¼ssig

anliegenden Sicherungsring spielfrei, jedoch verdrehbar

gehalten. Der Sauggreifer ist dadurch am VerbindungsstÃ¼ck

taumelfÃ¤hig angeordnet.This joint part is with a central, conical

Recess of a rigid integrated in the suction plate

Carrier engages and is in it by one on the carrier

screwed and form-fitting on the spherical joint part

adjacent circlip free of play, but rotatable

held. The suction cup is thus on the connector

arranged wobble.

Die Fertigung und die Montage eines derartigen Gelenkes ist

mit entsprechend groÃer PrÃ¤zision vorzunehmen, was material- und

zeitaufwendig ist und bei der Herstellung solcher

Sauggreifer kostenmÃ¤Ãig entsprechend zu Buche schlÃ¤gt.The manufacture and assembly of such a joint is

to carry out with great precision what material and

is time consuming and in the manufacture of such

Suction pad costs accordingly.

Dabei erfordert diese Art der Anlenkung einen speziellen

Aufbau des Sauggreifers, weshalb es nicht mÃ¶glich ist,

Sauggreifer in einer anderen Ausbildung zum Zwecke einer

selbsttÃ¤tigen Anpassung an unterschiedliche Lagen von

WerkstÃ¼ckflÃ¤chen mit einem solchen Gelenk nachzurÃ¼sten.This type of articulation requires a special one

Structure of the suction pad, which is why it is not possible

Suction cup in another training for the purpose of a

automatic adjustment to different locations of

Retrofit workpiece surfaces with such a joint.

Des weiteren befindet sich der sphÃ¤rische Gelenkteil

konstruktionsbedingt in einem axialen Abstand zur Dichtlippe

der Saugplatte, woraus der Nachteil resultiert, dass wÃ¤hrend

einer Schwenkbewegung des Sauggreifers zur Anpassung seiner

Lage an die Winkellage der WerkstÃ¼ckflÃ¤che dessen Dichtlippe,

aufgrund des aus dem Abstand des Gelenkpunktes zur

WerkstÃ¼ckoberflÃ¤che gegebenen Hebelarmes, zugleich relativ zur

WerkstÃ¼ckflÃ¤che verschoben wird, um, mit Bezug auf die

Hubrichtung, zumindest teilweise einen radialen und ggf. auch

axialen Versatz auszugleichen. Durch solche Radialbewegungen

der ringfÃ¶rmigen Dichtlippe wird die Standzeit des

Sauggreifers herabgesetzt.Furthermore, the spherical joint part is located

due to the design, an axial distance from the sealing lip

Â the suction plate, resulting in the disadvantage that during

a swiveling movement of the suction pad to adjust it

Position at the angular position of the workpiece surface, its sealing lip,

due to the distance from the hinge point to

Workpiece surface given lever arm, at the same time relative to

Workpiece surface is shifted to, with respect to the

Stroke direction, at least partially a radial and possibly also

to compensate for axial misalignment. Through such radial movements

the annular sealing lip will the service life of

Suction cup lowered.

Um dieses kinematische Problem besser in den Griff zu

bekommen, hat man den Abstand des Gelenkpunktes zur

WerkstÃ¼ckoberflÃ¤che dadurch mÃ¶glichst klein gehalten, dass der

sphÃ¤rische Gelenkteil in der Saugplatte entsprechend tief

gelagert wurde. Dadurch mÃ¼sste aber der Durchmesser des kugel- oder

teilkugelfÃ¶rmigen Gelenkteils stark reduziert werden, was

mit einer entsprechenden Verringerung der mittels der

Hubvorrichtung zu handhabenden Maximallast zu erkaufen war.To better handle this kinematic problem

you get the distance of the hinge point to

Workpiece surface kept as small as possible that the

spherical joint part in the suction plate correspondingly deep

was stored. This would have the diameter of the ball or

partially spherical joint part can be greatly reduced, what

with a corresponding reduction in means of

Lifting device to handle maximum load was to buy.

Die taumelfÃ¤hige Anlenkung der Saugplatte am VerbindungsstÃ¼ck

erfordert auÃerdem ein spezielles RÃ¼ckstellmittel, wie eine

Feder, um den Sauggreifer in seiner Ausgangslage in einer zur

Achse des VerbindungsstÃ¼ckes senkrechten Ebene zu halten.The swiveling articulation of the suction plate on the connector

also requires a special reset means such as one

Spring to the suction cup in its initial position in a

Keep axis of the connector vertical plane.

SchlieÃlich ist ohne spezielle Anschlagmittel nicht zu

vermeiden, dass sich der Sauggreifer relativ zum

VerbindungsstÃ¼ck verdrehen kann, was insbesondere die Funktion

von Sauggreifern mit oval er Saugplatte beeintrÃ¤chtigen oder

diese ganz auÃer Kraft setzen kann.After all, no special sling gear is needed

avoid that the suction pad relative to the

Â Connector can twist, which in particular the function

of suction cups with an oval suction plate or

can override them entirely.

Der Erfindung liegt die Aufgabe zugrunde, fÃ¼r einen

Sauggreifer mit den im Oberbegriff des Anspruches erlÃ¤uterten

Merkmalen ein Gelenk anzugeben, das sich durch konstruktive

Einfachheit auszeichnet und mit dessen Hilfe sich die

vorstehend erlÃ¤uterten Nachteile vermeiden lassen.The invention is based, for one

Suction pads with those explained in the preamble of the claim

Characteristics indicate a joint that is characterized by constructive

Simplicity distinguishes itself and with its help

Have the disadvantages explained above avoided.

Diese Aufgabe wird erfindungsgemÃ¤Ã durch die kennzeichnenden

Merkmale des Anspruches 1 gelÃ¶st.This object is achieved by the characterizing

Features of claim 1 solved.

Durch die erfindungsgemÃ¤Ã zwischen VerbindungsstÃ¼ck und

Sauggreifer vorgesehene, drehfeste Anordnung eines elastischen

KÃ¶rpers konnte ein Gelenk geschaffen werden, das optimale

Voraussetzungen zur Behebung der oben erlÃ¤uterten Nachteile

der bekannten, gattungsgleichen Sauggreiferkonstruktion

bietet.Due to the invention between the connector and

Suction pad provided, non-rotatable arrangement of an elastic

A joint could be created in the body, the optimal one

Requirements for eliminating the disadvantages explained above

the well-known suction cup construction of the same type

offers.

In kinematischer Hinsicht ermÃ¶glicht die Erfindung, aufgrund

der ElastizitÃ¤t des elastischen KÃ¶rpers, eine Gelenkanordnung

auÃerhalb der Saugplatte, also in relativ groÃem Abstand von

der anzusaugenden WerkstÃ¼ckoberflÃ¤che, ohne dass dies bei

entsprechender Winkellage des WerkstÃ¼ckes zu einer

verschleiÃfÃ¶rdernden Radialverlagerung der Saugplatte auf der

WerkstÃ¼ckoberflÃ¤che fÃ¼hren kann.

In kinematic terms, the invention enables, based on

the elasticity of the elastic body, a joint arrangement

outside the suction plate, i.e. at a relatively large distance from

the workpiece surface to be sucked in without this

corresponding angular position of the workpiece to a

wear-promoting radial displacement of the suction plate on the

Workpiece surface can lead.

Â

Ein weiterer Vorteil dieser durch die Erfindung ermÃ¶glichten

Gelenkanordnung bietet sich in einer einfach und schnell

durchfÃ¼hrbaren Gelenkmontage sowie in der MÃ¶glichkeit,

vorhandene Sauggreifer, deren Saugplatte mit dem

VerbindungsstÃ¼ck bzw. der Hubvorrichtung starr verbunden ist,

ohne Probleme durch ein Zwischenschalten des elastischen

KÃ¶rpers zwischen diese Teile mit einem Taumelgelenk nachrÃ¼sten

zu kÃ¶nnen.Another advantage of this made possible by the invention

Joint arrangement is easy and quick

feasible joint assembly as well as the possibility

existing suction pads, the suction plate with the

Connecting piece or the lifting device is rigidly connected,

without problems by interposing the elastic

Retrofit the body between these parts with a wobble joint

to be able to.

Eine weitere vorteilhafte Eigenschaft des elastischen KÃ¶rpers

besteht darin, dass bei durchzufÃ¼hrenden WerkstÃ¼ckdrehungen

eine weitgehend starre Drehverbindung zwischen Sauggreifer und

Hubvorrichtung gegeben ist, so dass auf eine Verdrehsicherung

zwischen Sauggreifer und VerbindungsstÃ¼ck verzichtet werden

kann.Another advantageous property of the elastic body

is that when the workpiece is rotated

a largely rigid rotary connection between the suction pad and

Lifting device is given, so that an anti-rotation

between the suction pad and the connector

can.

Dabei sind auf dem Markt elastische KÃ¶rper in verschiedenster

AusfÃ¼hrung als Fertigteile erhÃ¤ltlich, so dass sich die Kosten

solcher Gelenkverbindungen auf niedrigstem Niveau halten

lassen.There are various types of elastic bodies on the market

Execution available as finished parts, so the cost

keep such articulations at the lowest level

to let.

So kann der elastische GelenkkÃ¶rper bspw. aus Metall bestehen

und wellrohr- oder balgartig ausgebildet sein. Bevorzugt

findet ein elastischer KÃ¶rper aus elastomerem Material

Verwendung, der insbesondere aus Gummi besteht, in den als

VerstÃ¤rkung wenigstens eine Gewebeeinlage integriert sein

kann.

For example, the elastic joint body can be made of metal

and be corrugated or bellows-like. Prefers

finds an elastic body made of elastomeric material

Use, which consists in particular of rubber, in the as

Reinforcement at least one fabric insert can be integrated

can.

Â

Vorteilhafte Ausgestaltungen der Erfindung sind Gegenstand von

UnteransprÃ¼chen, wobei die durch deren Merkmale erzielbaren

Vorteile in Verbindung mit der Beschreibung eines

AusfÃ¼hrungsbeispieles eines in der Zeichnung gezeigten,

erfindungsgemÃ¤Ãen Sauggreifers erlÃ¤utert sind. Es zeigen:Advantageous embodiments of the invention are the subject of

Subclaims, those achievable by their characteristics

Advantages in connection with the description of a

Embodiment of a shown in the drawing

Suction pad according to the invention are explained. Show it:

Fig. 1 einen vertikalen TeillÃ¤ngsschnitt durch

den mittleren Teil des Sauggreifers; Figure 1 shows a vertical partial longitudinal section through the central part of the suction pad.

Fig. 2 und 3 jeweils Darstellungen gemÃ¤Ã Fig. 1, wobei

Saugplatte und VerbindungsstÃ¼ck in

unterschiedlichen Winkel lagen zueinander

dargestellt sind.Said suction plate and connector in different angular positions FIGS. 2 and 3 are views according to Fig. 1, are presented to each other.

In der Zeichnung ist als Ganzes mit 10 ein Sauggreifer

bezeichnet, wie er zum Anheben und/oder Transportieren von

Lasten, insbesondere von WerkstÃ¼cken, eingesetzt wird. Dessen

Saugplatte 12 weist einen starren, insbesondere metallischen

TrÃ¤ger 13 auf, an dessen Unterseite ein Saugring 14 aus

elastischem Material, insbesondere Gummi, in geeigneter Weise

befestigt ist.In the drawing, a suction gripper is designated as a whole by 10 , as it is used for lifting and / or transporting loads, in particular workpieces. Its suction plate 12 has a rigid, in particular metallic support 13 , on the underside of which a suction ring 14 made of elastic material, in particular rubber, is fastened in a suitable manner.

Beim vorliegenden AusfÃ¼hrungsbeispiel greift dieser Saugring

14 in untere, stirnseitige, hinterschnittene TrÃ¤gerringnuten

16, 18 ein und ist am TrÃ¤ger 13 befestigt.

In the present exemplary embodiment, this suction ring 14 engages in lower, undercut, undercut carrier ring grooves 16 , 18 and is fastened to the carrier 13 .

Der Sauggreifer 10 ist z. B. rotationssymmetrisch ausgebildet;

er kann, je nach Einsatzzweck, auch jede andere geeignete

Umfangsform aufweisen und bspw. oval gestaltet sein.The suction pad 10 is such. B. rotationally symmetrical; depending on the intended use, it can also have any other suitable circumferential shape and can be oval, for example.

Der Saugring 14 ist mit einer im Querschnitt sich nach radial

auÃen verschlankenden Dichtlippe 20 ausgestattet, mit der er

z. B. auf eine ebene WerkstÃ¼ckflÃ¤che 22 aufsetzbar und durch

einen innerhalb der Dichtlippe 20 wirksam werdenden Unterdruck

an dieser zwecks eines WerkstÃ¼cktransports haftend festlegbar

ist.The suction ring 14 is equipped with a sealing lip 20 which narrows radially towards the outside in cross-section, with which it seals z. B. can be placed on a flat workpiece surface 22 and can be fixed by an effective inside the sealing lip 20 negative pressure on the latter for the purpose of workpiece transport.

Der Sauggreifer 10 ist Ã¼ber ein VerbindungsstÃ¼ck 24 an eine

nicht gezeigte Hub- und Transportvorrichtung anbaubar, wobei

er am VerbindungsstÃ¼ck 24 mittels eines Gelenkes 26 in alle

Richtung abkippbar angelenkt ist.The suction pads 10 can be mounted via a connector 24 to a not shown lifting and transporting device, wherein it is hinged be tilted on the connecting piece 24 by a joint 26 in all direction.

Dieses Gelenk 26 bildet ein sogenanntes Flexgelenk, dessen

elastischer GelenkkÃ¶rper 28 verschieden gestaltet sein kann.This joint 26 forms a so-called flexible joint, the elastic joint body 28 of which can be designed differently.

Wie bereits erlÃ¤utert wurde, kÃ¶nnte der GelenkkÃ¶rper 28 aus

Metall gefertigt und bspw. in Art einer Federwendel oder

balgartig ausgebildet sein.As already explained, the joint body 28 could be made of metal and, for example, be designed in the manner of a spring coil or bellows-like.

Der GelenkkÃ¶rper 28 besteht jedoch vorzugsweise aus

elastomerem Material, insbesondere Gummi, und ist an einander

zugekehrten, ebenen BefestigungsflÃ¤chen von Sauggreifer 10 und

VerbindungsstÃ¼ck 24 bevorzugt durch Anvulkanisieren befestigt.

However, the joint body 28 is preferably made of elastomeric material, in particular rubber, and is fastened to facing, flat fastening surfaces of the suction gripper 10 and connecting piece 24, preferably by vulcanization.

Der GelenkkÃ¶rper 28 kann bspw. durch einen entsprechend

bemessenen, geschlossenen Gummiblock gebildet sein, der so

dimensioniert ist, dass, wie in den Fig. 2 und 3 gezeigt,

entsprechende Winkelverlagerungen zwischen den Teilen 10 und

24 mÃ¶glich sind, um ein selbsttÃ¤tiges Anpassen der Lage des

Sauggreifers 10 an eine im Raum unter einem von der

Senkrechten zur Hubrichtung des Sauggreifers 10 abweichenden

Winkellage der WerkstÃ¼ckflÃ¤che 22 zu ermÃ¶glichen.The joint body 28 can, for example, be formed by a suitably dimensioned, closed rubber block which is dimensioned such that, as shown in FIGS. 2 and 3, corresponding angular displacements between the parts 10 and 24 are possible in order to automatically adjust the position of the suction gripper 10 to an angular position of the workpiece surface 22 which deviates from the perpendicular to the lifting direction of the suction gripper 10 in space.

Wie gezeigt, ist der GummigelenkkÃ¶rper 28 zwischen den

einander zugekehrten StirnflÃ¤chen von jeweils einem

endseitigen AuÃenflansch 30 bzw. 32 durch Vulkanisieren

gehalten. Die AuÃenflansche 30, 32 bilden jeweils einen Teil

einer FlanschhÃ¼lse, von denen die eine das ein AuÃengewinde

aufweisende VerbindungsstÃ¼ck 24 bildet, wÃ¤hrend die andere,

mit 36 bezeichnete, mit einem AuÃengewinde in eine zentrale

Gewindebohrung 36 des TrÃ¤gers 12 eingeschraubt ist. Zur

vakuumdichten Verbindung von TrÃ¤ger 12 und FlanschhÃ¼lse 34 ist

zwischen TrÃ¤gerauÃenseite und AuÃenflansch 32 ein auf die

FlanschhÃ¼lse 34 aufgesteckter Dichtring 38 eingespannt.As shown, the rubber joint body 28 is held between the mutually facing end faces by an end-side outer flange 30 or 32 by vulcanization. The outer flanges 30 , 32 each form part of a flange sleeve, one of which forms the connecting piece 24 having an external thread, while the other, designated 36, is screwed into a central threaded bore 36 of the carrier 12 with an external thread. For the vacuum-tight connection of carrier 12 and the flange sleeve 34 between the carrier outside and the outer flange 32, a plugged on the flange sleeve 34 sealing ring 38 is clamped.

Eine weitere FlanschhÃ¼lse ist mit 40 bezeichnet. Sie ist in

ein axiales Innengewinde des VerbindungsstÃ¼ckes 24

eingeschraubt und bildet ein den GelenkkÃ¶rper 28 mit radialem

Abstand durchsetzendes und mit seinem Flanschende in die

FlanschhÃ¼lse 34 eingreifendes, axiales AnsatzstÃ¼ck des

VerbindungsstÃ¼ckes 24, dessen Funktion noch erlÃ¤utert wird.

Another flange sleeve is designated 40 . It is screwed into an axial internal thread of the connecting piece 24 and forms a the joint body 28 at a radial distance by releasing and engaging with its flange into the flange sleeve 34, axial extension of the connection piece 24 whose function will be explained.

Die Teile 24, 28, 34 und 40 bilden gemeinsam eine von einem

Axialkanal 42 durchsetzte Baueinheit, die den Vorteil bietet,

dass durch sie hindurch zugleich das innerhalb des Saugringes

14 benÃ¶tigte Vakuum wirksam werden und somit darauf verzichtet

werden kann, am Sauggreifer 10 noch eine, zum VerbindungsstÃ¼ck

24 externe, spezielle Unterdruckleitung anschlieÃen zu mÃ¼ssen.The parts 24 , 28 , 34 and 40 together form an assembly penetrated by an axial channel 42 , which offers the advantage that the vacuum required within the suction ring 14 also takes effect through it and can therefore be dispensed with on the suction pad 10 , to have to connect 24 external, special vacuum line to the connector.

Wie aus der Zeichnung ersichtlich, ist an die FlanschhÃ¼lse 40

an deren unteres HÃ¼lsenende ein AuÃenflansch 44 angeformt,

dessen AuÃendurchmesser kleiner ist als der Innendurchmesser

der FlanschhÃ¼lse 34. Des weiteren ist diesem AuÃenflansch 44

innerhalb der FlanschhÃ¼lse 34 ungefÃ¤hr in der Ebene ihres

AuÃenflansches 32 ein durch eine angeformte Innenringschulter

46 gebildeter Anschlag zugeordnet, zu dem der AuÃenflansch 44

einen Gegenanschlag bildet.As can be seen from the drawing, an outer flange 44 is formed on the flange sleeve 40 at its lower sleeve end, the outer diameter of which is smaller than the inner diameter of the flange sleeve 34 . Furthermore, this outer flange 44 is assigned a stop formed by a molded inner ring shoulder 46 within the flange sleeve 34 approximately in the plane of its outer flange 32 , to which the outer flange 44 forms a counter stop.

Dieser Gegenanschlag 44 begrenzt bei der Aufnahme einer

relativ groÃen Last die Axialdehnung bzw. Zugbelastung des

GelenkkÃ¶rpers 28 und bildet somit eine mechanische Sicherung.This counter stop 44 limits the axial expansion or tensile load of the joint body 28 when receiving a relatively large load and thus forms a mechanical securing means.

Damit eine Anpassung des Sauggreifers 10 an die rÃ¤umliche Lage

einer WerkstÃ¼ckflÃ¤che 22 mÃ¶glich ist, ohne dass die hierzu

notwendige Deformation des GummigelenkkÃ¶rpers 28 durch die

FlanschhÃ¼lse 40 beeintrÃ¤chtigt wird, ist der GummigelenkkÃ¶rper

28 vorzugsweise als Ringscheibe ausgebildet, deren

Innendurchmesser grÃ¶Ãer ist als der AuÃendurchmesser der

FlanschhÃ¼lse 40.

So that an adaptation of the suction pad 10 to the spatial position of a workpiece surface 22 is possible without the necessary deformation of the rubber joint body 28 being impaired by the flange sleeve 40 , the rubber joint body 28 is preferably designed as an annular disc, the inside diameter of which is larger than the outside diameter of the flange sleeve 40 .

Wie aus der Zeichnung ersichtlich ist, kommt dabei dem

AuÃenflansch 44 der FlanschhÃ¼lse 40 noch eine weitere,

wesentliche Bedeutung zu.As can be seen from the drawing, the outer flange 44 of the flange sleeve 40 has yet another important meaning.

Der GummigelenkkÃ¶rper 28 definiert einen mit 48 bezeichneten

Gelenkpunkt, der sich bei einer Lage des Sauggreifers 10 in

einer zur LÃ¤ngsachse 50 des VerbindungsstÃ¼ckes 24 senkrechten

Ebene a-a zu dieser in einem Abstand b bzw. im Schwerpunkt des

GummigelenkkÃ¶rpers 28 befindet (siehe Fig. 1).The rubber joint body 28 defines an articulation point designated 48 which, when the suction gripper 10 is in a plane aa perpendicular to the longitudinal axis 50 of the connecting piece 24, is at a distance b or in the center of gravity of the rubber joint body 28 (see FIG. 1).

Im Falle einer notwendig werdenden Anpassung der Lage des

Sauggreifers 10 an eine SchrÃ¤glage einer WerkstÃ¼ckflÃ¤che 22

geht dies zwangslÃ¤ufig mit einer unter Druck- oder

Zugbelastung erfolgenden Verformung des GummigelenkkÃ¶rpers 28

um den Gelenkpunkt 48 einher (siehe Fig. 2 und 3).If it becomes necessary to adapt the position of the suction gripper 10 to an inclined position of a workpiece surface 22 , this is inevitably associated with a deformation of the rubber joint body 28 around the hinge point 48 under pressure or tensile load (see FIGS. 2 and 3).

Wird hierbei der Auslenkwinkel Î± (siehe Fig. 2) zwischen den

Teilen 12 und 24 so groÃ, dass der AuÃenflansch 44 der

FlanschhÃ¼lse 40 die InnenumfangsflÃ¤che 52 der FlanschhÃ¼lse 34

berÃ¼hrt, kommt dadurch noch ein spezieller kinematischer

Effekt zur Wirkung, in dem sich der Gelenkpunkt 48 bei

weiterer Auslenkung kontinuierlich in Richtung auf die

WerkstÃ¼ckflÃ¤che 22 verlagert und sich dabei die GrÃ¶Ãe des

Abstandes b, bspw. im Falle eines Auslenkwinkels Î², zu b'

verkleinert (siehe Fig. 3).

If the deflection angle Î± (see FIG. 2) between the parts 12 and 24 is so large that the outer flange 44 of the flange sleeve 40 touches the inner circumferential surface 52 of the flange sleeve 34 , a special kinematic effect comes into effect, in which the articulation point 48 continuously displaced in the direction of the workpiece surface 22 in the event of further deflection, and the size of the distance b, for example in the case of a deflection angle Î², is reduced to b '(see FIG. 3).

Diese Verlagerung des Gelenkpunktes bietet den Vorteil, dass

radialer und ggf. axialer Versatz bei der Hubbewegung des

Sauggreifers 10 zum Ansetzen desselben an eine WerkstÃ¼ckflÃ¤che

22 im Wesentlichen ausgeglichen wird und somit dessen

Dichtlippe 20 auf dieser keine verschleiÃfÃ¶rdernde oder ggf.

nur noch eine vernachlÃ¤ssigbar kleine Verschiebebewegung

durchzufÃ¼hren hat. AuÃerdem schafft der GummigelenkkÃ¶rper 28

eine wirksame Verdrehsicherung zwischen VerbindungsstÃ¼ck 24

und Sauggreifer 10.This displacement of the articulation point has the advantage that radial and possibly axial displacement during the lifting movement of the suction gripper 10 for placing the same on a workpiece surface 22 is substantially compensated for, and thus its sealing lip 20 thereon does not promote any wear-promoting or possibly only a negligibly small displacement movement has to perform. In addition, the rubber joint body 28 creates an effective anti-rotation device between the connecting piece 24 and the suction pad 10 .

## Classifications

- B66C1/0293
- B65G47/91
- B65G47/91
- B66C1/02
- B66C1/0212

## Cited patent documents

- [DE-3036116-C2](https://patents.google.com/patent/DE3036116C2/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
