# 14. Vacuum handling device having a suction nozzle
and gripper part contained within a single housing

- **Archive rank:** 14 of 50
- **Publication:** [US-2005258657-A1](https://patents.google.com/patent/US20050258657A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/007961965/publication/US20050258657A1?q=pn%3DUS20050258657A1)
- **Publication date:** 2005-11-24
- **Filing date:** 2002-09-12
- **Earliest priority:** 2001-09-21
- **Family:** 7961965
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus

## Parties

- **Applicant / assignee:** GEBAUER GUNTER; SCHNATTERER JURGEN
- **Inventors:** GEBAUER GUNTER; SCHNATTERER JURGEN

## Abstract

A vacuum handling device comprises includes a vacuum source having a suction nozzle means ( 6 ) operating on the ejector principle and furthermore a suction gripper ( 3 ) which possesses a gripper part ( 26 ) connected with the suction side of the suction nozzle means ( 6 ). The housing of the vacuum source ( 2 ) and of the suction gripper ( 3 ) constitute a housing unit ( 4 ), the gripper part ( 26 ) being adjustably mounted on the housing unit ( 4 ) for setting in the acting suction direction ( 44 ) thereof.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/8b/e3/2b/2bbd5857c048ff/US20050258657A1-20051124-D00000.png)

![Sketch 1 for US-2005258657-A1](https://patentimages.storage.googleapis.com/8b/e3/2b/2bbd5857c048ff/US20050258657A1-20051124-D00000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/e5/ee/af/73ab13152bcf51/US20050258657A1-20051124-D00001.png)

![Sketch 2 for US-2005258657-A1](https://patentimages.storage.googleapis.com/e5/ee/af/73ab13152bcf51/US20050258657A1-20051124-D00001.png)

## Claims

### Claim 1 (independent)

A vacuum handling device comprising a vacuum source which possesses a suction nozzle means adapted to operate on an ejector principle, a suction gripper which possesses a movable gripper part connected directly with a suction side of the suction nozzle means, and a housing unit having a cavity containing both said suction nozzle means and at least a portion of said gripper part and wherein the gripper part is adjustably mounted on the housing unit for setting in an acting suction direction. 2 . The vacuum handling device as set forth in claim 1 , wherein the housing unit is an integral design. 3 . The vacuum handling device as set forth in claim 1 , wherein the vacuum source and the suction gripper are arranged in the acting suction direction one after the other. 4 . The vacuum handling device as set forth in claim 1 , wherein the suction nozzle means comprises a single suction nozzle. 5 . The vacuum handling device as set forth in claim 1 , wherein the suction nozzle means includes several suction nozzles functionally connected in parallel. 6 . The vacuum handling device as set forth in claim 4 , wherein the suction nozzle is a cartridge, said cartridge being plugged into the housing unit. 7 . The vacuum handling device as set forth in claim 1 , wherein the gripper part is connected fluidwise in the interior of the housing unit with the suction side of the suction nozzle means. 8 . The vacuum handling device as set forth in claim 1 , wherein the adjustably mounted gripper part projects into the housing unit. 9 . The vacuum handling device as set forth in claim 1 , further comprising a spring means effective between the gripper part unit and the housing unit which biases the gripper part into a maximally extended home position, the gripper part being able to be shifted out of position by a setting force (Fv) against the spring force (FF) of the spring means. 10 . A vacuum handling device comprising a vacuum source which possesses a suction nozzle means adapted to operate on an ejector principle, a suction gripper which possesses a movable gripper part connected with a suction side of the suction nozzle means, and a housing unit containing both said suction nozzle means and at least a portion of said gripper part and wherein the gripper part is adjustably mounted on the housing unit for setting in an acting suction direction, and wherein the adjustable gripper part delimits, in the interior of the housing unit an active plenum communicating with the suction side of the suction nozzle means, the vacuum built up in the active plenum being able to cause setting of the gripper part in relation to the housing unit from a farther extended position into a farther retracted position. 11 . The vacuum handling device as set forth in claim 10 , wherein the gripper part is biased into the farther extended position by spring means. 12 . The vacuum handling device as set forth in claim 10 wherein the active plenum is delimited by a piston-like terminal section of the gripper part, which is arranged in a sliding fashion in the interior of the housing unit with a sealing means between it and the housing. 13 . The vacuum handling device as set forth in claim 10 , wherein the gripper part has a at least one suction space on its outer end, such space being connected by way of an aspiration duct extending through the gripper part with the plenum. 14 . The vacuum handling device as set forth in claim 13 , wherein the space is delimited by at least one suction plate or suction cup. 15 . The vacuum handling device as set forth in claim 5 , wherein the suction nozzle is a cartridge, said cartridge being plugged into the housing unit. 16 . A vacuum handling device comprising: a housing having an inlet supply connection, an outlet opening and a cavity formed between said inlet supply connection and said outlet opening; a suction nozzle contained within said housing cavity between said inlet supply connection and said outlet opening, said suction nozzle having a suction opening and producing a suction at said suction opening when a pressure medium is supplied to said inlet supply connection of said housing; and a movable gripper part at least partially slidingly contained within said housing cavity, said gripper part being in direct fluid communication with said suction opening of said suction nozzle for holding an object by vacuum action.

## Full description

**[p0001]**

The invention relates to a vacuum handling device comprising a vacuum source, which possesses a suction nozzle means adapted to operate on the ejector principle and furthermore a suction gripper which possesses a gripper part connected with the suction side of the suction nozzle means. In the case of a vacuum handling device of this type described in the German patent publication (utility model) 20,011,839 an independent vacuum source is provided, which is fitted with a suction nozzle means able, on being supplied with a pressure medium, to produce a suction effect at a suction side. The suction side is connected by a fluid duct with a suction gripper, which comprises a gripper part constituted by a suction cup to be applied to the object to be handled. By the operation of the suction nozzle means air is sucked from the internal space in the gripper part so that the object to be handled is drawn against the gripper part. The German patent publication (utility model) 9,215,404 discloses a suction gripper having a moving gripper part biased by spring means so that on application to an object to be handled a compensation of length of the suction gripper is possible. The suction gripper is kinematically coupled with a handling means and for producing the suction effect may be connected with a pressure medium storage means or a vacuum pump.

**[p0002]**

A comparable arrangement is disclosed in the German patent publication (utility model) 4,133,135 A1. Here a suction gripper provided with a moving gripper part is held on a robot arm, the gripper part being connected by way of a pipe with a vacuum suction system. One object of the present invention is to provide a vacuum handling device of the type initially mentioned, which has a simple structure and compact dimensions. In order to achieve this object there is the provision that the housing of the vacuum source and the suction gripper constitute a housing unit and that the gripper part is mounted in an adjustable manner on the housing unit for setting in its acting suction direction. In the case of this vacuum handling device the vacuum source and the suction gripper are collected together as a compact structural unit, the housing unit present assuming the housing function both as regards the vacuum source and also as regards the suction gripper. If the vacuum handling device is moved and positioned during the use thereof there is accordingly a ganged movement and positioning both of the vacuum source and of the suction gripper. It is in this manner that it is possible to do without movable fluid connections, and it is possible for all components to be collected together in a minimum of space. The support function, which is adjustable in the suction direction, of the gripper part on the housing unit renders possible the assumption of different relative positions of the gripper part and of the housing unit, something which for example permits a certain adaptation in length

**[p0002]**

on application of the gripper part to an object to be handled.

**[p0003]**

Further advantageous developments of the invention are defined in the dependent claims. It would in principle be possible to make up the housing unit of a plurality of housing components permanently connected together. Preferably however a one-piece design of the housing unit is provided. The vacuum source and the suction gripper are preferably arranged in the acting suction direction one after the other, something which renders possible a very slim design. The suction nozzle means may comprise a single suction nozzle for producing the desired vacuum. Should a higher suction power be desired it is possible for the suction nozzle means to comprise a plurality of suction nozzles functionally connected together in series. One or more suction nozzles can be designed in the form of a cartridge-like structural units, which may be installed simply by plugging into the housing unit. It is advantageous for the fluid connection between the gripper part and the suction side of the suction nozzle means to be within the housing unit so that it is possible to do without external fluid lines.

**[p0004]**

In the case of a further convenient design inside the interior of the housing unit the gripper part delimits an active or working plenum communicating with the suction side of the suction nozzle unit, the vacuum building up in the active plenum being able to cause setting of the gripper part in relation to the housing unit from a farther extended position into a farther retracted position. This effect may be employed in order to lift an object without having to move the housing unit itself. When the vacuum handling device has its gripper part applied to an object to be lifted, the object is aspirated by the suction action during operation of the suction nozzle means. Furthermore, the vacuum building up in the active plenum means that the gripper part is withdrawn into the housing unit owing to the pressure differential built up, something which in the case of a vertical alignment of the vacuum handling device means an upward movement of the gripper part with the object sucked onto it. Preferably the gripper part is biased by spring means into the farther out, extended position moved the latter position preferably being the home position of the gripper part.

**[p0005]**

The gripper part has at least one suction space at the outer end thereof, such space being for example defined by a flexible suction cup, and being connected by way of a duct extending through the gripper part with the active plenum. In the following the invention will be described with reference to the accompanying drawings. FIG. 1 is a longitudinal section taken through a preferred embodiment of the vacuum handling device in accordance with the invention, the gripper part being illustrated in two different position on either side of the longitudinal axis. FIG. 2 is a highly diagrammatic representation of a further embodiment of the vacuum handling device whose suction nozzle means is fitted with two suction nozzles connected functionally in parallel. The vacuum handling device 1 is composed of two principal parts, that is to say a first part in the form of a vacuum source 2 and a second part in the form of a suction gripper 3 . These parts constitute a rigid structural unit, same being held together by a housing unit 4 , which constitutes both the housing of the vacuum source 2 and also the housing of the suction gripper 3 .

**[p0006]**

The housing unit 4 preferably possesses an elongated configuration and is preferably manufactured integrally. Admittedly it would be possible to divide up the housing unit 4 into, for instance, two housing components, of which the one would constitute the housing of the vacuum source 2 and the other the housing of the suction gripper 3 and which to form the housing unit would be rigidly and permanently connected together. However the integral housing design of the working example possesses substantial advantages over such a design, more particularly as regards the costs of manufacture and assembly. Preferably the housing unit 4 is designed in the form of a hollow body, which contains a cavity 5 which is preferably continuous in the longitudinal direction and in which the principal components of the device are accommodated. The vacuum source 2 comprises a suction nozzle means 6 with one or more suction nozzles. In the working example of FIG. 1 a single suction nozzle 7 is provided. The working example illustrated in FIG. 2 on the other hand constitutes a vacuum handling device 1 with at least two suction nozzles functionally connected in parallel.

**[p0007]**

At this point it is to be noted that in the case of the working example of FIG. 2 identical reference numerals are employed to the extent parts corresponding to those of FIG. 1 are present. The suction nozzle 7 is seated in the interior of the housing unit 4 . As shown in FIG. 1 it is located in the above mentioned cavity 5 . Its assembly takes place starting at the one end of the housing unit 4 , preferably by insertion or plugging in place. This type of design is preferred when the suction nozzle 7 , as in the present case, is in the form of a cartridge-like structural unit, which is assembled prior to insertion into the housing unit and is then inserted as a whole, that is to say as a unit, into the housing unit 4 . The suction nozzle 7 has at one end an inlet opening 8 , which is constantly connected with a supply connection 12 of the device. In the case of the vertical alignment of the vacuum handling device 1 as illustrated in the drawing the inlet opening 8 is directed upward and the supply connection 12 is located near the top end of the housing unit 4 .

**[p0008]**

The supply connection 12 is provided with connection means 13 , which render possible a fluid-tight and preferably detachable connection of a fluid line 14 as indicated in chained lines. By way of this fluid line 14 a connection of the supply connection 12 with a source of pressure medium may be produced, such pressure medium source preferably being a source of compressed air. It is in this manner that fluid pressure medium may be supplied by way of the supply connection 12 and fed to the inlet opening 8 of the suction nozzle 7 . The connection means 13 are preferably designed in the form of plug connecting means. In the working embodiment illustrated in FIG. 2 the inlet openings 8 of both suction nozzles 7 are jointly connected with the supply connection 12 . Furthermore the suction nozzle 7 has a suction opening 15 at the terminal portion axially opposite to the inlet opening 8 . In the working embodiment this opening is directed downward. Finally the suction nozzle 7 furthermore possesses an outlet opening 16 which is connected with an outlet 17 opening to the outer face of the housing unit 4 , and accordingly leading into the atmosphere, from the housing unit 4 . This exit is in the working example at an angle and preferably at a right angle to the longitudinal axis of the suction nozzle 7 and is located alongside the housing unit 4 .

**[p0009]**

During operation pressure medium introduced by way of supply connection 12 flows through the suction nozzle 7 , it firstly flowing through a jet nozzle duct 18 , wherein it is preferably accelerated to a supersonic speed. After emerging from the jet nozzle duct 18 the pressure medium then runs through an intermediate space 22 and then enters a receiver nozzle duct 23 , which runs to the outlet opening 16 . Thence the pressure medium flows by way of the outlet 17 into the atmosphere. The flow direction of the pressure medium within the suction nozzle 7 extends as far as the outlet opening 16 generally in the longitudinal direction of the suction nozzle 7 . Following this the pressure medium is directed by a deflector wall 24 of the suction nozzle 7 to the laterally arranged outlet 17 . The jet nozzle duct 18 constitutes, together with the receiver nozzle duct 23 , an ejector means, which owing to the pressure medium flowing through it produces an aspirating effect in the intermediate space 22 . Since the intermediate space 22 communicates by way of an internal connecting duct 25 of the suction nozzle 7 with the suction opening 15 there is accordingly an aspirating effect at the suction opening 15 as well.

**[p0010]**

In the case of the working example illustrated in FIG. 2 comprising a plurality of parallel-connected suction nozzles 7 all suction openings 15 are connected together with one another so that there is a simultaneous aspirating effect of all suction nozzles 7 . The suction gripper 3 is axially connected with the vacuum source 2 in the downward direction in the figure. It includes a vacuum gripper part, referred to in the following merely as the gripper part 26 , which is able to hold an object 29 by vacuum action. The gripper part 26 is located partially outside and partially within the housing unit 4 . It is seated on the terminal portion, opposite to the supply connection 12 , of the housing unit 4 , which terminal portion is directed downward in the drawing. The gripper part 26 has, at its free end axially opposite to the housing unit 4 , a flexible suction cup 27 or an at least partially flexible suction plate, which is secured in a sealing manner to a plunger body 28 of the gripper part 26 . The plunger body 28 is aligned in the longitudinal direction of the housing unit 4 and extends into a receiving chamber 32 in the interior of the housing unit 4 . The receiving chamber 32 is preferably constituted by the associated terminal section of the continuous cavity 5 .

**[p0011]**

The inner terminal section 33 axially opposite to the suction cup 27 of the gripper part 26 is piston-like in shape. It is sealingly connected by means of a circumferential seal 34 , making sealing contact, with the circumferential wall of the receiving chamber 32 and accordingly divides the receiving chamber 32 in a sealing manner into two axially sequential spaces 35 and 36 . The space 35 located on the side, which faces the suction nozzle means 6 , of the piston-like terminal section 33 , will be termed the active plenum. It is constantly connected with the suction opening 15 and is accordingly in fluid connection with the suction side of the suction nozzle means. The other, second space 36 communicates constantly with the atmosphere, for example by way of an intermediate space 37 , which is located around the plunger body 28 between the same and a terminating wall 38 delimiting the receiving chamber 32 axially to the outside. The gripper part 26 has an aspiration duct 42 extending axially through it. Such duct opens at one end into the active plenum 35 and at the other end into a suction space 43 delimited by the Suction cup 27 .

**[p0012]**

The aspirating action produced during operation of the suction nozzle means 6 at the suction opening 15 accordingly leads to aspiration of air from the active plenum 35 , the aspiration duct 42 and the suction space 43 . In order to lift an object 29 the vacuum handling device 1 ia placed against the respective object 29 with the open side of the suction cup 27 to the fore. This means that the suction space 43 is sealed off all around it. The aspirating effect of the suction nozzle means 6 produces vacuum on the suction side, as far as the suction space 43 , such vacuum ensuring the object 29 is sucked held against the gripper part 26 . The acting suction direction 44 indicated by an arrow in the drawing, extends in the longitudinal direction of the gripper part 26 and as a rule at a right angle to the plane of extent of the suction opening, covered by the object 29 on it, of the suction space 43 . As shown in clearly in the figures, the suction gripper 3 and the vacuum source 2 are preferably arranged one after the other in the direction 44 of suction action.

**[p0013]**

The suction gripper 3 conveniently possesses spring means 45 biasing the gripper part 26 into a home position moved farther out of the housing unit 41 This home position applies in the case of the gripper part 26 depicted in FIG. 1 to the right of the longitudinal axis 46 of the vacuum handling device. The spring means 45 take effect between the gripper part 26 and the housing unit 4 . Preferably, they are placed in the interior of the active plenum 35 and designed in the form of compression spring means, which bear against the piston-like terminal section 33 of the gripper part 26 and the axially opposite wall of the receiving chamber 32 . Abutment means, which are secured to the housing, serve to ensure that the gripper part 26 is not moved beyond the desired home position out of the housing unit. Such abutment means are in the working example of the invention constituted by the terminal wall 38 against which the gripper part 26 , for instance at its piston-like terminal section, may strike.

**[p0014]**

The gripper part 26 is able to be displaced by a setting force Fv against the spring force FF of the spring means 45 . It can accordingly be set in position in the acting suction direction 44 in relation to the housing unit 4 . The setting force Fv may for example be produced because the vacuum handling device 1 has its gripper part 26 thrust against the object 29 on positioning the object 29 and accordingly the gripper part 26 is shifted a small distance against the spring force in relation to the housing unit 4 . It is in this manner that the positioning of the vacuum handling device 1 in relation to an object 29 is facilitated, since a certain degree of inaccuracy or tolerance is possible as regards positioning. The behavior indicated has a favorable effect when several vacuum handling devices 1 are collected together in a single handling unit and simultaneously are to be applied to an object 29 . The resiliently Elastic adjustability will in this case compensate for different positions of the gripper parts 26 automatically. It is possible to speak of an automatic length compensation.

**[p0015]**

The gripper part 26 slides on being set, its seal 34 running on the inner face of the receiving chamber 32 . It is possible for the setting Fv also to be produced completely or partially by the pressure difference obtaining at the piston-like terminal section 33 . If the gripper part 26 has its suction cup 27 in sealing engagement with the object 29 and then the above mentioned vacuum is produced, the pressure difference will take effect between the lower pressure obtaining in the active plenum 35 and the atmospheric pressure obtaining in the second space 36 in such a manner on the gripper part 26 that there is a resulting pressure force acting in the suction direction and hence the gripper part 26 including the held object 29 will be shifted in relation to the housing unit 4 . Accordingly the object 29 is automatically lifted without any lifting effect being required on the part of the housing unit 4 . The lifting stroke is in this case defined by the axial displacement available for the gripper part 26 .

**[p0016]**

Owing to the joining together of the vacuum source 2 and the suction gripper 3 by way of the housing, there is a structural unit able to be handled in one piece and for whose fixation in place a single, common holding means 48 is sufficient. Separate holders for the vacuum source 2 and the suction gripper 3 are unnecessary. The holding means 48 forms part of, for example, a positioning means, with which the handling means can be moved and positioned with and without any object being held by it. In the case of need the fluid connection between the suction space 43 and the suction opening may run through a flow control valve 47 indicated in chained lines in FIG. 1 . Preferably, such valve is seated in the aspiration duct 42 extending through the plunger body 28 in the longitudinal direction. It may be employed for flow regulation in such a manner that the aspirated flow is also reduced during operation of the suction nozzle means 6 as long as the suction space 43 is covered.

**[p0017]**

In the case of need the housing unit 4 may have further components integrated in it as required for operation. For instance the housing unit 4 may have a means for automatically economizing in air or have a vacuum-controlled valve for controlling the manner of operation. For instance, a compressed air receiver could be integrated from which a gage pressure pulse could be taken in order to kill the built up vacuum for depositing the lifted object 29 as smartly as possible.

## Figure captions

- **Figure 1:** FIG. 1 is a longitudinal section taken through a preferred embodiment of the vacuum handling device in accordance with the invention, the gripper part being illustrated in two different position on either side of the longitudinal axis.
- **Figure 2:** FIG. 2 is a highly diagrammatic representation of a further embodiment of the vacuum handling device whose suction nozzle means is fitted with two suction nozzles connected functionally in parallel.
- **Figure 1:** The vacuum source 2 comprises a suction nozzle means 6 with one or more suction nozzles. In the working example of FIG. 1 a single suction nozzle 7 is provided. The working example illustrated in FIG. 2 on the other hand constitutes a vacuum handling device 1 with at least two suction nozzles functionally connected in parallel.
- **Figure 2:** At this point it is to be noted that in the case of the working example of FIG. 2 identical reference numerals are employed to the extent parts corresponding to those of FIG. 1 are present.
- **Figure 1:** The suction nozzle 7 is seated in the interior of the housing unit 4 . As shown in FIG. 1 it is located in the above mentioned cavity 5 . Its assembly takes place starting at the one end of the housing unit 4 , preferably by insertion or plugging in place.
- **Figure 2:** In the working embodiment illustrated in FIG. 2 the inlet openings 8 of both suction nozzles 7 are jointly connected with the supply connection 12 .
- **Figure 2:** In the case of the working example illustrated in FIG. 2 comprising a plurality of parallel-connected suction nozzles 7 all suction openings 15 are connected together with one another so that there is a simultaneous aspirating effect of all suction nozzles 7 .
- **Figure 1:** The suction gripper 3 conveniently possesses spring means 45 biasing the gripper part 26 into a home position moved farther out of the housing unit 41 This home position applies in the case of the gripper part 26 depicted in FIG. 1 to the right of the longitudinal axis 46 of the vacuum handling device.

## Classifications

- B66C1/0212
- B66C1/0212
- B65G47/91
- B65G47/91
- B65G47/91
- B66C1/02
- B66C1/0256
- B66C1/0256
- B66C1/0293
- B66C1/0293

## Cited patent documents

- [US-3107794-A](https://patents.google.com/patent/US3107794A/en) — PRS
- [US-3568959-A](https://patents.google.com/patent/US3568959A/en) — PRS
- [US-3637249-A](https://patents.google.com/patent/US3637249A/en) — PRS
- [US-3702698-A](https://patents.google.com/patent/US3702698A/en) — PRS
- [US-3834558-A](https://patents.google.com/patent/US3834558A/en) — PRS
- [US-3899087-A](https://patents.google.com/patent/US3899087A/en) — PRS
- [US-3902505-A](https://patents.google.com/patent/US3902505A/en) — PRS
- [US-3967849-A](https://patents.google.com/patent/US3967849A/en) — PRS
- [US-3991997-A](https://patents.google.com/patent/US3991997A/en) — PRS
- [US-402951-A](https://patents.google.com/patent/US402951A/en) — PRS
- [US-4640503-A](https://patents.google.com/patent/US4640503A/en) — PRS
- [US-4655692-A](https://patents.google.com/patent/US4655692A/en) — PRS
- [US-4736938-A](https://patents.google.com/patent/US4736938A/en) — PRS
- [US-4753104-A](https://patents.google.com/patent/US4753104A/en) — PRS
- [US-5076564-A](https://patents.google.com/patent/US5076564A/en) — PRS
- [US-5193776-A](https://patents.google.com/patent/US5193776A/en) — PRS
- [US-5201875-A](https://patents.google.com/patent/US5201875A/en) — PRS
- [US-5277468-A](https://patents.google.com/patent/US5277468A/en) — PRS
- [US-5451086-A](https://patents.google.com/patent/US5451086A/en) — PRS
- [US-5727418-A](https://patents.google.com/patent/US5727418A/en) — PRS
- [US-5755471-A](https://patents.google.com/patent/US5755471A/en) — PRS
- [US-6065789-A](https://patents.google.com/patent/US6065789A/en) — PRS
- [US-6168220-B1](https://patents.google.com/patent/US6168220B1/en) — PRS
- [US-6213521-B1](https://patents.google.com/patent/US6213521B1/en) — PRS
- [US-6663092-B2](https://patents.google.com/patent/US6663092B2/en) — PRS

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
