# 12. Porte-piece a depression

- **Archive rank:** 12 of 50
- **Publication:** [FR-2513160-A1](https://patents.google.com/patent/FR2513160A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/023175295/publication/FR2513160A1?q=pn%3DFR2513160A1)
- **Publication date:** 1983-03-25
- **Filing date:** 1982-09-17
- **Earliest priority:** 1981-09-21
- **Family:** 23175295
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** GERBER SCIENT PRODUCTS INC
- **Inventors:** GORDON THOMAS A; WOOD KENNETH O

## Abstract

CE PORTE-PIECE A DEPRESSION COMPREND UNE PLAQUE DONT LA FACE INTERIEURE EVIDEE DELIMITE AVEC UN FOND UNE CHAMBRE A VIDE QUI EST RACCORDEE A UNE POMPE A VIDE PAR UNE CONDUITE 36 ET QUI COMMUNIQUE AVEC CHACUNE DE NOMBREUSES CELLULES D&#39;ASPIRATION 22, 22 MENAGEES DANS SA FACE SUPERIEURE PAR AUTANT DE TRES PETITS ORIFICES 34. LA SECTION TOTALE DES PETITS ORIFICES 34 EST SUFFISAMMENT PETITE POUR QU&#39;UNE POMPE A VIDE DE CAPACITE RELATIVEMENT FAIBLE SOIT CAPABLE DE MAINTENIR UN VIDE IMPORTANT DANS LA CHAMBRE A VIDE MEME LORSQUE TOUTES LES CELLULES D&#39;ASPIRATION 22, 22 SONT DECOUVERTES. DE CETTE FACON, UNE PIECE 31 DE DIMENSIONS QUELCONQUES PEUT ETRE FIXEE PAR LE PORTE-PIECE AVEC UNE FORCE DE RETENUE SUFFISANTE, MEME SI CETTE PIECE NE RECOUVRE QUE QUELQUES UNES DES CELLULES D&#39;ASPIRATION.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf000.png)

![Sketch 1 for FR-2513160-A1](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf001.png)

![Sketch 2 for FR-2513160-A1](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf002.png)

![Sketch 3 for FR-2513160-A1](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf003.png)

![Sketch 4 for FR-2513160-A1](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf004.png)

![Sketch 5 for FR-2513160-A1](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf005.png)

![Sketch 6 for FR-2513160-A1](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf006.png)

![Sketch 7 for FR-2513160-A1](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf007.png)

![Sketch 8 for FR-2513160-A1](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf008.png)

![Sketch 9 for FR-2513160-A1](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf009.png)

![Sketch 10 for FR-2513160-A1](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf009.png)

[Sketch 11](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf010.png)

![Sketch 11 for FR-2513160-A1](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf010.png)

[Sketch 12](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf011.png)

![Sketch 12 for FR-2513160-A1](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf011.png)

[Sketch 13](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf012.png)

![Sketch 13 for FR-2513160-A1](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf012.png)

[Sketch 14](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf013.png)

![Sketch 14 for FR-2513160-A1](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf013.png)

[Sketch 15](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf014.png)

![Sketch 15 for FR-2513160-A1](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf014.png)

[Sketch 16](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf015.png)

![Sketch 16 for FR-2513160-A1](https://nimo.iptorch.com/refdrawing/FR-2513160-A1/pdf015.png)

## Claims

### Claim 1 (independent)

Porte-pièce à dépression, du type com- 1. Vacuum workpiece carrier, type com prenant des moyens définissant une région de fixation de la pièce, une partie de cette région étant constituée par une surface de contact avec la pièce et qui est définie par une matière imperméable à l'air tandis qu'une autre partie de cette région est constituée par une série de cellules d'aspiration réparties sur cette région, chaque cellule étant entièrement entourée par des parties de ladite surface de contact avec la pièce, de sorte que lesdites cellules sont isolées pneumatiquement les unes des autres le long de lignes situées dans ladite surface, chacune desdites cellules ayant une face dirigée vers l'extérieur de niveau avec ladite surface de contact avec la pièce, face qui est composée au moins en-partie taking means defining a region for fixing the part, a part of this region being constituted by a contact surface with the part and which is defined by an air-impermeable material while another part of this region is constituted by a series of suction cells distributed over this region, each cell being entirely surrounded by parts of said contact surface with the part, so that said cells are pneumatically isolated from each other along lines located in said surface , each of said cells having an outward facing face level with said work contact surface, a face which is composed at least in part d'une portion ouverte; des moyens définissant une cham- an open portion; means defining a cham- bre à vide adaptée pour être reliée à une source de vide; vacuum bre adapted to be connected to a vacuum source; et des moyens définissant une série de passages d'écou- and means defining a series of listening passages lement dont chacun s'étend entre ladite face dirigée vers l'extérieur de sa cellule respective et ladite chambre à vide, ce porte-pièce étant caractérisé en ce que lesdits moyens définissant des passages comprennent, pour chacun desdits passages, des moyens ( 34,64,64 ') définissant un étranglement qui possède une surface de section transversale effective de nombreuses fois plus petite que la surface de ladite partie ouverte de la face ( 29,66) de celle des cellules d'aspiration ( 22, 58,100) qui lui est associée, de sorte qu'il se produit Each of which extends between said face directed towards the outside of its respective cell and said vacuum chamber, this workpiece holder being characterized in that said means defining passages comprise, for each of said passages, means (34, 64.64 ') defining a constriction which has an effective cross-sectional area many times smaller than the area of said open part of the face (29,66) of that of the suction cells (22,58,100) which is associated, so it happens une perte de pression importante à travers cet étrangle- a significant loss of pressure through this constriction ment lorsqu'un vide est établi dans ladite chambre à vide ( 30) et que ladite face ( 29,66) de ladite cellule d'aspiration associée qui lui est associée est découverte ment when a vacuum is established in said vacuum chamber (30) and that said face (29,66) of said associated suction cell associated with it is uncovered par une pièce.by one piece. 18 - 18 -

### Claim 2

Porte-pièce suivant la revendication 1, caractérisé en ce que lesdits moyens qui définissent2. Workpiece holder according to claim 1, characterized in that said means which define une région de fixation de la pièce comprennent une pla- a workpiece attachment region includes a plate que ( 16) ayant une face supérieure ( 18) qui présente une série d'alvéoles ( 28,28) répartis sur son étendue, that (16) having an upper face (18) which has a series of cells (28, 28) distributed over its extent, lesdits alvéoles constituant lesdites cellules d'aspi- said cells constituting said vacuum cells ration ( 22,22) et la partie de ladite face supérieure qui est située entre lesdits alvéoles constituant ladite ration (22,22) and the part of said upper face which is located between said cells constituting said surface de contact avec la pièce.contact surface with the part. 3 Porte-pièce suivant la revendication 2, caractérisé en ce qu'une partie de ladite chambre à vide ( 30) est située sous chacun des alvéoles ( 28, 28) 3 workpiece holder according to claim 2, characterized in that a part of said vacuum chamber (30) is located under each of the cells (28, 28) et que, pour chacun des passages, lesdits moyens défi- and that, for each of the passages, said means defi- nissant un étranglement comprennent une petite ouver- ness a choke include a small open- ture ( 34) qui s'étend du fond de l'alvéole correspondant structure (34) which extends from the bottom of the corresponding cell à ladite chambre à vide.to said vacuum chamber.

### Claim 4

Porte-pièce suivant la revendication 1, caractérisé en outre par le fait que lesdits moyens 4. Workpiece holder according to claim 1, further characterized in that said means qui définissent une région de fixation des pièces com- which define a region for fixing the parts prennent une plaque ( 48) ayant une face supérieure ( 50) laquelle présente des alvéoles ( 52,52) répartis sur son take a plate (48) having an upper face (50) which has cells (52,52) distributed over its étendue, une feuille ( 53) d'une matière flexible imper- extended, a sheet (53) of flexible waterproof material méable à l'air, étalée sur ladite face supérieure de ladite plaque et qui couvre lesdits alvéoles, ladite feuille comprenant une série de petites ouvertures airable, spread on said upper face of said plate and which covers said cells, said sheet comprising a series of small openings ( 64,64 ') dont chacune traverse ladite feuille et commu- (64.64 ') each of which crosses said sheet and commu- nique avec un alvéole respectif, les espaces situés sur la face externe de ladite feuille et qui coïncident avec nique with a respective cell, the spaces located on the outer face of said sheet and which coincide with lesdits alvéoles constituant lesdites cellules d'aspira- said cells constituting said suction cells tion ( 58,58) et lesdites petites ouvertures formées dans tion (58,58) and said small openings formed in ladite feuille constituant lesdits étranglements. said sheet constituting said throttles.

### Claim 5

Porte-pièce suivant la revendication 4, caractérisé en outre en ce que ladite feuille ( 53) de matière flexible imperméable à l'air est une feuille de 5. Workpiece holder according to claim 4, further characterized in that said sheet (53) of flexible air-impermeable material is a sheet of matière élastomère.elastomeric material. 19 - 19 -

### Claim 6

Porte-pièce suivant la revendication 4, caractérisé en ce que ladite feuille ( 53) de matière flexible imperméable à l'air est une feuille de matière6. Workpiece holder according to claim 4, characterized in that said sheet (53) of flexible air-impermeable material is a sheet of material essentiellement composés d'uréthane. mainly composed of urethane. 7 Porte-pièce suivant la revendication 7 workpiece according to claim 4, caractérisé en ce que chacune desdites petites ouver- 4, characterized in that each of said small openings tures ( 64) est réalisée sous la forme d'un trou distinct tures (64) is made in the form of a separate hole ménagé dans ladite matière en feuille. formed in said sheet material.

### Claim 8

Porte-pièce suivant la revendication 4, caractérisé en ce que chacune des petites ouvertures ( 64 ') est réalisée sous la forme d'une fente ménagée 8. Workpiece holder according to claim 4, characterized in that each of the small openings (64 ') is made in the form of a slot dans ladite matière en feuille.in said sheet material.

### Claim 9

Porte-pièce suivant l'une quelconque 9. Workpiece holder according to any one des revendications 4, 5, 6, 7 et 8, caractérisé en ce claims 4, 5, 6, 7 and 8, characterized in qu'une partie de ladite chambre à vide ( 30) est située au-dessous de chacun des alvéoles et en ce que les moyens that part of said vacuum chamber (30) is located below each of the cells and in that the means définissant un passage comprennent une ouverture relati- defining a passage include a relative opening vement grande ( 62) qui s'étend du fond de chacun des large (62) extending from the bottom of each alvéoles à ladite chambre à vide. cells at said vacuum chamber. 10 Porte-pièce suivant l'une quelconque 10 Workpiece holder according to any one des revendications 4, 5, 6, 7 et 8, caractérisé par une claims 4, 5, 6, 7 and 8, characterized by a série de garnitures perméables à l'air, relativement series of relatively breathable linings rigides, ( 68,68) dont chacune est logée dans l'un res- rigid, (68,68) each of which is housed in one pectif desdits alvéoles ( 52,52) et est agencée de manière à attaquer et supporter la surface intérieure de la portion correspondante de ladite feuille ( 53) de matière flexible lorsque cette feuille de matière flexible est pectif of said cells (52,52) and is arranged so as to attack and support the interior surface of the corresponding portion of said sheet (53) of flexible material when this flexible sheet of material is attirée dans l'alvéole ( 52) par une différence de pres- drawn into the socket (52) by a difference in pressure sion existant entre la face inférieure et la face supé- existing between the lower face and the upper face rieure deladite feuille.of said leaf.

### Claim 11 (independent)

Porte-pièce suivant la revendication , caractérisé en ce que chacune desdites garnitures 11. Workpiece holder according to claim, characterized in that each of said fittings ( 68,68) est constituée par un morceau de feutre. (68,68) is made up of a piece of felt.

### Claim 12

Porte pièce suivant la revendication 10, caractérisé en ce que chacune desdites garnitures 12. Piece holder according to claim 10, characterized in that each of said linings ( 68,68) est constituée par une pièce de métal fritté. (68,68) is formed by a piece of sintered metal.

### Claim 13

- 13. Porte-pièce selon la revendication 1, caractérisé en ce que lesdits moyens qui définissent une région de fixation de la pièce comprennent une plaque - 13. Workpiece holder according to claim 1, characterized in that said means which define a part attachment region comprise a plate ( 16) ayant une face supérieure ( 20) qui présente une sé- (16) having an upper face (20) which has a section rie d'alvéoles ( 28,28) répartis sur son étendue et une série de garnitures perméables à l'air, relativement row of cells (28,28) distributed over its extent and a series of relatively breathable linings rigides ( 78,84) dont chacune est logée dans l'un res- rigid (78.84) each of which is housed in one pectif desdits alvéoles, la partie de ladite face supérieure de la plaque située entre lesdits alvéoles constituant ladite surface de contact avec la pièce, et lesdites garnitures ayant des faces tournées vers l'extérieur de niveau avec ladite surface de contact avec -la pièce, chacune desdites garnitures constituant pectif of said cells, the part of said upper face of the plate situated between said cells constituting said contact surface with the part, and said linings having faces turned towards the outside level with said contact surface with the part, each said linings constituting l'une respective desdites cellules d'aspiration. a respective one of said suction cells. 14 Porte-pièce selon la revendication 13, caractérisé en ce que chacune desdites garnitures ( 78, 14 Workpiece holder according to claim 13, characterized in that each of said fittings (78, 78) est constituée par une pièce de métal fritté. 78) is formed by a piece of sintered metal.

### Claim 15

Porte-pièce selon la revendication 13, caractérisé en ce que chacune desdites garnitures ( 84,84) est constituée par un organe rigide ayant une pluralité d'ouvertures discrètes le traversant de façon 15. Workpiece holder according to claim 13, characterized in that each of said linings (84,84) is constituted by a rigid member having a plurality of discrete openings passing through it so générale perpendiculairement à sa face supérieure. general perpendicular to its upper face.

### Claim 16

Porte-pièce selon la revendication 13, caractérisé en ce qu'une partie de ladite chambre à 16. Workpiece holder according to claim 13, characterized in that part of said chamber vide ( 30) est située en dessous de chacun desdits al- vacuum (30) is located below each of said al- véoles et en ce que lesdits moyens définissant un étran- voles and in that said means defining a strang- glement pour chacun desdits passages est constitué par une petite ouverture ( 34) allant du fond de l'alvéole glement for each of said passages is constituted by a small opening (34) going from the bottom of the cell associé à ladite chambre d'aspiration. associated with said suction chamber. 17 Porte-pièce suivant la revendication 1, caractérisé en ce que lesdits moyens qui définissent 17 Workpiece holder according to claim 1, characterized in that said means which define une région de fixation de la pièce comprennent une pla- a workpiece attachment region includes a plate que ( 16) qui possède une surface supérieure sur laquelle est répartie une série d'alvéoles ( 28,28) et une feuille rigide ( 92) qui recouvre ladite face supérieure de 21 - ladite plaque, ladite feuille ( 92) ayant pour chacun desdits alvéoles une série d'ouvertures discrètes ( 94, 94) qui traversent cette feuille et communiquent avec lesdits alvéoles pour définir l'une desdites cellules d'aspiration. that (16) which has an upper surface on which is distributed a series of cells (28,28) and a rigid sheet (92) which covers said upper face with 21 - said plate, said sheet (92) having for each of said cells a series of discrete openings (94, 94) which pass through this sheet and communicate with said cells to define one of said suction cells.

### Claim 18

Porte-pièce suivant la revendication 17, caractérisé en ce qu'une partie de ladite chambre à18. Workpiece holder according to claim 17, characterized in that part of said chamber vide ( 30) est située au-dessous de chacun desdits al- vacuum (30) is located below each of said al- véoles et en ce que lesdits moyens qui définissent un étranglement pour chacun desdits passages comprennent voles and in that said means which define a constriction for each of said passages comprises une petite ouverture ( 34) qui s'étend du fond de l'al- a small opening (34) which extends from the bottom of the véole correspondant à ladite chambre à vide. vole corresponding to said vacuum chamber.

### Claim 19

Porte-pièce suivant l'une quelconque 19. Workpiece holder according to any one dbs revendications 1, 2, 4, 13 et 17, caractérisé par dbs claims 1, 2, 4, 13 and 17, characterized by des moyens qui définissent un évent ( 38) qui s'étend entre ladite chambre à vide ( 30) et l'atmosphère et un appareil obturateur ( 40) permettant d'ouvrir et de means which define a vent (38) which extends between said vacuum chamber (30) and the atmosphere and a shutter device (40) making it possible to open and fermer sélectivement ledit évent.selectively close said vent.

### Claim 20

Porte-pièce suivant la revendication 19, caractérisé en ce que ledit appareil obturateur ( 40) comprend des moyenscb sollicitation ( 42) qui tendent à le placer dans la position dans laquelle il ferme ledit évent, et des moyens pouvant être actionnés manuellement et servant à l'amener, en surmontant la force desdits moyens de sollicitation, à la position dans laquelle il 20. Workpiece holder according to claim 19, characterized in that said shutter device (40) comprises biasing means (42) which tend to place it in the position in which it closes said vent, and means which can be actuated manually and serving to bring it, overcoming the force of said biasing means, to the position in which it ouvre ledit évent.opens said vent.

### Claim 21

Porte-pièce suivant la revendication 21. Workpiece holder according to claim 1, caractérisé en ce que toutes ledites cellules d'as- 1, characterized in that all of said suction cells piration ( 22,58,100) présentent des faces dirigées vers piration (22,58,100) present faces directed towards l'extérieur ( 29,66) de dimensions et de formes sensible- the exterior (29.66) of sensitive dimensions and shapes- ment uniformes et qui sont réparties sensiblement uni- uniformly distributed and distributed uniformly formément sur ladite région de fixation de la pièce. formally on said part fixing region.

### Claim 22

Porte-pièce suivant la-revendication 1, caractérisé en ce que ladite région de fixation de la pièce possède une partie qui contient des cellules 22 - d'aspiration ( 100,100) dont les faces dirigées vers l'extérieur sont de petites aires et qui sont étroitement 22. Workpiece holder according to claim 1, characterized in that said part attachment region has a part which contains cells 22 - suction (100,100) whose faces directed towards the outside are small areas and who are closely rapprochées les unes des autres et en ce que ladite ré- close together and in that said re- gion de fixation des pièces comprend une autre partie qui contient des cellules d'aspiration ( 100,100) dont les faces dirigées vers l'extérieur sont d'une aire relativement grande et sont relativement plus espacées part fixing part includes another part which contains suction cells (100,100) whose faces directed towards the outside are of a relatively large area and are relatively more spaced les unes des autres.each other.

### Claim 23

Porte-pièce suivant la revendication 1, caractérisé par une source de vide ( 32) reliée à ladite chambre de vide ( 30), lesdits étranglements ( 34, 64,64 ') étant d'une dimension telle et la source de 23. Workpiece holder according to claim 1, characterized by a vacuum source (32) connected to said vacuum chamber (30), said throttles (34, 64,64 ') being of such a dimension and the source of vide d'une capacité telle que, lorsque toutes les cel- void of a capacity such that when all of the lules d'aspiration ( 22,58,100) sont découvertes par une pièce, ladite source de vide puisse entretenir un the suction cells (22,58,100) are discovered by a part, said vacuum source being able to maintain a vide notable dans ladite chambre à vide. significant vacuum in said vacuum chamber.

### Claim 24

Porte-pièce suivant la revendication 24. Workpiece holder according to claim 1, caractérisé par une source de vide ( 35) reliée à la- 1, characterized by a vacuum source (35) connected to the- dite chambre à vide ( 30), lesdits étranglements ( 34,64, 64 ') étant d'une dimension telle et ladite source de vide étant d'une capacité telle que, lorsque toutes les cellules d'aspiration ( 22,58,100) sont découvertes par *une pièce, le fonctionnement de ladite source de vide maintienne dans ladite chambre à vide un vide d'environ said vacuum chamber (30), said throttles (34,64, 64 ') being of such a dimension and said vacuum source being of such a capacity that, when all the suction cells (22,58,100) are discovered by * a part, the operation of said vacuum source maintains in said vacuum chamber a vacuum of about 127 mm de mercure ou plus grand.127 mm of mercury or larger.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGHAND CUTTING TOOLS; CUTTING; SEVERINGCUTTING; DETAILS COMMON TO MACHINES FOR PERFORATING, PUNCHING, CUTTING-OUT, STAMPING-OUT OR SEVERINGDetails of apparatus for cutting, cutting-out, stamping-out, punching, perforating, or severing by means other than cuttingMeans for holding or positioning workHolding the work by suctionPERFORMING OPERATIONS; TRANSPORTINGHAND TOOLS; PORTABLE POWER-DRIVEN TOOLS; MANIPULATORSTOOLS OR BENCH DEVICES NOT OTHERWISE PROVIDED FOR, FOR FASTENING, CONNECTING, DISENGAGING, OR HOLDINGWork holders not covered by any preceding group in the subclass, e.g. magnetic work holders, vacuum work holdersVacuum work holders

Description

Translated from French

La prÃ©sente invention se rapporte Ã un mandrin ou dispositif analogue Ã The present invention relates to a mandrel or device similar to

dÃ©pression destinÃ© Ã tenir des piÃ¨ces et elle concerne plus particuliÃ¨rement des perfectionnements apportÃ©s Ã un tel dispositif de telle maniÃ¨re que le mandrin soit capable de manipuler diverses dimensions diffÃ©rentes de piÃ¨ces sans rÃ©glage, qu'il n'exige qu'une source de dÃ©pression de capacitÃ© relativement petite et ne demande pas de masquage niÂ Â vacuum intended to hold parts and it relates more particularly to improvements made to such a device in such a way that the mandrel is capable of handling various different dimensions of parts without adjustment, that it only requires a source of capacity vacuum relatively small and does not require masking or

d'autre obturation des zones non couvertes par la piÃ¨ce.Â Â other sealing of the areas not covered by the part.

Les portes-piÃ¨ces Ã dÃ©pression du type gÃ©nÃ©ral auquel l'invention se rapporte sont bien connus et dÃ©crits, par exemple par les brevets US antÃ©rieurs n O 2 694 337, 2 993 824 et 3 294 392 Dans de telsÂ Â Vacuum work carriers of the general type to which the invention relates are well known and described, for example by prior US Pat. Nos. 2,694,337, 2,993,824 and 3,294,392 In such

dispositifs de la technique antÃ©rieure, une surface sup-Â Â prior art devices, a sup-

port de piÃ¨ce est formÃ©e par un Ã©lÃ©ment poreux qui re-Â Â workpiece port is formed by a porous element which re-

couvre une chambre Ã vide ou autre espace Ã vide.Â Â covers a vacuum chamber or other vacuum space.

Lorsqu'une piÃ¨ce est placÃ©e sur la surface support, la dÃ©pression passant Ã travers l'Ã©lÃ©ment poreux en provenance de la chambre Ã vide s'applique Ã la surface infÃ©rieure de la piÃ¨ce en dÃ©veloppant, en combinaison avec la pression atmosphÃ©rique une force Ã appliquer Ã la piÃ¨ce, force qui pousse cette derniÃ¨re Ã joint Ã©tanche contre la surface du support Toutefois, si la piÃ¨ce neÂ Â When a part is placed on the support surface, the vacuum passing through the porous element coming from the vacuum chamber is applied to the lower surface of the part by developing, in combination with atmospheric pressure, a force to be applied to the workpiece, the force which pushes the latter with a tight seal against the surface of the support However, if the workpiece does not

couvre pas la totalitÃ© de la surface support, l'air fuit-Â Â does not cover the entire support surface, air leaks

Ã travers sa partie libre, ce qui provoque frÃ©quemment l'application d'une force de tenue insuffisante Ã la piÃ¨ce, en raison de l'abaissement de la dÃ©pression dans la chambre Ã vide, ou, sinon, exige une pompe Ã vide de trÃ¨s grande capacitÃ© capable de maintenir un vide notableÂ Â through its free part, which frequently causes the application of an insufficient holding force to the part, due to the lowering of the vacuum in the vacuum chamber, or, otherwise, requires a vacuum pump of very large capacity capable of maintaining a significant vacuum

dans la chambre Ã vide en dÃ©pit de la fuite Pour sur-Â Â in the vacuum chamber despite the leak For sur-

monter ce problÃ¨me de fuite, le brevet no 2 694 337 prÃ©-Â Â mount this leakage problem, patent no. 2,694,337 pre-

citÃ© dÃ©crit un grand nombre de soupapes associÃ©es Ã l'Ã©lÃ©ment support, qui peuvent Ãªtre ouvertes ou fermÃ©es individuellement pour rendre poreuse uniquement la partie de l'Ã©lÃ©ment support qui est couverte par la piÃ¨ce Le -2- brevet n' 3 294 392 prÃ©citÃ© dÃ©crit l'utilisation d'une feuille ou couverture en matiÃ¨re plastique impermÃ©able Ã l'air sur la partie libre de la surface support, pour la rendre Ã©tanche aux fuites d'air tendant Ã pÃ©nÃ©trer dans la chambre Ã vide. Les deux solutions apportÃ©es au problÃ¨me de la fuite qui sont suggÃ©rÃ©es par le brevet N O 3 694 337 et le brevet N O 3 294 392 prÃ©citÃ©s prÃ©sentent certains inconvÃ©nients et le but de l'invention est de rÃ©aliser un mandrin ou porte-piÃ¨ce Ã dÃ©pression perfectionnÃ© qui constitue un perfectionnement par rapport aux types deÂ Â cited describes a large number of valves associated with the support element, which can be opened or closed individually to make porous only the part of the support element which is covered by the part. The above-mentioned patent no. 3,294,392 describes the use of a sheet or cover of airtight plastic material on the free part of the support surface, to make it impervious to air leaks tending to enter the vacuum chamber. The two solutions to the problem of leakage which are suggested by patent NO 3,694,337 and patent NO 3,294,392 mentioned above have certain drawbacks and the aim of the invention is to produce a mandrel or workpiece with improved vacuum which constitutes an improvement compared to the types of

dispositifs dÃ©crits par ces brevets.Â Â devices described by these patents.

Un but plus particulier de l'invention est de rÃ©aliser un mandrin ou porte-piÃ¨ce Ã dÃ©pression capable de manipuler une large diversitÃ© de dimensionsÂ Â A more particular object of the invention is to produce a mandrel or vacuum workpiece capable of handling a wide variety of dimensions

de piÃ¨ces sans exiger aucun masquage, ensemble de sou-Â Â of parts without requiring any masking, support assembly

papes o autre conditionnement de l'Ã©lÃ©ment support lorsqu'on passe d'une piÃ¨ce Ã autre, que les piÃ¨ces successives soient de mÃªmes dimensions ou de dimensions diffÃ©rentes C'est-Ã -dire que le porte-piÃ¨ce suivant l'invention accepte immÃ©diatement et tient de faÃ§onÂ Â popes o other packaging of the support element when moving from one part to another, whether the successive parts are of the same dimensions or of different dimensions That is to say that the workpiece carrier according to the invention immediately accepts and holds so

satisfaisante n'importe quelle piÃ¨ce qui lui est prÃ©-Â Â any piece that comes before it

sentÃ©e et qui rentre dans un large intervalle de dimen-Â Â felt and which falls within a wide range of dimen-

sions pourvu seulement que la piÃ¨ce soit relativement non poreuse et qu'elle possÃ¨de une surface infÃ©rieure gÃ©nÃ©ralement conforme ou capable de se conformer Ã laÂ Â Only provided that the part is relatively non-porous and has a lower surface generally conforming or capable of conforming to the

forme de la surface support.shape of the support surface.

Un autre but de l'invention est de rÃ©aliser un mandrin ou porte-piÃ¨ce Ã dÃ©pression du type dÃ©crit plus haut qui n'exige qu'une pompe ou autre source de dÃ©pression de capacitÃ© relativement faible qui soitÂ Â Another object of the invention is to produce a vacuum mandrel or workpiece holder of the type described above which requires only a pump or other source of vacuum of relatively low capacity which is

relativement peu coÃ»teuse Ã obtenir et Ã exploiter.Â Â relatively inexpensive to obtain and operate.

Un autre but de l'invention est de rÃ©aliser un dispositif porte-piÃ¨ce du caractÃ¨re ci-dessus qui puisse Ãªtre conÃ§u pour et utilisÃ© avec une grande -3- diversitÃ© de diffÃ©rents types de piÃ¨ces qui prÃ©sentent une surface infÃ©rieure courbe ou plate, tels que des blocs rigides ou semi-rigides, plaques ou feuilles de mÃ©tal, de bois ou de matiÃ¨re plastique ou tels que des feuilles flexibles de papier, carton, matiÃ¨re plastiqueÂ Â Another object of the invention is to provide a workpiece carrier device of the above character which can be designed for and used with a wide variety of different types of workpieces which have a curved or flat bottom surface, such as rigid or semi-rigid blocks, plates or sheets of metal, wood or plastic or such as flexible sheets of paper, cardboard, plastic

ou matiÃ¨res composites.or composite materials.

D'autres buts et avantages de l'inventionÂ Â Other objects and advantages of the invention

apparaÃ®tront au cours de la description dÃ©taillÃ©e qui vaÂ Â will appear during the detailed description which will

suivre et en regard des dessins.follow and next to the drawings.

L'invention consiste dans un porte-piÃ¨ce muni de moyens qui dÃ©finissent une rÃ©gion de fixation de la piÃ¨ce constituÃ©e, en partie, par une surface de contact avec la piÃ¨ce et, pour une autre partie, par une sÃ©rie de cellules d'aspiration isolÃ©es les unes des autres et rÃ©parties sur ladite rÃ©gion La face de chaque cellule d'aspiration qui est dirigÃ©e vers l'extÃ©rieur est soit entiÃ¨rement ouverte, soit d'une nature analogue Ã un tamis, de faÃ§on Ã Ãªtre composÃ©e en partie d'espaces libres et en partie de surfaces matÃ©rielles qui peuvent entrer en contact avec la piÃ¨ce pour donner un support additionnel Ã la piÃ¨ce Chaque cellule d'aspiration estÂ Â The invention consists in a workpiece carrier provided with means which define a region for fixing the workpiece formed, in part, by a contact surface with the workpiece and, for another part, by a series of isolated suction cells from one another and distributed over said region The face of each suction cell which is directed towards the outside is either entirely open, or of a nature similar to a sieve, so as to be composed in part of free spaces and partly of material surfaces which can come into contact with the part to give additional support to the part Each suction cell is

reliÃ©e Ã une chambre Ã vide par son propre circuit d'Ã©-Â Â connected to a vacuum chamber by its own heating circuit

coulement qui lui est exclusivement associÃ© et qui com-Â Â flow which is exclusively associated with it and which

prend un Ã©tranglement ayant une surface de section transversale effective de nombreuses fois plus petite que la surface de la partie libre de la face de laÂ Â takes a throttle having an effective cross-sectional area many times smaller than the area of the free part of the face of the

cellule, en ne permettant ainsi qu'un trÃ¨s faible Ã©cou-Â Â cell, thus allowing only a very small amount of

lement d'air de l'atmosphÃ¨re Ã la chambre Ã vide lorsque la cellule n'est pas recouverte par une piÃ¨ce mais en permettant cependant Ã la rÃ©gion libre de la face de la cellule de se vider d'air lorsqu'elle est couverte parÂ Â lement of air from the atmosphere to the vacuum chamber when the cell is not covered by a part but allowing, however, the free region of the face of the cell to empty of air when it is covered by

une piÃ¨ce.a piece.

L'invention rÃ©side Ã©galement dans diverses constructions diffÃ©rentes des cellules d'aspiration, dans la prÃ©sence d'un obturateur d'Ã©vent pour Ã©vacuer a 513160 -4-Â Â The invention also resides in various constructions different from the suction cells, in the presence of a vent shutter to evacuate a 513160 -4-

le vide de la chambre Ã vide afin de faciliter le place-Â Â the vacuum of the vacuum chamber to facilitate the placement-

ment de la piÃ¨ce sur le porte-piÃ¨ce et son enlÃ¨vement deÂ Â ment of the workpiece on the workpiece carrier and its removal from

ce dernier, et dans le fait que les cellules d'aspira-Â Â the latter, and in the fact that the cells of aspira-

tion sont, soit d'une dimension uniforme et/ou d'une distribution rÃ©guliÃ¨re sur la rÃ©gion de fixation de la piÃ¨ce, soit d'une dimension non uniforme et/ou d'une distribution irrÃ©guliÃ¨re sur la surface de fixation deÂ Â tion are either of a uniform size and / or a regular distribution on the attachment region of the part, or of a non-uniform size and / or an irregular distribution on the attachment surface of

la piÃ¨ce -the room -

La Figure 1 est une vue en perspective montrant un porte-piÃ¨ce ou mandrin Ã dÃ©pression suivant l'inventionÂ Â Figure 1 is a perspective view showing a workpiece or vacuum mandrel according to the invention

La Figure 2 est une coupe verticale par-Â Â Figure 2 is a vertical section through

tielle prise suivantla ligne 2-2 de la Figure 1; La Figure 3 est une vue en perspective, montrant le porte-piÃ¨ce de la Figure 1 combinÃ© Ã une pompe Ã vide; La Figure 4 est une vue en perspective montrant un porte- piÃ¨ce constituant une autre forme de rÃ©alisation de l'invention; La Figure 5 est une vue en coupe verticale partielle prise suivant la ligne 5-5 de la Figure 4 et qui montre Ã©galement une partie d'une piÃ¨ce disposÃ©e sur le porte-piÃ¨ce; La Figure 6 est une vue partielle en plan montrant la face de l'une des cellules d'aspiration du dispositif de la Figure 4; La Figure 7 est une vue analogue Ã la Figure 6 mais qui montre une variante d'un orifice dÃ©finissant un Ã©tranglement dans la feuille supÃ©rieure du porte-piÃ¨ce La Figure 8 est une vue analogue Ã la Figure 5 mais qui montre une variante de rÃ©alisation de l'invention; La Figure 9 est une vue partielle en perspective, en partie en coupe, qui montre une partie d'un porte-piÃ¨ce constituant encore une autre forme de rÃ©alisation de l'invention; La Figure 10 est une vue analogue Ã la Figure 9, qui montre un porte-piÃ¨ce constituant une autre forme de rÃ©alisation de l'invention; La Figure 11 est une vue analogue Ã la Figure 9, qui montre un porte-piÃ¨ce constituant encore une autre forme de rÃ©alisation de l'invention; et La Figure 12 est une vue en perspective montrant un porte- piÃ¨ce constituant encore une autreÂ Â taken along line 2-2 of Figure 1; Figure 3 is a perspective view showing the workpiece carrier of Figure 1 combined with a vacuum pump; Figure 4 is a perspective view showing a workpiece holder constituting another embodiment of the invention; Figure 5 is a partial vertical sectional view taken along line 5-5 of Figure 4 and which also shows part of a part disposed on the workpiece carrier; Figure 6 is a partial plan view showing the face of one of the suction cells of the device of Figure 4; Figure 7 is a view similar to Figure 6 but which shows a variant of an orifice defining a constriction in the upper sheet of the workpiece carrier Figure 8 is a view similar to Figure 5 but which shows an alternative embodiment of the invention; Figure 9 is a partial perspective view, partly in section, which shows part of a workpiece holder constituting yet another embodiment of the invention; Figure 10 is a view similar to Figure 9, which shows a workpiece holder constituting another embodiment of the invention; Figure 11 is a view similar to Figure 9, which shows a workpiece holder constituting yet another embodiment of the invention; and Figure 12 is a perspective view showing a workpiece holder constituting yet another

forme de rÃ©alisation de l'invention.Â Â embodiment of the invention.

Un porte-piÃ¨ce suivant l'invention peut Ãªtre conÃ§u pour Ãªtre utilisÃ© avec divers dimensions et types diffÃ©rents de piÃ¨ces qui sont sensiblement non poreusesÂ Â A workpiece carrier according to the invention can be designed to be used with various dimensions and different types of workpieces which are substantially non-porous

et possÃ¨dent une surface intÃ©rieure relativement lisse.Â Â and have a relatively smooth interior surface.

Les piÃ¨ces peuvent Ãªtre rigides, avec une surface infÃ©-Â Â The parts can be rigid, with a smaller surface

rieure plate ou courbe, auquel cas le porte-piÃ¨ce Ã dÃ©pression est conÃ§u avec une surface support de piÃ¨ce plate ou courbe, conforme Ã la surface infÃ©rieure des piÃ¨ces; ou encore, les piÃ¨ces peuvent Ãªtre des piÃ¨ces d'une matiÃ¨re flexible capables de se conformer Ã diverses formes diffÃ©rentes de la surface support, auquel cas le porte-piÃ¨ce est conÃ§u avec une surface support de la forme qui est nÃ©cessaire pour tenir la piÃ¨ce dans l'Ã©tat dÃ©sirÃ© pendant qu'on la travaille Par ailleurs, le porte-piÃ¨ce peut Ãªtre fixe par rapport Ã la terre ouÂ Â flat or curved part, in which case the vacuum workpiece carrier is designed with a flat or curved workpiece support surface, conforming to the lower surface of the parts; or, the parts may be parts of flexible material capable of conforming to various shapes different from the support surface, in which case the workpiece holder is designed with a support surface of the shape which is necessary to hold the part in the desired state while it is being worked In addition, the workpiece holder can be fixed relative to the ground or

Ã un support et Ãªtre utilisÃ© avec un outil ou un ins-Â Â to a stand and be used with a tool or tool

trument mis en mouvement manuellement ou mÃ©caniquement, ou encore le porte-piÃ¨ce peut Ãªtre mis en mouvement manuellement ou par une machine, et utilisÃ© avec un outil ou instrument fixe Dans les formes de rÃ©alisation de l'invention qui sont reprÃ©sentÃ©es et dÃ©crites dans le prÃ©sent mÃ©moire, le porte-piÃ¨ce comprend une surface support de piÃ¨ce plane et il est d'un type gÃ©nÃ©ralement stationnaire mais il va de soi que la planÃ©itÃ© de la -6surface support et le caractÃ¨re fixe du porte-piÃ¨ce ne sont pas essentiels pour l'invention et ont Ã©tÃ© choisisÂ Â implement moved manually or mechanically, or the workpiece carrier can be moved manually or by machine, and used with a stationary tool or instrument In the embodiments of the invention which are shown and described herein Memory, the workpiece holder includes a flat workpiece support surface and it is of a generally stationary type but it goes without saying that the flatness of the support surface and the fixed nature of the workpiece carrier are not essential for the invention and were chosen

dans un but uniquement illustratif.for illustrative purposes only.

On se reportera maintenant aux dessins et on considÃ¨rera tout d'abord les Figures 1, 2 et 3 Un porte-piÃ¨ce suivant l'invention est reprÃ©sentÃ© sur ces dessins en 14 et comprend une plaque principale 16 qui forme une rÃ©gion porte-piÃ¨ce 18 qui regarde vers le haut, comprenant une surface 20 de contact avec la piÃ¨ce et une sÃ©rie de cellules d'aspiration 22, 22 rÃ©parties sur cette rÃ©gion La plaque 16 est composÃ©e d'un corps rigide 24 fait d'une matiÃ¨re impermÃ©able Ã l'air telle qu'un mÃ©tal ou une matiÃ¨re plastique et il porte une couche 26 d'une matiÃ¨re Ã©lastomÃ¨re telle qu'un latex, nÃ©oprÃ¨ne, caoutchouc de silicone ou urÃ©thane, sur sa surface supÃ©rieure La couche 26 sert de surface de friction pour s'opposer au glissement d'une piÃ¨ce, telle que celleÂ Â We will now refer to the drawings and we will first consider Figures 1, 2 and 3 A workpiece according to the invention is shown in these drawings at 14 and comprises a main plate 16 which forms a workpiece region 18 which looks upwards, comprising a surface 20 for contact with the workpiece and a series of suction cells 22, 22 distributed over this region The plate 16 is composed of a rigid body 24 made of an air-impermeable material such as a metal or a plastic material and it carries a layer 26 of an elastomeric material such as a latex, neoprene, silicone rubber or urethane, on its upper surface The layer 26 serves as a friction surface for opposing the sliding of a part, such as that

indiquÃ©e en 31 sur la Figure 1, sur la rÃ©gion de fixa-Â Â indicated at 31 in Figure 1, on the fixation region

tion de la piÃ¨ce et pour favoriser l'Ã©tablissement de l'Ã©tanchÃ©itÃ© entre la piÃ¨ce et les cellules 22,22 qu'elle recotwre Toutefois, la couche 26 n'est pas nÃ©cessaire dans tousÂ Â tion of the part and to promote the establishment of the seal between the part and the cells 22,22 which it recotwre However, the layer 26 is not necessary in all

les cas et elle peut Ã©ventuellement Ãªtre omise Elle peut Ãªtre appli-Â Â cases and it can optionally be omitted It can be applied

quÃ©e, soit par pulvÃ©risation, soit par enduction Ã la brosse, sur la surface supÃ©rieure du corps 24, soit sous la forme d'une feuille sÃ©parÃ©e colÃ©e ou fixÃ©e d'uneÂ Â quÃ©e, either by spraying, or by coating with a brush, on the upper surface of the body 24, or in the form of a separate sheet glued or fixed with a

autre faÃ§on Ã la surface supÃ©rieure du corps.Â Â other way to the upper surface of the body.

Les cellules d'aspiration 22,22 du porte-Â Â The suction cells 22,22 of the holder

piÃ¨ce 188 sont constituÃ©es par des alvÃ©oles cylindriques 28,28 qui prÃ©sentent une face ouverte 29,29 dirigÃ©e vers le haut, de niveau avec la surface 20 de contact avec la piÃ¨ce La surface 20 de contact avec la piÃ¨ce s'Ã©tend entre les alvÃ©oles 28, 28 et entoure complÃ¨tement ces alvÃ©oles et, de cette faÃ§on, elle isole pneumatiquement les alvÃ©oles les uns des autres, le long de lignes situÃ©es dans la surface 20 Les alvÃ©oles sont d'une -7- dimensions et d'une forme sensiblement uniformes et ils sont rÃ©partis rÃ©guliÃ¨rement sur la rÃ©gion 18 de fixation de la piÃ¨ce Bien que les alvÃ©oles soient reprÃ©sentÃ©s sous une forme Ã section circulaire, ceci n'est pas une caractÃ©ristique critique et ils peuvent Ã©galement Ãªtre de n'importe quelle autre section appropriÃ©e si on le dÃ©sire. Au-dessous des alvÃ©oles 28, 28 se trouve un espace ou une chambre Ã vide 30 dÃ©fini par une cavitÃ©Â Â part 188 are constituted by cylindrical cells 28, 28 which have an open face 29, 29 directed upwards, level with the surface 20 for contact with the part The surface 20 for contact with the part extends between the cells 28 , 28 and completely surrounds these cells and, in this way, it pneumatically isolates the cells from each other, along lines located in the surface. The cells are of substantially uniform dimensions and shape and they are distributed regularly over the region 18 for fixing the part. Although the cells are represented in a form with a circular section, this is not a critical characteristic and they can also be of any other appropriate section if it is longed for. Below the cells 28, 28 is a space or a vacuum chamber 30 defined by a cavity

mÃ©nagÃ©e dans la surface infÃ©rieure de la plaque princi-Â Â formed in the lower surface of the main plate

pale 16, qui est recouverte par une plaque infÃ©rieureÂ Â blade 16, which is covered by a bottom plate

32 fixÃ©e Ã joint Ã©tanche Ã la plaque 16 comme reprÃ©sen-Â Â 32 fixed to seal 16 on plate 16 as shown

tÃ© Une partie de la chambre Ã vide 30 se trouve au-Â Â tee Part of the vacuum chamber 30 is located

dessous de chacune des cavitÃ©s 28,28 et chaque cavitÃ© est reliÃ©e individuellement Ã la chambre Ã vide par son propre passage exclusif composÃ© d'une petite ouvertureÂ Â below each of the cavities 28,28 and each cavity is individually connected to the vacuum chamber by its own exclusive passage composed of a small opening

34 qui s'Ã©tend du fond de l'alvÃ©ole Ã la chambre Ã vide.Â Â 34 which extends from the bottom of the cell to the vacuum chamber.

Le diamÃ¨tre effectif de l'ouverture 34 est de nombreuses fois plus petit que la surface de la face de son alvÃ©oleÂ Â The effective diameter of the opening 34 is many times smaller than the surface of the face of its cell

28 qui est dirigÃ©e vers l'extÃ©rieur de sorte que, lors-Â Â 28 which is directed outwards so that when

que cette face est dÃ©couverte par une piÃ¨ce, il neÂ Â that this face is discovered by a coin, it does not

s'Ã©coule qu'une trÃ¨s petite quantitÃ© d'air de l'atmos-Â Â only a very small amount of air flows from the

phÃ¨re dans la chambre Ã vide Ã travers l'ouverture dansÂ Â sphere in the vacuum chamber through the opening in

un temps donnÃ© C'est-Ã -dire que l'ouverture 34 se com-Â Â a given time, that is to say that the opening 34

porte comme un Ã©tranglement qui assure, Ã la fois grÃ¢ce Ã sa faible surface de section et grÃ¢ce Ã sa longueur, une grande rÃ©sistance Ã l'Ã©coulement de l'air Ã travers cette ouverture De cette faÃ§on lorsqu'on place toutÂ Â carries like a constriction which ensures, both thanks to its small cross-sectional area and thanks to its length, a great resistance to the flow of air through this opening In this way when placing everything

d'abord une piÃ¨ce 31 sur le porte-piÃ¨ce 14, les ouver-Â Â first a part 31 on the workpiece holder 14, the openings

tures 34,34 associÃ©es aux alvÃ©oles 28, 28 couverts laissent l'air s'Ã©vacuer de ces alvÃ©oles pour faire le vide dans les alvÃ©oles et crÃ©er ainsi une force de fixation ou de retenue de la piÃ¨ce Cette formation deÂ Â 34.34 associated with the cells 28, 28 covered allow air to escape from these cells to create a vacuum in the cells and thus create a force for fixing or retaining the part This formation of

vide dans les alvÃ©oles couverts se produit assez rapi-Â Â vacuum in the covered cells occurs fairly quickly

dement, en raison du volume relativement faible des -8- alvÃ©oles; toutefois, en ce qui concerne les alvÃ©oles 28,28 qui sont laissÃ©s libres ou exposÃ©s par la piÃ¨ce, la quantitÃ© totale d'air qui s'Ã©coule Ã travers leurs ouvertures 34, 34 est encore suffisamment petite pour qu'un vide acceptable puisse Ãªtre entretenue dans laÂ Â because of the relatively small volume of the cells; however, with respect to the cavities 28, 28 which are left free or exposed by the room, the total amount of air flowing through their openings 34, 34 is still small enough that an acceptable vacuum can be created. maintained in the

chambre Ã vide 30 par une pompe Ã vide de capacitÃ© rela-Â Â vacuum chamber 30 by a vacuum pump of relative capacity

tivement faible telle que celle reprÃ©sentÃ©e en 35 sur la Figure 3 Le nombre des cellules d'aspiration, leurs dimensions, leur forme et leur espacement, la dimension des orifices 34,34 et la taille de la pompe Ã vide 35Â Â tively small such as that shown at 35 in FIG. 3 The number of suction cells, their dimensions, their shape and their spacing, the size of the orifices 34, 34 and the size of the vacuum pump 35

peuvent varier dans de larges limites suivant l'utilisa-Â Â may vary within wide limits depending on the use

tion Ã laquelle le porte-piÃ¨ce est destinÃ© Toutefois,Â Â tion for which the workpiece holder is intended However,

par exemple, le porte-piÃ¨ce peut comporter, comme reprÃ©-Â Â for example, the workpiece carrier may include, as shown

sentÃ©, 144 cellules d'aspiration 22,22 dÃ©finies par des alvÃ©oles cylindriques 28,28 de 19,05 mm de diamÃ¨tre, qui sont espacÃ©s les uns des autres de 25,4 mm, en douze rangÃ©es et douze colonnes et les orifices 34, 34 peuvent avoir un diamÃ¨tre d'environ 0,25 mm et une longueurÂ Â smelled, 144 suction cells 22,22 defined by cylindrical cells 28,28 of 19.05 mm in diameter, which are spaced from each other by 25.4 mm, in twelve rows and twelve columns and the orifices 34, 34 can have a diameter of about 0.25mm and a length

d'environ 3,2 mm Avec ce type de construction du porte-Â Â about 3.2 mm With this type of carrier construction

piÃ¨ce, une pompe Ã vide 35 entraÃ®nÃ©e par un moteur de 93 W environ devrait Ãªtre suffisante pour desservir convenablement le porte-piÃ¨ce En tous cas, la capacitÃ© de la pompe ou autre source de vide utilisÃ©e avec le porte-piÃ¨ce doit Ãªtre telle que la pompe soit capable de maintenir un vide apprÃ©ciable, d'environ 127 mm de mercure ou plus, dans la chambre Ã vide 30 lorsque toutes les cellules d'aspiration 22,22 sont exposÃ©es parce qu'aucune piÃ¨ce n'est placÃ©e sur la rÃ©gion support deÂ Â workpiece, a vacuum pump 35 driven by a motor of about 93 W should be sufficient to adequately service the workpiece carrier In any case, the capacity of the pump or other vacuum source used with the workpiece carrier must be such that the pump capable of maintaining an appreciable vacuum, of approximately 127 mm of mercury or more, in the vacuum chamber 30 when all the suction cells 22,22 are exposed because no part is placed on the support region of

piÃ¨ce 18.Exhibit 18.

Ainsi qu'on l'a reprÃ©sentÃ©e, la pompe Ã vide 35 est reliÃ©e au porte-piÃ¨ce 14 par une-conduite de vide 36 qui communique avec la piÃ¨ce Ã vide 30 La pompe Ã vide est de prÃ©fÃ©rence une pompe qui travaille continuellement pendant que le porte-piÃ¨ce est utilisÃ© avec diffÃ©rentes piÃ¨ces successives Pour faciliter le -9- transfertdes piÃ¨ces au porte-piÃ¨ce ou de ce porte-piÃ¨ce Ã un autre endroit, le porte-piÃ¨ce peut comporter, ainsiÂ Â As shown, the vacuum pump 35 is connected to the workpiece 14 by a vacuum line 36 which communicates with the vacuum piece 30 The vacuum pump is preferably a pump which works continuously while the workpiece carrier is used with different successive parts To facilitate the transfer of the parts to the workpiece carrier or from this workpiece carrier to another place, the workpiece carrier may thus include

qu'on l'a reprÃ©sentÃ©, un Ã©vent 28 et un appareil obtura-Â Â that we have represented, a vent 28 and a shutter device

teur 40 Ã commande manuelle dans cet Ã©vent.Â Â tor 40 manual control in this vent.

L'obturateur 40 reprÃ©sentÃ© est sollicitÃ© vers le haut, pour prendre une position fermÃ©e, par un ressort 42 et on peut l'abaisser manuellement, pour leÂ Â The shutter 40 shown is biased upward, to take a closed position, by a spring 42 and can be lowered manually, for the

placer dans une position ouverte, dans laquelle sa lu-Â Â place in an open position, in which its lu-

miÃ¨re 44 est alignÃ©e sur l'Ã©vent 38 pour mettre laÂ Â 44 is aligned with the vent 38 to put the

chambre Ã vide 30 en communication avec l'atmosphÃ¨re.Â Â vacuum chamber 30 in communication with the atmosphere.

Par consÃ©quent, lorsqu'on doit placer une piÃ¨ce sur le porte-piÃ¨ce 18, on enfonce l'obturateur 40 pour mettre la chambre Ã vide 30 Ã l'air libre Pendant que cette mise Ã l'air libre est effective, on peut placer la piÃ¨ce sur la rÃ©gion de fixation 18 et la faire glisser facilement sur la rÃ©gion de fixation pour l'amener Ã n'importe quelle position dÃ©sirÃ©e Ensuite, on relÃ¢che l'obturateur 40 pour fermer l'Ã©vent 38, faire le vide dans la chambre 30 et appliquer le vide Ã la piÃ¨ce 31 par l'intermÃ©diaire des cellules d'aspiration 22,22 qui sont recouvertes Pour retirer la piÃ¨ce du porte-piÃ¨ce, on abaisse Ã nouveau l'obturateur 40, en relÃ¢chant le vide dans la chambre Ã vide et dans les cellules d'aspiration recouvertes, ce qui supprime la force de fixation exercÃ©eÂ Â Consequently, when a part has to be placed on the workpiece holder 18, the shutter 40 is pressed in to put the vacuum chamber 30 in the open air. While this setting in the open air is effective, one can place the part on the attachment region 18 and easily slide it over the attachment region to bring it to any desired position Then, the shutter is released 40 to close the vent 38, create a vacuum in the chamber 30 and apply the vacuum to the part 31 by means of the suction cells 22, 22 which are covered. To remove the part from the part holder, the shutter 40 is again lowered, releasing the vacuum in the chamber. vacuum and in the covered suction cells, which removes the fixing force exerted

sur la piÃ¨ce et permet de soulever facilement cette der-Â Â on the workpiece and allows easy lifting

niÃ¨re du porte-piÃ¨ce.workpiece carrier.

Les Figures 4, 5 et 6 montrent un porte-Â Â Figures 4, 5 and 6 show a holder

piÃ¨ce 46 constituant une autre forme de rÃ©alisation LeÂ Â part 46 constituting another embodiment Le

porte-piÃ¨ce 46 comprend une plaque principale 48 possÃ©-Â Â workpiece holder 46 includes a main plate 48

dant une face supÃ©rieure plane 50 qui prÃ©sente une sÃ©rie d'alvÃ©oles cylindriques 52,52 de dimension uniforme et rÃ©partis rÃ©guliÃ¨rement sur la face 50 La face supÃ©rieure est Ã son tour recouverte d'une feuille flexible 53 dont la surface supÃ©rieure forme la rÃ©gion porte-piÃ¨ce 56 du porte-piÃ¨ce; et la feuille est de prÃ©fÃ©rence faite - d'une matiÃ¨re qui donne Ã sa surface une qualitÃ© de friction capable d'empÃªcher le glissement des piÃ¨ces sur cette surface, la matiÃ¨re Ã©tant Ã©galement de prÃ©fÃ©renceÂ Â dant a planar upper face 50 which has a series of cylindrical cells 52,52 of uniform size and distributed regularly on the face 50 The upper face is in turn covered with a flexible sheet 53 whose upper surface forms the carrier region part 56 of the workpiece carrier; and the sheet is preferably made of - a material which gives its surface a quality of friction capable of preventing the parts from sliding on this surface, the material also preferably being

une matiÃ¨re Ã©lastomÃ¨re, de faÃ§on Ã favoriser l'Ã©tablis-Â Â an elastomeric material, so as to favor the establishment

sement d'un joint Ã©tanche entre la surface infÃ©rieureÂ Â a tight seal between the bottom surface

d'une piÃ¨ce et les cellules d'aspiration du porte-piÃ¨ce.Â Â and the suction cells of the workpiece carrier.

Diverses matiÃ¨res diffÃ©rentes peuvent Ãªtre utilisÃ©es pour la feuille 53 et, par exemple, cette feuille peutÂ Â Various different materials can be used for sheet 53 and, for example, this sheet can

Ãªtre constituÃ©e par une feuille d'urÃ©thane ou de nÃ©o-Â Â consist of a urethane or neo sheet

prÃ¨ne Les rÃ©gions de la feuille 53 qui recouvrent lesÂ Â take the regions of sheet 53 which cover the

alvÃ©oles 52,52 et coÃ¯ncident avec ces derniers consti-Â Â alveoli 52,52 and coincide with these latter

tuent les cellules d'aspiration 58,58 du porte-piÃ¨ce 46 et la rÃ©gion de la feuille supÃ©rieure qui entoure les cellules d'aspiration 58,58 constitue une surface 60 deÂ Â kill the suction cells 58,58 of the workpiece holder 46 and the region of the top sheet which surrounds the suction cells 58,58 constitutes a surface 60 of

contact avec les piÃ¨ces.contact with parts.

Une chambre Ã vide 30, analogue Ã celle du porte-piÃ¨ce 14, est mÃ©nagÃ©e dans le porte-piÃ¨ce 46 et se trouve au-dessous de chacun des alvÃ©oles 52, 52 Une communication entre chaque alvÃ©ole 52 et la chambre Ã vide 30 est Ã©tablie par une ouverture relativement grande 62 mÃ©nagÃ©e dans le fond de chaque alvÃ©ole, qui n'oppose pas de rÃ©sistance notable Ã l'Ã©coulement de l'air entre l'alvÃ©ole et la chambre Ã vide Un moyen de formation d'un Ã©tranglement dans le passage d'Ã©coulement entre chaque cellule d'aspiration 58 et la chambre Ã vide 30 est constituÃ© par une petite ouverture 64 mÃ©nagÃ©e dans la feuille 53, laquelle prÃ©sente une ouverture 64 pourÂ Â A vacuum chamber 30, similar to that of the workpiece carrier 14, is provided in the workpiece carrier 46 and is located below each of the cells 52, 52 A communication between each cell 52 and the vacuum chamber 30 is established by a relatively large opening 62 formed in the bottom of each cell, which does not oppose significant resistance to the flow of air between the cell and the vacuum chamber A means of forming a constriction in the passage flow between each suction cell 58 and the vacuum chamber 30 is constituted by a small opening 64 formed in the sheet 53, which has an opening 64 for

chaque cellule d'aspiration 58.each suction cell 58.

Le vide produit dans chaque alvÃ©ole 52 attire dans cet alvÃ©ole la partie sus-jacente de la feuille 53, comme reprÃ©sentÃ© sur la Figure 5, en donnantÂ Â The vacuum produced in each cell 52 attracts in this cell the overlying part of the sheet 53, as shown in Figure 5, giving

ainsi aux cellules d'aspiration 52,58 la forme et l'ap-Â Â thus to the suction cells 52,58 the form and the ap-

parence de ventouses et la face 66, supÃ©rieure ou diri-Â Â parence of suction cups and face 66, upper or direct

gÃ©e vers l'extÃ©rieur, de chaque cellule d'aspiration, qui est de niveau avec la surface 60 de contact avec laÂ Â outwardly, from each suction cell, which is level with the surface 60 of contact with the

- 11- 11

piÃ¨ce, est donc entiÃ¨rement ouverte Lorsqu'une piÃ¨ce telle que celle reprÃ©sentÃ©e en 31 sur la Figure 1 estÂ Â part, is therefore fully open When a part such as that shown at 31 in Figure 1 is

placÃ©e sur le porte-piÃ¨ce 46, les cellules 58,58 cou-Â Â placed on the workpiece holder 46, the cells 58.58 cou-

vertes par la piÃ¨ce sont mises sous vide par l'extraction d'air Ã travers leurs ouvertures 64,64 Cette dÃ©pression est appliquÃ©e Ã la surface infÃ©rieure de la piÃ¨ce 28, par l'intermÃ©diaire des faces supÃ©rieures ouvertes 66, 66 des cellules recouvertes, en crÃ©ant une force de fixation tendant Ã attirer la piÃ¨ce vers le bas, vers le porte-piÃ¨ce Lorsque ceci se produit, la feuille 53 est comprimÃ©e entre la piÃ¨ce 28 et la plaque 48, en Ã©tablissant ainsi un joint Ã©tanche autour du bord de chaque cellule d'aspiration recouverte 58 et-la face infÃ©rieure de la piÃ¨ce, pour empÃªcher la pÃ©nÃ©tration deÂ Â green by the part are evacuated by the extraction of air through their openings 64,64 This vacuum is applied to the lower surface of the part 28, via the open upper faces 66, 66 of the covered cells, by creating a fixing force tending to attract the workpiece downwards, towards the workpiece carrier When this occurs, the sheet 53 is compressed between the workpiece 28 and the plate 48, thereby establishing a tight seal around the edge of each covered suction cell 58 and the underside of the part, to prevent the penetration of

l'air extÃ©rieur dans la cellule.outside air in the cell.

Ici, Ã©galement, comme dans le cas des ou-Â Â Here, too, as in the case of the ou-

vertures 34,34 du porte-piÃ¨ce 14, la dimension des ou-Â Â vertices 34,34 of the workpiece holder 14, the size of the

vertures 64,64 formant Ã©tranglement est si petite que la quantitÃ© totale d'air qui traverse les cellules 58,58 non recouvertes est suffisamment petite pour qu'un degrÃ© appropriÃ© de vide puisse Ãªtre maintenu dans la chambre Ã Â Â 64.64 constriction grooves are so small that the total amount of air passing through the uncovered cells 58.58 is small enough that an appropriate level of vacuum can be maintained in the chamber

vide 30 quel que soit le nombre des cellules non recou-Â Â empty 30 whatever the number of cells not covered

vertes. Comme on l'a reprÃ©sentÃ© sur la Figure 6, chaque trou 64 du portepiÃ¨ce 46 est constituÃ© par une ouverture distincte, qui peut Ãªtre formÃ©e au moyen d'unÂ Â green. As shown in Figure 6, each hole 64 of the workpiece holder 46 is constituted by a separate opening, which can be formed by means of a

foret ou par un outil de perÃ§age chauffÃ© enfoncÃ© Ã tra-Â Â drill bit or by a heated drilling tool inserted through

vers la feuille 53 Toutefois, il peut Ãªtre prÃ©vu d'au-Â Â to sheet 53 However, provision may be made for

tres types d'ouvertures et, comme exemple d'un tel autre type, la Figure 7 montre une ouverture 64 ' constituÃ©eÂ Â very types of openings and, as an example of such another type, Figure 7 shows an opening 64 'made up

par une petite fente formÃ©e en enfonÃ§ant une lame tran-Â Â by a small slit formed by driving in a sharp blade

chante Ã travers la feuille 53 sans enlever une quantitÃ© notable de matiÃ¨re Lorsque l'alvÃ©ole correspondant est mis sous vide, la fente 64 ' s'ouvre suffisamment pourÂ Â sings through the sheet 53 without removing a significant amount of material When the corresponding cell is evacuated, the slot 64 'opens sufficiently to

laisser l'air pÃ©nÃ©trer dans l'alvÃ©ole Ã travers elle.Â Â let air enter the cell through it.

12 - Dans le porte-piÃ¨ce 46 des Figures 4, 5 et 6, les alvÃ©oles 52,52 ne sont pas garnis, de sorte que, lorsqu'on fait le vide dans les alvÃ©oles, les parties sus-jacentes de la feuille 53 sont attirÃ©es dans les alvÃ©oles sur une distance qui varie avec le degrÃ© de vide rÃ©gnant dans les alvÃ©oles et avec l'Ã©lasticitÃ© deÂ Â 12 - In the workpiece holder 46 of FIGS. 4, 5 and 6, the cells 52, 52 are not filled, so that, when there is a vacuum in the cells, the overlying parts of the sheet 53 are drawn into the alveoli over a distance which varies with the degree of vacuum in the alveoli and with the elasticity of

la matiÃ¨re de la feuille Si la feuille 53 est trÃ¨s min-Â Â the material of the sheet If the sheet 53 is very thin

ce, comme cela peut Ãªtre souhaitable dans certains cas, cette attraction de la feuille dans les alvÃ©oles 52,52Â Â this, as may be desirable in certain cases, this attraction of the sheet in the alveoli 52,52

peut tendre Ã briser la feuille ou peut attirer la feuil-Â Â may tend to break the leaf or may attract leaf

le pour l'appliquer sur les fonds des alvÃ©oles, en obstruant ainsi certaines des ouvertures 64,64 Pour Ã©viter cet inconvÃ©nient, chaque alvÃ©ole peut Ãªtre muni, comme on l'a reprÃ©sentÃ© dans le porte-piÃ¨ce 46 ' de la Figure 8, d'une garniture poreuse 68, permÃ©able Ã l'air, telle qu'un bloc de feutre ou de mÃ©tal frittÃ©, dont la surface supÃ©rieure est situÃ©e seulement Ã une petite distance au-dessous de la surface supÃ©rieure 50 de la plaque 48 Par consÃ©quent, comme on l'a reprÃ©sentÃ© sur la Figure 8, les garnitures 68,68 entrent en contact avec des parties de la feuille 53 qui sont aspirÃ©es dansÂ Â to apply it to the bottom of the cells, thereby obstructing some of the openings 64,64 To avoid this drawback, each cell can be provided, as shown in the workpiece holder 46 'in Figure 8, d a porous lining 68, permeable to air, such as a block of felt or sintered metal, the upper surface of which is situated only a small distance below the upper surface 50 of the plate 48 Consequently, as shown in Figure 8, the linings 68, 68 come into contact with parts of the sheet 53 which are drawn into

les alvÃ©oles 52,52 en permettant ainsi de crÃ©er des al-Â Â the alveoli 52,52, thus making it possible to create al-

vÃ©oles d'aspiration 58,58 sans Ã©tirage ou autre dÃ©forma-Â Â suction tubes 58.58 without stretching or other deformation

tion indÃ©sirÃ©e d'amplitude excessive de la feuille 53.Â Â undesired excessively large leaf 53.

Dans chacun des portes-piÃ¨ces 14 et 46 dÃ©crits plus haut, chaque cellule d'aspiration prÃ©sente une face extÃ©rieure entiÃ¨rement libre ou ouverte, qui ne donne pas d'appui Ã la piÃ¨ce, l'appui de la piÃ¨ce Ã©tant entiÃ¨rement assurÃ© par la surface de contact avec laÂ Â In each of the workpieces 14 and 46 described above, each suction cell has an entirely free or open external face, which does not give support to the workpiece, the workpiece support being entirely provided by the surface of contact with

piÃ¨ce qui entoure les diverses cellules Ces portes-Â Â room that surrounds the various cells These doors

piÃ¨ces sont donc anp DropriÃ©s pour Ãªtre utilisÃ©s avec des piÃ¨ces relativement rigides qui ne sont pas notablement dÃ©formÃ©es par l'absence d'appui dans les zones occupÃ©esÂ Â parts are therefore suitable for use with relatively rigid parts which are not significantly deformed by the lack of support in the occupied areas

par les cellules d'aspiration Toutefois, ces portes-Â Â by the suction cells However, these holders

piÃ¨ces pourraient ne pas possÃ©der de performances 13 - satisfaisantes pour la fixation de piÃ¨ces en papier ouÂ Â parts may not perform 13 - satisfactory for fixing paper parts or

autres piÃ¨ces minces et flexibles analogues Pour rÃ©sou-Â Â other similar thin and flexible parts For resolving

dre ce problÃ¨me, et rÃ©aliser un porte-piÃ¨ce pour de teres piÃ¨ces flexibles, les cellules d'aspiration peuvent Ãªtre conÃ§ues de maniÃ¨re Ã prÃ©senter des faces externes ana-Â Â dre this problem, and realize a workpiece for teres flexible parts, the suction cells can be designed so as to present external faces ana-

logues Ã des tamis, qui sont composÃ©es en partie d'ou-Â Â sieves, which are partly made up of

vertures libres et en partie d'une matiÃ¨re pouvant Ãªtre mise en contact avec la face infÃ©rieure de la piÃ¨ce, pour constituer un appui pour la piÃ¨ce dans la rÃ©gion des cellules d'aspiration Les Figures 9, 10, il montrent trois portes-piÃ¨ces construits de cette faÃ§on CesÂ Â free grooves and partly of a material which can be brought into contact with the underside of the part, to constitute a support for the part in the region of the suction cells Figures 9, 10, it show three work-holders constructed this way these

portes-piÃ¨ces sont en grande partie analogues au porte-Â Â workpiece carriers are largely analogous to the workpiece carrier

piÃ¨ce 14 des Figures 1 Ã 3 et les parties qui sont ou peuvent Ãªtre identiques Ã celles du porte-piÃ¨ce 14 ont reÃ§u les mÃªmes numÃ©ros de rÃ©fÃ©rence et il n'est donc pasÂ Â part 14 of Figures 1 to 3 and the parts which are or may be identical to those of the workpiece holder 14 have been given the same reference numbers and therefore it is not

nÃ©cessaire de les dÃ©crire Ã nouveau.Â Â necessary to describe them again.

La Figure 9 montre un porte-piÃ¨ce 76 dans lequel chaque alvÃ©ole 28 est garni d'une garniture 7Â Â Figure 9 shows a workpiece 76 in which each cell 28 is lined with a gasket 7

poreuse permÃ©able Ã l'air qui prÃ©sente une surface supÃ©-Â Â porous air permeable which has a superior surface

rieure 80 de niveau avec la surface 20 de contact avec la piÃ¨ce Chaque Ã©lÃ©ment rapportÃ© 80 peut Ãªtte, parÂ Â 80 level with the surface 20 of contact with the part Each added element 80 can be, for

exemple, fait d'un mÃ©tal frittÃ© ou de feutre rigide.Â Â example, made of sintered metal or rigid felt.

La Figure 10 montre un porte-piÃ¨ce 82 dans lequel Ã chaque alvÃ©ole est associÃ©e une plaquette Ã Â Â FIG. 10 shows a workpiece carrier 82 in which a plate is associated with each cell.

orifices faite d'un mÃ©tal rigide ou d'une matiÃ¨re plas-Â Â holes made of rigid metal or plastic

tique rigide et qui est logÃ©e dans une partie supÃ©rieure en Ã©paulement de l'alvÃ©ole Chaque plaquette 84 possÃ¨de une surface supÃ©rieure 86 de niveau avec la surface 20 de la plaque 16 qui entre en contact avec la piÃ¨ce etÂ Â rigid tick and which is housed in an upper shoulder portion of the cell Each plate 84 has an upper surface 86 level with the surface 20 of the plate 16 which comes into contact with the part and

elle prÃ©sente un grand nombre d'ouvertures 94,94 de dia-Â Â it has a large number of 94.94 dia-

mÃ¨tre relativement grand, qui la traversent et comnmuni-Â Â relatively large meter, which cross it and comnmuni-

quent avec chacun des alvÃ©oles 28,28 sous-jacents De cette faÃ§on, chaque groupe d'ouvertures 94,94 associÃ© Ã un alvÃ©ole 28 est encerclÃ© d'une ligne interrompue 96 sur la Figure 11 constitue une cellule d'aspiration et 14 la face supÃ©rieure de la feuille 92 qui est comprise entre les zones 96,96 des cellules d'aspiration forme une surface 20 ' de contact avec les piÃ¨ces analogues Ã la rÃ©gion 20 du porte-piÃ¨ce 14, qui est destinÃ©e Ã entrer en contact avec les piÃ¨ces.Â Â quent with each of the underlying cavities 28,28 In this way, each group of openings 94,94 associated with a cavity 28 is surrounded by a broken line 96 in FIG. 11 constitutes a suction cell and 14 the face upper part of the sheet 92 which is between the zones 96, 96 of the suction cells forms a surface 20 'of contact with the parts similar to the region 20 of the workpiece holder 14, which is intended to come into contact with the parts .

Dans tous les porte-piÃ¨ces dÃ©crits prÃ©cÃ©-Â Â In all the workpieces described above

demment, les cellules d'aspiration ont Ã©tÃ© reprÃ©sentÃ©es ou considÃ©rÃ©es comme Ã©tant d'une dimension sensiblement uniforme et comme Ã©tant rÃ©parties uniformÃ©ment sur la rÃ©gion de fixation des piÃ¨ces Toutefois, ceci n'est pasÂ Â Also, the suction cells have been shown or considered to be of a substantially uniform size and to be distributed uniformly over the region of attachment of the parts. However, this is not

nÃ©cessaire et, si l'on sait que de petites piÃ¨ces doi-Â Â necessary and, if we know that small parts must

vent toujours Ãªtre placÃ©es en un mÃªme emplacement de la rÃ©gion de fixation des piÃ¨ces, il peut Ãªtre souhaitable de prÃ©voir un grand nombre de cellules d'aspiration de dimensions relativement petites dans cet emplacement, et d'accroÃ®tre progressivement la dimension et l'espacementÂ Â Always be placed in the same location of the part attachment region, it may be desirable to provide a large number of suction cells of relatively small dimensions in this location, and gradually increase the dimension and spacing

des cellules d'aspiration au fur et Ã mesure de l'accrois-Â Â suction cells as they grow

sement de leur Ã©loignement de cet emplacement Un tel porte-piÃ¨ce est reprÃ©sentÃ©, par exemple, en 98 sur la Figure 12 et ce porte-piÃ¨ce comprend un grand nombre de cellules d'aspiration 100,100 Ces cellules d'aspirationÂ Â ment of their distance from this location Such a workpiece holder is shown, for example, at 98 in FIG. 12 and this workpiece holder comprises a large number of suction cells 100,100 These suction cells

peuvent Ãªtre analogues, Ã l'exception de leurs dimen-Â Â may be analogous, with the exception of their dimensions

sions et de leur distribution, Ã l'une quelconque des cellules dÃ©crites prÃ©cÃ©demment et la structure restante du porte-piÃ¨ce 98 peut Ã©galement Ãªtre analogue Ã celle de l'un quelconque des portes-piÃ¨ces dÃ©crits plus haut Le porte-piÃ¨ce 98 possÃ¨de une rÃ©gion 102 de fixation des piÃ¨ces et, le long de deux bords de la zone 102, il possÃ¨de deux rÃ©glettes rectilignes 104 et 106Â Â sions and their distribution, to any of the cells described above and the remaining structure of the workpiece carrier 98 may also be similar to that of any of the workpiece carriers described above. The workpiece carrier 98 has a region 102 for fixing the parts and, along two edges of the zone 102, it has two rectilinear strips 104 and 106

qui aident Ã placer les piÃ¨ces sur la rÃ©gion de fixa-Â Â which help place the pieces on the fixation region

tion Lorsqu'il s'agit de piÃ¨ces rectangulaires, on dispose la piÃ¨ce sur le porte-piÃ¨ce 98 en mettant deux de ses bords respectivement en contact avec les rÃ©glettes rectilignes 104 et 106 Les piÃ¨ces les plus petites seront donc toujours placÃ©es dans l'angle supÃ©rieur - gauche du porte- piÃ¨ce, vu sur la Figure 12 ConformÃ©mentÂ Â When it comes to rectangular pieces, the piece is placed on the workpiece holder 98 by putting two of its edges respectively in contact with the straight bars 104 and 106 The smallest pieces will therefore always be placed in the corner upper - left of the workpiece carrier, seen in Figure 12 According

Ã ceci, les alvÃ©oles 100,100 prÃ©vus dans l'angle supÃ©-Â Â to this, the 100,100 cells provided in the upper corner

rieur gauche de la rÃ©gion 102 de fixation des piÃ¨ces sont de dimensions relativement petites et ils sont relativement rapprochÃ©s les uns des autres et les autres cellules d'aspiration 100,100 croissent en dimension et espacement au fur et Ã mesure de l'accroissement de leur Ã©loignement par rapport Ã l'angle supÃ©rieur gauche Cet arrangement des cellules d'aspiration garantis que le nombre des cellules d'aspiration qui sera recouvert par une petite piÃ¨ce sera suffisant pour dÃ©velopper une force de fixation appropriÃ©e pour cette piÃ¨ce tout en rÃ©duisant en mÃªme temps la fuite d'air par pÃ©nÃ©tration dans la chambre Ã vide en ne laissant exposÃ©es qu'un plus petit nombre de cellules d'aspiration que ce neÂ Â the left laughing part of the region 102 for fixing the parts are relatively small and they are relatively close to one another and the other suction cells 100, 100 grow in size and spacing as their distance increases. compared to the upper left corner This arrangement of the suction cells guarantees that the number of suction cells that will be covered by a small part will be sufficient to develop an appropriate fixing force for this part while at the same time reducing the leakage of air by penetration into the vacuum chamber leaving exposed only a smaller number of suction cells than it does

serait le cas avec une dimension uniforme et une dis-Â Â would be the case with a uniform dimension and a dis-

tribution uniforme des cellules Lorsqu'on place uneÂ Â uniform tribution of cells When placing a

grande piÃ¨ce sur le porte-piÃ¨ce 98, les cellules d'aspi- ration couvertes dÃ©veloppent une grande force pour fixerÂ Â large workpiece on workpiece holder 98, the covered suction cells develop great force to fix

la piÃ¨ce au porte-piÃ¨ce, les grandes cellules d'aspira-Â Â the workpiece holder, the large vacuum cells

tion largement espacÃ©es, situÃ©es dans les zones Ã©loignÃ©esÂ Â widely spaced, located in remote areas

de l'angle supÃ©rieur gauche Ã©tant suffisantes pour main-Â Â of the upper left corner being sufficient for main-

tenir les extrÃ©mitÃ©s de la piÃ¨ce appliquÃ©es.Â Â hold the ends of the part applied.

Il convient encore de remarquer qu'en ce qui concerne le porte-piÃ¨ce 46 des Figures 4, 5 et 6,Â Â It should also be noted that with regard to the workpiece holder 46 of Figures 4, 5 and 6,

la feuille supÃ©rieure 53 peut Ãªtre fournie Ã l'utilisa-Â Â the top sheet 53 can be supplied to the user.

teur sous la forme d'une feuille non perforÃ©e, l'utili-Â Â in the form of an unperforated sheet, the user

sateur perÃ§ant alors les ouvertures 64,64, selon les besoins des diffÃ©rentes piÃ¨ces C'est-Ã -dire que, par exemple, le porte-piÃ¨ce peut avoir une grande rÃ©gion deÂ Â sator then piercing the openings 64,64, according to the needs of the different parts, that is to say that, for example, the workpiece holder can have a large region of

fixation des piÃ¨ces et un grand nombre d'alvÃ©oles 52,52.Â Â fixing the parts and a large number of cells 52.52.

Dans ce cas, lorsqu'on utilise le porte-piÃ¨ce pour tenir une piÃ¨ce beaucoup plus petite que la rÃ©gion de fixation des piÃ¨ces qui est disponible, l'opÃ©rateur peut percer des ouvertures 64,64 dans la feuille de maniÃ¨re Ã ne 16 - former de telles ouvertures que pour les alvÃ©oles qui seront recouverts par la piÃ¨ce Naturellement, la feuille supÃ©rieure est remplaÃ§able et on peut utiliser selon le besoin de nouvelles feuilles non perforÃ©es, que l'on perfore selon le besoin L'opÃ©ration de perforation estÂ Â In this case, when the workpiece carrier is used to hold a workpiece much smaller than the workpiece attachment region which is available, the operator can pierce openings 64, 64 in the sheet so as not to form such openings as for the cells which will be covered by the part Naturally, the upper sheet is replaceable and new non-perforated sheets can be used as needed, which are punctured as required. The perforation operation is

facile et peut Ãªtre exÃ©cutÃ©e Ã peu de frais.Â Â easy and can be performed inexpensively.

17 -17 -

## Classifications

- B26D7/018
- B23Q3/08
- B25B11/00
- B25B11/005
- B26D7/01

## Cited patent documents

- [DE-1249780-B](https://patents.google.com/patent/DE1249780B/en) — SEA
- [FR-2208757-A2](https://patents.google.com/patent/FR2208757A2/en) — SEA
- [US-3004766-A](https://patents.google.com/patent/US3004766A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
