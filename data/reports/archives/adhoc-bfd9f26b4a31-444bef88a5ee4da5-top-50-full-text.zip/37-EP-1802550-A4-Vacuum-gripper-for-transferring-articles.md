# 37. Vacuum gripper for transferring articles

- **Archive rank:** 37 of 50
- **Publication:** [EP-1802550-A4](https://patents.google.com/patent/EP1802550A4/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/033306102/publication/EP1802550A4?q=pn%3DEP1802550A4)
- **Publication date:** 2013-09-25
- **Filing date:** 2005-10-11
- **Earliest priority:** 2004-10-12
- **Family:** 33306102
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** PINOMATIC OY
- **Inventors:** PITKAERANTA JUHA; RANTALA MATTI

## Abstract

_No abstract was available from the queried sources._

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/EP-1802550-A4/ops000.png)

![Sketch 1 for EP-1802550-A4](https://nimo.iptorch.com/refdrawing/EP-1802550-A4/ops000.png)

## Claims

### Claim 1 (independent)

A vacuum gripper for lifting and transferring articles, the vacuum gripper comprising: - a vacuum space (7), - sealing means (6), - a plurality of inward relief valves arranged between the vacuum space (7) and the sealing means (6), each of the inward relief valves comprising a channel and a moving object (3) arranged in each channel, which channel further comprises, in parallel with the passage, a spring (2) that is arranged to direct forces at the moving object (3), the moving object (3) having a cup-like shape extending to the sides of the spring (2), characterized in that the moving object has the property of closing the air flow between the vacuum space and the channel completely if the air flow between the channel and the moving object (3) generates in the moving object (3) a force that overcomes the counterforce of the spring (2).

### Claim 2

A vacuum gripper according to claim 1, characterized in that the sealing means comprise a sealing plate the material of which is foam rubber.

### Claim 3

A vacuum gripper according to any one of claims 1 to 2, characterized in that the foam rubber of the sealing plate has been selected to have such a porosity that it allows predetermined by-pass flow through it in connection with attachment to the article.

### Claim 4

A vacuum gripper according to any one of the preceding claims, characterized in that a screen section has been positioned between the inward relief valve and the sealing means.

### Claim 5 (independent)

An inward relief valve intended particularly for a device with which articles can be gripped by means of negative pressure from above, from one side or from below, the inward relief valve comprising: - a frame part (1), - a channel provided in the frame part (1), enabling air flow through the frame part, - a moving object (3) positioned in the channel and arranged to be movable in the channel, which channel is further provided, in parallel with the passage, a spring (2) that is adapted to direct forces at the moving object (3), the moving object (3) having a cup-like cylindrical shape extending to the sides of the spring (2), characterized in that the moving object closes the air flow between the vacuum space and the channel completely if the air flow between the channel and the moving object (3) generates in the moving object (3) a force that overcomes the counterforce of the spring (2).

### Claim 6

An inward relief valve according to claim 5, characterized in that the moving object (3) is manufactured of plastic.

### Claim 7

An inward relief valve according to any one of the preceding claims, characterized in that the outer diameter of the moving object (3) is 3 to 10 % smaller than the inner diameter of the valve frame (1), this difference functioning as the flow channel.

## Full description

### BACKGROUND OF THE INVENTION

**[0001]**

The invention relates to a device for gripping articles from above, from one side or from below by means of negative pressure. The device may be moved in different positions and places by manpower or mechanically with a robot or another lifting device.

**[0002]**

Publication FR 2152957 (Herman ) discloses a channel structure of a vacuum gripper in which the channel has a moving ball capable of closing said channel.

**[0003]**

Swedish publication SE-C-506603 discloses a channel structure comprising, in connection with a first channel, a second channel having a diameter that is essentially smaller than the diameter of the first channel, whereby the moving ball is capable of closing the first channel when negative pressure is generated in a vacuum space, except for the air flow of the second channel. Such a by-pass channel allows air to pass through it all the time.

**[0004]**

Further, both solutions has a metal ball as the closing means. When a gravitationally returning ball is used, said devices are applicable to gripping an article only from above. Publication DE 3810989 discloses an apparatus for handling and transporting articles with the features of the preamble of claim 1, comprising a closure body movable in a suction channel back and forth between an open position and a working position, depending on the pressure gradient between a vacuum side and a working side, in such a manner that, in its working position, the flow cross-section available for the sucked-in air is reduced with respect to the open position.

### BRIEF DESCRIPTION OF THE INVENTION

**[0005]**

A new vacuum gripper and an inward relief valve have now been developed. The solution is characterised by what is stated in the independent claims. Preferred embodiments of the invention are set forth in the dependent claims.

**[0006]**

One of the aims of the invention is to provide a vacuum gripper structure allowing an article to be gripped from above, from one side or from below. This aim is achieved by providing a cup-like object that moves in the channel. The cup-like construction is, for example, a cylinder inside which a spring is placeable, whereby sudden acceleration, braking or vibration does not hinder the operation. The cup-like construction functions as the support and controller of the spring when the spring moves in the passage of the inward relief valve. Placing the spring at least partially inside the valve cup allows implementation of a small flow channel between the passage and the moving object. The valve cup has a light structure, and it can be manufactured of plastic material, for instance. Further, properties of the vacuum gripper can be changed easily by changing the valve cup and/or spring.

**[0007]**

Another aim of the invention is to provide a vacuum gripper construction having low air consumption (energy consumption), because the valve cup of a negative pressure valve according to the invention closes the air flow completely, if required. This is significant for example when the vacuum gripper is provided with a plurality of inward relief valves for gripping articles of different sizes. Thus, the article does not necessarily extend to all inward relief valves.

**[0008]**

Yet one of the aims of the invention is to provide a negative pressure valve applicable to be used in a vacuum gripper or the like device.

**[0009]**

Advantages of a negative pressure valve and a vacuum gripper include, for instance:

**[0010]**

1. The vacuum gripper can grip articles from above, from one side or from below.

**[0011]**

2. The valve cup can be manufactured of light material, such as plastic. The valve cup is controlled by the force of the spring, whereby sudden acceleration, braking or vibration does not hinder the operation.

**[0012]**

3. Low air consumption (energy consumption) because the cup-like structure closes the air flow completely, if required.

**[0013]**

4. When an article generating dust, for instance wood, is gripped, the screen of the valve becomes cleaned when the article is removed, as the normal air pressure forcefully rushes through the valve back to the surface of the article.

**[0014]**

5. No pass-by channels or holes required by the operation are needed in the valve frame or valve cup.

**[0015]**

6. With regard to the operation of the device, no air containers are needed for providing negative pressure shocks.

**[0016]**

The operation of the invention is based on the vacuum gripper being connected by means of a tube system via a three-way closing valve to an object generating negative pressure. The lower surface of the vacuum gripper has an elastic seal that seals the space between the article and the vacuum gripper in an airtight manner, after which the negative pressure is conducted via the three-way closing valve through the device to the surface of the article which causes the article to be attached to the device. The vacuum gripper quickly grips the article after the opening of the three-way valve, once the negative pressure has reached the surface of the article.

### BRIEF DESCRIPTION OF THE FIGURES

**[0017]**

The invention will now be described in more detail in connection with preferred embodiments, referring to the attached drawings, of which:

**[0018]**

Figure 1 shows a partial cross-section of an embodiment of the vacuum gripper, in which the inward relief valve on the left is shown disassembled and the inward relief valve on the right is shown assembled;

**[0019]**

Figure 2 shows a partial blow-up of the vacuum gripper illustrated in Figure 1 .

### DETAILED DESCRIPTION OF THE INVENTION

**[0018]**

Referring to Figures 1 and 2 , in which the valve cup 3 is pressed against a screen 4 by the force of a spring 2. When a three-way valve 10 opens a vacuum channel into a vacuum space 7 of the box, whereby a flow is generated between the valve cup 3 and a valve frame 5.

**[0019]**

If the by-pass flow of an article 11 against the hole of a sealing plate 6 in the valve is not sufficient to draw the valve cup 3 against the shoulder of a valve frame 1, the valve stays open.

**[0020]**

If the article 11 to be gripped does not close the hole of the sealing plate 6 properly or if the by-pass flow between the valve cup 3 and the valve frame 1 grows otherwise large, the valve cup 3 is pressed against the shoulder of the valve frame 1 and closes the flow through the valve completely.

**[0021]**

The flow may grow large for instance if the sealing plate 6 leaks through itself, the surface of the article 11 to be gripped is so uneven that the sealing plate is not properly shaped into the article, the material of the article 11 is so porous that the flow through the article is large. In the case of such a large flow, the flow force of air between the valve cup 3 and the valve frame 1 is sufficient to overcome the force of the spring 2 of the valve cup, whereby the valve cup 3 is pressed against the shoulder of the valve frame 1 and closes the flow through the valve completely.

**[0022]**

The valve remains closed due to the effect of the negative pressure in the vacuum space 7 until the negative pressure disappears from the vacuum space 7 when the three-way valve has closed the main flow channel and opened a channel out, whereby the vacuum in the vacuum space 7 of the box is filled with normal air pressure. As a result of this, the spring 2 of the valve cup presses the valve cup 3 off the shoulder of the valve frame 1, and the valve is opened.

**[0023]**

The area of the holes of the sealing plate 6 must be sufficiently large in order for the force of the vacuum to keep the article fixedly attached and in order to tightly compress the sealing plate 6 and thus to enable the sealing plate 6 to be tightly shaped to the surface of even an uneven article 11. The material of the sealing plate 6 is foam rubber, which is somewhat porous in such a way that it leaks very slightly through in order for the sealing to be well-shapeable and soft. However, the sealing must be sufficiently dense so as not to allow too much flow through the sealing, so that the amount of air flowing through the valves before closing of the valve can be kept as small as possible for reliable gripping. When the amount of air flowing through the valves is small, the size of the vacuum pump and the tube system can be kept small.

**[0024]**

In the embodiment of Figures 1 and 2 , a valve plate 7 provided with a plurality of inward relief valves is positioned between the vacuum space 7 of the vacuum gripper and the sealing plate. The valve plate 7 is provided with a plurality of valves one after the other and a few valves in parallel, staggered relative to each other. The positioning of the valves may vary according to the shape and size of the articles 11 to be gripped. The valves should, however, be positioned on the valve plate 5 in such a way that even a narrow article can be gripped reliably when at least one valve is always at the point of the article 11. In a case where the edge of the article 11 becomes only partly positioned at the point of the hole of the sealing plate 6 and the valve placed in it, the valve closes completely and hence thus not lose any negative pressure.

**[0025]**

The purpose of the screen 4 is to prevent the access of dirt into the inside of the inward relief valve and to keep the spring 2 of the valve cup as well as the valve cup itself in place. The task of the screen 4 is also to give replacement air to the sealing plate 6 when the article 11 is being detached to enable quick detachment of the article 11 from the sealing plate 6.

**[0026]**

The dimensioning of the diameter of the valve cup 3 allows the adjustment of the amount of flow, i.e. by which amount the valve is closed. The outer diameter of the valve cup is 3 to 10 % smaller and preferably 4 to 7 % smaller and still more preferably 5 to 6 % smaller than the inner diameter of the valve frame 1, this difference functioning as the flow channel. The amount of flow is also affected by how much the sealing plate 6 or the article 11 to be gripped leaks through, as well by the surface shape of the article 11 to be gripped. If the valve closes too easily and does not grip the article, the valve is to be provided with a valve cup 3 with a smaller diameter that allows more flow before closing. Owing to the cylindrical structure of the valve cup 3, the spring 2 of the valve cup gets good guidance from the cup edges. The closing edge of the valve cup 3 must be smooth, so that the valve is closed tightly and thus does not lose any negative pressure. There are no holes at the bottom of the valve cup, so the whole of the flow takes place between the valve cup and the valve.

**[0027]**

The spring 2 of the valve cup and the light valve cup 3 enable reliable functioning of the vacuum gripper irrespective of the position or vibration and sudden movements and allow a short delay for the valve, during which the system has time to grip the article and compress the sealing plate. In addition, the valve is completely closed if the flow is still too large after said delay.

**[0028]**

The frame 1 of the inward relief valve keeps the valve parts in place, guides the movement of the valve cup 3, and the shoulders of the frame function as the countersurface for the valve cup 3 when the valve is closed.

**[0029]**

The three-way valve 10 opens a vacuum channel in the vacuum space 7 when the article is being gripped and closes it when the article is being released at the same time as a second channel is opened which lets the negative pressure out of the vacuum space 7.

**[0030]**

The use of a box-like vacuum gripper allows even narrow articles to be gripped because there are a plurality of inward relief valves in the box. The positioning of the inward relief valves in the box may vary according to the object of use. In the solution according to the invention, those valves of the vacuum gripper that are not directed at the article 11 are completely closed. If the valves were not completely closed, they would lose some negative pressure without even gripping the article 11. Owing to valves that can be completely closed, the size of the vacuum pump can be reduced, or a vacuum pump with lower production can be selected. Similarly, the tube systems leading to the boxes can be provided with a smaller diameter, and thus the whole gripper structure can be made lighter.

**[0031]**

The vacuum gripper entity described above comprises a device in which an object generating negative pressure is connected to a vacuum box 8 via the three-way valve 10 and a tube system 9. The negative pressure is conveyed from between the valve frame 1 and the valve cup 3 via the screen 4 to the surface of the article 11 that is attached to the sealing plate 6, generating a vacuum between the article 11 and the valve plate and generating traction force between the surfaces. If the article 11 is not attached to the sealing plate 6 or if the article is porous, the air flow increases in speed as the pressure difference grows, generating in the valve cup a force that overcomes the counterforce of the spring 2, causing the valve cup 3 to move against the shoulder of the valve frame 1 and closing the air flow, after which the valve cup 3 remains closed with negative pressure, closing the valve. The article 11 is detached from the device by closing the three-way valve 10, whereby there will no longer be any negative pressure directed at the article 11 but normal air pressure arrives in its place via the three-way valve so that the article becomes detached. The moving object is a cup-like cylinder 3 the weight of which is lower than the force of the counterspring 2. The cup-like cylinder is controlled by the force of the spring 2.

**[0032]**

It is obvious to a person skilled in the art that as the technology advances, the basic idea of the invention can be implemented in a plurality of ways. The invention and its embodiments are thus not restricted to the example described but may vary within the scope of the claims.

## Classifications

- B65G47/91
- B25J15/06
- B25J15/0616
- B65G2201/0282
- B65G47/91
- B66C/
- B66C1/02
- B66C1/0218
- B66C1/0256

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
