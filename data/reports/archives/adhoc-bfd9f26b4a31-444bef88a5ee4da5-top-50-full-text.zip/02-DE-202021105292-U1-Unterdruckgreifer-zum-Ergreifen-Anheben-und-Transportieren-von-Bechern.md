# 02. Unterdruckgreifer zum Ergreifen, Anheben und Transportieren von Bechern

- **Archive rank:** 2 of 50
- **Publication:** [DE-202021105292-U1](https://patents.google.com/patent/DE202021105292U1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/078280873/publication/DE202021105292U1?q=pn%3DDE202021105292U1)
- **Publication date:** 2021-10-08
- **Filing date:** 2021-09-30
- **Earliest priority:** 2021-09-30
- **Family:** 78280873
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** H & T MARSBERG GMBH & CO KG

## Abstract

Unterdruckgreifer (5) zum Ergreifen, Anheben und Transportieren von Bechern (1), insbesondere Metallbechern, die in Dosierinhalatoren oder zur Herstellung von Batterien verwendet werden,
 wobei der Unterdruckgreifer (5) wenigstens einen Abschnitt (7) aufweist, der sich in einer Längsrichtung (8) von einem in der Längsrichtung (8) gelegenen vorderen Ende (9) in Richtung nach hinten erstreckt und der dazu geeignet ist, mit dem vorderen Ende (9) voran durch eine Becheröffnung (3) in einen Becher (1) eingefahren zu werden, so dass ein an dem vorderen Ende (9) des Unterdruckgreifers (5) vorhandener Saugkörper (11) an dem inneren Boden (2) des Bechers (1) angreifen kann,
 wobei in dem Saugkörper (11) eine Ansaugöffnung (20) ausgebildet ist, die mit einer an dem Unterdruckgreifer vorgesehenen Unterdruckleitung (19) in Verbindung steht, wobei die Ansaugöffnung (20) über die Unterdruckleitung (19) aus einer Unterdruckquelle mit Unterdruck beaufschlagbar ist, so dass dann, wenn der Saugkörper (11) auf dem inneren Boden (2) des Bechers (1) anliegt, der Unterdruck über den Saugkörper (11) auf den inneren Boden (2) des Bechers (1) einwirkt,
 wobei zumindest im Bereich des vorderen Endes (9) des Unterdruckgreifers ein den Saugkörper (11) in einer Ebene quer zur Längsrichtung (8) umlaufendes Ringelement (12) angeordnet ist, das auf dem Unterdruckgreifer (5) in Längsrichtung (8) verschiebbar geführt ist und dessen in Längsrichtung (8) gelegenes stirnseitiges Ende (13) einen Anschlag (14) für den inneren Boden (2) des Bechers (1) ausbildet, 
 wobei der Unterdruckgreifer Rückstellmittel (16) umfasst und das Ringelement (12) entgegen der Rückstellkraft der Rückstellmittel (16) in Richtung nach hinten verschiebbar ist, wenn das Ringelement (12) mit dem inneren Boden (2) des Bechers (1) in Eingriff steht.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/91/9d/c4/6696ac14011b0c/DE202021105292U1_0001.png)

![Sketch 1 for DE-202021105292-U1](https://patentimages.storage.googleapis.com/91/9d/c4/6696ac14011b0c/DE202021105292U1_0001.png)

[Sketch 2](https://patentimages.storage.googleapis.com/c2/6b/e9/a98c5620eae39d/DE202021105292U1_0002.png)

![Sketch 2 for DE-202021105292-U1](https://patentimages.storage.googleapis.com/c2/6b/e9/a98c5620eae39d/DE202021105292U1_0002.png)

[Sketch 3](https://patentimages.storage.googleapis.com/7c/4b/46/b14a20cc50242a/DE202021105292U1_0003.png)

![Sketch 3 for DE-202021105292-U1](https://patentimages.storage.googleapis.com/7c/4b/46/b14a20cc50242a/DE202021105292U1_0003.png)

[Sketch 4](https://patentimages.storage.googleapis.com/c8/a8/87/624345bc6d82a4/DE202021105292U1_0004.png)

![Sketch 4 for DE-202021105292-U1](https://patentimages.storage.googleapis.com/c8/a8/87/624345bc6d82a4/DE202021105292U1_0004.png)

[Sketch 5](https://patentimages.storage.googleapis.com/d2/31/30/37f291dbc011d0/DE202021105292U1_0005.png)

![Sketch 5 for DE-202021105292-U1](https://patentimages.storage.googleapis.com/d2/31/30/37f291dbc011d0/DE202021105292U1_0005.png)

## Claims

### Claim 1 (independent)

Unterdruckgreifer (5) zum Ergreifen, Anheben und Transportieren von Bechern (1), insbesondere Metallbechern, die in Dosierinhalatoren oder zur Herstellung von Batterien verwendet werden, wobei der Unterdruckgreifer (5) wenigstens einen Abschnitt (7) aufweist, der sich in einer Längsrichtung (8) von einem in der Längsrichtung (8) gelegenen vorderen Ende (9) in Richtung nach hinten erstreckt und der dazu geeignet ist, mit dem vorderen Ende (9) voran durch eine Becheröffnung (3) in einen Becher (1) eingefahren zu werden, so dass ein an dem vorderen Ende (9) des Unterdruckgreifers (5) vorhandener Saugkörper (11) an dem inneren Boden (2) des Bechers (1) angreifen kann, wobei in dem Saugkörper (11) eine Ansaugöffnung (20) ausgebildet ist, die mit einer an dem Unterdruckgreifer vorgesehenen Unterdruckleitung (19) in Verbindung steht, wobei die Ansaugöffnung (20) über die Unterdruckleitung (19) aus einer Unterdruckquelle mit Unterdruck beaufschlagbar ist, so dass dann, wenn der Saugkörper (11) auf dem inneren Boden (2) des Bechers (1) anliegt, der Unterdruck über den Saugkörper (11) auf den inneren Boden (2) des Bechers (1) einwirkt, wobei zumindest im Bereich des vorderen Endes (9) des Unterdruckgreifers ein den Saugkörper (11) in einer Ebene quer zur Längsrichtung (8) umlaufendes Ringelement (12) angeordnet ist, das auf dem Unterdruckgreifer (5) in Längsrichtung (8) verschiebbar geführt ist und dessen in Längsrichtung (8) gelegenes stirnseitiges Ende (13) einen Anschlag (14) für den inneren Boden (2) des Bechers (1) ausbildet, wobei der Unterdruckgreifer Rückstellmittel (16) umfasst und das Ringelement (12) entgegen der Rückstellkraft der Rückstellmittel (16) in Richtung nach hinten verschiebbar ist, wenn das Ringelement (12) mit dem inneren Boden (2) des Bechers (1) in Eingriff steht.Vacuum gripper (5) for gripping, lifting and transporting cups (1), in particular metal cups that are used in metered dose inhalers or to manufacture batteries, wherein the vacuum gripper (5) has at least one section (7) which extends in a longitudinal direction (8) from a front end (9) located in the longitudinal direction (8) in the rearward direction and which is suitable for the front End (9) first to be inserted through a cup opening (3) into a cup (1), so that a suction body (11) present at the front end (9) of the vacuum gripper (5) on the inner bottom (2) of the cup (1) can attack, wherein a suction opening (20) is formed in the suction body (11) which is connected to a vacuum line (19) provided on the vacuum gripper, wherein the suction opening (20) can be acted upon by a vacuum source via the vacuum line (19), so that when the absorbent body (11) rests on the inner base (2) of the cup (1), the negative pressure acts on the inner base (2) of the cup (1) via the absorbent body (11), wherein at least in the area of the front end (9) of the vacuum gripper a ring element (12) running around the suction body (11) in a plane transverse to the longitudinal direction (8) is arranged, which is guided on the vacuum gripper (5) so as to be displaceable in the longitudinal direction (8) and its front end (13) located in the longitudinal direction (8) forms a stop (14) for the inner bottom (2) of the cup (1), wherein the vacuum gripper comprises resetting means (16) and the ring element (12) can be displaced towards the rear against the resetting force of the resetting means (16) when the ring element (12) is in engagement with the inner base (2) of the cup (1) .

### Claim 2

Unterdruckgreifer nach Anspruch 1, wobei das Ringelement (12) nach Art einer sich in Längsrichtung (8) entlang des Unterdruckgreifers (5) erstreckenden Hülse ausgebildet ist.Vacuum gripper after Claim 1 , wherein the ring element (12) is designed in the manner of a sleeve extending in the longitudinal direction (8) along the vacuum gripper (5).

### Claim 3

Unterdruckgreifer nach Anspruch 1 oder 2, wobei der Verschiebewege des Ringelements (12) begrenzt ist und das Ringelement (12) zwischen einer vorderen Endposition und einer hinteren Endposition längsverschiebbar ist und wobei sich das vordere Ende des Saugkörpers (11) in der vorderen Endposition des Ringelements (12) über das stirnseitige Ende des Ringelements (12) hinaus erstreckt.Vacuum gripper after Claim 1 or 2 , wherein the displacement path of the ring element (12) is limited and the ring element (12) is longitudinally displaceable between a front end position and a rear end position and the front end of the suction body (11) in the front end position of the ring element (12) over the front End of the ring element (12) also extends.

### Claim 4

Unterdruckgreifer nach einem der vorhergehenden Ansprüche, wobei das Ringelement (12) in einer Ebene quer zur Längsrichtung (8) derart dimensioniert ist, dass dann, wenn der Saugkörper (11) in dichtendem Kontakt mit dem inneren Boden (2) eines Bechers (1) steht und der Becher (1) mittels Unterdruck von dem Saugkörper (11) gehalten und der Becher um eine Achse quer zur Längsrichtung (8) gekippt wird, das Ringelement (12) einen Anschlag für die innere Seitenwand (4) des Bechers bereitstellt, der die Kippbewegung des Bechers (1) relativ zu dem Saugkörper (11) begrenzt und den dichtenden Kontakt zwischen Saugkörper (11) und Becherboden (2) sicherstellt.Vacuum gripper according to one of the preceding claims, wherein the ring element (12) is dimensioned in a plane transverse to the longitudinal direction (8) such that when the suction body (11) is in sealing contact with the inner base (2) of a cup (1) and the cup (1) is held by the suction body (11) by means of negative pressure and the cup is tilted about an axis transverse to the longitudinal direction (8), the ring element (12) provides a stop for the inner side wall (4) of the cup, which the tilting movement of the cup (1) relative to the absorbent body (11) is limited and the sealing contact between the absorbent body (11) and the cup base (2) is ensured.

### Claim 5

Unterdruckgreifer nach einem der vorhergehenden Ansprüche, wobei sich die Außenkontur des Ringelements (12) zum vorderen Ende hin verjüngt.Vacuum gripper according to one of the preceding claims, wherein the outer contour of the ring element (12) tapers towards the front end.

### Claim 6

Unterdruckgreifer nach einem der vorhergehenden Ansprüche, wobei die Rückstellmittel (16) ein oder mehr elastische Elemente, vorzugsweise eine oder mehrere Federn umfassen.Vacuum gripper according to one of the preceding claims, wherein the restoring means (16) comprise one or more elastic elements, preferably one or more springs.

### Claim 7

Unterdruckgreifer nach einem der vorhergehenden Ansprüche, wobei der Saugköper (11) zumindest teilweise elastisch verformbar ausgebildet.Vacuum gripper according to one of the preceding claims, wherein the suction body (11) is at least partially elastically deformable.

### Claim 8

Unterdruckgreifer nach einem der vorhergehenden Ansprüche, wobei der Saugkörper (11) einen insbesondere ringförmigen Dichtabschnitt oder eine insbesondere ringförmige Dichtlippe (22) zum Herstellen einer dichtenden Verbindung mit dem inneren Boden (2) des Bechers (1) umfasst.Vacuum gripper according to one of the preceding claims, wherein the suction body (11) comprises an in particular annular sealing section or an in particular annular sealing lip (22) for producing a sealing connection with the inner base (2) of the cup (1).

### Claim 9

Unterdruckgreifer nach einem der vorhergehenden Ansprüche, wobei der Saugkörper (11) nach Art einer Glocke ausgebildet ist, die einen Unterdruckraum (21) ausbildet, der mit der Ansaugöffnung (20) strömungsverbunden ist.Vacuum gripper according to one of the preceding claims, wherein the suction body (11) is designed in the manner of a bell which forms a vacuum space (21) which is flow-connected to the suction opening (20).

### Claim 10

Unterdruckgreifer nach einem der vorhergehenden Ansprüche, wobei der Unterdruckgreifer (5) einen rohrförmigen Körper (6) umfasst, durch den die Unterdruckleitung (19) in Längsrichtung (8) verläuft und an dessen einen Ende der Saugkörper (11) angeordnet ist.Vacuum gripper according to one of the preceding claims, wherein the vacuum gripper (5) comprises a tubular body (6) through which the vacuum line (19) runs in the longitudinal direction (8) and at one end of which the suction body (11) is arranged.

### Claim 11

Unterdruckgreifer nach Anspruch 10, wobei der rohrförmige Körper (6) an einem von dem Saugkörper (11) abgewandten Ende Mittel (18) zum insbesondere form- und/oder kraftschlüssigen Verbinden des rohrförmigen Körpers (6) mit einer Unterdruckquelle aufweist.Vacuum gripper after Claim 10 , wherein the tubular body (6) has at an end facing away from the absorbent body (11) means (18) for, in particular, a positive and / or non-positive connection of the tubular body (6) to a vacuum source.

### Claim 12

Unterdruckgreifer nach einem der Ansprüche 10 oder 11, wobei sich der rohrförmige Körper (6) zumindest teilweise durch die Rückstellmittel (16) erstreckt.Vacuum gripper according to one of the Claims 10 or 11th wherein the tubular body (6) extends at least partially through the restoring means (16).

### Claim 13

Unterdruckgreifer nach einem der Ansprüche 10 bis 12, wobei der rohrförmige Körper (6) einen Anschlag (17) zum Abstützen der Rückstellmittel (16) in Längsrichtung (8) trägt oder ausbildet.Vacuum gripper according to one of the Claims 10 until 12th , wherein the tubular body (6) carries or forms a stop (17) for supporting the restoring means (16) in the longitudinal direction (8).

### Claim 14

Unterdruckgreifer nach Anspruch 13, wobei der Anschlag (17) zum Abstützen der Rückstellmittel (16) in Bezug auf die Innenwand des Bechers (1) derart positioniert und dimensioniert ist, dass der Anschlag (17) zum Abstützen der Rückstellmittel (16) Kippbewegungen des Bechers (1) um eine Achse quer zur Längsrichtung (8) begrenzt und den dichtenden Kontakt zwischen Saugkörper (11) und Becherboden (2) sicherstellt.Vacuum gripper after Claim 13 , wherein the stop (17) for supporting the restoring means (16) in relation to the inner wall of the cup (1) is positioned and dimensioned such that the stop (17) for supporting the restoring means (16) tilting movements of the cup (1) an axis is limited transversely to the longitudinal direction (8) and ensures the sealing contact between the absorbent body (11) and the cup base (2).

### Claim 15

Transporteinheit zum Greifen, Anheben und Transportieren von Bechern (1), insbesondere Metallbechern, die in Dosierinhalatoren oder zur Herstellung von Batterien verwendet werden, umfassend ein oder mehrere Unterdruckgreifer (5) nach einem der vorhergehenden Ansprüche.Transport unit for gripping, lifting and transporting cups (1), in particular metal cups, which are used in metered dose inhalers or for the production of batteries, comprising one or more vacuum grippers (5) according to one of the preceding claims.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippers

Description

Translated from German

TECHNISCHES GEBIETTECHNICAL AREA

Die Erfindung betrifft einen Unterdruckgreifer zum Ergreifen, Anheben und Transportieren von Bechern, insbesondere Metallbechern, die in Dosierinhalatoren oder zur Herstellung von Batterien verwendet werden.The invention relates to a vacuum gripper for gripping, lifting and transporting cups, in particular metal cups, which are used in metered dose inhalers or for the production of batteries.

HINTERGRUND DER ERFINDUNGBACKGROUND OF THE INVENTION

Bei der Herstellung von metallischen, becherfÃ¶rmigen Produkten werden in vielen Bereichen hohe QualitÃ¤tsanforderungen gestellt, insbesondere in der Batterieproduktion oder im medizinischen Bereich. Bei der Produktion von Batteriebechern, die die metallische Ã¤uÃere HÃ¼lle einer Batterie stellen, sind z. B. eine hohe OberflÃ¤chenqualitÃ¤t und MaÃeinhaltung gefordert. Nur Batteriebecher, die nach der Produktion die vorgegebenen MaÃe aufweisen, gewÃ¤hrleisten die technische FunktionalitÃ¤t und Sicherheit des Endprodukts Batterie. Die medizinische Industrie hat Ã¤hnliche Anforderungen. Becher, die z. B. zu Kartuschen fÃ¼r Dosierinhalatoren weiterverarbeitet werden, mÃ¼ssen hohe QualitÃ¤tsanforderungen erfÃ¼llen, um die FunktionalitÃ¤t und QualitÃ¤t des Medizinprodukts zu gewÃ¤hrleisten.In the manufacture of metallic, cup-shaped products, high quality requirements are made in many areas, especially in battery production or in the medical field. In the production of battery cans that represent the metallic outer shell of a battery, z. B. a high surface quality and dimensional compliance is required. Only battery cans that have the specified dimensions after production guarantee the technical functionality and safety of the end product battery. The medical industry has similar needs. Mug, the z. B. to be processed into cartridges for metered dose inhalers must meet high quality requirements in order to guarantee the functionality and quality of the medical device.

Die Herstellung derartiger Becher, z. B. fÃ¼r die Batterieproduktion, erfolgt hÃ¤ufig im Batch- und Queue-Verfahren in einer Produktionslinie mit mindestens einer Tiefziehstation zur Bildung eines tiefgezogenen Bechers. Das Tiefziehen erfolgt unter Verwendung mindestens eines Stempels mit vorstehenden FormflÃ¤chen und mit Einrichtungen, die das Blechmaterial Ã¼ber den Stempel spannen, wÃ¤hrend dieser quer zum Material bewegt wird. The manufacture of such cups, e.g. B. for battery production, often takes place in batch and queue processes in a production line with at least one deep-drawing station to form a deep-drawn cup. The deep drawing is carried out using at least one punch with protruding molding surfaces and with devices that stretch the sheet metal material over the punch while it is moved across the material.

Die Presskraft drÃ¼ckt den Stempel auf den spÃ¤teren Boden des zu fertigenden Tiefziehteiles. Durch die fortlaufende Bewegung des Stempels wird der Blechzuschnitt durch in eine Matrize gedrÃ¼ckt. Ein typisches Tiefziehverfahren ist z. B. im US-Patent 2 989 019 beschrieben, das hiermit durch Verweis einbezogen wird.The pressing force presses the punch onto the later base of the deep-drawn part to be manufactured. The continuous movement of the punch presses the sheet metal blank through into a die. A typical deep drawing process is e.g. B. in U.S. Patent 2,989,019 which is hereby incorporated by reference.

Wie in der Industrienorm DIN 8584 definiert ist, ist das Tiefziehen ein Umformverfahren, das unter einer Kombination von Zug- und Druckbedingungen stattfindet. WÃ¤hrend des Tiefziehens ist der Werkstoff hohen Spannungsbelastungen ausgesetzt. Charakteristisch fÃ¼r das Tiefziehen ist der hohe Druck in der GrÃ¶Ãenordnung von 100.000 Pound pro Quadratzoll (psi), der bei diesem Vorgang auftritt. Um diese Kraft zu bewÃ¤ltigen und eine Verformung der Stempel und Matrizen zu vermeiden, wird ein Schmiermittel verwendet. Unter diesem Druck sollte das Ziehschmiermittel die Matrize und den Artikel kÃ¼hlen, fÃ¼r eine Grenzschmierung zwischen Matrize und Artikel sorgen, Metallan-Metall-Haftung oder VerschweiÃen verhindern und die Matrize wÃ¤hrend des Ziehvorgangs dÃ¤mpfen.As defined in the industry standard DIN 8584, deep drawing is a forming process that takes place under a combination of tensile and pressure conditions. During deep drawing, the material is exposed to high stress loads. Characteristic of deep drawing is the high pressure, on the order of 100,000 pounds per square inch (psi), that occurs in the process. A lubricant is used to manage this force and avoid deformation of the punches and dies. Under this pressure, the drawing lubricant should cool the die and the article, provide boundary lubrication between die and article, prevent metal-to-metal adhesion or welding, and dampen the die during the drawing process.

In einem weiteren Schritt werden die Formteile in einen Wasch- und Trockenbereich gebracht, um das Schmiermittel zu entfernen. Nach dem oben genannten Produktionsschritt werden die Formteile hÃ¤ufig auf geforderte QualitÃ¤tsstandards geprÃ¼ft. Genauigkeit und eine hohe MaterialqualitÃ¤t werden fÃ¼r die Sicherheit insbesondere von Lithium-Ionen-Batterien (Li-Ion) immer wichtiger. Obwohl sich die Entwicklungsstandards fÃ¼r Li-Ionen-Batterien in den letzten Jahren stetig verbessert haben, werden UnfÃ¤lle wie Explosionen und BrÃ¤nde immer noch durch unkontrollierte Freisetzung der chemisch gespeicherten Energie der Batterie verursacht, z. B. durch mechanische BeschÃ¤digungen und Materialfehler. Daher ist es wichtig, dass die Batteriedose hohen DrÃ¼cken standhÃ¤lt, ohne im Falle einer Fehlfunktion der Batterie zu bersten.In a further step, the molded parts are brought into a washing and drying area in order to remove the lubricant. After the production step mentioned above, the molded parts are often checked for the required quality standards. Precision and high material quality are becoming more and more important for the safety of lithium-ion batteries (Li-ion) in particular. Although the development standards for Li-ion batteries have steadily improved in recent years, accidents such as explosions and fires are still caused by the uncontrolled release of the battery's chemically stored energy, e.g. B. by mechanical damage and material defects. It is therefore important that the battery jar can withstand high pressures without bursting in the event of a battery malfunction.

Bei Produktion von Batteriebechern werden die becherfÃ¶rmigen WerkstÃ¼cke durch mehrere Stationen von Produktions- und QualitÃ¤tskontrolllinien transportiert. In der Regel werden dazu Transportgestelle oder Transportpaletten verwendet, die eine Vielzahl von Bechern aufnehmen. In manchen FÃ¤llen ist es erforderlich, die einzelnen Becher ihrem Transportgestell zu entnehmen, beispielsweise um bestimmte Abschnitte des Bechers Verarbeitungs- oder Veredelungseinheiten zuzufÃ¼hren, um visuelle Kontrollen bestimmter OberflÃ¤chenbereiche zu ermÃ¶glichen oder um die Becher in andere Transportgestelle umzuladen. Oftmals erfolgt in hochproduktiven Produktionslinien auch eine Vereinzelung der Becher, beispielsweise zum Zwecke der Aussortierung, Sortierung, Reinigung oder zum Zwecke einer Lagerung.When producing battery cans, the cup-shaped workpieces are transported through several stations on production and quality control lines. As a rule, transport racks or transport pallets that hold a large number of cups are used for this purpose. In some cases it is necessary to remove the individual cups from their transport frame, for example in order to supply certain sections of the cup to processing or finishing units, to enable visual checks of certain surface areas or to reload the cups into other transport frames. Often the cups are also separated in highly productive production lines, for example for the purpose of sorting out, sorting, cleaning or for the purpose of storage.

Der Einsatz von Saug- bzw. Unterdruckgreifern in der industriellen Produktion ist allgemein bekannt. Ein Vorteil dieser Systeme besteht darin, dass gerade WerkstÃ¼cke mit empfindlichen OberflÃ¤chen besonders schonend erfolgen kann. Unterdruckgreifer besitzen eine Saugeinheit oder einen SaugkÃ¶rper, der mit einer WerkstÃ¼ckoberflÃ¤che in BerÃ¼hrung gebracht wird. Dichtende Mittel des SaugkÃ¶rpers dichten einen Unterdruckraum zwischen der WerkstÃ¼ckoberflÃ¤che und dem SaugkÃ¶rper ab, so dass bei der Erzeugung eines Unterdrucks zwischen dem SaugkÃ¶rper und der WerkstÃ¼ckoberflÃ¤che der Ã¤uÃere Luftdruck das WerkstÃ¼ck an den SaugkÃ¶rper presst. Mittels der Ansaugkraft kann das WerkstÃ¼ck dann am Unterdruckgreifer gehalten und transportiert werden. Befinden sich ein oder mehrere Unterdruckgreifer an entsprechenden Manipulatoren, wie beispielsweise Roboterarmen, so kÃ¶nnen ein oder mehrere der angesaugten WerkstÃ¼cke transportiert und neu positioniert werden.The use of suction or vacuum grippers in industrial production is well known. One advantage of these systems is that workpieces with sensitive surfaces can be carried out particularly gently. Vacuum grippers have a suction unit or a suction body that is brought into contact with a workpiece surface. Sealing means of the absorbent body seal a vacuum space between the workpiece surface and the absorbent body, so that when a vacuum is generated between the absorbent body and the workpiece surface, the external air pressure presses the workpiece against the absorbent body. By means of the suction force, the workpiece can then be held on the vacuum gripper and transported. If there are one or more vacuum grippers on corresponding manipulators, such as robot arms, one or more of the sucked-in workpieces can be transported and repositioned.

WÃ¤hrend fÃ¼r flÃ¤chige WerkstÃ¼cke bereits effiziente Unterdruckgreifsysteme zur VerfÃ¼gung stehen, gibt es fÃ¼r den Transport von becherfÃ¶rmigen WerkstÃ¼cken, wie insbesondere Batteriebechern, noch keine zufriedenstellende LÃ¶sung. Dies ist insbesondere dann der Fall, wenn der Becher auf eine bestimmte Art und Weise angehoben und transportiert werden muss, beispielsweise derart, dass seine Ã¤uÃere OberflÃ¤che, also die Ã¤uÃere MantelflÃ¤che und die Ã¤uÃere OberflÃ¤che des Bodens, frei bzw. nicht bedeckt ist, beispielsweise zum Zwecke einer visuellen Inspektion oder zum Zwecke einer OberflÃ¤chenveredelung. Hierbei hat man im wesentliche auf mechanische Greifsysteme zurÃ¼ckgreifen mÃ¼ssen, die sich z.B. an der Innenwand des Bechers festklemmen, aber dem Ziel eines schonenden und sicheren Transports der Becher entgegenstehen.While efficient vacuum gripping systems are already available for flat workpieces, there is still no satisfactory solution for the transport of cup-shaped workpieces, such as battery cans in particular. This is particularly the case when the cup has to be lifted and transported in a certain way, for example in such a way that its outer surface, i.e. the outer jacket surface and the outer surface of the base, is free or not covered, for example for Purposes of a visual inspection or for the purpose of a surface refinement. In this case, one essentially had to resort to mechanical gripping systems which, for example, clamp onto the inner wall of the cup, but which stand in the way of gentle and safe transport of the cups.

Es ist daher Aufgabe der vorliegenden Erfindung, einen Unterdruckgreifer vorzuschlagen, der ein effektives und schonendes Ergreifen, Anheben und Transportieren von Bechern, insbesondere Metallbechern, die in Dosierinhalatoren oder zur Herstellung von Batterien verwendet werden, ermÃ¶glicht.It is therefore the object of the present invention to propose a vacuum gripper which enables an effective and gentle gripping, lifting and transporting of cups, in particular metal cups, which are used in metered dose inhalers or for the production of batteries.

ZUSAMMENFASSUNG DER ERFINDUNGSUMMARY OF THE INVENTION

Die der Erfindung zugrundeliegende Aufgabe wird durch einen Unterdruckgreifer mit den Merkmalen des Anspruchs 1 gelÃ¶st. Weitere und bevorzugte AusfÃ¼hrungsformen der Erfindung sind in der nachfolgenden Beschreibung und in den abhÃ¤ngigen AnsprÃ¼chen offenbart.The object on which the invention is based is achieved by a vacuum gripper with the features of claim 1. Further and preferred embodiments of the invention are disclosed in the following description and in the dependent claims.

Der erfindungsgemÃ¤Ãe Unterdruckgreifer weist zumindest einen Abschnitt auf, der sich in einer LÃ¤ngsrichtung von einem in der LÃ¤ngsrichtung gelegenen vorderen Ende in Richtung nach hinten erstreckt, also entlang einer LÃ¤ngsachse des Abschnitts in LÃ¤ngsrichtung weg von dem vorderen Ende, und der dazu geeignet ist, mit dem vorderen Ende voran durch eine BecherÃ¶ffnung in einen Becher eingefahren zu werden, so dass ein an dem vorderen Ende des Unterdruckgreifers vorhandener SaugkÃ¶rper an dem inneren Boden des Bechers angreifen kann, um diesen mittels Unterdruck anzusaugen und zu halten. In dem SaugkÃ¶rper ist eine AnsaugÃ¶ffnung ausgebildet ist, die mit einer Unterdruckleitung in Verbindung steht, die sich beispielsweise zumindest durch den sich in LÃ¤ngsrichtung erstreckenden Abschnitt erstrecken kann, wobei die AnsaugÃ¶ffnung Ã¼ber die Unterdruckleitung aus einer Unterdruckquelle, z.B. einer Vakuumpumpe oder einer weiteren Unterdruckleitung, an die die Unterdruckleitung des Unterdruckgreifers angeschlossen ist, mit Unterdruck beaufschlagbar ist, so dass dann, wenn der SaugkÃ¶rper auf dem inneren Boden des Bechers anliegt, der Unterdruck Ã¼ber den SaugkÃ¶rper auf den inneren Boden des Bechers einwirkt, und der Becher mittels Unterdruck angehoben und gehalten werden kann. Zumindest im Bereich des vorderen Endes des Unterdruckgreifers ist ein den SaugkÃ¶rper in einer Ebene quer zur LÃ¤ngsrichtung umlaufendes Ringelement angeordnet, das auf dem Unterdruckgreifer in LÃ¤ngsrichtung verschiebbar gefÃ¼hrt ist und dessen in LÃ¤ngsrichtung gelegenes stirnseitiges Ende, also das vordere Ende, einen Anschlag fÃ¼r den inneren Boden des Bechers ausbildet, wobei der Unterdruckgreifer RÃ¼ckstellmittel umfasst und das Ringelement entgegen der RÃ¼ckstellkraft der RÃ¼ckstellmittel in Richtung nach hinten verschiebbar ist, wenn das Ringelement an dem inneren Boden des Bechers anschlÃ¤gt bzw. mit diesem in Eingriff steht.The vacuum gripper according to the invention has at least one section which extends in a longitudinal direction from a front end located in the longitudinal direction towards the rear, that is, along a longitudinal axis of the section in the longitudinal direction away from the front end, and which is suitable for the front end to be moved through a cup opening into a cup so that a suction body present at the front end of the vacuum gripper can grip the inner bottom of the cup in order to suck and hold it by means of vacuum. A suction opening is formed in the suction body, which is connected to a vacuum line which can extend, for example, at least through the section extending in the longitudinal direction, the suction opening being connected via the vacuum line from a vacuum source, e.g. a vacuum pump or a further vacuum line which is connected to the vacuum line of the vacuum gripper, can be acted upon with negative pressure, so that when the suction body rests on the inner bottom of the cup, the negative pressure acts on the inner bottom of the cup via the suction body, and the cup is lifted and held by means of negative pressure can. At least in the area of the front end of the vacuum gripper, a ring element running around the suction body in a plane transverse to the longitudinal direction is arranged, which is guided on the vacuum gripper so that it can be displaced in the longitudinal direction and whose front end located in the longitudinal direction, i.e. the front end, has a stop for the inner base of the cup, the vacuum gripper comprising resetting means and the ring element being displaceable towards the rear against the resetting force of the resetting means when the ring element strikes the inner bottom of the cup or is in engagement with it.

Durch das in axialer Richtung bzw. in LÃ¤ngsrichtung relativ zu dem Unterdruckgreifer verschiebbare Ringelement wird ein besonders schonender aber stabiler Transport des Bechers sichergestellt. Das Ringelement stabilisiert die relative Position zwischen Becher und Unterdruckgreifer indem es eine gegen den Becher vorgespannte AuflageflÃ¤che fÃ¼r den inneren Boden des Bechers bereitstellt, wÃ¤hrend der SaugkÃ¶rper mittels Unterdruck den inneren Boden des Bechers hÃ¤lt. Der Becher wird zudem am Verkippen um eine Achse quer zur LÃ¤ngsrichtung gehindert, wodurch der SaugkÃ¶rper von der OberflÃ¤che des inneren Becherboden weggerissen werden kÃ¶nnte. Gleichzeitig erlaubt das Ringelement in definierten Grenzen relative Axialbewegungen zwischen Becher und Saugeinheit, wodurch sich Abweichungen kompensieren lassen, wie beispielweise Verformungen des SaugkÃ¶rpers in Folge des Unterdrucks oder Verformungen der Dichtmittel der Saugeinheit. Die RÃ¼ckstellmittel stellen dabei nicht nur eine fÃ¼r die Stabilisierung notwendige AbstÃ¼tzkraft zur VerfÃ¼gung, sie unterstÃ¼tzen auch das LÃ¶sen des Bechers von dem Unterdruckgreifer, wenn der Unterdruck bewusst abgestellt wird, um den Becher abzustellen. AuÃerdem kÃ¶nnen dadurch, dass das Ringelement in LÃ¤ngsrichtung verschiebbar ist, also keine starre Position an dem Unterdruckgreifer aufweist, Fehlpositionierungen des Bechers in LÃ¤ngsrichtung kompensiert werden. Die Verschiebbarkeit des Ringelements verhindert beispielsweise, dass das Ringelement beim Einfahren in einen Becher, der aufgrund produktionsbedingter UnregelmÃ¤Ãigkeiten zu nah an dem Unterdruckgreifer positioniert ist, die Einfuhrbewegung des Unterdruckgreifers auf den Becherboden Ã¼bertrÃ¤gt und diesen beschÃ¤digt.The ring element, which can be displaced in the axial direction or in the longitudinal direction relative to the vacuum gripper, ensures particularly gentle but stable transport of the cup. The ring element stabilizes the relative position between the cup and the vacuum gripper by providing a bearing surface for the inner base of the cup that is pretensioned against the cup, while the suction body holds the inner base of the cup by means of negative pressure. The cup is also prevented from tilting about an axis transverse to the longitudinal direction, as a result of which the absorbent body could be torn away from the surface of the inner cup base. At the same time, the ring element allows relative axial movements between the cup and suction unit within defined limits, whereby deviations can be compensated, such as deformations of the suction body as a result of the negative pressure or deformations of the sealing means of the suction unit. The restoring means not only provide a supporting force necessary for the stabilization, they also support the detachment of the cup from the vacuum gripper when the vacuum is deliberately turned off in order to put the cup down. In addition, because the ring element is displaceable in the longitudinal direction, that is to say does not have a rigid position on the vacuum gripper, incorrect positioning of the cup in the longitudinal direction can be compensated for. The displaceability of the ring element prevents, for example, that the ring element, when moving into a cup that is positioned too close to the vacuum gripper due to production-related irregularities, transfers the insertion movement of the vacuum gripper to the cup base and damages it.

Ein weiterer Vorteil, der daraus resultiert, dass das Ringelement in LÃ¤ngsrichtung relativ zu dem Unterdruckgreifer verschiebbar ist, besteht in einer vereinfachten Wartung des Unterdruckgreifers. So kann beispielsweise zum Zwecke des Austauschens des SaugkÃ¶rpers das den SaugkÃ¶rper umlaufende Ringelement verschoben werden, um den SaugkÃ¶rper zumindest teilweise freizulegen. Dies ermÃ¶glicht einen einfacheren Zugang zu dem SaugkÃ¶rper.Another advantage that results from the fact that the ring element can be displaced in the longitudinal direction relative to the vacuum gripper consists in simplified maintenance of the vacuum gripper. For example, for the purpose of replacing the absorbent body, the ring element surrounding the absorbent body can be displaced in order to at least partially expose the absorbent body. This enables easier access to the absorbent body.

Becher kennzeichnen im Allgemeinen einen BehÃ¤lter mit einer umlaufenden Seitenwand, die sich von einem Becherboden bis zu einer BecherÃ¶ffnung erstreckt, welche in Bezug auf den Becherboden am gegenÃ¼berliegenden Ende des Bechers angeordnet ist. Die Seitenwand kann zylindrisch, also nach Art einer HÃ¼lse geformt sein. Es ist jedoch mit dem erfindungsgemÃ¤Ãen Unterdruckgreifer auch mÃ¶glich, Becher zu transportieren, deren Seitenwand sich zum Becherboden hin oder zu BecherbecherÃ¶ffnung verjÃ¼ngt.Cups generally characterize a container with a circumferential side wall which extends from a cup base to a cup opening which is arranged at the opposite end of the cup with respect to the cup base. The side wall can be cylindrical, that is, shaped like a sleeve. However, with the vacuum gripper according to the invention it is also possible to transport cups whose side wall tapers towards the cup base or towards the cup opening.

Die RÃ¼ckstellmittel kÃ¶nnen insbesondere elastische Elemente umfassen, wie beispielsweise Federn, insbesondere Schraubenfedern, Gummielemente oder Elastomere. Durch Verformung infolge der Axialbewegung des Ringelements nach hinten werden solche RÃ¼ckstellmittel gespannt, d.h. sie Ã¼ben eine Gegenkraft auf das Ringelement aus, die nach vorne wirkt.The restoring means can in particular comprise elastic elements such as springs, in particular helical springs, rubber elements or elastomers. Such return means are tensioned by deformation as a result of the axial movement of the ring element to the rear, i.e. they exert a counterforce on the ring element which acts forwards.

Die Dimensionen des erfindungsgemÃ¤Ãen Unterdruckgreifers, insbesondere des Ringelements, kÃ¶nnen fÃ¼r den Einsatzfall an die zu transportierende BechergrÃ¶Ãe ohne weiteres konstruktiv angepasst werdenThe dimensions of the vacuum gripper according to the invention, in particular of the ring element, can easily be structurally adapted for the application to the size of the cup to be transported

GemÃ¤Ã einer weiteren AusfÃ¼hrungsform der Erfindung ist das Ringelement nach Art einer sich in LÃ¤ngsrichtung entlang des Unterdruckgreifers erstreckenden HÃ¼lse ausgebildet.According to a further embodiment of the invention, the ring element is designed in the manner of a sleeve extending in the longitudinal direction along the vacuum gripper.

GemÃ¤Ã einer weiteren AusfÃ¼hrungsform der Erfindung ist der Verschiebeweg des Ringelements begrenzt und das Ringelement ist lediglich zwischen zwei Endpositionen lÃ¤ngsverschiebbar auf dem Unterdruckgreifer gefÃ¼hrt. Die erste Endposition ist eine vordere Position des Ringelements, d.h. das Ringelement befindet sich am vorderen Ende des Unterdruckgreifers. Die zweite Endposition ist eine hintere Position, d.h. das Ringelement befindet weiter weg vom vorderen Ende des Unterdruckgreifers als in der ersten Endposition. Die erste Endposition kann so gewÃ¤hlt sein, dass sich die RÃ¼ckstellmittel in der ersten Endposition des Ringelements in einem entspannten Zustand befinden. Bei dieser AusfÃ¼hrungsform ist ferner vorgesehen, dass sich das vordere Ende des SaugkÃ¶rpers in der ersten Endposition des Ringelements Ã¼ber das stirnseitige Ende des Ringelements hinaus erstreckt. Dadurch ist sichergestellt, dass beim Einfahren des vorderen Endes des Unterdruckgreifers zunÃ¤chst der SaugkÃ¶rper mit der WerkstÃ¼ckoberflÃ¤che in Kontakt treten kann und das Ringelement erst anschlieÃend, z.B. beim anschlieÃenden Ansaugen, mit dem inneren Boden des Bechers in Eingriff tritt.According to a further embodiment of the invention, the displacement path of the ring element is limited and the ring element is only guided on the vacuum gripper so as to be longitudinally displaceable between two end positions. The first end position is a front position of the ring element, i.e. the ring element is at the front end of the vacuum gripper. The second end position is a rear position, i.e. the ring element is further away from the front end of the vacuum gripper than in the first end position. The first end position can be selected such that the restoring means are in a relaxed state in the first end position of the ring element. In this embodiment it is further provided that the front end of the absorbent body extends in the first end position of the ring element beyond the front end of the ring element. This ensures that when the front end of the vacuum gripper is retracted, the suction body can first come into contact with the workpiece surface and the ring element only then comes into engagement with the inner bottom of the cup, e.g. during subsequent suction.

GemÃ¤Ã einer weiteren AusfÃ¼hrungsform der Erfindung ist das Ringelement in einer Ebene quer zur LÃ¤ngsrichtung, also in Richtung der Innenwand des Bechers, derart dimensioniert, dass dann, wenn der SaugkÃ¶rper in dichtendem Kontakt mit dem inneren Boden eines Bechers steht und der Becher mittels Unterdruck von dem SaugkÃ¶rper gehalten und der Becher um eine Achse quer zur LÃ¤ngsrichtung gekippt wird, das Ringelement einen Anschlag fÃ¼r die Innenwand bzw. die innere Seitenwand des Bechers bereitstellt, der die Kippbewegung des Bechers relativ zu dem SaugkÃ¶rper begrenzt und den dichtenden Kontakt zwischen SaugkÃ¶rper und Becherboden sicherstellt. Die Sicherstellung des Unterdruckzustands wird bei dieser AusfÃ¼hrungsform also durch einen zusÃ¤tzlich, in seitlicher Richtung wirkenden Stabilisator unterstÃ¼tzt.According to a further embodiment of the invention, the ring element is dimensioned in a plane transverse to the longitudinal direction, i.e. in the direction of the inner wall of the cup, so that when the absorbent body is in sealing contact with the inner bottom of a cup and the cup is removed from the cup by means of negative pressure The absorbent body is held and the cup is tilted about an axis transverse to the longitudinal direction, the ring element provides a stop for the inner wall or the inner side wall of the cup, which limits the tilting movement of the cup relative to the absorbent body and ensures the sealing contact between the absorbent body and the cup base. In this embodiment, the safeguarding of the negative pressure state is thus supported by an additional stabilizer acting in the lateral direction.

GemÃ¤Ã einer weiteren AusfÃ¼hrungsform der Erfindung verjÃ¼ngt sich die AuÃenkontur des Ringelements zumindest in einem Bereich zum vorderen Ende hin. In einer Seitenansicht auf den Unterdruckgreifer weist bei dieser AusfÃ¼hrungsform die nach vorne gerichtete Stirnseite des Ringelements zumindest einen Abschnitt auf, dessen AuÃendurchmesser in Richtung nach vorne abnimmt, z.B. schrÃ¤g in Richtung LÃ¤ngsachse verlÃ¤uft und eine Konusform annimmt. Eine solche VerjÃ¼ngung am vorderen Ende kann das EinfÃ¼hren des Unterdruckgreifers in die Ãffnung des Bechers maÃgeblich erleichtern. Zudem kann die VerjÃ¼ngung als Zentrierhilfe dienen und den Becher beim EinfÃ¼hren des Ringelements relativ zu dem Ringelement ausrichten.According to a further embodiment of the invention, the outer contour of the ring element tapers at least in one area towards the front end. In a side view of the vacuum gripper in this embodiment, the front face of the ring element facing forward has at least one section, the outer diameter of which decreases in the forward direction, e.g. runs obliquely in the direction of the longitudinal axis and assumes a conical shape. Such a taper at the front end can significantly facilitate the introduction of the vacuum gripper into the opening of the cup. In addition, the taper can serve as a centering aid and align the cup relative to the ring element when the ring element is inserted.

GemÃ¤Ã einer weiteren AusfÃ¼hrungsform der Erfindung umfassen die RÃ¼ckstellmittel ein oder mehr elastische Elemente, vorzugsweise in Form einer oder mehrerer Federn.According to a further embodiment of the invention, the restoring means comprise one or more elastic elements, preferably in the form of one or more springs.

GemÃ¤Ã einer weiteren AusfÃ¼hrungsform der Erfindung ist der SaugkÃ¶per zumindest teilweise elastisch verformbar ausgebildet. Der SaugkÃ¶rper kann beispielsweise vollstÃ¤ndig aus Silikon oder einem anderen elastischen Stoff gebildet sein. Es ist aber auch mÃ¶glich, dass der SaugkÃ¶rper elastische und nichtelastische Abschnitte aufweist, wobei die elastischen Abschnitte derart angeordnet sind, dass sie mit der OberflÃ¤che des inneren Bodens des Bechers in Kontakt treten kÃ¶nnen, um eine dichtende Verbindung zwischen der OberflÃ¤che des inneren Bodens des Bechers und dem SaugkÃ¶rper sicherzustellen. Nach einer weiteren AusfÃ¼hrungsform der Erfindung umfasst der SaugkÃ¶rper einen insbesondere ringfÃ¶rmigen Dichtabschnitt oder eine insbesondere ringfÃ¶rmige Dichtlippe zur Herstellen einer dichtenden Verbindung mit dem inneren Boden des Bechers.According to a further embodiment of the invention, the suction body is designed to be at least partially elastically deformable. The absorbent body can, for example, be formed entirely from silicone or another elastic material. However, it is also possible for the absorbent body to have elastic and non-elastic sections, the elastic sections being arranged in such a way that they can come into contact with the surface of the inner bottom of the cup in order to create a sealing connection between the surface of the inner bottom of the cup and ensure the absorbent body. According to a further embodiment of the invention, the absorbent body comprises an in particular annular sealing section or an in particular annular sealing lip for producing a sealing connection with the inner base of the cup.

GemÃ¤Ã einer weiteren AusfÃ¼hrungsform der Erfindung ist der SaugkÃ¶rper nach Art einer Glocke ausgebildet, die einen Unterdruckraum ausbildet, der mit der AnsaugÃ¶ffnung strÃ¶mungsverbunden ist. Die Glocke ist in einer besonders bevorzugten AusfÃ¼hrungsform ein elastisch verformbarer KÃ¶rper mit einer AnsaugÃ¶ffnung, die von einem umlaufenden Kragen umgeben ist, der gegenÃ¼ber der AnsaugÃ¶ffnung verbreitert ist und eine Dichtlippe bereitstellt.According to a further embodiment of the invention, the suction body is designed in the manner of a bell, which forms a negative pressure space which is flow-connected to the suction opening. In a particularly preferred embodiment, the bell is an elastically deformable body with a Suction opening, which is surrounded by a circumferential collar, which is widened in relation to the suction opening and provides a sealing lip.

GemÃ¤Ã einer weiteren AusfÃ¼hrungsform der Erfindung umfasst der Unterdruckgreifer einen rohrfÃ¶rmigen KÃ¶rper, durch den die Unterdruckleitung in LÃ¤ngsrichtung verlÃ¤uft und an dessen einen Ende der SaugkÃ¶rper angeordnet ist. Die Unterdruckleitung kann besondere durch einen Rohrdurchgang gebildet sind.According to a further embodiment of the invention, the vacuum gripper comprises a tubular body through which the vacuum line runs in the longitudinal direction and at one end of which the suction body is arranged. The vacuum line can in particular be formed by a pipe passage.

GemÃ¤Ã einer weiteren AusfÃ¼hrungsform der Erfindung weist der rohrfÃ¶rmige KÃ¶rper an einem von dem SaugkÃ¶rper abgewandten Ende Mittel zum insbesondere form- und/oder kraftschlÃ¼ssigen Verbinden des rohrfÃ¶rmigen KÃ¶rpers mit einer Unterdruckquelle auf. Als Verbindungsmittel kÃ¶nnen insbesondere Mittel zum Herstellen einer Schraubverbindung, wie beispielsweise ein AuÃengewindeabschnitt, vorgesehen sein, die mit passend gestalteten Verbindungsmitteln der Unterdruckquelle, z.B. in Form eines Innengewindeabschnitts, zusammenwirken kÃ¶nnen. Andere Verbindungsmittel, wie beispielsweise Rast oder Klemmmittel, sind ebenfalls mÃ¶glich. Als Unterdruckquelle kommen wie oben erwÃ¤hnt, z.B. Vakuumpumpen oder einer weitere Unterdruckleitung in Betracht.According to a further embodiment of the invention, the tubular body has, at an end facing away from the absorbent body, means for, in particular, a form-fitting and / or force-fitting connection of the tubular body to a vacuum source. In particular, means for producing a screw connection, such as an externally threaded section, can be provided as the connecting means, which can interact with suitably designed connecting means of the vacuum source, e.g. in the form of an internally threaded section. Other connecting means, such as latching or clamping means, are also possible. As mentioned above, vacuum pumps or another vacuum line can be used as a vacuum source.

GemÃ¤Ã einer weiteren AusfÃ¼hrungsform der Erfindung erstreckt sich der rohrfÃ¶rmige KÃ¶rper zumindest teilweise durch die RÃ¼ckstellmittel, was eine kompakte Bauweise ermÃ¶glicht. Die RÃ¼ckstellmittel kÃ¶nnen insbesondere in Form einer Schraubenfeder vorliegen, die auf dem rohrfÃ¶rmigen KÃ¶rper angeordnet ist.According to a further embodiment of the invention, the tubular body extends at least partially through the restoring means, which enables a compact design. The restoring means can in particular be in the form of a helical spring which is arranged on the tubular body.

GemÃ¤Ã einer weiteren AusfÃ¼hrungsform der Erfindung trÃ¤gt der rohrfÃ¶rmige KÃ¶rper einen Anschlag zum AbstÃ¼tzen der RÃ¼ckstellmittel in LÃ¤ngsrichtung oder bildet einen solchen aus. Nach einer weiteren AusfÃ¼hrungsform der Erfindung ist der Anschlag in Bezug auf die Innenwand des Bechers derart positioniert und dimensioniert, dass der Anschlag Kippbewegungen des Bechers um eine Achse quer zur LÃ¤ngsrichtung begrenzt und den dichtenden Kontakt zwischen SaugkÃ¶rper und Becherboden sicherstellt. Bei dieser AusfÃ¼hrungsform wirkt der Anschlag Ã¤hnlich wie das oben beschriebene Ringelement als seitlicher Stabilisator, um Kippbewegungen des Bechers zu minimieren. Aufgrund seiner Position in LÃ¤ngsrichtung hinter dem Ringelement kann so ein alternativer oder zusÃ¤tzlicher Abschnitt der Innenwand des Bechers abgestÃ¼tzt werden.According to a further embodiment of the invention, the tubular body carries a stop for supporting the restoring means in the longitudinal direction or forms such a stop. According to a further embodiment of the invention, the stop is positioned and dimensioned in relation to the inner wall of the cup in such a way that the stop limits tilting movements of the cup about an axis transverse to the longitudinal direction and ensures the sealing contact between the absorbent body and the cup base. In this embodiment, the stop acts similarly to the ring element described above as a lateral stabilizer in order to minimize tilting movements of the cup. Because of its position in the longitudinal direction behind the ring element, an alternative or additional section of the inner wall of the cup can be supported.

Die Erfindung umfasst ferner eine Transporteinheit zum Greifen, Anheben und Transportieren von Bechern, insbesondere Metallbechern, die in Dosierinhalatoren oder zur Herstellung von Batterien verwendet werden, z.B. in einer Produktionsline oder QualitÃ¤tsprÃ¼fungslinie, wobei die Transporteinheit einen oder mehrere Unterdruckgreifer aufweist, wie sie hierin beschrieben sind. Hinsichtlich der Anordnung mehrerer Unterdruckgreifer kÃ¶nnen diese den Produktionsanforderungen positioniert werden, beispielsweise in Reihen- oder in Matrixanordnung z.B. an einem Roboterarm oder einem Servoantrieb, um einen hohen Durchsatz in der Produktionslinie zu gewÃ¤hrleisten.The invention further comprises a transport unit for gripping, lifting and transporting cups, in particular metal cups, which are used in metered dose inhalers or for the production of batteries, e.g. in a production line or quality inspection line, the transport unit having one or more vacuum grippers as described herein . With regard to the arrangement of several vacuum grippers, these can be positioned according to the production requirements, for example in a row or in a matrix arrangement, e.g. on a robot arm or a servo drive, in order to ensure a high throughput in the production line.

FigurenlisteFigure list

Weitere Merkmale, Vorteile und AnwendungsmÃ¶glichkeiten der vorliegenden Erfindung ergeben sich aus der nachfolgenden Beschreibung eines AusfÃ¼hrungsbeispiels anhand der Zeichnungen. Es zeigen:

1 einen Becher aus Metall zur Herstellung von Batterien in einer Schnittansicht;

2 einen Unterdruckgreifer nach einer ersten AusfÃ¼hrungsform der Erfindung in einer Seitenansicht;

3 den Unterdruckgreifer aus 2 in einer Seitenansicht;

4 Details des Unterdruckgreifers aus 2 in einer Schnittansicht; und

5 den Unterdruckgreifer aus 2 in dem Becher aus 1.

Further features, advantages and possible applications of the present invention emerge from the following description of an exemplary embodiment with reference to the drawings. Show it:

1 a metal can for manufacturing batteries in a sectional view;

2 a vacuum gripper according to a first embodiment of the invention in a side view;

3 the vacuum gripper off 2 in a side view;

4th Details of the vacuum gripper 2 in a sectional view; and

5 the vacuum gripper off 2 in the cup 1 .

1 zeigt einen Becher 1 in Form eines zylindrischen Tiefziehteils aus Metall zur Herstellung von Batterien. Der Becher 1 weist einen Becherboden 2 und eine sich von dem Becherboden 2 bis einer Ãffnung 3 erstreckende umlaufende Seitenwand 4 auf. 1 shows a mug 1 in the form of a cylindrical deep-drawn part made of metal for the manufacture of batteries. The cup 1 has a beaker bottom 2 and one from the bottom of the cup 2 until an opening 3 extending circumferential side wall 4th on.

2 zeigt einen Unterdruckgreifer 5 zum Ergreifen, Anheben und Transportieren des Bechers 1 aus 1. Der Unterdruckgreifer 5 umfasst einen rohrfÃ¶rmigen KÃ¶rper 6 mit einem vorderen Abschnitt 7, der sich wie der rohrfÃ¶rmige KÃ¶rper 6 in einer LÃ¤ngsrichtung 8 erstreckt, wobei die LÃ¤ngsrichtung 8 hier mit der LÃ¤ngsachse des rohrfÃ¶rmigen KÃ¶rpers 6 zusammenfÃ¤llt. Der vordere Abschnitt 7 erstreckt sich von einem in LÃ¤ngsrichtung 8 gelegenen vorderen Ende 9 nach hinten, also in Richtung des in 2 dargestellten hinteren Endes 10 des rohrfÃ¶rmigen KÃ¶rpers 6. 2 shows a vacuum gripper 5 for gripping, lifting and transporting the cup 1 the end 1 . The vacuum gripper 5 comprises a tubular body 6th with a front section 7th that looks like the tubular body 6th in a longitudinal direction 8th extends, the longitudinal direction 8th here with the longitudinal axis of the tubular body 6th coincides. The front section 7th extends from one longitudinally 8th located front end 9 to the rear, i.e. in the direction of the in 2 illustrated rear end 10 of the tubular body 6th .

An dem vorderen Ende 9 des Unterdruckgreifers 5 ist ein SaugkÃ¶rper 11 angeordnet. Der SaugkÃ¶rper 11 ist in der Darstellung in der 2 teils durch ein Ringelement 12 in Form einer sich in LÃ¤ngsrichtung 8 erstreckenden HÃ¼lse verdeckt. Die HÃ¼lse 12 ist auf dem rohrfÃ¶rmigen KÃ¶rper 6 angeordnet, der sich durch die HÃ¼lse 12 erstreckt, so die HÃ¼lse 12 im Bereich des vorderen Endes 9 den Unterdruckgreifer 5 in einer Ebene quer zur LÃ¤ngsrichtung 8 umlÃ¤uft.At the front end 9 of the vacuum gripper 5 is an absorbent body 11th arranged. The absorbent body 11th is shown in the 2 partly by a ring element 12th in the form of a lengthways 8th extending sleeve covered. The sleeve 12th is on the tubular body 6th arranged, which extends through the sleeve 12th extends so the sleeve 12th in the area of the front end 9 the vacuum gripper 5 in a plane transverse to the longitudinal direction 8th running around.

Die HÃ¼lse 12 ist auf dem Unterdruckgreifer 5 in LÃ¤ngsrichtung 8 verschiebbar gefÃ¼hrt. In Richtung nach vorne, d.h. in 2 nach unten, bildet das stirnseitige Ende 13 der HÃ¼lse 12 einen Anschlag 14 aus. AuÃerdem verjÃ¼ngt sich das vordere Ende der HÃ¼lse 12 zum vorderen Ende hin. Die VerjÃ¼ngung 15 stellt eine EinfÃ¼hrhilfe fÃ¼r das EinfÃ¼hren des Unterdruckgreifers in einen Becher bereit.The sleeve 12th is on the vacuum gripper 5 longitudinal 8th slidably guided. In the forward direction, i.e. in 2 downwards, forms the frontal end 13th the sleeve 12th a stop 14th the end. In addition, the front end of the sleeve is tapered 12th towards the front end. The rejuvenation 15th provides an insertion aid for inserting the vacuum gripper into a cup.

Am hinteren Ende der HÃ¼lse 12 ist eine Feder 16 Ã¼ber den rohrfÃ¶rmigen KÃ¶per 6 geschoben und liegt am hinteren Ende der HÃ¼lse 12 an. Die Feder 16 ist zwischen der HÃ¼lse 12 und einem Federanschlag 17 angeordnet, der in einem Abstand zur HÃ¼lse 12 auf dem rohrfÃ¶rmigen KÃ¶rper 6 fixiert ist. Die HÃ¼lse 12 ist zwischen vordefinierten Grenzen in LÃ¤ngsrichtung verschiebbar. Die 2 zeigt die HÃ¼lse 12 in der vorderst-mÃ¶glichen Position, also einer vorderen Endposition. Dabei erstreckt sich das vordere Ende des SaugkÃ¶rpers 11 Ã¼ber das stirnseitige Ende 13 der HÃ¼lse 12 hinaus.At the rear end of the sleeve 12th is a feather 16 over the tubular body 6th pushed and lies at the rear end of the sleeve 12th at. The feather 16 is between the sleeve 12th and a spring stop 17th arranged at a distance from the sleeve 12th on the tubular body 6th is fixed. The sleeve 12th can be moved lengthways between predefined limits. the 2 shows the sleeve 12th in the foremost possible position, i.e. a front end position. The front end of the absorbent body extends here 11th over the front end 13th the sleeve 12th out.

Am hinteren Ende 10 des rohrfÃ¶rmigen KÃ¶rpers 6 sind Mittel 18 in Form eines AuÃengewindes zum Verbinden des Unterdruckgreifers mit einer Unterdruckquelle eingeformt.At the far end 10 of the tubular body 6th are means 18th molded in the form of an external thread for connecting the vacuum gripper to a vacuum source.

3 ist eine weitere Darstellung des Unterdruckgreifers 5 aus 2, allerdings ist die HÃ¼lse 12, die in LÃ¤ngsrichtung 8 verschiebbar auf dem Unterdruckgreifer 5 gefÃ¼hrt ist, in Richtung nach hinten, d.h. in Richtung des hinteren Ende 10 verschoben worden, um den SaugkÃ¶rper freizulegen. Infolge der rÃ¼ckwÃ¤rtigen Bewegung der HÃ¼lse 12 wurde die Feder 16 komprimiert und hat eine RÃ¼ckstellkraft aufgebaut, die nach vorne, d.h. in Richtung des vorderen Endes 9 wirkt. Die Feder 16 hat die Funktion eines RÃ¼ckstellmittels fÃ¼r die HÃ¼lse 12. 3 is another illustration of the vacuum gripper 5 the end 2 , however, is the sleeve 12th running lengthways 8th movable on the vacuum gripper 5 is guided, in the rearward direction, ie in the direction of the rear end 10 moved to expose the absorbent body. As a result of the backward movement of the sleeve 12th became the pen 16 compresses and has built up a restoring force, which is forward, ie in the direction of the front end 9 works. The feather 16 has the function of a return means for the sleeve 12th .

4 ist eine Schnittansicht des Unterdruckgreifers aus 2, wobei der Federanschlag, die Feder und die HÃ¼lse nicht dargestellt sind. In dem rohrfÃ¶rmigen KÃ¶rper 6 ist eine Unterdruckleitung 19 ausgebildet, die sich in LÃ¤ngsrichtung 8 durch den gesamten rohrfÃ¶rmigen KÃ¶rper 6 erstreckt. 4th FIG. 14 is a sectional view of the vacuum gripper of FIG 2 , the spring stop, the spring and the sleeve are not shown. In the tubular body 6th is a vacuum line 19th formed, which extends in the longitudinal direction 8th through the entire tubular body 6th extends.

Der SaugkÃ¶rper 11 besteht aus elastischem Silikonmaterial und ist am vorderen Ende des rohrfÃ¶rmigen KÃ¶rpers 6 angebracht. Der SaugkÃ¶rper 11 ist nach Art einer Glocke ausgebildet und bildet in Richtung nach vorne eine AnsaugÃ¶ffnung 20 aus. Der Innenraum der Glocke ist mit der Unterdruckleitung 19 strÃ¶mungsverbunden, d.h. der Innenraum der Glocke stellt einen Unterdruckraum 21 zur VerfÃ¼gung. Die AnsaugÃ¶ffnung 20 ist ringfÃ¶rmig umgeben von einem Abschnitt der Glocke, der als Dichtlippe 22 ausgebildet ist.The absorbent body 11th consists of elastic silicone material and is at the front end of the tubular body 6th appropriate. The absorbent body 11th is designed in the manner of a bell and forms a suction opening in the forward direction 20th the end. The interior of the bell is with the vacuum line 19th flow-connected, ie the interior of the bell represents a negative pressure space 21 to disposal. The suction opening 20th is ring-shaped surrounded by a section of the bell that acts as a sealing lip 22nd is trained.

Wird der rohrfÃ¶rmige KÃ¶rper 6 mittels des AuÃengewindes 18 an eine Unterdruckquelle, z.B. eine Vakuumpumpe oder eine Unterdruckleitung angeschlossen, kann in dem Unterdruckraum 21 ein Unterdruck erzeugt werden, so dass dann, wenn der SaugkÃ¶rper 11 mit der Dichtlippe 22 auf einer FlÃ¤che anliegt, der Unterdruck Ã¼ber den SaugkÃ¶rper 11 auf die FlÃ¤che einwirkt. Diese Ansaugkraft kann genutzt werden, um ein WerkstÃ¼ck anzuheben.Will the tubular body 6th by means of the external thread 18th Connected to a vacuum source, for example a vacuum pump or a vacuum line, can be in the vacuum space 21 a negative pressure can be generated so that when the absorbent body 11th with the sealing lip 22nd rests on a surface, the negative pressure over the absorbent body 11th acts on the surface. This suction force can be used to lift a workpiece.

5 zeigt den Unterdruckgreifer 5 aus 2 in Kombination mit dem als Batteriebecher bestimmten Becher 1 aus der 1, wobei hier ein Zustand dargestellt ist, bei dem in dem SaugkÃ¶rpers 11 ein Unterdruck vorherrscht. Die HÃ¼lse 12 und der Becher 1 sind aus DarstellungsgrÃ¼nden in einer Schnittansicht dargestellt. 5 shows the vacuum gripper 5 the end 2 in combination with the cup designed as a battery cup 1 from the 1 , a state is shown here in which in the absorbent body 11th a negative pressure prevails. The sleeve 12th and the mug 1 are shown in a sectional view for reasons of illustration.

Der Unterdruckgreifer 5 aus 2 wurde an eine Unterdruckquelle (nicht dargestellt) angeschlossen und mit dem vorderen Ende voran durch die BecherÃ¶ffnung 3 in den Becher 1 eingefahren, so dass der SaugkÃ¶rper 11 am vorderen Ende 9 des Unterdruckgreifers 5 am inneren Boden 2 des Bechers 1 zur Anlage kam. WÃ¤hrend des EinfÃ¼hrvorgangs sorgte die VerjÃ¼ngung 15 fÃ¼r eine sanfte Zentrierung zwischen Becher 1 und Unterdruckgreifer 5.The vacuum gripper 5 the end 2 was connected to a vacuum source (not shown) and front end first through the cup opening 3 in the cup 1 retracted so that the absorbent body 11th at the front end 9 of the vacuum gripper 5 on the inner bottom 2 of the mug 1 came to the plant. Tapered during the insertion process 15th for gentle centering between cups 1 and vacuum gripper 5 .

AnschlieÃend wurde in dem SaugkÃ¶rper 11 ein Unterdruck aufgebaut, um den inneren Boden 2 des Bechers 1 durch den SaugkÃ¶rper 11 festzusaugen. Die oben beschriebenen Dichtlippen des SaugkÃ¶rpers 11 sorgen dabei fÃ¼r die notwendige Abdichtung des Unterdruckraums in dem SaugkÃ¶rper. Infolge des Unterdruckaufbaus wurde der Becher 1 an den Unterdruckgreifer herangezogen, unter anderem aufgrund einer unterdruckbedingten Verformung des SaugkÃ¶rpers 11. Dann kam der Anschlag 14 der HÃ¼lse 12 zur Anlage mit dem Becherboden 2 und die HÃ¼lse 12 wurde etwas nach hinten, d.h. in Richtung des hinteren Endes 10, verschoben. Dadurch wurde die Feder 16 komprimiert und drÃ¤ngt nun im dargestellten Zustand die HÃ¼lse 12 gegen den inneren Boden 2 des Bechers 1. Die RÃ¼ckstellkraft der Feder 16 ist jedoch gewÃ¤hlt, dass sie geringer ist als die Ã¼ber den Unterdruck ausgeÃ¼bte Ansaugkraft.Then was in the absorbent body 11th a negative pressure built up around the inner floor 2 of the mug 1 through the absorbent body 11th to suck up. The sealing lips of the absorbent body described above 11th ensure the necessary sealing of the negative pressure space in the absorbent body. As a result of the build-up of negative pressure, the cup became 1 pulled on the vacuum gripper, among other things due to a vacuum-induced deformation of the suction body 11th . Then came the attack 14th the sleeve 12th for system with the cup base 2 and the sleeve 12th became a little backwards, that is, towards the rear end 10 , postponed. This made the pen 16 compresses and now pushes the sleeve in the state shown 12th against the inner floor 2 of the mug 1 . The restoring force of the spring 16 however, it is selected that it is less than the suction force exerted by the negative pressure.

Ãber die Ansaugkraft ist der Becher 1 im dargestellten Zustand am Unterdruckgreifer 5 festgelegt und kann nun durch den Unterdruckgreifer anhoben und transportiert werden, z.B. indem der in 5 dargestellte Unterdruckgreifer nach oben verfahren wird.The cup is about the suction force 1 in the state shown on the vacuum gripper 5 and can now be lifted and transported by the vacuum gripper, e.g. by placing the in 5 vacuum gripper shown is moved upwards.

Der Anschlag 14 am stirnseitigen Ende der HÃ¼lse 12 stabilisiert die relative Lage zwischen Becher und Unterdruckgreifer und verhindert durch den Andruck des Anschlags 14 um den SaugkÃ¶rper 11 herum auf die innere BodenflÃ¤che 2 des Bechers Kippbewegungen des Bechers 1 relativ zum Unterdruckgreifer 5 und stellt die dichte Verbindung zwischen SaugkÃ¶rper und innerer BodenflÃ¤che 2 des Bechers sicher.The attack 14th at the front end of the sleeve 12th stabilizes the relative position between the cup and the vacuum gripper and prevents it from pressing down on the stop 14th around the absorbent body 11th around on the inner bottom surface 2 of the cup tilting movements of the cup 1 relative to the vacuum gripper 5 and creates the tight connection between the absorbent body and the inner floor surface 2 of the cup safe.

Beim Absetzen des Bechers 1 wird der Unterdruck unterbrochen. Die Feder 16 unterstÃ¼tzt mit ihrer RÃ¼ckstellkraft dann das LÃ¶sen des Bechers 1 von dem Unterdruckgreifer.When putting down the cup 1 the vacuum is interrupted. The feather 16 then supports the release of the cup with its restoring force 1 from the vacuum gripper.

Die seitliche UmfangsflÃ¤che der HÃ¼lse 12, aber auch die seitliche UmfangsflÃ¤che des Federanschlags 17 sind in einer Richtung quer zur LÃ¤ngsrichtung 8 so dimensioniert, d.h. der Abstand zur inneren Seitenwand 4 des Bechers ist gering gehalten, dass die SeitenflÃ¤chen beider Elemente 12 und 17 einen Anschlag fÃ¼r die Innenwand des Bechers bereitstellen, der Kippbewegung des Bechers relativ zu dem SaugkÃ¶rper zusÃ¤tzlich begrenzt.The lateral peripheral surface of the sleeve 12th , but also the lateral circumferential surface of the spring stop 17th are in a direction transverse to the longitudinal direction 8th so dimensioned, ie the distance to the inner side wall 4th of the cup is kept small that the side surfaces of both elements 12th and 17th provide a stop for the inner wall of the cup, which additionally limits the tilting movement of the cup relative to the absorbent body.

BezugszeichenlisteList of reference symbols

11

Bechercups

22

BecherbodenCup bottom

33

BecherÃ¶ffnungCup opening

44th

SeitenwandSide wall

55

UnterdruckgreiferVacuum gripper

66th

rohrfÃ¶rmiger KÃ¶rpertubular body

77th

Abschnittsection

88th

LÃ¤ngsrichtungLongitudinal direction

99

vorderes Endefront end

1010

hinteres Enderear end

1111th

SaugkÃ¶rperAbsorbent body

1212th

Ringelement / HÃ¼lseRing element / sleeve

1313th

vorderes stirnseitiges Ende der HÃ¼lsefront end of the sleeve

1414th

Anschlagattack

1515th

VerjÃ¼ngungrejuvenation

1616

RÃ¼ckstellmittel / FederReturn means / spring

1717th

FederanschlagSpring stop

1818th

Verbindungsmittel / AuÃengewindeLanyard / external thread

1919th

UnterdruckleitungVacuum line

2020th

AnsaugÃ¶ffnungSuction opening

2121

UnterdruckraumNegative pressure room

2222nd

DichtlippeSealing lip

ZITATE ENTHALTEN IN DER BESCHREIBUNGQUOTES INCLUDED IN THE DESCRIPTION

Diese Liste der vom Anmelder aufgefÃ¼hrten Dokumente wurde automatisiert erzeugt und ist ausschlieÃlich zur besseren Information des Lesers aufgenommen. Die Liste ist nicht Bestandteil der deutschen Patent- bzw. Gebrauchsmusteranmeldung. Das DPMA Ã¼bernimmt keinerlei Haftung fÃ¼r etwaige Fehler oder Auslassungen.This list of the documents listed by the applicant was generated automatically and is included solely for the better information of the reader. The list is not part of the German patent or utility model application. The DPMA assumes no liability for any errors or omissions.

Zitierte PatentliteraturPatent literature cited

US 2989019 [0004]US 2989019 [0004]

## Classifications

- B65G47/91
- B65G47/91

## Cited patent documents

- [US-2989019-A](https://patents.google.com/patent/US2989019A/en) — APP

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
