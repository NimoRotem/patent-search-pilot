# 29. Portable flexible electric suction cup

- **Archive rank:** 29 of 50
- **Publication:** [CN-218205808-U](https://patents.google.com/patent/CN218205808U/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/084647945/publication/CN218205808U?q=pn%3DCN218205808U)
- **Publication date:** 2023-01-03
- **Filing date:** 2022-06-27
- **Earliest priority:** 2022-06-27
- **Family:** 84647945
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** JIANGSU SPIDER ROPE CLEANING TECH CO LTD

## Abstract

The utility model discloses a light nimble electric chuck relates to high altitude glass handling technical field, has solved the problem that glass handling is wasted time and energy and is fragile, which comprises a frame, the back of frame is fixed with a plurality of vacuum chuck, the frame openly is fixed with the block terminal, the block terminal internal fixation has vacuum pump, lithium cell and controller, baroceptor is all installed to the vacuum chuck upper end, there is the relief valve vacuum chuck one side through intake-tube connection, the vacuum chuck opposite side is connected through the end of bleeding of breathing pipe with the vacuum pump. This electric chuck can utilize vacuum chuck to adsorb glass fixedly, and is not only fixed effectual, labour saving and time saving moreover to can be greater than when the predetermined threshold value automatic start vacuum pump take the air in the vacuum chuck out, in order to keep vacuum chuck to have sufficient negative pressure suction.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-218205808-U/000.png)

![Sketch 1 for CN-218205808-U](https://nimo.iptorch.com/refdrawing/CN-218205808-U/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-218205808-U/001.png)

![Sketch 2 for CN-218205808-U](https://nimo.iptorch.com/refdrawing/CN-218205808-U/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/CN-218205808-U/002.png)

![Sketch 3 for CN-218205808-U](https://nimo.iptorch.com/refdrawing/CN-218205808-U/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/CN-218205808-U/003.png)

![Sketch 4 for CN-218205808-U](https://nimo.iptorch.com/refdrawing/CN-218205808-U/003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/CN-218205808-U/004.png)

![Sketch 5 for CN-218205808-U](https://nimo.iptorch.com/refdrawing/CN-218205808-U/004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/CN-218205808-U/005.png)

![Sketch 6 for CN-218205808-U](https://nimo.iptorch.com/refdrawing/CN-218205808-U/005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/CN-218205808-U/006.png)

![Sketch 7 for CN-218205808-U](https://nimo.iptorch.com/refdrawing/CN-218205808-U/006.png)

[Sketch 8](https://patentimages.storage.googleapis.com/66/47/34/6c4f8cedc78a69/HDA0003714781870000011.png)

![Sketch 8 for CN-218205808-U](https://patentimages.storage.googleapis.com/66/47/34/6c4f8cedc78a69/HDA0003714781870000011.png)

[Sketch 9](https://patentimages.storage.googleapis.com/66/26/7b/bcb2fc36334403/HDA0003714781870000021.png)

![Sketch 9 for CN-218205808-U](https://patentimages.storage.googleapis.com/66/26/7b/bcb2fc36334403/HDA0003714781870000021.png)

[Sketch 10](https://patentimages.storage.googleapis.com/20/2a/61/e9d53361629f3d/HDA0003714781870000031.png)

![Sketch 10 for CN-218205808-U](https://patentimages.storage.googleapis.com/20/2a/61/e9d53361629f3d/HDA0003714781870000031.png)

[Sketch 11](https://patentimages.storage.googleapis.com/7e/aa/6b/aa1fda53aefe6e/HDA0003714781870000041.png)

![Sketch 11 for CN-218205808-U](https://patentimages.storage.googleapis.com/7e/aa/6b/aa1fda53aefe6e/HDA0003714781870000041.png)

[Sketch 12](https://patentimages.storage.googleapis.com/16/15/c2/03359db9e3daf8/HDA0003714781870000051.png)

![Sketch 12 for CN-218205808-U](https://patentimages.storage.googleapis.com/16/15/c2/03359db9e3daf8/HDA0003714781870000051.png)

[Sketch 13](https://patentimages.storage.googleapis.com/2a/33/d4/8c684e9cfd8517/HDA0003714781870000061.png)

![Sketch 13 for CN-218205808-U](https://patentimages.storage.googleapis.com/2a/33/d4/8c684e9cfd8517/HDA0003714781870000061.png)

[Sketch 14](https://patentimages.storage.googleapis.com/9b/65/21/409af761767771/HDA0003714781870000071.png)

![Sketch 14 for CN-218205808-U](https://patentimages.storage.googleapis.com/9b/65/21/409af761767771/HDA0003714781870000071.png)

## Claims

### Claim 1 (independent)

Light nimble electric chuck, its characterized in that, including the frame, the back of frame is fixed with a plurality of vacuum chuck, the frame openly is fixed with the block terminal, the block terminal internal fixation has vacuum pump, lithium cell and controller, baroceptor is all installed to the vacuum chuck upper end, there is the relief valve vacuum chuck one side through intake-tube connection, the vacuum chuck opposite side is connected with the end of bleeding of vacuum pump through the breathing pipe, the check valve is all installed to the one end that the breathing pipe is close to vacuum chuck, switch and knob formula timer are installed to the chamber door outer wall of block terminal, the lithium cell switch with the controller component becomes the series circuit, the vacuum pump baroceptor knob formula timer all with controller electric connection, the frame openly is equipped with rings subassembly.

### Claim 2

The portable flexible electric suction cup according to claim 1, wherein the suspension ring assembly comprises a fixed shaft, a transmission shaft, a winding disc, a regulating belt and a suspension ring, the fixed shaft is fixed on both sides of the lower end of the front surface of the frame, the rotatable transmission shaft is arranged on the upper end of the front surface of the frame, the winding disc is fixed on both ends of the transmission shaft, a bearing is fixedly sleeved on the outer wall of each end of the transmission shaft, a connecting plate is fixed on the outer wall of each bearing, the connecting plate is fixedly connected with the frame, the regulating belt is fixedly arranged between the winding disc and the fixed shaft, the suspension ring is fixed on the middle part of the regulating belt, one end of the transmission shaft is connected with a band-type brake motor for driving the transmission shaft to rotate, and the band-type brake motor is electrically connected with the controller.

### Claim 3

The portable and flexible electric suction cup as claimed in claim 2, wherein the brake motor comprises a motor and a brake, the motor is fixedly connected with the connecting plate, a rotating shaft of the motor is fixedly connected with the transmission shaft, the brake is mounted at the tail of the motor, a reset switch is fixed on the outer wall of a box door of the distribution box, and the reset switch, the motor and the brake are electrically connected with the controller.

### Claim 4

The portable and flexible electric chuck according to claim 1, wherein an alarm, a power digital display and a pneumatic digital display are fixed on the outer wall of the door of the distribution box, the alarm and the pneumatic digital display are both electrically connected with the controller, the power digital display is electrically connected with the lithium battery, a charging interface is embedded in the bottom end of the distribution box, and the charging interface is electrically connected with the lithium battery.

### Claim 5

The portable and flexible electric suction cup according to claim 4, wherein a level is fixed to the outer wall of the lower end of the door of the distribution box.

### Claim 6

The portable flexible electric suction cup according to claim 5, wherein a canopy is fixed to the top end of the electric distribution box.

## Full description

Description

Portable flexible electric suction cup

Technical Field

The utility model relates to a high altitude glass handling technical field particularly, relates to light nimble electric sucking disc.

Background

The glass curtain wall is a building external protective structure or a decorative structure which has a certain displacement capacity relative to the main structure by a supporting structure system and does not bear the action of the main structure. The wall body has two types of single-layer glass and double-layer glass. The glass curtain wall is a beautiful and novel building wall decoration method, is a remarkable characteristic of modern times of the most modern high-rise buildings, and in the installation of the high-rise glass curtain wall, a large glass block needs to be accurately hoisted to a high-rise glass installation position, and then the glass is manually installed and fixed.

In the prior art, the glass horizontally placed on the ground is usually and directly hoisted to the installation position by adopting the lifting equipment, so that time and labor are wasted, the glass is not easily fixed in the hoisting process, and the glass is easily damaged.

An effective solution to the problems in the related art has not been proposed yet.

SUMMERY OF THE UTILITY MODEL

An object of the utility model is to provide a light nimble electric sucking disc to solve the problem that proposes among the above-mentioned background art.

In order to achieve the above object, the utility model provides a following technical scheme: light nimble electric chuck includes the frame, the back of frame is fixed with a plurality of vacuum chuck, the frame openly is fixed with the block terminal, the block terminal internal fixation has vacuum pump, lithium cell and controller, baroceptor is all installed to the vacuum chuck upper end, there is the relief valve vacuum chuck one side through intake-tube connection, the vacuum chuck opposite side is connected through the bleed-off end of breathing pipe with the vacuum pump, the check valve is all installed to the one end that the breathing pipe is close to vacuum chuck, switch and knob formula timer are installed to the chamber door outer wall of block terminal, the lithium cell switch with the controller constitutes the series circuit, the vacuum pump the baroceptor knob formula timer all with controller electric connection, the frame openly is equipped with rings subassembly.

Further, the rings subassembly includes the fixed axle, the transmission shaft, the rolling dish, regulation band and rings, the both sides of the positive lower extreme of frame all are fixed with the fixed axle, the positive upper end of frame is equipped with rotatable transmission shaft, the transmission shaft both ends all are fixed with the rolling dish, the equal fixed cover in transmission shaft both ends outer wall is equipped with the bearing, the bearing outer wall all is fixed with the connecting plate, the connecting plate all with frame fixed connection, the fixed regulation band that is equipped with between rolling dish and the fixed axle, the regulation band middle part is fixed with rings, transmission shaft one end is connected with and is used for driving transmission shaft pivoted band-type brake motor, band-type brake motor and controller electric connection, can rotate the position to rings through control band-type brake motor and adjust, thereby can adjust the glass of horizontality to vertical state.

Further, the band-type brake motor includes motor and band-type brake ware, motor and connecting plate fixed connection, and the pivot and the transmission shaft fixed connection of motor, and the band-type brake ware is installed to the afterbody of motor, and the chamber door outer wall of block terminal is fixed with reset switch, and reset switch, motor and band-type brake ware all with controller electric connection, can reset the regulation band of release rolling to the band-type brake motor through reset switch to the band-type brake ware can be fixed with the pivot locking of motor when motor stop work.

Further, the chamber door outer wall of block terminal is fixed with siren, electric quantity digital display and atmospheric pressure digital display, the siren with atmospheric pressure digital display all with controller electric connection, electric quantity digital display and lithium cell electric connection, the block terminal bottom mounting inlays and is equipped with the interface that charges, interface and lithium cell electric connection charge, when getting into the air in the vacuum suction disc and leading to inside atmospheric pressure to be greater than predetermined threshold value, the controller can automatic control siren issue an alarm to utilize electric quantity digital display can detect and show the residual capacity of lithium cell, utilize atmospheric pressure digital display can show the atmospheric pressure value that atmospheric pressure sensor detected.

Furthermore, a level meter is fixed on the outer wall of the lower end of the box door of the distribution box, and the levelness of the glass can be judged through the level meter when the distribution box is installed.

Further, the top of block terminal is fixed with the canopy, can increase the rain-proof performance of block terminal.

Compared with the prior art, the utility model discloses following beneficial effect has:

1. the vacuum sucking disc can be used for adsorbing and fixing glass, the fixing effect is good, time and labor are saved, the glass is not easy to damage, the air pressure in the vacuum sucking disc can be detected by arranging the air pressure sensor, and therefore the vacuum pump can be automatically started to pump out air in the vacuum sucking disc when the air pressure is greater than a preset threshold value, and the vacuum sucking disc is kept to have enough negative pressure suction;

2. the utility model discloses can be when carrying out the handling to the glass that the level was placed for glass still keeps the level, prevents that glass one end from being hoisted and the other end from bumping with ground and leading to glass cracked, thereby can effectually avoid the collision that glass took place because of the slope when initial handling, can adjust glass to vertical state automatically moreover after glass reaches the take the altitude, thereby be convenient for with glass and installation position block.

Drawings

In order to more clearly illustrate the embodiments of the present invention or the technical solutions in the prior art, the drawings required to be used in the embodiments will be briefly described below, and it is obvious that the drawings in the following description are only some embodiments of the present invention, and for those skilled in the art, other drawings can be obtained according to these drawings without creative efforts.

FIG. 1 is a schematic diagram of a lightweight flexible electric suction cup according to an embodiment of the present invention;

FIG. 2 is a schematic diagram of a frame and bail assembly in a lightweight flexible electric suction cup in accordance with an embodiment of the present invention;

fig. 3 is a schematic structural view of a distribution box and a vacuum chuck in a portable flexible electric chuck according to an embodiment of the present invention;

FIG. 4 is a schematic view of the adjustment strap under tension in the portable flexible electric suction cup according to an embodiment of the present invention;

FIG. 5 is a cross-sectional view of a vacuum chuck in a lightweight flexible electric chuck in accordance with an embodiment of the present invention;

fig. 6 is a schematic structural view of a transmission shaft in a lightweight flexible electric suction cup according to an embodiment of the present invention;

fig. 7 is a schematic connection diagram of a lightweight flexible electric suction cup according to an embodiment of the present invention.

Reference numerals are as follows:

1. a frame; 2. a vacuum chuck; 3. a distribution box; 4. a vacuum pump; 5. a lithium battery; 6. a controller; 7. an air pressure sensor; 8. an air inlet pipe; 9. a pressure relief valve; 10. an air intake duct; 11. a one-way valve; 12. a power switch; 13. a knob type timer; 14. a fixed shaft; 15. a drive shaft; 16. a winding disc; 17. an adjustment belt; 18. a hoisting ring; 19. a bearing; 20. a connecting plate; 21. a band-type brake motor; 22. a reset switch; 23. an alarm; 24. a power digital display; 25. a barometric pressure digital display; 26. a level gauge; 27. a rain shed; 28. and a charging interface.

Detailed Description

The following description of the present invention will be made with reference to the accompanying drawings and the detailed description thereof:

example (b):

please refer to fig. 1-7, according to the utility model discloses a light nimble electric chuck, including frame 1, wherein, frame 1 is formed by the welding of I shape aluminum alloy, the back of frame 1 is fixed with a plurality of vacuum chuck 2, frame 1 openly is fixed with block terminal 3, block terminal 3 internal fixation has vacuum pump 4, lithium cell 5 and controller 6, baroceptor 7 is all installed to vacuum chuck 2 upper end, 2 one side of vacuum chuck is connected with relief valve 9 through intake pipe 8, 2 opposite sides of vacuum chuck are connected with the bleed end of vacuum pump 4 through breathing pipe 10, check valve 11 is all installed to the one end that breathing pipe 10 is close to vacuum chuck 2, switch 12 and knob formula timer 13 are installed to the chamber door outer wall of block terminal 3, lithium cell 5 switch 12 with controller 6 constitutes the series circuit, vacuum pump 4, baroceptor 7 knob formula timer 13 all with controller 6 electric connection, frame 1 openly is equipped with rings subassembly, can utilize vacuum chuck 2 to adsorb fixedly to glass, not only fixes effectually, and is difficult for the damage glass to carry out the atmospheric pressure in order to have enough suction that vacuum chuck 2 in advance to detect the suction, thereby vacuum chuck 4 is greater than vacuum chuck 2.

Further, the flying ring component comprises a fixed shaft 14, a transmission shaft 15, a winding disc 16, an adjusting belt 17 and a flying ring 18, the fixed shaft 14 is fixed on two sides of the lower end of the front surface of the frame 1, the rotatable transmission shaft 15 is arranged at the upper end of the front surface of the frame 1, the winding disc 16 is fixed at two ends of the transmission shaft 15, bearings 19 are fixedly sleeved on the outer walls of two ends of the transmission shaft 15, connecting plates 20 are fixed on the outer walls of the bearings 19, the connecting plates 20 are fixedly connected with the frame 1, the adjusting belt 17 is fixedly arranged between the winding disc 16 and the fixed shaft 14, the flying ring 18 is fixed in the middle of the adjusting belt 17, one end of the transmission shaft 15 is connected with a band-type brake motor 21 for driving the transmission shaft 15 to rotate, the band-type brake motor 21 is electrically connected with the controller 6, the position of the flying ring 18 can be adjusted by controlling the band-type brake motor 21 to rotate, so that the glass in a horizontal state can be adjusted to a vertical state, when the glass is lifted horizontally arranged, the glass, so that the glass can be lifted, one end of the glass can be kept horizontal state, so that the glass can be lifted and the other end of the glass can be collided with the ground to cause the glass to be cracked, thereby effectively avoiding the glass to be automatically clamped with the ground, the glass when the glass is lifted height is adjusted to be conveniently mounted.

Further, band-type brake motor 21 includes motor and band-type brake ware, motor and 20 fixed connection of connecting plate, and the pivot and the 15 fixed connection of transmission shaft of motor, the band-type brake ware is installed to the afterbody of motor, block terminal 3's chamber door outer wall is fixed with reset switch 22, motor and band-type brake ware all with 6 electric connection of controller, can reset the regulation band 17 of release rolling to band-type brake motor 21 through reset switch 22, and the band-type brake ware can be fixed with the pivot locking of motor when the motor stop work.

Further, block terminal 3's chamber door outer wall is fixed with siren 23, electric quantity digital display 24 and atmospheric pressure digital display 25, siren 23 with atmospheric pressure digital display 25 all with 6 electric connection of controller, electric quantity digital display 24 and 5 electric connection of lithium cell, 3 bottom mounting of block terminal inlays and is equipped with interface 28 that charges, interface 28 and 5 electric connection of lithium cell charge, it leads to inside atmospheric pressure to be greater than when predetermineeing the threshold value to get into the air in the vacuum sucking disc 2, 6 can automatic control siren 23 alarm of controller, and utilize electric quantity digital display 24 to detect and show lithium cell 5's residual capacity, utilize atmospheric pressure digital display 25 to show the atmospheric pressure value that atmospheric pressure sensor 7 detected.

Furthermore, a level gauge 26 is fixed on the outer wall of the lower end of the door of the distribution box 3, and the levelness of the glass can be judged through the level gauge 26 when the distribution box is installed.

Further, the top of block terminal 3 is fixed with canopy 27, can increase block terminal 3's rain proofness ability.

For the convenience of understanding the technical solution of the present invention, the following detailed description is made on the working principle or the operation mode of the present invention in the practical process.

In practical application, the vacuum chuck 2 is placed on glass to be installed, a cross beam of the frame 1 is made to be parallel to the bottom edge of the glass, a longitudinal beam of the frame 1 is made to be parallel to the side edge of the glass, then the power switch 12 is pressed, the controller 6 can automatically control the vacuum pump 4 to work after being electrified so as to pump out air inside the vacuum chuck 2, so that the vacuum chuck 2 can be firmly adsorbed on the glass by using negative pressure, the check valve 11 can effectively prevent air from entering the vacuum chuck 2 from the vacuum pump 4 along the air suction pipe 10, then the two hanging rings 18 are connected with the two hanging ropes, timing is carried out by the knob type timer 13, and the glass is lifted by connecting the two hanging rings 18 through the hanging ropes by using lifting equipment, at the moment, because the hanging rings 18 are positioned in the middle positions of the two sides of the frame 1, the glass can be in a state of being parallel to the ground when leaving the ground, therefore, the collision of the glass with the ground due to inclination during initial lifting can be effectively avoided, when the glass is lifted to a certain height after timing is finished, at the moment, the controller 6 can automatically control the motor to work, the motor drives the transmission shaft 15 and the rolling discs 16 at the two ends of the transmission shaft 15 to rotate to roll the adjusting belt 17, so that the lifting ring 18 can be moved to one end of the frame 1, the glass is converted from a state parallel to a horizontal plane to a state vertical to the horizontal plane, the glass is usually in a state vertical to the horizontal plane during installation and fixation, so that the glass can be conveniently clamped with an installation position, after the glass is installed and fixed, the power switch 12 is closed, then the pressure release valve 9 is opened, so that the external air enters the vacuum chuck 2, the vacuum chuck 2 loses suction force, and the vacuum chuck 2 can be separated from the glass, when the air entering the vacuum chuck 2 causes the internal air pressure to be larger than the preset threshold value, the controller 6 can automatically control the vacuum pump 4 and the alarm 23 to work, the vacuum pump 4 is utilized to pump out the air in the vacuum chuck 2, and meanwhile the alarm 23 gives an alarm to remind related personnel.

Although embodiments of the present invention have been shown and described, it will be appreciated by those skilled in the art that changes, modifications, substitutions and alterations can be made in these embodiments without departing from the principles and spirit of the invention, the scope of which is defined in the appended claims and their equivalents.

---

Generated by IPtorch. Verify legal conclusions against the official publication.
