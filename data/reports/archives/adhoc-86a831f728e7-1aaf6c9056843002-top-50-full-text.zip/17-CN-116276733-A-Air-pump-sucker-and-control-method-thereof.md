# 17. Air pump sucker and control method thereof

- **Archive rank:** 17 of 50
- **Publication:** [CN-116276733-A](https://patents.google.com/patent/CN116276733A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/086813496/publication/CN116276733A?q=pn%3DCN116276733A)
- **Publication date:** 2023-06-23
- **Filing date:** 2023-05-15
- **Earliest priority:** 2023-05-15
- **Family:** 86813496
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** YONGKANG BINYI IND AND TRADE CO LTD
- **Inventors:** LI KAI

## Abstract

The invention relates to an air pump sucker and a control method thereof, wherein the air pump sucker comprises: a handle for holding by a user, a sucker body, a motor, an air pump, a battery, a deflation valve for deflating and an air pressure sensor for detecting air pressure; the motor, the air pump and the battery are arranged in the handle; the two ends of the handle are fixed to the top of the sucker main body; the bottom of the sucker main body is provided with a rubber structure; the sucker main body is provided with an air flow channel communicated with one side of the rubber structure; the motor drives the air pump to work, so that air between the rubber structure and a plane contacted with the rubber structure is extracted through the air flow channel; an air pump suction cup has an air suction operation state, an air pressure maintaining state and an air release state. The beneficial effects of the invention are as follows: the air suction working state, the air pressure maintaining state and the air release state are set, and when the air pressure value reaches the preset air pressure, the air suction working state can be automatically adjusted to the air pressure maintaining state. Compared with the mode of continuously maintaining the air extraction working state, the electric quantity is saved, the motor load is small, and the service life is long.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-116276733-A/000.png)

![Sketch 1 for CN-116276733-A](https://nimo.iptorch.com/refdrawing/CN-116276733-A/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-116276733-A/001.png)

![Sketch 2 for CN-116276733-A](https://nimo.iptorch.com/refdrawing/CN-116276733-A/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/CN-116276733-A/002.png)

![Sketch 3 for CN-116276733-A](https://nimo.iptorch.com/refdrawing/CN-116276733-A/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/CN-116276733-A/003.png)

![Sketch 4 for CN-116276733-A](https://nimo.iptorch.com/refdrawing/CN-116276733-A/003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/CN-116276733-A/004.png)

![Sketch 5 for CN-116276733-A](https://nimo.iptorch.com/refdrawing/CN-116276733-A/004.png)

[Sketch 6](https://patentimages.storage.googleapis.com/fc/6c/6d/7924516659ceff/HDA0004228877760000011.png)

![Sketch 6 for CN-116276733-A](https://patentimages.storage.googleapis.com/fc/6c/6d/7924516659ceff/HDA0004228877760000011.png)

[Sketch 7](https://patentimages.storage.googleapis.com/6b/24/a2/6d39288895590b/HDA0004228877760000021.png)

![Sketch 7 for CN-116276733-A](https://patentimages.storage.googleapis.com/6b/24/a2/6d39288895590b/HDA0004228877760000021.png)

[Sketch 8](https://patentimages.storage.googleapis.com/a2/8b/f5/2cf471f1561f9e/HDA0004228877760000031.png)

![Sketch 8 for CN-116276733-A](https://patentimages.storage.googleapis.com/a2/8b/f5/2cf471f1561f9e/HDA0004228877760000031.png)

[Sketch 9](https://patentimages.storage.googleapis.com/6c/21/1d/0c4984430c6e32/HDA0004228877760000041.png)

![Sketch 9 for CN-116276733-A](https://patentimages.storage.googleapis.com/6c/21/1d/0c4984430c6e32/HDA0004228877760000041.png)

[Sketch 10](https://patentimages.storage.googleapis.com/de/1b/06/7622e8cb6a8240/HDA0004228877760000051.png)

![Sketch 10 for CN-116276733-A](https://patentimages.storage.googleapis.com/de/1b/06/7622e8cb6a8240/HDA0004228877760000051.png)

## Claims

### Claim 1 (independent)

An air pump suction cup, characterized by comprising: a handle for holding by a user, a sucker body, a motor, an air pump, a battery, a deflation valve for deflating and an air pressure sensor for detecting air pressure; the motor, the air pump and the battery are arranged in the handle; two ends of the handle are fixed to the top of the sucker main body; the bottom of the sucker main body is provided with a rubber structure; the sucker main body is provided with an air flow channel communicated with one side of the rubber structure; the motor drives the air pump to work, so that air between the rubber structure and a plane contacted with the rubber structure is extracted through the air flow channel; the air pump sucking disc is provided with an air suction working state, an air pressure maintaining state and an air discharging state; when the air pump is in the air suction working state, the motor drives the air pump to suck air; when the air pressure value reaches the preset air pressure, the air pump sucking disc is adjusted from the air extraction working state to the air pressure maintaining state; in the air pressure maintaining state, the motor is turned off; in the deflated state, the motor closes the deflate valve and opens.

### Claim 2

An air pump suction cup according to claim 1, wherein, the air pump sucking disc includes: the first indicator lamp, the second indicator lamp and the third indicator lamp; when the air pump is in the air extraction working state, the first indicator lamp is on; when the air pump is in the deflation state, the second indicator light is on; and when the air pump is in the air pressure maintaining state, the third indicator lamp is on.

### Claim 3

An air pump suction cup according to claim 2, wherein, and when the voltage of the battery is lower than a preset voltage, the first indicator lamp flashes.

### Claim 4

An air pump suction cup according to claim 2, wherein, when the air pressure sensor fails, the first indicator lamp, the second indicator lamp and the third indicator lamp are simultaneously turned on.

### Claim 5

An air pump suction cup according to claim 2, wherein, and when the air pressure sensor detects that the air pressure value exceeds the preset air pressure to reach a preset difference value, the third indicator lamp flashes.

### Claim 6

A control method of an air pump suction cup, characterized in that the control method is applied to the air pump suction cup as claimed in claim 1, and comprises the following steps: step 1, the air pump sucker enters the air extraction working state; step 2, when the air pressure value reaches the preset air pressure, the motor is turned off, and the air pump sucking disc is adjusted from the air suction working state to the air pressure maintaining state; step 3, in the air pressure maintaining state, if the air pressure value is lower than a preset lower limit air pressure, the motor is started, and the air pump sucking disc is adjusted from the air pressure maintaining state to an air extraction working state; and 4, repeating the step 2 and the step 3 before controlling the air pump sucker to enter the deflation state.

### Claim 7

The method of controlling an air pump suction cup according to claim 6, further comprising the steps of: and 5, controlling the air pump sucker to enter the air release state, and opening the air release valve.

### Claim 8

A control method of an air pump suction cup according to claim 7, wherein, and (2) when the air pump sucker enters the air release state, the air pump sucker can be controlled to enter the air extraction working state again within the preset time, the step (1) is executed, and if the air extraction working state is not entered within the preset time, the air pump sucker is automatically powered off beyond the preset time.

### Claim 9

A control method of an air pump suction cup according to claim 8, wherein, the air pump sucking disc is provided with a start button; in the power-off state, when the power-on button is pressed for a long time, the air pump sucker is started up and enters the air extraction working state; when the air pressure is kept or the air extraction working state is achieved, the start button is pressed for a long time, and the air pump sucker is powered off; and in the air pressure maintaining state or the air extraction working state, the start button is double-clicked, the air release valve is opened, and the air pump sucker enters the air release state.

### Claim 10

A control method of an air pump suction cup according to claim 9, wherein, in the deflation state, the suction disc of the air pump is controlled to enter the air extraction working state by clicking the start button; in the deflation state, the air pump sucker can be powered off by long-time pressing of the power-on button.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGHAND TOOLS; PORTABLE POWER-DRIVEN TOOLS; MANIPULATORSTOOLS OR BENCH DEVICES NOT OTHERWISE PROVIDED FOR, FOR FASTENING, CONNECTING, DISENGAGING, OR HOLDINGWork holders not covered by any preceding group in the subclass, e.g. magnetic work holders, vacuum work holdersVacuum work holders

Description

Air pump sucker and control method thereof

Technical Field

The invention relates to an air pump sucker and a control method thereof.

Background

Air pump suction cups are commonly used to suck items such as tile, glass, and the like. After the traditional air pump sucker is started, the air pump sucker keeps in a continuous air exhaust state for a long time, the power consumption is low, and the motor keeps in a high load or even overload state for a long time, so that the service life of the motor is influenced.

Disclosure of Invention

The invention aims to provide an air pump sucker and a control method thereof, which are used for solving the problems in the background technology.

In order to achieve the above purpose, the present invention provides the following technical solutions:

an air pump suction cup, comprising: a handle for holding by a user, a sucker body, a motor, an air pump, a battery, a deflation valve for deflating and an air pressure sensor for detecting air pressure;

the motor, the air pump and the battery are arranged in the handle; the two ends of the handle are fixed to the top of the sucker main body; the bottom of the sucker main body is provided with a rubber structure; the sucker main body is provided with an air flow channel communicated with one side of the rubber structure; the motor drives the air pump to work, so that air between the rubber structure and a plane contacted with the rubber structure is extracted through the air flow channel;

an air pump sucker has an air suction working state, an air pressure maintaining state and an air discharging state;

in the air extraction working state, the motor drives the air pump to extract air; when the air pressure value reaches the preset air pressure, the air pump sucking disc is adjusted from an air suction working state to an air pressure maintaining state; when the air pressure is kept, the motor is closed; in the deflated state, the motor closes the deflate valve and opens.

As a further embodiment of the present invention, an air pump suction cup includes: the first indicator lamp, the second indicator lamp and the third indicator lamp;

when the air pump is in an air extraction working state, the first indicator lamp is on; when the air pump is in a deflation state, the second indicator light is on; when the air pump is in the air pressure maintaining state, the third indicator lamp is on.

As a further embodiment of the present invention, the first indicator light blinks when the voltage of the battery is lower than the preset voltage.

As a further embodiment of the present invention, the first indicator light, the second indicator light, and the third indicator light are turned on simultaneously when the air pressure sensor fails.

As a further embodiment of the present invention, the third indicator light blinks when the air pressure sensor detects that the air pressure value exceeds the preset air pressure by a preset difference.

A control method of an air pump sucker is applied to the air pump sucker, and comprises the following steps:

step 1, an air pump sucker enters an air extraction working state;

step 2, when the air pressure value reaches the preset air pressure, the motor is closed, and the air pump sucking disc is adjusted from an air suction working state to an air pressure maintaining state;

step 3, in the air pressure maintaining state, if the air pressure value is lower than the preset lower limit air pressure, the motor is opened, and the air pump sucking disc is adjusted from the air pressure maintaining state to an air extraction working state;

and 4, repeating the step 2 and the step 3 before controlling an air pump sucker to enter a deflation state.

As a further embodiment of the present invention, a control method of an air pump suction cup further includes the steps of:

and 5, controlling an air pump sucker to enter a deflation state, and opening a deflation valve.

As a further embodiment of the invention, when an air pump sucker enters a deflation state, the air pump sucker can be controlled to enter an air extraction working state again within a preset time, the step 1 is executed, and if the air pump sucker does not enter the air extraction working state within the preset time, the air pump sucker is automatically shut down if the air pump sucker does not enter the air extraction working state beyond the preset time.

As a further embodiment of the present invention, an air pump suction cup is provided with a start button;

in the power-off state, when a power-on button is pressed for a long time, the air pump sucker is started and enters into an air extraction working state;

in the air pressure maintaining state or the air extraction working state, the start button is pressed for a long time, and the air pump sucker is powered off;

in the air pressure maintaining state or the air exhausting working state, the start button is double-clicked, the air release valve is opened, and the air pump sucking disc enters the air release state.

As a further embodiment of the invention, in the deflation state, the suction disc of the air pump is controlled to enter the air extraction working state by clicking the start button; in the deflation state, the air pump sucker can be powered off by long-time pressing of the power-on button.

The invention has the advantages that: the air suction working state, the air pressure maintaining state and the air release state are set, and when the air pressure value reaches the preset air pressure, the air suction working state can be automatically adjusted to the air pressure maintaining state. Compared with the mode of continuously maintaining the air extraction working state, the electric quantity is saved, the motor load is small, and the service life is long.

When the pressure is insufficient, the pressure can be automatically adjusted from the air pressure maintaining state to the air pumping working state. The reliability of adsorption is maintained.

The operation is simple, only one start button is arranged, and the air pump sucker is controlled to be switched under different states through the operation of the start button.

Other features and advantages of the present invention will be disclosed in the following detailed description of the invention and the accompanying drawings.

Drawings

FIG. 1 is a perspective view of an air pump suction cup of the present invention;

FIG. 2 is a plan view of the suction cup of the air pump of FIG. 1;

FIG. 3 is a bottom view of the air pump suction cup of FIG. 2;

FIG. 4 is a schematic view of the handle of the air pump suction cup of FIG. 1;

fig. 5 is a schematic view of the internal structure of the handle of fig. 4.

List of reference numerals: the air pump sucking disc 100, the handle 10, the sucking disc main body 20, the motor 30, the air pump 40, the battery 50 and the start button 60.

Detailed Description

The following description of the embodiments of the present invention will be made clearly and completely with reference to the accompanying drawings, in which it is apparent that the embodiments described are only some embodiments of the present invention, but not all embodiments. All other embodiments, which can be made by those skilled in the art based on the embodiments of the invention without making any inventive effort, are intended to be within the scope of the invention.

As shown in fig. 1 to 5, an air pump suction cup 100 includes: the handle 10, the suction cup body 20, the motor 30, the air pump 40, the battery 50, the air release valve and the air pressure sensor.

The handle 10 is intended to be held by a user. The deflating valve is used for deflating. The air pressure sensor is used for detecting air pressure.

The motor 30, the air pump 40, and the battery 50 are disposed within the handle 10. The motor 30, the air pump 40 and the battery 50 are arranged in a straight line within the handle 10. The handle 10 is fixed at both ends to the top of the suction cup body 20. The bottom of the suction cup body 20 is provided with a rubber structure. The suction cup body 20 is provided with an air flow passage communicating with one side of the rubber structure.

The motor 30 drives the air pump 40 to operate so as to draw air between the rubber structure and the plane in contact therewith through the air flow passage. Also the air pressure of the space detected by the air pressure sensor. The air pressure of the space may be determined by detecting the air pressure of the air flow channel or a pipe connected to the air flow channel.

An air pump suction cup 100 has an air suction operation state, an air pressure maintaining state, and an air discharge state. In the air extraction operation state, the motor 30 drives the air pump 40 to extract air. When the air pressure reaches the preset air pressure, the air pump suction cup 100 is adjusted from the air pumping working state to the air pressure maintaining state. In the air pressure maintaining state, the motor 30 is turned off. In the deflated state, the motor 30 is turned off and the deflate valve is opened.

As a specific embodiment, an air pump suction cup 100 includes: the first indicator lamp, the second indicator lamp and the third indicator lamp. The first indicator light, the second indicator light and the third indicator light are all LED lamps. When the air pump 40 is in the air-extracting working state, the first indicator light is on. When the air pump 40 is in the deflated state, the second indicator light is on. When the air pump 40 is in the air pressure maintaining state, the third indicator light is turned on. In the air pressure maintaining state, the air pump suction cup 100 reaches a suction force of 500mmHg (millimeter hg).

As a specific embodiment, when the voltage of the battery 50 is lower than the preset voltage, the first indicator light blinks to prompt the user to charge in time. When the air pressure sensor fails, the first indicator lamp, the second indicator lamp and the third indicator lamp are simultaneously turned on. When the air pressure sensor detects that the air pressure value exceeds the preset air pressure to reach a preset difference value (20-110 kPa), the third indicator lamp flashes.

The control method of the air pump sucking disc 100 is applied to the air pump sucking disc 100, and comprises the following steps:

step 1, an air pump suction cup 100 enters an air pumping working state.

Step 2, when the air pressure reaches the preset air pressure, the motor 30 is turned off, and the air pump suction cup 100 is adjusted from the air pumping working state to the air pressure maintaining state.

In step 3, in the air pressure maintaining state, if the air pressure value is lower than the preset lower limit air pressure, the motor 30 is turned on, and the air pump suction cup 100 is adjusted from the air pressure maintaining state to the air pumping working state.

Step 4, the steps 2 and 3 are repeated until the air pump suction cup 100 is controlled to enter the air release state. 7. The control method of the air pump suction cup 100 according to claim 6, further comprising the steps of:

and 5, controlling the air pump sucking disc 100 to enter a deflation state, and opening a deflation valve.

As a specific embodiment, when an air pump suction cup 100 enters into a deflation state, the air pump suction cup 100 can be controlled again to enter into an air extraction working state within a preset time, step 1 is executed, and if the air pump suction cup 100 does not enter into the air extraction working state within the preset time, the air pump suction cup 100 is automatically turned off if the air pump suction cup does not enter into the air extraction working state beyond the preset time.

As a specific embodiment, an air pump suction cup 100 is provided with a power-on button 60.

In the off state, when the power-on button 60 is pressed for a long time, the air pump suction cup 100 is started up and enters the air pumping working state.

In the air pressure maintaining state or the air extracting operation state, the start button 60 is pressed for a long time, and the air pump suction cup 100 is turned off.

In the air pressure maintaining state or the air extracting operation state, the start button 60 is double-clicked, the air release valve is opened, and an air pump suction cup 100 is brought into the air release state.

In the deflated state, an air pump suction cup 100 is controlled to enter the deflated state by clicking the power-on button 60.

In the deflated state, an air pump suction cup 100 can be turned off by long pressing the power-on button 60. In the deflated state, the device is automatically shut down if no operation is performed within 12 seconds.

As a specific embodiment, when the power-on button 60 is pressed for a long time, the power-on enters the air-extracting working state, and the first indicator light is turned on. At this time, the user keeps the air pump suction cup 100 in good contact with it. The air pump suction cup 100 pumps air. When the suction force of the air pump suction cup 100 is enough, the air pump suction cup enters an air pressure maintaining state, at this time, the first indicator light is turned off, and the third indicator light is turned on. In the air pressure maintaining state, the air pump suction cup 100 is not in absolute sealing, and air leakage is gradually caused. The suction of the air pump sucker 100 also gradually decreases, when the suction of the air pump sucker 100 is smaller than a certain value, the motor 30 is automatically triggered to work, the air pump sucker 100 enters into an air extraction working state, the first indicator light is on, and the third indicator light is on.

Double clicking on the start button 60 opens the bleed valve and the pump suction cup 100 is in the bleed state, the first indicator light turns off the third indicator light, and the second indicator light turns on for 1 second and then turns off.

And clicking the button within 10 seconds after the second indicator lamp is turned off, so that the air suction working state can be reentered. After the second indicator light is turned off for 10 seconds, the air pump suction cup 100 enters a power-off state. In the case of long-press of the power-on button 60, the power-on is restarted.

It will be evident to those skilled in the art that the invention is not limited to the details of the foregoing illustrative embodiments, and that the present invention may be embodied in other specific forms without departing from the spirit or essential characteristics thereof. The present embodiments are, therefore, to be considered in all respects as illustrative and not restrictive, the scope of the invention being indicated by the appended claims rather than by the foregoing description, and all changes which come within the meaning and range of equivalency of the claims are therefore intended to be embraced therein. Any reference sign in a claim should not be construed as limiting the claim concerned.

Furthermore, it should be understood that although the present disclosure describes embodiments, not every embodiment is provided with a separate embodiment, and that this description is provided for clarity only, and that the disclosure is not limited to the embodiments described in detail below, and that the embodiments described in the examples may be combined as appropriate to form other embodiments that will be apparent to those skilled in the art.

## Classifications

- B25B11/005
- B25B11/00

---

Generated by IPtorch. Verify legal conclusions against the official publication.
