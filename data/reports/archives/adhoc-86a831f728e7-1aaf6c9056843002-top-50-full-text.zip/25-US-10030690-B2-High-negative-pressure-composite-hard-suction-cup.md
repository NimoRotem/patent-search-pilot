# 25. High-negative-pressure composite hard suction cup

- **Archive rank:** 25 of 50
- **Publication:** [US-10030690-B2](https://patents.google.com/patent/US10030690B2/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/052867339/publication/US10030690B2?q=pn%3DUS10030690B2)
- **Publication date:** 2018-07-24
- **Filing date:** 2015-08-10
- **Earliest priority:** 2014-08-28
- **Family:** 52867339
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus

## Parties

- **Applicant / assignee:** XIAMEN NAILLESS TECH CO LTD
- **Inventors:** LIU JIANPING

## Abstract

The high-negative-pressure composite hard suction cup has a main member made of a hard, composite material tightly joined to a highly flexible washer made of soft plastic along a bottom side. The main member is configured with a vacuuming mechanism to another side. The vacuuming mechanism includes a piston chamber, one-way valve, piston assembly, and spring. A vacuum alarming assembly is configured on the piston assembly. When a degree of vacuum between the hard suction cup and an object attached is less than satisfactory, an audio or visual alarm is issued and an alert marking is revealed to notify a user to take appropriate action so that the hard suction cup remains reliably attached to the object.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-10030690-B2/000.png)

![Sketch 1 for US-10030690-B2](https://nimo.iptorch.com/refdrawing/US-10030690-B2/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/US-10030690-B2/001.png)

![Sketch 2 for US-10030690-B2](https://nimo.iptorch.com/refdrawing/US-10030690-B2/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/US-10030690-B2/002.png)

![Sketch 3 for US-10030690-B2](https://nimo.iptorch.com/refdrawing/US-10030690-B2/002.png)

## Claims

### Claim 1 (independent)

A suction cup, characterized in that: the suction cup has a main member made of a composite material joined to a flexible washer made of plastic along a bottom side of the main member; a vacuuming mechanism is mounted to another side of the main member; the vacuuming mechanism comprises a piston chamber, and a one-way valve, a piston assembly, and a spring, all inside the piston chamber; a vacuum alarming assembly is mounted on the piston assembly; a plurality of protruding ribs are mounted at an interface of the main member with the washer; the piston chamber surrounds a channel running vertically through the main member and connecting the inside of the piston chamber to outside of the main member; and the one-way valve is disposed above the channel.

### Claim 2

The hard suction cup according to claim 1 , characterized in that the piston assembly is supported by the spring and the piston assembly therefore is vertically moveable within the piston chamber; and the piston assembly comprises a piston body, a sealing ring on a bottom flange of the piston body, a button mounted on the piston body, a conductive ring configured on a bottom flange of the button, and an alert marking configured on a circumference of the button.

### Claim 3

The hard suction cup according to claim 2 , wherein the vacuum alarming assembly comprises a first conductive column, a second conductive column, two insulating elastic bodies, conductive wires, a battery, and an audio/visual indicator; the insulating elastic bodies are disposed oppositely in a chamber cap mounted on a top end of the piston chamber; the first and second conductive columns are embedded in the insulating elastic bodies, respectively, and are series-connected to the audio/visual indicator and the battery through the wires; and the contact or separation of the first and second conductive columns with or from the conductive ring closes or breaks a circuit involving the audio/visual indicator and the battery, therefore turning on or off the audio/visual indicator.

## Full description

### Background Of The Invention

**[p0001]**

(a) Technical Field of the Invention The present invention is generally related to parts for daily products and specialized tools, and more particular to negative-pressure suction cups. (b) Description of the Prior Art The present applicant filed a China patent application in 2010 whose patent no. is ZL201010003309.8, and the China patent disclosed a suction cup attachable to an airtight surface regardless of its flatness or smoothness. After production and practical application for four years, the present applicant noticed that there is still room for improvement for the suction cup with respect to its structure and material so as to enhance its production efficiency and yield. Through the employment of new technical structure and material art, the suction cup can be more reliable and safe during usage, in addition to its superior suction performance. Anew patent application is therefore filed.

### Summary Of The Invention

**[p0002]**

The present invention discloses a hard suction cup made of a composite material and capable of being formed into various shapes. In contrast to the conventional disc-shaped soft suction cup, the hard suction cup employs high negative pressure to improve the reliability of the attachment of the hard suction cup to an object. A highly flexible washer of the hard suction cup is significantly deformed under the high pressure, effectively enhancing the airtightness and friction between the hard suction cup and the object. The hard suction cup is therefore attachable to an airtight object surface regardless of its flatness and smoothness with enhanced weight bearing capability. When a degree of vacuum of the hard suction cup drops to a certain level, an alarm is issued to alert a user to take responsive action in restoring the required degree of vacuum so that the hard suction cup does not fall of from the object. The present invention involves the following technical means. The high-negative-pressure composite hard suction cup includes a main member, a highly flexible washer, protruding ribs, a piston chamber, a one-way valve, a spring, a piston assembly, a chamber cap, first and second conductive columns, insulating bodies, wires, a battery, an audio/visual indicator. The piston chamber, one-way valve, spring, and piston assembly jointly form a vacuuming mechanism. The piston assembly includes a piston body, a sealing ring, a button, a conductive ring, and an alert marking. The first and second conductive columns, insulating bodies, wires, a battery, and an audio/visual indicat

**[p0002]**

or jointly form a vacuum alarming assembly.

**[p0003]**

The high-negative-pressure composite hard suction cup has a main member tightly joined to a highly flexible washer of soft plastic along a bottom side of the main member. The main member is made of a hard, composite material and can be formed into various shapes. The washer is formed into a compatible shape. A number of protruding ribs are configured at an interface of the main member with the washer. A vacuuming mechanism is configured to another side of the main member and includes a piston chamber, and a one-way valve, a piston assembly, and a spring, all inside the piston chamber. The piston chamber surrounds a channel running vertically through the main member and connecting the inside of the piston chamber to outside of the main member; and the one-way valve is disposed above the channel. The piston assembly is supported by the spring and the piston assembly therefore is vertically moveable within the piston chamber. A vacuum alarming assembly is configured on the piston assembly. By using springs of different elasticity, various degrees of vacuum can be indicated and alarmed. The piston assembly includes a piston body, a sealing ring on a bottom flange of the piston body, a button mounted on the piston body, a conductive ring configured on a bottom flange of the button, and an alert marking configured on a circumference of the button. The conductive ring and the alert marking therefore move along the piston assembly. The vacuum alarming assembly includes a first conductive column, a second conductive column, two insulating elastic bodies, conductive wires, a battery,

**[p0003]**

and an audio/visual indicator. The insulating elastic bodies are disposed oppositely in a chamber cap mounted on a top end of the piston chamber. The first and second conductive columns are embedded in the insulating elastic bodies, respectively, and are series-connected to the audio/visual indicator and the battery through the wires. The contact or separation of the first and second conductive columns with or from the conductive ring closes or breaks a circuit involving the audio/visual indicator and the battery, therefore turning on or off the audio/visual indicator.

**[p0004]**

The foregoing objectives and summary provide only a brief introduction to the present invention. To fully appreciate these and other objects of the present invention as well as the invention itself, all of which will become apparent to those skilled in the art, the following detailed description of the invention and the claims should be read in conjunction with the accompanying drawings. Throughout the specification and drawings identical reference numerals refer to identical or similar parts. Many other advantages and features of the present invention will become manifest to those versed in the art upon making reference to the detailed description and the accompanying sheets of drawings in which a preferred structural embodiment incorporating the principles of the present invention is shown by way of illustrative example.

### Brief Description Of The Drawings

**[p0005]**

FIG. 1 is a schematic sectional diagram showing a hard suction cup according to an embodiment of the present invention before usage. FIG. 2 is a schematic sectional diagram showing the hard suction cup of FIG. 1 during usage.

### Detailed Description Of The Preferred Embodiments

**[p0006]**

The following descriptions are exemplary embodiments only, and are not intended to limit the scope, applicability or configuration of the invention in any way. Rather, the following description provides a convenient illustration for implementing exemplary embodiments of the invention. Various changes to the described embodiments may be made in the function and arrangement of the elements described without departing from the scope of the invention as set forth in the appended claims. As shown in FIG. 1 , a high-negative-pressure hard suction cup according to the present invention is made of a hard, composite material and is capable of attaching to an object&#39;s airtight surface regardless of the smoothness and flatness of the surface. The hard suction cup includes a main member 1 and a highly flexible washer 2 made of soft plastic. The washer 2 is tightly joined to a bottom side of the main member 1 . At an interface of the main member 1 with the washer 2 , a number of protruding ribs 3 are configured. The ribs 3 press and deform the washer 2 , and may even embed into recesses on the object, thereby forming multiple rings of sealing, completely blocking air conduction between the inside and outside of the hard suction cup, and securing a high degree of vacuum inside the hard suction cup. The hard suction cup further include a vacuuming mechanism configured on another side of the main member 1 oppositely to the washer 2 . The vacuuming mechanism includes a cylindrical piston chamber 4 , a one-way valve 6 , a piston assembly, a spring 7 , and a chamber cap 13 . The piston ch

**[p0006]**

amber 4 surrounds a channel 5 running vertically through the main member 1 and connecting the inside of the piston chamber 4 to outside of the main member 1 . The one-way valve 6 is configured inside the piston chamber 4 above the channel 5 . The spring 7 is configured inside the piston chamber 4 and surrounds the one-way valve 6 . The chamber cap 13 is disposed at a top end of the piston chamber 4 .

**[p0007]**

The piston assembly is configured in the piston chamber 4 and is supported by the spring 7 . The piston assembly therefore is vertically moveable within the piston chamber 4 under the confinement of the chamber cap 13 through the elasticity of the spring 7 . The piston assembly includes a piston body 8 having an M-shaped section, a sealing ring 9 on a bottom flange of the piston body 8 , and a button 10 mounted on the piston body 8 . A conductive ring 11 is configured on a bottom flange of the button 10 , and an alert marking 12 is configured on a circumference of the button 10 . The hard suction cup further includes a vacuum alarming assembly. The vacuum alarming assembly includes a first conductive column 14 , a second conductive column 15 , two insulating elastic bodies 16 , conductive wires 17 , a battery 19 , and an audio/visual indicator 18 . The insulating elastic bodies 16 are disposed oppositely in the chamber cap 13 . The first and second conductive columns 14 and 15 are embedded in the insulating elastic bodies 16 , respectively, and are series-connected to the audio/visual indicator 18 and the battery 19 through the wires 17 . The contact or separation of the first and second conductive columns 14 and 15 with or from the conductive ring 11 closes or breaks a circuit involving the audio/visual indicator 18 and the battery 19 , therefore turning on or off the audio/visual indicator 18 .

**[p0008]**

As shown in FIG. 2 , to put the hard suction cup into use, the hard suction cup is attached to an object&#39;s surface. The button 10 is depressed and the piston assembly is moved as well. The air between the object and the hard suction cup is pressurized to flow away through the gap between the sealing ring 9 and the piston chamber 4 , thereby achieving a high degree of vacuum. After releasing the button 10 , the spring 7 restores the piston assembly. Negative pressure is produced between the hard suction cup and the object, and the two are as such tightly pressed together. When the button 10 is depressed and the piston assembly is moved again, the negative pressure within the piston chamber 4 is reduced, and the one-way valve 6 closes the channel 5 . The pressurized air in the piston chamber 4 again flows through the gap between the sealing ring 9 and the piston chamber 4 , and the degree of vacuum within the piston chamber 4 is further enhanced. After releasing the button 10 , the spring 7 again restores the piston assembly. The one-way valve 6 opens the channel 5 , the degree of vacuum within the piston chamber 4 and the degree of vacuum between the hard suction cup and the object reach a balance. By repeating the above operation multiple times, the degree of vacuum between the hard suction cup and the object would be again and again enhanced, until the resilience of the spring 7 cannot restore the piston assembly under the atmospheric pressure on the piston assembly. At the moment, the conductive ring 11 on the piston assembly is separated from the first and second con

**[p0008]**

ductive columns 14 and 15 , breaking up the circuit between the audio/visual indicator 18 and the battery 19 . When some amount of air permeates into the piston chamber 4 and the degree of vacuum drops, the resilience of the spring 7 gradually restores the piston assembly until the conductive ring 11 touches the first and second conductive columns 14 and 15 . The circuit between the audio/visual indicator 18 and the battery 19 is closed and the audio/visual indicator 18 issues audio or visual alarm. In the meantime, the alert marking 11 is also exposed. At this moment, there is still some degree of vacuum between the hard suction cup and the object, and the hard suction cup does not fall off. Through the audio or visual alarm, a user is alerted to depress the button 10 multiple times to restore a high degree of vacuum between the hard suction cup and the object.

**[p0009]**

While certain novel features of this invention have been shown and described and are pointed out in the annexed claim, it is not intended to be limited to the details above, since it will be understood that various omissions, modifications, substitutions and changes in the forms and details of the device illustrated and in its operation can be made by those skilled in the art without departing in any way from the claims of the present invention.

## Figure captions

- **Figure 1:** FIG. 1 is a schematic sectional diagram showing a hard suction cup according to an embodiment of the present invention before usage.
- **Figure 2:** FIG. 2 is a schematic sectional diagram showing the hard suction cup of FIG. 1 during usage.

## Classifications

- F16B47/00
- F16B47/00
- F16B47/00
- A47G29/087
- A47G29/087
- A47G29/087
- A47G29/087
- F16B47/00
- G01M3/26
- G01M3/26
- G01M3/26
- G08B5/22
- G08B5/22
- G08B5/22

## Cited patent documents

- [US-2006231705-A1](https://patents.google.com/patent/US20060231705A1/en) — SEA
- [US-2012112023-A1](https://patents.google.com/patent/US20120112023A1/en) — SEA
- [US-2014027588-A1](https://patents.google.com/patent/US20140027588A1/en) — SEA
- [US-3759560-A](https://patents.google.com/patent/US3759560A/en) — SEA
- [US-3970341-A](https://patents.google.com/patent/US3970341A/en) — SEA
- [US-5184858-A](https://patents.google.com/patent/US5184858A/en) — SEA
- [US-5795001-A](https://patents.google.com/patent/US5795001A/en) — SEA
- [US-7475860-B2](https://patents.google.com/patent/US7475860B2/en) — SEA
- [US-7665706-B2](https://patents.google.com/patent/US7665706B2/en) — SEA
- [US-7673914-B2](https://patents.google.com/patent/US7673914B2/en) — SEA
- [US-8104809-B1](https://patents.google.com/patent/US8104809B1/en) — SEA
- [US-9057398-B2](https://patents.google.com/patent/US9057398B2/en) — SEA
- [US-9581291-B2](https://patents.google.com/patent/US9581291B2/en) — SEA

---

Generated by IPtorch. Verify legal conclusions against the official publication.
