# 47. Vacuum lift device

- **Archive rank:** 47 of 50
- **Publication:** [US-2942745-A](https://patents.google.com/patent/US2942745A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/025100570/publication/US2942745A?q=pn%3DUS2942745A)
- **Publication date:** 1960-06-28
- **Filing date:** 1958-11-17
- **Earliest priority:** 1958-11-17
- **Family:** 25100570
- **Text status:** source text incomplete — use the office links above
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** YALE & TOWNE MFG CO

## Abstract

_No abstract was available from the queried sources._

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-2942745-A/000.png)

![Sketch 1 for US-2942745-A](https://nimo.iptorch.com/refdrawing/US-2942745-A/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/US-2942745-A/001.png)

![Sketch 2 for US-2942745-A](https://nimo.iptorch.com/refdrawing/US-2942745-A/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/US-2942745-A/002.png)

![Sketch 3 for US-2942745-A](https://nimo.iptorch.com/refdrawing/US-2942745-A/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/US-2942745-A/003.png)

![Sketch 4 for US-2942745-A](https://nimo.iptorch.com/refdrawing/US-2942745-A/003.png)

[Sketch 5](https://patentimages.storage.googleapis.com/06/8d/e2/caba89a98ed7ff/US2942745-drawings-page-1.png)

![Sketch 5 for US-2942745-A](https://patentimages.storage.googleapis.com/06/8d/e2/caba89a98ed7ff/US2942745-drawings-page-1.png)

[Sketch 6](https://patentimages.storage.googleapis.com/8d/20/97/21471fa330fd7c/US2942745-drawings-page-2.png)

![Sketch 6 for US-2942745-A](https://patentimages.storage.googleapis.com/8d/20/97/21471fa330fd7c/US2942745-drawings-page-2.png)

[Sketch 7](https://patentimages.storage.googleapis.com/a8/8e/3a/529e3ac77c08cc/US2942745-drawings-page-3.png)

![Sketch 7 for US-2942745-A](https://patentimages.storage.googleapis.com/a8/8e/3a/529e3ac77c08cc/US2942745-drawings-page-3.png)

[Sketch 8](https://patentimages.storage.googleapis.com/d4/7c/56/df0e7b9386badb/US2942745-drawings-page-4.png)

![Sketch 8 for US-2942745-A](https://patentimages.storage.googleapis.com/d4/7c/56/df0e7b9386badb/US2942745-drawings-page-4.png)

## Claims

_Claims were not available from the queried sources._

## Full description

**[p0001]**

PERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGHOISTING, LIFTING, HAULING OR PUSHING, NOT OTHERWISE PROVIDED FOR, e.g. DEVICES WHICH APPLY A LIFTING OR PUSHING FORCE DIRECTLY TO THE SURFACE OF A LOADDevices for lifting or lowering bulky or heavy goods for loading or unloading purposesDevices for lifting or lowering bulky or heavy goods for loading or unloading purposes movable, with their loads, on wheels or the like, e.g. fork-lift trucksConstructional features or detailsPlatforms; Forks; Other load supporting or gripping membersLoad gripping or retaining meansLoad gripping or retaining means by suction means Description June 28, 1960 Filed Nov. 1'7. 1958 E. A. HORTON VACUUM LIFT DEVICE 4 Sheets-Sheet 1 I NV EN TOR. 54; 14. flogrv y June 28, 1960 E. A. HORTON 2, VACUUM LIFT DEVICE Filed Nov. 17, 1958 4 Sheets-Sheet 2 IIIII ll Tali- Z. INVENTOR. [AQL A. HaQra/y ATTOQNEY June 28, 1960 Filed Nov. 17, 1958 E. A. HORTON VACUUM LIFT DEVICE 4 Sheets-Sheet 3 INV ENT OR. 644.. A. HoQrO Y WIQM ArTo /vev June 28, 1960 E. A. HORTON 2,942,745

**[p0002]**

VACUUM LIFT DEVICE Filed Nov. 17, 1958 4 Sheets-Sheet 4 1N VENTOR. [4191. A. Hog ro- United States Patent VACUUM LIFT DEVICE Earl A. Horton, Philadelphia, Pa, assignor to The Yale and Towne Manufacturing Company, Stamford, Conn., a corporation of Connecticut Filed Nov. 17, 1958, Ser. No. 774,215 6 Claims. (Cl. 214-650) This invention relates to an industrial truck, and, more particularly, to an industrial truck equipped with an attachment by which loads may be gripped and lifted through the medium of a vacuum cup or vacuum cups. It is old in the art to lift loads by the application of vacuum cups to surfaces of the loads, but so far as I know, it has never been possible to bring about automatically a gripping of a load upon the movement of the truck toward the load. Thus, those skilled in the art will appreciate that industrial trucks must be operated at a very high speed and with a minimum of operator control, particularly during that portion of the cycle when the load is accepted by the truck and that portion of the cycle when the load is deposited by the truck. My invention has for its particular purpose the contribution of means that make possible the acceptance of a load by vacuum cups without exact and complicated maneuvering of the truck relatively to the load, and for automatic deposit of the load or removal'of the load from the truck.

**[p0003]**

My invention is particularly important where a stack of cartons are to be elevated through first being gripped by a series of vacuum cups. Obviously, the application of various vacuum cups to a stack of cartons, and the application of vacuum to the vacuum cups, would in such a situation require considerable manipulation of the truck and considerable manipulation of complicated controls. As a feature of my invention, I apply to each of one or more vacuum cups a control whereby vacuum is applied to the cup only when the cup is in a position to grip the surface of a load. As a further feature of the invention, the vacuum cup is normally cut off from communication with the vacuum source on the truck, and is automatically placed in communication with the vacuum source only when the control detects the imme diate presence of a carton to be gripped. More particularly, the control actuates a valve that opens a path between the cup and the vacuum source as the cup approaches a carton. For this purpose, the control has means for detecting the presence of a carton opposite the cup as the truck is maneuvered towards the carton to be gripped.

**[p0004]**

As a further control feature of my invention, I apply between the source of vacuum pressure and each of the vacuum cups, a valve which is preferably solenoid operated, and that is normally positioned in a vacuum path between the vacuum cups and controls and the source of vacuum. Naturally, none of the vacuum will be used except when a vacuum cup is applied to a carton to be lifted because of the control at each cup. However, to release the cartons that have been lifted, operation of the solenoid breaks the vacuum path between the cups and the vacuum source, and as a matter of further improvement, places the vacuum cups in communication with the atmosphere, thereby immediately releasing the load. Because of the particular arrangement, it is obvious that all of the cartons gripped by a series of vacuum cups will be released simultaneously. However, each of the cartons will be individually gripped in the order in which it is contacted by its particular vacuum cup, since the vacuum at each cup is controlled by the control mechanism at that cup. Therefore, the lifting is orderly and in sequence as each cup contacts its carton during the part of the load handling cycle when the load is being accepted by the truck. At the same time, the entire load comprising a stack of cartons is releasedat one time, and this is of extreme importance during the part of the cycle when the load is freed from the truck.

**[p0005]**

As a still further feature of my invention, I provide a back-up plate that is adjustable vertically and that serves as a bearing surface for the lower part of a carton that has been lifted. Since it is desirable from the point of view of stability to grip the cartons at the highest part thereof that is possible, there will be a tendency for the cartons to rotate relatively to the truck to bring the lower part of the cartons toward the truck and the upper part away from the vacuum cup. To overcome this tendency, the back-up plate is manually adjusted by the operator before he commences to handle a particular group of cartons so that the plate will be in a position to resist the tendency of the cartons to rotate when lifted. I have thus outlined rather broadly the more important features of my invention in order that the detailed description thereof that follows may be better understood, and in order that my contribution to the art may be better appreciated. There are, of course, additional features of my invention that will be described hereinafter and which will form the subject of the claims appended hereto. Those skilled in the art will appreciate that the conception on which my disclosure is based may readily be utilized as a basis for the designing of other structures for carrying out the several purposes of my invention. It is important, therefore, that the claims be regarded as including such equivalent constructions as do not depart from the spirit and scope of my invention, in order to prevent the appropriation of my invention by those skilled in the art.

**[p0006]**

A specific embodiment of the invention has been chosen for purposes of illustration and description, and is shown in the accompanying drawings. In the drawings: Fig. 1 is a side view, partly broken away, of the load carrying end of an industrial truck equipped with an attachment in accordance with my invention and showing an upper vacuum cup in elevated position in full lines, and in lowered position in broken lines, with the vacuum cups gripping a carton; Fig. 2 is a front view,- partly broken away, of the structure shown in Fig. 1; Fig. 3 is a cross-sectional view taken along the lines 33 of Fig. 1; Fig. 4 is a side view of a suction cup and its control, the control being illustrated in several positions; Fig. 5 is a rear view taken along the lines 5-5 of Fig. 4; and Fig. 6 is a schematic view of an entire vacuum producing and control system, illustrating one vacuum cup about to grip a carton, and one cup already gripping a carton. Referring now to the drawings, and more particularly to Fig. 1 thereof, there is shown a portion of the main frame of an industrial truck T partly supported on front wheel 10. The truck may be equipped with a pair of primary uprights 11, a tilt device 12 for tilting the uprights forwardly and rearwardly, and secondary uprights 14 in the form of I beams, as best seen in Fig. 3.

**[p0007]**

In order that the secondary uprights may be movable vertically relatively to the primary uprights, rollers 15 are pivoted on the secondary upright and extend into the inner-channels "of theiuprights to bear against t-hefianges-of these channels for --guiding-the movement of the secondary uprights. 'To support; my vacuum lift device for vertical movement relatively, tothesecondary uprightsjl providea carria'ge plate 16.thatis;provide'd with rearwardly ext'endin'g brackets 17. These brackets pivotally support rollers l9 that extend into the inner channels of thesecondary u rights and bear against'the flanges of-those uprightsto guidethe vertical movement'o'fthe carriage *plate relatively' to the secondary-uprights. V i 1 It is-not necessary to show thepower means formoving the secondary uprights or the carriage plate since such 'means-are already well known to those persons skilledin theart and constituteon part of the presentinvention'. 'It will also be appreciated that, if desired, the carriage platecould support a known' side shifting or swinging mechanism so that my vacuumlift device could be shifted or swung laterally relatively to the uprights.

**[p0008]**

the vertical openings'zdforconnection to the bars 25. l 26but welded tothe tubes 22, as shown in Fig.2. 7 ,From the description thus -far,itwill be seen that the also provide a Secondiransverse plate 27, similar to'plate .tubes 22 are integrally connected through the upper and lower: angle members 21 and 22 to the carriage plate 16 for vertical movement with the carriage plate. lt will =also "be.seenthat the bars25, the plate 26 and'the cross piece'l28comprisea frame 30'that is movable vertically underzthe guidance of the verticalwtube's '22, while the. plate 27 isintegral .with thetubes 22. Inorderto controlmovement ofthe frame 30, I provide ahydrauliciram 31Tthat' is pivotally supported atth'e' center of the lower angle member 21 byabracket 32; The ram cylinder extends upwardly "through the horizontal flange ofthe upper angle .member20that is reeessed'for pecans. r the rear surface of the plates 26 and 27 at one end, and "against the flanges of the'spacers at the other end. vAs I have already stated, when the cups grip Cartons and lift them, there will be a tendency for the cartons to rotate relatively to the truck to bring the lower part of ,the cartons toward the truck and the upper part away from the vacuum cup gripping it. The heavier springs 49 will resist any tendency toward forward movement of the cups due to this rotational effect, and-the lighter springs 47 permit the cups to readily seek-their own position against the cartons vthey .grip;

**[p0009]**

' In order to provide furthenassurance thatthe-partons will not rotate, I provide a vertically adjustable back plate 50 (-Figs. 1 to 3). The-back plate 50 comprises a cross piece 51 that lweld to the lower ends of a pair of vertically disposed tubes 52. As best shown in Fig. 3, these tubes 52 are generally 'G-shaped in cross section and are mounted for guided vertical movement about the exterior of tubes 22. 'Gussettplates 54 arewelded tothe tubes :52 and cross piece 51 to add rigidity to-the back plate. For the purpose of retaining the" back plate in various adjusted positions, I provide'the tubes 22with'a series of vertically spaced holes55 '(Fig. 2),-and 'I pro- .vide a hole 56 in the tube 52. Theh'ole-Sdis placedso as to register with one of the holes 55 dependingupon the position ofthe back plate. A pin 57- passes. through the hole 56 anditsr'egisteiinghole-SS to retain theback platein its adjusted position. While I' have described means for retaining the back plate in the position to :Which it has been manually adjusted, it will be understood .that 'my basic concept includes 'othermeans of-- vertical adjustment: such as by hydraulic ram, for example.

**[p0010]**

that purpose, and through a" reinforcing plate"34-welded to the angle member 20. As mentioned heretofore' the bracket 35 drrthecross piece 28; As the ram is extended, the :framej!) will move upwardly,the bars 25 sliding in .tubes 22, and as the ram is retracted theifi'ame-will the cups .are mounted identically on both platesflfshall 'transversetplates26.and'.27-areibent at their central'porp :tions to provide room for. the ram to'pass b'ehindthem'. lihetupperzend .of :the ram piston rod is pivoted-to e. only :idescribe'themounting of the cups oni the 'upper plate 26, a1 1d for this purpose l shall refer to Fig-'3 V Thecups '36: maybe formed'of any suitable material, such' as rubber, and have rear walls 37 andfofWaIdly. -formed preferably with four rearwardly projecting bosses 41. 'I 'then provide a spacer 42 formed with a throu'gh' bore'44 and an annular flange 45 for e ac h b oss. fjThe spacers extend through suitable aperture's 46 in the'plate to. ear a ains h platesfafl .at, n end and. aga

**[p0011]**

theplateszfi andj2'liatftheiothercfid. Lplace a se cond, heaiziert spri g; 4a ,around each spacer; 42. to bear against' extending peripheral lip's' 59. "As shown inFig.-'3,' ;the 'rearwalls 37 are bonded-to metalplate's wearers each I-shall .now describe the vacuum systemaand control means by which I enable the cups 36 to grip and release .a load. For this purpose referencejwillfirst be had to Fig. 6. I-provideonthe truck T a sourceof -electrieal power"60;and an electricmotor 61in driven relation to the source. Since I have chosen to represent'mypower source 60as-anelectric batte y,fI provide a conduit 62 :from one terminal -i of the source 60 to one 0f the .motortermin als. second conduit 4- extends between the .opposed battery terminal "and the opposed motor terminal, 'andthis conduit includes the normally open main 'co'ntrolswitch 65, and-apressure switch 66. place a vacuum pump 67in drivenengagement with the motor 61. A vacuum line 69 leading fromlthe pump is conected to avacuum tank 70 after which it passes 'througha- Tzconnection 71- 'to acheckvalveflZ. Qhe side of the T connection leads toa-vacuutn -gauge 74 and; the pressure switch '66. a V l After passing thecheck valve 72, iche-vacuum line 69 :is branched through -T connections 75 into" a number of secondary. vacuum lines'76- equal to the number of vacuum-cups to be employed on-the particularvacuum -lift device. i i

**[p0012]**

Since each of the secondaryivacuum lines includes the cup. control-=thatwilI later be" described. A yalve mem- -ber 82 is slidable within the chamber 77 andhas a portionof reduced fdiameter sordisposed that this -memb e r normally closes -cond1iit seam permits communication between conduits 76 and -81. Upon sliding movement- 9f the valve member 8210 a the right as :viewed {Fig-'3. under control "chan electromagneticfsolenoid 84,f the 'conduitf76 is-closedand the-conduit 81 is .yented; to atmosphere through the conduit; 80. lUpongde-energiza- 'tion of the solenoid, a spring 8 5 returnsthe valve member toits normal positipn as shown. 7 IO Rroyide energy :for operation pflhe solenoid :84,- I/ connect anrelectric .conduit. 86,.betweenoueside of the solenoid 84.,and the conduitngthen otcnsideg the ma nr w tc i 6 -21 opposite side of the solenoid is connected through electric conduit 87 to conduit 62 or to the same side of source 60 to which conduit 62 is attached. A normally open switch 89 is provided in conduit 86 so that the solenoid is normally inactive.

**[p0013]**

The vacuum conduit 81 connects the chamber 77 of each valve 79 with a chamber 90 of a second valve 91. Each valve 91 is also provided with a vacuum conduit 92 that extends from the chamber 90 through the plate 40 and the vacuum cup 36 to the atmosphere. A valve member 94 in the chamber 90 is normally urged by a spring 95 in a direction to prevent communication between the conduits 81 and 92 so that the vacuum cannot reach the cup 36. As shown in Figs. 4 and 5, the valve member 94 extends beyond the chamber 90 and is connected through a pivot 96 to a link 97 that is connected through a lost motion pin and slotted sleeve connection 98 to a bell crank 99. A light spring 100 urges the slotted sleeve in a direction towards the bell crank. This bell crank is supported by a pivot 101 one bracket 102 on the rear surface of the plate 40. The free arm of the bell crank 99 extends forwardly past the vacuum. cup 36 and has a roller 103 mounted on its extremity. In operation, assuming that the cartons to be handled are stacked two cartons high, and that the particular vacuum lift device has two upper vacuum cups carried by plate 26 and two lower cups carried by plate 27, the operator first elevates the carriage plate 16 until the lower cups are just below the tops of the lower cartons. He then adjusts the back-up plate 50 downwardly until the cross piece 51 is opposite the lower part of the lower cartons. The upper cups are then elevated relatively to the lower cups by extension of the ram 31 until these cups are just below the tops of the upper cartons. v

**[p0014]**

The switch 65 is closed and the motor 61 operates the vacuum pump 67 to draw a vacuum in the vacuum system. The pressure switch 66 in the motor circuit automatically controls the operation of the motor to maintain the vacuum in the desired range. When sufficient vacuum is built up, the truck is driven towards the cartons C to be lifted. As the cups 36 approach the cartons, the rollers 103 first make contact causing the bell cranks 99 to rock on pivots 101 in a direction to take up the lost motion in the pin and slotted sleeve connection 98 until the roller reaches opening position, referred to as OP in Fig. 4. At this position valve member 94 is about to open communication between conduits 81 and 92. Further movement of the truck toward the cartons causes the valve member 94 to move in a direction against the force of spring 95 to establish communication between conduits S1 and 92 as shown on the right side of Fig. 6, as viewed. The roller is then in hold position referred to as HP in Fig. 4. In this way, the space in front of each cup 36 facing a carton is placed under vacuum and the carton is gripped by the adjacent cups.

**[p0015]**

Once all of the cartons to be handled in a particular load are gripped, the carriage plate may be elevated according to the height at which the load is to be deposited. It will be understood that, due to the'weight of the load, and the fact that gripping will usually occur eccentrically of the center of gravity of the load, there will be a tendency for the cartons to rotate in a manner to move their upper portions away from the cups and their lower portions towards the truck. Such tendencies are resisted by the heavy springs 49 behind the plates 26 and 27, and by the back-up plate that provides a surface against which the lower part of the load may bear. When the load has been transported to the place of deposit and it is desired to release the cartons, the operator closes the switch 89, thereby energizing the solenoids 84 and drawing the valve members toward the right, as viewed in Fig. 6, to close the vacuum conduit 76 and open the conduit 81 to atmosphere through the conduit 80. The vacuum in the space in front of the cups will thus be broken and the cartons released.

**[p0016]**

From the foregoing description, it will be seen that I have contributed to the art means that make possible the acceptance of a load by vacuum cups without exact and complicated maneuvering of the truck relatively to the load, and for automatic deposit of the load or removal of the load from the truck. It will also be seen that by means of my invention, I am able to apply a vacuum automatically only to those cups that are in a position relatively to a load to grip the load. I believe that the construction and operation of my novel vacuum lift device will now be understood, and that the advantages of my invention will be fully appreciated by those persons skilled in the art. I now claim: 1. In a truck of the class described, a carriage mounted for vertical lifting movement, a series of vacuum cups mounted on said carriage, a vacuum source on said truck communicating with all of said vacuum cups, separate means for each vacuum cup for normally closing communication between each vacuum cup and said vacuum source, separate control means carried by said carriage adjacent each vacuum cup movable by physical contact with a particular surface to be gripped by a vacuum cup upon movement of said truck toward a plurality of such surfaces to operate said means and establish communication between its respective vacuum cup and said vacuum source whereby each vacuum cup grips its particular surface in sequence as said cups contact said surfaces, and means for breaking simultaneously the communication between said vacuum source and all of said cups.

**[p0017]**

2. In a truck of the class described, a carriage mounted for vertical lifting movement, a series of vacuum cups mounted on said carriage, a vacuum source on said truck communicating with all of said vacuum cups, separate means for each vacuum cup for normally closing communication between each vacuum cup and said vacuum source, separate control means carried by said carriage adjacent each vacuum cup movable by physical contact with a particular surface to be gripped by a vacuum cup upon movement of said truck toward a plurality of such surfaces, means whereby each control means upon such movement establishes communication between its respective vacuum cup and said vacuum source whereby each vacuum cup grips its particular surface in sequence as said cups contact said surfaces, and means for breaking simultaneously the communication between said vacuum source and all of said cups. 3. In a truck of the class described, a carriage mounted for vertical lifting movement, a series of vacuum cups mounted on said carriage, a vacuum source on said truck communicating with all of said vacuum cups, a separate valve for each vacuum cup normally closing communication between each vacuum cup and said vacuum source, separate control means for each vacuum cup movable by physical contact with a particular surface to be gripped by said vacuum cup upon movement of said truck toward a plurality of such surfaces, means whereby each control means upon such movement operates one of said valves to establish communication between its respective vacuum cup and said vacuum source whereby each vacuum

**[p0017]**

cup grips its particular surface in sequence as said cups contact said surfaces, and means for breaking simultaneously the communication between said vacuum source and all of said cups.

**[p0018]**

4. In a truck of the class described, a carriage mounted for vertical lifting movement, a series of vacuum cups mounted on said carriage, a vacuum source on said truck communicating with all of said vacuum cups, a separate valve for each vacuum cup normally closing communication between each vacuum cup and said vacuum source, separate control means for each vacuum cup being movable by physical contact with a particular surface to be gripped by said vacuum cup upon movement of said :7 trucktoward a plurality of such surfaces, means whereby each control means upon such movement operates one of said valvesto establish communication between its respective vacuum cup and saidvacuum source whereby each vacuum cup grips its particular surface in sequence as said cups contact said surfaces, and electromagnetic valve means ifor simultaneously closing commumcation between said vacuum'source and all of said cups and I venting said cupsto atmosphere. 7 .5. In a truck of the class d e'scribed, a carriage mounted for vertical lifting movement, aseries of vacuum cups V mount ed in verticallyjspaced relation onlsaid carriage, V a vac'uum source on said truck communicating with all l t s'aid vacuum cups, separate means forcach vacuum cup for normally closin g communication between each vacuum cup and said'va'cuum source,-separate control 'means carried by said carriage movable by physical conte wit a'pa cul l fac g by e c vacuum cup upon movement of said truck toward a plu- ,r y at u h, sn iasss' mea h re ea sostr means, upon such movement establishes communication i'bctween'its respective

**[p0018]**

vacuum cup and said vacuum source whereby each vacuum cu p grips its 7 particular surface in sequence as said cups contact said surfaces, means for breaking simultaneously the communicationbetween said vacuum sourceand all of s aid cups, and'means adjustable vertically below the lowest of said vacuum cups to provide a bearing for the lower portion of 'saidfsurfaces ,to be gripped by said lowest vacuum "cups fo r accepting forces tending lto rotate said surfaces V f "6. In a truck of the class described, a carriage mounted for vertical lifting movement, a series bfvacuunfcups mounted on said carriage, a vacuum source on said truck communicating withall of said vacuum cups, separate means for each vacuum cup for normally closing 'co'm- 2,049,850 Lytle eta]. V Aug. 4, 1936 2,675,153 Weimer Apr. 13, 1954 V 5 2,708,046

**[p0019]**

Cusham May 10, 1955

## Classifications

- B66F9/181
- B66F9/181

## Cited patent documents

- [US-2049850-A](https://patents.google.com/patent/US2049850A/en) — SEA
- [US-2675153-A](https://patents.google.com/patent/US2675153A/en) — SEA
- [US-2708046-A](https://patents.google.com/patent/US2708046A/en) — SEA

---

Generated by IPtorch. Verify legal conclusions against the official publication.
