# 34. Vacuum operated lifting device

- **Archive rank:** 34 of 50
- **Publication:** [GB-2337982-A](https://patents.google.com/patent/GB2337982A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/010831811/publication/GB2337982A?q=pn%3DGB2337982A)
- **Publication date:** 1999-12-08
- **Filing date:** 1998-05-12
- **Earliest priority:** 1998-05-12
- **Family:** 10831811
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** WATSON PAUL
- **Inventors:** WATSON PAUL

## Abstract

A lifting beam for picking up sheets by suction has all the necessary controls provided on it, can be connected to a hoist or the forks of a fork lift truck and is battery operated to avoid the need to connect to any external power source. Preferably, control and non-return valves and vacuum sensors are provided.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/GB-2337982-A/pdf000.png)

![Sketch 1 for GB-2337982-A](https://nimo.iptorch.com/refdrawing/GB-2337982-A/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/GB-2337982-A/pdf001.png)

![Sketch 2 for GB-2337982-A](https://nimo.iptorch.com/refdrawing/GB-2337982-A/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/GB-2337982-A/pdf002.png)

![Sketch 3 for GB-2337982-A](https://nimo.iptorch.com/refdrawing/GB-2337982-A/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/GB-2337982-A/pdf003.png)

![Sketch 4 for GB-2337982-A](https://nimo.iptorch.com/refdrawing/GB-2337982-A/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/GB-2337982-A/pdf004.png)

![Sketch 5 for GB-2337982-A](https://nimo.iptorch.com/refdrawing/GB-2337982-A/pdf004.png)

## Claims

### Claim 1 (independent)

Claims (3) A PORTABLE LIFTING BEAM UTILIZING VACUUM LIFTING FORCE TO ACHIEVE LIFTING VIA FORKLIFT TRUCK OR HOIST.

### Claim 2

A PORTABLE LIFTING BEAM AS CLAIMED IN CLAIM 1) UTILIZING 12/24 VDC PORTABLE POWER TO PROVIDE AN INDEPENDANTLY POWERED SYSTEM REQUI1;tING NO ELECTRICAL CONNECTION OR CABLING.

### Claim 3

A PORTABLE LIFTING BEAM AS CLAIMED IN CLAIM 1) UTILIZING A COMBINATION OF VACUUM SWITCHING TO ENSURE CONTINUOUS OPERATION WITHIN A 10 HOUR WORKING DAY 4) A PORTABLE LIFTING BEAM AS CLAIMED IN CLAIM 1) UTILIZING A DC POWERED VACUUM PUMP AND NON RETURN VALVES TO ENSURE SAFETY FACTOR OF MINIMUM 2.2

## Full description

**[p0001]**

PERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGHOISTING, LIFTING, HAULING OR PUSHING, NOT OTHERWISE PROVIDED FOR, e.g. DEVICES WHICH APPLY A LIFTING OR PUSHING FORCE DIRECTLY TO THE SURFACE OF A LOADDevices for lifting or lowering bulky or heavy goods for loading or unloading purposesDevices for lifting or lowering bulky or heavy goods for loading or unloading purposes movable, with their loads, on wheels or the like, e.g. fork-lift trucksConstructional features or detailsPlatforms; Forks; Other load supporting or gripping membersLoad gripping or retaining meansLoad gripping or retaining means by suction meansPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansOperating and control devices

**[p0002]**

Description BATLIFT' DESCRIPTION 2337982 THIS INVENTION RELATES TO A BATLIEFT - BATTERY OPERATED VACUUM LIFTLNG BEAM. USERS OF STEEL/ALLOY PLATES & SHEETS FREQUENTLY EMPLOY A FORKLIFT TRUCK FOR GENERAL HANDLING OF PLATE/SHEET MATERIALS. THE MAIN DRAW BACK OF THE FORKLIFT IS THAT FORKS HAVE TO BE APPLIED TO THE UNDERSIDE OF THE MATERIAL BEING LIFTED, OFTEN CAUSING DAMAGE AND NECESSITATING USE OF WOODEN SPACERS OR SIMILAR TO ALLOW FORK ACCESS. ACCORDING TO THE PRESENT INVENTION WE PROVIDE A STRUCTURAL LIFTING BEAM/RESERVOIER COMBINATION EQU1PPED WITH 2 OFF SUCTION PADS AND VACUUM PUMP. THE BEAM IS PROVIDED WITH 2 OFF FORK SHOES FOR LOCATING OF FORK LIFT TRUCK FORKS. A SPECIFIC EMBOD1EMENT OF THE INVENTION WILL NOW BE DESCRIBED BY WAY OF EXAMPLE WITH REFERENCE TO THE ACCOMPANYING DRAWING ENTITLED' BATLIFT TYPE 500' THE DRAWING SHOWS A SQUARE STRUCTURAL SECTION RESERVOUPLIBEAM WITH BATTERY PACK/ PUMPISENSORS AND ALL OTHER COMPONENTS MOUNTED ON THE SYSTEM. 2 OFF SUCTIONPADS ARE ALSO MOUNTED ON THE UNIT.

**[p0003]**

THE BATLI1FT IS SWITCHED ON VIA INTEGRAL CONTROL PANEL AND THE VACUUM PUMP THEN STARTS TO EVACUATE AIR FROM THE RESERVOIR. THE VACUUM LEVEL IS MONITORED BY 2 OFF VACUUM SWITCH WHICH ENSURES ADEQUATE RESERVOIR VACUUM PRIOR AND DURING OPERATION. ONCE ADEQUATE VACUUM IS ACHIEVED THE RED WARNING INDICATOR LOCATED ON TOP OF THE CONTROL BOX WILL STOP FLASHING THE UNIT IS NOW READY FOR USE. THE FORK LIFT OPERATOR LOCATES HIS FORKS INSIDE THE FORK SHOES AND TIGHTENS THE RETAINING BOLTS LOCATED WITHIN THE FORK SHOES. THE BATLIFT IS NOW AN INTEGRAL EXTENSION OF THE'FORK LIFT FORKS AND THE OPERATOR PLACES THE LIFT BEAM ON THE PLATE/SKEET TO BE HANDLED - OPERATES THE CONTROL VALVE - VACUUM LIFTING FORCE IS THEN APPLED VIA THE 2 OFF V45145 SUCTION PADS ONTO THE TOP SURFACE OF THE TARGET PLATE/SHEET. THE OPERATOR THEN RAISES HIS FORKS AND THE PLATE/SHEET IS LIFTED. 2.

## Classifications

- B66F9/181
- B66C1/02
- B66C1/0256
- B66F9/18

## Cited patent documents

- [GB-1028065-A](https://patents.google.com/patent/GB1028065A/en) — SEA
- [GB-2232955-A](https://patents.google.com/patent/GB2232955A/en) — SEA
- [JP-H0762879-A](https://patents.google.com/patent/JPH0762879A/en) — SEA
- [US-4155583-A](https://patents.google.com/patent/US4155583A/en) — SEA
- [US-4685714-A](https://patents.google.com/patent/US4685714A/en) — SEA
- [US-5516254-A](https://patents.google.com/patent/US5516254A/en) — SEA
- [WO-9713718-A1](https://patents.google.com/patent/WO9713718A1/en) — SEA

---

Generated by IPtorch. Verify legal conclusions against the official publication.
