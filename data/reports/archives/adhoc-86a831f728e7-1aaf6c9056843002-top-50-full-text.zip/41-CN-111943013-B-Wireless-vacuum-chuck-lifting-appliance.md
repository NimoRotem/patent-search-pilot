# 41. Wireless vacuum chuck lifting appliance

- **Archive rank:** 41 of 50
- **Publication:** [CN-111943013-B](https://patents.google.com/patent/CN111943013B/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/073358797/publication/CN111943013B?q=pn%3DCN111943013B)
- **Publication date:** 2021-02-09
- **Filing date:** 2020-08-19
- **Earliest priority:** 2020-08-19
- **Family:** 73358797
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** 浙江玥耀起重机械有限公司

## Abstract

The invention provides a wireless vacuum chuck lifting appliance. The invention comprises a hanger shell, an object lifting sucker, a vacuumizing device and a power supply, wherein the vacuumizing device is used for exhausting air inside the object lifting sucker and is characterized in that: the hanger comprises a hanger shell, and is characterized in that a mounting opening is formed in the hanger shell, the power supply comprises a battery box provided with a storage battery, the battery box is clamped in the mounting opening, and the storage battery in the battery box is electrically connected with the vacuumizing device. Based on adopt detachable construction between battery case and the hoist shell, can be in advance with a plurality of battery casees that are full of the electricity, insert one of them battery case in the installing port of hoist shell, after the normal work a period, dismantle the battery case after will having used a period again, change new battery case, need not to carry out traditional shut down charging operation, use the convenience height.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-111943013-B/000.png)

![Sketch 1 for CN-111943013-B](https://nimo.iptorch.com/refdrawing/CN-111943013-B/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-111943013-B/001.png)

![Sketch 2 for CN-111943013-B](https://nimo.iptorch.com/refdrawing/CN-111943013-B/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/CN-111943013-B/002.png)

![Sketch 3 for CN-111943013-B](https://nimo.iptorch.com/refdrawing/CN-111943013-B/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/CN-111943013-B/003.png)

![Sketch 4 for CN-111943013-B](https://nimo.iptorch.com/refdrawing/CN-111943013-B/003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/CN-111943013-B/004.png)

![Sketch 5 for CN-111943013-B](https://nimo.iptorch.com/refdrawing/CN-111943013-B/004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/CN-111943013-B/005.png)

![Sketch 6 for CN-111943013-B](https://nimo.iptorch.com/refdrawing/CN-111943013-B/005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/CN-111943013-B/006.png)

![Sketch 7 for CN-111943013-B](https://nimo.iptorch.com/refdrawing/CN-111943013-B/006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/CN-111943013-B/007.png)

![Sketch 8 for CN-111943013-B](https://nimo.iptorch.com/refdrawing/CN-111943013-B/007.png)

[Sketch 9](https://patentimages.storage.googleapis.com/34/4c/1c/894060fb741919/HDA0002640353100000011.png)

![Sketch 9 for CN-111943013-B](https://patentimages.storage.googleapis.com/34/4c/1c/894060fb741919/HDA0002640353100000011.png)

[Sketch 10](https://patentimages.storage.googleapis.com/6d/02/90/ff8b390f416077/HDA0002640353100000021.png)

![Sketch 10 for CN-111943013-B](https://patentimages.storage.googleapis.com/6d/02/90/ff8b390f416077/HDA0002640353100000021.png)

[Sketch 11](https://patentimages.storage.googleapis.com/80/45/c6/c4dd4edbdbd800/HDA0002640353100000031.png)

![Sketch 11 for CN-111943013-B](https://patentimages.storage.googleapis.com/80/45/c6/c4dd4edbdbd800/HDA0002640353100000031.png)

[Sketch 12](https://patentimages.storage.googleapis.com/65/c1/c9/0981ed9fa15fff/HDA0002640353100000041.png)

![Sketch 12 for CN-111943013-B](https://patentimages.storage.googleapis.com/65/c1/c9/0981ed9fa15fff/HDA0002640353100000041.png)

[Sketch 13](https://patentimages.storage.googleapis.com/27/c3/b3/7d5454f7fda4a6/HDA0002640353100000051.png)

![Sketch 13 for CN-111943013-B](https://patentimages.storage.googleapis.com/27/c3/b3/7d5454f7fda4a6/HDA0002640353100000051.png)

[Sketch 14](https://patentimages.storage.googleapis.com/34/29/39/ee7d330ee1913d/HDA0002640353100000061.png)

![Sketch 14 for CN-111943013-B](https://patentimages.storage.googleapis.com/34/29/39/ee7d330ee1913d/HDA0002640353100000061.png)

[Sketch 15](https://patentimages.storage.googleapis.com/36/f9/06/54bf58e220c72e/HDA0002640353100000071.png)

![Sketch 15 for CN-111943013-B](https://patentimages.storage.googleapis.com/36/f9/06/54bf58e220c72e/HDA0002640353100000071.png)

[Sketch 16](https://patentimages.storage.googleapis.com/eb/3d/e5/9ce3f35a244004/HDA0002640353100000081.png)

![Sketch 16 for CN-111943013-B](https://patentimages.storage.googleapis.com/eb/3d/e5/9ce3f35a244004/HDA0002640353100000081.png)

## Claims

### Claim 1 (independent)

The utility model provides a wireless vacuum chuck hoist, includes hoist shell (1), carries thing sucking disc (2), evacuating device (3), power supply (5), evacuating device (3) are used for carrying thing sucking disc (2) inside to bleeding, characterized by: the hanger shell (1) is provided with a mounting port (4), the power supply (5) comprises a battery box (6) provided with a storage battery, the battery box (6) is clamped in the mounting port (4), and the storage battery in the battery box (6) is electrically connected to the vacuumizing device (3); the lifting appliance comprises a lifting appliance shell (1), a vacuum pumping device (3) and a lifting object sucker (2), wherein the lifting appliance shell (1) is provided with a connecting hole (7), the vacuum pumping device (3) is connected with the connecting hole (7) through an air pipe (8), the lifting object sucker (2) is fixed on the lifting appliance shell (1) through a screw (9), the lifting object sucker (2) is provided with a first air hole (10), and the first air hole (10) corresponds to and is communicated with the connecting hole (7); a sliding groove (13) is formed in the side wall, close to the object lifting sucker (2), of the lifting appliance shell (1), a sucker sliding block (26) is connected to the sliding groove (13) in a sliding mode, the connecting hole (7) is formed in the sucker sliding block (26), the object lifting sucker (2) is connected to the sucker sliding block (26), a positioning part (14) is arranged in the lifting appliance shell (1), and the positioning part (14) is used for pushing the sucker sliding block (26) to move to a specified position; be equipped with slot (15) on hoist shell (1), locating part (14) including set up first spring (141) in slot (15), slide and set up inserted block (142) in slot (15), first spring (141) are connected inserted block (142) in slot (15), first spring (141) are used for releasing slot (15) notch with the tip of inserted block (142), be equipped with first wedge face (143) on inserted block (142), be equipped with slider connecting piece (16) in spout (13), the both ends of slider connecting piece (16) are link (1611) and drive end (1711) respectively, link (1611) connect in sucking disc slider (26), be equipped with second wedge face (1612) on drive end (1711), second wedge face (1612) and first wedge face (143) offset contact.

### Claim 2

The wireless vacuum chuck sling according to claim 1, wherein: a filter screen (11) is arranged between the object lifting suction disc (2) and the side wall of the lifting appliance shell (1), and the filter screen (11) is arranged between the connecting hole (7) and the first air hole (10).

### Claim 3

The wireless vacuum chuck sling according to claim 2, wherein: the article lifting sucker (2) is provided with an accommodating groove (12) at the end face close to the filter screen (11), and the accommodating groove (12) is communicated with the first air hole (10).

### Claim 4

The wireless vacuum chuck sling according to claim 1, wherein: carry thing sucking disc (2) including laminate in sucking disc body (201) of hoist shell (1) lateral wall, set up sucking disc body (201) deviate from hoist shell (1) one side and with sucking disc body (201) integrated into one piece's ripple deformation section (202).

### Claim 5

The wireless vacuum chuck sling according to claim 1, wherein: the sliding block connecting piece (16) is divided into a left sliding block (161) and a right sliding block (171), a second spring (27) is connected between the left sliding block (161) and the right sliding block (171), the second wedge-shaped surface (1612) is arranged at the end of the left sliding block (161), and the connecting end (1611) is arranged at the end of the right sliding block (171); the lifting appliance is characterized in that a distance adjusting screw rod (18) is arranged on the lifting appliance shell (1), the distance adjusting screw rod (18) penetrates into the sliding groove (13), and the end part of the distance adjusting screw rod (18) is abutted to the side wall of the right sliding block (171).

### Claim 6

The wireless vacuum chuck sling according to claim 5, wherein: the sucker sliding block (26) is rotatably connected to the right sliding block (171), a fluted disc (19) is mounted on the sucker sliding block (26), a rack (20) is mounted in the sliding groove (13), and the rack (20) is meshed with the fluted disc (19); the end part of the sucker sliding block (26) is rotatably connected with a connecting block (21), and the sucker sliding block (26) is connected in the sliding groove (13) in a sliding mode through the connecting block (21).

### Claim 7

The wireless vacuum chuck sling according to claim 6, wherein: a telescopic driving part (22) and a blowing part (23) are arranged in the hanger shell (1), a blowing rod (231) is connected in the connecting hole (7) in a sliding manner, the telescopic driving part (22) is used for driving the blowing rod (231) to move in a telescopic manner towards the object lifting sucker (2), the blowing part (23) is in butt joint with the blowing rod (231) and is used for supplying air to the blowing rod (231), and a second air outlet hole is formed in the end part, close to the object lifting sucker (2), of the blowing rod (231); an air suction channel (24) is arranged in the sucker sliding block (26), one end of the air suction channel (24) is communicated with the interior of the object lifting sucker (2), and the other end of the air suction channel (24) is butted with a vacuumizing device (3); the cleaning brush (25) is arranged on the sucker sliding block (26), the cleaning brush (25) comprises a brush holder (251) and brush bristles (252) arranged on the brush holder (251), the brush bristles (252) are located on the outer side of the object lifting sucker (2), and the brush bristles (252) are distributed along the circumferential direction of the outer side of the object lifting sucker (2).

## Full description

PERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansMultiple lifting units; More than one suction areaDivided cups

Description

Wireless vacuum chuck lifting appliance

Technical Field

The invention relates to the technical field of hoisting tools, in particular to a wireless vacuum chuck hoisting tool.

Background

The vacuum chuck lifting appliance of the present suction cup lifting appliance, as disclosed in the chinese utility model with the publication number of CN205397826U, has a structure comprising a frame and a vacuumizing mechanism, wherein the two ends of the bottom of the frame are connected with a support sheet, the support sheet is hinged with a first vacuum chuck, and the middle position of the bottom of the frame is hinged with a second vacuum chuck. Wherein, evacuation mechanism includes the vacuum pump, and the vacuum pump passes through the trachea and connects a plurality of vacuum valves, and vacuum pump and vacuum valve all pass through circuit connection controller, and the vacuum valve is connected with first vacuum chuck and second vacuum chuck through this trachea.

When the vacuum sucking disc is used, the first vacuum sucking disc and the second vacuum sucking disc are placed on an object, and then air in the first vacuum sucking disc and the second vacuum sucking disc is pumped away through the vacuum pump, so that the first vacuum sucking disc and the second vacuum sucking disc are firmly adsorbed on the object.

At present, partial sucking disc hoist internally mounted has the battery, and the battery supplies power in the vacuum pump, but this type of electric sucking disc need charge internally mounted's battery in advance, and after using for a long time, if the inside short of electricity of battery, need shut down again and charge, and the convenience of use is low.

Disclosure of Invention

In view of the above, the present invention provides a wireless vacuum chuck lifting tool, which has a detachable battery pack and is convenient and fast to use.

In order to solve the technical problems, the technical scheme of the invention is as follows:

the utility model provides a wireless vacuum chuck hoist, includes the hoist shell, carries the thing sucking disc, evacuating device, power supply, evacuating device is used for bleeding to carrying thing sucking disc inside, the installing port has been seted up on the hoist shell, power supply is including the battery case that is equipped with the battery, the battery case joint in the installing port, battery electricity in the battery case connect in evacuating device.

Through above-mentioned technical scheme, based on adopt detachable construction between battery case and the hoist shell, can be in advance with a plurality of battery cases that are full of the electricity, insert one of them battery case in the installing port of hoist shell, after the normal work a period, will use the battery case after a period again and dismantle, change new battery case, need not to carry out traditional shut down charging operation, use the convenience height.

Preferably, a connecting hole is formed in the hanger shell, the vacuumizing device is connected with the connecting hole through an air pipe, the object lifting sucker is fixed on the hanger shell through a screw, a first air hole is formed in the object lifting sucker, and the first air hole corresponds to the connecting hole and is communicated with the connecting hole.

Through the technical scheme, the disassembly and assembly work between the object lifting suction disc and the lifting appliance shell can be completed through rotating the screw, so that the use convenience of the vacuum suction disc lifting appliance is further improved.

Preferably, a filter screen is arranged between the object lifting sucker and the side wall of the hanger shell, and the filter screen is arranged between the connecting hole and the air hole.

Through above-mentioned technical scheme, can take the air out in carrying the thing sucking disc through evacuating device, at this moment, the air between connecting hole and the gas pocket can receive the filter effect of filter screen, is favorable to promoting evacuating device's life.

Preferably, the article-lifting sucker is provided with a storage groove at the end face close to the filter screen, and the storage groove is communicated with the air hole.

Through above-mentioned technical scheme, after carrying thing sucking disc air through the filter screen filtration, the dust debris that are blocked by the filter screen can move to accomodating the inslot, accomodate the groove and play the effect of accomodating dust debris, on the one hand, can reduce the risk that the filter screen was blockked up completely, on the other hand also can reduce the dust and drop the total amount of carrying the thing sucking disc again.

Preferably, carry the thing sucking disc including laminating in the sucking disc body of hoist shell lateral wall, setting and be in the sucking disc body deviates from hoist shell one side and with sucking disc body integrated into one piece's ripple deformation section.

Through above-mentioned technical scheme, the thickness of sucking disc body can set up great, can and the hoist shell between produce stable the being connected, ripple deformation section thickness can set up less relatively, can take place deformation light relatively.

Preferably, the side wall of the hanger shell close to the object lifting sucker is provided with a sliding groove, the sliding groove is connected with a sucker slider in a sliding manner, the connecting hole is formed in the sucker slider, the object lifting sucker is connected to the sucker slider, a positioning part is arranged in the hanger shell and used for pushing the sucker slider to move to a specified position.

Through above-mentioned technical scheme, because treat that absorbent article surface is not of uniform size, at this moment, the accessible promotes the sucking disc slider, and the sucking disc slider drives carries the thing sucking disc to remove, and then changes the position distribution of carrying the thing sucking disc, then fixes the position of sucking disc slider through locating part, can adapt to the article absorption in different surface sizes, and application scope is wide.

Preferably, be equipped with the slot on the hoist shell, the locating part sets up the inserted block in the slot including setting up first spring in the slot, sliding, first spring is connected the inserted block in the slot, first spring is used for releasing the slot notch with the tip of inserted block, be equipped with first wedge on the inserted block, be equipped with the slider connecting piece in the spout, the both ends of slider connecting piece are link and drive end respectively, the link connect in the sucking disc slider, be equipped with the second wedge on the drive end, the second wedge offsets with first wedge and contacts.

Through the technical scheme, when the lifting appliance shell is gradually close to the surface of an object to be adsorbed, the end part of the inserting block can firstly abut against the object to be adsorbed, the inserting block overcomes the elastic action of the first spring to slide towards the inside of the slot, the first wedge-shaped surface on the inserting block can extrude the second wedge-shaped surface, the inserting block pushes the sliding block connecting piece to slide, and the sliding block connecting piece pushes the sucker sliding block to move;

therefore, under the actual adsorption operation action, on one hand, the moving position of the object lifting sucker can be adjusted by replacing the inserting blocks with different lengths or different wedge-shaped angles; on the other hand, in the process of the transverse movement of the object lifting sucker, the object lifting sucker can generate contact sliding with the surface of the object to be adsorbed, dust and impurities on the surface of the object to be adsorbed can be cleaned to a certain degree, and the adsorption stability of the object lifting sucker is improved.

Preferably, the slider connecting piece is divided into a left slider and a right slider, a second spring is connected between the left slider and the right slider, the second wedge-shaped surface is arranged at the end part of the left slider, and the connecting end is arranged at the end part of the right slider;

the lifting appliance is characterized in that a distance adjusting screw rod is arranged on the lifting appliance shell, penetrates through the sliding groove, and the end part of the distance adjusting screw rod is abutted to the side wall of the right sliding block.

Through above-mentioned technical scheme, through rotatory roll adjustment screw rod, the tip of roll adjustment screw rod can offset with the tip of right slider, and right slider produces the extrusion to the second spring, and the second spring takes place deformation, and the interval between left slider and the right slider just can change, and at this moment, carrying thing sucking disc place position and also can taking place direct change, has further promoted the position control flexibility ratio of carrying the thing sucking disc.

Preferably, the sucker sliding block is rotatably connected to the right sliding block, a fluted disc is arranged on the sucker sliding block, a rack is arranged in the chute, and the rack is meshed with the fluted disc;

the end part of the sucker sliding block is rotatably connected with a connecting block, and the sucker sliding block is connected in the sliding groove in a sliding mode through the connecting block.

Through above-mentioned technical scheme, when the in-process that the sucking disc slider removed along the spout, fluted disc on the sucking disc slider can mesh with the rack mutually, and the rack can drive the fluted disc and take place the rotation in a circumferential direction, and the fluted disc can drive the sucking disc slider and rotate, carries under the rotation state thing sucking disc and can treat that absorbent object surface produces more effectual dust removal effect.

Preferably, a telescopic driving part and a blowing part are arranged in the hanger shell, a blowing rod is connected in the connecting hole in a sliding manner, the telescopic driving part is used for driving the blowing rod to move in a telescopic manner towards the object lifting sucker, the blowing part is in butt joint with the blowing rod and is used for supplying air to the blowing rod, and a second air outlet hole is formed in the end part, close to the object lifting sucker, of the blowing rod;

an air suction channel is arranged in the sucker slide block, one end of the air suction channel is communicated with the interior of the object lifting sucker, and the other end of the air suction channel is butted with a vacuumizing device;

the cleaning brush is arranged on the sucker sliding block and comprises a brush holder and brush bristles arranged on the brush holder, the brush bristles are located on the outer side of the object lifting sucker, and the brush bristles are distributed along the circumferential direction of the outer side of the object lifting sucker.

According to the technical scheme, firstly, the sucker sliding block can drive the cleaning brush to rotate in the circumferential direction, and the brush hair part of the cleaning brush can effectively clean the surface of an object to be adsorbed; secondly, at the in-process that the sucking disc slider slided, flexible drive division drive gas blow the pole and move toward treating absorbent object surface to gas portion fills gas into the gas blow pole, and gas blows out in the second venthole of gas blow pole, and on the one hand, this gas can be treated absorbent object surface and blow the dirt operation, and on the other hand, this gas can produce outside blowing power to the brush hair that is located peripheral position, can reduce by a wide margin that the brush hair is unexpected to be squeezed in the sucking disc body and treat the circumstances between the absorbent object surface.

The technical effects of the invention are mainly reflected in the following aspects:

(1) an external detachable battery box is adopted, the traditional shutdown charging operation is not needed, and the use convenience is high;

(2) the object lifting sucker is arranged on the shell of the lifting appliance in a sliding manner, and can be adapted to adsorb the surfaces of objects with different sizes;

(3) the adoption is like parts such as cleaning brush, gas blow pole, reduces the dust debris on waiting to adsorb the object surface, promotes the adsorption stability.

Drawings

FIG. 1 is a schematic structural diagram according to a first embodiment;

FIG. 2 is a schematic partial cross-sectional view illustrating a structure according to a first embodiment;

FIG. 3 is a schematic bottom view partially in section of the second embodiment;

FIG. 4 is an enlarged view of portion A of FIG. 3;

FIG. 5 is a schematic side view partially in section according to the second embodiment;

FIG. 6 is an enlarged view of the portion B of FIG. 5;

FIG. 7 is an enlarged view of section C of FIG. 5;

fig. 8 is an enlarged view of a portion D of fig. 7.

Reference numerals: 1. a spreader housing; 2. a suction cup for lifting objects; 201. a suction cup body; 202. a corrugated deformation section; 3. a vacuum pumping device; 4. an installation port; 5. a power supply; 6. a battery case; 7. connecting holes; 8. an air tube; 9. a screw; 10. a first air hole; 11. a filter screen; 12. a receiving groove; 13. a chute; 14. a positioning member; 141. a first spring; 142. inserting a block; 143. a first wedge-shaped face; 15. a slot; 16. a slider connection; 161. a left slider; 1611. a connecting end; 1612. a second wedge-shaped face; 171. a right slider; 1711. a driving end; 18. adjusting the pitch of the screw rod; 19. a fluted disc; 20. a rack; 21. connecting blocks; 22. a telescopic driving part; 23. a blowing section; 231. a blowing rod; 232. a second air hole; 2321. blowing pores; 2322. a dust blowing hole; 24. an air suction passage; 25. a cleaning brush; 251. a brush holder; 252. brushing; 26. a suction cup slider; 27. a second spring.

Detailed Description

The following detailed description of the embodiments of the present invention is provided in order to make the technical solution of the present invention easier to understand and understand.

The first embodiment is as follows:

a wireless vacuum sucker lifting appliance is shown in figure 1 and comprises a lifting appliance shell 1, an object lifting sucker 2, a vacuumizing device 3 and a power supply 5, wherein the power supply 5 supplies electric energy to the vacuumizing device 3, the object lifting sucker 2 is in surface contact with an object to be adsorbed, the vacuumizing device 3 is used for exhausting air inside the object lifting sucker 2, and the object lifting sucker 2 can be firmly adsorbed on the surface of the object.

Referring to fig. 2, the object lifting suction cup 2 includes a suction cup body 201 attached to the side wall of the hanger case 1, and a corrugated deformation section 202 disposed on one side of the suction cup body 201 away from the hanger case 1 and integrally formed with the suction cup body 201.

Referring to fig. 1 and 2, a mounting port 4 is formed in the hanger shell 1, the power supply 5 includes a battery box 6 containing a storage battery, the battery box 6 is clamped in the mounting port 4, and the storage battery in the battery box 6 is electrically connected to the vacuum extractor 3.

Referring to fig. 1 and 2, a connection hole 7 is formed in a hanger shell 1, a vacuum extractor 3 is connected with the connection hole 7 through an air pipe 8, an object lifting suction cup 2 is fixed on the hanger shell 1 through a screw 9, a suction cup body 201 of the object lifting suction cup 2 is provided with a first air hole 10, and the first air hole 10 corresponds to and is communicated with the connection hole 7.

Referring to fig. 2, a filter screen 11 is arranged between the object lifting suction disc 2 and the side wall of the hanger shell 1, and the filter screen 11 is arranged between the connecting hole 7 and the air hole.

Referring to fig. 2, the end surface of the suction cup body 201 close to the filter screen 11 is provided with a receiving groove 12, the receiving groove 12 is concentric with the first air hole 10, and the receiving groove 12 is communicated with the air hole.

In the actual use process, the vacuumizing device 3 sucks air into the object lifting suction disc 2 through the air pipe 8, the air in the object lifting suction disc 2 sequentially passes through the first air hole 10 and the connecting hole 7, in the process, the passing air also passes through the filter screen 11, and dust and impurities in the air stay on the filter screen 11 and enter the accommodating groove 12.

Example two: on the basis of the first embodiment, the following structure is added.

Referring to fig. 3, the number of the object lifting suction cups 2 illustrated in the present embodiment is four.

Referring to fig. 3, the side wall of the hanger shell 1 close to the object lifting suction cups 2 is provided with sliding grooves 13, and the number of the sliding grooves 13 is also corresponding to the number of the object lifting suction cups 2, and is also four.

Referring to fig. 3 and 4, a suction cup sliding block 26 is slidably connected in each sliding groove 13, the connection hole 7 is disposed on the suction cup sliding block 26, and a suction cup body 201 of the object lifting suction cup 2 is connected to the suction cup sliding block 26 through a screw 9.

Referring to fig. 5, a positioning component 14 is arranged in the hanger shell 1, and the positioning component 14 is used for pushing the sucker slide 26 to move to a specified position.

Referring to fig. 5, a slot 15 is formed in the middle of the hanger case 1, and the four sliding grooves 13 are communicated with the inside of the slot 15.

Referring to fig. 5, the positioning component 14 includes a first spring 141 disposed in the slot 15 and an insertion block 142 slidably disposed in the slot 15, the insertion block 142 is connected in the slot 15 by the first spring 141, the first spring 141 is used for pushing an end of the insertion block 142 out of a notch of the slot 15, a first wedge-shaped surface 143 is disposed on the insertion block 142, when the object lifting suction cup 2 is not in a use state, the first spring 141 pushes the insertion block 142 to move toward the object lifting suction cup 2, a distance between an end of the insertion block 142 departing from the first spring 141 and the hanger housing 1 provided with the object lifting suction cup 2 is a, a distance between an end of the object lifting suction cup 2 departing from the hanger housing 1 and the hanger housing 1 provided with the object lifting suction cup 2 is b, and a is greater than b.

Referring to fig. 5, 6 and 7, a slider connecting member 16 is disposed in each sliding slot 13, and a connecting end 1611 and a driving end 1711 are respectively disposed at two ends of the slider connecting member 16. The slider connector 16 is provided separately as a left slider 161 and a right slider 171, and a second spring 27 is connected between the left slider 161 and the right slider 171.

Referring to fig. 6 and fig. 7, the connecting end 1611 is located at an end position of the right slider 171, the suction cup slider 26 is rotatably connected to the connecting end 1611, the suction cup slider 26 is provided with a toothed disc 19, a rack 20 is installed in the sliding slot 13, a length direction of the rack 20 is identical to a sliding direction of the suction cup slider 26, and the rack 20 is engaged with the toothed disc 19.

Referring to fig. 6, the driving end 1711 is located at an end position of the left slider 161 facing away from the right slider 171, and a second wedge-shaped surface 1612 is arranged on the driving end 1711, and the second wedge-shaped surface 1612 is in contact with the first wedge-shaped surface 143.

Referring to fig. 5 and 7, the spreader housing 1 is provided with the pitch adjusting screw 18, the pitch adjusting screw 18 penetrates through the sliding groove 13, the end of the pitch adjusting screw 18 abuts against the side wall of the right slider 171, and the length direction of the pitch adjusting screw 18 is consistent with the sliding direction of the suction cup slider 26.

Referring to fig. 7, the end of the suction cup sliding block 26 is rotatably connected with the connecting block 21, and the suction cup sliding block 26 is slidably connected in the sliding groove 13 through the connecting block 21.

Referring to fig. 5 and 7, a telescopic driving part 22 and a blowing part 23 are further arranged in the hanger housing 1, the telescopic driving part 22 can be a telescopic cylinder, a blowing rod 231 is slidably connected in the connecting hole 7, the telescopic driving part 22 is used for driving the blowing rod 231 to telescopically move towards the inside of the object lifting suction cup 2, the blowing part 23 is in butt joint with the blowing rod 231 and is used for supplying air to the blowing rod 231, and a second air outlet is formed in the end part, close to the object lifting suction cup 2, of the blowing rod 231.

Referring to fig. 5 and fig. 7, a suction channel 24 is provided in the suction cup slide block 26, one end of the suction channel 24 is communicated with the inside of the object-lifting suction cup 2, and the other end of the suction channel 24 is butted with the vacuum extractor 3.

Referring to fig. 5, the suction cup slide block 26 is provided with a cleaning brush 25, the cleaning brush 25 includes a brush holder 251 and bristles 252 mounted on the brush holder 251, the bristles 252 are located on the outer side of the object-lifting suction cup 2, and the bristles 252 are distributed along the outer circumferential direction of the object-lifting suction cup 2. Wherein, the end of the brush 252 departing from the hanger case 1 is bent, and the bending direction is toward the outside of the object lifting suction cup 2.

In addition, referring to fig. 7 and 8, the second air hole 232 includes blowing holes 2321 and dust blowing holes 2322, the blowing holes 2321 are distributed on the circumferential sidewall of the blowing rod 231, and the opening of the blowing holes 2321 is inclined toward the side of the bristles 252. The air blown out from the blowing holes 2321 can generate a blowing force effect on the bristles 252 in a direction away from the object lifting suction cup 2, so that the whole bristles 252 are bent and deformed towards one side away from the object lifting suction cup 2. The dust blowing holes 2322 are distributed at the end position of the blowing rod 231 which is far away from the hanger shell 1. The air blown out from the dust blowing hole 2322 can perform targeted air blowing and dust removal on the surface of an object right below the object lifting suction cup 2.

In the actual use process:

(1) and (4) pre-adjusting. According to the surface area of the object to be adsorbed, on one hand, the insertion block 142 with a proper length and a proper slope of the first wedge-shaped surface 143 is selected, and on the other hand, the distance adjusting screw 18 is rotated, so that the distance adjusting screw 18 can push the right slider 171 to move, the right slider 171 can extrude the second spring 27, and the distance between the left slider 161 and the right slider 171 is adjusted.

(2) And (5) dedusting and adsorbing. Handheld hoist shell 1 will be equipped with and carry hoist shell 1 one side of thing sucking disc 2 and be close to gradually treating the adsorbed object surface, and the inserted block 142 tip can contact with treating the adsorbed object surface earlier, and inserted block 142 can receive the extrusion and take place to remove in the slot 15.

Meanwhile, the insert 142 can produce the extrusion force to first spring 141, first wedge 143 on the insert 142 can produce the extrusion of sliding to the second wedge 1612 of left slider 161, left slider 161 can be slided to right slider 171 one side, left slider 161 promotes right slider 171 through second spring 27 and moves, right slider 171 drives sucking disc slider 26 and carries out the syntropy removal along spout 13, at this moment, fluted disc 19 and rack 20 intermeshing, fluted disc 19 rotates, fluted disc 19 drives sucking disc slider 26 and rotates, sucking disc slider 26 drives and carries thing sucking disc 2, cleaning brush 25 rotates, the last brush hair 252 of cleaning brush 25 can be cleaned the dust removal to absorbent article surface.

The telescopic driving part 22 drives the air blowing rod 231 to move towards the surface of an object to be adsorbed, the air blowing part 23 inflates the air blowing rod 231, air blown out from the air blowing holes 2321 can generate a blowing force effect in the direction deviating from the object lifting suction disc 2 on the bristles 252, the whole bristles 252 are bent and deformed on one side deviating from the object lifting suction disc 2, and the air blown out from the air blowing holes 2322 can perform targeted air blowing and dust removal on the surface of the object under the object lifting suction disc 2.

Until the right sliding block 171 is abutted against the distance adjusting screw 18, the object lifting suction cup 2 moves to a designated position, the telescopic driving part 22 drives the air blowing rod 231 to move back to the surface of an object to be adsorbed, the air blowing part 23 stops working, the vacuumizing device 3 is started, the vacuumizing device 3 performs air suction on the inner part of the object lifting suction cup 2 through the air suction channel 24, and the whole object lifting suction cup 2 can be tightly adsorbed on the surface of the object.

The above are only typical examples of the present invention, and besides, the present invention may have other embodiments, and all the technical solutions formed by equivalent substitutions or equivalent changes are within the scope of the present invention as claimed.

## Classifications

- B66C1/025
- B66C1/02

---

Generated by IPtorch. Verify legal conclusions against the official publication.
