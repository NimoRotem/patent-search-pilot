# 28. Improvements in and relating to suction lifting equipment

- **Archive rank:** 28 of 50
- **Publication:** [GB-923724-A](https://patents.google.com/patent/GB923724A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/010391176/publication/GB923724A?q=pn%3DGB923724A)
- **Publication date:** 1963-04-18
- **Filing date:** 1959-10-29
- **Earliest priority:** 1959-10-29
- **Family:** 10391176
- **Text status:** source text incomplete — use the office links above
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** PETERS G D & CO LTD
- **Inventors:** STRETTON HENRY JACKSON

## Abstract

923,724. Suction lifting devices. G. D. PETERS &amp; CO. Ltd. Oct. 31, 1960 [Oct. 29, 1959], No. 36786/59. Class 78 (4). In a suction lifting apparatus the vacuum in the pads 3 is released by a valve 21 which opens in response to differential air pressure produced when the pads are disconnected from a vacuum reservoir 11. The pads are connected to the reservoir 11 by an electromagnetically operated valve 19 controlled by push-buttons 32. When the valve member 27 is in its upper position the reservoir 11 is connected to pads 3 through pipes 17a, 17, 23 and 5. A constriction 24 in the pipe 23 produces a drop in pressure in a chamber 14 which moves a diaphragm 16 and the valve 21 upwards to allow suction to develop in the pads 3. Once the valve 21 is closed it is held closed by reduced pressure in a chamber 15. To release the vacuum, the valve member 27 is moved to the position shown to connect the pipe 17 to atmosphere through a pipe and filter 29, 30. This causes an increase in pressure in the chamber 14 which moves the diaphragm 16 and the valve 21 downwards, thus admitting air to the suction pads. The opening movement of the valve 21 is aided by gravity. A micro-switch 31 actuated by the valve 21 ensures that a motor 10 runs continuously to maintain a vacuum when an article is being lifted. At other times a pressureresponsive switch 25 controls the motor 10. When the vacuum in the suction pads reaches a value at which the load may be lifted in safety, a pressure-responsive switch 35 extinguishes a red light and lights a green one. The constriction 24 by preventing a sudden change in the vacuum pressure when suction is first applied to the pads ensures that the green light will not light up prematurely. To prevent rotation during lifting, the whole apparatus is suspended from a hoist mechanism by a rope which passes under two horizontallyspaced pulleys mounted thereon. The apparatus can be steered during lifting by a handle 42. Specifications 830,393, 830,394 and 876,370 are referred to.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/GB-923724-A/ops000.png)

![Sketch 1 for GB-923724-A](https://nimo.iptorch.com/refdrawing/GB-923724-A/ops000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/GB-923724-A/ops001.png)

![Sketch 2 for GB-923724-A](https://nimo.iptorch.com/refdrawing/GB-923724-A/ops001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/GB-923724-A/ops002.png)

![Sketch 3 for GB-923724-A](https://nimo.iptorch.com/refdrawing/GB-923724-A/ops002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/GB-923724-A/ops003.png)

![Sketch 4 for GB-923724-A](https://nimo.iptorch.com/refdrawing/GB-923724-A/ops003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/GB-923724-A/ops004.png)

![Sketch 5 for GB-923724-A](https://nimo.iptorch.com/refdrawing/GB-923724-A/ops004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/GB-923724-A/ops005.png)

![Sketch 6 for GB-923724-A](https://nimo.iptorch.com/refdrawing/GB-923724-A/ops005.png)

## Claims

_Claims were not available from the queried sources._

## Full description

**[p0001]**

PERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansMultiple lifting units; More than one suction areaSeparate cupsPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansCircular shapePERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting force

**[p0001]**

s to articles or groups of articles by suction meansSafety measures, e.g. sensors, duplicate functions

## Classifications

- B66C1/0243
- B66C1/02
- B66C1/0212
- B66C1/0218

---

Generated by IPtorch. Verify legal conclusions against the official publication.
