# 11. Sucker with pressure early warning detection function

- **Archive rank:** 11 of 50
- **Publication:** [US-8814113-B1](https://patents.google.com/patent/US8814113B1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/051358423/publication/US8814113B1?q=pn%3DUS8814113B1)
- **Publication date:** 2014-08-26
- **Filing date:** 2013-03-13
- **Earliest priority:** 2013-03-13
- **Family:** 51358423
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** CHEN KUEI-I; TRU MILES HARDWARE CO LTD
- **Inventors:** CHEN KUEI-I

## Abstract

A sucker includes a sucker body, a pressure sensor, a control circuit board, and a warning member. The sucker body has an attachment surface. The control circuit board and the warning member are combined with the pressure sensor. The pressure sensor, the control circuit board and the warning member are mounted in a closed receiving portion. The pressure sensor is connected to the attachment surface of the sucker body. Thus, the pressure sensor, the control circuit board and the warning member construct an early warning detection mechanism which successively detects and monitors the pressure of the attachment surface of the sucker body, and produces an early warning signal automatically by detection of the pressure differential of the attachment surface of the sucker body to prevent the sucker from being detached from an object.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-8814113-B1/000.png)

![Sketch 1 for US-8814113-B1](https://nimo.iptorch.com/refdrawing/US-8814113-B1/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/US-8814113-B1/001.png)

![Sketch 2 for US-8814113-B1](https://nimo.iptorch.com/refdrawing/US-8814113-B1/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/US-8814113-B1/002.png)

![Sketch 3 for US-8814113-B1](https://nimo.iptorch.com/refdrawing/US-8814113-B1/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/US-8814113-B1/003.png)

![Sketch 4 for US-8814113-B1](https://nimo.iptorch.com/refdrawing/US-8814113-B1/003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/US-8814113-B1/004.png)

![Sketch 5 for US-8814113-B1](https://nimo.iptorch.com/refdrawing/US-8814113-B1/004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/US-8814113-B1/005.png)

![Sketch 6 for US-8814113-B1](https://nimo.iptorch.com/refdrawing/US-8814113-B1/005.png)

## Claims

### Claim 1 (independent)

A sucker for attaching an article to an object with an early warning detection function, comprising: a sucker body; a pressure sensor connected with the sucker body; a control circuit board connected with the pressure sensor; and a warning member connected with the control circuit board; wherein: the sucker body has an attachment surface; the control circuit board and the warning member are combined with the pressure sensor; the pressure sensor, the control circuit board and the warning member are mounted in a closed receiving portion; the pressure sensor is connected to the attachment surface of the sucker body; the pressure sensor successively detects and reacts a vacuum leak variation of the attachment surface of the sucker body, and transmits the vacuum leak variation of the attachment surface of the sucker body to the control circuit board; the control circuit board converts the vacuum leak variation of the attachment surface of the sucker body into a feedback signal, and converts the feedback signal into an early warning signal; the control circuit board transmits the early warning signal to the warning member which displays or starts the early warning signal; and the sucker performs an early warning action to provide a safety function.

### Claim 2

The sucker of claim 1 , wherein: the sucker further comprises: a wireless transceiver connected with the control circuit board; and a digital faceplate connected with the control circuit board to receive a remote wireless signal; the wireless transceiver transmits the pressure differential from the control circuit board; and the digital faceplate receives the remote wireless signal from the wireless transceiver and indicates the pressure differential in the closed receiving portion of the sucker body.

### Claim 3

The sucker of claim 1 , wherein: the sucker body has a periphery provided with an air hole connected between the closed receiving portion and the attachment surface of the sucker body to connect the closed receiving portion to the attachment surface of the sucker body; the closed receiving portion is directly formed in the sucker body; the closed receiving portion is connected with an outer receiving portion which is located outside of the sucker body; and the attachment surface of the sucker body is attached to an object, with the closed receiving portion and the attachment surface of the sucker body forming a closed chamber detection zone.

### Claim 4

The sucker of claim 1 , wherein: the sucker further comprises a pull-type handle or an eccentric handle pivotally connected with the sucker body; and the handle is connected to the closed receiving portion.

### Claim 5

The sucker of claim 3 , wherein the pressure sensor is directly received in the closed receiving portion or placed in the outer receiving portion of the sucker body.

### Claim 6

The sucker of claim 1 , wherein the sucker further comprises a digital display mounted outside of the sucker body and connected with the pressure sensor to indicate the pressure differential in the closed receiving portion of the sucker body.

## Full description

### Background Of The Invention

**[p0001]**

1. Field of the Invention The present invention relates to an attachment device and, more particularly, to a sucker for attaching an article to an object, such as a wall and the like. 2. Description of the Related Art A conventional sucker comprises an attachment surface that is bonded onto an object, such as a wall, plane and the like, to attach an article to the object. However, when ambient air enters the inside of the sucker, the negative pressure in the sucker is reduced or released, so that the sucker is easily detached or removed from the object, and the article easily falls down. In addition, the user cannot predict reduction or release of the suction force of the sucker so that the sucker is easily detached from the object unexpectedly, thereby causing inconvenience or danger to the user.

### Brief Summary Of The Invention

**[p0002]**

In accordance with the present invention, there is provided a sucker, comprising a sucker body, a pressure sensor connected with the sucker body, a control circuit board connected with the pressure sensor, and a warning member connected with the control circuit board. The sucker body has an attachment surface. The control circuit board and the warning member are combined with the pressure sensor. The pressure sensor, the control circuit board and the warning member are mounted in a closed receiving portion. The pressure sensor is connected to the attachment surface of the sucker body. In practice, the pressure sensor successively detects and reacts a vacuum leak variation of the attachment surface of the sucker body, and transmits the vacuum leak variation of the attachment surface of the sucker body to the control circuit board. The control circuit board converts the vacuum leak variation of the attachment surface of the sucker body into a feedback signal, and converts the feedback signal into an early warning signal. The control circuit board transmits the early warning signal to the warning member which displays or starts the early warning signal. Thus, the sucker performs an early warning action to provide a safety function.

**[p0003]**

The sucker further comprises a wireless transceiver connected with the control circuit board, and a digital faceplate connected with the control circuit board to receive a remote wireless signal. Thus, the wireless transceiver transmits the pressure differential from the control circuit board, and the digital faceplate receives the remote wireless signal from the wireless transceiver and indicates the pressure differential in the closed receiving portion of the sucker body. The sucker body has a periphery provided with an air hole connected between the closed receiving portion and the attachment surface of the sucker body to connect the closed receiving portion to the attachment surface of the sucker body. The closed receiving portion is directly formed in the sucker body. Alternatively, the closed receiving portion is connected with an outer receiving portion which is located outside of the sucker body. Thus, the attachment surface of the sucker body is attached to an object, with the closed receiving portion and the attachment surface of the sucker body forming a closed chamber detection zone.

**[p0004]**

The sucker further comprises a pull-type handle or an eccentric handle pivotally connected with the sucker body. The handle is connected to the closed receiving portion. The pressure sensor is directly received in the closed receiving portion or placed in the outer receiving portion of the sucker body. The sucker further comprises a digital display mounted outside of the sucker body and connected with the pressure sensor to indicate the pressure differential in the closed receiving portion of the sucker body. The primary objective of the present invention is to provide a sucker with a pressure early warning detection function. According to the primary advantage of the present invention, the pressure sensor, the control circuit board and the warning member construct an early warning detection mechanism which successively detects and monitors the pressure of the attachment surface of the sucker body, and produces an early warning signal automatically by detection of the pressure differential of the attachment surface of the sucker body so as to prevent the sucker from being detached from the object, and to provide a safety function to the user.

**[p0005]**

Further benefits and advantages of the present invention will become apparent after a careful reading of the detailed description with appropriate reference to the accompanying drawings.

### Brief Description Of The Several Views Of The Drawing(S)

**[p0006]**

FIG. 1 is a perspective cross-sectional view of a sucker in accordance with the preferred embodiment of the present invention. FIG. 2 is a bottom operational view of the sucker as shown in FIG. 1 . FIG. 3 is a side cross-sectional operational view of the sucker as shown in FIG. 1 . FIG. 4 is a perspective view of a sucker in accordance with another preferred embodiment of the present invention. FIG. 5 is a perspective view of a sucker in accordance with another preferred embodiment of the present invention.

### Detailed Description Of The Invention

**[p0007]**

Referring to the drawings and initially to FIGS. 1-3 , a sucker in accordance with the preferred embodiment of the present invention comprises a sucker body 10 , a pressure sensor 12 connected with the sucker body 10 , a control circuit board 121 connected with the pressure sensor 12 , and a warning member 122 connected with the control circuit board 121 . The sucker body 10 has an attachment surface 11 . The attachment surface 11 of the sucker body 10 is formed on the bottom of the sucker body 10 and has a substantially planar or concave shape. The control circuit board 121 and the warning member 122 are combined with the pressure sensor 12 . The pressure sensor 12 , the control circuit board 121 and the warning member 122 are mounted in a closed receiving portion 13 . The closed receiving portion 13 is integrally formed in the sucker body 10 . The pressure sensor 12 is connected to the attachment surface 11 of the sucker body 10 . In practice, the pressure sensor 12 successively detects and reacts a vacuum leak variation of the attachment surface 11 of the sucker body 10 , and transmits the vacuum leak variation of the attachment surface 11 of the sucker body 10 to the control circuit board 121 . The control circuit board 121 converts the vacuum leak variation of the attachment surface 11 of the sucker body 10 into a feedback signal, and converts the feedback signal into an early warning signal. The control circuit board 121 then transmits the early warning signal to the warning member 122 which displays or starts the early warning signal. Thus, the sucker performs an ear

**[p0007]**

ly warning action to provide a safety function.

**[p0008]**

In the preferred embodiment of the present invention, the sucker body 10 has a periphery provided with an air hole 131 connected between the closed receiving portion 13 and the attachment surface 11 of the sucker body 10 to connect the closed receiving portion 13 to the attachment surface 11 of the sucker body 10 . Thus, when the attachment surface 11 of the sucker body 10 is attached to an object, the closed receiving portion 13 and the attachment surface 11 of the sucker body 10 form a closed chamber detection zone 13 A. In operation, referring to FIGS. 2 and 3 with reference to FIG. 1 , the attachment surface 11 of the sucker body 10 is initially attached to an object closely, to form a vacuum suction state between the attachment surface 11 of the sucker body 10 and the object. At this time, the closed receiving portion 13 and the attachment surface 11 of the sucker body 10 form a closed chamber detection zone 13 A. In addition, the pressure sensor 12 is connected to the attachment surface 11 of the sucker body 10 so that the pressure sensor 12 can detect the pressure of the suction force at the attachment surface 11 of the sucker body 10 , and the control circuit board 121 operates the pressure differential of the attachment surface 11 of the sucker body 10 . In such a manner, when air permeates the attachment surface 11 of the sucker body 10 into the closed chamber detection zone 13 A, the pressure sensor 12 successively detects the pressure of the attachment surface 11 of the sucker body 10 and transmits a pressure differential to the control circuit board 121 . Then,

**[p0008]**

the control circuit board 121 compares the pressure differential of the attachment surface 11 of the sucker body 10 with a preset pressure limit. When the pressure differential of the attachment surface 11 of the sucker body 10 reaches the preset pressure limit, the control circuit board 121 drives the warning member 122 to emit an early warning signal to warn a user so that the user predicts that the suction force of the sucker body 10 is exhausted and has to supplement the vacuum negative pressure suction force in the closed chamber detection zone 13 A so as to prevent the sucker body 10 from being detached from the object. Thus, the sucker can monitor and detect its pressure and can produce an early warning signal automatically by detection of a pressure differential so as to provide a safety function to the user.

**[p0009]**

In the preferred embodiment of the present invention, the closed receiving portion 13 is directly formed in the sucker body 10 . Alternatively, the closed receiving portion 13 is connected with an outer receiving portion (not shown) which is located outside of the sucker body 10 to form a closed chamber detection zone. The pressure sensor 12 is directly received in the closed receiving portion 13 or placed in the outer receiving portion of the sucker body 10 . The warning member 122 is an light emitting diode (LED) light source, an audio alarm, a buzzer and the like. In another preferred embodiment of the present invention, the sucker further comprises a digital display (not shown) mounted outside of the sucker body 10 and connected with the pressure sensor 12 to indicate the pressure differential in the closed receiving portion 13 of the sucker body 10 . In another preferred embodiment of the present invention, the sucker further comprises a wireless transceiver (not shown) connected with the control circuit board 121 , and a digital faceplate (not shown) connected with the control circuit board 121 to receive a remote wireless signal. Thus, the wireless transceiver transmits the pressure differential from the control circuit board 121 , and the digital faceplate receives the remote wireless signal from the wireless transceiver and indicates the pressure differential in the closed receiving portion 13 of the sucker body 10 .

**[p0010]**

As shown in FIG. 4 , the sucker further comprises a pull-type handle 14 pivotally connected with the sucker body 10 . The handle 14 is connected to the closed receiving portion 13 . Thus, when the handle 14 is pulled outward relative to the sucker body 10 , the closed receiving portion 13 is disposed at a vacuum state so that the attachment surface 11 of the sucker body 10 is attached to the object by a vacuum suction force. As shown in FIG. 5 , the sucker further comprises an eccentric handle 14 pivotally connected with the sucker body 10 . The handle 14 is connected to the closed receiving portion 13 . Thus, when the handle 14 is pulled outward relative to the sucker body 10 in an eccentric manner, the closed receiving portion 13 is disposed at a vacuum state so that the attachment surface 11 of the sucker body 10 is attached to the object by a vacuum suction force. Accordingly, the pressure sensor 12 , the control circuit board 121 and the warning member 122 construct an early warning detection mechanism which successively detects and monitors the pressure of the attachment surface 11 of the sucker body 10 , and produces an early warning signal automatically by detection of the pressure differential of the attachment surface 11 of the sucker body 10 so as to prevent the sucker from being detached from the object, and to provide a safety function to the user.

**[p0011]**

Although the invention has been explained in relation to its preferred embodiment(s) as mentioned above, it is to be understood that many other possible modifications and variations can be made without departing from the scope of the present invention. It is, therefore, contemplated that the appended claim or claims will cover such modifications and variations that fall within the true scope of the invention.

## Figure captions

- **Figure 1:** FIG. 1 is a perspective cross-sectional view of a sucker in accordance with the preferred embodiment of the present invention.
- **Figure 2:** FIG. 2 is a bottom operational view of the sucker as shown in FIG. 1 .
- **Figure 3:** FIG. 3 is a side cross-sectional operational view of the sucker as shown in FIG. 1 .
- **Figure 4:** FIG. 4 is a perspective view of a sucker in accordance with another preferred embodiment of the present invention.
- **Figure 5:** FIG. 5 is a perspective view of a sucker in accordance with another preferred embodiment of the present invention.

## Classifications

- F16B47/00
- F16B47/00
- A45D42/14
- F16B2200/95
- F16B2200/95

## Cited patent documents

- [US-2003197609-A1](https://patents.google.com/patent/US20030197609A1/en) — SEA
- [US-2006247730-A1](https://patents.google.com/patent/US20060247730A1/en) — SEA
- [US-2006247813-A1](https://patents.google.com/patent/US20060247813A1/en) — SEA
- [US-7542797-B2](https://patents.google.com/patent/US7542797B2/en) — SEA

---

Generated by IPtorch. Verify legal conclusions against the official publication.
