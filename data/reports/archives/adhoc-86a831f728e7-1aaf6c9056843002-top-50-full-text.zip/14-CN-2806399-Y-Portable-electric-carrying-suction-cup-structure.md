# 14. Portable electric carrying suction cup structure

- **Archive rank:** 14 of 50
- **Publication:** [CN-2806399-Y](https://patents.google.com/patent/CN2806399Y/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/036920701/publication/CN2806399Y?q=pn%3DCN2806399Y)
- **Publication date:** 2006-08-16
- **Filing date:** 2005-04-29
- **Earliest priority:** 2005-04-29
- **Family:** 36920701
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** CHAN SAN GLASS CO LTD

## Abstract

The utility model relates to a portable electric carrying sucker structure, which is mainly characterized in that a vacuum pump is arranged on a sucker body, a control unit is connected between a power supply part for supplying power to the vacuum pump and the vacuum pump, so that after the sucker body is attached to the surface of a smooth material, the control unit can be used for controlling the vacuum pump to pump out air between the sucker body and the surface of the smooth material, and continuously pump out the air after the sucker body and the smooth material are in an airtight state; therefore, the operation and the use are more rapid and convenient, a better airtight effect can be achieved, air is continuously pumped outwards to avoid loosening and falling in the moving process, and the use convenience and the safety are further improved.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-2806399-Y/000.png)

![Sketch 1 for CN-2806399-Y](https://nimo.iptorch.com/refdrawing/CN-2806399-Y/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-2806399-Y/001.png)

![Sketch 2 for CN-2806399-Y](https://nimo.iptorch.com/refdrawing/CN-2806399-Y/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/CN-2806399-Y/002.png)

![Sketch 3 for CN-2806399-Y](https://nimo.iptorch.com/refdrawing/CN-2806399-Y/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/CN-2806399-Y/003.png)

![Sketch 4 for CN-2806399-Y](https://nimo.iptorch.com/refdrawing/CN-2806399-Y/003.png)

## Claims

### Claim 1 (independent)

Claims (5)

### Claim 2 (independent)

Translated from Chinese ä¸ç§ææçµå¨æ¬è¿å¸çç»æï¼å

### Claim 4 (independent)

¶ç¹å¾å¨äºï¼ä¸»è¦äºå¸çä½ä¸ç«¯åºè®¾æææé¨ï¼å¦äºå¸çä½è®¾æçç©ºæ³µï¼è¯¥çç©ºæ³µå¹¶ç»ä¸æ°éä¸å¸çä½åºç«¯é¢è¿æ¥å¯¼éï¼ä¸ä¾ç»çç©ºæ³µçµæºççµæºé¨ä¸æè¿°çç©ºæ³µä¹é´è¿æ¥ä¸æ§å¶åå

### Claim 5 (independent)

ã1. A portable electric suction cup structure, characterized in that: a handle is fixed on the upper end of the suction cup body, and a vacuum pump is provided on the suction cup body. A control unit is connected between the power supply part of the vacuum pump power supply and the vacuum pump. å¦æå©è¦æ±1æè¿°çææçµå¨æ¬è¿å¸çç»æï¼å

### Claim 7 (independent)

¶ç¹å¾å¨äºï¼è¯¥å¸çä½ä¸ç«¯åºè®¾çææé¨åä¸­ç©ºç¶å

### Claim 8 (independent)

·ææè¿°æ°éï¼ä¸äºæ°éä¸ç«¯è®¾æè¿æ°éï¼äºæ°éå

### Claim 9

åè®¾ææè¿°çç©ºæ³µã2. The suction cup structure for portable electric transportation as claimed in claim 1, characterized in that: the handle portion fixed on the upper end of the suction cup body is hollow and has the air passage, and an air inlet valve is arranged at one end of the air passage, and the air inlet valve is arranged at one end of the air passage. Said vacuum pump is then provided in the road. å¦æå©è¦æ±1æè¿°çææçµå¨æ¬è¿å¸çç»æï¼å

### Claim 11 (independent)

¶ç¹å¾å¨äºï¼è¯¥æ§å¶åå

### Claim 12 (independent)

è®¾æä¾ä½¿ç¨è

### Claim 13 (independent)

è½è½»æå¾ç¥å¸çä½ä¸å

### Claim 14

æ»æè´¨è¡¨é¢é´çååååçååè¡¨ã3. The suction cup structure for portable electric transportation according to claim 1, wherein the control unit is provided with a pressure gauge for the user to easily know the pressure change between the suction cup body and the surface of the smooth material. å¦æå©è¦æ±1æè¿°çææçµå¨æ¬è¿å¸çç»æï¼å

### Claim 16 (independent)

¶ç¹å¾å¨äºï¼è¯¥æ§å¶åå

### Claim 17 (independent)

è®¾æä¾æ¾ç¤ºä¸åä½¿ç¨ç¶æçåå

### Claim 18

æºã4. The portable electric transport suction cup structure according to claim 1, wherein the control unit is provided with a light source for displaying different usage states. å¦æå©è¦æ±1æè¿°çææçµå¨æ¬è¿å¸çç»æï¼å

### Claim 20 (independent)

¶ç¹å¾å¨äºï¼è¯¥æ§å¶åå

### Claim 21

è®¾æä¾ä¾ä¸åä½¿ç¨ç¶æååºè­¦æ¥å£°åçèé¸£å¨ã5. The portable electric transport suction cup structure according to claim 1, characterized in that: the control unit is provided with a buzzer for sending out alarm sounds according to different usage states.

## Full description

**[p0001]**

Description Translated from Chinese ææçµå¨æ¬è¿å¸çç»æPortable electric handling suction cup structure ææ¯é¢åtechnical field æ¬å®ç¨æ°åæå ³äºä¸ç§ææçµå¨æ¬è¿å¸çç»æï¼å°¤å ¶æ¯æä¸ç§äºæä½ä½¿ç¨æ¶ä¸ä» æ´ä¸ºå¿«éãç®ä¾¿ï¼ä¸ä¹æ´å ·æä½¿ç¨å®å ¨æ§ï¼èå¨æ´ä½æ½è¡ä½¿ç¨ä¸æ´å ·å®ç¨ä¾¿å©åæç¹æ§çææçµå¨æ¬è¿å¸çç»æãThe utility model relates to a portable electric transport suction cup structure, in particular to a suction cup that is not only faster and easier to operate, but also more secure in use, and more practical and convenient in overall implementation and use. Portable electric handling suction cup structure. èæ¯ææ¯Background technique ä¸è¬å¸¸å¯è§å°ä¸è äºæ¬è¿å¤§åç»çãç³æç­å æ»æè´¨ç©ä½æ¶ï¼ä¸ºè½ä¾¿å©è¿è¡æ¬è¿ç§»å¨ãé²æ­¢äºæ¬å¨æ¶å æ½åä¸æé ææ»è±æè½å¯¼è´å ¶ç ´ç¢ä¼¤äººçæ åµåçãåé¿å äºè¯¥å æ»æè´¨è¡¨é¢çä¸æé¨èæ±¡çè¿¹ç­ï¼èé½ä¼å©ç¨æ¬è¿å¸çæ¥è¾

**[p0002]**

å©è¿è¡æ¬ç§»ãGenerally, it can be seen that when carrying large glass, stone and other smooth material objects, in order to facilitate the handling and movement, to prevent the situation that it is not easy to slip off and fall due to the force applied during the movement, causing it to break and hurt people, and to avoid this The surface of the smooth material leaves traces of hand dirt, etc., and the handling suction cups are used to assist in the handling. å ¶ä¸­ï¼å¦å¾5æç¤ºå³ä¸ºä¸è¬å¸¸è§çæ¬è¿å¸ç6ï¼è¯¥æ¬è¿å¸ç6ä¸»è¦è®¾æä¸å¸çä½61ï¼äºè¯¥å¸çä½61ä¸ç«¯è¿ç»åºè®¾ä¸æææé¨62ï¼è¯¥ææé¨62åä¸­ç©ºç¶å ·ææ°é621ä¸å¸çä½61è¿ç»å¯¼éï¼äºè¯¥ææé¨62æ°é621å è®¾æå§ç­63ï¼è¯¥å§ç­63å¹¶åææé¨62å¤å¸è®¾ææåé¨631ï¼èäºææé¨62ä¸åå¦å¯¹è¯¥æ°é621è®¾ææ³æ°é64ï¼å¦æ­¤ä¸æ¥ï¼äºä½¿ç¨æ¶ï¼å¦å¾6ãå¾7æç¤ºï¼å°è¯¥æ¬è¿å¸ç6çå¸çä½61è´´éäºå æ»æè´¨è¡¨é¢ï¼å©ç¨æåå§ç­63å¸è®¾äºææé¨62å¤çæåé¨631ï¼ä»¤å¸çä½61ä¸å

**[p0003]**

æ»æè´¨è¡¨é¢é´çç©ºæ°ç»æ°é621é­å§ç­63åå¤æ½åºåçç©ºç¶ï¼èå³è½ç±è¯¥ææé¨61å°æ¬è¿å¸ç6è¿åè¢«å¸éçå æ»æè´¨ä¸å¹¶æ¬è¿ç§»å¨ï¼äºæ¬è¿è³å®ä½ååå¯å¦åå¾8æç¤ºæåè¯¥æ³æ°é64ä»¤å¤çç©ºæ°è¿å ¥å¸çä½61ä¸å æ»æè´¨è¡¨é¢é´ï¼ä»¥è½è®©è¯¥æ¬è¿å¸ç6ä¸å æ»æè´¨è¡¨é¢ç¸è±ç¦»ãWherein, as shown in Figure 5, it is a common handling suction cup 6, the handling suction cup 6 is mainly provided with a suction cup body 61, and a handle portion 62 is fixedly connected to the upper end of the suction cup body 61, and the handle portion 62 is hollow and has a The air passage 621 is connected with the suction cup body 61, and a pump 63 is arranged in the air passage 621 of the handle portion 62. The air channel 621 is provided with a vent valve 64; in this way, when in use, as shown in Figure 6 and Figure 7, the suction cup body 61 of the transport suction cup 6 is attached to the surface of the smooth material, and the pressing pump 63 is used to protrude on the The pressing part 631 outside the handle part 62 makes the air between the sucker body 61 and the surface of the smooth material drawn out by the pump 63 through the air passage 621 to be vacuum-like, and the handle part 61 can carry the sucker 6 together with the absorbed The smooth material is transported and moved together. After being transported to the location, the air release valve 64 can be pressed as shown in FIG. .

**[p0004]**

ç¶èï¼ä¸è¿°æ¬è¿å¸çè½å¯è¾¾å°å¸éå¨å æ»æè´¨è¡¨é¢ï¼ä½¿å ¶ä¾¿äºæ¬è¿ç§»å¨çé¢æåæï¼ä½å¨å ¶å®é æä½å®æ½ä½¿ç¨ä¸­å´åç°å ¶å ·æä¸åç¼ºç¹ï¼However, although the above-mentioned handling suction cup can achieve the expected effect of being adsorbed on the surface of a smooth material, making it easy to carry and move, it is found to have the following disadvantages in its actual operation and use: 1.è¯¥ç»æäºæä½ä¸ãå ¶éç±ä½¿ç¨è åå¤æåè¯¥å§ç­çæåé¨ï¼æ¹è½ä»¤å¸çä½ä¸å æ»æè´¨è¡¨é¢é´çç©ºæ°é­æ½åºï¼ä½¿å ¶äºä½¿ç¨æ¶ä¸ä» æ¾å¾è¾ä¸ºéº»ç¦ä¸ä¾¿ï¼ä¸ä¹è¾ä¸ºèæ¶èåã1. In terms of operation, the user needs to repeatedly press the pressing part of the pump to draw out the air between the suction cup body and the surface of the smooth material, which is not only troublesome and inconvenient to use, but also relatively Time-consuming and labor-intensive. 2.è¯¥ç»æäºæä½ä¸ï¼å ¶ç±äºä¸ºæå¨æä½æ¹å¼å¹¶æ æ³è¾¾å°ç¡®å®æ°å¯çç©ºææï¼ä½¿å¾äºæ¬è¿ç§»å¨è¿ç¨ä¸­ï¼å¤çç©ºæ°ææç¼æ

**[p0005]**

¢è¿å ¥å¸çä½ä¸å æ»æè´¨è¡¨é¢ä¹é´ï¼é ææ¾å¨çç°è±¡åçï¼èéäºä½¿ç¨ä¸æ®µæ¶é´åå³åè¡æå¨å§ç­æåé¨å°ç©ºæ°æ½åºï¼ä¸ä» æ¾å¾ä½¿ç¨ä¸è¾ä¸ºéº»ç¦ä¸ä¾¿ï¼ä¸æ´å ·æä½¿ç¨ä¸çå±é©æ§ã2. In terms of operation, the structure is manually operated and cannot achieve an airtight vacuum effect, so that during the process of handling and moving, the outside air can easily slowly enter between the suction cup body and the smooth material surface, resulting in loosening. , and after using for a period of time, it is necessary to press the pressing part of the pump to extract the air, which is not only troublesome and inconvenient to use, but also dangerous to use. åæå å®¹Contents of the invention æ¬å®ç¨æ°åçç®çå¨äºæä¾ä¸ç§ææçµå¨æ¬è¿å¸çç»æï¼å ¶äºè¯¥å¸çä½è®¾æçç©ºæ³µï¼è¯¥çç©ºæ³µå¹¶åæ§å¶åå æææ§ä½å¨ï¼ä»¥äºå°è¯¥å¸çä½è´´éå¨å æ»æè´¨è¡¨é¢åï¼è½å©ç¨æ§å¶åå æ§å¶è¯¥çç©ºæ³µå°å¸çä½ä¸å

**[p0006]**

æ»æè´¨è¡¨é¢é´çç©ºæ°åå¤æ½åºï¼å¹¶äºå ¶ä¸¤è é´åæ°å¯ç¶æåæç»­åå¤æ½åºç©ºæ°ï¼ç±æ­¤ï¼ä¸ä» äºæä½ä½¿ç¨ä¸æ´ä¸ºè¿ éæ¹ä¾¿ï¼ä¸ä¹è½è¾¾å°æ´ä½³çæ°å¯åæï¼å¹¶ç±æç»­åå¤æ½åºç©ºæ°ä»¥è½é¿å äºæ¬ç§»è¿ç¨ä¸­äº§çæ¾è±ãæè½ï¼èæ´å¢å ¶ä½¿ç¨ä¾¿å©æ§åå®å ¨æ§ãThe purpose of this utility model is to provide a portable electric transport suction cup structure, which is provided with a vacuum pump on the suction cup body, and the vacuum pump is controlled and actuated by the control unit, so that after the suction cup body is attached to the smooth material surface, it can be used The control unit controls the vacuum pump to draw out the air between the suction cup body and the surface of the smooth material, and continues to draw out the air after the two are in an airtight state; thus, it is not only faster and more convenient to operate, but also It can also achieve a better airtight effect, and the air is continuously drawn out to avoid loosening and falling during the moving process, which increases its convenience and safety.

**[p0007]**

æ¬å®ç¨æ°åçç®çæ¯è¿æ ·å®ç°çï¼ä¸ç§ææçµå¨æ¬è¿å¸çç»æï¼ä¸»è¦äºå¸çä½ä¸ç«¯åºè®¾æææé¨ï¼å¦äºå¸çä½è®¾æçç©ºæ³µï¼è¯¥çç©ºæ³µå¹¶ç»ä¸æ°éä¸å¸çä½åºç«¯é¢è¿æ¥å¯¼éï¼ä¸ä¾ç»çç©ºæ³µçµæºççµæºé¨ä¸æè¿°çç©ºæ³µä¹é´è¿æ¥ä¸æ§å¶åå ï¼The purpose of this utility model is achieved in this way, a hand-held electric transport sucker structure, mainly fixed with a handle on the upper end of the sucker body, and a vacuum pump is provided on the sucker body, and the vacuum pump is connected to the bottom end surface of the sucker body through an air channel. through, a control unit is connected between a power supply unit for supplying power to the vacuum pump and the vacuum pump; ç±æ­¤ï¼ä»¥è½ä»¤çç©ºæ³µèªå¨å°å¸çä½ä¸å æ»æè´¨è¡¨é¢é´çç©ºæ°æç»­åå¤æ½åºï¼è®©ä½¿ç¨è ä»¥ææ¡æææé¨æä½ä½¿ç¨ï¼ä¸ä» äºæä½ä½¿ç¨ä¸æ´ä¸ºè¿ éæ¹ä¾¿ï¼ä¸ä¹è½è¾¾å°æ´ä½³çæ°å¯åæï¼å¹¶ç±æç»­åå¤æ½åºç©ºæ°ä»¥è½é¿å

**[p0008]**

äºæ¬ç§»è¿ç¨ä¸­äº§çæ¾è±ãæè½ãThus, the vacuum pump can automatically continuously draw out the air between the suction cup body and the surface of the smooth material, allowing the user to hold the handle to operate and use, which is not only faster and more convenient in operation and use, but also achieves better Excellent airtight effect, and the air is continuously pumped out to avoid loosening and falling during the moving process. è¯¥å¸çä½ä¸ç«¯åºè®¾çææé¨åä¸­ç©ºç¶å ·ææè¿°æ°éï¼ä¸äºæ°éä¸ç«¯è®¾æè¿æ°éï¼äºæ°éå åè®¾ææè¿°çç©ºæ³µãThe handle part fixed on the upper end of the sucker body is hollow and has the air passage, and an air inlet valve is arranged at one end of the air passage, and the vacuum pump is arranged in the air passage. è¯¥æ§å¶åå è®¾æååè¡¨ï¼ä»¥ä¾ä½¿ç¨è è½è½»æå¾ç¥å¸çä½ä¸å æ»æè´¨è¡¨é¢é´çååååãThe control unit is provided with a pressure gauge so that the user can easily know the pressure change between the suction cup body and the surface of the smooth material.

**[p0009]**

è¯¥æ§å¶åå è®¾æåå æºï¼ä»¥ä¾æ¾ç¤ºä¸åä½¿ç¨ç¶æãThe control unit is provided with a light source for displaying different usage states. è¯¥æ§å¶åå è®¾æèé¸£å¨ï¼ä»¥ä¾ä¾ä¸åä½¿ç¨ç¶æååºè­¦æ¥å£°åãThe control unit is provided with a buzzer for sending out alarm sounds according to different usage states. éå¾è¯´æDescription of drawings å¾1ï¼æ¬å®ç¨æ°åçç«ä½ç»æå¾ãFig. 1: The three-dimensional structural diagram of the utility model. å¾2ï¼æ¬å®ç¨æ°åçç«ä½ç»æå±é¨æ¾å¤§å¾ãFigure 2: Partial enlarged view of the three-dimensional structure of the utility model. å¾3ï¼æ¬å®ç¨æ°åçä½¿ç¨ç¶æåè§å¾ä¸ãFigure 3: Sectional view 1 of the utility model in use. å¾4ï¼æ¬å®ç¨æ°åçä½¿ç¨ç¶æåè§å¾äºãFigure 4: Sectional view II of the utility model in use. å¾5ï¼å·²ç¥çç«ä½ç»æå¾ãFigure 5: Diagram of known three-dimensional structures. å¾6ï¼å·²ç¥çä½¿ç¨ç¶æåè§å¾ä¸ãFigure 6: Sectional view 1 of a known state of use.

**[p0010]**

å¾7ï¼å·²ç¥çä½¿ç¨ç¶æåè§å¾äºãFigure 7: The second cross-sectional view of the known state of use. å¾8ï¼å·²ç¥çä½¿ç¨ç¶æåè§å¾ä¸ãFigure 8: Section 3 of the known state of use. éå¾æ å·ï¼Figure number: 1Â Â Â Â Â Â å¸çä½Â Â Â Â Â Â Â Â Â Â Â Â Â Â Â 2Â Â Â Â Â ææé¨1 Suction cup body 2 Handle 21Â Â Â Â Â æ°éÂ Â Â Â Â Â Â Â Â Â Â Â Â Â Â Â Â 22Â Â Â Â è¿æ°é21 Airway 22 Intake valve 3Â Â Â Â Â Â çç©ºæ³µÂ Â Â Â Â Â Â Â Â Â Â Â Â Â Â 4Â Â Â Â Â æ§å¶åå 3 Vacuum pump 4 Control unit 41Â Â Â Â Â å¼å ³é®Â Â Â Â Â Â Â Â Â Â Â Â Â Â Â 42Â Â Â Â ååè¡¨41 Open key 42 Pressure gauge 43Â Â Â Â Â åå æºÂ Â Â Â Â Â Â Â Â Â Â Â Â Â Â 44Â Â Â Â èé¸£å¨43 Light source 44 Buzzer 5Â Â Â Â Â Â çµæºé¨Â Â Â Â Â Â Â Â Â Â Â Â Â Â Â 6Â Â Â Â Â æ¬è¿å¸ç5 Power supply unit 6 Carrying suction cup 61Â Â Â Â Â å¸çä½Â Â Â Â Â Â Â Â Â Â Â Â Â Â Â 62Â Â Â Â ææé¨61 Suction cup body 62 Handle 621Â Â Â Â æ°éÂ Â Â Â Â Â Â Â Â Â Â Â Â Â Â Â Â 63Â Â Â Â å§ç­621 Airway 63 Pump

**[p0011]**

631Â Â Â Â æåé¨Â Â Â Â Â Â Â Â Â Â Â Â Â Â Â 64Â Â Â Â æ³æ°é631 Press part 64 Air release valve å ·ä½å®æ½æ¹å¼Detailed ways é¦å ï¼è¯·åé å¾1ãå¾2æç¤ºï¼æ¬å®ç¨æ°åä¸»è¦äºå¸çä½1ä¸ç«¯åºè®¾æææé¨2ï¼è¯¥ææé¨2åä¸­ç©ºç¶å ·ææ°é21ä¸å¸çä½1åºç«¯é¢è¿ç»å¯¼éï¼ä¸äºè¯¥æ°é21ä¸ç«¯è®¾æè¿æ°é22ï¼äºè¯¥æ°é21å è®¾æçç©ºæ³µ3ï¼ä¸ä¾ç»çç©ºæ³µ3çµæºççµæºé¨5ä¸æè¿°çç©ºæ³µ3ä¹é´è¿æ¥ä¸æ§å¶åå 4ï¼èäºè¯¥æ§å¶åå 4åå¯åå«è®¾æå¼å ³é®41ãååè¡¨42ãåå æº43åèé¸£å¨44ãFirst, please refer to Fig. 1 and Fig. 2, the utility model is mainly provided with a handle part 2 on the upper end of the sucker body 1, the handle part 2 is hollow and has an air passage 21 connected to the bottom surface of the sucker body 1, and One end of the air passage 21 is provided with an air inlet valve 22, and a vacuum pump 3 is arranged in the air passage 21. A control unit 4 is connected between a power supply unit 5 for supplying power to the vacuum pump 3 and the vacuum pump 3, and the control unit 4 is connected to the vacuum pump 3. The unit 4 can be respectively provided with a switch key 41 , a pressure gauge 42 , a light source 43 and a buzzer 44 .

**[p0012]**

æ¬å®ç¨æ°åäºå®æ½ä½¿ç¨æ¶ï¼è¯·ä¸å¹¶åé å¾3æç¤ºï¼å ¶ä»¤è¯¥å¸çä½1ç¸éäºå æ»æè´¨è¡¨é¢åï¼æå¨è¯¥æ§å¶åå 4çå¼å ³é®41ä»¤çç©ºæ³µ3ç±çµæºé¨5è·å¾çµåä¾åºåå¼å§ä½å¨ï¼å°è¯¥å¸çä½1ä¸å æ»æè´¨è¡¨é¢é´çç©ºæ°ç»ææé¨2å çæ°é21åå¤æ½åºï¼å¾ è¯¥å¸çä½1ä¸å æ»æè´¨è¡¨é¢é´åä¸å®å ¨æ°å¯ç¶æåï¼å³è½å©ç¨ææé¨2å°å¸çä½1è¿åå æ»æè´¨ä¸å¹¶æ¬è¿ç§»å¨ï¼æ­¤æ¶è¯¥çç©ºæ³µ3ä»æç»­ä½å¨ä»¤å¸çä½1ä¸å æ»æè´¨è¡¨é¢é´ç¡®å®åä¸æä½³çæ°å¯ç¶æï¼èå¨å ¶ä½¿ç¨è¿ç¨ä¸­ä½¿ç¨è å¯è½»æç±æ§å¶åå 4çååè¡¨42å¾ç¥è¯¥å¸çä½1ä¸å æ»æè´¨è¡¨é¢é´çååååï¼åæ¶ä¹è½ç±è¯¥åå æº43åèé¸£å¨44æ¸ æ¥å¾ç¥å ¶ä½¿ç¨ç¶æï¼èå¨å°å æ»æè´¨ç©ä½æ¬è¿è³å®ç¹åï¼å³å¯å¦å¾4æç¤ºï¼ç±æå¨è¯¥ä¸ææé¨2æ°é21è¿ç»å¯¼éçè¿æ°é22ï¼ä»¤å¤çç©ºæ°è¿å ¥å¸çä½1ä¸å æ»æè´¨è¡¨é¢é´ï¼ä»¥è½è½»æå°è¯¥å¸çä½1åç¦»åä¸ãWhen the utility model is implemented and used, please refer to Fig. 3 together. After the suction cup body 1 is attached to the smooth material surface, press the switch key 41 of the control unit 4 to make the vacuum pump 3 obtain power from the power supply unit 5. Start to move after the supply, the air between the suction cup body 1 and the smooth material surface is drawn out through the air passage 21 in the handle part 2, and after the suction cup body 1 and the smooth material surface are in a completely airtight state, that is, The suction cup body 1 and the smooth material can be transpo

**[p0012]**

rted and moved by using the handle part 2. At this time, the vacuum pump 3 is still in operation so that the suction cup body 1 and the surface of the smooth material are indeed in an excellent airtight state, and during its use The user can easily know the pressure change between the suction cup body 1 and the surface of the smooth material from the pressure gauge 42 of the control unit 4, and can also clearly know its use status from the light source 43 and the buzzer 44. After transporting the smooth material object to a fixed point, as shown in Figure 4, by pressing the air intake valve 22 connected to the air passage 21 of the handle part 2, the outside air enters between the suction cup body 1 and the surface of the smooth material, In order to be able to separate and remove the sucker body 1 easily.

**[p0013]**

ç±ä»¥ä¸æè¿°ï¼è¯¥å ä»¶çç»æä¸ä½¿ç¨å®æ½è¯´æå¯ç¥ï¼æ¬å®ç¨æ°åä¸å·²ç¥ç¸è¾ä¹ä¸ï¼ç¡®å ·æä¸åä¼ç¹ï¼As can be seen from the above, the composition of the element and the instructions for use, the utility model has the following advantages compared with the known ones: 1.æ¬å®ç¨æ°åäºæä½ä½¿ç¨ä¸ï¼ç±äºå ¶å©ç¨çç©ºæ³µèªå¨å°å¸çä½ä¸å æ»æè´¨è¡¨é¢é´çç©ºæ°åå¤æ½åºï¼ä»¤å ¶ä¿æä¸æ°å¯ç¶æï¼ä½¿å¾å ¶äºä½¿ç¨æ¶ä¸ä» æ´ä¸ºå¿«éï¼ä¸ä¹æ´å ·ç®æãä¾¿å©åææ§ã1. In terms of operation and use, the utility model uses a vacuum pump to automatically draw out the air between the suction cup body and the surface of the smooth material to keep it in an airtight state, making it not only faster in use, but also more efficient. Simple, convenient and functional. 2.æ¬å®ç¨æ°åäºæä½ä½¿ç¨ä¸ï¼ç±äºå ¶çç©ºæ³µäºå°å¸çä½ä¸å æ»æè´¨è¡¨é¢é´ç©ºæ°æ½åºåï¼å ¶ä»ç»§ç»­è¿è½¬æ½åºç©ºæ°ï¼ä½¿å¾äºå¸çä½ä¸å æ»æè´¨è¡¨é¢é´è½æç»­ä¿æä¸æä½³çæ°å¯ç¶æãä¸æ¾è±ãä¸æè½ï¼èä¸ä»

**[p0014]**

å¨ä½¿ç¨ä¸æ´å ·ä¾¿å©æ§ï¼ä¸ä¹å ·æ´å çä½¿ç¨å®å ¨æ§ã2. In operation and use of the utility model, after the vacuum pump pumps out the air between the suction cup body and the smooth material surface, it continues to operate to pump out air, so that an optimal air can be continuously maintained between the suction cup body and the smooth material surface. It is not only more convenient to use, but also more secure to use.

---

Generated by IPtorch. Verify legal conclusions against the official publication.
