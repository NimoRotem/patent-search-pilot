# 42. A kind of vacuum system of heavy hydraulic overturning rotating suction disc suspender

- **Archive rank:** 42 of 50
- **Publication:** [CN-208200110-U](https://patents.google.com/patent/CN208200110U/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/064520142/publication/CN208200110U?q=pn%3DCN208200110U)
- **Publication date:** 2018-12-07
- **Filing date:** 2018-05-08
- **Earliest priority:** 2018-05-08
- **Family:** 64520142
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** GUANGZHOU COWEST MACHINERY EQUIPMENT CO LTD

## Abstract

The utility model discloses a kind of vacuum system of heavy hydraulic overturning rotating suction disc suspender, including being set on sucker and vacuum system connected to it, the vacuum system includes vacuum pump, gas storage component, battery component and pressure vacuum gauge, the pressure vacuum gauge, vacuum pump, gas storage component and sucker are sequentially connected by pipeline, and the battery component is connect with the pressure vacuum gauge and vacuum pump respectively；The gas storage component includes that the check valve connect, air accumulator, solenoid valve and filter are sequentially connected by pipeline, and the check valve is connect with the vacuum pump, and the filter is connect with the sucker；The battery component includes electric-quantity display device, low tension switch, digital display pressure switch and battery module.The utility model is driven by battery, band pressure detecting, vacuum alarm, low pressure alarming；Based on the opening and closing of PLC remote controler long-distance intelligent control vacuum pump, to realize absorption and release of the sucker to material.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-208200110-U/pdf000.png)

![Sketch 1 for CN-208200110-U](https://nimo.iptorch.com/refdrawing/CN-208200110-U/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-208200110-U/pdf001.png)

![Sketch 2 for CN-208200110-U](https://nimo.iptorch.com/refdrawing/CN-208200110-U/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/CN-208200110-U/pdf002.png)

![Sketch 3 for CN-208200110-U](https://nimo.iptorch.com/refdrawing/CN-208200110-U/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/CN-208200110-U/pdf003.png)

![Sketch 4 for CN-208200110-U](https://nimo.iptorch.com/refdrawing/CN-208200110-U/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/CN-208200110-U/pdf004.png)

![Sketch 5 for CN-208200110-U](https://nimo.iptorch.com/refdrawing/CN-208200110-U/pdf004.png)

## Claims

### Claim 1 (independent)

a kind of vacuum system of heavy hydraulic overturning rotating suction disc suspender, including it is set on sucker and vacuum connected to it System, it is characterised in that: the vacuum system includes vacuum pump, gas storage component, battery component and pressure vacuum gauge, the vacuum Pressure gauge, vacuum pump, gas storage component and sucker are sequentially connected by pipeline, the battery component respectively with the pressure vacuum gauge It is connected with vacuum pump； The gas storage component includes that the check valve connect, air accumulator, solenoid valve and filter are sequentially connected by pipeline, described unidirectional Valve is connect with the vacuum pump, and the filter is connect with the sucker； The battery component includes electric-quantity display device, low tension switch, digital display pressure switch and battery module, the battery module point It is not connect with the electric-quantity display device, low tension switch and digital display pressure switch.

### Claim 2

a kind of vacuum system of heavy hydraulic overturning rotating suction disc suspender according to claim 1, it is characterised in that: also Including the wireless remote controlled receiver with PLC remote controler by wireless connection, the wireless remote controlled receiver and the battery component Connection.

### Claim 3

a kind of vacuum system of heavy hydraulic overturning rotating suction disc suspender according to claim 1, it is characterised in that: institute It states battery module to be fixed on the sucker by sealing plate, the battery module includes battery and charger.

### Claim 4

a kind of vacuum system of heavy hydraulic overturning rotating suction disc suspender according to claim 1, it is characterised in that: institute The outside for stating vacuum pump is equipped with vacuum pump shield.

### Claim 5

a kind of vacuum system of heavy hydraulic overturning rotating suction disc suspender according to claim 1, it is characterised in that: institute The outside for stating gas storage component is equipped with air accumulator shield.

### Claim 6

a kind of vacuum system of heavy hydraulic overturning rotating suction disc suspender according to claim 1, it is characterised in that: institute The outside for stating battery component is equipped with battery shield, and the electric-quantity display device, low tension switch and digital display pressure switch are respectively arranged on institute It states on battery shield.

## Full description

Description

A kind of vacuum system of heavy hydraulic overturning rotating suction disc suspender

Technical field

The utility model relates to vacuum system field, especially a kind of vacuum system of heavy hydraulic overturning rotating suction disc suspender

System.

Background technique

Suspender refers to the device of hanged weight in hoisting machinery.The hanged most common suspender of work piece is suspension hook, suspender belt,

There is also hanging ring, hoisting suction cup, clamp and pallet forks etc..It is widely used in hoisting and hanging industry.

Existing suspender is generally comprised including sunpender, the suction cup carrier connecting with sunpender and the sucker being mounted in suction cup carrier.

Vacuum system is applied on suspender, and sucker utilizes vacuum suction material, has the advantages that absorption is secured, is easy to control absorptionï¼But

It is existing vacuum system since structure is complicated, connects power supply, using trouble often through socketï¼No low-voltage variation, short circuit are protected

Shield, influences the service life of vacuum pumpï¼No remote control suction is put, and the risk of production accident is higher.

Utility model content

In order to overcome the disadvantages mentioned above of the prior art, the purpose of the utility model is to provide one kind to be driven by battery, is with pressure

Power detection, vacuum alarm, low pressure alarming, remote control inhale the vacuum system for the glass evacuated sucker rotary hanger of heavy type put.

The technical scheme adopted by the utility model to solve the technical problem is as follows:

A kind of vacuum system of heavy hydraulic overturning rotating suction disc suspender, including be set on sucker and connected to it true

Empty set system, the vacuum system includes vacuum pump, gas storage component, battery component and pressure vacuum gauge, the pressure vacuum gauge, true

Sky pump, gas storage component and sucker are sequentially connected by pipeline, the battery component respectively with the pressure vacuum gauge and vacuum pump

Connectionï¼

The gas storage component includes that the check valve connect, air accumulator, solenoid valve and filter are sequentially connected by pipeline, described

Check valve is connect with the vacuum pump, and the filter is connect with the suckerï¼

The battery component includes electric-quantity display device, low tension switch, digital display pressure switch and battery module, the battery mould

Block is connect with the electric-quantity display device, low tension switch and digital display pressure switch respectively.

As further improvement of the utility model: further including being connect with PLC remote controler by the wireless remote control being wirelessly connected

Device is received, the wireless remote controlled receiver is connect with the battery component.

As further improvement of the utility model: the battery module is fixed on the sucker by sealing plate, described

Battery module includes battery and charger.

As further improvement of the utility model: the outside of the vacuum pump is equipped with vacuum pump shield.

As further improvement of the utility model: the outside of the gas storage component is equipped with air accumulator shield.

As further improvement of the utility model: the outside of the battery component is equipped with battery shield, and the electricity is aobvious

Show that device, low tension switch and digital display pressure switch are respectively arranged on the battery shield.

Compared with prior art, the utility model has the beneficial effects that

The utility model is driven by battery, band pressure detecting, vacuum alarm, low pressure alarmingï¼Based on the long-range intelligence of PLC remote controler

It can control the opening and closing of vacuum pump, to realize absorption and release of the sucker to material.

Detailed description of the invention

Fig. 1 is the block schematic illustration of the utility model.

Fig. 2 is the structural schematic diagram of the utility model.

Specific embodiment

Now in conjunction with Detailed description of the invention, the present invention will be further described with embodiment:

A kind of vacuum system of heavy hydraulic overturning rotating suction disc suspender, including be set on sucker 2 and connected to it

Vacuum system, the vacuum system include vacuum pump 11, gas storage component, battery component and pressure vacuum gauge 14, the vacuum pressure

Power table 14, vacuum pump 11, gas storage component and sucker 2 are sequentially connected by pipeline, the battery component respectively with the vacuum pressure

Power table 14 and vacuum pump 11 connectï¼

The gas storage component includes that the check valve 121 connect, air accumulator 122, solenoid valve 123 and mistake are sequentially connected by pipeline

Filter 124, the check valve 121 are connect with the vacuum pump 11, and the filter 124 is connect with the sucker 2ï¼

The battery component includes electric-quantity display device 131, low tension switch 132, digital display pressure switch 133 and battery module

134, the battery module 134 is connect with the electric-quantity display device 131, low tension switch 132 and digital display pressure switch 133 respectively.

It further include the wireless remote controlled receiver with PLC remote controler by being wirelessly connected, the wireless remote controlled receiver and institute

State battery component connection.

The battery module 134 is fixed on the sucker 2 by sealing plate 137, and the battery module 134 includes battery

135 and charger 136.

The outside of the vacuum pump 11 is equipped with vacuum pump shield 111.

The outside of the gas storage component is equipped with air accumulator shield 125.

The outside of the battery component is equipped with battery shield 138, the electric-quantity display device 131, low tension switch 132 and digital display

Pressure switch 133 is respectively arranged on the battery shield 138.

The pressure vacuum gauge 14 is used for the pressure for detecting sucker 2 and being adsorbed between materialï¼The low tension switch 132 is used

In low pressure alarming, low pressure disconnecting circuit, protection vacuum pumpï¼The digital display pressure switch is used for vacuum alarm, short-circuit protection, intelligence

Control pressure.

Opening and closing of the utility model based on PLC remote controler long-distance intelligent control vacuum pump, to realize sucker to object

The absorption and release of material.

In conclusion after those skilled in the art read the utility model file, skill according to the present utility model

Art scheme and technical concept are not necessarily to creative mental labour and make other various corresponding conversion schemes, and it is practical new to belong to this

The range that type is protected.

---

Generated by IPtorch. Verify legal conclusions against the official publication.
