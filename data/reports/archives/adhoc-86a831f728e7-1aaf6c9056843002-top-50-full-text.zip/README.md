# Top 50 full-text patent archive

Search: Cordless Handheld Vacuum Lifter With Grip-Loss Warning Indicator

This summary introduces a selection of concepts that are described further in the detailed description. It is not intended to identify essential features of the claimed subject matter, nor to limit the scope of the claims.

A cordless handheld vacuum lifter is disclosed. The lifter has a rigid body comprising a handle, and a suction cup carried by the rigid body. The suction cup comprises a flexible sealing lip which, when placed against a workpiece, bounds a sealed region between the suction cup and the workpiece. An electric vacuum pump is disposed within the rigid body and draws air from the sealed region through a port so as to establish a grip vacuum in the sealed region, the grip vacuum holding the suction cup, and hence a load carried by the suction cup, against the workpiece. A pressure sensor monitors the grip vacuum. A warning indicator is carried by the rigid body and is driven by the pressure sensor. A rechargeable battery carried by the rigid body powers the electric vacuum pump.

The grip vacuum is treated throughout this disclosure as a positive magnitude: it is the amount by which the pressure in the sealed region is below the ambient pressure outside the lifter, so that a larger grip vacuum means a firmer grip and a decaying grip is a falling grip vacuum.

The warning indicator activates when the grip vacuum falls to a warning vacuum level. The warning vacuum level is not the level at which the grip fails and is not the level at which the pump is asked to run again. It is a level that is greater than a release vacuum level, the release vacuum level being the grip vacuum below which the suction cup can no longer retain the load. Because the warning vacuum level is above the release vacuum level, the grip vacuum on a decaying grip reaches the warning vacuum level first and the release vacuum level only afterwards. The warning indicator therefore activates while the suction cup is still holding the load, and there is grip in reserve at the moment the user is told. That reserve is what the user spends in getting the panel onto a stand, against a wall, or back onto the stack.

This ordering of levels is what makes the alarm useful in a hand-held tool rather than merely informative. A frame-mounted or suspended lifter can respond to a failing grip by itself, by cutting in a second vacuum source or by refusing to move. A cordless handheld lifter has no such recourse: the only actuator available is the person holding the handle, and a person needs an interval in which to act. Defining the warning threshold with respect to the release vacuum level, rather than with respect to the working vacuum level or with respect to a rate of change, is what makes that interval exist by construction rather than by luck.

In embodiments, the warning indicator remains active for as long as the grip vacuum stays at or below the warning vacuum level, so that a grip which is decaying continuously produces a warning which persists rather than a single transient. In embodiments, the warning indicator is positioned on the rigid body where it is perceptible to a user whose hand is on the handle and whose eyes are on the panel. In embodiments, the pressure sensor is in fluid communication with the sealed region, so that what is monitored is the grip vacuum acting on the workpiece itself rather than a proxy elsewhere in the machine.

Because the electric vacuum pump, the pressure sensor, the warning indicator, and the rechargeable battery are all carried by the rigid body, the lifter grips, monitors, and warns without any hose, cord, or external controller, and can be taken up a ladder or onto a scaffold in one hand.

A method of lifting a workpiece with such a lifter is also disclosed. The method includes placing the flexible sealing lip against the workpiece, drawing air from the sealed region with the electric vacuum pump to establish the grip vacuum, monitoring the grip vacuum with the pressure sensor while the load is carried, and activating the warning indicator when the grip vacuum falls to the warning vacuum level, that is, while the suction cup still retains the load and before the grip vacuum has fallen to the release vacuum level.

1. A cordless handheld vacuum lifter, comprising:

a rigid body comprising a handle;

a suction cup carried by the rigid body, the suction cup comprising a flexible sealing lip configured to bound a sealed region between the suction cup and a workpiece when the flexible sealing lip is placed against the workpiece;

an electric vacuum pump disposed within the rigid body, the electric vacuum pump configured to draw air from the sealed region through a port to establish a grip vacuum in the sealed region, the grip vacuum retaining a load on the suction cup;

a pressure sensor configured to monitor the grip vacuum;

a warning indicator carried by the rigid body and driven by the pressure sensor, the warning indicator configured to activate when the grip vacuum falls to a warning vacuum level, the warning vacuum level being greater than a release vacuum level at which the suction cup ceases to retain the load, such that the warning indicator activates while the suction cup is still retaining the load; and

a rechargeable battery carried by the rigid body and configured to power the electric vacuum pump.

2. The cordless handheld vacuum lifter of claim 1, wherein the warning indicator is configured to remain active for as long as the grip vacuum remains at or below the warning vacuum level, and to deactivate when the grip vacuum returns above the warning vacuum level.

3. The cordless handheld vacuum lifter of claim 1, wherein the electric vacuum pump is configured to raise the grip vacuum to a working vacuum level, and the warning vacuum level is less than the working vacuum level and greater than the release vacuum level.

4. The cordless handheld vacuum lifter of claim 1, wherein the warning indicator is configured to activate when the grip vacuum falls to the warning vacuum level irrespective of whether the electric vacuum pump is operating, such that continued operation of the electric vacuum pump does not suppress activation of the warning indicator.

5. The cordless handheld vacuum lifter of claim 1, wherein the pressure sensor is in fluid communication with the sealed region, such that the grip vacuum monitored by the pressure sensor is the grip vacuum acting on the workpiece.

6. The cordless handheld vacuum lifter of claim 5, further comprising a suction passage within the rigid body connecting the port to an inlet of the electric vacuum pump, and a sensing passage branching from the suction passage on a sealed-region side of the electric vacuum pump and connecting the suction passage to the pressure sensor.

7. The cordless handheld vacuum lifter of claim 1, further comprising a drive path connecting the pressure sensor to the warning indicator, the drive path comprising a threshold circuit configured to compare the grip vacuum monitored by the pressure sensor with the warning vacuum level and to energize the warning indicator when the grip vacuum has fallen to the warning vacuum level.

8. The cordless handheld vacuum lifter of claim 1, wherein the warning indicator is positioned on the rigid body so as to be perceptible to a user gripping the handle.

9. The cordless handheld vacuum lifter of claim 1, wherein the warning indicator comprises at least one of a visual emitter, an audible emitter, and a vibratory emitter. [DRAFTING NOTE: the disclosure does not state the modality of the warning indicator; confirm which of these are supported so that this claim can be made specific, or delete it.]

10. The cordless handheld vacuum lifter of claim 1, wherein the electric vacuum pump, the pressure sensor, the warning indicator, and the rechargeable battery are all carried by the rigid body, such that the cordless handheld vacuum lifter establishes the grip vacuum, monitors the grip vacuum, and activates the warning indicator without connection to any hose, cord, or controller external to the rigid body.

11. The cordless handheld vacuum lifter of claim 1, wherein the port opens into the sealed region through the suction cup, and the cordless handheld vacuum lifter further comprises an exhaust outlet in the rigid body through which the electric vacuum pump discharges to atmosphere the air drawn from the sealed region.

12. The cordless handheld vacuum lifter of claim 1, wherein the flexible sealing lip is configured to conform to and seal against a face of a planar glass or stone panel constituting the workpiece.

13. The cordless handheld vacuum lifter of claim 1, wherein the rechargeable battery is further configured to power the pressure sensor and the warning indicator, and the cordless handheld vacuum lifter further comprises a charging interface on the rigid body configured to receive charging power for the rechargeable battery from a source external to the rigid body.

14. The cordless handheld vacuum lifter of claim 1, wherein the handle stands above an upper side of the rigid body and the suction cup depends from a lower side of the rigid body, such that a line of action of the load passes through the handle.

15. A method of lifting a workpiece with a cordless handheld vacuum lifter having a rigid body comprising a handle, a suction cup carried by the rigid body and comprising a flexible sealing lip, an electric vacuum pump disposed within the rigid body, a pressure sensor, a warning indicator carried by the rigid body, and a rechargeable battery carried by the rigid body, the method comprising:

placing the flexible sealing lip against a face of the workpiece so that the suction cup, the flexible sealing lip, and the face bound a sealed region;

drawing air from the sealed region through a port with the electric vacuum pump powered by the rechargeable battery, thereby establishing a grip vacuum in the sealed region;

carrying a load on the suction cup by the handle, the load being retained on the suction cup by the grip vacuum;

monitoring the grip vacuum with the pressure sensor while the load is retained; and

activating the warning indicator, driven by the pressure sensor, upon the grip vacuum falling to a warning vacuum level that is greater than a release vacuum level at which the suction cup ceases to retain the load, whereby the warning indicator is activated while the suction cup is still retaining the load and before the grip vacuum has fallen to the release vacuum level.

16. The method of claim 15, further comprising maintaining the warning indicator active for as long as the grip vacuum remains at or below the warning vacuum level.

17. The method of claim 15, wherein drawing air from the sealed region raises the grip vacuum to a working vacuum level, and the warning vacuum level is less than the working vacuum level and greater than the release vacuum level.

18. The method of claim 15, wherein the warning indicator is activated while the electric vacuum pump continues to draw air from the sealed region and the grip vacuum continues to fall.

19. The method of claim 15, further comprising setting the workpiece down, after the warning indicator has been activated and while the grip vacuum remains above the release vacuum level, within a warning interval that elapses between the grip vacuum falling to the warning vacuum level and the grip vacuum falling to the release vacuum level.

20. The method of claim 15, wherein the workpiece is a planar glass or stone panel, and carrying the load comprises carrying the panel with the cordless handheld vacuum lifter unconnected to any hose, cord, or controller external to the rigid body.

In the following description, reference is made to the accompanying drawings, which form a part hereof and in which are shown by way of illustration specific embodiments. Other embodiments may be used and structural changes may be made without departing from the scope of the disclosure. Like numerals refer to like parts throughout.

Terminology used in this disclosure has the following meanings. The grip vacuum is the amount by which the absolute pressure within the sealed region 18 is below the ambient atmospheric pressure surrounding the cordless handheld vacuum lifter 100, expressed as a positive magnitude. A grip vacuum of zero corresponds to no grip at all; the grip vacuum rises as air is removed from the sealed region 18 and falls as air leaks back into it. Statements that the grip vacuum is greater, higher, or above a stated level therefore mean that the pressure difference clamping the suction cup 10 to the workpiece 50 is larger, and that the grip is firmer. This convention is used consistently in the description, in the drawings, and in the claims.

The release vacuum level 66 is the grip vacuum below which the suction cup 10 can no longer retain the load it is carrying, that is, the grip vacuum at which the holding force produced across the area bounded by the flexible sealing lip 12 ceases to exceed the force tending to separate the suction cup 10 from the workpiece 50. The release vacuum level 66 is a property of the particular combination of suction cup 10, workpiece 50, load, and orientation in use, and it is not a setting of the cordless handheld vacuum lifter 100. The warning vacuum level 64, by contrast, is a property of the cordless handheld vacuum lifter 100: it is the grip vacuum at which the warning indicator 32 is driven to activate.

FIG. 1 shows a cordless handheld vacuum lifter 100 in use. The cordless handheld vacuum lifter 100 comprises a rigid body 14 comprising a handle 16, and a suction cup 10 carried by the rigid body 14. In the illustrated embodiment the handle 16 is an arch standing above an upper side of the rigid body 14 and the suction cup 10 depends from a lower side of the rigid body 14, so that the whole of the load hangs below the user's hand and the line of action of the load passes through the handle 16. A workpiece 50, such as a glass pane or a stone slab, is gripped on its face by the suction cup 10 and is carried by the user by way of the handle 16. The cordless handheld vacuum lifter 100 is a single hand-held unit: no hose, no cord, and no external controller is connected to it in use.

[DRAFTING NOTE: The disclosure does not give the outside dimensions of the rigid body 14, the diameter of the suction cup 10, the rated load, or the materials of the rigid body 14 and the flexible sealing lip 12. Please supply these; a filing-quality description would ordinarily state at least a working size range for the suction cup 10, the rated load it is designed to carry, and the elastomer used for the flexible sealing lip 12.]

FIG. 2 is a vertical section through the cordless handheld vacuum lifter 100. The suction cup 10 comprises a flexible sealing lip 12 which projects toward the workpiece 50 and runs around the periphery of the suction cup 10. When the flexible sealing lip 12 is placed against the workpiece 50 it deflects and conforms to the face of the workpiece 50, and the suction cup 10, the flexible sealing lip 12, and the face of the workpiece 50 together bound a sealed region 18. The flexible sealing lip 12 is the only part of the cordless handheld vacuum lifter 100 that touches the workpiece 50 in normal use, and its compliance is what allows the sealed region 18 to be closed against a face that is not perfectly flat or perfectly clean.

An electric vacuum pump 20 is disposed within the rigid body 14. The electric vacuum pump 20 is configured to draw air from the sealed region 18 through a port 22. The port 22 opens into the sealed region 18 through the suction cup 10, and a suction passage 24 within the rigid body 14 connects the port 22 to an inlet of the electric vacuum pump 20. Air drawn from the sealed region 18 is discharged to atmosphere through an exhaust outlet 26 in the rigid body 14. Running the electric vacuum pump 20 removes air from the sealed region 18 and so raises the grip vacuum; the pressure of the surrounding atmosphere acting on the outside of the suction cup 10 then clamps the suction cup 10, and with it the rigid body 14 and the handle 16, to the workpiece 50.

Because the electric vacuum pump 20 is disposed within the rigid body 14 rather than mounted remotely and connected by a hose, the whole of the evacuated volume is short and small: it consists of the sealed region 18, the port 22, and the suction passage 24. A small evacuated volume matters to the behaviour described below, because it means that a leak of a given size produces a rapid and therefore detectable fall in the grip vacuum rather than a slow drift buffered by a large reservoir.

A pressure sensor 30 is configured to monitor the grip vacuum. In the illustrated embodiment the pressure sensor 30 is in fluid communication with the sealed region 18 by way of a sensing passage 34 that branches from the suction passage 24 on the sealed-region side of the electric vacuum pump 20, so that the pressure sensor 30 sees the pressure in the sealed region 18 itself and not a pressure developed elsewhere in the machine. What is monitored is thus the grip actually acting on the workpiece 50.

[DRAFTING NOTE: The disclosure states that the pressure sensor 30 monitors the grip vacuum but does not state where it is plumbed or what type of sensor it is. The sensing passage 34 branching from the suction passage 24 is described here as one way to give the pressure sensor 30 sight of the sealed region 18. Please confirm the sensing location (sealed region, port, suction passage, or pump inlet) and the sensor type (for example piezoresistive gauge-pressure transducer, or a pressure switch with a fixed trip point), and supply the sensing range.]

A warning indicator 32 is carried by the rigid body 14 and is driven by the pressure sensor 30. The warning indicator 32 is placed on the rigid body 14 where it is perceptible to a user whose hand is on the handle 16 and whose attention is on the workpiece 50 and the surroundings rather than on the tool.

[DRAFTING NOTE: The disclosure does not state the modality of the warning indicator 32 - whether it is visual, audible, vibratory, or a combination. Please confirm which are supported, so that the description and the corresponding dependent claim can be made specific. Nothing in this description should be read as an assertion that a particular modality was disclosed.]

The pressure sensor 30 drives the warning indicator 32 over a drive path 36 that includes a threshold circuit 38. The threshold circuit 38 compares the grip vacuum reported by the pressure sensor 30 with the warning vacuum level 64 and energizes the warning indicator 32 when the grip vacuum has fallen to the warning vacuum level 64.

[DRAFTING NOTE: The disclosure states that the pressure sensor 30 drives the warning indicator 32 but does not state how the comparison against the warning vacuum level 64 is implemented. The threshold circuit 38 is described here generically. Please confirm the implementation - a discrete comparator, a microcontroller executing firmware, or a pressure sensor with an integral threshold output - and whether the warning vacuum level 64 is fixed at manufacture or user-adjustable. If it is adjustable, the adjustment means and range are needed.]

A rechargeable battery 40 is carried by the rigid body 14 and is configured to power the electric vacuum pump 20 over a power path 44. The rechargeable battery 40 also supplies the pressure sensor 30 and the warning indicator 32 over the power path 44, so that the monitoring and warning function is available whenever the cordless handheld vacuum lifter 100 is in the user's hand. A charging interface 42 on the rigid body 14 receives charging power for the rechargeable battery 40 from an external source between uses.

[DRAFTING NOTE: The disclosure does not state the battery chemistry, voltage, capac

Generated: 2026-08-26T07:07:08.983279+00:00

48 of 50 publications include both claims and description. Any unavailable source text is called out inside its Markdown file; every file links to the official web records and available sketches.
