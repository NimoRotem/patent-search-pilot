# 35. Vakuumhebegerät mit elektrisch angetriebener Pumpe und Energieversorgung im Handgriff

- **Archive rank:** 35 of 50
- **Publication:** [DE-102010016244-B4](https://patents.google.com/patent/DE102010016244B4/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/042629144/publication/DE102010016244B4?q=pn%3DDE102010016244B4)
- **Publication date:** 2014-08-21
- **Filing date:** 2010-03-30
- **Earliest priority:** 2009-04-06
- **Family:** 42629144
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** WINDEN UND MASCHB GRESSBACH GMBH

## Abstract

Vakuumhebegerät (10) zum Anheben und/oder Handhaben von Werkstücken, mit einer Saugvorrichtung (50), die mittels einer elektrisch angetriebenen Pumpe (80) zwischen einer Saugplatte (54) und einem anzuhebenden Werkstück ein Vakuum erzeugt, wobei für die Pumpe (80) eine Energieversorgung (40) vorgesehen ist, und mit einem Handgriff (20) zum Handhaben des Vakuumhebegerätes (10) und der Saugvorrichtung (50), wobei der Handgriff (20) über zwei parallel voneinander beabstandet angeordnete Halter (70) an einer Halteplatte (53) befestigt ist, an der die Saugplatte (54) angeordnet ist, dadurch gekennzeichnet, dass die Energieversorgung (40) für die Pumpe (80) im Handgriff (20) unterbringbar ist, wobei der Handgriff (20) im Wesentlichen rohrförmig ausgebildet ist, wobei jeder Halter (70) an seinem oberen Ende (71) eine runde Öffnung (73) aufweist, deren Innendurchmesser dem Außendurchmesser des Handgriffs (20) entspricht, wobei der Handgriff (20) durch die Öffnungen (73) hindurchgeführt und darin festgelegt sowie an wenigstens einer Stirnseite (26) verschließbar ist.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-102010016244-B4/000.png)

![Sketch 1 for DE-102010016244-B4](https://nimo.iptorch.com/refdrawing/DE-102010016244-B4/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-102010016244-B4/001.png)

![Sketch 2 for DE-102010016244-B4](https://nimo.iptorch.com/refdrawing/DE-102010016244-B4/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/DE-102010016244-B4/002.png)

![Sketch 3 for DE-102010016244-B4](https://nimo.iptorch.com/refdrawing/DE-102010016244-B4/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/DE-102010016244-B4/003.png)

![Sketch 4 for DE-102010016244-B4](https://nimo.iptorch.com/refdrawing/DE-102010016244-B4/003.png)

[Sketch 5](https://patentimages.storage.googleapis.com/8e/45/28/3695f9dd7ba848/DE102010016244B4_0002.png)

![Sketch 5 for DE-102010016244-B4](https://patentimages.storage.googleapis.com/8e/45/28/3695f9dd7ba848/DE102010016244B4_0002.png)

[Sketch 6](https://patentimages.storage.googleapis.com/b8/4e/07/6e587a5e730256/DE102010016244B4_0003.png)

![Sketch 6 for DE-102010016244-B4](https://patentimages.storage.googleapis.com/b8/4e/07/6e587a5e730256/DE102010016244B4_0003.png)

[Sketch 7](https://patentimages.storage.googleapis.com/e8/cb/86/2ab5b6c8b93e28/DE102010016244B4_0004.png)

![Sketch 7 for DE-102010016244-B4](https://patentimages.storage.googleapis.com/e8/cb/86/2ab5b6c8b93e28/DE102010016244B4_0004.png)

[Sketch 8](https://patentimages.storage.googleapis.com/f5/b6/15/8f506c08fada6b/DE102010016244B4_0005.png)

![Sketch 8 for DE-102010016244-B4](https://patentimages.storage.googleapis.com/f5/b6/15/8f506c08fada6b/DE102010016244B4_0005.png)

## Claims

### Claim 1 (independent)

Vakuumhebegerät (10) zum Anheben und/oder Handhaben von Werkstücken, mit einer Saugvorrichtung (50), die mittels einer elektrisch angetriebenen Pumpe (80) zwischen einer Saugplatte (54) und einem anzuhebenden Werkstück ein Vakuum erzeugt, wobei für die Pumpe (80) eine Energieversorgung (40) vorgesehen ist, und mit einem Handgriff (20) zum Handhaben des Vakuumhebegerätes (10) und der Saugvorrichtung (50), wobei der Handgriff (20) über zwei parallel voneinander beabstandet angeordnete Halter (70) an einer Halteplatte (53) befestigt ist, an der die Saugplatte (54) angeordnet ist, dadurch gekennzeichnet, dass die Energieversorgung (40) für die Pumpe (80) im Handgriff (20) unterbringbar ist, wobei der Handgriff (20) im Wesentlichen rohrförmig ausgebildet ist, wobei jeder Halter (70) an seinem oberen Ende (71) eine runde Öffnung (73) aufweist, deren Innendurchmesser dem Außendurchmesser des Handgriffs (20) entspricht, wobei der Handgriff (20) durch die Öffnungen (73) hindurchgeführt und darin festgelegt sowie an wenigstens einer Stirnseite (26) verschließbar ist.Vacuum lifting device ( 10 ) for lifting and / or handling workpieces, with a suction device ( 50 ) by means of an electrically driven pump ( 80 ) between a suction plate ( 54 ) and a workpiece to be lifted generates a vacuum, wherein for the pump ( 80 ) an energy supply ( 40 ) and with a handle ( 20 ) for handling the vacuum lifting device ( 10 ) and the suction device ( 50 ), whereby the handle ( 20 ) via two mutually spaced apart holders ( 70 ) on a holding plate ( 53 ) is attached to the suction plate ( 54 ), characterized in that the power supply ( 40 ) for the pump ( 80 ) in the handle ( 20 ), whereby the handle ( 20 ) is substantially tubular, each holder ( 70 ) at its upper end ( 71 ) a round opening ( 73 ), the inner diameter of the outer diameter of the handle ( 20 ), wherein the handle ( 20 ) through the openings ( 73 ) and fixed therein and at least one end face ( 26 ) is closable.

### Claim 2

Vakuumhebegerät nach Anspruch 1, dadurch gekennzeichnet, dass der Handgriff (20) einen Schalter (31) für die Pumpe (80) aufweist.Vacuum lifting device according to claim 1, characterized in that the handle ( 20 ) a switch ( 31 ) for the pump ( 80 ) having.

### Claim 3

Vakuumhebegerät nach einem der Ansprüche 1 oder 2, dadurch gekennzeichnet, dass im Handgriff (20) ein Anschluss (41) für die Energieversorgung (40) vorgesehen ist.Vacuum lifting device according to one of claims 1 or 2, characterized in that in the handle ( 20 ) a connection ( 41 ) for the energy supply ( 40 ) is provided.

### Claim 4

Vakuumhebegerät nach Anspruch 3, dadurch gekennzeichnet, dass die Energieversorgung (40) ein Akkumulator (43) oder eine Batterie ist.Vacuum lifting device according to claim 3, characterized in that the power supply ( 40 ) an accumulator ( 43 ) or a battery.

### Claim 5

Vakuumhebegerät nach Anspruch 3 oder 4, dadurch gekennzeichnet, dass an den Anschluss (41) ein Netzteil (90) anschließbar ist.Vacuum lifting device according to claim 3 or 4, characterized in that the connection ( 41 ) a power supply ( 90 ) is connectable.

### Claim 6

Vakuumhebegerät nach einem der Ansprüche 1 bis 5, dadurch gekennzeichnet, dass die Pumpe (80) in einem Gehäuse (35) angeordnet ist, welches am Handgriff (20) anbringbar ist.Vacuum lifting device according to one of claims 1 to 5, characterized in that the pump ( 80 ) in a housing ( 35 ), which on the handle ( 20 ) is attachable.

### Claim 7

Vakuumhebegerät nach einem der Ansprüche 1 bis 6, dadurch gekennzeichnet, dass der Handgriff (20) das Gehäuse (30) einer Taschenlampe ist.Vacuum lifting device according to one of claims 1 to 6, characterized in that the handle ( 20 ) the housing ( 30 ) is a flashlight.

### Claim 8

Vakuumhebegerät nach Anspruch 7, dadurch gekennzeichnet, dass das Gehäuse (35) der Pumpe (80) mit dem Gehäuse (30) der Taschenlampe verschraubbar ist.Vacuum lifting device according to claim 7, characterized in that the housing ( 35 ) of the pump ( 80 ) with the housing ( 30 ) of the flashlight is screwed.

### Claim 9

Vakuumhebegerät nach Anspruch 7 oder 8, dadurch gekennzeichnet, dass das Gehäuse (30) der Taschenlampe an einer Stirnseite (26) mit einem Deckel (33, 92) verschließbar ist.Vacuum lifting device according to claim 7 or 8, characterized in that the housing ( 30 ) of the flashlight on one end face ( 26 ) with a lid ( 33 . 92 ) is closable.

### Claim 10

Vakuumhebegerät nach Anspruch 9, dadurch gekennzeichnet, dass der Deckel (92) mit einem Durchbruch (93) für ein Kabel (94) des Netzteils (90) versehen ist.Vacuum lifting device according to claim 9, characterized in that the lid ( 92 ) with a breakthrough ( 93 ) for a cable ( 94 ) of the power supply ( 90 ) is provided.

### Claim 11

Vakuumhebegerät nach einem der Ansprüche 1 bis 10, dadurch gekennzeichnet, dass die Saugplatte (54) an ihrer dem anzusaugenden Werkstück zugewandten Unterseite (55) eine Gummidichtung (56) aufweist.Vacuum lifting device according to one of claims 1 to 10, characterized in that the suction plate ( 54 ) on its side facing the workpiece to be sucked ( 55 ) a rubber seal ( 56 ) having.

### Claim 12

Vakuumhebegerät nach einem der Ansprüche 1 bis 11, dadurch gekennzeichnet, dass der Handgriff (20) und die Saugplatte (54) an einer Halteplatte (53) montierbar sind.Vacuum lifting device according to one of claims 1 to 11, characterized in that the handle ( 20 ) and the suction plate ( 54 ) on a holding plate ( 53 ) are mountable.

### Claim 13

Vakuumhebegerät nach Anspruch 12, dadurch gekennzeichnet, dass die Saugplatte (54) und die Halteplatte (53) einstückig ausgebildet sind. Vacuum lifting device according to claim 12, characterized in that the suction plate ( 54 ) and the retaining plate ( 53 ) are integrally formed.

### Claim 14

Vakuumhebegerät nach einem der Ansprüche 1 bis 13, dadurch gekennzeichnet, dass die Saugvorrichtung (50) einen Grobfilter (65), eine Filterpatrone (63) und/oder ein Ventil (66) zum Belüften aufweist.Vacuum lifting device according to one of claims 1 to 13, characterized in that the suction device ( 50 ) a coarse filter ( 65 ), a filter cartridge ( 63 ) and / or a valve ( 66 ) for venting.

### Claim 15

Vakuumhebegerät nach einem der Ansprüche 1 bis 14, dadurch gekennzeichnet, dass eine optische Anzeige vorgesehen ist, welche den Ladezustand des Akkumulators (43) anzeigt.A vacuum lifting device according to one of claims 1 to 14, characterized in that an optical display is provided, which (the state of charge of the accumulator 43 ).

## Full description

PERFORMING OPERATIONS; TRANSPORTINGHAND TOOLS; PORTABLE POWER-DRIVEN TOOLS; MANIPULATORSTOOLS OR BENCH DEVICES NOT OTHERWISE PROVIDED FOR, FOR FASTENING, CONNECTING, DISENGAGING, OR HOLDINGWork holders not covered by any preceding group in the subclass, e.g. magnetic work holders, vacuum work holdersVacuum work holdersVacuum work holders portable, e.g. handheld

Description

Translated from German

Die Erfindung betrifft ein VakuumhebegerÃ¤t zum Anheben und/oder Handhaben von WerkstÃ¼cken, insbesondere von Platten, Steinen und anderen flÃ¤chigen GegenstÃ¤nden, gemÃ¤Ã dem Oberbegriff von Anspruch 1.The invention relates to a vacuum lifting device for lifting and / or handling of workpieces, in particular of plates, bricks and other flat objects, according to the preamble of claim 1.

VakuumhebegerÃ¤te sind in zahlreichen AusfÃ¼hrungsformen aus dem Stand der Technik bekannt. Sie haben meist eine oder mehrere Saugvorrichtungen, die mittels einer Pumpe zwischen einer Saugplatte und einem WerkstÃ¼ck ein Vakuum erzeugen. Dadurch lÃ¤sst sich das WerkstÃ¼ck ansaugen und anheben, ohne dass es zusÃ¤tzlicher Greifelemente bedarf.Vacuum lifting devices are known in numerous embodiments from the prior art. They usually have one or more suction devices which create a vacuum between a suction plate and a workpiece by means of a pump. This allows the workpiece to suck in and lift, without the need for additional gripping elements.

Die Vakuumpumpe wird gewÃ¶hnlich von einem Elektromotor angetrieben, der mit einer Energieversorgung verbunden ist. Bei stationÃ¤ren VakuumhebegerÃ¤ten ist dies gewÃ¶hnlich das Stromnetz und die Verbindung erfolgt Ã¼ber eine entsprechende Zuleitung. Bei mobilen VakuumhebegerÃ¤ten, die an einen Bagger oder einen Kran angehÃ¤ngt werden, ist dies jedoch nicht ohne weiteres mÃ¶glich, weil nicht immer ein Netzanschluss vorhanden ist oder ein Kabel nicht verwendet werden kann.The vacuum pump is usually driven by an electric motor connected to a power supply. In stationary vacuum lifting devices this is usually the power supply and the connection is made via a corresponding supply line. However, this is not readily possible with mobile vacuum lifting devices attached to an excavator or crane because there is not always a mains connection or a cable can not be used.

Man hat daher VakuumhebegerÃ¤te entwickelt, die mit Akkumulatoren betrieben werden und somit zeitweise oder gÃ¤nzlich netzunabhÃ¤ngig arbeiten. DE 10 2005 022 929 B4 beschreibt z. B. ein VakuumhebegerÃ¤t, das mit einem Mittelspannungsmotor angetrieben wird und als Spannungsquelle einen Akkumulator nutzt. Zwischen dem Akkumulator und dem Mittelspannungsmotor ist ein DC/AC-Wandler geschaltet.It has therefore developed vacuum lifting devices that are operated with batteries and thus work temporarily or completely independent of the mains. DE 10 2005 022 929 B4 describes z. B. a vacuum lifting device that is driven by a medium voltage motor and uses a battery as a voltage source. Between the accumulator and the medium voltage motor, a DC / AC converter is connected.

WÃ¤hrend all diese VakuumhebegerÃ¤te zum Anheben groÃer und schwerer WerkstÃ¼cke vorgesehen sind, hat man auch kleinere HandgerÃ¤te entwickelt, die ohne Bagger oder Kran betrieben werden kÃ¶nnen und die zum Handhaben von kleineren WerkstÃ¼cken geeignet sind. Diese GerÃ¤te haben meist einen Handgriff zum Handhaben des VakuumhebegerÃ¤tes sowie eine Energieversorgung fÃ¼r die Vakuumpumpe in Form eines Akkumulators, um das HandgerÃ¤t netzunabhÃ¤ngig betreiben zu kÃ¶nnen.While all these vacuum lifters are designed to lift large and heavy workpieces, smaller hand tools have been developed which can be operated without excavators or cranes and which are suitable for handling smaller workpieces. These devices usually have a handle for handling the vacuum lifting device and a power supply for the vacuum pump in the form of a rechargeable battery to operate the handset off-grid.

US 5 795 001 A zeigt ein VakuumhebegerÃ¤t mit einem Handgriff, der Ã¼ber zwei voneinander beabstandet angeordnete Halter an einer Halteplatte befestigt ist. An der Halteplatte ist eine Saugplatte angeordnet. Dabei dient zur Energieversorgung ein Batteriepack, das als modulares Bauteil von auÃen am VakuumhebegerÃ¤t befestigt werden kann. Innerhalb des Handgriffs ist dabei die zur Erzeugung eines Vakuums erforderliche, elektrische angetriebene Pumpe untergebracht. US 5,795,001 A shows a vacuum lifting device with a handle, which is attached via two spaced-apart holder to a holding plate. On the holding plate, a suction plate is arranged. The power supply is a battery pack that can be attached as a modular component from the outside of the vacuum lifting device. Within the handle while the required for generating a vacuum, electrically driven pump is housed.

In DE 29 916 647 U1 ist eine Vakuum-Handhabungs-Wechselvorrichtung, also ein VakuumhebegerÃ¤t, beschrieben, bei der ein Handgriff Ã¼ber zwei voneinander beabstandet angeordnete Halter an einer Halterplatte befestigt ist, an der eine Saugplatte mit einer Schnellwechselvorrichtung angeordnet ist. Die Halter sind dabei relativ voluminÃ¶s ausgebildet, wobei in einem der Halter eine elektrisch angetriebene Pumpe untergebracht ist. An einer Oberseite der Halteplatte ist parallel zum Handgriff zur Energieversorgung der Pumpe ein Akkumulator angeordnet.In DE 29 916 647 U1 is a vacuum handling change device, ie a vacuum lifting device, described in which a handle is attached via two spaced-apart holder to a holder plate on which a suction plate is arranged with a quick-change device. The holders are relatively bulky, wherein in one of the holders an electrically driven pump is housed. On an upper side of the holding plate, an accumulator is arranged parallel to the handle for supplying power to the pump.

Die gattungsfremde DE 42 11 014 A1 zeigt eine HandhabungsgerÃ¤t zum Aufnehmen und Platzieren von GegenstÃ¤nden, wobei in einem Handgriff sowohl eine Pumpe zum Erzeugen eines Vakuums als auch eine Batterie zur Energieversorgung angeordnet ist. An einem Ende des GehÃ¤uses ragt aus dem GehÃ¤use eine KanÃ¼le heraus, wobei das GerÃ¤t insgesamt nach Art eines Pistolengriffs ausgestaltet ist. An das offene Ende der KanÃ¼le kann ein Sauger aufgesteckt werden, der aus einem flexiblen Material besteht, um auch GegenstÃ¤nde mit einer rauen OberflÃ¤che ansaugen zu kÃ¶nnen.The non-generic DE 42 11 014 A1 shows a handling device for picking up and placing objects, wherein in a handle both a pump for generating a vacuum and a battery for power supply is arranged. At one end of the housing projects out of the housing a cannula, wherein the device is configured in the manner of a pistol grip. To the open end of the cannula, a nipple can be plugged, which consists of a flexible material, in order to suck objects with a rough surface.

Aus der gattungsfremden US 4 976 173 A ist ein handliches Elektrowerkzeug bekannt, dass ein pistolenfÃ¶rmiges GehÃ¤use aufweist, wobei im vorderen Bereich des GehÃ¤uses eine Aufnahme ausgebildet ist, um unterschiedliche WerkzeugeinsÃ¤tze aufnehmen zu kÃ¶nnen. Diese werden dann elektrisch mit einer im Handgriff des GehÃ¤uses untergebrachten Energieversorgung verbunden. Dabei ist unter anderem vorgesehen, einen der WerkzeugeinsÃ¤tze als Vakuumsauger auszubilden.From the alien US 4,976,173 A a handy power tool is known that has a pistol-shaped housing, wherein a receptacle is formed in the front region of the housing in order to accommodate different tool inserts can. These are then electrically connected to a housed in the handle of the housing power supply. It is intended inter alia to form one of the tool inserts as a vacuum suction.

Von Nachteil hierbei ist jedoch, dass es sich bei den Akkumulatoren meist um teure Spezialteile handelt, die nur als Systemkomponenten zur VerfÃ¼gung stehen. Beim Auswechseln eines Akkus ist man daher stets auf systemkompatible Teile angewiesen. Werden zusÃ¤tzliche Akkus benÃ¶tigt oder ist ein Akku defekt, entstehen hohe Kosten. Hinzu kommt, dass die Abmessungen der Akkumulatoren oder deren Adapter oft sehr groÃ sind, so dass die VakuumhebegerÃ¤te relativ groÃ und schwer ausfallen, was sich ungÃ¼nstig auf die Handhabung auswirkt.The disadvantage here, however, is that it is the accumulators usually expensive special parts that are available only as system components. When replacing a battery, you are always dependent on system compatible parts. If additional batteries are needed or if a battery is defective, high costs arise. In addition, the dimensions of the accumulators or their adapters are often very large, so that the vacuum lifting devices are relatively large and heavy, which has an unfavorable effect on handling.

Ziel der Erfindung ist es, diese und weitere Nachteile des Standes der Technik zu Ã¼berwinden und ein VakuumhebegerÃ¤t zu entwickeln, das mit einfachen Mitteln kostengÃ¼nstig aufgebaut ist und ein zuverlÃ¤ssiges Ansaugen und Handhaben der WerkstÃ¼cke gewÃ¤hrleistet. Das GerÃ¤t soll insbesondere kompakte Abmessungen und ein geringes Gesamtgewicht aufweisen. Angestrebt werden ferner eine einfache Bedienung sowie eine kostengÃ¼nstige Wartung.The aim of the invention is to overcome these and other disadvantages of the prior art and to develop a vacuum lifting device, which is constructed inexpensively by simple means and ensures reliable suction and handling of the workpieces. The device should in particular have compact dimensions and a low total weight. The aim is also simple operation and cost-effective maintenance.

Hauptmerkmale der Erfindung sind im kennzeichnenden Teil von Anspruch 1 angegeben. Ausgestaltungen sind Gegenstand der AnsprÃ¼che 2 bis 15. Main features of the invention are specified in the characterizing part of claim 1. Embodiments are the subject of claims 2 to 15.

Bei einem VakuumhebegerÃ¤t zum Anheben und/oder Handhaben von WerkstÃ¼cken, mit einer Saugvorrichtung, die mittels einer elektrisch angetriebenen Pumpe zwischen einer Saugplatte und einem anzuhebenden WerkstÃ¼ck ein Vakuum erzeugt, wobei fÃ¼r die Pumpe eine Energieversorgung vorgesehen ist, und mit einem Handgriff zum Handhaben des VakuumhebegerÃ¤tes und der Saugvorrichtung, wobei der Handgriff Ã¼ber zwei parallel voneinander beabstandete Halter an einer Halteplatte befestigt ist, an der die Saugplatte angeordnet ist, sieht die Erfindung vor, dass die Energieversorgung fÃ¼r die Pumpe im Handgriff unterbringbar ist, wobei der Handgriff im Wesentlichen rohrfÃ¶rmig ausgebildet ist, wobei jeder Halter an seinem oberen Ende eine runde Ãffnung aufweist, deren Innendurchmesser dem AuÃendurchmesser des Handgriffs entspricht, und wobei der Handgriff durch die Ãffnungen hindurchgefÃ¼hrt und darin festgelegt sowie an wenigstens einer Stirnseite verschlieÃbar ist.In a vacuum lifting device for lifting and / or handling workpieces, with a suction device which generates a vacuum between a suction plate and a workpiece to be lifted by means of an electrically driven pump, wherein a power supply is provided for the pump, and with a handle for handling the vacuum lifting device and the suction device, wherein the handle is attached via two parallel spaced holder to a holding plate on which the suction plate is arranged, the invention provides that the power supply for the pump can be accommodated in the handle, wherein the handle is substantially tubular wherein each holder has at its upper end a round opening, the inner diameter of which corresponds to the outer diameter of the handle, and wherein the handle is passed through the openings and fixed therein and closable on at least one end face.

Dadurch lÃ¤sst sich ein Ã¤uÃerst kompakter und leicht zu handhabender Aufbau erzielen, denn die Energieversorgung fÃ¼r die Pumpe bildet kein sperriges oder abstehendes Bauteile mehr, welches die Handhabung behindern kÃ¶nnte. Das erfindungsgemÃ¤Ãe VakuumhebegerÃ¤t ist vielmehr klein und handlich ausgebildet, was die Benutzung insgesamt vereinfacht. Zudem sorgt die im Handgriff integrierte Energieversorgung fÃ¼r eine gÃ¼nstige Gewichtsverteilung, so dass ein ermÃ¼dungsfreies Arbeiten und eine prÃ¤zise Handhabung gewÃ¤hrleistet sind.This makes it possible to achieve a very compact and easy-to-handle construction, because the power supply for the pump no longer forms bulky or protruding components, which could hinder the handling. The vacuum lifting device according to the invention is rather small and handy, which simplifies the overall use. In addition, the integrated power supply in the handle ensures a favorable weight distribution, so that fatigue-free working and precise handling are guaranteed.

Um die Energieversorgung fÃ¼r die Pumpe optimal im Handgriff unterbringen zu kÃ¶nnen, ist dieser im Wesentlichen rohrfÃ¶rmig ausgebildet und an wenigstens einer Stirnseite verschlieÃbar. Letzteres sorgt dafÃ¼r, dass die in dem Handgriff untergebrachte Stromversorgung oder andere Teile wÃ¤hrend des Betriebes nicht herausfallen kÃ¶nnen. Gleichzeitig ist ein rascher Zugang zur Energieversorgung gewÃ¤hrleistet, sollte dies notwendig sein.In order to optimally accommodate the power supply for the pump in the handle, this is substantially tubular and can be closed at least one end face. The latter ensures that the power supply or other parts housed in the handle can not fall out during operation. At the same time, rapid access to energy supply is ensured should this be necessary.

ZweckmÃ¤Ãig weist der Handgriff einen Schalter fÃ¼r die Pumpe auf. Dadurch ist es mÃ¶glich, das VakuumhebegerÃ¤t mit nur einer Hand zu bedienen, was sich oft als nÃ¼tzlich erweist, insbesondere beim Verlegen von Platten oder Fliesen.Suitably, the handle on a switch for the pump. This makes it possible to operate the vacuum lifting device with one hand, which often proves useful, especially when laying panels or tiles.

GemÃ¤Ã einem weiteren Aspekt der Erfindung ist im Handgriff ein Anschluss fÃ¼r die Energieversorgung vorgesehen, die vorzugsweise als Akkumulator oder als Batterie ausgebildet ist. Letzteres ermÃ¶glicht einen netzunabhÃ¤ngigen Betrieb des VakuumhebegerÃ¤tes. Ãber den Anschluss kann der Akku bzw. die Batterie rasch und bequem an das GerÃ¤t angeschlossen werden.According to a further aspect of the invention, a connection for the power supply is provided in the handle, which is preferably designed as an accumulator or as a battery. The latter enables a network-independent operation of the vacuum lifting device. Through the connection, the battery or the battery can be quickly and easily connected to the device.

Ein weiterer Vorteil der Erfindung besteht darin, dass bezÃ¼glich der Energieversorgung keine speziellen Systemkomponenten oder Systembauteile mehr notwendig sind. Durch die rohrfÃ¶rmige Ausbildung des Handgriffs und die Verwendung eines handelsÃ¼blichen Anschlusses kÃ¶nnen handelsÃ¼bliche und damit preiswerte Akkus oder Batterien an die Pumpe angeschlossen und in dem Handgriff untergebracht werden. Dies wirkt sich Ã¤uÃerst gÃ¼nstig auf die Herstellkosten aus.Another advantage of the invention is that with respect to the power supply no special system components or system components are more necessary. The tubular design of the handle and the use of a commercially available connection commercially available and therefore inexpensive batteries or batteries can be connected to the pump and housed in the handle. This has a very favorable effect on the production costs.

Der Anschluss fÃ¼r die Energieversorgung ermÃ¶glicht es ferner verschiedene Spannungsquellen an dem VakuumhebegerÃ¤t anzuschlieÃen. So ist bei Bedarf an dem Anschluss auch ein Netzteil anschlieÃbar, wenn beispielsweise kein geladener Akku mehr zur VerfÃ¼gung steht oder wenn der im Handgriff angeordnete Akku wÃ¤hrend des Betriebes geladen werden soll. Der rohrfÃ¶rmige Handgriff nimmt auch hier sowohl den Akku als auch den Anschluss auf, so dass keine stÃ¶renden Leitungen oder Kabel im Weg sind und das HebegerÃ¤t einfach zu handhaben ist. Man kann den Akku zum Laden in einem externen LadegerÃ¤t aber auch ausbauen und an dem Anschluss nur das Netzteil anschlieÃen, sollte dessen Kabel nicht weiter stÃ¶ren.The connection for the power supply also makes it possible to connect different voltage sources to the vacuum lifting device. Thus, if necessary, a power supply can be connected to the connection if, for example, no charged battery is available or if the battery arranged in the handle is to be charged during operation. The tubular handle takes on both the battery and the connection, so that no disturbing cables or cables are in the way and the lifter is easy to handle. You can also remove the battery for charging in an external charger and connect to the port only the power supply should not interfere with the cable.

Eine weitere AusfÃ¼hrungsform der Erfindung sieht vor, dass die Pumpe in einem GehÃ¤use angeordnet ist, welches am Handgriff anbringbar ist. Das GehÃ¤use schÃ¼tzt die Pumpe vor Ã¤uÃeren EinflÃ¼ssen, beispielsweise bei EinsÃ¤tzen des GerÃ¤tes in staubigen oder schmutzigen Umgebungen. Gleichzeitig kann die Pumpe mit dem GehÃ¤use unmittelbar an dem Handgriff montiert werden, was sich ebenfalls gÃ¼nstig auf die Gewichtsverteilung des GerÃ¤tes auswirkt. Handgriff und PumpengehÃ¤use bilden daher eine kompakte Einheit, die stets einfach zu handhaben ist. Abstehende oder auslandende Bauteile sind nicht vorhanden, was sich gÃ¼nstig auf die Gewichtsverteilung und die Betriebssicherheit auswirkt.A further embodiment of the invention provides that the pump is arranged in a housing which can be attached to the handle. The housing protects the pump from external influences, for example when using the device in dusty or dirty environments. At the same time, the pump with the housing can be mounted directly on the handle, which also has a favorable effect on the weight distribution of the device. Handle and pump housing therefore form a compact unit, which is always easy to handle. There are no protruding or foreign components, which has a favorable effect on weight distribution and operational safety.

Besonders vorteilhaft ist die Ausgestaltung der Erfindung, wonach der Handgriff das GehÃ¤use einer Taschenlampe ist. Durch diese MaÃnahme lassen sich die Herstell- und Montagekosten gegenÃ¼ber herkÃ¶mmlichen VakuumhebegerÃ¤ten deutlich reduzieren, weil das TaschenlampengehÃ¤use weitgehend vorgefertigt ist und die notwendige StabilitÃ¤t aufweist. So sind beispielsweise die Enden des GehÃ¤uses bereits mit Gewinden versehen, die unmittelbar zum VerschlieÃen des Handgriffs mit einem Deckel und zur Montage des PumpengehÃ¤uses verwendet werden kÃ¶nnen. Ferner ist gewÃ¶hnlich in jedem TaschenlampengehÃ¤use bereits ein Schalter eingebaut, der unmittelbar zum Ein- und Ausschalten der Vakuumpumpe verwendet werden kann und â wie bei Taschenlampen Ã¼blich â zugleich auch abgedichtet ist. Das TaschenlampengehÃ¤use kann zudem unmittelbar als Handgriff verwendet werden, der gut in der Hand liegt und keiner weiteren Endbehandlung mehr bedarf.Particularly advantageous is the embodiment of the invention, according to which the handle is the housing of a flashlight. By this measure, the manufacturing and assembly costs compared to conventional vacuum lifting devices can be significantly reduced because the flashlight housing is largely prefabricated and has the necessary stability. For example, the ends of the housing are already provided with threads that can be used directly for closing the handle with a lid and for mounting the pump housing. Furthermore, usually in each flashlight housing already installed a switch that can be used directly for switching on and off the vacuum pump and - as in Flashlights usual - at the same time also sealed. The flashlight housing can also be used directly as a handle that fits well in the hand and no further finishing needs more.

Dementsprechend sieht die Erfindung weiter vor, dass das GehÃ¤use der Pumpe mit dem GehÃ¤use der Taschenlampe verschraubbar ist. Das GehÃ¤use lÃ¤sst sich damit nicht nur rasch und bequem montieren, sondern auch ebenso schnell und einfach wieder abnehmen, sollte eine Wartung der Pumpe oder des Elektromotors notwendig sein. Dabei ist es zweckmÃ¤Ãig, wenn das GehÃ¤use dort aufgeschraubt wird, wo sich gewÃ¶hnlich der Kopf der Taschenlampe befindet. In diesem Bereich sitzt normalerweise auch die GlÃ¼hlampe der Taschenlampe, die Ã¼ber den Schalter ein- und ausgeschaltet wird. Dementsprechend lÃ¤sst sich der Elektromotor der Vakuumpumpe nach dem Ausbau der GlÃ¼hlampe ohne grÃ¶Ãeren Aufwand an den Schalter anschlieÃen, so dass die Pumpe unmittelbar Ã¼ber den Schalter der Taschenlampe betÃ¤tigt werden kann.Accordingly, the invention further provides that the housing of the pump can be screwed to the housing of the flashlight. The case can not only be mounted quickly and conveniently, but also removed quickly and easily, should maintenance of the pump or the electric motor be necessary. It is expedient if the housing is screwed where usually the head of the flashlight is located. In this area usually sits the bulb of the flashlight, which is switched on and off via the switch. Accordingly, the electric motor of the vacuum pump after removal of the light bulb without much effort to connect to the switch, so that the pump can be operated directly via the switch of the flashlight.

Das rÃ¼ckwÃ¤rtige Ende des TaschenlampengehÃ¤uses wird stirnseitig von einem Deckel verschlossen. Hierbei handelt es sich bevorzugt um den Deckel der Taschenlampe, der mithin weiter verwendet werden kann, was sich ebenfalls gÃ¼nstig auf die Herstellkosten auswirkt.The rear end of the flashlight housing is closed at the front by a lid. This is preferably the lid of the flashlight, which can therefore continue to be used, which also has a favorable effect on the production costs.

Ein weiterer wichtiger Vorteil der Erfindung besteht darin, dass das TaschenlampengehÃ¤use handelsÃ¼bliche Akkus oder Batterien aufnimmt, die â wie bei einer Taschenlampe Ã¼blich â unmittelbar in das TaschenlampengehÃ¤use und damit den Handgriff eingesetzt werden kÃ¶nnen. Man kann aber auch den bereits erwÃ¤hnten Anschluss verwenden, um den Akku an den Schalter und damit an die Pumpe anschlieÃen zu kÃ¶nnen.Another important advantage of the invention is that the flashlight housing commercially available batteries or batteries absorbs - as in a flashlight usual - can be used directly in the flashlight housing and thus the handle. But you can also use the aforementioned connection to connect the battery to the switch and thus to the pump can.

Verwendet man ein Netzteil, um den Akku zu laden oder um die Pumpe Ã¼ber das Netzteil zu betreiben, ist der Deckel mit einem Durchbruch fÃ¼r ein Kabel des Netzteils versehen.If you use a power supply to charge the battery or to power the pump via the power supply, the cover is provided with a breakthrough for a cable of the power supply.

Um die WerkstÃ¼cke, ohne sie zu beschÃ¤digen, stets zuverlÃ¤ssig ansaugen und anheben zu kÃ¶nnen, ist an der dem anzusaugenden WerkstÃ¼ck zugewandten Unterseite der Saugplatte eine Gummidichtung angebracht. Zur Bildung eines Vakuums erweist sich die Saugplatte mit der Gummidichtung als vorteilhaft, da sie eine stets dichte Verbindung zwischen sich und dem WerkstÃ¼ck ermÃ¶glicht. Unebenheiten im WerkstÃ¼ck werden durch die Dichtung zuverlÃ¤ssig ausgeglichen, so dass auch grÃ¶Ãere oder schwerere WerkstÃ¼cke stets zuverlÃ¤ssig gehalten werden.In order to always be able to reliably suck in and lift the workpieces without damaging them, a rubber seal is attached to the underside of the suction plate facing the workpiece to be suctioned. To form a vacuum, the suction plate with the rubber seal proves to be advantageous because it allows an always tight connection between itself and the workpiece. Unevenness in the workpiece is reliably compensated by the seal, so that even larger or heavier workpieces are always reliably held.

Der Handgriff und die Saugplatte sind zweckmÃ¤Ãig an einer gemeinsamen Halteplatte montierbar. Dadurch kann man die Saugplatte bei Bedarf rasch und bequem gegen eine andere austauschen, sollte beispielsweise eine andere, grÃ¶Ãere oder kleinere Gummidichtung notwendig oder diese beschÃ¤digt sein. Die Saugplatte und die Halteplatte kÃ¶nnen aber auch einstÃ¼ckig ausgebildet sein, wodurch sich der Aufbau des VakuumhebegerÃ¤ts weiter vereinfacht.The handle and the suction plate are conveniently mounted on a common plate. This allows you to swap the suction plate when needed quickly and conveniently against another, for example, another, larger or smaller rubber seal necessary or damaged. But the suction plate and the holding plate can also be integrally formed, whereby the structure of the vacuum lifting device further simplified.

Vorteilhaft ist weiter, dass die Saugvorrichtung einen Grobfilter, eine Filterpatrone und/oder ein Ventil zum BelÃ¼ften aufweist. Die Filter verhindern, dass Schmutz, Staub und andere Verunreinigungen aufgesaugt werden. Dies kÃ¶nnte die Funktionsweise und die Lebensdauer der Pumpe beeintrÃ¤chtigen. Das Ventil dient zum BelÃ¼ften der Pumpe, damit das GerÃ¤t das WerkstÃ¼ck nach dem Absetzten an der vorgesehnen Stelle wieder frei gibt.A further advantage is that the suction device has a coarse filter, a filter cartridge and / or a valve for venting. The filters prevent dirt, dust and other impurities from being absorbed. This could affect the operation and life of the pump. The valve is used to ventilate the pump so that the device releases the workpiece after settling in the intended position.

Eine optische Anzeige im GehÃ¤use oder im Deckel zeigt den Ladezustand des Akkumulators an, so dass dieser rechtzeitig ausgewechselt oder an das LadegerÃ¤t angeschlossen werden kann. Auch beim Aufladen eines entleerten Akkumulators ist erkennbar, wie weit der Aufladezustand fortgeschritten ist.An optical display in the housing or in the lid indicates the state of charge of the accumulator, so that it can be replaced in time or connected to the charger. Even when charging a depleted battery can be seen how far the state of charge has progressed.

Weitere Merkmale, Einzelheiten und Vorteile der Erfindung ergeben sich aus dem Wortlaut der AnsprÃ¼che sowie aus der folgenden Beschreibung von AusfÃ¼hrungsbeispielen anhand der Zeichnung. Es zeigen:Further features, details and advantages of the invention will become apparent from the wording of the claims and from the following description of exemplary embodiments with reference to the drawing. Show it:

1 eine SchrÃ¤gansicht eines mobilen VakuumhebegerÃ¤ts, 1 an oblique view of a mobile vacuum lifting device,

2 eine Schnittansicht von 1, 2 a sectional view of 1 .

3 eine Schnittansicht von 1 von schrÃ¤g unten betrachtet und three a sectional view of 1 viewed from diagonally below and

4 eine SchrÃ¤gansicht des VakuumhebegerÃ¤ts in anderer AusfÃ¼hrungsform. 4 an oblique view of the vacuum lifting device in another embodiment.

Das in 1 allgemein mit 10 bezeichnete VakuumhebegerÃ¤t ist als HandgerÃ¤t ausgebildet. Es dient zum Anheben und/oder Handhaben von (nicht dargestellten) WerkstÃ¼cken, wie beispielsweise Bodenfliesen, Naturstein- oder Betonplatten, Kunststoffplatten, Blechen oder Glasscheiben, die von Hand verlegt bzw. verbaut werden kÃ¶nnen.This in 1 generally with 10 designated vacuum lifting device is designed as a handheld device. It is used for lifting and / or handling of workpieces (not shown), such as, for example, floor tiles, natural stone or concrete slabs, plastic sheets, metal sheets or glass sheets, which can be installed or installed by hand.

Das GerÃ¤t 10 hat eine Saugvorrichtung 50, die mittels einer elektrisch angetriebenen Pumpe 80 zwischen einer Saugplatte 54 und der OberflÃ¤che eines anzuhebenden WerkstÃ¼cks ein Vakuum erzeugt, und einen Handgriff 20 zum Handhaben des VakuumhebegerÃ¤tes 10 bzw. der Saugvorrichtung 50.The device 10 has a suction device 50 by means of an electrically driven pump 80 between a suction plate 54 and creates a vacuum on the surface of a workpiece to be lifted, and a handle 20 for handling the vacuum lifting device 10 or the suction device 50 ,

In dem im Wesentlichen rohrfÃ¶rmig ausgebildeten Handgriff 20 ist eine Energieversorgung 40 fÃ¼r die Pumpe 80 vorgesehen, vorzugsweise ein Akkumulator 43 oder eine (nicht gezeigte) Batterie, um das HebegerÃ¤t 10 netzunabhÃ¤ngig betreiben zu kÃ¶nnen. Damit der Akku 43 oder die Batterie beim Handhaben des GerÃ¤tes 10 nicht aus dem Handgriff 20 herausfallen kann, ist dieser an einer Stirnseite 26 mit einem Deckel 33 verschlieÃbar, der vorzugsweise mit einem Endabschnitt 27 des Handgriffs 20 verschraubt wird. Letzterer ist dazu endseitig mit einem entsprechenden (nicht nÃ¤her bezeichneten) Innengewinde versehen, wÃ¤hrend der Deckel 33 einen korrespondierenden Gewindeabschnitt 133 aufweist. Ein Zwischenring 134 kann als Distanzring zur Sicherung des Akkus 43 im Handgriff 20 ausgebildet sein. Man kann den Ring 134 aber auch als Dichtung ausbilden. In the substantially tubular handle 20 is an energy supply 40 for the pump 80 provided, preferably an accumulator 43 or a battery (not shown) around the lifter 10 to operate independently of the network. So the battery 43 or the battery when handling the device 10 not from the handle 20 can fall out, this is on one end face 26 with a lid 33 closed, preferably with an end portion 27 of the handle 20 is screwed. The latter is provided at the end with a corresponding (unspecified) internal thread, while the lid 33 a corresponding threaded portion 133 having. An intermediate ring 134 Can be used as a spacer ring to secure the battery 43 in the handle 20 be educated. You can see the ring 134 but also train as a seal.

Am gegenÃ¼berliegenden Ende 29 des Handgriffs 20 ist ein GehÃ¤use 35 auf den Handgriff 20 aufgesetzt, vorzugsweise aufgeschraubt. Das im Wesentlichen zylindrische GehÃ¤use 35 nimmt â wie 2 zeigt â die Vakuumpumpe 80 sowie deren Elektromotor 86 auf. Der Handgriff 20 ist zur Aufnahme des GehÃ¤uses 35 mit einem AuÃengewinde 34 versehen, wÃ¤hrend in dem GehÃ¤use 35 ein entsprechendes (nicht nÃ¤her bezeichnetes) Innengewinde ausgebildet ist. An der Unterseite 38 des GehÃ¤uses 35 befindet sich ein Pumpenanschluss 82, der einen Anschluss 84 fÃ¼r einen Saugschlauch 85 aufweist. Neben dem Sauganschluss 84 liegt ein Auslass 88, der als Luftauslass fÃ¼r die von der Pumpe 80 angesaugte Luft dient (siehe 3).At the opposite end 29 of the handle 20 is a housing 35 on the handle 20 put on, preferably screwed on. The essentially cylindrical housing 35 takes - like 2 shows - the vacuum pump 80 as well as their electric motor 86 on. The handle 20 is to accommodate the housing 35 with an external thread 34 provided while in the housing 35 a corresponding (unspecified) internal thread is formed. On the bottom 38 of the housing 35 there is a pump connection 82 who has a connection 84 for a suction hose 85 having. Next to the suction connection 84 is an outlet 88 that acts as an air outlet for the pump 80 sucked air is used (see three ).

Der Handgriff 20 ist Ã¼ber zwei parallel beabstandet angeordnete Halter 70 an einer Halteplatte 53 befestigt. Jeder Halter 70 weist hierzu an seinem oberen Ende 71 eine runde Ãffnung 73 auf, deren Innendurchmesser dem AuÃendurchmesser des Handgriffs 20 entspricht. Dieser ist durch die Ãffnungen 73 hindurchgefÃ¼hrt und darin festgelegt, beispielsweise mittels einer Schraube 75. Am unteren Ende 72 sind die Halter 70 mit Schenkeln 74 ausgefÃ¼hrt, die endseitig mit der Halteplatte 53 verschraubt sind. Mann kann die Schenkel 74 aber auch mit der Halteplatte 53 verschweiÃen, verlÃ¶ten oder verkleben.The handle 20 is about two parallel spaced holder 70 on a holding plate 53 attached. Every holder 70 points to this at its upper end 71 a round opening 73 on, the inner diameter of the outer diameter of the handle 20 equivalent. This one is through the openings 73 guided and fixed therein, for example by means of a screw 75 , At the bottom 72 are the holders 70 with thighs 74 executed, the end with the holding plate 53 are bolted. Man can the thighs 74 but also with the retaining plate 53 welding, soldering or gluing.

FÃ¼r den Anschluss des im Handgriff 20 fÃ¼r den Antrieb der Pumpe 80 untergebrachten Akkumulators 43 ist ein Anschluss 41 vorgesehen, der vorzugsweise als Steckverbindung 42 ausgefÃ¼hrt ist. Der bevorzugt stabfÃ¶rmige Akku 43 ist mit einem entsprechenden GegenstÃ¼ck 44 versehen, das beispielsweise als einfache zweipolige Buchse ausgebildet sein kann, welche die als Stecker ausgebildete Steckverbindung 42 aufnimmt. Letztere ist mit einem Kabel 45 im Inneren des Handgriffs an einen Schalter 31 angeschlossen, der in der Wandung des Handgriffs 20 eingebaut ist. Ãber den Schalter 31 wird der Elektromotor 86 der Vakuumpumpe 80 ein- und ausgeschaltet, wobei der Schalter 31 Ã¼ber (nicht dargestellte) Verbindungsleitungen mit dem Elektromotor 86 verbunden ist. Dieser ist hierzu mit LÃ¶tverbindungen 87 versehen. Zwischen dem GegenstÃ¼ck 44 der Steckverbindung 41 ist ebenfalls ein Kabel 45 vorgesehen.For the connection of the handle 20 for driving the pump 80 accommodated accumulator 43 is a connection 41 provided, preferably as a plug connection 42 is executed. The preferred rod-shaped battery 43 is with a corresponding counterpart 44 provided, which may be formed for example as a simple two-pin socket, which designed as a plug connector 42 receives. The latter is with a cable 45 inside the handle to a switch 31 connected in the wall of the handle 20 is installed. About the switch 31 becomes the electric motor 86 the vacuum pump 80 switched on and off, the switch 31 via (not shown) connecting lines with the electric motor 86 connected is. This is for this purpose with solder joints 87 Mistake. Between the counterpart 44 the connector 41 is also a cable 45 intended.

Die Kabel 45 der Steckverbindung 41, 44 sind so lang ausgebildet, dass der Stecker 41, die Buchse 44 und der Akku aus dem Handgriff 20 herausgezogen werden kÃ¶nnen. AuÃerhalb des Handgriffs 20 lassen sich die Steckverbinder 41, 44 leichter lÃ¶sen bzw. verbinden. Ist der Akku 43 angeschlossen wird er zusammen mit der Steckverbindung 41, 44 und dem Kabel 45 in den Handgriff 20 eingeschoben, bis der Deckel 33 geschlossen werden kann.The cables 45 the connector 41 . 44 are designed so long that the plug 41 , the socket 44 and the battery from the handle 20 can be pulled out. Outside the handle 20 let the connectors go 41 . 44 easier to solve or connect. Is the battery 43 it is connected together with the plug connection 41 . 44 and the cable 45 in the handle 20 pushed in until the lid 33 can be closed.

Eine wichtige Besonderheit der Erfindung besteht darin, dass es sich bei dem Handgriff 20 um das GehÃ¤use 30 einer handelsÃ¼blichen Taschenlampe handelt. Dieses ist weitestgehend vorgefertigt und kann nach Entfernen des (nicht gezeigten) Taschenlampenkopfes und der GlÃ¼hlampe verbaut werden. Dazu wird lediglich der in der Taschenlampe bereits eingebaute Schalter 31 Ã¼ber das Kabel 45 mit der Steckverbindung 42 des Anschlusses 41 fÃ¼r den Akku 43 und Ã¼ber eine weitere (nicht gezeigte) Leitung mit dem Elektromotor 86 der Pumpe 80 verbunden. Deren GehÃ¤use 35 wird mit seinem Gewinde 34 unmittelbar auf das AuÃengewinde des TaschenlampengehÃ¤uses 30 aufgeschraubt. Die Sicherung des Akkus 43 im GehÃ¤use 30 erfolgt mit dem Deckel 33 der Taschenlampe, der mithin ebenfalls unverÃ¤ndert weiter verwendet werden kann.An important feature of the invention is that it is the handle 20 around the case 30 a commercial flashlight is. This is largely prefabricated and can be installed after removing the (not shown) flashlight head and the bulb. This is only the built-in flashlight switch 31 over the cable 45 with the plug connection 42 of the connection 41 for the battery 43 and via another line (not shown) to the electric motor 86 the pump 80 connected. Their housing 35 becomes with his thread 34 directly on the external thread of the flashlight housing 30 screwed. The backup of the battery 43 in the case 30 done with the lid 33 the flashlight, which can therefore continue to be used unchanged.

Das GehÃ¤use 30 der Taschenlampe bietet ausreichend Platz sowohl fÃ¼r den Akku 43 als auch fÃ¼r den Anschluss 41, wobei keine speziellen Akkus 43 notwendig sind. Es kÃ¶nnen vielmehr handelsÃ¼bliche Zellen verwendet werden, die gÃ¼nstig in der Anschaffung sind. Diese Zellen passen unmittelbar in das Batteriefach der Taschenlampe, das sich etwa vom Endabschnitt 27 bis zu einem Mittelteil 28 der Taschenlampe erstreckt. Am vorderen Ende des Mittelteils 28 sitzt der Schalter 31, der zumeist auch bereits gegen Spritzwasser geschÃ¼tzt und damit abgedichtet ist. Der zum Ein- und Ausschalten der Taschenlampe vorhandene Schalter 31 hat bei dieser umgebauten AusfÃ¼hrungsform die Aufgabe, die Pumpe 80 ein- und abzuschalten. Im vorliegenden AusfÃ¼hrungsbeispiel ist der Schalter 31 an der Oberseite 22, im Mittelteil 28, des Handgriffs 20 angeordnet.The housing 30 The flashlight offers enough space for both the battery 43 as well as for the connection 41 , where no special batteries 43 necessary. It can be used commercially available cells that are cheap to buy. These cells fit directly into the battery compartment of the flashlight, extending approximately from the end section 27 up to a middle part 28 the flashlight extends. At the front end of the middle section 28 the switch sits 31 , which is usually already protected against splashing and thus sealed. The switch for switching the flashlight on and off 31 has the task in this rebuilt embodiment, the pump 80 to turn on and off. In the present embodiment, the switch 31 at the top 22 , in the middle part 28 , the handle 20 arranged.

Auf der Halteplatte 53 ist ein Grobfilter (nicht dargestellt), eine Filterpatrone 63 (siehe 2) und ein Ventil 66 (siehe 2) zum BelÃ¼ften der Saugvorrichtung 50 angeordnet, die von einer zwischen den Haltern 70 angeordneten Abdeckplatte 60 geschÃ¼tzt werden. Die an mindestens einer der Stirnseiten 61 offen ausgebildete Abdeckplatte 60, die vorzugsweise mittels Schrauben 62 an der Oberseite 51 der Halteplatte 53 befestigt ist, bietet einen Schutz bzw. Kabelkanal fÃ¼r die fÃ¼r das VakuumhebegerÃ¤t 10 notwendigen Kabel- und Schlauchverbindungen. ZusÃ¤tzlich ist an der Abdeckplatte 60 ein Ventilschalter 662 bzw. Hebel angebracht, mit dem das Ventil 66 zum BelÃ¼ften der Saugplatte 54 betÃ¤tigbar ist.On the retaining plate 53 is a coarse filter (not shown), a filter cartridge 63 (please refer 2 ) and a valve 66 (please refer 2 ) for ventilating the suction device 50 arranged by one between the holders 70 arranged cover plate 60 to be protected. The at least one of the front sides 61 open trained cover plate 60 , the preferably by means of screws 62 at the top 51 the holding plate 53 is attached, provides a protection or conduit for the vacuum lifting device 10 necessary cable and hose connections. Additionally is on the cover plate 60 a valve switch 662 or lever attached to the valve 66 for aerating the suction plate 54 is operable.

Durch die mit Schenkeln 74 ausgebildeten Halter 70 fÃ¼hrt ein Schlauch 85, an der offen gestalteten Stirnseite 61 der Abdeckplatte 60, zum Anschluss 84 des Pumpenanschlusses 82 am GehÃ¤use 35 und innerhalb des GehÃ¤uses 35 zur Vakuumpumpe 80.Through the with thighs 74 trained holder 70 leads a hose 85 , on the open end 61 the cover plate 60 , to the connection 84 the pump connection 82 on the housing 35 and inside the case 35 to the vacuum pump 80 ,

An der Unterseite 52 der Halteplatte 53 ist die Saugplatte 54 Ã¼ber Schnellverbinder 57 befestigt. Um auch unebene und raue Platten zuverlÃ¤ssig ansaugen und anheben zu kÃ¶nnen, ist am AuÃenrand der Unterseite 55 der Saugplatte 54 eine Gummidichtung 56 vorgesehen. Die Schnellverbinder 57 ermÃ¶glichen ein rasches Austauschen der Saugplatte 54 im Bedarfsfall. Dies kann dann nÃ¶tig werden, wenn beispielsweise die Gummidichtung 56 beschÃ¤digt ist oder wenn ein anderes Format benÃ¶tigt wird.On the bottom 52 the holding plate 53 is the suction plate 54 via quick connector 57 attached. To be able to reliably pick up and lift even uneven and rough boards is on the outer edge of the bottom 55 the suction plate 54 a rubber seal 56 intended. The quick connectors 57 allow quick replacement of the suction plate 54 if necessary. This may be necessary if, for example, the rubber seal 56 damaged or if another format is needed.

Wie die Zeichnung weiter zeigt, kann statt eines Akkus 43 auch ein Netzteil 90 an das GerÃ¤t 10 angeschlossen werden. Das Netzteil 90 hat ein Kabel 94, welches durch einen mit einem Durchbruch 93 versehenen Deckel 92 gefÃ¼hrt ist. An der Innenseite des Deckels 92 ist an dem Kabel 94 eine Steckverbindung 91 vorgesehen, die mit der Steckverbindung 42 kompatibel ist. Nach Zusammenstecken der Steckverbindung 91 des Netzteils 91 mit der Steckverbindung 42 des VakuumhebegerÃ¤ts 10 wird der gesamte Anschluss 41 in den Handgriff 20 eingeschoben und mit dem Deckel 92 verschlossen. Das VakuumhebegerÃ¤t 10 kann nun Ã¼ber das Netzteil betrieben werden, sollte beispielsweise kein Akku 43 verfÃ¼gbar sein.As the drawing further shows, instead of a battery 43 also a power supply 90 to the device 10 be connected. The power supply 90 has a cable 94 which one through with a breakthrough 93 provided lid 92 is guided. On the inside of the lid 92 is on the cable 94 a plug connection 91 provided with the connector 42 is compatible. After plugging the plug connection 91 of the power supply 91 with the plug connection 42 of the vacuum lifting device 10 becomes the entire connection 41 in the handle 20 pushed in and with the lid 92 locked. The vacuum lifting device 10 can now be operated via the power supply, for example, should no battery 43 be available.

In 2 ist eine Schnittansicht des erfindungsgemÃ¤Ãen mobilen VakuumhebegerÃ¤ts 10 zu sehen. Das an Haltern 70 angeordnete GehÃ¤use 30 der Taschenlampe ist als Handgriff 20 an seiner Unterseite 24 zwischen den Schenkeln 74 der Halter 70 mit je einer Madenschraube 75 fixiert.In 2 is a sectional view of the mobile vacuum lifting device according to the invention 10 to see. The haltern 70 arranged housing 30 The flashlight is as a handle 20 at its bottom 24 between the thighs 74 the holder 70 each with a grub screw 75 fixed.

Man erkennt, dass das GehÃ¤use 35 der Pumpe 80 in seinem Anfangsbereich 36 und der â Endabschnitt 27 des Handgriffs 20 mit Gewinden 34 versehen sind, Ã¼ber die die Teile schnell und zuverlÃ¤ssig miteinander verbunden werden kÃ¶nnen. In dem GehÃ¤use 35 ist etwa mittig der fÃ¼r die Pumpe 80 notwendige Elektromotor 86 angeordnet. Die LÃ¶tverbindungen 87 des Elektromotors 86 sind in Richtung des Schalters 31 des Handgriffs 20 gerichtet. Der Schalter 31 weist ebenfalls LÃ¶tverbindungen 32 auf. Direkt hinter dem Elektromotor 86 ist am Endbereich 37 des GehÃ¤uses 35 die Pumpe 80 angeordnet.You can see that the case 35 the pump 80 in his starting area 36 and the - end section 27 of the handle 20 with threads 34 are provided, over which the parts can be quickly and reliably connected to each other. In the case 35 is about the middle of the pump 80 necessary electric motor 86 arranged. The solder joints 87 of the electric motor 86 are in the direction of the switch 31 of the handle 20 directed. The desk 31 also has solder joints 32 on. Directly behind the electric motor 86 is at the end area 37 of the housing 35 the pump 80 arranged.

Zwischen den beiden Haltern 70 sind unter der Abdeckplatte 60 das Ventil 66 und die erforderlichen SchlÃ¤uche 65 zu erkennen. Um eine direkte Schlauchverbindung zum Pumpenanschluss 82 zu haben, ist das Ventil 66 zum PumpengehÃ¤use 35 hin gerichtet angebracht.Between the two holders 70 are under the cover plate 60 the valve 66 and the required hoses 65 to recognize. For a direct hose connection to the pump connection 82 to have is the valve 66 to the pump housing 35 attached directed.

Die Halteplatte 53 weist eine Ãffnung 58 auf, durch die mittels eines WinkelstÃ¼cks 67 die AnsaugÃ¶ffnung 68 durch die Saugplatte 54 hindurch, an die Unterseite 55 der Saugplatte 54, gerichtet ist. An dem WinkelstÃ¼ck 67 ist ein zum Ventil 66 verlaufender Schlauch 65 angeschlossen.The holding plate 53 has an opening 58 on, by means of an elbow 67 the intake opening 68 through the suction plate 54 through, to the bottom 55 the suction plate 54 , is directed. At the elbow 67 is one to the valve 66 running hose 65 connected.

In 3 sind durch die Betrachtung des VakuumhebegerÃ¤ts 10 von schrÃ¤g unten die unter der Abdeckplatte 60 angeordneten Teile besser zu erkennen. Man erkennt den am Ventil 66 angeordneten Ventilschalter 662 der zur BelÃ¼ftung der Vorrichtung 10 dient. Am Ventil 66 sind drei AnschlÃ¼sse 661 zu sehen. An den beiden Ã¤uÃeren sind jeweils SchlÃ¤uche 65 befestigt. Der Anschluss 661 in der Mitte 663 dient zum BelÃ¼ften, d. h. nachdem ein WerkstÃ¼ck angesaugt wurde und das WerkstÃ¼ck nach Versetzen wieder von dem VakuumhebegerÃ¤t 10 freigegeben werden soll, strÃ¶mt nach BetÃ¤tigen des Ventilschalters 662 durch den mittigen Anschluss 661 Luft zwischen Saugplatte 54 und WerkstÃ¼ck, so dass das Vakuum aufgehoben wird und die das WerkstÃ¼ck sich lÃ¶sen kann.In three are by looking at the vacuum lifting device 10 from below diagonally below the cover plate 60 better to recognize arranged parts. You can see it on the valve 66 arranged valve switch 662 the for ventilation of the device 10 serves. At the valve 66 are three connections 661 to see. On the two outer tubes are each 65 attached. The connection 661 in the middle 663 is used for venting, ie after a workpiece has been sucked in and the workpiece after relocating from the vacuum lifting device 10 to be released, flows after actuation of the valve switch 662 through the central connection 661 Air between suction plate 54 and workpiece so that the vacuum is released and the workpiece can come loose.

Von den beiden SchlÃ¤uchen 661 verlÃ¤uft einer in eine Filterpatrone 63 und dient dazu Staub, Schmutz und dergleichen von der Pumpe 80 fernzuhalten. Die Filterpatrone 63 ist Ã¼ber SchraubanschlÃ¼sse 64 an SchlÃ¤uchen 65 befestigt. Diese einfache Montage ermÃ¶glicht einen werkzeuglosen schnellen Einbau bzw. Austausch im Bedarfsfall.From the two hoses 661 one runs into a filter cartridge 63 and serves to dust, dirt and the like from the pump 80 keep. The filter cartridge 63 is via screw connections 64 on hoses 65 attached. This simple installation allows a tool-free quick installation or replacement if necessary.

Ein weiterer am Ventil 66 befestigter Schlauch 65 ist mit dem WinkelstÃ¼ck 67 der AnsaugÃ¶ffnung 68 verbunden.Another at the valve 66 attached hose 65 is with the elbow 67 the suction opening 68 connected.

In 4 ist eine andere AusfÃ¼hrungsform des VakuumhebegerÃ¤ts 10 dargestellt. Im Unterschied zur AusfÃ¼hrungsform der 1 sind hier die Halter 70 nicht mit Schenkeln 74 versehen, sondern im Wesentlichen vollflÃ¤chig ausgebildet. Um den Schlauch 85 vom Pumpenanschluss 82 der Pumpe 80 mit dem Ventil 66 verbinden zu kÃ¶nnen, ist in dem Halter 70 eine kleine Ãffnung 76 ausgebildet. Auch die auf der Halteplatte 53 befestigte Abdeckplatte 60 ist nicht eckig sondern halbrund gestaltet, was dem GerÃ¤t 10 ein optisch ansprechendes Design verleiht. Zudem ist die Abdeckung 60 ein handelsÃ¼blicher Kabelkanal die Herstellkosten weiter reduziert. In 4 is another embodiment of the vacuum lifting device 10 shown. In contrast to the embodiment of 1 Here are the holders 70 not with thighs 74 provided, but essentially formed over the entire surface. To the hose 85 from the pump connection 82 the pump 80 with the valve 66 to be able to connect is in the holder 70 a small opening 76 educated. Also on the mounting plate 53 attached cover plate 60 is not angular but semi-circular designed what the device 10 gives a visually appealing design. In addition, the cover 60 a commercial cable channel further reduces the manufacturing costs.

Ein wichtiger Unterschied zu der Ausbildung von 1 besteht darin, dass die Halteplatte 53 und die Saugplatte 54 einstÃ¼ckig ausgebildet sind, d. h. Halteplatte 53 und Saugplatte 54 sind baulich vereinigt, so dass die Saugplatte 54 nicht separat gelÃ¶st werden kann.An important difference to the training of 1 is that the holding plate 53 and the suction plate 54 are integrally formed, ie Retaining plate 53 and suction plate 54 are structurally united, so that the suction plate 54 can not be solved separately.

Die Steckverbindung 42 am Anschluss 41 fÃ¼r die Energieversorgung 40 ist als Flachstecker ausgefÃ¼hrt. Die Steckverbindung 44 des Akkus 43 ist hier nicht an einem Kabel 45 angeordnet, sondern unmittelbar auf dem Akku 43 befestigt. In diesem Zusammenhang sei auch erwÃ¤hnt, dass sich der Anschluss 41 innerhalb des Handgriffs 20 befinden kann, so dass der Akku 43 beim Einschieben in das GehÃ¤use 30 der Taschenlampe automatisch mit der Steckverbindung 41 in Eingriff gelangt.The plug connection 42 at the connection 41 for the energy supply 40 is designed as a flat connector. The plug connection 44 of the battery 43 is not on a cable here 45 arranged, but directly on the battery 43 attached. In this context it should also be mentioned that the connection 41 inside the handle 20 can be located so that the battery 43 when inserted into the housing 30 the flashlight automatically with the connector 41 engaged.

Das Ansaugen und Anheben eines WerkstÃ¼cks mit dem erfindungsgemÃ¤Ãen VakuumhebegerÃ¤t 10 stellt sich wie folgt dar:

ZunÃ¤chst wird an die Steckverbindung 42 des GerÃ¤ts 10 ein aufgeladener Akku 43 angeschlossen. Dieser wird dann in den Handgriff 20 bzw. in das TaschenlampengehÃ¤use 30 eingeschoben. Letzteres wird mit dem Deckel 33 verschlossen. Nun kann das GerÃ¤t 10 auf ein (nicht dargestelltes) WerkstÃ¼ck, z. B. eine Platte oder Fliese, die angehoben werden soll, aufgesetzt werden. Mit derselben Hand mit der das GerÃ¤t 10 am Handgriff 20 gefÃ¼hrt wird, kann Ã¼ber den im GehÃ¤use 30 integrierten Schalter 31 die Pumpe 80 eingeschaltet werden. Zwischen der Saugplatte 54 und dem WerkstÃ¼ck wird sogleich ein Vakuum erzeugt und das WerkstÃ¼ck kann angehoben werden. Nachdem das WerkstÃ¼ck an eine vorgesehene Stelle versetzt worden ist, kann der Schalter 662 fÃ¼r das BelÃ¼ftungsventil 66 betÃ¤tigt werden. Das VakuumhebegerÃ¤t 10 lÃ¶st sich von dem WerkstÃ¼ck und kann am nÃ¤chsten WerkstÃ¼ck angesetzt werden.The suction and lifting of a workpiece with the vacuum lifting device according to the invention 10 Is as follows:

First, to the connector 42 of the device 10 a charged battery 43 connected. This will then be in the handle 20 or in the flashlight housing 30 inserted. The latter comes with the lid 33 locked. Now the device can 10 on a (not shown) workpiece, for. As a plate or tile to be raised, are placed. With the same hand with the device 10 on the handle 20 can be guided over the housing 30 integrated switch 31 the pump 80 be turned on. Between the suction plate 54 and the workpiece is immediately generated a vacuum and the workpiece can be raised. After the workpiece has been moved to a designated location, the switch 662 for the ventilation valve 66 be operated. The vacuum lifting device 10 separates from the workpiece and can be attached to the next workpiece.

Falls nach lÃ¤ngerem Einsatz der Akku 43 entleert ist, kann er an eine Ladestation (nicht dargestellt) angeschlossen und wieder aufgeladen werden. Zur weiteren Benutzung des VakuumhebegerÃ¤ts 10 wird dann ein anderer Akku oder aber das Netzteil 90 angeschlossen. Man kann die Steckverbindung 41 auch derart ausbilden, dass das Netzteil 90 bei eingesetztem Akku 43 angeschlossen werden kann. Auf diese Weise ist es mÃ¶glich, den Akku 43 bereits wÃ¤hrend des Betriebes aufzuladen.If after prolonged use of the battery 43 is emptied, it can be connected to a charging station (not shown) and recharged. For further use of the vacuum lifting device 10 then another battery or the power supply 90 connected. You can use the plug connection 41 also train so that the power supply 90 when the battery is inserted 43 can be connected. In this way it is possible to use the battery 43 already during operation.

Die Erfindung ist nicht auf eine der vorbeschriebenen AusfÃ¼hrungsformen beschrÃ¤nkt, sondern in vielfÃ¤ltiger Weise abwandelbar. So kÃ¶nnen die Akkus 43 beispielsweise bei Bedarf mit einer optischen Anzeigen (hier nicht dargestellt) versehen sein, um den Ladezustand anzuzeigen. Die optische Anzeige kann entweder im GehÃ¤use 30 oder im Deckel 33 angeordnet sein, so dass diese von auÃen sichtbar ist.The invention is not limited to one of the above-described embodiments, but can be modified in many ways. So can the batteries 43 For example, if necessary with an optical displays (not shown here) to indicate the state of charge. The optical display can either be in the housing 30 or in the lid 33 be arranged so that it is visible from the outside.

Ãber die GrÃ¶Ãe und LÃ¤nge des GehÃ¤uses 30 ist entsprechend das VakuumhebegerÃ¤t 10 kleiner bzw. grÃ¶Ãer ausfÃ¼hrbar. Die OberflÃ¤che des Handgriffs 20 kann zum besseren Handhaben angeraut oder mit einer elastischen Auflage versehen sein.About the size and length of the case 30 is accordingly the vacuum lifting device 10 smaller or larger executable. The surface of the handle 20 can be roughened for better handling or provided with an elastic support.

Das PumpengehÃ¤use 35 sowie der am Endabschnitt 29 des Griffs 20 angebrachte Deckel 33 kÃ¶nnen alternativ am Handgriff 20 aufgesteckt oder mit Hilfe von anderen Verbindungsmitteln kraft- und/oder formschlÃ¼ssig angebracht sein.The pump housing 35 as well as the end section 29 of the handle 20 attached lids 33 can alternatively on the handle 20 attached or with the help of other fasteners force and / or positively attached.

Der bevorzugt eingesetzte Lithium-Ionen Akku 43 kann auch gegen einen herkÃ¶mmlichen anderen Akku ausgetauscht werden. Der Akku kann so ausgebildet sein, dass er zwei Steckverbindungen aufweist. Eine Steckverbindung wird an das VakuumhebegerÃ¤t 10 aufgesteckt, die andere wird mit dem Netzteil 90 verbunden, so dass bei entladenem Akku und angeschlossenem Netzteil 90, einerseits das GerÃ¤t betrieben wird und gleichzeitig der Akku aufgeladen wird.The preferred lithium-ion battery 43 can also be exchanged for a conventional other battery. The battery can be designed so that it has two connectors. A plug connection is sent to the vacuum lifting device 10 plugged in, the other comes with the power adapter 90 connected, so with discharged battery and connected power supply 90 , on the one hand the device is operated and at the same time the battery is charged.

Die Verbindung von Halteplatte 53 mit Saugplatte 54 muss nicht zwingend Ã¼ber Schnellverbinder 57 erfolgen, sondern kann auch Ã¼ber einfache Schraub- und Mutterverbindungen oder Madenschrauben miteinander verbunden sein.The connection of retaining plate 53 with suction plate 54 does not necessarily have a quick connector 57 carried out, but can also be connected to each other via simple screw and nut connections or grub screws.

SÃ¤mtliche aus den AnsprÃ¼chen, der Beschreibung und der Zeichnung hervorgehenden Merkmale und Vorteile, einschlieÃlich konstruktiver Einzelheiten, rÃ¤umlicher Anordnungen und Verfahrensschritten, kÃ¶nnen sowohl fÃ¼r sich als auch in den verschiedensten Kombinationen erfindungswesentlich sein.All of the claims, the description and the drawings resulting features and advantages, including design details, spatial arrangements and method steps may be essential to the invention both in itself and in various combinations.

BezugszeichenlisteLIST OF REFERENCE NUMBERS

1010

VakuumhebegerÃ¤tVakuumhebegerÃ¤t

2020

Handgriffhandle

2222

Oberseite des HandgriffsTop of the handle

2424

Unterseite des HandgriffsBottom of the handle

2626

Stirnseitenfront sides

2727

Endabschnittend

2828

Mittelteilmidsection

2929

EndeThe End

3030

TaschenlampengehÃ¤useflashlight casing

3131

Schalterswitch

3232

LÃ¶tverbindung (Schalter)Solder joint (switch)

3333

Deckelcover

133133

Gewindethread

134134

Zwischenringintermediate ring

3434

Gewindethread

3535

PumpengehÃ¤usepump housing

3636

Anfangsbereichinitial region

3737

Endbereichend

3838

Unterseite PumpengehÃ¤useBottom of pump housing

4040

Energieversorgungpower supply

4141

Anschlussconnection

4242

Steckverbindungconnector

4343

Akkumulatoraccumulator

4444

Steckverbindung AkkumulatorPlug connection accumulator

4545

Kabelelectric wire

5050

Saugvorrichtungsuction device

5151

Oberseite der HalteplatteTop of the retaining plate

5252

Unterseite der HalteplatteBottom of the retaining plate

5353

HalteplatteRetaining plate

5454

Saugplattesuction plate

5555

Unterseite der SaugplatteBottom of the suction plate

5656

Gummidichtungrubber seal

5757

Schnellverbinderquick connector

5858

Ãffnungopening

6060

Abdeckplattecover

6161

Stirnseiten der AbdeckplatteEnd faces of the cover plate

6262

Schraubenscrew

6363

Filterpatronefilter cartridge

6464

SchraubanschlÃ¼ssescrew

6565

Schlauchtube

6666

VentilValve

661661

AnschlÃ¼sseconnections

662662

Ventilschaltervalve switch

663663

Anschluss MitteConnection center

6767

WinkelstÃ¼ckelbow

6868

AnsaugÃ¶ffnungsuction

7070

Halterholder

7171

oberes Endetop end

7272

unteres Endelower end

7373

runde Ãffnunground opening

7474

Schenkelleg

7575

Madenschraubegrub screw

7676

Ãffnungopening

8080

Pumpepump

8282

Pumpenanschlusspump connection

8484

Anschlussconnection

8585

Schlauchtube

8686

Elektromotorelectric motor

8787

LÃ¶tverbindungsolder

8888

Auslassoutlet

9090

Netzteilpower adapter

9191

Steckverbindung NetzteilPlug connection power supply

9292

Deckel NetzteilCover power supply

9393

Durchbruchbreakthrough

9494

Kabelelectric wire

## Classifications

- B25B11/007

## Cited patent documents

- [DE-102005022929-B4](https://patents.google.com/patent/DE102005022929B4/en) — UNKNOWN
- [DE-29916647-U1](https://patents.google.com/patent/DE29916647U1/en) — UNKNOWN
- [DE-4211014-A1](https://patents.google.com/patent/DE4211014A1/en) — UNKNOWN
- [US-4976173-A](https://patents.google.com/patent/US4976173A/en) — UNKNOWN
- [US-5795001-A](https://patents.google.com/patent/US5795001A/en) — UNKNOWN

---

Generated by IPtorch. Verify legal conclusions against the official publication.
