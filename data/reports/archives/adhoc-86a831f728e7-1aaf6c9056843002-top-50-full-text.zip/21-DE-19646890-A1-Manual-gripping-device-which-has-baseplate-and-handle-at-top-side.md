# 21. Manual gripping device which has baseplate and handle at top side

- **Archive rank:** 21 of 50
- **Publication:** [DE-19646890-A1](https://patents.google.com/patent/DE19646890A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/007811545/publication/DE19646890A1?q=pn%3DDE19646890A1)
- **Publication date:** 1998-05-14
- **Filing date:** 1996-11-13
- **Earliest priority:** 1996-11-13
- **Family:** 7811545
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** GRUBER BRUNO
- **Inventors:** GRUBER BRUNO

## Abstract

The manual gripping device has a baseplate (2), which carries at the top side a handle (5) located above a distance holder (6), and at the under side carries a rubber elastic adhesion element. It has a controllable pump (13), which produces between the adhesion elements and a part to grip, a determined pressure compared to the atmosphere. The pump is a battery operated vacuum pump. The battery and the vacuum pump are accommodated constructively at the gripping device. The battery is an exchangeable accumulator (4), which is connected to the gripping unit across plug contacts (11,12). The accumulator lies on an imaginary line, which extends in the direction of the handle. The accumulator lies in a row with the handle and the external edge region of the baseplate. An on/off switch (8) is provided at the top side of a distance holder.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-19646890-A1/ops000.png)

![Sketch 1 for DE-19646890-A1](https://nimo.iptorch.com/refdrawing/DE-19646890-A1/ops000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-19646890-A1/ops001.png)

![Sketch 2 for DE-19646890-A1](https://nimo.iptorch.com/refdrawing/DE-19646890-A1/ops001.png)

## Claims

### Claim 1 (independent)

Manueller Greifer, der eine Grundplatte, die an der Deckseite einen über Abstandshalter gelagerten Handgriff und an der Unterseite gummielastische Haftelemente trägt, und der eine steuerbare Pumpe aufweist, die zwischen den Haftelementen und einem zu greifenden Teil einen bestimmten Druck gegenüber der Atmosphäre erzeugt, dadurch gekennzeichnet, daß die Pumpe eine batteriebetriebene Vakuumpumpe (13) ist, daß die Batterie und die Vakuumpumpe (13) baulich an dem Greifer untergebracht sind, und daß die Batterie ein Wechselakku (4) ist, der über Steckkontakte (11, 12) an dem Greifer anschließbar ist. manual gripper which has a base plate which has a handle mounted on a spacer on the top side and rubber-elastic adhesive elements on the underside and which has a controllable pump which generates a certain pressure in relation to the atmosphere between the adhesive elements and a part to be gripped, characterized by that the pump is a battery-operated vacuum pump ( 13 ), that the battery and the vacuum pump ( 13 ) are structurally housed on the gripper, and that the battery is a removable battery ( 4 ) which can be connected to the gripper via plug contacts ( 11 , 12 ).

### Claim 2

Manueller Greifer nach Anspruch 1, dadurch gekennzeichnet, daß der Wechselakku (4) auf einer gedachten Linie liegt, die sich in Richtung des Handgriffes (5) erstreckt.2. Manual gripper according to claim 1, characterized in that the removable battery ( 4 ) lies on an imaginary line which extends in the direction of the handle ( 5 ).

### Claim 3

Manueller Greifer nach Anspruch 1 und 2, dadurch gekennzeichnet, daß der Wechselakku (4) in Reihe mit dem Handgriff (5) und am äußeren Randbereich der Grundplatte (2) liegt.3. Manual gripper according to claim 1 and 2, characterized in that the removable battery ( 4 ) is in series with the handle ( 5 ) and on the outer edge region of the base plate ( 2 ).

### Claim 4

Manueller Greifer nach Anspruch 1 und 2, dadurch gekennzeichnet, daß der Wechselakku (4) in die Abstandshalter (6, 7) integriert ist, die den Handgriff (5) tragen.4. Manual gripper according to claim 1 and 2, characterized in that the removable battery ( 4 ) in the spacers ( 6 , 7 ) is integrated, which carry the handle ( 5 ).

### Claim 5

Manueller Greifer nach Anspruch 1 bis 4, dadurch gekennzeichnet, daß die Grundplatte (2) plan ist.5. Manual gripper according to claim 1 to 4, characterized in that the base plate ( 2 ) is flat.

### Claim 6

Manueller Greifer nach Anspruch 1 bis 4, dadurch gekennzeichnet, daß die Grundplatte (3) an das zu greifende Teil angepaßt und insbesondere kreisbogenförmig gekrümmt ist.6. Manual gripper according to claim 1 to 4, characterized in that the base plate ( 3 ) is adapted to the part to be gripped and in particular is curved in a circular arc.

### Claim 7

Manueller Greifer nach Anspruch 6, dadurch gekennzeichnet, daß die kreisbogenförmige Krümmung einen Öffnungswinkel von kleiner als 180°, insbesondere 120° aufweist.7. Manual gripper according to claim 6, characterized in that the arcuate curvature an opening angle of less than 180 °, in particular 120 °.

### Claim 8

Manueller Greifer nach Anspruch 1 bis 7, dadurch gekennzeichnet, daß ein EIN/AUS-Schalter (8), insbesondere an der Oberseite eines Abstandshalters (7) ausgebildet ist8. Manual gripper according to claim 1 to 7, characterized in that an ON / OFF switch ( 8 ), in particular on the top of a spacer ( 7 ) is formed

### Claim 9

Manueller Greifer nach Anspruch 1 bis 8, dadurch gekennzeichnet, daß akustische und/oder optische Signalelemente (9, 10), insbesondere LEDs vorgesehen sind. Manual gripper according to claim 1 to 8, characterized in that acoustic and / or optical signal elements ( 9 , 10 ), in particular LEDs are provided.

### Claim 10

Manueller Greifer nach Anspruch 9, dadurch gekennzeichnet, daß die Signalelemente (9, 10), den Ladezustand des Wechselakku (4) und/oder die Druckverhältnisse zwischen den Haftelementen und dem zu greifenden Teil signalisieren.10. Manual gripper according to claim 9, characterized in that the signal elements ( 9 , 10 ), the state of charge of the removable battery ( 4 ) and / or the pressure conditions between the adhesive elements and the part to be gripped signal.

### Claim 11

Manueller Greifer nach Anspruch 1 bis 10, dadurch gekennzeichnet, daß Steuerelemente vorgesehen sind, die ein Umschalten des Pumpbetriebs von Vakuum auf Überdruck und umgekehrt zulassen.11. Manual gripper according to claim 1 to 10, characterized in that Control elements are provided which switch the pumping mode from Allow vacuum to overpressure and vice versa.

### Claim 12

Manueller Greifer nach Anspruch 11, dadurch gekennzeichnet, daß der Vakuumbetrieb der Grundbetriebszustand ist.12. Manual gripper according to claim 11, characterized in that the Vacuum operation is the basic operating state.

### Claim 13

Manueller Greifer nach Anspruch 11 und 12, dadurch gekennzeichnet, daß das Steuerungselement eine pneumatischer, manueller Ventilschieber (16) ist, der die Verbindungsleitung (20) zwischen der Grundplatte (2) wechselweise mit einer Saugleitung (14) und einer Druckleitung (15) verbindet.13. Manual gripper according to claim 11 and 12, characterized in that the control element is a pneumatic, manual valve slide ( 16 ), the connecting line ( 20 ) between the base plate ( 2 ) alternately with a suction line ( 14 ) and a pressure line ( 15th ) connects.

### Claim 14

Manueller Greifer nach Anspruch 12, dadurch gekennzeichnet, daß die Druckleitung (15) die Druckabgabeseite einer Membranvakuumpumpe bildet.14. Manual gripper according to claim 12, characterized in that the pressure line ( 15 ) forms the pressure discharge side of a diaphragm vacuum pump.

### Claim 15

Manueller Greifer nach Anspruch 1 bis 14, dadurch gekennzeichnet, daß an der Grundplatte (2) Sensorelemente ausgebildet sind, die die Druckverhältnisse und/oder die Berührung mit dem zu greifenden Teil detektieren.15. Manual gripper according to claim 1 to 14, characterized in that on the base plate ( 2 ) sensor elements are formed which detect the pressure conditions and / or the contact with the part to be gripped.

### Claim 16

Manueller Greifer nach Anspruch 14, dadurch gekennzeichnet, daß das Sensorelement ein kapazitver Sensor, ein Taststösel (25) und/oder eine Membrandose (28) ist.16. Manual gripper according to claim 14, characterized in that the sensor element is a capacitive sensor, a probe ( 25 ) and / or a membrane box ( 28 ).

### Claim 17

Manueller Greifer nach Anspruch 15, dadurch gekennzeichnet, daß die Sensorelemente einen Schalter (22) steuern, der als Schließer den EIN/AUS-Schalter (8) überbrückt. Manual gripper according to claim 15, characterized in that the sensor elements control a switch ( 22 ) which bridges the ON / OFF switch ( 8 ) as a closer.

### Claim 18

Manueller Greifer nach Anspruch 9 bis 15, dadurch gekennzeichnet, daß die Sensorelemente die Signalelemente (9, 10) ansteuern.18. Manual gripper according to claim 9 to 15, characterized in that the sensor elements control the signal elements ( 9 , 10 ).

### Claim 19

Manueller Greifer nach Anspruch 12 bis 17, dadurch gekennzeichnet, daß der Ventilschieber (16) drei Schaltstellungen, Vakuum, Atmosphäre und Druck aufweist.19. Manual gripper according to claim 12 to 17, characterized in that the valve slide ( 16 ) has three switching positions, vacuum, atmosphere and pressure.

### Claim 20

Manueller Greifer nach Anspruch 12 bis 18, dadurch gekennzeichnet, daß der Ventilschieber (16) in dem Abstandshalter (6, 7) ausgebildet ist.20. Manual gripper according to claim 12 to 18, characterized in that the valve slide ( 16 ) is formed in the spacer ( 6 , 7 ).

## Full description

PERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippers

Description

Translated from German

Die Erfindung betrifft einen manuellen Greifer gemÃ¤Ã dem Oberbegriff des

Anspruchs 1.The invention relates to a manual gripper according to the preamble of

Claim 1.

Ein derartiger Greifer besteht aus einer Grundplatte, die an der Deckseite

einen Ã¼ber Abstandshalter gelagerten Handgriff und an der Unterseite

gummielastische Haftelemente aufweist. Weiter ist eine steuerbare Pumpe

vorgesehen, die zwischen den Haftelementen und einem zu greifenden Teil

einen bestimmten Druck gegenÃ¼ber der AtmosphÃ¤re aufbaut. Dieser bekannte

Greifer wird beispielsweise zum Verlegen von Gehwegplatten verwendet.Such a gripper consists of a base plate on the top side

a handle mounted on a spacer and on the underside

has rubber-elastic adhesive elements. There is also a controllable pump

provided between the adhesive elements and a part to be gripped

builds up a certain pressure against the atmosphere. This well-known

Grab is used, for example, to lay pavement slabs.

Der bekannte manuelle Greifer hat sich bewÃ¤hrt, dennoch ist es

wÃ¼nschenswert, den bekannten Greifer weiter zu entwickeln, um seine

EinsatzmÃ¶glichkeiten zu verbessern.The well-known manual gripper has proven itself, but it is

desirable to develop the known gripper to its

To improve possible uses.

Daher ist es Aufgabe der Erfindung, an einem manuellen Greifer die

Handhabung zu verbessern.Therefore, it is an object of the invention to a manual gripper

Improve handling.

Die Aufgabe der Erfindung wird durch die Merkmale des Anspruchs 1 gelÃ¶st.The object of the invention is solved by the features of claim 1.

ErfindungsgemÃ¤Ã weist der manuelle Greifer eine batteriebetriebene

Vakuumpumpe auf, die zusammen mit der Batterie baulich an dem Greifer

untergebracht ist. Ein weiteres wesentliches Merkmal ist, daÃ die Batterie ein

steckbarer Wechselakku ist.According to the invention, the manual gripper has a battery-operated one

Vacuum pump on, which is structurally attached to the gripper

is housed. Another key feature is that the battery is a

plug-in removable battery.

ErfindungsgemÃ¤Ã ergibt sich damit ein einstÃ¼ckiges Werkzeug, das den

Arbeitsablauf nicht durch ZuleitungsschlÃ¤uche und Verbindungskabel

behindert, wie dies beim Stand der Technik der Fall ist. Somit liegt ein

Werkzeug vor, das einen schnelleren und behinderungsfreien Einsatz erlaubt.

Durch den Wechselakku ist es mÃ¶glich, den begrenzten

Stromversorgungsbetrieb auch Ã¼ber lange ArbeitsablÃ¤ufe aufrecht zu halten.

Einfaches Stecken erlaubt den Einsatz einer neu geladenen Batterie.According to the invention this results in a one-piece tool that the

Workflow not through supply hoses and connecting cables

hampers, as is the case with the prior art. Thus lies one

Tool that allows faster and unobstructed use.

With the removable battery it is possible to use the limited one

Maintain power supply operations even over long work processes.

Simply plugging in allows the use of a newly charged battery.

Der Wechselakku liegt bevorzugt auf einer gedachten Linie, die sich lÃ¤ngs des

Handgriffes erstreckt. Damit wird der Vorteil eines Schwerpunktausgleichs

bewirkt und der erfindungsgemÃ¤Ãe Greifer hÃ¤ngt in Greifposition in gerader

Lage.The removable battery is preferably on an imaginary line that runs along the

Handle extends. This is the advantage of balancing the focus

causes and the gripper according to the invention hangs in the gripping position in a straight line

Location.

Ein weiterer Vorteil nach einer Weiterbildung besteht darin, daÃ ein

Ventilschieber vorgesehen ist, der ein Umschalten von Vakuum- auf

Druckluftbetrieb zulÃ¤Ãt. Auf diese Weise kann eine Trennung zwischen dem

Greifer und einer angehobenen und plazierten Platte wesentlich schneller

erfolgen.Another advantage of training is that a

Valve slide is provided, which switches from vacuum to

Allows compressed air operation. In this way, a separation between the

Gripper and a raised and placed plate much faster

respectively.

Nach einer anderen Weiterbildung sind Sensorelemente vorgesehen, die den

Vakuumbetrieb selbsttÃ¤tig einschalten, sobald der Sensor eine zu greifende

Platte detektiert. Bevorzugt weist der Sensor eine Einstellung auf, daÃ das

Eigengewicht des Greifers in der Ruheposition den Vakuumbetrieb nicht

einschaltet.According to another development, sensor elements are provided which

Switch on vacuum mode automatically as soon as the sensor detects one

Plate detected. The sensor preferably has a setting that the

Â Dead weight of the gripper in the rest position does not mean vacuum operation

switches on.

Weiterbildungen der Erfindung sind den anderen UnteransprÃ¼chen zu

entnehmen, die in beliebiger Weise als Ganzes oder in einzelnen Merkmalen

untereinander oder mit dem ersten Anspruch in technisch funktioneller Weise

kombinierbar sind.Developments of the invention are to the other claims

refer to that in any way as a whole or in individual characteristics

with each other or with the first claim in a technically functional manner

can be combined.

Nachfolgend wird die Erfindung anhand der Zeichnung nÃ¤her beschrieben. Es

zeigen:The invention is described in more detail below with reference to the drawing. It

demonstrate:

Fig. 1 eine perspektivische Ansicht einer AusfÃ¼hrungsform der

Erfindung, und Fig. 1 is a perspective view of an embodiment of the invention, and

Fig. 2 eine Prinzipskizze einer Verschaltung einer AusfÃ¼hrungsform der

Erfindung. Fig. 2 is a schematic diagram of an interconnection of an embodiment of the invention.

Fig. 1 zeigt einen manuellen Greifer mit einer planen Grundplatte 2 und einem

unterseitigen Randwulst 3, die zusammen eine Saugplatte 1 bilden. Der

Randwulst 3 besteht aus gummielastischem Material. Der manuelle Greifer

dient beim Verlegen zum Anheben und Absetzen von Kacheln und Platten. Im

Prinzip eignet sich der Greifer zum kurzfristigen Transport von Brettern,

Glasplatten und anderen flachen GegenstÃ¤nden. Fig. 1 shows a manual gripper with a flat base plate 2 and an underside edge bead 3 , which together form a suction plate 1 . The edge bead 3 is made of rubber-elastic material. The manual gripper is used to lift and set tiles and slabs when laying. In principle, the gripper is suitable for the short-term transport of boards, glass plates and other flat objects.

Je nach AusfÃ¼hrungsform kann die Saugplatte 1 auch kreisbogenfÃ¶rmig

gekrÃ¼mmt sein, um zum Beispiel Kunststoffrohre anzuheben. Zu diesem Zweck

ist die KrÃ¼mmung der Saugplatte 1 an die KrÃ¼mmung des Gegenstandes

angepaÃt, der angehoben werden soll. Vorzugsweise besitzt eine gekrÃ¼mmte

Saugplatte 1 in der Seitenansicht einen Ãffnungswinkel von 120Â°. Auf diese

Weise kann der Greifer leicht an einem Rohr angesetzt und entfernt werden,

weil keine Hinterschneidungen vorliegen.Depending on the embodiment, the suction plate 1 can also be curved in a circular arc, for example to lift plastic pipes. For this purpose, the curvature of the suction plate 1 is adapted to the curvature of the object that is to be lifted. A curved suction plate 1 preferably has an opening angle of 120 Â° in the side view. In this way, the gripper can be easily attached to a pipe and removed because there are no undercuts.

An der Oberseite der Grundplatte 2 sind zwei gegenÃ¼berstehende

Abstandshalter 6, 7 vorgesehen, die Ã¼ber einen Handgriff 5 miteinander

verbunden sind. Der vordere Abstandshalter 7 weist einen EIN/AUS-Schalter 8

und Signalelemente z. B. in Form von Leuchtdioden 9, 10 auf. Neben optischen

Signalelementen kÃ¶nnen auch akustische Signalelemente vorgesehen sein, die

die BetriebszustÃ¤nde des Greifers signalisieren. Als akustisches Signalelement

eignet sich insbesondere ein Piezoschwinger.On the top of the base plate 2 , two opposing spacers 6 , 7 are provided, which are connected to one another via a handle 5 . The front spacer 7 has an ON / OFF switch 8 and signal elements such. B. in the form of LEDs 9 , 10 . In addition to optical signal elements, acoustic signal elements can also be provided which signal the operating states of the gripper. A piezo oscillator is particularly suitable as an acoustic signal element.

Weiter trÃ¤gt die Grundplatte 2 an der Oberseite einen aufladbaren

Wechselakku 4, der Ã¼ber Steckkontakte 11, 12 (vgl. Fig. 2) schnell

ausgetauscht werden kann, wenn er entladen ist. Der aufladbare Wechselakku

4 ist gewichtsmÃ¤Ãig so angeordnet, daÃ er kein Drehmoment um die Achse des

Handgriffes 5 ausÃ¼bt, wenn der Greifer angehoben wird. Bevorzugt liegt der

Wechselakku 4 schwerpunktsmÃ¤Ãig auf einer gedachten Linie, die sich lÃ¤ngs

des Handgriffes 5 erstreckt. Der Wechselakku 4 kann auch in einem der

Abstandhalter 6, 7 integriert sein.Furthermore, the base plate 2 carries on the top a rechargeable battery 4 that can be quickly replaced via plug contacts 11 , 12 (see FIG. 2) when it is discharged. The rechargeable battery 4 is arranged in weight so that it does not exert any torque about the axis of the handle 5 when the gripper is raised. The exchangeable battery 4 is preferably located on an imaginary line that extends along the handle 5 . The exchangeable battery 4 can also be integrated in one of the spacers 6 , 7 .

Fig. 2 zeigt eine Prinzipdarstellung des Greifers aus Fig. 1 teilweise im Schnitt

mit einer zugehÃ¶rigen elektrisch, pneumatischen Verschaltung. Der Greifer aus

Fig. 1 weist eine Vakuumpumpe, vorzugsweise eine Membranpumpe 13 auf,

die z. B. in dem Halter 6 untergebracht ist. Die Membranpumpe 13 wird

eingangsseitig Ã¼ber den elektrischen Schalter 8 von dem steckbaren Akku 4

mit Strom versorgt, der Ã¼ber die Steckkontakte 11, 12 schnell anschlieÃbar ist.

Weiter weist die Pumpe 13 eine Saugleitung 14 und eine Druckleitung 15 auf,

die an einen manuell bedienbaren Ventilschieber 16 angeschlossen sind. FIG. 2 shows a basic illustration of the gripper from FIG. 1, partly in section with an associated electrical, pneumatic circuit. The gripper from FIG. 1 has a vacuum pump, preferably a diaphragm pump 13 , which, for. B. is housed in the holder 6 . The diaphragm pump 13 is supplied on the input side by the electrical switch 8 with the plug-in battery 4 , which can be quickly connected via the plug contacts 11 , 12 . The pump 13 also has a suction line 14 and a pressure line 15 , which are connected to a manually operated valve slide 16 .

Der Ventilschieber 16 ist entgegen eine Druckfeder 18 in FÃ¼hrungselementen

17 gelagert. Im Inneren weist der Schieber 16 einen StrÃ¶mungskanal 19 mit

drei EinzelkanÃ¤len auf, die miteinander verbunden sind. Ausgangsseitig

mÃ¼ndet ein Einzelkanal des StrÃ¶mungskanals 19 des Ventilschiebers 16 in

einen beweglichen Schlauch 20, der mit der Saugplatte 1 verbunden ist. In der

in Fig. 2 gezeigten Stellung wird die Luft Ã¼ber den geradlinigen ersten und

zweiten Kanalabschnitt des StrÃ¶mungskanals 19 sowie Ã¼ber die Ãffnung 26 in

der Grundplatte 2 aus dem Hohlraum 21 abgesaugt, den der Randwulst 3 an

der Grundplatte 2 aufspannt. Innerhalb des Ventilschiebers 16 ist ein

L-fÃ¶rmiger Abschnitt des StrÃ¶mungskanals 19 vorgesehen, der den dritten

Kanalzweig bildet. In der gezeigten Stellung wird die EingangsÃ¶ffnung des L-fÃ¶rmigen

Einzelkanals durch ein Ã¤uÃeres FÃ¼hrungselement 17 geschlossen.The valve spool 16 is supported against a compression spring 18 in guide elements 17 . Inside, the slide 16 has a flow channel 19 with three individual channels which are connected to one another. On the output side, a single channel of the flow channel 19 of the valve slide 16 opens into a movable hose 20 which is connected to the suction plate 1 . In the position shown in FIG. 2, the air is sucked out of the cavity 21 through the rectilinear first and second channel section of the flow channel 19 and via the opening 26 in the base plate 2 , which the edge bead 3 spans on the base plate 2 . Within the valve slider 16. An L-shaped section of the flow channel 19 is provided, which forms the third channel branch. In the position shown, the inlet opening of the L-shaped individual channel is closed by an outer guide element 17 .

Auf dieses Weise preÃt der Ã¤uÃere Luftdruck die Saugplatte 1 an den

Gegenstand (nicht dargestellt) an, der angehoben werden soll. Die Saugplatte

1 kann nur den Randwulst 3, aber auch einen zusÃ¤tzliche Gummifolie 24

aufweisen, die nicht ganz bis zum Rand der Grundplatte 2 angeklebt ist. Diese

teilverklebte Gummiplatte ist als flacher Haftsauger unter dem Namen

LevistorÂ® bekannt geworden. Der Greifer lÃ¤Ãt sich mit den unterschiedlichsten

Haftelementen an der Unterseite der Grundplatte 2 ausstatten.In this way, the external air pressure presses the suction plate 1 against the object (not shown) that is to be lifted. The suction plate 1 can have only the edge bead 3 , but also an additional rubber film 24 , which is not completely glued to the edge of the base plate 2 . This partially glued rubber sheet has become known as a flat suction cup under the name LevistorÂ®. The gripper can be equipped with a wide variety of adhesive elements on the underside of the base plate 2 .

Wurde ein ausreichender Unterdruck in dem Hohlraum 21 aufgebaut, lÃ¤Ãt sich

dies Ã¼ber eine Membrandose 28 detektieren, die Ã¼ber eine Ãffnung 30 mit dem

Hohlraum 21 verbunden ist, und deren Membrane 29 in Richtung auf den

Hohlraum 21 gesaugt wird. Die Membrane 29 ist mit einem Umschalter 27

gekoppelt. Mit der Bewegung der Membrane 29 schaltet der Umschalter die

beiden Leuchtdioden 9, 10 um, die z. B. rotes und grÃ¼nes Licht abgeben.

Ebenso kann ein Piezoschwinger vorgesehen sein, der ein akustisches Signal

abgibt, daÃ eine ausreichender Unterdruck vorliegt, um z. B. eine Gehwegplatte

anzuheben.If a sufficient negative pressure has been built up in the cavity 21 , this can be detected via a membrane box 28 which is connected to the cavity 21 via an opening 30 and the membrane 29 of which is sucked in the direction of the cavity 21 . The membrane 29 is coupled to a changeover switch 27 . With the movement of the membrane 29 , the switch switches the two LEDs 9 , 10 to z. B. give red and green light. Likewise, a piezo oscillator can be provided, which emits an acoustic signal that there is sufficient negative pressure to z. B. raise a walkway slab.

Um nach dem Absetzen der Platte in der gewÃ¼nschten Position den Unterdruck

abzubauen, kann einerseits der Schalter 8 ausgeschaltet werden. Dies

erfordert jedoch eine relativ lange Zeitspanne, bis Luft in den Hohlraum 21

eingestrÃ¶mt ist und der Greifer wieder von der Gehwegplatte entfernt werden

kann, um die nÃ¤chste Platte zu ergreifen.In order to release the negative pressure in the desired position after the plate has been set down, the switch 8 can be switched off on the one hand. However, this requires a relatively long period of time until air has flowed into the cavity 21 and the gripper can be removed again from the walkway slab in order to grip the next slab.

Nach der in Fig. 2 gezeigten AusfÃ¼hrungsform des Ventilschieber 16 ist es

mÃ¶glich, den StrÃ¶mungskanal 19 in Richtung des Pfeiles um eine Kanalbreite

zu verschieben. Auf diese Weise kann Umgebungsluft in den Schlauch 20

einstrÃ¶men und der Greifer kann etwas schneller abgehoben werden.According to the embodiment of the valve slide 16 shown in FIG. 2, it is possible to shift the flow channel 19 by one channel width in the direction of the arrow. In this way, ambient air can flow into the hose 20 and the gripper can be lifted somewhat faster.

Andererseits ist es mÃ¶glich, den Saugbetrieb der Pumpe 13 elektrisch auf die

Zufuhr von Luft umzustellen (nicht dargestellt).

On the other hand, it is possible to electrically switch the suction operation of the pump 13 to the supply of air (not shown).

In einer dritten Betriebsstellung und in Richtung des Pfeiles in der tiefsten

Stellung des Ventilschiebers 16 gelangt der L-fÃ¶rmige Abschnitt des

StrÃ¶mungskanals 19 zu der Druckluftleitung 15, der beispielsweise die

Abgabeluft von der Membranpumpe 13 zugefÃ¼hrt wird. Somit wird Luft in den

Hohlraum 21 eingeblasen und das AblÃ¶sen der Saugplatte 1 von dem

Gegenstand erfolgt noch schneller. In diesem Zustand saugt die Leitung 14

Ã¼ber eine kleine Aussparung 31 in dem Schieber 16 Umgebungsluft an. Mit

dem Druckausgleich schaltet der Umschalter 27 um und die Leuchtdioden 9, 10

signalisieren, daÃ der Greifer abgehoben werden kann.In a third operating position and in the direction of the arrow in the lowest position of the valve slide 16 , the L-shaped section of the flow channel 19 reaches the compressed air line 15 , to which the discharge air from the diaphragm pump 13 is supplied, for example. Thus, air is blown into the cavity 21 and the suction plate 1 is detached from the object even faster. In this state, the line 14 draws in ambient air via a small recess 31 in the slide 16 . With the pressure equalization, the changeover switch 27 switches over and the light-emitting diodes 9 , 10 signal that the gripper can be lifted off.

Weiter zeigt Fig. 2 einen TaststÃ¶sel 25, der in der Grundplatte 2 angeordnet ist.

Eine mechanische Verbindung 23 stellt die Kopplung zu einem SchlieÃer 22

her. Der SchlieÃer 22 Ã¼berbrÃ¼ckt den Schalter 8, der fÃ¼r die weitere

Beschreibung der Funktionsweise geÃ¶ffnet sei. Soll z. B. eine Gehwegplatte

von einem Stapel entnommen werden, wird der Greifer kurz angepreÃt. Dabei

schaltet der SchlieÃer 22 die Membranpumpe 13 ein, verbleibt in dieser

Stellung und nach kurzer Dauer, kann die Gehwegplatte angehoben werden.

Diese Vorgehensweise erspart das manuelle Ein- und Ausschalten Ã¼ber den

Schalter 8 und erlaubt einen halbautomatischen Betrieb. Next, FIG. 2 is a TaststÃ¶sel 25, which is arranged in the base plate 2. A mechanical connection 23 establishes the coupling to a closer 22 . The make contact 22 bridges the switch 8 , which is open for further description of the mode of operation. Should z. B. a sidewalk plate can be removed from a stack, the gripper is pressed briefly. The closer 22 switches on the diaphragm pump 13 , remains in this position and after a short period of time, the walkway plate can be raised. This procedure saves manual switching on and off via switch 8 and allows semi-automatic operation.

Folglich bildet der soweit beschriebene Greifer ein einstÃ¼ckiges Werkzeug, das

vollkommen frei gehandhabt werden kann. Der Ventilschieber 16 umfaÃt damit

die drei Betriebsstellungen: Vakuum, AtmosphÃ¤re, Druck. Weiter kÃ¶nnen

Signalelemente vorgesehen sein, die den Ladezustand des Akkus 4 anzeigen.

Der Schlauch 20 kann z. B. aus Silikon bestehen.Consequently, the gripper described so far forms a one-piece tool that can be handled completely freely. The valve spool 16 thus comprises the three operating positions: vacuum, atmosphere, pressure. Signal elements can also be provided which indicate the charge status of the battery 4 . The hose 20 may e.g. B. consist of silicone.

BezugszeichenlisteReference list

11

Saugplatte

Suction plate

22nd

Grundplatte

Base plate

33rd

Randwulst

Edge bead

44th

Wechselakku

Removable battery

55

Handgriff

Handle

66

Abstandshalter

Spacers

77

Abstandshalter

Spacers

88th

EIN/AUS-Schalter

ON / OFF switch

99

LED rot

LED red

1010th

LED grÃ¼n

LED green

1111

Steckkontakt

Plug contact

1212th

Steckkontakt

Plug contact

1313

Membranpumpe

Diaphragm pump

1414

Saugleitung

Suction line

1515

Druckleitung

Pressure line

1616

Ventilschieber

Valve spool

1717th

FÃ¼hrungselemente

Guide elements

1818th

Feder

feather

1919th

StrÃ¶mungskanal

Flow channel

2020th

beweglicher Schlauch

movable hose

2121

Hohlraum

cavity

2222

SchlieÃer

NO contact

2323

mechanische Verbindung

mechanical connection

2424th

Gummifolie (LevistorÂ®)

Rubber film (LevistorÂ®)

2525th

TaststÃ¶sel

Stylus

2626

Ãffnung

opening

2727

Umschalter

switch

2828

Membrandose

Membrane box

2929

Membrane

membrane

3030th

Ãffnung

opening

3131

Aussparung

Recess

## Classifications

- B65G47/91
- B65G47/91

---

Generated by IPtorch. Verify legal conclusions against the official publication.
