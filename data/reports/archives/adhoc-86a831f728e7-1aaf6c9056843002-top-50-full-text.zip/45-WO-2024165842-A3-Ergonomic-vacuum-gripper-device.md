# 45. Ergonomic vacuum gripper device

- **Archive rank:** 45 of 50
- **Publication:** [WO-2024165842-A3](https://patents.google.com/patent/WO2024165842A3/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/090236292/publication/WO2024165842A3?q=pn%3DWO2024165842A3)
- **Publication date:** 2025-01-30
- **Filing date:** 2024-02-06
- **Earliest priority:** 2023-02-07
- **Family:** 90236292
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus

## Parties

- **Applicant / assignee:** EXORDIA GLOBAL LTD
- **Inventors:** MYATT MARCO LANCE

## Abstract

An ergonomic device (10) for attachment to a vacuum gripper (60). The device (10) comprises an elongate shaft (12), a handle arrangement (14) at a first end of the shaft (12) for manipulating the device (10), and a mounting arrangement (16) at a second end of the shaft (12) for mounting the vacuum gripper (60) thereon. The mounting arrangement (16) supports one or more conveying elements, such as one or more wheels (18), which are configured to allow the device (10) to be conveyed along the ground whilst the vacuum gripper (60) is mounted thereto.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/WO-2024165842-A3/pdf000.png)

![Sketch 1 for WO-2024165842-A3](https://nimo.iptorch.com/refdrawing/WO-2024165842-A3/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/WO-2024165842-A3/pdf001.png)

![Sketch 2 for WO-2024165842-A3](https://nimo.iptorch.com/refdrawing/WO-2024165842-A3/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/WO-2024165842-A3/pdf002.png)

![Sketch 3 for WO-2024165842-A3](https://nimo.iptorch.com/refdrawing/WO-2024165842-A3/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/WO-2024165842-A3/pdf003.png)

![Sketch 4 for WO-2024165842-A3](https://nimo.iptorch.com/refdrawing/WO-2024165842-A3/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/WO-2024165842-A3/pdf004.png)

![Sketch 5 for WO-2024165842-A3](https://nimo.iptorch.com/refdrawing/WO-2024165842-A3/pdf004.png)

## Claims

### Claim 1

CLAIMS 1. An ergonomic device for attachment to a vacuum gripper, the device comprising: an elongate shaft; a handle arrangement at a first end of the shaft for manipulating the device; and a mounting arrangement at a second end of the shaft for mounting a vacuum gripper thereon, wherein the mounting arrangement supports one or more conveying elements configured to allow the device to be conveyed along the ground whilst a vacuum gripper is mounted thereto. 2. A device as claimed in claim 1 , wherein the shaft has a length in the range 400mm-800mm. 3. A device as claimed in claim 1 or 2, wherein the length of the shaft is adjustable. 4. A device as claimed in claim 1 , 2 or 3, wherein the shaft comprises a first section and a second section, with the length of the shaft being adjusted by moving the first section longitudinally relative to the second section. 5. A device as claimed in claim 4, wherein the first section and second section are arranged telescopically. 6. A device as claimed in claim 4 or 5, wherein the position of the first section relative to the second section is fixable using one or more mechanical fasteners. 7. A device as claimed in any one of the preceding claims, wherein the handle arrangement comprises an elongate handle member. 8. A device as claimed in claim 7, wherein the handle member has a length in the range 300mm-700mm. 9. A device as claimed in claim 7 or 8, wherein the handle member extends substantially perpendicular to the shaft. 10. A device as claimed in claim 7, 8 or 9, wherein the handle member extends substantially perpendicular to the axis of rotation of the one or more conveyers. 11. A device as claimed in any one of claims 7-10, wherein the handle member comprises a bar member or a channel member. 12. A device as claimed in any one of the preceding claims, wherein the handle arrangement comprises a first lifting structure and a second lifting structure. 13. A device as claimed in claim 12, wherein each lifting structure comprises a pair of lifting members. 14. A device as claimed in claim 13, wherein the lifting members of each pair of lifting members extend substantially parallel to one another. 15. A device as claimed in claim 13 or 14, wherein each pair of lifting members comprises a joining section that extends substantially perpendicular to the pair of lifting members. 16. A device as claimed in any one of claims 12-15, wherein the position of the lifting structures is adjustable relative to the shaft. 17. A device as claimed in any one of claims 12-16, wherein the position of the lifting structures relative to the shaft is fixable using one or more mechanical fasteners. 18. A device as claimed in any one of the preceding claims, wherein the mounting arrangement comprises a mounting bracket for receiving the vacuum gripper therein. 19. A device as claimed in any one of the preceding claims, wherein the mounting arrangement comprises a first plate for attachment at a first side of the vacuum gripper and a second plate for attachment at a second side of the vacuum gripper. 20. A device as claimed in any one of the preceding claims, wherein the mounting arrangement comprises one or more fixing points for fixing the vacuum gripper to the mounting arrangement. 21. A device as claimed in any one of the preceding claims, wherein the mounting arrangement comprises one or more openings and/or recesses and/or cut-outs to allow access to one or more features of the vacuum gripper when mounted thereto. 22. A kit comprising a device as claimed in any one of claims 1-21 and a vacuum gripper for attachment thereto. 23. A system comprising a device as claimed in any one of claims 1-21 and a vacuum gripper attached thereto. 24. A method of constructing a system as claimed in claim 23, the method comprising attaching the vacuum gripper to the device. 25. A method of manipulating a load using a system as claimed in claim 23, the method comprising: attaching a load to the vacuum gripper; and using the handle arrangement of the device to move the vacuum gripper and load along the ground on the one or more conveying elements.

## Full description

**[0001]**

ERGONOMIC VACUUM GRIPPER DEVICE

**[0002]**

The present invention relates to an ergonomic device for attachment to a vacuum gripper. The present invention also relates to kits, systems and methods incorporating the ergonomic device.

**[0003]**

Vacuum grippers are used to carry heavy or awkward loads, such as sheets of material, glass, tiles, paving slabs, etc., around work sites. Vacuum grippers typically comprise a vacuum pad for contacting the load and a vacuumcreating mechanism, such as a pump, for selectively reducing the pressure in the region between the vacuum pad and the load, thereby selectively attaching the vacuum pad to the load. Vacuum grippers also typically comprise a grip that allows the vacuum gripper and its attached load to be moved manually. When using the grip to manipulate a load, an operator may need to lean forward and/or twist awkwardly, and this can lead to injury. To address this problem, it is known to attach an elongate shaft to a vacuum gripper to reduce the need for the operator to lean forward to manipulate the load. However, such devices still require the operator to lift the vacuum gripper off the ground, and therefore still have the potential to cause injury when used with particularly heavy or awkward loads.

**[0004]**

It is desired to provide improvements relating to devices for attachment to vacuum grippers.

**[0005]**

According to an aspect of the present invention there is provided an ergonomic device for attachment to a vacuum gripper, the device comprising: an elongate shaft; a handle arrangement at a first end of the shaft for manipulating the device; and a mounting arrangement at a second end of the shaft for

**[0006]**

mounting a vacuum gripper thereon, wherein the mounting arrangement supports one or more conveying elements configured to allow the device to be conveyed along the ground whilst a vacuum gripper is mounted thereto.

**[0006]**

As will be appreciated, the device of the present invention can allow for safer manipulation of a vacuum gripper and load attached thereto. In particular, an operator can use the handle arrangement of the device, together with the lever effect of the elongate shaft, to manipulate the mounting arrangement so as to move the vacuum gripper and its load along the ground on the one or more conveying elements. For example, the operator may use the handle arrangement to tip the device onto the one or more conveying members, thereby lifting the vacuum gripper and load off the ground. This in turn can reduce the risk of injury occurring by reducing the need for the operator to lift the device completely off the ground in order to move the vacuum gripper and load around a work site.

**[0007]**

In embodiments, the shaft may have a length in the range 400mm-800mm. These dimensions are ergonomic for most operators. The overall length of the shaft may be (e.g. repeatedly) adjustable. This can allow the device to be adjusted to suit a particular operator or load. For example, the shaft may comprise a first section and a second section, with the length of the shaft being adjusted by moving the first section longitudinally relative to the second section. The first section and/or second section may comprise a channel section. The first section and second section may be arranged telescopically. The second section may be located within the (e.g. channel of the) second section or vice versa. The second section may be (e.g. repeatedly) attachable to and/or detachable from the first section. This can allow the device to be disassembled for storage and/or allow

**[0009]**

different handle arrangements to be used. The position of the first section relative to the second section may be fixed using one or more mechanical fasteners (e.g. threaded fasteners, such as bolts or screws, and threaded bores). For example, a series of locking points (e.g. bores) may be provided to allow a variety of locking positions. The one or more mechanical fasteners may each have a lever arm for facilitating manual rotation of the fastener. The shaft may be formed of a metallic material, such as steel or aluminium.

**[0008]**

In embodiments, the handle arrangement may comprise an elongate handle member. The handle member may have a length in the range 300mm- 700mm. Again, these dimensions are ergonomic for most operators. The handle member may extend substantially perpendicular to the shaft. This can allow the device to be easily lifted vertically if needed. The handle member may extend substantially perpendicular to the axis of rotation of the one or more conveyers. This can provide a compact device. The shaft may be attached substantially halfway along the handle member. In some embodiments, the handle member may comprise a bar member. In other embodiments, the handle member may comprise a channel member. The handle arrangement may comprise one or more lifting structures. For example, the handle arrangement may comprise a first lifting structure and a second lifting structure. This can allow two operators to manipulate a particularly heavy or awkward load. Each lifting structure may comprise a pair of lifting members, i.e. one lifting member per hand of each operator. The lifting members of each pair of lifting members may extend substantially parallel to one another. The distance between the lifting members of the pair of lifting members may be in the range 300mm-500mm. Each pair of

**[0011]**

lifting members may comprise a joining section that extends substantially perpendicular to the pair of lifting members. Thus, each lifting structure may form a substantially U-shaped lifting structure. Each lifting structure may comprise an elongate connecting member that attaches the lifting structure to the (e.g. channel of the) handle member. The connecting member may be attached substantially midway between the lifting members and/or may be attached substantially halfway along the joining section. The connecting member may extend substantially parallel to the pair of lifting members and/or substantially perpendicular to the joining section. The connecting member may extend substantially parallel to the handle member. The position of the lifting structure may be (e.g. repeatedly) adjustable relative to the shaft (and, e.g., relative to the handle member). This can allow the lifting structure to be adjusted (e.g. inwardly and outwardly) to suit a particular operator or load. For example, the position of the lifting structure relative to the shaft (and, e.g., relative to the handle member) may be adjusted by moving the (e.g. connecting member of the) lifting structure longitudinally relative to the (e.g. channel of the) handle member. The (e.g. connecting member of the) lifting structure and the (e.g. channel of the) handle member may be arranged telescopically. For example, the (e.g. connecting member of the) lifting structure may be received in the (e.g. channel of the) handle member or vice versa. The (e.g. connecting member of the) lifting structure may be (e.g. repeatedly) attachable to and/or detachable from the (e.g. channel of the) handle member. Again, this can allow the device to be disassembled for storage and/or allow different handle arrangements to be used. The position of the (e.g. connecting member of the) lifting structure relative to the (e.g. channel of the)

**[0012]**

handle member may be fixed using one or more mechanical fasteners (e.g. threaded fasteners, such as bolts or screws, and threaded bores). For example, a series of locking points (e.g. bores) may be provided to allow a variety of locking positions. The one or more mechanical fasteners may each have a lever arm for facilitating manual rotation of the fastener. Again, the handle arrangement may be formed of a metallic material, such as steel or aluminium.

**[0009]**

In embodiments, the mounting arrangement may comprise a mounting bracket for receiving the vacuum gripper therein. The mounting arrangement may comprise a first plate for attachment at a first side of the vacuum gripper and a second plate for attachment at a second side of the vacuum gripper. The mounting arrangement may comprise a third plate attached to the shaft. The third plate may span between the first plate and the second plate. These embodiments can provide a secure mounting for the vacuum gripper. The mounting arrangement may comprise a first arm for rotational attachment (e.g. via an axle and/or bearing) at a first side of a conveying member and a second arm for rotational attachment (e.g. via an axle and/or bearing) at a second side of the conveying member. An axis of rotation (e.g. provided by an axle and/or bearing) for the conveying member may extend between the first arm and the second arm. The first arm may extend from the first plate and/or the second arm may extend from the second plate. The mounting arrangement may comprise one or more fixing points (e.g. through-holes) for fixing the vacuum gripper to the mounting arrangement. The one or more fixing points (e.g. through-holes) of the mounting arrangement may be substantially aligned with one or more corresponding fixing points (e.g. lugs) on the vacuum gripper. One or more fixing points of the

**[0014]**

mounting arrangement may be provided on the first plate and/or one or more fixing points of the mounting arrangement may be provided on the second plate. For example, a first pair of fixing points may be provided on the first plate and/or a second pair of fixing points may be provided on the second plate. Again, these embodiments can provide a secure mounting for the vacuum gripper. The mounting arrangement may comprise one or more openings and/or recesses and/or cut-outs to allow access to one or more features of the vacuum gripper when mounted thereto. For example, the mounting arrangement may comprise one or more openings and/or recesses and/or cut-outs to allow access to one or more of: a vacuum mechanism compartment (e.g. to allow air egress/ingress); a power source compartment (e.g. to allow a battery to be replaced); a power control (e.g. to allow the vacuum gripper to be powered on and/or off); an activate control (e.g. to allow the vacuum mechanism to be activated); a deactivate control (e.g. to allow the vacuum mechanism to be deactivated); a vacuum release control (e.g. to allow the vacuum gripper to be released from the load); and a pressure gauge (e.g. to allow the extent of the vacuum to be monitored). Again, the mounting arrangement may be formed of a metallic material, such as steel or aluminium. The mounting arrangement may, for example, conveniently be formed of and from a (e.g. single) sheet of material.

**[0010]**

In embodiments, the one or more conveying elements may comprise one or more wheels. The one or more conveying elements may comprise a single conveying element, e.g. a single wheel. A single conveying element can allow the device to rotate easily on the spot to provide greater manoeuvrability. The one or more conveying elements may be mounted on a single axle and/or bearing. The

**[0016]**

axes of rotation of the one or more conveying elements may be substantially perpendicular to a grip of the vacuum gripper when mounted to the mounting arrangement. This can provide a compact device and vacuum gripper system.

**[0011]**

In embodiments, the one or more conveying elements may be (e.g. repeatedly) attachable to and/or detachable from the mounting arrangement. For example, the one or more conveying elements may be (e.g. repeatedly) attachable to and/or detachable from the first arm and/or second arm. For another example, the first arm and/or second arm may be (e.g. repeatedly) attachable to and/or detachable from the mounting arrangement (e.g. together with the one or more conveying elements). These embodiments can allow the one or more conveying elements to be removed as desired, e.g. when not needed to convey the device along the ground.

**[0012]**

According to another aspect of the present invention there is provided a kit comprising a device as described herein in any aspect or embodiment and a vacuum gripper for attachment thereto.

**[0013]**

According to another aspect of the present invention there is provided a system comprising a device as described herein in any aspect or embodiment and a vacuum gripper attached thereto.

**[0014]**

According to another aspect of the present invention there is provided a method of constructing a system as described herein in any aspect or embodiment, the method comprising attaching the vacuum gripper to the device.

**[0015]**

According to another aspect of the present invention there is provided a method of manipulating a load using a system as described herein in any aspect or embodiment, the method comprising: attaching a load to the vacuum gripper;

**[0022]**

and using the handle arrangement of the device to move the vacuum gripper and load along the ground on the one or more conveying elements.

**[0016]**

In embodiments, the vacuum gripper may comprise one or more vacuum pads for selective attachment to a load. The vacuum gripper may comprise a vacuum mechanism (e.g. a pump) for selectively reducing the pressure in the region between the one or more vacuum pads and the load thereby selectively attaching the one or more vacuum pads to the load. The vacuum gripper may comprise a vacuum mechanism compartment for housing the vacuum mechanism. The vacuum mechanism may be mechanical or electro-mechanical. The vacuum gripper may comprise a power source for powering the vacuum mechanism. The power source may comprise one or more (e.g. rechargeable) batteries. The vacuum gripper may comprise a power source compartment for housing the power source. The compartment may have a removeable cover for allowing access to the power source. The vacuum gripper may comprise an elongate grip for directly manipulating the load when the vacuum gripper is not attached to the device. The grip may extend between compartments of the vacuum gripper. The vacuum gripper may be (e.g. removably) mounted to the mounting arrangement. The vacuum gripper may comprise one or more fixing points (e.g. lugs) for fixing the vacuum gripper to the mounting arrangement. The one or more fixing points (e.g. lugs) of the vacuum gripper may be substantially aligned with one or more corresponding fixing points (e.g. through-holes) of the mounting arrangement. The vacuum gripper may comprise a power control for powering the vacuum gripper on and/or off. The vacuum gripper may comprise an activate control for activating the vacuum mechanism. The vacuum gripper

**[0024]**

may comprise a deactivate control for deactivating the vacuum mechanism. The vacuum gripper may comprise a vacuum release control for selectively increasing (e.g. via a vent to the surrounding atmosphere) the pressure in the region between the one or more vacuum pads and the load thereby selectively detaching the one or more vacuum pads from the load. The vacuum gripper may comprise a pressure gauge for indicating the pressure in the region between the one or more vacuum pads and the load.

**[0017]**

By way of example only, embodiments of the invention will now be described in detail with reference being made to the accompanying drawings in which:

**[0018]**

Figure 1 is a perspective view of an ergonomic device for attachment to a vacuum gripper according to an embodiment of the present invention;

**[0019]**

Figure 2 is an exploded perspective view of the device of Figure 1 ;

**[0020]**

Figure 3 is a side view of the device of Figure 1 ;

**[0021]**

Figure 4 is a front view of the device of Figure 1 ;

**[0022]**

Figure 5 is a perspective view of an ergonomic device for attachment to a vacuum gripper according to another embodiment of the present invention;

**[0023]**

Figure 6A is a side view of a vacuum gripper for attachment to the device of Figure 1 or Figure 5; and

**[0024]**

Figure 6B is a top view of the vacuum gripper of Figure 6A.

**[0025]**

Figures 1-4 show an ergonomic device 10 for attachment to a vacuum gripper according to an embodiment of the present invention. The device 10 is formed primarily of a metallic material, such as steel or aluminium. The device 10 comprises an elongate shaft 12 which is repeatedly adjustable in length to allow

**[0034]**

the device to be adjusted to suit a particular operator or load. In this embodiment, the shaft 12 comprises a first channel section 20 and a second channel section 22. The second channel section 22 is received telescopically within the first channel section 20, with the length of the shaft 12 being adjusted by moving the second channel section 22 longitudinally relative to the first channel section 20. The second channel section 22 can even be completely detached from the first channel section 20 to facilitate storage of the device 10. The position of the second channel section 22 relative to the first channel section 20 can be fixed using a pair of mechanical fasteners 24. The mechanical fasteners 24 each comprise a threaded bolt 36 which is received through bores 37 in the second channel section 22 and into one of a series of threaded bores 38 in the first channel section 20. Each mechanical fastener has a lever arm 40 for facilitating manual rotation thereof.

**[0026]**

The device 10 further comprises a handle arrangement 14 at a first end of the shaft 12 for manipulation by an operator. In this embodiment, the handle arrangement 14 comprises a bar member 26 which extends substantially perpendicularly to the shaft 12. The second channel section 22 of the shaft 12 is attached around halfway along the bar member 26. The device 10 further comprises a mounting bracket 16 at a second end of the shaft 12 for mounting a vacuum gripper therein. In this embodiment, the bracket 16 is formed from a single sheet of folded material. The bracket 16 comprises first and second plates 27 for attachment to respective first and second sides of the vacuum gripper. The bracket 16 further comprises a third plate 28 that spans between the first and second plates 27 and is attached to the shaft 12. The bracket 16 further

**[0036]**

comprises through-holes 30 for fixing a vacuum gripper to the bracket 16. The bracket 16 further comprises various openings, recesses and cut-outs 32 to allow features of the vacuum gripper to be accessed when mounted to the bracket 16. The bracket 16 further comprises first and second arms 29 extending respectively from the first and second plates 27. The first and second arms 29 are rotationally coupled to a single wheel 18 via an axle 34. The wheel 18 allows the device 10 to be tipped and then conveyed along the ground whilst a vacuum gripper is mounted to the bracket 16. In some embodiments, the wheel 18 and/or arms 29 may be removably mounted to the bracket 16, for example to allow the device 10 to be used or stored without the wheel 18 as desired.

**[0027]**

Figure 5 shows an ergonomic device 42 for attachment to a vacuum gripper according to another embodiment of the present invention. The shaft 12, bracket 16 and wheel 18 of this device 42 are the same as those of the device 10 described above. However, in this embodiment, the handle arrangement 44 comprises a channel member 46. The handle arrangement 44 further comprises first and second lifting structures 47 to allow two operators to manipulate a particularly heavy or awkward load. Each lifting structure 47 comprises a pair of parallel lifting members 48 and a joining section 49 that extends perpendicular to the pair of lifting members 48 to form a U-shaped lifting structure. Each lifting structure 47 further comprises an elongate connecting member 50 that is telescopically received in the channel member 46. The position of the lifting structures 47 relative to the channel member 46 can be adjusted inwardly and outwardly to suit a particular operator or load. The position of the lifting structures 47 relative to the channel member 46 can be locked in place using a pair of

**[0038]**

mechanical fasteners 52, which operate in the same manner as mechanical fasteners 24 described above.

**[0028]**

Figures 6A and 6B show a vacuum gripper 60 which can be attached to either of the devices described above. The vacuum gripper 60 comprises a vacuum pad 62 for selective attachment to a sheet load 61 . The vacuum gripper 60 also comprises a vacuum pump mechanism (not visible), which is housed in vacuum mechanism compartment 64 for selectively reducing the pressure in a region between the vacuum pad 62 and load 61 . The vacuum gripper 60 further comprises a removable and rechargeable battery power source (not visible), which is housed in power source compartment 66, for powering the vacuum mechanism. The battery power source can be accessed by removing a cover 67, thereby allowing the battery power source to be removed and replaced. The vacuum gripper 60 further comprises an elongate grip 68 that extends between compartments 64, 66 for directly manipulating the load when the vacuum gripper 60 is not attached to the ergonomic device. The vacuum gripper 60 further comprises a slidable power control switch 70 for powering the vacuum gripper 60 on and off, a combined activate/deactivate control button 72 that can be toggled for activating/deactivating the vacuum mechanism, a vacuum release control button 74 for selectively detaching the vacuum pad 62 from the load 61 by opening a vent (not visible) from the vacuum region to the surrounding atmospheric pressure, and a pressure gauge 76 for indicating the pressure in the region between the vacuum pad 62 and the load 61 . The vacuum gripper 60 is removably mountable to the bracket 16 described above. To this end, the vacuum gripper 60 comprises four fixing lugs 78 which align with the four through-holes

**[0040]**

32 on the bracket 16. Mechanical fasteners (e.g. bolts or screws) can be secured through the through-holes 32 and lugs 78.

## Classifications

- B25H1/00
- B65G49/061
- B25B11/00
- B25B11/007
- B25H1/00
- B62B3/04
- B62B3/108
- B65G2249/04
- B65G49/063
- B65G7/12

## Cited patent documents

- [EP-4119296-A1](https://patents.google.com/patent/EP4119296A1/en) — ISR
- [US-2013232766-A1](https://patents.google.com/patent/US20130232766A1/en) — ISR
- [US-2021299825-A1](https://patents.google.com/patent/US20210299825A1/en) — ISR
- [US-2022297943-A1](https://patents.google.com/patent/US20220297943A1/en) — ISR
- [US-6101702-A](https://patents.google.com/patent/US6101702A/en) — ISR
- [WO-2021081336-A1](https://patents.google.com/patent/WO2021081336A1/en) — ISR

---

Generated by IPtorch. Verify legal conclusions against the official publication.
