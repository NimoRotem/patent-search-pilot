# 24. Fastening device

- **Archive rank:** 24 of 50
- **Publication:** [WO-2006087063-A8](https://patents.google.com/patent/WO2006087063A8/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/036217006/publication/WO2006087063A8?q=pn%3DWO2006087063A8)
- **Publication date:** 2006-12-07
- **Filing date:** 2006-01-17
- **Earliest priority:** 2005-02-18
- **Family:** 36217006
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** GASSMANN JUERGEN; KAERCHER GMBH & CO KG ALFRED; RUST HENDRIK; STEWEN CHRISTIAN
- **Inventors:** GASSMANN JUERGEN; RUST HENDRIK; STEWEN CHRISTIAN

## Abstract

The invention relates to a fastening device (10) for detachably fastening an article on a base (14). Said device comprises a suction plate (18) on which a sealing ring (13) for resting on the base (14) is held and an electric vacuum pump (26) which impinges a space (36) between the suction plate (18) and the base (14) that can be sealed by the sealing ring (13) with negative pressure. The aim of the invention is to improve the fastening device (10) in such a manner that it can be operated independent of a line voltage and is easier to use. For this purpose, the suction plate (18) is integrated into a housing (42) which houses the vacuum pump (26), a battery (63) and an electrical switching element (64) for switching the vacuum pump on and off. The invention is furthermore characterized in that a collector for bore cuttings (110) is integrated into the housing of the fastening device (10).

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/WO-2006087063-A8/ops000.png)

![Sketch 1 for WO-2006087063-A8](https://nimo.iptorch.com/refdrawing/WO-2006087063-A8/ops000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/WO-2006087063-A8/ops001.png)

![Sketch 2 for WO-2006087063-A8](https://nimo.iptorch.com/refdrawing/WO-2006087063-A8/ops001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/WO-2006087063-A8/ops002.png)

![Sketch 3 for WO-2006087063-A8](https://nimo.iptorch.com/refdrawing/WO-2006087063-A8/ops002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/WO-2006087063-A8/ops003.png)

![Sketch 4 for WO-2006087063-A8](https://nimo.iptorch.com/refdrawing/WO-2006087063-A8/ops003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/WO-2006087063-A8/ops004.png)

![Sketch 5 for WO-2006087063-A8](https://nimo.iptorch.com/refdrawing/WO-2006087063-A8/ops004.png)

## Claims

### Claim 1 (independent)

PATENTANSPRUCHE Befestigungseinrichtung zum lösbaren Befestigen eines Gegenstandes an einem Untergrund, mit einer Saugplatte, an der ein Dichtring gehalten ist zur Anlage am Untergrund, und mit einer elektrischen Vakuumpumpe, mit der ein vom Dichtring abdichtbarer Zwischenraum zwischen der Saugplatte und dem Untergrund mit Unterdruck beaufschlagbar ist, dadurch gekennzeichnet, dass die Saugplatte (18; 48; 102) in ein Gehäuse (12; 42; 77) integriert ist, das die Vakuumpumpe (26; 62; 96), eine Batterie (27; 63; 97) sowie ein elektrisches Schaltorgan (29; 64; 98) zum Einund Ausschalten der Vakuumpumpe (26; 62; 96) aufnimmt.

### Claim 2

Befestigungseinrichtung nach Anspruch 1, dadurch gekennzeichnet, dass die Befestigungseinrichtung (10; 40) ein Verbindungselement (33; 70) zum lösbaren Verbinden eines Gegenstandes mit dem Gehäuse (12; 42) umfasst.

### Claim 3

Befestigungseinrichtung nach Anspruch 2, dadurch gekennzeichnet, dass das Verbindungselement eine Aufnahme (70) umfasst zum formschlüssigen Verbinden des Gehäuses (42) mit dem Gegenstand.

### Claim 4

Befestigungseinrichtung nach Anspruch 3, dadurch gekennzeichnet, dass die Aufnahme als T-förmige oder schwalbenschwanzförmige Nut (70) ausgebildet ist.

### Claim 5

Befestigungseinrichtung nach einem der voranstehenden Ansprüche, dadurch gekennzeichnet, dass die Befestigungseinrichtung ein Belüftungselement (37; 55; 86) aufweist zum Belüften des Zwischenraums (36; 60; 103).

### Claim 6

Befestigungseinrichtung nach Anspruch 5, dadurch gekennzeichnet, dass das Belüftungselement (37; 55; 86) manuell betätigbar ist.

### Claim 7

Befestigungseinrichtung nach Anspruch 5 oder 6, dadurch gekennzeichnet, dass das Belüftungselement ein federelastisch in eine Schliessstellung vorgespanntes Belüftungsventil (37; 55; 86) umfasst.

### Claim 8

Befestigungseinrichtung nach Anspruch 7, dadurch gekennzeichnet, dass das Belüftungsventil (37; 55; 86) mit einem manuell betätigbaren Schaltstössel (38; 69; 95) zusammenwirkt.

### Claim 9

Befestigungseinrichtung nach einem der voranstehenden Ansprüche, dadurch gekennzeichnet, dass das Gehäuse (12; 42; 77) einen Strömungskanal (22; 59; 93) ausbildet, der mit der Vakuumpumpe (26; 62; 96) in Strömungsverbindung steht und in dem vom Dichtring (13; 43; 78) umgebenen Bereich die Saugplatte (18; 48; 102) durchgreift.

### Claim 10

Befestigungseinrichtung nach Anspruch 9, dadurch gekennzeichnet, dass der Strömungskanal (22; 59; 93) über einen flexiblen Saugschlauch (25; 68; 101) mit der Vakuumpumpe (26; 62; 96) verbunden ist.

### Claim 11

Befestigungseinrichtung nach Anspruch 9 oder 10, dadurch gekennzeichnet, dass im Strömungskanal (22; 59; 93) ein Filterelement (23; 61; 94) angeordnet ist.

### Claim 12

Befestigungseinrichtung nach Anspruch 11, dadurch gekennzeichnet, dass das Filterelement (23; 61; 94) den Strömungskanal (22; 59; 93) vollständig ausfüllt.

### Claim 13

Befestigungseinrichtung nach einem der Ansprüche 9 bis 12, dadurch gekennzeichnet, dass der Strömungskanal (22; 59; 93) in einer Zwischenwand (17; 52; 87) des Gehäuses (12; 42; 77) verläuft.

### Claim 14

Befestigungseinrichtung nach Anspruch 13, dadurch gekennzeichnet, dass die Zwischenwand (52; 87) das Gehäuse (42; 77) in zwei Gehäusekammern (53, 54; 91, 92) unterteilt, wobei eine erste Gehäusekammer (53; 91) die Vakuumpumpe (62; 96), die Batterie (63; 97) und das Schaltorgan (64; 98) aufnimmt.

### Claim 15

Befestigungseinrichtung nach Anspruch 14, dadurch gekennzeichnet, dass eine zweite Gehäusekammer (54; 92) einen zu befestigenden Gegenstand aufnimmt.

### Claim 16

Befestigungseinrichtung nach Anspruch 14 oder 15, dadurch gekennzeichnet, dass in die zweite Gehäusekammer (92) eine Bohrschmutzauffangeinrichtung (110) integriert ist und die zweite Gehäusekammer (92) von einem Bohrer (115) durchsetzbar ist zum Einbringen einer Bohrung in den Untergrund (80), wobei die zweite Gehäusekammer (92) einen Bohrschmutzsammelraum (124) definiert und mindestens eine Reinigungseinrichtung (126, 128) aufnimmt zum Abreinigen des Bohrers (115).

### Claim 17

Befestigungseinrichtung nach Anspruch 16, dadurch gekennzeichnet, dass eine erste Reinigungseinrichtung zumindest eine den Bohrer (115) beim Herausziehen aus der zweiten Gehäusekammer (92) abstreifende erste Reinigungsbürste (126) umfasst.

### Claim 18

Befestigungseinrichtung nach Anspruch 17, dadurch gekennzeichnet, dass eine erste Reinigungsbürste (152) ringförmig ausgestaltet und vom Bohrer (115) durchsetzbar ist.

### Claim 19

Befestigungseinrichtung nach Anspruch 17 oder 18, dadurch gekennzeichnet, dass eine erste Reinigungsbürste (126) als Doppelbürste ausgestaltet ist und zwei einander zugewandte Borstenreihen (131, 132) aufweist, die zwischen sich den Bohrer (115) aufnehmen.

### Claim 20

Befestigungseinrichtung nach Anspruch 17, 18 oder 19, dadurch gekennzeichnet, dass die zweite Gehäusekammer (92) zwei fluchtend zueinander ausgerichtete, vom Bohrer (115) durchsetzbare Gehäuseöffnungen (112, 113) aufweist, wobei eine stirnseitige Gehäuseöffnung (112) dem Untergrund (80) zugewandt und eine rückseitige Gehäuseöffnung (113) dem Untergrund (80) abgewandt ist und wobei die erste Reinigungseinrichtung (126) die rückseitige Gehäuseöffnung (113) zumindest teilweise überdeckt.

### Claim 21

Befestigungseinrichtung nach einem der Ansprüche 17 bis 20, dadurch gekennzeichnet, dass die erste Reinigungseinrichtung (126) der stirnseitigen Gehäuseöffnung (112) zugewandt eine Abdeckung (156) aufweist.

### Claim 22

Befestigungseinrichtung nach Anspruch 21, dadurch gekennzeichnet, dass die Abdeckung (156) aus einem flexiblen Material gefertigt ist.

### Claim 23

Befestigungseinrichtung nach Anspruch 21 oder 22, dadurch gekennzeichnet, dass die Abdeckung (156) kegelmantelförmig ausgestaltet ist.

### Claim 24

Befestigungseinrichtung nach einem der Ansprüche 17 bis 23, dadurch gekennzeichnet, dass eine zweite Reinigungseinrichtung zumindest eine den rotierenden Bohrer (115) beim Bohren abstreifende zweite Reinigungsbürste (128) umfasst.

### Claim 25

Befestigungseinrichtung nach Anspruch 24, dadurch gekennzeichnet, dass eine zweite Reinigungsbürste (152) ringförmig ausgestaltet ist und vom Bohrer (115) durchsetzbar ist.

### Claim 26

Befestigungseinrichtung nach Anspruch 24 oder 25, dadurch gekennzeichnet, dass eine zweite Reinigungsbürste (128) zumindest eine Borstenreihe (141, 142) aufweist, die parallel oder in einem spitzen Winkel zur Bohrerlängsachse (147) ausgerichtet ist.

### Claim 27

Befestigungseinrichtung nach Anspruch 24, 25 oder 26, dadurch gekennzeichnet, dass eine zweite Reinigungsbürste (128) als Doppelbürste aus gestaltet ist und zwei einander zugewandte Borstenreihen (141, 142) aufweist, die zwischen sich den Bohrer (115) aufnehmen.

### Claim 28

Befestigungseinrichtung nach einem der Ansprüche 20 bis 27, dadurch gekennzeichnet, dass die stirnseitige Gehäuseöffnung (112) von einer Schmutzführungshülse (118) durchgriffen ist.

### Claim 29

Befestigungseinrichtung nach Anspruch 28, dadurch gekennzeichnet, dass die Schmutzführungshülse (118) aussenseitig über die zweite Gehäusekammer (92) hervorsteht.

### Claim 30

Befestigungseinrichtung nach Anspruch 29, dadurch gekennzeichnet, dass die Schmutzführungshülse (118) in ihrem nach aussen vorstehenden Bereich von einem Dichtring (119) umgeben ist.

### Claim 31

Befestigungseinrichtung nach Anspruch 30, dadurch gekennzeichnet, dass der Dichtring (119) aus einem elastisch verformbaren Material gefertigt ist.

### Claim 32

Befestigungseinrichtung nach einem der Ansprüche 28 bis 31, dadurch gekennzeichnet, dass die Schmutzführungshülse (118) in die zweite Gehäusekammer (92) hineinragt.

### Claim 33

Befestigungseinrichtung nach Anspruch 28 bis 32, dadurch gekennzeichnet, dass die Schmutzführungshülse (118) sich in das Innere der zweiten Gehäusekammer (92) konisch erweitert.

### Claim 34

Befestigungseinrichtung nach einem der Ansprüche 28 bis 33, dadurch gekennzeichnet, dass die Schmutzführungshülse (118) aus Metall gefertigt ist.

### Claim 35

Befestigungseinrichtung nach einem der Ansprüche 28 bis 34, dadurch gekennzeichnet, dass die Schmutzführungshülse (118) an der zweiten Gehäusekammer (92) auswechselbar gehalten ist.

### Claim 36

Befestigungseinrichtung nach einem der Ansprüche 20 bis 35, dadurch gekennzeichnet, dass die rückseitige Gehäuseöffnung (113) von einer Führungsbuchse (121) durchgriffen ist.

### Claim 37

Befestigungseinrichtung nach Anspruch 36, dadurch gekennzeichnet, dass die Führungsbuchse (121) an der rückseitigen Gehäuseöffnung (113) auswechselbar gehalten ist.

### Claim 38

Befestigungseinrichtung nach Anspruch 36 oder 37, dadurch gekennzeichnet, dass die Führungsbuchse (121) aus Metall gefertigt ist.

### Claim 39

Befestigungseinrichtung nach Anspruch 36, 37 oder 38, dadurch gekennzeichnet, dass die Führungsbuchse (121) nach aussen aus der zweiten Gehäusekammer (92) herausragt.

### Claim 40

Befestigungseinrichtung nach einem der Ansprüche 36 bis 39, dadurch gekennzeichnet, dass die Führungsbuchse (121) nach innen in die zweite Gehäusekammer (92) hineinragt.

## Full description

**[p0001]**

Befestigungseinrichtung Die Erfindung betrifft eine Befestigungseinrichtung zum lösbaren Befestigen eines Gegenstandes an einem Untergrund, insbesondere einer Wand oder einer Decke, mit einer Saugplatte, an der ein Dichtring gehalten ist zur Anlage an dem Untergrund, und mit einer elektrischen Vakuumpumpe, mit der ein vom Dichtring abdichtbarer Zwischenraum zwischen der Saugplatte und dem Untergrund mit Unterdruck beaufschlagbar ist. Mittels einer derartigen Befestigungseinrichtung kann ein Gegenstand, beispielsweise ein Messgerät, eine Markierungseinrichtung oder auch ein Schmutzauffanggerät, zeitweilig an einem Untergrund befestigt werden, insbesondere an einer Wand oder einer Decke. Hierzu kann die Saugplatte unter Zwischenlage des Dichtringes an den Untergrund angelegt werden, und anschliessend kann mittels der Vakuumpumpe der Zwischenraum zwischen der Saugplatte und dem Untergrund abgesaugt werden und somit mit Unterdruck beaufschlagt werden. Dies hat zur Folge, dass die Saugplatte pneumatisch am Untergrund anhaftet.

**[p0002]**

Aus der WO 03/072964 Al ist eine Befestigungseinrichtung bekannt, bei der von der Saugplatte auf deren dem Dichtring abgewandter Rückseite die elektrische Vakuumpumpe absteht und in die Saugplatte eine Ausnehmung eingeformt ist, die eine eisenhaltige Stützplatte aufnimmt. Dies gibt die Möglichkeit, an der Stützplatte mit Hilfe eines Magneten insbesondere eine Messeinrichtung festzulegen. Zusätzlich zur Vakuumpumpe nimmt die Saugplatte auch ein Manometer auf, mit dessen Hilfe der Unterdruck zwischen der Saugplatte und dem Untergrund gemessen werden kann. Mit Hilfe von Stützstiften, die von der Saugplatte in Richtung Untergrund abstehen, kann ein definierter Abstand zwischen der Saugplatte und dem Untergrund eingehalten werden. Die bekannte Befestigungseinrichtung ist unhandlich und schwer und erfordert die Bereitstellung einer Netzspannung, an die die elektrische Vakuumpumpe mittels eines Anschlusskabels angeschlossen werden kann. Aufgabe der vorliegenden Erfindung ist es, eine Befestigungseinrichtung der eingangs genannten Art derart weiterzubilden, dass sie unabhängig von einer Netzspannung betrieben werden kann und einfacher zu handhaben ist.

**[p0003]**

Diese Aufgabe wird bei einer Befestigungseinrichtung der gattungsgemässen Art erfindungsgemäss dadurch gelöst, dass die Saugplatte in ein Gehäuse integriert ist, das die Vakuumpumpe, eine Batterie sowie ein elektrisches Schaltorgan zum Einund Ausschalten der Vakuumpumpe aufnimmt. Die erfindungsgemässe Befestigungseinrichtung bildet ein autarkes Gerät aus, mit dem ein Gegenstand zeitweilig an einem Untergrund, insbesondere einer Wand oder einer Decke, befestigt werden kann, ohne dass eine Netzspannung und ein Anschlusskabel bereitgestellt werden müssen. Dies ermöglicht es insbesondere, die Befestigungseinrichtung in Räumen ohne Netzanschluss zu betreiben, beispielsweise in einem Rohbau. Ausserdem zeichnet sich die erfindungsgemässe Befestigungseinrichtung durch eine einfache Handhabung aus, denn sämtliche Bauteile der Befestigungseinrichtung sind in das Gehäuse integriert, das beispielsweise quaderförmig oder zylinderförmig ausgestaltet sein kann und vom Benutzer auf einfache Weise ergriffen werden kann. Durch Betätigung des elektrischen Schaltorganes kann die im Gehäuse angeordnete Vakuumpumpe in Gang gesetzt werden, deren elektrische Energie von der ebenfalls im Gehäuse angeordneten, vorzugsweise wiederaufladbaren Batterie bereitgestellt wird. Mittels der Vakuumpumpe kann bei am Untergrund angelegtem Gehäuse der Zwischenraum zwischen der Saugplatte des Gehäuses und dem Untergrund abgesaugt werden, so dass das Gehäuse pneumatisch am Untergrund anhaftet. Das Anhaften erfolgt solange wie die Vakuumpumpe in Betrieb ist. Wird sie mittels des elektrischen Schaltorganes ausgescha

**[p0003]**

ltet, so kann aufgrund von Leckagen eine Belüftung des Zwischenraumes erfolgen, so dass das Gehäuse auf einfache Weise vom Benutzer wieder vom Untergrund gelöst werden kann.

**[p0004]**

Die erfindungsgemässe Befestigungseinrichtung ist kostengünstig herstellbar. Hierzu ist es von Vorteil, wenn die Vakuumpumpe in Form einer Membranpumpe ausgestaltet ist. Bei einer vorteilhaften Ausführungsform umfasst die Befestigungseinrichtung ein Verbindungselement zum lösbaren Verbinden eines Gegenstandes mit dem Gehäuse. So kann beispielsweise in das Gehäuse eine Durchgangsöffnung eingeformt sein, in die ein Halteorgan des Gegenstandes, insbesondere ein Haltebügel, eingesetzt werden kann. Alternativ oder ergänzend kann vorgesehen sein, dass das Verbindungselement eine Aufnahme umfasst zum formschlüssigen Verbinden des Gehäuses mit dem Gegenstand. Die Aufnahme kann beispielsweise als T-förmige oder schwalbenschwanzförmige Nut ausgebildet sein, in die eine korrespondierend ausgebildete Leiste des Gegenstandes eingeführt werden kann. Dies ermöglicht eine lösbare Verbindung des Gehäuses mit dem Gegenstand und hat den Vorteil, dass unter-schiedliche Gegenstände mit dem Gehäuse der Befestigungseinrichtung verbunden werden kann. So kann beispielsweise vorgesehen sein, dass das Gehäuse mit einer Positionsbestimmungseinrichtung, einer Messeinrichtung, beispielsweise einem aufrollbaren Massband, und/oder mit einer Markierungseinrichtung, beispielsweise einer Lasermarkierungseinrichtung, verbunden werden kann. Dies gibt zum Beispiel die Möglichkeit, eine bestimmte Position eines Bohrloches, das in den Untergrund eingebracht werden soll, auszumessen und zu markieren. Vorzugsweise ist das Gehäuse auch mit einer Bohrschmutzauffangeinrichtung verbindbar, die von einem Bohrer zum Einb

**[p0004]**

ringen einer Bohrung in den Untergrund durchgriffen werden kann und der Aufnahme des beim Bohren anfallenden Bohrschmutzes dient.

**[p0005]**

Als mit dem Gehäuse lösbar verbindbarer Gegenstand kann auch eine Libelle zum Einsatz kommen zum horizontalen und/oder vertikalen Ausrichten der Befestigungseinrichtung an einer Wand oder einer Decke. Alternativ oder ergänzend kann als Verbindungselement auch ein Klebekissen zum Einsatz kommen, das am Gehäuse gehalten ist und vorzugsweise von einer abziehbaren Schutzfolie bedeckt ist. Mittels des Klebekissens kann ein temporär am Untergrund zu befestigender Gegenstand mit dem Gehäuse der Befestigungseinrichtung lösbar verklebt werden. Der an der Saugplatte gehaltene Dichtring ist bevorzugt aus einem elastisch verformbaren Material gefertigt. Günstig ist es, wenn er an leicht gekrümmte Oberflächen des Untergrundes anpassbar und spaltfüllend ist, so dass der vom Dichtring umgebene Bereich der Saugplatte luftdicht abgedichtet werden kann, wenn die Saugplatte unter Zwischenschaltung des Dichtringes an den Untergrund angelegt wird. Wie bereits erläutert, lässt sich die Befestigungseinrichtung pneumatisch an einem Untergrund festlegen, indem der vom Dichtring abgedichtete Zwischenraum zwischen der Saugplatte und dem Untergrund mittels der Vakuumpumpe abgesaugt wird. Zum Abnehmen der Befestigungseinrichtung vom Untergrund ist es in vielen Fällen ausreichend, die Vakuumpumpe auszuschalten, da dann aufgrund von Leckagen der Zwischenraum belüftet wird. Bei einer Befestigung an einem glatten Untergrund ist es allerdings von Vorteil, wenn die Befestigungseinrichtung ein Belüftungselement aufweist zum Belüften des Zwischenraumes. Der glatte Untergrund kann zur Folge haben, dass der Zwis

**[p0005]**

chenraum beim Ausschalten der Vakuumpumpe nur langsam aufgrund von Leckagen belüftet wird. Mit Hilfe des Belüftungselementes kann jedoch der Zwischenraum innerhalb sehr kurzer Zeit belüftet werden, so dass der Unterdruck im Zwischenraum entfällt und folglich die Befestigungseinrichtung auf einfache Weise vom Untergrund entfernt werden kann.

**[p0006]**

Das Belüftungselement kann elektrisch betätigbar sein. Insbesondere kann vorgesehen sein, dass das Belüftungselement mit der Vakuumpumpe gekoppelt ist dergestalt, dass das Belüftungselement den Zwischenraum belüftet, wenn die Vakuumpumpe abgeschaltet wird. Bei einer konstruktiv besonders einfachen und kostengünstig herstellbaren Ausführungsform ist das Belüftungselement manuell betätigbar. Es kann somit vom Benutzer zum Belüften des Zwischenraumes betätigt werden. Es kann beispielsweise vorgesehen sein, dass das Belüftungselement ein federelastisch in eine Schliessstellung vorgespanntes Belüftungsventil umfasst. Mittels des Belüftungsventiles kann eine Strömungsverbindung zwischen dem Zwischenraum und der Umgebung der Befestigungseinrichtung gesteuert werden. Im unbetätigten Zustand nimmt das Belüftungsventil aufgrund seiner Federbelastung eine Schliessstellung ein, so dass die Strömungsverbindung zwischen dem Zwischenraum und der Umgebung unterbrochen ist. Zur Belüftung des Zwischenraumes wird der Schaltzustand des Belüftungsventiles geändert, so dass dieses in seine Offenstellung übergeht und dadurch der Zwischenraum belüftet werden kann.

**[p0007]**

Bei einer vorteilhaften Ausführungsform wirkt das Belüftungsventil mit einem manuell betätigbaren Schaltstössel zusammen. Durch Betätigung des Schaltstössels kann die Schaltstellung des Belüftungsventiles geändert werden, insbesondere kann das Belüftungsventil entgegen der Einwirkung einer Federkraft in seine Offenstellung überführt werden. Günstig ist es, wenn der Schaltstössel eine dem Untergrund abgewandte Rückwand des Gehäuses durchgreift und nach aussen über die Rückwand vorsteht. Das Belüftungselement kann ebenso wie die Vakuumpumpe, die Batterie und das elektrische Schaltorgan innerhalb des Gehäuses angeordnet sein. Bei einer bevorzugten Ausführungsform bildet das Gehäuse der Befestigungseinrichtung einen Strömungskanal aus, der mit der Vakuumpumpe in Strömungsverbindung steht und in dem vom Dichtring umgebenen Bereich die Saugplatte durchgreift. Der Strömungskanal bildet zumindest einen Teil einer Saugleitung aus, über die der abzusaugende Zwischenraum mit der Vakuumpumpe in Strömungsverbindung steht.

**[p0008]**

Es kann vorgesehen sein, dass der Strömungskanal über einen innerhalb des Gehäuses angeordneten flexiblen Saugschlauch mit der Vakuumpumpe verbunden ist. Die flexible Verbindung der Vakuumpumpe über den Saugschlauch mit dem starren Strömungskanal erleichtert das Einsetzen der Vakuumpumpe bei der Montage der Befestigungseinrichtung. Von besonderem Vorteil ist es, wenn im Strömungskanal ein Filterelement angeordnet ist, vorzugsweise ist das Filterelement in den Strömungskanal einschiebbar. Mittels des Filterelementes kann vermieden werden, dass die Vakuumpumpe mit Schmutzpartikel in Kontakt kommt. Dadurch kann die Lebensdauer der Vakuumpumpe verlängert werden. Günstig ist es, wenn das Filterelement den Strömungskanal vollständig ausfüllt. Vorzugsweise weist das Filterelement ein Papierfilter auf, das in den Strömungskanal einsetzbar ist. Bei einer vorteilhaften Ausführungsform verläuft der Strömungskanal in einer Zwischenwand des Gehäuses. Durch die Zwischenwand kann die mechanische Belastbarkeit des Gehäuses erhöht werden und gleichzeitig kann mit ihrer Hilfe ein Strömungskanal bereitgestellt werden. Dies ermöglicht es, die Befestigungseinrichtung besonders kostengünstig herzustellen und zu montieren.

**[p0009]**

Die Zwischenwand unterteilt bei einer vorteilhaften Ausführungsform das Gehäuse in zwei Gehäusekammern, wobei eine erste Gehäusekammer die Vaku- umpumpe, die Batterie und das Schaltorgan aufnimmt. Sämtliche elektrischen Bauteile der Befestigungseinrichtung sind somit in der ersten Gehäusekammer angeordnet und dadurch vor Umwelteinflüssen geschützt. Bei Einsatz eines Belüftungselementes kann dieses ebenfalls in der ersten Gehäusekammer angeordnet sein. Vorzugsweise ist die erste Gehäusekammer dem Benutzer nach Entfernen eines Deckels zugänglich zum Austausch der Batterie, die bei einer besonders bevorzugten Ausführungsform wiederaufladbar ausgestaltet ist. Es kann vorgesehen sein, dass eine zweite Gehäusekammer einen zu befestigenden Gegenstand aufnimmt. So kann beispielsweise vorgesehen sein, dass die zweite Gehäusekammer eine Aufnahme bildet, in die der temporär zu befestigende Gegenstand eingesetzt werden kann. Wie bereits erläutert, kann mittels der Befestigungseinrichtung beispielsweise eine Bohrschmutzauffangeinrichtung temporär an einem Untergrund, insbesondere einer Wand oder einer Decke, befestigt werden. Mittels der Bohrschmutzauffangeinrichtung kann während des Einbringens einer Bohrung in den Untergrund anfallender Bohrschmutz, also Bohrmaterial und Bohrstaub, aufgefangen werden. Hierzu ist bei einer besonders bevorzugten Ausführungsform der erfindungsgemässen Befestigungseinrichtung vorgesehen, dass in die zweite Gehäusekammer eine Bohrschmutzauffangeinrichtung integriert ist und die zweite Gehäusekammer von einem Bohrer durchsetzbar ist zum Einbringen einer Boh

**[p0009]**

rung in den Untergrund, wobei die zweite Gehäusekammer einen Bohrschmutzsammelraum definiert und mindestens eine Reinigungseinrichtung aufnimmt zum Abreinigen des Bohrers. Zum Einbringen einer Bohrung in den Untergrund kann das Gehäuse an den Untergrund angelegt und durch Einschalten der Vakuumpumpe an diesem pneumatisch festgelegt werden, wie dies voranstehend bereits erläutert wurde. Es kann dann ein drehfest an einer Bohrmaschine gehaltener Bohrer durch die zweite Gehäusekammer hindurchgeführt werden zum Einbringen einer Bohrung in den Untergrund. Anfallender Bohrschmutz wird vom Bohrer nach Art eines Schneckenförderers in den Innenraum der zweiten Gehäusekammer überführt und sammelt sich im Bohrschmutzsammelraum an. Zum Abreinigen des Bohrers während des Einbringens der Bohrung und/oder beim Herausziehen des Bohrers aus der zweiten Gehäusekammer nimmt diese zumindest eine Reinigungseinrichtung auf. Dadurch ist sichergestellt, dass der Bohrschmutz innerhalb des Bohrschmutzsammelraumes verbleibt und nicht in den Aussenbereich des Gehäuses gelangt.

**[p0010]**

So kann beispielsweise vorgesehen sein, dass eine erste Reinigungseinrichtung zumindest eine den Bohrer beim Herausziehen aus der zweiten Gehäusekammer abstreifende erste Reinigungsbürste umfasst. Mittels der ersten Reinigungsbürste kann der Bohrer nach dem Einbringen einer Bohrung in den Untergrund abgestreift werden, während er aus der zweiten Gehäusekammer herausgezogen wird. Alternativ oder ergänzend zu der mindestens einen ersten Reinigungsbürste können flexible Reinigungselemente zum Einsatz kommen, beispielsweise Gummistreifen, die den Bohrer beim Herausziehen aus der zweiten Gehäusekammer abstreifen und somit von anhaftendem Bohrschmutz befreien. Bevorzugt ist eine erste Reinigungsbürste ringförmig ausgestaltet und vom Bohrer durchsetzbar. Damit ist auf konstruktiv einfache Weise sichergestellt, dass der am Bohrer entlang seines Umfanges anhaftende Bohrschmutz entfernt werden kann. Es kann auch vorgesehen sein, dass eine erste Reinigungsbürste als Doppelbürste ausgestaltet ist und zwei einander zugewandte Borstenreihen aufweist, die zwischen sich den Bohrer aufnehmen. Die Borstenreihen sind kostengünstig herstellbar, und durch den Einsatz zweier einander zugewandter Borstenreihen kann der Bohrer in Umfangsrichtung praktisch vollständig abgereinigt werden.

**[p0011]**

Bei einer vorteilhaften Ausführungsform weist die zweite Gehäusekammer zwei fluchtend zueinander angeordnete, vom Bohrer durchsetzbare Gehäuseöffnungen auf, wobei eine stirnseitige Gehäuseöffnung dem Untergrund zugewandt und eine rückseitige Gehäuseöffnung dem Untergrund abgewandt ist und wobei die erste Reinigungseinrichtung die rückseitige Gehäuseöffnung zumindest teilweise überdeckt. Dadurch ist sichergestellt, dass auch beim Einbringen einer Bohrung in eine Decke kein Bohrschmutz durch die zweite Gehäusekammer hindurch fallen kann, vielmehr wird sämtlicher Bohrschmutz innerhalb der zweiten Gehäusekammer von der ersten Reinigungseinrichtung zurückgehalten, die die rückseitige Gehäuseöffnung zumindest teilweise überdeckt und diese zusammen mit dem die zweite Gehäusekammer durchgreifenden Bohrer verschiesst. Günstig ist es, wenn die erste Reinigungseinrichtung der stirnseitigen Gehäuseöffnung zugewandt eine Abdeckung aufweist. Dadurch wird die Gefahr besonders gering gehalten, dass beim Einbringen einer Bohrung in eine Decke Bohrschmutz durch das Gehäuse hindurchfällt.

**[p0012]**

Vorzugsweise ist die Abdeckung an den Aussenumfang des Bohrers anlegbar. Es kann vorgesehen sein, dass die Abdeckung aus einem flexiblen Material, beispielsweise einem gummiartigen Material, gefertigt ist. Insbesondere kann die Abdeckung in Form einer Membran ausgebildet sein. Die Abdeckung überdeckt bei einer bevorzugten Ausführungsform der Erfindung die rückseitige Gehäuseöffnung. Als vorteilhaft hat es sich erwiesen, die Abdeckung kegelmantelförmig auszugestalten, denn dadurch kann auf konstruktiv einfache Weise Bohrschmutz in radialer Richtung vom Bohrer entfernt werden, der die Abdeckung zentral durchgreift. Bei einer besonders bevorzugten Ausführungsform umfasst eine zweite Reinigungseinrichtung zumindest eine den rotierenden Bohrer beim Bohren abstreifende zweite Reinigungsbürste. Es gibt die Möglichkeit, während des Einbringens einer Bohrung in den Untergrund am Bohrer anhaftender Bohrschmutz von diesem zu entfernen und in den Bohrschmutzsammelraum zu überführen. Wie bereits erläutert, bildet der rotierende Bohrer einen Schnekkenförderer aus, der den anfallenden Bohrschmutz aus dem Bohrloch heraus transportiert und in das Innere der zweiten Gehäusekammer überführt. In der zweiten Gehäusekammer wird der rotierende Bohrer von der mindestens einen zweiten Reinigungsbürste abgestreift und somit von Bohrschmutz befreit.

**[p0013]**

Der kombinierte Einsatz einer ersten Reinigungsb[upsilon]rste, die den Bohrer beim Herausziehen aus der zweiten Gehäusekammer abstreift, und einer zweiten Reinigungsbürste, die den rotierenden Bohrer beim Einbringen einer Bohrung in den Untergrund abstreift, hat sich als besonders vorteilhaft erwiesen, um praktisch sämtlichen anfallenden Bohrschmutz aufzufangen und sicherzustellen, dass auch beim Herausziehen des Bohrers aus der zweiten Gehäusekammer kein Bohrschmutz entweichen kann. Von Vorteil ist es, wenn die zweite Reinigungsbürste zwischen der ersten Reinigungsbürste und der stirnseitigen Gehäuseöffnung angeordnet ist. Bei einer derartigen Anordnung wird der rotierende Bohrer während des Bohrens zunächst von der zweiten Reinigungsbürste abgebürstet, insbesondere wird die mindestens eine wendeiförmige Bohrnut des Bohrers von Bohrschmutz befreit. Bohrschmutzreste, die von der zweiten Reinigungsbürste nicht erfasst werden, werden in der Bohrnut vom rotierenden Bohrer zur ersten Reinigungsbürste überführt und von dieser abgebürstet. Die Reinigungswirkung der ersten Reinigungsbürste entfaltet sich somit nicht erst beim Herausziehen des Bohrers aus der zweiten Gehäusekammer sondern auch während des Bohrens. Dadurch wird eine optimale Abreinigung des Bohrers erzielt.

**[p0014]**

Es kann vorgesehen sein, dass die zweite Reinigungsbürste ringförmig ausgestaltet und vom Bohrer durchsetzbar ist. Mittels der zweiten Reinigungsbürste wird der rotierende Bohrer bei einer derartigen Ausgestaltung in Umfangsrichtung von allen Seiten gleichzeitig abgebürstet. Insbesondere lässt sich dadurch auf konstruktiv einfache Weise mindestens eine Bohrnut, in der der Bohrschmutz aus dem Bohrloch herausgeführt wird, zuverlässig abreinigen. Bei einer besonders vorteilhaften Ausführungsform weist eine zweite Reinigungsbürste zumindest eine Borstenreihe auf, die parallel oder in einem spitzen Winkel zur Bohrerlängsachse ausgerichtet ist. Der in der Bohrnut des Bohrers aus dem Bohrloch herausgeführte Bohrschmutz wird bei einer derartigen Ausgestaltung innerhalb der zweiten Gehäusekammer seitlich der zweiten Reinigungsbürste zugeführt und kann von dieser zuverlässig abgebürstet werden. Bevorzugt ist eine zweite Reinigungsbürste als Doppelbürste ausgebildet und weist zwei einander zugewandte Borstenreihen auf, die zwischen sich den Bohrer aufnehmen. Hierbei ist es von besonderem Vorteil, wenn die beiden Borstenreihen parallel oder in einem spitzen Winkel zur Bohrerlängsachse ausgerichtet sind. Eine derartige Ausrichtung ist allerdings nicht zwingend erforderlich, es kann auch vorgesehen sein, dass die beiden Borstenreihen eine Ausrichtung senkrecht zur Bohrerlängsachse aufweisen.

**[p0015]**

Um zu vermeiden, dass sich während des Bohrens zwischen dem Untergrund und der Aussenwand der zweiten Gehäusekammer Bohrschmutz ansammeln kann, ist bei einer besonders vorteilhaften Ausführungsform vorgesehen, dass die stirnseitige Gehäuseöffnung von einer Schmutzführungshülse durchgriffen ist. Mittels der Schmutzführungshülse wird im Bereich der stirnseitigen Gehäuseöffnung Bohrschmutz zuverlässig in den Bohrschmutzsammelraum der zweiten Gehäusekammer überführt. Von besonderem Vorteil ist es, wenn die Schmutzführungshülse aussenseitig über die zweite Gehäusekammer hervorsteht. Dies hat den Vorteil, dass die Schmutzführungshülse unmittelbar an den Untergrund angelegt werden kann. Günstig ist es, wenn die Schmutzführungshülse in ihrem nach aussen vorstehenden Bereich von einem Dichtring umgeben ist. Letzterer ist vorzugsweise aus einem elastisch verformbaren Material gefertigt. Insbesondere kann er derart ausgestaltet sein, dass er an leicht gekrümmte Oberflächen des Untergrundes anpassbar und spaltfüllend ist, so dass der Bereich zwischen dem Bohrloch und der stirnseitigen Gehäuseöffnung der zweiten Gehäusekammer auch auf einem rauhen Untergrund zuverlässig staubdicht abgedichtet ist.

**[p0016]**

Um zu vermeiden, dass beim Abnehmen der zweiten Gehäusekammer vom Untergrund über die stirnseitige Gehäuseöffnung Bohrschmutz entweichen kann, ist es von Vorteil, wenn die Schmutzführungshülse in die zweite Gehäusekammer hineinragt. Sie bildet dadurch einen von der stirnseitigen Gehäuseöffnung nach innen vorstehenden Kragen, der innerhalb der zweiten Gehäusekammer angesammelten Bohrschmutz in der zweiten Gehäusekammer zurückhält. Von Vorteil ist es, wenn sich die Schmutzführungshülse in das Innere der zweiten Gehäusekammer konisch erweitert. Dadurch ist sichergestellt, dass der sich auf der Schmutzführungshülse ablagernde Bohrschmutz selbsttätig an der Schmutzführungshülse entlang gleitet und somit in den Innenraum der zweiten Gehäusekammer überführt wird. Die Schmutzführungshülse ist bei einer vorteilhaften Ausführungsform aus Metall gefertigt, insbesondere aus gehärtetem Metall. Günstig ist es, wenn die Schmutzführungshülse an der zweiten Gehäusekammer auswechselbar gehalten ist, denn dies gibt die Möglichkeit, die Schmutzführungshülse auf einfache Weise auszuwechseln.

**[p0017]**

Bei einer vorteilhaften Ausführungsform ist die rückseitige Gehäuseöffnung von einer Führungsbuchse durchgriffen. Mittels der Führungsbuchse wird das Einführen des Bohrers in die zweite Gehäusekammer und auch dessen Ausrichtung beim Bohren vereinfacht. Von Vorteil ist es hierbei, wenn die Führungsbuchse an der rückseitigen Gehäuseöffnung auswechselbare gehalten ist, denn dies gibt die Möglichkeit, in Abhängigkeit vom Durchmesser des zum Einsatz kommenden Bohrers eine entsprechend angepasste Führungsbuchse an der rückseitigen Gehäuseöffnung festzulegen. Die Führungsbuchse ist günstigerweise aus Metall gefertigt, insbesondere aus gehärtetem Metall. Es kann vorgesehen sein, dass der lichte Durchmesser der Führungsbuchse dem lichten Durchmesser der Schmutzführungshülse entspricht. Dadurch wird das Ausrichten des Bohrers bei Einbringen einer Bohrung in den Untergrund vereinfacht. Von Vorteil ist es, wenn die Führungsbuchse nach aussen aus der zweiten Gehäusekammer herausragt. Sie kann in diesem herausragenden Bereich einen Bund ausbilden, mit dem sie aussenseitig an die zweite Gehäusekammer anlegbar ist.

**[p0018]**

Vorzugsweise ragt die Führungsbuchse nach innen in die zweite Gehäusekammer hinein. Sie kann im Innern der Gehäusekammer einen von der rückseitigen Gehäuseöffnung abstehenden Kragen ausbilden, der die Gefahr vermindert, dass beim Abnehmen der zweiten Gehäusekammer vom Untergrund Bohrschmutz aus der zweiten Gehäusekammer über die rückseitige Gehäuseöffnung entweichen kann. Zum Abreinigen des Bohrers kann ergänzend oder alternativ zu der ersten oder zweiten Reinigungsbürste auch eine Turbine zum Einsatz kommen. Die Turbine kann in der ersten oder der zweiten Gehäusekammer angeordnet sein und während des Einbringens einer Bohrung den Bohrer innerhalb des Gehäuses absaugen oder abblasen. Die nachfolgende Beschreibung vorteilhafter Ausführungsformen der Erfindung dient im Zusammenhang mit der Zeichnung der näheren Erläuterung. Es zeigen: Figur 1 : eine schematische Schnittansicht einer ersten Ausführungsform einer Befestigungseinrichtung; Figur 2: eine schematische Schnittansicht einer zweiten Ausführungsform einer Befestigungseinrichtung;

**[p0019]**

Figur 3: eine schematische Schnittansicht einer dritten Ausführungsform einer Befestigungseinrichtung mit integrierter Bohrschmutzauffangeinrichtung; Figur 4: eine Schnittansicht einer zweiten Reinigungsbürste der Bohrschmutzauffangeinrichtung entlang der Linie 4-4 in Figur 3; Figur 5: eine Ansicht der zweiten Reinigungsbürste in Richtung von Pfeil A aus Figur 4; Figur 6: eine Schnittansicht einer ersten Reinigungsbürste der Bohrschmutzauffangeinrichtung längs der Linie 6-6 in Figur 3 und Figur 7: eine Schnittansicht einer alternativen Ausgestaltung einer ersten und/oder zweiten Reinigungsbürste der Bohrschmutzauffangeinrichtung aus Figur 3. In Figur 1 ist schematisch eine erste Ausführungsform einer erfindungsgemässen Befestigungseinrichtung dargestellt, die insgesamt mit dem Bezugszeichen 10 belegt ist. Sie umfasst ein Gehäuse 12, das unter Zwischenlage eines Dichtringes 13 an einen Untergrund 14, beispielsweise eine Gebäudewand oder eine Gebäudedecke, anlegbar ist. Das Gehäuse 12 weist eine Bodenwand 16 auf und eine Deckenwand 17, die über eine Stirnwand 18 und eine Rückwand 19 einstückig miteinander verbunden sind. Die Stirnwand 18 bildet eine Saugplatte aus, an deren Aussenseite 20 der Dichtring 13 auswechselbar gehalten ist.

**[p0020]**

In die Deckenwand 17 ist ein Strömungskanal 22 eingeformt, der die Stirnwand 18 durchgreift und vollständig von einem Filterelement 23 ausgefüllt ist. Über einen flexiblen Saugschlauch 25 steht der Strömungskanal 22 mit einer elektrischen Membranpumpe 26 in Strömungsverbindung, die innerhalb des Gehäuses 12 angeordnet ist und die mit einer elektrischen Batterie 27 verbunden ist und über ein Verbindungskabel 28 mit einem im Gehäuse 12 angeordneten elektromechanischen Schaltorgan 29 in elektrischer Verbindung steht, das ein die Rückwand 19 durchgreifendes Betätigungselement 30 aufweist. In die Stirnwand 18 ist eine Belüftungsöffnung 35 eingeformt, an der innenseitig ein Belüftungselement in Form eines Belüftungsventils 37 gehalten ist, das mittels eines Schaltstössels 38, der die Rückwand 19 durchgreift und innerhalb des Gehäuses 12 in einer Führungshülse 39 geführt ist, betätigt werden kann. Das Belüftungsventil 37 umfasst eine Schliessfeder 41, die das Belüftungsventil 37 selbsttätig in seine Schliessstellung vorspannt. Durch Drücken des Schaltstössels 38 kann der Benutzer das Belüftungsventil 37 entgegen der Wirkung der Schliessfeder 41 in eine Offenstellung überführen, in der es eine Strömungsverbindung freigibt zwischen der Belüftungsöffnung 35 und einer in die Bodenwand 16 eingeformten Durchgangsöffnung 45.

**[p0021]**

Oberseitig bildet das Gehäuse 12 eine wannenförmige Aufnahme 32 aus, in die ein Klebekissen 33 eingesetzt ist, das von einer abziehbaren Schutzfolie 34 überdeckt ist. Soll ein Gegenstand, beispielsweise eine Messeinrichtung, eine Markierungseinrichtung oder ein sonstiges Objekt zeitweilig am Untergrund 14 befestigt werden, so kann hierzu das Gehäuse 12 an den Untergrund 14 angelegt werden, und durch Betätigen des Schaltorganes 29 kann die Membranpumpe 26 in Gang gesetzt werden, so dass ein vom Dichtring 13 luftdicht abgedichteter Zwischenraum 36 zwischen der Stirnwand 18 und dem Untergrund 14 abgesaugt und somit mit Unterdruck beaufschlagt wird. Aufgrund des sich ausbildenden Unterdruckes haftet die Befestigungseinrichtung 10 am Untergrund 14, ohne dass dieser beschädigt wird. Ein temporär zu befestigender Gegenstand kann nun durch Ablösen der Schutzfolie 34 mit dem Klebekissen 33 verbunden werden, so dass er über das Klebekissen 33 am Gehäuse 12 zuverlässig gehalten ist. Soll die Befestigungseinrichtung 10 wieder vom Untergrund 14 entfernt werden, so wird hierzu die Membranpumpe 26 abgeschaltet und kurzzeitig der Schaltstössel 38 betätigt, so dass der Zwischenraum 36 über die Belüftungsöffnung 35, den Innenraum des Gehäuses 12 und die Durchgangsöffnung 45 belüftet wird. Die Befestigungseinrichtung 10 kann dann vom Benutzer wieder vom Untergrund 14 entfernt werden.

**[p0022]**

In Figur 2 ist eine zweite Ausführungsform einer erfindungsgemässen Befestigungseinrichtung dargestellt und insgesamt mit dem Bezugszeichen 40 belegt. Sie ist weitgehend identisch ausgebildet wie die voranstehend erläuterte Befestigungseinrichtung 10 und umfasst ein Gehäuse 42, das unter Zwischenlage eines auswechselbaren Dichtringes 43 an einen Untergrund 44 angelegt werden kann. Das Gehäuse 42 weist eine Bodenwand 46 und eine Deckenwand 47 auf, die über eine Stirnwand 48 und eine Rückwand 49 einstückig miteinander verbunden sind. Die Stirnwand 48 bildet eine Saugplatte aus, an deren dem Untergrund 14 zugewandter Aussenseite 50 der Dichtring 43 gehalten ist, Das Gehäuse 42 weist ausserdem eine Zwischenwand 52 auf, die doppelwandig ausgebildet ist und das Gehäuse 42 in eine erste Gehäusekammer 53 und eine zweite Gehäusekammer 54 unterteilt. Die Zwischenwand 52 weist eine erste , der ersten Gehäusekammer 53 zugewandte Wandschicht 56 auf sowie eine zweite, der zweiten Gehäusekammer zugewandte Wandschicht 57, die parallel und im Abstand zueinander angeordnet sind und zwischen sich einen Strömungskanal 59 definieren, der die Stirnwand 48 durchgreift und in den Zwischenraum 60 zwischen der Stirnwand 48 und dem Untergrund 44 einmündet.

**[p0023]**

Die erste Gehäusekammer 53 nimmt eine Membranpumpe 62, eine Batterie 63 sowie ein elektrisches Schaltorgan 64 auf, das mit einem Betätigungselement 65 die Rückwand 49 durchgreift. Über ein Verbindungskabel 66 steht das Schaltorgan 64 mit der Membranpumpe 62 in elektrischer Verbindung, und mittels eines flexiblen Saugschlauches 68 wird innerhalb der ersten Gehäusekammer 53 eine Strömungsverbindung hergestellt zwischen der Membranpumpe 62 und dem Strömungskanal 59. Der Strömungskanal 59 ist vollständig von einem Filterelement 61 ausgefüllt. Ausserdem nimmt die erste Gehäusekammer 53 ein Belüftungsventil 55 auf, das eine Strömungsverbindung zwischen einer Belüftungsöffnung 58 der Stirnwand 48 und einer in die Bodenwand 46 eingeformten Durchgangsöffnung 67 steuert. Entsprechend dem voranstehend unter Bezugnahme auf die Figur 1 erläuterten Belüftungsventil 37 kann auch das Belüftungsventil 55 mittels eines Schaltstössels 69 ausgehend von seiner Schliessstellung entgegen der Wirkung einer Schliessfeder in eine Offenstellung überführt werden zum Belüften des Zwischenraums 60. In die Deckenwand 47 ist eine schwalbenschwanzförmige Nut 70 eingeformt, die eine Aufnahme ausbildet zum formschlüssigen Verbinden eines temporär am Untergrund 44 zu befestigenden Gegenstandes mit dem Gehäuse 42.

**[p0024]**

Soll ein Gegenstand mittels der Befestigungseinrichtung 40 temporär am Untergrund 44 befestigt werden, so kann er mit einer komplementär zur Nut 70 ausgestalteten Leiste durch Einführen derselben in die Nut 70 mit dem Gehäuse 42 lösbar verbunden werden. Das Gehäuse 42 kann dann mit der Stirnwand 48 an den Untergrund 44 angelegt werden, und durch Einschalten der Membranpumpe 62 kann der Zwischenraum 60 abgesaugt werden, so dass das Gehäuse 42 pneumatisch am Untergrund 44 anhaftet, so lange die Membranpumpe 62 in Betrieb ist. Wird die Membranpumpe 62 vom Benutzer ausgeschaltet und der Schaltstössel 69 betätigt, so baut sich der Unterdruck im Zwischenraum 60 aufgrund der Belüftung über das Belüftungsventil 55 ab und das Gehäuse 42 kann wieder vom Untergrund 44 entfernt werden. In den Figuren 3 bis 7 ist eine dritte Ausführungsform einer insgesamt mit dem Bezugszeichen 75 belegten Befestigungseinrichtung dargestellt. Diese weist ein Gehäuse 77 auf, das unter Zwischenlage eines auswechselbaren Dichtringes 78 an einen Untergrund 80 angelegt werden kann, insbesondere an eine Gebäudewand oder eine Gebäudedecke. Wiederum weist das Gehäuse 77 eine Bodenwand 82 und eine Deckenwand 83 auf, die über eine Stirnwand 84 und eine Rückwand 85 einstückig miteinander verbunden sind. Zusätzlich umfasst das Gehäuse 77 eine Zwischenwand 87, die die Stirnwand 84 mit der Rückwand 85 einstückig verbindet und doppelwandig ausgestaltet ist mit einer ersten Wandschicht 88 und einer zweiten Wandschicht 89.

**[p0025]**

Durch die Zwischenwand 87 wird das Gehäuse 77 in eine erste Gehäusekammer 91 und eine zweite Gehäusekammer 92 unterteilt, und zwischen der ersten Wandschicht 88 und der zweiten Wandschicht 89 verläuft ein Strömungskanal 93, der ein Filterelement 94 aufnimmt und in dem vom Dichtring 78 umgebenen Bereich die Stirnwand 84 durchgreift. Die erste Gehäusekammer 91 nimmt eine Membranpumpe 96, eine Batterie 97 und ein elektromechanisches Schaltorgan 98 mit einem Betätigungselement 99 auf, wobei das Schaltorgan 98 über ein Verbindungskabel 100 elektrisch mit der Membranpumpe 96 verbunden ist und die Membranpumpe 96 über einen flexiblen Saugschlauch 101 mit dem Strömungskanal 93 in Strömungsverbindung steht. Ausserdem nimmt die erste Gehäusekammer 91 ein Belüftungsventil 86 auf, das innenseitig an einer Belüftungsöffnung 90 der Stirnwand 84 angeordnet ist und vom Benutzer über einen Schaltstössel 95 betätigt werden kann. Das Belüftungsventil 86 nimmt aufgrund des Einsatzes einer Schliessfeder selbsttätig seine Schliessstellung ein, in der es eine Strömungsverbindung zwischen der Belüftungsöffnung 90 und einer in die Bodenwand 82 eingeformten Durchgangsöffnung 81 unterbricht. Durch Betätigen des Schaltstössels 95 kann der Benutzer das Belüftungsventil 86 in seine Offenstellung überführen.

**[p0026]**

Im Bereich des Dichtringes 78 bildet die Stirnwand 84 eine Saugplatte 102 aus, an deren Aussenseite der Dichtring 78 gehalten ist und die zusammen mit dem Untergrund 80 einen Zwischenraum 103 begrenzt, der von der Membranpumpe 96 über den Saugschlauch 101 und den Strömungskanal 93 abgesaugt werden kann, so dass das Gehäuse 77 pneumatisch am Untergrund 80 anhaftet. Soll der Zwischenraum 103 belüftet werden, so kann hierzu der Benutzer den Schaltstössel 95 betätigen, so dass das Belüftungsventil 86 in seine Offenstellung übergeht und dadurch der Zwischenraum 103 über die Belüftungsöffnung 90 belüftet werden kann. Während die in den Figuren 1 und 2 dargestellten Befestigungseinrichtungen 10 bzw. 40 mit einem temporär am jeweiligen Untergrund 14 bzw. 44 zu befestigenden Gegenstand lösbar verbindbar sind, ist in das Gehäuse 77 der in Figur 3 dargestellten Befestigungseinrichtung 75 ein zu befestigender Gegenstand in Form einer Bohrschmutzaufnahmeeinrichtung 110 integriert. Die zweite Gehäusekammer 92 weist hierzu in der Stirnwand 84 und der Rückwand 85 jeweils eine Gehäuseöffnung 112 bzw. 113 auf, die miteinander fluchten und von einem in den Figuren 3 bis 6 gestrichelt dargestellten Bohrer 115 durchgriffen werden können. Der Bohrer 115 ist drehfest an einer in Figur 3 teilweise dargestellten Bohrmaschine 116 gehalten.

**[p0027]**

Die stirnseitige Gehäuseöffnung 112 ist von einer auswechselbaren Schmutzführungshülse 118 durchgriffen, die sich in Richtung auf das Innere der zweiten Gehäusekammer 92 konisch erweitert und nach innen und nach aussen über die Stirnwand 84 hervorsteht. In ihrem nach aussen vorstehenden Bereich ist die Schmutzführungshülse 118 von einem flexiblen, elastisch verformbaren Dichtring 119 umgeben, der unmittelbar an den Untergrund 80 anlegbar ist. Die rückseitige Gehäuseöffnung 113 ist von einer Führungsbuchse 121 durchgriffen, die ebenso wie die Schmutzführungshülse 118 aus gehärtetem Metall gefertigt ist und die an der rückseitigen Gehäuseöffnung 113 auswechselbar gehalten ist. Sie kann in die rückseitige Gehäuseöffnung 113 eingesetzt wer-den, wobei sie mit einem auskragenden Bund 122 aussenseitig an der Rückwand 113 des Gehäuses 77 anliegt. Die zweite Gehäusekammer 92 definiert in ihrem Inneren einen Bohrschmutzsammelraum 124 und nimmt eine erste Reinigungseinrichtung in Form einer ersten Reinigungsbürste 126 und eine zweite Reinigungseinrichtung in Form einer zweiten Reinigungsbürste 128 auf. Mittels der ersten Reinigungsbürste 126 wird der Bohrer 115 beim Herausziehen aus der zweiten Gehäusekammer 92 abgestreift, und mittels der zweiten Reinigungsbürste 128 kann der rotierende Bohrer beim Einbringen einer Bohrung in den Untergrund 80 abgereinigt werden. Die zweite Reinigungsbürste 128 ist zwischen der ersten Reinigungsbürste 126 und der stirnseitigen Gehäuseöffnung 112 angeordnet, die erste Reinigungsbürste 126 ist der rückseitigen Gehäuseöffnung 113 benachbart positioniert

**[p0027]**

.

**[p0028]**

Wie insbesondere aus Figur 6 deutlich wird, ist die erste Reinigungsbürste 126 als Doppelbürste ausgestaltet und umfasst zwei Borstenreihen 131, 132, die einander zugewandt sind und jeweils an einem im Querschnitt U-förmigen Borstenhalter 133 bzw. 134 gehalten sind. Die beiden Borstenreihen 131, 132 nehmen zwischen sich den Bohrer 115 auf. Dieser weist zwei einander diametral gegenüberliegende Bohrnuten 136, 137 auf, die den Bohrer 115 wendeiförmig umgeben und Bohrschmutz, also Bohrmaterial und Bohrstaub, aus einem Bohrloch 138 des Untergrundes 80 in das Innere der zweiten Gehäusekammer 92 überführen. Nach erfolgtem Einbringen einer Bohrung kann der Bohrer 115 aus der zweiten Gehäusekammer 92 herausgezogen werden, wobei er von den Borstenreihen 131, 132 abgestreift wird. Hierzu weisen die Borstenreihen 131, 132 Borsten 139 auf, deren Länge so gewählt ist, dass sie den Grund der Bohrnuten 136, 137 erreichen und diese von Bohrschmutz befreien können. Wie aus Figur 4 ersichtlich ist, ist auch die zweite Reinigungsbürste 128 als Doppelbürste ausgestaltet und weist zwei Borstenreihen 141, 142 auf, die einander zugewandt sind und zwischen sich den Bohrer 115 aufnehmen. Sie sind jeweils an einem im Querschnitt U-förmigen Borstenhalter 143 bzw. 144 gehalten und umfassen Borsten 145, deren Länge wiederum so gewählt ist, dass sie bis zum Grund der Bohrnuten 136, 137 reichen.

**[p0029]**

Während die Borstenreihen 131, 132 der ersten Reinigungsbürste 126 senkrecht zur Längsachse 147 des Bohrers 115 ausgerichtet sind, verlaufen die Borstenreihen 141, 142 der zweiten Reinigungsbürste 128 in einem spitzen Winkel zur Längsachse 147. Dies hat zur Folge, dass den Borstenreihen 141, 142 der Bohrschmutz vom rotierenden Bohrer 115 beim Einbringen einer Bohrung in den Untergrund 80 seitlich zugeführt wird, so dass er mittels der Borsten 145 ungefähr in Längsrichtung der Bohrnuten 136, 137 aus diesen herausgebürstet werden kann. Mittels der zweiten Reinigungsbürste 128 kann somit während des Einsatzes des Bohrers 115 Bohrschmutz zuverlässig von diesem entfernt werden. Der Bohrschmutz sammelt sich im Bohrschmutzsammelraum 124 an, und über eine Deckenöffnung 149, die von einem Deckel 150 verschliessbar ist, kann der Bohrschmutzsammelraum 124 der zweiten Gehäusekammer 92 entleert werden. In Figur 7 ist eine alternative Ausgestaltung sowohl der ersten Reinigungsbürste 126 als auch der zweiten Reinigungsbürste 128 dargestellt in Form einer Ringbürste 152. Diese umfasst eine Vielzahl von radial zur Längsachse 147 des

**[p0030]**

Bohrers 115 verlaufenden Borsten 153, die an einem Haltering 154 gehalten sind. Die erste Reinigungsbürste 126 kann ebenso wie die zweite Reinigungsbürste 128 in Form der Ringbürste 152 ausgestaltet sein, die vom Bohrer 115 durchgriffen werden kann. Auf der der zweiten Reinigungsbürste 128 zugewandten Seite ist die erste Reinigungsbürste 126 von einer Abdeckung 156 abgedeckt. Diese ist als flexible Gummimembran ausgebildet in Form des Mantels eines Kegelstumpfes, der zentral vom Bohrer 115 durchgriffen werden kann. Mittels der Abdeckung 156 wird Bohrschmutz bezogen auf die Längsachse 147 radial nach aussen geführt. Wird der Bohrer 115 aus der zweiten Gehäusekammer 92 herausgezogen, so ist mittels der Abdeckung 156 in Kombination mit der ersten Reinigungsbürste 126 sichergestellt, dass der Bohrer 115 abgestreift und somit an diesem anhaftender Bohrschmutz entfernt wird, und gleichzeitig ist gewährleistet, dass kein Bohrschmutz über die rückseitige Gehäuseöffnung 113 aus dem Gehäuse 77 entweichen kann. Dies gilt insbesondere bei vertikaler Ausrichtung des Bohrers 115, das heisst bei Einbringen einer Bohrung in eine Decke. Auch in diesem Fall wird sämtlicher Bohrstaub, der beim Bohren anfällt, innerhalb der zweiten Gehäusekammer 92 gesammelt.

**[p0031]**

Wie bereits erläutert, kann die Bohrschmutzauffangeinrichtung 110 durch Absaugen des Zwischenraumes 103 zuverlässig am Untergrund 80 gehalten werden zum Einbringen einer Bohrung in den Untergrund 80. Während des Einbringens bleibt die Membranpumpe 96 eingeschaltet. Nachdem eine Bohrung in den Untergrund 80 eingebracht wurde, kann der Bohrer 115 aus der zweiten Gehäusekammer 92 herausgezogen werden, und anschliessend kann die Membranpumpe 96 mittels des Schaltorganes 98 ausgeschaltet werden. Es kann dann kurzzeitig der Schaltstössel 95 betätigt werden, so dass der Zwischenraum 103 belüftet wird und das Gehäuse 77 vom Untergrund 80 entfernt werden kann. Zusätzlich zur Bohrschmutzauffangeinrichtung 110 kann in das Gehäuse 77 eine an sich bekannte und deshalb in der Zeichnung nicht dargestellte Markierungseinrichtung, insbesondere eine Lasermarkierungseinrichtung, sowie eine Messeinrichtung und eine Libelle integriert sein. Mittels der Messeinrichtung kann die gewünschte Position für eine Bohrung am Untergrund 80 bestimmt werden, und mittels der Markierungseinrichtung kann eine Markierung vorgenommen werden. Die notwendige Befestigung am Untergrund 80 erfolgt durch den Einsatz der Membranpumpe 96, so dass der Benutzer jeweils beide Hände frei hat und beispielsweise mit beiden Händen die Bohrmaschine 116 sicher halten kann.

## Classifications

- B25B11/007
- B25B11/00
- F16M13/02
- F16M13/022
- G01D11/30

---

Generated by IPtorch. Verify legal conclusions against the official publication.
