# 37. Sucker prevented from falling off

- **Archive rank:** 37 of 50
- **Publication:** [CN-103836054-A](https://patents.google.com/patent/CN103836054A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/050799861/publication/CN103836054A?q=pn%3DCN103836054A)
- **Publication date:** 2014-06-04
- **Filing date:** 2012-11-20
- **Earliest priority:** 2012-11-20
- **Family:** 50799861
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery

## Parties

- **Applicant / assignee:** KUNSHAN YANDA COMP TECH CO LTD

## Abstract

The invention provides a sucker prevented from falling off. The sucker comprises a hollow sucker body, a first air pressure detecting sensor, a second air pressure detecting sensor, a processing unit and an alarming unit. The hollow sucker body is attached to the smooth surface; the first air pressure detecting sensor is arranged in the hollow sucker body and detects the air pressure value P1 inside the hollow sucker body; the second air pressure detecting sensor is arranged outside the hollow sucker body and detects the air pressure value P2 outside the hollow sucker body; the processing unit is connected with the first air pressure detecting sensor and the second air pressure detecting sensor, the value of P1/P2 is worked out through the processing unit, and when the value of P1/P2 reaches a first early-warning value, a first warning signal is sent; The alarming unit is connected with the processing unit and after the first warning signal is received by the alarming unit, first buzzing warning sound is sent. The sucker prevented from falling off can remind a user to guard when the hollow sucker body is going to falling off so that unnecessary hurt is avoided.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/d6/30/f9/8a3a908d2a56ee/HDA00002432795100011.png)

![Sketch 1 for CN-103836054-A](https://patentimages.storage.googleapis.com/d6/30/f9/8a3a908d2a56ee/HDA00002432795100011.png)

## Claims

### Claim 1 (independent)

Claims (8) a Drop-proof sucker, it is for fixed electronic device; It is characterized in that described Drop-proof sucker comprises:

### Claim 3 (independent)

Hollow sucker, it is adsorbed on smooth surface;

### Claim 4 (independent)

The first air pressure detection sensor, it is arranged in hollow sucker and sensing sucker air pressure inside value P1;

### Claim 5 (independent)

The second air pressure detection sensor, it is arranged at the outer also sensing sucker external pressure value P2 of hollow sucker;

### Claim 6 (independent)

Processing unit, it connects described the first air pressure detection sensor and the second air pressure detection sensor, and described processing unit calculating P1/P2, and in the time that P1/P2 reaches the first early warning value, sends the first alarm signal;

### Claim 7

Alarm unit, it connects described processing unit, and described alarm unit sends the first buzzing alarming sound after receiving the first alarm signal. Drop-proof sucker according to claim 1, is characterized in that: described processing unit calculates P1/P2, and in the time that P1/P2 reaches the second early warning value, sends the second alarm signal; And described alarm unit sends the second buzzing alarming sound after receiving the second alarm signal. Drop-proof sucker according to claim 1, is characterized in that: described the first early warning value is 90%. Drop-proof sucker according to claim 1, is characterized in that: described the first early warning value is 95%. Drop-proof sucker according to claim 1, is characterized in that: described processing unit wireless connections the first air pressure detection sensor. Drop-proof sucker according to claim 1, is characterized in that: described processing unit wireless connections the second air pressure detection sensor. Drop-proof sucker according to claim 1, is characterized in that: described processing unit and alarm unit are arranged in electronic equipment.

### Claim 8

Drop-proof sucker according to claim 1, is characterized in that: described electronic equipment is gyropilot.

## Full description

**[p0001]**

Description Drop-proof sucker [technical field] The present invention relates to a kind of Drop-proof sucker, particularly a kind of can be before hollow sucker drops prior notice user's Drop-proof sucker. [background technique] Sucker adopts macromolecule organic material, noncrystal, structure of molecule is special, when with wall adhesion, smallest molecule gap is less than nitrogen oxygen equimolecular volume in air, so can avoid air to flow into, the mean molecule gap that the sucker that quality is better causes is less, in unit time, air influx is less, so keep the subsides time on the wall longer. C China patent application discloses a kind of sucker with absorption surface No. 200710101258.0, and wherein sucker has the main sucker of dish type unit, and has attaching surface, and this main sucker unit is made up of the material of elastically deformable.This attaching surface has the gel layer being made up of gel, thereby this gel layer is bonded in and on attaching surface, covers this attaching surface.Absorption surface is formed by the surface of described gel layer, and gel layer is made up of core and circumferential section, and described core forms the center of absorption surface, and described circumferential section forms the excircle of absorption surface.

**[p0002]**

But the sucker in No. 200710101258.0th, C China patent application is after long-time use, the atmospheric pressure in sucker can constantly increase, and user can not discover, so that the article that are fixed on hollow sucker damage because dropping. [summary of the invention] Main purpose of the present invention be to provide a kind of can be before hollow sucker drops prior notice user's Drop-proof sucker. The invention provides a kind of Drop-proof sucker; It draws together hollow sucker, the first air pressure detection sensor, the second air pressure detection sensor, processing unit and alarm unit, and described hollow sucker is adsorbed on smooth surface; Described the first air pressure detection sensor is arranged in hollow sucker and sensing sucker air pressure inside value P1; Described the second air pressure detection sensor is arranged at the outer also sensing sucker external pressure value P2 of hollow sucker; Described processing unit connects described the first air pressure detection sensor and the second air pressure detection sensor, and described processing unit calculating P1/P2, and in the time that P1/P2 reaches the first early warning value, sends the first alarm signal; Described alarm unit connects described processing unit, and described alarm unit sends the first buzzing alarming sound after receiving the first alarm signal.

**[p0003]**

Especially, described processing unit calculates P1/P2, and in the time that P1/P2 reaches the second early warning value, sends the second alarm signal; And described alarm unit sends the second buzzing alarming sound after receiving the second alarm signal. Especially, described the first early warning value is 90%. Especially, described the first early warning value is 95%. Especially, described processing unit wireless connections the first air pressure detection sensor. Especially, described processing unit wireless connections the second air pressure detection sensor. Especially, described processing unit and alarm unit are arranged in electronic equipment. Especially, described electronic equipment is gyropilot. Compared with prior art, Drop-proof sucker of the present invention can allow user's reminding user before hollow sucker is about to drop carry out and take precautions against preparation, in order to avoid cause unnecessary damage. [accompanying drawing explanation] Fig. 1 is the functional-block diagram of Drop-proof sucker of the present invention.

**[p0004]**

[embodiment] Refer to shown in Fig. 1, the invention provides a kind of Drop-proof sucker; It draws together hollow sucker 10, the first air pressure detection sensor 20, the second air pressure detection sensor 30, processing unit 40 and alarm unit 50, and described hollow sucker 10 is adsorbed on smooth surface 100; Described the first air pressure detection sensor 20 is arranged in hollow sucker 10 and sensing sucker air pressure inside value P1; Described the second air pressure detection sensor 30 is arranged at the outer also sensing sucker external pressure value P2 of hollow sucker 10; Described processing unit 40 connects described the first air pressure detection sensor 20 and the second air pressure detection sensor 30, and described processing unit 40 calculates P1/P2, and in the time that P1/P2 reaches the first early warning value, sends the first alarm signal; Described alarm unit 50 connects described processing unit 40, and described alarm unit 50 sends the first buzzing alarming sound after receiving the first alarm signal.In the present embodiment, described processing unit 40 calculates P1/P2, and in the time that P1/P2 reaches the second early warning value, sends the second alarm signal; And described alarm unit 50 sends the second buzzing alarming sound after receiving the second alarm signal; Wherein, described the first early warning value is 90%; Described the first early warning value is 95%.Described processing unit 40 wireless connections the first air pressure detection sensors 20; Described processing unit 40 wireless connections the second ai

**[p0004]**

r pressure detection sensors 30; Described processing unit 40 is arranged in electronic equipment 200 with alarm unit 50; Described electronic equipment 200 is gyropilot.

**[p0005]**

Drop-proof sucker of the present invention can allow user's reminding user before hollow sucker 10 is about to drop carry out and take precautions against preparation, in order to avoid cause unnecessary damage. The above; be only the specific embodiment of the present invention, but protection scope of the present invention is not limited to this, any be familiar with those skilled in the art the present invention disclose technical scope in; can expect easily changing or replacing, within all should being encompassed in protection scope of the present invention.Therefore, protection scope of the present invention should be as the criterion with the protection domain of claim.

## Cited patent documents

- [CN-102393988-A](https://patents.google.com/patent/CN102393988A/en) — SEA
- [CN-102426463-A](https://patents.google.com/patent/CN102426463A/en) — SEA
- [CN-201711969-U](https://patents.google.com/patent/CN201711969U/en) — SEA
- [JP-2005291404-A](https://patents.google.com/patent/JP2005291404A/en) — SEA
- [US-2003197609-A1](https://patents.google.com/patent/US20030197609A1/en) — SEA

---

Generated by IPtorch. Verify legal conclusions against the official publication.
