# 49. Vacuum lifting device

- **Archive rank:** 49 of 50
- **Publication:** [WO-9416148-A1](https://patents.google.com/patent/WO9416148A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/006888185/publication/WO9416148A1?q=pn%3DWO9416148A1)
- **Publication date:** 1994-07-21
- **Filing date:** 1994-01-11
- **Earliest priority:** 1993-01-16
- **Family:** 6888185
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** KLEIN WILHELM; WILHELM KLEIN GMBH
- **Inventors:** KLEIN WILHELM

## Abstract

The invention relates to a vacuum lifting device for plates, stones and other objects, the holding surface of which is uneven, using the vacuum principle employed in suction attachments, consisting of an essentially uniform, plane-parallel and rigid supporting plate, one side of which bears the supporting or holding means (11) and the other side, serving as a seal, is coated with a plastically deformable sealing compound. The feature of the invention is that the supporting plate (1) has spring-loaded inserts (7) running perpendicularly to the plate plane in the region of the vacuum chambers which project beyond the upper limit of the plastically deformable sealing compound (6).

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/WO-9416148-A1/ops000.png)

![Sketch 1 for WO-9416148-A1](https://nimo.iptorch.com/refdrawing/WO-9416148-A1/ops000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/WO-9416148-A1/ops001.png)

![Sketch 2 for WO-9416148-A1](https://nimo.iptorch.com/refdrawing/WO-9416148-A1/ops001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/WO-9416148-A1/ops002.png)

![Sketch 3 for WO-9416148-A1](https://nimo.iptorch.com/refdrawing/WO-9416148-A1/ops002.png)

## Claims

### Claim 1 (independent)

Schutz ansprüche: Vakuum-Hebegerät für Platten, Steine und andere Gegenstände, deren Haltefläche Unebenheiten aufweisen können, unter Anwendung des bei Saugvorsätzen benutzten Vakuumprinzips, bestehend aus einer in sich homogenen, planparallelen und biegesteifen Halteplatte, deren eine Seite die Halte- oder Befestigungsmittel (11) trägt und deren andere, der Abdichtung dienende Seite zur Abgrenzung von einem oder mehreren Vakuumräumen mit einer plastisch verformbaren Dichtungsmase belegt ist, dadurch gekennzeichnet, dass die Halteplatte (1) im Bereich der Vakuumräume senkrecht zur Plattenebene serlaufende federnde Einsätze (7) aufweist, welche die obere Begrenzung der plastisch verformbaren Dichtungsmasse (6) überragen.

### Claim 2

Vakoum-Hebegerät nach Anspruch 1, dadurch gekennzeichnet, dass die federnden Einsätze (7) die plastisch verformbare Dichtungsmasse (6) um 5 bis 50 mm, vorzugsweise um 10 mm, überragen.

### Claim 3

Vakuum-Hebegerät nach Anspruch 1 und 2, dadurch gekennzeichnet, dass die federnden Einsätze (7) aus elastisch verformbarem Material, z. B. Moosgummi, bestehen.

### Claim 4

Vakuum-Hebegerät nach Anspruch 1 bis 2, dadurch gekennzeichnet, dass die federnden Einsätze (7) aus Ringen oder Rohren bestehen, die aus elastisch verformbaren Material verschiedener Shore-Härte zusammengesetzt sind.

### Claim 5

Vakuum-Hebegerät nach Anspruch 1 bis 4, dadurch gekennzeichnet, dass die federnden Einsätze (7) aus elastisch verformbarem Material Armierungsstäbe (25) aufweisen.

### Claim 6

Vakuum-Hebegerät nach Anspruch 1-bis 5, dadurch gekennzeichnet, dass die federnden Einsätze in Rillen oder Aussparungen der Halteplatte eingelegt, vorzugsweise eingeklebt, sind.

### Claim 7

Vakuum-Hebegerät nach Anspruch 1 bis 6, dadurch gekennzeichnet, dass die plastisch verformbare Dichtungsmasse (6) aus dem Kunststoff Polyisobutylen besteht.

### Claim 8

Vakuum-Hebegerät nach Anspruch 1 bis 7, dadurch gekennzeichnet, dass die Halteplatte (1) aus einem korrosionsbeständigen Kunststoff mit grosser Oberflächen-Adhäsion, vorzugsweise aus dem Kunststoff Polypropylen besteht.

### Claim 9

Vakuum-Hebegerät nach Anspruch 1 bis 8, dadurch gekennzeichnet, dass mehrere, in der Halteplatte (1) vorgesehene Vakuumräume durch innerhalb der Platte vorhandene Kanäle miteinander verbunden sind.

### Claim 10

Vakuum-Hebegerät nach Anspruch 1 bis 9, dadurch gekennzeichnet, dass die Abdichtungsseite der Halteplatte (1) eine gefräste oder durch sandstrahlen aufgerauhte Oberfläche aufweist.

### Claim 11

Vakuum-Hebegerät nach Anspruch 1 bis -10, dadurch gekennzeichnet, dass die Halteplatte (1) eine Grösse von etwa 30 x 30 cm2 und eine Stärke von 3 bis 5 cm, vorzugsweise von 2,5 cm aufweist.

### Claim 12

Vakuum-Hebegerät nach Anspruch 1 bis 11, dadurch gekennzeichnet, dass es einen zusätzlichen Vakuumbehälter (19) aufweist, der zwischen den erforderlichen Vakuumerzeuger (17) und die zur Halteplatte (22) führende Vakuumleitung (20)

## Full description

**[0001]**

Vakuum-Hebegerät Die Erfindung betrifft ein Vakuum-Hebegerät für Platten, Steine und andere Gegenstände, deren Halteflächen Unebenheiten aufweisen können, unter Anwendung des bei Saugvorsätzen benutzten Vakuumprinzips.

**[0002]**

Es wird von einer aus DE 41 25 889 bekannten Vorrichtung ausgegangen, welche aus einer mit einer Vakuumdurchführung versehenen Armatur besteht, deren eine Seite die Halteoder Befestigungsmittel trägt und deren andere der Abdichtung dienende Seite mit einer geschlossenen Wulst aus komprimierbarem Material versehen ist. In dieser bekannten Vorrichtung ist die Armatur als in sich homogene, planparallele und biegesteife Halteplatte ausgebildet, auf deren Abdichtungsseite die Wulst als plastisch verformbare Dichtungsmasse aufgetragen ist. Als besonders empfehlenswert hat sich bei dieser bekannten Vorrichtung die Verwendung des Kunsstoffes Polyisobutylen als plastische Dichtungsmasse erwiesen.

**[0003]**

Dieser Kunststoff wird bei der bekannten Vorrichtung beispielsweise in Form einer Wulst als Umrandung auf die Halteplatte aufgebracht; er lässt sich nach Gebrauch sowohl von der unebenen Fläche als auch von der Halteplatte leicht abziehen ohne Rückstände zu hinterlassen. Er kann daher bei beliebig vielen Einsätzen der Halteplatte benutzt werden.

**[0004]**

Der besondere Vorteil eines solchen plastisch verformbaren Kunststoffes in Verbindung mit einer Vorrichtung nach der erwähnten Veröffentlichung besteht darin, dass sich dieser Kunststoff bei Herstellung des Vakuums zwischen der Halteplatte und der Fläche, an der die Halteplatte befestigt werden soll, deren Unebenheiten vakuumdicht anpasst. Es hat sich dabei die überraschende Wirkung ergeben, dass die Halteplatte auch nach Aufheben des zwischen ihr und der unebenen Fläche bestehenden Vakuums noch über einen längeren Zeitraum auch unter Belastung festgehalten wird, weil unter dem Einfluss des Vakuums eine Verzahnung zwischen der plastisch verformbaren Dichtungsmasse und der unebenen Fläche eingetreten ist.

**[0005]**

Der Erfindung liegt die Aufgabe zugrunde, dieses bewährte Prinzip auf ein Vakuum- Hebegerät zu übertragen, welches die Aufgabe hat, Lasten mit annähernd ebener Oberfläche abzuheben, ggf. zu transportieren und dann wieder abzusetzen und zwar ohne Eingriff in Teile dieses Hebegerätes, wozu die Halteplatte mit dem plastisch verformbaren Kunststoff gehört.

**[0006]**

Gelöst wird diese Aufgabe bei einem solchen Vakuum-Hebegerät, welches aus einer, in sich homogenen, planparallelen und biegesteifen Halteplatte besteht, deren eine Seite die Halte- oder Befestigungsmittel trägt, und deren andere, der Abdichtung dienende Seite zur Abgrenzung von einem oder mehreren Vakuumräumen mit einer plastisch verformbaren Dichtungsmasse belegt ist, dadurch, dass die Halteplatte im Bereich der Vakuumräume senkrecht zur Plattenebene verlaufende federnde Einsätze aufweist, welche die obere Begrenzung der plastisch verformbaren Dichtungsmasse überrag en.

**[0007]**

Zweckmässig erscheint eine solche Überragung in der Grösse von 5 bis 50 mm, vorzugsweise von 10 mm.

**[0008]**

Für das erfindungsgemässe Vakuum-Hebegerät wird also die bekannte ausgezeichnete Haltekraft des auf die Halteplatte aufgebrachten plastisch verformbaren Kunststoffes, insbesondere in Form des Kunststoffes Polyisobutylen, ausgenutzt, gleichzeitig wird aber eine gewollte schnelle Aufhebung dieser Haltekraft durch die in den Vakuumräumen eingebauten federnden Einsätze aus vorzugsweise elastisch verformbaren Material erreicht.

**[0009]**

Da diese Einsätze die obere Begrenzung der plastisch verformbaren Schicht im Ruhezustand überragen, reicht ihre im Vakuumzustand erfolgte elastische Verformung aus, um dank der auftretenden Rückstellkräfte den Ansaugzustand der Halteplatte aufzuheben, sobald der Vakuumzustand unterbrochen, beispielsweise die Vakuumpumpe abgeschaltet wird.

**[0010]**

Dank seiner Konstruktion ist das erfindungsgemässe Vakuum- Hebegerät bekannten Hebegeräten, wie sie beispielsweise in der DAS 27 23 616 und EP 0 125 550 beschrieben sind, weit überlegen. Bei den bekannten Geräten werden in der Regel zur Aufrechterhaltung des Vakuums zwei oder mehr elastisch verformbare Gummischichten angewendet, wobei diese einzelnen Schichten verschiedene Shorehärte aufweisen.

**[0011]**

Der Nachteil dieser bekannten Hebegeräte gegenüber der Erfindung besteht darin, dass diese Geräte nur dann anwendbar sind, wenn die zu erfassenden Gegenstände eine möglichst ebene Oberfläche aufweisen oder wenn die vorhandenen Unebenheiten nur sehr gering sind. Bei grösseren Unebenheiten versagen diese bekannten Geräte.

**[0012]**

Von Vorteil ist bei dem erfindungsgemässen Gerät noch, dass im Betrieb des Gerätes auftretende Undichtigkeiten ohne Schwierigkeiten schnell beseitigt werden können, weil die auf die Halteplatte aufgebrachte plastisch verformbare Dichtungsmasse jederzeit eine Nachbesserung erlaubt.

**[0013]**

Die federnden Einsätze bestehen zweckmässig aus elastisch verformbarem Material, z. B. Moosgummi. Diese können in Rillen oder Aussparungen der Halteplatte eingelegt, vorzugsweise eingeklebt sein.

**[0014]**

Sie können aber auch aus Ringen oder Rohren bestehen, die aus elastisch verformbarem Material verschiedener shore-Härte zusammen gesetzt sind.

**[0015]**

Eine weitere Verbesserung besteht darin, dass die Einsätze aus elastisch verformbarem Material Armierungsstäbe aufweisen. Damit wird sichergestellt, dass ihre geometrische Form stets erhalten bleibt.

**[0016]**

Die Halteplatte selbst besteht zweckmässig aus einen korrosionsbeständigen Kunststoff mit grosser Oberflächen-Adhäsion, verzugsweise aus dem Kunststoff Polypropylen.

**[0017]**

Weiterhin empfiehlt es sich, dass mehrere ggf. in der Halteplatte vorgesehene Vakuumräume durch innerhalb der Platte vorhande Kanäle miteinander verbunden sind. Es ist dann lediglich ein einziger Anschluss für das Hebegerät an den Vakuumerzeuger erforderlich.

**[0018]**

Das erfindungsgemässe Vakuum-Hebegerät, dessen Halteplatte 2 zweckmässig eine Grösse von etwa 30 x 30 cm2 und eine Stärke von 3 bis 5 cm, vorzugsweise von 3,5 cm aufweisen soll, wird zweckmässig mit einem zusätzlichen Vakuumbehälter betrieben, der zwischen den erforderlichen Vakuumerzeuger und die zur Halteplatte führende Vakuumleitung eingeschaltet wird. Das hat den Vorteil, dass der Vakuumerzeuger nicht ständig in Betrieb zu sein braucht, da das Vakuum eines verhältnismässig kleinen Vakuumbehälters ausreicht, um ein solches Vakuum-Hebegerät für eine verhältnismässig lange Zeitdauer zu betreiben.

**[0019]**

Eine weitere Verbesserung eines solches Gerätes besteht noch darin, dass die Abdichtungsseite der Halteplatte eine gefräste oder durch Sandstrahlen aufgerauhte Oberfläche aufweist. Damit wird die Haftung der plastisch verformbaren Dichtungsmasse an der Halteplatte erheblich verbessert.

**[0020]**

Ausführungsbeispiele der Erfindung sind in den Zeichungen dargestellt.

**[0021]**

Es zeigen: Fig. 1 die Aufsicht auf ein solches Hebegerät, Fig. 2 einen Querschnitt durch das Hebegerät gemäss Fig. 1 in Richtung A-B, Fig. 3 die Aufsicht auf ein Hebegerät etwas anderer Konstruktion, Fig. 4 einen Querschnitt durch dieses Gerät in Richtung der Schnittlinie C-D von Fig. 3, Fig. 5 einen Stapler mit einem daran montierten Hebegerät.

**[0022]**

In dem Ausführungsbeispiel nach den Figuren 1 und 2 ist ein solches Hebegerät dargestellt, mit dessen Halteplatte (1) gleichzeitig vier etwas unregelmässig verlegte Bausteine (2), (3), (4) und (5) angehoben werden sollen. Zu diesem Zweck ist die aus dem Kunststoff Polypropylen bestehende Halteplatte (1) auf ihrer Halteseite mit einer Schicht (6) des plastisch verformbaren Kunststoffes Polyisobutylen belegt. Aus der Querschnittsdarstellung nach Fig. 2 ist zu erkennen, dass die Halteplatte (1) einen Vakuumanschluss (10) aufweist, der zu Vakuumleitungen oder Vakuumhohlräumen innerhalb der Halteplatte (1) führt, welche alle untereinander verbunden sind.Im Bereich dieser Vakuumräume sind auf der Abdichtungsseite der Halteplatte (1) Einsätze (7) und (8) aus elastisch verformbarem Kunststoff eingebaut, welche eine etwas grössere Stärke als die Dicke der Schicht (6) besitzen, so dass sie diese Schicht geringfügig überragen; diese Überragung beträgt hier 5 mm. Auf seiner Oberseite ist die Halteplatte (1) mit einem Handgriff (11) versehen.

**[0023]**

Zum Abheben der vier in Fig. 1 dargestellten Bausteine (2), (3), (4) und (5) ist es lediglich erforderlich, dass die soeben beschriebene Halteplatte (1) auf diese Bausteine aufgesetzt wird und dass dann über den Vakuumanschluss (10) das Vakuum hergestellt wird. Danach haften die Bausteine an der Halteplatte (1) und können nunmehr angehoben werden. Nach dem Umsetzen der Steine ist es lediglich erforderlich, das Vakuum aufzuheben, wodurch die Haftung der Halteplatte (1) an der Steinoberfläche beseitigt wird. Dafür sorgen die Überhöhungen der Einsatzstücke (7) und (8), welche in diesem Ausführungsbeispiel als Ringwulst ausgebildet sind.

**[0024]**

In dem Ausführungsbeispiel nach den Figuren (3) und (4) ist ein Vakuum-Hebegerät dargestellt, mit welchem ein Kanaldeckel (12) mit ausserordentlich ungleichmässiger Oberfläche abgehoben werden soll. Aus der Querschnittsdarstellung nach Fig. 4 ist die Verteilung der plastisch verformbaren Dichtungsmasse (6) zu erkennen. In diese Masse (6) sind die aus elastisch verformbaren Kunststoff, beispielsweise elastischem Gummi, bestehenden federnden Einsätze (13) und (14) eingebettet, welche die äussere Begrenzung der Schicht (6) überragen. Dieses Ausführungsbeispiel zeigt, dass die Erfindung auch bei recht unebenen Oberflächen eines abzuhebenden Körpers anwendbar ist.

**[0025]**

In Figur 5 ist schliesslich ein Stapler (15) mit dem Hebegerät dargestellt; letzteres testeht aus der Halteplatte (22) mit einer entsprechenden Traverse.

**[0026]**

Auf dem Stapler ist der Vakuumerzeuger (17) dargestellt, der von einer Batterie (16) betrieben wird. Mit (18) ist ein Vakuumschalter bezeichnet. Dieser Vakuumerzeuger (17) arbeitet auf einen Vakuumbehälter (19), der seinerseits über ein Vakuumleitungssystem (20) mit der Halteplatte (22) verbunden ist. Mit (21) ist eine Leitungstrommel bezeichnet.

**[0027]**

Dieses Betriebsgerät benötigt naturgemäss noch ein Steuerventil, welches der Einfachheit halber nicht eingezeichnet ist; es sind lediglich diejenigen Teile und Geräte dargestellt, welche in Verbindung mit dem Hebegerät benötigt werden, welches die Aufgabe hat, einen Stapel Platten (23) abzuheben.

## Classifications

- E01C19/524
- B25B11/00
- B25B11/007
- B66C1/02
- B66C1/0212
- B66C1/0243
- E01C19/52

## Cited patent documents

- [DE-2065192-A1](https://patents.google.com/patent/DE2065192A1/en) — ISR
- [DE-4125889-C1](https://patents.google.com/patent/DE4125889C1/en) — ISR
- [EP-0120291-A2](https://patents.google.com/patent/EP0120291A2/en) — ISR

---

Generated by IPtorch. Verify legal conclusions against the official publication.
