# 31. Device with a suction cup for supporting and mounting articles to a surface

- **Archive rank:** 31 of 50
- **Publication:** [US-2006231705-A1](https://patents.google.com/patent/US20060231705A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/036101040/publication/US20060231705A1?q=pn%3DUS20060231705A1)
- **Publication date:** 2006-10-19
- **Filing date:** 2006-02-03
- **Earliest priority:** 2005-02-04
- **Family:** 36101040
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus

## Parties

- **Applicant / assignee:** LIU YI
- **Inventors:** LIU YI

## Abstract

A fixing device with a suction cup for supporting and mounting articles to a surface is provided by the present invention. The fixing device comprises a housing, a suction cup assembly and an air outlet formed in the suction cup assembly. A vacuum pump is contained in the housing and is connected to the air outlet via a first conduit. A battery pack supplies power to the vacuum pump and a switch is provided for activating the vacuum pump. The fixing device can further include a valve for releasing the device from the attached surface, an actuating member for automatically activating the vacuum pump, and a fixing pad with a magnet and two different-shaped surfaces. Accordingly, the fixing device can be fixed on a smooth or roughened surface for a long time and can be easily and quickly removed without damaging the surface. In addition, the fixing device can also be used to support and mount articles of different shapes and functions to the wall.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/d0/b9/a6/b3e1dc9c5ddc53/US20060231705A1-20061019-D00000.png)

![Sketch 1 for US-2006231705-A1](https://patentimages.storage.googleapis.com/d0/b9/a6/b3e1dc9c5ddc53/US20060231705A1-20061019-D00000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/af/94/f4/f395ca917caec3/US20060231705A1-20061019-D00001.png)

![Sketch 2 for US-2006231705-A1](https://patentimages.storage.googleapis.com/af/94/f4/f395ca917caec3/US20060231705A1-20061019-D00001.png)

[Sketch 3](https://patentimages.storage.googleapis.com/37/7f/82/1afe4ab3a8690e/US20060231705A1-20061019-D00002.png)

![Sketch 3 for US-2006231705-A1](https://patentimages.storage.googleapis.com/37/7f/82/1afe4ab3a8690e/US20060231705A1-20061019-D00002.png)

[Sketch 4](https://patentimages.storage.googleapis.com/ca/e0/e6/4629264ba38c18/US20060231705A1-20061019-D00003.png)

![Sketch 4 for US-2006231705-A1](https://patentimages.storage.googleapis.com/ca/e0/e6/4629264ba38c18/US20060231705A1-20061019-D00003.png)

[Sketch 5](https://patentimages.storage.googleapis.com/39/a5/0f/70055c3e935415/US20060231705A1-20061019-D00004.png)

![Sketch 5 for US-2006231705-A1](https://patentimages.storage.googleapis.com/39/a5/0f/70055c3e935415/US20060231705A1-20061019-D00004.png)

[Sketch 6](https://patentimages.storage.googleapis.com/bd/d5/25/a86cb7a5026181/US20060231705A1-20061019-D00005.png)

![Sketch 6 for US-2006231705-A1](https://patentimages.storage.googleapis.com/bd/d5/25/a86cb7a5026181/US20060231705A1-20061019-D00005.png)

[Sketch 7](https://patentimages.storage.googleapis.com/79/58/55/a7605b0dab49cf/US20060231705A1-20061019-D00006.png)

![Sketch 7 for US-2006231705-A1](https://patentimages.storage.googleapis.com/79/58/55/a7605b0dab49cf/US20060231705A1-20061019-D00006.png)

[Sketch 8](https://patentimages.storage.googleapis.com/44/3b/c1/05ef8aaa0627c7/US20060231705A1-20061019-D00007.png)

![Sketch 8 for US-2006231705-A1](https://patentimages.storage.googleapis.com/44/3b/c1/05ef8aaa0627c7/US20060231705A1-20061019-D00007.png)

[Sketch 9](https://patentimages.storage.googleapis.com/4d/9f/0f/caa5bb9ea266b6/US20060231705A1-20061019-D00008.png)

![Sketch 9 for US-2006231705-A1](https://patentimages.storage.googleapis.com/4d/9f/0f/caa5bb9ea266b6/US20060231705A1-20061019-D00008.png)

[Sketch 10](https://patentimages.storage.googleapis.com/f0/a1/02/df4bb48742ced7/US20060231705A1-20061019-D00009.png)

![Sketch 10 for US-2006231705-A1](https://patentimages.storage.googleapis.com/f0/a1/02/df4bb48742ced7/US20060231705A1-20061019-D00009.png)

## Claims

### Claim 1 (independent)

A device for supporting and mounting articles to a surface, comprising a housing, a suction cup coupled to the housing, an air outlet provided in the housing and in communication with a space defined by the housing and the suction cup, a vacuum pump contained in the housing and being connected to the air outlet via a first conduit, a battery pack for supplying power source to the vacuum pump, and a switch for activating the vacuum pump.

### Claim 2

The device of claim 1 further including an air inlet provided in the housing, the air inlet including a valve connected to a release button for opening or closing the valve.

### Claim 3

The device of claim 2 , wherein the valve further comprises a valve body, a bar portion, a plug, and a spring urged by a member which is fixed in a second conduit, wherein the valve body is fixedly fitted within the second pipe, and the valve body comprises a first chamber which links a lumen of the second pipe to the atmosphere.

### Claim 4

The device of claim 3 , wherein the valve body further comprises a second chamber communicating with said first chamber and a slot connecting the second chamber to the second conduit.

### Claim 5

The device of claim 1 , further comprising a compressible downward protrusion positioned in the space defined by the housing and the suction cup, a control rod being supported on the protrusion at one end and a second end of the control rod capable of activating a trigger for switching on the vacuum pump.

### Claim 6

The device of claims 1 , further comprising a frame connected to the housing, the frame including a fixing pad having a magnet for retaining a desired object.

### Claim 7

The device of claim 6 , wherein the fixing pad has two opposed contact surfaces and the fixing pad can be selectively locked in the frame.

### Claim 8

The device of claim 7 , wherein one of the two opposed surfaces is curved and the other is flat.

### Claim 9

The device of claim 6 , wherein a recess is provided on the fixing pad, corresponding to which a latch is provided in the frame with an actuator connected therewith, the recess and the latch being engagable with each other.

### Claim 10 (independent)

An apparatus for fixing an object to a surface, the apparatus comprising: a housing; a suction member coupled to the housing and defining an interior suction space; an air outlet formed in the suction member and in communication with the suction space; a vacuum pump coupled to the air outlet for removing air from the suction space; a power source connected to the vacuum pump; a switch for activating the vacuum pump; and an air inlet connected to a valve for selectively connecting the suction space with an ambient atmosphere.

### Claim 11

The apparatus of claim 10 , further comprising means for automatically activating the vacuum pump.

### Claim 12

The apparatus of claim 11 , wherein the means for automatically activating the vacuum pump comprises a actuating member having one end disposed in the suction space and another end in contact with a trigger for switching the vacuum pump on and off.

### Claim 13

The apparatus of claim 12 , wherein the suction space has an air pressure and when the air pressure in the suction space is at a first level, the actuating member switches the vacuum pump on and when the air pressure in the suction space is at a second level, the actuating member switches the vacuum pump off.

### Claim 14

The apparatus of claim 10 , further comprising a member provided on the housing for actuating the valve for selectively connecting the suction space with the ambient atmosphere via the air inlet.

### Claim 15 (independent)

An apparatus for removeably mounting a laser generating device on a surface, the apparatus comprising: a housing having a suction member coupled thereto such that when the apparatus is placed on the surface, the surface and the suction member define an interior suction space; an air outlet formed in the suction member and in communication with the suction space; a vacuum pump coupled to the air outlet for removing air from the suction space; a power source connected to the vacuum pump; a switch for activating the vacuum pump; an air inlet connected to a valve for selectively connecting the suction space with an ambient atmosphere; and a fixing pad connected to the housing, the fixing pad having means for removeably connecting the light generating device to the housing.

### Claim 16

The apparatus of claim 15 , wherein the means for removeably connecting the light generating device comprises a magnet.

### Claim 17

The apparatus of claim 15 , wherein the light generating device can be rotated up to 360 degrees with respect to the housing when the apparatus is mounted on the surface.

### Claim 18

The apparatus of claim 15 , wherein the fixing pad is removeably mounted with a frame in the housing.

### Claim 19

The apparatus of claim 18 , wherein the fixing pad has a first and second contact surface for cooperating with the light generating device.

### Claim 20

The apparatus of claim 19 , wherein the first contact surface is rounded and the second contact surface is flat.

## Full description

### Cross-Reference To Related Applications

**[p0001]**

This application claims priority to Chinese Application No. 200520068932.6, filed on Feb. 4, 2005.

### Federally Sponsored Research Or Development

**[p0002]**

None.

### Technical Field

**[p0003]**

The present invention relates to a fixing device with a suction cup capable of being attached to a surface, for fixing an article which is connected to the fixing device on the surface.

### Background Of The Invention

**[p0004]**

It is well known in the art that adhesive, glue, nails or suction cups can be used to fix articles on a vertical or inclined surface. However, adhesive and glue are apt to foul the attached surface, and nails are liable to leave holes in the wall, which influences aesthetics and even alters the surface. A suction cup, however, does not have the above drawbacks. In prior fixing devices utilizing suction cups, a suction member having a skirt portion, which is usually made of rubber or plastics, is flattened on a surface. A chamber is defined by the skirt portion of the suction member and the surface. A vacuum is created as the skirt portion is compressed and the suction cup is fixed on the surface therefore. Generally, such a suction cup can only be attached on a very flat and smooth surface such as glass, glazed tile and the like, and can only carry a very small load. If a suction cup of this type carries a heavier load than it can afford or is attached on a surface which is not very smooth, air will influx into the chamber defined by the skirt portion and the surface and the device will not adhere to the desired surface.

**[p0005]**

On the other hand, if a suction cup has a very strong suction force, a new problem will occur, that is, it will be very difficult to remove from the wall surface on which it has been fixed.

### Summary Of The Invention

**[p0006]**

To avoid such disadvantage and inconvenience as set forth hereinbefore, one object of the present invention is to provide an improved fixing device with a suction cup that can be fixed on a surface for a long time. To achieve this object, the fixing device of the present invention comprises a housing, a suction cup and an air outlet provided in the bottom of the housing which connects to the suction cup. A vacuum pump is contained in the housing and connected to the air outlet via a conduit. The housing also includes a battery pack for supplying power to the vacuum pump and a switch for activating the vacuum pump. Another object of the invention is to achieve quick removal of a fixing device with a suction cup fixed on a surface. To achieve this object, the top of the suction cup where the housing is coupled further includes an air inlet connected to one end of an air intake conduit. The other end of the conduit is connected to a valve. A release button is provided on the housing for opening or closing of the valve. The valve comprises a valve body, a bar portion, a plug, and a spring urged by a member which is fixed in the air intake pipe. The valve body is fixedly fitted in the air intake pipe and comprises a chamber which links the lumen of the air intake pipe to the atmosphere. The chamber is formed with a valve port and the plug can be pressed against and cover the port under the biasing of the spring. The bar portion can press on the other end of the plug and is connected to a release button.

**[p0007]**

Yet another object of the invention is to provide an energy-saving fixing device. To achieve this object, the top of the suction cup comprises a compressible downward protrusion, a controlling rod supported on the protrusion at the one end, and with the other end being capable of activating a trigger for switching on the vacuum pump. Still another object of the invention is to provide a separate fixing device which can be used to support articles with various shapes and different functions. To achieve this object, a frame is applied in the housing, a fixing pad comprising two opposite surfaces with different shapes which can be selectively locked in the frame. The opposite surfaces can be differently configured (e.g., flat or rounded) and preferably includes a magnet. With these configurations, the fixing device of the present invention can be fixed on a smooth or even less smooth surface for a long time, and/or can be easily and quickly taken down from the surface, and/or provides for energy-savings while being fixed on a surface. In addition, the fixing device of the invention can be used to support articles of different shapes and functions.

**[p0008]**

Other features and advantages of the invention will be apparent from the following specification taken in conjunction with the following drawings.

### Brief Description Of The Drawings

**[p0009]**

A preferred embodiment of the invention will be described in detail in reference with the accompanying drawings, wherein: FIG. 1 is a perspective view of a general appearance of a preferred embodiment of the fixing device with a suction cup according to the present invention; FIG. 2 is another perspective view of the fixing device shown in FIG. 1 ; FIG. 3 is a perspective view of the fixing device shown in FIG. 1 , with the fixing pad being separated alongside; FIG. 4 is a perspective view of the fixing pad when it is turned over from the position as shown in FIG. 3 ; FIG. 5 is a perspective view of the fixing device with a portion of the housing removed away; FIG. 6 is a perspective view of a portion of the fixing device, wherein the suction cup is sectioned; FIG. 7 is a side view of some components of the fixing device, wherein the valve is sectioned; FIG. 8 is an interior cross-sectional view of the fixing device shown in FIG. 1 ; FIG. 9 is a perspective view of the fixing device shown in FIG. 1 , with a laser level supported thereon;

**[p0010]**

FIG. 10 is a perspective view of the fixing device with another laser level carried thereon; and FIG. 11 is a perspective view of the fixing device with a laser target carried thereon.

### Detailed Description

**[p0011]**

While this invention is susceptible of embodiments in many different forms, there is shown in the drawings and will herein be described in detail preferred embodiments of the invention with the understanding that the present disclosure is to be considered as an exemplification of the principles of the invention and is not intended to limit the broad aspect of the invention to the embodiments illustrated. Referring to FIGS. 1, 2 , 5 and 6 , a fixing device 100 comprises a housing 1 , a suction cup 2 , and a mini-sized vacuum pump 9 contained in the housing 1 . The pump 9 is connected to an air outlet 22 on the top 220 of the suction cup 2 via a conduit 82 . On the housing 1 , a power switch 3 is provided, which could be turned on to connect a battery pack 7 to a circuit. In this manner, the vacuum pump 9 is powered on and starts to operate. As a result, the air under the suction cup 2 is thus exhausted out through the pipe 82 from the air outlet 22 . Referring to FIG. 2 , the suction cup 2 includes a flexible skirt 24 made of elastic material such as rubber. The flexible skirt 24 includes a peripheral edge 240 which is smooth and lies in a single plane. Consequently, to place the fixing device 100 on a surface such as a wall, and switch on the power switch 3 , the vacuum pump 9 will then continually evacuate the air in the space 210 defined between the skirt 24 and the surface, such that the air pressure of the space 210 is greatly reduced and even drops to vacuum. As a result, the fixing device 100 is firmly secured on the surface.

**[p0012]**

Referring to FIGS. 3 and 4 , the fixing device 100 further includes a fixing pad 5 , which can be taken out of a locking frame 55 of the housing 1 . The fixing pad 5 includes a pair of protrusions 53 at one side and an elongated recess 54 at the opposite side. The fixing pad 5 further includes a first support surface 51 and a second support surface 52 with different shapes. For example, in one preferred embodiment, the first support surface 51 is spherical and the second support surface 52 is flat. Moreover, a magnet 56 is embedded in the fixing pad 5 . As can be seen from FIGS. 3 and 5 , the locking frame 55 comprises a pair of abutments 57 for supporting the protrusions 53 thereon, and a latch 61 connected with a pusher 6 . The latch 61 can be caught into the recess 54 of the fixing pad 5 and lock the fixing pad 5 in the locking frame 55 . The pusher 6 is used to pull back the latch 61 and thereby release the fixing pad 5 . Various articles having corresponding attaching surfaces of different shapes can be attached to the fixing device 100 because of the above-mentioned fixing pad 5 . As shown in FIG. 9 , a laser level 110 (or other light generating device) is attached on the fixing device 100 of the present invention. The laser level 110 comprises a concave spherical bottom surface, which can engage with and be attracted to the convex spherical top surface 51 of the fixing pad 5 , such that the laser level 110 can be turned in the direction of arrow 111 and is inclinable in the direction as shown by arrow 112 , thereby the laser line L 1 can be adjusted in all directions

**[p0012]**

. For example, the laser level 110 can be rotated up to 360 degrees with respect to the housing 1 of the fixing device 100 . Persons skilled in the art are directed to the laser level 110 disclosed in CN Patent No. ZL 200420028106.4, which is wholly incorporated by reference herein.

**[p0013]**

With reference to FIG. 10 , another laser level 120 with a flat bottom surface is attached on the second support surface 52 of the fixing pad 5 . The laser level 120 includes a rotating mechanism coupled to a laser generator. The rotating mechanism can be turned in the direction as shown by arrow 121 with the laser line L 2 being rotatable from a substantially horizontal reference line to a substantially vertical reference line. A laser level of this type is disclosed in U.S. Patent Application Publication No. 2004/0123472 A1, which is fully incorporated herein by reference. In addition to being used to attach a laser level 110 or 120 on a wall, the fixing device 100 is also used for supporting other articles. For example, as shown in FIG. 11 , the fixing device 100 can be used to support a laser target 130 on a wall surface for use with any conventional distance measuring device. Moreover, the fixing device 100 can be equipped with a hook, a latch, a groove or recess and the like for carrying and/or supporting articles of other shapes.

**[p0014]**

As shown in FIGS. 6 and 7 , in order to quickly and easily remove the fixing device 100 from the surface on which it has been attached, the top 220 of the suction cup 2 comprises an air inlet 21 connected with one end of an air intake conduit 81 . The other end of conduit 81 is connected to a valve 400 . When the valve 400 is opened, the space 210 is in communication with the atmosphere via pipe 81 . Accordingly, air is permitted to enter into the space 210 via the air inlet 21 so that the vacuum in the space 210 is broken. At this time, a user can easily remove the fixing device 100 from the surface. Referring now to FIG. 7 , the valve 400 will be described in great detail hereinafter. The valve 400 includes a valve body 42 , which is closely fitted within the conduit 81 and has a stepped internal chamber comprising a first chamber 421 and a second chamber 422 . The inner diameter of the first chamber 421 is smaller than the inner diameter of the second chamber 422 . Furthermore, a screw 45 is fixed on the distal end of the second chamber 422 of the valve body 42 . An axial slot 46 is provided on the wall of the valve body 42 for communication between the conduit 81 and the second chamber 422 . And a spring is compressed in the second chamber 422 with one end biasing on a valve plug, which is preferably a steel ball 43 . The steel ball 43 blocks the valve port 423 between the first chamber 421 and second chamber 422 under the biasing force of the spring 44 so that the air communication between the second chamber 422 and the first chamber 421 , and consequently the atmosphe

**[p0014]**

re, is blocked. Therefore, the second chamber 422 , conduit 81 and space 210 in the suction cup 2 form a serial sealed space. Further referring to FIG. 7 , a valve bar 41 is loosely inserted in the first chamber 421 of the valve body 42 with its free end being contactable to the ball 43 . A button 4 is provided on the other end of the bar 41 for the user&#39;s operation. When the button 4 is pressed, the ball 43 is pushed away from the valve port 423 by the bar portion 41 . Thus, the air enters into the space 210 in the suction cup 2 through the second chamber 422 , slot 46 and conduit 81 . As a result, the vacuum is broken.

**[p0015]**

As shown in FIGS. 2 and 8 , a control means is provided which includes a protrusion 23 extending downward from the top 220 of the suction cup 2 and a control rod 230 . The control rod 230 is disposed in the housing 1 with one end being supported on the top of the protrusion 23 and the other end extending through a spring 231 and being in contact with a trigger 232 . When the fixing device 100 is attached on a surface such as glass, glazed tile, painted wall and the like, the contact between the suction cup 2 and the surface will be very compact. When the vacuum pump 9 draws air out, the air pressure in the space 210 is decreased rapidly, and the distance between the top 220 of the suction cup 2 and the surface is reduced gradually. When the distance is reduced to a certain value, the downward protrusion 23 begins to be pressed upward so as to push up the control rod 230 and further to activate the trigger 232 , which will then shut down a power switch (not shown) and thus the vacuum pump 9 will stop working. Due to the close contact between the suction cup 2 and the surface, the vacuum in the space 210 cannot easily be broken even if the vacuum pump 9 is not operating. However, air will slightly flow into the space 210 more or less, and the space 210 will expand little by little. As this occurs, the protrusion 23 will free from being pressed by the attached surface, such that the control rod 230 will disengage from the trigger 232 , and the vacuum pump 9 will restart and maintain a vacuum seal between the suction cup 2 and the surface. With such a control mechanism, energy-

**[p0015]**

savings can be effectively achieved.

**[p0016]**

The fixing device 100 can also be integrated in a single unit with some objects usually used on a wall surface. While the invention has been described and illustrated in the preferred embodiment, the description and illustration is exemplary and explanatory but not intended to limit the invention to the extent disclosed herein. It is obvious that those who are skilled in this field may make changes and modifications without departing from the spirit and scope of the invention. Therefore, all changes and modifications based on the innovation of the invention all fall in the invention&#39;s scope claimed in the appended claims.

## Figure captions

- **Figure 1:** FIG. 1 is a perspective view of a general appearance of a preferred embodiment of the fixing device with a suction cup according to the present invention;
- **Figure 2:** FIG. 2 is another perspective view of the fixing device shown in FIG. 1 ;
- **Figure 3:** FIG. 3 is a perspective view of the fixing device shown in FIG. 1 , with the fixing pad being separated alongside;
- **Figure 4:** FIG. 4 is a perspective view of the fixing pad when it is turned over from the position as shown in FIG. 3 ;
- **Figure 5:** FIG. 5 is a perspective view of the fixing device with a portion of the housing removed away;
- **Figure 6:** FIG. 6 is a perspective view of a portion of the fixing device, wherein the suction cup is sectioned;
- **Figure 7:** FIG. 7 is a side view of some components of the fixing device, wherein the valve is sectioned;
- **Figure 8:** FIG. 8 is an interior cross-sectional view of the fixing device shown in FIG. 1 ;
- **Figure 9:** FIG. 9 is a perspective view of the fixing device shown in FIG. 1 , with a laser level supported thereon;
- **Figure 10:** FIG. 10 is a perspective view of the fixing device with another laser level carried thereon; and
- **Figure 11:** FIG. 11 is a perspective view of the fixing device with a laser target carried thereon.

## Classifications

- F16B47/00
- F16B47/00
- F16B47/00
- A45D42/14
- F21V21/092

## Cited patent documents

- [US-2002043599-A1](https://patents.google.com/patent/US20020043599A1/en) — PRS
- [US-2007101594-A1](https://patents.google.com/patent/US20070101594A1/en) — PRS
- [US-4753212-A](https://patents.google.com/patent/US4753212A/en) — PRS
- [US-6536250-B1](https://patents.google.com/patent/US6536250B1/en) — PRS
- [US-6841726-B2](https://patents.google.com/patent/US6841726B2/en) — PRS
- [US-7191532-B2](https://patents.google.com/patent/US7191532B2/en) — PRS

---

Generated by IPtorch. Verify legal conclusions against the official publication.
