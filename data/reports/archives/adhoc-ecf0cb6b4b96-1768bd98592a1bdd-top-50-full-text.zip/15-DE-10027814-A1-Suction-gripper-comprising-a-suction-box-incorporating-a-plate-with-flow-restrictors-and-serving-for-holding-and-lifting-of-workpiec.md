# 15. Suction gripper comprising a suction box incorporating a plate with flow restrictors, and serving for holding and lifting of workpieces , is provided with an illuminating unit

- **Archive rank:** 15 of 50
- **Publication:** [DE-10027814-A1](https://patents.google.com/patent/DE10027814A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/007644760/publication/DE10027814A1?q=pn%3DDE10027814A1)
- **Publication date:** 2001-12-13
- **Filing date:** 2000-06-05
- **Earliest priority:** 2000-06-05
- **Family:** 7644760
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** SCHMALZ J GMBH
- **Inventors:** EISELE THOMAS; GRAF THOMAS; SCHMALZ KURT

## Abstract

The suction gripper (10) comprising a suction box incorporating a plate with flow restrictors (22), and serving for holding and lifting of workpieces , is provided with an illuminating unit (34).

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-10027814-A1/ops000.png)

![Sketch 1 for DE-10027814-A1](https://nimo.iptorch.com/refdrawing/DE-10027814-A1/ops000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-10027814-A1/ops001.png)

![Sketch 2 for DE-10027814-A1](https://nimo.iptorch.com/refdrawing/DE-10027814-A1/ops001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/DE-10027814-A1/ops002.png)

![Sketch 3 for DE-10027814-A1](https://nimo.iptorch.com/refdrawing/DE-10027814-A1/ops002.png)

## Claims

### Claim 1 (independent)

Sauggreifer zum Ansaugen und Anheben von Werkstücken, mit einem einen Hohlraum (18) aufweisenden Saugkasten (16), wobei der Hohlraum (18) mit einer Unterdruck­ quelle in Verbindung steht und an seiner dem oder den Werkstücken zugewandten Seite eine Platte (20) auf­ weist, die insbesondere mit Strömungswiderständen (22), Ventilen, Einzelsaugern oder dergleichen ver­ sehen ist, dadurch gekennzeichnet, dass der Saug­ greifer (10) mit einer Beleuchtungseinrichtung (34) versehen ist.1. Suction gripper for sucking and lifting workpieces, with a suction box ( 16 ) having a cavity ( 18 ), the cavity ( 18 ) being connected to a vacuum source and a plate ( 20 ) on its side facing the workpiece (s) has, which is seen in particular with flow resistances ( 22 ), valves, individual suction cups or the like, characterized in that the suction gripper ( 10 ) is provided with a lighting device ( 34 ).

### Claim 2

Sauggreifer nach Anspruch 1, dadurch gekennzeichnet, dass die z. B. mit Strömungswiderständen (22) versehene Platte (20) einen mehrschichtigen Aufbau aufweist.2. Suction pad according to claim 1, characterized in that the z. B. with flow resistors ( 22 ) provided plate ( 20 ) has a multilayer structure.

### Claim 3

Sauggreifer nach Anspruch 2, dadurch gekennzeichnet, dass wenigstens eine Schicht (28, 32) der Platte (20) flexibel, insbesondere aus einem Elastomer ausgebildet ist.3. Suction pad according to claim 2, characterized in that at least one layer ( 28 , 32 ) of the plate ( 20 ) is flexible, in particular made of an elastomer.

### Claim 4

Sauggreifer nach Anspruch 2 oder 3, dadurch gekennzeichnet, dass wenigstens eine Schicht (24) der Platte (20) aus einem durchsichtigen oder durchscheinenden Material, z. B. Acrylglas oder Plexiglas, ausgebildet ist.4. suction pad according to claim 2 or 3, characterized in that at least one layer ( 24 ) of the plate ( 20 ) made of a transparent or translucent material, for. B. acrylic glass or plexiglass is formed.

### Claim 5

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass die Strömungswiderstände (22) von Löchern (26) gebildet werden.5. Suction gripper according to one of the preceding claims, characterized in that the flow resistances ( 22 ) are formed by holes ( 26 ).

### Claim 6

Sauggreifer nach Anspruch 5, dadurch gekennzeichnet, dass die Löcher (26) in einer regelmäßigen Anordnung in der Platte (20) vorgesehen sind.6. Suction pad according to claim 5, characterized in that the holes ( 26 ) are provided in a regular arrangement in the plate ( 20 ).

### Claim 7

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass bei einem mehrschichtigen Aufbau der Platte (20) die äußere Schichtlage (32) der Platte (20) mit einer Vielzahl von großen Öffnungen (30) und die innere Schichtlage (24) der Platte (20) mit einer Vielzahl von kleinen Öffnungen (26) zur Bildung der Strömungswiderstände (22), insbesondere der Löcher (26), versehen sind.7. Suction pad according to one of the preceding claims, characterized in that in a multilayer structure of the plate ( 20 ), the outer layer layer ( 32 ) of the plate ( 20 ) with a plurality of large openings ( 30 ) and the inner layer layer ( 24 ) Plate ( 20 ) with a plurality of small openings ( 26 ) to form the flow resistances ( 22 ), in particular the holes ( 26 ), are provided.

### Claim 8

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass die Beleuchtungseinrich­ tung (34) am Rand des Saugkastens (16) vorgesehen und in Richtung auf das anzusaugende Werkstück ausgerichtet ist. Suction gripper according to one of the preceding claims, characterized in that the illuminating device ( 34 ) is provided on the edge of the suction box ( 16 ) and is oriented in the direction of the workpiece to be sucked in.

### Claim 9

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass die Beleuchtungseinrich­ tung (34) in Ausschnitten vorgesehen ist, die in der Platte vorgesehen sind.9. Suction gripper according to one of the preceding claims, characterized in that the illuminating device ( 34 ) is provided in cutouts which are provided in the plate.

### Claim 10

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass die Beleuchtungseinrich­ tung (34) bezüglich der Ansaugebene des Saugkastens (16) zurückversetzt ist.10. Suction gripper according to one of the preceding claims, characterized in that the illuminating device ( 34 ) is set back with respect to the suction plane of the suction box ( 16 ).

### Claim 11

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass die Beleuchtungseinrich­ tung (34) innerhalb des Hohlraumes (18) angeordnet ist.11. Suction gripper according to one of the preceding claims, characterized in that the illuminating device ( 34 ) is arranged within the cavity ( 18 ).

### Claim 12

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass die Beleuchtungseinrichtung (34) eine Platine (42) mit daran befestigten Beleuchtungskörpern umfasst.12. Suction gripper according to one of the preceding claims, characterized in that the lighting device ( 34 ) comprises a circuit board ( 42 ) with lighting bodies attached to it.

### Claim 13

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass die Beleuchtungseinrichtung (34) eine oder mehrere Leuchtquellen, insbesondere LED, Halogenlampen, Neonlampen usw., aufweist. Suction gripper according to one of the preceding claims, characterized in that the lighting device ( 34 ) has one or more light sources, in particular LED, halogen lamps, neon lamps, etc.

### Claim 14

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass eine Licht leitende Platte vorgesehen ist, dass wenigstens eine Lichtquelle am Rand der Platte vorgesehen ist und dass die Platte eine Vielzahl von integrierten Prismen aufweist, über die Licht in Richtung auf das Werkstück ausgekoppelt wird.14. Suction gripper according to one of the preceding claims, characterized in that a light conducting Plate is provided that at least one Light source is provided on the edge of the plate and that the plate has a variety of integrated prisms has, via the light towards the workpiece is decoupled.

### Claim 15

Sauggreifer nach Anspruch 14, dadurch gekennzeichnet, dass die Prismen aufgesetzt oder eingeschliffen sind.15. Suction pad according to claim 14, characterized in that the prisms are attached or ground in.

### Claim 16

Sauggreifer nach Anspruch 14 oder 15, dadurch gekennzeichnet, dass die Platte parallel zur Ansaugebene des Saugkastens (16) angeordnet ist.16. Suction pad according to claim 14 or 15, characterized in that the plate is arranged parallel to the suction plane of the suction box ( 16 ).

### Claim 17

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass zusätzlich zur Beleuchtungseinrichtung (34) eine Kamera vorgesehen ist.17. Suction gripper according to one of the preceding claims, characterized in that a camera is provided in addition to the lighting device ( 34 ).

### Claim 18

Sauggreifer nach Anspruch 17, dadurch gekennzeichnet, dass die Kamera im Sauggreifer (10) integriert ist.18. Suction pad according to claim 17, characterized in that the camera is integrated in the suction pad ( 10 ).

## Full description

PERFORMING OPERATIONS; TRANSPORTINGHAND TOOLS; PORTABLE POWER-DRIVEN TOOLS; MANIPULATORSMANIPULATORS; CHAMBERS PROVIDED WITH MANIPULATION DEVICESGripping heads and other end effectorsGripping heads and other end effectors with vacuum or magnetic holding meansGripping heads and other end effectors with vacuum or magnetic holding means with vacuumPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippersPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansOperating and control devicesPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansRectangular or square shape

Description

Translated from German

Die Erfindung betrifft einen Sauggreifer zum Ansaugen und

Anheben von WerkstÃ¼cken, mit einem einen Hohlraum

aufweisenden Saugkasten, wobei der Hohlraum mit einer

Unterdruckquelle in Verbindung steht und an seiner, dem

oder den WerkstÃ¼cken zugewandten Seite eine Platte

aufweist, die insbesondere mit StÃ¶mungswiderstÃ¤nden,

Ventilen, Einzelsaugern oder dergleichen versehen ist.The invention relates to a suction pad for suction and

Lifting workpieces with a cavity

having suction box, the cavity with a

Vacuum source communicates and at his, the

or a plate facing the workpiece

has, in particular with flow resistance,

Valves, single suction devices or the like is provided.

Sauggreifer sind in vielfÃ¤ltigen AusfÃ¼hrungsformen bekannt.

Sie werden dazu benutzt, um GegenstÃ¤nde auf einfache Art

und Weise ansaugen und anheben und somit transportieren,

z. B. innerhalb eines Bearbeitungsprozesses umsetzen zu

kÃ¶nnen. Derartige Sauggreifer werden auch an Roboterarmen

befestigt, wobei der Roboter Ã¼ber eine Kamera mit

Bildauswertung selbstÃ¤ndig die Form und GrÃ¶Ãe und/oder

Position von WerkstÃ¼cken erkennt, diese ergreift und

umsetzt. Dabei hat sich herausgestellt, dass in nicht

optimal ausgeleuchteten RÃ¤umen Fehlfunktionen auftreten

kÃ¶nnen, da die Kamera die GegenstÃ¤nde nicht oder nur zum

Teil erkennt. Es wurde versucht, zusÃ¤tzlich zur Kamera eine

Beleuchtungseinrichtung am Roboterarm anzubringen, was

jedoch nur teilweise Abhilfe brachte, da der am Roboterarm

befestigte Sauggreifer die Ausleuchtung bzw. Beleuchtung

des WerkstÃ¼cks mitunter behindert.Suction cups are known in various forms.

They are used to store objects in a simple way

and suck in and lift and thus transport,

Â e.g. B. implement within a machining process

can. Such suction cups are also used on robot arms

attached, the robot using a camera with

Image evaluation independently the shape and size and / or

Detects the position of workpieces, grips them and

implements. It turned out that not

malfunctions occur in optimally illuminated rooms

can, since the camera can not or only for

Part recognizes. An attempt was made to add one to the camera

Attach lighting device to the robot arm, what

but only partially remedied, because the robot arm

attached suction cups the illumination or lighting

of the workpiece sometimes hindered.

Der Erfindung liegt daher die Aufgabe zugrunde, einen

Sauggreifer bereitzustellen, mit dem Fehlfunktionen,

insbesondere von Roboterarmen, vermindert werden bzw.

ausgeschlossen werden kÃ¶nnen.The invention is therefore based on the object

Provide suction pads with which malfunctions

robotic arms in particular, or

can be excluded.

Diese Aufgabe wird bei einem Sauggreifer der eingangs

genannten Art erfindungsgemÃ¤Ã dadurch gelÃ¶st, dass der

Sauggreifer mit einer Beleuchtungseinrichtung versehen ist.This task is the beginning of a suction pad

mentioned type solved according to the invention in that the

Suction cup is provided with a lighting device.

Wird die Beleuchtungseinrichtung direkt mit dem Sauggreifer

verbunden, dann steht der Sauggreifer der Ausleuchtung des

Raumes bzw. der Beleuchtung des Objektes nicht mehr im

Wege. AuÃerdem folgt die Beleuchtungseinrichtung jeder

Bewegung des Sauggreifers, unabhÃ¤ngig von den Bewegungen

des Roboterarmes.The lighting device is used directly with the suction pad

connected, then the suction pad stands for the illumination of the

Room or the lighting of the object no longer in the

Â Ways. In addition, the lighting device follows everyone

Movement of the suction cup, regardless of the movements

of the robot arm.

Bei einer Weiterbildung ist vorgesehen, dass die mit

StÃ¶mungswiderstÃ¤nden oder Ventilen versehene Platte einen

mehrschichtigen Aufbau aufweist. In der Regel besteht die

Platte aus einem formsteifen ersten Element und einem

flexiblen, eine Dichtung darstellenden zweiten Element, Ã¼ber

welches der Sauggreifer am einzusaugenden Gegenstand

anliegt. Mittels des ersten Elements werden die KrÃ¤fte

aufgenommen bzw. abgestÃ¼tzt und mittels des zweiten

Elements wird der im Hohlraum erzeugte Unterdruck

aufrechterhalten bzw. wird die Leckage auf ein Minimum

reduziert. Dieses zweite Element weist wenigstens eine

Schicht aus einem flexiblen Material, insbesondere aus

einem Elastomer, auf. HierfÃ¼r kann z. B. Moosgummi oder ein

Schwammmaterial, z. B. Zellkautschuk, verwendet werden.In a further training it is provided that the with

Flow resistors or valves provided one

has a multilayer structure. Usually there is

Plate made of a dimensionally stable first element and one

flexible second element constituting a seal, via

which of the suction pads on the object to be sucked in

is present. Forces are created using the first element

recorded or supported and by means of the second

Element is the negative pressure generated in the cavity

the leakage is maintained or minimized

reduced. This second element has at least one

Layer made of a flexible material, in particular

an elastomer. For this, e.g. B. foam rubber or a

Sponge material, e.g. B. cellular rubber can be used.

Bei einer Weiterbildung ist vorgesehen, dass das erste

Element bzw. die erste Schicht aus einem durchsichtigen

oder durchscheinenden Material, z. B. aus Acrylglas oder

Plexiglas, ausgebildet ist. Es besteht jedoch auch die

MÃ¶glichkeit, dass die erste Schicht aus einem Lochblech

besteht.

In a further development it is provided that the first

Element or the first layer of a transparent

or translucent material, e.g. B. made of acrylic glass or

Plexiglass, is formed. However, there is also

Possibility that the first layer of perforated sheet

consists.

Â

Die StrÃ¶mungswiderstÃ¤nde werden bei einem bevorzugten

AusfÃ¼hrungsbeispiel von LÃ¶chern gebildet, die einen

bestimmten Querschnitt aufweisen. Der Querschnitt ist so

gewÃ¤hlt, dass auch bei Nichtbelegung der LÃ¶cher der

Unterdruck im Hohlraum nicht zusammenbricht. Hierdurch wird

gewÃ¤hrleistet, dass einmal angesaugte GegenstÃ¤nde auf jeden

Fall vom Sauggreifer angehalten werden.The flow resistances are preferred

Embodiment formed by holes that a

have a certain cross-section. The cross section is like this

chosen that even if the holes of the

Vacuum in the cavity does not collapse. This will

ensures that once vacuumed objects on everyone

Case are stopped by the suction pad.

Die LÃ¶cher sind bevorzugterweise in einer regelmÃ¤Ãigen

Anordnung in der Platte vorgesehen. Bei einem

mehrschichtigen Aufbau der Platte weist die Ã¤uÃere

Schichtlage der Platte eine Vielzahl von groÃen Ãffnungen

und weist die innere Schichtlage der Platte eine Vielzahl

von kleinen Ãffnungen zur Bildung der StrÃ¶mungswiderstÃ¤nde

auf. Die groÃen Ãffnungen dienen dazu, dass die WerkstÃ¼cke

Ã¼ber eine mÃ¶glichst groÃe FlÃ¤che angesaugt und dadurch

mÃ¶glichst groÃe AnsaugkrÃ¤fte erzielt werden.The holes are preferably regular

Arrangement provided in the plate. At a

multilayer structure of the plate shows the outer

Layer of the plate a variety of large openings

and the inner layer layer of the plate has a plurality

of small openings to form the flow resistances

on. The large openings serve for the workpieces

sucked in over the largest possible area and thereby

suction forces as large as possible can be achieved.

Eine Variante sieht vor, dass die Beleuchtungseinrichtung

am Rand des Saugkastens vorgesehen und in Richtung auf das

anzusaugende WerkstÃ¼ck ausgerichtet ist. Auf diese Weise

kann das WerkstÃ¼ck direkt angestrahlt werden, wobei die

Strahlen vom Saugkasten nicht behindert werden. AuÃerdem

wird eine optimale Ausleuchtung erzielt, da die

anzusaugende FlÃ¤che direkt angestrahlt wird.

A variant provides that the lighting device

provided at the edge of the suction box and towards the

workpiece to be sucked is aligned. In this way

the workpiece can be illuminated directly, the

Beams from the suction box are not obstructed. Moreover

optimal illumination is achieved because the

surface to be suctioned is illuminated directly.

Â

Eine andere Variante sieht vor, dass die

Beleuchtungseinrichtung in in der Platte vorgesehenen

Ausschnitten angeordnet sind. Diese Variante kann auch

zusÃ¤tzlich zur vorgenannten Variante an einem Sauggreifer

verwirklicht sein. Die in der Platte angeordnete

Beleuchtungseinrichtung bzw. in die Platte integrierte

Beleuchtungseinrichtung bietet den wesentlichen Vorteil,

dass das anzusaugende WerkstÃ¼ck gleichmÃ¤Ãig beleuchtet

werden kann, und zwar unabhÃ¤ngig von der GrÃ¶Ãe der Platte.Another variant provides that the

Lighting device provided in the plate

Cutouts are arranged. This variant can also

in addition to the aforementioned variant on a suction pad

be realized. The one arranged in the plate

Lighting device or integrated in the plate

Lighting device offers the main advantage

that the workpiece to be sucked in is evenly illuminated

regardless of the size of the plate.

Eine Weiterbildung sieht vor, dass die BeleuchtungseinÂ­

richtung bezÃ¼glich der Ansaugebene des Saugkastens

zurÃ¼ckversetzt ist. Dadurch wird das Ansetzen bzw.

Aufsetzen des Saugkastens auf das anzusaugende WerkstÃ¼ck

nicht behindert; auÃerdem wird die Beleuchtungseinrichtung

bzw. wird das bzw. werden die WerkstÃ¼cke beim Aufsetzen des

Sauggreifers nicht beschÃ¤digt.A further training provides that the lighting

direction with regard to the suction level of the suction box

is set back. This means that

Place the suction box on the workpiece to be suctioned

not disabled; also the lighting device

or will that or the workpieces when placing the

Suction pad not damaged.

Eine andere AusfÃ¼hrungsform sieht vor, dass die

Beleuchtungseinrichtung innerhalb des Hohlraumes angeordnet

ist. Diese Beleuchtungseinrichtung scheint durch die Platte

auf das anzusaugende WerkstÃ¼ck, was den wesentlichen

Vorteil hat, dass die Beleuchtungseinrichtung gleichmÃ¤Ãig

Ã¼ber die FlÃ¤che der Platte verteilt angeordnet sein kann

und dass die Beleuchtungseinrichtung gegen BeschÃ¤digung

geschÃ¼tzt ist. Das Durchleuchten der Platte stellt

keinerlei Probleme dar, wenn die Platte aus einem durchÂ­

sichtigen oder durchscheinenden Material, z. B. aus AcrylÂ­

glas oder Plexiglas, besteht. Die Beleuchtungseinrichtung

kann z. B. eine Platine mit daran befestigten

BeleuchtungskÃ¶rpern umfassen. Die BeleuchtungskÃ¶rper sind

z. B. Leuchtdioden, Halogenlampen, GlÃ¼hlampen, Neonlampen

od. dgl.. Bevorzugt werden jedoch LeuchtkÃ¶rper, die relativ

wenig WÃ¤rme entwickeln.Another embodiment provides that the

Lighting device arranged within the cavity

is. This lighting device shines through the plate

on the workpiece to be sucked, which is the essential

The advantage is that the lighting device is even

can be arranged distributed over the surface of the plate

and that the lighting device against damage

is protected. The plate is illuminated

Â no problems if the plate from a through

visible or translucent material, e.g. B. made of acrylic

glass or plexiglass. The lighting device

can e.g. B. a board with attached

Include lighting fixtures. The lighting fixtures are

e.g. B. light emitting diodes, halogen lamps, incandescent lamps, neon lamps

od. Like .. However, preference is given to luminous elements that are relative

develop little heat.

Eine weitere Variante der Erfindung sieht vor, dass eine

Licht leitende Platte vorgesehen ist, dass wenigstens eine

Lichtquelle am Rand der Platte vorgesehen ist und dass die

Platte eine Vielzahl von integrierten Prismen aufweist,

Ã¼ber die das durch den Rand in die Platte eingespeiste

Licht in Richtung auf das WerkstÃ¼ck ausgekoppelt wird. Die

Platte dient bei diesem AusfÃ¼hrungsbeispiel als

Lichtleiter, der das Licht exakt an den Stellen auskoppelt,

wo die Beleuchtung des WerkstÃ¼cks erfolgen soll.Another variant of the invention provides that a

Light-conducting plate is provided that at least one

Light source is provided on the edge of the plate and that the

Plate has a variety of integrated prisms

over which the fed through the edge into the plate

Light is coupled out towards the workpiece. The

Plate serves as in this embodiment

Light guide, which couples the light exactly at the points,

where the workpiece is to be illuminated.

SelbstverstÃ¤ndlich kann die Lichtquelle auch an einem

anderen Ort als am Rand vorgesehen sein, wobei dann zum

Einkoppeln des Lichts in die Platte ebenfalls ein Prisma

erforderlich ist.Of course, the light source can also be on one

be provided other than on the edge, then to

Coupling the light into the plate is also a prism

is required.

ErfindungsgemÃ¤Ã sind die Prismen aufgesetzt oder in die

Platte eingeschliffen. Die Platte ist in bevorzugter Weise

parallel zu einer Saugebene angeordnet und weist die die

StrÃ¶mungswiderstÃ¤nde bildenden LÃ¶cher auf.According to the invention, the prisms are placed on or in the

Ground in plate. The plate is preferred

Â arranged parallel to a suction plane and has the

Holes forming flow resistance.

Weitere Vorteile, Merkmale und Einzelheiten der Erfindung

ergeben sich aus den UnteransprÃ¼chen sowie der

nachfolgenden Beschreibung, in der unter Bezugnahme auf die

Zeichnung besonders bevorzugte AusfÃ¼hrungsbeipiele im

Einzelnen beschrieben sind. Dabei kÃ¶nnen die in der

Zeichnung dargestellten sowie in den AnsprÃ¼chen und in der

Beschreibung erwÃ¤hnten Merkmale jeweils einzeln fÃ¼r sich

oder in beliebiger Kombination erfindungswesentlich sein.Further advantages, features and details of the invention

result from the subclaims and the

following description, in which with reference to the

Drawing particularly preferred exemplary embodiments in

Individuals are described. The in the

Drawing shown as well as in the claims and in the

Description mentioned features each individually

or be essential to the invention in any combination.

In der Zeichnung zeigen:The drawing shows:

Fig. 1 eine Sicht auf die Unterseite eines ersten

AusfÃ¼hrungsbeispiels eines Sauggreifers mit am

Rand vorgesehener Beleuchtungseinrichtung; Fig. 1 is a view of the underside of a first embodiment of a suction pad provided at the edge with the illumination device;

Fig. 2 eine Seitenansicht des Sauggreifers gemÃ¤Ã Fig. 1; FIG. 2 shows a side view of the suction pad according to FIG. 1;

Fig. 3 einen Schnitt III-III gemÃ¤Ã Fig. 4 durch eine

zweite AusfÃ¼hrungsform eines Sauggreifers, die

Ansaugseite zeigend; Fig. 3 shows a section III-III according to Fig 4 showing a second embodiment of a suction gripper, the suction side.

Fig. 4 eine Seitenansicht des Sauggreifers gemÃ¤Ã Fig. 3;

FIG. 4 shows a side view of the suction gripper according to FIG. 3;

Fig. 5 einen Schnitt V-V gemÃ¤Ã Fig. 6 durch eine dritte

AusfÃ¼hrungsform eines Sauggreifers, die

Ansaugseite zeigend; und Fig. 5 is a section VV according to Figure 6 showing a third embodiment of a suction gripper, the suction side. and

Fig. 6 eine Seitenansicht des Sauggreifers gemÃ¤Ã Fig. 5. Fig. 6 is a side view of the suction pad according to Fig. 5.

Die Fig. 1 und 2 zeigen ein erstes AusfÃ¼hrungsbeispiel

eines insgesamt mit 10 bezeichneten Sauggreifers, der zum

Ansaugen eines oder mehrerer WerkstÃ¼cke dient. Dieser

Sauggreifer 10 kann Ã¼ber eine Kupplung 12 mit einem (nicht

dargestellten) Roboterarm verbunden werden und wird Ã¼ber

diesen manipuliert. An der Oberseite des Sauggreifers 10

ist ein Absaugstutzen 14 vorgesehen, Ã¼ber welchen der

Sauggreifer 10 mit einer Unterdruckquelle verbunden wird.

Dieser Absaugstutzen 14 sitzt auf einem Saugkasten 16 auf,

der einen Hohlraum 18 umgibt. Die Unterseite des Hohlraums

18 ist von einer mehrschichtigen Platte 20 abgedeckt, die

ihrerseits eine Vielzahl von StrÃ¶mungswiderstÃ¤nden 22

aufweist. Die mehrschichtige Platte 20 besitzt eine erste

Schicht 24, die von einer biegesteifen Platte gebildet

wird. Diese biegesteife Platte besteht aus Metall oder

einem steifen Kunststoff, der insbesondere durchsichtig

oder durchscheinend ist. In dieser ersten Schicht 24 wird

der StrÃ¶mungswiderstand 22 von einer Vielzahl von LÃ¶chern

26 gebildet, die einen kleinen Querschnitt aufweisen. Figs. 1 and 2 show a first embodiment of a suction gripper, generally designated 10, which serves for drawing one or several workpieces. This suction gripper 10 can be connected via a coupling 12 to a robot arm (not shown) and is manipulated via this. At the top of the suction gripper 10 , a suction nozzle 14 is provided, via which the suction gripper 10 is connected to a vacuum source. This suction nozzle 14 sits on a suction box 16 which surrounds a cavity 18 . The underside of the cavity 18 is covered by a multilayer plate 20 , which in turn has a large number of flow resistances 22 . The multilayer plate 20 has a first layer 24 , which is formed by a rigid plate. This rigid plate is made of metal or a rigid plastic, which is particularly transparent or translucent. In this first layer 24 , the flow resistance 22 is formed by a plurality of holes 26 , which have a small cross section.

Unterhalb der ersten Schicht 24 befindet sich eine mittlere

Schicht 28, die z. B. aus einem elastischen Material,

insbesondere einem Elastomer, hergestellt ist. Es eignet

sich hier insbesondere ein Schwammmaterial, um beim

Ansaugen mehrerer GegenstÃ¤nde HÃ¶hentoleranzen der einzelnen

GegenstÃ¤nde auf einfache Weise ausgleichen zu kÃ¶nnen. Diese

mittlere Schicht 28 ist an die erste Schicht 24 angeklebt

und weist zu den LÃ¶chern 26 der ersten Schicht 24

korrespondierende Ãffnungen 30 auf, die einen groÃen

Querschnitt besitzen und insbesondere rechteckfÃ¶rmig

ausgebildet sind. Diese Ãffnungen 30 bilden kleine

Saugkammern mit relativ groÃer FlÃ¤che, so dass das

anzusaugende WerkstÃ¼ck mit einer grÃ¶ÃtmÃ¶glichen Kraft

angesaugt werden kann.Below the first layer 24 is a middle layer 28 which, for. B. is made of an elastic material, in particular an elastomer. A sponge material is particularly suitable here in order to be able to easily compensate for height tolerances of the individual objects when sucking in several objects. This middle layer 28 is glued to the first layer 24 and has openings 30 corresponding to the holes 26 of the first layer 24 , which have a large cross section and are in particular rectangular. These openings 30 form small suction chambers with a relatively large area, so that the workpiece to be sucked in can be sucked in with the greatest possible force.

Unterhalb der mittleren Schicht 28 befindet sich eine

weitere Schicht 32, die ebenfalls aus einem elastischen

Material besteht. Es eignet sich hierfÃ¼r insbesondere eine

Zellkautschukmatte, die ebenfalls mit Ãffnungen versehen

ist, die zu den Ãffnungen 30 korrespondieren. Die

Zellkautschukmatte besteht aus einem geschlossenzelligen

Werkstoff.Below the middle layer 28 is a further layer 32 , which also consists of an elastic material. A cellular rubber mat, which is also provided with openings that correspond to the openings 30 , is particularly suitable for this purpose. The cellular rubber mat is made of a closed-cell material.

Es besteht jedoch auch die MÃ¶glichkeit, dass die mittlere

Schicht 28 mit kleinen Ãffnungen, die zu den LÃ¶chern 26 der

ersten Schicht 24 korrespondieren, versehen ist und

lediglich die weitere Schicht 32 groÃe Ãffnungen aufweist.

However, there is also the possibility that the middle layer 28 is provided with small openings, which correspond to the holes 26 of the first layer 24 , and only the further layer 32 has large openings.

Aus den Fig. 1 und 2 ist deutlich erkennbar, dass am Rand

des Saugkastens 16, insbesondere an dessen Unterseite, eine

Beleuchtungseinrichtung 34 vorgesehen ist, die beim

dargestellten AusfÃ¼hrungsbeispiel aus insgesamt vier

Leuchtpaketen 36 gebildet wird. Diese Leuchtpakete 36

werden ihrerseits von einer Vielzahl von Leuchtdioden

gebildet, die vorzugsweise auf einer Platine angeordnet

sind. Die Leuchtpakete 36 sind symmetrisch angeordnet, so

dass eine gleichmÃ¤Ãige Ausleuchtung erzielt wird.From Figs. 1 and 2 is clearly seen that, formed in the illustrated embodiment a total of four light-emitting packages 36 at the edge of the suction box 16, in particular on its underside, a lighting device 34 is provided. These light packages 36 are in turn formed by a large number of light-emitting diodes, which are preferably arranged on a circuit board. The light packages 36 are arranged symmetrically so that uniform illumination is achieved.

In Fig. 1 ist auÃerdem ein zentraler, am Saugkasten 16

montierter Turm 38 erkennbar, in welchem eine (nicht

dargestellte) Kamera angeordnet ist, die durch eine in der

Platte 20 vorgesehene Ãffnung 40 auf das anzusaugende

WerkstÃ¼ck gerichtet ist.In Fig. 1 further comprises a central, mounted on the suction box 16 tower 38 can be seen in which a (not shown) camera is arranged, which is directed through an opening provided in the plate 20 opening 40 to be sucked to the workpiece.

Die Fig. 3 und 4 zeigen ein zweites AusfÃ¼hrungsbeipiel des

erfindungsgemÃ¤Ãen Sauggreifers 10, bei welchem innerhalb

des Hohlraums 18 die Beleuchtungseinrichtung 34 angeordnet

ist. Bei diesem AusfÃ¼hrungsbeispiel besteht die

Beleuchtungseinrichtung 34 aus einer oder mehreren Platinen

42, an welchen die Leuchtmittel in Form von Leuchtdioden,

Halogenlampen, Neonlampen od. dgl. vorgesehen sind. Die

Lichtstrahlen treten entweder durch die in der ersten

Schicht 24 vorgesehenen LÃ¶cher 26 aus oder durch die

gesamte erste Schicht 24, sofern diese durchsichtig oder

durchscheinend ist. Durch die Luftabsaugung Ã¼ber den

Absaugstutzen 14 erfahren die Platinen 42 eine ausreichende

KÃ¼hlung. FIGS. 3 and 4 show a second embodiment of the suction gripper Example 10 of the invention in which within the cavity 18, the lighting device 34 is disposed. In this exemplary embodiment, the lighting device 34 consists of one or more circuit boards 42 , on which the illuminants are provided in the form of light-emitting diodes, halogen lamps, neon lamps or the like. The light rays exit either through the holes 26 provided in the first layer 24 or through the entire first layer 24 , provided that this is transparent or translucent. The circuit boards 42 are adequately cooled due to the air extraction via the suction connection 14 .

Die Fig. 5 und 6 zeigen ein drittes AusfÃ¼hrungsbeispiel des

erfindungsgemÃ¤Ãen Sauggreifers 10, bei dem im Hohlraum 18

ebenfalls die Beleuchtungseinrichtung 34 angeordnet ist,

die bei diesem AusfÃ¼hrungsbeispiel jedoch von Halogen- oder

Neonlampen gebildet wird. Auch hier erfahren die

Leuchtmittel eine ausreichende KÃ¼hlung durch die Ã¼ber den

Absaugstutzen 14 abgesaugte Luft. FIGS. 5 and 6 show a third embodiment of the vacuum gripper 10 of the invention, the illumination device in which the cavity 18 is also arranged 34, which is however formed in this embodiment from halogen or neon. Here, too, the illuminants are adequately cooled by the air drawn off via the suction connection 14 .

## Classifications

- B25J15/0616
- B25J15/06
- B65G47/91
- B65G47/91
- B66C1/0256
- B66C1/0281

## Cited patent documents

- [DE-19613516-A1](https://patents.google.com/patent/DE19613516A1/en) — SEA
- [DE-4032857-C1](https://patents.google.com/patent/DE4032857C1/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
