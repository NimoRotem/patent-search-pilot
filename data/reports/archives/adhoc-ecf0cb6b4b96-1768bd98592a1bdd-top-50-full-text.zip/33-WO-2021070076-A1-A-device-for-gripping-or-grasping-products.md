# 33. A device for gripping or grasping products

- **Archive rank:** 33 of 50
- **Publication:** [WO-2021070076-A1](https://patents.google.com/patent/WO2021070076A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/069701304/publication/WO2021070076A1?q=pn%3DWO2021070076A1)
- **Publication date:** 2021-04-15
- **Filing date:** 2020-10-07
- **Earliest priority:** 2019-10-08
- **Family:** 69701304
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery

## Parties

- **Applicant / assignee:** PULSAR SRL
- **Inventors:** FRANZAROLI MASSIMO

## Abstract

A device (10) for gripping or grasping products (11), said products being in particular in the form of packages, in a preferred manner defined by a corresponding envelope, for example made of a plastic film, or a paper sheet, or other, or made of cardboard which wraps or contains one or more articles; in particular said articles being articles of the so-called Tissue field and preferably being made of paper material or other material, such as woven fabric or non-woven fabric, and preferentially being in the form of rolls, in particular rolls of toilet paper, of kitchen paper or for another use, or rolls for the treatment of food products, such as rolls of aluminium foil, plastic film, wax paper film, and the like, i.e., said articles being in the form of packaging, in particular packs, packets or other containers, in particular for napkins, handkerchiefs, small towels for hands and face, hand towels, bed sheets, and other. The device comprises supporting means (12) for means (14) for engaging and holding by suctioning the respective product (11). Said means (14) for engaging and holding by suctioning the respective product (11) define a first (141) and a second (142) surfaces for engaging and holding by suctioning the same product (11), in particular angularly spaced apart, preferably angularly spaced by an angle equal to, or substantially equal to, 90°.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf000.png)

![Sketch 1 for WO-2021070076-A1](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf001.png)

![Sketch 2 for WO-2021070076-A1](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf002.png)

![Sketch 3 for WO-2021070076-A1](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf003.png)

![Sketch 4 for WO-2021070076-A1](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf004.png)

![Sketch 5 for WO-2021070076-A1](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf005.png)

![Sketch 6 for WO-2021070076-A1](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf006.png)

![Sketch 7 for WO-2021070076-A1](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf007.png)

![Sketch 8 for WO-2021070076-A1](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf008.png)

![Sketch 9 for WO-2021070076-A1](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf009.png)

![Sketch 10 for WO-2021070076-A1](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf009.png)

[Sketch 11](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf010.png)

![Sketch 11 for WO-2021070076-A1](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf010.png)

[Sketch 12](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf011.png)

![Sketch 12 for WO-2021070076-A1](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf011.png)

[Sketch 13](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf012.png)

![Sketch 13 for WO-2021070076-A1](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf012.png)

[Sketch 14](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf013.png)

![Sketch 14 for WO-2021070076-A1](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf013.png)

[Sketch 15](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf014.png)

![Sketch 15 for WO-2021070076-A1](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf014.png)

[Sketch 16](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf015.png)

![Sketch 16 for WO-2021070076-A1](https://nimo.iptorch.com/refdrawing/WO-2021070076-A1/pdf015.png)

## Claims

### Claim 1

CLAIMS 1. A device (10) for gripping or grasping products, said products being in particular in the form of packages, in a preferred manner defined by a corresponding envelope, for example made of a plastic film, ora paper sheet, or other, or made of cardboard, which wraps or contains one or more articles; in particular said articles being articles of the so-called Tissue field and preferably being made of paper material or other material, such as woven fabric or non-woven fabric, and preferentially being in the form of rolls, in particular rolls of toilet paper, of kitchen paper or for another use, or rolls for the treatment of food products, such as rolls of aluminium foil, plastic film, wax paper film, and the like, i.e. , said articles being in the form of packaging, in particular packs, packets or other containers, in particular for napkins, handkerchiefs, small towels for hands and face, hand towels, bed sheets, sanitary napkins for personal care; the device comprising support means (12) for means (14) for engaging and holding by suctioning the respective product and being characterized in that said means (14) for engaging and holding by suctioning the respective product define a first (141) and a second (142) surfaces for engaging and holding by suctioning the same product, in particular angularly spaced apart, preferably angularly spaced by an angle equal to, or substantially equal to, 90°. 2. The device according to claim 1, characterized in that said first and second surfaces (141, 142) for engaging and holding by suctioning the same product are adapted to engage respective faces of the product to be grasped, in particular angularly spaced apart faces, and preferably mutually adjacent, of said product, and preferably faces of said product that are angularly spaced apart by an angle equal to, or substantially equal to, 90°. 3. The device according to any of the preceding claims, characterized in that said first surface (141) for engaging and holding by suctioning the same product is adapted to engage the upper surface of the product. 4. The device according to claim 3, characterized in that said first surface (141) for engaging and holding by suctioning the same product is adapted to engage the upper surface of the product at a central, or substantially central, zone thereof. 5. The device according to any of the preceding claims, characterized in that said second surface (142) for engaging and holding by suctioning the same product is adapted to engage a side surface of the same product. 6. The device according to claim 5, characterized in that said second surface (142) for engaging and holding by suctioning the same product is adapted to engage the side surface of the corresponding product in the proximity of the upper surface of the same product. 7. The device according to any of the preceding claims, characterized in that said first surface (141) for engaging and holding by suctioning the same product has a respective longitudinal extension (11) that is greater than the longitudinal extension (12) of said second engaging surface (142). 8. The device according to any of the preceding claims, characterized in that said first surface (141) for engaging and holding by suctioning the same product has a respective transversal extension (t1 ) that is lesser than the corresponding transversal extension (t2) of said second engaging surface (142). 9. The device according to any of the preceding claims, characterized in that said supporting means (12) define corresponding suctioning chamber means (16) upstream of said first and second surfaces (141 , 142) for engaging and holding by suctioning the same product. 10. The device according to claim 9, characterized in that said suctioning chamber means (16) comprise corresponding first and second suctioning chambers (161 , 162) respectively upstream of said first and second surfaces (141, 142) for engaging and holding by suctioning the same product. 11. The device according to any of the preceding claims, characterized in that said supporting means (12) of the device (10) comprise a first and a second supporting bodies (121, 122) respectively for said first and second surfaces (141 , 142) for engaging and holding by suctioning the same product. 12. The device according to claim 11 , characterized in that said first and second bodies (121, 122) respectively for supporting said first and second surfaces (141, 142) for engaging and holding by suctioning the same product define a respective suctioning chamber (161 or 162) upstream of the respective surface (141, 142) for engaging and holding by suctioning the same product (141, 142). 13. The device according to any of the preceding claims or according to the pre-characterizing part of claim 1 , characterized in that at the respective surface (141, 142) for engaging and holding by suctioning the same product, corresponding means (18) are provided for the passage of said suctioning flow. 14. The device according to claim 13, characterized in that said means (18) for the passage of said suctioning flow comprise, in particular on the first supporting body (121), a respective large suctioning opening (180), i.e. , a first and a second suctioning openings (180’, 180’), preferably longitudinal, mutually aligned, in particular at which opening a corresponding grid (181), in particular a metal grid, is provided for the passage of a corresponding suctioning air. 15. The device according to any of the preceding claims or according to the pre-characterizing part of claim 1 , characterized in that the respective product engaging and holding surface, in particular said first surface (141 ) for engaging and holding the product, is defined by a corresponding annular lip (141), in particular having an elongated configuration, preferably defined by a corresponding body (13) of elastic material provided at the front face of the corresponding, or first, supporting body (121) and defining the respective suctioning opening (180); especially said annular body (13) being secured to the front face of said corresponding, or first, supporting body (121). 16. The device according to claim 15, characterized in that said body (13) of elastic material at the front face of the corresponding, or first, supporting body (121) is adapted to hold said grid (181) to the same supporting body (121), in particular clamping the edges of the same grid (181) between the rear surface of the same body of elastic material (13) and a corresponding front surface of the corresponding, or first, supporting body (121). 17. The device according to any of the preceding claims or according to the pre-characterizing part of claim 1 , characterized in that the respective surface for engaging and holding by suctioning the same product, in particular said second surface (142) for engaging and holding by suctioning the same product is defined by the front surface of a pad (182), preferably made of elastic material, at the front face of the corresponding, or second, supporting body (122). 18. The device according to any of the preceding claims 13 to 17, characterized in that said means (18) for the passage of said suctioning flow comprise, in particular on the second supporting body (122), a plurality of passages (183), in particular evenly distributed, for a corresponding suctioning flow, in particular provided at the outer surface of a pad (182), preferably made of elastic material, in particular said pad (182) defining said surface (142) for engaging and holding by suctioning a corresponding face, in particular the side face, of the product, i.e. , the second surface (142) for engaging and holding by suctioning provided on the second supporting body (122) of the same device (10). 19. The device according to any of the preceding claims or according to the pre-characterizing part of claim 1, characterized in that said means (14) for engaging by suctioning the respective product, i.e., the respective surface (141, 142) for engaging and holding by suctioning the same product, have, or has, means (20) for sealing the contact with the opposite face of the product to be grasped. 20. The device according to claim 19, characterized in that said means (20) for sealing the contact with the opposite surface of the product comprise an annular or shaped lip (141, 14T), in particular having an elongated configuration, preferably defined by a corresponding body (13) of elastic material defining the respective product engaging and holding surface, in particular said first surface (141) for engaging and holding the product. 21. The device according to any of the preceding claims 20 and 21, characterized in that said means (20) for sealing the contact with the opposite surface of the product comprise a peripheral or shaped portion (184), of a pad (182), preferably of elastic material, defining respective surface for engaging and holding by suctioning the same product, in particular said second surface (142) for engaging and holding by suctioning thereof. 22. The device according to any of the preceding claims or according to the pre-characterizing part of claim 1 , characterized in that said supporting means (12) comprise corresponding means (20) for the connection to means for generating a suctioning flow, in particular corresponding conduits of the suctioning circuit. 23. The device according to claim 22, characterized in that said means (18) for the connection to means for generating a suctioning flow, in particular corresponding conduits of the suctioning circuit comprise corresponding tubular portions (201 , 202) projecting from said supporting means (12) and in connection with the respective first and second suctioning chambers (161, 162) respectively upstream of said first and second surfaces (141, 142) for engaging and holding by suctioning the same product. 24. The device according to any of the preceding claims 22 and 23, characterized in that a first and a second projecting tubular portions (181, 182) are provided, defining said means (18) for the connection to means for generating a suctioning flow, which extend from said first and from said second supporting bodies (121, 122), respectively. 25. The device according to any of the preceding claims, characterized in that said supporting means (12) comprise connecting means (123) between said first and second supporting bodies (121, 122) respectively of said first and second surfaces (141, 142) for engaging and holding by suctioning the same product. 26. The device according to claim 25, characterized in that said connecting means (123) between said first and second supporting bodies respectively of said first and second surfaces (141, 142) for engaging and holding by suctioning the same product are in the form of a corresponding bracket, in particular a metal bracket, (123), which is interposed between said first and second supporting bodies (121, 122). 27. The device according to any of the preceding claims, characterized in that said connecting means, or bracket, (123) between said first and second supporting bodies (121, 122) have a respective longitudinal portion (1231) and a perpendicular portion, in particular oblique, (1232) respectively, for supporting said first and second supporting bodies (121, 122), i.e., consequently, respectively, for said first and second surfaces (141, 142) for engaging and holding by suctioning the same product. 28. The device according to any of the preceding claims, characterized in that means (1233) are provided, for adjusting the relative position between said first and second supporting bodies (121, 122), in particular the perpendicular relative position between said first and second supporting bodies (121, 122). 29. The device according to claim 28, characterized in that said means (1233) for adjusting the relative position between said first and second supporting bodies (121 , 122), in particular the perpendicular relative position between said first and second supporting bodies (121 , 122), are provided on said connecting means, or bracket, (123) between said first and second supporting bodies (121, 122). 30. The device according to any of the preceding claims 28 and 29, characterized in that said means (1233) for adjusting the relative position between said first and second supporting bodies (121, 122), in particular the perpendicular relative position between said first and second supporting bodies (121, 122), comprise, in particular on said perpendicular portion (1231) of said connecting means, or bracket, (123) between said first and second supporting bodies (121, 122), respective elongated-slot means (1233) for the sliding of corresponding pins (1234) for supporting the corresponding, or first, body (121) of the respective surface (141) for engaging and holding by suctioning the product, which supporting pins (1234) can be blocked in the corresponding, preferably perpendicular, position, especially through corresponding tightening screws (1235). 31. The device according to any of the preceding claims or according to the pre-characterizing part of claim 1 , characterized in that attachment means (17) are provided, in particular for a rapid attachment to means for moving said device (10), in particular defined by the arm of a corresponding robot. 32. The device according to claim 31, characterized in that said attachment means (17), in particular for a rapid attachment to means for moving said device (10), in particular defined by the arm of a corresponding robot, are provided on said connecting means (123) between said first and second supporting bodies (121, 122) define, and in particular extend superiorly from the same connecting means, or bracket, (123) between said first and second supporting bodies (121, 122). 33. The device according to any of the preceding claims or according to the pre-characterizing part of claim 1 , characterized in that means (22) for releasing the product from the device are provided. 34. The device according to claim 33, characterized in that said means for releasing the product from the device comprise means (221 , 222) for ejecting a compressed airflow at the respective surface (141, 142) for engaging and holding by suctioning the same product, in particular at said first and second surfaces (141 , 142) for engaging and holding by suctioning the same product. 35. The device according to claim 34, characterized in that said means for releasing the product from the device comprise respective first and second conduits (221 , 222) for ejecting a compressed airflow in connection with said first and second suctioning chambers (161, 162) respectively upstream of said first and second surfaces (141, 142) for engaging and holding by suctioning the same product, and in particular provided at the respective first and second supporting bodies (121, 122) of the device (10). 36. The device according to any of the preceding claims, characterized in that the respective supporting body (122), in particular said second supporting body (122) of the device (10), has rear supporting means (1220) of the respective pad (182), preferably made of elastic material, defining said surface (142) for engaging and holding by suctioning the product. 37. The device according to claim 36, characterized in that said rear supporting means of the respective pad (182), preferably of elastic material, defining said surface (142) for engaging and holding by suctioning the product, comprise a plurality of transversal ribs (1220), defining anteriorly the corresponding suctioning chamber (162), and spaced apart one from the other to define a suitable passage for the suctioning flow of the product. 38. The device according to any of the preceding claims or according to the pre-characterizing part of claim 1, characterized in that said means (14) for engaging by suctioning the respective product, in particular the surface (141 , 142) for engaging and holding by suctioning the same product, i.e., the respective supporting body (121, 122), have, or has, an elongated, in particular longitudinally elongated shape. 39. The device according to any of the preceding claims or according to the pre-characterizing part of claim 1, characterized in that said means (14) for engaging by suctioning the respective product, in particular the respective surface (142) for engaging and holding by suctioning the same product have, i.e., the respective supporting body (121, 122), have, or has, a substantially or generally quadrangular shape, in particular a square or rectangular shape. 40. The device according to any of the preceding claims or according to the pre-characterizing part of claim 1 , characterized in that the respective surface (141, 142) for engaging and holding by suctioning the same product has a generally elliptical configuration, in particular having a profile composed of parallel longitudinal lengths (1401, 1401) joined to one another at the opposite longitudinal ends through corresponding semi-circular, or substantially semi-circular, lengths, (140c, 140c). 41. The device according to any of the preceding claims or according to the pre-characterizing part of claim 1 , characterized in that the respective engaging and holding surface, in particular the second surface (142) for engaging and holding by suctioning the same product, is defined by the front surface of a pad (182), preferably of elastic material, at the front face of the corresponding, or second, supporting body (122), which defines, with a respective shaped body (184) means for sealing the contact with the opposite surface of the product which define a first and a second suctioning zones (1800, 1800), in particular longitudinally mutually aligned. 42. The device according to any of the preceding claims or according to the pre-characterizing part of claim 1 , characterized in that said supporting means (12), i.e., said first and second supporting bodies (121, 122), are of plastic material, preferably obtained through a tridimensional printer. 43. The device according to any of the preceding claims or according to the pre-characterizing part of claim 1, characterized in that said means (14) for engaging and holding by suctioning the respective product that define a first (141) and a second (142) surfaces for engaging and holding by suctioning the same product (11 ), which are movable one with respect to the other one. 44. The device according to any of the preceding claims or according to the pre-characterizing part of claim 1, characterized in that a first and a second supporting bodies (121, 122), respectively, are provided for said first and second surfaces (141, 142) for engaging and holding by suctioning the same product (11 ) which are movable one with respect to the other one. 45. The device according to any of the preceding claims 43 and 44, characterized in that said first (141) and second (142) surfaces for engaging and holding by suctioning the same product (11) are movable one with respect to the other one in a position, in particular a resting or lifted position, in which they are aligned or substantially mutually aligned. 46. The device according to any of the preceding claims 43 to 45, characterized in that said first and second supporting bodies (121 , 122) respectively for said first and second surfaces (141 , 142) for engaging and holding by suctioning the same product (11 ) are movable one with respect to the other one in a position, in particular a resting or lifted position, in which they are aligned or substantially mutually aligned. 47. The device according to any of the preceding claims 43 to 46, characterized in that said second surface (142) for engaging and holding by suctioning the same product (11) is movable with respect to the first surface (141) for engaging and holding by suctioning the same product (11) in a position, in particular a resting or lifted position, in which said first (141) and second (142) surfaces for engaging and holding by suctioning the same product are aligned or substantially mutually aligned. 48. The device according to any of the preceding claims 43 to 47, characterized in that said second supporting body (122), for said second surface (141, 142) for engaging and holding by suctioning the same product (11), is movable with respect to said first supporting body (121), for said first surface (141 ) for engaging and holding by suctioning the same product (11 ), in a position, in particular a resting or lifted position, in which said first and second supporting bodies (121, 122) are aligned or substantially mutually aligned. 49. The device according to any of the preceding claims 43 to 48, characterized in that said first (141 ) and second (142) surfaces for engaging and holding by suctioning the same product (11 ) are movable with respect to one another in a position, in particular an engaging position of the product (11), in which they are angularly spaced apart, in particular by 90°, or substantially by 90°. 50. The device according to any of the preceding claims 43 to 49, characterized in that said first and second supporting bodies (121 , 122) respectively for said first and second surfaces (141 , 142) for engaging and holding by suctioning the same product are movable one with respect to the other one, in a position, in particular an engaging position of the product (11 ), in which they are angularly spaced apart from one another, in particular by 90°, or substantially by 90°. 51. The device according to any of the preceding claims 43 to 50, characterized in that said second surface (142) for engaging and holding by suctioning the same product (11) is movable with respect to the first surface (141) for engaging and holding by suctioning the same product (11) in a position, in particular an engaging position of the product (11), in which they are angularly spaced apart, in particular by 90°, or substantially by 90°. 52. The device according to any of the preceding claims 43 to 51, characterized in that said second supporting body (122), for said second surface (141, 142) for engaging and holding by suctioning the same product (11), is movable with respect to said first supporting body (121), for said first surface (141 ) for engaging and holding by suctioning the same product (11 ), in a position, in particular an engaging position of the product (11), in which they are angularly spaced apart from one another, in particular by 90°, or substantially by 90°. 53. The device according to any of the preceding claims 43 to 52, characterized in that means (30) for a relative rotation between a first (141) and a second (142) surfaces for engaging and holding by suctioning the same product (11) are provided, in particular according to a respective angular direction, especially by an angle equal to, or substantially equal to, 90°, especially between a position in which said first (141) and second (142) surfaces for engaging and holding by suctioning the same product (11) are aligned or substantially mutually aligned, and a position in which said first (141) and second (142) surfaces for engaging and holding by suctioning the same product (11) are angularly spaced apart, in particular by 90°, or substantially by 90°. 54. The device according to any of the preceding claims 43 to 53, characterized in that means (30) for a relative rotation of the second surface (142) for engaging and holding by suctioning the same product (11) are provided, with respect to the surface (141) for engaging and holding by suctioning the same product (11), in particular according to a respective angular direction, especially by an angle equal to, or substantially equal to, 90°, especially between a position in which said first (141) and second (142) surfaces for engaging and holding by suctioning the same product (11) are aligned or substantially mutually aligned, and a position in which said first (141) and second (142) surfaces for engaging and holding by suctioning the same product (11) are angularly spaced apart, in particular by 90°, or substantially by 90°. 55. The device according to any of the preceding claims 43 to 54, characterized in that means (30) for a rotation between a first and a second supporting bodies (121, 122) respectively for said first and second surfaces (141, 142) for engaging and holding by suctioning the same product are provided, in particular according to a respective angular direction, in particular by an angle equal to, or substantially equal to, 90°, especially between a position in which said first (141) and second (142) surfaces for engaging and holding by suctioning the same product (11) are aligned or substantially mutually aligned, and a position in which said first (141) and second (142) surfaces for engaging and holding by suctioning the same product (11) are angularly spaced apart, in particular by 90°, or substantially by 90°. 56. The device according to any of the preceding claims 43 to 55, characterized in that means (30) for a rotation of said second supporting body (122) are provided, for said second surface (141, 142) for engaging and holding by suctioning the same product (11 ), is movable with respect to said first supporting body (121), for said first surface (141) for engaging and holding by suctioning the same product (11), in particular according to a respective angular direction, in particular by an angle equal to, or substantially equal to, 90°, especially between a position in which said first (141) and second (142) surfaces for engaging and holding by suctioning the same product (11) are aligned or substantially mutually aligned, and a position in which said first (141) and second (142) surfaces for engaging and holding by suctioning the same product (11) are angularly spaced apart, in particular by 90°, or substantially by 90°. 57. The device according to any of the preceding claims 43 to 56, characterized in that said rotation between said first (141) and second (142) surfaces for engaging and holding by suctioning the same product, and/or between said first and second supporting bodies (121, 122) respectively for said first and second surfaces (141, 142) for engaging and holding by suctioning the same product said first (141) and second (142) surfaces for engaging and holding by suctioning the same product, is according to a respective horizontal axis. 58. The device according to any of the preceding claims 43 to 57, characterized in that said rotation between said first (141) and second (142) surfaces for engaging and holding by suctioning the same product, and/or between said first and second supporting bodies (121, 122) respectively for said first and second surfaces (141, 142) for engaging and holding by suctioning the same product said first (141) and second (142) surfaces for engaging and holding by suctioning the same product, is according to an axis parallel to the adjacent sides of said first (141 ) and second (142) surfaces for engaging and holding by suctioning the same product, and/or said first and second supporting bodies (121, 122) respectively for said first and second surfaces (141 , 142) for engaging and holding by suctioning the same product. 59. The device according to any of the preceding claims 43 to 58, characterized in that said rotation means (30) are provided for between said first (141) and said second (142) surfaces for engaging and holding by suctioning the same product, and/or between said first and said second supporting bodies (121, 122) respectively for said first and second surfaces (141, 142) for engaging and holding by suctioning the same product, are in the form of, or defined by, a corresponding rotation hinge (30). 60. The device according to any of the preceding claims 43 to 59, characterized in that said rotation means, or respective hinge, (30) are at the connecting means (123) between said first and second supporting bodies (121, 122) respectively of said first and second surfaces (141, 142) for engaging and holding by suctioning the same product. 61. The device according to any of the preceding claims 43 to 60, characterized in that said rotation means, or respective hinge, (30) are provided for between a first part (123’) of said connecting means (123) between said first and second supporting bodies (121 , 122), which is integral to, and/or projecting from, said first supporting body (121), and a second part (123”) of said connecting means (123) between said first and second supporting bodies (121, 122), which is integral to, and/or projecting from, said second supporting body (121, 122). 62. The device according to any of the preceding claims 43 to 61, characterized in that said rotation means, or respective hinge, (30) are adapted to arrange said first (141) and second (142) surfaces for engaging and holding by suctioning the same product on the same plane, in particular a horizontal plane, i.e. , in a mutually aligned condition. 63. The device according to any of the preceding claims 43 to 62, characterized in that said rotation means, or respective hinge, (30) are adapted to arrange said first (141) and second (142) surfaces for engaging and holding by suctioning the same product on planes that are angularly spaced apart from one another, in particular on planes that are angularly spaced apart from one another by 90°. 64. The device according to any of the preceding claims 43 to 63, characterized in that said rotation means, or respective hinge, (30) are in a position above said first surface (141 ) for engaging and holding by suctioning the same product and/or said second surface (142) for engaging and holding by suctioning the same product, in particular in a mutually aligned condition. 65. The device according to any of the preceding claims 43 to 64, characterized in that said second surface (142) for engaging and holding by suctioning the same product (11 ), and/or the corresponding supporting body (121 ), in the position, in particular for engaging the product (11), in which it is angularly rotated, in particular by 90°, or substantially by 90°, extends inferiorly with respect to said first surface (142) for engaging and holding by suctioning the same product (11), and/or with respect to the corresponding supporting body (121). 66. The device according to any of the preceding claims or according to the pre-characterizing part of claim 1, characterized in that said first (141) and second (142) surfaces for engaging and holding by suctioning the same product are movable one with respect to the other one with a translating movement, in particular parallel to the other surface (141) for engaging and holding by suctioning the same product; in particular said second surface (142) for engaging and holding by suctioning the same product, or vertically positioned surface, is movable parallel to the first engaging and holding surface (141), or horizontally positioned surface. 67. The device according to any of the preceding claims or according to the pre-characterizing part of claim 1, characterized in that said first and second supporting bodies (121, 122) respectively for said first and second surfaces (141, 142) for engaging and holding by suctioning the same product are movable one with respect to the other with a translating movement, in particular parallel to the surface (141 ) for engaging and holding by suctioning the same product, of the other supporting body (121), in particular said second supporting body (122) of said second surface (142) for engaging and holding by suctioning the same product, or vertically positioned surface, is movable parallel to the first engaging and holding surface (141), or horizontally positioned surface, i.e. , parallel to said first supporting body (121) of said first surface (141) for engaging and holding by suctioning the same product. 68. The device according to any of the preceding claims 66 and 67, characterized in that said first (141) and second (142) surfaces for engaging and holding by suctioning the same product, and/or said first and second supporting bodies (121, 122) respectively for said first and second surfaces (141, 142) for engaging and holding by suctioning the same product, are respectively movable with a translating movement, forwards and backwards, between a respective mutually moved-farther position and a respective moved-closer position, in particular for gripping the product (11 ). 69. The device according to any of the preceding claims 66 to 68, characterized in that means for the actuation of the relative translating movement between said first (141) and second (142) surfaces for engaging and holding by suctioning the same product are provided, i.e., between said first and second supporting bodies (121, 122) respectively for said first and second surfaces (141, 142) for engaging and holding by suctioning the same product. 70. The device according to claim 69, characterized in that said means for the actuation of the relative translating movement between said first (141) and second (142) surfaces for engaging and holding by suctioning the same product, i.e. , between said first and second supporting bodies (121, 122) respectively for said first and second surfaces (141 , 142) for engaging and holding by suctioning the same product, are adapted to move said connecting means (123) between said first and second supporting bodies (121, 122) respectively for said first and second surfaces (141 , 142) for engaging and holding by suctioning the same product, with respect to said first supporting body (121). 71. A device, characterized in that it is produced according to any of the preceding claims and/or as described and illustrated with reference to the attached drawings.

## Full description

**[0001]**

DESCRIPTION

**[0002]**

A DEVICE FOR GRIPPING OR GRASPING PRODUCTS.

**[0003]**

Application field of the present invention The present invention relates to a device for gripping or grasping products.

**[0004]**

Preferably, said products are in the form of packages, in a preferred manner defined by a corresponding envelope, for example made of a plastic film, or a paper sheet, or other, or made of cardboard which wraps or contains one or more articles.

**[0005]**

In particular said articles being articles of the so-called Tissue field and preferably being made of paper material or other material, such as woven fabric or non-woven fabric, and preferentially being in the form of rolls, in particular rolls of toilet paper, of kitchen paper or for another use, i.e., rolls for the treatment of food products, such as rolls of aluminium foil, plastic film, wax paper film, and the like.

**[0006]**

Said articles can also be in the form of respective packaging, in particular packs, packets or other containers, in particular for napkins, handkerchiefs, small towels for hands and face, hand towels, bed sheets, and other. Other articles that are treated through the present device for gripping and grasping products, for example, consist in sanitary pads for personal care and corresponding packages or packaging.

**[0007]**

State of the art Devices for gripping or grasping products are known, which devices comprise supporting means for means for engaging and holding by suctioning the respective product.

**[0008]**

According to an already known type of devices for gripping or grasping products, suction cups for engaging the corresponding surface of the product

**[0009]**

are used, which suction cups, however, do not allow exerting a sufficiently high holding action and, therefore, do not allow achieving a safe and reliable grip.

**[0009]**

In other types of devices for gripping and grasping solid pieces, having a high weight, suctioning members are usually used, which firmly engage the upper surface of the product, which therefore turn out to be completely unsuitable when it is desired to grasp products that are, or that have, their respective outer surface that is particularly weak or delicate to be treated. Summary of the invention.

**[0010]**

By the present invention, it is aimed to propose a novel, alternative solution to the solutions known to date, and in particular it is proposed to obviate one or more of the drawbacks or problems cited above and/or to meet one or more needs cited above, and/or anyhow felt in the art, and in particular derivable from what has been set forth herein above.

**[0011]**

Therefore, a device is provided, for gripping or grasping products, said products being in particular in the form of packages, in a preferred manner defined by a corresponding envelope, for example made of a plastic film, or a paper sheet, or other, or made of cardboard, which wraps or contains one or more articles; in particular said articles being articles of the so-called Tissue field and preferably being made of paper material or other material, such as woven fabric or non-woven fabric, and preferentially being in the form of rolls, in particular rolls of toilet paper, of kitchen paper or for another use, or rolls for the treatment of food products, such as rolls of aluminium foil, plastic film, wax paper film, and the like, i.e. , said articles being in the form of packaging, in particular packs, packets or other containers, in particular for napkins, handkerchiefs, small towels for hands and face, hand towels, bed sheets, sanitary napkins for personal care; the device comprising supporting means for means for engaging and holding by suctioning the respective

**[0013]**

product and being characterized in that said means for engaging and holding by suctioning the respective product define a first and a second surfaces for engaging and holding by suctioning the same product, in particular angularly spaced apart, preferably angularly spaced by an angle equal to, or substantially equal to, 90°.

**[0012]**

In this manner, it is possible to easily and efficiently grasp the product, in particular without providing excessive stresses to the same product, especially to the peripheral surface of the same product, i.e. , to the film, or sheet, of the package wrapping the respective articles, for example to the film, or sheet, which wraps corresponding toilet paper rolls.

**[0013]**

Brief description of the drawings

**[0014]**

This and other novel aspects, or specific advantageous implementations, are anyhow set forth in the claims cited below, the technical characteristics of which can be found in the following detailed description, illustrating preferred and advantageous embodiments, which are however to be considered as merely exemplary and non-limiting of the invention; said description being given by reference to the attached drawings, in which: figure 1A illustrates a perspective, schematic view of a first preferred implementation of device according to the present invention; figure 1 B illustrates a perspective, schematic view, taken from a different direction from the one of figure 1A, of the first preferred implementation of device according to the present invention; figure 1 C illustrates a perspective, schematic view, taken on the opposite side with respect to the one of figure 1A, of the first preferred implementation of device according to the present invention; figure 1 D illustrates a side elevational view of the first preferred implementation of device according to the present invention; figure 1E illustrates bottom plan view of the first preferred

**[0017]**

implementation of device according to the present invention; figure 1 F illustrates front elevational view of the first preferred implementation of device according to the present invention; figure 1G illustrates top plan view of the first preferred implementation of device according to the present invention; figure 1 H illustrates rear elevational view of the first preferred implementation of device according to the present invention; figure 11 illustrates a cross-sectional perspective view of the first preferred implementation of device according to the present invention; - figure 1 L illustrates a cross-sectional perspective view, taken on the opposite side with respect to the one of figure 11, of the first preferred implementation of device according to the present invention; figured 2A to 2C illustrate in respective cross-sectional perspective views a second version of the first preferred implementation of device according to the present invention; figure 3A illustrates a perspective view of a second preferred implementation of device according to the present invention, in a first configuration of use; figure 3B illustrates a perspective view of the second preferred implementation of device according to the present invention, in the first configuration of use, taken on the opposite side with respect to the one of figure 3A; figure 3C illustrates a side elevational view of the second preferred implementation of device according to the present invention, in the first configuration of use; figure 3D illustrates a perspective view of the second preferred implementation of device according to the present invention, particularly illustrating a cross-section of the inner part of the first supporting means of the device;

**[0018]**

figure 3E illustrates a perspective view of the second preferred implementation of device according to the present invention, particularly illustrating a cross-section of the inner part of the second supporting means del device; - figure 3F illustrates a perspective view of a second preferred implementation of device according to the present invention, in a second configuration of use; figure 3G illustrates a perspective view of the second preferred implementation of device according to the present invention, in the second configuration of use, taken on the opposite side with respect to the one of figure 3F; figure 3H illustrates a side elevational view of the second preferred implementation of device according to the present invention, in the second configuration of use; - figures 4A to 4C illustrate in a respective side view a third preferred implementation of device according to the present invention, while it performs a climbing over movement of a product and of gripping of another product; figure 4D illustrates a perspective view of the third preferred implementation of device in the gripping position of figure 4C; figures 5A to 5F illustrate in a respective side view the third preferred implementation of device according to the present invention, while it performs a gripping movement of a corresponding flat sheet, which is moved above a corresponding plurality of products; - figure 5G illustrates a perspective view of the third preferred implementation of device in the in the release position of the flat sheet on the plurality of products of the previous figure 5F; figures 6A to 6C illustrate in respective side view the third preferred implementation of device according to the present invention, while

**[0019]**

it performs a gripping movement of a product with a translating movement of the second engaging and holding surface; figure 6D illustrates a perspective view of the third preferred implementation of device in the gripping position of figure 6C.

**[0015]**

Detailed description of preferred implementations of the invention

**[0016]**

In the attached figures da 1 A a 1 L, a first preferred implementation 10 of a device for gripping or grasping products is illustrated.

**[0017]**

Said products are, in particular, in the form of packages, and in a preferred manner they are defined by a corresponding envelope, for example made of a plastic film, or a paper sheet, or other, or made of cardboard which wraps or contains one or more articles.

**[0018]**

In particular, in a preferred and anyhow non-limiting manner, said articles are articles of the so-called Tissue field and preferably are in a paper material or in other material, such as woven fabric or non-woven fabric, preferentially being in the form of rolls, in particular rolls of toilet paper, of kitchen paper or for another use, or rolls for the treatment of food products, such as rolls of aluminium foil, plastic film, wax paper film, and the like.

**[0019]**

In particular, furthermore, said articles can be in the form of packaging, in particular packs, packets or other containers, in particular for napkins, handkerchiefs, small towels for hands and face, hand towels, bed sheets, sanitary napkins for personal care and other.

**[0020]**

Therefore, the device 10 comprises, as illustrated, means 12 for the support of the means 14 for engaging and holding by suctioning the respective product.

**[0021]**

Particularly advantageously, it is provided for that said means 14 for engaging and holding by suctioning the respective product define a first 141 and a second 142 surfaces for engaging and holding by suctioning the same product, in particular angularly spaced apart, preferably angularly spaced by

**[0027]**

an angle equal to, or substantially equal to, 90°.

**[0022]**

In this manner, it is possible to easily and efficiently grasp the product, in particular without providing excessive stresses to the same product, especially to the peripheral surface of the same product, i.e. , to the film, or sheet, of the package wrapping respective articles, for example to the film, or sheet, which wraps corresponding toilet paper rolls.

**[0023]**

Advantageously, while it is not particularly illustrated in the attached figures, said first and second surfaces 141, 142 for engaging and holding by suctioning the same product are adapted to engage respective faces of the product to be grasped, in particular angularly spaced apart faces, and preferably mutually adjacent, of said product, and preferably faces of said product that are angularly spaced apart by an angle equal to, or substantially equal to, 90°.

**[0024]**

In this manner, it is possible to operate in a delicate manner, i.e., without creating excessive stress peaks at the product surface to be grasped produced, and the product can thus be taken without damaging the outer envelope, for example of plastic material, which wraps the respective articles, for example in the form of toilet paper rolls wrapped in a respective packaging plastic film. In an advantageous manner, while it is not particularly illustrated in the attached figures, said first surface 141 for engaging and holding by suctioning the same product is adapted to engage the upper surface of the product.

**[0025]**

With advantage, while it is not particularly illustrated in the attached figures, said first surface 141 for engaging and holding by suctioning the same product is adapted to engage the upper surface of the product at a central, or substantially central, zone thereof.

**[0026]**

With particular advantage, while it is not particularly illustrated in the attached figures, the second surface 142 for engaging and holding by suctioning the same product is adapted to engage a side surface of the same

**[0033]**

product.

**[0027]**

In an advantageous manner, while it is not particularly illustrated in the attached figures, said second surface 142 for engaging and holding by suctioning the same product is adapted to engage the side surface of the corresponding product in the proximity of the upper surface of the same product, i.e. , of the upper surface of the same side surface of the product.

**[0028]**

As is clear from said figures, with advantage, said first surface 141 for engaging and holding by suctioning the same product has a respective longitudinal extension 11 that is greater than the longitudinal extension I2 of said second engaging surface 142.

**[0029]**

However, while said longitudinal extension is added with the first engaging surface 141, which is particularly preferred, it shall anyhow be understood that the fact to obtain engaging and holding surfaces 141, 142, which have substantially the same longitudinal extension, or with said second engaging and holding surface 142 having a longitudinal extension larger than that of said first engaging and holding surface 141 is also able to be devised.

**[0030]**

As is clear from said figures, with advantage, said first surface 141 for engaging and holding by suctioning the same product has a respective transversal extension t1 that is lesser than the corresponding transversal extension t2 of said second engaging surface 142.

**[0031]**

In this manner, in particular, it is possible to exert a greater holding action upon the less-stressed side surface of the product and, ultimately, a good distribution of the withdrawal stresses between the upper part and the side part of the product or package is obtained. However, while said longitudinal extension is added with the second engaging surface, which is adapted to engage the side face of the product, particularly which is particularly preferred, it shall anyhow be understood that the fact to obtain engaging and holding surfaces of the upper and side faces that have substantially the same transversal extension, or with said second

**[0039]**

engaging and holding surface of the side surface of the product that has a transversal extension that is less than that of said first engaging and holding surface of the upper face of the product is also able to be devised.

**[0032]**

Advantageously, as is clear from said figures, said supporting means 12 define corresponding suctioning chamber means 16 upstream of said first and second surfaces 141, 142 for engaging and holding by suctioning the same product.

**[0033]**

With particular advantage, as is clear from said figures, said suctioning chamber means 16 comprise corresponding first and second suctioning chambers 161, 162, respectively upstream of said first and second surfaces 141 , 142 for engaging and holding by suctioning the same product.

**[0034]**

As is clear from said figures, in an advantageous manner, said supporting means 12 of the device 10 comprise a first and a second supporting bodies 121, 122 respectively for said first and second surfaces 141 , 142 for engaging and holding by suctioning the same product.

**[0035]**

As is clear from said figures, with advantage, said first and second bodies 121, 122 respectively for supporting said first and second surfaces 141 , 142 for engaging and holding by suctioning the same product define a respective suctioning chamber 161 or 162 upstream of the respective surface 141 , 142 for engaging and holding by suctioning the same product 141, 142.

**[0036]**

With advantage, as is clear from said figures, at the respective surface 141 , 142 for engaging and holding by suctioning the same product, corresponding means 18 for the passage of said suctioning flow are provided.

**[0037]**

In a further advantageous manner, as is clear from said figures, said means 18 for the passage of said suctioning flow comprise, in particular on the first supporting body 121, a respective large suctioning opening 180 at which a corresponding grid 181 , in particular a metal grid, is provided for the passage of a corresponding suctioning air.

**[0038]**

Advantageously, as is clear from said figures, the respective surface

**[0047]**

for engaging and holding the product, in particular said first surface 141 for engaging and holding the product, is defined by a corresponding annular lip 141 , in particular having an elongated configuration, preferably defined by a corresponding body 13 of elastic material provided at the front face of the corresponding, or first, supporting body 121 and defining said suctioning opening 180.

**[0039]**

Especially, as illustrated, said annular body 13 is secured to the front face of said corresponding, or first, supporting body 121.

**[0040]**

As is clear from said figures, with advantage, said body 13 of elastic material at the front face of the corresponding, or first, supporting body 121 is adapted to hold said grid 181 to the same supporting body 121 , in particular clamping the edges of the same grid 181 between the rear surface of the same body of elastic material 13 and a corresponding front surface of the corresponding, or first, supporting body 121. However, it shall be understood that also means that are different from the means 180, 181 and 13 illustrated above could be anyhow devised. For example, the grid 181 and said peripheral body 13 could be replaced with any other porous material, such as a corresponding spongy material, preferably provided with corresponding through holes of said suctioning flow. In an advantageous manner, as is clear from said figures, the respective surface for engaging and holding by suctioning the same product, in particular said second surface 142 for engaging and holding by suctioning the same product, is defined by the front surface of a pad 182, preferably made of elastic material, at the front face of the corresponding, or second, supporting body 122.

**[0041]**

With particular advantage, as is clear from said figures, said means 18 for the passage of said suctioning flow comprise, in particular on the second supporting body 122, a plurality of passages 183, in particular evenly distributed, for a corresponding suctioning flow, in particular provided at the

**[0051]**

outer surface of a pad 182, preferably made of elastic material, in particular said pad 182 defining said surface 142 for engaging and holding by suctioning a corresponding face, in particular the side face, of the product, i.e., the second surface 142 for engaging and holding by suctioning provided on the second supporting body 122 of the same device 10.

**[0042]**

However, it shall be understood that said second engaging surface could also be produced in a different manner with respect to said pad 182. In particular, in accordance with a further embodiment, said engaging surface 142 could also be defined by a plurality of, for example two, pads, perhaps respectively having through holes with a diameter that is different from one another.

**[0043]**

Advantageously, as is clear from said figures, said means 14 for engaging by suctioning the respective product, i.e., the respective surface 141 , 142 for engaging and holding by suctioning the same product, have, or has, means 20 for sealing the contact with the opposite face of the product to be grasped.

**[0044]**

In an advantageous manner, as is clear from said figures, said means 20 for sealing the contact with the opposite surface of the product comprise said annular lip 141, in particular having an elongated configuration, preferably defined by a corresponding body 13 of elastic material defining the respective product engaging and holding surface, in particular said first surface 141 for engaging and holding the product.

**[0045]**

With advantage, as is clear from said figures, said means 20 for sealing the contact with the opposite surface of the product comprise a peripheral portion 184, of a pad 182, preferably made of elastic material, defining respective surface for engaging and holding by suctioning the same product, in particular said second surface 142 for engaging and holding by suctioning thereof.

**[0046]**

In an advantageous manner, as is clear from said figures, said

**[0057]**

supporting means 12 comprise corresponding means 20 for the connection to means, not illustrated in particular in the attached figures, for generating a suctioning flow, in particular corresponding conduits of the suctioning circuit.

**[0047]**

In an advantageous manner, as is clear from said figures, said means 18 for the connection to means for generating a suctioning flow, in particular corresponding conduits of the suctioning circuit comprise corresponding tubular portions 201, 202 projecting from said supporting means 12 and in connection with the respective first and second suctioning chambers 161, 162 respectively upstream of said first and second surfaces 141, 142 for engaging and holding by suctioning the same product.

**[0048]**

With particular advantage, as is clear from said figures, a first and a second projecting tubular portions 181, 182 defining said means 18 for the connection to means for generating a suctioning flow are provided, which respectively extend from said first and from said second supporting bodiesl 21 , 122, in particular from the first supporting body 121 superiorly and towards the rear part of the device and posteriorly upwards from the second supporting body 122.

**[0049]**

In particular, said suctioning tubular portions 181, 182 are positioned in connection with a common suctioning circuit, and adjusting means can be provided, for suitably differentiate the suction flow rate between the same suctioning tubular portions 181, 182, i.e. , the same suctioning tubular portions 181, 182 can be each connected to a respective and different suctioning device, in particular so as to obtain suction flow rates that are suitably different from one another. Furthermore, said projecting tubular portions 181, 182 may also have, unlike what has been illustrated, diameters that are suitably different from one another.

**[0050]**

With advantage, as is clear from said figures, said supporting means 12 comprise connecting means 123 between said first and second supporting

**[0062]**

bodies 121, 122 respectively of said first and second surfaces 141, 142 for engaging and holding by suctioning the same product.

**[0051]**

In an advantageous manner, as is clear from said figures, said connecting means 123 between said first and second supporting bodies 121 , 122 respectively of said first and second surfaces 141 , 142 for engaging and holding by suctioning the same product are in the form of a corresponding bracket, in particular a metal grid, 123, which is interposed between said first and second supporting bodies 121, 122.

**[0052]**

Advantageously, as is clear from said figures, said connecting means, or bracket, 123 between said first and second supporting bodies 121, 122 have a respective longitudinal portion 1231 and a respective perpendicular portion, in particular oblique, 1232 respectively, for supporting said first and second supporting bodies 121, 122, i.e. , consequently, respectively, for said first and second surfaces 141, 142 for engaging and holding by suctioning the same product.

**[0053]**

Advantageously, as is clear from the following figures 2A to 2C, regarding a second version of the first preferred implementation of device, and from figures 3A to 3H regarding a second preferred implementation 100 of device, which will be anyhow best understood from the following of the present description, means 1233 for adjusting the relative position between said first and second supporting bodies 121, 122 are provided, in particular the perpendicular relative position between said first and second supporting bodies 121, 122.

**[0054]**

In this manner, it is possible to adjust the device to different types or product sizes.

**[0055]**

In an advantageous manner, as is clear from said figures, said means 1233 for adjusting the relative position between said first and second supporting bodies 121, 122, in particular the perpendicular relative position between said first and second supporting bodies 121, 122, are provided on

**[0068]**

said connecting means, or bracket, 123 between said first and second supporting bodies 121, 122.

**[0056]**

With advantage, as is clear from said figures, said means 1233 for adjusting the relative position between said first and second supporting bodies 121, 122, in particular the perpendicular relative position between said first and second supporting bodies 121, 122, comprise, in particular on said longitudinal portion 1231 of said connecting means, or bracket, 123 between said first and second supporting bodies 121, 122, respective elongated-slot means 1233 for the sliding of corresponding pins 1234 for supporting the corresponding, or first, body 121 of the respective surface 141 for engaging and holding by suctioning the product, which supporting pins 1234 can be blocked in the corresponding, preferably perpendicular, position, especially through corresponding tightening screws 1235.

**[0057]**

Although means for adjusting the perpendicular relative position between said first and second holding means 141 , 142 have been illustrated, it can anyhow be devised to be able to adjust the relative position of the same said first and second holding means 141, 142 according to any other desired direction, for example, according to a direction that is longitudinal thereto.

**[0058]**

With particular advantage, as is clear from said figures, attachment means 17 are provided, in particular for a rapid attachment to means for moving said device 10, in particular defined by the arm of a corresponding robot.

**[0059]**

In an advantageous manner, said attachment means 17, in particular for a rapid attachment to means for moving said device 10, in particular defined by the arm of a corresponding robot, are provided on said connecting means 123 between said first and second supporting bodies 121, 122 define, and in particular extend superiorly from the same connecting means, or bracket, 123 between said first and second supporting bodies 121, 122.

**[0060]**

Particularly advantageously, as is clear from said figures, means 22

**[0074]**

for releasing the product from the device are provided.

**[0061]**

With advantage, as is clear from said figures, said means for releasing the product from the device comprise means 221, 222 for ejecting a compressed air flow at the respective surface 141, 142 for engaging and holding by suctioning the same product, in particular at said first and second surfaces 141 , 142 for engaging and holding by suctioning the same product.

**[0062]**

In an advantageous manner, as is clear from said figures, said means for releasing the product from the device comprise respective first and second conduits 221, 222 for ejecting a compressed airflow in connection with said first and second suctioning chambers 161, 162 respectively upstream of said first and second surfaces 141, 142 for engaging and holding by suctioning the same product, and in particular provided at the respective first and second supporting bodies 121, 122 of the device 10.

**[0063]**

It shall anyhow be understood that said first and second conduits 221 , 122 for ejecting a compressed air flow can be supplied by a single circuit with optional means for adjusting the flow rate, in order to suitably differentiate the release action respectively on the first and on the second engaging and holding means 141, 142, i.e. , they could also be supplied by circuits generating a compressed airflow that are mutually different and independent, in particular in order to be able to suitably differentiate the release action respectively on the first and on the second engaging and holding means 141 , 142.

**[0064]**

Advantageously, as is clear from said figures, the respective supporting body 122, in particular said second supporting body 122 of the device 10, has means 1220 for a rear support of the respective pad 182, preferably of elastic material, defining said surface 142 for engaging and holding by suctioning the product.

**[0065]**

With particular advantage, as is clear from said figures, said rear supporting means of the respective pad 182, preferably of elastic material,

**[0080]**

defining said surface 142 for engaging and holding by suctioning the product, comprise a plurality of transversal ribs 1220, defining anteriorly the corresponding suctioning chamber 162, and spaced apart one from the other to define a suitable passage for the suctioning flow of the product. In an advantageous manner, as is clear from said figures, said means

**[0066]**

14 for engaging by suctioning the respective product, in particular the surface 141 , 142 for engaging and holding by suctioning the same product, i.e. , the respective supporting body 121, 122, have, or has, an elongated, in particular longitudinally elongated shape. With advantage, as is clear from said figures, in particular with regard to the first preferred implementation of device, said means 14 for engaging by suctioning the respective product, in particular the respective surface 142 for engaging and holding by suctioning the same product have, i.e., the respective supporting body 121, 122, have, or has, a substantially or generally quadrangular shape, in particular squared, or rectangular, as provided in the second preferred implementation of device, which will be best understood from the following of the present description.

**[0067]**

In the following figures 3A to 3H, a second preferred implementation 100 of device according to the present invention is illustrated, the components of which that are similar, or equivalent, to those of the previous preferred implementation are marked with the same reference numerals and, in order not to excessively burden the present description, are not commented in detail again.

**[0068]**

The present second preferred implementation 100 of device is distinguished from the first preferred implementation of device in that the respective surface for engaging and holding the product, in particular said first surface 141 for engaging and holding the product, is defined by a corresponding shaped lip 14T, in particular having an elongated configuration, preferably defined by a corresponding body 13 of elastic

**[0084]**

material provided at the front face of the corresponding, or first, supporting body 121 and defining a first and a second suctioning openings 180’, 180’, longitudinally mutually aligned.

**[0069]**

Said shaped lip 141’, in particular having an elongated configuration, preferably defined by a corresponding body 13 of elastic material provided at the front face of the corresponding, or first, supporting body 121 and defining said suctioning openings 180’, 180’, substantially comprises an outer elongated portion, in particular having a generally elliptical shape, 141a and an intermediate portion 141b for the connection between opposite longitudinal sides of said outer elongated portion 141a, and in particular extending at the median zones of the same longitudinal sides.

**[0070]**

In this manner, it is possible to obtain a firmer and/or tighter grip of the product on the respective engaging side.

**[0071]**

Furthermore, the present second preferred implementation 100 of device is distinguished from the first preferred implementation of device in that the respective engaging and holding surface, in particular said second surface 142 for engaging and holding by suctioning the same product, is defined by the front surface of a pad 182, preferably made of elastic material, at the front face of the corresponding, or second, supporting body 122, which defines, with a respective shaped body 184 means for sealing the contact with the opposite surface of the product which define a first and a second suctioning zones 1800, 1800, in particular longitudinally mutually aligned, and in which corresponding through or passage holes 183 are provided.

**[0072]**

In particular said shaped lip 184 is defined by a peripheral portion 188a, from the intermediate zone of which of the opposite ling sides a corresponding transversal portion 184b extends, which divides, in said engaging pad 182, said first and second suctioning zones1800, 1800.

**[0073]**

In this manner, it is possible to obtain a firmer and/or tighter grip of the product on the respective engaging side.

**[0090]**

Furthermore, as is clear from said first and second preferred implementation, the respective surface 141 for engaging and holding by suctioning the same product has a generally elliptical configuration, in particular having a profile composed of parallel longitudinal lengths 1401, 1401, joined to one another at the opposite longitudinal ends through corresponding semi-circular, or substantially semi-circular, lengths, 140c, 140c.

**[0074]**

In this manner, it is possible to advantageously engage products, in particular respective packages of rolls, that have a similar configuration of the respective face, in particular of the upper face thereof.

**[0075]**

However, it shall be understood that the configuration of the respective engaging and holding surface can be any, in particular, besides being elongated, it can be quadrangular, rectangular or elliptical, even having a circular shape, or another shape. In an advantageous manner, said supporting means 12, i.e., said first and second supporting bodies 121, 122, are of plastic material, preferably obtained through a tridimensional printer.

**[0076]**

In the following figures 4A to 6D, a third preferred implementation of device is illustrated, which third implementation has components that are similar or equivalent to those of the previous preferred implementations, which are marked by the same numeral references that were used in the previous preferred implementations and which, in order not to excessively burden the present description, are not commented in detail again.

**[0077]**

Advantageously, as is clear from said figures 4A to 6D, in this third preferred implementation of device, means 14 for engaging and holding by suctioning the respective product 11 are provided, which define a first 141 and a second 142 surfaces for engaging and holding by suctioning the same product, which are movable one with respect to the other one.

**[0078]**

With advantage, therefore, as is clear from said figures 4A to 6D, a

**[0096]**

first and a second supporting bodies 121, 122 are provided, respectively for supporting for said first and second surfaces 141, 142 for engaging and holding by suctioning the same product, which are movable one with respect to the other one. With advantage, said first 141 and second 142 surfaces for engaging and holding by suctioning the same product are movable one with respect to the other one in a position, in particular a resting or lifted position, for example illustrated in said figures 4A, and 5A to 5G, in which they are aligned or substantially mutually aligned. Advantageously, as is clear from said figures 4A to 6D, said first and second supporting bodies 121, 122 respectively for said first and second surfaces 141, 142 for engaging and holding by suctioning the same product are movable one with respect to the other one in a position, in particular a resting or lifted position, in which they are aligned or substantially mutually aligned.

**[0079]**

Advantageously, as is clear from said figures 4A to 6D, said second surface 142 for engaging and holding by suctioning the same product 11 is movable with respect to the first surface 141 for engaging and holding by suctioning the same product 11 in a position, in particular a resting or lifted position, in which said first 141 and second 142 surfaces for engaging and holding by suctioning the same product are aligned or substantially mutually aligned.

**[0080]**

As is clear from said figures 4A to 6D, in an advantageous manner, said second supporting body 122, for said second surface 141, 142 for engaging and holding by suctioning the same product 11, is movable with respect to said first supporting body 121, for said first surface 141 for engaging and holding by suctioning the same product 11, in a position, in particular a resting or lifted position, in which said first and second supporting bodies 121, 122 are aligned or substantially mutually aligned.

**[0099]**

In an advantageous manner, said first 141 and second 142 surfaces for engaging and holding by suctioning the same product 11 are movable with respect to one another in a position, in particular an engaging position of the product 11 , in which they are angularly spaced apart, in particular by 90°, or substantially by 90°, in particular well illustrated in said figures 4B to 4D and 6A to 6D.

**[0081]**

Advantageously, as is clear from said figures 4B to 4D and 6A to 6D, said first and second supporting bodies 121, 122 respectively for said first and second surfaces 141, 142 for engaging and holding by suctioning the same product are movable one with respect to the other one, in a position, in particular an engaging position of the product 11 , in which they are angularly spaced apart from one another, in particular by 90°, or substantially by 90°.

**[0082]**

As is clear from said figures 4A to 6D, particularly advantageously, said second surface 142 for engaging and holding by suctioning the same product 11 is movable with respect to the first surface 141 for engaging and holding by suctioning the same product 11 in a position, in particular an engaging position of the product 11 , in which they are angularly spaced apart, in particular by 90°, or substantially by 90°.

**[0083]**

Advantageously, as is clear from said figures 4A to 6D, said second supporting body 122, for said second surface 141, 142 for engaging and holding by suctioning the same product 11 , is movable with respect to said first supporting body 121, for said first surface 141 for engaging and holding by suctioning the same product 11, in a position, in particular an engaging position of the product 11 , in which they are angularly spaced apart from one another, in particular by 90°, or substantially by 90°.

**[0084]**

Particularly advantageously, as is most clear from figure 4B, means 30 for a relative rotation between a first 141 and a second 142 surfaces for engaging and holding by suctioning the same product 11 are provided, in particular according to a respective angular direction, especially by an angle

**[0104]**

equal to, or substantially equal to, 90°, especially between a position in which said first 141 and second 142 surfaces for engaging and holding by suctioning the same product 11 are aligned or substantially mutually aligned, and a position in which said first 141 and second 142 surfaces for engaging and holding by suctioning the same product 11 are angularly spaced apart, in particular by 90°, or substantially by 90°.

**[0085]**

As is clear as is most clear from said figure 4B, with advantage, means 30 for a relative rotation of the second surface 142 for engaging and holding by suctioning the same product 11 are provided, with respect to the surface 141 for engaging and holding by suctioning the same product 11 , in particular according to a respective angular direction, especially by an angle equal to, or substantially equal to, 90°, especially between a position in which said first 141 and second 142 surfaces for engaging and holding by suctioning the same product 11 are aligned or substantially mutually aligned, and a position in which said first 141 and second 142 surfaces for engaging and holding by suctioning the same product 11 are angularly spaced apart, in particular by 90°, or substantially by 90°.

**[0086]**

Advantageously, as is most clear from figure 4B, means 30 for a rotation between a first and a second supporting bodies 121 , 122 respectively for said first and second surfaces 141 , 142 for engaging and holding by suctioning the same product are provided, in particular according to a respective angular direction, in particular by an angle equal to, or substantially equal to, 90°, especially between a position in which said first 141 and second 142 surfaces for engaging and holding by suctioning the same product 11 are aligned or substantially mutually aligned, and a position in which said first 141 and second 142 surfaces for engaging and holding by suctioning the same product 11 are angularly spaced apart, in particular by 90°, or substantially by 90°.

**[0087]**

Advantageously, as is clear from said figures 4A to 6D, means 30 for

**[0108]**

a rotation of said second supporting body 122 are provided, for said second surface 141, 142 for engaging and holding by suctioning the same product 11, is movable with respect to said first supporting body 121, for said first surface 141 for engaging and holding by suctioning the same product 11, in particular according to a respective angular direction, in particular by an angle equal to, or substantially equal to, 90°, especially between a position in which said first 141 and second 142 surfaces for engaging and holding by suctioning the same product 11 are aligned or substantially mutually aligned, and a position in which said first 141 and second 142 surfaces for engaging and holding by suctioning the same product 11 are angularly spaced apart, in particular by 90°, or substantially by 90°.

**[0088]**

As is clear from said figures 4A to 6D, in an advantageous manner, said rotation between said first 141 and second 142 surfaces for engaging and holding by suctioning the same product, and/or between said first and second supporting bodies 121, 122 respectively for said first and second surfaces 141, 142 for engaging and holding by suctioning the same product said first 141 and second 142 surfaces for engaging and holding by suctioning the same product, occurs according to a respective horizontal axis.

**[0089]**

With advantage, as is clear from said figures 4A to 6D, said rotation between said first 141 and second 142 surfaces for engaging and holding by suctioning the same product, and/or between said first and second supporting bodies 121, 122 respectively for said first and second surfaces 141 , 142 for engaging and holding by suctioning the same product said first 141 and second 142 surfaces for engaging and holding by suctioning the same product, occurs according to an axis parallel to the adjacent sides of said first 141 and second 142 surfaces for engaging and holding by suctioning the same product, and/or said first and second supporting bodies 121 , 122 respectively for said first and second surfaces 141, 142 for engaging and holding by suctioning the same product.

**[0111]**

Advantageously, as is clear from said figures 4A to 6D, said rotation means 30 are provided for between said first 141 and said second 142 surfaces for engaging and holding by suctioning the same product, and/or between said first and said secondo supporting bodies 121, 122 respectively for said first and second surfaces 141 , 142 for engaging and holding by suctioning the same product, are in the form of, or defined by, a corresponding rotation hinge 30.

**[0090]**

As is clear from said figures 4A to 6D, particularly advantageously, said rotation means, or respective hinge, 30 are at the connecting means 123 between said first and second supporting bodies 121 , 122 respectively of said first and second surfaces 141, 142 for engaging and holding by suctioning the same product.

**[0091]**

Advantageously, as is clear from said figures 4A to 6D, said rotation means, or respective hinge, 30 are provided for between a first part 123’ of said connecting means 123 between said first and second supporting bodies 121 , 122, which is integral to, and/or projecting from, said first supporting body 121, and a second part 123” of said connecting means 123 between said first and second supporting bodies 121, 122, which is integral to, and/or projecting from, said second supporting body 121, 122. In an advantageous manner, as is clear from said figures 4A to 6D, said rotation means, or respective hinge, 30 are adapted to arrange said first 141 and second 142 surfaces for engaging and holding by suctioning the same product on the same plane, in particular a horizontal plane, i.e. , in a mutually aligned condition. As is clear from said figures 4A to 6D, with advantage, said rotation means, or respective hinge, 30 are adapted to arrange said first 141 and second 142 surfaces for engaging and holding by suctioning the same product on planes that are angularly spaced apart from one another, in particular on planes that are angularly spaced apart from one another by 90°.

**[0114]**

Advantageously, as is clear from said figures 4A to 6D, said rotation means, or respective hinge, 30 are in a position above said first surface 141 for engaging and holding by suctioning the same product and/or said second surface 142 for engaging and holding by suctioning the same product, in particular in a mutually aligned condition.

**[0092]**

As is clear from said figures 4A to 6D, particularly advantageously, said second surface 142 for engaging and holding by suctioning the same product 11, and/or the corresponding supporting body 121, in the position, in particular for engaging the product 11 , in which it is angularly rotated, in particular by 90°, or substantially by 90°, extends inferiorly with respect to said first surface 142 for engaging and holding by suctioning the same product 11 , and/or with respect to the corresponding supporting body 121 , in particular corresponding, or substantially corresponding, to the arrangement of the preferred implementation above. In this manner, by virtue of the present possibility to rotate, the device can thus be configurated in a completely lifted position, which allows a movement of the device such as to avoid respective products 11 and at a height level that is advantageous or substantially corresponding to that for gripping the respective product 11, as is clear from figures 4A to 4D, i.e. , which allows taking flat product or articles, for example cardboard sheets 11 ’ to be used to create stacks of products 11 , as is clear from said figures 5A to 5G.

**[0093]**

Advantageously, as is clear from said figures 6A to 6D, said first 141 and second 142 surfaces for engaging and holding by suctioning the same product are movable one with respect to the other one with a translating movement, in particular parallel to the other surface 141 for engaging and holding by suctioning the same product; in particular said second surface 142 for engaging and holding by suctioning the same product, or vertically positioned surface, is movable parallel to the first engaging and holding

**[0117]**

surface 141, or horizontally positioned surface.

**[0094]**

As is clear from said figures 6A to 6D, in an advantageous manner, said first and second supporting bodies 121, 122 respectively for said first and second surfaces 141, 142 for engaging and holding by suctioning the same product are movable one with respect to the other with a translating movement, in particular parallel to the surface 141 for engaging and holding by suctioning the same product, of the other supporting body 121. In particular said second supporting body 122 of said second surface 142 for engaging and holding by suctioning the same product, or vertically positioned surface, is movable parallel to the first engaging and holding surface 141 , or horizontally positioned surface, i.e. , parallel to said first supporting body 121 of said first surface 141 for engaging and holding by suctioning the same product 11.

**[0095]**

Particularly advantageously, as is clear from said figures 6A to 6D, means for the actuation of the relative translating movement between said first 141 and second 142 surfaces for engaging and holding by suctioning the same product are provided, i.e., between said first and second supporting bodies 121, 122 respectively for said first and second surfaces 141, 142 for engaging and holding by suctioning the same product. Particularly advantageously, as is clear from said figures 6A to 6D said first 141 and second 142 surfaces for engaging and holding by suctioning the same product, and/or said first and second supporting bodies 121 , 122 respectively for said first and second surfaces 141, 142 for engaging and holding by suctioning the same product, are respectively movable with a translating movement, forwards and backwards, between a respective mutually moved-farther position and a respective moved-closer position, in particular for gripping the product 11.

**[0096]**

Advantageously, as is clear from said figures 6A to 6D, said means for the actuation of the relative translating movement between said first 141 and

**[0121]**

second 142 surfaces for engaging and holding by suctioning the same product, i.e., between said first and second supporting bodies 121 , 122 respectively for said first and second surfaces 141, 142 for engaging and holding by suctioning the same product, are adapted to move said connecting means 123 between said first and second supporting bodies 121, 122 respectively for said first and second surfaces 141, 142 for engaging and holding by suctioning the same product, with respect to said first supporting body 121.

**[0097]**

In particular, as illustrated in the figures 6A to 6D, said connecting means 123 between said first and second supporting bodies 121, 122 respectively for said first and second surfaces 141, 142 for engaging and holding by suctioning the same product, move longitudinally with respect to said first supporting body 121 , in particular entering again and extending into, or with respect, thereto. For example, this translating movement could be provided by corresponding pneumatic means, in particular a pneumatic cylinder, i.e., of the electromechanic type, which move said connecting means 123 between said first and second supporting bodies 121, 122 respectively for said first and second surfaces 141, 142 for engaging and holding by suctioning the same product.

**[0098]**

In this manner, it is possible to hold the product firm with the upper engaging and holding surface 141 and subsequently contact it with the lower or side engaging and holding surface 142. This type of grip is particularly advantageous, for example, when the product to be grasped has a limited weight, as occurs for products or packs in the tissue field. In practice, said upper engaging and holding surface 141 easily engages the product, having the contrast of the opposite lower surface onto which it rests, and it is thus possible to contact the same product laterally by the lower or side engaging and holding surface 142, without the risk to move in an undesired manner the

**[0124]**

same product.

**[0099]**

In practice, as is clear, the technical characteristics illustrated above allow, singularly or in a respective combination to achieve one or more of the following advantageous results: - it is possible to easily grasp the product, in particular without providing excessive stresses to the same product, especially to the peripheral surface of the same product, i.e. , to the film, or sheet, of the package wrapping respective articles, for example to the film, or sheet, which wraps corresponding toilet paper rolls; - it is possible to operate in a delicate manner, i.e., without creating excessive stress peaks at the surface of the product to be grasped produced, and the product can thus be taken without damaging the outer envelope, for example of plastic material, which wraps the respective articles, for example in the form of toilet paper rolls wrapped in a respective packaging plastic film; - it is possible to exert a greater holding action upon the less-stressed side surface of the product;

**[0100]**

- it is possible to exert a movement of the device such as to avoid respective products and at a height level substantially corresponding to the grasping level of the respective product; - it is possible to take flat products or articles, for example cardboard sheets to be used to create stacks of products;

**[0101]**

- it is possible to un movement of the device such as to avoid respective products and at a height level that is advantageous or substantially corresponding to the grasping level of the respective product; - it is possible to take flat products or articles, for example cardboard sheets to be used to create stacks of products;

**[0102]**

- it is further possible to easily grasp products that have a limited weight, as occurs for the products or packs of the tissue field.

**[0129]**

The present invention is susceptible of a clear industrial application. Those skilled in the art will be able to devise a number of modifications and/or variations to be made to the same invention, while remaining within the scope of the innovative concept, as broadly set forth. Furthermore, those skilled in the art will be able to devise further preferred implementations of the invention that comprise one or more of the characteristics illustrated above of the preferred implementation. Furthermore, it is also understood that all the details of the invention can be replaced by technically equivalent elements.

## Classifications

- B25J15/0616
- B25B11/00
- B25J15/0061
- B25J15/06
- B25J15/0691
- B65G47/91
- B65G47/918
- B65G57/005
- B66C1/02
- B66C1/02
- B66C1/0243
- B66C1/0262
- B66C1/0268
- B66C1/0281
- B66C1/0287

## Cited patent documents

- [JP-2013248695-A](https://patents.google.com/patent/JP2013248695A/en) — ISR
- [US-2007280812-A1](https://patents.google.com/patent/US20070280812A1/en) — ISR
- [US-2010239408-A1](https://patents.google.com/patent/US20100239408A1/en) — ISR
- [US-2018297200-A1](https://patents.google.com/patent/US20180297200A1/en) — ISR
- [US-9498887-B1](https://patents.google.com/patent/US9498887B1/en) — ISR

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
