# 14. Vacuum-load adhering device for lifting e.g. natural stone slabs, has suction space staying in connection with another suction space, and suction plate possessing larger dimension than another suction plate

- **Archive rank:** 14 of 50
- **Publication:** [DE-102009047815-A1](https://patents.google.com/patent/DE102009047815A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/043662631/publication/DE102009047815A1?q=pn%3DDE102009047815A1)
- **Publication date:** 2011-03-31
- **Filing date:** 2009-09-30
- **Earliest priority:** 2009-09-30
- **Family:** 43662631
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** PROBST GREIFTECHNIK VERLEGESYSTEME GMBH

## Abstract

The device has two suction plates (5, 10) comprising sealing components (6, 12) that are arranged at retaining plates (8, 13), respectively. The components enclose suction spaces (7, 11), where one of the spaces stays in connection with a vacuum device. Another one of the spaces stays in connection with the former space in a tight manner when one of the components stays in connection with one of the retaining plates. One of the components cooperates with a received plate in a sealed manner and one of the suction plates possesses larger dimension than another one of the suction plates.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-102009047815-A1/000.png)

![Sketch 1 for DE-102009047815-A1](https://nimo.iptorch.com/refdrawing/DE-102009047815-A1/000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/4b/28/1b/5d9d5b67d06614/00170000.png)

![Sketch 2 for DE-102009047815-A1](https://patentimages.storage.googleapis.com/4b/28/1b/5d9d5b67d06614/00170000.png)

## Claims

### Claim 1 (independent)

Vakuum-Lasthaftgerät zum Anheben von Gegenständen mit einer ansaugbaren Fläche, insbesondere von Beton- oder Natursteinplatten, mit einer einen Unterdruck erzeugenden Vakuum-Einrichtung (4) in einem Grundkörper (2) und einer an dem Grundkörper (2) anordenbaren ersten Saugplatte (5), die ein mit einer aufzunehmenden Platte zusammenwirkendes erstes Dichtmittel (6) aufweist, wobei das erste Dichtmittel (6) an einer ersten Halteplatte (8) angeordnet ist und einen ersten Saugraum (7) umschließt, der mit der Vakuum-Einrichtung (4) in Verbindung steht, dadurch gekennzeichnet, dass eine zweite Saugplatte (10) vorgesehen ist, die ein zweites Dichtmittel (12) aufweist, das mit einer aufzunehmenden Platte abdichtend zusammenwirkt, wobei das zweite Dichtmittel (12) an einer zweiten Halteplatte (13) angeordnet ist und einen zweiten Saugraum (11) der zweiten Saugplatte (10) umschließt, der mit dem ersten Saugraum (7) dicht in Verbindung steht, wenn das erste Dichtmittel (6) abdichtend mit der zweiten Halteplatte (13) in Verbindung steht, wobei die erste Saugplatte (5) eine andere Abmessung besitzt, als die zweite Saugplatte (10).Vacuum-load device for lifting objects with a suctionable surface, in particular concrete or natural stone slabs, with a negative pressure generating vacuum device ( 4 ) in a basic body ( 2 ) and one on the main body ( 2 ) can be arranged first suction plate ( 5 ), which cooperates with a male plate first sealing means ( 6 ), wherein the first sealant ( 6 ) on a first holding plate ( 8th ) is arranged and a first suction chamber ( 7 ), which is connected to the vacuum device ( 4 ), characterized in that a second suction plate ( 10 ) is provided, which is a second sealant ( 12 ) which sealingly cooperates with a male plate, the second sealant ( 12 ) on a second holding plate ( 13 ) is arranged and a second suction chamber ( 11 ) of the second suction plate ( 10 ), which is connected to the first suction chamber ( 7 ) is tightly connected when the first sealant ( 6 ) sealingly with the second retaining plate ( 13 ), wherein the first suction plate ( 5 ) has a different dimension than the second suction plate ( 10 ).

### Claim 2

Vakuum-Lasthaftgerät nach Anspruch 1, dadurch gekennzeichnet, dass die zweite Saugplatte (10) mit einer Befestigungsvorrichtung (15) an dem Vakuum-Lasthaftgerät (1) derart befestigbar ist, dass das erste Dichtmittel (6) abdichtend mit der zweiten Halteplatte (13) zusammenwirkt.Vacuum load device according to claim 1, characterized in that the second suction plate ( 10 ) with a fastening device ( 15 ) on the vacuum load device ( 1 ) is attachable such that the first sealant ( 6 ) sealingly with the second retaining plate ( 13 ) cooperates.

### Claim 3

Vakuum-Lasthaftgerät nach Anspruch 1, dadurch gekennzeichnet, dass die zweite Saugplatte (10) eine größere Abmessung besitzt als die erste Saugplatte (5).Vacuum load device according to claim 1, characterized in that the second suction plate ( 10 ) has a larger dimension than the first suction plate ( 5 ).

### Claim 4

Vakuum-Lasthaftgerät nach Anspruch 1, dadurch gekennzeichnet, dass die zweite Saugplatte (10) eine kleiner Abmessung besitzt, als die erste Saugplatte (5).Vacuum load device according to claim 1, characterized in that the second suction plate ( 10 ) has a smaller dimension than the first suction plate ( 5 ).

### Claim 5

Vakuum-Lasthaftgerät nach Anspruch 1, dadurch gekennzeichnet, dass eine dritte Saugplatte (20) vorgesehen ist, die ein drittes Dichtmittel (21) aufweist, das abdichtend mit einer aufzunehmenden Platte zusammenwirkt, wobei das dritte Dichtmittel (21) an einer dritten Haltplatte (22) angeordnet ist und einen dritten Saugraum (24) umschließt, der mit dem zweiten Saugraum (11) dicht in Verbindung steht, wobei das zweite Dichtmittel (12) abdichtend mit der dritten Halteplatte (22) zusammenwirkt.Vacuum-load device according to claim 1, characterized in that a third suction plate ( 20 ), which is a third sealant ( 21 ) which sealingly cooperates with a male plate, the third sealant ( 21 ) on a third holding plate ( 22 ) is arranged and a third suction chamber ( 24 ), which communicates with the second suction chamber ( 11 ), the second sealant ( 12 ) sealingly with the third retaining plate ( 22 ) cooperates.

### Claim 6

Vakuum-Lasthaftgerät nach einem der Ansprüche 1 bis 5, dadurch gekennzeichnet, dass der erste Saugraum (7) über eine in der ersten Halteplatte (8) vorgesehene erste Öffnung (9) mit der Vakuum-Einrichtung (4) dicht in Verbindung steht.Vacuum-load device according to one of claims 1 to 5, characterized in that the first suction chamber ( 7 ) via one in the first holding plate ( 8th ) provided first opening ( 9 ) with the vacuum device ( 4 ) is tightly connected.

### Claim 7

Vakuum-Lasthaftgerät nach einem der Ansprüche 1 bis 6, dadurch gekennzeichnet, dass der zweite Saugraum (11) über eine in der zweiten Halteplatte (13) vorgesehene zweite Öffnung (14) mit dem ersten Saugraum (7) dicht in Verbindung steht.Vacuum-load device according to one of claims 1 to 6, characterized in that the second suction chamber ( 11 ) via a in the second holding plate ( 13 ) provided second opening ( 14 ) with the first suction chamber ( 7 ) is tightly connected.

### Claim 8

Vakuum-Lasthaftgerät nach einem der Ansprüche 15 bis 7, dadurch gekennzeichnet, dass der dritte Saugraum (24) über eine in der dritten Halteplatte (22) vorgesehene dritte Öffnung (23) mit dem zweiten Saugraum (11) dicht in Verbindung steht.Vacuum-load device according to one of claims 15 to 7, characterized in that the third suction chamber ( 24 ) via a in the third retaining plate ( 22 ) provided third opening ( 23 ) with the second suction chamber ( 11 ) is tightly connected.

### Claim 9

Vakuum-Lastkraftgerät nach einem der Ansprüche 1 bis 8, dadurch gekennzeichnet, dass eine weitere Befestigungsvorrichtung vorgesehen ist, mit der die dritte Saugplatte (20) derart an dem Vakuum-Lasthaftgerät (1) befestigbar ist, dass das zweite Dichtmittel (12) abdichtend mit der dritten Halteplatte (22) zusammenwirkt.Vacuum load device according to one of claims 1 to 8, characterized in that a further fastening device is provided, with which the third suction plate ( 20 ) on the vacuum load device ( 1 ) is attachable, that the second sealant ( 12 ) sealingly with the third retaining plate ( 22 ) cooperates.

### Claim 10

Vakuum-Lasthaftgerät nach einem der Ansprüche 2 bis 9, dadurch gekennzeichnet, dass die Befestigungsvorrichtung (15) die Form eines Schnellverschlusses aufweist.Vacuum-load device according to one of claims 2 to 9, characterized in that the fastening device ( 15 ) has the form of a quick release.

### Claim 11

Vakuum-Lasthaftgerät nach Anspruch 9 oder 10, dadurch gekennzeichnet, dass die weitere Befestigungsvorrichtung die Form eines Schnellverschlusses aufweist.Vacuum-load device according to claim 9 or 10, characterized in that the further fastening device has the shape of a quick release.

### Claim 12

Vakuum-Lasthaftgerät nach Anspruch 10 oder 11, dadurch gekennzeichnet, dass der Schnellverschluss ein Hakenteil (17), das an der zweiten Halteplatte (13) befestigt ist, und ein Bügelteil (16) umfasst, das in dem Hakenteil (17) arretierbar und durch Betätigen eines Handgriffteiles (18) derart spannbar ist, dass das Hakenteil (16) in Richtung auf die erste Saugplatte (5) gezogen wird.Vacuum-load device according to claim 10 or 11, characterized in that the quick release a hook part ( 17 ), which on the second retaining plate ( 13 ) is attached, and a strap part ( 16 ), which in the hook part ( 17 ) and by pressing a handle part ( 18 ) is tensioned so that the hook part ( 16 ) in the direction of the first suction plate ( 5 ) is pulled.

### Claim 13

Vakuum-Lasthaftgerät nach Anspruch 12, dadurch gekennzeichnet, dass der Schnellverschluss ein Hakenteil, das an der dritten Halteplatte (22) befestigt ist, und ein Bügelteil (16) umfasst, das in dem Hakenteil (17) arretierbar und durch Betätigen eines Handgriffteiles derart spannbar ist, dass das Hakenteil in Richtung auf die zweite Halteplatte (13) gezogen wird.Vacuum-load device according to claim 12, characterized in that the quick release a hook portion, on the third holding plate ( 22 ) is attached, and a strap part ( 16 ), which in the hook part ( 17 ) can be locked and tensioned by operating a handle part such that the hook part in the direction of the second holding plate ( 13 ) is pulled.

### Claim 14

Vakuum-Lasthaftgerät nach Anspruch 12 oder 13, dadurch gekennzeichnet, dass das Handgriffteil (18) am Grundkörper (2) befestigt ist.Vacuum load device according to claim 12 or 13, characterized in that the handle part ( 18 ) on the base body ( 2 ) is attached.

### Claim 15

Vakuum-Lasthaftgerät nach einem der Ansprüche 2 bis 9, dadurch gekennzeichnet, dass die Befestigungsvorrichtung (15) die Form eines Bajonettverschlusses aufweist.Vacuum-load device according to one of claims 2 to 9, characterized in that the fastening device ( 15 ) has the form of a bayonet closure.

### Claim 16

Vakuum-Lasthaftgerät nach Anspruch 15, dadurch gekennzeichnet, dass der Bajonettverschluss in dem ersten Saugraum (7), vorzugsweise die erste Öffnung (9) umgebend, angeordnet ist.Vacuum-load device according to claim 15, characterized in that the bayonet closure in the first suction chamber ( 7 ), preferably the first opening ( 9 ) is arranged.

### Claim 17

Vakuum-Lasthaftgerät nach einem der Ansprüche 9 bis 16, dadurch gekennzeichnet, dass die weitere Befestigungsvorrichtung die Form eines Bajonettverschlusses aufweist.Vacuum-load device according to one of claims 9 to 16, characterized in that the further fastening device has the form of a bayonet closure.

### Claim 18

Vakuum-Lasthaftgerät nach Anspruch 17, dadurch gekennzeichnet, dass der weitere Bajonettverschluss in dem zweiten Saugraum (11), vorzugsweise die zweite Öffnung (14) umgebend, angeordnet ist.Vacuum-load device according to claim 17, characterized in that the further bayonet closure in the second suction chamber ( 11 ), preferably the second opening ( 14 ) is arranged.

### Claim 19

Vakuum-Lasthaftgerät nach einem der Ansprüche 15 bis 18, dadurch gekennzeichnet, dass die ersten Elemente des Bajonettverschlusses an der ersten Halteplatte (8) der ersten Saugplatte (5) oder der zweiten Halteplatte (13) der zweiten Saugplatte (10) oder der dritten Halteplatte (22) der dritten Saugplatte (20) befestigt sind und dass die zweiten Elemente des Bajonettverschlusses an der zweiten Halteplatte (13) der zweiten Saugplatte (10) oder der dritten Halteplatte (22) der dritten Saugplatte (20) oder an einer weiteren Halteplatte einer weiteren Saugplatte angeordnet sind.Vacuum-load device according to one of claims 15 to 18, characterized in that the first elements of the bayonet closure on the first holding plate ( 8th ) of the first suction plate ( 5 ) or the second holding plate ( 13 ) of the second suction plate ( 10 ) or the third holding plate ( 22 ) of the third suction plate ( 20 ) and that the second elements of the bayonet lock on the second retaining plate ( 13 ) of the second suction plate ( 10 ) or the third holding plate ( 22 ) of the third suction plate ( 20 ) or on a further holding plate of a further suction plate are arranged.

### Claim 20

Vakuum-Lasthaftgerät nach einem der Ansprüche 1 bis 19, dadurch gekennzeichnet, dass die erste Saugplatte (5) zum Ansaugen einer ersten Platte (A) dient, dass die zweite Saugplatte (10) zum Ansaugen einer zweiten Platte (B) dient, wobei das Format der zweiten Platte (B) größer, vorzugsweise doppelt so groß, ist, wie das Format der ersten Platte (A).Vacuum load device according to one of claims 1 to 19, characterized in that the first suction plate ( 5 ) for sucking a first plate (A), that the second suction plate ( 10 ) is used for sucking a second plate (B), wherein the format of the second plate (B) is larger, preferably twice as large, as the format of the first plate (A).

### Claim 21

Vakuum-Lasthaftgerät nach einem der Ansprüche 1 bis 20, dadurch gekennzeichnet, dass die erste Saugplatte (15) fest an dem Grundkörper (2) montiert istVacuum load device according to one of claims 1 to 20, characterized in that the first suction plate ( 15 ) fixed to the base body ( 2 ) is mounted

### Claim 22

Vakuum-Lasthaftgerät nach einem der Ansprüche 1 bis 20, dadurch gekennzeichnet, dass die erste Saugplatte (5) mit dem Grundkörper (2) vorzugsweise mit einer Wechseleinrichtung verbindbar ist.Vacuum load device according to one of claims 1 to 20, characterized in that the first suction plate ( 5 ) with the basic body ( 2 ) is preferably connectable to a changing device.

## Full description

"Global patent litigation datasetâ by Darts-ip is licensed under a Creative Commons Attribution 4.0 International License.FIXED CONSTRUCTIONSBUILDINGSCAFFOLDING; FORMS; SHUTTERING; BUILDING IMPLEMENTS OR AIDS, OR THEIR USE; HANDLING BUILDING MATERIALS ON THE SITE; REPAIRING, BREAKING-UP OR OTHER WORK ON EXISTING BUILDINGSPreparing, conveying, or working-up building materials or building elements in situ; Other devices or measures for constructional workConveying or assembling building elementsTools or apparatusPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansMultiple lifting units; More than one suction areaFIXED CONSTRUCTIONSCONSTRUCTION OF ROADS, RAILWAYS, OR BRIDGESCONSTRUCTION OF, OR SURFACES FOR, ROADS, SPORTS GROUNDS, OR THE LIKE; MACHINES OR AUXILIARY TOOLS FOR CONSTRUCTION OR REPAIRMachines, tools or auxiliary devices for preparing or distributing paving materials, for working the placed materials, or for forming, consolidating, or finishing the pavingApparatus for laying individual preformed surfacing elements, e.g. kerbstonesApparatus for laying individual preformed surfacing elements, e.g. kerbstones using suction devicesFIXED CONSTRUCTIONSBUILDINGSCAFFOLDING; FORMS; SHUTTERING; BUILDING IMPLEMENTS OR AIDS, OR THEIR USE; HANDLING BUILDING MATERIALS ON THE SITE; REPAIRING, BREAKING-UP OR OTHER WORK ON EXISTING BUILDINGSPreparing, conveying, or working-up building materials or building elements in situ; Other devices or measures for constructional workConveying or assembling building elementsTools or apparatusTools or apparatus specially adapted for working-up plates, panels or slab shaped building elements

Description

Translated from German

Die vorliegende Erfindung betrifft ein Vakuum-LasthaftgerÃ¤t zum Anheben von GegenstÃ¤nden, insbesondere von groÃformatigen Platten, die aus einem Betonmaterial oder aus Naturstein bestehen.The present invention relates to a vacuum load-holding device for lifting objects, in particular large-sized plates, which consist of a concrete material or natural stone.

Vakuum-LasthaftgerÃ¤te zum Verlegen von Platten, insbesondere von groÃformatigen Platten aus Beton- oder Natursteinen, sind bekannt. Beispielsweise geht aus der DE 43 27 663 C2 eine Vakuum-Hebeeinrichtung fÃ¼r Steinelemente hervor, die einen GrundkÃ¶rper aufweist, der mit der Hilfe einer AufhÃ¤ngeeinrichtung am Kranhaken oder dergleichen eines motorisch verfahrbaren ArbeitsgerÃ¤tes befestigbar ist. In dem GrundkÃ¶rper ist eine Vakuum-Einrichtung in der Form einer Vakuumpumpe zur Erzeugung eines Vakuums angeordnet. Die Vakuum-Einrichtung ist mit einer Vakuum-Saugvorrichtung zum Ansaugen der zu verlegenden Platten verbunden. Dabei wird die Vakuum-Saugeinrichtung auf eine ansaugbare OberflÃ¤che der jeweils anzusaugenden Platte aufgebracht. Ferner ist an dem GrundkÃ¶rper ein Handgriffteil vorgesehen, mit dessen Hilfe die am Kranhaken des verfahrbaren ArbeitsgerÃ¤tes hÃ¤ngende Vakuum-Hebeeinrichtung zum Verlegen der durch die Vakuum-Saugeinrichtung angesaugten Platten manipulierbar ist.Vacuum load-holding devices for laying panels, in particular large-sized panels made of concrete or natural stones, are known. For example, goes from the DE 43 27 663 C2 a vacuum lifting device for stone elements, which has a base body which can be fastened with the aid of a suspension device on the crane hook or the like of a motor-driven working device. In the main body, a vacuum device in the form of a vacuum pump for generating a vacuum is arranged. The vacuum device is connected to a vacuum suction device for sucking the plates to be laid. In this case, the vacuum suction device is applied to a suctionable surface of each plate to be sucked. Further, a handle part is provided on the main body, with the help of which the crane hook of the movable working device hanging vacuum lifting device for laying the sucked by the vacuum suction plate is manipulated.

Der derzeit aktuelle architektonische Trend bei der Gestaltung von Wegen und PlÃ¤tzen geht immer mehr hin zu groÃformatigen Platten in der Form von Beton- oder Natursteinen. Da die aus solchen Platten hergestellten BelÃ¤ge auch von Lieferfahrzeugen und dergleichen befahrbar sein sollen, wird Ã¼blicherweise die Dicke der Steinplatten und damit auch deren Gewicht vergrÃ¶Ãert. Eine fachgerechte und schonende Verlegung ohne BeschÃ¤digung von solchen hochwertigen und schweren Platten kann daher nur mit der Hilfe von Vakuum-LasthaftgerÃ¤ten erfolgen.The current architectural trend in the design of paths and squares is increasingly towards large-format slabs in the form of concrete or natural stone. Since the coverings produced from such plates should also be passable by delivery vehicles and the like, the thickness of the stone plates and thus also their weight is usually increased. A professional and careful installation without damaging such high-quality and heavy plates can therefore only be done with the help of vacuum load-securing devices.

Das Verlegen der genannten Platten erfolgt Ã¼blicherweise im so genannten âLÃ¤uferverbandâ oder âHalbsteinverbandâ. Ein solcher Verband ist in der 1 dargestellt. Dabei weist die Ã¼berwiegende Mehrzahl der Platten ein groÃes, vorzugsweise rechteckiges Format B auf. An zwei sich gegenÃ¼berliegenden RÃ¤ndern eines solchen, beispielsweise entlang einer Bordsteinkante verlegten Platten, benÃ¶tigt man jedoch auch rechteckige, kleinere Platten im Format A, um das gewÃ¼nschte Verlegemuster zu erzielen. Zumeist sind die Platten mit dem Format A nur halb so lang wie die Platten mit dem Format B.The laying of said plates is usually done in the so-called "runners association" or "half-cast". Such a bandage is in the 1 shown. In this case, the vast majority of plates on a large, preferably rectangular format B on. On two opposite edges of such, for example, laid along a curb edge plates, but you also need rectangular, smaller plates in the format A to achieve the desired laying pattern. In most cases, the format A plates are only half as long as the B. format plates.

Im Zusammenhang mit der Herstellung solcher PlattenbelÃ¤ge ist es bekannt, dass die Vakuum-Saugeinrichtungen der derzeit eingesetzten Vakuum-LasthaftgerÃ¤te Befestigungsvorrichtungen zum Anbau von Saugplatten unterschiedlicher GrÃ¶Ãen aufweisen. Dabei muss ein derartiges, bekanntes Vakuum-LasthaftgerÃ¤t in der folgenden Weise betrieben werden: Wenn zum Verlegen von Platten im grÃ¶Ãeren Format B (1) eine Saugplatte verwendet wird, die mehr als die HÃ¤lfte der OberflÃ¤che des Formates B bedeckt, wobei ein bestimmter Unterdruck durch die Vakuum-Saugeinrichtung erzeugt wird, muss zum Verlegen einer Platte des kleineren Formates A die zuvor verwendete Saugplatte fÃ¼r das grÃ¶Ãere Format B von der Vakuum-Saugeinrichtung abgebaut und durch eine kleinere Saugplatte mit dadurch verminderter Tragkraft ersetzt werden. Dies bedeutet, dass im Beispiel der 1 zwei verschieden groÃe Saugplatten erforderlich sind. Im dargestellten Beispiel muss nach dem Verlegen von spÃ¤testens drei Platten im Format B in bestimmten Reihen jeweils eine Platte im Format A verlegt werden. Hierzu mÃ¼ssen die Saugplatten gewechselt werden. Dieser Austausch von Saugplatten fÃ¼hrt dazu, dass dabei mehr Zeit benÃ¶tigt wird, als zum eigentlichen Verlegen der Platten. Es geht daher sehr viel kostspielige Arbeitszeit verloren. Dies gilt auch dann, wenn der Austausch der Saugplatten mit auf dem Markt verfÃ¼gbaren, so genannten Schnellwechselsystemen erfolgt.In connection with the production of such plate coverings, it is known that the vacuum suction devices of the vacuum load devices currently used have fastening devices for mounting suction plates of different sizes. In this case, such a known vacuum-load device must be operated in the following manner: If for laying of plates in the larger format B ( 1 ) a suction plate is used, which covers more than half of the surface of the format B, wherein a certain negative pressure is generated by the vacuum suction device, for laying a plate of the smaller format A, the previously used suction plate for the larger format B of the Vacuum suction degraded and replaced by a smaller suction plate with reduced load capacity. This means that in the example of the 1 two different sized suction plates are required. In the example shown, after the laying of at the latest three plates in format B, one plate in format A must be laid in each case in certain rows. For this, the suction plates must be changed. This replacement of suction plates means that more time is needed than actually laying the plates. It is therefore lost a lot of costly working hours. This also applies if the replacement of the suction plates with so-called quick-change systems available on the market takes place.

Die Aufgabe der vorliegenden Erfindung besteht daher darin, ein Vakuum-LastkraftgerÃ¤t so auszugestalten, dass eine schnelle und effiziente sowie kostengÃ¼nstige Verlegung von Platten unterschiedlicher Formate ermÃ¶glicht wird.The object of the present invention is to design a vacuum load device so that a fast and efficient and cost-effective installation of plates of different formats is made possible.

Diese Aufgabe wird durch ein Vakuum-LasthaftgerÃ¤t zum Anheben von plattenfÃ¶rmigen GegenstÃ¤nden, insbesondere von Beton- oder Natursteinplatten, gelÃ¶st, die eine einen Unterdruck erzeugende Vakuum-Einrichtung in einem GrundkÃ¶rper und eine an dem GrundkÃ¶rper angordenbare erste Saugplatte umfasst, die ein mit einer aufzunehmenden Platte zusammenwirkendes erstes Dichtmittel aufweist, wobei das erste Dichtmittel an einer ersten Halteplatte angeordnet ist und einen ersten Saugraum umschlieÃt, der Ã¼ber eine in der ersten Halteplatte vorgesehene erste Ãffnung mit der Vakuum-Einrichtung in Verbindung steht. Das Vakuum-LasthaftgerÃ¤t weist wenigstens eine zweite Saugplatte auf, die ein zweites Dichtmittel besitzt, das mit einer aufzunehmenden Platte abdichtend zusammenwirkt, wobei das zweite Dichtmittel an einer zweiten Halteplatte angeordnet ist und einen zweiten Saugraum der zweiten Saugplatte umschlieÃt, der Ã¼ber eine in der zweiten Halteplatte angeordnete zweite Ãffnung mit dem ersten Saugraum dicht in Verbindung steht, wenn das erste Dichtmittel abdichtend mit der zweiten Halteplatte in Verbindung steht. Dabei besitzt die erste Saugplatte eine andere Abmessung als die zweite Saugplatte.This object is achieved by a vacuum load-holding device for lifting plate-shaped objects, in particular concrete or natural stone slabs, comprising a vacuum generating vacuum device in a base body and a first suction plate angordenbare on the body, the one with a male plate cooperating first sealing means, wherein the first sealing means is arranged on a first holding plate and encloses a first suction space, which is connected via a provided in the first holding plate first opening with the vacuum device in combination. The vacuum load holding device has at least a second suction plate, which has a second sealing means which sealingly cooperates with a male plate, wherein the second sealing means is arranged on a second holding plate and encloses a second suction chamber of the second suction plate, via one in the second Holding plate arranged second opening with the first suction chamber is tightly connected, when the first sealing means is sealingly in communication with the second holding plate. In this case, the first suction plate has a different dimension than the second suction plate.

Der wesentliche Vorteil der vorliegenden Erfindung besteht darin, dass aufgrund der speziellen Ausgestaltung des erfindungsgemÃ¤Ãen Vakuum-LasthaftgerÃ¤tes die Verlegung von Platten, insbesondere von Stein- oder Betonplatten, in wenigstens zwei unterschiedlich groÃen Formaten zeitsparend und daher kostengÃ¼nstig erfolgen kann, weil ein vergleichsweise zeitaufwÃ¤ndiger Austausch von Saugplatten unterschiedlicher GrÃ¶Ãen nicht erforderlich ist.The essential advantage of the present invention is that due to the special design of the vacuum load-holding device according to the invention, the laying of plates, in particular of stone or concrete slabs, in at least two different sizes formats can be time-saving and therefore cost-effective, because a relatively time-consuming replacement of suction plates of different sizes is not required.

Besonders zweckmÃ¤Ãig ist es, wenn die zweite Saugplatte mit einer Befestigungsvorrichtung an dem Vakuum-LasthaftgerÃ¤t derart befestigbar ist, dass das erste Dichtmittel abdichtend mit der zweiten Halteplatte zusammenwirkt.It is particularly expedient if the second suction plate with a fastening device on the vacuum load-holding device can be fastened such that the first sealing means sealingly cooperates with the second holding plate.

Bei einer bevorzugten Ausgestaltung des erfindungsgemÃ¤Ãen Vakuum-LasthaftgerÃ¤tes besitzt die zweite Saugplatte eine grÃ¶Ãere Abmessung als die erst Saugplatte. Alternativ kann die zweite Saugplatte auch eine kleinere Abmessung als die erste Saugplatte besitzen. Die Herstellung eines Belages aus Platten mit zwei unterschiedlichen Formaten kann daher besonders einfach erfolgen. Es kann auch zweckmÃ¤Ãig sein, eine dritte Saugplatte vorzusehen, die ein drittes Dichtmittel aufweist, das abdichtend mit einer aufzunehmenden Platte zusammenwirkt, wobei das dritte Dichtmittel an einer dritten Haltplatte angeordnet ist und einen dritten Saugraum umschlieÃt, der Ã¼ber eine in der dritten Halteplatte angeordnete dritte Ãffnung mit dem zweiten Saugraum dicht in Verbindung steht, wobei das zweite Dichtmittel abdichtend mit der dritten Halteplatte zusammenwirkt. In diesem Fall kann die Herstellung eines Belages aus Platten mit drei unterschiedlichen Formaten besonders einfach erfolgen.In a preferred embodiment of the vacuum load-holding device according to the invention, the second suction plate has a larger dimension than the first suction plate. Alternatively, the second suction plate may also have a smaller dimension than the first suction plate. The production of a covering of plates with two different formats can therefore be particularly simple. It may also be expedient to provide a third suction plate having a third sealing means which sealingly cooperates with a male plate, wherein the third sealing means is disposed on a third retaining plate and enclosing a third suction chamber, the third arranged over a third in the third holding plate Opening with the second suction chamber is tightly connected, wherein the second sealing means sealingly cooperates with the third holding plate. In this case, the production of a coating of plates with three different formats can be done very easily.

Besonders einfach ist eine Anordnung, bei der der erste Saugraum Ã¼ber eine in der ersten Halteplatte vorgesehene erste Ãffnung mit der Vakuum-Einrichtung dicht in Verbindung steht. Entsprechend kann der zweite Saugraum Ã¼ber eine in der zweiten Halteplatte vorgesehene zweite Ãffnung mit dem ersten Saugraum dicht in Verbindung stehen und kann der dritte Saugraum Ã¼ber eine in der dritten Halteplatte vorgesehene dritte Ãffnung mit dem zweiten Saugraum dicht in Verbindung stehen.Particularly simple is an arrangement in which the first suction chamber is in close communication with the vacuum device via a first opening provided in the first holding plate. Accordingly, the second suction chamber can be tightly connected to the first suction space via a second opening provided in the second holding plate, and the third suction space can be tightly connected to the second suction space via a third opening provided in the third holding plate.

Wenn eine dritte Saugplatte vorgesehen ist, ist es zweckmÃ¤Ãig, eine weitere Befestigungsvorrichtung vorzusehen, mit der die dritte Saugplatte derart an dem Vakuum-LasthaftgerÃ¤t oder an der zweiten Halteplatte befestigbar ist, dass das zweite Dichtmittel abdichtend mit der dritten Halteplatte zusammenwirkt.If a third suction plate is provided, it is expedient to provide a further fastening device with which the third suction plate can be fastened to the vacuum load-holding device or to the second holding plate in such a way that the second sealing means cooperates sealingly with the third holding plate.

Besonders einfach ist ein Anbringen der zweiten Saugplatte an der ersten Saugplatte, wenn die Befestigungsvorrichtung die Form eines Schnellverschlusses aufweist. Dies gilt gleichermaÃen auch fÃ¼r die Ausgestaltung der weiteren Befestigungsvorrichtung zum Anbringen der dritten Saugplatte an der zweiten Saugplatte.Attaching the second suction plate to the first suction plate is particularly simple if the fastening device has the form of a quick-acting closure. This applies equally to the embodiment of the further fastening device for attaching the third suction plate to the second suction plate.

Der Schnellverschluss kann dabei ein Hakenteil, das an der zweiten Halteplatte befestigt ist, und ein BÃ¼gelteil umfassen, das in dem Hakenteil arretierbar und durch BetÃ¤tigen eines Handgriffteiles derart spannbar ist, dass das Hakenteil in Richtung auf die erste Saugplatte gezogen wird. Entsprechend kann der Schnellverschluss ein Hakenteil umfassen, das an der dritten Halteplatte befestigt ist, und ein BÃ¼gelteil aufweist, das in dem Hakenteil arretierbar und durch BetÃ¤tigen eines Handgriffteiles derart spannbar ist, dass das Hakenteil in Richtung auf die zweite Halteplatte gezogen wird. Besonders vorteilhaft ist eine AusfÃ¼hrungsform, bei der das Handgriffteil am GrundkÃ¶rper befestigt ist.The quick release can comprise a hook part which is fastened to the second holding plate, and a bow part which can be locked in the hook part and tensioned by actuating a handle part such that the hook part is pulled in the direction of the first suction plate. Accordingly, the quick release may include a hook member attached to the third support plate and a bracket member lockable in the hook member and tensionable by operating a handle member such that the hook member is pulled toward the second support panel. Particularly advantageous is an embodiment in which the handle part is attached to the base body.

Bei einer weiteren bevorzugten Ausgestaltung weist die Befestigungsvorrichtung die Form eines Bajonettverschlusses auf, der in dem ersten Saugraum, vorzugsweise die erste Ãffnung umgebend, angeordnet sein kann. Entsprechend kann die weitere Befestigungsvorrichtung die Form eines Bajonettverschlusses aufweisen, der in dem zweiten Saugraum, vorzugsweise die zweite Ãffnung umgebend, angeordnet ist. Dabei sind die ersten Elemente des Bajonettverschlusses an der ersten Halteplatte der ersten Saugplatte oder der zweiten Halteplatte der zweiten Saugplatte oder der dritten Halteplatte der dritten Saugplatte vorgesehen, wÃ¤hrend die zweiten zweite Elemente des Bajonettverschlusses an der zweiten Halteplatte der zweiten Saugplatte oder an der dritten Halteplatte der dritten Saugplatte oder an einer weiteren Halteplatte einer weiteren Saugplatte vorgesehen sind, die an der dritten Saugplatte anordnebar ist.In a further preferred embodiment, the fastening device has the form of a bayonet closure, which can be arranged in the first suction chamber, preferably surrounding the first opening. Accordingly, the further fastening device may have the form of a bayonet closure, which is arranged in the second suction chamber, preferably surrounding the second opening. In this case, the first elements of the bayonet closure are provided on the first holding plate of the first suction plate or the second holding plate of the second suction plate or the third holding plate of the third suction plate, while the second second elements of the bayonet closure on the second holding plate of the second suction plate or on the third holding plate of the third suction plate or on a further holding plate of a further suction plate are provided, which is anordnebar to the third suction plate.

Besonders vorteilhaft ist eine Anwendung des erfindungsgemÃ¤Ãen Vakuum-LasthaftgerÃ¤tes, wenn die erste Saugplatte zum Ansaugen von ersten Platten und die zweite Saugplatte zum Ansaugen von zweiten Platten dienen, wobei das Format der zweiten Platten grÃ¶Ãer, vorzugsweise doppelt so groÃ, ist, wie das Format der ersten Platten.Particularly advantageous is an application of the vacuum load-holding device according to the invention, when the first suction plate for sucking first plates and the second suction plate for sucking second plates, wherein the format of the second plates is larger, preferably twice as large as the format of first plates.

Besonders stabil und vorteilhaft ist eine AusfÃ¼hrungsform, bei der die erste Saugplatte fest an dem GrundkÃ¶rper montiert ist. Es ist jedoch auch denkbar, die erste Saugplatte mit dem GrundkÃ¶rper vorzugsweise mit einer Wechseleinrichtung zu verbinden.Particularly stable and advantageous is an embodiment in which the first suction plate is fixedly mounted on the base body. However, it is also conceivable to connect the first suction plate to the main body preferably with a changing device.

Vorteilhafte Ausgestaltungen der Erfindung gehen aus den UnteransprÃ¼chen hervor.Advantageous embodiments of the invention will become apparent from the dependent claims.

Im folgenden werden die Erfindung und deren Ausgestaltungen im Zusammenhang mit den Figuren nÃ¤her erlÃ¤utert. Es zeigen:In the following the invention and its embodiments in connection with the figures will be explained in more detail. Show it:

1 in schematischer Darstellung die Ansicht eines aus Platten zweier unterschiedlicher Formate hergestellten Plattenbelages von oben; 1 a schematic representation of the view of a Plattenbelages prepared from plates of two different formats from above;

2 eine Seitenansicht des erfindungsgemÃ¤Ãen Vakuum-LasthaftgerÃ¤tes zum Verlegen von Platten zweier unterschiedlicher Formate und 2 a side view of the vacuum load device according to the invention for laying panels of two different formats and

3 die Anordnung der Saugplatten eines Vakuum-LasthaftgerÃ¤tes zum Verlegen von drei unterschiedlichen Plattenformaten. 3 the arrangement of the suction plates of a vacuum load-holding device for laying three different plate formats.

Zu der Erfindung fÃ¼hrten die folgenden Ãberlegungen. Bei groÃformatigen Platten, die insbesondere aus Beton bestehen, geht der derzeitige Trend zu hochdekorativen SteinoberflÃ¤chen. Bei einer kostengÃ¼nstigen Herstellung solcher dekorativen Betonplatten hat sich gezeigt, dass ein gewisser Grad an PorositÃ¤t der entsprechenden Betonmaterialien hingenommen werden muss. Dies wiederum hat dazu gefÃ¼hrt, dass herkÃ¶mmliche Vakuum-LasthaftgerÃ¤te zum Verlegen derartiger Platten nicht mehr verwendet werden kÃ¶nnen, weil die durch die Mikroporen des Betons zuflieÃende Luftmenge so groÃ ist, dass das von der verwendeten Vakuumpumpe erzeugte Vakuum nicht mehr ausreicht, um die entsprechende Betonplatte anzusaugen. Ãblicherweise arbeiten herkÃ¶mmliche Vakuum-LasthaftgerÃ¤te mit einem Unterdruck von etwa 0,6 bar. Untersuchungen der Patentanmelderin haben ergeben, dass bei relativ hohen UnterdrÃ¼cken aufgrund der hohen Druckdifferenz zwischen dem Drucksaugraum der Saugplatte und dem Umgebungsdruck ein groÃes Luftvolumen von den verwendeten Vakuumpumpen wegbefÃ¶rdert werden muss, um eine einwandfreie Funktion zu gewÃ¤hrleisten. Dabei ist es aber erforderlich, dass aufgrund dieses hohen Luftvolumens und des hohen Unterdruckes die Vakuumpumpen hohe Antriebsleistungen benÃ¶tigen. Bei der Verwendung andersartiger Vakuumpumpen, die beispielsweise nur mit einem Unterdruck von maximal 0,2 bar arbeiten, ist die Druckdifferenz geringer. Dies hat zur Folge, dass nicht so viel Luft durch die Poren des Betonsmaterials der Betonplatten nach flieÃt. Eine solche Konfiguration benÃ¶tigt eine deutlich kleinere Antriebsleistung und ermÃ¶glicht so ein wirtschaftlicheres Arbeiten. Wenn allerdings mit einem solchen geringen Unterdruck gearbeitet wird, mÃ¼ssen die Saugplatten entsprechend grÃ¶Ãer ausgelegt werden, um die notwendigen HaltekrÃ¤fte aufzubringen. Ein Arbeiten mit solchen niedrigen UnterdrÃ¼cken kann nach dem erfindungsgemÃ¤Ãen Konzept dadurch erfolgen, dass je nach GrÃ¶Ãe des verwendeten Plattenformates an einer kleineren, zweckmÃ¤Ãigerweise fest mit der Vakuum-Saugeinrichtung verbundenen Saugplatte, grÃ¶Ãerformatige Saugplatten durch âAnsaugenâ befestigt werden, ohne dass ein zeitaufwÃ¤ndiger Austausch der kleineren Saugplatte erforderlich ist.The following considerations led to the invention. For large-sized panels, which are made especially of concrete, the current trend is towards highly decorative stone surfaces. In an inexpensive production of such decorative concrete slabs has been found that a certain degree of porosity of the corresponding concrete materials must be accepted. This, in turn, has led to the inability of conventional vacuum load attachments to lay such panels because the amount of air flowing through the micropores of the concrete is so great that the vacuum created by the vacuum pump used is insufficient to support the corresponding concrete slab to suck. Usually, conventional vacuum load-holding devices operate with a negative pressure of about 0.6 bar. Investigations by the patent applicant have shown that at relatively high negative pressures due to the high pressure difference between the pressure suction of the suction plate and the ambient pressure, a large volume of air must be transported away from the vacuum pumps used to ensure proper functioning. However, it is necessary that due to this high volume of air and the high negative pressure, the vacuum pumps require high drive power. When using different types of vacuum pumps, for example, only work with a negative pressure of a maximum of 0.2 bar, the pressure difference is lower. As a result, not so much air flows through the pores of the concrete material of the concrete slabs. Such a configuration requires a much smaller drive power and thus allows a more economical working. However, if you work with such a low vacuum, the suction plates must be designed to be larger in order to apply the necessary holding forces. Working with such low negative pressures can be carried out according to the concept according to the invention in that depending on the size of the plate format used on a smaller, conveniently firmly connected to the vacuum suction suction plate, larger-sized suction plates are fixed by "suction" without a time-consuming replacement of smaller suction plate is required.

In der 2 ist ein Vakuum-LasthaftgerÃ¤t 1 dargestellt, das im wesentlichen einen GrundkÃ¶rper 2, eine an dem GrundkÃ¶rper 2 angeordnete AufhÃ¤ngeeinrichtung 3 zum Befestigen des Vakuum-LasthaftgerÃ¤tes 1 am Ausleger eines motorisch verfahrbaren ArbeitsgerÃ¤tes, sowie eine durch das Bezugszeichen 5 bezeichnete erste Saugplatte umfasst, die beispielsweise fest am Vakuum-LasthaftgerÃ¤t 1 bzw. am GrundkÃ¶rper 2 desselben montiert ist. Im GrundkÃ¶rper 2 ist eine Vakuum-Einrichtung 4 zur Erzeugung des erforderlichen Vakuums angeordnet. Es wird darauf hingewiesen, dass die erste Saugplatte 5 auch mit der Hilfe einer Wechselvorrichtung am GrundkÃ¶rper 2 befestigbar ist.In the 2 is a vacuum load device 1 shown, which is essentially a body 2 , one on the main body 2 arranged suspension device 3 for attaching the vacuum load holding device 1 on the boom of a motor-driven implement, as well as one by the reference numeral 5 designated first suction plate includes, for example, fixed to the vacuum load-holding device 1 or at the base body 2 the same is mounted. In the main body 2 is a vacuum device 4 arranged to generate the required vacuum. It should be noted that the first suction plate 5 also with the help of a changing device on the main body 2 is fastened.

In der an sich Ã¼blichen Weise umfasst die erste Saugplatte 5 ein an einer AnsaugflÃ¤che einer Platte anzulegendes Dichtmittel 6, das einen Saugraum 7 umschlieÃt und an einer Halteplatte 8 befestigt ist, die eine zweckmÃ¤Ãigerweise mittige Ãffnung 9 besitzt, Ã¼ber die der Saugraum 7 mit der Vakuum-Einrichtung 4 in Verbindung steht. Die Saugplatte 5 weist eine relativ kleine GrÃ¶Ãe auf, so dass sie fÃ¼r das Ansaugen relativ kleiner Platten (z. B. Platten A in 1) geeignet ist.In the usual way, the first suction plate comprises 5 a sealant to be applied to a suction surface of a plate 6 that has a suction room 7 encloses and on a holding plate 8th is fastened, which is a suitably central opening 9 possesses, over which the suction space 7 with the vacuum device 4 communicates. The suction plate 5 has a relatively small size, so that it is suitable for sucking relatively small plates (eg plates A in FIG 1 ) suitable is.

ErfindungsgemÃ¤Ã ist eine zweite Saugplatte 10 vorgesehen, die Ã¤hnlich aufgebaut ist wie die erste Saugplatte 5, jedoch grÃ¶Ãer ausgestaltet und daher zum Ansaugen von Platten (z. B. Platten B in 1) geeignet ist, die ein grÃ¶Ãeres Format aufweisen, wie die mit der ersten Saugplatte 5 ansaugbaren Platten. Der Saugraum der zweiten Saugplatte 10 ist mit 11 bezeichnet. Das Dichtmittel 12 der zweiten Saugplatte 10 ist an einer Halteplatte 13 angeordnet, in der eine zweckmÃ¤Ãigerweise mittige Ãffnung 14 angeordnet ist, Ã¼ber die der Saugraum 11 der zweiten Saugplatte 10 mit dem Saugraum 7 der ersten Saugplatte 5 in Verbindung steht. Die erste Saugplatte 5 wird derart auf die zweite Saugplatte 10 aufgesetzt, dass ihr Dichtmittel 6 die Ãffnung 14 der zweiten Saugplatte 10 dicht umgibt. Es wird darauf hingewiesen, dass die zweite Saugplatte 10 auch so ausgestaltet sein kann, dass ihre SaugflÃ¤che kleiner ist als diejenige der ersten Saugplatte 5.According to the invention, a second suction plate 10 provided, which is similar to the first suction plate 5 , but designed larger and therefore for sucking plates (eg plates B in 1 ) is suitable, which have a larger format, as with the first suction plate 5 suctionable plates. The suction chamber of the second suction plate 10 is with 11 designated. The sealant 12 the second suction plate 10 is on a retaining plate 13 arranged, in which a suitably central opening 14 is arranged over which the suction chamber 11 the second suction plate 10 with the suction chamber 7 the first suction plate 5 communicates. The first suction plate 5 is so on the second suction plate 10 put on that their sealant 6 the opening 14 the second suction plate 10 surrounds tightly. It should be noted that the second suction plate 10 may also be configured so that their suction surface is smaller than that of the first suction plate 5 ,

Die zweite Saugplatte 10 ist mit einer schnell betÃ¤tigbaren Befestigungsvorrichtung 15 an der ersten Saugplatte 5 befestigbar. Aufwendige Austauschoperationen sind daher nicht erforderlich.The second suction plate 10 is with a quick-acting attachment device 15 on the first suction plate 5 fixable. Elaborate replacement operations are therefore not required.

Beispielsweise weist die Befestigungsvorrichtung 15 die Form eines in der 2 schematisch gezeigten Schnellverschlusses auf, der ein BÃ¼gelteil 16 umfasst, das Ã¼ber ein Hakenteil 17 legbar ist und zur Befestigung der zweiten Saugplatte 10 an der ersten Saugplatte 5 durch BetÃ¤tigen eines Handgriffes 18 in Richtung (Pfeil 19) auf den GrundkÃ¶rper 2 ziehbar ist. Vorzugsweise sind zwei derartige Befestigungsvorrichtungen 15 an sich gegenÃ¼berliegenden Seiten des GrundkÃ¶rpers 2 angeordnet. Andere schnell betÃ¤tigbare Befestigungsvorrichtungen sind denkbar.For example, the fastening device 15 the shape of a in the 2 schematically shown quick release, the one ironing part 16 includes that over a hook part 17 is laying and fixing the second suction plate 10 on the first suction plate 5 by pressing a handle 18 in direction (arrow 19 ) on the body 2 is drawable. Preferably, two such fastening devices 15 on opposite sides of the body 2 arranged. Other quickly operable fasteners are conceivable.

Die 3 zeigt eine AusfÃ¼hrungsform der vorliegenden Erfindung, bei der neben der ersten Saugplatte 5 und der zweiten Saugplatte 10 eine dritte Saugplatte 20 vorgesehen ist, die grÃ¶Ãerformatig ausgestaltet ist als die zweite Saugplatte 10 und in der im Zusammenhang mit der 2 erlÃ¤uterten Weise an der zweiten Saugplatte 10 befestigbar ist. Die dritte Saugplatte 20 umfasst ein Dichtmittel 21, eine Halteplatte 22 und eine zweckmÃ¤Ãigerweise mittige Ãffnung 23, Ã¼ber die der Saugraum 24 der dritten Saugplatte 20 mit dem Saugraum 11 der zweiten Saugplatte 10 in Verbindung steht. Die schnell betÃ¤tigbaren Befestigungsvorrichtungen sind auch hier schematisch dargestellt und besitzen beispielsweise die Form von BajonettverschlÃ¼ssen, die jeweils in den SaugrÃ¤umen 7, 11, 24 der jeweiligen Saugplatten 5, 10, 20 angeordnet sind. Dabei werden die einzelnen Saugplatten durch Verdrehen aneinander befestigt. Die Befestigung einer weiteren grÃ¶Ãerformatigen Saugplatte an der dritten Saugplatte 20 ist denkbar. The 3 shows an embodiment of the present invention, in addition to the first suction plate 5 and the second suction plate 10 a third suction plate 20 is provided, which is designed larger than the second suction plate 10 and in the context of the 2 explained manner on the second suction plate 10 is fastened. The third suction plate 20 includes a sealant 21 , a holding plate 22 and a conveniently central opening 23 about which the suction chamber 24 the third suction plate 20 with the suction chamber 11 the second suction plate 10 communicates. The quick-acting fastening devices are also shown schematically here and have for example the form of bayonet locks, each in the suction spaces 7 . 11 . 24 the respective suction plates 5 . 10 . 20 are arranged. The individual suction plates are attached by twisting each other. The attachment of another larger-sized suction plate to the third suction plate 20 is conceivable.

Die ersten Elemente des Bajonettverschlusses sind dabei an der ersten Halteplatte 8 der ersten Saugplatte 5 oder der zweiten Halteplatte 13 der zweiten Saugplatte 10 oder der dritten Halteplatte 22 der dritten Saugplatte 20 angeordnet und die zweiten Elemente des Bajonettverschlusses sind an der zweiten Halteplatte 13 der zweiten Saugplatte 10 oder der dritten Halteplatte 22 der dritten Saugplatte 20 oder an einer weiteren Halteplatte einer weiteren Saugplatte angeordnet.The first elements of the bayonet lock are on the first holding plate 8th the first suction plate 5 or the second holding plate 13 the second suction plate 10 or the third holding plate 22 the third suction plate 20 arranged and the second elements of the bayonet lock are on the second holding plate 13 the second suction plate 10 or the third holding plate 22 the third suction plate 20 or arranged on a further holding plate of a further suction plate.

BezugszeichenlisteLIST OF REFERENCE NUMBERS

11

Vakuum-LasthaftgerÃ¤tVacuum load adhesive device

22

GrundkÃ¶rperbody

33

AufhÃ¤ngeeinrichtungsuspension

44

Vakuum-EinrichtungVacuum means

55

Saugplattesuction plate

66

Dichtmittelsealant

77

Saugraumsuction

88th

HalteplatteRetaining plate

99

Ãffnungopening

1010

Saugplattesuction plate

1111

Saugraumsuction

1212

Dichtmittelsealant

1313

HalteplatteRetaining plate

1414

Ãffnungopening

1515

Befestigungsvorrichtungfastening device

1616

BÃ¼gelteilIroning part

1717

Hakenteilhook part

1818

HandgriffteilHandle part

1919

Pfeilarrow

2020

Saugplattesuction plate

2121

Dichtmittelsealant

2222

HalteplatteRetaining plate

2323

Ãffnungopening

2424

Saugraumsuction

ZITATE ENTHALTEN IN DER BESCHREIBUNG QUOTES INCLUDE IN THE DESCRIPTION

Diese Liste der vom Anmelder aufgefÃ¼hrten Dokumente wurde automatisiert erzeugt und ist ausschlieÃlich zur besseren Information des Lesers aufgenommen. Die Liste ist nicht Bestandteil der deutschen Patent- bzw. Gebrauchsmusteranmeldung. Das DPMA Ã¼bernimmt keinerlei Haftung fÃ¼r etwaige Fehler oder Auslassungen.This list of the documents listed by the applicant has been generated automatically and is included solely for the better information of the reader. The list is not part of the German patent or utility model application. The DPMA assumes no liability for any errors or omissions.

Zitierte PatentliteraturCited patent literature

DE 4327663 C2 [0002] DE 4327663 C2 [0002]

## Classifications

- E04G21/16
- B66C1/02
- B66C1/0237
- E01C19/52
- E01C19/524
- E04G21/14
- E04G21/167

## Cited patent documents

- [DE-4327663-C2](https://patents.google.com/patent/DE4327663C2/en) — APP

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
