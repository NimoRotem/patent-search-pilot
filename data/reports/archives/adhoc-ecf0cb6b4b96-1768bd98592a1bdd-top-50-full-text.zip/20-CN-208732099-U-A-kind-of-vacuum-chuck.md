# 20. A kind of vacuum chuck

- **Archive rank:** 20 of 50
- **Publication:** [CN-208732099-U](https://patents.google.com/patent/CN208732099U/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/066024415/publication/CN208732099U?q=pn%3DCN208732099U)
- **Publication date:** 2019-04-12
- **Filing date:** 2018-05-10
- **Earliest priority:** 2018-05-10
- **Family:** 66024415
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** GUANGZHOU GUANYAN HYDRAULIC SEAL CO LTD

## Abstract

The utility model discloses a kind of vacuum chucks, the sucker including forming a negative pressure chamber, and the sucker includes sealing lip, side wall and hollow body；The side wall surrounds the sucker wall for forming a truncated cone-shaped；The upper and lower side of the hollow cavity has the first port and the second port, and for being connected to external vacuum generating device, the second port is connected the first port with sucker wall upper end, sucker wall lower end connection sealing lip；The hollow body is compressible along the vertical direction and folds；The sucker wall is deformable material, and the lower end of sucker wall is provided with spiral pleated structure；Elastic ring is additionally provided in the sealing lip；Interior sucker is additionally provided in the inside of the sucker wall.The utility model solves caused by adsorbent chamber existing in the prior art is smaller, sucker itself material softness degree is inadequate that adsorption capacity is small, is not suitable for the problem of object and single layer sucker rough, in irregular shape are easy broken invalid.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-208732099-U/pdf000.png)

![Sketch 1 for CN-208732099-U](https://nimo.iptorch.com/refdrawing/CN-208732099-U/pdf000.png)

## Claims

### Claim 1 (independent)

a kind of vacuum chuck, the sucker including forming a negative pressure chamber, which is characterized in that the sucker includes sealing lip Side, side wall and hollow body；The side wall surrounds the sucker wall for forming a truncated cone-shaped；The upper and lower side of the hollow body has One port and the second port, for being connected to external vacuum generating device, the second port is connected the first port with sucker wall upper end, inhales The lower end Pan Bi connection sealing lip；The hollow body is compressible along the vertical direction and folds；The sucker wall is deformable material, The lower end of sucker wall is provided with spiral pleated structure；Elastic ring is additionally provided in the sealing lip；In the sucker wall Portion is additionally provided with interior sucker.

### Claim 2

vacuum chuck according to claim 1, which is characterized in that the interior sucker is hollow truncated cone-shaped, rotary table It is respectively arranged with third connectivity mouth and the 4th port at the top and bottom of shape, the diameter of the third connectivity mouth is straight less than the first port Diameter, the diameter of the diameter of the 4th port less than the second port；The upper part of the interior sucker is connected with sucker wall top, makes It obtains third connectivity mouth to communicate with hollow body, but does not influence the first port and be connected to hollow body.

### Claim 3

vacuum chuck according to claim 2, which is characterized in that the quantity of the interior sucker is one or more It is a.

### Claim 4

vacuum chuck described in any one of claim 1 to 3, which is characterized in that the quantity of the elastic ring is one It is a or multiple.

### Claim 5

vacuum chuck according to claim 4, which is characterized in that the elastic ring and the sides aligned parallel of sealing lip are set It sets.

### Claim 6

vacuum chuck according to claim 5, which is characterized in that the elastic ring is thermoplastic polyurethane elastomer rubber Glue material matter.

### Claim 7

according to claim 1~3, vacuum chuck described in any one of 5,6, which is characterized in that the sealing lip is silicon Rubber material.

### Claim 8

vacuum chuck according to claim 7, which is characterized in that be provided with foldable structure in the middle part of the hollow body.

### Claim 9

according to claim 1~3, vacuum chuck described in any one of 5,6,8, which is characterized in that the vacuum chuck is Integral structure.

### Claim 10

vacuum chuck according to claim 9, which is characterized in that the vacuum chuck has sizes model.

## Full description

Description

A kind of vacuum chuck

Technical field

The utility model relates to automate a kind of sucker on industry terminal-collecting machine handgrip, in particular to a kind of vacuum chuck.

Background technique

Industrial at present realized using absorption class movement mainly takes two kinds to the Acetabula device of crawl and the release of object

Structure: one is vacuum chuck absorbent bodies surface, another kind is electromagnet absorption ferromagnetic object, since electromagnet needs are held

Continue continuous electric energy to keep the magnetism of sucker, therefore, its energy consumption is higher, other than fever and security appliance problem, once hair

Raw power failure or fault, the object being crawled can be fallen down, very dangerous.For vacuum chuck, it is not necessarily to electricity consumption, but to object

Surface smoothness requires high.Traditional vacuum chuck is usually the soft rubber material of disc-shape, single layer, carry out in use, due to

The material softness degree of sucker itself is inadequate, and the adsorbent chamber in sucker is smaller, and vacuum degree is small, causes adsorption capacity small, finally leads

Cause cannot be adsorbed effectively and is fixed on object.Or since the surface for being adsorbed object is not smooth enough, cause sucker not

Object can be effectively adsorbed, the fixation object on connecting sucker is easy from being adsorbed as above falling off.Moreover, the most of suckers of tradition are

Single layer sucker, slightly breakage, which is easy for gas leakage, leads to fall part, once lip scuffing will be replaced at once, is otherwise easy

Part causes to automate handgrip or even whole automation line is out of service.

Utility model content

The utility model discloses a kind of vacuum chuck, to solve, adsorbent chamber existing in the prior art is smaller, sucker

Adsorption capacity caused by the material softness degree of itself is inadequate is small, is not suitable for object and single layer rough, in irregular shape

Sucker is easy the problem of broken invalid.

In order to achieve the above object, the utility model adopts the following technical solution:

A kind of vacuum chuck, including formed a negative pressure chamber sucker, the sucker include sealing lip, side wall and

Hollow bodyï¼The side wall surrounds the sucker wall for forming a truncated cone-shapedï¼The upper and lower side of the hollow cavity have the first port and

Second port, the first port is for being connected to external vacuum generating device, and the second port is connected with sucker wall upper end, sucker wall lower end

Connection sealing lipï¼The hollow body is compressible along the vertical direction and foldsï¼The sucker wall is deformable material, sucker wall

Lower end is provided with spiral pleated structureï¼Elastic ring is additionally provided in the sealing lipï¼It is also set up in the inside of the sucker wall

There is interior sucker.

Further, the interior sucker is hollow truncated cone-shaped, and it is logical that third is respectively arranged at the top and bottom of truncated cone-shaped

Mouth and the 4th port, the diameter of the third connectivity mouth is less than the diameter of the first port, and the diameter of the 4th port is less than the second port

Diameterï¼The upper part of the interior sucker is connected with sucker wall top, so that third connectivity mouth is communicated with hollow body, but not shadow

The first port is rung to be connected to hollow body.

Further, the quantity of the interior sucker is one or multiple.

Further, the quantity of the elastic ring is one or multiple.

Further, the elastic ring and the sides aligned parallel of sealing lip are arranged.

Further, the elastic ring is thermoplastic polyurethane elastomer rubber material.

Further, the sealing lip is silicone rubber material.

Further, foldable structure is provided in the middle part of the hollow body.

Further, the vacuum chuck is an integral structure.

Further, the vacuum chuck has sizes model.

Compared with prior art, the utility model has the following beneficial effects:

1, the vacuum chuck of the utility model is connected with hollow body on absorption wall, and hollow body is compressible along the vertical direction

And folding, the volume of adsorbent chamber is increased, is filled with air in hollow body before vacuum extraction, is started after vacuumizing, hollow body

It is folded and compresses, air therein is excluded, and increases vacuum degree, and adsorption capacity is big.

2, the vacuum chuck of the utility model, sucker wall are deformable material, and sealing lip is silicone rubber material, material

Softness, good airproof performance.

3, the vacuum chuck of the utility model, the lower end of sucker wall are provided with spiral pleated structure, and since sucker wall is

Deformable material, therefore when the sucker of the utility model touches object, spiral pleated structure can be received according to the shape of object

Compression deformation, and soft sealing lip is combined, so that the vacuum chuck is more bonded adsorbed object, in addition, sealing lip

One or a plurality of elastic ring are additionally provided on side, elastic ring there can be a tightening effect according to the shape of object, so that sealing

Lip is more bonded object, will not fall off easily, thus the vacuum chuck can be suitably used for it is rough or in irregular shape

Object.

4, the vacuum chuck of the utility model, when the inside of sucker wall is additionally provided with interior sucker, grabs object, sucker

Wall and interior sucker can form closed adsorbent chamber with hollow body, on the one hand increase adsorption capacity, on the other hand,

When adsorbing wall breakage or other situations influence its suction-operated, interior sucker still can not influence vacuum with absorbent bodies

The use of sucker.

Detailed description of the invention

Fig. 1 is the structural schematic diagram of the utility model.

Description of symbols: 1 be sealing lip, 2 be hollow body, 3 be sucker wall, 4 be interior sucker, 101 be elastic ring,

201 be the first port, 202 be the second port, 301 be spiral pleated structure, 401 be third connectivity mouth, 402 be the 4th port.

Specific embodiment

The utility model is further illustrated below in conjunction with attached drawing and specific embodiment, but this practical information not office

It is limited to these attached drawings and embodiment.

Such as Fig. 1, a kind of vacuum chuck is mainly used for the front end of manipulator, for grabbing, shifting article etc., this kind of vacuum

Sucker includes the sucker to form a negative pressure chamber, and sucker includes sealing lip 1, side wall and hollow body 2.

Side wall surrounds the sucker wall 3 for forming a truncated cone-shapedï¼The upper and lower side of hollow cavity has the first port 201 and second

Port 202, the first port 201 is for being connected to external vacuum generating device, and the second port 202 is connected with 3 upper end of sucker wall, sucker

3 lower end of wall connection sealing lip 1.

Hollow body 2 is compressible along the vertical direction and folds, and the volume of adsorbent chamber is increased, before vacuum extraction in hollow body

It is filled with air, is started after vacuumizing, hollow body 2 is folded and compresses, and air therein is excluded, and increases vacuum degree, inhales

Attached power is big.Preferably, its folding and compression function are realized by the way that foldable structure is arranged in the middle part of hollow body 2.

Sucker wall 3 is deformable material, and material is soft, and good airproof performance, the lower end of sucker wall 3 is provided with spiral pleated structure

301ï¼When the vacuum chuck touches object, spiral pleated structure 301 can be according to the shape contraction distortion of objectï¼Seal lip

1 is silicone rubber material, seals and is additionally provided with elastic ring 101 in lip 1ï¼Preferably, the quantity of elastic ring 101 is one or more

A, the sides aligned parallel of elastic ring 101 and sealing lip 1 is arranged, and elastic ring 101 is thermoplastic polyurethane elastomer rubber material,

Elastic ring 101 can have a tightening effect not fall off easily so that sealing lip 1 is more bonded object according to the shape of object,

Therefore the vacuum chuck can be suitably used for object rough or in irregular shape.

Be additionally provided with interior sucker 4 in the inside of sucker wall 3, interior sucker 4 is hollow truncated cone-shaped, at the top of truncated cone-shaped and

Bottom is respectively arranged with third connectivity mouth 401 and the 4th port 402, it is preferable that the diameter of third connectivity mouth 401 is less than the first port

201 diameter, the diameter of the diameter of the 4th port 402 less than the second port 202ï¼The upper part of interior sucker 4 and sucker wall 3

Top is connected, so that third connectivity mouth 401 is communicated with hollow body 2, but does not influence the first port 201 and is connected to hollow body 2.Grab object

When body, sucker wall 3 and interior sucker 4 can form closed adsorbent chamber with hollow body 2, on the one hand increase absorption

Power, on the other hand, when adsorbing wall breakage or other situations influence its suction-operated, interior sucker still can be with adsorbate

Body does not influence the use of vacuum chuck.Preferably, the quantity of interior sucker 4 is one or multiple.

The vacuum chuck of the utility model is an integral structure.

The vacuum chuck of the utility model has sizes model.

The foregoing is merely the better embodiment of the utility model, the utility model is not limited to above-mentioned embodiment party

Formula, there may be the structural modifications that part is small in implementation process, if various changes or modifications to the utility model are not

The spirit and scope of the utility model are detached from, and are belonged within the scope of the claims and equivalents of the utility model, then originally

Utility model is also intended to encompass these modification and variations.

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
