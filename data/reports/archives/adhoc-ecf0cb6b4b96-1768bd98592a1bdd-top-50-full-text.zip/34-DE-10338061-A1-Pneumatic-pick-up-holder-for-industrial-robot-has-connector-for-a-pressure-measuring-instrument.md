# 34. Pneumatic pick-up holder for industrial robot has connector for a pressure measuring instrument

- **Archive rank:** 34 of 50
- **Publication:** [DE-10338061-A1](https://patents.google.com/patent/DE10338061A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/034201690/publication/DE10338061A1?q=pn%3DDE10338061A1)
- **Publication date:** 2005-03-24
- **Filing date:** 2003-08-19
- **Earliest priority:** 2003-08-19
- **Family:** 34201690
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery

## Parties

- **Applicant / assignee:** DAIMLER CHRYSLER AG; SCHMALZ J GMBH; SPRINGER GMBH
- **Inventors:** EISELE THOMAS; GIESLER ALBERT; KURPJUWEIT RALF; MAEDER KARL-HEINZ; SCHMIDT WOLFHARD; SPRINGER UWE

## Abstract

An industrial robot used in conjunction with e.g. assembly of automotive components has a pick-up with a vacuum powered grip. The grip has a pneumatic connector for a pressure measuring instrument.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-10338061-A1/pdf000.png)

![Sketch 1 for DE-10338061-A1](https://nimo.iptorch.com/refdrawing/DE-10338061-A1/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-10338061-A1/pdf001.png)

![Sketch 2 for DE-10338061-A1](https://nimo.iptorch.com/refdrawing/DE-10338061-A1/pdf001.png)

## Claims

### Claim 1 (independent)

Greifervorrichtung mit einer Haltevorrichtung (9, 14) und zumindest einem an der Haltevorrichtung (9, 14) befestigten Greifelement (1), welches einen Vakuumerzeuger (2) zur Erzeugung eines Unterdrucks aufweist, dadurch gekennzeichnet, dass das Greifelement (1) einen pneumatischen Messanschluss (20) aufweist.Gripper device with a holding device ( 9 . 14 ) and at least one on the holding device ( 9 . 14 ) attached gripping element ( 1 ), which is a vacuum generator ( 2 ) for generating a negative pressure, characterized in that the gripping element ( 1 ) a pneumatic measuring connection ( 20 ) having.

### Claim 2

Greifervorrichtung nach Anspruch 1, dadurch gekennzeichnet, dass eine pneumatische Messleitung (5) an den Messanschluss (20) anschließbar ist.Gripper device according to claim 1, characterized in that a pneumatic measuring line ( 5 ) to the measuring connection ( 20 ) is connectable.

### Claim 3

Greifervorrichtung nach Anspruch 2, dadurch gekennzeichnet, dass die pneumatische Messleitung (5) entfernt von dem Greifelement (1) mit einem Anschluss (11) für einen zentralen Vakuumschalter (10) verbindbar ist.Gripper device according to claim 2, characterized in that the pneumatic measuring line ( 5 ) away from the gripping element ( 1 ) with a connection ( 11 ) for a central vacuum switch ( 10 ) is connectable.

### Claim 4

Greifervorrichtung nach zumindest einem der vorangegangenen Ansprüche, dadurch gekennzeichnet, dass zumindest eine Druckluftleitung (3, 4) an den Vakuumerzeuger (2) angeschlossen ist.Gripper device according to at least one of the preceding claims, characterized in that at least one compressed air line ( 3 . 4 ) to the vacuum generator ( 2 ) connected.

### Claim 5

Greifervorrichtung nach zumindest einem der vorangegangenen Ansprüche, dadurch gekennzeichnet, dass der Vakuumerzeuger (2) eine Venturidüse ist.Gripper device according to at least one of the preceding claims, characterized in that the vacuum generator ( 2 ) is a Venturi nozzle.

### Claim 6

Greifervorrichtung nach zumindest einem der vorangegangenen Ansprüche, dadurch gekennzeichnet, dass das Greifelement (1) einen oder mehrere Sauger (6) aufweist.Gripper device according to at least one of the preceding claims, characterized in that the gripping element ( 1 ) one or more suckers ( 6 ) having.

### Claim 7

Greifervorrichtung nach zumindest einem der vorangegangenen Ansprüche, dadurch gekennzeichnet, dass eine Mehrzahl von Greifelementen (1) mit der Haltevorrichtung (9, 14) verbunden ist, von denen eine Minderzahl mit jeweils einer pneumatischen Messleitung (5) verbunden ist.Gripper device according to at least one of the preceding claims, characterized in that a plurality of gripping elements ( 1 ) with the holding device ( 9 . 14 ), of which a minority, each with a pneumatic measuring line ( 5 ) connected is.

### Claim 8

Greifervorrichtung nach zumindest einem der vorangegangenen Ansprüche, dadurch gekennzeichnet, dass für jede pneumatische Messleitung (5) ein Medienadapter (13) vorgesehen ist, der Anschlüsse (11, 12) für Druckluft und die pneumatische Messleitung (5) aufweist.Gripper device according to at least one of the preceding claims, characterized in that for each pneumatic measuring line ( 5 ) a media adapter ( 13 ), the connections ( 11 . 12 ) for compressed air and the pneumatic measuring line ( 5 ) having.

### Claim 9

Greifervorrichtung nach zumindest einem der vorangegangenen Ansprüche, dadurch gekennzeichnet, dass die Anschlüsse (11, 12) als Druckluftkupplungen ausgebildet sind.Gripper device according to at least one of the preceding claims, characterized in that the connections ( 11 . 12 ) are designed as compressed air couplings.

## Full description

The Invention relates. a gripper device according to the preamble of claim 1.

From the publication DE 198 17 426 A1 a gripper device is known, which can be attached to a robot hand and which is designed in particular as a vacuum gripper system. Each gripping element of the vacuum gripper system is equipped with an ejector, so that it is possible to dispense with a central vacuum system. Furthermore, each gripping element is connected to a force sensor which, inter alia, indicates the presence of a gripped component. Each gripping element is designed to be individually controllable, for which purpose each local own electronics, such as a microcontroller, is provided. An individual determination of the prevailing negative pressure is carried out on each individual gripping element.

Of the The invention has for its object to provide a gripper device, which with few monitoring components gets along, less susceptible to interference and is inexpensive to produce.

The The object is achieved by the Characteristics of claim 1 solved.

at a gripper device according to the invention For example, a gripping element has a pneumatic measuring connection. At This measuring connection can be a measuring device for determining the Negative pressure to be connected. In addition to the advantage that no central vacuum supply for the gripper device necessary is, on each gripping element designed in this way a measurement of the Negative pressure takes place. It can be selected depending on demand, which of the existing gripping elements are used for this purpose. Preferably is the pneumatic measuring connection to a vacuum generator of the gripping element intended. There is a vacuum on one of the vacuum generators or the gripping elements can serve as a criterion for whether a component was taken by the gripper device or not. It can be expensive and fault-prone electrical Connecting cables and especially on expensive electrical connectors be waived. Instead, you can inexpensive, robust pneumatic lines and pneumatic clutches used become. Such a gripper device is especially for one Use in production lines, for example as a robot tool or as a manipulator on a press for handling gripped Components and the like. About that In addition, an operation of the gripper device is facilitated since less and lighter components can be used and the weight of the gripper device is thereby reduced. Especially The omission of sensors directly on the vacuum generator brings considerable savings potential in weight and costs.

is the pneumatic measuring line away from the gripping element with a Connection for a central vacuum switch can be connected, a central provision the vacuum prevailing locally on the vacuum generator or on an associated vacuum cleaner be made. The vacuum switch can be fixed to a robot or a workstation, such as a workstation. a heat press, to be installed and only when needed connected to the gripper device. This requires no such vacuum switch on the gripper device itself be provided. This simplifies and reduces the cost of the gripper device. One and the same vacuum switch can also be equipped with several pneumatic Be connected measuring lines, such as by a suitable switching device, so that in the gripper device with a plurality of gripping elements pneumatic measuring lines can be provided.

is at least one compressed air line connected to the vacuum generator, can be beneficial a venturi be used to generate the negative pressure. This is special Cheap, as a compressed air supply in the appropriate work environments usually available is. Through a change the compressed air supply to the Venturi nozzle let yourself the size of the negative pressure just set.

has The gripping element on two suckers, can by their close proximity in a gripping element a reliable control of the presence a gripped component.

If a plurality of gripping elements is connected to a holding device, of which a minority number are each connected to a separate pneumatic measuring line, component monitoring can be carried out without having to connect all gripping elements to pneumatic measuring lines. Depending on the shape of a gripped component and each different gripping elements may be provided with a pneumatic measuring line. The pneumatic measuring line only has to be transferred to another gripping element. Conveniently, all gripping elements are identical and all have a connection for the pneumatic measuring line. The holding device may be a transfer bar or a frame or a rod-shaped holder which can be fastened, for example, to a robot arm. This gripper elements can be attached to jibs or directly to be able to grip a large component. Not ever The gripping element, or not every vacuum generator, is necessary for checking the presence of the component, so that pneumatic measuring lines need only be provided when necessary or at particularly critical points. The connection for the pneumatic measuring line provided in the vacuum generator is a simple coupling which, if no measuring line is connected, is closed and automatically prevents the ingress of leakage air.

is for every pneumatic measuring line provided a media adapter, the connections for compressed air and the pneumatic measuring line, may be a gripper device can be easily rebuilt to handle components of different sizes. The media adapter may be attached to the fixture. Alternatively, this can also be done on a robot or workstation be arranged on or connected to the gripping device is.

are the connections designed as compressed air couplings, the gripper device can be to produce very cheaply. You can use the same parts become; the storage for replacement parts for the gripper device is simplified.

Cheap designs and advantages of the invention are the description and the other claims remove.

in the Following is the invention with reference to a described in the drawing embodiment explained in more detail.

there demonstrate:

1 a detail of a preferred gripper device with a gripping element with vacuum generator and connected pneumatic measuring line,

2 a detail of a media adapter for the pneumatic measuring line and compressed air lines

3 a section of a preferred gripper device with a plurality of gripping elements, and

4 a plan view of the back of a media adapter.

A section of a gripper device with a holding device 9 . 14 and a gripping element attached thereto 1 is in 1 shown. The holding device is made of a holder 9 and one or more cantilevers attached thereto 14 educated. The gripping element 1 has a vacuum generator 2 , preferably an ejector, more preferably a venturi, for generating a negative pressure. The gripping element 1 consists of preferably two suckers 6 which rest in an activated state on a component and suck it by the negative pressure. The suckers 6 are preferably designed as suction pads. Optionally, these can also be designed as a suction pad. By several such gripping elements 1 a flat component can be gripped. On a top 8th of the gripping element 1 is the vacuum generator 2 arranged. The vacuum generator 2 has a pneumatic measuring connection 20 on that with a pneumatic measuring line 5 connected is. The pneumatic measuring line 5 is along the holder 9 and the jib protruding from it 14 guided. Furthermore, the gripping element 1 unspecified connections for one or more compressed air lines 3 . 4 on which the Venturi nozzle of the vacuum generator 2 supply with compressed air and / or can operate a reversing valve. The gripping element 1 can with conventional, preferably modular clamping systems with the boom 14 and the boom 14 as well with the holder 9 be connected.

The pneumatic measuring line 5 is removed from the vacuum generator 2 with a connection 11 for a central vacuum switch 10 connectable. This connection 11 is on a connector panel with one or more media adapters 13 arranged. This is in 2 to recognize. In the figures, the same or similar parts are numbered with the same reference numerals. The terminal board is preferably attached to a robot or fixed station to which the gripper device is mountable. Alternatively, the terminal board may also be firmly connected to the gripper device. Depending on how many gripping elements 1 each with its own pneumatic measuring line 5 are provided, the number of mounted media adapters 13 to be changed. Furthermore, on the media adapter 13 connections 12 for compressed air lines 3 . 4 intended. The compressed air lines 3 . 4 and the pneumatic measuring line 5 need only to the preferably designed as compressed air connections connections 11 . 12 be connected. There is a vacuum switch on the robot or fixed station 10 provided the negative pressure in the pneumatic measuring line 5 certainly. A single vacuum switch 10 Can be used for a variety of pneumatic test leads 5 be provided. The measuring points can be unswitched with a suitable switching device, not shown.

The gripping element 1 is preferably part of one of a plurality of gripping elements 1 gripping device for handling gripped components, as in 3 in a detail darge is is. On both sides of a holder 9 are outriggers 14 with gripping elements 1 arranged, each one or two suckers 6 exhibit. Among the plurality of gripping elements shown 1 is only one with a pneumatic measuring line 5 connected.

4 shows a media adapter 13 from his back 15 , On its front are the pneumatic measuring line 5 and the compressed air lines 3 . 4 plugged in. On the back side 15 are compressed air couplings 16 provided, to which the compressed air supply and a measuring apparatus for determining the negative pressure on the gripping element 1 is provided, which to the pneumatic measuring line 5 connected.

## Classifications

- B25J15/0616
- B25J15/06

## Cited patent documents

- [DE-10140248-A1](https://patents.google.com/patent/DE10140248A1/en) — SEA
- [DE-19817426-A1](https://patents.google.com/patent/DE19817426A1/en) — SEA
- [DE-4229833-C2](https://patents.google.com/patent/DE4229833C2/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
