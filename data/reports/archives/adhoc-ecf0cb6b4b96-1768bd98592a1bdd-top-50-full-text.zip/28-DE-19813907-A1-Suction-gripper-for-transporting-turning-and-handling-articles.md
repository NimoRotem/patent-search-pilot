# 28. Suction gripper for transporting, turning and handling articles

- **Archive rank:** 28 of 50
- **Publication:** [DE-19813907-A1](https://patents.google.com/patent/DE19813907A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/007862774/publication/DE19813907A1?q=pn%3DDE19813907A1)
- **Publication date:** 1999-09-30
- **Filing date:** 1998-03-28
- **Earliest priority:** 1998-03-28
- **Family:** 7862774
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** SCHMALZ J GMBH
- **Inventors:** SCHMALZ KURT

## Abstract

The suction gripper has a suction connection supported by a suction plate (5) fitted with a sealing profile (8). The suction plate has in the region of its edge (6) fasteners which project over the surface of the top and bottom sides of the suction plate whereby the sealing profile which is to be pushed onto the edge of the suction plate is pushed over the fasteners.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-19813907-A1/ops000.png)

![Sketch 1 for DE-19813907-A1](https://nimo.iptorch.com/refdrawing/DE-19813907-A1/ops000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-19813907-A1/ops001.png)

![Sketch 2 for DE-19813907-A1](https://nimo.iptorch.com/refdrawing/DE-19813907-A1/ops001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/DE-19813907-A1/ops002.png)

![Sketch 3 for DE-19813907-A1](https://nimo.iptorch.com/refdrawing/DE-19813907-A1/ops002.png)

## Claims

### Claim 1 (independent)

Sauggreifer mit einem Sauganschluss (2), einer den Sauganschluss (2) tragenden Saugplatte (5) und einem an der Saugplatte (5) befestigten Dichtprofil (8), dadurch gekennzeichnet, dass die Saugplatte (5) im Bereich ihres Randes (6) mit die Oberfläche der Oberseite und Unterseite der Saugplatte (5) über­ ragenden Befestigungselementen versehen ist, und dass das auf den Rand (6) der Saugplatte (5) aufzuschie­ bende Dichtprofil (8) über die Befestigungselemente aufgeschoben ist.1. Suction gripper with a suction connection ( 2 ), a suction plate ( 5 ) carrying the suction connection ( 2 ) and a sealing profile ( 8 ) attached to the suction plate ( 5 ), characterized in that the suction plate ( 5 ) in the region of its edge ( 6 ) is provided with the surface of the top and bottom of the suction plate ( 5 ) over protruding fastening elements, and that the sealing profile ( 8 ) to be pushed onto the edge ( 6 ) of the suction plate ( 5 ) is pushed over the fastening elements.

### Claim 2

Sauggreifer nach Anspruch 1, dadurch gekennzeichnet, dass im Bereich des Randes (6) der Saugplatte (5) Durchbrüche (9) vorgesehen sind.2. Suction pad according to claim 1, characterized in that in the region of the edge ( 6 ) of the suction plate ( 5 ) openings ( 9 ) are provided.

### Claim 3

Sauggreifer nach Anspruch 1 oder 2, dadurch gekennzeichnet, dass die Befestigungselemente einteilig mit der Saugplatte (5) oder als separate Bauelemente ausgebildet sind.3. Suction pad according to claim 1 or 2, characterized in that the fastening elements are formed in one piece with the suction plate ( 5 ) or as separate components.

### Claim 4

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass der die Befestigungs­ elemente als Klammern (11) ausgebildet sind. Suction pad according to one of the preceding claims, characterized in that the fastening elements are designed as clips ( 11 ).

### Claim 5

Sauggreifer nach Anspruch 4, dadurch gekennzeichnet, dass die freien Enden der Schenkel (12) der Klammern (11), die die Plattenoberfläche (22) überragen, in Richtung der Plattenmitte zeigen.5. Suction pad according to claim 4, characterized in that the free ends of the legs ( 12 ) of the brackets ( 11 ), which protrude beyond the plate surface ( 22 ), point in the direction of the plate center.

### Claim 6

Sauggreifer nach einem der Ansprüche 2 bis 5, dadurch gekennzeichnet, dass der Durchbruch (9) eine längliche Form aufweist und im wesentlichen parallel zum Rand (6) verläuft.6. Suction pad according to one of claims 2 to 5, characterized in that the opening ( 9 ) has an elongated shape and extends substantially parallel to the edge ( 6 ).

### Claim 7

Sauggreifer nach einem der Ansprüche 2 bis 6, dadurch gekennzeichnet, dass der Durchbruch (9) eine Ausstanzung oder Bohrung ist.7. Suction gripper according to one of claims 2 to 6, characterized in that the opening ( 9 ) is a punched out or bore.

### Claim 8

Sauggreifer nach einem der Ansprüche 2 bis 6, dadurch gekennzeichnet, dass der Durchbruch (9) lasergeschnitten ist und insbesondere mittels eines Kanals (10) mit den Rand (6) verbunden ist.8. Suction gripper according to one of claims 2 to 6, characterized in that the opening ( 9 ) is laser cut and in particular by means of a channel ( 10 ) with the edge ( 6 ).

### Claim 9

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass die Befestigungselemente aus Federstahl bestehen.9. suction pad according to one of the preceding claims, characterized in that the fasteners are made of spring steel.

### Claim 10

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass das Dichtprofil (8) ein Endlosprofil ist. Suction pad according to one of the preceding claims, characterized in that the sealing profile ( 8 ) is an endless profile.

### Claim 11

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass das Dichtprofil (8) in der Aufnahmenut (19) für den Rand (6) der Saugplatte (5), insbesondere in den Nutwänden Aufnahmen (20) für die die Oberfläche überragenden Abschnitte, insbesondere für die freien Enden (13) der Schenkel (12) der Befestigungselemente aufweist.11. Suction pad according to one of the preceding claims, characterized in that the sealing profile ( 8 ) in the receiving groove ( 19 ) for the edge ( 6 ) of the suction plate ( 5 ), in particular in the groove walls, receptacles ( 20 ) for the sections projecting above the surface , in particular for the free ends ( 13 ) of the legs ( 12 ) of the fastening elements.

### Claim 12

Sauggreifer nach Anspruch 11, dadurch gekennzeichnet, dass die Aufnahme (20) für die die Oberfläche überragenden Abschnitte der Befestigungselemente mit Hinterschneidungen (21) versehen sind.12. Suction gripper according to claim 11, characterized in that the receptacle ( 20 ) for the portions of the fastening elements projecting above the surface are provided with undercuts ( 21 ).

### Claim 13

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass das Dichtprofil (8) aus mehreren Materialien besteht.13. Suction pad according to one of the preceding claims, characterized in that the sealing profile ( 8 ) consists of several materials.

### Claim 14

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass das Dichtprofil (8) extrudiert ist.14. Suction pad according to one of the preceding claims, characterized in that the sealing profile ( 8 ) is extruded.

### Claim 15

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass die Saugplatte (5) aus Stahl, Aluminium, Kunststoff oder dergleichen besteht. Suction pad according to one of the preceding claims, characterized in that the suction plate ( 5 ) consists of steel, aluminum, plastic or the like.

### Claim 16

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass die Befestigungselemente im wesentlichen C-förmig ausgebildet sind.16. suction pad according to one of the preceding claims, characterized in that the fasteners are essentially C-shaped.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansSingle lifting units; Only one suction cupPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippersPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansCircular shape

Description

Translated from German

Die Erfindung betrifft einen Sauggreifer mit einem

Sauganschluss, einer den Sauganschluss tragenden Saugplatte

und einem an der Saugplatte befestigten Dichtprofil.The invention relates to a suction pad with a

Suction port, a suction plate carrying the suction port

and a sealing profile attached to the suction plate.

Sauggreifer sind in einer Vielzahl bekannt. Sie werden

Ã¼berall dort eingesetzt, wo GegenstÃ¤nde, Teile,

Verpackungen usw. angehoben, transportiert, gewendet oder

Ã¤hnlich gehandhabt werden. Als Verbindungselement zwischen

WerkstÃ¼ck und Vakuum-Erzeuger hat die technische und

konstruktive Ausgestaltung der Sauggreifer eine wichtige

Bedeutung. Es sind z. B. Flachsauggreifer,

Faltenbalgsauggreifer und andere Spezialsauggreifer

bekannt. Flachsauggreifer eignen sich besonders gut fÃ¼r die

Aufnahme von horizontalen KrÃ¤ften zum Handhaben glatter

WerkstÃ¼cke, z. B. von Blechtafeln, Kartons, Glasscheiben,

Spanplatten usw. FÃ¼r diese GegenstÃ¤nde weist der

Sauggreifer bzw. weist das Dichtprofil eine Dichtlippe auf.

Sollen GegenstÃ¤nde mit rauher, strukturierter OberflÃ¤che,

z. B. Holz, Steine, Strukturglas, Riffelbleche usw.

gehandhabt werden, dann werden Dichtprofile mit Dichtringen

verwendet. Die Faltenbalgsauggreifer besitzen eine gute

Anpassung an unebene OberflÃ¤chen und besitzen einen

Hubeffekt beim Ansaugen. Sie sind besonders fÃ¼r

groÃflÃ¤chige, biegeschlaffe WerkstÃ¼cke geeignet.Suction pads are known in a large number. you will be

used wherever objects, parts,

Packaging, etc. raised, transported, turned or

be handled similarly. As a connecting element between

Workpiece and vacuum generator has the technical and

constructive design of the suction pads an important

Meaning. There are e.g. B. flat suction pads,

Bellows suction cups and other special suction cups

known. Flat suction cups are particularly suitable for

Â Absorption of horizontal forces to handle smoother

Workpieces, e.g. B. of metal sheets, boxes, glass panes,

Chipboard, etc. For these items, the

Suction pad or the sealing profile has a sealing lip.

Should objects with a rough, structured surface,

e.g. B. wood, stones, structural glass, checker plates, etc.

are handled, then sealing profiles with sealing rings

used. The bellows suction cups have a good one

Adaptation to uneven surfaces and have one

Lift effect when suctioning. They are special for

large, limp workpieces suitable.

Insgesamt hat sich gezeigt, dass das Dichtprofil mehr oder

weniger stark verschleiÃt und dadurch der Sauggreifer nicht

mehr dicht am Gegenstand anliegt. Sind derartige

Dichtprofile mit der Saugplatte verklebt oder an diese

anvulkanisiert, dann muss der gesamte Sauggreifer ersetzt

werden.Overall, it has been shown that the sealing profile more or

less wear and therefore the suction pad does not

more close to the object. Are such

Sealing profiles glued to or on the suction plate

vulcanized, then the entire suction cup must be replaced

become.

Spezialsauggreifer werden fÃ¼r verschiedene Handling-

Aufgaben eingesetzt und besitzen unter UmstÃ¤nden eine an

den zu ergreifenden Gegenstand angepasste Form. Somit

werden auch bestimmte Geometrien des Dichtprofils benÃ¶tigt.

Um diese Kosten fÃ¼r speziell geformte Dichtprofile zu

senken wurde vorgeschlagen, Endlosprofile zu verwenden, die

mit der Saugplatte in geeigneter Weise verbunden werden.

Special suction pads are used for various handling

Tasks used and may have one

form adapted to the object to be gripped. Consequently

certain geometries of the sealing profile are also required.

To avoid these costs for specially shaped sealing profiles

it was suggested to use continuous profiles that lower

be connected to the suction plate in a suitable manner.

Â

Dies ist bei einem stetig konvexen gekrÃ¼mmten

Saugplattenrand relativ einfach mittels eines Spannringes

mÃ¶glich. Weist die Saugplatte jedoch konkav gekrÃ¼mmte

Randbereiche auf, dann wird das Dichtprofil entweder mit

der Saugplatte verklebt oder an diese angeschraubt. Es ist

auch bekannt, Befestigungsbleche, die das Dichtprofil

Ã¼bergreifen, zu verwenden. Hierbei hat sich als nachteilig

herausgestellt, dass das Wechseln des Dichtprofils zum

einen zeitaufwendig ist, zum anderen die BefestigungsÂ­

elemente sich unter UmstÃ¤nden als stÃ¶rend auswirken.This is with a continuously convex curved

Suction plate edge relatively simple using a clamping ring

possible. However, the suction plate has a concave curvature

Edge areas, then the sealing profile is either with

glued or screwed to the suction plate. It is

also known mounting plates that the sealing profile

spill over to use. This has been found to be disadvantageous

emphasized that changing the sealing profile to the

one is time consuming, the other is the attachment

elements may be disruptive.

Der Erfindung liegt daher die Aufgabe zugrunde, einen

Sauggreifer bereit zu stellen, welcher preiswert

herstellbar ist, und zudem das Dichtprofil relativ einfach

ausgewechselt werden kann.The invention is therefore based on the object

Suction pad ready to provide, which is inexpensive

is producible, and also the sealing profile is relatively simple

can be replaced.

Die Aufgabe wird mit einem Sauggreifer der eingangs

genannten Art erfindungsgemÃ¤Ã dadurch gelÃ¶st, dass die

Saugplatte im Bereich ihres Randes mit die OberflÃ¤che der

Oberseite und Unterseite der Saugplatte Ã¼berragenden

Befestigungselementen versehen ist, und dass das auf den

Rand der Saugplatte aufzuschiebende Dichtprofil Ã¼ber die

Befestigungselemente aufgeschoben ist.The task starts with a suction pad

mentioned type according to the invention solved in that the

Suction plate in the area of its edge with the surface of the

The top and bottom of the suction plate protrude

Fasteners is provided, and that on the

Edge of the suction plate to be pushed over the sealing profile

Fasteners are pushed on.

Der erfindungsgemÃ¤Ãe Sauggreifer hat den wesentlichen

Vorteil, dass das Dichtprofil lediglich auf den Rand der

Saugplatte aufgeschoben werden muss und dort von den am

Rand vorgesehenen Befestigungselementen gehalten wird. Das

Dichtprofil muss beim erfindungsgemÃ¤Ãen Sauggreifer also

nicht an die Saugplatte angeklebt oder anvulkanisiert

werden. Das Aufstecken hat den wesentlichen Vorteil, dass

dies in der Regel ohne Werkzeug erfolgen kann und deshalb

vor Ort, z. B. auch auf einer Baustelle durchfÃ¼hrbar ist.

Das Dichtprofil kann deshalb gewechselt werden, ohne dass

eine neue Saugplatte verwendet werden muss. Ein weiterer

Vorteil des erfindungsgemÃ¤Ãen Sauggreifers wird darin

gesehen, dass das Dichtprofil nicht nur an den konvex

gekrÃ¼mmten Bereichen eine Saugplatte, sondern gleichermaÃen

gut auch an konkav gekrÃ¼mmten Randbereichen der Saugplatte

befestigt werden kann. Die Saugplatte kann also beliebige

Formen aufweisen, wie z. B. eine H-Form zum handhaben von

sogenannten "Knochensteinen". Da die Befestigungselemente

bei einem AusfÃ¼hrungsbeispiel der Erfindung vom Dichtprofil

vollstÃ¤ndig Ã¼berdeckt werden, wirken sie sich nicht als

stÃ¶rend aus bzw. behindern nicht die Handhabung der

GegenstÃ¤nde. Dabei kÃ¶nnen die Befestigungselemente

einstÃ¼ckig an der Saugplatte vorgesehen sein, wobei hier

die Saugplatte z. B. als Kunststoff-Spritzgussteil relativ

preiswert herstellbar ist. Es besteht aber auch die

MÃ¶glichkeit, die Befestigungselemente als separate Bauteile

auszubilden. In diesem Fall kÃ¶nnen ebene Platten verwendet

werden, an denen die Befestigungselemente angebracht werden.

The suction pad according to the invention has the essential

Advantage that the sealing profile only on the edge of the

Â Suction plate must be pushed on and there by the

Edge provided fasteners is held. The

Sealing profile must therefore with the suction pad according to the invention

not glued or vulcanized to the suction plate

become. Attaching has the main advantage that

this can usually be done without tools and therefore

on site, e.g. B. is also feasible on a construction site.

The sealing profile can therefore be changed without

a new suction plate must be used. Another

The advantage of the suction pad according to the invention is therein

seen that the sealing profile not only on the convex

curved areas a suction plate, but equally

also good at concave curved edge areas of the suction plate

can be attached. So the suction plate can be any

Have shapes such. B. an H-shape to handle

so-called "bone stones". Because the fasteners

in one embodiment of the invention from the sealing profile

are completely covered, they do not act as

disturbing or do not hinder the handling of the

Objects. The fasteners can

be provided in one piece on the suction plate, here

the suction plate z. B. relatively as a plastic injection molding

is inexpensive to manufacture. But there is also

Possibility of fastening elements as separate components

to train. In this case flat plates can be used

to which the fasteners are attached.

Â

Bei einem AusfÃ¼hrungsbeispiel ist der Rand der Saugplatte

mit DurchbrÃ¼chen versehen. In die DurchbrÃ¼che kÃ¶nnen die

z. B. im wesentlich C-fÃ¶rmige Befestigungselemente, die z. B.

als Klammern ausgebildet sind, eingesetzt werden. Dabei

zeigen die freien Enden der Schenkel der BefestigungsÂ­

elemente, insbesondere der Klammern, die die PlattenoberÂ­

flÃ¤che Ã¼berragen, in Richtung der Plattenmitte.In one embodiment, the edge of the suction plate

provided with breakthroughs. In the breakthroughs

e.g. B. essentially C-shaped fasteners, the z. B.

are designed as brackets, are used. Here

show the free ends of the legs of the attachment

elements, especially the brackets that make up the slab top

protrude surface in the direction of the center of the plate.

Bei einem bevorzugten AusfÃ¼hrungsbeispiel der Erfindung

weist der Durchbruch eine lÃ¤ngliche Form auf, die im

wesentlichen parallel zum Rand verlÃ¤uft. Durch die Form des

Durchbruchs wird sichergestellt, dass die Klammer sich

mÃ¶glichst nahe zum Rand der Saugplatte befindet, so dass

das Dichtprofil optimal am Rand der Saugplatte gehalten

werden kann.In a preferred embodiment of the invention

the breakthrough has an elongated shape, which in the

runs essentially parallel to the edge. Due to the shape of the

Breakthrough ensures that the brace itself

is as close as possible to the edge of the suction plate, so that

the sealing profile optimally held at the edge of the suction plate

can be.

Vorteilhaft ist der Durchbruch eine Ausstanzung oder eine

Bohrung oder wird durch nibbeln oder mittels eines

Schneidbrenners oder Lasers hergestellt. Bei einer

bevorzugten AusfÃ¼hrungsform ist der Durchbruch Ã¼ber einen

Kanal mit dem Rand verbunden. Wird die Saugplatte mit einem

Laser ausgeschnitten, dann kann dieser gleichzeitig beim

Schneiden der Kontur auch die DurchbrÃ¼che erzeugen und

erzeugt beim Einfahren ins Platteninnere zum Ausschneiden

der DurchbrÃ¼che die oben genannten KanÃ¤le.

The breakthrough is a punched out or a

Hole or is by nibbling or by means of a

Cutting torch or laser manufactured. At a

preferred embodiment is the breakthrough over a

Channel connected to the edge. If the suction plate with a

Laser cut out, then this can be done at the same time

Cutting the contour also create the breakthroughs and

created when cutting into the interior of the panel

of breakthroughs the above channels.

Â

Der Laserstrahl muÃ bei der Bearbeitung der Saugplatte

nicht abgesetzt werden. Es kÃ¶nnen sowohl der Rand als auch

die DurchbrÃ¼che in einem Arbeitsgang bearbeitet bzw.

hergestellt werden.The laser beam must be used when processing the suction plate

not be discontinued. It can both the edge as well

processed the breakthroughs in one operation or

getting produced.

Vorzugsweise besteht die Klammer bei einem

AusfÃ¼hrungsbeispiel aus Federstahl. Andere Materialien,

z. B. Kunststoff oder Verbundmaterialien sind denkbar.The bracket is preferably at one

Spring steel embodiment. Other materials,

e.g. B. plastic or composite materials are conceivable.

Bei einer bevorzugten AusfÃ¼hrungsform ist vorgesehen, dass

das Dichtprofil in der Aufnahmenut fÃ¼r den Rand der

Saugplatte, insbesondere in den NutwÃ¤nden Aufnahmen fÃ¼r die

freie Enden der Schenkel der Klammern aufweist. Wird das

Dichtprofil Ã¼ber den Rand der Saugplatte somit auf die

Klammern aufgeschoben, dann greifen die freien Enden der

Schenkel der Klammern in die an den NutwÃ¤nden vorgesehene

Aufnahmen ein, wodurch das Dichtprofil festgehalten wird.

Die die OberflÃ¤che der Saugplatte Ã¼berragenden Schenkel der

Klammern liegen insbesondere unter Vorspannung in diesen

Aufnahmen an den NutwÃ¤nden an.In a preferred embodiment it is provided that

the sealing profile in the receiving groove for the edge of the

Suction plate, especially in the groove walls for the recordings

has free ends of the legs of the brackets. Will that

Sealing profile over the edge of the suction plate thus on the

Put the clamps on, then grab the free ends of the

Leg of the brackets in the provided on the groove walls

Recordings, whereby the sealing profile is held.

The leg of the

Parentheses are located in them in particular under tension

Recordings on the groove walls.

Eine Weiterbildung sieht vor, dass die Aufnahmen fÃ¼r die

freien Enden der Schenkel der Klammern mit HinterÂ­

schneidungen versehen sind. Aufgrund der Hinterschneidungen

wird das Dichtprofil von den freien Enden der Schenkel der

Klammern auch gehalten, wenn KrÃ¤fte, insbesondere

QuerkrÃ¤fte am Dichtprofil angreifen. Die Hinterschneidungen

verhindern ein Herausgleiten der Schenkel bzw. der freien

Enden der Schenkel aus den Aufnahmen.A further training provides that the recordings for the

free ends of the legs of the brackets with hind

cuts are provided. Because of the undercuts

the sealing profile from the free ends of the legs of the

Brackets also held when forces, in particular

Â Apply lateral forces to the sealing profile. The undercuts

prevent the legs or the free ones from sliding out

Ends of the legs from the shots.

Bevorzugt besteht das Dichtprofil aus einem oder mehreren

Materialien. So kann z. B. der Abschnitt, an welchem die

Klammern angreifen und der zur Befestigung des Dichtprofils

an der Saugplatte dient, aus einem hÃ¤rteren Werkstoff

bestehen, wobei die Dichtlippe aus einem weicheren

Werkstoff hergestellt ist. Dieses Dichtprofil wird aufgrund

des hÃ¤rteren Werkstoffes im Bereich des Randes der

Saugplatte sicher festgehalten und es kÃ¶nnen dennoch z. B.

unebene GegenstÃ¤nde mit dem relativen weichen Werkstoff der

Dichtlippen angesaugt werden.The sealing profile preferably consists of one or more

Materials. So z. B. the section where the

Attack clips and attach the sealing profile

serves on the suction plate, made of a harder material

consist, the sealing lip of a softer

Material is made. This sealing profile is due

of the harder material in the area of the edge of the

Suction plate held securely and it can still z. B.

uneven objects with the relative soft material of the

Sealing lips are sucked in.

Vorzugsweise besteht das Dichtprofil aus Meterware. Das

Dichtprofil ist vorzugsweise mittels eines ExtrudiervorÂ­

ganges hergestellt. Von diesem Dichtprofil kann dann die

benÃ¶tigte LÃ¤nge abgeschnitten und auf die Saugplatte

aufgeschoben oder aufgeklipst werden. Die beiden freien

Enden des Dichtprofils werden dann lediglich miteinander

verklebt. Soll ein abgenutztes bzw. verschlieÃendes

Dichtprofil ersetzt werden, dann wird die Aufnahmenut

aufgeschnitten und das Dichtprofil kann von der Saugplatte

abgenommen werden. Die Saugplatte und die Klammern bleiben

unbeschÃ¤digt und kÃ¶nnen wiederverwendet werden.

Preferably, the sealing profile consists of yard goods. The

Sealing profile is preferably by means of an extrusion

ganges manufactured. From this sealing profile can then

Cut the required length and onto the suction plate

be pushed on or clipped on. The two free

The ends of the sealing profile are then only together

glued. Should be a worn or occlusive one

Sealing profile to be replaced, then the receiving groove

cut open and the sealing profile can from the suction plate

be removed. The suction plate and the clips remain

undamaged and can be reused.

Â

Weitere Vorteile, Merkmale und Einzelheiten der Erfindung

ergeben sich aus den UnteransprÃ¼chen sowie aus der

nachfolgenden Beschreibung, in der unter Bezugnahme auf die

Zeichnung ein besonders bevorzugtes AusfÃ¼hrungsbeispiel im

Einzelnen beschrieben ist. Dabei kÃ¶nnen die in der

Zeichnung dargestellten sowie in den AnsprÃ¼chen und in der

Beschreibung erwÃ¤hnten Merkmale jeweils einzeln fÃ¼r sich

oder in beliebiger Kombination erfindungswesentlich sein.Further advantages, features and details of the invention

result from the subclaims and from the

following description, in which with reference to the

Drawing a particularly preferred embodiment in

Individual is described. The in the

Drawing shown as well as in the claims and in the

Description mentioned features each individually

or be essential to the invention in any combination.

In der Zeichnung zeigen:The drawing shows:

Fig. 1 eine Draufsicht auf eine Saugplatte eines

Sauggreifers gemÃ¤Ã der Erfindung; Figure 1 is a plan view of a suction plate of a suction pad according to the invention.

Fig. 2 eine perspektivische Ansicht eines Sauggreifers

gemÃ¤Ã dem Stand der Technik; Fig. 2 is a perspective view of a suction pad according to the prior art;

Fig. 3 einen Ausschnitt III eines Durchbruchs gemÃ¤Ã

Fig. 1, in vergrÃ¶Ãerter Wiedergabe; und Fig. 3 shows a detail III of an opening of Figure 1 in an enlarged view. and

Fig. 4 einen Schnitt IV-IV durch den Durchbruch gemÃ¤Ã

Fig. 3, jedoch mit eingesetzter Klammer und

aufgeschobenem Dichtprofil. Fig. 4 shows a section IV-IV through the breakthrough according to FIG. 3, but with an inserted clip and pushed sealing profile.

Die Fig. 2 zeigt einen insgesamt mit 1 bezeichneten

Sauggreifer, wie er aus dem Stand der Technik bekannt ist.

FIG. 2 shows a suction gripper, generally designated 1 , as is known from the prior art.

Dieser Sauggreifer 1 besitzt einen Sauganschluss 2, der

z. B. mit einem AuÃengewinde 3 versehen ist, Ã¼ber welches

der Sauggreifer 1 in eine hierfÃ¼r vorgesehene Aufnahme

eingeschraubt werden kann. Der Sauganschluss 2 ist mit

einer Bohrung 4 versehen, Ã¼ber welche Luft aus der

Saugglocke abgesaugt werden kann. Dieser Sauganschluss 2

ist an einer Saugplatte 5 befestigt, wobei die Saugplatte 5

beim gezeigten AusfÃ¼hrungsbeispiel eine kreisrunde Form

besitzt. Es sind jedoch auch andere Formen denkbar. Am Rand

6 der Saugplatte 5 ist mittels eines Schlauchbinders 7 ein

Dichtprofil 8 befestigt. Die Verwendung eines

Schlauchbinders 7 zur Befestigung des Dichtprofils 8 an der

Saugplatte 5 ist jedoch nur dann mÃ¶glich, wenn der Rand 6

der Saugplatte 5 stetig konvex geformt ist, so daÃ der

Schlauchbinder 7 jederzeit am Rand 6 anliegt. Bei konkav

gekrÃ¼mmten Abschnitten kann zur Befestigung des

Dichtprofils 8 kein Schlauchbinder 7 mehr verwendet werden

und das Dichtprofil muss z. B. Ã¼ber entsprechend geformte,

das Dichtprofil Ã¼bergreifende Halteelemente oder mittels

einer Klebeverbindung an der Saugplatte 5 befestigt werden.This suction pad 1 has a suction port 2 , the z. B. is provided with an external thread 3 , via which the suction pad 1 can be screwed into a receptacle provided for this purpose. The suction connection 2 is provided with a bore 4 , through which air can be sucked out of the suction bell. This suction port 2 is attached to a suction plate 5 , the suction plate 5 having a circular shape in the embodiment shown. However, other shapes are also conceivable. At the edge 6 of the suction plate 5 , a sealing profile 8 is fastened by means of a hose tie 7 . However, the use of a hose clamp 7 for fastening the sealing profile 8 on the suction plate 5 is only possible when the edge of the suction plate 5 is formed continuously convexly 6, so that the hose clamp 7 at any time stops at the edge. 6 In concavely curved portions for fastening the sealing profile 8 can not be used more hose clamps 7 and the sealing profile must z. B. via appropriately shaped, the sealing profile overlapping holding elements or by means of an adhesive connection to the suction plate 5 .

Die Fig. 1 zeigt eine Saugplatte 5 gemÃ¤Ã der Erfindung,

die z. B. mittels eines Lasers aus einem plattenfÃ¶rmigen

Material ausgeschnitten ist. Die Saugplatte 5 weist im

Bereich ihres Randes 6 lÃ¤ngliche DurchbrÃ¼che 9 auf, die in

im wesentlichen regelmÃ¤Ãigen AbstÃ¤nden am Rand 6 vorgesehen

sind. Die DurchbrÃ¼che 9 erstrecken sich im wesentlichen in

Richtung des Randes 6. Fig. 1 shows a suction plate 5 according to the invention, the z. B. is cut out of a plate-shaped material by means of a laser. The suction plate 5 has in the area of its edge 6 elongated openings 9 which are provided at the edge 6 at substantially regular intervals. The openings 9 extend essentially in the direction of the edge 6 .

Die Fig. 3 zeigt einen Ausschnitt III des Durchbruchs 9

gemÃ¤Ã Fig. 1. Es ist deutlich erkennbar, dass der

Durchbruch 9 Ã¼ber einen Kanal 10 mit dem Rand 6 der Platte

5 verbunden ist. Der Laserstrahl kann also beim

Ausschneiden der Saugplatte 5 aus dem plattenfÃ¶rmigen

Material in einem Arbeitsgang die DurchbrÃ¼che 9 herstellen,

indem er ins Platteninnere abgelenkt wird, wodurch die

KanÃ¤le 10 erzeugt werden. Es ist jedoch auch denkbar, dass

die Ãffnungen 9 keine Verbindung zum Rand 6 aufweisen. FIG. 3 shows a section III of the opening 9 according to FIG. 1. It can be clearly seen that the opening 9 is connected to the edge 6 of the plate 5 via a channel 10 . When the suction plate 5 is cut out of the plate-shaped material, the laser beam can thus produce the openings 9 in one work step by deflecting it into the plate interior, as a result of which the channels 10 are produced. However, it is also conceivable that the openings 9 have no connection to the edge 6 .

In der Fig. 4 ist der Schnitt IV-IV durch die Saugplatte 5

dargestellt, wobei in den Durchbruch 9 eine Klammer 11

eingesetzt und auf den Rand 6 der Saugplatte 5 das

Dichtprofil 8 aufgeschoben ist. Diese Klammer 11 weist zwei

Schenkel 12 auf, deren freie Enden 13 die OberflÃ¤che 22 der

Saugplatte 5 Ã¼berragen. Die beiden Schenkel 12 sind Ã¼ber

einen Verbindungssteg 14 miteinander verbunden, wobei sich

der Verbindungssteg 14 an einer dem Rand 6 zugewandten

SeitenflÃ¤che 15 (Fig. 3) des Durchbruchs 9 abstÃ¼tzt. Das

Dichtprofil 8 ist im in der Fig. 4 dargestellten

AusfÃ¼hrungsbeispiel zweiteilig ausgebildet, wobei der erste

Teil 16 aus einem hÃ¤rteren Werkstoff besteht und den Rand 6

der Saugplatte 6 umgreift und an diesem ersten Teil 16 ein

zweiter Teil 17 angeklebt oder anvulkanisiert ist, wobei

der zweite Teil 17 die Dichtlippe 18 trÃ¤gt und aus einem

weicheren Werkstoff besteht. Das gesamte Dichtprofil 8 kann

auch als Zweikomponentenprofil in einem Arbeitsgang

hergestellt werden.In FIG. 4 the section IV-IV is illustrated by the suction plate 5, in which a bracket 11 is inserted into the opening 9 and the sealing profile 8 is pushed to the edge 6 of the suction plate 5. This bracket 11 has two legs 12 , the free ends 13 of which protrude beyond the surface 22 of the suction plate 5 . The two legs 12 are connected to one another via a connecting web 14 , the connecting web 14 being supported on a side face 15 ( FIG. 3) of the opening 9 facing the edge 6 . The sealing profile 8 is formed in two parts in the embodiment shown in FIG. 4, wherein the first part 16 consists of a harder material and encompasses the edge 6 of the suction plate 6 and on this first part 16 a second part 17 is glued or vulcanized, the second part 17 carries the sealing lip 18 and consists of a softer material. The entire sealing profile 8 can also be produced as a two-component profile in one operation.

Das Dichtprofil 8 besitzt eine Aufnahmenut 19, in welche

der Rand 6 der Saugplatte 5 eingeschoben wird. An den

NutwÃ¤nden dieser Aufnahmenut 19 sind einander

gegenÃ¼berliegende Aufnahmen 20 fÃ¼r die Schenkel 12 der

Klammer 11 vorgesehen. Diese Aufnahmen 20 besitzen

Hinterschneidungen 21, hinter welche die freien Enden 13

der Schenkel 12 eingreifen. Wird das Dichtprofil 8 auf den

Rand 6 der Saugplatte 5 aufgeschoben und liegen die freien

Enden 13 der Schenkel 12 der Klammer 11 hinter den

Hinterschneidungen 21 der Aufnahmen 20, dann ist das

Dichtprofil 8 unverlierbar an der Saugplatte 5 befestigt

und kann nicht nur horizontale KrÃ¤fte, sondern auch

QuerkrÃ¤fte aufnehmen bzw. abstÃ¼tzen.The sealing profile 8 has a receiving groove 19 into which the edge 6 of the suction plate 5 is inserted. On the groove walls of this receiving groove 19 , opposing receptacles 20 are provided for the legs 12 of the bracket 11 . These receptacles 20 have undercuts 21 , behind which the free ends 13 of the legs 12 engage. If the sealing profile 8 is pushed onto the edge 6 of the suction plate 5 and the free ends 13 of the legs 12 of the bracket 11 lie behind the undercuts 21 of the receptacles 20 , then the sealing profile 8 is captively attached to the suction plate 5 and can not only apply horizontal forces, but also absorb or support lateral forces.

Ein LÃ¶sen des Dichtprofils 8, z. B. bei verschlissener

Dichtlippe 16, erfolgt auf einfache Weise dadurch, dass das

Dichtprofil 8, insbesondere der erste Teil 16

aufgeschnitten wird, so dass dieser von der Klammer 11

abgezogen werden kann. Sowohl die Saugplatte 5 als auch die

Klammern 11 kÃ¶nnen fÃ¼r ein neues Dichtprofil 8

wiederverwendet werden.Loosening the sealing profile 8 , for. B. with worn sealing lip 16 , is done in a simple manner by cutting the sealing profile 8 , in particular the first part 16 , so that it can be removed from the bracket 11 . Both the suction plate 5 and the brackets 11 can be reused for a new sealing profile 8 .

Die Klammern 11 sind nach dem Aufschieben des Dichtprofils

8 von auÃen nicht zu sehen. Es ist leicht einzusehen, dass

der erfindungsgemÃ¤Ãe Sauggreifer 1, insbesondere die

Saugplatte 5 beliebige Formen aufweisen kann und das

Dichtprofil 8 dennoch sicher an der Saugplatte 5 befestigt

werden kann. AuÃerdem kann der erfindungsgemÃ¤Ãe Sauggreifer

1 mit Saugplatte 5 aus beliebigem Material hergestellt

sein. Die Saugplatte 5 kann aus Stahl, Aluminium,

Kunststoff oder einem anderen Werkstoff bestehen.The clips 11 cannot be seen from the outside after the sealing profile 8 has been pushed on. It is easy to see that the suction gripper 1 according to the invention, in particular the suction plate 5, can have any shape and the sealing profile 8 can nevertheless be securely attached to the suction plate 5 . In addition, the suction pad 1 according to the invention with the suction plate 5 can be made of any material. The suction plate 5 can be made of steel, aluminum, plastic or another material.

## Classifications

- B66C1/0293
- B65G47/91
- B65G47/91
- B66C1/02
- B66C1/0212

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
