# 40. Saugvorrichtung und damit ausgestattete Handhabungsvorrichtung

- **Archive rank:** 40 of 50
- **Publication:** [DE-102004017898-A1](https://patents.google.com/patent/DE102004017898A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/034962693/publication/DE102004017898A1?q=pn%3DDE102004017898A1)
- **Publication date:** 2005-11-03
- **Filing date:** 2004-04-13
- **Earliest priority:** 2004-04-13
- **Family:** 34962693
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** FESTO AG & CO
- **Inventors:** SCHOETTNER MICHAEL

## Abstract

Die Erfindung betrifft eine Saugvorrichtung mit mindestens einem mit Unterdruck beaufschlagbaren Haltekopf (28) und mit einer Unterdruckerzeugungseinrichtung (25) zum Erzeugen des Unterdruckes in einem Ansaugbereich (27) des mindestens einen Haltekopfs (28), wobei ein Gegenstand (24) durch den Unterdruck an den mindestens einen Haltekopf (28) angesaugt wird. Die Unterdruckerzeugungseinrichtung (25) weist einen elektrischen Lineardirektantrieb (26) zur Erzeugung des Unterdrucks auf. Ein Läufer (32) des Lineardirektantriebs (26) bildet einen relativ zu dem mindestens einen Haltekopf (28) beweglichen Druckkolben (31) zur Erzeugung des Unterdrucks.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-102004017898-A1/pdf000.png)

![Sketch 1 for DE-102004017898-A1](https://nimo.iptorch.com/refdrawing/DE-102004017898-A1/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-102004017898-A1/pdf001.png)

![Sketch 2 for DE-102004017898-A1](https://nimo.iptorch.com/refdrawing/DE-102004017898-A1/pdf001.png)

## Claims

### Claim 1 (independent)

Saugvorrichtung mit mindestens einem mit Unterdruck beaufschlagbaren Haltekopf (28) und mit einer Unterdruckerzeugungseinrichtung (25) zum Erzeugen des Unterdruckes in einem Ansaugbereich (27) des mindestens einen Haltekopfs (28), wobei ein Gegenstand (24) durch den Unterdruck an den mindestens einen Haltekopf (28) angesaugt wird, dadurch gekennzeichnet, dass die Unterdruckerzeugungseinrichtung (25) einen elektrischen Lineardirektantrieb (26) zur Erzeugung des Unterdrucks aufweist, und dass ein Läufer (32) des Lineardirektantriebs (26) einen relativ zu dem mindestens einen Haltekopf (28) beweglichen Druckkolben (31) zur Erzeugung des Unterdrucks bildet.Suction device with at least one acted upon by vacuum holding head ( 28 ) and with a vacuum generating device ( 25 ) for generating the negative pressure in a suction region ( 27 ) of the at least one holding head ( 28 ), whereby an object ( 24 ) by the negative pressure to the at least one holding head ( 28 ), characterized in that the vacuum generating device ( 25 ) an electric linear direct drive ( 26 ) for generating the negative pressure, and that a runner ( 32 ) of the linear direct drive ( 26 ) one relative to the at least one holding head ( 28 ) movable pressure piston ( 31 ) forms to generate the negative pressure.

### Claim 2

Saugvorrichtung nach Anspruch 1, dadurch gekennzeichnet, dass der mindestens eine Haltekopf (28) und die Unterdruckerzeugungseinrichtung (25) axial hintereinander angeordnet sind.Suction device according to claim 1, characterized in that the at least one holding head ( 28 ) and the negative pressure generating device ( 25 ) are arranged axially one behind the other.

### Claim 3

Saugvorrichtung nach Anspruch 1 oder 2, dadurch gekennzeichnet, dass der mindestens eine Haltekopf (28) eine Unter druckkammer (30) der Unterdruckerzeugungseinrichtung (25) begrenzt, wenn er einen Gegenstand (24) ansaugt.Suction device according to claim 1 or 2, characterized in that the at least one holding head ( 28 ) a lower pressure chamber ( 30 ) of the vacuum generating device ( 25 ), if he is an object ( 24 ) sucks.

### Claim 4

Saugvorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass der Läufer (32) zur Vergrößerung bzw. Verkleinerung des Volumens der Unterdruckkammer (30) vorgesehen ist.Suction device according to one of the preceding claims, characterized in that the rotor ( 32 ) for increasing or decreasing the volume of the vacuum chamber ( 30 ) is provided.

### Claim 5

Saugvorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass die Unterdruckerzeugungseinrichtung (25) und der mindestens eine Haltekopf (28) eine Baueinheit bilden.Suction device according to one of the preceding claims, characterized in that the negative pressure generating device ( 25 ) and the at least one holding head ( 28 ) form a structural unit.

### Claim 6

Saugvorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass der Läufer (32) in Richtung in zwei einander entgegengesetzten Richtungen antreibbar ist, wobei er einer Bewegung in einer ersten Richtung Unterdruck im Ansaugbereich (27) des mindestens einen Haltekopfs (28) erzeugt und bei einer der ersten Bewegung entgegengesetzten Bewegung in einer zweiten Richtung ausgeglichene Druckverhältnisse oder Überdruck im Ansaugbereich (27) des mindestens einen Haltekopfs (28) erzeugt, so dass ein durch den mindestens einen Haltekopf (28) angesaugter Gegenstand (24) freigegeben bzw. vom Haltekopf (28) abgestoßen wird.Suction device according to one of the preceding claims, characterized in that the rotor ( 32 ) is drivable in the direction in two opposite directions, wherein it is a movement in a first direction negative pressure in the intake ( 27 ) of the at least one holding head ( 28 ) and in a second direction opposite to the first motion movement balanced pressure conditions or pressure in the intake ( 27 ) of the at least one holding head ( 28 ), so that a through the at least one holding head ( 28 ) sucked object ( 24 ) or released from the holding head ( 28 ) is repelled.

### Claim 7

Saugvorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass die Unterdruckerzeugungseinrichtung (25) einen Auslass (44) zum Ausstoßen von Druckluft beim Erzeugen von Unterdruck auf Seiten des mindestens einen Haltekopfs (28) aufweist.Suction device according to one of the preceding claims, characterized in that the negative pressure generating device ( 25 ) an outlet ( 44 ) for discharging compressed air when generating negative pressure on the side of the at least one holding head ( 28 ) having.

### Claim 8

Saugvorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass sie mindestens einen Verbindungskanal (33) zur Verbindung einer Unterdruckkammer (30) der Unterdruckerzeugungseinrichtung (25) mit einem Ansaugbereich (27) des mindestens einen Haltekopfs (28) aufweist.Suction device according to one of the preceding claims, characterized in that it comprises at least one connecting channel ( 33 ) to the verbin a vacuum chamber ( 30 ) of the vacuum generating device ( 25 ) with a suction area ( 27 ) of the at least one holding head ( 28 ) having.

### Claim 9

Saugvorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass der Läufer (32) durch einen Permanentmagnet gebildet wird oder eine Permanentmagnetanordnung aufweist.Suction device according to one of the preceding claims, characterized in that the rotor ( 32 ) is formed by a permanent magnet or has a permanent magnet arrangement.

### Claim 10

Saugvorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass der Lineardirektantrieb (26) eine Erreger-Spulenanordnung mit mehreren entsprechend der Bewegungsrichtung des Läufers (32) aneinandergereihten Spulen aufweist.Suction device according to one of the preceding claims, characterized in that the linear direct drive ( 26 ) a field coil arrangement with several according to the direction of movement of the rotor ( 32 ) has juxtaposed coils.

### Claim 11

Saugvorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass dem Lineardirektantrieb (26) eine insbesondere in die Saugvorrichtung (13) integrierte Steuereinrichtung (50) zugeordnet ist.Suction device according to one of the preceding claims, characterized in that the linear direct drive ( 26 ) a particular in the suction device ( 13 ) integrated control device ( 50 ) assigned.

### Claim 12

Saugvorrichtung nach Anspruch 11, dadurch gekennzeichnet, dass die Steuereinrichtung (50) eine insbesondere zur Kraftregelung ausgestaltete Regelungseinrichtung (51) enthält.Suction device according to claim 11, characterized in that the control device ( 50 ) a control device designed in particular for force control ( 51 ) contains.

### Claim 13

Saugvorrichtung nach Anspruch 12, dadurch gekennzeichnet, dass die Regelungseinrichtung (51) zur Ansteuerung des Lineardirektantriebs (26) zum Ausgleich einer Leckage im Bereich des Haltekopfes (28) ausgestaltet ist.Suction device according to claim 12, characterized in that the regulating device ( 51 ) for controlling the linear direct drive ( 26 ) to compensate for a leakage in the region of the holding head ( 28 ) is configured.

### Claim 14

Saugvorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass sie mindestens einen Drucksensor (52) zur Erfassung des Drucks im Ansaugbereich (27) des mindestens einen Haltekopfs (28) aufweist.Suction device according to one of the preceding claims, characterized in that it comprises at least one pressure sensor ( 52 ) for detecting the pressure in the intake area ( 27 ) of the at least one holding head ( 28 ) having.

### Claim 15

Saugvorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass der mindestens eine Haltekopf (28) zumindest teilweise aus flexiblem Material ist.Suction device according to one of the preceding claims, characterized in that the at least one holding head ( 28 ) is at least partially made of flexible material.

### Claim 16

Saugvorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass der mindestens eine Haltekopf (28) auswechselbar ist.Suction device according to one of the preceding claims, characterized in that the at least one holding head ( 28 ) is interchangeable.

### Claim 17

Handhabungsvorrichtung mit mindestens einer Saugvorrichtung (13) nach einem der vorhergehenden Ansprüche und mindestens einem Linear- und/oder mindestens einem Rotationsantrieb zur Positionierung der mindestens einen Saugvorrichtung (13).Handling device with at least one suction device ( 13 ) according to one of the preceding claims and at least one linear and / or at least one rotary drive for positioning the at least one suction device ( 13 ).

## Full description

PERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippersPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippersDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippers control arrangements

Description

Translated from German

Die

Erfindung betrifft eine Saugvorrichtung mit mindestens einem mit

Unterdruck beaufschlagbaren Haltekopf und mit einer Unterdruckerzeugungseinrichtung

zum Erzeugen des Unterdruckes in einem Ansaugbereich des mindestens

einen Haltekopfs, wobei ein Gegenstand durch den Unterdruck an den

mindestens einen Haltekopf angesaugt wird. Die Erfindung betrifft

ferner eine damit ausgestattete Handhabungsvorrichtung.The

The invention relates to a suction device with at least one with

Negative pressurizable holding head and with a vacuum generating device

for generating the negative pressure in a suction region of the at least

a holding head, wherein an object by the negative pressure to the

at least one holding head is sucked. The invention relates

Furthermore, a handling device equipped therewith.

Eine

derartige Saugvorrichtung ist beispielsweise aus der deutschen Patentanmeldung

25 49 514 bekannt. Dieses Dokument beschreibt Saugvorrichtungen,

die Unterdruckerzeugungseinrichtungen enthalten. Die Saugvorrichtungen

sind an einem FÃ¶rderband

befestigt und dienen zum Ansaugen und WeiterfÃ¶rdern von Bechern. Die Saugvorrichtungen und

somit auch die Unterdruckerzeugungseinrichtungen werden durch von

auÃen

angreifende mechanische KrÃ¤fte

betÃ¤tigt,

nÃ¤mlich

durch Steuerschienen, die in Nuten an den Unterdruckerzeugungseinrichtungen

eingreifen und somit einen Haltekopf relativ zu einem Basisteil

der Saugvorrichtung bewegen. Durch die Relativbewegung wird eine

Unterdruckkammer im Innern der Saugvorrichtung verkleinert und somit

in einem mit der Unterdruckkammer durch KanÃ¤le verbundenen Ansaugbereich

des Haltekopfs ein Unterdruck zum Ansaugen eines Gegenstandes, im

konkreten Fall eines Bechers, erzeugt.A

such suction device is for example from the German patent application

25 49 514 known. This document describes suction devices,

containing the vacuum generating means. The suction devices

are on a conveyor belt

attached and serve for sucking and forwarding cups. The suction devices and

thus also the vacuum generating devices are by

Outside

attacking mechanical forces

actuated,

namely

by control rails, which are in grooves on the vacuum generating devices

engage and thus a holding head relative to a base part

to move the suction device. The relative movement becomes a

Vacuum chamber inside the suction reduced and thus

in a suction area connected to the vacuum chamber through channels

of the holding head, a negative pressure for sucking an object, im

concrete case of a mug, generated.

Nun

ist es in vielen AnwendungsfÃ¤llen

nicht mÃ¶glich,

dass mechanische KrÃ¤fte

von auÃen

an Saugvorrichtungen angreifen. HÃ¤ufig verwendet man dann pneumatische

Saugvorrichtungen, bei denen eine von der Saugvorrichtung abgesetzte

pneumatische Vakuumerzeugungsvorrichtung den Unterdruck erzeugt.

Die Saugvorrichtung und die Vakuumerzeugungsvorrichtung sind mittels

eines oder mehrerer DruckluftschlÃ¤uche verbunden. Derartige SchlÃ¤uche behindern

jedoch den Bewegungsspielraum der Saugvorrichtung, insbesondere

dann, wenn sie einen Bestandteil einer Handhabungsvorrichtung bildet. Ferner

ist das zusÃ¤tzliche

Aggregat in Gestalt der Vakuumerzeugungsvorrichtung notwendig.Now

it is in many applications

not possible,

that mechanical forces

from the outside

to attack suction devices. Often one then uses pneumatic

Suction devices in which one of the suction device remote

pneumatic vacuum generating device generates the negative pressure.

The suction device and the vacuum generating device are by means of

one or more compressed air hoses connected. Hinder such hoses

but the range of motion of the suction device, in particular

when forming part of a handling device. Further

is the extra

Aggregate in the form of the vacuum generating device necessary.

In

der DE 101 50 126

A1 ist eine Saugvorrichtung beschrieben, bei der ein piezo-elektrischer Biegewandler

einen zum Ansaugen eines Gegenstandes durch einen Haltekopf erforderlichen

Unterdruck erzeugt. Die HaltekrÃ¤fte

sind allerdings sehr gering, weil der Biegewandler lediglich einen

geringen Unterdruck erzeugen kann.In the DE 101 50 126 A1 a suction device is described in which a piezoelectric bending transducer generates a vacuum required for sucking an object by a holding head. However, the holding forces are very low, because the bending transducer can only produce a slight negative pressure.

Es

ist daher die Aufgabe der vorliegenden Erfindung, eine flexibel

einsetzbare Saugvorrichtung mit verhÃ¤ltnismÃ¤Ãig groÃen SaugkrÃ¤ften bereitzustellen. Ferner

soll eine mit einer derartigen Saugvorrichtung ausgestattete Haltevorrichtung

bereitgestellt werden.It

Therefore, the object of the present invention, a flexible

deployable suction device with relatively large suction forces. Further

to a equipped with such a suction device holding device

to be provided.

Zur

LÃ¶sung

der Aufgabe sieht die Erfindung bei einer Saugvorrichtung der eingangs

genannten Art vor, dass die Unterdruckerzeugungseinrichtung einen

elektrischen Lineardirektantrieb zur Erzeugung des Unterdrucks aufweist,

und dass ein LÃ¤ufer

des Lineardirektantriebs einen relativ zu dem mindestens einen Haltekopf

beweglichen Druckkolben zur Erzeugung des Unterdrucks bildet. Zur

LÃ¶sung

der Aufgabe ist ferner eine mit einer erfindungsgemÃ¤Ãen Saugvorrichtung

ausgestattete Handhabungsvorrichtung vorgesehen.to

solution

The object of the invention in a suction device of the beginning

mentioned type, that the negative pressure generating device a

electrical linear direct drive for generating the negative pressure,

and that a runner

of the linear direct drive relative to the at least one holding head

forms movable pressure piston for generating the negative pressure. to

solution

The object is also a with a suction device according to the invention

equipped handling device provided.

Die

erfindungsgemÃ¤Ãe Saugvorrichtung baut

kompakt. Zur elektrischen Stromversorgung oder Steuerung benÃ¶tigt sie

zwar elektrische Leitungen, die aber wesentlich flexibler sind als

beispielsweise DruckluftschlÃ¤uche.

Eine zentrale, separate Druckerzeugungsvorrichtung ist nicht erforderlich. Der

Lineardirektantrieb kann auf verhÃ¤ltnismÃ¤Ãig einfache Weise gesteuert

und/oder geregelt werden, sodass die DruckverhÃ¤ltnisse im Ansaugbereich des Haltekopfs

einfach beeinflussbar sind. Der Lineardirektantrieb stellt verhÃ¤ltnismÃ¤Ãig groÃe AntriebskrÃ¤fte bereit,

sodass groÃe

AnsaugkrÃ¤fte

mÃ¶glich

sind. Es kÃ¶nnen

dementsprechend verhÃ¤ltnismÃ¤Ãig schwere

GegenstÃ¤nde

angesaugt werden. GegenÃ¼ber

einem piezoelektrischen Antrieb sind die AntriebskrÃ¤fte eines

Lineardirektantriebes wesentlich grÃ¶Ãer. In AbhÃ¤ngigkeit der benÃ¶tigten DruckverhÃ¤ltnisse

bzw. Ansaugkraft kann der Verstellweg des LÃ¤ufers bzw. Druckkolbens entsprechend

lang ausgelegt sein.The

Suction device according to the invention builds

compact. It requires electrical power or control

Although electrical lines, but much more flexible than

For example, compressed air hoses.

A central, separate pressure generating device is not required. Of the

Linear direct drive can be controlled in a relatively simple manner

and / or regulated, so that the pressure conditions in the intake of the holding head

are easily influenced. The linear direct drive provides relatively high driving forces

so big

suction forces

possible

are. It can

accordingly relatively heavy

objects

be sucked. Across from

a piezoelectric drive are the driving forces of a

Linear direct drive much larger. Depending on the required pressure conditions

or suction, the adjustment of the rotor or pressure piston accordingly

be designed long.

Weitere

vorteilhafte Ausgestaltungen der Erfindung ergeben sich aus den

abhÃ¤ngigen

AnsprÃ¼chen

sowie aus der Beschreibung.Further

advantageous embodiments of the invention will become apparent from the

dependent

claims

as well as from the description.

Der

Haltekopf und die Unterdruckerzeugungseinrichtung sind zweckmÃ¤Ãigerweise

axial hintereinander angeordnet. Dies ermÃ¶glicht optimale StrÃ¶mungsverhÃ¤ltnisse.Of the

Holding head and the vacuum generating device are expediently

arranged axially one behind the other. This allows optimal flow conditions.

Der

Haltekopf begrenzt vorteilhafterweise eine Unterdruckkammer der

Unterdruckerzeugungseinrichtung, wenn er einen Gegenstand ansaugt.

Der LÃ¤ufer

bzw. Druckkolben dient zur VergrÃ¶Ãerung bzw.

Verkleinerung des Volumens der Unterdruckkammer, sodass die DruckverhÃ¤ltnisse

im Ansaugbereich des Haltekopfs durch Verstellen des LÃ¤ufers bzw.

Druckkolbens beeinflussbar sind.Of the

Holding head advantageously defines a vacuum chamber of the

Vacuum generating device, when it sucks an object.

The runner

or pressure piston is used to increase or

Reduction of the volume of the vacuum chamber, so the pressure conditions

in the intake of the holding head by adjusting the rotor or

Pressure piston can be influenced.

Die

Unterdruckerzeugungseinrichtung und der Haltekopf bilden zweckmÃ¤Ãigerweise

eine integrale Baueinheit. Beispielsweise ist die Unterdruckerzeugungseinrichtung

in einem GehÃ¤use

der Saugvorrichtung angeordnet, an dem der Haltekopf angebracht

ist. Der Haltekopf ist zweckmÃ¤Ãigerweise lÃ¶sbar an

der Saugvorrichtung bzw. an deren GehÃ¤use befestigt, beispielsweise

geschraubt, geklemmt oder dergleichen. Dadurch ist es z.B. mÃ¶glich, einen durch

Gebrauch verschlissenen Haltekopf auszuwechseln bzw. einen fÃ¼r die jeweiligen

VerhÃ¤ltnisse optimalen Haltekopf

an der Saugvorrichtung anzuordnen. Der Haltekopf besteht vorzugsweise

aus flexiblem Material, beispielsweise Kunststoff, Weichpolymer

oder dergleichen. Es versteht sich, dass auch VerstÃ¤rkungselemente

im Haltekopf enthalten sein kÃ¶nnen.The negative pressure generating device and the holding head expediently form an integral structural unit. For example, the Unterdru ckerzeugungseinrichtung arranged in a housing of the suction device on which the holding head is mounted. The holding head is suitably releasably attached to the suction device or to the housing, for example screwed, clamped or the like. This makes it possible, for example, to replace a wear-worn by use of holding head or to arrange an optimal for the respective conditions holding head on the suction device. The holding head is preferably made of flexible material, for example plastic, soft polymer or the like. It is understood that also reinforcing elements may be included in the holding head.

Der

LÃ¤ufer

des Lineardirektantriebes ist vorteilhafterweise in zwei zueinander

entgegengesetzten Richtungen antreibbar. In einer Richtung erzeugt er

Unterdruck im Bereich des Haltekopfs. In entgegengesetzter Bewegungsrichtung

sorgt er fÃ¼r

ausgeglichene DruckverhÃ¤ltnisse

im Ansaugbereich des Haltekopfs, sodass ein durch den Haltekopf

angesaugter Gegenstand freigegeben wird. Besonders bevorzugt ist

es aber, dass der LÃ¤ufer

bei dieser zweiten Bewegung Ãberdruck

im Ansaugbereich des Haltekopfs erzeugt, sodass ein angesaugter

Gegenstand vom Haltekopf abgestoÃen wird, sozusagen weg- oder

abgeblasen wird.Of the

runner

the linear direct drive is advantageously in two to each other

drivable opposite directions. It produces in one direction

Negative pressure in the area of the holding head. In opposite direction of movement

he takes care of

balanced pressure conditions

in the intake of the holding head, so that a through the holding head

sucked object is released. Particularly preferred

but that the runner

overpressure at this second movement

created in the intake of the holding head, so that sucked

Item is repelled by the holding head, so to speak away or

is blown off.

Vorzugsweise

ist ein Auslass an der Unterdruckerzeugungseinrichtung bzw. an der

Saugvorrichtung vorhanden, durch den Druckluft beim Erzeugen von

Unterdruck auf Seiten des Haltekopfs ausgestoÃen werden kann. Dieser Auslass

befindet sich zweckmÃ¤Ãigerweise

an der dem Haltekopf entgegengesetzten Seite der Saugvorrichtung.

Der LÃ¤ufer bzw.

der Druckkolben kann dementsprechend durch diesen Auslass Luft ausstoÃen, wenn

er den Unterdruck im Ansaugbereich des Haltekopfs erzeugt.Preferably

is an outlet at the vacuum generating device or at the

Suction device present, by the compressed air when generating

Vacuum can be ejected on the side of the holding head. This outlet

is conveniently located

on the holding head opposite side of the suction device.

The runner or

Accordingly, the pressure piston can expel air through this outlet when

he generates the negative pressure in the intake of the holding head.

Zwischen

einer Unterdruckkammer der Unterdruckerzeugungseinrichtung und dem

Ansaugbereich des Haltekopfs sind vorteilhafterweise einer oder

mehrere VerbindungskanÃ¤le

vorhanden. Besonders bevorzugt ist, wenn der Leitungsquerschnitt

des Verbindungskanals mÃ¶glichst

groÃ ist,

um StrÃ¶mungsverluste

mÃ¶glichst

gering zu halten. Die Unterdruckkammer kann prinzipiell den Ansaugbereich des

Haltekopfs sozusagen integral bilden.Between

a negative pressure chamber of the negative pressure generating device and the

Aspiration region of the holding head are advantageously one or

several connection channels

available. It is particularly preferred if the line cross section

the connection channel as possible

is great

for flow losses

preferably

to keep low. The vacuum chamber can in principle the suction of the

Form holding head so to speak integrally.

Der

LÃ¤ufer

des Lineardirektantriebs ist vorteilhafterweise durch einen Permanentmagneten

gebildet oder enthÃ¤lt

eine Permanentmagnetanordnung. Es versteht sich, dass prinzipiell

auch ein elektrisch erregter LÃ¤ufer

mÃ¶glich

ist. Der Lineardirektantrieb weist vorteilhafterweise eine Erreger-Spulenanordnung auf,

die entsprechend der Bewegungsrichtung des LÃ¤ufers aneinandergereihte Spulen

enthÃ¤lt. Durch

sequentielles Bestromen der Spulen wird der LÃ¤ufer in der gewÃ¼nschten

Bewegungsrichtung angetrieben, bei der er beispielsweise Unterdruck

im Ansaugbereich des Haltekopfs erzeugt.Of the

runner

The linear direct drive is advantageously by a permanent magnet

formed or contains

a permanent magnet arrangement. It is understood that, in principle

also an electrically excited runner

possible

is. The linear direct drive advantageously has a field coil arrangement,

the coils arranged adjacent to one another in accordance with the direction of movement of the runner

contains. By

sequentially energizing the coils will make the runner in the desired

Movement direction driven, in which he, for example, negative pressure

generated in the intake of the holding head.

Wie

bereits erlÃ¤utert,

sind bei dem elektrischen Lineardirektantriebsprinzip vielfÃ¤ltige SteuerungsmÃ¶glichkeiten

und RegelungsmÃ¶glichkeiten

gegeben. Dem Lineardirektantrieb ist daher zweckmÃ¤Ãigerweise

eine Steuereinrichtung zugeordnet. Die Steuereinrichtung bildet

vorteilhafterweise zumindest teilweise einen Bestandteil der erfindungsgemÃ¤Ãen Saugvorrichtung.

In der Steuereinrichtung zum Steuern des Lineardirektantriebes ist

vorteilhafterweise eine Regelungseinrich tung enthalten. Die Regelungseinrichtung

dient zweckmÃ¤Ãigerweise

zur Kraftregelung des Lineardirektantriebes, sodass auf diesem Wege

die DruckverhÃ¤ltnisse

im Ansaugbereich des Haltekopfes regelbar sind. Die Regelungseinrichtung

steuert den Lineardirektantrieb vorteilhafterweise zum Ausgleich

einer Leckage im Bereich des Haltekopfes an. Beispielsweise kÃ¶nnen zwischen dem

aufzunehmenden Gegenstand und dem Haltekopf Undichtigkeiten auftreten,

beispielsweise wenn eine KontaktoberflÃ¤che des Gegenstandes, an der der

Haltekopf angreift, rau, uneben oder dergleichen ist.As

already explained,

are in the electrical linear direct drive principle manifold control options

and control options

given. The linear direct drive is therefore expediently

associated with a control device. The control device forms

advantageously at least partially a component of the suction device according to the invention.

In the control device for controlling the linear direct drive is

advantageously contain a Regelseinrich device. The control device

is used appropriately

for force control of the linear direct drive, so in this way

the pressure conditions

are adjustable in the intake of the holding head. The control device

controls the linear direct drive advantageously to compensate

a leakage in the region of the holding head. For example, between the

object to be picked up and the holding head leaks occur

For example, if a contact surface of the object to which the

Holding head attacks, rough, uneven or the like.

Vorteilhafterweise

ist bei der Saugvorrichtung mindestens ein Drucksensor vorhanden,

der den Druck im Ansaugbereich des Haltekopfs erfassen und zweckmÃ¤Ãigerweise

der erfindungsgemÃ¤Ãen Steuereinrichtung

bzw. Regelungseinrichtung Druckmesswerte Ã¼bermitteln kann. Der Drucksensor kann

unmittelbar im Bereich des Haltekopfs, aber auch in einer Unterdruckkammer

der Unterdruckerzeugungseinrichtung angeordnet sein. Anhand der durch

den Drucksensor gemeldeten Druckmesswerte ist die Regelungseinrichtung

in der Lage, konstante oder im Wesentlichen konstante DruckverhÃ¤ltnisse im

Ansaugbereich des Haltekopfs durch entsprechende Ansteuerung des

Lineardirektantriebes herzustellen. Es versteht sich, dass alternativ

oder in ErgÃ¤nzung

zu einem Drucksensor auch Kraftsensoren, insbesondere im Bereich

des Haltekopfs, vorgesehen sein kÃ¶nnen. Mit derartigen Kraftsensoren

ist die entsprechende Ansaugkraft, mit der ein Gegenstand an den

Haltekopf angesaugt ist, erfassbar.advantageously,

at least one pressure sensor is present in the suction device,

which detect the pressure in the intake of the holding head and expediently

the control device according to the invention

or control device can transmit pressure readings. The pressure sensor can

directly in the area of the holding head, but also in a vacuum chamber

be arranged the vacuum generating device. On the basis of

the pressure sensor reported pressure sensor is the controller

capable of constant or substantially constant pressure conditions in the

Intake of the holding head by appropriate control of the

Linear direct drive produce. It is understood that alternatively

or in addition

to a pressure sensor and force sensors, especially in the field

of the holding head, can be provided. With such force sensors

is the corresponding suction force with which an object is attached to the

Holding head is sucked, detectable.

Anhand

der jeweiligen Kraftmesswerte ist der elektrische Lineardirektantrieb

steuerbar und/oder regelbar.Based

the respective force measurements is the electrical linear direct drive

controllable and / or controllable.

Die

erfindungsgemÃ¤Ãe Handhabungsvorrichtung,

die eine oder mehrere erfindungsgemÃ¤Ãe Saugvorrichtungen aufweist,

enthÃ¤lt

beispielsweise einen oder mehrere Linearantriebe und/oder einen oder

mehrere Rotationsantriebe, um die Saugvorrichtung(en) zu positionieren.

Die Positionierantriebe sind beispielsweise fluidtechnisch, insbesondere pneumatisch,

betrieben. Besonders bevorzugt ist jedoch eine ausschlieÃlich elektrische

Variante, bei der der oder die Positionierantriebe elektrisch betreibbar sind.

Die Saugvorrichtung(en) sind beispielsweise an dem oder den Abtriebsteilen

einer Positionier-Antriebseinheit

angeordnet.The handling device according to the invention, which comprises one or more suction devices according to the invention, contains, for example, one or more linear drives and / or one or more rotary drives in order to position the suction device (s). The positioning drives, for example, fluid technology, especially pneumatically operated. However, particularly preferred is an exclusively electrical variant in which the positioning drive or drives are electrically operable. The suction device (s) are arranged for example on the one or more driven parts of a positioning drive unit.

Nachfolgend

wird ein AusfÃ¼hrungsbeispiel der

Erfindung anhand der Zeichnung nÃ¤her

erlÃ¤utert. Es

zeigen:following

is an embodiment of

Invention with reference to the drawing

explained. It

demonstrate:

1 eine

erfindungsgemÃ¤Ãe Handhabungsvorrichtung

mit einer erfindungsgemÃ¤Ãen Saugvorrichtung

in schematischer, teilweise geschnittener Darstellung, 1 a handling device according to the invention with a suction device according to the invention in a schematic, partially sectioned illustration,

2 die

Handhabungsvorrichtung gemÃ¤Ã 1 in

einer schematischen perspektivischen Ansicht, und 2 the handling device according to 1 in a schematic perspective view, and

3 eine

Querschnittsansicht der Saugvorrichtung gemÃ¤Ã 1 und 2. 3 a cross-sectional view of the suction device according to 1 and 2 ,

Eine

in den 1 und 2 gezeigte Handhabungsvorrichtung 10 weist

eine Positionier-Antriebseinheit 11 auf, an deren Abtriebsteil 12 eine Saugvorrichtung 13 angeordnet

ist. Die Antriebseinheit 11 ist ein Linearantrieb. Die

Antriebseinheit 11 ist im vorliegenden Fall fluidtechnisch,

beispielsweise pneumatisch, betreibbar, wobei alternativ eine elektrische

Bauform mÃ¶glich

ist. Das Abtriebsteil 12 ist z.B. eine Kolbenstange, die

aus einem GehÃ¤use 14 der

Antriebseinheit 11 bei entsprechender Druckluftbeaufschlagung

bzw. EntlÃ¼ftung

aus dem GehÃ¤use 14 ausfÃ¤hrt bzw.

in dieses einfÃ¤hrt.

Das Abtriebsteil 12 ist an einem Kolben 15 angeordnet,

der in dem GehÃ¤use 14 in

einer LÃ¤ngsrichtung 16 hin

und her beweglich ist. Der Kolben 15 unterteilt eine Kammer 17 im

GehÃ¤use 14 in

Arbeitskammern 18, 19, die mittels einer Steuerventilanordnung 20 mit

Druck beaufschlagbar bzw. entlÃ¼ftbar

sind. Die Steuerventilanordnung 20, beispielsweise ein

4/2-Wegeventil, ist mit einer Druckluftquelle 21 sowie Ã¼ber Leitungen 22, 23 mit

den Arbeitskammern 18, 19 verbunden. Wenn die

Steuerventilanordnung 20 die Arbeitskammer 18 mit

Druckluft beaufschlagt und die Arbeitskammer 19 entlÃ¼ftet, fÃ¤hrt das

Abtriebsteil 12 in das GehÃ¤use 14 ein, bei Druckluftbeaufschlagung

der Arbeitskammer 19 und EntlÃ¼ftung der Arbeitskammer 18 aus

dem GehÃ¤use 14 aus.

Die am freien Ende des Abtriebsteils 12 befestigte Saugvorrichtung 13 fÃ¼hrt eine

entsprechende LÃ¤ngsbewegung

in LÃ¤ngsrichtung 16 durch.One in the 1 and 2 shown handling device 10 has a positioning drive unit 11 on, at the output part 12 a suction device 13 is arranged. The drive unit 11 is a linear drive. The drive unit 11 is in the present case fluid technology, for example, pneumatically operated, with an alternative electrical design is possible. The output part 12 Eg is a piston rod, which consists of a housing 14 the drive unit 11 with appropriate compressed air or venting from the housing 14 extends or retracts into this. The output part 12 is on a piston 15 arranged in the housing 14 in a longitudinal direction 16 is movable back and forth. The piston 15 divided a chamber 17 in the case 14 in working chambers 18 . 19 , which by means of a control valve assembly 20 can be acted upon with pressure or vented. The control valve assembly 20 For example, a 4/2-way valve is with a compressed air source 21 as well as via lines 22 . 23 with the working chambers 18 . 19 connected. When the control valve assembly 20 the working chamber 18 subjected to compressed air and the working chamber 19 vented, drives the driven part 12 in the case 14 on, with compressed air to the working chamber 19 and venting the working chamber 18 out of the case 14 out. The at the free end of the stripping section 12 attached suction device 13 performs a corresponding longitudinal movement in the longitudinal direction 16 by.

Die

Saugvorrichtung 13 dient zum Anheben bzw. Ablegen von GegenstÃ¤nden, zum

Beispiel eines plattenartigen Gegenstandes 24. Die Saugvorrichtung 13,

die man auch als Vakuumsauger bezeichnen kann, enthÃ¤lt eine

Unterdruckerzeugungseinrichtung 25 mit einem elektrischen

Lineardirektantrieb 26 zur Erzeugung von Unterdruck in

einem Ansaugbereich 27 eines Haltekopfes 28.The suction device 13 serves for lifting or depositing objects, for example a plate-like object 24 , The suction device 13 , which can also be referred to as a vacuum suction, contains a vacuum generating device 25 with an electric linear direct drive 26 for generating negative pressure in a suction area 27 a holding head 28 ,

Der

Haltekopf 28, der vorzugsweise aus flexiblem, insbesondere

elastischem Material, zum Beispiel Kunststoff, Gummi oder dergleichen,

besteht, ist an der Unterseite eines GehÃ¤uses 29 der Saugvorrichtung 13 angeordnet,

beispielsweise angeschraubt, angeklebt, angeklemmt oder dergleichen. Im

GehÃ¤use 29 ist

eine Unterdruckkammer oder Arbeitskammer 30 ausgebildet.

Die Unterdruckkammer 30 wird oben von einem als Arbeitskolben

oder Druckkolben 31 ausgestalteten, entlang der Achse 36 beweglichen

LÃ¤ufer 32 des

Lineardirektantriebs 26, seitlich von dem GehÃ¤use 29 und

unterseitig durch den Haltekopf 28 begrenzt. Die Unterdruckkammer 30 ist Ã¼ber einen

Verbindungskanal 33 fluidtechnisch mit dem Ansaugbereich 27 verbunden.

Der Verbindungskanal 33 ist an der Oberseite des Haltekopfs 28 ausgebildet.

Ferner befindet sich am AuÃenumfang

des Druckkolbens 31 eine Dichtung 40, die an einer

Innenwand 41 des GehÃ¤uses 29 anliegt.The holding head 28 , which preferably consists of flexible, in particular elastic material, for example plastic, rubber or the like, is at the bottom of a housing 29 the suction device 13 arranged, for example screwed, glued, clamped or the like. In the case 29 is a vacuum chamber or working chamber 30 educated. The vacuum chamber 30 gets up from one as a working piston or plunger 31 designed, along the axis 36 movable runner 32 of the linear direct drive 26 , to the side of the housing 29 and underside by the holding head 28 limited. The vacuum chamber 30 is via a connection channel 33 Fluidtechnisch with the intake 27 connected. The connection channel 33 is at the top of the holding head 28 educated. Further, located on the outer periphery of the pressure piston 31 a seal 40 on an interior wall 41 of the housing 29 is applied.

Der

Haltekopf 28 weist eine an das GehÃ¤use 29 z.B. angeschraubte

oder angeklebte Montageplatte 34, beispielsweise aus Metall

oder hartem Kunststoff, sowie einen flexiblen FuÃ oder Schuh 35 auf, der

in Gebrauchsstellung auf dem Gegens tand 24 aufliegt und

mit diesem eine im Wesentlichen druckdichte Verbindung bildet.The holding head 28 has one to the housing 29 eg bolted or glued mounting plate 34 For example, made of metal or hard plastic, as well as a flexible foot or shoe 35 on, who stood in the position of use on the counter 24 rests and forms a substantially pressure-tight connection with this.

Die

Unterdruckerzeugungseinrichtung 25 und der Haltekopf 28 sind

beim AusfÃ¼hrungsbeispiel in

axialer Richtung hintereinander entlang der Bewegungs-Achse 36 des

Druckkolbens 31 angeordnet.The negative pressure generating device 25 and the holding head 28 are in the embodiment in the axial direction one behind the other along the movement axis 36 of the pressure piston 31 arranged.

Beim

AusfÃ¼hrungsbeispiel

weist die Saugvorrichtung 13 eine um die Achse 36 im

Wesentlichen rotationssymmetrische, beispielsweise zylindrische

Gestalt auf, wobei ohne weiteres auch andere geometrische Ausgestaltungen

mÃ¶glich

sind.In the embodiment, the suction device 13 one around the axis 36 substantially rotationally symmetrical, for example, cylindrical shape, with other geometric configurations are readily possible.

Der

LÃ¤ufer 32 ist

beim AusfÃ¼hrungsbeispiel als

Permanentmagnet ausgestaltet bzw. weist eine Permanentmagnetanordnung

auf, wobei beispielsweise der magnetische Nordpol N und der magnetische

SÃ¼dpol

S des LÃ¤ufers 32 entsprechend

der Achse 36 orientiert sind. Es versteht sich, dass auch

andere Polungen prinzipiell mÃ¶glich

sind. Mittels einer Erregermagnetanordnung 37 des Lineardirektantriebes 26 ist

der LÃ¤ufer 31 in

Richtung der Achse 36 hin und her bzw. auf und ab bewegbar.

Die Erregermagnetanordnung 37 ist beispielsweise in das

GehÃ¤use 29 integriert,

beispielsweise zwischen Wandungen des GehÃ¤uses 29 angeordnet.The runner 32 is configured in the embodiment as a permanent magnet or has a permanent magnet arrangement, wherein, for example, the magnetic north pole N and the magnetic south pole S of the rotor 32 according to the axis 36 are oriented. It is understood that other polarities are possible in principle. By means of an excitation magnet arrangement 37 of the linear direct drive 26 is the runner 31 in the direction of the axis 36 movable back and forth or up and down. The exciter magnet arrangement 37 is for example in the housing 29 integrated, for example between walls of the housing 29 arranged.

Die

Erregermagnetanordnung 37 enthÃ¤lt mehrere, in Richtung der

Achse 36 aneinander gereihte elektrische Spulen 38.

Eine Bestromungseinrichtung 39 bestromt die Spulen 38 derart,

dass ein magnetisches Wanderfeld entsteht. Durch dieses magnetische

Wanderfeld wird der LÃ¤ufer 32 in

Achsrichtung 36 hin und her bzw. auf und ab bewegt.The exciter magnet arrangement 37 contains several, in the direction of the axis 36 juxtaposed electric coils 38 , An energizing device 39 energizes the coils 38 such that one magnetic traveling field arises. This magnetic traveling field turns the runner 32 in the axial direction 36 moved back and forth or up and down.

Bei

einer Bewegung des Arbeits- bzw. Druckkolbens 31 von dem

Haltekopf 28 weg wird das Volumen der Unterdruckkammer 30 vergrÃ¶Ãert. Wenn

der Haltekopf 28 dabei auf dem Gegenstand 24 aufliegt, bildet

sich eine im Wesentlichen druckdichte Verbindung zwischen dem Gegenstand 24 und

dem flexiblen Schuh 35 des Haltekopfes 28 aus.

Dementsprechend ist die Unterdruckkammer 30 im Wesentlichen druckdicht

geschlossen, wenn der Haltekopf 28 auf dem Gegenstand 24 aufsitzt.

Wenn sich dann der Druckkolben 31 bzw. LÃ¤ufer 32 nach

oben bewegt und das Volumen der Unterdruckkammer 30 vergrÃ¶Ãert wird,

bildet sich ein Unterdruck im Bereich der Unterdruckkammer 30 und

somit auch im Ansaugbereich 27 aus. Der Gegenstand 24 wird

dann angesaugt. Bei entsprechend umgekehrter Bestromung der Erregermagnetanordnung 27 bewegt

sich der LÃ¤ufer 32 nach

unten, wobei das Volumen in der Unterdruckkammer 30 wieder

verkleinert wird. Der Unterdruck in der Unterdruckkammer 30 und

dem Ansaugbereich 27 nimmt ab, bis schlieÃlich ausgeglichene

DruckverhÃ¤ltnisse

eintreten, bei denen der Gegenstand 24 vom Haltekopf 28 bzw.

der Saugvorrichtung 13 freigegeben wird. Besonders bevorzugt ist

es, dass der LÃ¤ufer 32 mit

verhÃ¤ltnismÃ¤Ãig groÃer Geschwindigkeit

in Richtung des Haltekopfs 28 bewegt wird, sodass der Gegenstand 24 von

der Saugvorrichtung 13 sozusagen abgestoÃen oder

weggestoÃen

wird.During a movement of the working or pressure piston 31 from the holding head 28 away is the volume of the vacuum chamber 30 increased. When the holding head 28 while on the object 24 rests, forms a substantially pressure-tight connection between the object 24 and the flexible shoe 35 of the holding head 28 out. Accordingly, the vacuum chamber 30 essentially closed pressure-tight when the holding head 28 on the object 24 seated. If then the pressure piston 31 or runner 32 moved up and the volume of the vacuum chamber 30 is increased, forms a negative pressure in the region of the vacuum chamber 30 and therefore also in the intake area 27 out. The object 24 is then sucked. In accordance with the reverse energization of the exciter magnet arrangement 27 the runner moves 32 down, with the volume in the vacuum chamber 30 is reduced again. The negative pressure in the vacuum chamber 30 and the intake area 27 decreases until finally balanced pressure conditions occur, in which the object 24 from the holding head 28 or the suction device 13 is released. It is particularly preferred that the runner 32 at a relatively high speed in the direction of the holding head 28 is moved, so the object 24 from the suction device 13 is repelled or pushed away, so to speak.

Bei

seiner Bewegung vom Haltekopf 28 weg, in der Zeichnung

nach oben, verdrÃ¤ngt

der Druckkolben 31 Luft 42 aus einer AbstrÃ¶mkammer 43 des

GehÃ¤uses 29 heraus.

Die AbstrÃ¶mkammer 43 an

der dem Haltekopf 28 abgewandten Seite des GehÃ¤uses 29 weist

eine Ãffnung 44 auf,

die als Auslass zum AbstrÃ¶men

von Luft 42 aus der AbstrÃ¶mkammer 43 dient.In his movement from the holding head 28 away, in the drawing up, displaces the plunger 31 air 42 from an outflow chamber 43 of the housing 29 out. The outflow chamber 43 at the holding head 28 opposite side of the housing 29 has an opening 44 on, as an outlet for the outflow of air 42 from the outflow chamber 43 serves.

Wenn

der Druckkolben 31 zum Haltekopf 28 hin bewegt

wird, kann Luft 42 durch die Ãffnung 44 in die AbstrÃ¶mkammer 43 hineinstrÃ¶men. Durch

die Ãffnung 44 ist

eine verhÃ¤ltnismÃ¤Ãig freie

Beweglichkeit des Druckkolbens 31 bzw. LÃ¤ufers 32 gegeben.When the pressure piston 31 to the holding head 28 is moved, can air 42 through the opening 44 in the outflow chamber 43 hineinstrÃ¶men. Through the opening 44 is a relatively free mobility of the pressure piston 31 or runner 32 given.

Es

versteht sich, dass auch Varianten von erfindungsgemÃ¤Ãen Saugvorrichtungen

mÃ¶glich

sind, bei denen eine geschlossene Kammer an der Stelle der AbstrÃ¶mkammer 43 vorhanden

ist, die dann eine Art Luftpuffer bildet. Der Druckkolben komprimiert

in einem solchen Fall die in der geschlossenen Kammer befindliche

Luft, sodass die Bewegung in Richtung vom Haltekopf weg gebremst

wird.It is understood that variants of suction devices according to the invention are possible in which a closed chamber at the location of the outflow chamber 43 is present, which then forms a kind of air buffer. The plunger compresses the air in the closed chamber in such a case, so that the movement is braked in the direction away from the holding head.

Eine

zentrale Steuerung 45 steuert die Positionier-Antriebseinheit 11 und

die Saugvorrichtung 13. Die Steuerungsvorrichtung 45 sendet

beispielsweise Ã¼ber

Leitungen 46, 47 Steuerbefehle an einen Antrieb 48 der

Steuerventilanordnung 20 und an eine lokale Steuereinrichtung 50 zur

Steuerung der Saugvorrichtung 13.A central control 45 controls the positioning drive unit 11 and the suction device 13 , The control device 45 sends for example via lines 46 . 47 Control commands to a drive 48 the control valve assembly 20 and to a local controller 50 for controlling the suction device 13 ,

Die

lokale Steuereinrichtung 50 ist vorzugsweise in die Baueinheit

der Saugvorrichtung 13 integriert. Es sind auch Bauformen

mÃ¶glich,

bei denen die Steuereinrichtung 50 eine von der Saugvorrichtung 13 abgesetzte

Baueinheit bildet, wie beispielsweise in 2 dargestellt.

Ferner ist es mÃ¶glich, dass

die Funktionen der Steuereinrichtung 50 beispielsweise

von einer zentralen Steuerungsvorrichtung in der Art der Steuerungsvorrichtung 45 Ã¼bernommen

werden.The local controller 50 is preferably in the assembly of the suction device 13 integrated. There are also designs possible in which the control device 50 one from the suction device 13 forms remote unit, such as in 2 shown. Furthermore, it is possible that the functions of the control device 50 for example, from a central control device in the nature of the control device 45 be taken over.

Eine

Regelungseinrichtung 51 dient zur Positions- und Kraftregelung

des LÃ¤ufers 32 bzw. Druckkolbens 31.

Die Regelungseinrichtung 51 kooperiert mit der Bestromungseinrichtung 39,

die beispielsweise einen elektronischen Kommutator, einen Stromrichter

oder dergleichen enthÃ¤lt.

Die Regelungseinrichtung 51 erhÃ¤lt von der Bestromungseinrichtung 39 Positionssignale,

die z.B. jeweilige Position des LÃ¤ufers 31 relativ zum

Haltekopf 28 signalisieren. Ferner erhÃ¤lt die Regelungseinrichtung 51 von

einem Drucksensor 52 Druck-Messsignale 53, die

die Drucksituation im Bereich der Unterdruckkammer 30 bzw.

des Ansaugbereichs 27 charakterisieren. Der Drucksensor 52 ist

beispielsweise im Bereich des Verbindungskanals 53 angeordnet.

Der Drucksensor 52 meldet die Druck-Messsignale 53 Ã¼ber eine

Leitung 54 an die Steuereinrichtung 50.A control device 51 serves to position and force control of the rotor 32 or pressure piston 31 , The control device 51 cooperates with the lighting device 39 which includes, for example, an electronic commutator, a power converter or the like. The control device 51 receives from the lighting device 39 Position signals, eg the respective position of the rotor 31 relative to the holding head 28 signal. Furthermore, the control device receives 51 from a pressure sensor 52 Pressure measurement signals 53 that the pressure situation in the area of the vacuum chamber 30 or the intake area 27 characterize. The pressure sensor 52 is for example in the area of the connection channel 53 arranged. The pressure sensor 52 reports the pressure measurement signals 53 over a line 54 to the controller 50 ,

Eine

andere Position des Drucksensors 52 ist jederzeit mÃ¶glich, beispielsweise

im Bereich der Innenwand 41. Es ist gegebenenfalls eine

versenkte Bauweise des Drucksensors 52 er forderlich, um

ihn vor BeschÃ¤digung

durch den LÃ¤ufer 32 oder

den anzusaugenden Gegenstand 24 zu schÃ¼tzen.Another position of the pressure sensor 52 is possible at any time, for example in the area of the inner wall 41 , It is possibly a recessed construction of the pressure sensor 52 He required him to be damaged by the runner 32 or the object to be sucked on 24 to protect.

Die

Regelungseinrichtung 51 empfÃ¤ngt beispielsweise Ã¼ber eine

Schnittstelle 55 einen Steuerbefehl 56 zum Ansaugen

des Gegenstandes 24. In dem Steuerbefehl 56 ist

eine gewÃ¼nschte

Ansaugkraft angegeben. Die Regelungseinrichtung 51 steuert

dann den Lineardirektantrieb 26 zur Einstellung der gewÃ¼nschten

Ansaugkraft an, das heiÃt,

sie gibt der Bestromungseinrichtung 39 Steuerbefehle zur Bestromung

der Erregermagnetanordnung 37 derart, dass der LÃ¤ufer 32 vom

Haltekopf 28 weg, also nach oben, bewegt wird. Wenn der

Drucksensor 52 signalisiert, dass ein zu der vorgegebenen

Ansaugkraft korrelierender Ansaug-Unterdruck erreicht ist, gibt die

Regelungseinrichtung 51 der Bestromungseinrichtung 39 vor,

den LÃ¤ufer 32 in

der dann erreichten LÃ¤ngsposition

relativ zum Haltekopf 28 anzuhalten.The control device 51 receives, for example via an interface 55 a control command 56 for sucking the object 24 , In the control command 56 is a desired suction indicated. The control device 51 then controls the linear direct drive 26 to set the desired suction, that is, it gives the energizing device 39 Control commands for energizing the excitation magnet arrangement 37 such that the runner 32 from the holding head 28 away, so up, is moved. When the pressure sensor 52 indicates that an intake negative pressure correlating with the predetermined intake force has been reached is given by the control device 51 the energizing device 39 before, the runner 32 in the then reached longitudinal position relative to the holding head 28 to stop.

Nun

kann es aber vorkommen, dass beispielsweise durch Undichtigkeiten

im Bereich des flexiblen Schuhs 39, beispielsweise am Ãbergangsbereich

zum Gegenstand 24, Luft in den Ansaugbereich 27 einstrÃ¶mt. Der

Unterdruck im Bereich der Unterdruckkammer 30 bzw. dem

Ansaugbereich 27 nimmt dann ab, sodass der Gegenstand 24 an

sich nicht mehr mit der gewÃ¼nschten

Ansaugkraft von der Saugvorrichtung 13 gehalten werden

kann. Der Drucksensor 52 meldet den abnehmenden Unterdruck

an die Regelungseinrichtung 51, die infolgedessen die Bestromungseinrichtung 39 zu

einer weiteren Verlagerung des LÃ¤ufers 32 vom Haltekopf 28 weg,

nach oben, ansteuert, bis der gewÃ¼nschte Ansaug-Unterdruck bzw.

die gewÃ¼nschte

Ansaugkraft wieder erreicht ist. Auf diese Weise regelt die Regelungseinrichtung 51 den

Lineardirektantrieb 26 derart, dass ein im Wesentlichen

konstanter Ansaug-Unterdruck bzw. eine im Wesentlichen konstante

Ansaugkraft beim Ansaugen des Gegenstands 24 vorhanden

ist. Es versteht sich, dass die Nachregelung durch die Regelungseinrichtung 51 durch

den als oberer Anschlag fÃ¼r

den LÃ¤ufer 32 dienenden

oberen GehÃ¤usedeckel 58 des

GehÃ¤uses 29 begrenzt

ist.Now it can happen that at For example, by leaks in the field of flexible shoe 39 , For example, at the transition area to the object 24 , Air in the intake area 27 flows. The negative pressure in the area of the vacuum chamber 30 or the intake area 27 then take off, so the object 24 in itself no longer with the desired suction of the suction device 13 can be held. The pressure sensor 52 reports the decreasing negative pressure to the control device 51 , as a result, the energizing device 39 to a further shift of the runner 32 from the holding head 28 away, upwards, controls until the desired suction negative pressure or the desired suction force is reached again. In this way, regulates the control device 51 the linear direct drive 26 such that a substantially constant suction negative pressure or a substantially constant suction force when sucking the object 24 is available. It is understood that the readjustment by the control device 51 by the upper stop for the runner 32 serving upper housing cover 58 of the housing 29 is limited.

Die

erfindungsgemÃ¤Ãe Saugvorrichtung kann,

wie bereits erlÃ¤utert,

sehr kompakt bauen. Die von der Saugvorrichtung bereitgestellte

Ansaugkraft hÃ¤ngt

unter anderem von der FlÃ¤che

des Druckkolbens 31 ab und betrÃ¤gt beispielsweise bei einer

FlÃ¤che

von ca. 78 mm2 und bei einem Unterdruck

von 0,20 bar im VerhÃ¤ltnis

zur Umgebung 1,57 N. Bei einem kreisrunden Druckkolben 31 wÃ¤re dessen Durchmesser

dann 10 mm. VergrÃ¶Ãert man

den Kolbendurchmesser des Druckkolbens 31 bzw. dessen FlÃ¤che auf

16 mm bzw. 201 mm2, ist bei gleichem Unterdruck

von 0,2 bar eine Ansaugkraft von ungefÃ¤hr 4 N mÃ¶glich. Wenn man den Unterdruck

weiter vergrÃ¶Ãert, beispielsweise

auf 0,9 bar, betrÃ¤gt

die Ansaugkraft etwa 18 N.The suction device according to the invention can, as already explained, build very compact. The suction force provided by the suction device depends inter alia on the surface of the pressure piston 31 For example, at an area of about 78 mm 2 and at a negative pressure of 0.20 bar in relation to the environment, it is 1.57 N. For a circular pressure piston 31 its diameter would then be 10 mm. If you increase the piston diameter of the pressure piston 31 or its area to 16 mm or 201 mm 2 , a suction force of about 4 N is possible at the same negative pressure of 0.2 bar. If you continue to increase the negative pressure, for example, to 0.9 bar, the suction force is about 18 N.

Es

versteht sich, dass Abwandlungen der Erfindung ohne weiteres mÃ¶glich sind.

Beispielsweise kÃ¶nnen

mehrere VentilkanÃ¤le

zwischen der Unterdruckkammer 30 und dem Ansaugbereich 27 vorgesehen

sein. Die ElastizitÃ¤t

des Haltekopfs 28, dessen geometrische Form oder dergleichen

kÃ¶nnen

an die jeweils aufzunehmenden GegenstÃ¤nde optimal angepasst sein.It is understood that modifications of the invention are readily possible. For example, a plurality of valve channels between the vacuum chamber 30 and the intake area 27 be provided. The elasticity of the holding head 28 whose geometric shape or the like can be optimally adapted to the respective objects to be picked up.

Eine

erfindungsgemÃ¤Ãe Saugvorrichtung kann

auch mehrere HaltekÃ¶pfe

aufweisen, die mit der jeweiligen durch den erfindungsgemÃ¤Ãen Lineardirektantrieb

volumenverÃ¤nderlichen

Unterdruckkammer durch entsprechende VerbindungskanÃ¤le fluidtechnisch

verbunden sind.A

suction device according to the invention can

also several holding heads

having, with the respective by the linear direct drive according to the invention

variable volume

Low-pressure chamber by appropriate connection channels fluid technology

are connected.

## Classifications

- B65G47/91
- B25J15/06
- B65G47/91
- B65G47/917
- B66C1/02

## Cited patent documents

- [DD-227196-A1](https://patents.google.com/patent/DD227196A1/en) — SEA
- [DE-10150126-A1](https://patents.google.com/patent/DE10150126A1/en) — SEA
- [DE-2549514-B2](https://patents.google.com/patent/DE2549514B2/en) — SEA
- [US-5609377-A](https://patents.google.com/patent/US5609377A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
