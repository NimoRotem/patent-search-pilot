# 23. Suction grip for lifting and holding workpieces - has housing to which is connected a suction bowl, inner chamber of which is connected to suction air channel in housing

- **Archive rank:** 23 of 50
- **Publication:** [DE-4215713-C1](https://patents.google.com/patent/DE4215713C1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/006458729/publication/DE4215713C1?q=pn%3DDE4215713C1)
- **Publication date:** 1993-06-17
- **Filing date:** 1992-05-13
- **Earliest priority:** 1992-05-13
- **Family:** 6458729
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Abstract

The suction air channel is connected to a vacuum-producing source. In the suction air channel (2) a tappet (3) is arranged which in the presence of a vacuum in the suction channel is adjustable from a rest position into a work position in which the tappet (3) operates a valve or an approximation switch. The tappet is a component of a piston (5) which is displaceable in a housing bore (6, 7) crosswise to the suction air channel (2), whereby the face side of the piston turned away from the tappet is connected to the atmosphere via housing apertures (8). USE/ADVANTAGE - A suction grip for lifting and retaining flat piece goods, in the suction air channel of which is a tappet which operates a positioning component.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-4215713-C1/ops000.png)

![Sketch 1 for DE-4215713-C1](https://nimo.iptorch.com/refdrawing/DE-4215713-C1/ops000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-4215713-C1/ops001.png)

![Sketch 2 for DE-4215713-C1](https://nimo.iptorch.com/refdrawing/DE-4215713-C1/ops001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/DE-4215713-C1/ops002.png)

![Sketch 3 for DE-4215713-C1](https://nimo.iptorch.com/refdrawing/DE-4215713-C1/ops002.png)

## Claims

### Claim 1 (independent)

Sauggreifvorrichtung zum Anheben und Halten von Werkstücken, z. B. flächigen Stückgütern, mit einem Gehäuse, an dem ein Saugnapf befestigbar ist, dessen lnnenraum an einen im Gehäuse ausgebildeten Saugluftkanal angeschlossen ist, der mit einer Unterdruck erzeugenden Einrichtung verbunden ist, dadurch gekennzeichnet, daß im Saugluftkanal (2) ein Stößel (3) angeordnet ist, der bei in der Saugleitung anstehendem Unterdruck aus einer Ruhelage in eine Arbeitsposition verstellt ist, in welcher der Stößel (3) ein Stellglied, z. B. ein Ventil oder einen Näherungsschalter, betätigt.1. Suction gripping device for lifting and holding workpieces, eg. B. flat piece goods, with a housing to which a suction cup can be attached, the interior of which is connected to a suction air duct formed in the housing, which is connected to a vacuum-generating device, characterized in that in the suction air duct ( 2 ) a plunger ( 3 ) is arranged, which is adjusted in a vacuum in the suction line from a rest position to a working position in which the plunger ( 3 ) is an actuator, for. B. actuated a valve or a proximity switch.

### Claim 2

Sauggreifvorrichtung nach Anspruch 1, dadurch gekennzeichnet, daß der Stößel (3) Bestandteil eines Kolbens (5) ist, der in einer quer zum Saugluftkanal (2) gerichteten Gehäusebohrung (6, 7) verschieblich ist, wobei die dem Stößel (3) abgewandte Stirnfläche des Kolbens (5) über Gehäuseöffnungen (8) mit der Außenatmosphäre in Verbindung steht und die Stirnfläche, von der der Stößel (3) abragt, mit dem Saugluftkanal (2) in Verbindung steht, wobei der Stößel (3) mit seinem freien Ende in einer Gehäusebohrung (7) geführt ist, in welche Gehäusebohrung (7) das vom Stößel (3) betätigbare Stellglied eingesetzt ist oder an welche Gehäuse­ bohrung (7) das Stellglied angesetzt ist, wobei der Kolben (5) und/oder der Stößel (3) mittels einer Feder (10) in die Ruhelage gedrängt ist und in der Arbeitslage entgegen der Kraft der Feder (10) verstellt ist.2. Suction gripping device according to claim 1, characterized in that the plunger ( 3 ) is part of a piston ( 5 ) which is displaceable in a housing bore ( 6 , 7 ) directed transversely to the suction air duct ( 2 ), the plunger ( 3 ) End face of the piston ( 5 ) facing away from the housing atmosphere ( 8 ) communicates with the outside atmosphere and the end face from which the plunger ( 3 ) protrudes communicates with the suction air duct ( 2 ), the plunger ( 3 ) having its free end end is guided in a housing bore (7), in which housing bore actuatable by the plunger (3) actuator is used (7) or to which the housing bore (7) the actuator is attached, the piston (5) and / or of the plunger ( 3 ) is pushed into the rest position by means of a spring ( 10 ) and is adjusted in the working position against the force of the spring ( 10 ).

### Claim 3

Sauggreifvorrichtung nach Anspruch 1 oder 2, dadurch gekennzeichnet, daß die den Stößel (3) samt Kolben (5) aufnehmende Gehäusekammer (6, 7) quer zum Verlauf des Saugluftkanales (2) verläuft und die Ein- oder Ansatzöffnung (9) für das Stellglied an einer Gehäuseseitenfläche (11) frei zugänglich ausgebildet ist, während die Einsatzöffnung der Gehäusekammer (7) für den Stößel (3) samt Kolben (5) auf der dieser gegenüberliegenden Gehäuseseitenfläche (12) frei zugänglich ist und mittels einer Durchgangs­ lochungen (8) aufweisenden Verschlußplatte (13) verschlossen ist.3. Suction gripping device according to claim 1 or 2, characterized in that the plunger ( 3 ) together with the piston ( 5 ) receiving the housing chamber ( 6 , 7 ) extends transversely to the course of the suction air duct ( 2 ) and the inlet or attachment opening ( 9 ) for the actuator is freely accessible on a housing side surface ( 11 ), while the insert opening of the housing chamber ( 7 ) for the plunger ( 3 ) together with the piston ( 5 ) is freely accessible on the housing side surface ( 12 ) opposite this and by means of through holes ( 8 ) has closure plate ( 13 ) is closed.

### Claim 4

Sauggreifvorrichtung nach einem der Ansprüche 1 bis 3, dadurch gekennzeichnet, daß der Kolben (5) mittels einer Gleitdichtung gegenüber der zylindrischen Kammerwandung abgedichtet ist.4. suction gripping device according to one of claims 1 to 3, characterized in that the piston ( 5 ) is sealed by means of a sliding seal against the cylindrical chamber wall.

### Claim 5

Sauggreifvorrichtung nach einem der Ansprüche 1 bis 4, dadurch gekennzeichnet, daß der Kolben (5) gegenüber der Einsatzöffnung durch eine an der Kammerwandung dicht eingespannte Dichtfolie (15) abgedichtet ist, die an der Kolbenstirnfläche anliegt.5. Suction gripping device according to one of claims 1 to 4, characterized in that the piston ( 5 ) is sealed off from the insert opening by a sealing film ( 15 ) which is tightly clamped to the chamber wall and abuts the piston end face.

### Claim 6

Sauggreifvorrichtung nach Anspruch 5, dadurch gekennzeichnet, daß die Kolbenstirnfläche durch eine Bohrung (16, 17) mit der Gehäusekammer (6) und somit mit dem Saugluftkanal (2) in Verbindung steht, welche Bohrung (16, 17) mittig den Kolben (5) durchsetzt und aus dem Stößel (3) radial austritt. suction gripping device according to claim 5, characterized in that the piston end face through a bore ( 16 , 17 ) with the housing chamber ( 6 ) and thus with the suction air duct ( 2 ) is connected, which bore ( 16 , 17 ) in the center of the piston ( 5 ) passes through and radially emerges from the tappet ( 3 ).

### Claim 7

Sauggreifvorrichtung nach Anspruch 6, dadurch gekennzeichnet, daß die Kolbenstirnfläche mittig eine flache Vertiefung (18) aufweist, an die bei anstehender Saugluft die Dichtfolie (15) angelegt ist.7. suction gripping device according to claim 6, characterized in that the piston end face has a shallow recess ( 18 ) in the center, to which the sealing film ( 15 ) is applied when suction air is present.

### Claim 8

Sauggreifvorrichtung nach einem der Ansprüche 1 bis 7, dadurch gekennzeichnet, daß die Feder (10) durch eine koaxial den Stößel (3) umgebende Schraubenfeder gebildet ist, die sich mit ihrem einen Ende an der Unterseite des Kolbens (5) und mit ihrem anderen Ende an einer Gehäuseschulter (19) oder einer sich gehäusefest abstützenden Stützplatte (20) abstützt, die vom Stößel (3) mit Spiel durchgriffen ist.8. suction gripping device according to one of claims 1 to 7, characterized in that the spring ( 10 ) is formed by a coaxial the plunger ( 3 ) surrounding coil spring, which is at one end on the underside of the piston ( 5 ) and with it supports the other end on a housing shoulder ( 19 ) or a support plate ( 20 ) which is fixed to the housing and which is penetrated by the plunger ( 3 ) with play.

### Claim 9

Sauggreifvorrichtung nach Anspruch 8, dadurch gekennzeichnet, daß die Stützplatte (20) mittels Stellbolzen (21) oder -schrauben (22) unter zunehmender Vorspannung der Feder (10) zum Kolben (5) hin verstellbar und in dieser Lage feststellbar ist. suction gripping device according to claim 8, characterized in that the support plate ( 20 ) by means of adjusting bolts ( 21 ) or screws ( 22 ) with increasing bias of the spring ( 10 ) to the piston ( 5 ) adjustable and can be determined in this position.

### Claim 10

Sauggreifvorrichtung nach Anspruch 9, dadurch gekennzeichnet, daß die Stellbolzen (21) oder -schrauben (22) gleichmäßig radial verteilt vorgesehen sind, deren Stellköpfe durch die Mündung von achsparallel zum Stößel (3) verlaufenden Gewindebohrungen (24) oder dergleichen zugänglich sind, wobei die Mündungen aus der Gehäuseseitenfläche (11) offen ausmünden, an welche das Stellglied angesetzt ist.10. suction gripping device according to claim 9, characterized in that the adjusting bolts ( 21 ) or screws ( 22 ) are provided evenly distributed radially, the adjusting heads are accessible through the mouth of axially parallel to the plunger ( 3 ) threaded holes ( 24 ) or the like, the orifices open out of the housing side surface ( 11 ) to which the actuator is attached.

### Claim 11

Sauggreifvorrichtung nach Anspruch 10, dadurch gekennzeichnet, daß die Mündungen außerhalb der vom Stellglied belegten Fläche (25) angeordnet sind.11. Suction gripping device according to claim 10, characterized in that the mouths are arranged outside the surface occupied by the actuator ( 25 ).

### Claim 12

Sauggreifvorrichtung nach Anspruch 10, dadurch gekennzeichnet, daß die Mündungen in der vom Stellglied belegten Fläche (25) angeordnet sind, die Bolzen (21) in den Bohrungen verschieblich sind und die Mündungen in exzentrisch zu den Bohrungen verlaufende Gewindebohrungen (27) übergehen, die nur teilweise in der vom Stellglied belegten Fläche (25) liegen und in die Stellschraube (28) eingeschraubt sind, die in ihrem Kopf Eingriffsschlitze (29) für ein Betätigungswerkzeug aufweisen, von denen mindestens ein Teilbereich außerhalb der vom Stellglied überdeckten Fläche (25) liegt.12. Suction gripping device according to claim 10, characterized in that the orifices are arranged in the surface occupied by the actuator ( 25 ), the bolts ( 21 ) are displaceable in the bores and the orifices merge into threaded bores ( 27 ) extending eccentrically to the bores, which lie only partially in the surface ( 25 ) occupied by the actuator and are screwed into the set screw ( 28 ), which have engagement slots ( 29 ) in their head for an actuating tool, at least a portion of which lies outside the surface ( 25 ) covered by the actuator lies.

### Claim 13

Sauggreifvorrichtung nach einem der Ansprüche 1 bis 12, dadurch gekennzeichnet, daß der Saugluftkanal (2) durch eine das Gehäuse (14) und die den Stößel (3) aufnehmende Gehäusekammer (6, 7) mittig durchsetzende Bohrung gebildet ist, deren zum Stößel (3) weisende Mündungen (30) exzentrisch in Richtung auf den Kolben (5) erweitert sind.13. Suction gripping device according to one of claims 1 to 12, characterized in that the suction air channel ( 2 ) through a housing ( 14 ) and the plunger ( 3 ) receiving housing chamber ( 6 , 7 ) is formed centrally penetrating bore, the plunger ( 3 ) pointing mouths ( 30 ) are expanded eccentrically in the direction of the piston ( 5 ).

### Claim 14

Sauggreifvorrichtung nach einem der Ansprüche 1 bis 13, dadurch gekennzeichnet, daß das Gehäuse (14) parallel zum Saugluftkanal (2) und ggf. quer dazu verlaufende Durchtrittskanäle (35, 35′) für Befestigungsmittel aufweist.14. Suction gripping device according to one of claims 1 to 13, characterized in that the housing ( 14 ) parallel to the suction air duct ( 2 ) and possibly transverse to it passages ( 35 , 35 ') for fasteners.

### Claim 15

Sauggreifvorrichtung nach einem der Ansprüche 1 bis 14, dadurch gekennzeichnet, daß an das Gehäuse (14) auf der dem Saugnapf (1) abgewandten Seite ein etwa formgleiches oder formähnliches zweites Gehäuseteil (31) mittelbar oder unter Zwischenfügung eines dritten Gehäuseteiles (32) dicht angesetzt ist, welches einen in den Saugluftkanal (2) mündenden Kanal (2) aufweist und quer dazu einen Arbeitskanal (33) mit einer Strahlpumpe.15. Suction gripping device according to one of claims 1 to 14, characterized in that on the housing ( 14 ) on the side facing away from the suction cup ( 1 ) an approximately identical or shape-like second housing part ( 31 ) indirectly or with the interposition of a third housing part ( 32 ) is tightly attached, which has an opening into the suction air channel (2) channel (2) and transverse thereto a working channel (33) having a jet pump.

### Claim 16

Sauggreifvorrichtung nach Anspruch 15, dadurch gekennzeichnet, daß die Strahlpumpe im Arbeitskanal (33) eine Düse (34) aufweist.16. Suction gripping device according to claim 15, characterized in that the jet pump in the working channel ( 33 ) has a nozzle ( 34 ).

### Claim 17

Sauggreifvorrichtung nach Anspruch 14 oder 15, dadurch gekennzeichnet, daß das zweite Gehäuseteil (31) parallel zum Saugluftkanal (2) und koaxial zu den entsprechenden Durchtrittskanälen (35) des ersten Gehäuseteiles (14) Durchtrittskanäle für Befestigungsmittel aufweist.17. Suction gripping device according to claim 14 or 15, characterized in that the second housing part ( 31 ) parallel to the suction air duct ( 2 ) and coaxial to the corresponding passage channels ( 35 ) of the first housing part ( 14 ) has passage channels for fasteners.

### Claim 18

Sauggreifvorrichtung nach einem der Ansprüche 1 bis 17, dadurch gekennzeichnet, daß zwischen das erste Gehäuse (14) und den Saugnapf (1) eine Gehäuseplatte (36) eingefügt ist, die eine zum Saugluftkanal (2) koaxiale Durchgangsbohrung aufweist, in deren dem ersten Gehäuse (14) abgewandte Mündung ein Gewindestutzen des Saugnapfes (1) einschraubbar ist.18. Suction gripping device according to one of claims 1 to 17, characterized in that between the first housing ( 14 ) and the suction cup ( 1 ), a housing plate ( 36 ) is inserted which has a through-bore to the suction air duct ( 2 ), in which the a threaded connector of the suction cup ( 1 ) can be screwed into the first housing ( 14 ) facing away from the mouth.

### Claim 19

Sauggreifvorrichtung nach einem der Ansprüche 1 bis 18, dadurch gekennzeichnet, daß vor das erste Gehäuse (14) oder zwischen das zweite Gehäuseteil (31) und das erste Gehäuse (14) das dritte Gehäuseteil (32) gefügt ist, welches ein im Saugluftkanal (2) angeordnetes Rückschlagventil (38) und/oder ein Schnellbelüftungsventil (39) aufweist, welches von außen betätigbar ist.19. Suction gripping device according to one of claims 1 to 18, characterized in that before the first housing ( 14 ) or between the second housing part ( 31 ) and the first housing ( 14 ), the third housing part ( 32 ) is added, which one in the suction air duct ( 2 ) arranged check valve ( 38 ) and / or a quick ventilation valve ( 39 ) which can be actuated from the outside.

### Claim 20

Sauggreifvorrichtung, insbesonderte nach Anspruch 19, dadurch gekennzeichnet, daß das dritte Gehäuseteil (32) einen koaxial zum Saugluftkanal (2) liegenden Eingang (40) aufweist, der über eine Bohrung (41) mit einer Kammer (42) des Rückschlagventiles (38) verbunden ist, daß am Boden der Kammer (42) ein Ventilsitz ausgebildet ist, der in einen Abgang (43) zum Saugluftkanal (2) mündet, der koaxial zum Eingang (40), aber entgegen gerichtet verläuft, daß insbesondere das Rückschlagventil (38) aus einem in eine Querbohrung des dritten Gehäuses (32) eingesetzten Ventiloberteil (44) mit federbelastetem Ventilstößel (45) und Ventilkörper (46) besteht, der bei am Eingang (40) anstehendem Unterdruck im Saugluftkanal (2) vom Ventilsitz abgehoben ist, bei an dem Saugnapf (1) anstehendem Unterdruck und am Eingang (40) anstehendem Atmosphärendruck aber auf dem Ventilsitz dichtend aufliegt.20. Suction gripping device, in particular according to claim 19, characterized in that the third housing part ( 32 ) has a coaxial to the suction air duct ( 2 ) lying input ( 40 ), which has a bore ( 41 ) with a chamber ( 42 ) of the check valve ( 38 ) is connected that a valve seat is formed on the bottom of the chamber ( 42 ), which opens into an outlet ( 43 ) to the suction air duct ( 2 ), which runs coaxially to the inlet ( 40 ) but in the opposite direction, that in particular the check valve ( 38 ) consists of a valve upper part ( 44 ) with a spring-loaded valve tappet ( 45 ) and valve body ( 46 ) inserted in a transverse bore of the third housing ( 32 ), which is lifted off the valve seat when the vacuum in the suction air duct ( 2 ) is present at the inlet ( 40 ) at the suction cup ( 1 ) and the atmospheric pressure at the inlet ( 40 ) but is sealingly seated on the valve seat.

### Claim 21

Sauggreifvorrichtung nach Anspruch 20, dadurch gekennzeichnet, daß der Ventilstößel (45) eine Bohrung (47, 48) aufweist, mittels derer der Eingang (40) des dritten Gehäuseteiles (32) mit einer Kammer (49) in Verbindung steht, die zwischen Ventiloberteil (44) und Stößel (45) ausgebildet ist und in der die auf den Stößel (45) einwirkende Schließfeder angeordnet ist. Suction gripping device according to claim 20, characterized in that the valve tappet ( 45 ) has a bore ( 47 , 48 ) by means of which the input ( 40 ) of the third housing part ( 32 ) is in communication with a chamber ( 49 ) between Valve upper part ( 44 ) and plunger ( 45 ) is formed and in which the closing spring acting on the plunger ( 45 ) is arranged.

### Claim 22

Sauggreifvorrichtung insbesondere nach Anspruch 19, dadurch gekennzeichnet, daß die den Ausgang (43) bildende Bohrung des dritten Gehäuseteiles (32) über eine Querbohrung (50) mit der Atmosphäre verbindbar ist, in die oder vor die das Schnellbelüftungsventil (39) eingesetzt ist.22. Suction gripping device in particular according to claim 19, characterized in that the outlet ( 43 ) forming the bore of the third housing part ( 32 ) via a transverse bore ( 50 ) can be connected to the atmosphere, in or in which the quick ventilation valve ( 39 ) is inserted .

### Claim 23

Sauggreifvorrichtung nach Anspruch 22, dadurch gekennzeichnet, daß das Schnellbelüftungsventil (39) unter Federvorspannung in der Schließlage gehalten ist und mittels einer entgegen Schließrichtung aufgebrachten Kraft, z. B. eines Druckluftstoßes, in die Offenlage überführbar ist.23. Suction gripping device according to claim 22, characterized in that the rapid ventilation valve ( 39 ) is held under spring preload in the closed position and by means of a force applied against the closing direction, for. B. a blast of compressed air can be transferred to the open position.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippers

Description

Translated from German

Die Erfindung betrifft eine Sauggreifvorrichtung zum

Anheben und Halten von WerkstÃ¼cken, z. B. flÃ¤chigen

StÃ¼ckgÃ¼tern, mit einem GehÃ¤use, an dem ein Saugnapf

befestigbar ist, dessen Innenraum an einen im GehÃ¤use

ausgebildeten Saugluftkanal angeschlossen ist, der mit

einer Unterdruck erzeugenden Einrichtung verbunden ist.The invention relates to a suction gripping device for

Lifting and holding workpieces, e.g. B. flat

General cargo, with a housing on which a suction cup

is attachable, the interior of one in the housing

trained suction air duct is connected with

a vacuum generating device is connected.

Aus der EP 02 20 407 B1 ist eine Ã¤hnliche

Sauggreifeinrichtung vorbekannt. Der Aufbau der bekannten

Sauggreifeinrichtung ist relativ kompliziert und schon

daher aufwendig und auch im Dauerbetrieb anfÃ¤llig.

Nachteilig ist insbesondere die zwingende Notwendigkeit

der Anordnung einer eingespannten gummielastischen

Membrane, die bei hoher SchalthÃ¤ufigkeit der

Sauggreifeinrichtung einem erheblichen VerschleiÃ

unterliegt.

A similar is known from EP 02 20 407 B1

Suction gripping device previously known. The structure of the known

Suction gripping device is relatively complicated and beautiful

therefore complex and susceptible to continuous operation.

The imperative is particularly disadvantageous

the arrangement of a clamped rubber elastic

Membrane, the high switching frequency of the

Suction gripper a considerable wear

subject to.

Â

Zudem ist nachteilig, daÃ infolge der mit der Membran

gekoppelten MÃ¶glichkeit der Schaltung eines Stellgliedes

in Form eines NÃ¤herungsschalters oder eines Mikroschalters

nur geringe KrÃ¤fte Ã¼bertragen werden kÃ¶nnen, die im

Regelfall zur Schaltung eines pneumatischen Stellgliedes

(Schalters oder dergleichen) nicht ausreichen.

Bei einer AusfÃ¼hrungsform in diesem Stand der Technik

ist als Schaltelement ein VentilstÃ¶Ãel vorgesehen, der

mit der Membran verbunden ist und der achsparallel, aber

nicht koaxial zum VentilstÃ¶Ãel ein Schaltelement aufweist,

welches wiederum mit einem NÃ¤herungsschalter oder

dergleichen Stellglied zusammenwirken kann. Auch bei

dieser Anordnung ist aufgrund der fehlenden koaxialen

Anordnung und der Zwangskopplung mit der Membran das

Aufbringen grÃ¶Ãerer KrÃ¤fte beispielsweise zum Schalten

eines mechanischen Schalters nicht oder nicht dauerhaft

gewÃ¤hrleistet.It is also disadvantageous that due to the membrane

coupled possibility of switching an actuator

in the form of a proximity switch or a microswitch

only small forces can be transmitted, which in

Normal case for switching a pneumatic actuator

(Switch or the like) are not sufficient.

In one embodiment in this prior art

a valve lifter is provided as a switching element, the

is connected to the membrane and the axially parallel, however

does not have a switching element coaxial to the valve tappet,

which in turn with a proximity switch or

the same actuator can cooperate. Also at

this arrangement is due to the lack of coaxial

Arrangement and the positive coupling with the membrane that

Applying greater forces, for example for switching

of a mechanical switch not or not permanently

guaranteed.

Zudem ist beim Stand der Technik nachteilig, daÃ eine

nachtrÃ¤gliche Einstellung von VorspannkrÃ¤ften nicht

mÃ¶glich ist, so daÃ die Einstellung auf einen Schaltpunkt

bei bestimmten auftretenden UnterdrÃ¼cken nicht mÃ¶glich

ist, sondern die festeingestellte Funktion auch dann

beibehalten werden muÃ, wenn die Schaltfunktion erst

bei hÃ¶heren auftretenden UnterdrÃ¼cken erwÃ¼nscht ist.

Auch die ZugÃ¤nglichkeit und Montage der Einzelteile ist

aufwendig. Zudem ist die vorbekannte Ausbildung deswegen

kompliziert, weil in einem einzigen Bauteil eine Vielzahl

von Elementen eingebracht werden mÃ¼ssen, so daÃ ein

modulweiser Aufbau und ein Auswechseln von schadhaften

Bestandteilen durch Wechsel von Modulen nicht mÃ¶glich

ist.It is also disadvantageous in the prior art that a

subsequent adjustment of pretensioning forces not

is possible, so that the setting to a switching point

not possible with certain occurring negative pressures

Â but the fixed function even then

must be maintained when the switching function

is desirable at higher pressures.

The accessibility and assembly of the individual parts is also

complex. In addition, the previously known training is therefore

complicated because a large number in a single component

of elements must be introduced so that a

modular construction and replacement of defective ones

Components not possible by changing modules

is.

Ausgehend von diesem Stand der Technik liegt der Erfindung

die Aufgabe zugrunde, eine Sauggreifvorrichtung der im

Oberbegriff bezeichneten Art zu schaffen, mit der groÃe

SchaltkrÃ¤fte zur BetÃ¤tigung von mechanischen Stellorganen

Ã¼bertragen werden kÃ¶nnen, die im Aufbau standardisierbar

ist und den Aufbau nach einem modulartigen Baukastensystem

ermÃ¶glicht. Dabei soll der konstruktive Aufwand gering

gehalten sein und die VerschleiÃteile mÃ¶glichst von auÃen

zugÃ¤nglich sein.

The invention is based on this prior art

the task of a suction gripping device in

Generic term designed to create with the big

Switching forces for actuating mechanical actuators

can be transferred, which can be standardized in the structure

is and the structure according to a modular system

enables. The design effort should be low

be kept and the wearing parts as possible from the outside

be accessible.

Â

Insbesondere ist im Sinne der Aufgabenstellung erwÃ¼nscht,

daÃ eine direkte BetÃ¤tigung eines NÃ¤herungsschalters

oder dergleichen mÃ¶glich ist und darÃ¼ber hinaus auch

dann, wenn elektrische Schalter aus betrieblichen GrÃ¼nden

nicht zulÃ¤ssig sind, mit derselben Einrichtung auch die

Schaltung von mechanischen Schaltern mÃ¶glich ist.

GrundsÃ¤tzlich soll auf den Einsatz einer Membran als

wesentliches Funktionselement verzichtet werden und die

VerschleiÃanfÃ¤lligkeit minimiert werden.In particular, in terms of the task, it is desirable

that direct actuation of a proximity switch

or the like is possible and moreover

then when electrical switches for operational reasons

are not permitted with the same facility

Switching mechanical switches is possible.

Basically, the use of a membrane should be considered

essential functional element and the

Susceptibility to wear can be minimized.

Zur LÃ¶sung dieser Aufgabe schlÃ¤gt die Erfindung

prinzipiell vor, daÃ im Saugluftkanal ein StÃ¶Ãel

angeordnet ist, der bei in der Saugleitung anstehendem

Unterdruck aus einer Ruhelage in eine Arbeitsposition

verstellt ist, in welcher der StÃ¶Ãel ein Stellglied,

z. B. ein Ventil oder einen NÃ¤herungsschalter, betÃ¤tigt.The invention proposes to achieve this object

in principle before that in the suction air duct a plunger

is arranged, the pending in the suction line

Negative pressure from a rest position to a working position

is adjusted, in which the plunger is an actuator,

e.g. B. actuated a valve or a proximity switch.

Durch diese Anordnung ist erreicht, daÃ bei in der

Saugleitung anstehendem Unterdruck und auf ein

entsprechendes WerkstÃ¼ck aufgesetztem Saugnapf der StÃ¶Ãel

aus seiner Ruhelage in einer Arbeitsposition verstellt

ist, in welcher der StÃ¶Ãel ein Stellglied, beispielsweise

einen NÃ¤herungsschalter oder auch einen mechanischen

Schalter oder ein Ventil betÃ¤tigt. Durch die BetÃ¤tigung

des Stellgliedes kÃ¶nnen unterschiedliche Funktionen bzw.

Funktionssignale erreicht werden. Beispielsweise ist

es mÃ¶glich, bei einem mit einer erfindungsgemÃ¤Ãen SaugÂ­

greifvorrichtung ausgerÃ¼steten Roboter das Schaltsignal

"Vakuum steht an" abzugeben, so daÃ der Arbeitsroboter

dann in Betrieb genommen werden kann, solange dieses

Signal ansteht. Wenn aus betrieblichen GrÃ¼nden keine

elektrischen Schaltelemente verwendet werden dÃ¼rfen,

so kann mittels des StÃ¶Ãels ein pneumatisches Ventil,

beispielsweise ein pneumatisches Zweiwege-Ventil

geschaltet werden, um die entsprechende Signalfunktion

an eine Steuerzentrale zu geben. Sobald der Unterdruck

nachlÃ¤Ãt, verstellt sich der StÃ¶Ãel wieder in die

Ruhelage, so daÃ das vom StÃ¶Ãel initiierbare Stellglied

das entsprechende Signal "Vakuum steht nicht an" an die

Schaltzentrale weitergibt und somit der mit der SauggreifÂ­

vorrichtung beispielsweise gekoppelte Roboter angehalten

oder auÃer Betrieb gesetzt wird, um ausfallbedingte

SchÃ¤den zu vermeiden.

This arrangement ensures that in the

Suction line applied vacuum and on

Corresponding workpiece attached suction cup of the plunger

adjusted from its rest position in a working position

is, in which the plunger is an actuator, for example

Â a proximity switch or a mechanical one

Switch or valve actuated. By actuation

of the actuator can have different functions or

Function signals can be reached. For example

it is possible with a suction according to the invention

equipped with a gripping device, the switching signal

"Vacuum is pending" so that the working robot

can then be put into operation as long as this

Signal pending. If for operational reasons none

electrical switching elements may be used,

a pneumatic valve,

for example a pneumatic two-way valve

can be switched to the corresponding signal function

to give to a control center. As soon as the vacuum

subsides, the plunger moves back into the

Rest position, so that the actuator initiated by the plunger

the corresponding signal "Vacuum is not present" to the

Control center passes on and thus the one with the suction gripper

device, for example, coupled robots stopped

or is taken out of service due to failure

Avoid damage.

Â

Eine bevorzugte Ausbildung wird darin gesehen, daÃ der

StÃ¶Ãel Bestandteil eines Kolbens ist, der in einer quer

zum Saugluftkanal gerichteten GehÃ¤usebohrung

verschieblich ist, wobei die dem StÃ¶Ãel abgewandte

StirnflÃ¤che des Kolbens Ã¼ber GehÃ¤useÃ¶ffnungen mit der

AuÃenatmosphÃ¤re in Verbindung steht und die StirnflÃ¤che,

von der der StÃ¶Ãel abragt, mit dem Saugluftkanal in

Verbindung steht, wobei der StÃ¶Ãel mit seinem freien

Ende in einer GehÃ¤usebohrung gefÃ¼hrt ist, in welche

GehÃ¤usebohrung das vom StÃ¶Ãel betÃ¤tigbare Stellglied

eingesetzt ist oder an welche GehÃ¤usebohrung das

Stellglied angesetzt ist, wobei der Kolben und/oder der

StÃ¶Ãel mittels einer Feder in die Ruhelage gedrÃ¤ngt ist

und in der Arbeitslage entgegen der Kraft der Feder

verstellt ist.A preferred training is seen in that the

Tappet is part of a piston that is in a cross

housing bore facing the suction air duct

is displaceable, the one facing away from the tappet

Face of the piston over the housing openings with the

Outside atmosphere and the face,

from which the plunger protrudes with the suction air duct in

Connection is established, the plunger with its free

End is guided in a housing bore in which

Housing bore the actuator actuated by the plunger

is used or to which housing bore that

Actuator is attached, the piston and / or the

Ram is pushed into the rest position by means of a spring

and in the working position against the force of the spring

is adjusted.

Dabei ist besonders bevorzugt vorgesehen, daÃ die den

StÃ¶Ãel samt Kolben aufnehmende GehÃ¤usekammer quer zum

Verlauf des Saugluftkanals verlÃ¤uft und die Ein- oder

AnsatzÃ¶ffnung fÃ¼r das Stellglied an einer

GehÃ¤useseitenflÃ¤che frei zugÃ¤nglich ausgebildet ist,

wÃ¤hrend die EinsatzÃ¶ffnung der GehÃ¤usekammer fÃ¼r den

StÃ¶Ãel samt Kolben auf der dieser gegenÃ¼berliegenden

GehÃ¤useseitenflÃ¤che frei zugÃ¤nglich ist und mittels einer

Durchgangslochungen aufweisenden VerschluÃplatte

verschlossen ist.It is particularly preferably provided that the

Tappet including piston housing housing transverse to

The course of the suction air duct runs and the inlet or

Approach opening for the actuator on one

Housing side surface is freely accessible,

while the insert opening of the housing chamber for the

Â Ram and piston on the opposite one

Housing side surface is freely accessible and by means of a

Closure plate with through holes

is closed.

Bei dieser Ausbildung ist bei geringem konstruktivem

Aufwand eine leichte ZugÃ¤nglichkeit zu den

Funktionselementen gegeben, so daÃ vor allem

VerschleiÃteile von auÃen leicht zugÃ¤nglich sind. Die

bei einer derartigen Ausbildung erreichte Schaltkraft

reicht zur BetÃ¤tigung eines Schaltventils oder dergleichen

aus, wobei durch die konstruktive Ausbildung eine koaxiale

Anordnung von StÃ¶Ãel und Schaltelement mÃ¶glich ist, was

einer hohen KraftÃ¼bertragung bei den auftretenden

UnterdrÃ¼cken zutrÃ¤glich ist. Bevorzugt ist die Ausbildung

einer relativ groÃen KolbenflÃ¤che bei einer relativ

geringen StÃ¶ÃelquerschnittsflÃ¤che, damit ausreichende

KrÃ¤fte Ã¼ber den Kolben auf den StÃ¶Ãel Ã¼bertragen werden

kÃ¶nnen. Bei der BetÃ¤tigung des StÃ¶Ãels muÃ die Federkraft

der RÃ¼ckstellfeder und die Schaltkraft des Stellgliedes

im Falle eines mechanischen Stellgliedes Ã¼berwunden

werden, was mit der erfindungsgemÃ¤Ãen Vorrichtung

ausgezeichnet mÃ¶glich ist.

This training is constructive with little

Ease of accessibility to the

Given functional elements, so that above all

Wear parts are easily accessible from the outside. The

switching force achieved with such a design

is sufficient to actuate a switching valve or the like

from, with the constructive training a coaxial

Arrangement of plunger and switching element is possible

a high power transmission in the occurring

Suppression is beneficial. Training is preferred

a relatively large piston area with a relatively

small tappet cross-sectional area, so sufficient

Forces are transferred via the piston to the tappet

can. The spring force must be applied when the plunger is actuated

the return spring and the switching force of the actuator

overcome in the case of a mechanical actuator

be what with the device according to the invention

excellent is possible.

Â

Durch die Anordnung der RÃ¼ckstellfeder ist es mÃ¶glich,

diese RÃ¼ckstellfeder in ihrer Federkraft so zu bemessen,

daÃ der StÃ¶Ãel beispielsweise erst bei einem zumindest

zu 60% aufgebautem Vakuum in die Arbeitsstellung

verschoben wird, bei geringerem Vakuum aber der StÃ¶Ãel

in der Ruhelage verbleibt.The arrangement of the return spring makes it possible to

to dimension this return spring in terms of its spring force,

that the plunger, for example, at least at one

60% vacuum built up in the working position

is moved, but the plunger at a lower vacuum

remains in the rest position.

Eine bevorzugte Weiterbildung wird darin gesehen, daÃ

der Kolben mittels einer Ringdichtung gegenÃ¼ber der

zylindrischen Kammerwandung abgedichtet ist.A preferred further development is seen in the fact that

the piston by means of an annular seal opposite the

cylindrical chamber wall is sealed.

In jedem Fall muÃ der Kolben in geeigneter Weise gegenÃ¼ber

der Kammerwandung abgedichtet sein, damit der Zutritt

von AtmosphÃ¤renluft in den Saugluftkanal unterbunden

ist.In any case, the piston must be suitably opposite

the chamber wall to be sealed so that access

prevented from atmospheric air in the suction air duct

is.

Eine Variante hierzu wird darin gesehen, daÃ der Kolben

gegenÃ¼ber der EinsatzÃ¶ffnung durch eine an der

Kammerwandung dicht eingespannte Dichtfolie abgedichtet

ist, die an der KolbenstirnflÃ¤che anliegt.A variant of this is seen in the fact that the piston

opposite the insert opening by one on the

Chamber wall tightly sealed sealing film sealed

which rests on the piston face.

Dabei ist bevorzugt vorgesehen, daÃ die KolbenstirnflÃ¤che

durch eine Bohrung mit der GehÃ¤usekammer und somit mit

dem Saugluftkanal in Verbindung steht, welche Bohrung

mittig den Kolben durchsetzt und aus dem StÃ¶Ãel radial

austritt.It is preferably provided that the piston face

through a hole with the housing chamber and thus with

Â the suction air duct is connected to which hole

passes through the center of the piston and radially out of the tappet

exit.

Weiterhin ist dabei bevorzugt, daÃ die KolbenstirnflÃ¤che

mittig eine flache Vertiefung aufweist, an die bei

anstehender Saugluft die Dichtfolie angelegt ist.It is further preferred that the piston face

has a shallow depression in the middle, to which at

the sealing film is applied to the suction air.

Bei dieser Anordnung kommt insbesondere eine vorgeformte

Dichtfolie oder dergleichen zum Einsatz, die bei

entsprechendem Unterdruck bei einer Bewegung der

StÃ¶Ãelkolbeneinheit leicht umschlagen kann. Um den

Umschlagvorgang einzuleiten, ist die mittige Vertiefung

in der KolbenstirnflÃ¤che und die dort ausmÃ¼ndende Bohrung

vorteilhaft, da bei auftretendem Vakuum die Dichtfolie

in diesem Mittelbereich in die Vertiefung eingezogen

und anschlieÃend bei Verstellung des StÃ¶Ãels samt Kolben

der Umschlag der Dichtfolie durchgefÃ¼hrt wird.

Die Dichtfolie selbst braucht nicht federelastisch

ausgebildet sein, da sie nicht als Membran, sondern

lediglich als Dichtfolie dient.

In this arrangement, a preformed one comes in particular

Sealing film or the like is used, which at

corresponding negative pressure when moving the

Tappet piston unit can easily turn over. To the

The central depression is to initiate the transhipment process

in the face of the piston and the bore opening there

advantageous because the sealing film when a vacuum occurs

moved into the recess in this central area

and then when the plunger and piston are adjusted

the sealing foil is wrapped.

The sealing film itself does not need to be resilient

be trained because they are not a membrane, but

only serves as a sealing film.

Â

Eine besonders bevorzugte Weiterbildung wird darin

gesehen, daÃ die Feder durch eine koaxial den StÃ¶Ãel

umgebende Schraubenfeder gebildet ist, die sich mit ihrem

einen Ende an der Unterseite des Kolbens und mit ihrem

anderen Ende an einer GehÃ¤useschulter oder einer sich

gehÃ¤usefest abstÃ¼tzenden StÃ¼tzplatte abstÃ¼tzt, die vom

StÃ¶Ãel mit Spiel durchgriffen ist.It is a particularly preferred development

seen that the spring through a coaxial the plunger

surrounding coil spring is formed, which with their

one end at the bottom of the piston and with her

other end on a housing shoulder or one itself

supporting support plate which is fixed to the housing and which is supported by the

Plunger is penetrated with play.

Dabei ist bevorzugt vorgesehen, daÃ die StÃ¼tzplatte

mittels Stellbolzen oder -schrauben unter zunehmender

Vorspannung der Feder zum Kolben hin verstellbar und

in dieser Lage feststellbar ist.It is preferably provided that the support plate

using adjusting bolts or screws with increasing

Preload of the spring adjustable towards the piston and

can be determined in this position.

Durch diese Anordnung ist es mÃ¶glich, die Federkraft

der RÃ¼ckstellfeder einzustellen, so daÃ der Schaltpunkt

des Ventils vom Benutzer in einfacher Weise eingestellt

werden kann.With this arrangement, it is possible to adjust the spring force

the return spring so that the switching point

of the valve set by the user in a simple manner

can be.

Zu diesem Zwecke ist vorteilhafter Weise vorgesehen,

daÃ die Stellbolzen oder -schrauben gleichmÃ¤Ãig radial

verteilt vorgesehen sind, deren StellkÃ¶pfe durch die

MÃ¼ndung von achsparallel zum StÃ¶Ãel verlaufenden GewindeÂ­

bohrungen oder dergleichen zugÃ¤nglich sind, wobei die

MÃ¼ndungen aus der GehÃ¤useseitenflÃ¤che offen ausmÃ¼nden,

an welche das Stellglied angesetzt ist.For this purpose, it is advantageously provided

that the adjusting bolts or screws are evenly radial

distributed are provided, the adjusting heads through the

Mouth of thread running parallel to the plunger

Â holes or the like are accessible, the

Open out openings from the side of the housing,

to which the actuator is attached.

Eine Weiterbildung hierzu wird darin gesehen, daÃ die

MÃ¼ndungen auÃerhalb der vom Stellglied belegten FlÃ¤che

angeordnet sind.A further training is seen in the fact that

Mouths outside the area occupied by the actuator

are arranged.

Hierdurch ist es mÃ¶glich, auch bei auf den GehÃ¤usekanal

aufgesetztem Stellglied die Federkraft einzustellen,

ohne daÃ das Stellglied demontiert werden mÃ¼Ãte.This makes it possible, even when on the housing channel

adjust the spring force on the actuator,

without the actuator having to be dismantled.

Eine bevorzugte Variante hierzu wird darin gesehen, daÃ

die MÃ¼ndungen in der vom Stellglied belegten FlÃ¤che

angeordnet sind, die Bolzen in den Bohrungen verschieblich

sind und die MÃ¼ndungen in exzentrisch zu den Bohrungen

verlaufende Gewindebohrungen Ã¼bergehen, die nur teilweise

in der vom Stellglied belegten FlÃ¤che liegen und in die

Stellschrauben eingeschraubt sind, die in ihrem Kopf

Eingriffsschlitze fÃ¼r ein BetÃ¤tigungswerkzeug aufweisen,

von denen mindestens ein Teilbereich auÃerhalb der vom

Stellglied Ã¼berdeckten FlÃ¤che liegt.

A preferred variant of this is seen in that

the mouths in the area occupied by the actuator

are arranged, the bolts are displaceable in the bores

are and the mouths are eccentric to the holes

tapping holes that pass only partially

lie in the area occupied by the actuator and in the

Set screws are screwed into her head

Have engagement slots for an actuating tool,

of which at least a subarea outside of

Actuator is covered area.

Â

Auf diese Weise ist auch bei geringer BaugrÃ¶Ãe der

Einzelelemente noch eine feste Anordnung des Stellgliedes

mÃ¶glich und dennoch bei angeordnetem Stellglied die

BetÃ¤tigung der Stellschrauben erreicht.In this way, even with a small size

Individual elements still a fixed arrangement of the actuator

possible and yet with the actuator arranged

Actuation of the set screws reached.

Um auch bei geringer BaugrÃ¶Ãe des GehÃ¤useteiles noch

sicherzustellen, daÃ die MÃ¼ndungen des Saugluftkanales

nicht teilweise von der StÃ¼tzplatte verdeckt sind, ist

vorgesehen, daÃ der Saugluftkanal durch eine das GehÃ¤use

und die den StÃ¶Ãel aufnehmende GehÃ¤usekammer mittig

durchsetzende Bohrung gebildet ist, deren zum StÃ¶Ãel

weisende MÃ¼ndungen exzentrisch in Richtung auf den Kolben

erweitert sind.To still with a small size of the housing part

ensure that the mouths of the suction air duct

are not partially covered by the support plate

provided that the suction air duct through a the housing

and the housing chamber receiving the plunger in the middle

penetrating bore is formed, the tappet

muzzle pointing eccentrically towards the piston

are expanded.

Um eine individuelle Befestigung des GehÃ¤uses an dem

entsprechenden Roboter oder dergleichen zu ermÃ¶glichen,

ist vorgesehen, daÃ das GehÃ¤use parallel zum Saugluftkanal

und ggf. quer dazu verlaufende DurchtrittskanÃ¤le fÃ¼r

Befestigungsmittel aufweist.To individually attach the housing to the

to enable corresponding robots or the like,

it is provided that the housing parallel to the suction air duct

and possibly transverse passages for

Has fasteners.

Eine bevorzugte Weiterbildung wird darin gesehen, daÃ

an das GehÃ¤use auf der dem Saugnapf abgewandten Seite

ein etwa formgleiches oder formÃ¤hnliches zweites

GehÃ¤useteil mittelbar oder unter ZwischenfÃ¼gung eines

dritten GehÃ¤useteiles dicht angesetzt ist, welches einen

in den Saugluftkanal mÃ¼ndenden Kanal aufweist und quer

dazu einen Arbeitskanal mit einer Strahlpumpe.A preferred further development is seen in the fact that

to the housing on the side facing away from the suction cup

Â an approximately identical or similar second

Housing part indirectly or with the interposition of a

third housing part is set tight, which one

has channel opening into the suction air duct and transversely

plus a working channel with a jet pump.

Die Ausbildung einer solchen Strahlpumpe ist an sich

bekannt, wozu auf die DE-OS 22 48 930 verwiesen wird.The formation of such a jet pump is in itself

is known, for which reference is made to DE-OS 22 48 930.

Bevorzugt ist dabei vorgesehen, daÃ die Strahlpumpe im

Arbeitskanal eine DÃ¼se aufweist.It is preferably provided that the jet pump in

Working channel has a nozzle.

Des weiteren ist vorzugsweise vorgesehen, daÃ das zweite

GehÃ¤useteil parallel zum Saugluftkanal und koaxial zu

den entsprechenden DurchtrittskanÃ¤len des ersten

GehÃ¤useteiles DurchtrittskanÃ¤le fÃ¼r Befestigungsmittel

aufweist.Furthermore, it is preferably provided that the second

Housing part parallel to the suction air duct and coaxially

the corresponding passage channels of the first

Housing part passage channels for fasteners

having.

Die vorher schon beschriebenen BefestigungsmÃ¶glichkeiten

des ersten GehÃ¤useteiles sind auch beim zweiten

GehÃ¤useteil gegeben, ebenso wie in den nachstehend

noch weiter beschriebenen weiteren GehÃ¤useteilen, so

daÃ durch entsprechend lange Befestigungsbolzen die

GehÃ¤useteile miteinander verbunden werden kÃ¶nnen und

auch quer dazu gerichtete Befestigungsschrauben an

entsprechenden Robotern oder Maschinenteilen angeordnet

werden kÃ¶nnen.The mounting options previously described

of the first housing part are also the second

Given housing part, as in the following

Â further described housing parts, see above

that by appropriately long mounting bolts

Housing parts can be connected to each other and

also cross-fastening screws

appropriate robots or machine parts arranged

can be.

Des weiteren ist bevorzugt vorgesehen, daÃ zwischen das

erste GehÃ¤use und den Saugnapf eine GehÃ¤useplatte

eingefÃ¼gt ist, die eine zum Saugluftkanal koaxiale

Durchgangsbohrung aufweist, in deren dem ersten GehÃ¤use

abgewandte MÃ¼ndung ein Gewindestutzen des Saugnapfes

einschraubbar ist.Furthermore, it is preferably provided that between the

first housing and the suction cup a housing plate

is inserted, one coaxial to the suction air duct

Has through hole in the first housing

mouth facing away from a threaded connector of the suction cup

can be screwed in.

Eine besonders bevorzugte Weiterbildung, die auch

selbstÃ¤ndig als erfinderisch angesehen wird, ist dadurch

gekennzeichnet, daÃ vor das erste GehÃ¤use oder zwischen

das zweite GehÃ¤useteil und das erste GehÃ¤use das dritte

GehÃ¤useteil gefÃ¼gt ist, welches ein im Saugluftkanal

angeordnetes RÃ¼ckschlagventil und/oder ein SchnellÂ­

belÃ¼ftungsventil aufweist, welches von auÃen betÃ¤tigbar

ist.

A particularly preferred training that also

is considered to be independently inventive

characterized in that before the first housing or between

the second housing part and the first housing the third

Housing part is joined, which one in the suction air duct

arranged check valve and / or a quick

has ventilation valve which can be operated from the outside

is.

Â

Durch diese Ausbildung wird erreicht, daÃ nach dem

Aufsetzen des Saugnapfes auf eine entsprechende FlÃ¤che

eines WerkstÃ¼ckes und nach dem Aufbau des Vakuums die

vakuumerzeugende Einrichtung abgeschaltet werden kann,

da das Vakuum durch das RÃ¼ckschlagventil aufrechterhalten

wird, welches sich dann in der SchlieÃlage befindet. Sofern

die vakuumerzeugende Einrichtung in Betrieb genommen

wird, wird das RÃ¼ckschlagventil in die Ãffnungslage

Ã¼berfÃ¼hrt und somit der Saugluftkanal mit der

vakuumerzeugenden Vorrichtung verbunden.This training ensures that after

Place the suction cup on an appropriate surface

of a workpiece and after building the vacuum

vacuum generating device can be switched off,

because the vacuum is maintained by the check valve

which is then in the closed position. Provided

the vacuum generating device was put into operation

the check valve is in the open position

transferred and thus the suction air duct with the

vacuum generating device connected.

Um einen entsprechend schnellen Abbau des Vakuums zum

Abnehmen des Saugnapfes von der entsprechenden

WerkstÃ¼ckflÃ¤che zu erreichen, ist die Anordnung des

SchnellbelÃ¼ftungsventiles vorteilhaft. Solche SchnellÂ­

belÃ¼ftungsventile sind im Stand der Technik, insbesondere

in der eingangs beschriebenen EP 02 20 407 an sich

bekannt.In order to release the vacuum quickly

Remove the suction cup from the corresponding one

To reach the workpiece surface is the arrangement of the

Rapid ventilation valves advantageous. Such quick

Aeration valves are in the prior art, in particular

in EP 02 20 407 described at the outset

known.

Eine bevorzugte Weiterbildung hierzu wird darin gesehen,

daÃ das dritte GehÃ¤ueteil einen koaxial zum Saugluftkanal

liegenden Eingang aufweist, der Ã¼ber eine Bohrung mit

einer Kammer des RÃ¼ckschlagventils verbunden ist, daÃ

am Boden der Kammer ein Ventilsitz ausgebildet ist, der

in einen Abgang zum Saugluftkanal mÃ¼ndet, der koaxial

zum Eingang, aber entgegengerichtet verlÃ¤uft, daÃ

insbesondere das RÃ¼ckschlagventil aus einem in eine

Querbohrung des dritten GehÃ¤uses eingesetzten

Ventiloberteil mit federbelastetem VentilstÃ¶Ãel und

VentilkÃ¶rper besteht, der bei am Eingang anstehendem

Unterdruck im Saugluftkanal vom Ventilsitz abgehoben

ist, bei an dem Saugnapf anstehendem Unterdruck und am

Eingang anstehendem AtmosphÃ¤rendruck aber auf dem

Ventilsitz dichtend aufliegt.A preferred further development for this is seen in

that the third housing part is coaxial with the suction air duct

has lying entrance, which has a hole with

Â a chamber of the check valve is connected that

a valve seat is formed on the bottom of the chamber

ends in a branch to the suction air duct, which is coaxial

to the entrance, but runs in the opposite direction, that

especially the check valve from one to one

Cross bore of the third housing used

Valve top with spring-loaded valve tappet and

Valve body exists, the one at the entrance

Vacuum in the suction air duct is lifted from the valve seat

is, with the vacuum on the suction cup and on

Atmospheric pressure input but on the

Valve seat lies sealingly.

Dabei ist bevorzugt vorgesehen, daÃ der VentilstÃ¶Ãel

eine Bohrung aufweist, mittels derer der Eingang des

dritten GehÃ¤useteils mit einer Kammer in Verbindung steht,

die zwischen Ventiloberteil und StÃ¶Ãel ausgebildet ist

und in der die auf den StÃ¶Ãel einwirkende SchlieÃfeder

angeordnet ist.It is preferably provided that the valve lifter

has a hole by means of which the entrance of the

third housing part is connected to a chamber,

which is formed between the valve upper part and tappet

and in the closing spring acting on the plunger

is arranged.

Die entsprechenden Bohrungen dienen zum Druckausgleich

innerhalb der Funktionsteile des Ventiles, so daÃ die

Federkraft der SchlieÃfeder gering gehalten werden kann.The corresponding holes serve to equalize the pressure

within the functional parts of the valve, so that the

Â Spring force of the closing spring can be kept low.

Weiterhin ist bevorzugt vorgesehen, daÃ die den Ausgang

bildende Bohrung des dritten GehÃ¤useteiles Ã¼ber eine

Querbohrung mit der AtmosphÃ¤re verbindbar ist, in die

oder vor die das SchnellbelÃ¼ftungsventil eingesetzt ist.Furthermore, it is preferably provided that the output

forming bore of the third housing part over a

Cross hole is connectable to the atmosphere in which

or in front of which the quick ventilation valve is inserted.

Dabei ist bevorzugt vorgesehen, daÃ das

SchnellbelÃ¼ftungsventil unter Federvorspannung in der

SchlieÃlage gehalten ist und mittels einer entgegen

SchlieÃrichtung aufgebrachten Kraft, z. B. eines DruckluftÂ­

stoÃes, in die Offenlage Ã¼berfÃ¼hrbar ist.It is preferably provided that the

Quick vent valve with spring preload in the

Closed position is maintained and by means of a counter

Closing direction applied force, e.g. B. a compressed air

bump, can be transferred to the open position.

Ein besonderer Vorteil der erfindungsgemÃ¤Ãen Vorrichtung

besteht auch darin, daÃ sÃ¤mtliche Elemente nach Art eines

Baukastensystemes in einfacher Weise austauschbar sind,

wobei gemÃ¤Ã Anwenderwunsch einzelne oder auch mehrere

Bauteile zu einer funktionstÃ¼chtigen Einheit

zusammengefÃ¼hrt werden kÃ¶nnen. SelbstverstÃ¤ndlich ist

bei der erfindungsgemÃ¤Ã vorgesehenen Ankopplung der

Bauteile aneinander jeweils eine dichte Ankopplung

notwendig.

A particular advantage of the device according to the invention

is also that all elements like a

Modular system are easily interchangeable,

whereby according to user request, one or more

Components to a functional unit

can be merged. It goes without saying

in the coupling provided according to the invention

Components tightly coupled to each other

necessary.

Â

Zudem sind alle VerschleiÃteile in einfacher Weise von

auÃen zugÃ¤nglich. Es sind auch an allen GehÃ¤useteilen

StandardbefestigungsmÃ¶glichkeiten durch die entsprechenden

Querbohrungen vorgegeben, so daÃ je nach Anwenderwunsch

gleiche oder unterschiedliche Befestigungspunkte gewÃ¤hlt

werden kÃ¶nnen. Es ist selbstverstÃ¤ndlich auch mÃ¶glich,

in die Abgangsbohrung der DÃ¼se eine SchalldÃ¤mpfeinrichtung

einzusetzen, wobei die DÃ¼se vorzugsweise aus Messing

besteht und sÃ¤mtliche GehÃ¤useteile aus Aluminium gefertigt

werden sollen. Der Einsatz dieser Materialien

gewÃ¤hrleistet bei relativ geringem Gewicht eine geringe

Korrosionsgefahr.In addition, all wear parts are in a simple manner

accessible from outside. It is also on all housing parts

Standard mounting options through the corresponding

Cross bores predefined so that depending on the user request

same or different attachment points selected

can be. Of course it is also possible

a silencer in the outlet bore of the nozzle

use, the nozzle preferably made of brass

exists and all housing parts made of aluminum

should be. The use of these materials

ensures a low weight at a relatively low weight

Risk of corrosion.

Die Erfindung ist nachstehend anhand von

AusfÃ¼hrungsbeispielen nÃ¤her beschrieben.The invention is based on

Embodiments described in more detail.

Es zeigtIt shows

Fig. 1 eine Sauggreifvorrichtung in Seitenansicht im

LÃ¤ngsmittelschnitt gesehen; Figure 1 seen a suction gripping device in side view in longitudinal central section.

Fig. 2 eine Einzelheit in gleicher Ansicht wie Fig. 1;

Fig. 2 shows a detail in the same view as Fig. 1;

Fig. 3 eine Variante der AusfÃ¼hrungsform gemÃ¤Ã Fig. 2

in Stirnansicht von links gesehen (gemÃ¤Ã Fig. 2). Fig. 3 shows a variant of the embodiment of FIG. 2 seen from the left in front view (according to FIG. 2).

Die Sauggreifvorrichtung zum Anheben und Halten von

WerkstÃ¼cken, beispielsweise flÃ¤chigen StÃ¼ckgÃ¼tern weist

GehÃ¤useteile auf, an welchen ein Saugnapf 1 befestigbar

ist, dessen Innenraum an einen Saugluftkanal 2

angeschlossen ist, der mit einer Unterdruck erzeugenden

Einrichtung verbunden ist. lm Saugluftkanal 2 ist ein

StÃ¶Ãel 3 angeordnet, der bei in der Saugleitung 2

anstehendem Unterdruck aus einer Ruhelage (in

Zeichnungsfigur 1 in durchgezogenen Linien gezeigt) in

eine Arbeitsposition (in Zeichnungsfigur 1 in

gestrichelten Linien gezeigt) verstellbar ist. In der

Arbeitslage ist der StÃ¶Ãel 3 gemÃ¤Ã Zeichnungsfigur 1

nach links verschoben, so daÃ die StÃ¶ÃelstirnflÃ¤che ein

Stellglied, beispielsweise ein Ventil oder auch einen

induktiven NÃ¤herungsschalter betÃ¤tigen kann. Im Falle

der BetÃ¤tigung eines NÃ¤herungsschalters ist in die

StirnflÃ¤che des StÃ¶Ãels eine ferromagnetische Schraube

4 als Geberteil eingebracht, wÃ¤hrend der StÃ¶Ãel 3 nebst

daran befindlichen Teilen aus Kunststoff besteht.

The suction gripping device for lifting and holding workpieces, for example flat piece goods, has housing parts to which a suction cup 1 can be fastened, the interior of which is connected to a suction air duct 2, which is connected to a device generating a vacuum. Arranged in the suction air duct 2 is a plunger 3 which can be adjusted from a rest position (shown in solid lines in drawing figure 1 ) to a working position (shown in broken lines in drawing figure 1 ) when the vacuum is present in the suction line 2 . In the working position, the plunger 3 is shifted to the left according to drawing figure 1 , so that the plunger end face can actuate an actuator, for example a valve or an inductive proximity switch. When a proximity switch is actuated, a ferromagnetic screw 4 is introduced as a transmitter part in the end face of the plunger, while the plunger 3, together with parts located thereon, is made of plastic.

Der StÃ¶Ãel 3 ist einstÃ¼ckig mit einem Kolben 5

ausgebildet, der in einer quer zum Saugluftkanal 2

gerichteten GehÃ¤usebohrung 6, 7 verschieblich angeordnet

ist. Die dem StÃ¶Ãel 3 abgewandte StirnflÃ¤che des Kolbens 5

steht Ã¼ber GehÃ¤useÃ¶ffnungen 8 mit der AuÃenatmosphÃ¤re

in Verbindung, wÃ¤hrend die StirnflÃ¤che des Kolbens 5,

von der der StÃ¶Ãel 3 abragt, mit dem Saugluftkanal 2

in Verbindung steht. Der StÃ¶Ãel 3 ist mit seinem freien

Ende in der GehÃ¤usebohrung 7 gefÃ¼hrt, wobei der StÃ¶Ãel 3

in diesem Bereich LÃ¤ngsnuten aufweist, um einen

Druckausgleich zu schaffen und einen Aufbau eines

Gaspolsters vor der StirnflÃ¤che des StÃ¶Ãels in der

GehÃ¤usekammer zu unterbinden.The plunger 3 is formed in one piece with a piston 5 , which is arranged displaceably in a housing bore 6 , 7 directed transversely to the suction air duct 2 . The end face of the piston 5 facing away from the plunger 3 is connected to the outside atmosphere via housing openings 8 , while the end face of the piston 5 , from which the plunger 3 projects, is connected to the suction air duct 2 . The plunger 3 is guided with its free end in the housing bore 7 , the plunger 3 having longitudinal grooves in this area in order to create a pressure compensation and to prevent the build-up of a gas cushion in front of the end face of the plunger in the housing chamber.

In diese GehÃ¤usebohrung 7 ist bei 9 ein vom StÃ¶Ãel 3

betÃ¤tigbares Stellglied einsetzbar oder vor die MÃ¼ndung

der GehÃ¤usebohrung anschraubbar (dicht), wobei die aus

Kolben 5 und StÃ¶Ãel 3 bestehende Einheit mittels einer

Feder 10 in die Ruhelage gedrÃ¤ngt ist (wie in Fig. 1

in durchgezogenen Linien gezeigt), wÃ¤hrend in der

Arbeitslage der Kolben 5 entgegen der Kraft der Feder 10

nach links verschoben ist.

In this housing bore 7 , an actuator which can be actuated by the plunger 3 can be inserted at 9 or screwed tightly in front of the mouth of the housing bore, the unit consisting of piston 5 and plunger 3 being pushed into the rest position by means of a spring 10 (as in FIG. 1 shown in solid lines), while in the working position the piston 5 is shifted to the left against the force of the spring 10 .

Die die StÃ¶Ãel 3 samt Kolben 5 aufnehmende GehÃ¤useÂ­

kammer 6, 7 verlÃ¤uft quer zum Verlauf des

Saugluftkanales 2, also in der Zeichnungsebene von rechts

nach links, wÃ¤hrend der Saugluftkanal 2 in der

Zeichnungsebene von oben nach unten verlÃ¤uft. Die Ein-

oder AnsatzÃ¶ffnung (bei 9) fÃ¼r das Stellglied ist an

einer GehÃ¤useseitenflÃ¤che 11 frei zugÃ¤nglich ausgebildet,

wÃ¤hrend die EinsatzÃ¶ffnung der GehÃ¤usekammer 6, 7 fÃ¼r

den StÃ¶Ãel 3 samt Kolben 5 auf der dieser (11)

gegenÃ¼berliegenden GehÃ¤useseitenflÃ¤che 12 frei zugÃ¤nglich

ist und mittels einer die Durchgangslochungen 8

aufweisenden VerschluÃplatte 13 verschlossen ist, die

gewindemÃ¤Ãig mit dem die Teile haltenden GehÃ¤useteil 14

verbunden ist. Der Kolben 5 kann mittels einer

reibungsarmen Gleitdichtung gegenÃ¼ber der zylindrischen

Kammerwandung der Kammer 6 abgedichtet sein. Im

AusfÃ¼hrungsbeispiel ist der Kolben 5 gegenÃ¼ber der

EinsatzÃ¶ffnung, die durch die VerschluÃplatte 13

verschlossen ist, durch eine an der Kammerwandung dicht

eingespannte Dichtfolie 15 abgedichtet, die an der

KolbenstirnflÃ¤che anliegt. Die KolbenstirnflÃ¤che ist

durch eine Bohrung 16, 17 mit der GehÃ¤usekammer 6 und

somit mit dem Saugluftkanal 2 in Verbindung, wobei die

Bohrung 16 den Kolben 5 mittig durchsetzt und Ã¼ber die

Bohrung 17 radial aus dem StÃ¶Ãel 3 austritt. Die

KolbenstirnflÃ¤che weist mittig eine flache Vertiefung 18

auf, an die bei anstehender Saugluft im Saugluftkanal 2

die Dichtfolie 15 angelegt ist.The plunger 3 together with the piston 5 accommodating housing chamber 6 , 7 runs transversely to the course of the suction air duct 2 , that is to say in the plane of the drawing from right to left, while the suction air duct 2 runs in the plane of the drawing from top to bottom. The inlet or extension opening (at 9 ) for the actuator is designed to be freely accessible on a housing side surface 11 , while the insertion opening of the housing chamber 6 , 7 for the plunger 3 together with the piston 5 is freely accessible on the housing side surface 12 opposite this ( 11 ) and by means of one of the through-holes 8 has a closure plate 13 which is threadedly connected to the housing part 14 holding the parts. The piston 5 can be sealed against the cylindrical chamber wall of the chamber 6 by means of a low-friction sliding seal. In the exemplary embodiment, the piston 5 is sealed off from the insert opening, which is closed by the closure plate 13 , by a sealing film 15 which is tightly clamped to the chamber wall and bears against the piston end face. The piston end face is connected through a bore 16 , 17 to the housing chamber 6 and thus to the suction air duct 2 , the bore 16 passing through the piston 5 in the center and emerging radially from the plunger 3 via the bore 17 . The center of the piston end face has a flat depression 18 , against which the sealing film 15 is applied when suction air is present in the suction air duct 2 .

Bei auf eine FlÃ¤che aufgesetztem Saugnapf 1 und im

Unterdruckkanal 2 anstehendem Unterdruck legt sich

zunÃ¤chst die Dichtfolie 15 an die flache Vertiefung 18

im Mittelbereich der KolbenstirnflÃ¤che an. Bei

Verschiebung des Kolbens 5 klappt die Dichtfolie dann

in die in der Zeichnungsfigur 1 gestrichelte Position

um. Durch diese Ausbildung wird die bewegungsbedingte

LÃ¤ngenÃ¤nderung der Folie ausgeglichen, da diese sich

im Bereich der Vertiefung 18 ausgleichend an den Kolben

anlegen kann.When the suction cup 1 is placed on a surface and the negative pressure is present in the vacuum channel 2 , the sealing film 15 first contacts the flat recess 18 in the central region of the piston end face. When the piston 5 is displaced, the sealing film then folds over into the position shown in dashed lines in the drawing figure 1 . This configuration compensates for the movement-related change in length of the film, since the film can rest against the piston in the region of the recess 18 .

Die Feder 10 ist im AusfÃ¼hrungsbeispiel durch eine den

StÃ¶Ãel 3 koaxial umgebende Schraubenfeder gebildet, die

sich mit ihrem einen Ende an der Unterseite des Kolbens 5

und mit ihrem anderen Ende an einer GehÃ¤useschulter 19

gemÃ¤Ã AusfÃ¼hrungsbeispiel Fig. 1 abstÃ¼tzt. lm

AusfÃ¼hrungsbeispiel gemÃ¤Ã Fig. 2 stÃ¼tzt sich das Ende

der Feder 10 an einer StÃ¼tzplatte 20 ab, die vom StÃ¶Ãel 3

mit Bewegungsspiel durchgriffen ist. Unter Bezugnahme

auf die Fig. 2 ist ersichtlich, daÃ die StÃ¼tzplatte 20

mittels Stellbolzen 21 oder Stellschrauben 22 unter

zunehmender Vorspannung der Feder 10 zum Kolben 5 hin

verstellbar und in dieser Lage fixierbar ist. Die

Stellbolzen 21 bzw. Stellschrauben 22 sind gleichmÃ¤Ãig

radial verteilt vorgesehen, wobei deren StellkÃ¶pfe

(Schlitz 23) der Schraube 22 durch die MÃ¼ndung der

achsparallel zum StÃ¶Ãel 3 verlaufenden Gewindebohrung 24

zugÃ¤nglich sind. Die MÃ¼ndungen mÃ¼nden aus der

GehÃ¤useseitenflÃ¤che 11 offen aus, an welche auch das

Stellglied (bei 9) ansetzbar ist. Infolge der beengten

RaumverhÃ¤ltnisse und der vorgegebenen MaÃe Ã¼blicher

Stellglieder liegt bei der AusfÃ¼hrungsform gemÃ¤Ã Fig. 2

- obere HÃ¤lfte - vorgesehenen Schraubenanordnung der

Schrauben 2 die MÃ¼ndung der entsprechenden

Gewindebohrungen 24 innerhalb der vom Stellglied belegten

FlÃ¤che, so daÃ die Schrauben 22 bzw. deren

Eingriffsschlitze 23 nur zugÃ¤nglich sind, wenn das

Stellglied abgenommen ist.

In the exemplary embodiment, the spring 10 is formed by a helical spring coaxially surrounding the tappet 3 , which is supported at one end on the underside of the piston 5 and at the other end on a housing shoulder 19 according to the exemplary embodiment in FIG. 1. In the embodiment shown in FIG. 2, the end of the spring 10 is supported on a support plate 20 which is penetrated by the plunger 3 with play. With reference to FIG. 2 it can be seen that the support plate 20 is adjustable by means of adjusting bolts 21 or adjusting screws 22 with increasing prestress of the spring 10 towards the piston 5 and can be fixed in this position. The adjusting bolts 21 or adjusting screws 22 are evenly distributed radially, the adjusting heads (slot 23 ) of the screw 22 being accessible through the mouth of the threaded bore 24 running parallel to the plunger 3 . The mouths open out of the housing side surface 11 , to which the actuator (at 9 ) can also be attached. As a result of the restricted space and the predetermined dimensions of conventional actuators, in the embodiment according to FIG. 2 - upper half - provided screw arrangement of the screws 2, the mouth of the corresponding threaded bores 24 lies within the area occupied by the actuator, so that the screws 22 or their engagement slots 23 are only accessible when the actuator is removed.

Bei der Ausbildung gemÃ¤Ã Fig. 2 unten und Fig. 3 ist

bei ansonsten gleichen RaumverhÃ¤ltnissen die MÃ¼ndung

des Aufnahmekanales exzentrisch nach radial auÃen

erweitert, so daÃ die MÃ¼ndungen mindestens teilweise

auÃerhalb der vom Stellglied belegten FlÃ¤che angeordnet

sind, welche FlÃ¤che in Fig. 3 mit 25 bezeichnet ist.

Die eigentlichen MÃ¼ndungen der Bohrungen 26 in denen

die Bolzen 21 verschieblich angeordnet sind, liegen zwar

innerhalb der von dem Stellglied abgedeckten FlÃ¤che 25,

jedoch gehen die MÃ¼ndungen in exzentrisch angeordnete

Gewindebohrungen 27 Ã¼ber, die nur teilweise in der vom

Stellglied belegten FlÃ¤che 25 liegen. In diese

Gewindebohrungen sind Stellschrauben 28 eingeschraubt,

die in ihrem Kopf Eingriffsschlitze 29 fÃ¼r ein

BetÃ¤tigungswerkzeug aufweisen, von denen mindestens ein

Teilbereich auÃerhalb der vom Stellglied Ã¼berdeckten

FlÃ¤che 25 liegt. Somit sind diese Stellschrauben 28 auch

bei aufgesetztem Stellglied zugÃ¤nglich, so daÃ die

Vorspannnkraft der Feder 10 auch dann eingestellt werden

kann.In the embodiment according to FIG. 2 below and FIG. 3, the mouth of the receiving channel is eccentrically widened radially outwards with otherwise the same spatial conditions, so that the mouths are at least partially arranged outside the surface occupied by the actuator, which surface in FIG. 3 is 25 is designated. The actual openings of the bores 26 in which the bolts 21 are arranged displaceably lie within the surface 25 covered by the actuator, but the openings merge into eccentrically arranged threaded bores 27 which are only partially in the surface 25 occupied by the actuator. Set screws 28 are screwed into these threaded bores and have engagement slots 29 in their head for an actuating tool, at least a portion of which lies outside the surface 25 covered by the actuator. Thus, these adjusting screws 28 are accessible even when the actuator is attached, so that the biasing force of the spring 10 can also be adjusted.

Der Saugluftkanal 2 ist durch eine das GehÃ¤use 14 und

die den StÃ¶Ãel aufnehmende GehÃ¤usekammer 6, 7 mittig

durchsetzende Bohrung gebildet, deren zum StÃ¶Ãel 3

weisende MÃ¼ndungen gemÃ¤Ã AusfÃ¼hrungsbeispiel Fig. 2

exzentrisch in Richtung auf den Kolben erweitert sind.

Die Erweiterungen sind mit 30 bezeichnet. Hierdurch ist

es mÃ¶glich, die StÃ¼tzplatte 20 in Richtung auf den

Kolben 5 mittels der Schrauben 22 oder Bolzen 21 zu

verschieben, ohne daÃ dadurch die MÃ¼ndung des

Saugluftkanales 2 wesentlich eingeengt wird. Die mittige

Anordnung des Saugluftkanales ist aber wegen der engen

EinbauverhÃ¤ltnisse und der KombinationsmÃ¶glichkeit mit

den spÃ¤ter noch beschriebenen Teilen notwendig.The suction air duct 2 is formed by a bore penetrating the housing 14 and the housing chamber 6 , 7 receiving the plunger, the openings of the plunger pointing towards the plunger 3 according to the embodiment of FIG. 2 being eccentrically extended in the direction of the piston. The extensions are labeled 30 . This makes it possible to move the support plate 20 in the direction of the piston 5 by means of the screws 22 or bolts 21 without the mouth of the suction air duct 2 being significantly restricted thereby. The central arrangement of the suction air duct is necessary because of the narrow installation conditions and the possibility of combination with the parts described later.

GemÃ¤Ã AusfÃ¼hrungsbeispiel Fig. 1 ist an das GehÃ¤use 14

auf der dem Saugnapf 1 abgewandten Seite ein etwa

formgleiches zweites GehÃ¤useteil 31 unter ZwischenfÃ¼gung

eines dritten GehÃ¤useteiles 32 dicht angesetzt. Das zweite

GehÃ¤useteil 31 weist einen in den Saugluftkanal 2

mÃ¼ndenden Kanal 2 und quer dazu einen Arbeitskanal 33

mit einer Strahlpumpe mit DÃ¼se 34 auf. Bei Druckaufgabe

in den Kanal 33 (von rechts in der Zeichnungsfigur 1)

wird die im Saugluftkanal 2 befindliche Luft angesaugt

und somit ein Vakuum in dem Kanal 2 erzeugt, wÃ¤hrend

die gesamte Luftmenge in der Zeichnungsfigur 1 links

abflieÃen kann, welche Ãffnung bei 33 mit einem

SchalldÃ¤mpfer oder dergleichen versehen sein kann. Zudem

ist es auch mÃ¶glich, auf das GehÃ¤useteil 31 oberseitig

eine Abdeckplatte anzuordnen. Das zweite GehÃ¤useteil 31

weist ebenso wie alle anderen GehÃ¤useteile parallel zum

Saugluftkanal 2 und koaxial zu den entsprechenden

DurchtrittskanÃ¤len 35 des ersten GehÃ¤useteiles 14

verlaufende DurchtrittskanÃ¤le fÃ¼r Befestigungsmittel

auf. Zwischen das erste GehÃ¤useteil 14 und den Saugnapf 1

ist zudem eine erste GehÃ¤useplatte 36 eingefÃ¼gt, die

eine zum Saugluftkanal 2 koaxiale Durchgangsbohrung

aufweist, in deren dem ersten GehÃ¤use 14 abgewandte

MÃ¼ndung ein Gewindestutzen des Saugnapfes 1 eingeschraubt

ist. Auch dieses GehÃ¤useteil 36 weist wiederum

entsprechende Durchgangsbohrungen 37 fÃ¼r

Befestigungsmittel auf. Zwischen das erste GehÃ¤useteil 14

und das zweite GehÃ¤useteil 31 ist das dritte

GehÃ¤useteil 32 eingefÃ¼gt, welches ein im Saugluftkanal 2

angeordnetes RÃ¼ckschlagventil 38 und ein

SchnellbelÃ¼ftungsventil 39 aufweist, welches von auÃen

betÃ¤tigbar ist.

According to the exemplary embodiment in FIG. 1, an approximately identical second housing part 31 is placed tightly on the housing 14 on the side facing away from the suction cup 1 with the interposition of a third housing part 32 . The second housing part 31 has an opening into the suction air passage 2 channel 2 and transversely thereto, a working channel 33 with a jet pump nozzle 34th When printing job in the channel 33 (from the right in the figure 1) the air in the suction air passage 2 is sucked and thus creates a vacuum in the duct 2, while the total amount of air can flow in the figure 1 on the left, which opening at 33 with a Muffler or the like can be provided. In addition, it is also possible to arrange a cover plate on top of the housing part 31 . The second housing part 31 , like all the other housing parts, has passage channels for fastening means that run parallel to the suction air duct 2 and coaxially with the corresponding passage channels 35 of the first housing part 14 . Between the first housing part 14 and the suction cup 1 , a first housing plate 36 is also inserted, which has a through-bore which is coaxial to the suction air duct 2 and into whose opening facing away from the first housing 14 a threaded connector of the suction cup 1 is screwed. This housing part 36 also has corresponding through bores 37 for fastening means. Between the first housing part 14 and the second housing part 31 , the third housing part 32 is inserted, which has a check valve 38 arranged in the suction air duct 2 and a quick ventilation valve 39 which can be actuated from the outside.

Das dritte GehÃ¤useteil 32 weist dazu einen koaxial zum

Saugluftkanal 2 liegenden Eingang 40 auf, der Ã¼ber eine

Bohrung 41 mit einer Kammer 42 des RÃ¼ckschlagventiles 38

verbunden ist. Am Boden der Kammer 42 ist ein Ventilsitz

ausgebildet, der in einen Abgang 43 zum Saugluftkanal 2

mÃ¼ndet. Dieser ist koaxial zum Eingang 40 aber entgegenÂ­

gesetzt gerichtet angeordnet. Das RÃ¼ckschlagventil 38

besteht im wesentlichen aus einem in eine Querbohrung

eingesetzten Ventiloberteil 44 mit federbelastetem

VentilstÃ¶Ãel 45 und VentilkÃ¶rper 46, der bei am Eingang 40

anstehendem Unterdruck im Saugluftkanal 2 vom Ventilsitz

abgehoben ist, so daÃ der Durchgang von 2 Ã¼ber 40 nach

43 zu 2 offen ist. Bei an dem Saugnapf 1 anstehendem

Unterdruck und am Eingang 40 anstehendem AtmosphÃ¤rendruck

liegt der VentilkÃ¶rper 46, wie in Zeichnungsfigur 1

gezeigt, auf dem Ventilsitz dichtend auf. Es ist somit

nach erzeugtem Vakuum nicht mehr notwendig, die

vakuumerzeugende Einrichtung weiter zu betreiben, sondern

das Vakuum wird selbsttÃ¤tig aufrechterhalten.For this purpose, the third housing part 32 has an inlet 40 lying coaxially to the suction air duct 2 , which is connected via a bore 41 to a chamber 42 of the check valve 38 . At the bottom of the chamber 42 , a valve seat is formed, which opens into an outlet 43 to the suction air duct 2 . This is arranged coaxially to the input 40 but directed in the opposite direction. The check valve 38 consists essentially of an upper valve part 44 inserted into a transverse bore with a spring-loaded valve tappet 45 and valve body 46 , which is lifted off the valve seat when the underpressure in the suction air duct 2 is present at the inlet 40 , so that the passage from 2 to 40 to 43 to 2 is open is. When the vacuum is present at the suction cup 1 and the atmospheric pressure at the inlet 40 , the valve body 46 , as shown in FIG. 1 , lies sealingly on the valve seat. After the vacuum has been generated, it is no longer necessary to continue operating the vacuum-generating device, but the vacuum is automatically maintained.

Der VentilstÃ¶Ãel 45 weist eine Bohrung 47, 48 auf, mittels

derer der Eingang 40 des dritten GehÃ¤useteiles 32 mit

einer Kammer 49 in Verbindung steht, die zwischen

Ventiloberteil 44 und StÃ¶Ãel 45 ausgebildet ist und in

der die auf den StÃ¶Ãel 45 einwirkende SchlieÃfeder

angeordnet ist. Diese Anordnung dient zum Druckausgleich

und zur Vermeidung des Aufbaues eines Gaspolsters

innerhalb der Kammer 49.The valve tappet 45 has a bore 47 , 48 , by means of which the inlet 40 of the third housing part 32 is connected to a chamber 49 which is formed between the valve upper part 44 and the tappet 45 and in which the closing spring acting on the tappet 45 is arranged. This arrangement serves to equalize the pressure and to avoid the build-up of a gas cushion within the chamber 49 .

Die den Ausgang bildende Bohrung 43 des dritten

GehÃ¤useteiles 32 ist Ã¼ber eine Querbohrung 50 mit der

AtmosphÃ¤re verbunden, in welche Bohrung das

SchnellbelÃ¼ftungsventil 39 eingesetzt ist. Das

SchnellbelÃ¼ftungsventil ist in der Zeichnungsfigur 1

in der SchlieÃlage gezeigt, wobei die SchlieÃlage durch

eine SchlieÃfeder erzeugt ist. Mittels einer entgegen

der SchlieÃrichtung aufgebrachten Kraft, beispielsweise

mittels eines DruckluftstoÃes Ã¼ber die auÃenliegende

Ãffnung des SchnellbelÃ¼ftungsventiles 39 kann das Ventil

in die Offenlage Ã¼berfÃ¼hrt und somit der Saugluftkanal 2

belÃ¼ftet werden, um das Vakuum abzubauen.The bore 43 of the third housing part 32 which forms the output is connected to the atmosphere via a transverse bore 50 , into which bore the rapid ventilation valve 39 is inserted. The rapid ventilation valve is shown in the drawing figure 1 in the closed position, the closed position being generated by a closing spring. By means of a force applied counter to the closing direction, for example by means of a compressed air blast via the external opening of the quick ventilation valve 39 , the valve can be brought into the open position and thus the suction air channel 2 can be ventilated in order to release the vacuum.

## Classifications

- B65G47/91
- B65G47/91

## Cited patent documents

- [DE-2248930-A1](https://patents.google.com/patent/DE2248930A1/en) — SEA
- [EP-0220407-B1](https://patents.google.com/patent/EP0220407B1/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
