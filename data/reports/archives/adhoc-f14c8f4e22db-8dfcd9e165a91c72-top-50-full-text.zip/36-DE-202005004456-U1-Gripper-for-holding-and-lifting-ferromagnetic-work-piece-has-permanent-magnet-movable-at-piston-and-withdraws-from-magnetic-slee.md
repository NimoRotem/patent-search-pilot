# 36. Gripper for holding and lifting ferromagnetic work piece, has permanent magnet movable at piston and withdraws from magnetic sleeve to lift workpiece, where magnet is moved by electric drive e.g. servomotor

- **Archive rank:** 36 of 50
- **Publication:** [DE-202005004456-U1](https://patents.google.com/patent/DE202005004456U1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/034802212/publication/DE202005004456U1?q=pn%3DDE202005004456U1)
- **Publication date:** 2005-07-14
- **Filing date:** 2005-03-11
- **Earliest priority:** 2005-03-11
- **Family:** 34802212
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** SCHMALZ J GMBH

## Abstract

The gripper has a permanent magnet (22) fastened at a roll membrane and at a piston using a spring. The magnet is movable at the piston and withdraws from a magnetic sleeve to lift a work piece. An electric drive e.g. servomotor, is arranged for movement of the magnet. A wiper disconnects the magnet from the piston. A resetting device e.g. pneumatic spring, resets the magnet from its deflected position to initial position.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-202005004456-U1/pdf000.png)

![Sketch 1 for DE-202005004456-U1](https://nimo.iptorch.com/refdrawing/DE-202005004456-U1/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-202005004456-U1/pdf001.png)

![Sketch 2 for DE-202005004456-U1](https://nimo.iptorch.com/refdrawing/DE-202005004456-U1/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/DE-202005004456-U1/pdf002.png)

![Sketch 3 for DE-202005004456-U1](https://nimo.iptorch.com/refdrawing/DE-202005004456-U1/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/DE-202005004456-U1/pdf003.png)

![Sketch 4 for DE-202005004456-U1](https://nimo.iptorch.com/refdrawing/DE-202005004456-U1/pdf003.png)

## Claims

### Claim 1 (independent)

Claims (27)

### Claim 2 (independent)

Translated from German

### Claim 3 (independent)

Greifvorrichtung (10) zum Greifen und

### Claim 4 (independent)

Anheben von ferromagnetischen WerkstÃ¼cken (30), mit einem

### Claim 5 (independent)

Magneten (22), dadurch gekennzeichnet, dass der

### Claim 6 (independent)

Magnet (22) in der Greifvorrichtung (10) beweglich

### Claim 7 (independent)

gelagert ist.Gripping device ( 10 ) for gripping and lifting ferromagnetic workpieces ( 30 ), with a magnet ( 22 ), characterized in that the magnet ( 22 ) in the gripping device ( 10 ) is movably mounted.

### Claim 8

Greifvorrichtung nach Anspruch 1, dadurch gekennzeichnet,

### Claim 9 (independent)

dass ein elektrischer Antrieb zum Bewegen des Magneten (22)

### Claim 10

vorgesehen ist.Gripping device according to claim 1, characterized in that an electric drive for moving the magnet ( 22 ) is provided.

### Claim 11

Greifvorrichtung nach Anspruch 2, dadurch gekennzeichnet,

### Claim 12

dass der elektrische Antrieb ein Servomotor ist.Gripping device according to claim 2, characterized in that

### Claim 13 (independent)

that the electric drive is a servomotor.

### Claim 14

Greifvorrichtung nach Anspruch 1, dadurch gekennzeichnet,

### Claim 15 (independent)

dass ein hydraulischer, pneumatischer oder mechanischer Antrieb

### Claim 16

zum Bewegen des Magneten (22) vorgesehen ist.Gripping device according to claim 1, characterized in that a hydraulic, pneumatic or mechanical drive for moving the magnet ( 22 ) is provided.

### Claim 17

Greifvorrichtung nach Anspruch 4, dadurch gekennzeichnet,

### Claim 18 (independent)

dass der mechanische Antrieb ein Gelenkmechanismus oder ein Kniehebel

### Claim 19

ist.Gripping device according to claim 4, characterized in that

### Claim 20 (independent)

that the mechanical drive is a hinge mechanism or a toggle lever

### Claim 21 (independent)

is.

### Claim 22

Greifvorrichtung nach einem der vorhergehenden AnsprÃ¼che, dadurch

### Claim 23 (independent)

gekennzeichnet, dass eine RÃ¼ckstellvorrichtung

### Claim 24 (independent)

fÃ¼r den

### Claim 25

Magneten (22) vorgesehen ist.Gripping device according to one of the preceding claims, characterized in that a return device for the magnet ( 22 ) is provided.

### Claim 26

Greifvorrichtung nach Anspruch 6, dadurch gekennzeichnet,

### Claim 27 (independent)

dass die RÃ¼ckstellvorrichtung

### Claim 28 (independent)

eine pneumatische, magnetische, elektromagnetische oder mechanische

### Claim 29

Feder ist.Gripping device according to claim 6, characterized in that

### Claim 30 (independent)

that the return device

### Claim 31 (independent)

a pneumatic, magnetic, electromagnetic or mechanical

### Claim 32 (independent)

Spring is.

### Claim 33

Greifvorrichtung nach Anspruch 1, dadurch gekennzeichnet,

### Claim 34 (independent)

dass der Antrieb von einem zusÃ¤tzlichen

### Claim 35

Magneten gebildet wird.Gripping device according to claim 1, characterized in that

### Claim 36 (independent)

that the drive of an additional

### Claim 37 (independent)

Magnet is formed.

### Claim 38

Greifvorrichtung nach einem der vorhergehenden AnsprÃ¼che, dadurch

### Claim 39 (independent)

gekennzeichnet, dass der Magnet (22) als HÃ¼lse (20)

### Claim 40 (independent)

ausgebildet ist und einen an der Greifvorrichtung starr abragenden

### Claim 41 (independent)

Kolben (18) umgreift und am Kolben (18) verschieblich

### Claim 42

gelagert ist.Gripping device according to one of the preceding claims, characterized in that the magnet ( 22 ) as a sleeve ( 20 ) is formed and a rigidly projecting on the gripping device piston ( 18 ) and on the piston ( 18 ) is slidably mounted.

### Claim 43

Greifvorrichtung nach einem der vorhergehenden AnsprÃ¼che, dadurch

### Claim 44 (independent)

gekennzeichnet, dass der Magnet (22) verschieblich, verschwenkbar

### Claim 45

oder drehbar gelagert ist.Gripping device according to one of the preceding claims, characterized in that the magnet ( 22 ) is mounted displaceably, pivotably or rotatably.

### Claim 46

Greifvorrichtung nach Anspruch 10, dadurch gekennzeichnet,

### Claim 47 (independent)

dass die Schwenk- oder Drehachse (36, 32) parallel

### Claim 48 (independent)

zur GreifflÃ¤che

### Claim 49

(40) der Greifvorrichtung (10) verlÃ¤uft.Gripping device according to claim 10, characterized in that the pivot or rotation axis ( 36 . 32 ) parallel to the gripping surface ( 40 ) of the gripping device ( 10 ) runs.

### Claim 50

Greifvorrichtung nach Anspruch 1, dadurch gekennzeichnet,

### Claim 51 (independent)

dass der Magnet (22) an einen verkÃ¼rzbaren Faltenbalg (46)

### Claim 52

befestigt ist.Gripping device according to claim 1, characterized in that the magnet ( 22 ) to a shortenable bellows ( 46 ) is attached.

### Claim 53

Greifvorrichtung nach Anspruch 12, dadurch gekennzeichnet,

### Claim 54 (independent)

dass der Faltenbalg (46) aus einem Elastomer oder aus Metall

### Claim 55

besteht.Gripping device according to claim 12, characterized in that the bellows ( 46 ) consists of an elastomer or of metal.

### Claim 56

Greifvorrichtung nach Anspruch 1, dadurch gekennzeichnet,

### Claim 57 (independent)

dass der Magnet (22) an einer Rollmembran (48)

### Claim 58

befestigt ist.Gripping device according to claim 1, characterized in that the magnet ( 22 ) on a rolling membrane ( 48 ) is attached.

### Claim 59

Greifvorrichtung nach Anspruch 1, dadurch gekennzeichnet,

### Claim 60 (independent)

dass der Magnet (22) in einem offenen Zylinder angeordnet

### Claim 61 (independent)

ist und mittels Unterdruck oder Ãberdruck

### Claim 62

bewegt wird.Gripping device according to claim 1, characterized in that the magnet ( 22 ) is arranged in an open cylinder and is moved by means of negative pressure or overpressure.

### Claim 63

Greifvorrichtung nach Anspruch 1, dadurch gekennzeichnet,

### Claim 64 (independent)

dass der Magnet (22) an einem beweglichen Kolben (50)

### Claim 65

befestigt ist.Gripping device according to claim 1, characterized in that the magnet ( 22 ) on a movable piston ( 50 ) is attached.

### Claim 66

Greifvorrichtung nach einem Anspruch 16, dadurch

### Claim 67 (independent)

gekennzeichnet, dass die Anbindung des Magneten (22) an

### Claim 68

den Kolben (50) mittels elastischer Mittel erfolgt.Gripping device according to claim 16, characterized in that the connection of the magnet ( 22 ) on the piston ( 50 ) takes place by means of elastic means.

### Claim 69

Greifvorrichtung nach Anspruch 17, dadurch gekennzeichnet,

### Claim 70

dass das Mittel eine Feder ist.Gripping device according to claim 17, characterized in that

### Claim 71 (independent)

that the agent is a spring.

### Claim 72 (independent)

Greifvorrichtung nach einem der AnsprÃ¼che 16 bis

### Claim 73 (independent)

18, dadurch gekennzeichnet, dass Abstreifer- oder ZurÃ¼ckhaltemittel

### Claim 74 (independent)

(52) vorgesehen sind, die den Magneten (22) vom

### Claim 75

Kolben (50) entfernen.Gripping device according to one of claims 16 to 18, characterized in that scraper or retaining means ( 52 ) are provided, which the magnet ( 22 ) from the piston ( 50 ) remove.

### Claim 76 (independent)

Greifvorrichtung nach einem der AnsprÃ¼che 16 bis

### Claim 77 (independent)

19, dadurch gekennzeichnet, dass der Kolben (50) mit AbdrÃ¼ckstiften

### Claim 78

versehen ist.Gripping device according to one of claims 16 to 19, characterized in that the piston ( 50 ) is provided with AbdrÃ¼ckstiften.

### Claim 79 (independent)

Greifvorrichtung nach einem der AnsprÃ¼che 16 bis

### Claim 80 (independent)

20, dadurch gekennzeichnet, dass der Magnet (22) Ã¼ber eine

### Claim 81

Zugstange (54) am Kolben (50) befestigt ist.Gripping device according to one of claims 16 to 20, characterized in that the magnet ( 22 ) via a pull rod ( 54 ) on the piston ( 50 ) is attached.

### Claim 82 (independent)

Greifvorrichtung nach einem der AnsprÃ¼che 16 bis

### Claim 83 (independent)

21, dadurch gekennzeichnet, dass der Kolben (50) in Transportrichtung

### Claim 84

zweigeteilt ist.Gripping device according to one of claims 16 to 21, characterized in that the piston ( 50 ) is divided into two parts in the direction of transport.

### Claim 85

Greifvorrichtung nach einem Anspruch 22, dadurch

### Claim 86 (independent)

gekennzeichnet, dass zwischen den beiden Kolbenteilen (60, 62)

### Claim 87

eine Trennscheibe (64) eingefÃ¼gt ist.Gripping device according to claim 22, characterized in that between the two piston parts ( 60 . 62 ) a cutting disc ( 64 ) is inserted.

### Claim 88

Greifvorrichtung nach Anspruch 23, dadurch gekennzeichnet,

### Claim 89 (independent)

dass die Trennscheibe (64) lose zwischen den beiden Kolbenteilen

### Claim 90

(60, 62) liegt.Gripping device according to claim 23, characterized in that the cutting disc ( 64 ) loosely between the two piston parts ( 60 . 62 ) lies.

### Claim 91

Greifvorrichtung nach Anspruch 16, dadurch gekennzeichnet,

### Claim 92 (independent)

dass der Kolben (50) einen stirnseitig abragenden Zapfen

### Claim 93 (independent)

(66) aufweist, dass der Magnet (22) vom Zapfen

### Claim 94 (independent)

(66) durchgriffen wird und dass das freie Ende Zapfens

### Claim 95 (independent)

(66) eine Abzugsverhinderung (72) fÃ¼r den Magneten

### Claim 96

(22) aufweist.Gripping device according to claim 16, characterized in that the piston ( 50 ) a front projecting pin ( 66 ), that the magnet ( 22 ) of the pin ( 66 ) and that the free end pin ( 66 ) a deduction prevention ( 72 ) for the magnet ( 22 ) having.

### Claim 97

Greifvorrichtung nach Anspruch 25, dadurch gekennzeichnet,

### Claim 98 (independent)

dass die LÃ¤nge

### Claim 99 (independent)

des Zapfens (66) ein mehrfaches der Dicke des Magneten

### Claim 100

(22) entspricht.Gripping device according to claim 25, characterized in that the length of the pin ( 66 ) a multiple of the thickness of the magnet ( 22 ) corresponds.

### Claim 101

Greifvorrichtung nach Anspruch 26, dadurch gekennzeichnet,

### Claim 102 (independent)

dass das VerhÃ¤ltnis

### Claim 103 (independent)

der LÃ¤nge

### Claim 104 (independent)

des Zapfens (66) zur Dicke des Magneten (22) 2

### Claim 105

bis 5, insbesondere 2,5 bis 4, bevorzugt 3 ist.Gripping device according to claim 26, characterized in that the ratio of the length of the pin ( 66 ) to the thickness of the magnet ( 22 ) 2 to 5, in particular 2.5 to 4, preferably 3.

## Full description

**[p0001]**

PERFORMING OPERATIONS; TRANSPORTINGHAND TOOLS; PORTABLE POWER-DRIVEN TOOLS; MANIPULATORSMANIPULATORS; CHAMBERS PROVIDED WITH MANIPULATION DEVICESGripping heads and other end effectorsGripping heads and other end effectors with vacuum or magnetic holding meansGripping heads and other end effectors with vacuum or magnetic holding means with magnetic holding meansPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating electrostatic or magnetic grippers Description Translated from German Die Erfindung betrifft eine Greifvorrichtung zum Greifen und Anheben

**[p0002]**

von ferromagnetischen WerkstÃ¼cken, mit einem Magneten.The The invention relates to a gripping device for gripping and lifting ferromagnetic workpieces, with a magnet. Derartige Greifvorrichtungen sind in einer Vielzahl bekannt. In der Regel handelt es sich hier um Elektromagnete, die zum Aufbau der Magnetkraft mit Strom versorgt werden mÃ¼ssen, sodass sie die ferromagnetischen WerkstÃ¼cke anziehen kÃ¶nnen.such Gripping devices are known in a variety. Usually these are electromagnets used to build up the magnetic force need to be powered, so they can tighten the ferromagnetic workpieces. Der Erfindung liegt die Aufgabe zugrunde, eine Greifvorrichtung vorzuschlagen, welche weniger Energie benÃ¶tigt.Of the Invention is based on the object to propose a gripping device, which needs less energy. Diese Aufgabe wird erfindungsgemÃ¤Ã mit einer Greifvorrichtung der eingangs genannten Art dadurch gelÃ¶st, dass der Magnet in der Greifvorrichtung beweglich gelagert ist.These Task is according to the invention with a Gripping device of the type mentioned solved in that

**[p0003]**

the magnet is movably mounted in the gripping device. Als Magnet wird ein Permanentmagnet verwendet, und durch die bewegliche Anordnung des Permanentmagneten in der Greifvorrichtung wird die StÃ¤rke des aus der Greifvorrichtung austretenden Magnetfelds des Permanentmagneten gesteuert. FÃ¼r die Bewegung des Magneten innerhalb der Greifvorrichtung bedarf es keiner elektrischer Energie. Ein weiterer Vorteil wird darin gesehen, dass lediglich dann Energie benÃ¶tigt wird, wenn der Magnet von der einen in die andere Position verlagert wird. Das bedeutet, dass das WerkstÃ¼ck ohne Zufuhr von Energie gehalten wird.When Magnet is a permanent magnet used, and by the movable Arrangement of the permanent magnet in the gripping device will increase the strength of the from the gripping device exiting magnetic field of the permanent magnet controlled. For the There is no need to move the magnet inside the gripping device electrical energy. Another advantage is seen in that only then energy needed becomes when the magnet shifts from one to the other position

**[p0004]**

becomes. This means that the workpiece is held without supply of energy becomes. Bei einer Weiterbildung ist vorgesehen, dass ein elektrischer Antrieb zum Bewegen des Magneten vorgesehen ist. Dabei kann der elektrische Antrieb ein Servomotor sein. Da dieser Antrieb sehr klein ausgefÃ¼hrt sein kann, benÃ¶tigt dieser nur sehr wenig Strom.at a development is provided that an electric drive is provided for moving the magnet. In this case, the electric Drive be a servomotor. Since this drive be made very small can, needed this very little power. Es ist jedoch auch denkbar, dass hydraulische, pneumatische oder mechanische Antriebe, insbesondere ein Gelenkmechanismus oder ein Kniehebel zum Bewegen des Magneten vorgesehen ist.It However, it is also conceivable that hydraulic, pneumatic or mechanical Drives, in particular a hinge mechanism or a toggle lever is provided for moving the magnet. Um den Magneten aus der ausgelenkten Lage wieder in die Ausgangslage zurÃ¼ckzustellen, ist eine RÃ¼ckstellvorrichtung fÃ¼r den Magneten

**[p0005]**

vorgesehen. Diese RÃ¼ckstellvorrichtung ist zum Beispiel eine pneumatische, magnetische, elektromagnetische oder mechanische Feder, insbesondere eine Zug- oder Druckfeder.Around the magnet from the deflected position back to the starting position reset, is a reset device for the magnet intended. This return device is for example a pneumatic, magnetic, electromagnetic or mechanical spring, in particular a tension or compression spring. Es ist auch denkbar, dass der Antrieb von einem zusÃ¤tzlichen Magneten gebildet wird.It It is also conceivable that the drive is formed by an additional magnet becomes. Bei einer AusfÃ¼hrungsform der Erfindung ist vorgesehen, dass der Magnet als HÃ¼lse ausgebildet ist und einen von der Greifvorrichtung starr abragenden Kolben umgreift und am Kolben verschieblich gelagert ist. Beim Bewegen des Magneten tritt der Kolben aus der magnetischen HÃ¼lse aus, wodurch das WerkstÃ¼ck abgestreift werden kann.at an embodiment The invention provides that the magnet is designed as a sleeve and surrounds a piston projecting rigidly from the gripping device

**[p0006]**

and is displaceably mounted on the piston. When moving the magnet The piston exits the magnetic sleeve, whereby the workpiece stripped off can be. Im Allgemeinen ist der Magnet verschieblich, verschwenkbar oder drehbar gelagert. Dabei kann die Schwenk- oder Drehachse parallel zur GreifflÃ¤che der Greifvorrichtung verlaufen. Dadurch wird der Magnet entweder hin zur oder weg von der GreifflÃ¤che verschwenkt.in the In general, the magnet is displaceable, pivotable or rotatable stored. In this case, the pivot or rotation axis parallel to the gripping surface of the Gripping device run. This will either put the magnet down pivoted to or away from the gripping surface. Eine andere AusfÃ¼hrungsform sieht vor, dass der Magnet an einem verkÃ¼rzbaren Faltenbalg, welcher aus einem Elastomer oder aus Metall besteht, befestigt ist. Der Magnet kann aber auch an einer Rollmembran befestigt sein.A other embodiment provides that the magnet on a shortenable bellows, which is made of an elastomer or of metal, is attached. Of the

**[p0007]**

Magnet can also be attached to a rolling membrane. Eine wiederum andere AusfÃ¼hrungsform sieht vor, dass der Magnet in einem offenen Zylinder angeordnet ist und mittels Unterdruck oder Ãberdruck bewegt wird.A in turn sees another embodiment before that the magnet is arranged in an open cylinder and by means of negative pressure or overpressure is moved. Der Magnet kann aber auch an einem beweglichen Kolben befestigt sein, wobei die Anbindung des Magneten an den Kolben zum Beispiel mittels elastischer Mittel erfolgt. Das elastische Mittel kann zum Beispiel eine Feder sein. Ferner sind bei einer Weiterbildung Abstreifer- oder ZurÃ¼ckhaltemittel vorgesehen, die den Magneten vom Kolben entfernen. AuÃerdem oder Alternativ kann der Kolben mit AbdrÃ¼ckstiften versehen sein.Of the Magnet can also be attached to a movable piston, wherein the connection of the magnet to the piston, for example by means of elastic means takes place. The elastic means may, for example to be a spring. Furthermore, in a further development scraper

**[p0008]**

or restraint means provided which remove the magnet from the piston. In addition or Alternatively, the piston can be provided with AbdrÃ¼ckstiften. Bei einem AusfÃ¼hrungsbeispiel ist der Magnet Ã¼ber eine Zugstange am Kolben befestigt.at an embodiment is the magnet over a pull rod attached to the piston. Eine wiederum andere AusfÃ¼hrungsform sieht vor, dass der Kolben in Transportrichtung zweigeteilt ist, wobei zwischen den beiden Kolbenteilen eine Trennscheibe, insbesondere lose eingefÃ¼gt ist.A in turn sees another embodiment before that the piston is divided into two parts in the transport direction, wherein between the two piston parts a cutting disc, in particular inserted loosely is. Eine Variante sieht vor, dass der Kolben einen stirnseitig abragenden Zapfen aufweist, dass der Magnet vom Zapfen durchgriffen wird und dass das freie Ende des Zapfens eine Abzugsverhinderung fÃ¼r den Magneten aufweist. Dabei kann die LÃ¤nge des Zapfens ein mehrfaches der Dicke des Magneten entsprechen. Insbesondere ist das VerhÃ¤ltnis

**[p0009]**

der LÃ¤nge des Zapfens zur Dicke des Magneten 2 bis 5, insbesondere 2,5 bis 4 und bevorzugt 3.A Variant provides that the piston projecting an end face Pin has that the magnet is penetrated by the pin and that the free end of the pin a deduction prevention for the magnet having. The length can be of the pin correspond to a multiple of the thickness of the magnet. Especially is the relationship the length of the pin to the thickness of the magnet 2 to 5, in particular 2.5 to 4 and preferably 3. Weitere Vorteile, Merkmale und Einzelheiten der Erfindung ergeben sich aus den UnteransprÃ¼chen sowie der nachfolgenden Beschreibung, in der unter Bezugnahme auf die Zeichnung mehrere AusfÃ¼hrungsbeispiele beschrieben sind. Dabei kÃ¶nnen die in der Zeichnung dargestellten sowie in der Beschreibung und in den AnsprÃ¼chen erwÃ¤hnten Merkmale jeweils einzeln fÃ¼r sich oder in beliebiger Kombination erfindungswesentlich sein.Further Advantages, features and details of the invention will become apparent the dependent claims as well as the following description, with reference to FIG

**[p0010]**

the drawing several embodiments are described. The can represented in the drawing as well as in the description and in the claims mentioned Features individually for each itself or in any combination essential to the invention. In der 1 ist eine insgesamt mit 10 bezeichnete Greifvorrichtung dargestellt, die ein GehÃ¤use 12 aufweist, in deren Innenraum von einer Decke 14 an einer Kolbenstange 16 ein Kolben 18 abragt. Der Kolben 18 ist von einer HÃ¼lse 20 umfasst, welche lÃ¤ngsverschieblich im GehÃ¤use 12 gefÃ¼hrt ist. Die HÃ¼lse 20 wird von einem Magneten 22 gebildet. Wird der Zylinderraum 24 mit einem Ãberdruck beaufschlagt, dann wird die HÃ¼lse 20 aus dem GehÃ¤use 12 in Richtung des Pfeils 26 ausgeschoben. Wird der Zylinderraum 24 mit einem Unterdruck beaufschlagt, dann wird der Magnet 22 in das GehÃ¤use 12 eingezogen. Die Stirnseite 28 des GehÃ¤uses 12 dient dabei als Abstreifer fÃ¼r am Magnet anhaftende WerkstÃ¼cke 30.In the 1 is a total with 10 designated gripping device shown, which is a housing 12 has, in the interior of a ceiling 14 on a piston rod 16 a piston 18 protrudes. The piston 18 is from a sleeve 20 includes, which longitudinally displaceable in the housing 12 is guided. The sleeve 20 is from a magnet 22 educated. Will the cylinder space 24 applied with an overpressure, then the sleeve 20 out of the case 12 in the direction of the arrow 26 ejected. Will the cylinder space 24 subjected to a vacuum, then the magnet 22 in the case 12 moved in. The front side 28 of the housing 12 serves as a scraper for adhering to the magnet workpieces 30 ,

**[p0011]**

Die 2 zeigt eine AusfÃ¼hrungsform, bei welcher der Magnet 22 ebenfalls in einem GehÃ¤use 12 angeordnet ist. Er ist jedoch um eine Drehachse 32 in Richtung des Pfeils 34 drehbar gelagert. Auf diese Weise kÃ¶nnen die MagnetkrÃ¤fte verÃ¤ndert werden.The 2 shows an embodiment in which the magnet 22 also in a housing 12 is arranged. He is, however, about a rotation axis 32 in the direction of the arrow 34 rotatably mounted. In this way, the magnetic forces can be changed. Beim AusfÃ¼hrungsbeispiel der 3 ist der Magnet 22 ebenfalls in einem GehÃ¤use 12 gelagert, und besitzt eine Schwenkachse 36, die auÃermittig angeordnet ist, sodass der Magnet 22 in Richtung des Pfeils 38 verschwenkt bzw. geklappt werden kann. Sowohl die Drehachse 32 als auch die Schwenkachse 36 verlaufen parallel zu einer mit 40 bezeichneten GreifflÃ¤che.In the embodiment of 3 is the magnet 22 also in a housing 12 stored, and has a pivot axis 36 , which is arranged off-center, so the magnet 22 in the direction of the arrow 38 can be pivoted or folded. Both the rotation axis 32 as well as the pivot axis 36 run parallel to one with 40 designated gripping surface.

**[p0012]**

Beim AusfÃ¼hrungsbeispiel der 4 wird ein offenes GehÃ¤use 12 verwendet, in welchem der Magnet 22 dadurch verschoben wird, dass an der Unterseite des Magneten 22 Ã¼ber eine geeignete Leitung 42 entweder ein Unterdruck oder ein Ãberdruck bereit gestellt wird.In the embodiment of 4 becomes an open case 12 used in which the magnet 22 is moved by that at the bottom of the magnet 22 via a suitable line 42 either a negative pressure or an overpressure is provided. Beim AusfÃ¼hrungsbeispiel der 5 ist der Magnet 22 ebenfalls in einem GehÃ¤use 12 lÃ¤ngsverschieblich in Richtung des Pfeils 44 gelagert und am Magnet 22 ist ein Faltenbalg 46 befestigt, welcher mit Ãberdruck oder mit Unterdruck beaufschlagt werden kann.In the embodiment of 5 is the magnet 22 also in a housing 12 longitudinally displaceable in the direction of the arrow 44 stored and at the magnet 22 is a bellows 46 attached, which can be subjected to pressure or negative pressure. Beim AusfÃ¼hrungsbeispiel der 6 ist am Magnet 22 eine Rollmembran 48 befestigt, Ã¼ber welche

**[p0013]**

der Magnet 22 in Richtung des Pfeils 44 bewegt wird.In the embodiment of 6 is at the magnet 22 a rolling membrane 48 attached, over which the magnet 22 in the direction of the arrow 44 is moved. Die 7 zeigt ein AusfÃ¼hrungsbeispiel, bei welchem der Magnet 22 vom Kolben 50 trennbar ist und dabei der Kolben 50 an einem Abstreiferbund 52 entlang gleitet.The 7 shows an embodiment in which the magnet 22 from the piston 50 is separable while the piston 50 on a scraper collar 52 along slides. Die 8 zeigt ein AusfÃ¼hrungsbeispiel, bei welchem der Magnet 22 Ã¼ber einen StÃ¶Ãel 54 am Kolben 50 befestigt ist und im Zylinderraum 56 bzw. 58 Ãberdruck oder Unterdruck angelegt werden kann. Die Stirnseite 28, die ebenfalls als GreifflÃ¤che dient, wirkt dabei ebenfalls als AbstreifflÃ¤che.The 8th shows an embodiment in which the magnet 22 over a pestle 54 on the piston 50 is attached and in the cylinder room 56 respectively. 58 Overpressure or negative pressure can be applied. The front side 28 , which also serves as a gripping surface, also acts as a scraper surface.

**[p0014]**

Beim AusfÃ¼hrungsbeispiel der 9 ist der Kolben 50 in zwei Kolbenteile 60 und 62 aufgeteilt, die axial hintereinander angeordnet sind. Zwischen den beiden Kolbenteilen 60 und 62 befindet sich eine lose Scheibe 64, die zum Beispiel aus Kunststoff besteht. Unterhalb des Kolbens 50 befindet sich der Magnet 22.In the embodiment of 9 is the piston 50 in two piston parts 60 and 62 split, which are arranged axially one behind the other. Between the two parts of the piston 60 and 62 there is a loose disc 64 , which is made of plastic, for example. Below the piston 50 is the magnet 22 , Beim AusfÃ¼hrungsbeispiel der 10 weist der Kolben 50 einen Zapfen 66 auf, der von einer KolbenflÃ¤che 68 abragt. Das freie Ende des Zapfens 66 ist mit einer Scheibe 70 versehen, die als Abzugsverhinderung 72 dient. Auf dem Zapfen 66 ist der Magnet 22 verschieblich gelagert, wobei er zwischen der KolbenflÃ¤che 68 und der Abzugsverhinderung 72 verschoben werden kann. Am Kolben 50 wirken Ãberdruck- oder UnterdruckkrÃ¤fte.In the embodiment of 10 points the piston 50 a pin 66 on top of a piston surface 68 protrudes. The free end of the pin 66 is with a disc 70 provided as deduction prevention 72 serves. On the cone 66 is the magnet 22 slidably mounted, passing between the piston surface 68 and the deduction prevention 72 can be moved. On the piston 50 act positive pressure or negative pressure forces.

## Classifications

- B25J15/0608
- B25J15/0608
- B25J15/06
- B25J15/06
- B65G47/92
- B65G47/92
- B65G47/92
- B65G47/92

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
