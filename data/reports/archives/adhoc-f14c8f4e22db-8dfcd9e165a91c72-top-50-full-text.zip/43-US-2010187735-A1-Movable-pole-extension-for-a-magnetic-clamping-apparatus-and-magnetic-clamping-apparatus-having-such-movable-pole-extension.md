# 43. Movable pole extension for a magnetic clamping apparatus and magnetic clamping apparatus having such movable pole extension

- **Archive rank:** 43 of 50
- **Publication:** [US-2010187735-A1](https://patents.google.com/patent/US20100187735A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/039865067/publication/US20100187735A1?q=pn%3DUS20100187735A1)
- **Publication date:** 2010-07-29
- **Filing date:** 2008-05-29
- **Earliest priority:** 2007-07-06
- **Family:** 39865067
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery

## Parties

- **Applicant / assignee:** CARDONE MICHELE; COSMAI GIOVANNI; FARANDA ROBERTO; GIGLIO ANTONINO
- **Inventors:** CARDONE MICHELE; COSMAI GIOVANNI; FARANDA ROBERTO; GIGLIO ANTONINO

## Abstract

The present invention relates to a movable pole extension ( 4 ) for a magnetic clamping apparatus ( 1 ) for holding a ferromagnetic workpiece (P), comprising a fixed pole member ( 5 ) extending in a predetermined longitudinal direction (X-X) and at least two pole members ( 6, 7 ) attached to said fixed pole member ( 5 ), said at least two pole members ( 6, 7 ) being movable relative to said fixed pole member ( 5 ). The movable pole extension is characterized in that it has holder means ( 8 ) operably coupled to said fixed pole member ( 5 ), wherein said holder means ( 8 ) are movable in said predetermined longitudinal direction (X-X) between a first operating position (P 1 ) and a second operating position (P 2 ) and operate on said at least two movable pole members ( 6, 7 ) to hold them in coupled contact with said fixed pole member ( 5 ).

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/a4/29/fe/00456deb947e57/US20100187735A1-20100729-D00000.png)

![Sketch 1 for US-2010187735-A1](https://patentimages.storage.googleapis.com/a4/29/fe/00456deb947e57/US20100187735A1-20100729-D00000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/10/24/44/c06c0b96c474fa/US20100187735A1-20100729-D00001.png)

![Sketch 2 for US-2010187735-A1](https://patentimages.storage.googleapis.com/10/24/44/c06c0b96c474fa/US20100187735A1-20100729-D00001.png)

[Sketch 3](https://patentimages.storage.googleapis.com/c0/d4/04/25443bc96a3c74/US20100187735A1-20100729-D00002.png)

![Sketch 3 for US-2010187735-A1](https://patentimages.storage.googleapis.com/c0/d4/04/25443bc96a3c74/US20100187735A1-20100729-D00002.png)

[Sketch 4](https://patentimages.storage.googleapis.com/4b/ed/0d/4a6511e9302fde/US20100187735A1-20100729-D00003.png)

![Sketch 4 for US-2010187735-A1](https://patentimages.storage.googleapis.com/4b/ed/0d/4a6511e9302fde/US20100187735A1-20100729-D00003.png)

[Sketch 5](https://patentimages.storage.googleapis.com/a6/de/8d/9087de647cfae6/US20100187735A1-20100729-D00004.png)

![Sketch 5 for US-2010187735-A1](https://patentimages.storage.googleapis.com/a6/de/8d/9087de647cfae6/US20100187735A1-20100729-D00004.png)

[Sketch 6](https://patentimages.storage.googleapis.com/70/9c/25/f4cb5b5d4b42b1/US20100187735A1-20100729-D00005.png)

![Sketch 6 for US-2010187735-A1](https://patentimages.storage.googleapis.com/70/9c/25/f4cb5b5d4b42b1/US20100187735A1-20100729-D00005.png)

[Sketch 7](https://patentimages.storage.googleapis.com/3b/c3/d0/a74fc1df4c7f70/US20100187735A1-20100729-D00006.png)

![Sketch 7 for US-2010187735-A1](https://patentimages.storage.googleapis.com/3b/c3/d0/a74fc1df4c7f70/US20100187735A1-20100729-D00006.png)

[Sketch 8](https://patentimages.storage.googleapis.com/e0/82/65/967d1b02f2d08b/US20100187735A1-20100729-D00007.png)

![Sketch 8 for US-2010187735-A1](https://patentimages.storage.googleapis.com/e0/82/65/967d1b02f2d08b/US20100187735A1-20100729-D00007.png)

## Claims

### Claim 21 (independent)

A movable pole extension for a magnetic clamping apparatus ( 1 ) for holding a ferromagnetic workpiece (P), comprising: a fixed pole member ( 5 ) extending in a predetermined longitudinal direction (X-X) and at least two pole members ( 6 , 7 ) coupled to said fixed pole member ( 5 ), said at least two pole members ( 6 , 7 ) being movable relative to said fixed pole member ( 5 ), characterized in that it comprises holder means ( 8 ) operably coupled to said fixed pole member ( 5 ), wherein said holder means ( 8 ): are movable in said predetermined longitudinal direction (X-X) between a first operating position (P 1 ) and a second operating position (P 2 ) and operate on said at least two movable pole members ( 6 , 7 ) to hold them in mating contact with said fixed pole member ( 5 ).

### Claim 22

A movable pole extension as claimed in claim 21 , wherein said at least two movable pole members ( 6 , 7 ) are each movable in different directions relative to said predetermined longitudinal direction (X-X).

### Claim 23

A movable pole extension as claimed in claim 21 , wherein said holder means ( 8 ) include a hollow member ( 9 ) in slideable mating relationship with said fixed pole member ( 5 ), said hollow member ( 9 ) being able to hold at least one portion ( 5 A) of said fixed pole member ( 5 ) by a form fit between complementary profiles.

### Claim 24

A movable pole extension as claimed in claim 23 , wherein said hollow member ( 9 ) comprises an end wall ( 9 A) with side walls ( 9 B) extending therefrom in said longitudinal direction (X-X) to contain said at least one portion ( 5 A) of said fixed pole member ( 5 ).

### Claim 25

A movable pole extension as claimed in claim 21 , characterized in that it has abutment means ( 10 ) for urging said holder means ( 8 ) to slide in said longitudinal direction (X-X) between said first operating position (P 1 ) and said second operating position (P 2 ), thereby limiting the stroke of said holder means ( 8 ) relative to said fixed pole member ( 5 ).

### Claim 26

A movable pole extension as claimed in claim 21 , wherein said fixed pole member ( 5 ) has a receptacle ( 11 ) that defines at least two curved surfaces ( 12 , 13 ) relative to said predetermined longitudinal direction (X-X) and a bottom ( 14 ), said at least two movable pole members ( 6 , 7 ) being each in slideable mating contact with one respective surface of said at least two surfaces ( 12 , 13 ).

### Claim 27

A movable pole extension as claimed in claim 26 , wherein said at least two curves surfaces ( 12 , 13 ) are oriented in opposite directions, converging towards said bottom ( 14 ).

### Claim 28

A movable pole extension as claimed in claim 27 , wherein said at least two curves surfaces ( 12 , 13 ) are second order algebraic surfaces.

### Claim 29

A movable pole extension as claimed in claim 28 , wherein said at least two second order algebraic surfaces ( 12 , 13 ) are substantially cylindrical.

### Claim 30

A movable pole extension as claimed in claim 21 , characterized in that it comprises elastic means ( 17 ) operating on said two movable pole members ( 6 , 7 ) for holding said at least two movable pole members ( 6 , 7 ) in contact with said fixed pole member ( 5 ).

### Claim 31

A movable pole extension as claimed in claim 130 wherein said elastic means ( 17 ) include at least one spring interposed between said at least two movable pole members ( 6 , 7 ) and said fixed pole member ( 5 ).

### Claim 32

A movable pole extension as claimed in claim 25 , wherein said fixed pole member ( 5 ) has at least two planar surfaces inclined to said predetermined longitudinal direction (X-X), said at least two movable pole members ( 6 , 7 ) being each in slideable mating contact with one respective inclined surface of said fixed pole member.

### Claim 33

A movable pole extension as claimed in claim 32 , wherein said at least two surfaces ( 12 A, 12 B, 13 A, 13 B) define respective sliding surfaces ( 12 A, 13 A) for said at least two movable pole members ( 6 , 7 ), said respective surfaces ( 12 , 13 A) being oriented in opposite directions.

### Claim 34

A movable pole extension as claimed in claim 33 , wherein each of said respective surfaces ( 12 A, 12 B, 13 A, 13 B) forms an angle of 40° to 50°, preferably 45°, relative to said predetermined longitudinal direction (X-X).

### Claim 35

A movable pole extension as claimed in claim 32 , characterized in that it comprises elastic means ( 17 ) operating on two movable pole members ( 6 , 7 ) for holding said at least two movable pole members ( 6 , 7 ) in contact with said fixed pole member ( 5 ).

### Claim 36

A movable pole extension as claimed in claim 21 , wherein said fixed pole member ( 5 ) has fastener means ( 15 ) for fixation thereof to said clamping plate ( 2 ) of said magnetic clamping apparatus ( 1 ).

### Claim 37

A movable pole extension as claimed in claim 21 , wherein said holder means ( 8 ) and said fixed pole member ( 5 ) have a circular plan shape.

### Claim 38

A movable pole extension as claimed claim 21 , wherein said holder means ( 8 ) and said fixed pole member ( 5 ) have a polygonal or elliptic plan shape or a polygonal shape with rounded corners.

### Claim 39 (independent)

A magnetic clamping apparatus comprising a frame adapted to contain a plurality of pole pieces, each of said plurality of pole pieces having a ferromagnetic pole member which defines a clamping surface, characterized in that at least one of said plurality of pole pieces is designed to be associated to a movable pole extension ( 4 ), said movable pole extension ( 4 ) comprising: a fixed pole member ( 5 ) extending in a predetermined longitudinal direction (X-X) and at least two pole members ( 6 , 7 ) coupled to said fixed pole member ( 5 ), said at least two pole members ( 6 , 7 ) being movable relative to said fixed pole member ( 5 ), wherein said holder means ( 8 ) operably coupled to said fixed pole member ( 5 ), wherein said holder means ( 8 ): are movable in said predetermined longitudinal direction (X-X) between a first operating position (P 1 ) and a second operating position (P 2 ) and operate on said at least two movable pole members ( 6 , 7 ) to hold them in mating contact with said fixed pole member ( 5 ).

### Claim 40

A magnetic clamping apparatus as claimed in claim 19 wherein, when said magnetic apparatus is activated, said holder means ( 8 ) for sad movable pole extension ( 4 ) at least partly act as a collector for the magnetic flux generated by said magnetic apparatus ( 1 ).

## Full description

**[p0001]**

The present invention relates to a movable pole extension for a magnetic clamping apparatus and a magnetic clamping apparatus having such movable pole extension as defined in the preambles of claims 1 and 19 respectively. As used herein, the term magnetic clamping apparatus is intended to indicate: a permanent-magnet apparatus, i.e. an apparatus that does not require any power supply when used for clamping or for changing its state from active to inactive and vice versa, and is formed with permanent magnets in appropriate arrangement within the apparatus; an electro-permanent apparatus, i.e. an apparatus that does not require any power supply when used for clamping and requires power supply when it is activated and inactivated, and is formed with reversible permanent magnets and, if needed, with static permanent magnets in appropriate arrangement within the apparatus; an electromagnetic apparatus, i.e. an apparatus that requires power supply when used for clamping, whose magnetic core is made of ferromagnetic material.

**[p0002]**

Magnetic apparatus for clamping ferromagnetic workpieces are known to be required to clamp the workpiece without subjecting it to deformation either during machining and during activation of the apparatus. Particularly, a deformation problem arises each time that the workpiece does not perfectly adhere against the clamping surface of the magnetic apparatus. In most cases, workpieces are subjected to elastic deformation during clamping, due to the high force exerted by the magnetic apparatus and tend to recover their original shape as they are released therefrom, thereby impairing machining accuracy. In an attempt to obviate the above drawback, movable pole extensions have been introduced, which can limit workpiece deformation by allowing the magnetic clamping surface to adapt to the workpiece. An example of such movable pole extensions is disclosed in the Italian patent IT 1222875, by the applicant hereof, which is wholly incorporated herein by reference to describe the technical and operational features of a movable pole extension of the prior art.

**[p0003]**

In view of the present disclosure it shall be recalled, also with reference to FIG. 1 , which shows a side view of a pole extension of the prior art, that the inclination of the sliding surface 716 allows the movable part 715 to be displaced partly in the direction of the axis of the fixed part 714 , i.e. orthogonal to the reference surface of the apparatus and partly lateral to the movable part 715 itself. Once the magnetic apparatus (not shown in this figure) is activated, the movable parts of the pole extensions 713 will conform to the shape of the workpiece (not shown in this figure) and be magnetically locked in their position, thereby preventing any vertical or horizontal displacement of the workpiece. This occurs both due to the considerable magnetic attractive force between the fixed part 714 and the movable part 715 , exerted by the magnetic apparatus and due to the joint and combined action of the various sliding surfaces of the extensions, when these are arranged opposite to each other.

**[p0004]**

Nonetheless, while the movable pole extensions as disclosed in the above mentioned patent IT 1222875 provide undisputable advantages, they still suffer from certain drawbacks, such as the following: part of the magnetic flux leaks from the pole extension as the magnetic apparatus is activated; the sliding displacement of two complementary parts over an inclined surface, e.g. having a 45° inclination, reduces the contact area between the movable and fixed parts of the pole extension as the stroke increases and reduces the amount of magnetic flux that can be used for workpiece clamping; the sliding motion of the movable member of the pole extension over an inclined surface, e.g. having a 45° inclination, may interfere with other workpieces lying on the clamping plate; the provision of one inclined surface for each pole extension, e.g. having a 45° inclination, requires the pole extensions to be suitably oriented in view of opposing the various sliding surfaces, and this involves that the direction of the inclined surface of a movable pole extension relative to the direction of the surface of the adjacent movable pole extension shall be accounted for; the fixation of the movable pole extension to the magnetic plate is complex and time-consuming, requiring holes to be formed in the extension, as well as a given number of steps for fastening the movable pole extension to the magnetic plate, which increases manufacturing costs; the use of movable pole extensions with an inclined surface, e.g. having a 45° inclination, requires pole extensions to be of greater height, under the sa

**[p0004]**

me magnetic pole member size conditions.

**[p0005]**

In view of the above prior art, the object of the present invention is to obviate the above mentioned drawbacks of prior art pole extensions. According to the present invention, this object is fulfilled by a movable pole extension for a magnetic clamping apparatus and a magnetic clamping apparatus having such movable pole extension as defined in the preambles of claims 1 and 18 respectively. The present invention provides a movable pole extension for use in magnetic clamping apparatuses for holding workpieces to be machined and/or lifted, that can automatically conform to the area of the workpieces to be clamped, while allowing extensive magnetic flux circulation, to minimize leakages and ensure firm workpiece holding. Particularly, the present invention allows removal of the gaps between the movable pole extension and the workpiece, thereby optimizing magnetic flux circulation, and achieving up to 40% increase of the clamping force as compared with a traditional movable extension of equal size.

**[p0006]**

Furthermore, with the present invention mutual orientation of the movable pole extensions is no longer required. The inventive features of the movable pole extensions also prevent any ingress of dirt, such as chips, etc. and consequent operation impairment. The movable pole extension of the present invention has a smaller height dimension than pole extensions formed with a inclined surface, which increases their versatility. Also, their circular conformation greatly simplifies fixation of the movable pole extension to the clamping plate of the magnetic apparatus, by avoiding the use of specific tools for fastening the extension to the plate. The characteristics and advantages of the invention will appear from the following detailed description of one practical embodiment, which is illustrated without limitation in the annexed drawings, in which: FIG. 1 is a side view of a prior art movable pole extension; FIG. 2 is a perspective view of a magnetic clamping apparatus having pole extensions as disclosed in the present invention;

**[p0007]**

FIGS. 3 and 4 are exploded views of a first embodiment of a movable pole extension as disclosed in the present invention; FIG. 5A is a top plan view of the movable pole extension of FIGS. 3 and 4 ; FIGS. 5B and 5C are respective sectional views of the movable pole extension taken along line I-I of FIG. 5A , particularly FIG. 5B with the movable pole extension in a first operating position and FIG. 5C with the movable pole extension in a second operating position; FIGS. 6A and 6B are a top plan view and a sectional view taken along line II-II of FIG. 6A respectively of a second embodiment of the movable pole extension of the present invention; FIG. 7A is a top plan view of a third embodiment of a movable pole extension of the present invention; FIGS. 7B and 7C are respective sectional views of the movable pole extension taken along line of FIG. 7A , particularly FIG. 7B with the movable pole extension in a first operating position and FIG. 7C with the movable pole extension in a second operating position.

**[p0008]**

Referring now to FIG. 2 , there is shown a perspective view of a magnetic clamping apparatus 1 , such as an electro-permanent apparatus as mentioned above, whose operation is well known to those of ordinary skill in the art and will not be further described herein. This magnetic clamping apparatus 1 has a magnetic surface defined by a clamping plate 2 . This clamping plate 2 is equipped with a plurality of pole pieces 3 , e.g. having a square section, which are activated and inactivated by a magnetic circuit that is known in the art and will not be further described herein. Certain pole pieces 3 A of this plurality of pole pieces 3 may be mechanically associated with respective movable pole extensions 4 , as explained in greater detail hereinbefore. Each movable pole extension 4 allows support and clamping of a ferromagnetic workpiece P which shall be, for instance, submitted to mechanical machining (not shown) by a machine tool, such as a miller or similar machines. As shown in FIGS. 3 to 7C , each movable pole extension 4 comprises:

**[p0009]**

a fixed pole member 5 extending in a predetermined longitudinal direction X-X, at least two pole members 6 and 7 coupled to said fixed pole member 5 , where the at least two pole members 6 and 7 are movable relative to said fixed pole member and holder means 8 . Particularly, the holder means 8 are movable in said predetermined longitudinal direction X-X between a first operating position P 1 ( FIGS. 4A , 6 A) and a second operating position P 2 ( FIGS. 4B , 6 B). As better explained hereinafter, the holder means 8 and the at least two movable pole members 6 and 7 are movable, between the first operating position P 1 and the second operating position P 2 in various different directions. For example, if the fixed element 5 extends in a longitudinal direction X-X perpendicular to the surface of the clamping plate 2 of the magnetic apparatus 1 , then the holder means 8 for containing each movable pole member 4 may move axially in said longitudinal direction X-X, whereas the at least two movable pole members 6 and 7 may move in directions inclined to said predetermined longitudinal direction X-X, to form a predetermined angle of inclination.

**[p0010]**

In other words, the at least two movable pole members 6 , 7 may move each in directions other than the predetermined longitudinal direction X-X in which said holder means 8 move. The at least two movable members 6 and 7 and the fixed pole member 5 are coupled by a surface contact form fit between complementary profiles. Advantageously, the holder means 8 are operably attached to the fixed pole member 5 . It shall be noted that the holder means 8 operate on said at least two movable pole members 6 and 7 to hold them in mating contact with said fixed pole member 5 . Furthermore, this mating contact provides high magnetic flux circulation, once the magnetic apparatus has been activated, to minimize magnetic leakage while ensuring firm clamping of the workpiece P. Therefore, the holder means 8 define a magnetic surface that is able to move between said first operating position P 1 and said second operating position P 2 and are also able to convey part of the magnetic flux from the magnetic pole member 3 A of the magnetic surface 3 , by acting as magnetic flux collector, to increase the magnetic performance of the movable pole extension 4 .

**[p0011]**

The holder means 8 have the following characteristics: they are movable in said predetermined longitudinal direction X-X between a first operating position P 1 ( FIGS. 4A , 6 A) and a second operating position P 2 ( FIGS. 4B , 6 B); they act as collectors of part of the magnetic flux from the magnetic pole member 3 A of the magnetic surface 3 ; they operate on said at least two movable pole members 6 and 7 to hold them in mating contact with said fixed pole member 5 . In other words, the holder means 8 are movable pole member holder means. Advantageously, the holder means 8 comprise a hollow member 9 in slideable mating relationship with said fixed pole member 5 , said hollow member 9 being able to hold at least one portion 5 A of said fixed pole member 5 by a form fit between complementary profiles, and to contain said at least two movable pole members 6 and 7 . Particularly, the hollow member 9 comprises an end wall 9 A with side walls 9 B extending therefrom in said longitudinal direction X-X to contain said at least one portion 5 A of said fixed pole member 5 .

**[p0012]**

The end wall 9 A, as specially shown in FIGS. 3 and 4 , acts as a bearing surface when the workpiece P lies on the movable pole extension 4 . Otherwise, the end wall 9 A of the hollow member 9 may be formed with such a shape as to mate with the surface of the workpiece P if such workpiece P has a non-planar surface. Abutment means 10 are provided to restrict the stroke of the hollow member 9 relative to the fixed pole member 5 between the first operating position P 1 and the second operating position P 2 , which means consist of a combination of a slot 10 A opening parallel to said longitudinal direction X-X into the outer surface of the fixed pole member 5 and a guide pin 10 B that is designed to slide within the slot 10 A, after passing through a hole 10 C formed in the side wall 9 B of the hollow member 9 , said hole 10 C facing towards said slot 10 A. The abutment means 10 constrain the holder means 8 between the first operating position P 1 and the second operating position P 2 , due to the sliding motion of the guide pin 10 B in the slot 10 A.

**[p0013]**

Particularly, the slot 10 A delimits the top (position P 1 ) and the bottom (position P 2 ) of the stroke covered by the holder means 8 . Those skilled in the art may obviously envisage other types of abutment means that are structurally and/or functionally equivalent to the above mentioned combination of the slot 10 A, the guide pin 10 B and the hole 10 C. It shall be further noted that the bottom of the fixed pole member 5 is equipped with fastener means 15 for mechanical fixation to the magnetic pole member 3 A of the clamping plate 2 of the magnetic apparatus 1 . These fastener means 15 consist, for instance, of a screw 15 A mating with a corresponding threaded hole 16 formed in the pole pieces 3 A of the magnetic apparatus 1 . Those skilled in the art may obviously envisage other types of fastener means that are structurally and/or functionally equivalent to the above mentioned combination of the screw 15 A and threaded hole 16 . The materials that form the fixed pole member 5 , the two pole members 6 and 7 and the holder means 8 are preferably ferromagnetic materials. Referring now to FIGS. 3 to 5C , there is shown a first embodiment of the present inventions, in which the fixed pole member 5 is shown to have a circular plan shape.

**[p0014]**

The holder means 8 also have a circular plan shape and thence can contain at least one portion 5 A of said fixed pole member 5 by form fit between complementary profiles. Here, the holder means 8 consist of a hollow cylindrical container whose end wall 9 A has a flat surface for supporting the ferromagnetic workpieces P, which is parallel to the clamping surface of the magnetic apparatus, and whose side wall 9 B contains at least one portion 5 A of said fixed pole member 5 . The hollow cylindrical container is free to move in the predetermined longitudinal direction X-X between the first operating position P 1 ( FIG. 5A ) and the second operating position P 2 ( FIG. 5B ). Therefore, when the hollow cylindrical container is in the first operating position P 1 , then the movable pole extension 4 will be in the maximum extension state, whereas when the hollow cylindrical container is in the second operating position P 2 , then the movable pole extension 4 is in the minimum extension state.

**[p0015]**

It shall be noted that the holder means 8 may be movable in the longitudinal direction X-X because the fixed pole member 5 has a receptacle 11 that defines at least two surfaces 12 and 13 , which provide a surface contact form fit between complementary profiles with the at least two movable members 6 and 7 . Advantageously, the at least two movable pole members 6 and 7 are in slideable mating contact with one of said at least two surfaces 12 and 13 respectively. This feature minimizes flux leakage and magnetic force reduction caused by the movable pole extension 4 , due to the lack of gaps. It shall be noted that the two surfaces 12 and 13 are preferably oriented in opposite directions and converge towards the bottom 14 . These surfaces may be identified by curved surfaces such as second order algebraic surfaces, also known as quadric surfaces. Particularly, the surfaces 12 and 13 are obtained by special machining to obtain a profile mating the surfaces of the movable pole members 6 and 7 .

**[p0016]**

In this preferred embodiment of the present invention, special machining of the receptacle 11 of the fixed pole member 5 allows the at least two second order algebraic surfaces 12 and 13 to have a substantially cylindrical shape. In this case, also referring to FIGS. 3 and 4 , the generators of these cylindrical surfaces 12 and 13 form an angle of 40° to 50°, preferably of 45° relative to the predetermined longitudinal direction X-X. Therefore, the two cylindrical surfaces 12 and 13 form the receptacle along which the movable pole members 6 and 7 can slide, so that the holder means 8 are also allowed to move between said first operating position P 1 and said second operating position P 2 . In other words, the movable pole members 6 and 7 slide in a direction that is inclined to said longitudinal direction X-X, at an angle of 40° to 50°, preferably 45°, whereas the holder means 8 move orthogonal to the clamping plate 2 between the first operating position P 1 ( FIG. 5A ) and the second operating position P 2

**[p0017]**

( FIG. 5B ). Advantageously, the special embodiment that is shown in the annexed figures provides a movable pole extension of smaller height as compared with prior art extensions, and this increases the useful height of the machine tool. It shall be noted that when the movable pole extension 4 is in the minimum extension state (P 2 ), then the movable pole members 6 and 7 are held within the receptacle 11 formed in the fixed pole member 5 . While two curved surfaces 12 and 13 are only shown herein, it shall be intended that the receptacle 11 may define a plurality of curved surfaces according to special design requirements. As shown in FIGS. 5A , 5 B and 5 C, elastic means 17 are also optionally provided, which operate on the two movable pole members 6 and 7 to hold said two movable pole members 6 and 7 in contact with the two surfaces 12 and 13 of said fixed pole member 5 and to hold the holder means 7 in the first operating position P 1 , i.e. the maximum extension position of the movable pole extension 4 .

**[p0018]**

Particularly, the elastic means 17 include at least one spring interposed between said at least two movable pole members 6 and 7 . In the embodiment as shown in FIGS. 5A , 5 B and 5 C two springs are provided, for better adhesion of the movable members 6 and 7 to the cylindrical surfaces 12 and 13 . In this first embodiment, the abutment means 10 consist of three slots 10 A, opening parallel to said longitudinal direction X-X into the outer surface of the fixed pole member 5 and three respective guide pins 10 B, each sliding in a respective slot 10 A, such pins passing through respective holes 10 C formed in the side wall 9 B of the hollow member 9 , each hole 10 C facing towards its respective slot 10 A. Referring now to FIGS. 6A and 6B , there is shown a second embodiment of the present invention, differing from the first embodiment in that the at least two inclined surfaces 12 A and 13 A of the fixed pole member 5 have different inclinations relative to the predetermined longitudinal direction X-X.

**[p0019]**

Particularly, the two inclined surfaces 12 A and 13 A define respective sliding surfaces for the at least two movable pole members 6 and 7 , each of the latter being in slideable mating contact with a respective surface of said fixed pole member 5 . Advantageously, the respective inclined surfaces 12 A and 13 A are oriented opposite to each other, e.g. each of these respective inclined sliding surfaces forms an angle of 40° to 50°, preferably 45°, relative to said predetermined longitudinal direction X-X. In other words, the movable pole members 6 and 7 slide in a direction that is inclined to said longitudinal direction X-X, at an angle of 40° to 50°, preferably 45°, whereas the holder means 8 move orthogonal to the clamping plate 2 . It shall be noted that, once more in this second embodiment, if elastic means 17 are designed to operate on the two movable pole members 6 and 7 to hold said at least two movable pole members 6 and 7 in contact with the inclined surfaces 12 A and 13 A of the fixed pole member 5 , then these elastic means 17 include at least one spring interposed between said at least two movable pole members 6 and 7 .

**[p0020]**

Preferably, there will be one spring for each movable pole member 6 and/or 7 , to be interposed between the fixed pole member 5 and the movable pole member 6 and/or 7 . Referring now to FIGS. 7A to 7C , there is shown a third embodiment of the present invention, differing from the first and the second embodiment in that the pole extension 4 has a quadrangular shape. Particularly, both the fixed pole member 5 and the holder means 8 have a quadrangular plan shape. These have the same size as the surface of the pole piece of the magnetic apparatus 1 with which the pole extension 4 is associated, thereby ensuring a continuous magnetic flux conduction section, while minimizing the causes for flux leakage and magnetic force reduction. In this particular embodiment, the fixed pole member 5 still includes the at least two surfaces 12 B and 13 B inclined to the predetermined longitudinal direction X-X. Particularly, the two inclined surfaces 12 B and 13 B define respective sliding surfaces for the at least two movable pole members 6 and 7 , each of the latter being in slideable mating contact with a respective surface 12 B and 13 B of said fixed pole member 5 .

**[p0021]**

Advantageously, the respective inclined surfaces 12 B and 13 B are oriented opposite to each other, e.g. each of these respective inclined sliding surfaces forms an angle of 40° to 50°, preferably 45°, relative to said predetermined longitudinal direction X-X. In other words, the movable pole members 6 and 7 slide in a direction that is inclined to said longitudinal direction X-X, at an angle of 40° to 50°, preferably 45°, whereas the holder means 8 move orthogonal to the clamping plate 2 . It shall be noted that, once more in the third embodiment the holder means 8 consist of a hollow parallelepipedal container that is free to move in the predetermined longitudinal direction X-X between the first operating position P 1 ( FIG. 7B ) and the second operating position P 2 ( FIG. 7C ). As an alternative to the above, in any one of the previously described embodiments the fixed pole member 5 and the holder means 8 may have a polygonal (hexagonal, octagonal, etc.) shape, an elliptic shape or a polygonal shape with rounded corners.

**[p0022]**

Concerning the operation of the magnetic apparatus 1 with the above mentioned pole extensions 4 , the end wall 9 A of the hollow member 9 , in response to the action of the elastic means 17 shall be first in the operating position P 1 , in which the movable pole extension 4 is in its maximum extension state. When the workpiece P is laid on the pole extensions 4 , the holder means 8 move in the predetermined longitudinal direction X-X, under the weight of the workpiece P, from the first operating position P 1 down to an intermediate location between the first operating position P 1 and the second operating position P 2 , or abut into the second operating position P 2 . Since the holder means 8 of each movable pole extension 4 can move in the longitudinal direction X-X independently of the fixed pole member 5 , each movable pole extension 4 can change its height, wherefore the distance between the surface on which the workpiece is laid P and the clamping plate 2 of the magnetic apparatus 1 may change according to the existing deformation of the workpiece P.

**[p0023]**

The use of multiple pole extensions as described above, either of circular or square plan shape, which are associated with the magnetic apparatus 1 by securing the screw 15 A in the corresponding threaded hole 16 provides a workpiece P clamping plate made up of the surfaces of all the pole extensions, that can automatically conform to the shape of the workpiece P to be clamped. When the pole extensions are equipped with elastic elements 17 designed to hold the hollow member 9 in the maximum allowed extension state, this shape conformation occurs with the magnetic apparatus 1 still inactivated. The arrangement of the movable pole members 6 and 7 relative to the fixed pole member 5 of each movable pole extension 4 allows the movable pole holder means 8 to move in the direction of axis X-X, i.e. orthogonal to the clamping surface 2 of the magnetic apparatus 1 . As the magnetic apparatus 1 is activated, all the movable pole extensions 4 , with the movable pole holder means 8 already adapted to the shape and weight of the workpiece P, will be locked in their position, thereby preventing any vertical or horizontal displacement of the workpiece P.

**[p0024]**

It shall be noted that the continuous and consistent contact of the workpiece P, the holder means 8 , the movable pole members 6 and 7 , the fixed pole member 5 and the magnetic pole 3 A allows minimization of the gaps and magnetic flux leakage, the magnetic flux being thus usefully conveyed to the workpiece P being clamped. This will ensure high clamping forces as well as a highly reliable operation of the pole extension 4 , without requiring any increase of the magnetomotive force in the magnetic surface of the relevant apparatus. The above pole extensions may be advantageously employed in upright or upturned positions even on magnetic lifting or handling apparatus. If the pole extensions are used in upturned positions, then the holder means 8 will be in the maximum extension state even without the provision of elastic means 17 , the weight of all movable members being sufficient to cause their downward sliding motion. As the workpiece P to be lifted is laid thereon, the holder means 8 of the movable pole extension 4 will tend to move back to the extent required for compensating for the local deformation of the workpiece P. Thus, all the movable pole extensions 4 will form a clamping surface adapted to conform to the workpiece P, all the relevant pole extensions being in direct contact with the workpiece P.

**[p0025]**

Once the magnetic apparatus is activated, the holder means 8 and the movable pole members 6 and 7 of each pole extension 4 will be locked in their relative positions, as mentioned above, thereby firmly holding the workpiece to be lifted. Those skilled in the art will obviously appreciate that a number of changes and variants may be made to the arrangements as described hereinbefore to meet specific needs, without departure from the scope of the invention, as defined in the following claims.

## Figure captions

- **Figure 1:** FIG. 1 is a side view of a prior art movable pole extension;
- **Figure 2:** FIG. 2 is a perspective view of a magnetic clamping apparatus having pole extensions as disclosed in the present invention;
- **Figure 3:** FIGS. 3 and 4 are exploded views of a first embodiment of a movable pole extension as disclosed in the present invention;
- **Figure 5A:** FIG. 5A is a top plan view of the movable pole extension of FIGS. 3 and 4 ;
- **Figure 5B:** FIGS. 5B and 5C are respective sectional views of the movable pole extension taken along line I-I of FIG. 5A , particularly FIG. 5B with the movable pole extension in a first operating position and FIG. 5C with the movable pole extension in a second operating position;
- **Figure 6A:** FIGS. 6A and 6B are a top plan view and a sectional view taken along line II-II of FIG. 6A respectively of a second embodiment of the movable pole extension of the present invention;
- **Figure 7A:** FIG. 7A is a top plan view of a third embodiment of a movable pole extension of the present invention;
- **Figure 7B:** FIGS. 7B and 7C are respective sectional views of the movable pole extension taken along line of FIG. 7A , particularly FIG. 7B with the movable pole extension in a first operating position and FIG. 7C with the movable pole extension in a second operating position.
- **Figure 2:** Referring now to FIG. 2 , there is shown a perspective view of a magnetic clamping apparatus 1 , such as an electro-permanent apparatus as mentioned above, whose operation is well known to those of ordinary skill in the art and will not be further described herein.
- **Figure 3:** Each movable pole extension 4 allows support and clamping of a ferromagnetic workpiece P which shall be, for instance, submitted to mechanical machining (not shown) by a machine tool, such as a miller or similar machines. As shown in FIGS. 3 to 7C , each movable pole extension 4 comprises:
- **Figure 4A:** Particularly, the holder means 8 are movable in said predetermined longitudinal direction X-X between a first operating position P 1 ( FIGS. 4A , 6 A) and a second operating position P 2 ( FIGS. 4B , 6 B).
- **Figure 3:** The end wall 9 A, as specially shown in FIGS. 3 and 4 , acts as a bearing surface when the workpiece P lies on the movable pole extension 4 .
- **Figure 3:** The materials that form the fixed pole member 5 , the two pole members 6 and 7 and the holder means 8 are preferably ferromagnetic materials. Referring now to FIGS. 3 to 5C , there is shown a first embodiment of the present inventions, in which the fixed pole member 5 is shown to have a circular plan shape.
- **Figure 5A:** The hollow cylindrical container is free to move in the predetermined longitudinal direction X-X between the first operating position P 1 ( FIG. 5A ) and the second operating position P 2 ( FIG. 5B ).
- **Figure 3:** In this case, also referring to FIGS. 3 and 4 , the generators of these cylindrical surfaces 12 and 13 form an angle of 40° to 50°, preferably of 45° relative to the predetermined longitudinal direction X-X.
- **Figure 5A:** In other words, the movable pole members 6 and 7 slide in a direction that is inclined to said longitudinal direction X-X, at an angle of 40° to 50°, preferably 45°, whereas the holder means 8 move orthogonal to the clamping plate 2 between the first operating position P 1 ( FIG. 5A ) and the second operating position P 2
- **Figure 5B:** ( FIG. 5B ).
- **Figure 5A:** As shown in FIGS. 5A , 5 B and 5 C, elastic means 17 are also optionally provided, which operate on the two movable pole members 6 and 7 to hold said two movable pole members 6 and 7 in contact with the two surfaces 12 and 13 of said fixed pole member 5 and to hold the holder means 7 in the first operating position P 1 , i.e. the maximum extension position of the movable pole extension 4 .
- **Figure 5A:** In the embodiment as shown in FIGS. 5A , 5 B and 5 C two springs are provided, for better adhesion of the movable members 6 and 7 to the cylindrical surfaces 12 and 13 .
- **Figure 6A:** Referring now to FIGS. 6A and 6B , there is shown a second embodiment of the present invention, differing from the first embodiment in that the at least two inclined surfaces 12 A and 13 A of the fixed pole member 5 have different inclinations relative to the predetermined longitudinal direction X-X.
- **Figure 7A:** Referring now to FIGS. 7A to 7C , there is shown a third embodiment of the present invention, differing from the first and the second embodiment in that the pole extension 4 has a quadrangular shape.
- **Figure 7B:** It shall be noted that, once more in the third embodiment the holder means 8 consist of a hollow parallelepipedal container that is free to move in the predetermined longitudinal direction X-X between the first operating position P 1 ( FIG. 7B ) and the second operating position P 2 ( FIG. 7C ).

## Classifications

- B23Q3/1543
- B23Q3/1543
- B23Q3/154
- B23Q3/1546
- B23Q3/1546
- B25B11/00
- B66C1/04
- B66C1/04
- H01F7/20

## Cited patent documents

- [US-2005269758-A1](https://patents.google.com/patent/US20050269758A1/en) — PRS
- [US-5080380-A](https://patents.google.com/patent/US5080380A/en) — PRS
- [US-5090648-A](https://patents.google.com/patent/US5090648A/en) — PRS
- [US-6012711-A](https://patents.google.com/patent/US6012711A/en) — PRS

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
