# 08. Magnet gripper

- **Archive rank:** 8 of 50
- **Publication:** [JP-2019155534-A](https://patents.google.com/patent/JP2019155534A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/067995456/publication/JP2019155534A?q=pn%3DJP2019155534A)
- **Publication date:** 2019-09-19
- **Filing date:** 2018-03-13
- **Earliest priority:** 2018-03-13
- **Family:** 67995456
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** CIVIL SOLUTION TECH CO LTD; RUUTO KOGYO KK

## Abstract

To provide a magnet gripper which does not require excessive operating force while using a permanent magnet.SOLUTION: A magnet gripper 1 takes a holding state in which a workpiece 8 to be a magnetic body is held by magnetic force and a release state in which the holding is released. The magnetic gripper includes: a housing 2 of a nonmagnetic material which is opened in its lower side; a permanent magnet 3 which is arranged movably in the vertical direction with a magnetization surface 5 directed downward in the housing 2; and a moving section 6 which moves the permanent magnet 3 upward and downward. An opening 4 of the housing 2 is formed into an inclined shape including a most protruding portion 9 projecting to a lowest section and a most retracted portion 10 retracted from the lowest section. As a moving range of the permanent magnet 3 by the moving section 6, a holding position where the whole of the magnetization surface 5 projects from the opening 4 of the housing 2 and the holding state is made and a release position where at least a part of the magnetization surface 5 is recessed inside the housing 2 and the release state is made are included.SELECTED DRAWING: Figure 1

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/JP-2019155534-A/000.png)

![Sketch 1 for JP-2019155534-A](https://nimo.iptorch.com/refdrawing/JP-2019155534-A/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/JP-2019155534-A/001.png)

![Sketch 2 for JP-2019155534-A](https://nimo.iptorch.com/refdrawing/JP-2019155534-A/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/JP-2019155534-A/002.png)

![Sketch 3 for JP-2019155534-A](https://nimo.iptorch.com/refdrawing/JP-2019155534-A/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/JP-2019155534-A/003.png)

![Sketch 4 for JP-2019155534-A](https://nimo.iptorch.com/refdrawing/JP-2019155534-A/003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/JP-2019155534-A/004.png)

![Sketch 5 for JP-2019155534-A](https://nimo.iptorch.com/refdrawing/JP-2019155534-A/004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/JP-2019155534-A/005.png)

![Sketch 6 for JP-2019155534-A](https://nimo.iptorch.com/refdrawing/JP-2019155534-A/005.png)

## Claims

### Claim 1 (independent)

Claims (3)

### Claim 2 (independent)

Translated from Japanese

### Claim 3 (independent)

ç£æ§ä½ã§ããã¯ã¼ã¯ãç£åã«ããä¿æããä¿æç¶æ

### Claim 4 (independent)

ã¨ï¼ä¿æãè§£é¤ããè§£é¤ç¶æ

### Claim 5 (independent)

ã¨ãã¨ããã°ãããã°ãªããã§ãã£ã¦ï¼

### Claim 6 (independent)

ä¸æ¹ãéå£ããéç£æ§æã®ãã¦ã¸ã³ã°ã¨ï¼

### Claim 7 (independent)

åè¨ãã¦ã¸ã³ã°å

### Claim 8 (independent)

ã«çç£é¢ãä¸ã«åãã¦ä¸ä¸æ¹åã«ç§»åå¯è½ã«é

### Claim 9 (independent)

ç½®ãããæ°¸ä¹

### Claim 10 (independent)

ç£ç³ã¨ï¼ åè¨æ°¸ä¹

### Claim 11 (independent)

ç£ç³ãä¸ä¸ã«ç§»åãããç§»åé¨ã¨ãæãï¼

### Claim 12 (independent)

åè¨ãã¦ã¸ã³ã°ã®éå£é¨ãï¼æãä¸æ¹ã«çªåºããæå¸ç®æã¨æãä¸æ¹ããéé¿ããæéç®æã¨ãå«ãå¾æç¶ã«å½¢æããã¦ããï¼

### Claim 13 (independent)

åè¨ç§»åé¨ã«ããåè¨æ°¸ä¹

### Claim 14 (independent)

ç£ç³ã®ç§»åç¯å²ã«ï¼

### Claim 15 (independent)

åè¨çç£é¢ã®å

### Claim 16 (independent)

¨ä½ãåè¨ãã¦ã¸ã³ã°ã®éå£é¨ããçªåºãã¦åè¨ä¿æç¶æ

### Claim 17 (independent)

ã¨ãªãä¿æä½ç½®ã¨ï¼

### Claim 18 (independent)

åè¨çç£é¢ã®å°ãªãã¨ãä¸é¨åãåè¨ãã¦ã¸ã³ã°ã®å

### Claim 19 (independent)

é¨ã«æ²¡å

### Claim 20 (independent)

¥ãã¦åè¨è§£é¤ç¶æ

### Claim 21 (independent)

ã¨ãªãè§£é¤ä½ç½®ã¨ãå«ã¾ãããã¨ãç¹å¾´ã¨ãããã°ãããã°ãªããã

### Claim 22 (independent)

A magnet gripper that takes a holding state in which a workpiece, which is a magnetic body, is held by a magnetic force, and a released state in which the holding is released,

### Claim 23 (independent)

A non-magnetic housing with an open bottom;

### Claim 24 (independent)

A permanent magnet disposed in the housing so as to be movable in a vertical direction with a magnetized surface facing down, and a moving part for moving the permanent magnet up and down,

### Claim 25 (independent)

An opening of the housing is formed in an inclined shape including a most convex portion protruding downward and a most retracted portion retracted from the bottom;

### Claim 26 (independent)

In the moving range of the permanent magnet by the moving part,

### Claim 27 (independent)

A holding position where the entire magnetized surface protrudes from the opening of the housing and enters the holding state;

### Claim 28 (independent)

A magnet gripper including a release position where at least a part of the magnetized surface enters the inside of the housing and enters the release state.

### Claim 29 (independent)

è«æ±é

### Claim 30 (independent)

ï¼ã«è¨è¼ã®ãã°ãããã°ãªããã§ãã£ã¦ï¼

### Claim 31 (independent)

åè¨ç§»åé¨ã¯ï¼åè¨è§£é¤ä½ç½®ã«ã¦ï¼åè¨çç£é¢ã®å

### Claim 32 (independent)

¨ä½ãåè¨ãã¦ã¸ã³ã°ã®å

### Claim 33 (independent)

é¨ã«æ²¡å

### Claim 34 (independent)

¥ããããã®ã§ãããã¨ãç¹å¾´ã¨ãããã°ãããã°ãªããã

### Claim 35

A magnet gripper according to claim 1,

### Claim 36

The magnet gripper according to claim 1, wherein the moving part is configured to immerse the entire magnetized surface into the housing at the release position.

### Claim 37 (independent)

è«æ±é

### Claim 38 (independent)

ï¼ã¾ãã¯è«æ±é

### Claim 39 (independent)

ï¼ã«è¨è¼ã®ãã°ãããã°ãªããã§ãã£ã¦ï¼

### Claim 40 (independent)

åè¨ãã¦ã¸ã³ã°ã®éå£é¨ããªãéå£é¢ã®ãã¡ï¼åè¨æå¸ç®æãå«ãå

### Claim 41 (independent)

¨éå£é¢ç©ã®ååä»¥ä¸ã®é¢ç©ã®é åã«ãããï¼åè¨æ°¸ä¹

### Claim 42 (independent)

ç£ç³ã®ç§»åæ¹åã¨åç´ãªé¢ã«å¯¾ããå¾æè§ãï¼ï¼Â°ãï¼ï¼Â°ã®ç¯å²å

### Claim 43 (independent)

ã«ãããã¨ãç¹å¾´ã¨ãããã°ãããã°ãªããã

### Claim 44

A magnet gripper according to claim 1 or claim 2,

### Claim 45 (independent)

An inclination angle with respect to a plane perpendicular to the moving direction of the permanent magnet is 5 Â° to 45 Â° in a region having an area of more than half of the total opening area including the most convex portion among the opening surfaces formed by the opening of the housing. A magnet gripper characterized by being in the range.

## Full description

**[p0001]**

Description Translated from Japanese æ¬çºæã¯ï¼ç£æ§ä½ã§ããã¯ã¼ã¯ãæ°¸ä¹ ç£ç³ã®ç£åã«ããä¿æããä¿æç¶æ ã¨ï¼ä¿æãè§£é¤ããè§£é¤ç¶æ ã¨ãã¨ããã°ãããã°ãªããã«é¢ãããã®ã§ããã Â Â The present invention relates to a magnet gripper that takes a holding state in which a workpiece, which is a magnetic body, is held by the magnetic force of a permanent magnet, and a released state in which the holding is released. å¾æ¥ããï¼ç£æ§ä½ã§ããã¯ã¼ã¯ãç£åã«ããä¿æãããã°ãããã°ãªãããä½¿ç¨ããã¦ãããç¹ã«æ°¸ä¹ ç£ç³å¼ã®ãã°ãããã°ãªããã¯ï¼ééç©ã§ããã¯ã¼ã¯ãä¿æãããããé¨åã«é»æµãä¾çµ¦ããå¿ è¦ããªãç¹ã§ï¼é»ç£ç³å¼ã®ãã®ããæ±ããããã¨ããå©ç¹ãããããã®ãããªæ°¸ä¹ ç£ç³å¼ã®ãã°ãããã°ãªããã®å¾æ¥ä¾ã¨ãã¦ï¼ä¾ãã°ï¼ç¹è¨±æç®ï¼ã«è¨è¼ããã¦ããããã°ããããã£ãã¯ããæãããã¨ãã§ããã

**[p0002]**

Â Â Conventionally, a magnetic gripper that holds a workpiece, which is a magnetic body, by magnetic force has been used. In particular, the permanent magnet type magnetic gripper has an advantage that it is easier to handle than the electromagnetic type in that it does not need to supply a current to the head portion that holds a heavy workpiece. As a conventional example of such a permanent magnet type magnet gripper, for example, a âmagnet chuckâ described in Patent Document 1 can be cited. ç¹é2016-124096å·å ¬å ±JP 2016-124096 gazette ããããªããï¼å¾æ¥ã®æ°¸ä¹ ç£ç³å¼ã®ãã°ãããã°ãªããã«ã¯ï¼æ¬¡ã®ãããªåé¡ç¹ããã£ããããªãã¡ä¿æç¶æ ããè§£é¤ç¶æ ã¸ã®åãæ¿ãæã«å¼·å¤§ãªæä½åãå¿ è¦ã¨ããã®ã§ãããééç©ã§ããã¯ã¼ã¯ãä¿æããããã«æ°¸ä¹ ç£ç³ã¨ãã¦å¼·åãªãã®ãä½¿ç¨ããå¿ è¦ãããããã§ãããè§£é¤ç¶æ ã¸ã®åãæ¿ãæã«ã¯ï¼å¼·åãªæ°¸ä¹ ç£ç³ã®çç£é¢ã«å¸çãã¦ããã¯ã¼ã¯ããã®çç£é¢ããç¡çç¢çå¼ãå¥ããåãå¿

**[p0003]**

è¦ã¨ãªãããã§ããã Â Â However, the conventional permanent magnet type magnetic gripper has the following problems. That is, a strong operating force is required when switching from the holding state to the release state. This is because it is necessary to use a strong permanent magnet to hold a heavy workpiece. This is because, when switching to the release state, it is necessary to force the workpiece that is attracted to the magnetized surface of the strong permanent magnet to be peeled off from the magnetized surface. æ¬çºæã¯ï¼åè¨ããå¾æ¥ã®æè¡ãæããåé¡ç¹ãè§£æ±ºããããã«ãªããããã®ã§ãããããªãã¡ãã®èª²é¡ã¨ããã¨ããã¯ï¼æ°¸ä¹ ç£ç³ãä½¿ç¨ãã¤ã¤ï¼éå¤§ãªæä½åãå¿ è¦ã¨ããªããã°ãããã°ãªãããæä¾ãããã¨ã«ããã Â Â The present invention has been made to solve the above-described problems of the prior art. That is, the problem is to provide a magnet gripper that uses a permanent magnet and does not require an excessive operating force.

**[p0004]**

æ¬çºæã®ä¸æ æ§ã«ããããã°ãããã°ãªããã¯ï¼ç£æ§ä½ã§ããã¯ã¼ã¯ãç£åã«ããä¿æããä¿æç¶æ ã¨ï¼ä¿æãè§£é¤ããè§£é¤ç¶æ ã¨ãã¨ãè£ ç½®ã§ãã£ã¦ï¼ä¸æ¹ãéå£ããéç£æ§æã®ãã¦ã¸ã³ã°ã¨ï¼ãã¦ã¸ã³ã°å ã«çç£é¢ãä¸ã«åãã¦ä¸ä¸æ¹åã«ç§»åå¯è½ã«é ç½®ãããæ°¸ä¹ ç£ç³ã¨ï¼æ°¸ä¹ ç£ç³ãä¸ä¸ã«ç§»åãããç§»åé¨ã¨ãæãï¼ãã¦ã¸ã³ã°ã®éå£é¨ãï¼æãä¸æ¹ã«çªåºããæå¸ç®æã¨æãä¸æ¹ããéé¿ããæéç®æã¨ãå«ãå¾æç¶ã«å½¢æããã¦ããï¼ç§»åé¨ã«ããæ°¸ä¹ ç£ç³ã®ç§»åç¯å²ã«ï¼çç£é¢ã®å ¨ä½ããã¦ã¸ã³ã°ã®éå£é¨ããçªåºãã¦ä¿æç¶æ ã¨ãªãä¿æä½ç½®ã¨ï¼çç£é¢ã®å°ãªãã¨ãä¸é¨åããã¦ã¸ã³ã°ã®å é¨ã«æ²¡å ¥ãã¦è§£é¤ç¶æ ã¨ãªãè§£é¤ä½ç½®ã¨ãå«ã¾ãããã®ã§ããã Â Â A magnet gripper according to an aspect of the present invention is a device that takes a holding state in which a workpiece, which is a magnetic body, is held by a magnetic force, and a released state in which the holding is released. It has a permanent magnet that can be moved in the vertical direction with the magnetized surface facing down, and a moving part that moves the permanent magnet up and down. The holding position is such that the entire magnetized surface protrudes from the opening of the housing in the range of movement of the permanent magnet by the moving part, and includes the most retracted part retracted from the lowermost part. And a release position in which

**[p0004]**

at least a part of the magnetized surface enters the inside of the housing to enter a release state.

**[p0005]**

ä¸è¨æ æ§ã«ããããã°ãããã°ãªããã§ã¯ï¼æ°¸ä¹ ç£ç³ãä¿æä½ç½®ã«ããã¨ãï¼ãã®ä¸åãã®çç£é¢ã®å ¨ä½ããã¦ã¸ã³ã°ã®éå£é¨ããçªåºãã¦ããããã®ãããã®çç£é¢ã§ã¯ã¼ã¯ãä¿æãããã¨ãã§ããããããä¿æç¶æ ã§ããããã®ç¶æ ããï¼ç§»åé¨ã«ããæ°¸ä¹ ç£ç³ãä¸åãã«ç§»åãããã¨æ°¸ä¹ ç£ç³ã¯ï¼çç£é¢ã®å°ãªãã¨ãä¸é¨åããã¦ã¸ã³ã°ã®å é¨ã«æ²¡å ¥ãã¦ããè§£é¤ä½ç½®ã¨ãªãããã®ç¶æ ã§ã¯çç£é¢ã«ããã¯ã¼ã¯ã®ä¿æãä¸å¯è½ã§ããããã®ããï¼ä¿æç¶æ ã§ä¿æãã¦ããã¯ã¼ã¯ã¯è½ä¸ãã¦ãã¾ãããããè§£é¤ç¶æ ã§ãããæ¬æ æ§ã§ã¯ï¼ä¿æç¶æ ããè§£é¤ç¶æ ã¸ç§»è¡ããã¨ãï¼çç£é¢ã¨ã¯ã¼ã¯ã¨ã®å¯çãå ¨é¢çã«ä¸æã«å¼ãå¥ããããã®ã§ã¯ãªãï¼æ®µéçã«å¼ãå¥ãããããããªãã¡ã¾ãï¼ä¿æç¶æ ããï¼ã¯ã¼ã¯ãï¼ãã¦ã¸ã³ã°ã®éå£é¨ã®æå¸ç®æã¨ï¼çç£é¢ã®ä¸ç®æã¨ã®ï¼ç¹ã§ä¿æãããç¶æ

**[p0006]**

ã¨ãªãããã®å¾ï¼çç£é¢ã®ä¸ç®æã§ã®ã¯ã¼ã¯ã®ä¿æãã§ããªããªãï¼è§£é¤ç¶æ ã¨ãªãããã®ããï¼ç§»åé¨ãæ°¸ä¹ ç£ç³ãç§»åãããããã«å¿ è¦ãªåãï¼æéçã«åæ£ãããããããã£ã¦ç§»åé¨ã®åºåã¯ãã»ã©å¼·åã§ãªãã¦ãããã Â Â In the magnet gripper according to the above aspect, when the permanent magnet is in the holding position, the entire downward magnetized surface protrudes from the opening of the housing. Therefore, the work can be held on the magnetized surface. This is the holding state. From this state, when the permanent magnet is moved upward by the moving portion, the permanent magnet is in a release position where at least a part of the magnetized surface is immersed in the housing. In this state, the work cannot be held by the magnetized surface. For this reason, the work held in the holding state falls. This is the release state. In this aspect, when shifting from the holding state to the release state, the adhesion between the magnetized surface and the workpiece is not peeled off at once, but is peeled off in stages. That is, first, from the holding state, the workpiece is held at the two points of the most convex portion of the opening of the housing and one portion of the magnetized surface. After that, it becomes impossible to hold the work at one place on the magnetized surface, and the released state is entered. For this reason, the force required for the moving part to move the permanent magnet is also dispersed in time. Therefore, the output of the moving unit does

**[p0006]**

not have to be very strong.

**[p0007]**

ä¸è¨æ æ§ã®ãã°ãããã°ãªããã§ã¯ããã«ï¼ç§»åé¨ã¯ï¼è§£é¤ä½ç½®ã«ã¦ï¼çç£é¢ã®å ¨ä½ããã¦ã¸ã³ã°ã®å é¨ã«æ²¡å ¥ããããã®ã§ãããã¨ãæã¾ããããã®ããã«ãªã£ã¦ããã°ï¼è§£é¤ä½ç½®ã§ã¯ç¢ºå®ã«ã¯ã¼ã¯ãæ°¸ä¹ ç£ç³ããé¢è±ããããã§ããã Â Â Further, in the magnet gripper of the above aspect, it is desirable that the moving part is configured to immerse the entire magnetized surface into the housing at the release position. This is because the workpiece is surely detached from the permanent magnet at the release position. ä¸è¨ã®ããããã®æ æ§ã®ãã°ãããã°ãªããã§ã¯ã¾ãï¼ãã¦ã¸ã³ã°ã®éå£é¨ããªãéå£é¢ã®ï¼æ°¸ä¹ ç£ç³ã®ç§»åæ¹åã¨åç´ãªé¢ã«å¯¾ããå¾æè§ãï¼ï¼Â°ãï¼ï¼Â°ã®ç¯å²å ã«ãããã¨ãæã¾ãããå¾æè§ãå°ãããã¦ã¯ãã¾ãæå³ããªããï¼å¤§ããããã¨ä¿æç¶æ ããè§£é¤ç¶æ ã¸ç§»è¡ããã¨ãã«ãããæå¸ç®æã«éä¸­ãã¦æããè² è·ãå¤§ãããã¨ã«ãªãããã§ããããã ãï¼ä¸è¨ã®å¾æè§ã®ç¯å²ã¯ï¼ãã¦ã¸ã³ã°ã®éå£é¨ããªãéå£é¢ã®ãã¡ï¼æå¸ç®æãå«ãå

**[p0008]**

¨éå£é¢ç©ã®ååä»¥ä¸ã®é¢ç©ã®é åã«ã¦æºãããã¦ããã°ååã§ãããããªãã¡ï¼æéç®æã«è¿ãé åã®å¾æè§ã¯ãã£ã¨æ¥å³»ã§ãããã Â Â In any of the above-described magnet grippers, it is preferable that the inclination angle of the opening surface formed by the opening of the housing with respect to the surface perpendicular to the moving direction of the permanent magnet is in the range of 5 Â° to 45 Â°. This is because if the inclination angle is too small, it does not make much sense, and if it is too large, the load that is concentrated on the most convex part when shifting from the holding state to the released state will be large. However, it is sufficient that the range of the above inclination angle is satisfied by a region having an area of at least half of the total opening area including the most convex portion in the opening surface formed by the opening of the housing. In other words, the inclination angle of the region near the most retracted point may be steeper.

**[p0009]**

æ¬æ§æã«ããã°ï¼æ°¸ä¹ ç£ç³ãä½¿ç¨ãã¤ã¤ï¼éå¤§ãªæä½åãå¿ è¦ã¨ããªããã°ãããã°ãªãããæä¾ããã¦ããã Â Â According to this configuration, a magnet gripper that uses a permanent magnet and does not require an excessive operating force is provided. å®æ½ã®å½¢æ ã«ä¿ããã°ãããã°ãªããï¼ä¿æç¶æ ï¼ã®æ­£é¢å³ã§ãããIt is a front view of the magnet gripper (holding state) concerning an embodiment. å®æ½ã®å½¢æ ã«ä¿ããã°ãããã°ãªããï¼è§£é¤ç¶æ ï¼ã®æ­£é¢å³ã§ãããIt is a front view of the magnet gripper (release state) concerning an embodiment. å®æ½ã®å½¢æ ã«ä¿ããã°ãããã°ãªããã®åºé¢å³ã§ãããIt is a bottom view of the magnet gripper concerning an embodiment. å®æ½ã®å½¢æ ã«ä¿ããã°ãããã°ãªããï¼ä¸­éç¶æ ï¼è§£é¤ç¶æ ï¼ã®æ­£é¢å³ã§ãããIt is a front view of the magnet gripper (intermediate state, release state) concerning an embodiment. ãã¦ã¸ã³ã°ã®å¾æè§ãèª¬æããããã®æ­£é¢å³ã§ãããIt is a front view for demonstrating the inclination-angle of a housing.

**[p0010]**

å¤å½¢ä¾ã«ä¿ããã¦ã¸ã³ã°ãç¤ºãæ­£é¢å³ã§ãããIt is a front view which shows the housing which concerns on a modification. ä»¥ä¸ï¼æ¬çºæãå ·ä½åããå®æ½ã®å½¢æ ã«ã¤ãã¦ï¼æ·»ä»å³é¢ãåç §ãã¤ã¤è©³ç´°ã«èª¬æãããæ¬å½¢æ ã¯ï¼å³ï¼ã«ç¤ºããã°ãããã°ãªããï¼ã«ããã¦æ¬çºæãé©ç¨ãããã®ã§ãããæ¬å½¢æ ã®ãã°ãããã°ãªããï¼ã¯ï¼å³ï¼ã«ç¤ºãããããã«ï¼ãã¦ã¸ã³ã°ï¼ã®å é¨ã«æ°¸ä¹ ç£ç³ï¼ãé ç½®ãããã®ã§ããããã¦ã¸ã³ã°ï¼ã¯ï¼ä¸­ç©ºã®ç´æ¹ä½ç¶ã®ãã®ã§ããï¼ä¸ç«¯ãå¾æããéå£é¨ï¼ã¨ãªã£ã¦ãããæ°¸ä¹ ç£ç³ï¼ã¯ï¼çç£é¢ï¼ã®ä¸æ¹ï¼ã©ã¡ãã®æ¥µã§ãããï¼ãä¸åãã¨ãªãããã«é ç½®ããã¦ããã Â Â DESCRIPTION OF THE PREFERRED EMBODIMENTS Embodiments embodying the present invention will be described below in detail with reference to the accompanying drawings. In this embodiment, the present invention is applied to the magnet gripper 1 shown in FIG. As shown in FIG. 1, the magnet gripper 1 of the present embodiment has a permanent magnet 3 disposed inside a housing 2. The housing 2 has a hollow rectangular parallelepiped shape, and has an opening 4 whose lower end is inclined. The permanent magnet 3 is arranged so that one of the magnetized surfaces 5 (whichever pole is used) faces downward.

**[p0011]**

ã¾ãï¼æ°¸ä¹ ç£ç³ï¼ã¯ãã¦ã¸ã³ã°ï¼å ã§ä¸ä¸æ¹åã«ç§»åå¯è½ã¨ããã¦ããããã®ãããã¦ã¸ã³ã°ï¼ã®ä¸é¨ã«ã¯ï¼ã¨ã¢ã·ãªã³ãï¼ãè¨­ãããã¦ãããã¨ã¢ã·ãªã³ãï¼ã¯ï¼æ°¸ä¹ ç£ç³ï¼ããã¦ã¸ã³ã°ï¼å ã§ä¸ä¸æ¹åã«ç§»åãããããã®æ©æ§ã§ãããã¨ã¢ã·ãªã³ãï¼ã«ã¯ï¼æ¬ã®ã¨ã¢ãã¼ã¹ï¼ãåãä»ãããã¦ãããã¨ã¢ãã¼ã¹ï¼ã¸ã®ç©ºæ°å§ã®å°å ç¶æ³ãåãæ¿ãããã¨ã§ï¼æ°¸ä¹ ç£ç³ï¼ãä¸åãã«ç§»åããããä¸åãã«ç§»åãããããããã¨ãã§ããã Â Â The permanent magnet 3 is movable in the vertical direction within the housing 2. Therefore, an air cylinder 6 is provided on the upper portion of the housing 2. The air cylinder 6 is a mechanism for moving the permanent magnet 3 in the vertical direction within the housing 2. Two air hoses 7 are attached to the air cylinder 6. By switching the state of application of air pressure to the air hose 7, the permanent magnet 3 can be moved upward or downward.

**[p0012]**

å³ï¼ã«ç¤ºãããç¶æ ã¯ï¼æ°¸ä¹ ç£ç³ï¼ãï¼ãã®å¯åç¯å²å ã®æãä¸æ¹ã«ä½ç½®ãã¦ããç¶æ ã§ããããã®ç¶æ ã§ã¯ï¼æ°¸ä¹ ç£ç³ï¼ã®ä¸åãã®çç£é¢ï¼ãï¼ãã¦ã¸ã³ã°ï¼ã®éå£é¨ï¼ããä¸åãã«çªåºãã¦ããããããã£ã¦ãã®ç¶æ ã¯ï¼ã¯ã¼ã¯ï¼ããã°ãããã°ãªããï¼ã§ä¿æããä¿æç¶æ ã§ããããã®ç¶æ ã§ã®æ°¸ä¹ ç£ç³ï¼ã®ä½ç½®ãä¿æä½ç½®ã§ãããããªãã¡ãã®ç¶æ ã§ã¯ï¼æ°¸ä¹ ç£ç³ï¼ã¨ã¯ã¼ã¯ï¼ã¨ãï¼çç£é¢ï¼ã®å ¨ä½ã§å¯çãã¦ãããæ°¸ä¹ ç£ç³ï¼ãä¸åãã«ç§»åããã¦çç£é¢ï¼ããã¦ã¸ã³ã°ï¼ã®éå£é¨ï¼ããçªåºããªãããã«ããã¨ï¼çç£é¢ï¼ã«ããã¯ã¼ã¯ï¼ã®ä¿æãè§£é¤ããï¼è§£é¤ç¶æ ã¨ãªãï¼å³ï¼ï¼ããã®ç¶æ ã§ã®æ°¸ä¹ ç£ç³ï¼ã®ä½ç½®ãè§£é¤ä½ç½®ã§ããããªãã¯ã¼ã¯ï¼ã¯å½ç¶ï¼ç£æ§æã§ã§ãã¦ãããã®ã§ããã Â Â The state shown in FIG. 1 is a state in which the permanent magnet 3 is located at the lowest position within the movable range. In this state, the downward magnetized surface 5 of the permanent magnet 3 protrudes downward from the opening 4 of the housing 2. Therefore, this state is a holding state in which the workpiece 8 is held by the magnet gripper 1. The position of the permanent magnet 3 in this state is the holding position. That is, in this state, the permanent magnet 3 and the work 8 are in close contact with the entire magnetized surface 5. When the permanent magnet 3 is moved upward so that the magnetized surface 5 does not pro

**[p0012]**

trude from the opening 4 of the housing 2, the work 8 held by the magnetized surface 5 is released, and the released state is established (FIG. 2). The position of the permanent magnet 3 in this state is the release position. The work 8 is naturally made of a magnetic material.

**[p0013]**

ããã§å³ï¼ããæãããªããã«ï¼æ¬å½¢æ ã®ãã°ãããã°ãªããï¼ã§ã¯ï¼éå£é¨ï¼ãï¼æ°´å¹³é¢ã§ã¯ãªãå¾æé¢ã¨ããã¦ãããããªãã¡éå£é¨ï¼ã«ã¯ï¼æãä¸æ¹ã«çªåºããæå¸ç®æï¼ã¨ï¼æãä¸æ¹ããéé¿ããæéç®æï¼ï¼ã¨ãããï¼ãããã®éã¯å¾æé¨ï¼ï¼ã¨ãªã£ã¦ããããªãï¼ãã¦ã¸ã³ã°ï¼ããã³æ°¸ä¹ ç£ç³ï¼ãçä¸ããè¦ä¸ãã¦ã¿ãã¨å³ï¼ã«ç¤ºãããã«æ­£æ¹å½¢ã«ãªã£ã¦ãããæå¸ç®æï¼ï¼æéç®æï¼ï¼ï¼å¾æé¨ï¼ï¼ã¯ããããï¼æ­£æ¹å½¢ã®ï¼è¾ºã§ãããã¤ã¾ãæå¸ç®æï¼ã¯ï¼å³ï¼ã§è¦ãã°ããããï¼ç¹ã®ããã«è¦ãããï¼å®éã«ã¯ï¼ç¹ã§ã¯ãªãããªãï¼çä¸ããè¦ããã¦ã¸ã³ã°ï¼ããã³æ°¸ä¹ ç£ç³ï¼ã®å½¢ç¶ã¯ï¼æ­£æ¹å½¢ã®ä»£ããã«é·æ¹å½¢ã§ãã£ã¦ãããã Â Â Here, as apparent from FIG. 1, in the magnet gripper 1 of the present embodiment, the opening 4 is an inclined surface instead of a horizontal surface. That is, the opening 4 has a most convex portion 9 that protrudes most downward and a most retracted portion 10 that retreats from the bottom, and an inclined portion 11 is formed between them. When the housing 2 and the permanent magnet 3 are looked up from directly below, they are square as shown in FIG. The most convex part 9, the most retracted part 10, and the inclined part 11 are all one side of a square. That is, the most convex portion 9 looks as if it is one point in FIG. 1, but is not actually one point. In addition, the shape of the housing 2 and the pe

**[p0013]**

rmanent magnet 3 viewed from directly below may be a rectangle instead of a square.

**[p0014]**

éå£é¨ï¼ãå¾æé¢ã§ãããã¨ã«ããï¼å³ï¼ã®ç¶æ ã¨å³ï¼ã®ç¶æ ã¨ã®éã«ï¼å³ï¼ã®ç¶æ ãå­å¨ãããå³ï¼ã®ç¶æ ã§ã¯ï¼æ°¸ä¹ ç£ç³ï¼ã®çç£é¢ï¼ãï¼éå£é¨ï¼ã«å¯¾ãã¦é¨åçã«çªåºãé¨åçã«æ²¡å ¥ãã¦ããããã®ç¶æ ã§ã®ã¯ã¼ã¯ï¼ã¯ï¼çç£é¢ï¼ã«å¯¾ãã¦å¯çãã¦ããªããçç£é¢ï¼ã®ä¸è¾ºã¨éå£é¨ï¼ã®æå¸ç®æï¼ã¨ã®è¨ï¼ç®æã§ãã°ãããã°ãªããï¼ã«æ¥ãã¦ããããã§ãããæ¬å½¢æ ã®ãã°ãããã°ãªããï¼ã§ã¯ï¼å³ï¼ã®ç¶æ ããï¼ãã®å³ï¼ã®ç¶æ ãçµã¦å³ï¼ã®ç¶æ ã«è³ããã¤ã¾ãï¼æ°¸ä¹ ç£ç³ï¼ã¨ã¯ã¼ã¯ï¼ã¨ã®å¯çãï¼ä¸ç¬ã§ãã¹ã¦å¼ãå¥ããããã®ã§ã¯ãªãï¼æ®µéçã«å¼ãå¥ããããã®ã§ããããã®ããï¼ã¨ã¢ã·ãªã³ãï¼ã®åºåã¯ï¼ä¸ç¬ã§ã®å¼ãå¥ããã«å¯¾å¿ã§ããã»ã©å¼·åã§ããå¿ è¦ã¯ãªãã Â Â Since the opening 4 is an inclined surface, the state of FIG. 4 exists between the state of FIG. 1 and the state of FIG. In the state of FIG. 4, the magnetized surface 5 of the permanent magnet 3 partially protrudes and is partially immersed in the opening 4. The workpiece 8 in this state is not in close contact with the magnetized surface 5. This is because the magnet gripper 1 is in contact with a total of two locations, one side of the magnetized surface 5 and the most convex portion 9 of the opening 4. In the magnet gripper 1 of this embodiment, the state of FIG. 1 is reached through the state of FIG. 4 to the state of FIG. That is, the adhesion between th

**[p0014]**

e permanent magnet 3 and the work 8 is not peeled off in an instant, but is peeled off in stages. For this reason, the output of the air cylinder 6 does not have to be strong enough to cope with the instant peeling.

**[p0015]**

ãªãï¼æ°¸ä¹ ç£ç³ï¼ã®ç£åã¨ã¯ã¼ã¯ï¼ã®ééã¨ã®é¢ä¿ã«ãã£ã¦ã¯ï¼å³ï¼ã®ç¶æ ã§ã¯ã¼ã¯ï¼ãä¿æãããè½ä¸ããå ´åãããããã®å ´åã«ã¯å³ï¼ã®ç¶æ ãè§£é¤ç¶æ ã¨ãã¦ä½¿ç¨ãããã¨ã¨ãã¦ãããããã®å ´åã®æ°¸ä¹ ç£ç³ï¼ã®è§£é¤ä½ç½®ã¯ï¼çç£é¢ï¼ãï¼éå£é¨ï¼ã«å¯¾ãã¦é¨åçã«çªåºãé¨åçã«æ²¡å ¥ãã¦ããç¶æ ã¨ãªãä½ç½®ã§ããã Â Â Depending on the relationship between the magnetic force of the permanent magnet 3 and the weight of the workpiece 8, the workpiece 8 may fall without being held in the state shown in FIG. In that case, the state shown in FIG. 4 may be used as the release state. In this case, the release position of the permanent magnet 3 is a position where the magnetized surface 5 partially protrudes from the opening 4 and is partially immersed. æ¬å½¢æ ã®ãã°ãããã°ãªããï¼ã«ãããæ°¸ä¹ ç£ç³ï¼ã¯ï¼ãã§ã©ã¤ãç£ç³ã§ãè¶ å¼·ç£æ§åéï¼ããªã¸ã ç³»ï¼ãµããªã¦ã ç³»ç­ï¼ç£ç³ã§ãããããã¦ã¸ã³ã°ï¼ã¯ï¼éç£æ§æã§ã§ãã¦ãããã®ã§ããããã¦ã¸ã³ã°ï¼ã®æè³ªã¨ãã¦ã¯ä¾ãã°ï¼ãªã¼ã¹ããã¤ãç³»ã¹ãã³ã¬ã¹é¼ï¼é

**[p0016]**

ï¼ã¢ã«ãç­ãæãããããç¡¬è³ªæ¨¹èãã»ã©ããã¯ã§ãã£ã¦ãï¼å¿ è¦ãªå¼·åº¦ãããã°ããã Â Â The permanent magnet 3 in the magnet gripper 1 of this embodiment may be a ferrite magnet or a superferromagnetic alloy (neodymium-based, samarium-based, etc.) magnet. The housing 2 is made of a nonmagnetic material. Examples of the material of the housing 2 include austenitic stainless steel, copper, and aluminum. Even if it is a hard resin or ceramic, it only needs to have the required strength. æ¬å½¢æ ã®ãã°ãããã°ãªããï¼ã«ãããéå£é¨ï¼ã®å¾æè§ã«ã¤ãã¦è¿°ã¹ããããã§ã¯å¾æè§Î¸ãå³ï¼ã«ç¤ºãããã«ï¼æ°´å¹³é¢ï½ã¨å¾æé¢ï½ã¨ããªãè§ã¨ãã¦å®ç¾©ãããæ°´å¹³é¢ï½ã¨ã¯ããªãã¡ï¼æ°¸ä¹ ç£ç³ï¼ã®ç§»åæ¹åã¨åç´ãªé¢ã§ãããå¾æé¢ï½ã¯ï¼éå£é¨ï¼ã®ç¸è¾ºï¼åè¿°ã®æå¸ç®æï¼ï¼æéç®æï¼ï¼ï¼å¾æé¨ï¼ï¼ï¼ã«ããå¼µãããé¢ã§ãããå¾æè§Î¸ã«ã¤ãã¦ã¯ï¼çµ¶å¯¾çãªå¶ç´ãããããã§ã¯ãªããï¼æ¨å¥¨ãããã®ã¯ï¼Â°ãï¼ï¼Â°ã®ç¯å²å

**[p0017]**

ã§ãããå¾æè§Î¸ãå¤§ããããã¨ï¼å³ï¼ã®ç¶æ ã§ãã¦ã¸ã³ã°ï¼ã®æå¸ç®æï¼ã«æããè² è·ãå¤§ããï¼ãã¦ã¸ã³ã°ï¼ã®æ¶èãæ¿ãããã¨ã«ãªããå¾æè§Î¸ãå°ããããã¨ï¼æ¬çºæã¨ãã¦ã®æå³ãèããã¨ã¨ãªãããªãï¼ï¼Â°ãï¼ï¼Â°ã®ç¯å²å ã§ããã°ããå¥½ã¾ããã Â Â The inclination angle of the opening 4 in the magnet gripper 1 of this embodiment will be described. Here, the inclination angle Î¸ is defined as an angle formed by the horizontal plane h and the inclined plane k as shown in FIG. That is, the horizontal plane h is a plane perpendicular to the moving direction of the permanent magnet 3. The inclined surface k is a surface stretched by the edge of the opening 4 (the above-mentioned most convex portion 9, the most retracted portion 10, and the inclined portion 11). Although there is no absolute restriction on the inclination angle Î¸, it is recommended to be within a range of 5 Â° to 45 Â°. If the inclination angle Î¸ is too large, the load applied to the most convex portion 9 of the housing 2 in the state shown in FIG. If the inclination angle Î¸ is too small, the meaning of the present invention is weak. In addition, if it is in the range of 5 degrees-30 degrees, it is more preferable.

**[p0018]**

ä»¥ä¸ï¼å¤å½¢ä¾ã«ã¤ãã¦èª¬æãããå³ï¼ã«ç¤ºããã¦ã¸ã³ã°ï¼ï¼ã¯ï¼åè¿°ã®å³ï¼ãå³ï¼ã®ãã¦ã¸ã³ã°ï¼ã«ãããéå£é¨ï¼ã®å¾æå½¢ç¶ãå¤å½¢ãããã®ã§ãããå³ï¼ã®ãã¦ã¸ã³ã°ï¼ï¼ã§ã¯ï¼éå£é¨ï¼ï¼ã«æå¸ç®æï¼ï¼ã¨æéç®æï¼ï¼ã¨ãå­å¨ããã¨ããç¹ã§ã¯åè¿°ã®ãã¦ã¸ã³ã°ï¼ã¨å ±éããããããå³ï¼ã®ãã¦ã¸ã³ã°ï¼ï¼ã§ã¯ï¼å¾æé¨ï¼ï¼ãä¸åãã«å¸ã§ããæ²ç·ç¶ã¨ãªã£ã¦ãããå³ï¼ã®ãã¦ã¸ã³ã°ï¼ã§ã¯å¾æé¨ï¼ï¼ãç´ç·ç¶ã¨ãªã£ã¦ããã®ã§ï¼ãã®ç¹ãç¸éç¹ã§ããã Â Â Hereinafter, modified examples will be described. The housing 12 shown in FIG. 6 is obtained by modifying the inclined shape of the opening 4 in the housing 2 shown in FIGS. 6 is the same as the housing 2 described above in that the most convex portion 19 and the most retracted portion 20 exist in the opening 14. However, in the housing 12 of FIG. 6, the inclined portion 21 has a curved shape that protrudes downward. In the housing 2 of FIG. 5, since the inclined part 11 was linear, this point is different.

**[p0019]**

å³ï¼ã®ãã¦ã¸ã³ã°ï¼ï¼ãç¨ãããã°ãããã°ãªããï¼ãã¦ã¸ã³ã°ï¼ä»¥å¤ã¯å³ï¼ã«ç¤ºãããã®ã¨åãï¼ã§ãåè¿°ã¨åæ§ã®å¹æãå¾ããããããã«ï¼å¾æé¨ï¼ï¼ãæ²ç·ç¶ã§ãããã¨ã«ããä»å çãªå¹æã¨ãã¦ï¼ãã¦ã¸ã³ã°ï¼ï¼ãé·å¯¿å½ã§ãããã¨ãæãããããå³ï¼ã®ç¶æ ã«ã¦ï¼ãã¦ã¸ã³ã°ï¼ï¼ã¨ã¯ã¼ã¯ï¼ã¨ã®æ¥ç¹ãæ¬¡ç¬¬ã«ç§»åããããã§ããããã¦ã¸ã³ã°ï¼ï¼ã®æå¸ç®æï¼ï¼ã¸ã®è² è·ã®éä¸­ãç·©åãããããã§ããã Â Â A magnet gripper using the housing 12 of FIG. 6 (the same as that shown in FIG. 1 except for the housing 2) can provide the same effect as described above. Further, as an additional effect due to the inclined portion 21 being curved, the housing 12 has a long life. This is because the contact between the housing 12 and the workpiece 8 gradually moves in the state of FIG. This is because the concentration of load on the most convex portion 19 of the housing 12 is alleviated.

**[p0020]**

å³ï¼ã®ãã¦ã¸ã³ã°ï¼ï¼ã®å ´åã«ãããå¾æè§Î¸ã§ãããï¼ãã¦ã¸ã³ã°ï¼ï¼ãä¸æ¹ããè¦ãé¢ç©ã®ãã¡ååä»¥ä¸ãå ãï¼ãã¤æå¸ç®æï¼ï¼ãå«ãé åï¼å³ï¼ä¸­ã«ï½ã§ç¤ºãï¼ã«ããã¦å¾æè§Î¸ãå®ç¾©ããã°ããããã®å¾æè§Î¸ãåè¿°ã®å¥½ã¾ããç¯å²å ã«ãããã¨ãå¥½ã¾ãããããªãã¡ï¼ãã¦ã¸ã³ã°ï¼ï¼ãæ°´å¹³é¢å æ¹åã«è¦ãè¦ç·ã§ãã£ã¦ï¼æå¸ç®æï¼ï¼ãæãç«¯ã«ä½ç½®ããè¦ç·ã§è¦ãã¨ãã®ï¼å³ï¼ãããã§ããï¼ä¸­éç¹ï¼°ã¨ï¼æå¸ç®æï¼ï¼ã¨ã§ï¼åè¿°ã®å¾æé¢ï½ã«ç¸å½ããé¢ãå®ç¾©ããã°ããã Â Â The inclination angle Î¸ in the case of the housing 12 in FIG. 6 is an inclination angle in a region (indicated by m in FIG. 6) that occupies more than half of the area of the housing 12 viewed from below and includes the most convex portion 19. What is necessary is just to define (theta). The inclination angle Î¸ is preferably within the above-mentioned preferable range. That is, it is a line of sight when the housing 12 is viewed in the horizontal plane direction, and the most convex part 19 is the middle point P when the most convex part 19 is seen with the line of sight positioned at the end (as in FIG. 6). , A surface corresponding to the aforementioned inclined surface k may be defined.

**[p0021]**

ã¾ãï¼ãã®ããã«å¾æé¨ï¼ï¼ãæ²ç·ç¶ã§ããå ´åã«ã¯ï¼åè¿°ã®è§£é¤ä½ç½®ãï¼æ°¸ä¹ ç£ç³ï¼ã®çç£é¢ï¼ããã¦ã¸ã³ã°ï¼ï¼å ã«å ¨é¨æ²¡å ¥ããä½ç½®ï¼å³ï¼ã«ç¸å½ï¼ã¨ããå¿ è¦ã¯ãªããçç£é¢ï¼ãéå£é¨ï¼ï¼ã«å¯¾ãã¦ä¸é¨æ²¡å ¥ããä½ç½®ï¼å³ï¼ã«ç¸å½ï¼ããã£ã¦è§£é¤ä½ç½®ã¨ããã°ååã§ããã Â Â Further, when the inclined portion 21 is curved as described above, the above-described release position needs to be a position (corresponding to FIG. 2) where the magnetized surface 5 of the permanent magnet 3 is completely immersed in the housing 12. Absent. It is sufficient that the position (corresponding to FIG. 4) where the magnetized surface 5 is partially immersed with respect to the opening 14 is the release position. ä»¥ä¸è©³ç´°ã«èª¬æããããã«æ¬å®æ½ã®å½¢æ ã«ããã°ï¼æ°¸ä¹ ç£ç³ï¼ãç¨ãããã°ãããã°ãªããï¼ã«ããã¦ï¼ãã¦ã¸ã³ã°ï¼ã®ä¸ç«¯ã®éå£é¨ï¼ãå¾æç¶ã¨ãã¦ãããããã«ããï¼æ°¸ä¹

**[p0022]**

ç£ç³ãä½¿ç¨ãã¤ã¤ï¼éå¤§ãªæä½åãå¿ è¦ã¨ããªããã°ãããã°ãªãããå®ç¾ããã¦ãããã¾ãï¼éå£é¨ã®å¾æé¨ãä¸åãã«å¸ãªå½¢ç¶ã¨ãããã¨ã§ï¼ãã¦ã¸ã³ã°ã®é·å¯¿å½åãå³ããã¨ãã§ããã Â Â As described in detail above, according to the present embodiment, in the magnet gripper 1 using the permanent magnet 3, the opening 4 at the lower end of the housing 2 is inclined. This realizes a magnet gripper that uses a permanent magnet and does not require an excessive operating force. In addition, by making the inclined portion of the opening convex downward, the life of the housing can be extended. ãªãï¼æ¬å®æ½ã®å½¢æ ã¯åãªãä¾ç¤ºã«ãããï¼æ¬çºæãä½ãéå®ãããã®ã§ã¯ãªãããããã£ã¦æ¬çºæã¯å½ç¶ã«ï¼ãã®è¦æ¨ãé¸è±ããªãç¯å²å ã§ç¨®ã ã®æ¹è¯ï¼å¤å½¢ãå¯è½ã§ãããä¾ãã°åè¨å½¢æ ã§ã¯ï¼ãã¦ã¸ã³ã°ããã³æ°¸ä¹ ç£ç³ã®æ°´å¹³é¢å æ­é¢å½¢ç¶ï¼å³ï¼ã§è¦ãå½¢ç¶ï¼ãï¼æ­£æ¹å½¢ã¨ãã¦é·æ¹å½¢ã§ãããã¨ããããããããã«ããã«éããï¼ä»»æã®å½¢ç¶ã§ãããããªãã¡ä»ã®å¤è§å½¢ç¶ãï¼æ²ç·ã§å²ã¾ããå½¢ç¶ï¼åå½¢ï¼æ¥åå½¢ï¼ç­ï¼ã§ãããã

**[p0023]**

Â Â Note that this embodiment is merely an example, and does not limit the present invention. Therefore, the present invention can naturally be improved and modified in various ways without departing from the gist thereof. For example, in the above-described embodiment, the horizontal cross-sectional shape (the shape seen in FIG. 3) of the housing and the permanent magnet may be a square or a rectangle. However, the present invention is not limited to this, and an arbitrary shape may be used. That is, other polygonal shapes or shapes surrounded by curves (circular, elliptical, etc.) may be used. ã¾ãå³ï¼ã§ã¯ï¼æ­£æ¹å½¢æ­é¢ã®å ´åã«ã¦ï¼è¾ºããã³ãã®å¯¾è¾ºãæå¸ç®æï¼ããã³æéç®æï¼ï¼ã¨ããããã®éã®ï¼è¾ºãå¾æé¨ï¼ï¼ã¨ãããï¼ï¼é ç¹ããã³ãã®å¯¾è§ç·ä¸ã®é ç¹ãæå¸ç®æï¼ããã³æéç®æï¼ï¼ã¨ãï¼ï¼çµã®ï¼è¾ºå ¨ä½ãå¾æé¨ï¼ï¼ï¼ä¸åãã«å¸ç¶ã§ãããï¼ã¨ãããã¨ãã§ããããã ããã®å ´åï¼å³ï¼ã«ç¸å½ããç¶æ

**[p0024]**

ã§ã®ãã¦ã¸ã³ã°ï¼ã¸ã®è² è·ãï¼æå¸ç®æï¼ã®ï¼ç¹ã«éä¸­ããã¨ããç¹ã§ã¯ä¸å©ã§ããã Â Â In FIG. 3, in the case of a square cross section, one side and its opposite side are the most convex part 9 and the most retreating part 10 and the two sides between them are the inclined portions 11. The most convex portion 9 and the most retracted portion 10 may be used, and the entire two sets of two sides may be inclined portions 11 (which may be convex downward). However, in that case, it is disadvantageous in that the load on the housing 2 in the state corresponding to FIG. 4 is concentrated at one point of the most convex portion 9. ã¾ãï¼å³ï¼ã«ç¤ºããããã«æ°´å¹³é¢å ã®ããæ¹åããè¦ãã¨ãã«ä¸ç«¯ã«æå¸ç®æãä½ç½®ãä»ç«¯ã«æéç®æãä½ç½®ããããã«ãããï¼ãããå¿ é ã§ã¯ãªããä¸­å¤®ã«æå¸ç®æãä½ç½®ãä¸¡ç«¯ã«æéç®æãä½ç½®ããããã«ãã¦ãããããã®å ´åã«å³ï¼ã«ç¸å½ããæ°´å¹³é¢å

**[p0025]**

é ç½®ãèããã¨ï¼ï¼çµã®å¯¾è¾ºãä¸¡æ¹ã¨ãæéç®æã¨ãªãï¼æ®ãï¼çµã®å¯¾è¾ºã®ä¸­å¤®ã«è¨ï¼ç®æã®æå¸ç®æãä½ç½®ãããã¨ã¨ãªããã¾ãï¼ä¸è¨ã®ãããã®ã±ã¼ã¹ã§ãï¼éå£é¨ãä¸åãã«å¸ç¶ã«ããå ´åï¼å³ï¼ãå³ï¼ã®è¦ç·ã§è¦ã¦ï¼å¾æé¨ï¼ï¼ãæ²ç·ç¶ã«éããæãç·ç¶ã«è¦ããããã«ãã¦ããããã¾ãï¼æ°¸ä¹ ç£ç³ï¼ããã¦ã¸ã³ã°å ã§ä¸ä¸æ¹åã«ç§»åãããæ©æ§ã¨ãã¦ã¨ã¢ã·ãªã³ãï¼ãç¨ãããï¼ããã«éããªããæ²¹å§ä½åã«ãããã®ã§ããããï¼æåãããããããã¯ã¬ãã¼ç­ã«ããæåå¼ã®ãã®ã§ãããã Â Â Further, as shown in FIG. 3, the most convex portion is located at one end and the most retracted portion is located at the other end when viewed from a certain direction in the horizontal plane, but this is not essential. The most convex part may be located at the center and the most retracted part may be located at both ends. In this case, considering the arrangement in the horizontal plane corresponding to FIG. 3, both sets of opposite sides are the most retracted places, and a total of two most convex places are located in the center of the remaining one set of opposite sides. In any of the cases described above, when the opening is convex downward, the inclined portion 11 may be viewed as a broken line as well as a curved line as seen from the line of sight in FIGS. Moreover, although the air cylinder 6 was used as a mechanism for moving the permanent magnet 3 in the vertical direction within the ho

**[p0025]**

using, the present invention is not limited to this. It may be hydraulically operated or manually operated by a hand turning knob or lever.

**[p0026]**

ï¼ ãã°ãããã°ãªãã ï¼ï¼ å¾æé¨ ï¼ ãã¦ã¸ã³ã° ï¼ï¼ ãã¦ã¸ã³ã° ï¼ æ°¸ä¹ ç£ç³ ï¼ï¼ éå£é¨ ï¼ éå£é¨ ï¼ï¼ æå¸ç®æ ï¼ çç£é¢ ï¼ï¼ æéç®æ ï¼ ã¨ã¢ã·ãªã³ãï¼ç§»åé¨ï¼ ï¼ï¼ å¾æé¨ ï¼ æå¸ç®æ Î¸ å¾æè§ ï¼ï¼ æéç®æ DESCRIPTION OF SYMBOLS 1 Magnet gripper 11 Inclination part 2 Housing 12 Housing 3 Permanent magnet 14 Opening part 4 Opening part 19 The most convex part 5 Magnetized surface 20 The most retracted part 6 Air cylinder (moving part) 21 Inclined part 9 The most convex part (theta) Inclination angle 10 Maximum Exit

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
