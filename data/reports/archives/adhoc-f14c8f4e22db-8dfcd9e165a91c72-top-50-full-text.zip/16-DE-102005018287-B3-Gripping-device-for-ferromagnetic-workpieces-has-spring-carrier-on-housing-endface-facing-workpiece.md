# 16. Gripping device for ferromagnetic workpieces has spring carrier on housing endface facing workpiece

- **Archive rank:** 16 of 50
- **Publication:** [DE-102005018287-B3](https://patents.google.com/patent/DE102005018287B3/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/036973873/publication/DE102005018287B3?q=pn%3DDE102005018287B3)
- **Publication date:** 2006-09-28
- **Filing date:** 2005-04-13
- **Earliest priority:** 2005-04-13
- **Family:** 36973873
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** SCHMALZ J GMBH
- **Inventors:** MAEDER KARL-HEINZ; RACK ALEXANDER

## Abstract

a The gripping device grips ferromagnetic workpieces (12). It has a pot-shaped housing (14) containing movable magnets. There is a spring carrier on the endface of the housing facing the workpiece. There are projecting spring elements on the spring carrier carrying a grip plate (24) forming a grip surface. The grip plate can move orthogonally relative to the longitudinal axis of the housing.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-102005018287-B3/pdf000.png)

![Sketch 1 for DE-102005018287-B3](https://nimo.iptorch.com/refdrawing/DE-102005018287-B3/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-102005018287-B3/pdf001.png)

![Sketch 2 for DE-102005018287-B3](https://nimo.iptorch.com/refdrawing/DE-102005018287-B3/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/DE-102005018287-B3/pdf002.png)

![Sketch 3 for DE-102005018287-B3](https://nimo.iptorch.com/refdrawing/DE-102005018287-B3/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/DE-102005018287-B3/pdf003.png)

![Sketch 4 for DE-102005018287-B3](https://nimo.iptorch.com/refdrawing/DE-102005018287-B3/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/DE-102005018287-B3/pdf004.png)

![Sketch 5 for DE-102005018287-B3](https://nimo.iptorch.com/refdrawing/DE-102005018287-B3/pdf004.png)

## Claims

### Claim 1 (independent)

Claims (18)

### Claim 2 (independent)

Translated from German

### Claim 3 (independent)

Greifvorrichtung zum Ergreifen von ferromagnetischen

### Claim 4 (independent)

WerkstÃ¼cken

### Claim 5 (independent)

(12), mit einem topffÃ¶rmigen GehÃ¤use (14)

### Claim 6 (independent)

und einem im GehÃ¤use

### Claim 7 (independent)

(14) beweglich gelagerten Magneten, dadurch gekennzeichnet, dass

### Claim 8 (independent)

an der dem WerkstÃ¼ck

### Claim 9 (independent)

(12) zugewandten Stirnseite des GehÃ¤uses (14) ein FedertrÃ¤ger (34)

### Claim 10 (independent)

angeordnet ist, dass am FedertrÃ¤ger

### Claim 11 (independent)

(34) radial nach auÃen

### Claim 12 (independent)

abragende Federelemente (44) angeordnet sind und dass die

### Claim 13 (independent)

Federelemente (44) eine die GreifflÃ¤che (26) bildende

### Claim 14 (independent)

Greifplatte (24) tragen und die Greifplatte (24) Ã¼ber die

### Claim 15 (independent)

Federelemente (44) beweglich bezÃ¼glich des GehÃ¤uses (14)

### Claim 16 (independent)

gelagert ist.Gripping device for gripping ferromagnetic workpieces ( 12 ), with a cup-shaped housing ( 14 ) and one in the housing ( 14 ) movably mounted magnet, characterized in that on the workpiece ( 12 ) facing the front side of the housing ( 14 ) a spring carrier ( 34 ) is arranged that on the spring carrier ( 34 ) radially outwardly projecting spring elements ( 44 ) are arranged and that the spring elements ( 44 ) one the gripping surface ( 26 ) forming gripping plate ( 24 ) and the gripping plate ( 24 ) via the spring elements ( 44 ) movable with respect to the housing ( 14 ) is stored.

### Claim 17

Greifvorrichtung nach Anspruch 1, dadurch gekennzeichnet,

### Claim 18 (independent)

dass die Greifplatte (24) orthogonal zur LÃ¤ngsachse

### Claim 19 (independent)

(62) des GehÃ¤uses

### Claim 20 (independent)

(14) beweglich am GehÃ¤use

### Claim 21

(14) gelagert ist.Gripping device according to claim 1, characterized in that the gripping plate ( 24 ) orthogonal to the longitudinal axis ( 62 ) of the housing ( 14 ) movable on the housing ( 14 ) is stored.

### Claim 22

Greifvorrichtung nach einem der vorhergehenden AnsprÃ¼che, dadurch

### Claim 23 (independent)

gekennzeichnet, dass die Federelemente (44) als Halteelemente

### Claim 24 (independent)

fÃ¼r die

### Claim 25

Greifplatte (24) dienen und eine Zentrierfunktion aufweisen.Gripping device according to one of the preceding claims, characterized in that the spring elements ( 44 ) as holding elements for the gripping plate ( 24 ) and have a centering function.

### Claim 26

Greifvorrichtung nach einem der vorhergehenden AnsprÃ¼che, dadurch

### Claim 27 (independent)

gekennzeichnet, dass die Federelemente (44) einen den FedertrÃ¤ger (34)

### Claim 28 (independent)

mit Federelemente (44) umgreifenden Gleitring (50)

### Claim 29

tragen.Gripping device according to one of the preceding claims, characterized in that the spring elements ( 44 ) a the spring carrier ( 34 ) With Spring elements ( 44 ) encompassing sliding ring ( 50 ) wear.

### Claim 30

Greifvorrichtung nach Anspruch 4, dadurch gekennzeichnet,

### Claim 31 (independent)

dass am Gleitring (50) ein die Stirnseite der Greifvorrichtung

### Claim 32

(10) bildender Deckel (56) befestigt ist.Gripping device according to claim 4, characterized in that on the sliding ring ( 50 ) a the front side of the gripping device ( 10 ) forming lid ( 56 ) is attached.

### Claim 33

Greifvorrichtung nach Anspruch 5, dadurch gekennzeichnet,

### Claim 34 (independent)

dass der Deckel (56) auf den Gleitring (50) aufgerastet

### Claim 35

ist.Gripping device according to claim 5, characterized in that the lid ( 56 ) on the sliding ring ( 50 ) is locked.

### Claim 36 (independent)

Greifvorrichtung nach einem der AnsprÃ¼che 4 bis

### Claim 37 (independent)

6, dadurch gekennzeichnet, dass das GehÃ¤use (14) im Bereich

### Claim 38 (independent)

der Stirnseite eine radial nach auÃen abragende Schulter (28)

### Claim 39 (independent)

aufweist, wobei an der dem WerkstÃ¼ck (12) zugewandten

### Claim 40 (independent)

Seite der Schulter (28) direkt oder indirekt der Gleitring

### Claim 41

(50) anliegt.Gripping device according to one of claims 4 to 6, characterized in that the housing ( 14 ) in the region of the front side a radially outwardly projecting shoulder ( 28 ), wherein on the workpiece ( 12 ) facing side of the shoulder ( 28 ) directly or indirectly the sliding ring ( 50 ) is present.

### Claim 42

Greifvorrichtung nach Anspruch 7, dadurch gekennzeichnet,

### Claim 43 (independent)

dass der Gleitring (50) in zur LÃ¤ngsachse (62) des

### Claim 44 (independent)

GehÃ¤uses

### Claim 45 (independent)

(14) orthogonaler Richtung (Pfeile 52) an der

### Claim 46

Schulter (28) entlang gleitet.Gripping device according to claim 7, characterized in that the sliding ring ( 50 ) in to the longitudinal axis ( 62 ) of the housing ( 14 ) orthogonal direction (arrows 52 ) on the shoulder ( 28 ) slides along.

### Claim 47 (independent)

Greifvorrichtung nach einem der AnsprÃ¼che 4 bis

### Claim 48 (independent)

8, dadurch gekennzeichnet, dass der Gleitring (50) und

### Claim 49

der Deckel (56) die Greifplatte (24) bilden.Gripping device according to one of claims 4 to 8, characterized in that the sliding ring ( 50 ) and the lid ( 56 ) the gripping plate ( 24 ) form.

### Claim 50

Greifvorrichtung nach einem der vorhergehenden AnsprÃ¼che, dadurch

### Claim 51 (independent)

gekennzeichnet, dass der FedertrÃ¤ger

### Claim 52 (independent)

(34) die Stirnseite des GehÃ¤uses (14) pneumatisch

### Claim 53

dicht abschlieÃt.Gripping device according to one of the preceding claims, characterized in that the spring carrier ( 34 ) the front side of the housing ( 14 ) closes pneumatically tight.

### Claim 54

Greifvorrichtung nach einem der vorhergehenden AnsprÃ¼che, dadurch

### Claim 55 (independent)

gekennzeichnet, dass der FedertrÃ¤ger

### Claim 56 (independent)

(34) auf die Stirnseite des GehÃ¤uses (14), gegebenenfalls

### Claim 57 (independent)

unter Zwischenschaltung einer Dichtung (38), aufgeschraubt

### Claim 58

ist.Gripping device according to one of the preceding claims, characterized in that the spring carrier ( 34 ) on the front side of the housing ( 14 ), optionally with the interposition of a seal ( 38 ), is screwed on.

### Claim 59

Greifvorrichtung nach einem der vorhergehenden AnsprÃ¼che, dadurch

### Claim 60 (independent)

gekennzeichnet, dass die Federelemente (44) einen im wesentlichen

### Claim 61 (independent)

C-fÃ¶rmigen

### Claim 62

Querschnitt aufweisen.Gripping device according to one of the preceding claims, characterized in that the spring elements ( 44 ) have a substantially C-shaped cross-section.

### Claim 63

Greifvorrichtung nach Anspruch 12, dadurch gekennzeichnet,

### Claim 64 (independent)

dass die freien Enden bzw. Federarme (46) der Federelemente

### Claim 65

(44) an der Greifplatte (24) anliegen.Gripping device according to claim 12, characterized in that the free ends or spring arms ( 46 ) of the spring elements ( 44 ) on the gripping plate ( 24 ) issue.

### Claim 66

Greifvorrichtung nach einem der vorhergehenden AnsprÃ¼che, dadurch

### Claim 67 (independent)

gekennzeichnet, dass der FedertrÃ¤ger

### Claim 68 (independent)

(34) und/oder die Greifplatte (24) aus nichtmagnetischem

### Claim 69

Material, wie Aluminium, Edelstahl oder Kunststoff bestehen.Gripping device according to one of the preceding claims, characterized in that the spring carrier ( 34 ) and / or the gripping plate ( 24 ) made of non-magnetic material, such as aluminum, stainless steel or plastic.

### Claim 70

Greifvorrichtung nach Anspruch 7, dadurch gekennzeichnet,

### Claim 71 (independent)

dass die Schulter (28) von einem das GehÃ¤use (14)

### Claim 72

umgebenden Ring (30) gebildet wird.Gripping device according to claim 7, characterized in that the shoulder ( 28 ) of a the housing ( 14 ) surrounding ring ( 30 ) is formed.

### Claim 73

Greifvorrichtung nach Anspruch 7 oder 15, dadurch

### Claim 74 (independent)

gekennzeichnet, dass die Schulter (28) aus nichtmagnetischem

### Claim 75

Material, wie Aluminium, Edelstahl oder Kunststoff besteht.Gripping device according to claim 7 or 15, characterized in that the shoulder ( 28 ) made of non-magnetic material, such as aluminum, stainless steel or plastic.

### Claim 76

Greifvorrichtung nach einem der vorhergehenden AnsprÃ¼che, dadurch

### Claim 77 (independent)

gekennzeichnet, dass das GehÃ¤use

### Claim 78 (independent)

(14) zum Befestigen an einem Manipulator eine Befestigungsvorrichtung

### Claim 79 (independent)

(18), z.B. einen Bolzen (20) aufweist, der gegenÃ¼ber dem

### Claim 80 (independent)

GehÃ¤use (14)

### Claim 81

drehbar und/oder neigbar ist.Gripping device according to one of the preceding claims, characterized in that the housing ( 14 ) for fastening to a manipulator a fastening device ( 18 ), eg a bolt ( 20 ), which opposite the housing ( 14 ) is rotatable and / or tiltable.

### Claim 82

Greifvorrichtung nach Anspruch 17, dadurch gekennzeichnet,

### Claim 83 (independent)

dass der Bolzen um 360 Â° drehbar und/oder

### Claim 84 (independent)

um Â± 5Â° neigbar

### Claim 85

ist.Gripping device according to claim 17, characterized in that

### Claim 86 (independent)

that the bolt can be rotated 360 Â° and / or

### Claim 87 (independent)

tiltable by Â± 5 Â°

### Claim 88 (independent)

is.

## Full description

**[p0001]**

PERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating electrostatic or magnetic grippersPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by magnetic means

**[p0002]**

Description Translated from German Die Erfindung betrifft eine Greifvorrichtung zum Ergreifen von ferromagnetischen WerkstÃ¼cken, mit einem im wesentlichen topffÃ¶rmigen GehÃ¤use und eine im GehÃ¤use beweglich gelagerten Magneten.The The invention relates to a gripping device for gripping ferromagnetic Workpieces, with a substantially pot-shaped Housing and one in the housing movably mounted magnet. Derartige Greifvorrichtungen, welche auch als Magnetgreifer bezeichnet werden, sind hinreichend bekannt, z.B. aus der DE 199 51 703 A1 . Mit diesen Magnetgreifern werden ferromagnetische WerkstÃ¼cke ergriffen und transportiert. HierfÃ¼r besitzt der Magnetgreifer ein topffÃ¶rmiges GehÃ¤use, in welchem ein Magnet angeordnet ist, der die Magnetkraft, mit welcher das WerkstÃ¼ck angezogen wird, bereitstellt. Dieser Magnet ist innerhalb des topffÃ¶rmigen GehÃ¤uses beweglich gelagert, wodurch das Magnetfeld so gesteuert wird, dass entweder groÃe oder sehr geringe MagnetkrÃ¤fte wirken. Mit diesen Magnetgreifern kÃ¶nnen also ferromagnetische

**[p0003]**

GegenstÃ¤nde ergriffen werden, die zum Beispiel stark verschmutzt sind oder eine Vielzahl von DurchbrÃ¼chen aufweisen, sodass sie mit einem Unterdruck- oder Sauggreifer nicht ergriffen werden kÃ¶nnen, da dieser nicht dicht am WerkstÃ¼ck anliegen kann. AuÃerdem sind derartige Magnetgreifer wesentlich robuster als Sauggreifer mit ihren empfindlichen Dichtlippen.Such gripping devices, which are also referred to as magnetic gripper, are well known, for example from the DE 199 51 703 A1 , With these magnetic grippers ferromagnetic workpieces are gripped and transported. For this purpose, the magnetic gripper has a pot-shaped housing, in which a magnet is arranged, which provides the magnetic force with which the workpiece is tightened. This magnet is movably mounted within the pot-shaped housing, whereby the magnetic field is controlled so that either large or very small magnetic forces act. With these magnetic grippers so ferromagnetic objects can be taken, for example, are heavily contaminated or have a variety of breakthroughs, so they can not be taken with a vacuum or suction gripper, as this can not lie close to the workpiece. In addition, such magnetic gripper are much more robust than suction pads with their sensitive sealing lips.

**[p0004]**

Um Greifsysteme sowohl mit Sauggreifern, welche mit Unterdruck arbeiten, als auch mit Magnetgreifern bestÃ¼cken zu kÃ¶nnen, werden die Magnete innerhalb des topffÃ¶rmigen GehÃ¤uses mittels Unterdruck verstellt, sodass beim Anlegen eines Unterdrucks im einen Fall SaugkrÃ¤fte am Sauggreifer wirken, im anderen Fall MagnetkrÃ¤fte am Magnetgreifer wirken. In beiden FÃ¤llen wird das WerkstÃ¼ck angezogen. Die Verlagerung des Magnets innerhalb des GehÃ¤uses erfolgt also mittels Unterdruck. Es ist auch denkbar, den Magneten mittels Ãberdruck zu verlagern.Around Gripping systems both with suction pads, which work with negative pressure, as well as equipped with magnetic grippers to be able to the magnets within the pot-shaped housing are adjusted by means of negative pressure, so that when applying a negative pressure in one case, suction forces on the suction pad act in the other case, magnetic forces act on the magnetic gripper. In both cases, the workpiece is tightened. The displacement of the magnet within the housing thus takes place by means of negative pressure.

**[p0005]**

It is also conceivable to shift the magnet by means of overpressure. Aus der DE 72 11 325 U ist eine Greifvorrichtung mit einem Magneten zum Ergreifen von ferromagnetischen WerkstÃ¼cken bekannt, bei der eine Greifplatte gegenÃ¼ber einem GehÃ¤use beweglich ist.From the DE 72 11 325 U is a gripping device with a magnet for gripping ferromagnetic workpieces known in which a gripping plate is movable relative to a housing. Der Erfindung liegt die Aufgabe zugrunde, eine Greifvorrichtung der eingangs genannten Art so weiter zu bilden, dass mit ihr die WerkstÃ¼cke in den Bearbeitungsmaschinen auch prÃ¤zise an vorhandene Referenzkanten angelegt werden kÃ¶nnen.Of the Invention is based on the object, a gripping device of to form the aforementioned type so that with her the workpieces in the processing machines also precise can be applied to existing reference edges. Diese Aufgabe wird mit einer Greifvorrichtung gelÃ¶st, bei welcher an der dem WerkstÃ¼ck zugewandten Stirnseite des GehÃ¤uses ein FedertrÃ¤ger angeordnet

**[p0006]**

ist, wobei am FedertrÃ¤ger radial nach auÃen abragende Federelemente angeordnet sind und die Federelemente eine die GreifflÃ¤che bildende Greifplatte tragen und die Greifplatte Ã¼ber die Federelemente beweglich bezÃ¼glich des GehÃ¤uses gelagert ist.These Task is solved with a gripping device, in which at the workpiece facing end face of the housing arranged a spring carrier is, being on the spring carrier radially outward protruding spring elements are arranged and the spring elements a the gripping surface carrying forming gripping plate and the gripping plate on the spring elements movable in terms of of the housing is stored. Bei der erfindungsgemÃ¤Ãen Greifvorrichtung wird das WerkstÃ¼ck mittels einer Greifplatte ergriffen, wobei die Greifplatte nicht starr mit dem topffÃ¶rmigen GehÃ¤use der Greifvorrichtung verbunden ist. Die Greifplatte ist vielmehr Ã¼ber Federelemente beweglich bezÃ¼glich des GehÃ¤uses gelagert. Die im topffÃ¶rmigen GehÃ¤use erzeugte magnetischen KrÃ¤fte durchdringen das GehÃ¤use sowie die Greifplatte und halten das WerkstÃ¼ck an der Greifplatte fest.

**[p0007]**

Um die OberflÃ¤che des WerkstÃ¼cks nicht zu beschÃ¤digen, insbesondere mit Schleifspuren zu versehen, darf die Greifplatte nicht auf der OberflÃ¤che des WerkstÃ¼cks verschoben werden. Da die Greifplatte bezÃ¼glich des GehÃ¤uses verschiebbar ist, kann das WerkstÃ¼ck in Grenzen relativ zum GehÃ¤use verschoben werden, sodass die die Greifvorrichtung tragende Transporteinrichtung die Greifvorrichtung zusammen mit dem WerkstÃ¼ck zum Beispiel an eine Referenzkante der Bearbeitungsmaschine heranfahren kann, bis das WerkstÃ¼ck an der Referenzkante anliegt. Die Greifvorrichtung kann nun aber noch geringfÃ¼gig weiterverfahren werden, sodass das WerkstÃ¼ck unter Vorspannung, insbesondere unter Vorspannung der Federelemente, an der Referenzkante anliegt. Dabei wird das GehÃ¤use bezÃ¼glich der Greifplatte und dem WerkstÃ¼ck verlagert.at the gripping device according to the invention is the workpiece gripped by a gripping plate, wherein the gripping plate is not rigid with the cup-shaped housing of Gripping device is connected. The gripping plate is rather about spring elements

**[p0008]**

movable with respect of the housing stored. The cup-shaped casing penetrate generated magnetic forces the housing and the gripping plate and hold the workpiece to the gripping plate. To the surface of the workpiece not to damage, in particular to provide with grinding marks, the gripping plate must not on the surface of the workpiece become. Since the gripping plate with respect of the housing is displaceable, the workpiece can be moved within limits relative to the housing are, so that the gripping device carrying the transport device the gripping device together with the workpiece, for example, to a reference edge the machine can approach until the workpiece on the Reference edge is applied. The gripping device can now proceed slightly further so that the workpiece under prestressing, in particular under prestressing of the spring elements, abuts the reference edge. In this case, the housing is displaced with respect to the gripping plate and the workpiece. Auf diese Weise kÃ¶nnen auch nicht exakt gegriffene WerkstÃ¼cke prÃ¤zise an eine Referenzkante angelegt

**[p0009]**

werden.On this way you can Also not precisely gripped workpieces precisely applied to a reference edge become. Die Verlagerung der Greifplatte bezÃ¼glich des topffÃ¶rmigen GehÃ¤uses erschÃ¶pft sich nicht nur in einer translatorischen Bewegung sondern es sind auch Drehbewegungen mÃ¶glich. Eine mÃ¶gliche Verschiebung liegt zum Beispiel im Bereich von 10 mm bis 20 mm, insbesondere bei 15 mm. Drehbewegungen sind Ã¼ber einen Winkel von 360Â° mÃ¶glich.The Displacement of the gripping plate with respect to the cup-shaped housing exhausted not only in a translational motion but it is too Rotational movements possible. A possible Displacement is for example in the range of 10 mm to 20 mm, especially at 15 mm. Rotary movements are possible over an angle of 360 Â°. Bei einer Weiterbildung ist die Greifplatte ausschlieÃlich orthogonal zur LÃ¤ngsachse des GehÃ¤uses beweglich am GehÃ¤use gelagert. Hierdurch wird ausgeschlossen, dass bei der Handhabung der Greifvorrichtung, insbesondere beim Abheben der Greifvorrichtung sich die Greifplatte vom GehÃ¤use lÃ¶st bzw.

**[p0010]**

dass die Greifplatte in axialer Richtung zum GehÃ¤use Spiel aufweist. Jedoch kann sich die Greifplatte in einer Ebene bewegen, deren Orthogonale parallel zur LÃ¤ngsachse der Greifvorrichtung liegt und die Greifplatte kann sich geringfÃ¼gig, wie bereits erwÃ¤hnt, um die LÃ¤ngsachse bzw. eine zur LÃ¤ngsachse parallelen Achse drehen.at In a further development, the gripping plate is exclusively orthogonal to the longitudinal axis of the housing movable on the housing stored. This excludes that when handling the gripping device, in particular when lifting the gripping device the gripping plate separates from the housing or in that the gripping plate has clearance in the axial direction relative to the housing. however the gripping plate can move in a plane whose orthogonal parallel to the longitudinal axis the gripping device is located and the gripping plate may be slightly, as already mentioned, around the longitudinal axis or one to the longitudinal axis rotate parallel axis. Mit Vorzug dienen die Federelemente als Halteelemente fÃ¼r die Greifplatte

**[p0011]**

und weisen eine Zentrierfunktion auf. Die Greifplatte wird also mittels der Federelemente am topffÃ¶rmigen GehÃ¤use gehalten und die Greifplatte wird von den Federelementen in eine bezÃ¼glich der LÃ¤ngsachse des GehÃ¤uses zentrierte Ruhelage Ã¼berfÃ¼hrt, sobald das WerkstÃ¼ck losgelassen wurde und keine Ã¤uÃeren KrÃ¤fte mehr auf die Greifplatte einwirken.With Preference serve the spring elements as holding elements for the gripping plate and have a centering function. The gripping plate is so held by the spring elements on the cup-shaped housing and the gripping plate is centered by the spring elements in a respect to the longitudinal axis of the housing Quiescent transferred as soon as the workpiece is released was and no external forces more act on the gripping plate. Bei einem besonders bevorzugten AusfÃ¼hrungsbeispiel tragen die Federelemente einen den FedertrÃ¤ger mit Federelemente umgreifenden Gleitring. Zwischen diesem Gleitring und dem FedertrÃ¤ger sind also die Federelemente angeordnet, wobei hierfÃ¼r entsprechende Aufnahmen im

**[p0012]**

Gleitring und im FedertrÃ¤ger, insbesondere Nuten oder Taschen vorgesehen sind.at a particularly preferred embodiment The spring elements carry a spring carrier with spring elements embracing Sliding ring. Between this slide ring and the spring carrier are So arranged the spring elements, for which appropriate recordings in Sliding ring and in the spring carrier, in particular grooves or pockets are provided. Eine Weiterbildung der Erfindung sieht vor, dass am Gleitring ein die Stirnseite der Greifvorrichtung bildender Deckel befestigt ist. Dabei kann der Deckel zum Beispiel auf den Gleitring aufgerastet sein. Dieser Deckel besitzt eine insbesondere rutschhemmende GleitflÃ¤che, an welcher das WerkstÃ¼ck anliegt. Da der Deckel relativ leicht auswechselbar ist, kann je nach WerkstÃ¼ck der geeignete Deckel gewÃ¤hlt werden, zum Beispiel mit einer weichen OberflÃ¤che, einer rutschhemmenden OberflÃ¤che, einer gegen Ãle, Chemikalien usw. bestÃ¤ndigen OberflÃ¤che usw. AuÃerdem kann der Deckel bei VerschleiÃ leicht

**[p0013]**

ausgewechselt werden.A Further development of the invention provides that on the sliding ring a Front side of the gripping device forming lid is attached. In this case, the lid may, for example, be latched onto the sliding ring. This cover has a particular slip-resistant sliding surface, on which rests the workpiece. Since the lid is relatively easy to replace, depending on the workpiece of the appropriate Lid selected be, for example, with a soft surface, an anti-slip Surface, one against oils, Chemicals etc. resistant surface etc. besides The lid can be easily worn be replaced. Bei einem bevorzugten AusfÃ¼hrungsbeispiel weist das GehÃ¤use im Bereich der Stirnseite eine radial nach auÃen abragende Schulter auf, wobei an der dem WerkstÃ¼ck zugewandten Seite der Schulter der Gleitring anliegt. Die Schulter dient also zum AbstÃ¼tzen der Kraft, mit welcher das WerkstÃ¼ck vom Magneten angezogen wird. Dabei kann der Gleitring an der Schulter in zur LÃ¤ngsachse des GehÃ¤uses orthogonaler Richtung gleiten bzw. kann sich um die LÃ¤ngsachse

**[p0014]**

des GehÃ¤uses verdrehen. Die Schulter dient also als Auf- oder Gleitlager fÃ¼r den Gleitring.at a preferred embodiment the housing in the area of the front side a radially outwardly projecting shoulder, being at the the workpiece facing side of the shoulder of the sliding ring rests. The shoulder thus serves for supporting the force with which the workpiece is attracted by the magnet. In this case, the sliding ring on the shoulder in to the longitudinal axis of the housing orthogonal direction or can slide around the longitudinal axis of the housing twist. The shoulder thus serves as a bearing or sliding bearing for the sliding ring. Mit Vorzug bilden der Gleitring und der Deckel die das WerkstÃ¼ck ergreifende Greifplatte. Wie bereits erwÃ¤hnt, kann die Greifplatte gezielt an die Eigenschaften des WerkstÃ¼cks angepasst werden.With Preferably, the sliding ring and the lid form the workpiece Gripping plate. As already mentioned, The gripping plate can be adapted to the characteristics of the workpiece become.

**[p0015]**

Um die pneumatischen Funktionen zum Bewegen des Magneten innerhalb des GehÃ¤uses nutzen zu kÃ¶nnen, schlieÃt der FedertrÃ¤ger die Stirnseite des GehÃ¤uses pneumatisch dicht ab. HierfÃ¼r ist der FedertrÃ¤ger nach Art eines Deckels ausgebildet und auf die Stirnseite des GehÃ¤uses, gegebenenfalls unter Zwischenschaltung einer Dichtung, aufgeschraubt.Around the pneumatic functions for moving the magnet inside of the housing to be able to use includes the spring carrier the front of the case pneumatically tight. Therefor is the spring carrier formed in the manner of a lid and on the front side of the housing, optionally below Interposition of a seal, screwed on. Bei einem bevorzugten AusfÃ¼hrungsbeispiel weisen die Federelemente einen im wesentlichen C-fÃ¶rmigen Querschnitt auf. Sie werden von speziell geformten Blattfedern gebildet, die relativ hohe KrÃ¤fte in einer zur Federebene parallelen Ebene abstÃ¼tzen kÃ¶nnen, die aber auch hohe FederkrÃ¤fte in Verformungsrichtung aufbringen kÃ¶nnen. Derartige Blattfedern sind mit unterschiedlichen Federkonstanten

**[p0016]**

herstellbar.at a preferred embodiment the spring elements have a substantially C-shaped cross-section. she are formed by specially shaped leaf springs, which are relatively high forces can be supported in a plane parallel to the spring plane level, but also high spring forces in the direction of deformation can muster. Such leaf springs are available with different spring constants produced. Bei einem bevorzugten AusfÃ¼hrungsbeispiel liegen die freien Enden der Federelemente an der Greifplatte an. Sie greifen dabei zum Beispiel in eine an der Innenseite der Greifplatte vorgesehene Innenumfangsnut ein, sodass sie optimal gefÃ¼hrt werden. Der mittlere Bereich der Blattfeder greift dabei in eine AuÃenumfangsnut am FedertrÃ¤ger ein und wird ebenfalls in Richtung der LÃ¤ngsachse des GehÃ¤uses abgestÃ¼tzt.at a preferred embodiment the free ends of the spring elements on the gripping plate. They are attacking in this case, for example, in a provided on the inside of the gripping plate Inner circumferential groove, so that they are optimally guided. The middle area

**[p0017]**

the leaf spring engages in an outer circumferential groove on the spring carrier and is also supported in the direction of the longitudinal axis of the housing. Vorteilhaft bestehen der FedertrÃ¤ger und/oder die Greifplatte aus nichtmagnetischem Material, wie Aluminium, Edelstahl oder Kunststoff. Auf diese Weise wird verhindert, dass das das GehÃ¤use verlassende Feld gestÃ¶rt oder verzerrt oder geschwÃ¤cht wird.Advantageous consist of the spring carrier and / or the gripping plate made of non-magnetic material, such as aluminum, stainless steel or plastic. In this way it is prevented that leaves the housing Field disturbed or distorted or weakened becomes. Bei einer AusfÃ¼hrungsform ist vorgesehen, dass die Schulter von einem das GehÃ¤use umgebenden Ring gebildet wird, wobei die Schulter ebenfalls aus nichtmagnetischem Material, wie Aluminium, Edelstahl oder Kunststoff bestehen kann. Dieser Ring hat den Vorteil, dass er den Gleitring vollflÃ¤chig abstÃ¼tzen kann, bzw. dass er fÃ¼r den Gleitring eine optimale GleitflÃ¤che bildet.at

**[p0018]**

an embodiment is provided that the shoulder of a surrounding the housing Ring is formed, the shoulder is also made of non-magnetic Material, such as aluminum, stainless steel or plastic can exist. This ring has the advantage that it can support the slide ring over the entire surface, or that he is for the sliding ring forms an optimal sliding surface. Weitere Vorteile, Merkmale und Einzelheiten der Erfindung ergeben sich aus den UnteransprÃ¼chen sowie der nachfolgenden Beschreibung, in der unter Bezugnahme auf die Zeichnung ein besonders bevorzugtes AusfÃ¼hrungsbeispiel im einzelnen beschrieben ist. Dabei kÃ¶nnen die in der Zeichnung dargestellten sowie in den AnsprÃ¼chen und in der Beschreibung erwÃ¤hnten Merkmale jeweils einzeln fÃ¼r sich oder in beliebiger Kombination erfindungswesentlich sein.Further Advantages, features and details of the invention will become apparent the dependent claims as well as the following description, with reference to FIG the drawing a particularly preferred embodiment in detail

**[p0019]**

is described. It can those shown in the drawing and in the claims and mentioned in the description Features individually for themselves or be essential to the invention in any combination. In der Zeichnung zeigenIn show the drawing 1 eine perspektivische Ansicht auf die Oberseite einer Greifvorrichtung gemÃ¤Ã der Erfindung; 1 a perspective view of the top of a gripping device according to the invention; 2 eine perspektivische Ansicht auf die Unterseite der Greifvorrichtung gemÃ¤Ã 1; 2 a perspective view of the underside of the gripping device according to 1 ; 3 eine Seitenansicht der Greifvorrichtung gemÃ¤Ã 1; 3 a side view of the gripping device according to 1 ; 4 einen Schnitt IV-IV gemÃ¤Ã 3; und 4 a section IV-IV according to 3 ; and 5 einen Schnitt V-V gemÃ¤Ã 3. 5 a section VV according to 3 , Die 1 zeigt eine insgesamt mit 10 bezeichnete Greifvorrichtung, mit der zum Beispiel ein plattenfÃ¶rmiges WerkstÃ¼ck 12, zum Beispiel eine Stahlplatte oder dergleichen, die in der 1 lediglich andeutungsweise dargestellt ist, ergriffen werden kann. HierfÃ¼r weist

**[p0020]**

die Greifvorrichtung 10 ein topffÃ¶rmiges GehÃ¤use 14 auf, in welchem sich ein (nicht dargestellter) Magnet befindet, der im GehÃ¤use 14 bewegt werden kann. HierfÃ¼r ist am GehÃ¤use 14 ein Pneumatikanschluss 16 vorgesehen, an welchen ein Ãberdruck und/oder ein Unterdruck angelegt werden kann. AuÃerdem besitzt das GehÃ¤use 14 eine Befestigungsvorrichtung 18 in Form eines Schraubbolzens 20, sodass die Greifvorrichtung 10 mittels Muttern 22 an einem entsprechenden Halter, z.B. an einem Roboterarm oder an einer Handhabe einer Bearbeitungsmaschine befestigt werden kann. Der Schraubbolzen 20 ist gegenÃ¼ber dem GehÃ¤use 14 um 360Â° drehbar und um Â± 5Â° neigbar.The 1 shows a total with 10 designated gripping device, with the example, a plate-shaped workpiece 12 , for example, a steel plate or the like, in the 1 only hinted at, can be taken. For this purpose, the gripping device 10 a pot-shaped housing 14 in which there is a (not shown) magnet in the housing 14 can be moved. This is the case 14 a pneumatic connection 16 provided, to which an overpressure and / or a negative pressure can be applied. In addition, the housing has 14 a fastening device 18 in the form of a bolt 20 so that the gripping device 10 by nuts 22 can be attached to a corresponding holder, for example on a robot arm or on a handle of a processing machine. The bolt 20 is opposite the case 14 360 Â° rotatable and tiltable by Â± 5 Â°.

**[p0021]**

Die dem WerkstÃ¼ck 12 zugewandte Seite der Greifvorrichtung 10 wird von einer Greifplatte 24 gebildet, die im wesentlichen achteckfÃ¶rmig ausgebildet ist und eine GreifflÃ¤che 26 aufweist, die am WerkstÃ¼ck 12 anliegt. Der Aufbau dieser Greifplatte 24 ergibt sich unter anderem aus 4, auf welche im folgenden Bezug genommen wird. Das GehÃ¤use 14 ist mit einer Schulter 28 versehen, an welcher ein Ring 30 anliegt. Dieser Ring 30 besitzt einen radial nach innen vorspringenden Fortsatz 32, der zwischen der Schulter 28 und einem insgesamt mit 34 bezeichnete FedertrÃ¤ger geklemmt ist. Dieser FedertrÃ¤ger 34 weist ein Innengewinde 36 auf und ist auf das stirnseitige Ende des GehÃ¤uses 14 aufgeschraubt. Da der FedertrÃ¤ger 34 deckelartig ausgebildet ist, verschlieÃt er das GehÃ¤use 14 stirnseitig. Um einen pneumatisch dichten Abschluss zu erhalten, ist noch eine Dichtung 38 vorgesehen, die ein Austreten von Druckluft aus dem Innenraum 40 des GehÃ¤uses bzw. ein Eindringen von Luft von auÃen in den Innenraum 40 verhindert.The the workpiece 12 facing side of the gripping device 10 is from a gripping plate 24 formed, which is formed substantially octagon-shaped and a gripping surface 26 that is on the workpiece 12 is applied. The structure of this gripping plate 24 results among other things from 4 to which reference is now made. The housing 14 is with a shoulder 28 provided on which a ring 30 is applied. This ring 30 has a radially inwardly projecting extension 32 that between the shoulder 28 and one in total with 34 designated spring carrier is clamped. This spring carrier 34 has an

**[p0021]**

internal thread 36 on and is on the front end of the housing 14 screwed. Because the spring carrier 34 is formed lid-like, it closes the housing 14 frontally. To get a pneumatically tight seal is still a seal 38 provided, the leakage of compressed air from the interior 40 of the housing or an intrusion of air from the outside into the interior 40 prevented.

**[p0022]**

Der FedertrÃ¤ger 34 ist mit einer AuÃenumfangsnut 42 versehen, in welche insgesamt drei Federelemente 44 (siehe 5) eingesetzt sind. Diese Federelemente 44 sind im wesentlichen C-fÃ¶rmig ausgestaltet, wobei die beiden Federarme 46 im wesentlichen radial nach auÃen abragen und in eine Innenumfangsnut 48 eines Gleitringes 50 eingreifen. Da die Federelemente 44 im wesentlichen als Blattfedern ausgebildet sind, sind sie in radialer Richtung (Pfeil 52) federelastisch, jedoch parallel zur LÃ¤ngsachse 62 des GehÃ¤uses 14 relativ steif. Auf diese Weise wird der Gleitring 50 an der GleitflÃ¤che 54 spielfrei gehalten und der Gleitring 50 kann entlang der GleitflÃ¤che 54 gleiten, indem die Federelemente 44 verformt werden.The spring carrier 34 is with an outer circumferential groove 42 provided, in which a total of three spring elements 44 (please refer 5 ) are used. These spring elements 44 are designed substantially C-shaped, wherein the two spring arms 46 protrude substantially radially outwardly and in an inner circumferential groove 48 a sliding ring 50 intervention. Because the spring elements 44 are formed substantially as leaf springs, they are in the radial direction (arrow 52 ) resilient, but parallel to the longitudinal axis 62 of the housing 14 relatively stiff. In this way, the slip ring 50 on the sliding surface 54 kept free of play and the sliding ring 50 can along the sliding surface 54 slide by the spring elements 44 be deformed.

**[p0023]**

In der 4 ist auÃerdem ein Deckel 56 erkennbar, der den FedertrÃ¤ger 34 sowie den axial abragenden Steg 58 des Gleitrings 50 umgreift und auf diesen Steg 58 aufgeklipst ist. HierfÃ¼r weist der Deckel 56 eine nach innen vorspringende Nase bzw. ein nach innen vorspringenden Ringwulst 60 auf, der in eine entsprechende Umfangsnut am Steg 58 einrastet. Dieser Deckel 56 weist die am WerkstÃ¼ck 12 zur Anlage kommende GreifflÃ¤che 26 auf.In the 4 is also a lid 56 recognizable, the spring carrier 34 and the axially projecting web 58 of the sliding ring 50 embraces and on this jetty 58 is clipped on. For this purpose, the lid 56 an inwardly projecting nose or an inwardly projecting annular bead 60 on, in a corresponding circumferential groove on the bridge 58 locks. This lid 56 has the on the workpiece 12 to the plant coming gripping surface 26 on. Wird mit einer derartigen Greifvorrichtung 10 ein WerkstÃ¼ck 12 ergriffen, dann kann das WerkstÃ¼ck 12 durch seitliches Verfahren der Greifvorrichtung 10 prÃ¤zise an

**[p0024]**

eine maschinenseitige Referenzkante angelegt werden. Sobald das WerkstÃ¼ck 12 an der Referenzkante anschlÃ¤gt wird das GehÃ¤use 14 bezÃ¼glich der Greifplatte 24, die vom Gleitring 50 und dem Deckel 56 gebildet wird, unter Verformung der Federelemente 40 in Richtung des Pfeils 52 und/oder des Pfeils 52' verschoben. AuÃerdem kann das GehÃ¤use 14 bezÃ¼glich der Greifplatte 24 verdreht werden. Dadurch wird sichergestellt, dass das WerkstÃ¼ck 12 Ã¼ber seine gesamte LÃ¤nge an der Referenzkante anliegt. Sobald das WerkstÃ¼ck 12 losgelassen wird, wird die Greifplatte 24 in die Ausgangsposition, die in der 4 dargestellt ist, zurÃ¼ck verlagert, indem die Federelemente 44 sich in ihre Ausgangslagen, die in der 5 dargestellt ist, zurÃ¼ckverformen.Is with such a gripping device 10 a workpiece 12 grabbed, then the workpiece can 12 by lateral movement of the gripping device 10 be applied precisely to a machine-side reference edge. As soon as the workpiece 12 at the reference edge abuts the housing 14 with regard to the gripping plate 24 coming from the sliding ring 50 and the lid 56 is formed, with deformation of the spring elements 40 in the direction of the arrow 52 and / or the arrow 52 ' postponed. In addition, the housing can 14 with regard to the gripping plate 24 to be twisted. This will ensure that the workpiece 12 over its entire length against the reference edge. As soon as the workpiece 12 is released, the gripping plate 24 to the starting position, in the 4 is shown, shifted back by the spring elements 44 into their starting positions, which in the 5 is shown, deform back.

## Classifications

- B65G47/92
- B65G47/92
- B65G47/92
- B65G47/92
- B66C1/04
- B66C1/04

## Cited patent documents

- [DE-19951703-A1](https://patents.google.com/patent/DE19951703A1/en) — SEA
- [DE-7211325-U](https://patents.google.com/patent/DE7211325U/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
