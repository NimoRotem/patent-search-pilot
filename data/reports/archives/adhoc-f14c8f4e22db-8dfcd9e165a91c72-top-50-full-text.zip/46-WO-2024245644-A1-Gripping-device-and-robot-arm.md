# 46. Gripping device and robot arm

- **Archive rank:** 46 of 50
- **Publication:** [WO-2024245644-A1](https://patents.google.com/patent/WO2024245644A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/086605059/publication/WO2024245644A1?q=pn%3DWO2024245644A1)
- **Publication date:** 2024-12-05
- **Filing date:** 2024-04-22
- **Earliest priority:** 2023-05-26
- **Family:** 86605059
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** SIEMENS AG
- **Inventors:** BLUMBERG ADRIAN; DENNELER STEFAN; PANTANO MATTEO

## Abstract

The invention relates to a gripping device for picking up objects (6) in a production process. The gripping device comprises - a housing (4) which has a gripping face (8) on a side close to the object (6) to be picked up, which gripping face is part of a gripping plate (10), and - a permanent-magnet plate (12) which is close to a face (14) of the gripping plate (10) that is opposite the gripping face (8) and which permanent-magnetic plate - is mounted so as to be translationally (26) movable along a perpendicular (16) to the gripping face (8) within the housing (4), wherein - strip-shaped magnetic north-south polarizations (18) run continuously through the permanent-magnet plate (12).

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf000.png)

![Sketch 1 for WO-2024245644-A1](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf001.png)

![Sketch 2 for WO-2024245644-A1](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf002.png)

![Sketch 3 for WO-2024245644-A1](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf003.png)

![Sketch 4 for WO-2024245644-A1](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf004.png)

![Sketch 5 for WO-2024245644-A1](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf005.png)

![Sketch 6 for WO-2024245644-A1](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf006.png)

![Sketch 7 for WO-2024245644-A1](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf007.png)

![Sketch 8 for WO-2024245644-A1](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf008.png)

![Sketch 9 for WO-2024245644-A1](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf009.png)

![Sketch 10 for WO-2024245644-A1](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf009.png)

[Sketch 11](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf010.png)

![Sketch 11 for WO-2024245644-A1](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf010.png)

[Sketch 12](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf011.png)

![Sketch 12 for WO-2024245644-A1](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf011.png)

[Sketch 13](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf012.png)

![Sketch 13 for WO-2024245644-A1](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf012.png)

[Sketch 14](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf013.png)

![Sketch 14 for WO-2024245644-A1](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf013.png)

[Sketch 15](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf014.png)

![Sketch 15 for WO-2024245644-A1](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf014.png)

[Sketch 16](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf015.png)

![Sketch 16 for WO-2024245644-A1](https://nimo.iptorch.com/refdrawing/WO-2024245644-A1/pdf015.png)

## Claims

### Claim 1

Patentansprüche 1. Greifvorrichtung zum Aufnehmen von Gegenständen (6) in einem Produktionsprozess, umfassend - ein Gehäuse (4) , das an einer dem zu greifenden Gegenstand (6) zugewandten Seite eine Greiffläche (8) aufweist, die Teil einer Greifplatte (10) ist und - eine Dauermagnetplatte (12) , die einer der Greiffläche (8) gegenüberliegenden Fläche (14) der Greifplatte (10) zugewandt ist und die - entlang einer Lotgerade (16) zur Greiffläche (8) innerhalb des Gehäuses (4) translatorisch (26) bewegbar gelagert ist, wobei - die Dauermagnetplatte (12) kontinuierlich von streifenförmigen magnetischen Nord-Süd-Polarisierungen (18) durchzogen ist . 2. Greifvorrichtung nach Anspruch 1, dadurch gekennzeichnet, dass eine Breite (22) von jeweils zwei Streifen (20) einer Nord-Süd-Polarisierungen (18) weniger als 25 % eines Magnetplattendurchmessers (24) beträgt. 3. Greifvorrichtung nach Anspruch 2 dadurch gekennzeichnet, dass die Breite (22) weniger als 15 %, insbesondere weniger als 10 % beträgt. 4. Greifvorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass ein Gehäusematerial eine Dichte von weniger als 3 g/cm<3>aufweist. 5. Greifvorrichtung nach Anspruch 4, dadurch gekennzeichnet, dass das Gehäusematerial einen Kunststoff umfasst. 6. Greifvorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass das Gehäuse (4) zumindest teilweise mittels eines Additiv-Manufacturing-Verfahrens hergestellt ist.

### Claim 7

Greifvorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass die translatorische Bewegung (26) der Dauermagnetplatte (12) mittels einer Pneumatik- Vorrichtung erfolgt. 8. Greifvorrichtung nach einem der Ansprüche 1 bis 6, dadurch gekennzeichnet, dass die translatorische Bewegung (26) der Dauermagnetplatte (12) mittels eines Elektromotors (28) erfolgt. 9. Greifvorrichtung nach Anspruch 8, dadurch gekennzeich- net, dass der Elektromotor (28) ein Servomotor (29) oder ein Linearmotor ist. 10. Greifvorrichtung nach Anspruch 9, dadurch gekennzeichnet, dass der Elektromotor (28) ein Servomotor ist und eine Umlenkvorrichtung (30) vorgesehen ist, die die rotatorische Bewegung des Servomotors (29) in die translatorischen Bewegung (26) umwandelt. 11. Greifvorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass die Dauermagnetplatte (12) an einer Trägerplatte (33) angebracht ist. 12. Greifvorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass mittels eines Abstandes (36) der Dauermagnetplatte (12) von der Greifplatte (10) entlang der Lotgerade (16) die Stärke eines Magnetfeldes, das auf den zu greifenden Gegenstand (6) wirkt, einstellbar ist. 13. Greifvorrichtung nach einem der vorhergehenden Ansprüche dadurch gekennzeichnet, dass die Greifvorrichtung (2) eine Aufnahmevorrichtung (32) für einen Roboterarm (34) umfasst. 14. Roboterarm mit einer Greifvorrichtung (2) nach einem der Ansprüche 1 bis 13.

## Full description

**[p0001]**

Beschreibung Grei fvorrichtung und Roboterarm Die Erfindung betri f ft eine Grei fvorrichtung zum Aufnehmen von Gegenständen nach Patentanspruch 1 sowie einen Roboterarm mit einer Grei fvorrichtung nach Patentanspruch 14 . In der industriellen Produktion werden zum Grei fen und Heben von Gegenständen, also Halbzeugen oder Produkten im Produktionsprozess Grei fvorrichtungen verwendet . Derartige Grei fvorrichtungen basieren entweder auf Saugvorrichtungen, wobei mittels Unterdrück die zu grei fenden Gegenstände angesaugt werden oder, falls es sich bei den Gegenständen, die zu greifen sind, um magnetische Gegenstände handelt , kommen auch elektromagnetische Grei fvorrichtungen zum Einsatz . Insbesondere bei sehr filigranen bzw . dünnschichtigen und mechanisch wenig stabilen Gegenständen sind sowohl die Vakuumgrei fvorrichtungen als auch elektromagnetische Grei fvorrichtungen wenig geeignet . Die Vakuumgrei fvorrichtungen saugen die Gegenstände punktuell mit einer hohen Kraft an, sodass es häufig zur Zerstörung der empfindlichen Gegenstände kommt . Elektromagnetische Grei fvorrichtungen, die an sich gut steuerbar sind, da ein elektrischer Strom bei dem Elektromagneten ein- oder ausgeschaltet wird, sind aber aufgrund dieses An- Aus-Prinzipes bezüglich der anzuwendenden Kraft schlecht dosierbar . Außerdem weisen sie auf eine bestimmte Fläche gesehen häufig ein unzureichend homogenes Magnetfeld auf .

**[p0002]**

Hinzu kommt , dass es sich bei den beschriebenen Technologien für Grei fvorrichtungen um mechanisch stabile aber durchaus auch schwere und großvolumige Grei fvorrichtungen handelt , die bei sogenannten kollaborativen Robotern, also Robotern, die nicht abgeschirmt in der Nähe von Menschen operieren dürfen, zu schwer sind . Daher besteht die Aufgabe der Erfindung darin, eine Greifvorrichtung sowie einen Roboterarm mit einer Greifvorrichtung bereitzustellen, die gegenüber dem Stand der Technik eine homogener verteilte Aufnahmekraft aufweist, wobei die Aufnahmekraft besser und feiner steuerbar ist und das Potenzial zu einer Leichtbauanwendung aufweist. Die Lösung der Aufgabe besteht in einer Greifvorrichtung mit den Merkmalen des Patentanspruchs 1 sowie in einem Roboterarm nach Patentanspruch 14. Die Greifvorrichtung zum Aufnehmen von Gegenständen in einem Produktionsprozess nach Patentanspruch 1 umfasst dabei folgende Merkmale. Dies ist zum einen ein Gehäuse, das an einer den zu greifenden Gegenstand zugewandten Seite eine Greiffläche aufweist, die Teil einer Greifplatte ist. Die Greiffläche ist demnach die Fläche, an der während des Greifprozesses der zu greifende Gegenstand anhaftet. Ferner weist die Greifvorrichtung eine Dauermagnetplatte auf, die eine der Greiffläche gegenüberliegenden Fläche der Greifplatte zugewandt ist. Diese Dauermagnetplatte ist innerhalb des Gehäuses, das sowohl die Greifplatte als auch die Dauermagnetplatte umfasst, translatorisch bewegbar gelagert. Ferner ist die Dauermagnetplatte kontinuierlich von streifenförmigen, magnetischen Nord-Süd-Polarisie

**[p0002]**

rungen durch zogen .

**[p0003]**

Dabei seien die bezüglich des Patentanspruchs 1 verwendeten Begriffe wie folgt definiert. Die zu greifenden Gegenständen sind Gegenstände, die im Produktionsprozess oder in einem sonstigen automatisierten oder teilautomatisierten Prozess beispielsweise im Baubereich von der Greifvorrichtung aufgenommen werden können und somit nicht Bestandteil der Greifvorrichtung sind. Die Greifplatte ist eine im Wesentlichen ebene Platte, die dabei zwei Seiten aufweist, zum einen die Greiffläche und zum anderen die der Greiffläche gegenüberliegende Fläche. Dabei kann die Greifplatte in derart ausgestaltet sein, dass sie Teil des Gehäuses ist und die Greiffläche den Gehäuseteil darstellt, an dem dann der zu greifende Gegenstand anhaftet. Demnach zeigt die gegenüberliegende Fläche ins Gehäuseinnere . Das Gehäuse muss dabei nicht eine hermetische Umschließung der weiteren beschriebenen Bestandteile der Grei fvorrichtung sein, es kann auch teilweise of fen oder lediglich durch verbindende und zusammenhaltenden Streben ausgestaltet sein .

**[p0004]**

Unter den strei fenförmigen magnetischen Nord-Süd- Polarisierungen werden in der Regel parallele Strei fen verstanden, bei denen die magnetische Polarisierung alternierend abwechselt . Derartige Strei fen von Nord-Süd-Polarisierungen können j edoch auch in Form von konzentrischen Kreisen bzw . konzentrischen Segmentabschnitten eines Kreises sein . Dies hängt davon ab, wie die Dauermagnetplatte technisch ausgestaltet ist und magnetisiert ist . Unter strei fenförmig ist j edoch nicht nur ein streng geometrischer paralleler Verlauf zu verstehen . Vorteilhaft ist dabei insbesondere eine möglichst enge alternierende magnetische Polarisierung, die zu einem möglichst homogenen Dauermagnetfeld führt . Die beschriebene Erfindung überwindet die Nachteile des Standes der Technik in verschiedenen Aspekten . Zum einen ist mittels eines Dauermagneten ein kontinuierliches und gleichmäßiges Magnetfeld in einer Ebene darstellbar . Dieses Magnetfeld ist mittels der translatorischen Bewegung entlang der Lotachse zur Grei f fläche bezüglich des zu grei fenden Gegenstandes quasi ein- und ausschaltbar . Durch die translatorische Bewegung der Magnetplatte zum zu grei fenden Gegenstand hin oder weg kann die Stärke des Magnetfeldes , das auf den zu grei fenden Gegenstand wirkt , zwischen null und maximal eingestellt werden . Das entspricht dem Ein- und Ausschalten eines sonst üblichen Elektromagneten . Der Vorteil gegenüber der Verwendung eines Elektromagneten besteht j edoch darin, dass durch die Entfernung der Dauermagnetplatte von dem zu grei fenden Gegenstand, also zu der Position entlang der t

**[p0004]**

ranslatorischen Bewegung auch noch die Stärke des Magnetfeldes variiert werden kann, sodass dieses homogene Magnetfeld auch als schwach oder stark eingestellt werden kann . Auf diese Weise kann auf die Anforderung verschiedener zu grei fender Gegenstände , die

**[p0005]**

insbesondere mechanisch unterschiedlich empfindlich sind, eingegangen werden . Als zusätzlicher Vorteil gegenüber der Grei fvorrichtung nach dem Stand der Technik ist die beschriebene Grei fvorrichtung auch leichtbautechnisch zu konstruieren . Hierfür ist beispielsweise das Gehäusematerial mit einem Material aus einer sehr geringen Dichte , das kleiner als 3 g/cm<3>ist , aus zugestalten . Besonders bevorzugt ist dabei das Gehäusematerial ein Kunststof f , der wiederum besonders bevorzugt durch ein additives Herstellungsverfahren genau nach den Anforderungen des zu grei fenden Gegenstandes und dessen Geometrie darstellbar ist . Ferner ist es insbesondere um die Leichtbauanforderungen an eine mögliche Grei fvorrichtung zu erfüllen, zweckmäßig, wenn die translatorische Bewegung der Dauermagnetplatte mittels einer Pneumatikvorrichtung erfolgt . Hierzu können Pneumatikschläuche direkt an die Dauermagnetplatte oder eine Trägerplatte , an der die Dauermagnetplatte befestigt ist , herangeführt werden . Somit ist die eigentliche Pneumatikvorrichtung abseits der Grei fvorrichtung installiert und muss nicht während des Grei fprozesses mitbewegt werden . Dies erspart die Bewegung von schweren technischen Bauteilen .

**[p0006]**

In einer anderen vorteilhaften Ausgestaltungs form der Erfindung ist ein Elektromotor vorgesehen, der die translatorische Bewegung der Dauermagnetplatte gewährleistet . Dieser Elektromotor kann beispielsweise ein Servomotor oder ein Linearmotor sein, wobei auch mehrere Elektromotoren gleichzeitig zum Einsatz kommen können . Dabei kann der Linearmotor direkt die translatorische Bewegung aus führen, ein Servomotor, der in der Regel ein niedrigeres Gewicht aufweist , benötigt zudem noch eine Umlenkvorrichtung, die die rotatorische Bewegung des Servomotors in eine translatorische Bewegung umwandelt . Die Dauermagnetplatte ist dabei in ihrer magnetischen Polarisierung bevorzugt so ausgestaltet , dass die Breite von j eweils zwei Strei fen einer Nord-Süd-Polarisierung weniger als 25 % eines Magnetplattendurchmessers beträgt . Dieser prozentuale Anteil des Magnetplattendurchmessers ist bevorzugt geringer als 15 % und besonders bevorzugt geringer als 10 % . Es ist dabei anzustreben, dass die j eweils zwei Strei fen einer Nord-Süd-Polarisierung möglichst schmal sind, sodass das Magnetfeld der Dauermagnetplatte möglichst konstant ist . Dabei entspricht der Magnetplattendurchmesser im Wesentlichen dem Durchmesser der Grei f fläche . Weist die Magnetplatte oder die Grei f fläche eine nicht kreis förmige Geometrie auf , dann wird unter dem Begri f f Durchmesser der längste Abstand zwischen zwei Außenrändern der Grei fplatte bzw . der Dauermagnetplatte verstanden . Diese wäre in einem Rechteck oder Quadrat dann die Diagonale .

**[p0007]**

In einer weiteren Ausgestaltungs form der Erfindung ist es zweckmäßig, dass mittels eines Abstandes der Dauermagnetplatte von der Grei fplatte entlang der Lotgerade die Stärke eines Magnetfelds , das auf den zu grei fenden Gegenstand wirkt , einstellbar ist . Hierdurch kann auf das erforderliche Magnetfeld, das auf den zu grei fenden Gegenstand wirkt , eingegangen werden . Ferner ist es zweckmäßig, dass die Grei fvorrichtung eine Aufnahmevorrichtung für einen Roboterarm umfasst . Somit kann die Grei fvorrichtung an einem Roboterarm befestigt werden, um den Grei fvorgang aus zuführen . Unter einem Roboterarm ist dabei eine j egliche Vorrichtung des industriellen Maschinenbaus zu verstehen, bei dem die Grei fvorrichtung entsprechend der im Produktionsprozess erforderlichen Bewegungsabläufe bewegt werden kann . Ferner ist Bestandteil der Erfindung ein Roboterarm mit einer Grei fvorrichtung nach einem der Ansprüche 2 bis 13 . Dieser Roboterarm mit der Grei fvorrichtung weist dieselben Vorteile

**[p0008]**

auf , die bereits bezüglich der Grei fvorrichtung allein beschrieben sind . Weitere Ausgestaltungs formen der Erfindung und weitere Merkmale werden anhand der folgenden Figuren näher erläutert . Merkmale mit derselben Bezeichnung aber in unterschiedlichen Ausgestaltungs formen sind dabei mit denselben Bezugs zeichen versehen . Es handelt sich dabei um rein schematische Darstellungen, die keine Einschränkungen des Schutzbereiches darstellen . Dabei zeigen : Figur 1 einen Roboterarm mit einer Grei fvorrichtung, Figur 2 eine Explosionsdarstellung einer Grei fvorrichtung mit und ohne Gehäuse , Figur 3 einen Ausschnitt aus einer Grei fvorrichtung mit Grei fplatte und Magnetplatte und Antrieb in zwei verschiedenen Ansichten, Figur 4 einen Elektromotor zum Bewegen einer Magnetplatte mit Umlenkvorrichtung als Teil der Grei fvorrichtung und Figur 5 Beispiele für magnetische Polarisierung der Dauermagnetplatte . In Figur 1 ist ein Roboterarm 34 dargestellt , an dem eine Grei fvorrichtung 2 montiert ist . Die Grei fvorrichtung 2 dient dazu, zu grei fende Gegenstände 6 in einem Produktionsprozess zwischen zwei Produktionsschritten zu bewegen . Bei den zu grei fenden Gegenständen 6 handelt es sich insbesondere um magnetische Bleche , die unter anderem vor einem Sinterprozess in einer Grünkörperform vorliegen . Die zu grei fenden Gegenstände 6 im vorliegenden Beispiel weisen eine rotationssymmetrische Geometrie auf , mit einem Durchmesser, der üblicherweise zwischen 100 mm und 300 mm liegt . Die Dicke der zu grei fenden Grünkörperscheiben beträgt j edoch lediglich zwi-

**[p0009]**

sehen 100 pm und 400 pm . Das bedeutet , dass die zu grei fenden Gegenstände 6 sehr fragil sind, j edoch ferromagnetische Eigenschaften aufweisen . Die Grei fvorrichtung 2 ist in einer Explosionsdarstellung in Figur 2 schematisch dargestellt . Dabei ist zunächst in Figur 2b ein Gehäuse 4 vorgesehen, das eine Grei fplatte 10 umfasst . Die Grei fplatte 10 wiederum weist dabei eine Grei f fläche 8 auf , die dem zu grei fenden Gegenstand 6 zugewandt ist . Ferner weist die Grei fplatte 10 eine hier nicht expli zit sichtbare Fläche 14 auf , die der Grei f fläche 8 gegenüberliegt . Dieser Fläche 14 wiederum ist eine Dauermagnetplatte 12 zugewandt , die in der Ausgestaltung gemäß Figur 2a und 2b mit einer Trägerplatte 30 versehen ist . Ferner ist eine Motor- Montageplatte 31 vorgesehen, auf der ein Elektromotor 28 in Form eines Servomotors 29 montiert ist . Dabei ist anzumerken, dass die Bauteile Gehäuse 4 , Trägerplatte 33 und Motor-Montageplatte 31 grundsätzlich aus Leichtmetall wie Aluminium oder Magnesium (beispielsweise im Druckgussverfahren hergestellt ) oder durch einen tragfesten Kunststof f ausgestaltet sein können . Alle Bauteile können dabei durch ein additives Herstellungsverfahren beispielsweise im 3D-Druckverf ahren hergestellt werden . Das ist insbesondere bei Kunststof fbauteilen dann zweckmäßig, wenn zur Gewährleistung der mechanischen Stabilität komplexe Stützstrukturen für die Bauteile notwendig sind .

**[p0010]**

In Figur 3 ist in zwei verschiedenen Blickwinkeln ( Fig . 3a und 3b ) eine schematische Darstellung für die Umsetzung der translatorischen Bewegbarkeit der Dauermagnetplatte 12 bezüglich der Grei fplatte 10 beschrieben . Hierzu ist ein Elektromotor 28 in Form eines Servomotors 29 auf einer Motorenträgerplatte montiert ( insbesondere in Figur 3a zu erkennen) . Ferner ist eine Umlenkvorrichtung 30 vorgesehen, die dazu geeignet ist , eine rotatorische Bewegung des Servomotors 29 in eine translatorische Bewegung 26 der Trägerplatte 30 für die Dauermagnetplatte 12 zu gewährleisten . Dies geschieht bei- spielsweise über einen Exzenterhebel 42 , der in einen Transportzapfen 46 eingrei ft und somit durch die Exzenterbewegung des Exzenterhebels 42 die translatorische Bewegung 26 vollzieht . Dabei wird j e nach Drehstellung des Servomotors 29 ein bestimmter Hub der Trägerplatte 30 bezüglich der Motor- Montageplatte 31 bewerkstelligt . Dieser Hub wiederum bewirkt einen Abstand 36 zwischen der Grei fplatte 10 , genauer gesagt zwischen der Fläche 14 der Grei fplatte 10 und der Dauermagnetplatte 12 . Auf diese Weise ist mittels der translatorischen Bewegung 26 dieser Abstand 36 genau abstimmbar, sodass auch eine Magnetfeld 48 mit eine dezidierten Feldstärke und Feldlinienverlauf an der Grei f fläche 8 eingestellt werden kann .

**[p0011]**

In Figur 4 ist eine etwas detailliertere Ausgestaltung des Servomotors 29 mit dem Exzenterhebel 42 sowie dem Transportbol zen 46 , der in einer translatorischen Führungsschiene 44 gelagert ist , gegeben, wodurch durch die Exzenterbewegung die translatorische Bewegung 26 beschrieben wird . Als Alternativen hierzu wäre es auch möglich, die translatorische Bewegung 26 durch einen hier nicht dargestellten Linearmotor zu gewährleisten, wobei man sich hiermit die Umlenkvorrichtung 30 einsparen könnte . Der Servomotor 29 einschließlich der Umlenkvorrichtung 30 ist j edoch kostengünstiger und auch mit geringerem Gewicht darstellbar, als dies in der Regel ein Linearmotor ist . Somit haben beide Ausgestaltungen bestimmte Vorteile und bestimmte Nachteile . Eine weitere ebenfalls hier nicht dargestellte Ausgestaltung zur Gewährleistung der translatorischen Bewegung 26 ist der Einsatz einer Pneumatikvorrichtung, die gegenüber den Elektromotor 28-Lösungen den Vorteil hat , dass lediglich Pneumatikschläuche zur Trägerplatte 30 gelegt werden müssen, was eine zusätzliche Ge- wichtseinsparung mit sich bringt .

**[p0012]**

Das bereits beschriebene magnetische Feld 48 , das um die Grei f fläche 8 herum wirkt , wird durch die Dauermagnetplatte 12 induziert . Die Stärke des Magnetfeldes 48 wiederum hängt von dem Abstand 36 der Dauermagnetplatte 12 von der Grei f- platte 10 ab . Wird mittels der translatorischen Bewegung 26 die Dauermagnetplatte 12 nahe an die Grei fplatte 10 herangeführt , so übersteigt die Stärke des Magnetfeldes 48 eine kritische Größe , sodass es die zu grei fenden Gegenstände 6 an die Grei f fläche 8 anhaftet . Durch den Abstand 36 kann somit die Magnetfeldstärke 48 genau eingestellt werden, sodass die Kraft nur so groß ist , wie dass die empfindlichen Gegenstände 6 bezüglich ihrer mechanischen Belastbarkeit vertragen können . Das heißt wiederum, dass die Stellung des Servomotors 29 oder die Position eines hier nicht dargestellten Linearmotors die Stärke des Magnetfeldes 48 beeinflussen . Durch empirische Magnetfeldmessungen bei unterschiedlichen Abständen 36 kann somit ein Steuersignal an den Elektromotor 30 ergehen, der für die zu transportierenden Gegenstände 6 das richtige Magnetfeld bzw . die richtige Magnetfeldstärke einstellt .

**[p0013]**

Neben der geeigneten Magnetfeldstärke für den j eweiligen Gegenstand 6 ist bei fragilen Gegenständen 6 die Homogenität des Magnetfeldes 48 bedeutend . Daher wird in der vorliegend beschriebenen Ausgestaltung auch kein herkömmlicher Elektromagnet verwendet , der ein vergleichsweise inhomogenes Magnetfeld herbei führt , sondern es wird eine Dauermagnetplatte 12 zur Erzeugung des Magnetfeldes 48 bereitgestellt , die abwechselnd strei fenförmige Nord-Süd-Polarisierungen 18 an ihrer Oberfläche aufweist . Dabei ist zur Erzeugung eines möglichst homogenen Magnetfeldes 48 die Bereitstellung von möglichst schmalen Strei fen 20 der Nord-Süd-Polarisierung 18 zweckmäßig . Dies ist in verschiedenen Ausgestaltungs formen in der Figur 5a bis 5c gezeigt . In Figur 5a handelt es sich um eine kreisrunde Dauermagnetplatte 12 , die parallele Strei fen 20 mit Nord-Süd-Polarisierung 18 aufweist . Grundsätzlich kann die Dauermagnetplatte 12 auch andere Formen annehmen, für das Beispiel der zu grei fenden Magnetbleche , die in diesem Fall die zu grei fenden Gegenstände 6 bilden, ist eine kreisrunde Dauermagnetplatte zweckmäßig .

**[p0014]**

Dabei müssen die Strei fen 20 auch nicht parallel verlaufen, wie dies in Figur 5a der Fall ist , sondern es kann auch gemäß Figur 5b ein konzentrischer kreis förmiger Verlauf der Streifen 20 eingestellt sein . Zudem ist es gemäß Figur 5c zweckmäßig, wenn die Dauermagnetplatte in einzelne Kreissegmente 38 segmentiert ist , und die Nord-Süd-Polarisierung der Strei fen 20 entsprechend der Figur 5c in unterschiedliche Richtungen bezüglich des Mittelpunktes der kreis förmigen Ausgestaltung verlaufen . Eine Breite 22 eines Paares von Nord-Süd-Polarisierungen 18 , also von zwei Strei fen 20 zusammengenommen, sollte dabei so schmal sein, dass weniger als 25 % eines Durchmessers 40 der Dauermagnetplatte 12 davon ausgefüllt ist . Je schmaler die Breite 22 der Strei fen 20 ist , desto homogener wird das Magnetfeld 48 , das entlang der Grei f fläche 8 wirkt . Somit ist es zweckmäßig, dass die Breite 22 möglichst gering, bevorzugt geringer als 10 % des Durchmessers 40 ist . Wie bereits dargelegt , können alle tragenden Bauteile der Grei fvorrichtung 2 , also insbesondere die Grei fplatte 10 , die Trägerplatte 33 für die Dauermagnetplatte 12 sowie die Motor- Montageplatte 31 aus einem Leichtmetall oder einem Kunststof f gefertigt sein . Dies wiederum führt dazu, dass die gesamte Grei fvorrichtung 2 für sich genommen ein sehr geringes Gewicht aufweist , was wiederum die Möglichkeit mit sich bringt , dass sie an sogenannten kollaborativen Robotern montiert werden kann . Diese Roboter haben die Eigenschaft , dass sie in der Umgebung von menschlichem Bedienpersonal eingesetzt werden können,

**[p0014]**

und nicht , wie dies in industriellen Anwendungen in der Regel der Fall ist , in gesicherten und abgesperrten Bereichen betrieben müssen . Das heißt , die beschriebene Grei fvorrichtung 4 kann an einen Roboterarm 34 montiert sein, der in direkter Umgebung eines Bedieners eingesetzt wird . Insbesondere bei komplexen teilautomatisierten Prozessen ist dies ein technischer Vorteil gegenüber Grei fvorrichtungen 2 , die , wie im Stand der Technik üblich, mit schweren Elektromagneten oder Vakuumvorrichtungen ausgestattet sind .

**[p0015]**

2 Greifvorrichtung 4 Gehäuse 6 zu greifender Gegenstand 8 Greiffläche 10 Greifplatte 12 Dauermagnetplatte 14 Fläche (gegenüberliegend Greiffläche) 16 Lotgerade 18 Nord-Süd-Polarisierung 20 Streifen 22 Breite der Streifen 24 Greifflächendurchmesser 26 translatorische Bewegung 28 Elektromotor 29 Servomotor 30 Umlenkvorrichtung 31 Motor-Montageplatte 32 Aufnahmevorrichtung 33 Trägerplatte 34 Roboterarm 36 Abstand Dauermagnetplatte/Greifplatte 38 Dauermagnetsegmente 40 Magnetplattendurchmesser 42 Exzenterhebel 44 translatorische Führungsschiene 46 Transport zapf en 48 Magnetfeld

## Classifications

- B25J15/0608
- B25J15/06

## Cited patent documents

- [DE-102010040642-B4](https://patents.google.com/patent/DE102010040642B4/en) — ISR
- [JP-2016124096-A](https://patents.google.com/patent/JP2016124096A/en) — ISR
- [US-2021031317-A1](https://patents.google.com/patent/US20210031317A1/en) — ISR

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
