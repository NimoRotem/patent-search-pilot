# 32. Gripper and method of manufacturing the gripper

- **Archive rank:** 32 of 50
- **Publication:** [US-6935666-B2](https://patents.google.com/patent/US6935666B2/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/011737206/publication/US6935666B2?q=pn%3DUS6935666B2)
- **Publication date:** 2005-08-30
- **Filing date:** 2001-03-30
- **Earliest priority:** 2001-03-30
- **Family:** 11737206
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** MITSUBISHI ELECTRIC CORP
- **Inventors:** MURAMATSU NAOKI; TADA TOMOYOSHI

## Abstract

The present invention is a gripper comprising a motor  12  for driving a connecting nut  126  that is translated, a gripping finger  103  having at least two sides of substantial V shape and a shared portion  103   g  for joining one ends of the two sides, and provided with the other ends of the sides, a base member  110  with a notch  110   c  for engaging the other end portion of the gripping member  103 , a holder member  145  having a groove  145   e  for engaging the base member  110  detachably and the hollow portions  145   m  and  145   h  that are penetrated, and a magnetic member  128  composed of a permanent magnet inserted into the hollow portions  145   m  and  145   h  of the holder member  145 , with one end connected to the connecting nut  126 , and the other end magnetically connected to the shared portion  103   g  of the gripping finger  103.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-6935666-B2/000.png)

![Sketch 1 for US-6935666-B2](https://nimo.iptorch.com/refdrawing/US-6935666-B2/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/US-6935666-B2/001.png)

![Sketch 2 for US-6935666-B2](https://nimo.iptorch.com/refdrawing/US-6935666-B2/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/US-6935666-B2/002.png)

![Sketch 3 for US-6935666-B2](https://nimo.iptorch.com/refdrawing/US-6935666-B2/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/US-6935666-B2/003.png)

![Sketch 4 for US-6935666-B2](https://nimo.iptorch.com/refdrawing/US-6935666-B2/003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/US-6935666-B2/004.png)

![Sketch 5 for US-6935666-B2](https://nimo.iptorch.com/refdrawing/US-6935666-B2/004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/US-6935666-B2/005.png)

![Sketch 6 for US-6935666-B2](https://nimo.iptorch.com/refdrawing/US-6935666-B2/005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/US-6935666-B2/006.png)

![Sketch 7 for US-6935666-B2](https://nimo.iptorch.com/refdrawing/US-6935666-B2/006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/US-6935666-B2/007.png)

![Sketch 8 for US-6935666-B2](https://nimo.iptorch.com/refdrawing/US-6935666-B2/007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/US-6935666-B2/008.png)

![Sketch 9 for US-6935666-B2](https://nimo.iptorch.com/refdrawing/US-6935666-B2/008.png)

## Claims

### Claim 1 (independent)

A gripper comprising: an actuator for actuating a movement portion which translates; a gripping member comprising: two sides of a substantial V shape; and a shared portion joining first ends of said two sides; a holder member comprising: a base member including a first engagement portion for engaging second ends of said two sides of said gripping member thereto; a second engagement portion for engaging said base member detachably thereto; and a hollow portion, which is penetrated; and a magnetic member made of a permanent magnet, wherein: an outer end of the magnetic member is connected to one end of said movement portion; an inner end of the magnetic member is magnetically connected to the shared portion of said gripping member; and the magnetic member is inserted into said hollow portion of said holder member.

### Claim 2

The gripper according to claim 1 , wherein a first slit is defined at each of the second ends of said gripping member.

### Claim 3

The gripper according to claim 1 , further comprising a connecting nut arranged between the shared portion of the gripping member and the magnet, wherein the connecting nut is formed of a magnetic substance so that it is attracted to the magnetic member.

### Claim 4

The gripper according to claim 3 , further comprising a screw connecting the shared portion of the gripping member to the connecting unit.

### Claim 5 (independent)

A gripper comprising: an actuator for actuating a movement portion which translates; a gripping member comprising: two sides of a substantial V shape; and a shared portion joining first ends of said two sides; a base member comprising: a bore punched in the central portion thereof; an engagement portion for engaging a second end portion of said gripping member thereto; and at least two protrusion pieces on an outer circumference; a holder member comprising at least two grooves for engaging said protrusion pieces of said base member detachably therewith, and a hollow portion, which is penetrated; a magnetic member, comprising a permanent magnet, inserted into said hollow portion of said holder member so that an outer end of which is connected to said movement portion; and a connection member comprising: a front end is adsorbed magnetically to an inner end of said magnetic member; and a back end connected to the shared portion of said gripping member, wherein the connection member is inserted into said hollow portion of said holder member.

### Claim 6

The gripper according to claim 5 , further comprising a screw member, wherein said connection member has a tapped hole at the back end thereof; and wherein the screw member is inserted into a bore of the shared portion of said gripping member and is tightened into the tapped hole of said connection member.

### Claim 7

The gripper according to claim 6 , wherein said screw member is cylindrical, and further comprises: a head portion comprising a minus sign shaped or plus sign shaped groove; a screw portion tightened into the tapped hole of said connection member; and a screw preventing portion having a diameter larger than said screw portion and smaller than said head portion and having a length greater than the thickness of said shared portion of said gripping member, said screw preventing portion provided between said head portion and said screw portion.

### Claim 8

The gripper according to claim 5 , wherein said protrusion pieces of said base member define second slits.

### Claim 9

The gripper according to claim 5 , wherein said shared portion of said gripping member has a slip-off prevention piece having a larger diameter than the diameter of the bore of said base member.

### Claim 10

The gripper according to claim 5 , wherein a first slit is defined at the second end portion of said gripping member

### Claim 11 (independent)

A method for manufacturing the gripper comprising: an actuator for actuating a movement portion which translates; a gripping member comprising at least two sides of substantial V shape, and a shared portion joining first end of said two sides; a base member comprising a bore punched in the central portion thereof, an engagement portion for engaging a second end portion of said gripping member thereto, and at least two protrusion pieces on an outer circumference; a holder member comprising at least two grooves for engaging said protrusion pieces of said base member detachably therewith, and a hollow portion, which is penetrated; a magnetic member, comprising a permanent magnet, inserted into said hollow portion of said holder member, so that an outer end of which is connected to said movement portion; and a connection member comprising a front end adsorbed magnetically to a back end of said magnetic member; and a second end connected to the shared portion of said gripping member, wherein the connection member is inserted into said hollow portion of said holder member, the method comprising: engaging the protrusion pieces of said base member with the grooves of said holder member by pressing side surfaces of the protrusion pieces of said base member with a first groove provided on the side face of a cylindrical member having a hollow portion into which said gripping member can be inserted.

## Full description

### Technical Field

**[p0001]**

The present invention relates to a gripper for use in conveying or assembling a minute part with improvements in replacement operation of a gripping finger.

### Background Art

**[p0002]**

A conventional gripper will be described below with reference to FIG. 10 as disclosed in the International Publication Number WO00/45999. In FIG. 10 , the gripper 1 has a gripping finger 10 for gripping or releasing a minute object and having three V-character pieces 10 v of substantial V shape, a conversion portion 20 for converting the rotation of a motor shaft 12 a of a motor 12 into translation motion, the conversion portion 20 being connected to a shared portion 10 g of the gripping finger 10 , a connection portion 30 for connecting the conversion portion 20 and the shared portion 10 g of the gripping finger 10 , a case portion 40 for accommodating the motor 12 , the conversion portion 20 and the connection portion 30 , and a fixing portion 50 for fixing a fixing pawl 10 t of the gripping finger 10 to the case portion 40 . The conversion portion 20 comprises a screw axis 22 for fitting and securing the motor shaft 12 a of the motor 12 and having a male screw 22 a around the outer circumference thereof, and a nut 26 for inserting the screw axis 22 and having a hollow portion formed with a female screw 26 a to be mated with the male screw 22 a , in which the rotation of the motor shaft 12 a of the motor 12 is converted into translation motion of the nut 26 .

**[p0003]**

The connection portion 30 is formed with a protruding portion 26 c having a tapped hole centrally at the top end of the nut 26 , in which the shared portion 10 g of the gripping finger 10 is secured into this tapped hole by a screw 32 . The case portion 40 is formed of a cylindrical case 41 for receiving the motor 12 and a part of the screw axis 22 , a lid 43 for closing a right end face of the case 41 , and a holder member 45 engaged with a left end face of the case 41 , in which the holder member 45 is like a barrel having a through hole, with a substantially trapezoidal shape in cross section, and has a female screw 45 b on the outer face of a hollow portion 45 a at the top end. The fixing portion 50 is formed with a male screw for mating with the female screw 45 b of the holder member 45 on an external circumferential face of a cylindrical presser ring 53 . The fixing pawl 10 t of the gripping finger 10 abuts onto the hollow portion 45 a of the holder member 45 , and the fixing portion 50 is securely pressed by the presser ring 53 .

**[p0004]**

Referring to FIG. 10 , the operation of the gripper as constituted above will be described below. First of all, the motor 12 is powered on, and then the motor shaft 12 a of the motor 12 is rotated, so that this rotation is transmitted via the screw axis 22 to the nut 26 to move the nut 26 in a right direction as indicated in FIG. 10 . Along with this, the shared portion 10 g of the gripping finger 10 is forcibly displaced by the same amount of displacement in the same direction, and the gripping finger 10 is subjected to a bending moment, so that the V-character pieces are bent at the top end portion in the direction coming closer to each other and closed to grip an object. On the contrary, if the rotation of the motor 12 is reversed, with this rotation, the nut 26 is translated via the screw axis 22 in a reverse direction, and the shared portion 10 g of the gripping finger 10 is also translated by the same amount of displacement in the consistent manner, so that the top end portions of the gripping finger 10 release the object.

**[p0005]**

However, if the gripping object of the gripping finger 10 is spherical, the gripping finger 10 maybe composed of three fingers as above described, but if the object is like a square pole, the gripping finger must be composed of two fingers (not shown) to grip the object appropriately. Also, the gripping finger 10 must be exchanged due to expiration of life, if a predetermined number of operation times is exceeded. Such an exchange is perform in such a way that the screw 32 is firstly turned by a screwdriver (not shown) to release engagement of the protruding portion 26 c of the nut 26 into the tapped hole, and then the presser ring 53 is turned by a spanner (not shown) to unscrew the holder member 45 from the female screw 45 b , thereby detaching the gripping finger 10 . In order to attach the gripping finger 10 on the holder member 45 , the screw 32 is tightened into the tapped hole of the protruding portion 26 c by the screwdriver, the presser ring 53 is turned by the spanner and mated with the female screw 45 b of the holder member 45 . Thus, there was a problem that the exchange operation of the gripping member 10 was troublesome.

**[p0006]**

In addition, in the case where the gripper 1 is employed for an end effector of a robot, and particularly is attached vertically downward at the top end portion of a scalar robot to be actuated horizontally, the gripper 1 can not be disposed sideways or upward, resulting in a problem that the exchange operation of the gripping finger 10 alone was troublesome. This invention is aimed at providing a gripper and its manufacturing method in which a gripping member is easily attached.

### Summary Of The Invention

**[p0007]**

A gripper according to a first invention comprises an actuator for actuating a movement portion which translates, a gripping member having at least two sides of substantial V shape, a shared portion for joining one ends of said two sides, and the other ends of said sides, a holder member having a base member including a first engagement portion for engaging the other ends of said gripping member thereto, a second engagement portion for engaging said base member detachably thereto, and a hollow portion, which is penetrated, and a magnetic member made of a permanent magnet, the magnetic member one end of which is connected to one end of said movement portion, the magnetic member the other end of which is magnetically connected to the shared portion of said gripping member, the magnetic member inserted into said hollow portion of said holder member. With this constitution of the gripper, the other end portion of the gripping member is engaged with the first engagement portion of the base member, the base member is engaged with the second engagement portion of the holder member, and the shared portion of the gripping member is magnetically connected to the other end of the magnetic member, whereby the gripping member can be engaged with the base member, and the base member attached to the holder member in simple manner.

**[p0008]**

Further, the base member attached to the holder member is disengaged from the second engagement portion of the holder member, and the shared portion of the gripping member is removed from the other end of the magnetic member by pulling it with a stronger force than a magnetic adsorption of the magnetic member. Accordingly, there is the effect that the base member having the gripping member can be easily removed from the holder member. A gripper according to a second invention comprises an actuator for actuating a movement portion which translates, a gripping member having at least two sides of substantial V shape, a shared portion for joining one ends of said two sides, and the other ends of said sides, a base member having a bore punched in the central portion thereof, an engagement portion for engaging an end portion of said gripping member thereto, and at least two protrusion pieces around outer circumference, a holder member having at least two grooves for engaging said protrusion pieces of said base member detachably therewith, and a hollow portion, which is penetrated, a magnetic member made of a permanent magnet, the magnetic member inserted into said hollow portion of said holder member, the magnetic member one end of which is connected to said movement portion, and a connection member one end of which is adsorbed magnetically to the other end of said magnetic member, the connection member the other end of which is connected to the shared portion of said gripping member, the connection member inserted into said hollow portion of said holder member.

**[p0009]**

With this constitution of the gripper, the end portion of the gripping member is engaged with the engagement portion of the base member, the protrusion piece of the base member is engaged with the groove of the holder member, and the shared portion of the gripping member is connected to the other end of the connection member, whereby the gripping member and the base member are attached to the connection member and the holder member, respectively. The protrusion piece of the base member is removed from the groove of the holder member, and the shared portion of the gripping member is pulled to detach one end of the connection member from the other end of the magnetic member, whereby the gripping member and the base member are removed from the connection member and the holder member, respectively. Accordingly, there is the effect that the gripping member and the base member can be easily removed from the connection member and the holder member, respectively. For example, if the protrusion piece of the base member is engaged in the groove provided on the side face of the cylindrical member having the hollow portion into which the gripping member can be inserted in a state where the base member is attached to the holder member, the protrusion piece of the base member is easily removed from the groove of the holder member.

**[p0010]**

The gripper according to a third invention is characterized in that a first slit is defined at the other end portion of said gripping member. With the constitution of the gripper, there is the effect that if the operator depresses an end portion of the gripping member, for example, the end portion is compressed owing to a spring action, and can be easily engaged with the engagement portion of the base member. The gripper according to a fourth invention is characterized in that said connection member has a tapped hole at the other end portion thereof, and the screw member is inserted into a bore of the shared portion of said gripping member and is tightened into the tapped hole of said connection member. With the constitution of the gripper, there is the effect that the shared portion of the gripping member can be simply attached to or detached from the connection member by means of the screw member. The gripper according to a fifth invention is characterized in that said screw member is cylindrical, and further comprises a head portion formed a minus signal shaped or plus signal shaped groove, a screw portion tightened into the tapped hole of said connection member, and a screw preventing portion having a diameter larger than said screw portion and smaller than said head portion and having a length greater than the thickness of said shared portion of said gripping member, said screw preventing portion provided between said head portion and said screw portion.

**[p0011]**

With the constitution of the gripper, when the screw member is inserted into the bore of the gripping member, and tightened into the tapped hole of the connection member by a screwdriver, for example, the screw preventing portion prevents the threaded portion of the screw member from proceeding. Accordingly, there is the effect that the gripping member is kept from being deformed due to tightening the screw member beyond the tolerance. The gripper according to a sixth invention is characterized in that said protrusion pieces of said base member define second slits. With the constitution of the gripper, when the protrusion piece of the base member with the gripping member is inserted into the groove of the holder member, the protrusion piece acts as a compression spring owing to the second slit provided in the base member. Accordingly, there is the effect that the protrusion piece of the base member with the gripping member is easily inserted into the groove of the holder member. The gripper according to a seventh invention is characterized in that said shared portion of said gripping member has a slip-off prevention piece having a larger diameter than the diameter of the bore of said base member.

**[p0012]**

With the constitution of the gripper, when the base member is pulled out of the holder member, the slip-off prevention piece of the gripping member abuts against an upper portion of the inner circumferential face of the base member at a predetermined displacement, even though the shared portion of the base member is pulled. Thus, there is the effect that the shared portion of the gripping member is restrained in the amount of movement, thereby preventing the sides of the gripping member from being contacted and pressed against each other, and being deformed. Also, there is the same effect when the gripping member is pulled and detached, because the slip-off prevention piece of the gripping member abuts against an upper portion of the inner circumferential face of the base member A method for manufacturing the gripper according to an eighth invention includes the steps of engaging the protrusion pieces of said base member with a engagement bore of said holder member by pressing side surfaces of the protrusion pieces of said base member with a first groove provided on a side face portion of a cylindrical member having a hollow portion into which said gripping member can be inserted.

**[p0013]**

Accordingly, the protrusion piece of the base member can be simply engaged into the engagement hole of the holder member, whereby there is the effect that the base member is easily attached on the holder member.

### Brief Description Of Drawings

**[p0014]**

FIG. 1 is a front cross-sectional view showing the constitution of a gripper. FIG. 2 is a perspective view of a finger unit as shown in FIG. 1 . FIG. 3 is a plan view showing a state where a gripping finger of FIG. 1 is expanded. FIG. 4 is a front cross-sectional view showing the finger unit and a part of a connection portion as shown in FIG. 1 . FIG. 5 is a plan view showing a base member for fixing an end portion of the gripping finger of FIG. 1 . FIG. 6A is a plan view of a connecting nut as shown in FIG. 1 , and FIG. 6B is a front cross-sectional view of the connecting nut, taken along the arrow b—b in FIG. 6 A. FIG. 7 is a front view of a center screw as shown in FIG. 1 . FIG. 8 is a front cross-sectional view of a holder member as shown in FIG. 1 . FIGS. 9 ( a ) through 9 ( c ) are explanatory views showing an adjuster that is an assembly jig. FIG. 10 is a front cross-sectional view showing the conventional gripper.

### Best Mode For Carrying Out The Invention

**[p0015]**

The preferred embodiments of the present invention will be described below. Embodiment 1 Referring to FIGS. 1 to 8 , an embodiment 1 of this invention will be described below. FIG. 1 is a front cross-sectional view showing the constitution of a gripper. FIG. 2 is a perspective view of a finger unit. FIG. 3 is a plan view showing a state where a gripping finger is expanded. FIG. 4 is a front cross-sectional view showing the finger unit and a part of a connection portion. FIG. 5 is a plan view showing a base member for fixing an end portion of the gripping finger. FIG. 6A is a plan view of a connecting nut. FIG. 6B is a front cross-sectional view of the connecting nut taken along an arrow b—b in FIG. 6 A. FIG. 7 is a front view of a center screw. FIG. 8 is a front cross-sectional view of a holder member. In FIG. 1 , the same or like parts are designated by the same numerals as in FIG. 10 . The description of those parts is omitted. In FIGS. 1 to 8 , a gripper 100 has a finger unit 101 , a motor 12 as an actuator connected to a shared portion 103 g of a gripping finger 103 and having a shaft 12 a for translating the shared portion 103 g , a conversion portion 120 for converting the rotation of the shaft 12 a of the motor 12 into translation motion, a connection portion 130 connected to the conversion portion 120 and the shared portion 103 g of the gripping finger 103 , and a case portion 140 for accommodating the motor 12 , the conversion portion 120 and the connection portion 130 and fixing the finger unit 101 .

**[p0016]**

The finger unit 101 has the gripping finger 103 as a gripping member and a base member 110 , as shown in FIG. 2 . The gripping finger 103 has two V-character pieces 103 v of substantial V shape that are opened or closed when the top end portions are widened by pulling or restoring one end in accordance with a translation displacement to grip a minute object. The gripping finger 103 expanded as shown in FIG. 3 is symmetrical with respect to a dotted line O, and is bent downward on the paper along a broken line L, bent upward on the paper along a broken line M, and bent downward on the paper along a broken line N to form the gripping finger 103 as shown in FIG. 4 . The gripping finger 103 has the shared portion 103 g in the central portion, each leg portion 103 f of the gripping finger 103 being formed with a slit (first slit) 103 s in the center and a cut-away end portion 103 t on either outer side. The shared portion 103 g of the gripping finger 103 is formed with a slip-off prevention piece 103 n having a larger diameter than the diameter of a bore 110 e of the base member 110 and with a bore 103 e punched in the central portion.

**[p0017]**

The base member 110 is like a plain washer, and has the bore 110 e punched in the center and two protrusion pieces 110 t provided around the outer circumference, as shown in FIG. 5 . The base member 110 is provided with two notches 110 c as a first engagement portion that are engaged by holding the leg portions 103 f of the finger 103 , as shown in FIG. 5 . The protrusion piece 110 t is provided with a slit 110 s (second slit) and formed with a circular slit 110 g continuous to the slit 110 s and extending to a ring portion of the base member 110 . The width of the slits 110 s , 110 g is formed in such an extent that if the protrusion piece 110 t is pressed by holding it from side faces thereof, whereby the protrusion piece 110 t is compressed due to a spring force, and the protrusion piece 110 t is inserted into a groove 145 e of the holder member 145 as will be described later and released holding, the protrusion piece 110 t can be restored due to a spring force and engaged in the groove 145 e.

**[p0018]**

The circular slit 110 g may not be needed depending on the magnitude of spring force. The notch 110 c of the base member 110 has a substantial T shape as seen in a plan view, and is wider in depth than an opening. The width of the notch 110 c in depth is formed slightly smaller than the width of an end portion 103 t of the gripping finger 103 at the top end. Thereby, the end portion 103 t is inserted into the notch 110 c by carrying both sides of the leg portion 103 f of the gripping finger 103 and abutted against the depth portion of the notch 110 c , and then the leg portion 103 f is released to engage the end portion 103 t with the notch 110 c . In this manner, the finger unit 101 is formed. The conversion portion 120 has a moving nut 126 as a movement portion that is mated with the male screw 22 a of the screw axis 22 and has a female screw 126 a on the outer face of a hollow portion formed by cutting the rear end, in which the rotation of the shaft 12 a of the motor 12 is converted into a translation displacement of the moving nut 126 .

**[p0019]**

The moving nut 126 has a rectangular outer shape to prevent rotation and is formed with a cylindrical hollow portion 126 e at the front end. The connection portion 130 has a cylindrical magnet 128 as a cylindrical magnetic member made of rare earth magnet, in which the cylindrical magnet 128 has an outer diameter slightly smaller than the bore diameter of the hollow portion 126 e in the moving nut 126 , with one end portion being inserted into the hollow portion 126 e and fixed by adhesives, a connecting nut 132 as a connection member made of magnetic substance such as iron steel that is magnetically adsorbed and fixed on the other end face of the cylindrical magnet 128 , and a center screw 134 inserted into the bore 103 e of the shared portion 103 g in the gripping finger 103 and screwed into the tapped hole 132 e (see FIG. 6 ) of the connecting nut 132 . In the case where the moving nut 126 is made of magnetic substance, it is not required that one end portion of the cylindrical magnet 128 is fixed to the hollow portion 126 e of the moving nut 126 by adhesives. Because it is fixed by adsorption due to a magnetic suction force of the cylindrical magnet 128 .

**[p0020]**

The connecting nut 132 is formed like an inverse T shape in cross section and is provided with a cylindrical portion 132 a and an interposing portion 132 d having two flat interposing faces 132 c opposed to each other to be easily turned by the spanner, as shown in FIG. 6 . The center screw 134 as the screw member is provided with a head portion 134 a having a minus sign shaped groove 134 c , a screw portion 134 d mated into the tapped hole 132 e of the connecting nut 132 , and a cylindrical screw preventing portion 134 f provided between the head portion 134 a and the screw portion 134 d , the screw preventing portion 134 f having a larger diameter than the screw portion 134 d and having a greater length than the thickness of gripping finger 101 at the end, as shown in FIG. 7 . The screw preventing portion 134 f is formed to be slightly smaller than the diameter of the bore 103 e in the gripping finger 103 . This is because the screw preventing portion 134 f is inserted into the bore 103 e of the gripping member 103 , and is movable within the bore 103 e.

**[p0021]**

The groove 134 c of the center screw 134 may be plus sign shaped. The case portion 140 is formed of a lid 43 , and a holder member 145 engaged with a left end face of the case 41 and holding the finger unit 101 detachably. The holder member 145 has formed a top end hollow portion 145 m for receiving the cylindrical magnet 128 and the center screw 134 in the central portion, which contains the connection portion 130 and is formed like a barrel with substantially trapezoidal shape in cross section, and a rear end hollow portion 145 h for receiving the moving nut 126 , as shown in FIGS. 1 and 8 . The holder member 145 is provided, at the top end portion, with a fixing portion 145 f , which is formed to be hollow and cylindrical with substantially concave shape in cross section and fixing the base member 110 of the finger unit 101 . The fixing portion 145 f is provided with two grooves 145 e as the second engagement portion, into which the protrusion piece 110 t of the base member 110 is inserted and fitted.

**[p0022]**

In a state where the protrusion piece 110 t is fitted into the groove 145 e , a top end of the protrusion piece 110 t is slightly protruded out of the outer circumference of the holder member 145 , as shown in FIG. 1 . The gripper 100 as constituted above can perform the substantially same operation as the conventional gripper. The assembly of the gripper as constituted above will be described below with reference to FIGS. 1 to 9 . Constitution of Assembly Jig Referring to FIG. 9 , an assembly jig will be described below. FIG. 9 is a front cross-sectional view (A), a right side view (B) and a plan view (C) of an adjuster for attaching the finger unit to the finger holder. In FIG. 9 , the adjuster 200 is a cylindrical member having a bore 200 e , having two protruding portions 200 b and 200 d on the upper and lower sides at the ends 200 a and 200 c , in which the protruding portions 200 b and 200 d are provided with the grooves 200 i and 200 h for interposing two protrusion pieces 110 t of the base member 110 in the finger unit 101 .

**[p0023]**

A groove 200 h has a slightly smaller width than the protrusion piece 110 t of the base member 110 , and is formed corresponding to the position of the protrusion piece 110 t . A groove 200 i is formed to be a slightly smaller width than the groove 200 h. Attaching or Detaching the Finger Unit 101 An operation of attaching or detaching the finger unit 101 to or from the holder member 145 using the adjuster 200 will be described below. First of all, when the finger unit 101 , the connecting nut 132 and the center screw 134 are not attached in FIG. 1 , and when the finger unit 101 is in a state of FIG. 2 , the screw portion 134 d of the center screw 134 is passed through the bore 103 e of the shared portion 103 g in the gripping finger 103 and mated into the tapped hole 132 e of the connecting nut 132 , as shown in FIG. 3 . While the bore 200 e of the adjuster 200 is being put on the gripping finger 103 from the above, the groove 200 h of the adjuster 200 is slidingly pressed on the side face of the protrusion piece 110 t of the base member 110 . Since a pressing force is exerted to interpose the protrusion piece 110 t , the protrusion pieces 110 t are elastically deformed toward each other under the pressure of the adjuster 200 , thereby narrowing the gap between the slits 110 s , so that the width of the protrusion piece 110 t is equal to that of the groove 200 h of the adjuster 200 .

**[p0024]**

And the protrusion piece 110 t of the base member 110 is engaged in the groove 200 h . In this engaged state, the protrusion piece 110 t is fitted into the groove 145 e of the holder member 145 , and interposed under a predetermined compression force, thereby attaching the finger unit 101 on the holder member 145 . Since the compression force of the groove 200 h of the adjuster 200 is released by fitting the protrusion piece 110 t into the groove 145 e of the holder member 145 , the groove 200 h of the adjuster 200 is easily detached from the protrusion piece 110 t of the base member 110 . At the same time, an end face of the connecting nut 132 is magnetically adsorbed onto an end face of the cylindrical magnet 128 , thereby completing the gripper 100 as shown in FIG. 1 . On the other hand, in the gripper 100 as shown in FIG. 1 , the protrusion piece 110 t is subjected to a pressure with one end 200 c of the adjuster 200 in contact with the finger unit 101 , and further compressed, while sliding it on the side face of the protrusion piece 110 t of the base member 110 , to be engaged in the groove 200 i of the adjuster 200 , whereby the protrusion piece 110 t is disengaged from the groove 145 e of the holder member 145 .

**[p0025]**

If the adjuster 200 is lifted, the center screw 134 and the connecting nut 132 connected to the finger unit 101 are lifted at the same time, and an end face of the connecting nut 132 is released from the magnetic adsorption with an upper face of the cylindrical magnet 128 , whereby the finger unit 101 , the center screw 134 and the connecting nut 132 can be easily removed from a main body of the gripper 100 . In lifting the finger unit 101 by means of the adjuster. 200 , the slip-off prevention piece 103 n of the finger 103 abuts against the surface of the base member 110 to act as a stopper. Accordingly, the shared portion 103 g of the finger 103 is restrained in the amount of movement, thereby preventing the V-character sides 103 v of the gripping finger 103 from being contacted and pressed to deform the V-character sides 103 v. The members described in this specification are only illustrative, and the invention is not limited to those members.

**[p0026]**

Industrial Applicability As described above, the gripper of the present invention is suitable for exchanging the gripping member simply.

## Figure captions

- **Figure 10:** Referring to FIG. 10 , the operation of the gripper as constituted above will be described below. First of all, the motor 12 is powered on, and then the motor shaft 12 a of the motor 12 is rotated, so that this rotation is transmitted via the screw axis 22 to the nut 26 to move the nut 26 in a right direction as indicated in FIG. 10 .
- **Figure 1:** FIG. 1 is a front cross-sectional view showing the constitution of a gripper.
- **Figure 2:** FIG. 2 is a perspective view of a finger unit as shown in FIG. 1 .
- **Figure 3:** FIG. 3 is a plan view showing a state where a gripping finger of FIG. 1 is expanded.
- **Figure 4:** FIG. 4 is a front cross-sectional view showing the finger unit and a part of a connection portion as shown in FIG. 1 .
- **Figure 5:** FIG. 5 is a plan view showing a base member for fixing an end portion of the gripping finger of FIG. 1 .
- **Figure 6A:** FIG. 6A is a plan view of a connecting nut as shown in FIG. 1 , and FIG. 6B is a front cross-sectional view of the connecting nut, taken along the arrow b—b in FIG. 6 A.
- **Figure 7:** FIG. 7 is a front view of a center screw as shown in FIG. 1 .
- **Figure 8:** FIG. 8 is a front cross-sectional view of a holder member as shown in FIG. 1 .
- **Figure 9:** FIGS. 9 ( a ) through 9 ( c ) are explanatory views showing an adjuster that is an assembly jig.
- **Figure 10:** FIG. 10 is a front cross-sectional view showing the conventional gripper.
- **Figure 1:** In FIG. 1 , the same or like parts are designated by the same numerals as in FIG. 10 . The description of those parts is omitted.
- **Figure 2:** The finger unit 101 has the gripping finger 103 as a gripping member and a base member 110 , as shown in FIG. 2 . The gripping finger 103 has two V-character pieces 103 v of substantial V shape that are opened or closed when the top end portions are widened by pulling or restoring one end in accordance with a translation displacement to grip a minute object.
- **Figure 6:** The connecting nut 132 is formed like an inverse T shape in cross section and is provided with a cylindrical portion 132 a and an interposing portion 132 d having two flat interposing faces 132 c opposed to each other to be easily turned by the spanner, as shown in FIG. 6 .
- **Figure 1:** The holder member 145 has formed a top end hollow portion 145 m for receiving the cylindrical magnet 128 and the center screw 134 in the central portion, which contains the connection portion 130 and is formed like a barrel with substantially trapezoidal shape in cross section, and a rear end hollow portion 145 h for receiving the moving nut 126 , as shown in FIGS. 1 and 8 .
- **Figure 1:** In a state where the protrusion piece 110 t is fitted into the groove 145 e , a top end of the protrusion piece 110 t is slightly protruded out of the outer circumference of the holder member 145 , as shown in FIG. 1 .
- **Figure 1:** The assembly of the gripper as constituted above will be described below with reference to FIGS. 1 to 9 .
- **Figure 9:** Referring to FIG. 9 , an assembly jig will be described below. FIG. 9 is a front cross-sectional view (A), a right side view (B) and a plan view (C) of an adjuster for attaching the finger unit to the finger holder.
- **Figure 9:** In FIG. 9 , the adjuster 200 is a cylindrical member having a bore 200 e , having two protruding portions 200 b and 200 d on the upper and lower sides at the ends 200 a and 200 c , in which the protruding portions 200 b and 200 d are provided with the grooves 200 i and 200 h for interposing two protrusion pieces 110 t of the base member 110 in the finger unit 101 .
- **Figure 1:** First of all, when the finger unit 101 , the connecting nut 132 and the center screw 134 are not attached in FIG. 1 , and when the finger unit 101 is in a state of FIG. 2 , the screw portion 134 d of the center screw 134 is passed through the bore 103 e of the shared portion 103 g in the gripping finger 103 and mated into the tapped hole 132 e of the connecting nut 132 , as shown in FIG. 3 .

## Classifications

- B25J15/0475
- B25J15/0475
- B25B9/00
- B25B9/00
- B25B9/00
- B25B9/02
- B25B9/02
- B25B9/02
- B25J15/12
- B25J15/12
- B25J15/12
- B25J7/00
- B25J7/00
- B25J7/00

## Cited patent documents

- [JP-H05293778-A](https://patents.google.com/patent/JPH05293778A/en) — APP
- [JP-H11260480-A](https://patents.google.com/patent/JPH11260480A/en) — APP
- [JP-S5959382-A](https://patents.google.com/patent/JPS5959382A/en) — APP
- [US-5020964-A](https://patents.google.com/patent/US5020964A/en) — SEA
- [US-5651574-A](https://patents.google.com/patent/US5651574A/en) — SEA
- [US-5884951-A](https://patents.google.com/patent/US5884951A/en) — SEA
- [WO-0024599-A1](https://patents.google.com/patent/WO0024599A1/en) — APP
- [WO-9930877-A1](https://patents.google.com/patent/WO9930877A1/en) — APP

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
