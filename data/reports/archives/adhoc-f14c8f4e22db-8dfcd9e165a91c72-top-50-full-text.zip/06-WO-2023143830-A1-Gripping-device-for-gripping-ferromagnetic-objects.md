# 06. Gripping device for gripping ferromagnetic objects

- **Archive rank:** 6 of 50
- **Publication:** [WO-2023143830-A1](https://patents.google.com/patent/WO2023143830A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/084943591/publication/WO2023143830A1?q=pn%3DWO2023143830A1)
- **Publication date:** 2023-08-03
- **Filing date:** 2022-12-21
- **Earliest priority:** 2022-01-25
- **Family:** 84943591
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** SCHMALZ J GMBH
- **Inventors:** CLAUSS JOHANNES; STORZ MICHAEL

## Abstract

The invention relates to a gripping device (10) for gripping ferromagnetic objects, comprising: a contact surface (16) for an object to be gripped; a magnet for providing a magnetic effect at the contact surface in order to grip the object; a first pole shoe (20) and a second pole shoe (22) which interact with the magnet in such a way that the first pole shoe provides a magnetic south pole (34) and the second pole shoe provides a magnetic north pole (36). A first portion (46) of the contact surface is provided on the first pole shoe and a second portion (48) of the contact surface is provided on the second pole shoe. The first and the second pole shoe can be moved relative to the magnet in order to adjust the magnetic effect provided at the contact surface within an adjustment range.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf000.png)

![Sketch 1 for WO-2023143830-A1](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf001.png)

![Sketch 2 for WO-2023143830-A1](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf002.png)

![Sketch 3 for WO-2023143830-A1](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf003.png)

![Sketch 4 for WO-2023143830-A1](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf004.png)

![Sketch 5 for WO-2023143830-A1](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf005.png)

![Sketch 6 for WO-2023143830-A1](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf006.png)

![Sketch 7 for WO-2023143830-A1](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf007.png)

![Sketch 8 for WO-2023143830-A1](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf008.png)

![Sketch 9 for WO-2023143830-A1](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf009.png)

![Sketch 10 for WO-2023143830-A1](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf009.png)

[Sketch 11](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf010.png)

![Sketch 11 for WO-2023143830-A1](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf010.png)

[Sketch 12](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf011.png)

![Sketch 12 for WO-2023143830-A1](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf011.png)

[Sketch 13](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf012.png)

![Sketch 13 for WO-2023143830-A1](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf012.png)

[Sketch 14](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf013.png)

![Sketch 14 for WO-2023143830-A1](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf013.png)

[Sketch 15](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf014.png)

![Sketch 15 for WO-2023143830-A1](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf014.png)

[Sketch 16](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf015.png)

![Sketch 16 for WO-2023143830-A1](https://nimo.iptorch.com/refdrawing/WO-2023143830-A1/pdf015.png)

## Claims

### Claim 1

Patentansprüche Greifvorrichtung (10) zum Greifen von ferromagnetischen Gegenständen, umfassend eine Anlagefläche (16) für einen zu greifenden Gegenstand, und einen Magnet (19) zur Bereitstellung einer Magnetwirkung an der Anlagefläche (16) , um den Gegenstand zu greifen, gekennzeichnet durch einen ersten Polschuh (20) und einen zweiten Polschuh (22) , welche mit dem Magnet (19) derart Zusammenwirken, dass der erste Polschuh (20) einen magnetischen Südpol (34) bereitstellt und der zweite Polschuh (22) einen magnetischen Nordpol (36) bereitstellt, wobei an dem ersten Polschuh (20) ein erster Abschnitt (46) der Anlagefläche (16) bereitgestellt ist und wobei an dem zweiten Polschuh (22) ein zweiter Abschnitt (48) der Anlagefläche (16) bereitgestellt ist, wobei der erste und der zweite Polschuh (20) zur Einstellung der an der Anlagefläche (16) bereitgestellten Magnetwirkung innerhalb eines Verstellbereichs relativ zu dem Magnet (19) verschiebbar sind. Greifvorrichtung (10) nach Anspruch 1, wobei der erste und der zweite Polschuh (20, 22) derart angeordnet sind, dass sie, zumindest in einer Funktionsstellung des Magneten (19) , zumindest abschnittsweise mit dem Magnet (19) überlappen, wobei durch Verschieben des ersten und zweiten Polschuhs (20, 22) innerhalb des Verstellbereichs ein Überlapp zwischen Magnet (19) und erstem oder zweitem Polschuh (20, 22) veränderbar, insbesondere einstellbar, ist. Greifvorrichtung (10) nach einem der vorherigen Ansprüche, wobei sich die Greifvorrichtung (10) entlang einer Längsachse (12) zwischen einem Anschlussabschnitt (14) zum Anschluss an eine Handhabungsvorrichtung und der Anlagefläche (16) erstreckt, wobei der erste und der zweite Polschuh (20, 22) jeweils entlang einer zu der Längsachse (12) parallel verlaufenden Verschiebeachse (54-1, 54-2) verschiebbar sind. Greifvorrichtung (10) nach einem der vorherigen Ansprüche, wobei der Magnet (19) durch einen Magnetkörper (25) aus einem permanent magnetischen Material bereitgestellt ist, wobei der Magnetkörper (25) einen magnetischen Nordpol (23) und einen gegenüberliegenden magnetischen Südpol (21) aufweist, wobei der erste Polschuh (20) dazu ausgebildet ist, den magnetischen Südpol (21) zu dem ersten Abschnitt (46) der Anlagefläche (16) zu leiten und wobei der zweite Polschuh (22) dazu ausgebildet ist, den magnetischen Nordpol (23) zu dem zweiten Abschnitt (48) der Anlagefläche (16) zu leiten.

### Claim 5

Greifvorrichtung (10) nach einem der vorherigen Ansprüche, außerdem umfassend einen dritten, ortsfesten Polschuh (24) , welcher zwischen dem ersten und dem zweiten Polschuh (20, 22) angeordnet ist, wobei der Magnet (19) zumindest in einer Funktionsstellung zumindest abschnittsweise in dem dritten Polschuh (24) aufgenommen ist. 6. Greifvorrichtung (10) nach Anspruch 5, wobei der dritte Polschuh (24) zwischen einem ersten und einem zweiten Gehäuseabschnitt (26, 28) eines Greifergehäuses (18) angeordnet ist, wobei der erste und der zweite Polschuh (20, 22) an dem ersten und/oder dem zweiten Gehäuseabschnitt (26, 28) verlagerbar geführt sind. 7. Greifvorrichtung (10) nach einem der Ansprüche 5 oder 6, wobei der dritte Polschuh (24) eine von einer Wandung des dritten Polschuhs (24) begrenzte Aufnahme (29) für den Magnet (19) aufweist, wobei eine Wandungsstärke derjenigen Wandungsabschnitte, welche den magnetischen Polen (21, 23) des Magneten (29) gegenüberliegen, größer ist als eine Wandungsstärke der dazwischenliegenden Wandungsabschnitte. 8. Greifvorrichtung (10) nach einem der vorherigen Ansprüche, wobei der Magnet (19) , insbesondere unabhängig von einer Verschiebebewegung des ersten oder zweiten Polschuhs (20, 22) innerhalb des Verstellbereichs, zwischen einer Aktivstellung zum Greifen eines Gegenstands und einer Passivstellung zum Loslassen des Gegenstands verlagerbar ist, insbesondere wobei der Magnet (19) in der Aktivstellung zumindest abschnittsweise in dem dritten Polschuh (24) , insbesondere in der Aufnahme (29) , auf genommen ist. Greifvorrichtung (10) nach einem der vorherigen Ansprüche, wobei an dem ersten und an dem zweiten Polschuh (20, 22) , insbesondere an einer jeweiligen Stirnseite (38, 40) des ersten und zweiten Polschuhs (20, 22) , welche dem zu greifenden Gegenstand zugewandt ist, jeweils wenigstens ein ferromagnetisches Zusatzteil (42, 44) angeordnet ist, welches den ersten oder zweiten Abschnitt (46, 48) der Anlagefläche (16) bereitstellt oder an welchem ein Kontaktaufsatz oder eine Kontaktschicht angeordnet ist, welche den ersten oder zweiten Abschnitt (46, 48) der Anlagefläche (16) bereitstellt . Greifvorrichtung (10) nach Anspruch 9, wobei das wenigstens eine ferromagnetische Zusatzteil (42, 44) wiederholbar lösbar mit dem ersten oder zweiten Polschuh (20, 22) verbindbar ist. Greifvorrichtung (10) nach einem der Ansprüche 9 oder 10, wobei das wenigstens eine ferromagnetische Zusatzteil (42, 44) in Form eines Bolzens, eines Zapfens (50) , einer Schraube, oder dgl . bereitgestellt ist, wobei das wenigstens eine Zusatzteil (42, 44) in den ersten oder zweiten Polschuh (20, 22) einschraubbar oder einsteckbar ist.

### Claim 12

Greifvorrichtung (10) nach einem der vorherigen Ansprüche, außerdem umfassend eine Aktorik (60) zum Antreiben einer Verschiebebewegung des ersten und zweiten Polschuhs (20, 22) . 13. Greifvorrichtung nach Anspruch 12, wobei die Aktorik (60) einen manuell und/oder motorisch betätigbaren Verstellring (60) umfasst, welcher derart um eine Drehachse (64) drehbar ist, dass durch Drehen des Verstellrings (62) um die Drehachse (64) der erste und der zweite Polschuh (20, 22) innerhalb des Verstellbereichs, insbesondere synchron, verschiebbar sind . 14. Greifvorrichtung (10) nach einem der vorherigen Ansprüche, außerdem umfassend wenigstens ein magnetisch isolierend wirkendes Zwischenteil, welches zwischen Magnet (19) und Anlagefläche (16) angeordnet ist . 15. Greifvorrichtung (10) nach einem der vorherigen Ansprüche, außerdem umfassend, ein oder mehrere Anwesenheitssensoren, mittels denen erfassbar ist, ob sich ein Gegenstand an der Anlagefläche (16) befindet oder an der Anlagefläche (16) anliegt und/oder ein oder mehrere Kontrollsensoren, mittels denen erfassbar ist, ob sich an der Anlagefläche (16) mehrere Gegenstände befinden.

## Full description

**[p0001]**

Titel: Greifvorrichtung zum Greifen von ferromagnetischen Gegenständen Beschreibung Die Erfindung betrifft eine Greifvorrichtung zum Greifen von ferromagnetischen Gegenständen gemäß dem Oberbegriff des Anspruchs 1. Solche Greifvorrichtungen werden auch als Magnetgreifer bezeichnet und finden beispielsweise in der industriellen Fertigung zum Greifen und Handhaben und Metallblechen Verwendung. Eine typische Anwendungssituation ist das Abstapeln, also das Vereinzeln, von Blechen von einem Stapel gleichartiger oder unterschiedlicher Bleche. Hierbei soll insbesondere vermieden werden, dass mehrere Bleche gleichzeitig gegriffen werden. Zu diesem Zweck ist es bekannt , eine Tiefenwirkung einer von der Grei fvorrichtung bereitgestellten Grei fkraft dadurch zu steuern, dass ein Abstand des Magneten von dem zu grei fenden Gegenstand vergrößert wird und somit das von dem Magnet ausgesandte Magnetfeld durch die Luft abgeschwächt wird . Aus der DE 20 2005 004 456 Ul ist beispielsweise eine Grei fvorrichtung bekannt , welche einen längsverschieblich geführten Magnet aufweist , der durch einen Aktor entlang einer Längsachse verlagert werden kann . Durch Verlagern des Magneten hin zu einer Anlagefläche kann ein ferromagnetischer Gegenstand durch den Magnet gegri f fen werden . Wird der Magnet von der Anlagefläche weg verlagert , kann das anhaftende Werkstück gelöst werden, wobei die Anlagefläche an der Gehäusestirnseite als Abstrei fer dienen kann .

**[p0002]**

Bei den aus dem Stand der Technik bekannten Lösungen geht eine Reduzierung der Tiefenwirkung durch Vergrößerung des Abstandes zwischen Magnet und Anlagefläche j edoch regelmäßig mit einer Reduzierung der auf den Gegenstand wirkenden Grei fkraft einher, was dazu führen kann, dass ein Gegenstand nicht mehr zuverlässig gegri f fen werden kann . Die Erfindung beschäftigt sich mit der Aufgabe , eine Grei fvorrichtung bereitzustellen, mit der ferromagnetische Gegenstände präzise und zuverlässig gegri f fen werden können . Diese Aufgabe wird durch eine Grei fvorrichtung mit den Merkmalen des Anspruchs 1 gelöst . Die Grei fvorrichtung ist zum Grei fen und insbesondere auch zum Handhaben von ferromagnetischen Gegenständen, wie bspw . Metallblechen, ausgebildet . Die Grei fvorrichtung umfasst eine Anlagefläche für einen zu grei fenden Gegenstand . In einem gegri f fenen Zustand liegt der Gegenstand insbesondere an der Anlagefläche an . Die Grei fvorrichtung umfasst außerdem einen Magnet zur Bereitstellung einer Magnetwirkung an der Anlagefläche , um den Gegenstand zu grei fen . Insbesondere stellt der Magnet zumindest in einer Funktionsstellung eine Magnetwirkung zum Grei fen des Gegenstands an der Anlagefläche bereit . Magnetwirkung meint im vorliegenden Zusammenhang insbesondere eine Wirkung eines an der Anlagefläche bereitgestellten magnetischen Feldes , weiter insbesondere eine durch das Magnetfeld auf einen ferromagnetischen Gegenstand wirkende Magnetkraft .

**[p0003]**

Die Grei fvorrichtung umfasst außerdem einen ersten Polschuh und einen, insbesondere von dem ersten Polschuh beabstandeten, zweiten Polschuh . Der erste und der zweite Polschuh wirken mit dem Magnet derart zusammen, dass der erste Polschuh einen magnetischen Südpol bereitstellt und der zweite Polschuh einen magnetischen Nordpol bereitstellt . Insofern kann der erste Polschuh einem magnetischen Südpol des Magneten örtlich zugeordnet sein und der zweite Polschuh kann einem magnetischen Nordpol des Magneten örtlich zugeordnet sein . Im vorliegenden Zusammenhang wird unter Polschuh insbesondere ein Bauteil verstanden, welches dazu ausgebildet ist , ein Magnetfeld bzw . magnetische Feldlinien zu leiten und in definierter Form austreten zu lassen . Vorzugsweise umfassen der erste und der zweite Polschuh ein ferromagnetisches Material oder sind aus einem ferromagnetischen Material ausgebildet . An dem ersten Polschuh ist ein erster Abschnitt der Anlagefläche bereitgestellt und an dem zweiten Polschuh ist ein zweiter Abschnitt der Anlagefläche bereitgestellt . Die Anlagefläche umfasst insofern insbesondere einen ersten Abschnitt , an welchem ein magnetischer Südpol wirkt , und einen zweiten Abschnitt , am dem ein magnetischer Nordpol wirkt . Die Anlagefläche ist vorzugsweise von dem Magnet beabstandet angeordnet .

**[p0004]**

Der erste und der zweite Polschuh sind - zur Einstellung der an der Anlagefläche bereitgestellten Magnetwirkung - innerhalb eines Verstellbereichs relativ zu dem Magnet verschiebbar . Insbesondere sind der erste und der zweite Polschuh an einem Grei fergehäuse der Grei fvorrichtung verschiebbar geführt . Bei der vorgeschlagenen Grei fvorrichtung leiten der erste und zweite Polschuh insofern einen magnetischen Fluss von dem Magnet zu der Anlagefläche bzw . lenken die von dem Magnet ausgesandten Magnetfeldlinien zu der Anlagefläche , sodass an dem ersten Abschnitt der Anlagefläche ein magnetischer Südpol und an dem zweiten Abschnitt der Anlagefläche ein magnetischer Nordpol bereitgestellt ist . Diese Magnetpole werden dann, wenn ein ferromagnetischer Gegenstand an dem ersten und zweiten Abschnitt der Anlagefläche anliegt , durch den Gegenstand miteinander gekoppelt . Es wird also durch den Gegenstand insbesondere ein geschlossener Pfad für den magnetischen Fluss (magnetischer Kreis ) gebildet . Hierdurch wird eine besonders starke magnetische Anziehungskraft auf den Gegenstand ausgeübt , sodass der Gegenstand sicher an der Grei fvorrichtung gehalten ist . Durch Verschieben des ersten und/oder zweiten Polschuhs relativ zu dem Magnet kann das an der Anlagefläche bereitgestellte Magnetfeld beeinflusst werden, insbesondere derart , dass eine Tiefenwirkung einer durch das Magnetfeld auf einen ferromagnetischen Gegenstand wirkenden Grei fkraft verändert wird ohne dass es zu einer nennenswerten Reduzierung der Grei f kraft kommt . Bei der vorgeschlagenen Grei fvorrichtung ist es ins

**[p0004]**

ofern beispielsweise möglich, eine Tiefenwirkung in Abhängigkeit einer Dicke eines zu grei fenden Blechs derart einzustellen, dass von einem Stapel gleiche Bleche nur das oberste Blech aufgegri f fen wird, auf dieses Blech aber eine hohe

**[p0005]**

Grei f kraft wirkt . Um eine Magnetwirkung an der Anlagefläche vergleichsweise schnell zu- bzw . abschalten zu können und somit einen Gegenstand schnell aufgrei fen oder ablegen zu können, kann es vorteilhaft sein, wenn der erste und der zweite Polschuh ein ferromagnetisches Material mit geringer magnetischer Remanenz aufweist . Vorzugsweise sind der erste und der zweite Polschuh j eweils derart angeordnet , dass sie , zumindest in einer Funktionsstellung des Magneten, zumindest abschnittsweise mit dem Magnet überlappen . Ein von dem Magnet bereitgestelltes Magnetfeld wird insofern von dem Magnet in die Polschuhe geleitet und von den Polschuhen zu der Anlagefläche geleitet . Im Konkreten ist der erste Polschuh insbesondere dazu ausgebildet sein, den magnetischen Südpol des Magneten zu dem ersten Abschnitt der Anlagefläche zu leiten und der zweite Polschuh ist dazu ausgebildet , den magnetischen Nordpol des Magneten zu dem zweiten Abschnitt der Anlagefläche zu leiten . Vorzugsweise sind der erste und der zweite Polschuh derart ausgebildet und angeordnet , dass ein Überlapp zwischen Magnet und erstem bzw . zweitem Polschuh durch Verlagerung des ersten bzw . zweiten Polschuhs innerhalb des Verstellbereichs veränderbar ist , also insbesondere eine Überlappungslänge zwischen Magnet und Polschuh veränderbar ist . In Abhängigkeit des Überlappungsgrads kann dann eine Magnetisierung der Polschuhe und somit eine Ausbreitung der Magnetfeldlinien an der Anlagefläche verändert werden . Insbesondere kann eine Tiefenwirkung einer durch das Magnetfeld an der Anlagefläche auf einen ferromag

**[p0005]**

netischen Gegenstand wirkenden Grei fkraft durch Veränderung des Überlapps zwischen Magnet und erstem und zweitem Polschuh verändert werden . Auf diese Weise kann eine hohe Grei fkraft mit definierter, insbesondere einstellbarer, Tiefenwirkung bereitgestellt werden .

**[p0006]**

In vorteilhafter Weise kann der erste und der zweite Polschuh innerhalb des Verstellbereichs zwischen einer ersten Endstellung und einer zweiten Endstellung, insbesondere synchron, verlagerbar sein . Insbesondere ist ein Überlapp zwischen Magnet und erstem bzw . zweitem Polschuh, insbesondere eine Überlappungslänge entlang einer Verschiebeachse der Polschuhe , in der ersten Endstellung größer als in der zweiten Endstellung . Insbesondere ist in der ersten Endstellung eine Tiefenwirkung der an der Anlagefläche bereitgestellten Magnetwirkung größer als in der zweiten Endstellung . Die erste Endstellung und die zweite Endstellung können durch eine mechanische Begrenzung vorgegeben sein, die eine weitere Verlagerung des ersten oder zweiten Polschuhs begrenzt . Beispielsweise ist es denkbar, dass der erste und der zweite Polschuh j eweils über ein oder mehrere Langlöcher an einem Grei fergehäuse verschiebbar geführt sind, z . B . über Langloch-Schrauben-Verbindungen . Vorzugsweise ist die an den Polschuhen bereitgestellte Anlagefläche in der zweiten Endstellung von dem Magnet weg verlagert und in der ersten Endstellung zu dem Magnet hin verlagert . Insofern kann durch Verschieben des ersten und zweiten Polschuhs innerhalb des Verstellbereichs ein Abstand zwischen Magnet und Anlagefläche verändert , insbesondere eingestellt , werden .

**[p0007]**

Im Rahmen einer vorteilhaften Ausgestaltung kann sich die Grei fvorrichtung entlang einer Längsachse zwischen einem Anschlussabschnitt der Grei fvorrichtung und der Anlagefläche erstrecken . Der Anschlussabschnitt kann insbesondere zum Anschluss an eine Handhabungsvorrichtung ausgebildet sein, beispielsweise zum Anschluss an einen Roboterf lansch . Der Anschlussabschnitt kann zusätzlich Versorgungsanschlüsse zum Anschluss an externe Versorgungsleitungen umfassen, z . B . zur Versorgung der Grei fvorrichtung mit Druckluft , Unterdrück, und/oder Strom . Vorzugsweise sind der erste und der zweite Polschuh j eweils entlang einer zu der Längsachse parallel verlaufenden Verschiebeachse verschiebbar . Bei dem Magnet kann es sich um einen Elektromagnet handeln . Dann kann der Magnet im aktivierten Zustand die Magnetwirkung bereitstellen . Bei dem Magnet kann es sich auch um einen Permanentmagnet handeln . Vorzugsweise ist der Magnet durch einen Magnetkörper aus einem permanent magnetischen Material gebildet . Der Magnetkörper kann selbst aus mehreren Teilen zusammengesetzt sein . Der Magnetkörper weist insbesondere einen magnetischen Nordpol und einen gegenüberliegenden magnetischen Südpol auf . Insofern weist der Magnet vorzugsweise eine Magnetisierungsrichtung von einem Nordpol zu einem Südpol auf . Unter Magnetisierungsrichtung wird insbesondere eine Vorzugsrichtung verstanden, entlang welcher im räumlichen Mittel die Feldlinien die magnetischen Feldlinien von Nordpol nach Südpol verlaufen . Der Magnetkörper ist vorzugsweise derart an der Grei fvorrichtung angeordnet , dass die

**[p0007]**

Magnetisierungsrichtung orthogonal zu einer Längsrichtung der Grei fvorrichtung verläuft . Der Magnetkörper kann insbesondere zylindrisch ausgebildet sein .

**[p0008]**

Im Rahmen einer bevorzugten Ausgestaltung kann die Grei fvorrichtung einen dritten, orts festen Polschuh umfassen, in welchem der Magnet zumindest in einer Funktionsstellung ( siehe unten) zumindest abschnittsweise auf genommen ist . Der dritte Polschuh ist insbesondere derart ausgebildet , dass er den Magnet bezüglich der Längsrichtung zumindest abschnittsweise umgibt . Der dritte Polschuh ist vorzugsweise zwischen dem ersten und dem zweiten (verschiebbaren) Polschuh angeordnet . Erster und zweiter Polschuh können insofern an gegenüberliegenden Seiten des dritten Polschuhs angeordnet sein . Der dritte , orts feste Polschuh dient dazu, das von dem Magnet ausgesandte Magnetfeld ef fi zient in den ersten und zweiten Polschuh einzuleiten . Insbesondere sind der erste und der zweite Polschuh - zur Einstellung der an der Anlagefläche bereitgestellten Magnetwirkung - innerhalb eines Verstellbereichs relativ zu dem dritten Polschuh verschiebbar . Insbesondere ist ein Überlapp zwischen drittem Polschuh und erstem bzw . zweitem Polschuh, insbesondere eine Überlappungslänge entlang einer Verschiebeachse des ersten und zweiten Polschuhs , in einer ersten Endstellung des Verstellbereichs größer als in einer zweiten Endstellung . Insbesondere ist in der ersten Endstellung eine Tiefenwirkung der an der Anlagefläche bereitgestellten Magnetwirkung größer als in der zweiten Endstellung .

**[p0009]**

Im Rahmen einer vorteilhaften Ausgestaltung kann die Grei fvorrichtung ein Grei fergehäuse umfassen . Dann kann der dritte Polschuh zwischen einem ersten und einem zweiten, insbesondere voneinander räumlich getrennten, Gehäuseabschnitt des Grei fergehäuses angeordnet sein . Vorzugsweise ist der erste und der zweite (verschiebbare ) Polschuh an, insbesondere zwischen, dem ersten und dem zweiten Gehäuseabschnitt verlagerbar geführt , bspw . über Langloch-Schrauben-Verbindungen . Eine Begrenzungswandung des Langlochs definiert dann insbesondere die Endstellungen des Verstellbereichs . Der erste und der zweite Gehäuseabschnitt können beispielsweise in Form von Backen ausgeführt sein, welche den dritten Polschuh zwischen sich haltern . Das Grei fergehäuse kann insbesondere aus nichtmagnetischem Material gebildet sein, bspw . aus Aluminium oder Kunststof f , sodass Grei fergehäuse und Polschuhe voneinander magnetisch entkoppelt sind . Vorzugsweise umfasst der dritte Polschuh eine Aufnahme für den Magnet . Die Aufnahme ist insbesondere durch eine Wandung des Polschuhs begrenzt . Aufnahme und Magnet sind vorzugsweise derart aufeinander abgestimmt , dass dann, wenn der Magnet in der Aufnahme aufgenommen ist , ein Abstand zwischen Magnet und Polschuh im Bereich von 1 / 10 mm liegt , was eine ef fi ziente Magnetisierung des dritten Polschuhs begünstigt . Eine besonders vorteilhafte Ausgestaltung des dritten Polschuhs besteht darin, dass eine Wandungsstärke derj enigen Wandungsabschnitte der Wandung, welche den magnetischen Polen des Magneten, bzw . Magnetkörpers , gegenüberliegen, grö

**[p0009]**

ßer ist als eine Wandungsstärke der dazwischenliegenden Wandungsabschnitte . Eine solche Ausgestaltung trägt dazu bei , dass ein magnetischer "Kurzschluss" zwischen den beiden Polen unterbunden wird und gleichzeitig eine ef fi ziente Polarisierung des ersten und zweiten Polschuhs begünstigt ist . Vorzugsweise weist

**[p0010]**

der dritte Polschuh eine im Querschnitt ovale , insbesondere stadionförmige , Kontur auf . Es ist grundsätzlich möglich, dass der Magnet orts fest an der Grei fvorrichtung angeordnet ist , beispielsweise orts fest in dem dritten Polschuh aufgenommen ist . Im Rahmen einer bevorzugten Ausgestaltung kann der Magnet , insbesondere bei einer Ausgestaltung als Permanentmagnet , zwischen einer Aktivstellung, in welcher der Magnet eine Magnetwirkung zum Grei fen des Gegenstands an der Anlagefläche bereitstellt , und einer Passivstellung, in welcher eine Magnetwirkung an der Anlagefläche gegenüber der Aktivstellung verringert oder sogar auf Null reduziert ist , verlagerbar sein . Eine solche Ausgestaltung ermöglicht es , eine von der Grei fvorrichtung bereitgestellte Grei fwirkung wahlweise zu- oder abschalten . Beispielsweise kann es zum schnellen Ablegen eines Gegenstands oder zum Warten der Grei fvorrichtung vorteilhaft sein, wenn an der Anlagefläche überhaupt keine oder nur eine geringe Magnetwirkung bereitgestellt ist . Der Magnet kann, vorzugsweise unabhängig von einer Verschiebebewegung des ersten oder zweiten Polschuhs , innerhalb des Grei fergehäuses , insbesondere entlang der Längsrichtung, verschieblich geführt sein . Die Grei fvorrichtung kann insofern einen Magneten und einen ersten, einen zweiten und einen dritten Polschuh umfassen, wobei der dritte Polschuh orts fest angeordnet ist , bspw . an einem Grei fergehäuse , und wobei der Magnet relativ zu dem dritten Polschuh verlagerbar ist und wobei der erste und der zweite Polschuh relativ zu dem dritten Polschuh, insbeso

**[p0010]**

ndere unabhängig

**[p0011]**

von dem Magneten, verlagerbar sind . Insbesondere kann eine Aktorik zur Verlagerung des Magneten zwischen Aktivstellung und Passivstellung vorgesehen sein . Beispielsweise kann die Aktorik eine pneumatische Kolben- Zylinder-Einheit oder einen elektrischen Antrieb ( z . B . Elektromotor oder Hubmagnet ) umfassen . Zudem ist denkbar, dass der Magnet stufenlos verschiebbar ist . Vorzugsweise ist der Magnet , bzw . der Magnetkörper , in der Aktivstellung zumindest abschnittsweise in dem dritten Polschuh, insbesondere in der vorstehend beschriebenen Aufnahme , aufgenommen . Bei einer solchen Ausgestaltung ist die Aufnahme in dem dritten Polschuh dann vorzugsweise einseitig of fen in Richtung des Anschlussabschnitts der Grei fvorrichtung ausgebildet . Eine besonders hohe Grei fkraft kann insbesondere dann erzielt werden, wenn die Anlagefläche aus einem ferromagnetischen Material gebildet ist . Es ist beispielsweise denkbar, dass der erste Abschnitt der Anlagefläche durch eine Stirnseite des ersten Polschuhs bereitgestellt ist , welche dem zu grei fenden Gegenstand zugewandt ist , und dass der zweite Abschnitt der Anlagefläche durch eine Stirnfläche des zweiten Polschuhs bereitgestellt ist , welche dem zu grei fenden Gegenstand zugewandt ist .

**[p0012]**

In vorteilhafter Weise kann die Anlagefläche aber durch ferromagnetische Zusatzteile bereitgestellt sein, welche an dem ersten und zweiten Polschuh angeordnet sind . Die ferromagnetischen Zusatzteile sind insbesondere aus einem ferromagnetischen Material ausgebildet . Eine solche Ausgestaltung mit Zusatzteilen ermöglicht es , durch Wahl einer bestimmten Form, eines Materials , und/oder eine Größe der Zusatzteile eine auf einen zu grei fenden Gegenstand abgestimmte Magnetkraft einzustellen, insbesondere eine Tiefenwirkung der Magnetkraft in Längsrichtung einzustellen . Im Konkreten kann an dem ersten und an dem zweiten Polschuh, insbesondere an einer dem zu grei fenden Gegenstand zugewandten Stirnseite des ersten und zweiten Polschuhs , j eweils wenigstens ein ferromagnetisches Zusatzteil angeordnet sein, welches den ersten bzw . zweiten Abschnitt der Anlagefläche bereitstellt . Es ist auch denkbar, dass auf dem wenigstens einen Zusatzteil ein Kontaktaufsatz bzw . eine Kontaktkappe oder eine Kontaktschicht angeordnet ist , welche den ersten bzw . zweiten Abschnitt der Anlagefläche bildet . Beispielsweise kann der Kontaktaufsatz , die Kontaktkappe oder die Kontaktschicht aus einem Elastomer ausgebildet sein, was das Risiko einer Beschädigung der Oberfläche eines zu grei fenden Gegenstandes reduziert . In vorteilhafter Weise können an dem ersten und/oder dem zweiten Polschuh j eweils mehrere ferromagnetische Zusatzteile , optional mit Kontaktaufsatz , Kontaktkappe oder Kontaktschicht , angeordnet sein, welche gemeinsam die Anlagefläche bereitstellen .

**[p0013]**

Im Rahmen einer vorteilhaften Weiterbildung kann das wenigstens eine ferromagnetische Zusatzteil wiederholbar lösbar mit dem ersten oder mit dem zweiten Polschuh verbindbar sein . Dies ermöglicht es , dass wenigstens eine Zusatzteil bei Bedarf aus zutauschen, beispielsweise bei Erreichen einer Verschleißgrenze . Es ist beispielsweise auch denkbar, dass ein Set von unterschiedlich ausgebildeten Zusatzteilen vorgehalten wird und in Abhängigkeit einer Grei f auf gäbe , beispielsweise in Abhängigkeit eines Materials oder einer Dicke eines zu grei fenden Gegenstandes , ein passendes Zusatzteil ausgewählt wird . Dies ermöglicht es , die an der Anlagefläche bereitgestellte Magnetwirkung bedarfsgereicht einzustellen . Eine besonders einfache und kostengünstige Ausgestaltung besteht darin, dass das wenigstens eine ferromagnetische Zusatzteile ein Bol zen, ein Zapfen, eine Schraube , eine Schraubenmutter, oder dergleichen ist . Das wenigstens eine Zusatzteil kann in den ersten oder zweiten Polschuh, insbesondere in eine entsprechende Aufnahme an deren Stirnseite , einschraubbar oder einsteckbar sein, was ein einfaches Auswechseln des wenigstens einen Zusatzteils ermöglicht .

**[p0014]**

Es ist auch denkbar, dass das wenigstes eine ferromagnetische Zusatzteil mehrstückig ausgebildet ist , umfassend eine Mehrzahl von Segmenten . Beispielsweise können die Segmente entlang der Längsachse aufeinander angeordnet und/oder zerstörungs frei lösbar miteinander verbunden sein . Es ist z . B . denkbar, dass mehrere Segmente unterschiedlicher Dicke und/oder Länge vorgehalten werden, aus denen dann das wenigstens eine Zusatzteil bedarfsgerecht zusammengestellt wird . Es ist auch denkbar, dass das wenigstens eine Zusatzteil in seiner Länge veränderbar ist , insbesondere derart , dass ein Abstand zwischen Anlagefläche und Magnet veränderbar, vorzugsweise einstellbar, ist . Im Rahmen einer vorteilhaften Weiterbildung kann die Grei fvorrichtung außerdem eine Aktorik zum Antreiben der Verschiebebewegung des ersten und zweiten Polschuhs umfassen . Die Aktorik kann manuell oder motorisch betrieben ausgebildet sein . Beispielsweise kann die Aktorik elektrisch, elektromotorisch oder pneumatisch betrieben sein .

**[p0015]**

Im Rahmen einer vorteilhaften Ausgestaltung kann die Aktorik einen manuell und/oder motorisch betätigbaren Verstellring umfassen, welcher derart um eine Drehachse drehbar ist , dass durch Drehen des Verstellrings um die Drehachse der erste und der zweite Polschuh innerhalb des Verstellbereichs , insbesondere synchron, verschiebbar sind . Eine solche Ausgestaltung ermöglicht eine besonders einfache und intuitive Anpassung der Magnetwirkung durch eine Bedienperson . Der Verstellring kann beispielsweise ein Innengewinde aufweisen, welches in ein entsprechendes Gegengewinde an dem Grei fergehäuse eingrei ft , sodass der Verstellring durch Drehen um die Drehachse entlang der Längsrichtung verlagerbar ist . Beispielsweise kann eine der Anlagefläche zugewandte Unterkante des Verstellrings an dem ersten und zweiten Polschuh anliegen, sodass eine synchrone und gleichzeitige Verstellung des ersten und zweiten Polschuhs erzielt werden kann . Optional kann die Grei fvorrichtung außerdem wenigstens ein magnetisch isolierend wirkendes Zwischenteil aufweisen, welches zwischen Magnet und Anlagefläche angeordnet ist . Beispielsweise kann das wenigstens eine Zwischenteil lösbar mit dem Grei fergehäuse verbunden sein . Über das wenigstens eine Zwischenteil kann die Magnetwirkung an der Anlagefläche zusätzlich verändert werden .

**[p0016]**

In vorteilhafter Weise können an oder in der Grei fvorrichtung ein oder mehrere Anwesenheitssensoren (Part-Presence-Sensor ) vorgesehen sein, mittels denen erfassbar ist , ob sich ein Gegenstand an der Anlagefläche der Grei fvorrichtung befindet oder an der Anlagefläche anliegt . Ein Anwesenheitssensor kann bspw . als optischer Sensor oder als induktiver Sensor ausgebildet sein . Als Sensoren können auch Magnetfeldsensoren, bspw . Hall- Sensoren, eingesetzt werden . Der oder die Sensoren können elektrisch und/oder elektronisch mit einer Steuerung der Grei fvorrichtung verbunden sein . Alternativ oder ergänzend können ein oder mehrere Kontrollsensoren vorgesehen sein, mittels denen erfassbar ist , ob sich an der Anlagefläche mehrere Gegenstände befinden ( Doppelblech-Kontrolle ) . Hiermit kann erfasst werden, ob durch die Grei fvorrichtung mehrere Gegenstände gegri f fen wurden . Dies ist bspw . hil freich, wenn mehrere gleichartige Gegenstände aufeinandergestapelt sind, die durch die Greif einrichtung jedoch nur einzeln auf genommen werden sollen. Wird durch die Kontrollsensoren erfasst, dass mehrere Gegenstände gegriffen sind, können diese, insbesondere mittels Ansteuerung durch eine Steuerung der Greifvorrichtung durch entsprechende Verlagerung des ersten und zweiten Polschuhs innerhalb des Verstellbereichs abgelegt werden. Ein Kontrollsensor kann bspw. als optischer Sensor oder als induktiver Sensor ausgebildet sein. Als Kontrollsensor können auch Magnetfeldsensoren, bspw. Hall-Sensoren, eingesetzt werden.

**[p0017]**

Die Erfindung wird im Folgenden anhand der Figuren näher erläutert . Es zeigen: Figur 1 skizzierte Darstellung einer Ausgestaltung der Greifvorrichtung in einer perspektivischen Detailansicht; Figuren 2a, 2b skizzierte Darstellungen der Greifvorrichtung gemäß Figur 1 mit Magnet in erster Endstellung in verschiedenen Seitenansichten; Figuren 3a, 3b skizzierte Darstellungen der Greifvorrichtung gemäß Figur 1 mit Magnet in zweiter Endstellung in verschiedenen Seitenansichten; Figuren 4a, 4b skizzierte Darstellungen einer weiteren Ausgestaltung der Greifvorrichtung mit Magnet in erster Endstellung in verschiedenen Seitenansichten; Figuren 5a, 5b skizzierte Darstellungen einer weiteren Ausgestaltung der Greifvorrichtung mit Magnet in erster Endstellung in verschiedenen Seitenansichten; und Figuren 6a, 6b vereinfachte skizzierte Schnittdarstellungen einer Ausgestaltung der Greifvorrichtung entlang der in Figur 2a mit VI-VI bezeichneten Schnittlinie, zur Erläuterung der Verlagerung des Magneten zwischen Aktivstellung (Ansicht a) und Passivstellung (Ansicht b) .

**[p0018]**

In der nachfolgenden Beschreibung sowie in den Figuren sind für identische oder einander entsprechende Merkmale jeweils dieselben Bezugszeichen verwendet. Die Figur 1 zeigt einen Ausschnitt einer Greifvorrichtung zum Greifen von ferromagnetischen Gegenständen, welche insgesamt mit dem Bezugszeichen 10 bezeichnet ist. Wie aus Fig. 2 ersichtlich, erstreckt sich die Greifvorrichtung 10 entlang einer Längsachse 12 zwischen einem Anschlussabschnitt 14 zur Verbindung mit einer Handhabungsvorrichtung (nicht dargestellt) und einer Anlagefläche 16 für einen zu greifenden Gegenstand (nicht gezeigt) . Die Greifvorrichtung 10 umfasst ein Greifergehäuse 18, welches sich entlang der Längsachse 12 erstreckt. Die Greifvorrichtung 10 umfasst außerdem einen Magnet 19 (vgl. Fig. 6a) zur Bereitstellung einer Magnetwirkung an der Anlagefläche 16, um einen Gegenstand zu greifen. Der Magnet 19 weist einen magnetischen Südpol 21 und einen gegenüberliegenden magnetischen Nordpol 23 auf (vgl . Fig . 6b ) . Beispielhaft und bevorzugt ist der Magnet 19 durch einen Magnetkörper 25 aus einem permanent magnetischen Material bereitgestellt .

**[p0019]**

Der Magnet 19 ist innerhalb des Grei fergehäuses 18 entlang der Längsachse 12 zwischen einer Aktivstellung zum Grei fen des Gegenstands (vgl . Fig . 6a ) und einer Passivstellung zum loslassen des Gegenstands (vgl . Fig . 6b ) verschiebbar geführt . Zu diesem Zweck kann die Grei fvorrichtung 10 eine entsprechende Aktorik zum Verlagern des Magneten zwischen Aktivstellung und Passivstellung aufweisen, bspw . umfassend einen Elektromotor oder einen Pneumatikzylinder . In dem in den Figuren 6a und 6b dargestellten Beispiel ist der Magnet 19 an einem Kolben 27 befestigt , welcher innerhalb des Grei fergehäuses 18 verschiebbar geführt ist und bspw . pneumatisch betätigbar ist . Es ist grundsätzlich auch möglich, dass der Magnet orts fest an der Grei fvorrichtung 10 angeordnet ist . In diesem Zusammenhand wird darauf hingewiesen, dass die Figuren 6a und 6b lediglich vereinfachte schematische Schnittdarstellungen sind, die nicht alle Bauteile der Grei fvorrichtung 10 zeigen . Die Grei fvorrichtung 10 umfasst außerdem einen ersten Polschuh 20 und einen zweiten Polschuh 22 . Zwischen dem ersten Polschuh 20 und dem zweiten Polschuh 22 ist zudem ein orts fester dritter Polschuh 24 angeordnet . Wie aus Fig . 1 ersichtlich, ist der dritte Polschuh 24 zwischen einem ersten Gehäuseabschnitt 26 und einem zweiten

**[p0020]**

Gehäuseabschnitt 28 des Greifergehäuses 18 gehaltert. Die Polschuhe 20, 22, 24 umfassen jeweils ein ferromagnetisches Material oder sind aus einem ferromagnetischen Material ausgebildet . In der Aktivstellung (vgl. Fig. 6a) ist der Magnet 19 zumindest abschnittsweise in dem dritten Polschuh 24 aufgenommen, sodass der erste und der zweite Polschuh 20, 22 entlang der Längsachse 12 zumindest abschnittsweise mit dem Magnet 19 überlappen. Der dritte Polschuh 24 ist dazu ausgebildet, das von dem Magnet ausgesandte Magnetfeld an den ersten und zweiten Polschuh 20, 22 zu leiten. Beispielhaft und bevorzugt weist der dritte Polschuh 24 ein in Richtung des Anschlussabschnitts 12 offene Aufnahme 29 für den Magnet 19 auf, welche von einer Wandung begrenzt ist. Vorzugsweise weist die Aufnahme 29 eine Negativform des Magneten 19 auf. Vorzugsweise ist der Magnet 19 in der Aktivstellung derart in dem dritten Polschuh 24 aufgenommen, dass sein magnetischer Südpol 21 dem ersten Polschuh 20 zugewandt ist (also sich in dem in Fig. 1 mit Bezugszeichen 30 angedeuteten Bereich befindet) und sein magnetischer Nordpol 23 dem zweiten Polschuh 22 zugewandt ist (also sich in dem in Fig. 1 mit Bezugszeichen 32 angedeuteten Bereich befindet) , vgl. Fig. 6b. Insofern verläuft eine Magnetisierungsrichtung 31 von dem Nordpol 23 des Magneten 19 zu dem Südpol 21 insbesondere orthogonal zur Längsachse 12.

**[p0021]**

Wie aus Figur 1 ersichtlich, weist der dritte Polschuh 24 im Beispiel einen stadionf örmigen Querschnitt orthogonal zur Längsachse 12 auf . Vorzugsweise ist die Aufnahme 29 in dem Polschuh 24 derart ausgebildet , sodass eine Wandungsstärke in den Bereichen 30 , 32 größer ist als eine Wandungsstärke in den dazwischenliegenden Bereichen, welche im Beispiel an die Gehäuseabschnitte 26 , 28 angrenzen . Beispielhaft und bevorzugst sind der Magnet 19 und die Aufnahme 29 in dem dritten Polschuh 24 zylindrisch ausgebildet . Ein von dem Magnet 19 bereitgestelltes Magnetfeld wird über den dritten Polschuh 24 an den ersten bzw . zweiten Polschuh 20 , 22 geleitet , welche das Magnetfeld weiter zu der Anlagefläche 16 leiten . Im Konkreten wird der magnetische Südpol 21 des Magneten 19 durch den ersten Polschuh 20 geführt , sodass dieser an seiner Stirnseite 38 einen magnetischen Südpol 34 bereitstellt und der magnetische Nordpol 23 des Magneten 19 wird durch den zweiten Polschuh 22 geleitet , sodass dieser an seiner Stirnseite 40 einen magnetischen Nordpol 36 bereitstellt (vgl . Fig . 2b ) .

**[p0022]**

Wie in Fig . 1 dargestellt , sind an der Stirnseite 38 des ersten Polschuhs 20 und an der Stirnseite 40 des zweiten Polschuhs 22 j eweils eine Mehrzahl , in dem dargestellten Beispiel j eweils drei , Zusatzteile 42 , 44 angeordnet , welche in ihrer Gesamtheit die Anlagefläche 16 bereitstellen . Im Beispiel stellen diej enigen Zusatzteile 42 , welche an dem ersten Polschuh 20 angeordnet sind, einen ersten Abschnitt 46 der Anlagefläche 16 bereit , an welchem der magnetische Südpol 34 auf einen Gegenstand wirkt, und diejenigen Zusatzteile 44, die an dem zweiten Polschuh 22 angeordnet sind, stellen einen zweiten Abschnitt 48 der Anlagefläche 16 bereit, an welchem der magnetische Nordpol 36 auf einen Gegenstand wirkt. Liegt nun ein ferromagnetischer Gegenstand an dem ersten und zweiten Abschnitt 46, 48 der Anlagefläche 16 an, werden die beiden Magnetpole 34, 36 miteinander verbunden, sodass eine Greifwirkung auf den Gegenstand ausgeübt wird. Die Zusatzteile 42, 44 sind vorzugsweise aus einem ferromagnetischen Material gebildet. Insofern ist die Anlagefläche 16 durch ein ferromagnetisches Material bereitgestellt. Bei nicht dargestellten Ausgestaltungen ist es auch denkbar, dass auf den Zusatzteilen 42, 44 jeweils ein Kontaktaufsatz, eine Kontaktkappe oder eine Kontaktschicht aus einem weichen Material, bspw. einem Elastomer, angeordnet ist, welche dann die Anlagefläche 16 bereitstellen.

**[p0023]**

In dem dargestellten Beispiel sind die Zusatzteile 42, 44 jeweils durch einen Zapfen 50 gebildet, welcher in einer entsprechenden Aufnahme 52 des jeweiligen Polschuhs 20, 22 einschraubbar oder einsteckbar ist (vgl. Fig. 6a) . Wie aus Fig. 1 ersichtlich, umfasst der erste und der zweite Polschuh 20, 22 an seiner jeweiligen Stirnseite 38, 40 vorzugsweise eine Mehrzahl solcher Aufnahmen 52 sodass Anzahl und/oder Position der Zusatzteile 42, 44 bedarfsgerecht veränderbar ist. Eine Ausgestaltung mit vier Zusatzteilen 42, 44 je Polschuh 20, 22 ist bspw. in den Figuren 4a und 4b gezeigt. Es ist auch möglich, dass die Zusatzteile 42, 44 in Längsrichtung 12 kürzer oder länger ausgebildet sind (vgl. Fig. 5a und 5a, welche eine Ausgestaltung mit längeren Zusatzteilen 42, 44 zeigen) . Wie in den Figuren 2b und 3b gezeigt, sind der erste und der zweite Polschuh 20, 22 innerhalb eines Verstellbereichs relativ zu dem Magnet 19 bzw. relativ zu dem dritten, ortsfesten Polschuh 24 verschiebbar angeordnet, vorzugsweise entlang einer zu der Längsachse 12 parallelen Verschiebeachse 54-1, 54-2. Insbesondere sind Magnet 19 und erster und zweiter Polschuh 20, 22 voneinander unabhängig relativ zu dem ortsfesten Polschuh 24 verlagerbar. In dem dargestellten Beispiel sind in dem ersten Polschuh 20 und in dem zweiten Polschuh 22 jeweils zwei Langlöcher 56-1, 56-2 ausgebildet, welche über eine Schraubverbindung 58-1, 58-2 mit dem ersten bzw. zweiten Gehäuseabschnitt 26, 28 verbunden sind. Die Langlöcher 56-1, 56-2 definieren einen Verstellbereichs für den ersten und zweiten Polschuh 20, 22, innerhalb d

**[p0023]**

essen der erste und der zweite Polschuh 20, 22 zwischen einer ersten Endstellung (vgl. Fig. 2a und 2b) und einer zweiten Endstellung (vgl. Fig. 3a und 3b) verschiebbar sind.

**[p0024]**

Wie bei einem Vergleich der Figuren 2b und 3b erkennbar ist, sind der erste und der zweite Polschuh 20, 22 derart angeordnet, dass in der ersten Endstellung ein Überlapp zwischen drittem Polschuh 24 und ersten und zweiten Polschuh 20, 22 größer ist als in der zweiten Endstellung. Zudem ist die Anlagefläche 16 in der zweiten Endstellung von dem dritten Polschuh 24 weiter entfernt als in der ersten Endstellung . Wie bereits erwähnt , kann in Abhängigkeit einer Verschiebeposition des ersten und zweiten Polschuhs 20 , 22 und somit in Abhängigkeit eines damit verbundenen Überlappungsgrads zwischen dem ersten und zweiten Polschuh 20 , 22 und dem drittem Polschuh 24 ein an der Anlagefläche 16 bereitgestelltes Magnetfeld verändert werden . Die Grei fvorrichtung 10 kann optional eine Aktorik 60 zum Antreiben der Verschiebebewegung des ersten und des zweiten Polschuhs 20 , 22 entlang der j eweiligen Verschiebeachse 54- 1 , 54-2 umfassen . In dem dargestellten Beispiel umfasst die Aktorik 60 einen manuell betätigbaren Verstellring 62 , welcher um eine , im Beispiel zu der Längsachse 12 identische , Drehachse 64 drehbar ist . Der Verstellring 12 ist beispielhaft mit einem Innengewinde ausgestattet , welches mit einem Gewindeabschnitt an dem Grei fergehäuse 18 zusammenwirkt . Wie aus den Figuren 2b und 3b ersichtlich, liegt der Verstellring 62 mit einer der Anlagefläche 16 zugewandten Unterseite 66 an dem ersten und dem zweiten Polschuh 20 , 22 an, sodass durch Verdrehen des Verstellrings 62 um die Drehachse 64 der erste und der zweite Polschuh 20 , 22 entlang der Verschiebeachse 54- 1

**[p0024]**

, 54-2 verstellt werden können . Bei nicht dargestellten Ausgestaltungen ist es auch denkbar, dass eine Verschiebebewegung des ersten und des zweiten Polschuhs 20 , 22 pneumatische oder elektromotorisch angetrieben ist .

**[p0025]**

Die Greifvorrichtung 10 kann optional ein oder mehrere Sensoren (nicht dargestellt) umfassen. Beispielhaft kann die Greifvorrichtung 10 einen Anwesenheitssensor umfassen, mittels dessen erfassbar ist, ob sich ein Gegenstand an der Anlagefläche 16 befindet oder nicht. Es ist auch denkbar, dass die Greifvorrichtung 10 einen Kontrollsensor aufweist, mittels dessen erfassbar ist, ob sich an der Anlagefläche 16 mehrere Gegenstände befinden.

## Classifications

- B65G47/92
- B25J15/06
- B25J15/0608
- B65G47/92

## Cited patent documents

- [DE-202005004456-U1](https://patents.google.com/patent/DE202005004456U1/en) — APP
- [EP-3263295-A1](https://patents.google.com/patent/EP3263295A1/en) — ISR
- [US-2022001501-A1](https://patents.google.com/patent/US20220001501A1/en) — ISR

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
