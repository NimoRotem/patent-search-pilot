# 03. Permanent magnet devices

- **Archive rank:** 3 of 50
- **Publication:** [US-3818399-A](https://patents.google.com/patent/US3818399A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/009783756/publication/US3818399A?q=pn%3DUS3818399A)
- **Publication date:** 1974-06-18
- **Filing date:** 1973-01-24
- **Earliest priority:** 1972-02-02
- **Family:** 9783756
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** NEIL HOLDINGS LTD JAMES

## Abstract

A permanent magnet device comprising at least two pairs of aligned plate-like polepieces of ferromagnetic material such as mild steel, and at least two permanent magnets in upper and lower rows magnetised in opposite directions through their thickness, associated with and lying between the pairs of polepieces, at least one of the magnets being capable of movement relative to at least one other and relative to the pairs of polepieces from a first position where the magnets and the polepieces co-operate to provide a maximum external magnetic field strength (the ON position) to a position where the external magnetic field is reduced to substantially zero (the OFF position).

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-3818399-A/000.png)

![Sketch 1 for US-3818399-A](https://nimo.iptorch.com/refdrawing/US-3818399-A/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/US-3818399-A/001.png)

![Sketch 2 for US-3818399-A](https://nimo.iptorch.com/refdrawing/US-3818399-A/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/US-3818399-A/002.png)

![Sketch 3 for US-3818399-A](https://nimo.iptorch.com/refdrawing/US-3818399-A/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/US-3818399-A/003.png)

![Sketch 4 for US-3818399-A](https://nimo.iptorch.com/refdrawing/US-3818399-A/003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/US-3818399-A/004.png)

![Sketch 5 for US-3818399-A](https://nimo.iptorch.com/refdrawing/US-3818399-A/004.png)

[Sketch 6](https://patentimages.storage.googleapis.com/9b/ef/1a/bb77fcce4ebe34/US3818399-drawings-page-2.png)

![Sketch 6 for US-3818399-A](https://patentimages.storage.googleapis.com/9b/ef/1a/bb77fcce4ebe34/US3818399-drawings-page-2.png)

[Sketch 7](https://patentimages.storage.googleapis.com/26/6a/1b/3205264fd00cc1/US3818399-drawings-page-3.png)

![Sketch 7 for US-3818399-A](https://patentimages.storage.googleapis.com/26/6a/1b/3205264fd00cc1/US3818399-drawings-page-3.png)

[Sketch 8](https://patentimages.storage.googleapis.com/18/fa/b9/1fac43acf838e0/US3818399-drawings-page-4.png)

![Sketch 8 for US-3818399-A](https://patentimages.storage.googleapis.com/18/fa/b9/1fac43acf838e0/US3818399-drawings-page-4.png)

[Sketch 9](https://patentimages.storage.googleapis.com/00/7c/df/101007e76ab724/US3818399-drawings-page-5.png)

![Sketch 9 for US-3818399-A](https://patentimages.storage.googleapis.com/00/7c/df/101007e76ab724/US3818399-drawings-page-5.png)

[Sketch 10](https://patentimages.storage.googleapis.com/50/2f/48/810b0225897b08/US3818399-drawings-page-6.png)

![Sketch 10 for US-3818399-A](https://patentimages.storage.googleapis.com/50/2f/48/810b0225897b08/US3818399-drawings-page-6.png)

## Claims

### Claim 1 (independent)

A permanent magnet device comprising at least two pairs of aligned plate-like polepieces of ferromagnetic material such as mild steel, and at least two permanet magnets in upper and lower rows magnetised in opposite directions through their thickness, associated with and lying between the pairs of polepieces, at least one of the magnets being capable of movement relative to the other and relative to the pairs of polepieces from a first position where the magnets and the polepieces co-coperate to provide a maximum external magnetic field strength an on position, to a position where the external magnetic field is reduced to substantially zero an off position.

### Claim 2

A permanent magnet device as in claim 1, wherein the relative movement is such that the magnets can be moved to a third position where an external magnetic field is produced opposite in direction to that provided by the first position.

### Claim 3

A permanet magnet device as in claim 1, wherein the magnets are of slab form and magnetised through the thicknesses of the slabs such that opposite polar faces are of opposite polarity.

### Claim 4

A permanent magnet device as in claim 1, wherein corresponding polar faces of the magnet associated with adjacent pairs of polepieces in the on position are of opposite polarity.

### Claim 5

A permanent magnet device as in claim 1, wherein the upper and lower magnets are moved, relatively to each other by sliding between the polepieces until each bridges the gap between the pairs of polepieces.

### Claim 6

A permanent magnet device as in claim 1, wherein adjacent pairs of polepieces are provided with at least one magnet permanently held between one pair of polepieces and a second magnet magnetised through its thickness in the reverse direction movable from a position between the other pair of polepieces, the ON position, to a position where both magnets are associated with one pair of polepieces, the OFF position.

### Claim 7

A permanent magnet device as in claim 1, wherein the magnetic attractions between each polar surface of each magnet and the neighbouring polepieces are substantially equal to one another but of opposite direction, whereby there is substantial balancing of the magnetIc forces acting on the polar faces of the magnets.

### Claim 8

A permanent magnet device as in claim 1, wherein the device is a work-holding device.

### Claim 9

A permanent magnet device as in claim 8, wherein the magnets and the polepieces are so proportioned that the polar surface area of permanent magnet in contact with a polepiece is greater than the area of the same polepiece in contact with any ferromagnetic article held by the device.

### Claim 10

A permanent magnet device as in claim 1, wherein the movable magnets are mechanically supported to hold the magnets in their positions between the polepieces and to move them as required.

### Claim 11

A permanent magnet device as in claim 10, wherein the movable magnets are positioned in appropriately shaped holes in a support bar of non-magnetic material.

### Claim 12

A permanent magnet device as in claim 11, wherein the bar is moved longitudinally between the polepieces and as it moves it carries the magnets with it.

### Claim 13

A permanent magnet device as in claim 1, wherein all the movable magnets are moved simultaneously.

### Claim 14

A permanent magnet device as in claim 1, wherein some of the movable magnets are movable separately from the remainder of the movable magnets whereby the device can be switched on and off in sections.

### Claim 15

A permanent magnet device as in claim 1, wherein for maximum utilisation of the magnets their width substantially equals that of the polepieces.

### Claim 16

A permanent magnet device as in claim 1, wherein the magnets are produced from high coercivity ferrite material, when thin magnets may be employed with a consequent narrow spacing of the polepieces.

### Claim 17

A permanent magnet device as in claim 8, comprising a base plate of non-magnetic material, side plates and end plates of ferromagnetic material, the base plate having a series of rectangular recesses running longitudinally of the base plate into each of which is secured a number of spaced polepieces, the longitudinal gaps between adjacent rows of polepieces being loaded with upper and lower rows of magnets, the gaps between the upper faces of the polepieces being filled with non-magnetic material.

### Claim 18

A permanent magnet device as in claim 17, wherein the movable magnets are located in support bars provided with recesses in which the magnets are a close fit, and the ends of the support bars extend to operating means for simultaneous movement of the upper and lower support bars in opposite directions.

### Claim 19

A permanent magnet device as in claim 18, wherein the operating means is a pin passing through a vertical slot in each support bar, each pin being located in and secured to rotatable plates, to one of which is secured an operating handle.

### Claim 20

A permanent magnet device as in claim 19, wherein the length of the slot is dictated by the degree of movement required of the support bar.

### Claim 21

A permanent magnet device as in claim 17, wherein the spacing between adjacent polepieces in the transverse direction is maintained by rods bridging the side plates on which distance pieces are provided, the distance pieces lying in the longitudinal gaps between the polepieces.

### Claim 22

A permanent magnet device as in claim 8, comprising a base plate of non-magnetic material, side plates and end plates of ferromagnetic material, the inside faces of the side plates being provided with spaced location pegs to locate transversely disposed packs of polepieces in alternation with magnets whereby adjacent packs provide the longitudinal rows of polepieces and lower fixed magnets, the gaps between the polepieces above the fixed magnets being loaded with the upper rows of magnets, and the gaps between the polepieces above the upper rows of magnets being filled with non-magnetic material.

### Claim 23

A permanent magnet device as in claim 22, wherein the movable magnets are located in support bars provided with recesses in which the magnets are a close fit, the ends of the support bars extending to operating means whereby the support bars can be moved simultaneously.

### Claim 24

A permanent magnet device As in claim 23, wherein the operating means is a rack and pinion, the racks being formed on one edge of the support bars and engaged by the pinion passing across the support bars, the pinion extending to epicyclic gearing to which is secured an operating handle whereby all the supporting bars are moved simultaneously.

### Claim 25

A permanent magnet device as in claim 1, wherein additional polepieces and associated magnets are disposed transversely adjacent said two permanent magnets, transversely adjacent magnets being oppositely magnetised.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGMACHINE TOOLS; METAL-WORKING NOT OTHERWISE PROVIDED FORDETAILS, COMPONENTS, OR ACCESSORIES FOR MACHINE TOOLS, e.g. ARRANGEMENTS FOR COPYING OR CONTROLLING; MACHINE TOOLS IN GENERAL CHARACTERISED BY THE CONSTRUCTION OF PARTICULAR DETAILS OR COMPONENTS; COMBINATIONS OR ASSOCIATIONS OF METAL-WORKING MACHINES, NOT DIRECTED TO A PARTICULAR RESULTDevices holding, supporting, or positioning work or tools, of a kind normally removable from the machineDevices for holding work using magnetic or electric force acting directly on the workStationary devicesStationary devices using permanent magnets

Description

United States Patent [191- I Edwards 1 June 18, I974 1 PERMANENT MAGNET DEVICES I 75 I t I M Ed Sh Primary Examiner-George Harris 1 men or wards leld England Attorney, Agent, or Firm-Lowe, King & Price [73] Assignee: James Neill Holdings Limited,

England W v 22 Filed: Jan. 24, 1973 [57] ABSTRACT 21 Appl 32 ,532 A permanent magnet device comprising at least two pairs of aligned plate-like polepieces of ferromagnetic material such as mild steel, and at least two permanent [30] Fmelgn Apphcauon Pnomy Data magnets in upper and lower rows magnetised in oppo- Feb. 2, 1972 Great Britain 4784/72 site directions through their thickness, associated with and lying between the pairs of polepieces, at least one [52] US. Cl. 335/295, 335/306 of the magnets being capable of movement relative to [51] Int. Cl. H0lf 7/04 at least one other and relative to the pairs of pole- [58] Field of Search 335/285, 295, 306 pieces from a first position where the magnets and the polepieces co-operate to provide a maximum external [56] References Cited magnetic field strength (the ON position) to a position UNITED STATES PATENTS where the extemal' magnetic field is reduced to sub- 2,972,4s5 2/1961 Ferchlandhl 335/295 stamlally Zero (the OFF 9 3,135.899 6/1964 Sears 335/295 1 25 Cl 14m F FOREIGN PATENTS OR APPLICATIONS 939.584 [0/1963 Great Britain. 335/295 8 l i I l l M! iv Is 5| M, V l l I- I l l l r w is s: {N N} ,s '5' l 1' I PATENTED N 1 8197-4 3 8 L8 3 SHEETIUFS PATENTEDJUN 1 31914 SHEET 3 OF 5 QUE II I

l L J PATENTED JUN] 8l174 SHEET l 0F 5 .U T A WT fi r C Jr U F 4 F w: I F UH F Q r m; JET Jr 4 Q r I ON 4 r Am F {V a Q Ur T J it 4r 4 H: F r A? h m? F J T 1: F H; H H:

PATENTED JUN 1 8 m4 SHEET 5 0F 5 This invention relates to permanent magnet devices and in particular relates to such devices when provided with a means to modify the external magnetic field of the permanent magnets by reduction, reversal, or complete elimination.

Such devices are alreadyknown, and in particular there are known work holding devices, e. g., permanent magnet chucks but such devices as are in present commercial use are known to have certain serious disadvantages. Hitherto, one well-known design of magnetic chuck has been constituted by two packs of pennanent magnets and ferro-magnetic pole pieces, the relative position of the two packs determining whether or not there is an external magnetic field. The upper pack of such a chuck is held stationary and its upper surface is the work holding surface; the lower pack is movable in relation to the upper pack. Such a construction has two inherent and serious drawbacks. Firstly the attractive force between the packs is so great as to make the lower pack difficult to move unless mechanical means are provided to separate the packs slightly and make relative movement practicable. Secondly, the upper pack is unsupported except at its edges and therefore when pressure is applied to work pieces during milling, grinding etc., the work-holding surface is deflected, thereby limiting the flatness and accuracy of machining and in extreme cases causing chatter marks on the finished surface.

The object of the present invention is to provide a permanent magnet device which is easily switched from the on to the off position and is free from the disadvantages described above when used as a workholding device.

According to the present invention, a permanent magnet device comprises at least two pairs of aligned plate-like polepieces of ferromagnetic material such as mild steel, and at least two permanent magnets magnet'ised in opposite directions through their thickness, associated with and lying between the pairs of polepieces, at least one of the magnets being capable of movement relative to at least one other and relative to the pairs of polepieces from first position where the magnets and the polepieces co-operate to provide maximum external magnetic field strength (the ON position) to a position where the external magnetic field is reduced to substantially zero (the OFF position). The relative movement may be such. that the magnets can be returned to their original position or moved to a third position where an external magnetic field is produced, opposite in direction to that provided by the first position.

site polarity. In this ON position, the magnets and the polepieces provide external fields of maximum strength. The two magnets may be moved, simultaneously or separately, relatively to each other by sliding between the polepieces until each bridges the gap between the pairs of polepieces, the OFF position. As the magnets approach this position the external field is reduced in strength until a critical position is reached at which the external fields become substantially zero, by virtue of the short circuit paths provided by the polepieces. The magnets may be returned to their original position when the external field returns to its maximum value, or the movement may be continued so that each magnet becomes associated with the other pair of polepieces when the external fields are increased to a maximum but of reversed directions. Alternatively, instead of moving the two magnets in opposite directions such as to bridge the gap between the pairs of polepieces, one magnet may be permanently held between one pair of polepieces and the second magnetised through its thickness in the reverse direction, moved from its posi tion between theother pair of polepieces to a position where both magnets are associated with one pair of polepieces. Thus, as the magnet is moved, the external magnetic field is gradually reduced until such time as both magnets lie between the same pair of polepieces, when-again complete short circuiting is provided to eliminate the external fields. The magnet that has been moved may be returned to its original position to increase the magnetic fields back to a maximum or alternatively the second magnet may be held and the first magnet moved into association with the other pair of polepieces, when the external fields are increased to maximum but of reversed directions. In certain usages of the device of the invention, it is desirable that in the OFF position, there is in fact a low strength external 'field of reverse direction to that in the ON position.

This is especially advantageous when the device is a work-holder, when demagnetisation of a hardened steel I workpiece can be effected.

Each polar surface of each magnet attracts, and is attracted by, the neighbouring ferromagnetic polepieces, and is, therefore, acted on by forces at its two polar surfaces which aresubstantially equal to one another but are in opposite directions. This substantial balancing of magnetic forces makes it particularly easy to slide the magnet between the polepieces in a direction transverse to its direction of magnetisation.

In accordance with the ultimate use to which the permanent magnet device is to be put so may the arrangement of polepieces and magnets be modified, thus any number of aligned pairs of polepieces may be provided and there .may be a magnet associated with each pair of polepieces in the ON position, i.e., the position where an external magnetic force of maximum strength is provided. Alternatively, two magnets may be provided in association with each pair of polepieces in the ON position, the two magnets being magnetised through their thickness in the same direction so that the corresponding face of each magnet associated with one of the pair of polepices is of the same polarity, the corresponding face of the magnets associated with the ad jacent pair of polepieces being of opposite polarity in that position. Such an arrangement can be designed to provide a heavy concentration of flux at the exposed edges of the polepieces thus making the device eminently suitable as a work-holding device. However,

work-holding devices of large surface area are often required. Therefore, in addition to there being any number of pairs of aligned polepieces and associated magnets in what for ease will be referred to as the longitudinal direction, additional polepieces and associated magnets may be provided in what can be referred to as the transverse direction with corresponding magnets in the transverse direction magnetised in the reverse direction. Thus, a sandwich" construction is provided of any length and breadth as may be required to suit any application.

Moreover, the magnets and the polepieces are readily so proportioned that the polar surface area of permanent magnet in contact with a polepiece is greater than the area of the same polepiece in contact with any ferromagnetic article held by the device. According to his conception, the polepiece collects magnetic flux at low density from a large area of permanent magnet surface, and concentrates it into the limited area of polepiece surface in contact with the ferromagnetic article being held. Under such circumstances as is well established both practically and theoretically, the total attraction between a polar surface of a magnet and its adjoining polepiece is much less than the total attraction between the same polepiece and the ferromagnetic article held, although substantially the same total amount of magnetic flux passes across both boundaries as parts of the same magnetic circuit.

Examining the previously-known construction from this point of view the reasons for its unsatisfactory mechanical operation are understood. The polepieces move with the magnets and the relative movement between the packs is at surfaces of high flux density. The force on the movable pack is all in one direction, there is no balancing force. By contrast the invention has fixed polepieces between which the magnets can easily slide, partly because the attraction between the magnets and the polepieces is small in any case, and partly because these forces are so arranged that they practi cally cancel one another.

From its simplest form where but two magnets are provided up to its most complex form where a large number of pairs of magnets are provided, it is necessary to provide mechanical support to hold the magnets in their positions between the polepieces and to move them as required. Thus, when both magnets are intended to be moved, it is preferred that the magnets be positioned in appropriately shaped holes in a support -bar of non-magnetic material (e.g., brass of synthetic plastics material), there being separate support bars for the upper and lower rows of magnets. The bar as a whole may be moved longitudinally between the polepieces by known and appropriate arrangements of levers, eccentrics, racks, pinions etc., and as it moves it carries the magnets with it. The magnets may be either a tight or a loose fit in the support bar as may be appropriate for the method of manufacture, the magnetisation may take place either before or after the magnets have been fitted into the bar or the bar has been moulded around them. A very small mechanical clearance is allowed to permit the bars and magnets to slide freely between the rows of polepieces. Alternatively, when only one row of magnets are to be moved, the other row may be secured directly between the polepieces.

Because there -is a cancellation of attractive forces between the magnets and the polepieces and because magnetic flux is fed between magnets and polepieces at low density, the mechanical forces required to move all the upper magnets and the lower magnets simultaneously is still small. Whilst the various upper and lower bars holding magnets are normally coupled together for simultaneous movement this is not essential,

and the magnetic device may be switched ON and OFF in sections if desired.

For maximum utilisation of the magnets their width should equal to slightly exceed that of the polepieces. A wider magnet islarger and produces more flux but excessive width increases the proportion of flux lost by leakage between neighbouring magnets.

It is preferred that the magnets should be produced from so-called ferrite material, when thin magnets may be employed with a consequent narrow spacing of the polepieces, a distinct advantage particularly when the device is used as a magnetic chuck. In normal constructions the thickness of the polepieces is somewhat greater than the thickness of the magnets between them.

When the device has two magnets associated with each pair of polepieces in the ON position, each polepiece-is normally in contact with four magnet polar surfaces corresponding to the upper and lower bars on each side, and each of these surfaces is of the same po Iarity. Exceptions are the four corner polepiecesof the construction which are in contact with one magnet polar surface only, and the other polepieces in the outermost rows and at one or both ends of each row, which are each in' contact with two magnet polar surfaces.

If the device is switched to the OFF position by moving the upper and lower bars with their associated magnets in opposite directions by approximately half a longitudinal pole pitch to bridge the polepieces, most of the magnets become associated with no less than four internal flux diversion paths. Therefore the flux diversion is particularly complete and the external magnetic field of the device can be controlled such as to substantially eliminate it or provide slight reversal, giving complete release of workpieces when the device is used as a workholder.

To explain the invention further, it will now be de scribed by way of example only with reference to the accompanying drawings, in which:

FIG. 1 is a diagrammatic representation of a flux switching device according to the invention in which both magnets associated with the pairs of polepieces move, the magnets being shown in the ON position;

FIG. 2 corresponds to FIG. 1, but shows the magnets in the OFF position;

FIG. 3, 4 and 5 are sections on the lines IIIIII, IV-IV and V-V respectively of FIG. 2 showing the internal flux diversion paths; I

FIG. 6 corresponds to FIG. 1, but shows an arrangement where only the upper magnets move, the magnets being shown in the ON position;

FIG. 7 corresponds to FIG. 6, but shows the magnets in the OFF position;

FIG. 8 is a section on the line VIII VIII of FIG. 7 showing the internal flux diversion path;

FIG. 9 is a plan view of a magnetic chuck in which the magnets are moved in accordance with FIG. 1;

FIG. 10 is a side elevation of FIG. 9;

FIG. 11 is a section on the line XIXI of FIG. 9;

FIG. 12 corresponds to FIG. 9, but shows a magnetic chuck in which the magnets are moved in accordance with FIG. 6;

FIG. 13 is a side elevation of FIG. 12; and,

FIG. 14 is a section on the line XIV-XIV of FIG. 12.

In FIG. 1, a flux switching device is shown as having a number of pairs of ferromagnetic polepieces I, be-

tween which lie upper and low rows of magnets 2. Each magnet is magnetised through its thickness so that opposite polar faces of the magnets are of opposite polarity, and are positioned between the polepieces such that the corresponding polar faces of adjacent magnets in each row are of opposite polarity. Thus, with the upperand lower rows of magnets moved to a position where all the magnets lie between respective pairsof polepieces, and with the corresponding polar face of an upper and lower magnet associated with one pair of polepieces being of the same polarity, the magnets and the polepieces combine to provide an external magnetic field of maximum strength, above and below the polepieces. To reduce these external fields to substantially zero, the magnets 2 of the upper and lower rows are moved by half a pole pitch to the position shown in FIG. 2, when each pair of polepieces, apart from the outermost pairs, are contacted by a mouth pole and a south pole of the magnets of the upper and lower rows, a north pole being adjacent a south pole in both the horizontal and vertical directions. The effect of this is shown by FIGS. 3, 4 and 5 which illustrate the flux diversion paths between the magnets through the polepieces, which effectively reduce the external field to substantially zero. The upper and lower-rows of magnets can be returned to the position shown in FIG. 1, when the external magnetic field is returned to maximum strength, but the magnets could be moved by half I a pole pitch in the opposite direction, when an external magnetic field of maximum strength would be created but of reverse direction to that of FIG. 1. That is, while viewing FIG. 1 and using the end magnets 2 as a reference point, assume the top row is shifted all the way to the left and the lower row is shifted all the way to the right, then the direction of the magnet field when considering the flux paths running from the north pole to the south pole of the adjacent magnet is opposite to that shown in the original position of FIG. 1.

As an alternative to moving both rows of magnets, the same effect can be obtained by moving either the upper or lower row. Thus, as is shown by FIGS. 6 and 7, a number of pairs of polepieces l are provided between which lie upper and'lower rows of magnets, each magnet again being magnetised through its thickness. The lower row of magnets are secured between the I polepieces with corresponding polar faces on adjacent magnets of opposite polarity. With the magnets of the upper row positioned as shown by FIG. 6, the magnets of both rows combine with the polepieces to provide an external magnetic field of maximum strength. To reduce the external field to substantially zero, the magnets 2 of the upper row are moved by a full pole pitch to the position shown in FIG. 7, when the corresponding polar faces of the magnets of the upper and lower rows associated with each pair of polepieces are of opposite polarity. The effect of this is to provide a flux diversion path through the polepieces as is shown by FIG.

8. To return the external magnetic field to full strength, the magnets 2 of the upper row may be returned to the position shown in FIG. 6, or they may be moved by a full pole pitch in the opposite direction (when a further pair of polepieces 1A would be provided) again to provide an external magnetic field of maximum strength Using another reference point from that used in describing FIG. 1, the magnet 2 that appears at the particular polepiece l first from the left of added polepiece 1A in FIG. 7, it can be seen that the resultant external magnetic fieldmay be considered to remain in the same direction between the shifted positions described, i.e. the magnetic field is toward the reference magnet after the top row is shifted in either direction as assumed above. Only when both the upper and lower rows are shifted by half a pole pitch apiece as in FIG. 1, would the field be of reversed direction to that of FIG. 6. Obviously, similar analysis of field directions with respect to other reference magnets 2 and other reference points in either FIG. 1 or FIG. 6 may be made as de sired.

The concept as defined above may be used in an instance where an external magnetic field is required, which field is required to be reduced, substantially eliminated, partially reversed or completely reversed. Because heavy concentration of flux can be arranged at the exposed edges of the polepieces and because the polepieces are held stationary as the magnets are moved (with relative ease by virtue of the selfbalancing of .magnetic attraction forces between the magnets and the polepieces) the flux switching device is eminently suitable as a work holding device (a magnetic chuck).

Thus, as is shown in FIG. 9, a magnetic chuck comprises a base plate 3 of non-magnetic material to which are secured end plates 4 and side plates 5 preferably of ferromagnetic material. The base plate 3 has a series of rectangular recesses 6 (F IG.. 1 1) running longitudinally of the base plate into each of which is secured a number of polepieces 1 (FIG. 10), the polepieces being secured in place by bolts 7. It will be appreciated that any number of polepieces can be provided in both the longitudinal and transverse directions of the base plate 3) to suit a particular application.

The longitudinal gaps between adjacent rows of polepieces are maintained by transverse rods 5A bridging the side plates 5, with distance pieces 53 located between the polepieces. The gaps are loaded with upper and lower rows of magnets 2 of high coercivity ferrite material in slab form, each row of magnets being located in a support bar 8 provided with recesses 9 in which the magnets are a close fit. The lower support bar rests directly on the base plate 3 between the polepieces and the upper support bar rests on the top face of the lower support bar. The gaps between the polepieces above the top face of the upper support bars are filled with non-magnetic material (preferably a suitable form of resin filler) prior to the application of the support bars to the gaps, the top face being machined after being filled to ensure that the upper surface of the polepieces are left exposed. After the support bars have been loaded, a further end plate 10 is secured to the side plates.

lnwardly of the end plate 10, the mechanism to provide simultaneous movement of all the upper and all the lower support bars and thus magnets in opposite directions is provided. Thus, as shown. particularly by FIG. 10 the corresponding end of the upper and lower support bars are each provided with vertical slots 11 through which pass pins 12, the pins being located in and secured to rotatable locking plates 13, to one of which is secured an operating handle 14. The length of the slots 11 is dictated by the degree of movement required of each support bar. In this embodiment the upper and lower support bars are each intended to move by approximately half a pole pitch.

Thus, with magnets, magnetised through their thickness either before or after being loaded in the support bars to provide opposite polar face, and with the magnets being disposed in each support bar in the manner depicted in FIG. 1 with corresponding polar faces of adjacent magnets in each support bar of opposite polarity and with corresponding magnets in adjacent support bars being magnetised in the reverse direction, the handle 14 is operated to cause the pins 12 to move the upper and lower support bars to the position shown in FIG. 10, the ON position, when all the magnets and all the polepieces co-operate to provide an external magnetic field of maximum strength in the manner described with respect to FIG. 1. To reduce the external magnetic field to substantially zero, the handle 14 is rotated in the opposite direction within the limits imposed by the lengths of the slots 11 in the support bars, to bring the upper and lower rows of magnets to the position corresponding to FIG. 2, when the magnets and the polepieces co-operate to provide internal flux diversion paths after the manner described with reference to FIGS. 3 to 5. Thus, any ferromagnetic workpieces resting on the upper surface of the chuck can then be removed. With certain workpieces, the application of the external field can cause'permanent magnetisation of the workpiece and it is therefore advisable that the lengths of the slots 11 are such as to allow a movement of the magnets to a point slightly beyond the position where the external field has been substantially eliminated, to provide a low strength external field of reverse direction thereby demagnetising the workpiece.

Because the upper surfaces of the polepieces actually form the worksupporting surface, and the polepieces extend directly to the base plate 3 which is in turn secured in the machine, a chuck of considerable mechanical strength is provided allowing great accuracy in any machining operation performed on the workpiece by virtue of the elimination of any tendency of the worksupporting surface to be deflected. Also, with the base plate, side plates and end plates formed from a suitable non-magnetic material, and with the efficiency of elimination of the external magnetic field by the flux diversion paths in the OFF position, stray external magnetic fields are substantially eliminated thereby preventing magnetisation of the machine itself with consequent prevention of magnetisation of the cutting means, (e.g., a milling cutter). This also considerably improves the surface finish capable of being given the workpiece.

FIG. 12, 13 and 14 show a flux switching device again in the form of a magnetic chuck, but in this case embodying the principle depicted in FIGS. 6, 7 and 8, where only the row of magnets is moved by a full pole width.

Thus, a magnetic chuck has a non-magnetic base plate 15 provided with side plates 16 and end plates 17, 18, preferably of ferromagnetic material. On the inside faces of each side plate 16 are provided spaced locating pegs 19. To provide the longitudinal rows of polepieces l and lower fixed magnets 2 (again of ferrite material in slab form), transverse rows of polepieces and magnets are separately formed as packs. Polepieces in alternation with magnets are placed in a jig, there being adhesive applied to both polar faces of the magnets. Distance pieces are placed between the polepieces at their upper ends, and the whole assembly compressed to provide the required transverse spacing between adjacent polepieces and the pack held to allow the adhesive to eat. The pack is then located between the side plates 16 on the pegs 19 by virtue of vertical slots 20 in the outside face of each outermost polepiece 1 and the pack secured from below, e.g., by bolts. With the area between the side plates loaded with the requisite number of packs, and before application of the end plate 18, a series of spacers are placed in the longitudinal gaps between adjacent pairs of polepieces, the spacers being lubricated with, e.g., a silicone base lubricant, to effect sealing of the gaps between the spacers and the polepieces. Resin is then run in to fill the gaps between the polepieces and the top surface finally ground to leave the polepieces with an exposed upper face. The spacers are then removed and replaced by support bars having recesses into which magnets are fitted, the magnets again being thin ferrite magnets magnetised through their thickness to provide polar faces of opposite polarity.

Thus, with adjacent polar faces of the lower fixed rows of magnets alternating in polarity both longitudinally and transversely and with the magnets in the support bars also alternating in polarity both longitudinally and transversely, the support bars are moved to a position such that the magnets assume a position equivalent to that shown in FIG. 6 whereby an external magnetic field is provided of maximum strength, and to reduce the magnetic field to substantially zero the rows of support bars moved until the magnets assume a position equivalent to that shown in FIG. 7 when internal flux diversion paths, as depicted in FIG. 8, are created with the resultant elimination of the external magnetic field. To move all the support bars simultaneously, the lower edge of each support bar 21, at its end adjacent the end plate 18 is provided with a rack 22 all the racks being engaged by a pinion 23 extending across the full width of the chuck through notches provided in the endmost polepieces. The pinion is secured to a gear wheel 24 lying externally of one side plate 16, the gear wheel 24 engaging an internally toothed gear wheel 25 having a drive shaft 26 on which is mounted a handle 27. A cover plate 28 encloses the epicyclic gearing 24, 25, the cover plate being provided with stops 29 (which may be adjustable) to limit movement of the handle 27. To reduce the overall length of the chuck, as is distinctly advantageous, the operating pinion is situated inwardly of the end plate and as a consequent, the endmost magnets must be shorter than the rest. This slightly reduces the maximum external field available at that point but this does not affect the overall performance of the chuck. By utilising an epicyclic gear transmission, a very convenient handle movement of approximately l is needed to switch the device ON and OFF.

Thus, rotation of the handle through approximately simultaneously moves all the support bars to bring the magnets in the support bars to a position corresponding to that shown in FIG. 6, reverse movement of the handle bringing the support bars and thus the magnets to a position corresponding to that shown in FIG. 7. The position of the stops 29 is such that the movable magnets can be brought to a position where the external magnetic field has been reduced to substantially zero, or to a position where a low strength external magnetic field is created of reverse direction, to effect demagnetisation of a workpiece applied to the working surface.

v in FIGS. 9 and 11 can be applied to the work-holding device of FIGS. 12 and 14 and vice versa.

With both constructions shown, it is advisable to have magnets slightly greater in length than the length of the polepieces and to have the thickness of the magnets slightly less than the thickness of the polepieces, whereby the maximum possible concentration of flux through the polepice is obtained.

What l claim is:

l. A permanent magnet device comprising at least two pairs of aligned plate-like polepieces of ferromagnetic material such as mild steel, and at least two permanet magnets in upper and lower rows magnetised in opposite directions through their thickness, associated with and lying between the pairs of polepieces, at least one of the magnets being capable of movement relative to the other and relative to the pairs of polepieces from a first position where the magnets and the polepieces co-coperate to provide a maximum external magnetic field strength an on position, to a position where the external magnetic field is reduced to substantially zero an off position.

2. A permanent magnet device as in claim 1, wherein the relative movement is such that the magnets can be moved to a third position where an external magnetic field is produced opposite in direction to that provided by the first position.

3. A permanet magnet device as in claim 1, wherein the magnets are of slab form and magnetised through the thicknesses of the slabs such that opposite polar faces are of opposite polarity.

4. A permanent magnet device as in claim 1, wherein corresponding polar faces of the magnet associated with adjacent pairs of polepieces in the on position are of opposite polarity.

5. A permanent magnet device as in claim 1, wherein the upper and lower magnets are moved, relatively to each other by sliding between the polepieces until each bridges the gap between the pairs of polepieces.

6. A permanent magnet device as in claim 1, wherein adjacent pairs of polepieces are provided with at least one magnet permanently held between one pair of polepieces and a second magnet magnetised through its thickness in the reverse direction movable from a position between the other pair of polepieces, the ON position, to a position where both magnets are associated with one pair of polepieces, the OFF position. I

7. A permanent magnet device as in claim 1, wherein the magnetic attractions between each polar surface of each magnet and the neighbouring polepieces are substantially equal to one another but of opposite direction, whereby there is substantial balancing of the magnetic forces acting on the polar faces of the magnets.

8. A permanent magnet device as in claim 1, wherein the device is a work-holding device.

9. A permanent magnet device as in claim 8, wherein the magnets and the polepieces are so proportioned that the polar surface area of permanent magnet in contact with a polepiece is greater than the area of the same polepiece incontact with any ferromagnetic article held by the device.

10. A permanent magnet device as in claim 1, wherein the movable magnets are mechanically supported to hold the magnets in their positions between the polepieces and to move them as required.

11. A permanent magnet device as in claim 10, wherein the movable magnets are positioned in appropriately shaped holes in a support bar of non-magnetic material.

l2. A permanent magnet device as in claim 11, wherein the bar is moved longitudinally between the polepieces and as it moves it carries the magnets with It.

13. A permanent magnet device as in claim 1, wherein all the movable magnets are moved simultaneously.

14. A permanent magnet device as in claim 1, wherein some of the movable magnets are movable separately from the remainder of the movable magnets whereby the device can be switched on and off in sections.

15. A permanent magnet device as in claim 1, wherein for maximum utilisation of the magnets their width substantially equals that of the polepieces.

16. A permanent magnet device as in claim 1,

wherein the magnets are produced from high coercivity ferrite material, when thin magnets may be employed with a consequent narrow spacing of the polepieces.

17. A permanent magnet device as in claim 8, comprising a base plate of non-magnetic material, side plates and end plates of ferromagnetic material, the base plate having a series of rectangular recesses run ning longitudinally of the base plate into each of which is secured a number of spaced polepieces, the longitudinal gaps between adjacent rows of polepieces being loaded with upper and lower rows of magnets, the gaps between the upper faces of the polepieces being filled with non-magneticmaterial.

18. A permanent magnet device as in claim 17, wherein the movable magnets are located in support bars provided with recesses in which the magnets are a close fit, and the ends of the support bars extend to operating means for simultaneous movement of the upper and lower support bars in opposite directions.

19. A permanent magnet device as in claim 18, wherein the operating means is a pin passing through a vertical slot in each support bar, each pin being located in and secured to rotatable plates, to one of which is secured an operating handle.

20. A permanent magnet device as in claim 19, wherein the length of the slot is dictated by the degree of movement required of the support bar.

21. A permanent magnet device as in claim 17, wherein the spacing between adjacent polepieces in the transverse direction is maintained by rods bridging the side plates on which distance pieces are provided, the distance pieces lying in the longitudinal gaps between the polepieces.

22. A permanent magnet device as in claim 8, comprising a base plate of non-magnetic material, side plates and end plates of ferromagnetic material, the inside faces of the side plates being provided with spaced location pegs to locate transversely disposed packs of polepieces in alternation with magnets whereby adjacent packs provide the longitudinal rows of polepieces and lower fixed magnets, the gaps between the polepieces above the fixed magnets being loaded with the upper rows of magnets, and the gaps between the polepieces above the upper rows of magnets being filled with non-magnetic material.

23. A permanent magnet device as in claim 22, wherein the movable magnets are located in support bars provided with recesses in which the magnets are a close fit, the ends of the support bars extending to operating means whereby the support bars can be moved simultaneously.

24. A pennanent magnet device as in claim 23,

sitely magnetised.

## Classifications

- B23Q3/1546
- B23Q3/1546

## Cited patent documents

- [GB-939584-A](https://patents.google.com/patent/GB939584A/en) — SEA
- [US-2972485-A](https://patents.google.com/patent/US2972485A/en) — SEA
- [US-3135899-A](https://patents.google.com/patent/US3135899A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
