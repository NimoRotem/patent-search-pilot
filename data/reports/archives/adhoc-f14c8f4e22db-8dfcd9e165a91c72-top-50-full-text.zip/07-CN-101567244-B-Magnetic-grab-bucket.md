# 07. Magnetic grab bucket

- **Archive rank:** 7 of 50
- **Publication:** [CN-101567244-B](https://patents.google.com/patent/CN101567244B/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/039365707/publication/CN101567244B?q=pn%3DCN101567244B)
- **Publication date:** 2012-12-05
- **Filing date:** 2009-02-04
- **Earliest priority:** 2008-02-04
- **Family:** 39365707
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** TRUMPF WERKZEUGMASCHINEN GMBH
- **Inventors:** W THIEL

## Abstract

The invention relates to a magnetic grab bucket used for grabbing and carrying ferromagnetic workpieces. The magnetic grab bucket comprises a housing; a housing base is disposed on the housing; the housing base has an end face facing the workpiece to be grabbed; the magnetic grab bucket also comprises at least one magnetic piston disposed in the housing and at least one connecting piece equipped to the at least one magnetic piston. The connecting piece is used for connecting the working fluid used by the movable magnetic piston; thereby, the magnetic piston bears a first operating pressure, and is transmitted to the operating position, here, the magnetic piston is positioned on the housing base or near the housing base; and the magnetic piston is transmitted to the unused position under another operating pressure, here, the magnetic piston is positioned far from the housing base; wherein, at least one detection apparatus is disposed on or in the housing, used for detecting whether a workpiece exists on the end side of the housing.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-101567244-B/000.png)

![Sketch 1 for CN-101567244-B](https://nimo.iptorch.com/refdrawing/CN-101567244-B/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-101567244-B/001.png)

![Sketch 2 for CN-101567244-B](https://nimo.iptorch.com/refdrawing/CN-101567244-B/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/CN-101567244-B/002.png)

![Sketch 3 for CN-101567244-B](https://nimo.iptorch.com/refdrawing/CN-101567244-B/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/CN-101567244-B/003.png)

![Sketch 4 for CN-101567244-B](https://nimo.iptorch.com/refdrawing/CN-101567244-B/003.png)

## Claims

### Claim 1 (independent)

Claims (19) magnetic grab bucket; Be used for grasping and carrying ferromagnetic workpiece (19); Said magnetic grab bucket comprises housing (16), and housing is provided with housing base (17), and said housing base has the end face (18) facing to the workpiece that will grasp (19); Said magnetic grab bucket also comprises at least one magnetic piston (21) that is arranged in the housing (16) and is at least one connector (31 that said at least one magnetic piston (21) is equipped with; 27), said connector is used to connect the used drive fluid of mobile magnetic piston (21), thereby magnetic piston (21) is born first operating pressure and is sent to operating position (36); This magnetic piston (21) be positioned at that housing base (17) is gone up or the housing base near; And magnetic piston is sent to rest position (37) under another operating pressure, is positioned to it is characterized in that away from housing base (17) in this magnetic piston (21); At least one checkout gear (41) is arranged in the housing (16) or on the housing; The end face (18) that is used to detect housing (16) is keeping workpiece (19) or is not having workpiece, and said at least one checkout gear (41) confirms the operating pressure of working fluid, and said operating pressure is obtained and represented that workpiece (19) remains on the end face (18) of housing (16) in valid function position (42) by checkout gear (41); And the variation of operating pressure, the variation of said operating pressure is obtained and is represented that workpiece (19) does not exist on the end face (18) of housing (16) in invalid operation position (43) by checkout gear (41).

### Claim 2

according to the magnetic grab bucket of claim 1; It is characterized in that; For magnetic piston (21) is sent to operating position (36), negative pressure or vacuum are applied in as operating pressure, and checkout gear (41) is kept the operating pressure that is applied in the process that grasps and carry workpiece (19).

### Claim 3

according to the magnetic grab bucket of claim 1, it is characterized in that for magnetic piston (21) is sent to operating position (36), negative pressure or vacuum are applied in as operating pressure, and do not exist, discharge or putting down that this operating pressure reduces under the situation of workpiece (19).

### Claim 4

according to the magnetic grab bucket of claim 1, it is characterized in that checkout gear (41) is arranged in the housing (16), and be provided in the enclosure space that is formed between housing (16) and the movably said magnetic piston (21).

### Claim 5

according to the magnetic grab bucket of claim 1, it is characterized in that checkout gear (41) is integrated in the movably said magnetic piston (21).

### Claim 6

according to the magnetic grab bucket of claim 1; It is characterized in that; Checkout gear (41) is constructed to mangneto dynamic formula valve gear; It opens or closes the passage (55) in the magnetic piston (21), and said passage is positioned at the piston chamber (26) of bearing said working fluid and opposed and bears between the operating chamber (24) of said another operating pressure.

### Claim 7

according to the magnetic grab bucket of claim 6, it is characterized in that said valve gear comprises that the have valve seat valve supporter (45) of (53) and the application valve body (46) with valve face (52), said application valve body are arranged to be suitable in said valve supporter, move.

### Claim 8

according to the magnetic grab bucket of claim 7, it is characterized in that said application valve body (46) has at least one permanent magnet (66) on its end facing to housing base (17).

### Claim 9

according to the magnetic grab bucket of claim 7 or 8, it is characterized in that said application valve body (46) remains on invalid operation position (43) by energy-storage travelling wave tube (47), and raise with respect to valve seat (53).

### Claim 10

according to the magnetic grab bucket of claim 7 or 8, it is characterized in that at least one leader (61) is arranged between application valve body (46) and the valve supporter (45).

### Claim 11

magnetic grab bucket according to Claim 8; It is characterized in that; Between said at least one permanent magnet (66) on valve seat (53) and the application valve body (46), be provided with leader (61), said leader has at least one channel shaped recess (57) and forms the part of said passage (55).

### Claim 12

magnetic grab bucket according to Claim 8; It is characterized in that; When magnetic piston (21) is sent to operating position (36) and workpiece (19) is magnetized workpiece (19) is positioned at the last time of end face (18) of housing (16); Application valve body (46) is suitable under the magneticaction of its at least one permanent magnet (66), being transferred into valid function position (42), and application valve body (46) is closed valve seat (53).

### Claim 13

magnetic grab bucket according to Claim 8; It is characterized in that; When valve gear was closed, the end face facing to housing base (17) of permanent magnet (66) (67) was supported on the housing base (17) with predetermined gap, and this gap is confirmed by the gasket ring that is connecting magnetic piston (21).

### Claim 14

the magnetic grab bucket according to claim 7 is characterized in that, is provided with lid (48), is used for restriction and adjusting range are arranged on valve face (52) on the application valve body (46) facing to the valve seat (53) of valve supporter (45) the stroke of opening.

### Claim 15

the magnetic grab bucket according to claim 14 is characterized in that, said lid (48) is fastened on the valve supporter (45).

### Claim 16

the magnetic grab bucket according to claim 14 is characterized in that, said valve gear also comprises intermediate energy storage element (47) and lid (48), is suitable for inserting in magnetic piston (21) or the housing (16) as prefabricated unit.

### Claim 17

the magnetic grab bucket according to claim 1 is characterized in that, between checkout gear (41) and relevant connector (31), is formed with connecting line (69), is used for supply and discharging working fluid.

### Claim 18

the magnetic grab bucket according to claim 1 is characterized in that, said at least one operating pressure that is used for magnetic piston (21) is sent to operating position (36) is suitable for being detected by at least one sensor (35).

### Claim 19

the magnetic grab bucket according to claim 1 is characterized in that, a plurality of checkout gears (41) be arranged on that housing (16) is gone up or housing in, and provide segmentation to detect to the end face (18) of housing (16).

## Full description

**[p0001]**

PERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by magnetic meansELECTRICITYELECTRIC ELEMENTSMAGNETS; INDUCTANCES; TRANSFORMERS; SELECTION OF MATERIALS FOR THEIR MAGNETIC PROPERTIESMagnetsPermanent magnets [PM]Magnetic circuits with PM for power or force generationPM holding devicesELECTRICITYELECTRIC ELEMENTSMAGNETS; INDUCTANCES; TRANSFORMERS; SELECTION OF MATERIALS FOR THEIR MAGNETIC PROPERTIESMagnetsPermanent magnets [PM]Means for releasing the attractive force Description Magnetic grab bucket Technical field The present invention relates to a kind of magnetic grab bucket (magnetic grab); Be used for grasping and the carrying ferromagnetic workpiece; Said magnetic grab bucket comprises housing, and housing is provided with the housing base, and said housing base has the end face facing to the workpiece that will grasp; Said magnetic grab bucket also comprises at least one magnetic piston that is arranged in the housing and is at least one connector that said at least one magnetic piston is equipped with; Said connector is used to connect and moves the used working fluid of magnetic piston, thus magnetic piston bear fir

**[p0001]**

st operating pressure and be sent to the operating position, be positioned on the housing base or near the housing base in this magnetic piston; And magnetic piston is sent to rest position under another operating pressure, is positioned away from the housing base in this magnetic piston.

**[p0002]**

Background technology A kind of magnetic grab bucket of the above-mentioned type is shown in DE 199 51 703 A1.In order to grasp and conveying workpieces, magnetic piston is born operating pressure, thereby is supported in the housing base.Can cause the magnetization of ferromagnetic workpiece like this, workpiece is being fixed on the housing end face under the effect of magnetic confining force.After the conveying, pressure pulse acts on magnetic piston, thereby magnetic piston moves to the position away from the housing base, so the magnetic field reduction, and workpiece can put down or discharge. Such magnetic grab bucket is preferred for such workpiece, and promptly because the oneself requirement of workpiece or anticipate, workpiece has a plurality of holes, perforation, distortion and/or complicated geometry, for example cell structure.Because the motion of magnetic piston occurs in the enclosure space, and workpiece keeps by magnetic force, and each pressure pulse or pressure surge are enough to make workpiece to be grasped or put down thus.Such magnetic grab bucket thereby can be in low-yield down operation.Whether the shortcoming of this magnetic grab bucket is, can not discern automatically to have received workpiece or workpiece whether and in course of conveying, lose.In order to meet growing automation requirement, hope and necessary these duties of keeping watch on.

**[p0003]**

Summary of the invention Therefore, the objective of the invention is to improve the magnetic grab bucket of the type of introducing the front, thereby when keeping aforementioned operation principle, realize independently state recognition, whether workpiece for confirmation is present on the magnetic grab bucket. According to the present invention, above-mentioned purpose can realize through the characteristic in the claim 1.Be equipped with and be arranged on the housing or in the housing, be used to detect the distolateral of housing and keeping workpiece or do not having workpiece because at least one checkout gear is a magnetic grab bucket, therefore, can obtain such benefit, realize in this magnetic grab bucket that promptly valid function keeps watch on.Therefore, process stability can improve.Because at least one checkout gear is located on the magnetic grab bucket or in the magnetic grab bucket, whether therefore can discern magnetisable workpiece grasped by magnetic grab bucket and keep and this workpiece whether carry or the carrying motion in lose.Therefore, a kind of magnetic grab bucket is provided, it allows identification to be handled upside down the state of workpiece.

**[p0004]**

According to useful embodiment of the present invention, make said at least one checkout gear confirm the operating pressure of working fluid based on effective or invalid operation position.As the result of the configuration of checkout gear, changing effectively or in the action of invalid operation position, checkout gear is confirmed the relevant work pressure or the change of pressure of working fluid, aforementioned method of work and aforementioned magnetic grab bucket structure can remain.The variation (preferably being obtained in the invalid operation position by checkout gear) of operating pressure of keeping that obtained and constant (preferably being obtained in the valid function position by checkout gear) or operating pressure is assessed so that detect and keep watch on the work at present state.Therefore the configuration of the Handling device with one or more magnetic grab bucket that the front is described and structure also can remain. According to useful embodiment of the present invention, for magnetic piston is sent to the operating position, negative pressure (underpressure) or vacuum are applied in as operating pressure, and checkout gear is kept the operating pressure that is applied in the process that grasps and carry workpiece.Therefore, by means of the operating pressure of the elevating movement that is used to drive magnetic piston, when reaching operating position or afterwards, can realize the detection whether ferromagnetic workpiece exists with the actual work at present fluid that reaches operating position.When superpressure (overpres

**[p0004]**

sure) also is like this when being provided as operating pressure.

**[p0005]**

According to further useful embodiment of the present invention, for magnetic piston is sent to the operating position, negative pressure or vacuum are applied in as operating pressure, and do not exist, discharge or putting down that this operating pressure reduces under the situation of workpiece.Therefore, by means of the operating pressure of the working fluid that is used to drive magnetic piston, can further realize the identification of state recognition and state variation again.Also be like this when superpressure is provided as operating pressure. According to useful embodiment of the present invention, checkout gear is arranged in the housing of magnetic grab bucket, and is provided in the enclosure space that is formed between magnetic piston and the housing.Because the housing of magnetic grab bucket has constant overall dimensions, therefore the configuration that therefore has the Handling device of a plurality of magnetic grab buckets can remain, and these magnetic grab buckets have aforementioned arrangements or modularization dimensional configurations.In having the Handling device of a plurality of magnetic grab buckets for example, in each magnetic grab bucket, have at least one checkout gear, sum that can be through inquiring about effective magnetic grab bucket and effectively the position of magnetic grab bucket keep watch on required minimum confining force.In case the checkout gear that is arranged on the minimum number of suitable configuration (particularly being evenly distributed in the workpiece top) sends out the suitable signal of relevant re

**[p0005]**

levant work pressure, the minimum confining force required by the magnetic grab bucket conveying workpieces promptly is limited at usable levels.

**[p0006]**

Further useful embodiment of the present invention makes said at least one checkout gear be integrated in movably in the magnetic piston.Therefore, only magnetic piston by the actual operating position that is sent to when carrying out the carrying program, checkout gear just is used. According to further useful embodiment of the present invention, checkout gear is configured to mangneto dynamic formula valve gear, the passage of its control in magnetic piston, and said passage is supplied between the operating chamber of another operating pressure in the piston chamber that is supplied working fluid and opposed.This make this magnetic grab bucket can by the operating pressure of working fluid for example vacuum or compressed air activate, the confining force of workpiece magnetic force capable of using realizes, similarly, the startup of checkout gear realizes by magnetic force, no matter and the operating pressure of working fluid how. Checkout gear is constructed to mangneto dynamic formula valve gear valuably, and it comprises valve supporter with valve seat and the application valve body with valve face, and said application valve body is arranged to and can in said valve supporter, moves.In the valid function position of valve gear, valve face is supported on the valve seat and closes operating chamber and the passage between the piston chamber in the magnetic grab bucket housing.Therefore can obtain the valve gear of actuating easily, it can be sent to based on elevating movement effectively and the invalid operation position.

**[p0007]**

According to the further useful embodiment of valve gear, make application valve body on its end, have at least one permanent magnet facing to the housing base.When workpiece is grasped and magnetic piston when being positioned at its operating position, application valve body therefore can be by means of the magnetic force that produces closing passage.Therefore negative pressure that is applied in the operating pressure in the piston chamber, particularly piston chamber or the vacuum that is applied keep constant.This state is preferably detected and assessment by at least one sensor.Therefore the safety criterion in the handling process can be satisfied.Workpiece in the course of conveying discharges the state variation that causes and can identify by means of the variation of job step, thereby the subsequent step that can begin to suit after this for example stops the conveying campaign of Handling device at once. According to further useful embodiment of the present invention, make the application valve body of checkout gear remain on the invalid operation position, and raise with respect to valve seat by energy-storage travelling wave tube.This invalid operation position makes that as long as in the zone of checkout gear, there is not workpiece to be attached to the housing end face, vacuum or negative pressure just needn't be kept.The energy-storage travelling wave tube preferable configuration becomes spiral or compression spring, has spring force, and this spring force acts on the magnetic confining force on the application valve body by said at least one permanent

**[p0007]**

magnet when being attached to the housing end face at workpiece.

**[p0008]**

According to further useful embodiment of the present invention, at least one leader is arranged between application valve body and the valve supporter.This makes, can in the valve supporter, directly guide application valve body.Therefore, can implementation structure simple and do not have and be contained in obliquely in the valve supporter. In addition, between the permanent magnet on valve seat and the application valve body, be provided with leader, said leader has at least one channel shaped recess and forms the part of the said passage between operating chamber and the piston chamber.This configuration can produce a kind of neat and compact configuration, and it has a spot of parts.Therefore can realize trouble-free operation. In addition, preferably, when magnetic piston be sent to operating position and workpiece be magnetized with the end face that workpiece is positioned at housing on the time, application valve body can be transferred into the valid function position under the magneticaction of its at least one permanent magnet.Application valve body particularly is arranged on the valve face on the application valve body, therefore be supported on the valve seat and closure piston chamber and operating chamber between passage.There is not outside air to flow into as subsequent flows through the operating chamber in the housing (this operating chamber is preferably connecting environment); The operating pressure that obtains in the operating chamber can not influence the operating pressure in the piston chamber, and the operating pressure that being used for of

**[p0008]**

being applied in the piston chamber is sent to magnetic piston its operating position can be kept.Can identify workpiece like this and be present in the distolateral state of housing base.

**[p0009]**

In addition, preferably, when valve gear is closed, the end face contact housing base facing to the housing base of permanent magnet.Therefore maximum confining force can be applied on the application valve body so that close valve seat. Further useful embodiment according to valve gear is provided with lid, be used to limit and the adjusting control valve body open stroke, said lid preferably is fastened on the valve supporter and preferably comprises flow controller. According to the further useful embodiment of checkout gear, make said valve gear, comprise valve supporter, application valve body, intermediate energy storage element and cover, can be used as prefabricated unit and insert in the housing or in the magnetic piston.Therefore can realize the modular organization of magnetic grab bucket, thereby depend on certain applications, various unit can be provided, and the application valve body in each unit has the flow controller that the different permanent magnet of intensity and/or lid have different size.

**[p0010]**

According to further useful embodiment of the present invention, between checkout gear and relevant connector, be formed with connecting line, be used for supply and discharging working fluid.Be arranged under the situation in the magnetic grab bucket at a plurality of checkout gears, make that each checkout gear can be by independent startup. According to further useful embodiment of the present invention, making can keeping or the variation of operating pressure by at least one sensor testing pressure.Said at least one sensor preferably is arranged on the valve module away from corresponding magnetic grab bucket.Said valve module is connecting a plurality of pressure lines (said pressure line leads to the air pressure connector of magnetic grab bucket) and is being connected to the holding wire of control and apparatus for evaluating.Each pressure line is by sensor query and keep watch on work at present pressure.This sensor particularly is configured to pressure sensor, allows to assess fast and easily this extraneous information.

**[p0011]**

According to further useful embodiment of the present invention, a plurality of checkout gears are arranged on the housing or in the housing, detect to allow to provide the segmentation to the end face of housing.Therefore, each distolateral zone of housing can be kept watch on, and other zone is not then kept watch on.This segmentation is kept watch on can obtain the extraneous information of relevant workpiece with respect to the position of corresponding magnetic grab bucket. Description of drawings Describe and explain the present invention and further advantage and improvement thereof below with reference to accompanying drawings in detail.According to the present invention, the various characteristics that disclose in specification and the accompanying drawing can itself adopt separately or with the mode of combination in any.In the accompanying drawings: Fig. 1 shows a kind of schematic side elevation of magnetic grab bucket; Fig. 2 shows the complete cutaway view of magnetic grab bucket that the line I-I in Fig. 1 is done;

**[p0012]**

Fig. 3 shows the magnetic grab bucket schematic cross sectional views that the line II-II in Fig. 1 is done; Fig. 4 a shows the schematic amplification view of the magnetic piston of magnetic grab bucket, and wherein the integrated form checkout gear is positioned at the valid function position; Fig. 4 b shows the schematic amplification view of the magnetic piston of magnetic grab bucket, and wherein the integrated form checkout gear is positioned at the invalid operation position. The specific embodiment Fig. 1 shows the schematic side elevation of magnetic grab bucket 11, and magnetic grab bucket has neck 12, and this neck has fastener 14, is used for magnetic grab bucket is fastened on robots arm or Handling device.At opposite opposite side, on cup-shaped housing 16, be provided with housing base 17, this housing base is for example through being threaded on the housing 16.This housing base 17 has end face 18, and this end face is by the workpiece that is grasped 19 butts, and this workpiece is represented as for example ferromagnetic plate.

**[p0013]**

Shown that in Fig. 2 the line I-I in Fig. 1 is the cutaway view that magnetic grab bucket 11 is done.In housing 16, magnetic piston 21 is directed, thereby can move up and down.Magnetic piston 21 comprises lead ring 22, in lead ring, is arranging seal 23, the sealing part will be present in the operating chamber 24 of magnetic piston 21 tops and be present in magnetic piston 21 and housing base 17 between piston chamber opened in 26 minutes.The volume of these two chambers 24,26 is defined as and the position of magnetic piston 21 in housing 16 relation of being inversely proportional to.Operating chamber 24 is connecting environment through through hole 27.As an example, be used for protecting the not contaminated screen cloth 28 of operating chamber 24 can be arranged on through hole 27.Piston chamber 26 is connecting connector 31, and particularly the air pressure connector is connecting pressure line 32 on this connector, and this pressure line leads to the valve module 33 with a plurality of control valves 30.Through actuation control valve 30, each pressure line 32 is supplied operating pressure through valve module 33.Each pressure line 32 preferably is equipped with sensors 35, is used for the operating pressure of monitor pressures pipeline 32.Sensor 35 detected signals are sent to assessment unit, are used for assessing and control magnetic grab bucket 11.

**[p0014]**

The line II-II that Fig. 3 shows in Fig. 1 is the cutaway view that magnetic grab bucket 11 is done.Magnetic piston 21 is at its distolateral at least one permanent magnet 34 that holding facing to housing base 17.Preferably, a plurality of permanent magnets 34 dispose with the form of independent fan-shaped section respectively adjacent to each other. For magnetic piston 21 is positioned at position shown in Figure 2, promptly the operating position 36, and operating pressure, particularly negative pressure or vacuum are applied in the piston chamber 26 through connector 31.Magnetic piston 21 seals with respect to housing 16 through seal 23, thereby piston chamber 26 (preferably connecting pressure line 32) forms enclosure space.As the result of the operating pressure that is applied, magnetic piston 21 is sent to lower position.Here, permanent magnet 34 preferably remains on the setpoint distance of separating one section weak point with the housing base, for example through shim elements 35, particularly gasket ring.Perhaps, said at least one permanent magnet 34 can directly be supported on the housing base 17.As workpiece 19 magnetized results, the magnetic confining force acts between said at least one permanent magnet 31 and the ferromagnetic workpiece 19, and workpiece 19 only has this magnetic confining force to keep and with respect to housing base 17 location.At this allocation position of magnetic piston 21, in operating chamber 24, obtain another operating pressure, particularly ambient pressure.In order to put down workpiece 19, negative pressure or vacuum redu

**[p0014]**

ce, and perhaps pressure pulse is introduced into piston chamber 26, thereby magnetic piston 19 is compelled to get into the position that raises with respect to housing base 17 and is arrived rest position 37 (being represented by dotted lines).Therefore this motion of magnetic piston 21 occurs in the piston chamber 26 of sealing, and the compressed air stream and the vacuum pneumatic of big volume promptly need be provided.

**[p0015]**

According to embodiment shown in Figure 2, magnetic grab bucket 11 has checkout gear 41, and for instance, this checkout gear is integrated in the magnetic piston 21.A simple embodiment of magnetic grab bucket 11 is provided with a checkout gear 41.Perhaps, a plurality of checkout gears 41 can be provided, and in this case, according to the quantity of checkout gear 41, housing 16 has partition valuably, is arranged in the corresponding enclosure space with the magnetic piston that will have at least one checkout gear 41.This checkout gear 41 shown in Fig. 2 schematically is shown enlarged in the different operation position in Fig. 4 a and 4b, and will be with reference to Fig. 4 a and 4b illustrated in detail. According to Fig. 4 a, be positioned at valid function position (activeoperating position) 42 with workpiece 19 relative checkout gears 41.On the other hand, according to Fig. 4 b, checkout gear 41 is shown as and is in invalid operation position (inactive operating position) 43.Checkout gear 41 comprises mangneto dynamic formula valve gear.This valve gear comprises valve supporter 45, is placed in application valve body 46 in the valve supporter, acts on the energy-storage travelling wave tube 47 between valve supporter 45 and the application valve body 46 and cover 48 with the moving mode of axially-displaceable.Energy-storage travelling wave tube 47 is supported on the shoulder 49 of valve supporter 45, and makes application valve body 46 remain essentially in invalid operation position 43, is supported at distolateral 51 of this application valve body 46 and cov

**[p0015]**

ers on 48.In this invalid operation position 43, the valve face 52 of application valve body 46 raises with respect to the valve seat 53 of valve supporter 45.As a result, the valve supporter is opened.

**[p0016]**

The working fluid that is present in the operating chamber 24 can flow through the flow controller 56 that covers in 48, and flows through pipe tunnel 57, and from then on flows through the horizontal pipeline 58 of branch to valve face 52, flows to piston chamber 26 through at least one the channel shaped recess 59 in the leader 61 again.Leader 61 is constructed to the collar 62 for example and acts on the shell face 63 of valve supporter 45.Preferably, additional pilot part 61 be arranged on cover 48 and valve seat 53 between so that application valve body 46 has obliquely do not installed.Energy-storage travelling wave tube 47 (preferable configuration is helical spring, compression spring or flexible member, so that application valve body 46 is placed invalid operation position 43) can be supported on the collar 62. On the end of application valve body 46, be provided with for example permanent magnet 66 facing to housing base 17.Permanent magnet 66 facing to the end face 67 of housing base and housing base 17 itself between be provided with the gap, the size in this gap is equal to or less than to application valve body 46 being sent to the stroke of the elevating movement of being carried out valid function position 42.

**[p0017]**

Piston chamber 26 is connecting connector 31 through the connecting line 69 that schematically shows.This connecting line 69 can be for example forms through the gap between two permanent magnets adjacent one another are 34 or slit (schematically showing as utilizing line 71 among Fig. 3) and the pipe section 70 that leads to connector 31. Utilize checkout gear 41 identifications and supervision to realize in the following manner by the workpiece 19 that magnetic grab bucket 11 grasps. Magnetic grab bucket 11 is located with respect to workpiece to be carried 19.Meanwhile, negative pressure or vacuum are applied in the piston chamber 26, thereby magnetic piston 21 is sent to operating position 36.Next, workpiece 19 is magnetized and is remained on the end face 18 of housing by the magnetic confining force.Meanwhile, the permanent magnet 66 of the application valve body 46 of checkout gear 41 receives magnetic action.The magnetic force that is produced is greater than the reaction force of energy-storage travelling wave tube 47, the result, and checkout gear 41, particularly application valve body 46, are sent to valid function position 42.Valve face rests on the valve seat 53 for 52 this moments.Therefore the operating pressure that is applied in the piston chamber 26, particularly negative pressure or vacuum are maintained.Through detecting the sensor 35 of the operating pressure of work at present fluid in the piston chamber 26, can confirm not have pressure drop, workpiece 19 is attached to grasping on the end face 18 of housing 16 and by magnetic grab bucket 11.Because

**[p0017]**

the just local end face 18 that abuts against housing 16 of workpiece 19, therefore, second checkout gear 41 is in invalid operation position 23.Passage between operating chamber 24 and the piston chamber 26 (this passage is opened when checkout gear 41 is in the invalid operation position) changes operating pressure, negative pressure or the vacuum of the working fluid that is applied in the piston chamber 26; This is because ambient pressure can and self flow through the vertical and horizontal pipeline 57,58 of passage, application valve body 46 and the valve seat of opening 53 through 27 acquisitions of the through hole in the operating chamber 24, thereby gets into piston chamber 26.Can judge from this point does not have workpiece 19 to be attached to the end face 18 of housing 16 or to bear against this at this.

**[p0018]**

Utilize in the process of workpiece 19 in magnetic grab bucket 11 conveyings; If such situation; Be that workpiece 19 end faces 18 from housing 16 own come off; Then checkout gear 41 is sent to invalid operation position 43 by energy-storage travelling wave tube 47 from valid function position 42, and sensor 35 then identifies the operating pressure of the working fluid in the piston chamber 26 and no longer keeps, but changes.This means that workpiece 19 lost. Therefore, this checkout gear 41 can be realized state recognition through the operating pressure of follow-up work fluid, is to be received and to carry to confirm workpiece 19, still is not received or in course of conveying, loses.

## Classifications

- B66C1/04
- B23Q3/15
- B66C1/04
- H01F7/02
- H01F7/0252
- H01F7/04

## Cited patent documents

- [CN-1127724-A](https://patents.google.com/patent/CN1127724A/en) — SEA
- [DE-19951703-A1](https://patents.google.com/patent/DE19951703A1/en) — SEA
- [GB-2000870-A](https://patents.google.com/patent/GB2000870A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
