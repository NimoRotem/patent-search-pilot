# 11. Magnetic gripper for mounting on e.g. tool holder of handling device utilized in industrial robot, has spacer axially displaced relative to holding magnet between spacing layer for releasing workpiece and grab layer for holding workpiece

- **Archive rank:** 11 of 50
- **Publication:** [DE-102010040642-A1](https://patents.google.com/patent/DE102010040642A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/045755874/publication/DE102010040642A1?q=pn%3DDE102010040642A1)
- **Publication date:** 2012-03-15
- **Filing date:** 2010-09-13
- **Earliest priority:** 2010-09-13
- **Family:** 45755874
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** SCHUNK GMBH & CO KG

## Abstract

The gripper (10) has a holding magnet (34) arranged at an axially displaceable input piston (26) for attracting a workpiece (16) to be gripped. An axially displaceable spacer (18) i.e. hollow piston (19), is engaged with the workpiece and axially displaced relative to the magnet between a spacing layer for releasing the workpiece and a grab layer for holding the workpiece. The spacer and the input piston are axially displaced relative to a gripper base (12) that includes a mounting portion (14) for arrangement at a tool receiver, a tool holder or a machine spindle of a handling device.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-102010040642-A1/000.png)

![Sketch 1 for DE-102010040642-A1](https://nimo.iptorch.com/refdrawing/DE-102010040642-A1/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-102010040642-A1/001.png)

![Sketch 2 for DE-102010040642-A1](https://nimo.iptorch.com/refdrawing/DE-102010040642-A1/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/DE-102010040642-A1/002.png)

![Sketch 3 for DE-102010040642-A1](https://nimo.iptorch.com/refdrawing/DE-102010040642-A1/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/DE-102010040642-A1/003.png)

![Sketch 4 for DE-102010040642-A1](https://nimo.iptorch.com/refdrawing/DE-102010040642-A1/003.png)

## Claims

### Claim 1 (independent)

Claims (13)

### Claim 2 (independent)

Translated from German

### Claim 3 (independent)

Magnetgreifer (10) fÃ¼r eine Handhabungsvorrichtung

### Claim 4 (independent)

â mit einem Haltemagneten (34) zum Anziehen eines zu greifenden WerkstÃ¼ckes (16) zum Magnetgreifer (10),

### Claim 5 (independent)

â mit einem axial verlagerbaren Abstandshalter (18) zur Anlage an das WerkstÃ¼ck (16),

### Claim 6 (independent)

â und mit einem axial verlagerbaren Ausgleichskolben 26), an welchem der Haltemagnet (34) angeordnet ist,

### Claim 7 (independent)

â wobei der Abstandshalter (18) relativ zum Haltemagneten (34) zwischen einer Abstandslage zum Loslassen des WerkstÃ¼cks (16) und einer Greiflage zum Halten des WerkstÃ¼ckes (16) axial verlagerbar ist.Magnetic gripper ( 10 ) for a handling device - with a holding magnet ( 34 ) for attracting a workpiece to be gripped ( 16 ) to the magnetic gripper ( 10 ), - with an axially displaceable spacer ( 18 ) for contact with the workpiece ( 16 ), - and with an axially displaceable balance piston 26 ), on which the holding magnet ( 34 ), - wherein the spacer ( 18 ) relative to the holding magnet ( 34 ) between a distance position for releasing the workpiece ( 16 ) and a gripping position for holding the workpiece ( 16 ) is axially displaceable.

### Claim 8

Greifer (10) nach Anspruch 1, dadurch gekennzeichnet, dass der Abstandshalter (18) einen Mitnahmeabschnitt (56) fÃ¼r einen an dem Ausgleichskolben (26) vorgesehenen Mitnahmeanschlag und/oder fÃ¼r den Haltemagneten (34) aufweist, wobei der Mitnahmeanschlag und/oder der Haltemagnet (34) an den Mitnahmeabschnitt (56) anliegt, wenn sich der Abstandshalter (18) in der Greiflage befindet.Gripper ( 10 ) according to claim 1, characterized in that the spacer ( 18 ) a driving section ( 56 ) for one on the balance piston ( 26 ) provided driving stop and / or for the holding magnet ( 34 ), wherein the driving stop and / or the holding magnet ( 34 ) to the driving section ( 56 ) is applied when the spacer ( 18 ) is in the gripping position.

### Claim 9

Greifer (10) nach einem der vorhergehenden AnsprÃ¼che, dadurch gekennzeichnet, dass ein Greifergrundteil (12) vorgesehen ist, wobei der Abstandshalter (18) und der Ausgleichskolben (26) relativ zum Greifergrundteil (12) axial verlagerbar sind.Gripper ( 10 ) according to one of the preceding claims, characterized in that a gripper base ( 12 ) is provided, wherein the spacer ( 18 ) and the balance piston ( 26 ) relative to the gripper base ( 12 ) are axially displaceable.

### Claim 10

Greifer (10) nach dem vorhergehenden Anspruch, dadurch gekennzeichnet, dass das Greifergrundteil (12) einen Montageabschnitt (14) zur Anordnung an einer Werkzeugaufnahme oder einem Werkzeughalter oder einer Maschinenspindel einer Handhabungsvorrichtung aufweist, wobei der Montageabschnitt (14) an einem dem Abstandshalter (18) abgewandten Bereich des Greifergrundteils (12) angeordnet ist.Gripper ( 10 ) according to the preceding claim, characterized in that the gripper base ( 12 ) a mounting section ( 14 ) for placement on a tool holder or a tool holder or a machine spindle of a handling device, wherein the mounting portion ( 14 ) on a spacer ( 18 ) facing away from the gripper base ( 12 ) is arranged.

### Claim 11

Greifer (10) nach einem der vorhergehenden AnsprÃ¼che, dadurch gekennzeichnet, das der Abstandshalter (18) einen Anlageabschnitt (24) zur Anlage des zu greifenden WerkstÃ¼ckes (16) aufweist, wobei der Anlageabschnitt (24) in der Greiflage an den Haltemagnet (34) herangefÃ¼hrt, in der Abstandslage vom Haltemagnet (34) beabstandet ist.Gripper ( 10 ) according to one of the preceding claims, characterized in that the spacer ( 18 ) a plant section ( 24 ) for conditioning the workpiece to be gripped ( 16 ), wherein the abutment section ( 24 ) in the gripping position to the holding magnet ( 34 ), in the distance of the holding magnet ( 34 ) is spaced.

### Claim 12

Greifer (10) nach einem der vorhergehenden AnsprÃ¼che, dadurch gekennzeichnet, dass der Ausgleichskolben (26) einen Haltekopf (28) und einen vom Haltekopf (28) abgewandten FÃ¼hrungsabschnitt (30) aufweist, wobei der Haltekopf (28) dem Abstandshalter (18) zugewandt ist und der Haltemagnet (34) an dem Haltekopf (28) angeordnet ist.Gripper ( 10 ) according to one of the preceding claims, characterized in that the Balance piston ( 26 ) a holding head ( 28 ) and one of the holding head ( 28 ) facing away from the guide section ( 30 ), wherein the holding head ( 28 ) the spacer ( 18 ) and the holding magnet ( 34 ) on the holding head ( 28 ) is arranged.

### Claim 13

Greifer (10) nach einem der vorhergehenden AnsprÃ¼che, dadurch gekennzeichnet, dass der Abstandshalter (18) einen Kolbenanschnitt (20) aufweist, welcher einen Druckraum (50) begrenzt, der zur Bewegung des Abstandshalters (18) in die Abstandslage mit einem Druckmittel druckbeaufschlagbar, insbesondere mit Druckluft oder KÃ¼hlmittel druckbeaufschlagbar ist.Gripper ( 10 ) according to one of the preceding claims, characterized in that the spacer ( 18 ) a piston gate ( 20 ), which has a pressure chamber ( 50 ), which is used to move the spacer ( 18 ) can be pressurized in the distance position with a pressure medium, in particular with compressed air or coolant can be pressurized.

### Claim 14

Greifer (10) nach dem vorhergehenden Anspruch, dadurch gekennzeichnet, dass der Abstandshalter (18) einen oder mehrere EntlastungskanÃ¤le (52) aufweist, durch welche Druckmittel aus dem Druckraum (50), insbesondere gedrosselt, entweichen kann.Gripper ( 10 ) according to the preceding claim, characterized in that the spacer ( 18 ) one or more discharge channels ( 52 ), by which pressure medium from the pressure chamber ( 50 ), in particular throttled, can escape.

### Claim 15

Greifer (10) nach dem vorhergehenden Anspruch, dadurch gekennzeichnet, dass der Abstandshalter (18) einen Anlageabschnitt (24) zur Anlage des zu greifenden WerkstÃ¼ckes (16) aufweist, und der Abstandshalter (18) im Bereich des Anlageabschnitts (24) eine oder mehrere AustrittsÃ¶ffnungen (54) aufweist, in welche die EntlastungskanÃ¤le (52) mÃ¼nden.Gripper ( 10 ) according to the preceding claim, characterized in that the spacer ( 18 ) a plant section ( 24 ) for conditioning the workpiece to be gripped ( 16 ), and the spacer ( 18 ) in the area of the plant section ( 24 ) one or more outlet openings ( 54 ) into which the discharge channels ( 52 ).

### Claim 16

Greifer (10) nach einem der vorhergehenden AnsprÃ¼che, dadurch gekennzeichnet, dass der Abstandshalter (18) als Hohlkolben (19) ausgebildet ist und der Ausgleichskolben (26) wenigstens abschnittsweise koaxial in dem Hohlkolben (19) gefÃ¼hrt ist.Gripper ( 10 ) according to one of the preceding claims, characterized in that the spacer ( 18 ) as a hollow piston ( 19 ) is formed and the balance piston ( 26 ) at least in sections coaxially in the hollow piston ( 19 ) is guided.

### Claim 17

Greifer (10) nach dem vorhergehenden Anspruch, dadurch gekennzeichnet, dass der Abstandshalter (18) als einseitig offener Hohlkolben (19) mit einem dem Ausgleichskolben (26) abgewandten Bodenabschnitt (22) ausgebildet ist, wobei der Haltemagnet (34) in der Greiflage an dem Bodenabschnitt (22) anliegt.Gripper ( 10 ) according to the preceding claim, characterized in that the spacer ( 18 ) as a hollow piston open on one side ( 19 ) with a balance piston ( 26 ) facing away from the floor section ( 22 ), wherein the holding magnet ( 34 ) in the gripping position on the bottom section ( 22 ) is present.

### Claim 18

Greifer (10) nach einem der vorhergehenden AnsprÃ¼che, dadurch gekennzeichnet, dass ein RÃ¼ckstellfedermittel (38) zur Vorspannung des Abstandshalters (18) in der Abstandslage gegen Verlagerung in die Greiflage vorgesehen ist.Gripper ( 10 ) according to one of the preceding claims, characterized in that a return spring means ( 38 ) for biasing the spacer ( 18 ) is provided in the distance position against displacement into the gripping position.

### Claim 19

Greifer (10) nach einem der vorhergehenden AnsprÃ¼che, dadurch gekennzeichnet, dass ein Ausgleichsfedermittel (38) zur Vorspannung des Ausgleichskolbens (26) gegen eine Verlagerung in eine Ausgleichslage vorgesehen ist.Gripper ( 10 ) according to one of the preceding claims, characterized in that a compensating spring means ( 38 ) for biasing the balance piston ( 26 ) is provided against a shift into a balancing position.

## Full description

**[p0001]**

PERFORMING OPERATIONS; TRANSPORTINGHAND TOOLS; PORTABLE POWER-DRIVEN TOOLS; MANIPULATORSMANIPULATORS; CHAMBERS PROVIDED WITH MANIPULATION DEVICESGripping heads and other end effectorsGripping heads and other end effectors with vacuum or magnetic holding meansGripping heads and other end effectors with vacuum or magnetic holding means with magnetic holding meansPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating electrostatic or magnetic grippers Description Translated from German Die Erfindung betrifft einen Magnetgreifer, beispielsweise fÃ¼r eine Hanhabungsvorrichtung, insbesondere zur Montage an einem Werkzeughalter.The invention relates to a magnetic gripper, for example for a Hanhabungsvorrichtung, in particular for mounting on a tool holder.

**[p0002]**

Derartige Magnetgreifer finden Verwendung zur Aufnahme eines (zumindest abschnittsweise magnetischen) WerkstÃ¼ckes mittels einer Handhabungsvorrichtung, beispielsweise einem Industrieroboter.Such magnetic grippers are used for receiving a (at least partially magnetic) workpiece by means of a handling device, such as an industrial robot. Die genannten Handhabungsvorrichtungen weisen, meist standardisierte, Werkzeughalter oder Werkzeugaufnahmen oder Maschinenspindeln auf, an welche die Handhabungswerkzeuge angeordnet werden kÃ¶nnen. Hierbei kann es erwÃ¼nscht sein, einen Magnetgreifer direkt an einen Werkzeughalter/Werkzeugaufnahme/Maschinenspindel einer solchen Handhabungsvorrichtung zu montieren.The aforementioned handling devices have, usually standardized, tool holders or tool holders or machine spindles to which the handling tools can be arranged. In this case, it may be desirable to mount a magnetic gripper directly on a tool holder / tool holder / machine spindle of such a handling device.

**[p0003]**

Dabei ist jedoch zu beachten, dass Werkzeugaufnahmen/Werkzeughalter/Maschinenspindeln meist steif und nicht federnd ausgefÃ¼hrt sind. Wird ein Magnetgreifer direkt (ohne ein axial ausgleichendes Verbindungselement) an die Werkzeugaufnahme/Werkzeughalter/Maschinenspindel einer Handhabungsvorrichtung montiert, besteht somit die Gefahr, dass die Werkzeugaufnahme/Werkzeughalter/Maschinenspindel und/oder die WerkstÃ¼ckoberflÃ¤che beschÃ¤digt werden, wenn die tatsÃ¤chliche Position des zu greifenden WerkstÃ¼cks nicht genau bekannt ist und der Magnetgreifer zu nahe an die WerkstÃ¼ckoberflÃ¤che herangefÃ¼hrt wird.However, it should be noted that tool holders / tool holders / machine spindles are usually designed to be stiff and not resilient. If a magnetic gripper is mounted directly (without an axially compensating connecting element) to the tool holder / tool holder / machine spindle of a handling device, there is a risk that the tool holder / tool holder / machine spindle and / or the workpiece surface will be damaged if the actual position of the workpiece to be gripped is not known exactly and the magnetic gripper is brought too close to the workpiece surface.

**[p0004]**

Aufgrund von Fertigungstoleranzen oder aufgrund von beispielsweise bei BearbeitungsvorgÃ¤ngen auf dem WerkstÃ¼ck verbleibenden Materialreste (beispielsweise MetallspÃ¤ne) ergeben sich jedoch oftmals Unsicherheiten hinsichtlich der Position des zu greifenden WerkstÃ¼ckes beziehungsweise seiner OberflÃ¤che. Vor diesem Hintergrund ist eine Greifeinrichtung mit der MÃ¶glichkeit eines axialen Ausgleiches bezÃ¼glich der Greifrichtung erwÃ¼nscht.However, due to manufacturing tolerances or due to, for example, during machining operations on the workpiece remaining material residues (for example, metal shavings) often arise uncertainties regarding the position of the workpiece to be gripped or its surface. Against this background, a gripping device with the possibility of an axial compensation with respect to the gripping direction is desired. Der Erfindung liegt die Aufgabe zugrunde, einen Magnetgreifer fÃ¼r eine Handhabungsvorrichtung bereitzustellen, mit dem eine verbesserte und â fÃ¼r die Handhabungsvorrichtung und/oder das zu greifende WerkstÃ¼ck â schonende Handhabung mÃ¶glich ist.The invention has for its object to provide a magnetic gripper for a handling device, with an improved and - for the handling device and / or the workpiece to be gripped - gentle handling is possible.

**[p0005]**

Diese Aufgabe wird durch einen Magnetgreifer mit den Merkmalen des Anspruchs 1 gelÃ¶st. Dieser Magnetgreifer fÃ¼r eine Handhabungsvorrichtung, insbesondere zur Montage an einen Werkzeughalter, weist einen Haltemagneten zum Anziehen eines zu greifenden WerkstÃ¼ckes in Richtung zum Magnetgreifer auf, sowie einen axial verlagerbaren Abstandshalter zur Anlage an das WerkstÃ¼ck, insbesondere wÃ¤hrend des Greifvorganges, sowie auÃerdem einen axial verlagerbaren Ausgleichskolben, an welchen der Haltemagnet angeordnet ist. Dabei ist vorgesehen, dass der Abstandshalter relativ zum Haltemagneten zwischen einer Abstandslage zum Loslassen des WerkstÃ¼ckes und einer Greiflage zum Halten des WerkstÃ¼ckes axial verlagerbar ist.This object is achieved by a magnetic gripper with the features of claim 1. This magnetic gripper for a handling device, in particular for mounting on a tool holder, has a holding magnet for attracting a workpiece to be gripped in the direction of the magnetic gripper, as well as an axially displaceable spacer for contact with the workpiece, in particular during the gripping process, and also an axially displaceable compensating piston to which the holding magnet is arranged. It is provided that the spacer is axially displaceable relative to the holding magnet between a distance position for releasing the workpiece and a gripping position for holding the workpiece.

**[p0006]**

Der Magnetgreifer dient zur Aufnahme von WerkstÃ¼cken in einer Greifrichtung. Entlang der Greifrichtung ist der Abstandshalter und der Ausgleichskolben axial verlagerbar.The magnetic gripper serves to receive workpieces in a gripping direction. Along the gripping direction of the spacer and the balance piston is axially displaceable. Hinsichtlich der axialen Verlagerung des Abstandshalters sind zwei axiale Positionen relativ zum Haltemagneten definiert: Eine Greiflage zum Halten des WerkstÃ¼ckes und eine Abstandslage zum Loslassen des WerkstÃ¼ckes. Der Abstandshalter ist jedoch weiter axial verlagerbar, auch wenn er sich relativ zum Haltemagneten in der Greiflage befindet. Der Abstandshalter ist ausgehend von der Abstandslage zunÃ¤chst zu einer axialen Position axial verlagerbar, in der er sich relativ zum Haltemagneten in der Greiflage befindet, jedoch auch Ã¼ber diese Position hinaus noch weiter axial um einen axialen Ausgleichsweg verlagerbar, wobei die Greiflage beibehalten wird.With regard to the axial displacement of the spacer, two axial positions relative to the holding magnet are defined:

**[p0007]**

A gripping position for holding the workpiece and a distance position for releasing the workpiece. However, the spacer is further axially displaceable, even if it is located relative to the holding magnet in the gripping position. The spacer is starting from the distance position initially axially displaceable to an axial position in which it is relative to the holding magnet in the gripping position, but even beyond this position even further axially displaceable about an axial compensation path, wherein the gripping position is maintained. Dadurch, dass der Haltemagnet an dem axial verlagerbaren Ausgleichskolben angeordnet ist, kann die Greiflage â welche durch eine bestimmte Position des Abstandshalters relativ zum Haltemagneten definiert ist â fÃ¼r den Abstandshalter an einer variablen axialen Position bereitgestellt werden.Characterized in that the holding magnet is arranged on the axially displaceable balance piston, the gripping position - which is defined by a certain position of the spacer relative to the holding magnet - can be provided for the spacer at a variable axial position.

**[p0008]**

Bei einem Greifvorgang wird der Magnetgreifer zunÃ¤chst mit in Abstandslage ausgefahrenem Abstandshalter auf das WerkstÃ¼ck aufgesetzt. Dadurch wird eine Vorfixierung erzielt, welche beispielsweise ein Verrutschen des WerkstÃ¼ckes verhindert. Zum Greifen wird der Abstandshalter in die Greiflage eingefahren, insbesondere dadurch, dass der Magnetgreifer weiter in Richtung auf das WerkstÃ¼ck zu bewegt wird. Die Bewegung des Magnetgreifers wird beispielsweise mit einer Steuereinrichtung einer Handhabungsvorrichtung, an welcher der Magnetgreifer angeordnet ist, vorgegeben. Der Magnetgreifer wird dabei zu einer vorgegebenen Position bewegt. Nach Erreichen der Greiflage kann der Abstandshalter noch weiter axial eingeschoben werden. Dabei kann durch die Anordnung des Haltemagneten an dem axial verlagerbaren Ausgleichskolben die Greiflage des Abstandshalters relativ zum Haltemagneten beibehalten werden.During a gripping process, the magnetic gripper is first placed on the workpiece with a spacer extended in a spacer position. As a result, a prefixing is achieved which prevents, for example, slipping of the workpiece. For gripping the spacer is retracted into the gripping position, in particular by the fact that the magnetic gripper is moved toward in the direction of the workpiece. The movement of the magnetic gripper is predetermined, for example, with a control device of a handling device on which the magnetic gripper is arranged. The magnetic gripper is moved to a predetermined position. After reaching the gripping position of the spacer can be inserted even further axially. It c

**[p0008]**

an be maintained relative to the holding magnet by the arrangement of the holding magnet on the axially displaceable balance piston, the gripping position of the spacer.

**[p0009]**

Durch diese schwimmende AufhÃ¤ngung kÃ¶nnen mit dem erfindungsgemÃ¤Ãen Magnetgreifer Abweichungen der tatsÃ¤chlichen Position von der erwarteten Position des zu greifenden WerkstÃ¼ckes durch axiale Verlagerung des Ausgleichskolbens ausgeglichen werden. Insbesondere kann ein harter Anschlag auf dem WerkstÃ¼ck vermieden werden. Der Magnetgreifer kann damit unmittelbar, insbesondere ohne ein elastisches Ausgleichselement, in einer starren Werkzeugaufnahme/Werkzeughalter/Maschinenspindel eingesetzt werden, ohne dass bei Fertigungstoleranzen oder bei auf dem WerkstÃ¼ck verbleibenden Materialresten (zum Beispiel MetallspÃ¤ne) die Gefahr einer BeschÃ¤digung fÃ¼r die Werkzeugaufnahme/Maschinenspindel/Werkzeughalter oder die WerkstÃ¼ckoberflÃ¤che besteht.By means of this floating suspension, deviations of the actual position from the expected position of the workpiece to be gripped by axial displacement of the compensating piston can be achieved with the magnetic gripper according to the invention be compensated. In particular, a hard stop on the workpiece can be avoided. The magnetic gripper can thus be used directly, in particular without an elastic compensating element, in a rigid tool holder / tool holder / machine spindle without the risk of damage to the tool holder / machine spindle / tool holder in the case of manufacturing tolerances or residual material remaining on the workpiece (for example metal shavings) or the workpiece surface is made.

**[p0010]**

Eine bevorzugte Ausgestaltung ergibt sich dadurch, dass der Abstandshalter einen Mitnahmeabschnitt fÃ¼r den Ausgleichskolben, insbesondere fÃ¼r einen an dem Ausgleichskolben vorgesehenen Mitnahmeanschlag, und/oder fÃ¼r den Haltemagneten aufweist. Dabei ist vorgesehen, dass der Ausgleichskolben und/oder der Mitnahmeanschlag und/oder der Haltemagnet an den Mitnahmeabschnitt anliegt, wenn sich der Abstandshalter in der Greiflage befindet. Der Mitnahmeanschlag kann am Ausgleichskolben vorgesehen sein, insbesondere auch von dem am Ausgleichskolben angeordneten Haltemagneten gebildet sein.A preferred embodiment results from the fact that the spacer has a driving portion for the balance piston, in particular for a driving stop provided on the compensating piston, and / or for the holding magnet. It is provided that the compensating piston and / or the driving stop and / or the holding magnet is applied to the driving portion when the spacer is in the gripping position. The driving stop may be provided on the balance piston, in particular be formed by the holding piston arranged on the balance piston.

**[p0011]**

Durch das Vorsehen des Mitnahmeabschnitts wird erreicht, dass der Ausgleichskolben von dem Abstandhalter axial mitgenommen wird, wenn sich der Abstandshalter in der Greiflage befindet und axial entlang der Richtung von der Abstandslage zur Greiflage (also in Greifrichtung) weiter bewegt wird. Der Abstandshalter wird dabei unter Beibehaltung der Greiflage gemeinsam mit dem Haltemagneten um einen axialen Ausgleichsweg weiter axial verschoben.By providing the driving portion is achieved that the compensating piston is taken along by the spacer axially when the spacer is in the gripping position and axially along the direction of the distance position to the gripping position (ie in the gripping direction) is further moved. The spacer is thereby further axially displaced while maintaining the gripping position together with the holding magnet to an axial compensation path. Zur weiteren Ausgestaltung weist der Greifer ein Greifergrundteil auf, wobei der Abstandshalter und der Ausgleichskolben relativ zu dem Greifergrundteil axial, insbesondere in Greifrichtung, verlagerbar sind.For further refinement, the gripper has a gripper base part, wherein the spacer and the compensating piston can be displaced axially relative to the gripper base part, in particular in the gripping direction.

**[p0012]**

Insbesondere ist vorteilhaft, wenn das Greifergrundteil an einem dem Abstandshalter abgewandten Bereich einen Montageabschnitt, insbesondere Montageadapter, zur Anordnung an einer Werkzeugaufnahme oder einem Werkzeughalter oder einer Maschinenspindel einer Handhabungsvorrichtung aufweist.In particular, it is advantageous if the gripper base part has, on a region facing away from the spacer, a mounting section, in particular a mounting adapter, for placement on a tool holder or a tool holder or a machine spindle of a handling device. Als weitere vorteilhafte Ausgestaltung der Erfindung ist vorgesehen, dass der Abstandshalter einen Anlageabschnitt zur Anlage des zu greifenden WerkstÃ¼ckes aufweist, wobei der Analageabschnitt in der Greiflage an den Haltemagneten herangefÃ¼hrt, in der Abstandslage von dem Haltemagneten beabstandet ist. Befindet sich der Abstandshalter in der Greiflage, so befindet sich ein an dem Anlageabschnitt anliegendes WerkstÃ¼ck so nahe an dem Haltemagneten, dass dieser eine ausreichende Anziehungskraft zum Greifen auf das WerkstÃ¼ck ausÃ¼bt. Ist der Abstandshalter in die Abstandslage verlagert, so ist das WerkstÃ¼ck so weit von dem Haltemagneten beabstandet, dass die anziehende Kraft des Haltemagneten klein genug zum Loslassen ist.As a further advantageous embodiment of the invention, it is provided that the spacer has a contact portion for abutment of the workpiece to be gripped, wherein the analageabschnitt brought in the gripping position to the holding magnet, spaced in the distance position of the holding magnet. When the spacer is in the gripping

**[p0012]**

position, a workpiece resting against the abutment portion is so close to the holding magnet that it exerts sufficient attractive force to grasp the workpiece. If the spacer is displaced in the distance position, the workpiece is so far away from the holding magnet, that the attractive force of the holding magnet is small enough to let go.

**[p0013]**

Besonders bevorzugt ist auch, dass der Ausgleichskolben einen Haltekopf und einen vom Haltekopf abgewandten FÃ¼hrungsabschnitt aufweist, wobei der Haltekopf dem Abstandshalter zugewandt ist und der Haltemagnet an dem Haltekopf angeordnet ist. Der FÃ¼hrungsabschnitt ist insbesondere in einem etwaigen Greifergrundteil axial verlagerbar und dient der axialen FÃ¼hrung des Ausgleichskolbens. Insbesondere ist der Haltekopf dem genannten Mitnahmeabschnitt des Abstandshalters zugewandt und der Haltemagnet als eine Magnetscheibe ausgebildet, welche den Ausgleichskolben in Richtung des Abstandshalters axial abschlieÃend am Haltekopf angeordnet ist. Der Haltekopf und/oder die Magnetscheibe kann dann den genannten Mitnahmeanschlag des Ausgleichskolbens fÃ¼r den genannten Mitnahmeabschnitt des Abstandshalters bereitstellen.It is also particularly preferred that the compensation piston has a holding head and a guide portion facing away from the holding head, wherein the holding head faces the spacer and the holding magnet is arranged on the holding head. The guide portion is axially displaceable in particular in a possible gripper base and serves for the axial guidance of the balance piston. In particular, the holding head facing said driving portion of the spacer and the holding magnet is formed as a magnetic disc, which is arranged in the direction of the spacer axially on the holding head the balance piston. The holding head and / or the magnetic disk can then provide said driving stop of the balancing piston for said driving portion of the spacer.

**[p0014]**

Eine besonders bevorzugte Ausgestaltung ergibt sich dadurch, dass der Abstandshalter einen Kolbenabschnitt aufweist, welcher einen Druckraum begrenzt, der zur Bewegung des Abstandshalters in die Abstandslage mit einem Druckmittel druckbeaufschlagbar ist, insbesondere mit Druckluft oder KÃ¼hlmittel druckbeaufschlagbar ist. Auch ein hydraulisches Druckmittel ist denkbar. Durch Beaufschlagung des Druckraumes drÃ¼ckt der Abstandshalter ein aufgenommenes WerkstÃ¼ck von dem Haltemagneten weg, wodurch das WerkstÃ¼ck freigegeben wird. Dadurch wird ein gezieltes Ablegen eines gegriffenen WerkstÃ¼ckes ermÃ¶glicht.A particularly preferred embodiment results from the fact that the spacer has a piston portion which limits a pressure chamber which can be pressurized to move the spacer in the distance position with a pressure medium, in particular with compressed air or coolant can be pressurized. A hydraulic pressure medium is conceivable. By applying pressure to the space, the spacer forces a picked workpiece away from the holding magnet, thereby releasing the workpiece. This allows a targeted placement of a gripped workpiece.

**[p0015]**

Als weitere vorteilhafte Ausgestaltung ist dabei vorgesehen, dass der Abstandshalter einen oder mehrere EntlastungskanÃ¤le aufweist, durch welche Druckmittel aus dem Druckraum, insbesondere gedrosselt, entweichen kann. Die EntlastungskanÃ¤le sind insbesondere axial verlaufend im Abstandshalter ausgebildet und mÃ¼nden insbesondere im Bereich eines Anlageabschnittes des Abstandshalters zur Anlage des WerkstÃ¼ckes in AustrittsÃ¶ffnungen, aus welchen das entweichende Druckmittel austreten kann. Durch Beaufschlagen des Druckraumes mit Druckmittel wird, wie erlÃ¤utert, der Abstandshalter in die Abstandlage bewegt und ein Freigeben eines gegriffenen WerkstÃ¼ckes eingeleitet. Dieser Vorgang kann durch das aus den AustrittsÃ¶ffnungen austretende Druckmittel weiter unterstÃ¼tzt werden. Sind die EntlastungskanÃ¤le derart ausgebildet, dass das Druckmittel gedrosselt entweicht, so wird auÃerdem ein zu schnelles, abruptes Ausfahren des Abstandshalters in die Abstandslage vermieden. Die EntlastungskanÃ¤le kÃ¶nnen im Allgemeinen auÃerdem dazu dienen, Druckmittel, welches beim Einfahren des Abstandshalters aus der Abstandslage in die Greiflage aus dem Druckraum verdrÃ¤ngt wird, abzufÃ¼hren. Sind die AustrittsÃ¶ffnungen im Bereich des genannten Anlageabschnitts angeordnet, so kann durch das durch die AustrittsÃ¶ffnungen austrÃ¶mende Druckmittel eine Reinigungswirkung fÃ¼r das zu greifende WerkstÃ¼ck und/oder den Anlageabschnitt des Magnetgreifers erzielt werden. Dadurch kÃ¶nnen beispielsweise stÃ¶rende MetallspÃ¤ne von dem Magnetgreifer und/oder dem WerkstÃ¼ck entfernt werden.As a further

**[p0015]**

advantageous embodiment, it is provided that the spacer has one or more discharge channels through which pressure fluid from the pressure chamber, in particular throttled, can escape. The relief channels are in particular formed axially extending in the spacer and open, in particular in the region of an abutment portion of the spacer for abutment of the workpiece in outlet openings, from which the escaping pressure medium can escape. By acting on the pressure chamber with pressure medium, as explained, the spacer moves in the distance position and initiated a release of a gripped workpiece. This process can be further supported by the exiting from the outlet pressure medium. If the discharge channels are designed in such a way that the pressure medium escapes in a throttled manner, a too rapid, abrupt extension of the spacer into the spacing position is also avoided. The relief channels can generally do this as well serve, pressure medium, which is displaced during retraction of the spacer from the distance position into the gripping position from the pressure chamber to dissipate. If the outlet openings are arranged in the area of said abutment section, a cleaning action for the workpiece to be gripped and / or the abutment section of the magnetic gripper can be achieved by the pressure medium flowing out through the outlet openings. As a result, interfering metal chips, for example, can be removed from the magnetic gripper and / or the workpiece.

**[p0016]**

Eine weitere vorteilhafte Ausgestaltung ergibt sich dadurch, dass der Abstandshalter als Hohlkolben ausgebildet ist, wobei der Ausgleichskolben wenigstens abschnittsweise koaxial in dem Hohlkolben gefÃ¼hrt ist. Insbesondere ist der Ausgleichskolben mit einem Haltekopf, an den der Haltemagnet angeordnet ist, in dem Hohlkolben koaxial gefÃ¼hrt. Umgekehrt ist jedoch auch denkbar, dass der Ausgleichskolben als Hohlkolben ausgebildet ist und der Abstandshalter wenigstens abschnittsweise koaxial in dem Ausgleichskolben gefÃ¼hrt ist.A further advantageous embodiment results from the fact that the spacer is designed as a hollow piston, wherein the compensating piston is guided at least partially coaxially in the hollow piston. In particular, the compensating piston is guided coaxially in the hollow piston with a holding head, on which the holding magnet is arranged. Conversely, however, it is also conceivable that the balance piston is designed as a hollow piston and the spacer is at least partially coaxially guided in the balance piston.

**[p0017]**

Eine vorteilhafte Ausgestaltung ergibt sich auch dadurch, dass der Abstandshalter als einseitig offener Hohlkolben mit einem dem Ausgleichskolben abgewandten Bodenabschnitt ausgebildet ist, wobei der Haltemagnet in der Greiflage an dem Bodenabschnitt anliegt. Insbesondere stellt der Bodenabschnitt den Mitnahmeabschnitt des Abstandshalters fÃ¼r den Ausgleichskolben bereit. Die dem Haltemagneten abgewandte Seite des Bodenabschnitts ist dem zu greifenden WerkstÃ¼ck zugewandt und stellt einen Anlageabschnitt fÃ¼r das zu greifende WerkstÃ¼ck bereit.An advantageous embodiment also results from the fact that the spacer is formed as a hollow piston open on one side with a bottom portion facing away from the balance piston, wherein the holding magnet rests in the gripping position on the bottom portion. In particular, the bottom portion provides the driving portion of the spacer for the balance piston. The side facing away from the holding magnet of the bottom portion facing the workpiece to be gripped and provides a contact portion for the workpiece to be gripped.

**[p0018]**

Zur Vorspannung des Abstandshalters in der Abstandslage, insbesondere gegen eine Bewegung in Richtung der Greiflage, ist vorteilhafter Weise ein RÃ¼ckstellfedermittel vorgesehen. Im Betrieb des Magnetgreifers wird dadurch eine AnnÃ¤herung des WerkstÃ¼ckes an den Haltemagneten abgebremst und ein harter Anschlag kann vermieden werden. Das RÃ¼ckstellfedermittel stÃ¼tzt sich insbesondere an dem Abstandshalter, insbesondere im Bereich eines etwaigen Kolbenabschnittes des Abstandshalters einerseits und andererseits an dem Greifergrundteil ab.For biasing the spacer in the distance position, in particular against a movement in the direction of the gripping position, advantageously a return spring means is provided. During operation of the magnetic gripper thereby an approach of the workpiece is braked to the holding magnets and a hard stop can be avoided. The return spring means is supported in particular on the spacer, in particular in the region of a possible piston portion of the spacer on the one hand and on the other hand on the gripper base.

**[p0019]**

Zur weiteren Ausgestaltung ist auÃerdem ein Ausgleichsfedermittel zur Vorspannung des Ausgleichskolbens gegen eine Verlagerung in eine Ausgleichslage vorgesehen. Dadurch wird gewÃ¤hrleistet, dass eine Verlagerung des Haltemagneten gemeinsam mit dem Abstandshalter nur dann erfolgt, wenn der Abstandshalter in die Greiflage verschoben wurde und (beispielsweise aufgrund einer Fertigungstoleranz oder eines auf dem WerkstÃ¼ck liegenden Metallspanes) weiter axial verlagert wird. Insbesondere stÃ¼tzt sich das Ausgleichsfedermittel einerseits an einem Greifergrundteil, andererseits an dem Ausgleichskolben ab. Das Ausgleichsfedermittel ist beispielsweise als koaxial um den Ausgleichskolben angeordnete Spiralfeder ausgebildet.For further embodiment, a compensating spring means is also provided for biasing the balance piston against displacement into a leveling position. This ensures that a displacement of the holding magnet together with the spacer takes place only when the spacer has been moved into the gripping position and (for example due to a manufacturing tolerance or lying on the workpiece metal chip) is further axially displaced. In particular, the compensation spring means is supported on the one hand on a gripper base, on the other hand on the balance piston. The compensating spring means is formed, for example, as coaxially arranged around the balance piston coil spring.

**[p0020]**

Weitere Einzelheiten und vorteilhafte Ausgestaltungen der Erfindung sind der nachfolgenden Beschreibung zu entnehmen, anhand derer die in den Figuren dargestellte. AusfÃ¼hrungsform der Erfindung nÃ¤her beschrieben und erlÃ¤utert ist.Further details and advantageous embodiments of the invention will become apparent from the following description, with reference to which shown in the figures. Embodiment of the invention described and explained in detail. Es zeigen:Show it: 1 eine erfindungsgemÃ¤Ãe Greifvorrichtung beabstandet von einem WerkstÃ¼ck mit in Abstandslage ausgefahrenem Abstandshalter; 1 a gripping device according to the invention spaced from a workpiece with spaced apart extended spacer; 2 Greifvorrichtung aus 1 mit auf das WerkstÃ¼ck aufgesetztem Abstandshalter; 2 Gripping device off 1 with spacers placed on the workpiece; 3 Greifvorrichtung aus den 1 und 2 mit in Greiflage eingefahrenem Abstandshalter; 3 Gripping device from the 1 and 2 with retracted in gripping position spacer;

**[p0021]**

4 Greifvorrichtung aus den 1 bis 3 mit aufgenommenem WerkstÃ¼ck. 4 Gripping device from the 1 to 3 with recorded workpiece. Ãbereinstimmende Bauteile sind in den 1 bis 4 mit denselben Bezugszeichen versehen.Matching components are in the 1 to 4 provided with the same reference numerals. Der in den 1 bis 4 dargestellte Magnetgreifer 10 hat ein Greifergrundteil 12 mit einem Montageabschnitt 14. Der Montageabschnitt 14 dient dazu, den Magnetgreifer 10 in einer nicht dargestellten Werkzeugaufnahme, beispielsweise Maschinenspindel, einer nicht dargestellten Handhabungsvorrichtung zu montieren.The in the 1 to 4 illustrated magnetic gripper 10 has a gripper base 12 with a mounting section 14 , The mounting section 14 serves to the magnetic gripper 10 to mount in a tool holder, not shown, for example, machine spindle, a handling device, not shown. Mit dem Magnetgreifer 10 soll ein WerkstÃ¼ck 16 aufgenommen werden.With the magnetic gripper 10 should a workpiece 16 be recorded. Der Magnetgreifer 10 weist einen Abstandshalter 18 auf, welcher als einseitig offener Hohlkolben 19 ausgebildet ist, welcher mit einem Kolbenabschnitt 20 in dem Greifergrundteil 12 gefÃ¼hrt ist. Der Hohlkolben 19 weist einen dem Kolbenabschnitt 20 abgewandten Bodenabschnitt 22 auf, an welchen das aufzunehmende WerkstÃ¼ck 16 zum Greifen anliegt (vergleiche 2 bis 4). Der Bodenabschnitt 22 bildet somit einen Analageabschnitt 24 des Abstandshalters 18 zur Anlage an das zu greifende WerkstÃ¼ck 16.The magnetic gripper 10 has a spacer 18 on, which as unilaterally open hollow piston 19 is formed, which with a piston

**[p0021]**

portion 20 in the gripper base 12 is guided. The hollow piston 19 has a piston portion 20 remote ground section 22 on which the workpiece to be picked 16 to grip (compare 2 to 4 ). The bottom section 22 thus forms a Analageabschnitt 24 of the spacer 18 for contact with the workpiece to be gripped 16 ,

**[p0022]**

Der Magnetgreifer 10 weist auÃerdem einen Ausgleichskolben 26 auf. Der Ausgleichskolben 26 hat einen Haltekopf 28 und einen FÃ¼hrungsabschnitt 30. Im Endbereich des FÃ¼hrungsabschnitts 30 weist der Ausgleichskolben 26 einen Anschlagswulst 31 auf.The magnetic gripper 10 also has a balance piston 26 on. The balance piston 26 has a holding head 28 and a guide section 30 , In the end of the guide section 30 points the balance piston 26 a stop bead 31 on. Der FÃ¼hrungsabschnitt 30 des Ausgleichskolbens 26 ist in einem zugeordneten FÃ¼hrungsabschnitt 32 des Greifergrundteils 12 axial gefÃ¼hrt. Das Greifergrundteil 12 weist auÃerdem im Bereich des FÃ¼hrungsabschnittes 32 einen Anschlagsabschnitt 33 auf, an welchen der Anschlagswulst 31 des Ausgleichskolbens 26 in der in der 1 dargestellten Grundlage des Ausgleichskolbens 26 anliegt. Der FÃ¼hrungsabschnitt 32 ist in der Art eines FÃ¼hrungsrohres ausgebildet, in dessen Rohrinnenraum der FÃ¼hrungsabschnitt 30 des Ausgleichskolbens 26 axial gefÃ¼hrt ist. The guide section 30 of the balance piston 26 is in an associated guide section 32 of the gripper base 12 axially guided. The gripper base 12 also points in the area of the guide section 32 a stopper section 33 on, to which the stop bead 31 of the balance piston 26 in the in the 1 illustrated basis of the balance piston 26 is applied. The guide section 32 is formed in the manner of a guide tube, in the tube interior of the guide portion 30 of the balance piston 26 is guided axially.

**[p0023]**

Der Haltekopf 28 des Ausgleichskolbens 26 ist in dem Hohlkolben 19, genauer in dessen Hohlkolbenausnehmung, koaxial gefÃ¼hrt.The holding head 28 of the balance piston 26 is in the hollow piston 19 , more precisely in the Hohlkolbenausnehmung, coaxially guided. An dem Haltekopf 28 des Ausgleichskolbens 26 ist ein Haltemagnet 34 angeordnet, welcher dem Bodenabschnitt 22 des Hohlkolbens 19 zugewandt ist.At the holding head 28 of the balance piston 26 is a holding magnet 34 arranged, which the floor section 22 of the hollow piston 19 is facing. Der Haltemagnet 34 dient zum AusÃ¼ben einer anziehenden Kraft auf das WerkstÃ¼ck 16 in einer Greifrichtung G (welche als Pfeil in 1 angedeutet ist) auf den Magnetgreifer 10 zu.The holding magnet 34 serves to exert an attractive force on the workpiece 16 in a gripping direction G (which as arrow in 1 indicated) on the magnetic gripper 10 to. In 1 ist der Abstandshalter 18 in seiner Abstandslage dargestellt. Der als Anlageabschnitt 24 dienende Bodenabschnitt 22 ist von dem Haltemagneten 34 entgegen der Greifrichtung G beabstandet. Der Ausgleichskolben 26 ist in der 1 in seiner Grundlage dargestellt, in welcher der Anschlagswulst 31 am Anschlagsabschnitt 33 anliegt.In 1 is the spacer 18 shown in its distance position. The as investment section 24 serving ground section 22 is from the holding magnet 34 spaced apart from the gripping direction G. The balance piston 26 is in the 1 presented in its basis, in which the stop bead 31 at the stop section 33 is applied.

**[p0024]**

Um den Abstandshalter 18 in der in 1 dargestellten Abstandslage vorzuspannen, ist ein als Schraubenfeder 36 ausgebildetes RÃ¼ckstellfedermittel 38 vorgesehen. Die Schraubenfeder 36 ist koaxial um den rohrartig ausgebildeten FÃ¼hrungsabschnitt 32 des Greifergrundteils 12 angeordnet und stÃ¼tzt sich einerseits am Greifergrundteil 12, andererseits an dem Kolbenabschnitt 20 des Abstandshalter 18 ab.To the spacer 18 in the in 1 vorzuspannen shown spacing, is a coil spring 36 formed return spring means 38 intended. The coil spring 36 is coaxial about the tubular guide portion 32 of the gripper base 12 arranged and supported on the one hand on the gripper base 12 on the other hand on the piston section 20 of the spacer 18 from. Um den Ausgleichskolben 26 in seiner in 1 dargestellten Grundlage vorzuspannen, ist ein als Schraubenfeder 40 ausgebildetes Ausgleichsfedermittel 42 vorgesehen. Die Schraubenfeder 40 ist koaxial um den dem Haltekopf 28 zugewandten Abschnitt des FÃ¼hrungsabschnitts 30 angeordnet. Die Schraubenfeder 40 stÃ¼tzt sich einerseits an dem Haltekopf 28, andererseits an dem FÃ¼hrungsabschnitt 32 des Greifergrundteils 12 ab.To the balance piston 26 in his in 1 vorzuspannen base is a coil spring 40 trained compensating spring means 42 intended. The coil spring 40 is coaxial with the holding head 28 facing portion of the guide section 30 arranged. The coil spring 40 supported on the one hand on the holding head 28 on the other hand on the guide section 32 of the gripper base 12 from.

**[p0025]**

Der Abstandshalter 18 begrenzt mit seinem Kolbenabschnitt 20 in dem Greifergrundteil 12 einen Druckraum 50. Der Druckraum 50 ist mit einem Druckmittel, beispielsweise Druckluft oder KÃ¼hlmittel, beaufschlagbar. Bei Beaufschlagung des Druckraums 50 erfÃ¤hrt der Abstandshalter 18 eine Kraft, welche ihn in die Abstandslage verlagert.The spacer 18 limited with its piston section 20 in the gripper base 12 a pressure room 50 , The pressure room 50 is with a pressure medium, for example, compressed air or coolant, acted upon. When loading the pressure chamber 50 the spacer learns 18 a force that moves him into the distance position. Der Hohlkolben 19 weist in seinen Wandungen axial verlaufende EntlastungskanÃ¤le 52 auf. Die EntlastungskanÃ¤le 52 mÃ¼nden einerseits im Bereich des Kolbenabschnitts 20 in den Druckraum 50, andererseits im Bereich des den Anlageabschnitt 24 bildenden Bodenabschnitts 22 in AustrittsÃ¶ffnungen 54. Jeder Entlastungskanal 52 weist einen derart geringen StrÃ¶mungsquerschnitt auf, dass fÃ¼r aus dem Druckraum 50 austretendes Druckmittel, welches den Entlastungskanal 52 durchstrÃ¶mt, eine Drosselwirkung bereitgestellt wird.The hollow piston 19 has axially extending discharge channels in its walls 52 on. The discharge channels 52 open on the one hand in the region of the piston section 20 in the pressure room 50 on the other hand in the area of the plant section 24 forming ground section 22 in outlet openings 54 , Every discharge channel 52 has such a small flow cross-section that for from the pressure chamber 50 escaping pressure medium, which is the discharge

**[p0025]**

channel 52 flows through, a throttling action is provided.

**[p0026]**

In der 2 ist der Magnetgreifer 10 in einer weiter in Richtung des WerkstÃ¼ckes 16 abgesenkten Position dargestellt. Dabei liegt der von dem Bodenabschnitt 22 gebildete Anlageabschnitt 24 des Abstandshalters 18 an dem WerkstÃ¼ck an. Dadurch kann das WerkstÃ¼ck 16 in gewissem MaÃe gegen seitliches Verrutschen vorfixiert werden. Der Abstandshalter 18 befindet sich jedoch noch in seiner Abstandslage. Daher ist das WerkstÃ¼ck 16 noch vom Haltemagnet 34 beabstandet und der Magnetgreifer 10 Ã¼bt noch keine zum Anheben des WerkstÃ¼cks 16 ausreichende Kraft in die Greifrichtung G aus.In the 2 is the magnetic gripper 10 in a further direction of the workpiece 16 lowered position shown. It is the bottom of the section 22 formed investment section 24 of the spacer 18 on the workpiece. This allows the workpiece 16 be pre-fixed to some extent against lateral slippage. The spacer 18 is still in its distance. Therefore, the workpiece is 16 still from the holding magnet 34 spaced and the magnetic gripper 10 still does not exercise to lift the workpiece 16 sufficient force in the gripping direction G from.

**[p0027]**

Um das WerkstÃ¼ck 16 mit dem Magnetgreifer 10 zu greifen, wird der Magnetgreifer 10 ausgehend von der in 2 dargestellten Position weiter in Richtung des WerkstÃ¼ckes 16 abgesenkt. Dadurch wird der Hohlkolben 19 ausgehend von seiner Abstandslage in das Greifergrundteil 12 eingeschoben.To the workpiece 16 with the magnetic gripper 10 to grab, becomes the magnetic gripper 10 starting from the in 2 shown position further in the direction of the workpiece 16 lowered. This will cause the hollow piston 19 starting from its distance position in the gripper base 12 inserted. Dabei wird zunÃ¤chst die Schraubenfeder 36 (RÃ¼ckstellfedermittel 38) von dem Kolbenabschnitt 20 zusammengedrÃ¼ckt. Ferner wird aus dem Druckraum 50 Druckmittel verdrÃ¤ngt, welches durch die EntlastungskanÃ¤le 52 gedrosselt entweichen kann. Dadurch wird eine Bremswirkung fÃ¼r die absenkende Bewegung des Magnetgreifer 10 bereitgestellt.First, the coil spring 36 (Return spring means 38 ) from the piston section 20 pressed together. Furthermore, from the pressure chamber 50 Pressure medium displaced, which through the discharge channels 52 throttled escape. As a result, a braking effect for the lowering movement of the magnetic gripper 10 provided.

**[p0028]**

Bei der axialen Verlagerung erreicht der Abstandshalter 18 seine Greiflage, wenn er so weit in das Greifergrundteil 12 eingeschoben ist, dass der Haltemagnet 34 an dem Bodenabschnitt 22 anliegt. In der Greiflage ist der Haltemagnet 34 sehr nahe am WerkstÃ¼ck 16, wodurch eine erhÃ¶hte Anziehungskraft fÃ¼r das WerkstÃ¼ck auf den Haltemagneten 34 bereitgestellt wird.During axial displacement, the spacer reaches 18 its gripping position when he is so far into the gripper base 12 is inserted that the holding magnet 34 at the bottom section 22 is applied. In the gripping position is the holding magnet 34 very close to the workpiece 16 , whereby an increased attraction for the workpiece on the holding magnet 34 provided. Solange sich der Abstandshalter 18 noch nicht in der Greiflage befindet, verbleibt der Ausgleichskolben 26 in der in 1 und 2 dargestellten Grundlage, da der Ausgleichskolben 26 durch das Ausgleichsfedermittel 42 in der Grundlage vorgespannt ist.As long as the spacer 18 not yet in the gripping position, the balance piston remains 26 in the in 1 and 2 illustrated basis, since the balance piston 26 by the compensating spring means 42 is biased in the foundation.

**[p0029]**

In 3 ist der Abstandshalter 18 bezÃ¼glich des Haltemagneten 34 in der Greiflage dargestellt: Der Haltemagnet 34 liegt an dem Bodenabschnitt 22 an.In 3 is the spacer 18 with respect to the holding magnet 34 shown in gripping position: The holding magnet 34 lies at the bottom section 22 at. Allerdings wurde in der Darstellung der 3 der Magnetgreifer 10 nach dem Erreichen der Greiflage noch weiter auf das WerkstÃ¼ck 16 abgesenkt. Dies kann beispielsweise dann auftreten, wenn die Position der WerkstÃ¼ckoberflÃ¤che von einer erwarteten Position abweicht (beispielsweise weil Fertigungstoleranzen bei der Herstellung des WerkstÃ¼ckes 16 auftreten).However, in the presentation of the 3 the magnetic gripper 10 after reaching the gripping position still further on the workpiece 16 lowered. This can occur, for example, when the position of the workpiece surface deviates from an expected position (for example, because manufacturing tolerances in the production of the workpiece 16 occur). In diesem Fall wird der Abstandshalter 18 weiter axial eingeschoben. Da der Ausgleichskolben 26 (mittelbar Ã¼ber den Haltemagneten 34) an dem Bodenabschnitt 22 anliegt, wird der Ausgleichskolben 26 bei weiterer axialer Verlagerung des Abstandshalters 18 ebenfalls axial verlagert. Der Ausgleichskolben 26 wird dann von dem Abstandshalter 18 axial mitgenommen. Der Bodenabschnitt 22 stellt also einen Mitnahmeabschnitt 56 des Abstandshalters fÃ¼r einen in diesem AusfÃ¼hrungsbeispiel von dem Haltemagneten 34 bereitgestellten Mitnahmeanschlag des Ausgleichskolbens 26 dar.In this case, the spacer will 18 furthe

**[p0029]**

r inserted axially. Because the balance piston 26 (indirectly via the holding magnet 34 ) at the bottom section 22 is applied, the balance piston 26 upon further axial displacement of the spacer 18 also axially displaced. The balance piston 26 is then from the spacer 18 taken along axially. The bottom section 22 thus provides a driving section 56 of the spacer for a in this embodiment of the holding magnet 34 provided driving stop of the balance piston 26 represents.

**[p0030]**

Wie aus der 3 erkennbar, wird bei weiterer axialer Verlagerung des Abstandshalters 18, wenn sich dieser relativ zum Haltemagneten 34 in der Greiflage befindet, das Ausgleichsfedermittel 42 (Schraubenfeder 40) zusammengedrÃ¼ckt. Dabei wird das Ausgleichsfedermittel 42 zwischen dem Haltekopf 28 und dem FÃ¼hrungsabschnitt 32 komprimiert.Like from the 3 recognizable, is at further axial displacement of the spacer 18 if this is relative to the holding magnet 34 located in the gripping position, the compensating spring means 42 (Coil spring 40 ) pressed together. In this case, the compensation spring means 42 between the holding head 28 and the guide section 32 compressed. Bei der beschriebenen weiteren axialen Verlagerung wird der Ausgleichskolben 26 aus seiner Grundlage in eine axiale Ausgleichslage verschoben. In dieser axialen Ausgleichslage hebt der Anschlagswulst 31 von dem Anschlagsabschnitt 33 um einen in der 3 mit A bezeichneten axialen Ausgleichsweg ab.In the described further axial displacement of the balance piston 26 moved from its base into an axial compensation position. In this axial compensation position lifts the stop bead 31 from the stopper section 33 one in the 3 starting with A designated axial compensation path.

**[p0031]**

Die 4 zeigt den Magnetgreifer 10, welcher mit dem gegriffenen WerkstÃ¼ck 16 angehoben wurde. Der Abstandshalter 18 befindet sich in der Greiflage, in welcher der Haltemagnet 34 an dem Bodenabschnitt 22 anliegt. Durch die Gewichtskraft des WerkstÃ¼ckes 16 ist jedoch der Abstandshalter 18 wieder nach unten gezogen. Dadurch ist der Ausgleichskolben 26 wieder in seine Grundlage zurÃ¼ckverlagert, in welcher der Anschlagswulst 31 an dem Anschlagsabschnitt 33 anliegt.The 4 shows the magnetic gripper 10 , which with the gripped workpiece 16 was raised. The spacer 18 is located in the gripping position, in which the holding magnet 34 at the bottom section 22 is applied. By the weight of the workpiece 16 however, it is the spacer 18 pulled back down. This is the balance piston 26 relocated back to its foundation, in which the stop bead 31 at the stopper section 33 is applied. Um schlieÃlich das WerkstÃ¼ck 16 loszulassen, kann nun der Druckraum 50 mit Druckmittel beaufschlagt werden. Wie erlÃ¤utert, wird dadurch der Abstandshalter 18 aus seiner Greiflage vom Haltemagneten 34 wegbewegt. Dadurch wird auch das an dem Anlageabschnitt 24 (Bodenabschnitt 22) anliegende WerkstÃ¼ck 16 vom Haltemagneten 34 entfernt. Das Loslassen des WerkstÃ¼ckes 16 kann weiter dadurch unterstÃ¼tzt werden, dass bei Beaufschlagung des Druckraums 50 Druckmittel (insbesondere Druckluft) durch die EntlastungskanÃ¤le 52 und die dem WerkstÃ¼ck 16 zugewandten AustrittsÃ¶ffnungen 54 ausstrÃ¶men.Finally, the workpiece 16 let go, now the pressure chamber 50 be acted upon with pressure medium. As explained, this will ma

**[p0031]**

ke the spacer 18 from his gripping position of the holding magnet 34 moved away. As a result, this is also the case at the contact section 24 (Bottom portion 22 ) fitting workpiece 16 from the holding magnet 34 away. Letting go of the workpiece 16 can be further supported by the fact that upon exposure to the pressure chamber 50 Pressure medium (in particular compressed air) through the discharge channels 52 and the workpiece 16 facing outlet openings 54 flow out.

## Classifications

- B25J15/0608
- B65G47/92

## Cited patent documents

- [DE-102008006447-A1](https://patents.google.com/patent/DE102008006447A1/en) — SEA
- [DE-20108552-U1](https://patents.google.com/patent/DE20108552U1/en) — SEA
- [US-5433492-A](https://patents.google.com/patent/US5433492A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
