# 26. Handling device for substantially flat ceramic articles

- **Archive rank:** 26 of 50
- **Publication:** [WO-2025202966-A1](https://patents.google.com/patent/WO2025202966A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/091829085/publication/WO2025202966A1?q=pn%3DWO2025202966A1)
- **Publication date:** 2025-10-02
- **Filing date:** 2025-03-27
- **Earliest priority:** 2024-03-28
- **Family:** 91829085
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** SACMI TECH S P A
- **Inventors:** MONTANARI FABRIZIO

## Abstract

A handling device (1) for a plane of substantially flat ceramic articles (2); comprising: a suction chamber (6); a suction unit (30) to generate a depression inside the suction chamber (6); a gripper surface (4) intended, in use, to come into contact with the plane to be picked up; a plurality of ducts (8) extending from the suction chamber (6) to said gripper surface (4); and a plurality of automatic valve assemblies (9), each arranged at a duct (8) and configured to selectively open or close the fluid connection between the respective duct (8) and the suction chamber (6) as pressure conditions within said duct (8) change.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops000.png)

![Sketch 1 for WO-2025202966-A1](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops001.png)

![Sketch 2 for WO-2025202966-A1](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops002.png)

![Sketch 3 for WO-2025202966-A1](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops003.png)

![Sketch 4 for WO-2025202966-A1](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops004.png)

![Sketch 5 for WO-2025202966-A1](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops005.png)

![Sketch 6 for WO-2025202966-A1](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops006.png)

![Sketch 7 for WO-2025202966-A1](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops007.png)

![Sketch 8 for WO-2025202966-A1](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops008.png)

![Sketch 9 for WO-2025202966-A1](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops009.png)

![Sketch 10 for WO-2025202966-A1](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops009.png)

[Sketch 11](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops010.png)

![Sketch 11 for WO-2025202966-A1](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops010.png)

[Sketch 12](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops011.png)

![Sketch 12 for WO-2025202966-A1](https://nimo.iptorch.com/refdrawing/WO-2025202966-A1/ops011.png)

## Claims

### Claim 1

CLAIMS 1. A handling device (1) for handling a plane of substantially flat ceramic articles (2) ; the handling device (1) comprises: a suction chamber (6) ; a suction unit (30) fluidly connected to said suction chamber (6) and operable to generate a depression of inside said suction chamber (6) ; a gripper surface (4) which, in turn, comprises a plurality of openings (13) , each having an area varying from about 1cm<2>to about 10cm<2>and is intended, in use, to come into contact with said plane of substantially flat ceramic articles to be picked up; a plurality of ducts (8) for fluidly connecting said suction chamber (6) and said gripper surface (4) ; each duct (8) of said plurality of ducts (8) extends from a respective opening (13) of said plurality of openings (13) to said suction chamber (6) ; a plurality of automatic valve assemblies (9) each arranged at a duct (8) of said plurality of ducts (8) and configured to selectively open or close the fluid connection between the respective duct (8) and said suction chamber (6) depending on (in particular, upon variation of) the pressure conditions within said duct (8) ; and at least one dividing grate (14) that extends from one end (12) of the suction chamber (6) , defines said plurality of ducts (8) and is internally hollow to accommodate a filling material; said filling material being a compressible material chosen among sponge, silicone foam, rubber or a combination thereof . 2. The handling device (1) according to claim 1, wherein said gripper surface (4) has an area varying from about Im<2>to about 8m<2>. 3. The handling device (1) according to claim 1 or 2, wherein said openings (13) of the plurality of openings (13) of said gripper surface (4) all substantially have the same area and are evenly distributed along said gripper surface (4) ; in particular, the sum of the areas of the openings (13) of said plurality of openings (13) is smaller than or identical to the area of said gripper surface (4) . 4. The handling device (1) according to any one of the preceding claims, wherein said suction unit (30) comprises (in particular, is formed by) a ventilation system configured to handle (namely, suck) a flow rate of air varying between about 50 cubic metres of air per minute and about 140 cubic metres of air per minute (in particular, from about 54 cubic metres of air per minute to about 134 cubic metres of air per minute) . 5. The handling device (1) according to any one of the preceding claims, wherein: said plurality of automatic valve assemblies (9) comprises a number of automatic valve assemblies (9) similar to the number of ducts (8) of said plurality of ducts (8) . 6. The handling device (1) according to any one of the preceding claims, wherein each automatic valve assembly (9) comprises at least one movable element (15) movable between a first position, wherein it prevents the fluid connection between the respective duct (8) and said suction chamber (6) , and a second position, wherein said movable element (15) is arranged to allow the fluid connection between the respective duct (8) and said suction chamber (6) . 7. The handling device (1) according to claim 6, wherein: said (namely, each) movable element (15) is configured to assume said second position under normal conditions and comprises (in particular, is formed by) at least one diaphragm (16) configured to shift from the second position to the first position only when subjected to an action resulting greater than a certain threshold value. 8. The handling device (1) according to claim 7, wherein : said (namely, each) at least one diaphragm (16) comprises (in particular, is) a partition which is hinged to a wall (18) of the respective duct (8) and is configured to occlude the respective duct (8) when it is in its first position; each automatic valve assembly (9) comprises a spring (17) configured to transmit an elastic force to said partition so as to hold it in said second position; and said threshold value being equal to the elastic force transmitted by said spring (17) . 9. The handling device (1) according to claim 7, wherein : said at least one diaphragm (16) comprises (in particular, is) a partition, which is hinged to a wall (18) of the respective duct (8) and is configured to obstruct the respective duct (8) when it is in the first position; said threshold value is equal to the weight (namely, force of gravity) to which said partition is subjected. 10. The handling device (1) according to claim 7, wherein : each automatic valve assembly (9) comprises a flexible material layer (29) interposed between said suction chamber (6) and said dividing grate (14) ; said at least one diaphragm (16) comprises (in particular, consists of) a pair of blades (19) manufactured as one single piece together with said flexible material layer (29) and each hinged to said flexible material layer (29) by means of a relative weakening section (20) ; the blades (19) of each pair of blades (19) in the second position extend from the respective weakening section (20) towards the inside of the respective duct (8) getting close to one another along two incident directions (Ai and A2) and are configured to rotate around the respective weakening section (20) overlapping one another so as to occlude the respective duct (8) by shifting from said second position to said first position; said threshold value being equal to the resistance to deformation of each one of said blades (19) . 11. The handling device (1) according to claim 6, wherein said (namely, each) movable element (15) is configured to assume said second position under normal conditions and comprises (in particular, is formed by) at least one sphere (31) which is configured to be movable within a respective duct (8) and to shift from the second position to the first position, wherein said sphere (31) occludes the respective duct (8) , only when subjected to an action resulting greater than a certain threshold value; in particular, said threshold value is equal to the weight (namely, force of gravity) to which said sphere (31) is subjected. 12. The handling device (1) according to any one of claims 1 to 6, wherein said movable element (15) is configured to assume said first position, under normal conditions, and shifts from said first position to said second position when subjected to a thrust action (S) transferred from said plane of substantially flat ceramic articles (2) to be picked up in contact with said gripper surface ( 4 ) . 13. The handling device according to claim 12, comprising : a first flexible material layer (21) , which is arranged at an end of the suction chamber (6) and, in turn, comprises a plurality of openable baffles (22) , each acting as movable element (15) and configured to open, thus defining a passage opening, when it shifts from said first position to said second position; and a second pressing layer (23) , which is located between said first layer (21) and said dividing grate (14) and comprises a plurality of pressing portions (24) , each extending in a respective duct (8) of said plurality of ducts (8) until it reaches the opening (13) of said plurality of openings (13) delimiting it, so that, in use, when said plane of substantially flat ceramic articles (2) to be picked up engages said opening (13) , the respective pressing portion (24) , subjected to the action of said plane of substantially flat ceramic articles (2) , shifts from a rest configuration to a thrust configuration, transferring said thrust action (S) onto the respective openable baffle (22) , thus causing it to shift from said first position to said second position. 14. The handling device according to claim 12, wherein said movable element (15) comprises: a shutter (25) which is rotatably coupled to a respective duct (8) of said plurality of ducts (8) to shift from a rest configuration, when said movable element (15) assumes said first position, wherein it extends parallel to said gripper surface (4) to occlude said respective duct (8) , to a rotated configuration, when said movable element (15) assumes said second position, wherein it is rotated with respect to said gripper surface (4) to fluidly connect the respective duct (8) with said suction chamber (6) ; and an appendage (26) which is connected to said shutter (25) and extends along said respective duct (8) until it engages said opening (13) of said plurality of openings (13) delimiting it so that, in use, when said plane of substantially flat ceramic articles (2) to be picked up engages said opening (13) by exerting said thrust action (S) on said appendage (26) , said appendage (26) transfers said thrust action (S) on said shutter (25) causing it to shift from the rest configuration to the rotated configuration. 15. Method for handling slab-shaped ceramic articles (2) to move at least one plane of substantially flat ceramic articles (2) ; the method comprises the following steps: providing a handling device (1) made according to any one of claims 1 to 14; bringing said handling device (1) close to a plane of substantially flat ceramic articles (2) to be picked-up until said gripper surface (4) comes into contact with said plane of substantially flat ceramic articles (2) to be picked up; operating said suction unit (30) of said handling device (1) until it grips said plane of substantially flat ceramic articles (2) to be picked up; and moving said handling device (1) , holding said plane of substantially flat ceramic articles (2) to be picked- up, from a first position to a second position.

## Full description

**[0001]**

"HANDLING DEVICE FOR SUBSTANTIALLY FLAT CERAMIC ARTICLES"

**[0002]**

CROSS-REFERENCE TO RELATED APPLICATIONS

**[0003]**

This Patent Appl ication claims priority from Italian Patent Application No . 102024000006994 filed on March 28 , 2024 , the entire disclosure of which is incorporated herein by reference .

**[0004]**

FIELD OF THE ART

**[0005]**

The present invention relates to a handling device for substantially flat ceramic articles ; more particularly, a handling device for handling a plane comprising at least one substantially flat ceramic article , such as , for example , a single ceramic slab or tile or a group of ceramic articles , so-called " squared tiles" of ceramic articles .

**[0006]**

BACKGROUND OF THE INVENTION

**[0007]**

In the ceramics industry, suction handling devices are known to be used for transporting and handling substantially flat ceramic articles such as tiles or ceramic slabs ; more particularly, for transporting and handling planes of flat ceramic articles comprising one or more large-si zed ceramic slabs or squared tiles , of ceramic tiles .

**[0008]**

These known handling devices generally comprise : a suction hood; a vacuum generating system, typically a centri fugal fan suction system, which can be operated to generate a depression inside the suction hood proportional to the volume of air being moved; and a gripper surface that extends from the suction hood, on the opposite side from the fan suction system, and is configured to come into contact with the plane of ceramic articles to be handled in order to grip and hold it during the various handling operations .

**[0009]**

More speci fically, these handling devices , thanks to

**[0010]**

the action of centri fugal fans , are able to exert , on the plane of ceramic articles to be transported, a force of attraction that is suf ficient to hold the plane of ceramic articles to be transported and keep it in place during handling .

**[0010]**

Suction devices of the known type are , for example , disclosed in document US5813713A, which relates to an apparatus for stacking products , in particular cartons , and document DE1956614A1 , which relates to the transport and stacking of panels .

**[0011]**

The above-mentioned devices of the known type , while having been ef fectively used in the ceramic field for several years now, have some technical disadvantages , especially when used in the most modern ceramic article handling systems , which are characterised by high flexibility in terms of si ze of ceramic articles being handled and which, therefore , require to handle planes of ceramic articles that are always di f ferent in si ze and/or shape .

**[0012]**

The well-known suction handling devices , in fact , when the extension of the plane of ceramic articles to be handled varies , run the risk of being inef fective due to pressure losses caused by the inlet of air into the suction hood through the areas of the gripper surface of the sucking plane which, in use (namely when the article or plane of articles is gripped) , are not in contact with the plane o f ceramic articles to be picked up .

**[0013]**

This could occur, for example , whenever the plane of ceramic articles to be picked up is smaller than the dimensions of the gripper surface , but also whenever the surface of ceramic articles to be handled is a squared tile of ceramic articles , which inevitably has spaces , however

**[0015]**

small , between the various ceramic articles that compose it and/or which may have missing articles , but also whenever the plane of ceramic articles to be handled has unforeseeable imperfections , for example defects and irregularities of one or more ceramic articles or missing portions of the ceramic article .

**[0014]**

In these cases , in use , the vacuum generating system will attract air from outside , the so-called false air, through those areas of the gripper surface that are not occupied (namely, not obstructed) by the plane of ceramic articles to be handled and this air, once it enters the suction hood, will inevitably cause a drop in the depression and therefore in the force of attraction exerted on the plane of ceramic articles to be handled, which, in the most serious cases , may lead to the loss of grip and therefore to the fall of the entire plane of ceramic articles to be handled, or of part of the ceramic articles that compose it , with all the problems in terms of safety and economic losses that this may entail .

**[0015]**

It is precisely to avoid these risks that every time the si ze of the plane of the ceramic articles to be handled changes , specialised operators are required to intervene manually by installing a removable covering layer, typically made of adhesive felt , at the areas of the gripper surface exceeding the si ze of the plane of the ceramic articles to be handled, or at the areas of the gripper surface that , in use , would not be occupied by the plane of the ceramic articles to be handled .

**[0016]**

The manual installation of such cover layers not only has all the drawbacks in terms of cost , accuracy and replicability that are typical of manual work, but also

**[0019]**

results in machine downtime every time the format of the plane of ceramic articles to be handled changes , with a consequent decrease in the ef ficiency of the ceramic article handling system .

**[0017]**

In addition to the aforementioned problems , there are limits in terms of the maximum thickness of the plane of ceramic articles that can be moved, which to date cannot exceed 30cm .

**[0018]**

The aim of the present invention is to propose a handling device for substantially flat ceramic articles , which solves , at least in part , the problems of the prior art .

**[0019]**

SUMMARY

**[0020]**

In accordance with the present invention, a device is proposed for handling substantially flat ceramic articles as described in the appended independent claims , and preferably, in any one of the claims dependent directly or indirectly on the mentioned independent claims .

**[0021]**

The claims describe preferred embodiments of the present invention forming an integral part of the present disclosure .

**[0022]**

BRIEF DESCRIPTION OF THE DRAWINGS

**[0023]**

The invention wi ll now be described with reference to the accompanying drawings , which show some non-limiting embodiments , wherein :

**[0024]**

- Figure 1 is a view of a handling device for ceramic articles in accordance with a first embodiment of the present invention and of two of its components shown disassembled underneath the handling device for ease of understanding;

**[0025]**

- Figure 2 is a plan view of the handling device for ceramic articles in Figure 1 ;

**[0029]**

- Figures 3 to 6 represent cross-section views of the ceramic article handling device in Figures 1 and 2 and of a substantially flat ceramic article during the subsequent steps of the ceramic article gripping operation, in which the air flows are represented with arrows and the di f ferent pressure conditions are represented with corresponding di f ferently coloured fills in order to better illustrate the operation of the ceramic article handling device ;

**[0026]**

- Figure 7 is a perspective view of a component of the ceramic article handling device of Figures 1 and 2 made in accordance with a variant of the first embodiment of the present invention;

**[0027]**

Figures 8 to 11 represent section views of the handling device for ceramic articles made in accordance with the aforementioned variant of the first embodiment of the present invention and of a substantially flat ceramic article during the subsequent steps of the ceramic article gripping operation, wherein the air flows are represented with arrows and the di f ferent pressure conditions are represented with corresponding di f ferent coloured fills , so as to better illustrate the operation of the ceramic article handling device ;

**[0028]**

- Figure 12 is a perspective view of a handling device for ceramic articles in accordance with a second embodiment of the present invention;

**[0029]**

- Figure 13 is an exploded view of the handling device for ceramic articles in Figure 12 ;

**[0030]**

- Figure 13A is a perspective view of a component of the handling device for ceramic articles of the present invention made in accordance with a variant of the second embodiment of the present invention;

**[0035]**

- Figures 14 to 17 represent cross-section views of the handling device for ceramic articles made in accordance with this variant of the second embodiment of the present invention of a substantially flat ceramic article during the successive steps of the ceramic article gripping operation, wherein the air flows are represented with arrows and the di f ferent pressure conditions are represented with corresponding di f ferent coloured fills so as to better illustrate the operation of the handling device for ceramic articles ;

**[0031]**

- Figure 18 is an exploded view of a handling device for ceramic articles in accordance with a third embodiment of the present invention;

**[0032]**

Figure 19 is a perspective view of part of the components of the handling device in Figure 18 from another angle ;

**[0033]**

- Figure 20 is a perspective view of the handling device for ceramic articles of Figure 18 , which holds a substantially flat ceramic article ;

**[0034]**

- Figures 21 to 24 represent side views of the handling device for ceramic articles in Figure 18 and of a substantially flat ceramic article during the subsequent steps of the ceramic article gripping operation, in which some parts have been removed to better illustrate others , the air flows are represented with arrows and the di f ferent pressure conditions are represented with corresponding di f ferently coloured fills to better illustrate the operation of the handling device for ceramic articles ;

**[0035]**

- Figure 25 shows a schematic side view of a part of a handling device for ceramic articles made according to a further embodiment of the present invention;

**[0041]**

- Figure 26 is a schematic side view of part of a handling device for ceramic articles made according to a last embodiment of the present invention; and

**[0036]**

- Figures 27 and 28 show two schematic views from below of two other poss ible embodiments of the handling device of the present invention .

**[0037]**

DETAILED DESCRIPTION

**[0038]**

In the attached figures , the number globally denotes a handling device 1 for substantially flat ceramic articles 2 such as ceramic slabs or tiles ; more in particular, a handling device for handling a plane of substantially flat ceramic articles 2 .

**[0039]**

Even more advantageously, but not limitatively, the present invention relates to the field of the handling (manipulation) of multi- format ceramic articles 2 and the handling device 1 of the present invention, as will be further explained below, is designed to be capable of picking up and handling substantially flat ceramic article 2 having di f ferent shapes and si zes .

**[0040]**

In the present discussion, the term "plane of substantially flat ceramic articles 2" , henceforth, for the sake of brevity, only "plane to be picked up" , means a plane comprising ( in particular, consisting of ) one or more substantially flat ceramic articles 2 such as ceramic slabs or tiles . Even more in detail , according to some advantageous but non-limiting embodiments such as those schematically shown in the attached figures ( see for example Figures 3 to 6 , 8 to 11 , 14 to 17 and 21 to 24 , which show the various steps of picking up a formed plane ) , the plane to be picked up comprises a ceramic slab 2 , namely, a slab made of ceramic material . Whereas , according to other advantageous but non-

**[0047]**

limiting and not shown embodiments, the plane to be picked up comprises a plurality of ceramic articles 2 grouped together (namely, a squared tile of ceramic articles 2) , which may be ceramic slabs or tiles, arranged side by side and aligned with each other to define the plane to be picked up .

**[0041]**

It should also be noted that, in the present discussion, terms such as "greater", "smaller", "side", "right", "left", "quota" or "height" are used with reference to the handling device 1, in use, i.e. while it comes into contact with a plane to be picked up (e.g. as schematically shown in Figures 3 to 6, 8 to 11, 14 to 17 and 21 to 26) , then arranged with one end (in particular with the gripper surface 4) arranged substantially parallel to the plane to be picked up, when said plane is arranged resting on a horizontal plane (as shown, for example, in Figures 3, 6, 9-11, 14-17, 21-24) . So, for example, the term "above" or "below" means, respectively, "placed above" or "placed below" another component of the handling device 1 in use. Likewise "internally", "externally" means "inwards" or "outwards" of the handling device 1. Furthermore, in the context of the present description, the term "second" component does not necessarily imply the presence of a "first" component. Such terms are sometimes used as labels to improve clarity.

**[0042]**

Advantageously but not limitatively, the handling device 1 comprises a support body 3, preferably in the form of a hood having a substantially truncated-cone shape. According to some advantageous but non-limiting embodiments, this support body 3 is made of metal material.

**[0043]**

Even more advantageously but not limitatively, the support body 3 is delimited, on one side, by a gripper

**[0051]**

surface 4 intended, in use , to come into contact with the plane to be picked up and comprises , in turn : an upper portion 32 (visible , for example, in Figure 26 ) , advantageously but not limitatively arranged on the opposite side with respect to the gripper surface 4 , and configured to carry a suction unit 30 ) ; a central portion 5 laterally delimiting a suction chamber 6 and a base portion 7 extending from the central portion 5 to the gripper surface 4 and configured to carry at least the aforementioned gripper surface 4 , as will become clearer below .

**[0044]**

With particular reference to the enclosed figures , advantageously, the handling device 1 comprises : the aforementioned suction chamber 6 , the aforementioned suction unit 30 , which is fluidly connected with the suction chamber 6 and operable to generate a depression inside the suction chamber 6 ; and the aforementioned gripper surface 4 , which, in use , is intended to come into contact with (namely, to engage ) the plane to be picked up .

**[0045]**

The handling device 1 of the present invention advantageously further comprises a plurality of ducts 8 extending from the suction chamber 6 to the gripper surface 4 to fluidly connect the suction chamber 6 and the gripper surface 4 ; and a plurality of automatic valve assemblies 9 , each arranged at a duct 8 and each configured to selectively open or close the fluid connection between the respective duct 8 and the suction chamber 6 depending on ( in particular, upon variation of ) the pressure (namely, force ) conditions inside the respective duct 8 .

**[0046]**

Even more advantageously but not limitatively, the aforementioned plurality of ducts 8 forms a sort of secondary suction chamber 10 selectively connectable to the suction

**[0055]**

chamber 6 by the aforementioned automatic valve assemblies 9.

**[0047]**

Even more advantageously, but not limitatively, each automatic valve assembly 9 comprises (in particular, consists of) a self-excluding valve suitably configured (as will be further explained below) to operate effectively even in a dusty environment such as the ceramic one.

**[0048]**

According to some advantageous but non-limiting embodiments of the invention not shown, each automatic valve assembly 9 is configured to close the fluid connection between the respective duct 8 and the suction chamber 6, when the pressure inside the suction chamber 6 is higher than 0.00015 bar; more advantageously but not limitatively, when the pressure inside the suction chamber 6 is greater than a limit value varying between about 0.00015 bar and about 0.0002 bar, depending on the type of automatic valve assembly 9; for example, when the valve unit 9 comprises (in particular, is formed by) at least one layer made of Polyethylene, as will be better explained below, said limit value is about 0.00016 bar while when the valve unit 9 comprises (in particular, is formed by) at least one layer made of HDPE, as will be better explained below, said limit value is about 0.00020 bar.

**[0049]**

Advantageously but not limitatively, the suction unit 30 comprises (in particular, is formed by) a ventilation system (see, e.g. Figure 26) known in itself and not described in detail herein, e.g., according to some advantageous but non-limiting embodiments, the ventilation system comprises at least one impeller (known in itself) ; according to other embodiments, such as the one shown in Figure 26, the ventilation system comprises two fans 33 of

**[0059]**

adequate power and capacity (see, e.g. Figure 26) .

**[0050]**

Even more advantageously, but not limitatively, the suction unit 30 is configured to move (namely, suck in) an air flow rate varying between (about) 50 cubic metres of air per minute and (about) 140 cubic metres of air per minute; more advantageously, for example, using a ventilation system having two fans 33 with a power of about 2.2 a 3 kW, each, such air flow rate is variable between (about) 54 cubic metres per minute and (about) 134 cubic metres per minute.

**[0051]**

According to some advantageous but non-limiting embodiments, such as those shown in the appended figures, the suction chamber 6 comprises a first upper opening 11, on a first side, through which said suction chamber 6 is fluidly connected to the suction unit 30, and at least one further lower opening 12 on the opposite side to the first upper opening 11, from which the aforementioned ducts 8 extend; in particular open to the aforementioned secondary suction chamber 10.

**[0052]**

Even more advantageously but not limitatively, the aforementioned lower opening 12 is parallel and counterf aceted to the gripper surface 4 and to the first opening 11 and has an extension smaller than the extension of the first opening and substantially similar to the extension of said gripper surface 4.

**[0053]**

Advantageously but not limitatively, the gripper surface 4 has an area ranging from (about) Im<2>to (about) 8m<2>.

**[0054]**

According to some advantageous but non-limiting embodiments, the gripper surface 4 comprises a plurality of openings 13, each having an area varying from (about) 1cm<2>to (about) 10cm<2>through which, in use, a force of attraction

**[0065]**

determined on the plane to be picked up is transmitted .

**[0055]**

Even more advantageously but not limitatively, in this case , each duct 8 of the plurality of ducts 8 is delimited, on a first side , by a respective opening 13 ; and the si ze of the cross-section area of each duct 8 is greater than or equal to the si ze of the area of the respective opening 13 delimiting it .

**[0056]**

According to some advantageous but non-limiting embodiments , such as those shown in Figures 1 to 6 , 8 to 18 and 20 to 24 , the openings 13 all have substantially the same area and are evenly distributed along the gripper surface 4 .

**[0057]**

More speci fically, advantageously but not limitatively, in this case , the sum of the cross-sectional areas of the ducts 8 is smaller than or equal to the area of the gripper surface 4 . In other words , the plurality of ducts 8 is si zed to cover the entire extension of the gripper surface 4 .

**[0058]**

According to some advantageous but non-limiting embodiments , the handling device 1 comprises at least one dividing grate 14 extending from the aforementioned opening 12 of the suction chamber 6 , on the opposite side of the suction unit 30 , and defines ( i . e . delimits ) the aforementioned ducts 8 and is internally hollow to accommodate a filling material . Even more advantageously but not limitatively, the filling material is a compressible material chosen from sponge , pos sibly closed-cell sponge , silicone foam, rubber, or possibly a combination thereof .

**[0059]**

Advantageously, in use , the presence of this compressible filling material allows the handling device 1 to adapt to planes of substantially flat ceramic articles 2 even i f they are not perfectly planar, e . g . due to

**[0071]**

inaccuracies in the forming process , compensating for any non-planarity and/or irregularity of the plane to be picked up, avoiding the risk that such non-planarity and/or irregularity may cause undesired entries of air flows into the suction chamber 6 , compromising the functionality and/or ef ficiency of the handling device 1 .

**[0060]**

Thanks also to the presence of such a filling material , the handling device 1 is able to pick up and handle any type of plane to be picked up, even those formed by ceramic articles 2 provided with a surface with an irregular structure or in any case provided with roughness that would make the so-called suction cup systems inef fective .

**[0061]**

According to some advantageous but non-limiting embodiments , such as those shown in Figures 1 to 6 , 8 to 18 and 20 to 25 , the plurality of automatic valve assemblies 9 comprises a number of automatic valve assemblies 9 similar to the number of ducts 8 . In other words , in this case , advantageously but not limitatively, the handling device 1 ( even more advantageously, the aforementioned secondary suction chamber 10 ) is partiali zed (namely, subdivided) into a plurality of ducts 8 , each of which is equipped with the aforementioned automatic valve assemblies 9 in order to be isolated from the suction chamber 6 depending on the forces and/or pressures to which it is subj ected as will be further explained below .

**[0062]**

This makes it advantageously possible to obtain the automatic closure of each duct 8 when the suction unit 30 is active and the corresponding opening 13 (namely, the one at which the duct 8 ends ) is not obstructed by the plane to be picked up .

**[0063]**

According to certain advantageous but non-limiting

**[0076]**

embodiments , such as those shown in Figures 1 to 11 , each automatic valve assembly 9 is normally open and is configured (namely, designed) to close only i f , once the suction unit 30 has been actuated, the plane to be picked up does not engage the opening 13 which delimits the duct 8 in which said automatic valve assembly 9 is placed . On the contrary, according to other advantageous but non-limiting embodiments , such as those shown in Figures 12 to 24 , the automatic valve assembly 9 is normally closed and is configured (namely, designed) to open only i f , once the suction unit 30 has been actuated, the plane to be pick up engages the opening 13 which delimits the duct 8 in which said automatic valve assembly 9 is placed .

**[0064]**

Advantageously but not limitatively, each automatic valve assembly 9 is integrally moulded with the dividing grate 14 defining the aforementioned ducts 8 .

**[0065]**

Even more advantageously but not limitatively, each automatic valve assembly 9 is made of plastic or rubber, most preferably of a thermoplastic polyurethane elastomer or soft thermoplastic vulcanised material ( TPV) , or fluorinated rubber or FPM rubber or Polyethylene .

**[0066]**

According to some advantageous but non-limiting embodiments , each automatic valve assembly 9 comprises ( in particular, is formed of ) a sheet of a plastic or rubbery material , for example one of the aforementioned ones ( i . e . thermoplastic polyurethane elastomer, thermoplastic soft vulcanised material ( TPV) , fluoro rubber, FPM rubber, Polyethylene ) ; even more advantageously but not limitatively, each automatic valve assembly 9 comprises ( in particular, is formed of ) a sheet of a flexible material having a Young modulus varying between ( about ) 600 N/mm<2>and

**[0080]**

( about ) 2200 N/mm<2>and having an opening 13 . In fact , in these cases , more advantageously but not limitatively, the automatic valve assembly 9 is formed by cutting this sheet with a laser cutting tool so as to form the aforementioned opening 13 .

**[0067]**

Advantageously, but not limitatively, each of the aforementioned automatic valve assemblies 9 comprises at least one element 15 movable between a first position, in which this prevents the fluid connection between the respective duct 8 and the suction chamber 6 , and a second position, in which this movable element 15 is arranged to allow the fluid connection between the duct 8 and the suction chamber 6 .

**[0068]**

According to certain advantageous but non-limiting embodiments , such as those shown in Figures 1 to 11 , the aforementioned movable element 15 of each automatic valve assembly 9 is configured to assume the second position under normal conditions and comprises ( in particular, is formed by) at least one diaphragm 16 configured to shi ft from the second position to the first position only when subj ected to an action resulting greater than a certain threshold value .

**[0069]**

Even more advantageously, but not limitatively, this diaphragm 16 is configured to shi ft from the second position to the first position when the suction unit 30 is active , the opening 13 delimiting the duct 8 wherein said diaphragm 16 is placed is not occupied (namely, occluded) by a plane to be picked up allowing the entry of a flow of air, whereby the diaphragm 16 , under the action also of said air flow, is subj ected to a resulting action which tends to push it from its rest position, namely from the aforementioned first position, to the second position or closed position .

**[0084]**

With particular reference to Figures 1 to 6 , advantageously but not limitatively, the valve assembly 9 also comprises a spring 17 , the ( or each) diaphragm 16 comprises ( in particular, is ) a partition which is hinged to a wall 18 of the duct 8 in which it i s arranged, and this spring 17 is conf igured to transmit an elastic force to the partition such that it is held in said second position . In this case , the aforementioned threshold value is equal to the elastic force transmitted by that spring 17 . In other words , each partition 16 of each automatic spring assembly 9 is rotatably connected to the wall 18 of the duct 8 by of the interposition of the aforementioned spring 17 , so that it shi fts from the second position, in which it fluidly connects the corresponding duct 8 with the suction chamber 6 ( see Figures 3 , 4 and 5 ) to the first position when the force transmitted by the air flow on the partition 17 is greater than the elastic force transmitted by the spring 17 .

**[0070]**

According to other, even simpler embodiments , the aforementioned partition 16 is hinged to a wall 18 of the duct 8 in which it is arranged and the aforementioned threshold value i s equal to the weight force (namely, force of gravity) to which the partition 16 is subj ected . In other words , in this case, when the resulting action to which the partition 16 is subj ected due to the flow of air is greater than and opposite to the weight force of the partition 16 , it shi fts from the second to the first position occluding the duct 8 in which it is arranged .

**[0071]**

According to other advantageous but non-limiting embodiments , such as the one shown in Figure 25 , the valve assembly 9 also comprises a sphere 31 defining the movable element 15 of each valve assembly 9 configured to assume the

**[0087]**

aforementioned second position under normal conditions . In this case , advantageously but not limitatively, said sphere 31 , that is advantageously but not limitatively hollow, is arranged within the respective duct 8 and is si zed to move inside said duct 8 , to shi ft from the second pos ition, in which the sphere 31 is free in the duct 8 and allows the fluid connection between the respective duct 8 and the suction chamber 6 , to the first position in which the sphere 31 , pushed upwards , occludes the duct 8 by closing the passage between the respective duct 8 and the suction chamber 6 , when subj ected to an external action greater than a certain threshold value . In particular, in this case , the shi ft from the second to the first position occurs whenever the action transmitted on the sphere 31 by the outside air exceeds a limit value which, more advantageously but not limitatively, is equal to the weight force (namely, force of gravity) to which the sphere 31 is subj ected .

**[0072]**

According to stil l other advantageous but non-limiting embodiments , each automatic valve assembly 9 comprises a layer 29 made of flexible material ( in particular, having an elastic modulus varying between about 600 N/mm<2>and about 2200 N/mm<2>) interposed between the suction chamber 6 and the dividing grate 14 ; the diaphragm 16 comprises ( in particular, is formed by) a pair of blades 19 , advantageously but not limitatively made in one single piece with the layer 29 of flexible material , and each hinged to the layer 29 of flexible material by means of a relative weakening section 20 which allows a rotation of each blade 9 , realising, as such, a hinge ( see , for example , Figure 7 ) .

**[0073]**

Even more advantageously, but not limitatively, in this case , in the aforementioned second position of the movable

**[0090]**

element 15, the blades 19 of each pair of blades 19 extend from the respective weakening section 20 towards the inside of the duct 8 in which they are arranged getting close to one another along two mutually incident directions Ai and A2 (schematically shown in Figure 8) and are configured to rotate around the respective weakening section 20 until they partially overlap one another to occlude the respective duct 8, shifting from the second position to the first position (compare Figures 8 and 11) . In this case, advantageously but not limitatively , the aforementioned threshold value is equal to the deformation resistance of each of these blades 19.

**[0074]**

In detail, advantageously but not limitatively, each blade 19 is made of a yielding material, having such a deformability as to move when the resulting force to which it is subjected is greater than its deformation resistance; more particularly, having an elastic modulus varying between (about) 600 N/mm<2>and (about) 2200 N/mm<2>and/or a tensile breaking strength (which is related to the deformation strength) varying between (about) 15 N/mm<2>and (about) 75 N/mm<2>; more particularly, between (about) 15 N/mm<2>and (about) 70 N/mm<2>.

**[0075]**

More advantageously but not limitatively, the layer 29 made of flexible material (more specifically, each blade 19) comprises (more specifically, is made of) plastic or rubber, more preferably, a thermoplastic polyurethane elastomer or a soft thermoplastic vulcanised material (TPV) , or fluorinated rubber or FPM rubber or Polyethylene.

**[0076]**

As already mentioned above, according to other advantageous but non-limiting embodiments, such as those shown in Figures 12 to 24, the automatic valve assembly 9 is

**[0094]**

normally closed and is configured (namely, designed) to open only i f , once the suction unit 30 has been actuated, the plane to be picked up engages the opening 13 which delimits the duct 8 in which said automatic valve assembly 9 is placed . Therefore , in this case, advantageously the movable element 15 is configured to assume the first position under normal conditions so as to occlude the duct 8 in which it is placed and shi ft from the first position to the second position only when subj ected to a thrust action S trans ferred ( directly or indirectly) from the plane to be picked up in contact with the gripper surface 4 .

**[0077]**

More in detail , according to some advantageous but nonlimiting embodiments , such as those shown in Figures 12 to 17 , the handling device comprises a first layer 21 made of flexible material which is arranged at a lower end of the suction chamber 6 , on the side opposite to the suction unit 30 , and which, in turn, comprises a plurality of openable baf fles 22 ; a second pressing layer 23 which is arranged between the layer 21 made of flexible material and the dividing grate 14 and comprises a plurality of pressing portions 24 ( see the enlargement contained in Figure 13 ) , each of which extends into a respective duct 8 until it reaches the opening 13 delimiting it ( delimiting the duct 8 at the bottom) so that , in use , when the plane to be picked up engages the respective opening 13 , said pressing portion 24 , subj ected to the action of the plane to be picked up, shi fts from a rest configuration to a thrust configuration, trans ferring a thrust action S on the respective openable baf fle 22 causing it to shi ft from the first position to the second position .

**[0078]**

Advantageously but not limitatively, this layer 21 of

**[0097]**

flexible material comprises ( in particular, is made of ) plastic or rubber, most preferably but not limited to , a material chosen from thermoplastic polyurethane elastomer, thermoplastic soft vulcanised material ( TPV) , fluorinated rubber, FPM rubber and polyethylene . Alternatively or in combination, advantageously but not limitatively, the layer 21 made of flexible material has an elastic modulus ranging between ( about ) 600 N/mm<2>and ( about ) 2200 N/mm<2>.

**[0079]**

Advantageously but not limitatively, each openable baf fle 22 acts as a movable element 15 and is configured (namely, is deformable ) to open defining a passage opening to fluidly connect the duct 8 in which it is placed and the suction chamber 6 , when it shi fts from the first position to the second position, namely, when the respective pressing portion trans fers the aforementioned thrust action S .

**[0080]**

According to some advantageous but non-limiting embodiments , such as those shown in Figures 13 , 14 - 17 , each openable baf fle 22 comprises ( in particular, is formed by) a pair of openable blades placed side by side and movable (namely, deformable ) to define the aforementioned passage opening when subj ected to the thrust action S .

**[0081]**

Alternatively or additionally, advantageously but not limitatively, each pressing portion 24 is operatively connected to the opening 13 that delimits the duct 8 in which it is placed and is configured to deform locally at the openings 13 that in use are engaged by the plane to be picked up so as to shi ft from the aforementioned rest configuration to the thrust configuration, by trans ferring the thrust action S to the movable baf fles 22 which are configured (namely, designed) to deform by opening the aforementioned passage opening under the action o f said thrust force S ( see ,

**[0101]**

for example , Figures 16 and 17 ) .

**[0082]**

According to other advantageous but non-limiting embodiments , such as the one shown in Figure 13A, each openable baf fle 22 comprises ( in particular, is formed by) four quadricuspid blades which together cover the circular cross-section of each duct 8 and which are movable (namely, deformable ) to define the aforementioned passage opening when subj ected to the thrust action S .

**[0083]**

It is understood that any other blade configuration could be used which, when j oined together, creates an openable baf fle 22 , such as those described above .

**[0084]**

According to other advantageous but non-limiting embodiments , such as those shown in Figures 18 to 24 , the aforementioned thrust action S is trans ferred directly from the movable element 15 .

**[0085]**

Advantageously but not limitatively, the movable element 15 comprises : a shutter 25 which is rotatably coupled to a respective duct 8 to shi ft from a rest configuration, when the movable element 15 assumes the first position, in which it extends parallel to the gripper surface 4 to occlude the respective duct 8 , to a rotated configuration, when the movable element 15 assumes the second position, in which it is rotated with respect to the gripper surface 4 to fluidly connect the respective duct 8 with the suction chamber 6 ; and an appendage 26 which is connected to the respective shutter 25 ( in particular, it is made in one single body with said shutter 25 ) and extends along the respective duct 8 until it reaches the opening 13 delimiting it so that , in use , when the plane to be picked up engages the respective opening 13 by exerting the aforementioned thrust action S on said appendage 26 , the appendage 26 trans fers the thrust

**[0106]**

action S on the shutter 25 causing it to shi ft from the rest configuration to the rotated configuration .

**[0086]**

Advantageously, but not limitatively, in this case , each shutter 25 rests on the walls of the dividing grate 14 and is configured (namely, shaped and si zed) so that , upon contact between the plane to be picked up and the appendage 26 , the appendage 26 is raised causing the rotation of the shutter 25 so as to open a passage opening to fluidly connect the duct 8 in which it is placed and the suction chamber 6 , when it shi fts from the first position to the second position .

**[0087]**

Alternatively or additionally, advantageously but not limitatively, the handling device 1 comprises a layer 27 made of flexible material arranged at the lower end ( in particular at the aforementioned opening 12 ) of the suction chamber 6 ( in particular, between the suction chamber 6 and the dividing grate 14 ) , which, in turn, has portions serving as shutters 25 , which, in turn, have the aforementioned appendages 26 . In other words , advantageously but not limitatively, the shutters 25 and appendages 26 are formed in one single piece with each other and with the layer 27 of flexible material and are separated from the rest of the layer 27 by the weakening sections 28 (partially vi sible in Figure 18 ) .

**[0088]**

According to other advantageous but non-limiting embodiments , such as those shown in Figures 27 and 28 , only part of the gripper surface 4 has openings 13 , having ( as mentioned above ) an area ranging from ( about ) 4cm<2>to ( about ) 25cm<2>delimiting corresponding ducts 8 provided with respective automatic valve assemblies 9 to selectively close or open said ducts 8 , while the remaining part of the gripper

**[0110]**

surface 4 is directly fluidly connected (namely, without interposing automatic valve assemblies 9 ) with the suction chamber 6 . In other words , advantageously but not limitatively, in this case , the gripper surface 4 is subdivided into a first zone Z 1 directly connected with the suction chamber 6 which, even more advantageously but not limitatively has an area that is substantially analogous to the si ze of the smallest of the planes to be picked up that the handling device 1 is intended to handle , and a second zone Z2 comprising openings 13 such as those described above , each of which is delimited, on one side , by a respective duct 9 as will be better explained below in relation to the various embodiments .

**[0089]**

According to some advantageous but non-limiting embodiments , such as those shown in Figures 1 to 6 , 8 to 18 and 20 to 25 , each opening 13 of the plurality of openings 13 has a polygonal or circular or elliptical or oval shape . It is understood that each opening 13 of the plurality of openings may have any shape . Even more advantageously but not limitatively, the cross-section of each duct 8 has the same shape as the corresponding opening 13 .

**[0090]**

According to a further aspect of the present invention, with particular reference to Figures 3 to 6 , 8 to 11 , 14 to 17 and 21 to 24 , a method for handling at least one plane of substantially flat ceramic articles 2 using a handling device 1 such as the one described above is proposed .

**[0091]**

Advantageously but not limitatively, the method comprises the following steps : providing a handling device 1 made in accordance with any one of the above-described embodiments ; bringing the handling device 1 close to a plane to be picked-up until the gripper surface 4 comes into

**[0114]**

contact with the plane to be picked-up ; operating the suction unit 30 of the handling device 1 to take the plane to be picked-up ; and handling the handling device 1 holding the plane to be picked-up from a f irst position to a second position, advantageously but not limitatively di f ferent from the first position .

**[0092]**

The handling device 1 of the present invention as well as the method for handling ceramic articles 2 using this handling device 1 have several advantages , among which the following ones are mentioned .

**[0093]**

The handling device 1 is cheap, reliable , and, unlike the handling devices known in the ceramic industry, can be used to pick up and handle planes of ceramic articles 2 of any shape and/or si ze without the need for any adj ustment and/or manual intervention . In fact , the subdivision of the gripper surface 4 in a certain number of openings 13 selectively connectable to the suction chamber 5 thanks to the presence of respective automatic valve assemblies 9 guarantees the automatic closing of the fluid connection between the gripper surface 4 and the suction chamber 6 at the areas of the gripper surface 4 (namely, of the openings 13 ) which, at the time of gripping the plane to be picked up, are not engaged by the plane itsel f , avoiding the risk of pressure drops inside the suction chamber 6 that would risk causing an undesired pres sure increase that could compromise the holding capacity of the handling device 1 .

**[0094]**

In other words , the handling device 1 of the present invention allows , with an appropriate si zing of the openings 13 and of the suction unit 30 , to handle planes of ceramic articles 2 of any shape , si ze and weight by generating the force of attraction necessary to pick up and hold the plane

**[0118]**

to be picked-up, moving (namely, sucking in) air flows of the order of one cubic metre in order to generate depression levels inside the suction chamber 6 such as to avoid undesired entry of air from the outside , thanks to the presence of the aforementioned channels 8 provided with automatic valve assemblies 9 which allow the aforementioned subdivision of the gripper surface 4 into a certain number of openings 13 .

**[0095]**

In addition, the handling device 1 of the present invention is not reached by the thermal conditions of the surface to be picked up, so that it can also be used to pick up substantially flat surfaces of ceramic articles 2 having temperatures in the order of 100 ° C, as may occur in the ceramic industry, for example when ceramic articles are to be picked up at the outlet of heat treatment machines .

**[0096]**

Finally, the structure of the handling device 1 of the present invention is also easily replicable in handling devices of the known type by simple modi fications , namely, by simply replacing the gripper surface of the handling devices of the known type with the components of any one of the above-described embodiments , for example by arranging a gripper surface 4 provided with a corresponding number of openings 13 , a dividing grate 14 defining the aforementioned plurality of ducts 8 , and installing an automatic valve assembly 9 of the above-described type in each of these ducts 8 .

## Classifications

- B65G47/91
- B25J15/06
- B65G2249/04
- B65G2249/045
- B65G47/91
- B65G49/061

## Cited patent documents

- [CN-103029985-A](https://patents.google.com/patent/CN103029985A/en) — ISR
- [DE-102020213943-A1](https://patents.google.com/patent/DE102020213943A1/en) — ISR
- [DE-1956614-A1](https://patents.google.com/patent/DE1956614A1/en) — ISR
- [IL-103906-A](https://patents.google.com/patent/IL103906A/en) — ISR
- [JP-2007331056-A](https://patents.google.com/patent/JP2007331056A/en) — ISR
- [US-3523707-A](https://patents.google.com/patent/US3523707A/en) — ISR
- [US-5813713-A](https://patents.google.com/patent/US5813713A/en) — ISR

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
