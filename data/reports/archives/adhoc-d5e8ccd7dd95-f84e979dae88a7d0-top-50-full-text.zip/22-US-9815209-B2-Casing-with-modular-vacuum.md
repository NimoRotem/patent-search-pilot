# 22. Casing with modular vacuum

- **Archive rank:** 22 of 50
- **Publication:** [US-9815209-B2](https://patents.google.com/patent/US9815209B2/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/051383776/publication/US9815209B2?q=pn%3DUS9815209B2)
- **Publication date:** 2017-11-14
- **Filing date:** 2015-02-05
- **Earliest priority:** 2014-02-06
- **Family:** 51383776
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus

## Parties

- **Applicant / assignee:** COVAL
- **Inventors:** CECCHIN MICHEL; MILHAU PIERRE; PINET MAXIME

## Abstract

A modular vacuum gripper having a first plate, a second plate provided with at least one downstream orifice, framework members, assembly device for assembling the first plate, the second plate and the framework members, at least one upstream orifice situated on one of the walls of the vacuum gripper, sealing device, vacuum generation device adapted to suck out the air contained inside the vacuum gripper via the upstream orifice, and at least one deformable element extending over the second plate so as to form a sealed contact surface with the part when the air contained inside the vacuum gripper is sucked out.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-9815209-B2/000.png)

![Sketch 1 for US-9815209-B2](https://nimo.iptorch.com/refdrawing/US-9815209-B2/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/US-9815209-B2/001.png)

![Sketch 2 for US-9815209-B2](https://nimo.iptorch.com/refdrawing/US-9815209-B2/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/US-9815209-B2/002.png)

![Sketch 3 for US-9815209-B2](https://nimo.iptorch.com/refdrawing/US-9815209-B2/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/US-9815209-B2/003.png)

![Sketch 4 for US-9815209-B2](https://nimo.iptorch.com/refdrawing/US-9815209-B2/003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/US-9815209-B2/004.png)

![Sketch 5 for US-9815209-B2](https://nimo.iptorch.com/refdrawing/US-9815209-B2/004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/US-9815209-B2/005.png)

![Sketch 6 for US-9815209-B2](https://nimo.iptorch.com/refdrawing/US-9815209-B2/005.png)

## Claims

### Claim 1 (independent)

A modular vacuum gripper for taking hold of a part, said modular vacuum gripper comprising: a first plate forming a top wall of the vacuum gripper; a second wall provided with at least one downstream orifice and forming a bottom wall of the vacuum gripper; framework members to which edges of the first and second plates are fastened and that form side walls of the vacuum gripper; assembling means for the first plate, the second plate and the framework members, the assembling means forming corners of the vacuum gripper; at least one upstream orifice situated on one of the walls of the vacuum gripper; sealing means for preventing exchange of air between the inside of the vacuum gripper and the outside of the vacuum gripper other than via the upstream orifice and via the downstream orifice; vacuum generating means to suck out the air contained inside the vacuum gripper via the upstream orifice so as to generate a vacuum inside the vacuum gripper; and at least one deformable element extending over the second plate and having an air passage orifice facing the downstream orifice so as to form a sealed contact surface with the part when the air contained inside the vacuum gripper is sucked out.

### Claim 2

The modular vacuum gripper according to claim 1 , wherein at least one framework member includes a shaped-section element.

### Claim 3

The modular vacuum gripper according to claim 1 , wherein the first and second plates and the assembling means are screwed to the framework members.

### Claim 4

The modular vacuum gripper according to claim 1 , wherein the sealing means comprise at least one flat seal extending over a length of at least one of the framework members.

### Claim 5

The modular vacuum gripper according to claim 1 , further including fastening means situated on the first plate and arranged to enable the vacuum gripper to be manipulated.

### Claim 6

The modular vacuum gripper according to claim 5 , wherein the fastening means include at least one shaped-section portion.

### Claim 7

The modular vacuum gripper according to claim 1 , wherein the deformable element includes at least one suction cup.

### Claim 8

The modular vacuum gripper according to claim 1 , wherein the vacuum generating means operate by Venturi effect.

### Claim 9

The modular vacuum gripper according to claim 1 , including at least one crosspiece defining, inside the vacuum gripper, at least two sealed and independent vacuum zones.

### Claim 10

The modular vacuum gripper according to claim 1 , including at least one anti-implosion protective stud that extends between the first plate and the second plate.

## Full description

**[p0001]**

The invention relates to gripper apparatus, and more particularly to a modular vacuum gripper for taking hold of a part.

### Background Of The Invention

**[p0002]**

Vacuum grippers are used in many industrial fields (automobile industry, pharmaceuticals, etc.), e.g. for applications for taking hold of, handling, and manipulating parts on a production line. A vacuum gripper associated with a pneumatic or electric vacuum generator includes a gripper plate on which gripper means are designed to take hold of the part when the air contained inside the vacuum gripper is sucked out. Such gripper means are usually constituted either by a certain number of suction cups, or by a foam pad having a certain number of gripper points. Each particular gripping application has its own constraints. Thus, parts that vacuum grippers are suitable for handling or manipulating are of variable weights and sizes. In addition, the required levels of vacuum, and the gripping cycle times differ depending on the applications. Vacuum grippers must thus be manufactured in such a manner as to satisfy the constraints specific to the particular gripping application in which they are used. It is thus relatively complex to implement methods of mass producing such grippers and thus to manufacture such grippers in short times and at low cost.

### Object Of The Invention

**[p0003]**

An object of the invention is to reduce the cost and time for manufacturing a vacuum gripper, and to simplify manufacture of vacuum grippers of various formats.

### Summary Of The Invention

**[p0004]**

With a view to achieving this object, the invention provides a modular vacuum gripper for taking hold of a part, said modular vacuum gripper comprising: a first plate forming a top wall of the vacuum gripper; a second wall provided with at least one downstream orifice and forming a bottom wall of the vacuum gripper; framework members to which edges of the first and second plates are fastened and that form side walls of the vacuum gripper; assembly means for assembling the first plate, the second plate and the framework members; at least one upstream orifice situated on one of the walls of the vacuum gripper; sealing means for preventing exchange of air between the inside of the vacuum gripper and the outside of the vacuum gripper other than via the upstream orifice and via the downstream orifice; vacuum generation means adapted to suck out the air contained inside the vacuum gripper via the upstream orifice so as to generate a vacuum inside the vacuum gripper; and at least one deformable element extending over the second plate and having an air passage orifice facing the downstream orifice so as to form a sealed contact surface with the part when the air contained inside the vacuum gripper is sucked out.

**[p0005]**

Dimensioning the vacuum gripper of the invention for any particular gripping application requires only a limited number of relatively simple operations while it is being manufactured. Such dimensioning consists, in particular, in dimensioning and manufacturing the framework members as a function of the constraints of the particular gripping application, and then in adapting the first plate and the second plate as a function of the dimensions of the framework members. Manufacturing the second plate is relatively simple, and, for example, may be achieved by cutting out from a previously manufactured similar plate of larger area. The first plate is manufactured in the same manner. The framework members are obtained from previously manufactured framework members that are of longer lengths and that are cut to lengths corresponding to the length and to the width of the second plate. Dimensioning the vacuum gripper of the invention is thus compatible with efficient mass production, making it possible to reduce the cost and time for manufacturing the vacuum gripper.

**[p0006]**

The invention can be better understood on reading the following description of a non-limiting particular embodiment of the invention.

### Brief Description Of The Drawings

**[p0007]**

Reference is made to the accompanying drawings, in which: FIG. 1 is a perspective view of a modular vacuum gripper in a first embodiment of the invention, and of a part being manipulated by the gripper; FIGS. 2 to 4 are detail views of the vacuum gripper of the invention while it is being assembled; FIG. 5 is a section view of a shaped-section element of a framework member of the gripper; FIG. 6 is a detail view of the inside of the modular vacuum gripper of the invention, showing an anti-implosion protective stud; FIG. 7 is a perspective view of a modular vacuum gripper in a second embodiment of the invention, said gripper being shown without its top and bottom walls; and FIG. 8 is a perspective view of a modular vacuum gripper in a third embodiment of the invention.

### Detailed Description Of The Invention

**[p0008]**

With reference to FIG. 1 , the invention relates to a modular vacuum gripper 1 for taking hold of a part, which gripper is used in this example in an application for manipulating a cardboard box 2 containing, for example, foodstuffs, said cardboard box 2 being rectangular block shaped and having a relatively large weight and a relatively large size. The modular vacuum gripper 1 of the invention has a first plate 3 forming a top wall of the vacuum gripper 1 , a second plate 4 forming a bottom wall of the vacuum gripper 1 , and framework members 5 to which edges of the first plate 3 and of the second plate 4 are fixed and which form side walls of the vacuum gripper 1 . The first plate 3 is provided with an upstream orifice while the second plate is provided with a certain number of downstream orifices. Vacuum generation means, operating by Venturi effect, are mounted on the first plate 3 . In a first embodiment of the vacuum gripper 1 , shown in FIG. 1 , these vacuum generation means are constituted by a “multi-stage” vacuum generator 8 that is provided with a compressed air intake orifice 9 and with discharge orifices 10 . The intake orifice 9 is connected to a plurality of vacuum generation chambers disposed in series inside the vacuum generator 8 , one behind the other. Each of these chambers is provided with a nozzle and with at least one side orifice communicating via the upstream orifice in the first plate 3 with the inside of the vacuum gripper 1 . When compressed air is admitted via the intake orifice 9 , the air contained in the vacuum gripper 1 is sucked out by the

**[p0008]**

side orifices via the upstream orifice, thereby generating a vacuum inside the vacuum gripper 1 . The intake orifice 9 is connected via a pipe 11 to a control unit 12 connected to a compressed air source that is not shown in FIG. 1 .

**[p0009]**

A certain number of deformable elements, which are suction cups 13 in this example, extend over the second plate 4 . In this example, the suction cups 13 are mounted on inserts that are themselves fastened by screw-fastening or by clipping onto the second plate. Each suction cup 13 has an air passage orifice positioned facing a downstream orifice in the second plate 4 . When a vacuum is generated inside the vacuum gripper 1 , the air contained in each suction cup 13 is sucked out via the passage orifice in the suction cup 13 and via the facing downstream orifice. Thus, when the vacuum generator 8 sucks out the air contained inside the vacuum gripper 1 , the suction cups 13 , as applied against the surface of the cardboard box 2 are united with it and take hold of the cardboard box 2 . In order to manipulate the cardboard box 2 once it has been taken hold of, it thus suffices to manipulate the vacuum gripper 1 . For this purpose, the vacuum gripper 1 is provided with fastening means situated on the first plate 3 . These fastening means are designed to fasten one end of a gripper arm (not shown in the figures) to the vacuum gripper 1 , said gripper arm then being operated manually or automatically to manipulate the vacuum gripper 1 and thus the cardboard box 2 .

**[p0010]**

The fastening means have at least a shaped-section portion, and in this example a shaped-section plate 15 positioned on the first plate 3 . The shaped-section plate 15 is provided with an opening 16 inside which the vacuum generator 8 is positioned. In this example, the shaped-section plate 15 defines four slideways 17 , each of two of which slideways 17 receives, inter alia, two tapped gib plates 18 whose position can be defined manually by causing the tapped gib plates 18 to slide along the slideways 17 . In addition to the shaped-section plate 15 and to the tapped gib plates 18 , the fastening means include four spacers 20 , each of which is made up of a threaded body 21 and of a long nut 22 . A first end 23 of each threaded body 21 is screwed into a tapped hole 24 in a tapped gib plate 18 , thereby making it possible, by compression, to assemble each spacer 20 to the shaped-section plate 15 . Since the threaded body 21 of each spacer 20 does not extend over the entire length of the long nut 22 when the threaded body 21 is screwed into the tapped hole 24 in the corresponding gib plate, each spacer 20 has a tapped free end 26 used for securing the end of the gripper arm to the shaped-section plate 15 and thus to the vacuum gripper 1 .

**[p0011]**

With reference to FIGS. 1 to 5 , the framework members 5 are now described in more detail, as is the manner in which they are assembled to the first plate 3 and to the second plate 4 . The framework members 5 of the vacuum chamber 1 comprise two first framework members 5 a disposed along the length of the vacuum gripper and two second framework members 5 b disposed along the width of the vacuum gripper 1 . At least one of these framework members 5 includes a shaped-section element. In this example, each framework member 5 includes a shaped-section element 30 , of length L for the first framework members 5 a and of length for the second framework members 5 b. Fastening studs 31 are disposed in the framework members 5 . Each fastening stud 31 has a circular base 32 and a tapped insert 33 . The circular bases 32 of the fastening studs 31 are inserted into the top slideways 34 a and into the bottom slideways 34 b of the shaped-section elements 30 of the framework members 5 .

**[p0012]**

The first plate 3 is positioned above the framework members 5 , and is screwed to the tapped inserts 33 of the fastening studs 31 situated in the top slideways 34 a via screws passing through fastening holes in the first plate 3 . Similarly, the second plate 4 is positioned above the framework members 5 , and is screwed to the tapped inserts 33 of the fastening studs 31 situated in the bottom slideways 34 b via screws passing through fastening holes in the second plate 4 . At each of its corners, the vacuum gripper 1 also includes assembly means, in this example fastening corners 36 forming the corners of the vacuum gripper 1 . Each fastening corner 36 is screwed to one of the first framework members 5 a and to one of the second framework members 5 b via the side internal tapped holes 33 in said framework members 5 a , 5 b. Once the first plate 3 , the second plate 4 , the first framework members 5 a , the second framework members 5 b , and the fastening corners 36 are assembled together and screwed together, protective corners 37 are disposed at each corner of the vacuum gripper 1 to close the vacuum gripper 1 and to create continuity along the outside surfaces of the side walls of the vacuum gripper 1 formed by the framework members 5 . The protective corners 37 are fastened to the fastening corners 36 . For this purpose, each protective corner 37 has two fastening tabs 38 adapted to be inserted into two complementary reception orifices 39 in the fastening corners 36 .

**[p0013]**

The vacuum gripper 1 also includes sealing means for preventing, an exchange of air between the inside of the vacuum gripper 1 and the outside of the vacuum gripper 1 other than via the upstream orifice and via the downstream orifices. The sealing means comprise flat seals or gaskets 40 that are disposed along the framework members 5 in first top grooves 41 and in first bottom grooves of the framework members 5 so as to extend over the entire lengths of the framework members 5 . The sealing means further comprise O-ring seals 43 situated at the fastening corners 36 and disposed in second top grooves 44 and in second bottom grooves of the fastening corners 36 . The flat seals 40 and the O-ring seals 43 must be positioned in the first top grooves 41 and in the second top grooves 44 before the first plate 3 is screwed to the framework members 5 , and in the first bottom grooves and in the second bottom grooves before the second plate 4 is screwed to the framework members 5 .

**[p0014]**

With reference to FIG. 6 , the vacuum gripper 1 is equipped with one or more anti-implosion protective studs 45 . These studs 45 make it possible to reinforce the structure of the vacuum gripper 1 and to improve its resistance to the stresses caused by the difference in pressure between the external pressure and the internal pressure of the vacuum gripper. The studs 45 are positioned inside the vacuum gripper 1 and extend between the first plate 3 and the second plate 4 . In a second embodiment, shown in FIG. 7 , the vacuum gripper of the invention 101 has a main crosspiece 102 and two secondary crosspieces 103 positioned inside the vacuum gripper 101 . The main crosspiece 102 extends between the centers of two opposite framework members 105 a situated facing each other. Each of the secondary crosspieces 103 extends between the centre of one of the other framework members 105 b and the centre of the main crosspiece 102 . Each end of the main and secondary crosspieces that is situated at a framework member 105 is fastened to said framework member 105 via a fastening piece 106 comprising a channel-section shaped element having a recess inside which the framework member extends. Each crosspiece 102 , 103 is provided with two flat seals 107 disposed along the crosspiece in top and bottom grooves in the crosspiece 102 , 103 .

**[p0015]**

The crosspieces 102 103 thus form partitions that, inside the vacuum gripper 101 , define four sealed and independent vacuum zones 108 . Each vacuum zone 108 may be associated with a distinct vacuum generator, having a distinct number of suction cups, etc. The crosspieces also act as mechanical reinforcements for mechanically strengthening the structure of the gripper. Naturally, the invention is not limited to the particular embodiments described above, but rather, quite to the contrary, it covers any variant lying within the ambit of the invention as defined by the claims. Although it is indicated that the vacuum generation means are constituted by a multi-stage vacuum generator, said vacuum generation means may be different. For example, in a third embodiment, visible in FIG. 8 , the vacuum gripper of the invention 201 has vacuum generation means that are formed merely by an ejector 208 having a single injection nozzle. Similarly, the vacuum generation means used may optionally include electrical control means for controlling the vacuum, blower means for disuniting the suction cups of the gripper, display means for displaying the level of vacuum, of the vacuum gauge type, etc.

**[p0016]**

Although a certain number of deformable elements are described extending over the second plate, the invention applies to any vacuum gripper having at least one deformable element. The deformable elements are not necessarily suction cups: it is naturally possible to use some other type of deformable element, e.g. a foam pad having at least one gripping point, i.e. an air passage orifice enabling a suction force to be exerted on the part. Similarly, although it is specified that the suction cups are mounted on inserts that are themselves fastened by screwfastening to the second plate, any other known means for providing an interface between the second plate and the suction cups or other deformable elements may be used: nozzle insets, leakage valves (when the deformable elements are constituted by a foam pad) etc. Although it has been chosen to illustrate the invention by disposing the vacuum generation means on the first plate of the vacuum gripper, i.e. on the top wall of the vacuum gripper, they may also be positioned at a side wall, in which case the upstream orifice is situated in said side wall.

**[p0017]**

Although vacuum grippers have been described and shown in which the fastening means include a single shaped-section plate provided with an opening inside which the vacuum generator is positioned, it is possible to equip the vacuum gripper with a plurality of shaped-section plates, and in particular with two shaped-section plates positioned on either side of the vacuum generator. Although the top and bottom walls of all of the vacuum grippers shown herein are rectangular in general shape, it is naturally possible to imagine vacuum grippers of different shapes, and in particular triangular vacuum grippers. In which case, the fastening corners are adapted so that the framework members to which they are fastened form angles less than or greater than 90° depending on the shape required for the vacuum gripper. Although it is indicated that three crosspieces define four distinct vacuum zones inside the vacuum gripper, it is naturally possible to use a different number of crosspieces to obtain at least two distinct vacuum zones.

**[p0018]**

It is also possible to equip the modular vacuum gripper of the invention with accessories making it possible to improve gripping or to offer additional, supplementary features. For example, it is possible to equip the vacuum gripper with one or more part-presence sensors making it possible to detect whether a part to be manipulated has indeed been taken hold of by the gripper. It is also possible to equip the vacuum gripper with unstacker means including, for example, at least one vacuum generator and a suction cup for separating a part, such as a metal sheet, from other parts with which it is stacked. In addition, it is possible to equip the vacuum gripper with mechanical means for holding or maintaining the part to be manipulated, in particular with holding means that can be folded away onto the side of the vacuum gripper.

## Figure captions

- **Figure 1:** FIG. 1 is a perspective view of a modular vacuum gripper in a first embodiment of the invention, and of a part being manipulated by the gripper;
- **Figure 2:** FIGS. 2 to 4 are detail views of the vacuum gripper of the invention while it is being assembled;
- **Figure 5:** FIG. 5 is a section view of a shaped-section element of a framework member of the gripper;
- **Figure 6:** FIG. 6 is a detail view of the inside of the modular vacuum gripper of the invention, showing an anti-implosion protective stud;
- **Figure 7:** FIG. 7 is a perspective view of a modular vacuum gripper in a second embodiment of the invention, said gripper being shown without its top and bottom walls; and
- **Figure 8:** FIG. 8 is a perspective view of a modular vacuum gripper in a third embodiment of the invention.
- **Figure 1:** With reference to FIG. 1 , the invention relates to a modular vacuum gripper 1 for taking hold of a part, which gripper is used in this example in an application for manipulating a cardboard box 2 containing, for example, foodstuffs, said cardboard box 2 being rectangular block shaped and having a relatively large weight and a relatively large size.
- **Figure 1:** With reference to FIGS. 1 to 5 , the framework members 5 are now described in more detail, as is the manner in which they are assembled to the first plate 3 and to the second plate 4 .

## Classifications

- B25J15/0616
- B25J15/0616
- B25J15/0616
- B25J15/0616
- A47B97/00
- B25J15/06
- B66C1/02

## Cited patent documents

- [DE-2910145-A1](https://patents.google.com/patent/DE2910145A1/en) — APP
- [DE-3028763-A1](https://patents.google.com/patent/DE3028763A1/en) — APP
- [DE-9307503-U1](https://patents.google.com/patent/DE9307503U1/en) — APP
- [DE-9418579-U1](https://patents.google.com/patent/DE9418579U1/en) — APP
- [FR-2601088-A1](https://patents.google.com/patent/FR2601088A1/en) — APP
- [US-2006082172-A1](https://patents.google.com/patent/US20060082172A1/en) — APP
- [US-2010040450-A1](https://patents.google.com/patent/US20100040450A1/en) — APP
- [US-2535952-A](https://patents.google.com/patent/US2535952A/en) — APP
- [US-3222051-A](https://patents.google.com/patent/US3222051A/en) — APP
- [US-3366410-A](https://patents.google.com/patent/US3366410A/en) — APP
- [US-3591228-A](https://patents.google.com/patent/US3591228A/en) — APP
- [US-4674785-A](https://patents.google.com/patent/US4674785A/en) — SEA
- [US-4881770-A](https://patents.google.com/patent/US4881770A/en) — SEA
- [US-4892296-A](https://patents.google.com/patent/US4892296A/en) — SEA
- [US-5749614-A](https://patents.google.com/patent/US5749614A/en) — SEA
- [US-6439631-B1](https://patents.google.com/patent/US6439631B1/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
