# 49. Sucker type manipulator for glass product processing

- **Archive rank:** 49 of 50
- **Publication:** [CN-117103316-A](https://patents.google.com/patent/CN117103316A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/088807745/publication/CN117103316A?q=pn%3DCN117103316A)
- **Publication date:** 2023-11-24
- **Filing date:** 2023-10-08
- **Earliest priority:** 2023-10-08
- **Family:** 88807745
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** FOSHAN TAICHANG GLASS PRODUCTS CO LTD
- **Inventors:** Gao Chaofu

## Abstract

The invention discloses a sucker type manipulator for processing glass products, and relates to the field of manipulators. The invention improves the adsorption effect between the sucker and the glass plate under the action of the piston and the transmission rod by arranging the air guide cylinder, the transmission rod and the piston, thereby ensuring that the sucker can suck the glass plate, and simultaneously ensuring that the sucker has enough suction force to fix and take the glass plate because the sucker mainly transfers the glass plate with small volume and light weight, thereby omitting the use of a vacuum pump.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-117103316-A/pdf000.png)

![Sketch 1 for CN-117103316-A](https://nimo.iptorch.com/refdrawing/CN-117103316-A/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-117103316-A/pdf001.png)

![Sketch 2 for CN-117103316-A](https://nimo.iptorch.com/refdrawing/CN-117103316-A/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/CN-117103316-A/pdf002.png)

![Sketch 3 for CN-117103316-A](https://nimo.iptorch.com/refdrawing/CN-117103316-A/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/CN-117103316-A/pdf003.png)

![Sketch 4 for CN-117103316-A](https://nimo.iptorch.com/refdrawing/CN-117103316-A/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/CN-117103316-A/pdf004.png)

![Sketch 5 for CN-117103316-A](https://nimo.iptorch.com/refdrawing/CN-117103316-A/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/CN-117103316-A/pdf005.png)

![Sketch 6 for CN-117103316-A](https://nimo.iptorch.com/refdrawing/CN-117103316-A/pdf005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/CN-117103316-A/pdf006.png)

![Sketch 7 for CN-117103316-A](https://nimo.iptorch.com/refdrawing/CN-117103316-A/pdf006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/CN-117103316-A/pdf007.png)

![Sketch 8 for CN-117103316-A](https://nimo.iptorch.com/refdrawing/CN-117103316-A/pdf007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/CN-117103316-A/pdf008.png)

![Sketch 9 for CN-117103316-A](https://nimo.iptorch.com/refdrawing/CN-117103316-A/pdf008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/CN-117103316-A/pdf009.png)

![Sketch 10 for CN-117103316-A](https://nimo.iptorch.com/refdrawing/CN-117103316-A/pdf009.png)

## Claims

### Claim 1 (independent)

The utility model provides a glass goods processing is with sucking disc formula manipulator, includes mounting panel (1), sucking disc (2) and arm body (6), sucking disc (2) are installed in mounting panel (1) bottom, its characterized in that: the connecting device is characterized in that a connecting column (3) is arranged at the top of the mounting plate (1), a top plate (4) is arranged at the top of the connecting column (3), a connecting frame (5) is arranged in the middle of the top end of the top plate (4), a connecting bearing (51) connected with a mechanical arm body (6) is arranged in the connecting frame (5), and a limiting block (52) used for limiting the connecting bearing (51) is arranged in the connecting frame (5); the air guide cylinder (7) is fixedly arranged in the mounting plate (1), the end part of the air guide cylinder (7) is communicated with the sucker (2), the transmission rod (8) is slidably arranged in the air guide cylinder (7), the end part of the transmission rod (8) is positioned in the sucker (2), a piston (9) which is slidably connected with the air guide cylinder (7) is arranged in the middle of the transmission rod (8), a reset spring (10) which is connected with the top plate (4) is arranged at the top of the transmission rod (8), a guide block (12) is arranged on the outer wall of the top of the transmission rod (8), a supporting block (14) for limiting the guide block (12) is arranged above the mounting plate (1), a driving roller (141) is arranged on the outer wall of the supporting block (14), an air cylinder (19) is slidably arranged in the middle of the top plate (4), a pressing plate (20) is arranged at the bottom end of the air cylinder (19), and a guide frame (18) for guiding the driving roller (141) is arranged at the bottom end of the pressing plate (20). The exhaust pipe (71) is fixedly arranged on the outer wall of the end part of the air guide cylinder (7), the top of the mounting plate (1) is provided with a push type exhaust valve (72) communicated with the exhaust pipe (71), the top of the push type exhaust valve (72) is provided with a valve rod (73), and the end part of the valve rod (73) is positioned below the guide frame (18).

### Claim 2

The chuck manipulator for glass product processing according to claim 1, wherein: the limiting block (52) is of a rectangular structural design, and a limiting groove (53) corresponding to the limiting block (52) is formed in the outer wall of the connecting frame (5) in a penetrating mode.

### Claim 3

The chuck manipulator for glass product processing according to claim 1, wherein: the section of the air guide cylinder (7) is of a T-shaped design, the diameter of an inner cavity of the air guide cylinder (7) in sliding connection with the piston (9) is larger than the inner diameter of an inner cavity of the air guide cylinder connected with the sucker (2), and the depth of the inner cavity of the air guide cylinder (7) for the piston (9) to slide is larger than the sliding length of the transmission rod (8).

### Claim 4

The chuck manipulator for glass product processing according to claim 1, wherein: the section of the transmission rod (8) is of a T-shaped design, the diameter of the top of the transmission rod (8) is larger than that of the reset spring (10), and an air guide groove (81) is formed in the outer wall of the transmission rod (8).

### Claim 5

The chuck manipulator for glass product processing according to claim 1, wherein: the air guide cylinders (7) are symmetrically arranged in the mounting plate (1), a plurality of groups of telescopic rods (11) connected with the top end of the transmission rod (8) and the ground of the top plate (4) are arranged above the air guide cylinders (7), and the reset springs (10) are sleeved on the outer walls of the telescopic rods (11).

### Claim 6

The chuck manipulator for glass product processing according to claim 1, wherein: the mounting bracket (13) is installed at mounting panel (1) top, and supporting shoe (14) slidable mounting is at mounting bracket (13) outer wall to supporting shoe (14) are located guide block (12) top, and buffer roller (15) that contacts with guide block (12) top are installed in rotation of supporting shoe (14) tip moreover.

### Claim 7

The chuck manipulator for glass product processing of claim 6, wherein: the top corners of the guide blocks (12) are of an oblique angle design, and the buffer rollers (15) are extruded by the oblique angles of the end parts of the guide blocks (12) when the guide blocks move upwards.

### Claim 8

The chuck manipulator for glass product processing of claim 6, wherein: a plurality of groups of limiting rods (16) which are in sliding connection with the supporting blocks (14) are arranged in the mounting frame (13), and pressure springs (17) connected with the supporting blocks (14) and the mounting frame (13) are sleeved on the outer walls of the limiting rods (16).

### Claim 9

The chuck manipulator for glass product processing according to claim 1, wherein: the driving rollers (141) are symmetrically arranged on the outer walls of the two sides of the supporting block (14), the guide frames (18) are of inverted U-shaped design corresponding to the driving rollers (141), and corners, close to the driving rollers (141), of the bottom ends of the guide frames (18) are of oblique angle design.

### Claim 10

The chuck manipulator for glass product processing according to claim 1, wherein: the bottom of the pressing plate (20) is provided with a plurality of groups of guide frames (18) for extruding the driving roller (141), and the extension lengths of the starting output ends of the air cylinders (19) for driving the pressing plate (20) are the same each time.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGHAND TOOLS; PORTABLE POWER-DRIVEN TOOLS; MANIPULATORSMANIPULATORS; CHAMBERS PROVIDED WITH MANIPULATION DEVICESGripping heads and other end effectorsGripping heads and other end effectors with vacuum or magnetic holding meansGripping heads and other end effectors with vacuum or magnetic holding means with vacuum

Description

Sucker type manipulator for glass product processing

Technical Field

The invention relates to the field of manipulators, in particular to a sucker type manipulator for processing glass products.

Background

The mechanical arm is the earliest industrial robot, and is also the earliest modern robot, and can be divided into hydraulic, pneumatic, electric and mechanical according to the driving mode, and is characterized by that it can be programmed to implement various expected operations, and its structure and performance have the advantages of both human and mechanical hand device, and can be used for replacing heavy work of human to implement mechanization and automation of production, and can be operated under harmful environment to protect personal safety, so that it can be extensively used in the departments of mechanical manufacture, metallurgy, electronics, light industry and atomic energy, etc..

The glass board is in production and processing, also can use the manipulator, there is sucking disc formula manipulator in the manipulator of being applied to glass board production and use, it mainly utilizes the adsorption affinity of negative pressure sucking disc to fix, snatch and transport glass, it mainly comprises parts such as manipulator arm body, mounting frame, sucking disc and vacuum pump, wherein, mounting frame installs at manipulator arm body tip, the vacuum pump is installed at manipulator arm body outer wall or inside, the sucking disc is located mounting frame's bottom, the sucking disc is connected with the vacuum pump through the air duct simultaneously, the vacuum pump starts when using, increase the adsorption affinity between sucking disc and the glass board through the air duct, thereby reach the operation of fixing to the glass board, snatch and transport, when needing to release the glass board, the manipulator can eliminate the negative pressure under the sucking disc through closing the air supply, this will reduce adsorption affinity, make glass board and sucking disc separation, accomplish the release glass board.

However, when the above-mentioned sucker type manipulator for glass plate production and processing is actually used, because the vacuum pump pumps out the gas through the mechanical or physical principle to form a vacuum environment, when the vacuum pump needs to consume a large amount of electric energy during starting, and when the sucker type manipulator is used for transferring the glass plate, in order to achieve the purpose of smoothly taking and releasing the glass plate, the vacuum pump needs to be frequently started and closed, so that the sucker type manipulator has larger energy consumption, and when the sucker type manipulator stops, the residual gas in the pump can also cause corrosion and damage to the pump body, therefore, the frequent start and stop can have serious influence on the service life and performance of the vacuum pump, particularly the glass plate with smaller volume and lighter weight is manufactured, and meanwhile, the glass plate manufacturer with smaller factory body volume can greatly increase the production cost of the glass plate produced by the factory, so that when the manufacturer selects the manipulator for transferring the glass, the sucker type manipulator is not frequently listed as the sucker type manipulator, and in order to develop the sucker type manipulator and ensure that the glass plate is manufactured with smaller volume and lighter weight, and the sucker type manipulator with smaller factory body can be improved.

Disclosure of Invention

Accordingly, an object of the present invention is to provide a chuck manipulator for glass product processing, which solves the above-mentioned technical problems in the prior art.

In order to achieve the above purpose, the present invention provides the following technical solutions: the sucker type manipulator for glass product processing comprises a mounting plate, a sucker and a mechanical arm body, wherein the sucker is mounted at the bottom of the mounting plate, a connecting column is mounted at the top of the mounting plate, a top plate is mounted at the top of the connecting column, a connecting frame is mounted in the middle of the top end of the top plate, a connecting bearing connected with the mechanical arm body is arranged in the connecting frame, and a limiting block used for limiting the connecting bearing is mounted in the connecting frame;

the air guide cylinder is fixedly arranged in the mounting plate, the end part of the air guide cylinder is communicated with the sucker, a transmission rod is slidably arranged in the air guide cylinder, the end part of the transmission rod is positioned in the sucker, a piston which is slidably connected with the air guide cylinder is arranged in the middle of the transmission rod, a reset spring which is connected with the top plate is arranged at the top of the transmission rod, a guide block is arranged on the outer wall of the top of the transmission rod, a supporting block for limiting the guide block is arranged above the mounting plate, a transmission roller is arranged on the outer wall of the supporting block, an air cylinder is slidably arranged in the middle of the top plate, a pressing plate is arranged at the bottom end of the air cylinder, and a guide frame for guiding the transmission roller is arranged at the bottom end of the pressing plate;

the exhaust pipe is fixedly arranged on the outer wall of the end part of the air guide cylinder, the top of the mounting plate is provided with a push type exhaust valve communicated with the exhaust pipe, the top of the push type exhaust valve is provided with a valve rod, and the end part of the valve rod is positioned below the guide frame.

By adopting the technical scheme, the suction effect between the suction cup and the glass plate is effectively improved under the action of the piston and the transmission rod, so that the suction cup can absorb the glass plate, and meanwhile, the suction cup mainly aims at the small-size and light-weight glass plate to transport, so that the suction cup has enough suction force to fix and take the glass plate, the use of a vacuum pump is omitted, the energy consumption during use is reduced, the use cost is lower, the suction cup is suitable for use in a glass factory with smaller body quantity, the suction cup cannot slide downwards in the process of transporting the glass plate under the action of the guide block and the support block, the suction effect of the suction cup on the glass plate is guaranteed at the moment, and meanwhile, under the action of the guide frame, the transmission roller, the exhaust pipe, the pressing type exhaust valve and the valve rod, the transmission rod is prevented from being limited when the guide frame descends, and meanwhile, the negative pressure between the suction cup and the glass plate is eliminated, so that the suction cup can be smoothly separated from the glass plate, and the suction cup can be smoothly fixed, grabbed, carried and carried.

The invention further provides that the limiting block is of a rectangular structural design, and the outer wall of the connecting frame is provided with a limiting groove corresponding to the limiting block in a penetrating way.

Through adopting above-mentioned technical scheme, prevent that the arm body from driving the mounting panel when the motion, mounting panel, roof and sucking disc appear rocking, cause the influence to the stability that the sucking disc adsorbed the glass board.

The invention is further arranged that the section of the air guide cylinder is of a T-shaped design, the diameter of the inner cavity of the air guide cylinder, which is in sliding connection with the piston, is larger than the inner diameter of the inner cavity of the air guide cylinder, which is connected with the sucker, and the depth of the inner cavity of the air guide cylinder, which is used for the piston to slide, is larger than the sliding length of the transmission rod.

Through adopting above-mentioned technical scheme for the piston can inhale the gas between a large amount of sucking discs and the glass board in the gas guide cylinder when upward movement, so as to improve the adsorption affinity of sucking disc to the glass board.

The invention is further arranged that the section of the transmission rod is of a T-shaped design, the diameter of the top of the transmission rod is larger than that of the reset spring, and the outer wall of the transmission rod is provided with an air guide groove.

By adopting the technical scheme, the gas between the sucker and the glass plate can enter the gas guide cylinder through the gas guide groove.

The invention is further characterized in that a plurality of groups of air guide cylinders are symmetrically arranged in the mounting plate, telescopic rods connected with the top end of the transmission rod and the ground of the top plate are arranged above the plurality of groups of air guide cylinders, and the reset spring is sleeved on the outer wall of the telescopic rods.

Through adopting above-mentioned technical scheme, ensure the stability of transfer line when sliding and guarantee reset spring's life.

The invention is further characterized in that the mounting frame is arranged at the top of the mounting plate, the supporting block is slidably arranged on the outer wall of the mounting frame, the supporting block is positioned above the guide block, and the end part of the supporting block is rotatably provided with the buffer roller which is contacted with the top end of the guide block.

Through adopting above-mentioned technical scheme, under the effect of mounting bracket, ensure the stability of supporting shoe when sliding.

The invention further provides that the top corners of the guide blocks are designed with oblique angles, and the oblique angles of the end parts of the guide blocks squeeze the buffer roller when the guide blocks move upwards.

By adopting the technical scheme, the buffer roller can smoothly obtain the power given by the guide block.

The invention is further characterized in that a plurality of groups of limiting rods which are in sliding connection with the supporting blocks are arranged in the mounting frame, and the outer wall of each limiting rod is sleeved with a pressure spring which is connected with the supporting blocks and the mounting frame.

By adopting the technical scheme, the fixability of the running track of the support block during sliding is further ensured.

The invention is further characterized in that two driving rollers are symmetrically arranged on the outer walls of the two sides of the supporting block, the guide frame is of an inverted U-shaped design corresponding to the driving rollers, and corners, close to the driving rollers, of the bottom end of the guide frame are of an oblique angle design.

Through adopting above-mentioned technical scheme, ensure that the driving roller can drive the supporting shoe and go to the mounting bracket in the extrusion of leading to the frame oblique angle.

The invention is further characterized in that a plurality of groups of guide frames for extruding the driving roller are arranged at the bottom of the pressing plate, and the extension lengths of the output ends of the cylinders for driving the pressing plate are the same when the cylinders are started each time.

By adopting the technical scheme, the support block is ensured to smoothly release the limit on the guide block.

In summary, the invention has the following advantages:

the invention effectively improves the adsorption effect between the sucker and the glass plate under the action of the piston and the transmission rod by arranging the air guide cylinder, the transmission rod and the piston, thereby ensuring that the sucker can suck the glass plate, and simultaneously, when the guide frame descends under the action of the guide frame, the transmission roller, the exhaust pipe, the pressing type exhaust valve and the valve rod, the transmission rod is out of limit, and meanwhile, the negative pressure between the sucker and the glass plate is eliminated, so that the sucker can be smoothly separated from the glass plate, and the glass plate can be smoothly fixed, grabbed and carried.

Drawings

FIG. 1 is a schematic structural view of a sucker type manipulator for glass product processing according to the present invention;

FIG. 2 is a cut-away view of the connector of the present invention;

FIG. 3 is a schematic view of a chuck manipulator for glass product processing according to the present invention after the top plate is removed;

FIG. 4 is a schematic view of the structure of FIG. 3 with the mounting plate removed;

FIG. 5 is a diagram showing the connection relationship between the gas cylinder and the exhaust valve according to the present invention;

FIG. 6 is a sectional view of the gas cylinder according to the present invention;

FIG. 7 is a partial cross-sectional view of a drive rod of the present invention;

FIG. 8 is a cut-away view of a drive rod of the present invention;

FIG. 9 is an enlarged view of the invention taken at A in FIG. 4;

fig. 10 is an exploded view of the support block and guide frame of the present invention.

In the figure: 1. a mounting plate; 2. a suction cup; 3. a connecting column; 4. a top plate; 5. a connecting frame; 51. connecting a bearing; 52. a limiting block; 53. a limit groove; 6. a robot arm body; 7. a gas cylinder; 71. an exhaust pipe; 72. a push type exhaust valve; 73. a valve rod; 8. a transmission rod; 81. an air guide groove; 9. a piston; 10. a return spring; 11. a telescopic rod; 12. a guide block; 13. a mounting frame; 14. a support block; 141. a driving roller; 15. a buffer roller; 16. a limit rod; 17. a pressure spring; 18. a guide frame; 19. a cylinder; 20. and (5) pressing plates.

Detailed Description

The technical solutions in the embodiments of the present invention will be clearly and completely described below with reference to the accompanying drawings in the embodiments of the present invention. The embodiments described below by referring to the drawings are illustrative only and are not to be construed as limiting the invention.

Hereinafter, an embodiment of the present invention will be described in accordance with its entire structure.

The sucker type manipulator for glass product processing comprises a mounting plate 1, a sucker 2 and a mechanical arm body 6, wherein the sucker 2 is arranged at the bottom of the mounting plate 1, as shown in fig. 1-10.

Specifically, the connecting column 3 is installed at the top of the mounting plate 1, the top plate 4 is installed at the top of the connecting column 3, the connecting frame 5 is installed in the middle of the top end of the top plate 4, and the connecting bearing 51 connected with the mechanical arm body 6 is arranged in the connecting frame 5, so that the mechanical arm body 6 can drive the top plate 4, the mounting plate 1 and the sucker 2 to move through the connecting bearing 51 and the connecting frame 5 when moving, the limiting block 52 for limiting the connecting bearing 51 is installed in the connecting frame 5, the position of the connecting bearing 51 on the connecting frame 5 can be limited, meanwhile, the limiting block 52 is of a rectangular structural design, the limiting groove 53 corresponding to the limiting block 52 is formed in the outer wall of the connecting frame 5 in a penetrating way, the limiting block 52 and the connecting bearing 51 can not rotate in the connecting frame 5, and the mechanical arm body 6 is prevented from shaking when the mounting plate 1 is driven to move, and the sucker 4 and the sucker 2, and the stability of the sucker 2 for adsorbing the glass plate is influenced; the air cylinder 7 is fixedly arranged in the mounting plate 1, the end part of the air cylinder 7 is communicated with the suction cup 2, so that the suction effect of the suction cup 2 on the glass plate can be improved if the air cylinder 7 is in a negative pressure state, the transmission rod 8 is slidably arranged in the air cylinder 7, and the end part of the transmission rod 8 is positioned in the suction cup 2, so that when the suction cup 2 extrudes the glass plate, the end part of the transmission rod 8 is contacted with the glass plate before the suction cup 2 because the bottom end of the transmission rod 8 is positioned at a lower level than the bottom of the suction cup 2, and the transmission rod 8 is slidably moved in the air cylinder 7 as the mounting plate 1 is continuously lowered, the suction cup 2 is also contacted with the glass plate in the process, meanwhile, the piston 9 slidably connected with the air cylinder 7 is arranged in the middle of the transmission rod 8, so that the transmission rod 8 drives the piston 9 to move upwards under the action of the principle of the piston 9, the invention improves the adsorption effect between the sucker 2 and the glass plate, thereby ensuring that the sucker 2 can suck the glass plate, and simultaneously, because the invention mainly aims at transferring the glass plate with small volume and light weight, the sucker 2 has enough suction force to fix and take the glass plate, thereby omitting the use of a vacuum pump, reducing the energy consumption during the use, leading the use cost of the invention to be lower, being suitable for the use of glass factories with smaller body weight, and the top of the transmission rod 8 is provided with the reset spring 10 connected with the top plate 4, the reset spring 10 can be extruded when the transmission rod 8 slides upwards, so that when the transmission rod 8 loses the extrusion force, the reset spring 10 can reset the transmission rod 8 by utilizing the characteristics of the reset spring, ensuring that the transmission rod 8 can be smoothly reset and put into use again during the use, and the guide block 12 is arranged on the outer wall of the top of the transmission rod 8, so that the transmission rod 8 can drive the guide block 12 to synchronously move when moving, the support block 14 for limiting the guide block 12 is arranged above the mounting plate 1, when the transmission rod 8 upwards slides to the limit position, the position of the bottom end of the guide block 12 at the moment corresponds to the position of the support block 14, the support block 14 at the moment can be abutted against the bottom of the guide block 12, the guide block 12 at the moment can not slide downwards, in the process of transferring the glass plate, the transmission rod 8 can not slide downwards, the adsorption effect of the sucking disc 2 on the glass plate at the moment is ensured, the transmission roller 141 is arranged on the outer wall of the support block 14, the opposite side can be driven to synchronously slide when any one of the support block 14 and the transmission roller 141 obtains sliding power, the cylinder 19 is slidably arranged in the middle of the top plate 4, when the mounting plate 1 can not descend after the glass plate is transported to the designated position, the air cylinder 19 can be started under the control of the control system, the pressing plate 20 is arranged at the bottom end of the air cylinder 19, the air cylinder 19 can push the pressing plate 20 to synchronously descend when being started, the guide frame 18 for guiding the driving roller 141 is arranged at the bottom end of the pressing plate 20, the driving roller 141 is extruded under the thrust action given by the pressing plate 20 to force the driving roller 141 to drive the supporting block 14 to slide, so that the supporting block 14 can be separated from the guiding block 12, the limit of the driving rod 8 can be released after the glass plate is transported to a platform for placing the glass plate or other positions for placing the glass plate, the driving rod 8 at the moment can start to drive the piston 9 to push the gas in the gas guide cylinder 7 outwards under the action of the reset spring 10 to release the adsorption force between the sucking disc 2 and the glass plate, after the glass plate is transported to the limiting position, the limit of the suction cup 2 on the glass plate can be automatically removed, the original vacuum pump is replaced by a mechanical mechanism, the air exhaust pipe 71 is more energy-saving in use, the air exhaust pipe 71 is fixedly arranged on the outer wall of the end part of the air guide pipe 7, the air in the air guide pipe 7 can be exhausted into the air exhaust pipe 71, the pressing type air exhaust valve 72 communicated with the air exhaust pipe 71 is arranged at the top of the mounting plate 1, the air in the air guide pipe 7 can be exhausted through the air exhaust pipe 71 and the pressing type air exhaust valve 72 when the pressing type air exhaust valve 72 is opened, the negative pressure between the suction cup 2 and the glass plate is eliminated, the suction cup 2 can be smoothly separated from the glass plate, the valve rod 73 is arranged at the top of the pressing type air exhaust valve 72, the end part of the valve rod 73 is positioned below the guide frame 18, the air exhaust valve 72 can be extruded in the descending process of the guide frame 18, and the pressing type air exhaust valve 72 can be started along with the descending of the guide frame 18.

Referring to fig. 2-6, the cross section of the air cylinder 7 is of a T-shape, and the diameter of the inner cavity of the air cylinder 7 slidably connected with the piston 9 is larger than the inner diameter of the inner cavity connected with the suction cup 2, so that when the piston 9 moves upwards, a large amount of air between the suction cup 2 and the glass plate is sucked into the air cylinder 7, thereby improving the adsorption force of the suction cup 2 on the glass plate, and the depth of the inner cavity of the air cylinder 7 for sliding the piston 9 is larger than the slidable length of the transmission rod 8, so that enough space is ensured in the air cylinder 7 for sliding the piston 9.

Referring to fig. 3-8, the section of the transmission rod 8 is of a T-shaped design, so that the end of the transmission rod 8 cannot completely enter the air guide cylinder 7, the top diameter of the transmission rod 8 is larger than the diameter of the return spring 10, when the transmission rod 8 slides, the top of the transmission rod 8 can smoothly upwards squeeze the return spring 10, an air guide groove 81 is formed in the outer wall of the transmission rod 8, and when the transmission rod 8 drives the piston 9 to move upwards, air between the suction cup 2 and the glass plate can enter the air guide cylinder 7 through the air guide groove 81, and meanwhile, the air guide groove 81 is formed in the outer wall of the transmission rod 8, so that the stability of the transmission rod 8 during sliding is not influenced by the air guide groove 81.

Referring to fig. 1-6 and 8, a plurality of groups of air guide cylinders 7 are symmetrically installed in a mounting plate 1, the plurality of groups of air guide cylinders 7 synchronously increase the adsorption effect of a plurality of groups of suckers 2 on a glass plate, so that the glass plate can be smoothly rotated, and telescopic rods 11 connected with the top end of a transmission rod 8 and the ground of a top plate 4 are arranged above the plurality of groups of air guide cylinders 7, so that when the transmission rod 8 moves upwards, the telescopic rods 11 start to stretch, the sliding of the transmission rod 8 is limited by the telescopic rods 11 at the moment, the stability of the transmission rod 8 during sliding is further ensured, and a return spring 10 is sleeved on the outer wall of the telescopic rods 11, so that the return spring 10 is supported by the telescopic rods 11 when the return spring 10 is extruded, and the outward explosion deformation of the return spring 10 after the compression is prevented, and the accident that the service life of the return spring 10 is shorter is caused.

Referring to fig. 2-4 and 8-10, the mounting frame 13 is mounted on top of the mounting plate 1, and the supporting block 14 is slidably mounted on the outer wall of the mounting frame 13, so that the supporting block 14 is supported and limited by the mounting frame 13, stability of the supporting block 14 during sliding is ensured, the supporting block 14 is located above the guide block 12, the end of the supporting block 14 is rotatably provided with the buffer roller 15 contacting with the top end of the guide block 12, and the corner of the top end of the guide block 12 is designed to be oblique, so that the buffer roller 15 can be extruded by the oblique angle of the end of the guide block 12 when the guide block 12 moves upwards, power given by the guide block 12 can be successfully obtained by the buffer roller 15, and meanwhile, the buffer roller 15 can also rotate when being extruded by the guide block 12, so that abrasion of the guide block 12 and the buffer roller 15 when contacting is reduced.

Referring to fig. 8-10, the bottom corners of the guide block 12 are designed to be oblique angles, so that when the guide block 12 slides upwards to the limit, the top surface of the guide block 12 and the bottom surface of the support block 14 are located at the same horizontal plane, so that the oblique angles at the bottom of the guide block 12 guide the support block 14, ensuring that the support block 14 can slide smoothly to the bottom of the guide block 12, and meanwhile, the two side corners of the end of the buffer roller 15 installed on the support block 14 are designed to be arc angles, so that the arc angles of the end of the support block 14 guide the support block 14 when sliding to the bottom of the guide block 12, further preventing the support block 14 from colliding with or being blocked between the corners of the guide block 12 when sliding to the guide block 12, and further ensuring that the support block 14 can slide smoothly to the bottom of the guide block 12 to support and limit the support.

Referring to fig. 5 and 8-10, a plurality of groups of limiting rods 16 slidably connected with the supporting blocks 14 are installed in the mounting frame 13, so that the supporting blocks 14 are limited by the limiting rods 16 when sliding, the fixability of the running track of the supporting blocks 14 when sliding is further ensured, and a pressure spring 17 connected with the supporting blocks 14 and the mounting frame 13 is sleeved on the outer wall of the limiting rods 16, so that the pressure spring 17 is extruded when the supporting blocks 14 slide into the mounting frame 13, and the supporting blocks 14 can be pushed outwards by the pressure spring 17 when the positions of the supporting blocks 14 and the guiding blocks 12 are staggered, so that the supporting blocks 14 can obtain power sliding to the bottoms of the guiding blocks 12.

Referring to fig. 5 and fig. 8-10, two driving rollers 141 are symmetrically installed on the outer walls of two sides of the supporting block 14, so that the two driving rollers 141 can simultaneously drive the supporting block 14 to slide after being extruded, further ensuring that the supporting block 14 can slide smoothly, and the guide frame 18 is in a inverted U-shaped design corresponding to the position of the driving rollers 141, so that the guide frame 18 can synchronously extrude the two driving rollers 141 when descending, and meanwhile, because the corner of the bottom end of the guide frame 18, which is close to the driving rollers 141, is in an oblique angle design, the position of the guide frame 18 for extruding the driving rollers 141 is in an oblique angle position of the guide frame 18, so that the driving rollers 141 can drive the supporting block 14 to slide towards the mounting frame 13 under the extrusion of the oblique angle of the guide frame 18, and the limit of the driving rod 8 can be smoothly lost to slide downwards when the glass plate is required to be separated from the sucker 2.

Referring to fig. 1-8, a plurality of groups of guide frames 18 for extruding the driving roller 141 are installed at the bottom of the pressing plate 20, so that when the pressing plate 20 descends, the plurality of groups of guide frames 18 are driven to descend synchronously, so that the plurality of groups of support blocks 14 are separated from the guide blocks 12 synchronously, the guide blocks 12 are ensured to lose restriction, and the extension length of the output end of each start of the air cylinder 19 for driving the pressing plate 20 is the same, so that after each start of the air cylinder 19, the guide frames 18 can extrude and restrict the driving roller 141, the support blocks 14 can smoothly remove the restriction on the guide blocks 12, and the driving rod 8, the guide blocks 12 and the pressing plate 20 are hollow, so that the weight of the driving rod 8, the guide blocks 12 and the pressing plate 20 is relatively light, thereby reducing the resistance of the driving rod 8, the guide blocks 12 and the pressing plate 20 in resetting, ensuring that the driving rod 8, the guide blocks 12 and the pressing plate 20 can be smoothly reset after being used, and meanwhile, the end part of the driving rod 8, which contacts with a glass plate, is of the rubber design, so that the end part of the driving rod 8 is in contact with the glass plate does not cause serious damage to the glass plate when contacting with the glass plate.

The working principle of the invention is as follows: when the invention is used, the mounting plate 1 is moved to the upper part of the glass plate by starting the mechanical arm body 6, then the mechanical arm body 6 drives the mounting plate 1 to move downwards, so that the end part of the transmission rod 8 is in contact with the glass plate, the transmission rod 8 cannot continuously descend, the end part of the transmission rod 8 gradually enters the air guide cylinder 7 along with the continuous descending of the mounting plate 1, in the process, the sucker 2 is contacted with the glass plate, the piston 9 sucks the gas between the sucker 2 and the glass plate into the air guide cylinder 7, thereby increasing the adsorption effect of the sucker 2 on the glass plate, ensuring that the sucker 2 has enough suction force to fix and take the glass plate, thereby omitting the use of a vacuum pump, reducing the energy consumption during the use, ensuring that the invention has lower use cost and smaller suitable body quantity, and driving the mounting frame 13 to synchronously descend along with the continuous descending process of the mounting plate 1, so that the buffer roller 15 at the end part of the supporting block 14 can contact with the glass plate, the oblique angle at the bottom of the guiding block 12, so that the supporting block 14 is abutted against the supporting block 13 to stop the sucking the gas between the sucker 2 and the glass plate, and the sliding block 12 can not be synchronously moved to the sliding block 12 when the supporting the mounting plate 1 is driven by the sliding block 12, and the sliding block 12 is prevented from moving down, and the sliding block 12 can not be contacted with the glass plate 12, and the sliding block 12 can not be continuously moved to the bottom the supporting the mounting plate 12 when the mounting plate is driven by the mounting plate 12;

when the glass plate is put down, firstly, the mechanical arm body 6 can place the glass plate on the ground or at other placing positions through the mounting plate 1, so that the glass plate cannot continue to move downwards, then the air cylinder 19 can be started under the control of the control system, the pressing plate 20 drives the guide frame 18 to slide downwards, the driving roller 141 at the moment can drive the supporting block 14 to slide away towards the mounting frame 13 under the action of the guide frame 18, the end part of the supporting block 14 is separated from the guide block 12, so that the driving rod 8 at the moment can slide, the end part of the driving rod 8 can squeeze the valve rod 73 when the guide frame 18 slides downwards, so that the push type exhaust valve 72 can be started along with the descending of the guide frame 18, at the moment, the air in the air guide cylinder 7 can be discharged through the exhaust pipe 71 and the push type exhaust valve 72, so that the negative pressure between the sucking disc 2 and the glass plate is eliminated, the sucking disc 2 can be smoothly separated from the glass plate, and the driving rod 8 at the moment can reset under the action of the reset spring 10 along with the beginning of the mechanical arm body 6, and the subsequent continuous use can be ensured.

Although embodiments of the invention have been shown and described, the detailed description is to be construed as exemplary only and is not limiting of the invention as the particular features, structures, materials, or characteristics may be combined in any suitable manner in any one or more embodiments or examples, and modifications, substitutions, variations, etc. may be made in the embodiments as desired by those skilled in the art without departing from the principles and spirit of the invention, provided that such modifications are within the scope of the appended claims.

## Classifications

- B25J15/0616
- B25J15/06

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
