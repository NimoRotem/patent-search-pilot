# 06. Systems and methods for providing high flow vacuum acquisition in automated systems

- **Archive rank:** 6 of 50
- **Publication:** [US-10857682-B2](https://patents.google.com/patent/US10857682B2/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/056959057/publication/US10857682B2?q=pn%3DUS10857682B2)
- **Publication date:** 2020-12-08
- **Filing date:** 2019-12-05
- **Earliest priority:** 2015-09-08
- **Family:** 56959057
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus

## Parties

- **Applicant / assignee:** BERKSHIRE GREY INC
- **Inventors:** AHEARN KEVIN; ALLEN THOMAS; COHEN BENJAMIN; DAWSON-HAGGERTY Michael; GEYER Christopher; KOLETSCHKA THOMAS; MARONEY Kyle; MASON MATTHEW T; PRICE GENE TEMPLE; ROMANO JOSEPH; SMITH DANIEL; SRINIVASA Siddhartha; VELAGAPUDI PRASANNA; WAGNER THOMAS

## Abstract

A system is disclosed for providing high flow vacuum control to an end effector of an articulated arm. The system includes a high flow vacuum source that provides an opening with an area of high flow vacuum at the end effector such that objects may be engaged while permitting substantial flow of air through the opening, and a load detection system for characterizing the load presented by the object.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-10857682-B2/000.png)

![Sketch 1 for US-10857682-B2](https://nimo.iptorch.com/refdrawing/US-10857682-B2/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/US-10857682-B2/001.png)

![Sketch 2 for US-10857682-B2](https://nimo.iptorch.com/refdrawing/US-10857682-B2/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/US-10857682-B2/002.png)

![Sketch 3 for US-10857682-B2](https://nimo.iptorch.com/refdrawing/US-10857682-B2/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/US-10857682-B2/003.png)

![Sketch 4 for US-10857682-B2](https://nimo.iptorch.com/refdrawing/US-10857682-B2/003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/US-10857682-B2/004.png)

![Sketch 5 for US-10857682-B2](https://nimo.iptorch.com/refdrawing/US-10857682-B2/004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/US-10857682-B2/005.png)

![Sketch 6 for US-10857682-B2](https://nimo.iptorch.com/refdrawing/US-10857682-B2/005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/US-10857682-B2/006.png)

![Sketch 7 for US-10857682-B2](https://nimo.iptorch.com/refdrawing/US-10857682-B2/006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/US-10857682-B2/007.png)

![Sketch 8 for US-10857682-B2](https://nimo.iptorch.com/refdrawing/US-10857682-B2/007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/US-10857682-B2/008.png)

![Sketch 9 for US-10857682-B2](https://nimo.iptorch.com/refdrawing/US-10857682-B2/008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/US-10857682-B2/009.png)

![Sketch 10 for US-10857682-B2](https://nimo.iptorch.com/refdrawing/US-10857682-B2/009.png)

[Sketch 11](https://nimo.iptorch.com/refdrawing/US-10857682-B2/010.png)

![Sketch 11 for US-10857682-B2](https://nimo.iptorch.com/refdrawing/US-10857682-B2/010.png)

[Sketch 12](https://nimo.iptorch.com/refdrawing/US-10857682-B2/011.png)

![Sketch 12 for US-10857682-B2](https://nimo.iptorch.com/refdrawing/US-10857682-B2/011.png)

[Sketch 13](https://nimo.iptorch.com/refdrawing/US-10857682-B2/012.png)

![Sketch 13 for US-10857682-B2](https://nimo.iptorch.com/refdrawing/US-10857682-B2/012.png)

## Claims

### Claim 1 (independent)

A system for providing high flow vacuum control to an end effector of an articulated arm, said system comprising a high flow vacuum source that provides a high flow vacuum at a contact surface at a distal side of the end effector such that an object is engageable at the contact surface for movement by the articulated arm while permitting substantial flow of air through the contact surface, wherein the contact surface includes a central region, and wherein the contact surface includes a plurality of openings, said plurality of openings providing more air flow at the central region of the contact surface than at a peripheral region of the contact surface, wherein the contact surface includes a cover that provides the plurality of openings therein.

### Claim 2

The system as claimed in claim 1 , wherein the plurality of openings include a larger number of openings at the central region than at the peripheral region of the contact surface.

### Claim 3

The system as claimed in claim 1 , wherein the plurality of openings include larger openings at the central region than at the peripheral region of the contact surface.

### Claim 4

The system as claimed in claim 1 , wherein the plurality of openings are more concentrated at the central region than at the peripheral region of the contact surface.

### Claim 5

The system as claimed in claim 1 , wherein the high flow vacuum source includes a blower.

### Claim 6

The system as claimed in claim 1 , wherein vacuum pressure is no more than about 50,000 Pascals below atmospheric.

### Claim 7

The system as claimed in claim 1 , wherein a maximum air flow rate is at least about 100 cubic feet per minute.

### Claim 8

The system as claimed in claim 1 , wherein the system determines whether to maintain a grasp on an object responsive to a load detection system that characterizes a load presented by the object.

### Claim 9

The system as claimed in claim 8 , wherein the load detection system monitors load weight.

### Claim 10

The system as claimed in claim 8 , wherein the load detection system monitors load balance.

### Claim 11

The system as claimed in claim 1 , wherein the plurality of openings in the cover include a plurality of slit openings.

### Claim 12

The system as claimed in claim 1 , wherein the plurality of openings in the cover include a plurality of square openings.

### Claim 13

The system as claimed in claim 1 , wherein the plurality of openings in the cover include a plurality of circular openings.

### Claim 14

The system as claimed in claim 1 , wherein the plurality of openings in the cover include an cross-shaped opening in the central region and a plurality of slit openings in the peripheral region.

### Claim 15 (independent)

A system for providing high flow vacuum control to an end effector of an articulated arm, said system comprising a high flow vacuum source that provides a high flow vacuum at a contact surface at a distal side of the end effector such that an object is engageable at the contact surface for movement by the articulated arm while permitting substantial flow of air through the contact surface, wherein the contact surface includes a cover with a central region, and wherein the cover includes a plurality of openings, said plurality of openings providing restricted air flow at a peripheral region of the cover as compared to air flow at the central region of the cover.

### Claim 16

The system as claimed in claim 15 , wherein the plurality of openings include a larger number of openings at the central region than at the peripheral region of the contact surface.

### Claim 17

The system as claimed in claim 15 , wherein the plurality of openings include larger openings at the central region that at the peripheral region of the contact surface.

### Claim 18

The system as claimed in claim 15 , wherein the plurality of openings are more concentrated at the central region than at the peripheral region of the contact surface.

### Claim 19

The system as claimed in claim 15 , wherein the high flow vacuum source includes a blower.

### Claim 20

The system as claimed in claim 15 , wherein vacuum pressure is no more than about 50,000 Pascals below atmospheric.

### Claim 21

The system as claimed in claim 15 , wherein a maximum air flow rate is at least about 100 cubic feet per minute.

### Claim 22

The system as claimed in claim 15 , wherein the cover includes a compliant outwardly facing material.

### Claim 23

The system as claimed in claim 15 , wherein the system includes a load detection system that characterizes a load presented by the object.

### Claim 24

The system as claimed in claim 23 , wherein the system determines whether to maintain a grasp on an object responsive to the load detection system that characterizes the load presented by the object.

### Claim 25

The system as claimed in claim 24 , wherein the load detection system monitors load weight.

### Claim 26

The system as claimed in claim 24 , wherein the load detection system monitors load balance.

### Claim 27

The system as claimed in claim 15 , wherein the plurality of openings in the cover include a plurality of slit openings.

### Claim 28

The system as claimed in claim 15 , wherein the plurality of openings in the cover include a plurality of square openings.

### Claim 29

The system as claimed in claim 15 , wherein the plurality of openings in the cover include a plurality of circular openings.

### Claim 30

The system as claimed in claim 15 , wherein the plurality of openings in the cover include an cross-shaped opening in the central region and a plurality of slit openings in the peripheral region.

### Claim 31 (independent)

A method of engaging and moving a load presented by an object at an end effector in a high flow vacuum system, said method comprising: providing a high flow vacuum at a contact surface of the end effector; engaging the object at the contact surface while permitting substantial flow of air through the contact surface, wherein the contact surface includes a central region, and wherein the contact surface includes a plurality of openings, said plurality of openings providing more air flow at the central region of the contact surface than at a peripheral region of the contact surface, the contact surface including a cover that provides the plurality of openings therein; and moving the engaged object using the end effector.

### Claim 32

The method as claimed in claim 31 , wherein the plurality of openings include a larger number of openings at the central region than at the peripheral region of the contact surface.

### Claim 33

The method as claimed in claim 31 , wherein the plurality of openings include larger openings at the central region that at the peripheral region of the contact surface.

### Claim 34

The method as claimed in claim 31 , wherein the plurality of openings are more concentrated at the central region than at the peripheral region of the contact surface.

### Claim 35

The method as claimed in claim 31 , wherein the high flow vacuum system includes a blower.

### Claim 36

The method as claimed in claim 31 , wherein vacuum pressure is no more than about 50,000 Pascals below atmospheric.

### Claim 37

The method as claimed in claim 31 , wherein a maximum air flow rate is at least about 100 cubic feet per minute.

### Claim 38

The method as claimed in claim 31 , wherein the method further includes determining whether to maintain a grasp on an object responsive to a load detection system that characterizes a load presented by the object.

### Claim 39

The method as claimed in claim 38 , wherein the load detection system monitors load weight.

### Claim 40

The method as claimed in claim 38 , wherein the load detection system monitors load balance.

### Claim 41

The method as claimed in claim 31 , wherein the plurality of openings in the cover include a plurality of slit openings.

### Claim 42

The method as claimed in claim 31 , wherein the plurality of openings in the cover include a plurality of square openings.

### Claim 43

The method as claimed in claim 31 , wherein the plurality of openings in the cover include a plurality of circular openings.

### Claim 44

The method as claimed in claim 31 , wherein the plurality of openings in the cover include an cross-shaped opening in the central region and a plurality of slit openings in the peripheral region.

### Claim 45 (independent)

A method of engaging and moving a load presented by an object at an end effector in a high flow vacuum system, said method comprising: providing a high flow vacuum at a contact surface of the end effector; engaging the object at the contact surface while permitting substantial flow of air through the contact surface, wherein the contact surface includes a cover with a central region, and wherein the cover includes a plurality of openings, said plurality of openings providing restricted flow at a peripheral region of the cover as compared to air flow at the central region of the cover; and moving the engaged object using the end effector.

### Claim 46

The method as claimed in claim 45 , wherein the plurality of openings include a larger number of openings at the central region than at the peripheral region of the cover.

### Claim 47

The method as claimed in claim 45 , wherein the plurality of openings include larger openings at the central region that at the peripheral region of the cover.

### Claim 48

The method as claimed in claim 45 , wherein the plurality of openings are more concentrated at the central region than at the peripheral region of the cover.

### Claim 49

The method as claimed in claim 45 , wherein the high flow vacuum system includes a blower.

### Claim 50

The method as claimed in claim 45 , wherein vacuum pressure is no more than about 50,000 Pascals below atmospheric.

### Claim 51

The method as claimed in claim 45 , wherein a maximum air flow rate is at least about 100 cubic feet per minute.

### Claim 52

The method as claimed in claim 45 , wherein the cover includes a compliant outwardly facing material.

### Claim 53

The method as claimed in claim 45 , wherein the system determines whether to maintain a grasp on an object responsive to a load detection system that characterizes a load presented by the object.

### Claim 54

The method as claimed in claim 53 , wherein the load detection system monitors load weight.

### Claim 55

The method as claimed in claim 53 , wherein the load detection system monitors load balance.

### Claim 56

The method as claimed in claim 45 , wherein the plurality of openings in the cover include a plurality of slit openings.

### Claim 57

The method as claimed in claim 45 , wherein the plurality of openings in the cover include a plurality of square openings.

### Claim 58

The method as claimed in claim 45 , wherein the plurality of openings in the cover include a plurality of circular openings.

### Claim 59

The method as claimed in claim 45 , wherein the plurality of openings in the cover include an cross-shaped opening in the central region and a plurality of slit openings in the peripheral region.

### Claim 60 (independent)

A system for providing high flow vacuum control to an end effector of an articulated arm, said system comprising a high flow vacuum source that provides a high flow vacuum at a contact surface at a distal side of the end effector such that an object is engageable at the contact surface for movement by the articulated arm while permitting substantial flow of air through the contact surface, wherein the contact surface includes a central region, and wherein the contact surface includes a plurality of openings, said plurality of openings providing more air flow at the central region of the contact surface than at a peripheral region of the contact surface, the plurality of openings including larger openings at the central region than at the peripheral region of the contact surface.

### Claim 61

The system as claimed in claim 60 , wherein the high flow vacuum source includes a blower.

### Claim 62

The system as claimed in claim 60 , wherein vacuum pressure is no more than about 50,000 Pascals below atmospheric.

### Claim 63

The system as claimed in claim 60 , wherein a maximum air flow rate is at least about 100 cubic feet per minute.

### Claim 64

The system as claimed in claim 60 , wherein the contact surface includes a cover that provides the plurality of openings therein.

### Claim 65

The system as claimed in claim 60 , wherein the system determines whether to maintain a grasp on an object responsive to a load detection system that characterizes a load presented by the object.

### Claim 66

The system as claimed in claim 65 , wherein the load detection system monitors load weight.

### Claim 67

The system as claimed in claim 65 , wherein the load detection system monitors load balance.

### Claim 68

The system as claimed in claim 60 , wherein the plurality of openings in the contact surface include a plurality of slit openings.

### Claim 69

The system as claimed in claim 60 , wherein the plurality of openings in the contact surface include a plurality of square openings.

### Claim 70

The system as claimed in claim 60 , wherein the plurality of openings in the contact surface include an cross-shaped opening in the central region and a plurality of slit openings in the peripheral region.

### Claim 71 (independent)

A method of engaging and moving a load presented by an object at an end effector in a high flow vacuum system, said method comprising: providing a high flow vacuum at a contact surface of the end effector; engaging the object at the contact surface while permitting substantial flow of air through the contact surface, wherein the contact surface includes a central region, and wherein the contact surface includes a plurality of openings, said plurality of openings providing more air flow at the central region of the contact surface than at a peripheral region of the contact surface, the plurality of openings including larger openings at the central region than at the peripheral region of the contact surface; and moving the engaged object using the end effector.

### Claim 72

The method as claimed in claim 71 , wherein the high flow vacuum system includes a blower.

### Claim 73

The method as claimed in claim 71 , wherein vacuum pressure is no more than about 50,000 Pascals below atmospheric.

### Claim 74

The method as claimed in claim 71 , wherein a maximum air flow rate is at least about 100 cubic feet per minute.

### Claim 75

The method as claimed in claim 71 , wherein the contact surface includes a cover that provides the plurality of openings therein.

### Claim 76

The method as claimed in claim 71 , wherein the method further includes determining whether to maintain a grasp on an object responsive to a load detection system that characterizes a load presented by the object.

### Claim 77

The method as claimed in claim 76 , wherein the load detection system monitors load weight.

### Claim 78

The method as claimed in claim 76 , wherein the load detection system monitors load balance.

### Claim 79

The method as claimed in claim 71 , wherein the plurality of openings in the contact surface include a plurality of slit openings.

### Claim 80

The method as claimed in claim 71 , wherein the plurality of openings in the contact surface include a plurality of square openings.

### Claim 81

The method as claimed in claim 71 , wherein the plurality of openings in the contact surface include an cross-shaped opening in the central region and a plurality of slit openings in the peripheral region.

## Full description

### Priority

**[p0001]**

The present application is a continuation of U.S. patent application Ser. No. 16/124,982 filed Sep. 7, 2018, which is a continuation of U.S. patent application Ser. No. 15/260,014 filed Sep. 8, 2016, now U.S. Pat. No. 10,118,300 issued Nov. 6, 2018, which claims priority to U.S. Provisional Patent Application Ser. No. 62/215,489 filed Sep. 8, 2015, as well as U.S. Provisional Patent Application No. Ser. No. 62/262,136 filed Dec. 2, 2015, the disclosures of which are hereby incorporated by reference in their entireties.

### Background

**[p0002]**

The invention generally relates to robotic and other sortation systems, and relates in particular to robotic systems having an articulated arm with an end effector that employs vacuum pressure to engage objects in the environment. Most vacuum grippers employ vacuum pressures well below 50% of atmospheric pressure, and are referred to herein as high vacuum. A typical source for a high vacuum gripper is a Venturi ejector, which produces high vacuum but low maximum air flow. Because of the low flow, it is essential to get a good seal between a vacuum gripper and an object, and it is also important to minimize the volume to be evacuated. Suppliers of ejectors and related system components include Vaccon Company, Inc. of Medway, Mass., Festo US Corporation of Hauppauge, N.Y., Schmalz, Inc. of Raleigh, N.C. and others. In some instances where a good seal is not possible, some systems use high flow devices. Typical high flow devices are air amplifiers and blowers, which produce the desired flows, but cannot produce the high vacuum of a high vacuum source. High flow sources include the side-channel blowers supplied by Elmo Rietschle of Gardner, Denver, Inc. of Quincy, Ill., Fuji Electric Corporation of America of Edison, N.J., and Schmalz, Inc. of Raleigh, N.C. It is also possible to use air amplifiers as supplied by EDCO USA of Fenton, Mo. and EXAIR Corporation of Cincinnati, Ohio. Multistage ejectors are also known to be used to evacuate a large volume more quickly, wherein each stage provides higher levels of flow but lower levels of vacuum.

**[p0003]**

Despite the variety of vacuum systems, however, there remains a need for an end effector in a robotic or other sortation system that is able to accommodate a wide variety of applications, involving engaging a variety of types of items. There is further a need for an end effector that is able to provide high flow and that is able to handle a wide variety of objects weights.

### Summary

**[p0004]**

In accordance with an embodiment, the invention provides a system for providing high flow vacuum control to an end effector of an articulated arm. The system includes a high flow vacuum source that provides an opening with an area of high flow vacuum at the end effector such that objects may be engaged while permitting substantial flow of air through the opening, and a load detection system for characterizing the load presented by the object. In accordance with another embodiment, the invention provides an object acquisition system that includes a high flow vacuum source that provides an opening with an area of high flow vacuum such that objects may be engaged while permitting substantial flow of air through the opening, and a load assessment system that assesses the load responsive to the flow and any of a load weight or load balance. In accordance with a further embodiment, the invention provides a method of characterizing a load presented by an object at an end effector in a high flow vacuum system. The method includes the steps of providing a high flow vacuum at an opening at the end effector, engaging an object at the opening while permitting substantial flow of air through the opening, and characterizing the load presented by the object.

### Brief Description Of The Drawings

**[p0005]**

The following description may be further understood with reference to the accompanying drawings in which: FIG. 1 shows an illustrative block diagrammatic view of a system in accordance with an embodiment of the present invention; FIG. 2 shows an illustrative diagrammatic view of an example of a system of FIG. 1 ; FIGS. 3A and 3B show illustrative diagrammatic views of an end effector of a system of an embodiment of the invention engaging different types of objects; FIG. 4 shows an illustrative diagrammatic view of a detection system together with an end effector of a system of an embodiment of the present invention; FIGS. 5A and 5B show illustrative photographic views of an end effector cover for use in a system of an embodiment of the present invention; FIG. 6 shows an illustrative diagrammatic view of an end effector of an embodiment of the invention engaging an object; FIGS. 7A-7D show illustrative diagrammatic views of other covers for use with end effectors of systems of further embodiments of the present invention;

**[p0006]**

FIGS. 8A and 8B show illustrative diagrammatic views of an end effector in a system of an embodiment of the present invention engaging a relatively light object; FIGS. 9A and 9B show illustrative diagrammatic views of an end effector in a system of an embodiment of the present invention engaging a relatively heavy object; FIGS. 10A and 10B show illustrative diagrammatic views of an end effector in a system of an embodiment of the present invention engaging an object that presents an unbalanced load; FIG. 11 shows an illustrative graphical representation of air flow verses pressure differential for different vacuum sources; FIG. 12 shows an illustrative graphical representation of air flow verses pressure differential for different parameterizations of performance; FIG. 13 shows an illustrative diagrammatic model of an end effector aperture and object in a system in accordance with an embodiment of the present invention; FIG. 14 shows an illustrative diagrammatic end view of the system of FIG. 13 showing the relative areas of the opening;

**[p0007]**

FIG. 15 shows an illustrative diagrammatic side view of the system of FIG. 13 showing flow direction and pressure; FIG. 16 shows an illustrative graphical representation of grip offset from a base versus angle in a system in accordance with an embodiment of the present invention; and FIG. 17 shows illustrative diagrammatic representations of objects being held at the offset points in FIG. 16 . The drawings are shown for illustrative purposes only and are not to scale.

### Detailed Description

**[p0008]**

There are numerous applications for a novel gripping system that could handle a broad variety of objects, varying in size, weight, and surface properties. In accordance with certain embodiments, the invention provides a system for providing high flow vacuum control to an end effector of an articulated arm. In accordance with various embodiments, the invention provides a dynamic high flow gripping system, and may optionally include a mechanism to select between the high flow source and a high vacuum source, depending on the application. High flow vacuum systems of the invention may therefore optionally be used with high vacuum sources. The system, for example, may include a first vacuum source for providing a first vacuum pressure with a first maximum air flow rate; and a second vacuum source for providing a second vacuum pressure with a second maximum air flow rate, wherein the second vacuum pressure is higher than the first vacuum pressure and wherein the second maximum air flow rate is greater than the first maximum air flow rate. The flow rates are characterized as maximum air flow rates because, when an object is engaged at an end effector, the flow rate may drop significantly. The high flow source may be used together with a high vacuum source, or as a single source.

**[p0009]**

FIG. 1 , for example, shows a system 10 in accordance with an embodiment of the present invention in which an optional high vacuum source 12 is provided as well as a high flow source 14 and a release source 16 that are each coupled to a selection unit 18 , that is coupled to an end effector 20 . The selection unit 18 selects between the high vacuum source 12 , high flow source 14 and the release source 16 for providing any of high vacuum, vacuum with high flow, or a release flow to the end effector. FIG. 1 therefore shows a general form of the invention, comprising mechanisms for producing high vacuum and high flow, a release source providing either atmospheric pressure via a vent or high pressure (blow off) via a compressor or reservoir, and a mechanism for selecting the source best suited to the present situation. In particular, FIG. 2 shows a system in accordance with an embodiment of the invention that includes a compressor 30 that is coupled to an ejector 32 to provide a high vacuum source that is coupled to a solenoid valve 34 . A blower 36 is also coupled to the solenoid valve 34 via a non-return valve 38 , and the blower 36 provides a vacuum source with a high maximum flow rate. A vent or blow-off source is also provided to the solenoid valve 34 , the output of which is provided to an end effector 40 . The system therefore, provides the ejector 32 as the high vacuum source, the regenerative blower 36 as the high flow source, the non-return valve 38 as a passive selection mechanism, and the solenoid valve 34 connecting the effector to the release source, either vent

**[p0009]**

or blow-off.

**[p0010]**

The vacuum pressure provided by the ejector 32 may be, for example, at least about 90,000 Pascals below atmospheric and the vacuum pressure provided by the blower 36 may be only no more than about 25,000 Pascals below atmospheric in some examples, and no more than about 50,000 Pascals below atmospheric in other examples. The vacuum pressure provided by the blower 36 is therefore higher than the vacuum pressure provided by the ejector 32 . The maximum air flow rate of the ejector may be, for example, no more than about 5 cubic feet per minute (e.g., 1-2 cubic feet per minute), and the maximum air flow rate of the blower may be, for example at least about 100 cubic feet per minute (e.g., 130-140 cubic feet per minute). For example, with reference to FIG. 3A , if a good seal is formed between an end effector 60 (which may for example, be a tubular or conical shaped bellows) and an object 62 on an articulated arm 64 , then the vacuum pressure may remain high vacuum and low flow. This will provide that the grasp of object 62 will be maintained by the high vacuum with a lower maximum air flow rate. With reference to FIG. 3B , if a good seal is not formed between an end effector 70 and an irregularly shaped object 72 on an articulated arm 74 , then the high flow source will dominate maintaining a high flow, and maintaining a grasp of object 72 with a higher maximum air flow rate.

**[p0011]**

With reference to FIG. 4 , in accordance with a further embodiment, the system may include an articulated arm 80 to which is attached an end effector 82 , again, which may be a tubular or conical shaped bellows. The end effector 82 also includes a sensor 84 that includes an attachment band 86 on the bellows, as well as a bracket 88 attached to magnetic field sensor 84 , and a magnet 92 is mounted on the articulated arm 80 . The bellows may move in any of three directions, e.g., toward and away from the articulated arm as shown diagrammatically at A, in directions transverse to the direction A as shown at B, and directions partially transverse to the direction A as shown at C. The magnetic field sensor 84 may communicate (e.g., wirelessly) with a controller 90 , which may also communicate with a flow monitor 94 to determine whether a high flow grasp of an object is sufficient for continued grasp and transport as discussed further below. In an embodiment, for example, the system may return the object if the air flow is insufficient to carry the load, or may increase the air flow to safely maintain the load.

**[p0012]**

During low vacuum/high flow use, a specialized end effector may be used that provides improved grasping of long narrow objects. Certain grippers that are designed for high flow use to acquire and hold an object generally require large apertures in order to obtain an air flow rate that is high enough to be useful for object acquisition. One drawback of some such grippers in certain applications, is that the object to be acquired may be small, not so small that each of its dimensions is smaller than the high flow opening, but small enough that certain of an object&#39;s dimensions is smaller than the opening. For example, long narrow objects such as pens, pencils etc., do not occlude enough of the high flow opening to generate sufficient negative forces to hold the object securely. In accordance with an embodiment therefore, the invention provides a specialized cover for use with a high flow vacuum gripper. In particular and as shown in FIGS. 5A (articulated arm facing side) and 5 B (object facing side), such a cover 100 may include a proximal back side 102 that does not permit air to flow through the material, and distal front side 104 for engaging objects that is formed of a foam material. Slit openings 106 in form of a star or asterisk shape are provided through the material in this example. During use, elongated objects may be received along opposing slit openings and held by the foam material.

**[p0013]**

FIG. 6 , for example, shows an elongated object 96 being held against the foam material 104 of a cover 100 that is coupled to the end effector 82 . While the elongated object 96 covers some of the opening provided by the slits 106 , other portions 108 of the opening provided by the slits 106 remain open. The pattern cut into the material allows for enough area to still obtain a relatively high flow, while providing a number or positions (or orientations) for a long, thin object to block (and thus be held by) a sufficiently high percentage of the air flow. The compliant foam on the surface 104 contacts the object to be acquired, giving the gripper some compliance while also acting to seal the aperture around the object as the foam is compressed and the high flow vacuum is applied. The aperture cover therefore allows a high flow gripper to effectively pick up long narrow objects with an easy to attach cover that may be held in a tool changer and added or removed from the gripper autonomously during real-time operation

**[p0014]**

In accordance with various embodiments, the cover 100 may be applied to the end effector by a human worker into a friction fitting on the end of the end effector, or in certain embodiments, the cover may be provided in a bank of available end effector attachments that the articulated arm may be programmed to engage as needed, and disengage when finished, e.g., using forced positive air pressure and/or a grasping device that secures the end effector attachment for release from the articulated arm. The invention therefore provides a system for providing vacuum control to an end effector of an articulated arm, where the system includes a vacuum source for providing a vacuum pressure at a flow rate to the end effector, and the end effector includes a cover including an air flow resistant material on a proximal side of the cover and a compliant material on a distal side of the cover for contacting objects to be grasped. The cover may include an opening that varies significantly in radius from a center of the cover, and the opening may include finger openings that extend radially from the center of the opening. The opening may be generally star shaped or asterisk shaped. The cover may be formed of a compliant material and include compliant foam on a distal side of the cover that engages an object to be grasped, and the cover may include an air flow resistant material on a proximal side of the cover. The vacuum pressure may be no more than about 25,000 Pascals or 50,000 Pascals below atmospheric, and the air flow rate may be at least about 100 cubic feet per minute.

**[p0015]**

Covers with other types of openings are shown in FIG. 7A-7D . FIG. 7A , for example, shows a cover 120 that includes slit openings 122 . FIG. 7B shows a cover 130 that includes different sized square openings 132 , 134 . Cover 140 shown in FIG. 7C includes small circular openings 142 , and cover 150 shown in FIG. 7D includes differently shaped openings 152 and 154 . In each of the covers 100 , 120 , 130 , 140 and 150 , a compliant foam surface may face the object to be acquired, and more area of the cover is provided to be open closer to the center of the cover with respect to the outer periphery of each cover. For example, in the cover 100 , the center of the asterisk shape is most open. In the cover 120 , the larger slits are provided in the center. In the cover 130 , the larger square openings are provided in the center. In the cover 140 , the greater concentration of the circular openings is provided in the center, and in the cover 150 , the larger shape 154 is provided in the center.

**[p0016]**

Systems in accordance with certain embodiments of the invention are able to monitor flow within the end effector as well as the weight and balance of an object being grasped. FIGS. 8A and 8B show an object 160 being lifted from a surface 162 by the end effector 82 that includes the load detection device of FIG. 4 . Upon engaging the object 160 , the system notes the position of the detection device and the level of flow (F 1 ) within the end effector as well as the vacuum pressure (P 1 ) and load (W 1 ) as shown in FIG. 8A . Once the object 160 is lifted ( FIG. 8B ), the system notes the change in the amount of flow (ΔF 1 ). In this example, the load provided by the object 160 is relatively light (ΔW 1 ), and a small variation (ΔF 1 ) in flow (when considering the load and aperture size) may be accepted. FIGS. 9A and 9B , however, show the end effector lifting a heavy object. FIGS. 9A and 9B show an object 170 being lifted from a surface 172 by the end effector 82 that includes the load detection device of FIG. 4 . Upon engaging the object 170 , the system notes the position of the detection device and the level of flow (F 2 ) within the end effector as well as the vacuum pressure (P 2 ) and load (W 2 ) as shown in FIG. 9A . Once the object 170 is lifted ( FIG. 9B ), the system notes the change in the amount of flow (ΔF 2 ). As noted above, in this example, the object 170 is heavy, presenting a higher load (ΔW 2 ). The system will evaluate the load in combination with the flow (F 2 ) and pressure (P 2 ) as well as the change in flow (ΔF 2 ) and change in pressure (ΔP 2 ) to

**[p0016]**

assess the grasp of the object. The system may use look-up tables of flow and load values for the sized aperture opening, and/or may use machine learning to develop and maintain information regarding loads that are suitable for different apertures sizes and flow rates. In further embodiments, the system may employ linear performance curves for the vacuum sources for maximum flow and maximum pressure, as adjusted by aperture opening size.

**[p0017]**

The system may also detect whether a load is not sufficiently balanced. FIGS. 10A and 10B show an object 180 being lifted from a surface 182 by the end effector 82 that includes the load detection device of FIG. 4 . Upon engaging the object 180 , the system notes the position of the detection device and the level of flow (F 3 ) within the end effector as well as the vacuum pressure (P 3 ) and load (W 3 ) as shown in FIG. 10A . Once the object 180 is lifted ( FIG. 10B ), the system notes the change in the amount of flow (ΔF 3 ). In this example, the object 180 presents a non-balanced load. The system will evaluate the load in combination with the flow (F 3 ) and pressure (P 3 ) as well as the change in flow (ΔF 3 ) and change in pressure (ΔP 3 ) to assess the grasp of the object. Again, the system may use look-up tables of flow and load values for the sized aperture opening, and/or may use machine learning to develop and maintain information regarding loads that are suitable for different apertures sizes and flow rates. In further embodiments, the system may employ linear performance curves for the vacuum sources for maximum flow and maximum pressure, as adjusted by aperture opening size.

**[p0018]**

The lifting force may be characterized as a function using any of machine learning, large data analytics, fuzzy logic or linear approximation. Lifting force depends on the vacuum generator performance model and the area of the object within the opening. Hose length and friction are also important. At high flow, pressure loss is related to flow velocity. Pressure loss is related to hose length and hose friction. Absent a performance curve, a linear approximation of the vacuum generator performance may be used. FIG. 11 shows linear performance curves for a blower (at 200 ) and a shop vacuum (at 202 ). Performance curves may also be concave or convex, depending on the parameter ds. The term ds parameterizes whether the relationship curve is concave or convex. The degree of concavity or convexity affects high flow gripper performance. FIG. 12 shows vacuum performance curves for ds=0.25 (as shown at 220 ), ds=1 (as shown at 222 ) and ds=1.5 (as shown at 224 ). FIGS. 13-15 show a two-pipe model of an example of a high flow gripper for illustrative purposes. As shown in FIG. 13 , an end effector 250 is engaging an object 252 . FIG. 14 shows that the area of the opening, a 1 is partially blocked by the object, leaving openings on either side of the object having a total area of a 2 . The area that is blocked is shown as (a 1 -a 2 ). FIG. 16 shows at 260 deflection angles versus lateral offset for an object using a bellows suction cup. An optimal aperture for a given maximum flow and maximum pressure, as well as (a 1 -a 2 )/a 1 may be provided. Also, knowing the center of mass of th

**[p0018]**

e held object with respect to the gripper, as well as any rotation of the object, the torque may be determined.

**[p0019]**

As shown in FIG. 16 , the deflection angles range correlate with grip offset from the base showing offset in one direction (as shown at 262 in FIG. 16 and 282 in FIG. 17 ), a balanced load (as shown at 270 in FIG. 16 and 290 in FIG. 17 ), and offset in an opposite direction (as shown at 276 in FIG. 16 and 296 in FIG. 17 ). The remaining points 264 , 266 , 268 , 272 and 274 correspond with the images 284 , 286 , 288 , 292 and 294 in FIG. 17 . The invention therefore provides, in various embodiments, that load weight, load balance, and flow may be used in a high flow system to provide accurate acquisition and transport of objects in a sortation system. Those skilled in the art will appreciate that numerous modifications and variations may be made to the above disclosed embodiments without departing from the spirit and scope of the present invention.

## Figure captions

- **Figure 1:** FIG. 1 shows an illustrative block diagrammatic view of a system in accordance with an embodiment of the present invention;
- **Figure 2:** FIG. 2 shows an illustrative diagrammatic view of an example of a system of FIG. 1 ;
- **Figure 3A:** FIGS. 3A and 3B show illustrative diagrammatic views of an end effector of a system of an embodiment of the invention engaging different types of objects;
- **Figure 4:** FIG. 4 shows an illustrative diagrammatic view of a detection system together with an end effector of a system of an embodiment of the present invention;
- **Figure 5A:** FIGS. 5A and 5B show illustrative photographic views of an end effector cover for use in a system of an embodiment of the present invention;
- **Figure 6:** FIG. 6 shows an illustrative diagrammatic view of an end effector of an embodiment of the invention engaging an object;
- **Figure 7A:** FIGS. 7A-7D show illustrative diagrammatic views of other covers for use with end effectors of systems of further embodiments of the present invention;
- **Figure 8A:** FIGS. 8A and 8B show illustrative diagrammatic views of an end effector in a system of an embodiment of the present invention engaging a relatively light object;
- **Figure 9A:** FIGS. 9A and 9B show illustrative diagrammatic views of an end effector in a system of an embodiment of the present invention engaging a relatively heavy object;
- **Figure 10A:** FIGS. 10A and 10B show illustrative diagrammatic views of an end effector in a system of an embodiment of the present invention engaging an object that presents an unbalanced load;
- **Figure 11:** FIG. 11 shows an illustrative graphical representation of air flow verses pressure differential for different vacuum sources;
- **Figure 12:** FIG. 12 shows an illustrative graphical representation of air flow verses pressure differential for different parameterizations of performance;
- **Figure 13:** FIG. 13 shows an illustrative diagrammatic model of an end effector aperture and object in a system in accordance with an embodiment of the present invention;
- **Figure 14:** FIG. 14 shows an illustrative diagrammatic end view of the system of FIG. 13 showing the relative areas of the opening;
- **Figure 15:** FIG. 15 shows an illustrative diagrammatic side view of the system of FIG. 13 showing flow direction and pressure;
- **Figure 16:** FIG. 16 shows an illustrative graphical representation of grip offset from a base versus angle in a system in accordance with an embodiment of the present invention; and
- **Figure 17:** FIG. 17 shows illustrative diagrammatic representations of objects being held at the offset points in FIG. 16 .

## Classifications

- B25J13/085
- B25J15/0616
- B25J15/0616
- B25J15/0616
- B25J13/08
- B25J13/085
- B25J13/085
- B25J13/085
- B25J15/06
- B25J15/0616
- B25J15/0625
- B25J15/0625
- B25J15/0625
- B25J15/0658
- B25J15/0658
- B25J15/0675
- B25J15/0675
- B25J15/0683
- B25J15/0683
- B25J15/0691
- B25J15/0691
- B25J9/16
- B25J9/1612
- B25J9/1612
- B25J9/1633

## Cited patent documents

- [CN-103987637-A](https://patents.google.com/patent/CN103987637A/en) — APP
- [CN-104093992-A](https://patents.google.com/patent/CN104093992A/en) — APP
- [CN-1390438-A](https://patents.google.com/patent/CN1390438A/en) — APP
- [CN-1744970-A](https://patents.google.com/patent/CN1744970A/en) — APP
- [CN-201586976-U](https://patents.google.com/patent/CN201586976U/en) — APP
- [DE-10121344-A1](https://patents.google.com/patent/DE10121344A1/en) — APP
- [DE-102007054867-A1](https://patents.google.com/patent/DE102007054867A1/en) — APP
- [DE-102012009011-A1](https://patents.google.com/patent/DE102012009011A1/en) — APP
- [DE-3810989-A1](https://patents.google.com/patent/DE3810989A1/en) — APP
- [EP-1256421-B1](https://patents.google.com/patent/EP1256421B1/en) — APP
- [EP-1348873-A1](https://patents.google.com/patent/EP1348873A1/en) — APP
- [EP-1671906-A1](https://patents.google.com/patent/EP1671906A1/en) — APP
- [EP-2014587-A2](https://patents.google.com/patent/EP2014587A2/en) — APP
- [EP-2823899-A1](https://patents.google.com/patent/EP2823899A1/en) — APP
- [EP-2960024-A2](https://patents.google.com/patent/EP2960024A2/en) — APP
- [FR-2592827-A1](https://patents.google.com/patent/FR2592827A1/en) — APP
- [JP-2010201536-A](https://patents.google.com/patent/JP2010201536A/en) — APP
- [JP-H0769470-A](https://patents.google.com/patent/JPH0769470A/en) — APP
- [JP-S6155399-A](https://patents.google.com/patent/JPS6155399A/en) — APP
- [TW-201400253-A](https://patents.google.com/patent/TW201400253A/en) — APP
- [US-10007827-B2](https://patents.google.com/patent/US10007827B2/en) — APP
- [US-10118300-B2](https://patents.google.com/patent/US10118300B2/en) — APP
- [US-10315315-B2](https://patents.google.com/patent/US10315315B2/en) — APP
- [US-10399236-B2](https://patents.google.com/patent/US10399236B2/en) — APP
- [US-10576641-B2](https://patents.google.com/patent/US10576641B2/en) — SEA
- [US-2001045755-A1](https://patents.google.com/patent/US20010045755A1/en) — APP
- [US-2003038491-A1](https://patents.google.com/patent/US20030038491A1/en) — APP
- [US-2003164620-A1](https://patents.google.com/patent/US20030164620A1/en) — APP
- [US-2006242785-A1](https://patents.google.com/patent/US20060242785A1/en) — APP
- [US-2008179224-A1](https://patents.google.com/patent/US20080179224A1/en) — APP
- [US-2009019818-A1](https://patents.google.com/patent/US20090019818A1/en) — APP
- [US-2010040450-A1](https://patents.google.com/patent/US20100040450A1/en) — APP
- [US-2010125361-A1](https://patents.google.com/patent/US20100125361A1/en) — APP
- [US-2013129464-A1](https://patents.google.com/patent/US20130129464A1/en) — APP
- [US-2013232918-A1](https://patents.google.com/patent/US20130232918A1/en) — APP
- [US-2013232919-A1](https://patents.google.com/patent/US20130232919A1/en) — APP
- [US-2013277999-A1](https://patents.google.com/patent/US20130277999A1/en) — APP
- [US-2014005831-A1](https://patents.google.com/patent/US20140005831A1/en) — APP
- [US-2015081090-A1](https://patents.google.com/patent/US20150081090A1/en) — APP
- [US-2015298316-A1](https://patents.google.com/patent/US20150298316A1/en) — APP
- [US-2015328779-A1](https://patents.google.com/patent/US20150328779A1/en) — APP
- [US-2015375401-A1](https://patents.google.com/patent/US20150375401A1/en) — APP
- [US-2016136816-A1](https://patents.google.com/patent/US20160136816A1/en) — APP
- [US-2016221187-A1](https://patents.google.com/patent/US20160221187A1/en) — APP
- [US-2016244262-A1](https://patents.google.com/patent/US20160244262A1/en) — APP
- [US-2016271805-A1](https://patents.google.com/patent/US20160271805A1/en) — APP
- [US-2017050315-A1](https://patents.google.com/patent/US20170050315A1/en) — APP
- [US-2017057091-A1](https://patents.google.com/patent/US20170057091A1/en) — APP
- [US-2017072572-A1](https://patents.google.com/patent/US20170072572A1/en) — APP
- [US-2017080571-A1](https://patents.google.com/patent/US20170080571A1/en) — APP
- [US-2017080579-A1](https://patents.google.com/patent/US20170080579A1/en) — APP
- [US-2017120455-A1](https://patents.google.com/patent/US20170120455A1/en) — APP
- [US-2853333-A](https://patents.google.com/patent/US2853333A/en) — APP
- [US-3005652-A](https://patents.google.com/patent/US3005652A/en) — APP
- [US-3195941-A](https://patents.google.com/patent/US3195941A/en) — APP
- [US-3195951-A](https://patents.google.com/patent/US3195951A/en) — APP
- [US-3637249-A](https://patents.google.com/patent/US3637249A/en) — APP
- [US-3959864-A](https://patents.google.com/patent/US3959864A/en) — APP
- [US-4389064-A](https://patents.google.com/patent/US4389064A/en) — APP
- [US-4412775-A](https://patents.google.com/patent/US4412775A/en) — APP
- [US-4466778-A](https://patents.google.com/patent/US4466778A/en) — APP
- [US-4495968-A](https://patents.google.com/patent/US4495968A/en) — APP
- [US-4557659-A](https://patents.google.com/patent/US4557659A/en) — APP
- [US-4828304-A](https://patents.google.com/patent/US4828304A/en) — APP
- [US-4880358-A](https://patents.google.com/patent/US4880358A/en) — APP
- [US-4960364-A](https://patents.google.com/patent/US4960364A/en) — APP
- [US-5024575-A](https://patents.google.com/patent/US5024575A/en) — APP
- [US-5207465-A](https://patents.google.com/patent/US5207465A/en) — APP
- [US-5683227-A](https://patents.google.com/patent/US5683227A/en) — APP
- [US-5752729-A](https://patents.google.com/patent/US5752729A/en) — APP
- [US-5764013-A](https://patents.google.com/patent/US5764013A/en) — APP
- [US-5791861-A](https://patents.google.com/patent/US5791861A/en) — APP
- [US-5865487-A](https://patents.google.com/patent/US5865487A/en) — APP
- [US-6015174-A](https://patents.google.com/patent/US6015174A/en) — APP
- [US-6244640-B1](https://patents.google.com/patent/US6244640B1/en) — APP
- [US-6397876-B1](https://patents.google.com/patent/US6397876B1/en) — APP
- [US-6817639-B2](https://patents.google.com/patent/US6817639B2/en) — APP
- [US-7017961-B1](https://patents.google.com/patent/US7017961B1/en) — APP
- [US-7140389-B2](https://patents.google.com/patent/US7140389B2/en) — APP
- [US-7263890-B2](https://patents.google.com/patent/US7263890B2/en) — APP
- [US-7618074-B2](https://patents.google.com/patent/US7618074B2/en) — APP
- [US-7637548-B2](https://patents.google.com/patent/US7637548B2/en) — APP
- [US-7677622-B2](https://patents.google.com/patent/US7677622B2/en) — APP
- [US-8070203-B2](https://patents.google.com/patent/US8070203B2/en) — APP
- [US-8096598-B2](https://patents.google.com/patent/US8096598B2/en) — APP
- [US-8132835-B2](https://patents.google.com/patent/US8132835B2/en) — APP
- [US-8267386-B2](https://patents.google.com/patent/US8267386B2/en) — APP
- [US-8565915-B2](https://patents.google.com/patent/US8565915B2/en) — APP
- [US-8641329-B2](https://patents.google.com/patent/US8641329B2/en) — APP
- [US-8662861-B2](https://patents.google.com/patent/US8662861B2/en) — APP
- [US-8721321-B2](https://patents.google.com/patent/US8721321B2/en) — APP
- [US-8777284-B2](https://patents.google.com/patent/US8777284B2/en) — APP
- [US-9061868-B1](https://patents.google.com/patent/US9061868B1/en) — APP
- [US-9120622-B1](https://patents.google.com/patent/US9120622B1/en) — APP
- [US-9227323-B1](https://patents.google.com/patent/US9227323B1/en) — APP
- [US-9492923-B2](https://patents.google.com/patent/US9492923B2/en) — APP
- [US-9604363-B2](https://patents.google.com/patent/US9604363B2/en) — APP
- [US-9623570-B1](https://patents.google.com/patent/US9623570B1/en) — APP
- [US-9656813-B2](https://patents.google.com/patent/US9656813B2/en) — APP
- [US-9999977-B2](https://patents.google.com/patent/US9999977B2/en) — APP
- [WO-2014161549-A1](https://patents.google.com/patent/WO2014161549A1/en) — APP
- [WO-2015162390-A1](https://patents.google.com/patent/WO2015162390A1/en) — APP
- [WO-2017035466-A1](https://patents.google.com/patent/WO2017035466A1/en) — APP

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
