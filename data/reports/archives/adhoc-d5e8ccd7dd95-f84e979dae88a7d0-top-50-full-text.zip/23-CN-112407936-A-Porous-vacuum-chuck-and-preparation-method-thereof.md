# 23. Porous vacuum chuck and preparation method thereof

- **Archive rank:** 23 of 50
- **Publication:** [CN-112407936-A](https://patents.google.com/patent/CN112407936A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/074828058/publication/CN112407936A?q=pn%3DCN112407936A)
- **Publication date:** 2021-02-26
- **Filing date:** 2020-10-30
- **Earliest priority:** 2020-10-30
- **Family:** 74828058
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** ZHENGZHOU RES INSTITUTE FOR ABRASIVES & GRINDING CO LTD
- **Inventors:** LIU XUN; Pei yaxing; SONG YUNYUN; SUN ZHENGBIN; ZHANG XIN

## Abstract

The invention belongs to the technical field of vacuum adsorption, and particularly relates to a porous vacuum sucker and a preparation method thereof. The porous vacuum chuck comprises a porous adsorption part, a sealing layer and a base, wherein the porous adsorption part is fixed on the base through the sealing layer, a through hole penetrates through the middle of the base, and the porous adsorption part is made of more than one of alumina, zirconia, ZTA, silicon carbide, silicon nitride, zinc oxide, titanium oxide, tin oxide, hydroxyapatite or quartz; the sealing layer is made of ceramic, glass or resin, and the thickness of the sealing layer is 10-500 mu m; the base is made of aluminum oxide, zirconium oxide, ZTA, silicon carbide, silicon nitride, quartz, stainless steel, titanium alloy or aluminum alloy. The porous vacuum chuck has small flow loss, and can realize stable adsorption of an adsorbate under the condition that the adsorbate cannot completely cover an adsorption area; and product defects such as concave deformation and the like can not be caused.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/03/e2/f3/508dc9854d25c2/201030104957.png)

![Sketch 1 for CN-112407936-A](https://patentimages.storage.googleapis.com/03/e2/f3/508dc9854d25c2/201030104957.png)

[Sketch 2](https://patentimages.storage.googleapis.com/b9/91/8f/c1fbf5c1fa1a40/201030105001.png)

![Sketch 2 for CN-112407936-A](https://patentimages.storage.googleapis.com/b9/91/8f/c1fbf5c1fa1a40/201030105001.png)

[Sketch 3](https://patentimages.storage.googleapis.com/aa/92/45/13a9c09711c4d3/201030105004.png)

![Sketch 3 for CN-112407936-A](https://patentimages.storage.googleapis.com/aa/92/45/13a9c09711c4d3/201030105004.png)

[Sketch 4](https://patentimages.storage.googleapis.com/1a/f3/7b/7aaf87d25f5014/201030105007.png)

![Sketch 4 for CN-112407936-A](https://patentimages.storage.googleapis.com/1a/f3/7b/7aaf87d25f5014/201030105007.png)

[Sketch 5](https://patentimages.storage.googleapis.com/3b/5a/a0/e013c05cd40390/201030105010.png)

![Sketch 5 for CN-112407936-A](https://patentimages.storage.googleapis.com/3b/5a/a0/e013c05cd40390/201030105010.png)

[Sketch 6](https://patentimages.storage.googleapis.com/66/d3/4a/0a29017b9392b4/201030105014.png)

![Sketch 6 for CN-112407936-A](https://patentimages.storage.googleapis.com/66/d3/4a/0a29017b9392b4/201030105014.png)

[Sketch 7](https://patentimages.storage.googleapis.com/c7/87/a7/8b2a5e306401da/201030105017.png)

![Sketch 7 for CN-112407936-A](https://patentimages.storage.googleapis.com/c7/87/a7/8b2a5e306401da/201030105017.png)

[Sketch 8](https://patentimages.storage.googleapis.com/df/8c/6f/4b06ae0dfdbbca/201030105020.png)

![Sketch 8 for CN-112407936-A](https://patentimages.storage.googleapis.com/df/8c/6f/4b06ae0dfdbbca/201030105020.png)

[Sketch 9](https://patentimages.storage.googleapis.com/35/35/d7/2ffb1d1a7ab033/201030105023.png)

![Sketch 9 for CN-112407936-A](https://patentimages.storage.googleapis.com/35/35/d7/2ffb1d1a7ab033/201030105023.png)

## Claims

### Claim 1 (independent)

A porous vacuum chuck comprises a porous adsorption part, a sealing layer and a base, wherein the porous adsorption part is fixed on the base through the sealing layer, and the middle part of the base is provided with a through hole which penetrates through the base; the sealing layer is made of ceramic, glass or resin, and the thickness of the sealing layer is 10-500 mu m; the base is made of aluminum oxide, zirconium oxide, ZTA, silicon carbide, silicon nitride, quartz, stainless steel, titanium alloy or aluminum alloy.

### Claim 2

The porous vacuum chuck according to claim 1, wherein the porous adsorption member has a raw material particle size of 0.1 to 30 μm.

### Claim 3

A method of manufacturing a porous vacuum chuck according to any of claims 1-2, comprising the steps of: (1) preparation of porous adsorption member: heating a solvent to 50-80 ℃, adding 20-70vol% of the raw materials of the porous adsorption component to prepare ceramic slurry, then placing the ceramic slurry in a ball mill, carrying out ball milling for 4-20h, pouring the ceramic slurry into a mold for molding and demolding, finally carrying out sublimation drying at room temperature for 20-48h, and then carrying out high-temperature sintering at 700-1600 ℃ to obtain the porous adsorption component; (2) processing a sinking platform, a through hole and a groove on the base, wherein the sinking platform is matched with the porous adsorption part, and roughening and cleaning the surface of the sinking platform to increase the binding force of a sealing surface; (3) coating adhesive on the surface of the sinking platform, embedding the porous adsorption component, and pressurizing and curing the porous adsorption component into a whole to obtain the porous adsorption material.

### Claim 4

The method for preparing a porous vacuum chuck according to claim 3, wherein the step (1) further comprises an additive, wherein the additive is used in an amount of 0.5-8 wt%; heating the solvent to 50-80 deg.C, and adding the raw materials and additives of the porous adsorption component; the solvent is camphene, tertiary butanol or a mixed solution of the tertiary butanol and water, and the additive is glycerol, polyvinyl alcohol, polyethylene glycol, polyacrylamide, tetramethylammonium hydroxide, polyvinylpyrrolidone, methyl cellulose, ammonium polyacrylate, gum arabic or modified polyester.

### Claim 5

The method for preparing the porous vacuum chuck according to the claim 3, wherein the ceramic slurry in the step (1) is rapidly poured into a mold on a cooling platform for molding after being subjected to nodular casting, and the mold is removed after the ceramic slurry is frozen; the temperature of the cooling platform is (-80) - (-30) DEG C.

### Claim 6

The method for preparing the porous vacuum chuck according to claim 3, wherein the bottom of the mold is made of an aluminum plate, a copper plate or a stainless steel plate, and the thickness of the bottom is 0.1-20 mm; the material of the die frame is polyurethane, polydimethylsiloxane, nylon or polytetrafluoroethylene, and the thickness of the frame is 10-100 mm.

### Claim 7

The method for preparing a porous vacuum chuck as claimed in claim 3, wherein the rotation speed of the ball mill is 100-800 r/min.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippersCHEMISTRY; METALLURGYCEMENTS; CONCRETE; ARTIFICIAL STONE; CERAMICS; REFRACTORIESLIME, MAGNESIA; SLAG; CEMENTS; COMPOSITIONS THEREOF, e.g. MORTARS, CONCRETE OR LIKE BUILDING MATERIALS; ARTIFICIAL STONE; CERAMICS; REFRACTORIES; TREATMENT OF NATURAL STONEShaped ceramic products characterised by their composition; Ceramics compositions; Processing powders of inorganic compounds preparatory to the manufacturing of ceramic productsShaped ceramic products characterised by their composition; Ceramics compositions; Processing powders of inorganic compounds preparatory to the manufacturing of ceramic products based on oxide ceramicsShaped ceramic products characterised by their composition; Ceramics compositions; Processing powders of inorganic compounds preparatory to the manufacturing of ceramic products based on oxide ceramics based on aluminium oxideCHEMISTRY; METALLURGYCEMENTS; CONCRETE; ARTIFICIAL STONE; CERAMICS; REFRACTORIESLIME, MAGNESIA; SLAG; CEMENTS; COMPOSITIONS THEREOF, e.g. MORTARS, CONCRETE OR LIKE BUILDING MATERIALS; ARTIFICIAL STONE; CERAMICS; REFRACTORIES; TREATMENT OF NATURAL STONEShaped ceramic products characterised by their composition; Ceramics compositions; Processing powders of inorganic compounds preparatory to the manufacturing of ceramic productsShaped ceramic products characterised by their composition; Ceramics compositions; Processing powders of inorganic compounds preparatory to the manufacturing of ceramic products based on oxide ceramicsShaped ceramic products characterised by their composition; Ceramics compositions; Processing powders of inorganic compounds preparatory to the manufacturing of ceramic products based on oxide ceramics based on zirconium or hafnium oxides, zirconates, zircon or hafnatesCHEMISTRY; METALLURGYCEMENTS; CONCRETE; ARTIFICIAL STONE; CERAMICS; REFRACTORIESLIME, MAGNESIA; SLAG; CEMENTS; COMPOSITIONS THEREOF, e.g. MORTARS, CONCRETE OR LIKE BUILDING MATERIALS; ARTIFICIAL STONE; CERAMICS; REFRACTORIES; TREATMENT OF NATURAL STONEShaped ceramic products characterised by their composition; Ceramics compositions; Processing powders of inorganic compounds preparatory to the manufacturing of ceramic productsShaped ceramic products characterised by their composition; Ceramics compositions; Processing powders of inorganic compounds preparatory to the manufacturing of ceramic products based on non-oxide ceramicsShaped ceramic products characterised by their composition; Ceramics compositions; Processing powders of inorganic compounds preparatory to the manufacturing of ceramic products based on non-oxide ceramics based on carbides or oxycarbidesShaped ceramic products characterised by their composition; Ceramics compositions; Processing powders of inorganic compounds preparatory to the manufacturing of ceramic products based on non-oxide ceramics based on carbides or oxycarbides based on silicon carbideCHEMISTRY; METALLURGYCEMENTS; CONCRETE; ARTIFICIAL STONE; CERAMICS; REFRACTORIESLIME, MAGNESIA; SLAG; CEMENTS; COMPOSITIONS THEREOF, e.g. MORTARS, CONCRETE OR LIKE BUILDING MATERIALS; ARTIFICIAL STONE; CERAMICS; REFRACTORIES; TREATMENT OF NATURAL STONEPorous mortars, concrete, artificial stone or ceramic ware; Preparation thereofPorous mortars, concrete, artificial stone or ceramic ware; Preparation thereof by burning-out added substances by burning natural expanding materials or by sublimating or melting out added substancesPreparing or treating the raw materials individually or as batchesCompounding ingredientsBurnable, meltable, sublimable materialsMacromolecular compoundsPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSIndexing codes relating to handling devices, e.g. conveyors, characterised by the type of product or load being conveyed or handledArticlesCHEMISTRY; METALLURGYCEMENTS; CONCRETE; ARTIFICIAL STONE; CERAMICS; REFRACTORIESLIME, MAGNESIA; SLAG; CEMENTS; COMPOSITIONS THEREOF, e.g. MORTARS, CONCRETE OR LIKE BUILDING MATERIALS; ARTIFICIAL STONE; CERAMICS; REFRACTORIES; TREATMENT OF NATURAL STONEAspects relating to ceramic starting mixtures or sintered ceramic productsAspects relating to sintered or melt-casted ceramic productsProperties of ceramic products, e.g. mechanical properties such as strength, toughness, wear resistanceGENERAL TAGGING OF NEW TECHNOLOGICAL DEVELOPMENTS; GENERAL TAGGING OF CROSS-SECTIONAL TECHNOLOGIES SPANNING OVER SEVERAL SECTIONS OF THE IPC; TECHNICAL SUBJECTS COVERED BY FORMER USPC CROSS-REFERENCE ART COLLECTIONS [XRACs] AND DIGESTSTECHNOLOGIES OR APPLICATIONS FOR MITIGATION OR ADAPTATION AGAINST CLIMATE CHANGECLIMATE CHANGE MITIGATION TECHNOLOGIES IN THE PRODUCTION OR PROCESSING OF GOODSClimate change mitigation technologies in the production process for final industrial or consumer productsManufacturing or production processes characterised by the final manufactured product

Description

Porous vacuum chuck and preparation method thereof

Technical Field

The invention belongs to the technical field of vacuum adsorption, and particularly relates to a porous vacuum sucker and a preparation method thereof.

Background

The porous vacuum chuck is used as a bearing platform for adsorbing a workpiece by forming negative pressure through vacuumizing, has the characteristics of high porosity, high flatness, uniform adsorption force and the like, and is widely applied to the industries of semiconductors, magnetic materials and photoelectricity. In the semiconductor industry, porous vacuum chucks are most widely used, and are mainly used for grinding, polishing, glue homogenizing and testing in the front process, and back reduction, scribing, cleaning, carrying and other processes in the rear process.

There are two main methods for manufacturing the adsorption part of the existing porous vacuum chuck, one is mechanical or laser drilling, as shown in fig. 1 (a); one is to form a pore by stacking pores and to form pores by adding a pore-forming agent, as shown in FIG. 2 (a). The vacuum chuck prepared by the two existing methods comprises a porous adsorption part (corresponding to 102 in fig. 1 and 103 in fig. 2), a sealing layer 2 and a base 3, wherein the porous adsorption part is fixed on the base 3 through the sealing layer 2. The diameter of the adsorption part manufactured by the punching method is 200 mu m-1.5mm, the adsorption part is a through hole vertical to the adsorption surface, the adsorption fixity is good, when adsorbing a sheet or film workpiece, the sheet or film workpiece is sunken and deformed in the adsorption hole area due to a larger diameter, so that the product defect is caused, the number of holes in a unit area is limited, and the adsorption uniformity is poor, as shown in fig. 1 (b). The pore diameter of the adsorption component manufactured by the pore forming method by accumulating pores and adding pore forming agent is between 30 mu m and 2mm, the pore forming process is limited, the porosity of the adsorption component is 20 to 50vol%, the structure and orientation of the pores are difficult to accurately control, and the pore channels are bent, so that the flow loss is caused, as shown in fig. 2 (b), the adsorption force is limited, so that only flat workpieces which can completely cover an adsorption area can be adsorbed (namely, the adsorbed workpieces can only be adsorbed workpieces 702 which completely cover the adsorption area), if workpieces with different shapes and sizes exist on a production line, porous vacuum chucks of various types need to be purchased for matching, once the shapes and sizes of the workpieces are changed, the porous vacuum chucks need to be replaced and correspondingly debugged, and the material cost and the time cost are increased.

In view of the problems in the prior art, it is desirable to provide a porous vacuum metal chuck having strong suction force and stable suction in the case where the adsorbate cannot completely cover the suction area.

Disclosure of Invention

To overcome the problems in the prior art, the present invention provides a porous vacuum chuck. The porous vacuum chuck can realize stable and uniform adsorption of an adsorbate under the condition that the adsorbate cannot completely cover an adsorption area, and cannot cause product defects such as concave deformation and the like.

The invention also provides a preparation method of the porous vacuum chuck.

In order to achieve the purpose, the technical scheme of the invention is as follows:

a porous vacuum chuck comprises a porous adsorption part, a sealing layer and a base, wherein the porous adsorption part is fixed on the base through the sealing layer, a through hole penetrating through the middle of the base is formed in the middle of the base, and the porous adsorption part is made of more than one of alumina, zirconia, ZTA, silicon carbide, silicon nitride, zinc oxide, titanium oxide, tin oxide, hydroxyapatite or quartz;

the sealing layer is made of ceramic, glass or resin, and the thickness of the sealing layer is 10-500 mu m;

the base is made of aluminum oxide, zirconium oxide, ZTA, silicon carbide, silicon nitride, quartz, stainless steel, titanium alloy or aluminum alloy.

Preferably, the raw material particle diameter of the porous adsorption member is 0.1 to 30 Î¼m. If the particle size is less than 0.1 mu m, the shrinkage rate is large in the drying and sintering processes, the blank is easy to crack and break, and the designed aperture and porosity cannot be obtained; if the particle size is larger than 30 Î¼m, the ceramic is not easily sintered, and the obtained pore size is larger than 30 Î¼m.

The preparation method of the porous vacuum chuck comprises the following steps:

(1) preparation of porous adsorption member: heating a solvent to 50-80 â, adding raw materials (the dosage of the raw materials is 20-70vol% of the solvent) of a porous adsorption component to prepare ceramic slurry, then placing the ceramic slurry in a ball mill, carrying out ball milling for 4-20h, pouring the ceramic slurry into a mold for molding and demolding, finally carrying out sublimation drying at room temperature for 20-48h, and then carrying out high-temperature sintering at 700-1600 â to obtain the porous adsorption component;

(2) processing a sinking platform, a through hole and a groove on the base, wherein the sinking platform is matched with the porous adsorption part, and roughening and cleaning the surface of the sinking platform to increase the binding force of a sealing surface;

(3) coating adhesive on the surface of the sinking platform, embedding the porous adsorption component, and pressurizing and curing the porous adsorption component into a whole to obtain the porous adsorption material.

If the raw material addition proportion of the porous adsorption part is lower than 20vol%, the strength of the dried green body and the sintered porous ceramic is too low; if the amount of the additive is more than 70vol%, the slurry has a high viscosity and is not easily molded, and the fired ceramic is dense and cannot be used as an adsorbent, so that the amount of the additive is limited to 20 to 70vol% based on the solvent.

Preferably, the step (1) further comprises an additive, wherein the additive is used in an amount of 0.5-8wt% (solid content); heating the solvent to 50-80 deg.C, and adding the raw materials and additives of the porous adsorption component; the solvent is camphene, tertiary butanol or a mixed solution of the tertiary butanol and water, and the additive is glycerol, polyvinyl alcohol, polyethylene glycol, polyacrylamide, tetramethylammonium hydroxide, polyvinylpyrrolidone, methyl cellulose, ammonium polyacrylate, gum arabic or modified polyester. The additive has the functions of stable suspension, dispersion, adhesion, grinding aid and the like.

The additive mainly has the functions of suspending and dispersing and enables a dried blank to have certain strength. The temperature of the solvent is kept between 50 and 80 â all the time during premixing and ball milling until the temperature is lower than 50 â, the solvent is easy to solidify and cannot be effectively mixed, and the solvent is volatile when the temperature is higher than 80 â, so that the concentration of slurry is influenced.

Preferably, the ceramic slurry in the step (1) is rapidly poured into a mold on a cooling platform for molding after being subjected to nodular casting, and the mold is removed after the ceramic slurry is completely frozen; the temperature of the cooling platform is (-80) - (-30) DEG C.

If the temperature is lower than minus 80 â, the freezing cost is too high, and if the temperature is higher than minus 30 â, the freezing crystal size obtained by too slow freezing is large, and pores with the diameter of 1-30 mu m can not be obtained after drying and sintering.

Preferably, the bottom of the die is made of an aluminum plate, a copper plate or a stainless steel plate, and the thickness of the bottom of the die is 0.1-20 mm; the material of the die frame is polyurethane, polydimethylsiloxane, nylon or polytetrafluoroethylene, and the thickness of the frame is 10-100 mm. This is to make the slurry cool in one direction perpendicular to the bottom plate, so as to obtain the directionally arranged pore structure, and the bottom plate and the frame can be separated to facilitate demoulding.

Preferably, the rotation speed of the ball mill is 100-.

The mold adopted by the invention is placed on a cooling platform, the mold consists of a bottom plate and a frame, the frame can be set according to the shape of a required porous adsorption part, and ceramic slurry is poured into the frame for molding.

Compared with the prior art, the invention has the beneficial effects that:

1. the micropore structure of the porous adsorption component is detected to be a through hole vertical to the adsorption surface through SEM, the pore diameter is 1-30 mu m through mercury porosimetry, the porosity is 40-70vol%, the pore diameter is small, the pore occupation ratio is high, so the adsorption force of the porous adsorption component is large, the flow loss is small, stable adsorption of an adsorbed object can be realized under the condition that the adsorbed object cannot completely cover an adsorption area, and therefore when the size and the shape of the processed object are changed, a ceramic sucker does not need to be replaced, the working procedures are reduced, the working efficiency is improved, the material cost and the management cost are reduced, and the porous adsorption component can be used for a sheet-shaped workpiece with warped edge and containing open pores and grooves;

2. the porous vacuum chuck has small aperture and uniform adsorption force, and can not cause adsorption deformation, so that the porous vacuum chuck can adsorb sheet and film workpieces, can be used in laser processing equipment and is beneficial to focusing;

3. the porous vacuum chuck has large adsorption force and no limit on the shape of an adsorbed workpiece, so that the application field of the porous vacuum chuck is greatly expanded, the porous vacuum chuck is not limited to the semiconductor industry and the photovoltaic industry any more, and the products of the type can be applied to equipment required by the traditional mechanical manufacturing industry, the novel intelligent automation industry and the like in a large quantity, and the functions of adsorption processing, fixed detection, carrying, conveying and the like of the products are realized;

4. the porous adsorption component is prepared by selecting ceramic powder, a solvent and the like and adopting a specific mould, a premixing process, a ball milling process, a cooling process and the like.

Drawings

FIG. 1 is a sectional view of a porous suction member and a porous vacuum chuck thereof manufactured by a conventional mechanical or laser drilling process, and (b) is an enlarged view of the deformation of a sheet or film workpiece at the suction hole;

fig. 2 (a) is a cross-sectional view of a porous adsorption member and a porous vacuum chuck thereof manufactured by a conventional pore forming method by stacking pores and adding a pore-forming agent, and (b) is an enlarged view of the internal structure and flow loss of a pore channel;

FIG. 3 is a cross-sectional view of a multi-hole vacuum chuck of the present invention;

FIG. 4 is a cross-sectional view of the mold and cooling platform;

FIG. 5 is SEM images of a longitudinal section (a) and a cross section (b) of the porous alumina ceramic in example 1;

FIG. 6 is a schematic view of the testing of the suction force of the multi-hole vacuum chuck in the present invention;

FIG. 7 is a schematic view of the structure of the multi-hole vacuum chuck in example 1;

FIG. 8 is a schematic view showing the structure of the multi-hole vacuum chuck in example 2;

FIG. 9 is a schematic view of the structure of the multi-hole vacuum chuck in example 3;

in the figure: 101 is a porous adsorption part of the invention, 102 is a porous adsorption part manufactured by the existing mechanical or laser drilling process, 103 is a porous adsorption part manufactured by the existing pore forming method by stacking pores and adding pore-forming agent, 2 is a sealing layer, 3 is a base, 4 is an external connector, 5 is a vacuum pump, 6 is an air passage in the base, 701 is an adsorbed workpiece which does not completely cover an adsorption area, 702 is an adsorbed workpiece which completely covers the adsorption area, 8 is a through hole, 9 is ceramic particles, 10 is a bottom plate, 11 is a frame, 12 is a cooling platform, 13 is ceramic slurry, 14 is a standard detection sample, 15 is an adsorption tester, and 16 is an exhaust hole.

Detailed Description

The invention is further illustrated, but not limited, by the following examples and the accompanying drawings.

In the description of the present invention, it should be noted that, for the terms of orientation, such as "central", "lateral", "longitudinal", "length", "width", "thickness", "upper", "lower", "front", "rear", "left", "right", "vertical", "horizontal", "top", "bottom", "inner", "outer", etc., it indicates that the orientation and positional relationship are based on those shown in the drawings, and is only for convenience of description and simplification of description, but does not indicate or imply that the device or element referred to must have a specific orientation, be constructed and operated in a specific orientation, and should not be construed as limiting the specific scope of the invention.

The porous vacuum chuck structure of the invention is shown in fig. 3 and is composed of a porous adsorption part 101, a sealing layer 2 and a base 3, wherein the porous adsorption part 101 is fixed on the base 3 through the sealing layer 2, a through hole is formed in the middle of the base 3, one side, far away from the porous adsorption part, of the through hole is connected with an external connector 4, and the external connector 4 is connected with a vacuum negative pressure generator (the external connector 4 and the vacuum negative pressure generator are not innovations of the invention, and the invention can be realized by adopting the conventional technology in the field, the vacuum negative pressure generator can be a vacuum pump or other devices with vacuum negative pressure effect, and the following embodiment adopts the vacuum pump 5, and the details are not repeated here). The porous adsorption component prepared by the invention is provided with through holes which vertically penetrate through, and the through holes and the interlayers formed by pressing the ceramic particles are arranged in a crossed manner.

As shown in figure 4, the mold adopted by the invention is placed on a cooling platform 12, the mold consists of a bottom plate 10 and a frame 11, the frame 11 is set according to the shape of a required porous adsorption part, and ceramic slurry 13 is poured into the frame 11 for molding.

Example 1

Heating a camphene solvent in a thermostatic water bath to 80 â, adding 20vol% of alumina powder with the average particle size of 1 mu m, 2.5wt% of polyacrylamide and 2.5wt% of gum arabic into the solvent, uniformly stirring, placing the mixture into a ball mill preheated to 80 â, and carrying out ball milling for 8 hours at the rotating speed of 200r/min to prepare ceramic slurry.

Setting a cooling platform to be 50 â below zero, sequentially placing a bottom plate 10 (made of copper) with the thickness of 1mm and a circular frame 11 made of polytetrafluoroethylene with the thickness of 20mm, quickly pouring the prepared ceramic slurry into a mould, after cooling for 8 hours, completely freezing the slurry, removing the frame 11, taking down the frozen circular-plate-shaped blank, and placing the blank in a ventilation environment at 20 â for sublimation and drying for 24 hours.

And (3) sintering the dried disk-shaped blank in a normal pressure sintering furnace at 1550 â to obtain the porous alumina ceramic. The porous alumina ceramics are detected by SEM, as shown in FIG. 5, the figure (a) and the figure (b) are SEM images of the longitudinal section and the cross section of the porous alumina ceramics respectively, and as can be seen from FIG. 5, the porous alumina ceramics prepared by the embodiment has a through hole structure vertical to the cooling surface and the through holes are uniformly distributed; the average pore diameter is 15 Î¼m and the porosity is 62% by mercury porosimetry.

Processing a phi 300 x 6mm sinking platform on an alumina ceramic base, processing a through hole in the middle of the base, milling a multi-ring annular groove and a cross groove structure on the sinking platform, wherein the cross groove penetrates through all the annular grooves, and the center of the cross groove is provided with a penetrating exhaust hole 16 which is communicated with an external gas circuit; and then roughening and cleaning the surface of the sunken table (machining the sunken table, the through hole, the annular groove, the cross groove, the exhaust hole 16 and roughening and cleaning the surface of the sunken table are conventional in the art, which are not innovative in the present invention and will not be described herein again).

Milling and processing the porous alumina ceramics with the diameter of 300 x 6mm according to the size of the sinking platform, and grinding defect layers on two end surfaces of the porous alumina ceramics to obtain the porous adsorption component. Coating ceramic adhesive on the surface of the sinking platform (selected according to the conventional technology in the field), then embedding the porous adsorption component, placing the porous adsorption component in a high-temperature drying box, heating to 300 â, pressurizing and curing to obtain the porous vacuum chuck. The schematic structure of the porous vacuum chuck manufactured in this example is shown in fig. 7.

The multi-hole vacuum chuck suction force testing device is shown in fig. 6, which is characterized in that a suction force tester 15 is added on the device in fig. 1, the negative pressure value of a vacuum pump 5 is adjusted to 0.9 atmospheric pressure, standard detection sample pieces 14 (the standard detection sample pieces 14 are aluminum alloy plates, the standard detection sample pieces 14 are adsorbed workpieces which do not completely cover an adsorption area, and are the same as 701 in fig. 3) with the size of 50mm by 5mm are placed on 5 different positions on a multi-hole adsorption part, the suction force tester 15 is connected with the standard detection sample pieces 14, and the average adsorption pressure in unit area is measured to be 42KPa through a tensile test.

Therefore, the porous vacuum chuck prepared by the embodiment can also stably adsorb 4 inches, 5 inches, 6 inches, 8 inches and 12 inches of wafers (the larger the workpiece area is, the larger the adsorption force is, the larger the 4 inches area is larger than the standard detection sample piece 14, so that the situation that the wafers are stably adsorbed on the surface of the porous ceramic in the operation process, such as wafer falling deflection and the like can not occur) for carrying, thinning and cutting, the wafers below 100 microns can be thinned without deformation and adsorption traces, and when the wafers with different sizes are replaced, the wafers can be directly adsorbed and processed without replacing the vacuum chuck.

Example 2

Heating a tert-butyl alcohol solvent in a constant-temperature water bath to 50 â, adding 60vol% of YSZ zirconia powder with the average particle size of 3 mu m, 2wt% of methylcellulose and 1wt% of polyvinyl alcohol into the solvent, uniformly stirring, placing the mixture into a ball mill preheated to 50 â, and carrying out ball milling at the speed of 800r/min for 4 hours to obtain ceramic slurry.

Setting the cooling platform to be-80 â, sequentially placing an aluminum mould bottom plate 10 with the thickness of 3mm and a polyurethane double-ring mould frame 11 with the thickness of 40mm, quickly pouring the prepared ceramic slurry into an annular mould, after cooling for 2 hours, completely freezing the slurry, removing the frame 11, taking off the frozen YSZ annular blank, and placing the YSZ annular blank in a 10 â ventilation environment for sublimation and drying for 40 hours.

And (3) putting the dried YSZ annular blank into a normal pressure sintering furnace to be sintered at 1600 â to obtain the porous zirconia ceramic. It also has a through hole structure perpendicular to the cooling surface; the average pore diameter was 2 Î¼m and the porosity was 41% as measured by mercury porosimetry.

An annular sinking platform with the inner diameter of 150mm, the outer diameter of 480mm and the height of 3mm is processed on a circular-plate-shaped stainless steel base, a through hole is processed in the middle of the base, a plurality of circles of annular grooves and radial grooves are milled on the sinking platform, 4 vertical through exhaust holes 16 are uniformly distributed at the joint of the grooves and communicated with an external gas circuit to coarsen and clean the surface of the sinking platform.

And milling porous zirconia ceramics with the inner diameter of 150mm, the outer diameter of 480mm and the height of 3mm according to the size of the sinking platform, and grinding defect layers on two end surfaces of the porous ceramics to obtain the porous adsorption component.

Coating resin binder on the surface of the sinking platform, then embedding the porous adsorption component, placing the component in a blast drying oven, heating to 80 â, pressurizing and curing to obtain the porous vacuum sucker. The schematic structure of the porous vacuum chuck manufactured in this example is shown in fig. 8.

As shown in fig. 6, the vacuum value of the vacuum pump 5 was adjusted to 0.9 atm, and the standard test pieces 14 (same as example 1) having a size of 50mm by 5mm were placed at 8 positions on the porous suction member, and the average suction pressure per unit area was measured to be 23KPa by a tensile test.

The porous vacuum chuck prepared by the embodiment can adsorb 6 sapphire sheets or zirconia substrates of 6 inches in an annular area for polishing, does not need precise positioning, omits the waxing and dewaxing processes, and avoids the breaking and pollution in the process.

Example 3

Mixing 70wt% of tert-butyl alcohol and water, heating the mixture to 60 â in a constant-temperature water bath, adding 40vol% of silicon carbide powder with the average particle size of 25 mu m, 4wt% of tetramethylammonium hydroxide and 6wt% of polyvinyl alcohol, uniformly stirring, placing the mixture in a ball mill preheated to 60 â, and carrying out ball milling for 20 hours at the speed of 600r/min to obtain ceramic slurry.

Setting a cooling platform to be-40 â, sequentially placing a stainless steel mold bottom plate 10 with the thickness of 5mm and a square mold frame 11 made of nylon with the thickness of 40mm, quickly pouring the prepared ceramic slurry into the mold, after cooling for 8 hours, completely freezing the slurry, removing the frame 11, taking down the frozen square plate-shaped silicon carbide blank, and placing the blank in a 5 â ventilation environment for sublimation drying for 48 hours.

And (3) putting the dried square plate-shaped silicon carbide blank into a hydrogen atmosphere sintering furnace to be sintered at 1200 â to obtain the porous silicon carbide ceramic. It also has a through hole structure perpendicular to the cooling surface; the average pore diameter was 28 Î¼m and the porosity was 50% as measured by mercury porosimetry.

The method comprises the steps of processing a 300 x 4mm square sinking platform on a silicon carbide ceramic base, processing a through hole in the middle of the base, milling a groove shaped like a Chinese character 'mi' and a well-shaped air passage on the sinking platform along the central line, and forming a through exhaust hole 16 in the center of the groove shaped like a Chinese character 'mi' to be communicated with an external air passage for roughening and cleaning the surface of the sinking platform.

And milling the porous silicon carbide ceramic with the size of 300 Ã 4mm according to the size of the sinking platform, and grinding off defect layers on two end faces of the porous ceramic to obtain the porous adsorption component. And coating a glass binder on the surface of the sinking platform, embedding the porous adsorption component, placing the sinking platform in an atmosphere sintering furnace, heating to 600 â, pressurizing and curing to obtain the porous vacuum sucker.

As shown in fig. 6, the vacuum value of the vacuum pump 5 was adjusted to 0.9 atm, and the standard test sample 14 (same as example 1) having a size of 50mm by 5mm was placed at 9 positions in the porous adsorption region, and the average adsorption pressure per unit area was measured to be 29KPa by a tensile test.

The porous vacuum chuck prepared by the embodiment can be used for laser detection and processing of window pieces with different shapes from 4 inches to 12 inches, laser focusing is accurate and diffusion-free, and the porous vacuum chuck has a good anti-static effect due to the semiconductor characteristic of the silicon carbide material.

Comparative example 1

A stainless steel porous adsorption member having a pore diameter of 500 Î¼m and a pore area ratio of 5% was fabricated by a punching method in place of the porous alumina ceramics in example 1, and the porous adsorption member was bonded to the susceptor by welding. The manufactured porous vacuum chuck was tested, the negative pressure value of the vacuum pump 5 was adjusted to 0.9 atm, the standard test piece 14 (same as example 1) having a size of 50mm by 5mm was covered on 5 positions in the porous adsorption region, and the adsorption pressure at the central region was measured to be 35KPa, while the average adsorption pressure at the edge region was only 5KPa, and the adsorption force was not uniform, by the tensile test. When a thin film piece having a thickness of 2mm or less is adsorbed, remarkable dent deformation occurs.

Comparative example 2

A porous silicon carbide ceramic adsorbent member having an average pore diameter of 50 Î¼m and a porosity of 30 vol% was prepared by depositing pores and adding a pore-forming agent in place of the porous silicon carbide ceramic in example 3, and the processes of the susceptor and the sealing layer were not changed. The manufactured porous vacuum chuck is detected, the negative pressure value of the vacuum pump 5 is adjusted to 0.9 atmospheric pressure, the standard detection sample piece 14 (same as the embodiment 1) with the size of 50mm 5mm is covered at 9 positions in the porous adsorption area, the average adsorption pressure of the unit area is measured to be less than 2KPa through a tensile test, the displacement and falling phenomenon is easy to occur during adsorption, and stable adsorption cannot be realized.

## Classifications

- B65G47/91
- B65G2201/02
- B65G47/91
- C04B2235/96
- C04B35/10
- C04B35/10
- C04B35/48
- C04B35/48
- C04B35/565
- C04B35/565
- C04B38/06
- C04B38/067
- Y02P70/50

## Cited patent documents

- [CN-101298386-A](https://patents.google.com/patent/CN101298386A/en) — SEA
- [CN-102260092-A](https://patents.google.com/patent/CN102260092A/en) — SEA
- [CN-102740947-A](https://patents.google.com/patent/CN102740947A/en) — SEA
- [CN-102826855-A](https://patents.google.com/patent/CN102826855A/en) — SEA
- [CN-111393180-A](https://patents.google.com/patent/CN111393180A/en) — SEA
- [CN-2746181-Y](https://patents.google.com/patent/CN2746181Y/en) — SEA
- [EP-0479553-A1](https://patents.google.com/patent/EP0479553A1/en) — SEA
- [US-2010112330-A1](https://patents.google.com/patent/US20100112330A1/en) — SEA
- [US-3852099-A](https://patents.google.com/patent/US3852099A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
