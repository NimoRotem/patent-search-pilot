# 20. Suction body for vacuum suction apparatus, and vacuum suction apparatus

- **Archive rank:** 20 of 50
- **Publication:** [JP-2009253247-A](https://patents.google.com/patent/JP2009253247A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/041313609/publication/JP2009253247A?q=pn%3DJP2009253247A)
- **Publication date:** 2009-10-29
- **Filing date:** 2008-04-11
- **Earliest priority:** 2008-04-11
- **Family:** 41313609
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** ARIAKE MATERIALS CO LTD

## Abstract

&lt;P&gt;PROBLEM TO BE SOLVED: To provide a suction body for a vacuum suction apparatus without level difference on a sucked body mounting surface of the suction body, and having remarkably successful sucking power, and to provide a vacuum suction apparatus having the sucking body.  &lt;P&gt;SOLUTION: The invention provides the suction body which is characterized in that it is the suction body for the vacuum suction apparatus consisting of a plate made of ceramic whose average pore diameter is 2-5 μm, and pore ratio is 30-40%, and at least a part of an outer peripheral surface of the plate is covered with a sealer, and the apparatus which is characterized in that it is the vacuum suction apparatus having the suction body (9) consisting of a porous plate made of ceramic, and a substrate (1) for mounting the sucked body, and the substrate has an intake air groove (3) on the sucked body mounting surface, and an intake air passage (6) connected to the intake air groove and continued to the outer surface of the substrate inside the substrate, and the suction body (9) is the suction body for the vacuum suction apparatus.  &lt;P&gt;COPYRIGHT: (C)2010,JPO&amp;INPIT

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/de/1c/88/0b2561d976e468/2009253247-6.png)

![Sketch 1 for JP-2009253247-A](https://patentimages.storage.googleapis.com/de/1c/88/0b2561d976e468/2009253247-6.png)

[Sketch 2](https://patentimages.storage.googleapis.com/a7/aa/ab/45ce264f758b63/2009253247-7.png)

![Sketch 2 for JP-2009253247-A](https://patentimages.storage.googleapis.com/a7/aa/ab/45ce264f758b63/2009253247-7.png)

## Claims

### Claim 1

平均気孔径が2〜5μmであり、かつ気孔率が30〜40%であるセラミック製平板から成る真空吸着装置用吸着体であって、該平板の少なくとも外周面の一部が、封孔剤により被覆されており、かつ該封孔剤被覆厚が0.05〜2mmであることを特徴とする吸着体。

### Claim 2

封孔剤が、ガラス質物質及び樹脂より成る群から選ばれるところの請求項1記載の吸着体。

### Claim 3

セラミック製多孔質平板から成る吸着体(9)と該吸着体を載置する基盤(1)とを備え、かつ該基盤(1)が、吸着体載置面(2)に吸気溝(3)を有すると共に、該吸気溝(3)と連通しかつ基盤外表面へと続く吸気通路(6)を基盤内部に有するところの真空吸着装置であって、該吸着体(9)が、請求項1又は2記載の吸着体であることを特徴とする装置。

## Full description

Description

Translated from Japanese

æ¬çºæã¯ãã»ã©ããã¯è£½å¤å­è³ªå¹³æ¿ããæãçç©ºå¸çè£

ç½®ç¨å¸çä½åã³è©²å¸çä½ãåããçç©ºå¸çè£

ç½®ã«é¢ããã

The present invention relates to an adsorbent for a vacuum adsorber comprising a ceramic porous flat plate and a vacuum adsorber provided with the adsorber.

åå°ä½ã¦ã¨ãã¼åã³ã¬ã©ã¹åºæ¿ç­ã®ç åå å·¥åã³ç ç£¨å å·¥ä¸¦ã³ã«ç²¾å¯æ¸¬å®ã¯ãéå¸¸ãçç©ºå¸çè£

ç½®ãä½¿ç¨ãã¦ããããåå°ä½ã¦ã¨ãã¼åã³ã¬ã©ã¹åºæ¿ç­ãå¸çä½ã®è¢«å¸çä½è¼ç½®é¢ã«åºå®ãããã¨ã«ããå®æ½ããã¦ãããå¾æ¥ãè©²å¸çä½ã¯ä¸­å¤®é¨ã®å¸çé¨ã¨ãã®å¨å²ã®æ¯æé¨ã¨ã«ããæ§æããã¦ãã(ç¹è¨±æç®1åã³2)ãå¸çé¨ãæ§æããææã¨ãã¦ã¯ãä¾ãã°ãå¤å­è³ªã»ã©ããã¯ãç¼çµãã©ã¹ããã¯ç­ã®å¤å­è³ªç©è³ªãä½¿ç¨ããã¦ããããã¤æ¯æé¨ãæ§æããææã¨ãã¦ã¯ãä¾ãã°ãéå±ãç·»å¯è³ªã»ã©ããã¯ç­ãä½¿ç¨ããã¦ããã

Grinding and polishing of semiconductor wafers and glass substrates, and precision measurement are usually carried out by fixing these semiconductor wafers and glass substrates, etc., to the adsorbent mounting surface of the adsorbent using a vacuum adsorption device. Has been. Conventionally, the adsorbent is constituted by a central adsorbing portion and a supporting portion around the adsorbing portion (Patent Documents 1 and 2). For example, porous materials such as porous ceramics and sintered plastics are used as the material constituting the adsorption part, and metals, dense ceramics, etc. are used as the material constituting the support part. ing.

ãããå¾æ¥ã®å¸çä½ã«ããã¦ãéå¸¸ãå¸çé¨ãæ§æããå¤å­è³ªç©è³ªã¯æ¯æé¨ãæ§æããææã¨æ¯è¼ãã¦ç¡¬åº¦ãä½ããå¾ã£ã¦ãç åå å·¥ãç ç£¨å å·¥ç­ãæ½ãã¨å¸çé¨ãããå¤ãåããã¦ãå¸çé¨ã¨æ¯æé¨ã¨ã®éã«å

ããªæ®µå·®ãçãããæ

ã«ãå¸çä½ã®è¢«å¸çä½è¼ç½®é¢ã®å

¨ä½ãå¹³å¦ãªé¢ã«ä»ä¸ãããã¨ã¯å®¹æã§ã¯ãªãã£ãã

In such a conventional adsorbent, the porous substance constituting the adsorbing part usually has a lower hardness than the material constituting the supporting part. Therefore, when the grinding process, the polishing process, or the like is performed, the suction part is more scraped, and a slight step is generated between the suction part and the support part. Therefore, it is not easy to finish the entire adsorbent mounting surface of the adsorbent to a flat surface.

å¸çé¨ã¨æ¯æé¨ã¨ããæ§æãããå¸çä½ã«ãå¤§å¤å½¢ã®åå°ä½ã¦ã¨ãã¼åã³ã¬ã©ã¹åºæ¿ç­ã®è¢«å¸çä½ãå¸çãããã¨ããããè¢«å¸çä½ã®ä¸é¨ãæ¯æé¨ã«ã¾ã§éãããå¾ã£ã¦ãå¸çé¨ã¨æ¯æé¨ã¨ã®éã«å

ããªæ®µå·®ãå­å¨ããã¨ãå¸çé¨ã®å¸çé¢ã¨ãããã®è¢«å¸çä½ã¨ã®éã«ééãçããè¯å¥½ãªå¸çãå¾ãããªããã¨ããã£ããä¸æ¹ãè¢«å¸çä½ã®å¤å½¢ããå¸çé¨ã®é¢ç©ã«æ¯ã¹ã¦å°ãéããããåã¯è¢«å¸çä½ãå¤§ããªã¹ã«ã¼ãã¼ã«ãåãã¦ãããããã¨ãå¸çé¨ã®éæ¾é¢ç©ãå¤§ãããªããè¯å¥½ãªå¸çãå¾ãããªããã¨ããã£ãããããã®åé¡ã«å¯¾å¦ããããã«ãå¸çé¨ã®é¢ç©ãç°ãªãç¨®ã

ã®çç©ºå¸çè£

ç½®ãæºåããããåã¯ãå¸çé¨ã®éæ¾é¨åãä½ããã®ææ®µãç¨ãã¦é½åº¦å¡ãã¨ããå¯¾ç­ãæ¡ããã¦ããã

When an object to be adsorbed such as a large-sized semiconductor wafer and a glass substrate is adsorbed to an adsorbent composed of an adsorbing part and a support part, a part of the adsorbed object reaches the support part. Therefore, if there is a slight step between the adsorption part and the support part, a gap is generated between the adsorption surface of the adsorption part and these adsorbents, and good adsorption may not be obtained. On the other hand, if the outer shape of the object to be adsorbed is too small compared to the area of the adsorbing part, or if the object to be adsorbed has a large through hole, the open area of the adsorbing part increases, and good adsorption cannot be obtained. There was a thing. In order to cope with these problems, various vacuum suction devices having different suction part areas are prepared, or a measure is taken to block the open part of the suction part each time using some means.

ç¹éå¹³8-19927å·å

¬å ±Japanese Patent Laid-Open No. 8-19927

ç¹é2007-253284å·å

¬å ±JP 2007-253284 A

ç¹é¡2007-106728å·Japanese Patent Application No. 2007-106728

æ¬çºæã¯ãå¸çä½ã®è¢«å¸çä½è¼ç½®é¢ã«æ®µå·®ããªãããã¤èããè¯å¥½ãªå¸çåãæããçç©ºå¸çè£

ç½®ç¨å¸çä½ãåã³è©²å¸çä½ãåããçç©ºå¸çè£

ç½®ãæä¾ãããã®ã§ããã

The present invention provides an adsorbent for a vacuum adsorbing device having no step on the adsorbent mounting surface of the adsorbent and having a remarkably good adsorbing force, and a vacuum adsorbing device provided with the adsorbent.

æ¬çºæè

ã¯ãå¾æ¥ã®çç©ºå¸çè£

ç½®ç¨å¸çä½ã«å­å¨ãããå¸çé¨ã¨æ¯æé¨ã¨ã®éã«å

ããªæ®µå·®ãçãå¸çä½ã®è¢«å¸çä½è¼ç½®é¢å

¨ä½ãå¹³å¦ãªé¢ã«ä»ä¸ãããã¨ãå®¹æã§ã¯ãªãã¨ããåé¡ãè§£æ±ºãã¹ããç¨®ã

ã®æ¤è¨ãè¡ã£ãããã®çµæãå¸çä½ããå¾æ¥å¿

é ã¨ããã¦ããæ¯æé¨ãåãããå¸çé¨ã®ã¿ããæ§æããããã¨ãã§ããã°ãå¸çä½ã®è¢«å¸çä½è¼ç½®é¢å

¨ä½ãå¹³å¦ãªé¢ã«ä»ä¸ããå¾ããã¨ã«æãè³ã£ãã

The present inventor has a slight step between the adsorbing portion and the supporting portion existing in the adsorbing body for the conventional vacuum adsorbing device, and it is easy to finish the entire adsorbent mounting surface of the adsorbing body to a flat surface. In order to solve the problem of not being, various studies were conducted. As a result, if the adsorbent does not include the support portion that has been required in the past and can be configured only by the adsorbing portion, the entire adsorbent mounting surface of the adsorbent can be finished to a flat surface. It came.

ä¸æ¹ãå¾æ¥ã®å¸çä½ã®æ¯æé¨ã¯å¸çé¨ãæ¯ããã¨ããåãã°ããã§ã¯ãªããå¤å­è³ªç©è³ªããæ§æãããå¸çé¨ã®å¤é¢ãè¦ããã¨ã§ãå¸çé¨ã®å¸çåãé«ãç¶­æããã¨ããåãããæãã¦ãããå¾ã£ã¦ãåã«æ¯æé¨ãåãé¤ããã ãã§ã¯ãå¸çä½æ¬æ¥ã®ä½ç¨ã§ããé«ãå¸çåãç¶­æãããã¨ã¯ã§ããªãã

On the other hand, the support part of the conventional adsorbent not only functions to support the adsorbing part, but also has the function of maintaining the adsorbing force of the adsorbing part high by covering the outer surface of the adsorbing part made of a porous material. Was. Therefore, it is not possible to maintain the high adsorption force that is the original function of the adsorbent by simply removing the support portion.

ããã§ãæ¬çºæè

ã¯æ´ã«æ¤è¨ãç¶ããçµæãå¸çé¨ã®å¹³åæ°å­å¾ãæå®ã®å¤ãå³ã¡ãå¾æ¥ã®çç©ºå¸çè£

ç½®ç¨å¸çä½ã®å¹³åæ°å­å¾ã®1/3ã1/10ç¨åº¦ã«è¨­å®ããã°ãå¸çä½ããæ¯æé¨ãåãé¤ãã¦ããå¸çé¨ã®é«ãå¸çåãä¿æãå¾ããã¨ãè¦åºããå¹³åæ°å­å¾ã2ã5Î¼mãæ°å­çã30ã40%ã®å¹³æ¿ç¶å¤å­è³ªã»ã©ããã¯ããæããã¨ãç¹å¾´ã¨ããçç©ºå¸çè£

ç½®ç¨å¸çä½ãåºé¡ãã(ç¹è¨±æç®3)ã

Therefore, as a result of further investigation, the present inventor set the average pore diameter of the adsorption part to a predetermined value, that is, about 1/3 to 1/10 of the average pore diameter of the adsorbent for the conventional vacuum adsorption device. For example, it is found that even if the support part is removed from the adsorbent, it is possible to maintain a high adsorbing power of the adsorbing part, and it is composed of a flat porous ceramic having an average pore diameter of 2 to 5 Î¼m and a porosity of 30 to 40%. An application was made for an adsorbent for a vacuum adsorber characterized by the following (Patent Document 3).

æ¬çºæè

ã¯ãä¸è¨ã®çç©ºå¸çè£

ç½®ç¨å¸çä½ã«ãããä¸å±¤è¯å¥½ãªå¸çåãä»ä¸ãã¹ããæ´ãªãæ¤è¨ãç¶ããããã®çµæãå°å­å¤ã«ãããä¸è¨ã®å¹³æ¿ç¶å¤å­è³ªã»ã©ããã¯ã®å¤è¡¨é¢ãè¢«è¦ãããã¨ã«æãè³ã£ããå°å­å¤ãä½¿ç¨ããã°ãéå¸¸ã«èãè¢«è¦ã«ãããå¤å­è³ªã»ã©ããã¯ã®å¤è¡¨é¢ã«å­å¨ããå­ãååã«å°ãããã¨ãã§ãããå¾ã£ã¦ãå¸çä½ã«ãããä¸å±¤è¯å¥½ãªå¸çåãä»ä¸ãããã¨ãã§ããã°ããã§ã¯ãªããå¤å­è³ªã»ã©ããã¯ã¨ã®ç¡¬åº¦å·®ãèæ

®ããå¿

è¦ããªããå¸çä½ã®è¢«å¸çä½è¼ç½®é¢å

¨ä½ãå¹³å¦ãªé¢ã«ä»ä¸ããå¾ããã¨ãè¦åºããã

The present inventor has continued to further study in order to give a better adsorption force to the above-described adsorbent for vacuum adsorption apparatus. As a result, the inventors have come up with the idea of coating the outer surface of the flat porous ceramic with a sealing agent. If a sealing agent is used, a very thin coating can sufficiently seal pores present on the outer surface of the porous ceramic. Therefore, not only can the adsorbing body be given even better adsorbing power, but there is no need to consider the hardness difference from the porous ceramic, and the entire adsorbent mounting surface of the adsorbing body is flat. Found that you can get to finish.

å³ã¡ãæ¬çºæã¯

(1)å¹³åæ°å­å¾ã2ã5Î¼mã§ããããã¤æ°å­çã30ã40%ã§ããã»ã©ããã¯è£½å¹³æ¿ããæãçç©ºå¸çè£

ç½®ç¨å¸çä½ã§ãã£ã¦ãè©²å¹³æ¿ã®å°ãªãã¨ãå¤å¨é¢ã®ä¸é¨ããå°å­å¤ã«ããè¢«è¦ããã¦ããããã¤è©²å°å­å¤è¢«è¦åã0.05ã2mmã§ãããã¨ãç¹å¾´ã¨ããå¸çä½ã§ããã

That is, the present invention

(1) An adsorbent for a vacuum adsorption device comprising a ceramic flat plate having an average pore diameter of 2 to 5 Î¼m and a porosity of 30 to 40%, wherein at least a part of the outer peripheral surface of the flat plate is sealed The adsorbent is characterized in that it is covered with a pore agent and has a thickness of 0.05 to 2 mm.

å¥½ã¾ããæ

æ§ã¨ãã¦ã

(2)å°å­å¤ã«ããè¢«è¦ããè©²å¹³æ¿ã®å¤å¨é¢ã«æ½ããã¦ããã¨ããã®ä¸è¨(1)è¨è¼ã®å¸çä½ã

(3) å°å­å¤ã«ããè¢«è¦ããè©²å¹³æ¿ã®å¤å¨é¢åã³ä»ã®ä¸é¢ã«æ½ããã¦ããã¨ããã®ä¸è¨(1)è¨è¼ã®å¸çä½ã

(4)å¹³æ¿å¤å¨é¢ã®å°å­å¤è¢«è¦åãã0.05ã1mmã§ããã¨ããã®ä¸è¨(1)ã(3)ã®ããããä¸ã¤ã«è¨è¼ã®å¸çä½ã

(5)å¹³æ¿å¤å¨é¢ã®å°å­å¤è¢«è¦åãã0.05ã0.5mmã§ããã¨ããã®ä¸è¨(1)ã(3)ã®ããããä¸ã¤ã«è¨è¼ã®å¸çä½ã

(6)å°å­å¤ããã¬ã©ã¹è³ªç©è³ªåã³æ¨¹èããæãç¾¤ããé¸ã°ããã¨ããã®ä¸è¨(1)ã(5)ã®ããããä¸ã¤ã«è¨è¼ã®å¸çä½ã

(7)ã¬ã©ã¹è³ªç©è³ªããã¬ã©ã¹ç²æ«ãæ°´ã¬ã©ã¹åã³ç¡æ©è³ªã³ã¼ãã£ã³ã°å¤ããæãç¾¤ããé¸ã°ããã¨ããã®ä¸è¨(6)è¨è¼ã®å¸çä½ã

(8)æ¨¹èãããã§ãã¼ã«æ¨¹èãã·ãªã³ã¼ã³æ¨¹èãã¨ãã­ã·æ¨¹èãã¡ã©ãã³æ¨¹èãå°¿ç´ æ¨¹èãä¸é£½åããªã¨ã¹ãã«æ¨¹èãã¢ã«ã­ãæ¨¹èãããªã¦ã¬ã¿ã³åã³ç±ç¡¬åæ§ããªã¤ããããæãç¾¤ããé¸ã°ããã¨ããã®ä¸è¨(6)è¨è¼ã®å¸çä½ã

(9)å¹³åæ°å­å¾ãã2.5ã4Î¼mã§ããã¨ããã®ä¸è¨(1)ã(8)ã®ããããä¸ã¤ã«è¨è¼ã®å¸çä½ã

(10)æ°å­çãã30ã35%ã§ããã¨ããã®ä¸è¨(1)ã(9)ã®ããããä¸ã¤ã«è¨è¼ã®å¸çä½

ãæãããã¨ãã§ããã

As a preferred embodiment,

(2) The adsorbent according to (1) above, wherein coating with a sealing agent is applied to the outer peripheral surface of the flat plate,

(3) The adsorbent according to the above (1), wherein coating with a sealing agent is applied to the outer peripheral surface of the flat plate and the other one surface,

(4) The adsorbent according to any one of (1) to (3) above, wherein the sealing agent coating thickness on the outer peripheral surface of the flat plate is 0.05 to 1 mm,

(5) The adsorbent according to any one of (1) to (3) above, wherein the sealing agent coating thickness on the outer peripheral surface of the flat plate is 0.05 to 0.5 mm,

(6) The adsorbent according to any one of (1) to (5) above, wherein the sealing agent is selected from the group consisting of a vitreous substance and a resin.

(7) The adsorbent according to (6) above, wherein the vitreous substance is selected from the group consisting of glass powder, water glass and an inorganic coating agent.

(8) The adsorption according to the above (6), wherein the resin is selected from the group consisting of phenol resin, silicone resin, epoxy resin, melamine resin, urea resin, unsaturated polyester resin, alkyd resin, polyurethane and thermosetting polyimide. body,

(9) The adsorbent according to any one of (1) to (8) above, wherein the average pore diameter is 2.5 to 4 Î¼m,

(10) The adsorbent according to any one of (1) to (9) above, wherein the porosity is 30 to 35%.

ã¾ããæ¬çºæã¯ã

(11)ã»ã©ããã¯è£½å¤å­è³ªå¹³æ¿ããæãå¸çä½(9)ã¨è©²å¸çä½ãè¼ç½®ããåºç¤(1)ã¨ãåãããã¤è©²åºç¤(1)ããå¸çä½è¼ç½®é¢(2)ã«å¸æ°æº(3)ãæããã¨å

±ã«ãè©²å¸æ°æº(3)ã¨é£éããã¤åºç¤å¤è¡¨é¢ã¸ã¨ç¶ãå¸æ°éè·¯(6)ãåºç¤å

é¨ã«æããã¨ããã®çç©ºå¸çè£

ç½®ã§ãã£ã¦ãè©²å¸çä½(9)ããä¸è¨(1)ã(10)ã®ããããä¸ã¤ã«è¨è¼ã®å¸çä½ã§ãããã¨ãç¹å¾´ã¨ããè£

ç½®ã§ããã

The present invention also provides:

(11) It is provided with an adsorbent body (9) made of a ceramic porous flat plate and a base (1) on which the adsorbent is placed, and the base (1) has an intake groove on the adsorbent placing surface (2). (3) and a suction device (6) that communicates with the suction groove (3) and continues to the outer surface of the substrate and has an intake passage (6) inside the substrate, the adsorber (9), An apparatus according to any one of the above (1) to (10).

å¥½ã¾ããæ

æ§ã¨ãã¦ã

(12)å¸æ°éè·¯(6)ããåºç¤å¤å¨è¡¨é¢ã¸ã¨ç¶ãã¨ããã®ä¸è¨(11)è¨è¼ã®è£

ç½®

ãæãããã¨ãã§ããã

As a preferred embodiment,

(12) The apparatus described in (11) above, wherein the intake passage (6) continues to the outer peripheral surface of the base.

æ¬çºæã®å¸çä½ã¯ãè¢«å¸çä½è¼ç½®é¢å

¨ä½ã«æ®µå·®ããªãå¹³æ»ã§ããããã¤èããå°ããªå¹³åæ°å­å¾åã³æå®ã®æ°å­çãæããå ãã¦å¤è¡¨é¢ã®ä¸é¨ãå°å­å¤ã«ããè¢«è¦ããã¦ãããå¾ã£ã¦ãè¢«å¸çä½ã®å¤§ãããå¤å½¢åã³ã¹ã«ã¼ãã¼ã«ã®æç¡ç­ã®å½±é¿ãåãããã¨ããªããå¸¸ã«ãèããè¯å¥½ãªå¸çåãæãããã¾ããæ¬çºæã®å¸çä½ã¯ãå¾æ¥å¿

é ã§ãã£ãæ¯æé¨ãå¿

è¦ã¨ããªããå¾ã£ã¦ãå¸çä½ã®å å·¥ç²¾åº¦ãé«ãå¾ãã°ããã§ã¯ãªããè»½éåãå¯è½ã§ããããã¤å¸çä½ãå®¹æãã¤å®ä¾¡ã«è£½é ãå¾ããå ãã¦ãæ¬çºæã®å¸çä½ã¯å¤å­è³ªã»ã©ããã¯åã³èããèãå°å­å¤è¢«è¦ããæ§æããã¦ããæ

ãå ç±ã«ããç±è¨å¼µã®ç¸éã«ä¼´ãæ­ªãèæ

®ããå¿

è¦ããªããé«æ¸©ä¸ã«ãããè¢«å¸çä½ã®å å·¥ãå¯è½ã§ããã

The adsorbent of the present invention is smooth with no steps on the entire surface to be adsorbed, and has an extremely small average pore diameter and a predetermined porosity, and in addition, a part of the outer surface is covered with a sealing agent. Has been. Accordingly, it is not affected by the size of the object to be adsorbed, the outer shape, the presence or absence of through-holes, etc., and always has a remarkably good adsorbing power. Further, the adsorbent of the present invention does not require a support portion that has been essential in the past. Therefore, not only the processing accuracy of the adsorbent can be increased, but also the weight can be reduced, and the adsorbent can be manufactured easily and inexpensively. In addition, since the adsorbent of the present invention is composed of a porous ceramic and a remarkably thin sealant coating, there is no need to take into account the strain associated with the difference in thermal expansion due to heating, and processing of the adsorbent at high temperatures. Is possible.

æ¬çºæã®çç©ºå¸çè£

ç½®ç¨å¸çä½ã«ãããå¹³åæ°å­å¾ã®ä¸éã¯5Î¼mãå¥½ã¾ããã¯4Î¼mã§ãããä¸éã¯2Î¼mãå¥½ã¾ããã¯2.5Î¼mã§ãããä¸è¨ä¸éãè¶

ããã¨ãç©ºæ°å¸å¼éãå¤ããªãéãã¦ãå¸çåãä½ä¸ããä¸è¨ä¸éæªæºã§ã¯ãç©ºæ°å¸å¼éãä¸è¶³ãã¦ãåæ§ã«å¸çåãä½ä¸ãããããã§ãè©²å¹³åæ°å­å¾ã¯ãæ°´éå§å

¥å¼ãã­ã·ã¡ã¼ã¿ã«ããæ¸¬å®ããå¤ã§ããã

The upper limit of the average pore diameter in the adsorbent for a vacuum adsorption apparatus of the present invention is 5 Î¼m, preferably 4 Î¼m, and the lower limit is 2 Î¼m, preferably 2.5 Î¼m. When the above upper limit is exceeded, the air suction amount becomes excessively large and the adsorptive power decreases, and when it is less than the above lower limit, the air suction amount becomes insufficient and the adsorptive power similarly decreases. Here, the average pore diameter is a value measured by a mercury intrusion porosimeter.

æ°å­çã®ä¸éã¯40%ãå¥½ã¾ããã¯35%ã§ãããä¸éã¯30%ã§ãããä¸è¨ä¸éãè¶

ããã¨ãè¢«å¸çä½è¼ç½®é¢ã®è¡¨é¢å¹³æ»æ§ãä½ä¸ããä¸è¨ä¸éæªæºã§ã¯ãå¸çåãä½ä¸ãããããã§ãè©²æ°å­çã¯ãJIS-C2141(é»æ°çµ¶ç¸ç¨ã»ã©ããã¯ææè©¦é¨æ¹æ³)ã«è¦å®ãããå¸æ°´çã®æ¸¬å®(ã¢ã«ã­ã¡ãã¹æ³)ã«æºæ ãã¦æ¸¬å®ããå¤ã§ããã

The upper limit of the porosity is 40%, preferably 35%, and the lower limit is 30%. If the above upper limit is exceeded, the surface smoothness of the adsorbent mounting surface is lowered, and if it is less than the lower limit, the adsorbing power is lowered. Here, the porosity is a value measured in accordance with the water absorption measurement (Archimedes method) defined in JIS-C2141 (Test method for ceramic material for electrical insulation).

ã»ã©ããã¯è£½å¹³æ¿ãæ§æããã»ã©ããã¯ã¯ãç¹ã«éå®ããããã®ã§ã¯ãªãããããç²¾å¯ãªå å·¥ãå¯è½ã§ããããã¤è¡¨é¢å¹³æ»åº¦ãé«ãå¾ããã¨ãããå¥½ã¾ããã¯å¿«åæ§å¤å­è³ªã»ã©ããã¯ãä½¿ç¨ããããå¿«åæ§å¤å­è³ªã»ã©ããã¯ã®ä¸­ã§ããã¯ã©ã¹ããã¤ãç³»å¤å­è³ªä½ããã¼ã©ã¹ã¢ã«ããããã¼ã©ã¹ã·ãªã«ãæ°å­å¾ãæ°å­çåã³å å·¥æ§ã®è¦³ç¹ããããå¥½ã¾ãããã¯ã©ã¹ããã¤ãç³»å¤å­è³ªä½åã³ãã®è£½é æ³ã¯å

¬ç¥ã§ãããè©³ããã¯ç¹å

¬å¹³4-21632å·å

¬å ±ã«è¨è¼ããã¦ããã

The ceramic constituting the ceramic flat plate is not particularly limited, but a free-cutting porous ceramic is preferably used because it can be processed more precisely and can increase the surface smoothness. Among the free-cutting porous ceramics, a wollastonite-based porous material, porous alumina, and porous silica are more preferable from the viewpoints of pore diameter, porosity, and workability. A wollastonite porous body and a method for producing the same are known, and are described in detail in JP-B-4-16332.

æ¬çºæã®çç©ºå¸çè£

ç½®ç¨å¸çä½ãæ§æããã»ã©ããã¯è£½å¹³æ¿ã¯ãå°ãªãã¨ãå¤å¨é¢ã®ä¸é¨ãå°å­å¤ã«ããè¢«è¦ããã¦ãããè¢«è¦é¨åã¯ãå¸çä½ã®ä½¿ç¨æ

æ§ã«ããç¸éããããå¸çä½ãåºç¤ä¸ã«è¼ç½®ãã¦ä½¿ç¨ããæ

æ§ã«ããã¦ã¯ãã»ã©ããã¯è£½å¹³æ¿ã®å¤å¨é¢ã®ä¸é¨åã¯å

¨é¨ãè¢«è¦ãããã¨ãå¥½ã¾ãããä¸æ¹ãåºç¤ã«è¼ç½®ããã«å¸çä½ã®ã¿ã§ä½¿ç¨ããæ

æ§ã«ããã¦ã¯ãã»ã©ããã¯è£½å¹³æ¿ã®å¤å¨é¢åã³ä»ã®ä¸é¢ã®ä¸é¨åã¯å

¨é¨ãè¢«è¦ãããã¨ãå¥½ã¾ãããè©²è¢«è¦ã«ãããèããè¯å¥½ãªå¸çåãéæãããã¨ãã§ããã

At least a part of the outer peripheral surface of the ceramic flat plate constituting the adsorbent for a vacuum adsorption device of the present invention is coated with a sealing agent. The covering portion differs depending on the use mode of the adsorbent, but in an embodiment in which the adsorbent is placed on the substrate and used, it is preferable to cover a part or all of the outer peripheral surface of the ceramic flat plate. On the other hand, in an aspect of using only the adsorbent without being placed on the substrate, it is preferable to cover a part or all of the outer peripheral surface of the ceramic flat plate and the other surface. With this coating, a very good adsorption force can be achieved.

å¸çä½å¤å¨é¢ã®å°å­å¤è¢«è¦åã¯ãè¯å¥½ãªå¸çåãéæãããéãç¹ã«å¶éã¯ãªããå¤å¨é¢ã®å°å­å¤è¢«è¦åã¯ãä¸éãå¥½ã¾ããã¯2.0mmãããå¥½ã¾ããã¯1.0mmãæ´ã«å¥½ã¾ããã¯0.5mmã§ãããä¸éãå¥½ã¾ããã¯0.05mmã§ãããä¸è¨ä¸éãè¶

ããã¨ãã»ã©ããã¯è£½å¹³æ¿ã¨ã®éã«æ®µå·®ãçãã¦è¢«å¸çä½è¼ç½®é¢å

¨ä½ãå¹³å¦ã«ãããã¨ãã§ããªããã¨ããããå¸çåã®ä½ä¸ãæãå¯è½æ§ããããä¸æ¹ãä¸è¨ä¸éæªæºã§ã¯ãã»ã©ããã¯è£½å¹³æ¿ã®å¤å¨é¢ã«å­å¨ããå­ãååã«å¡ããã¨ãã§ããªããã¨ããããåæ§ã«å¸çåã®ä½ä¸ãæãå¯è½æ§ããããå¸çä½å¤å¨é¢ä»¥å¤ã®é¢ã®å°å­å¤è¢«è¦åããè¯å¥½ãªå¸çåãéæãããéãç¹ã«å¶éã¯ãªããå°å­å¤è¢«è¦åã®ä¸éåã³ä¸éã¯ãå¤å¨é¢ã®å°å­å¤è¢«è¦åã¨åãã§ãããã¨ãå¥½ã¾ããã

The sealing agent coating thickness on the outer peripheral surface of the adsorbent is not particularly limited as long as a good adsorbing force is achieved. The upper limit of the sealant coating thickness on the outer peripheral surface is preferably 2.0 mm, more preferably 1.0 mm, still more preferably 0.5 mm, and the lower limit is preferably 0.05 mm. If the upper limit is exceeded, a step may be formed between the flat plate made of ceramic and the entire adsorbent mounting surface may not be flattened, which may lead to a reduction in adsorbing power. On the other hand, if it is less than the said lower limit, the hole which exists in the outer peripheral surface of a ceramic flat plate may not be fully plugged, and it may cause the fall of adsorption power similarly. The sealing agent coating thickness on the surface other than the outer peripheral surface of the adsorbent is not particularly limited as long as a good adsorbing force is achieved. The upper and lower limits of the sealant coating thickness are preferably the same as the sealant coating thickness of the outer peripheral surface.

å°å­å¤ã¨ãã¦ã¯ãå

¬ç¥ã®ãã®ãä½¿ç¨ãããã¨ãã§ããå¥½ã¾ããã¯ã¬ã©ã¹è³ªç©è³ªåã³æ¨¹èããæãç¾¤ããé¸ã°ãããã¬ã©ã¹è³ªç©è³ªã¨ãã¦ã¯ãä¾ãã°ãã¬ã©ã¹ç²æ«ãæ°´ã¬ã©ã¹ãããã©ã¨ãã­ã·ã·ã©ã³ç­ã®ç¡æ©è³ªã³ã¼ãã£ã³ã°å¤ç­ãæãããããã¾ããæ¨¹èã¨ãã¦ã¯ãä¾ãã°ããã§ãã¼ã«æ¨¹èãã·ãªã³ã¼ã³æ¨¹èãã¨ãã­ã·æ¨¹èãã¢ã¯ãªã¬ã¼ãæ¨¹èãã¡ã¿ã¯ãªã¬ã¼ãæ¨¹èãã¡ã©ãã³æ¨¹èãå°¿ç´ æ¨¹èãä¸é£½åããªã¨ã¹ãã«æ¨¹èãã¢ã«ã­ãæ¨¹èãããªã¦ã¬ã¿ã³ãç±ç¡¬åæ§ããªã¤ããç­ãæããããã

A well-known thing can be used as a sealing agent, Preferably it selects from the group which consists of a glassy substance and resin. Examples of the vitreous substance include inorganic coating agents such as glass powder, water glass, and tetraethoxysilane. Examples of the resin include phenol resin, silicone resin, epoxy resin, acrylate resin, methacrylate resin, melamine resin, urea resin, unsaturated polyester resin, alkyd resin, polyurethane, and thermosetting polyimide.

å¸çä½å¤è¡¨é¢ãå°å­å¤ã«ããè¢«è¦ããæ¹æ³ããå¸çä½å¤å¨é¢ã®è¢«è¦ãä¾ã«æãã¦èª¬æãããã¾ããå¸çä½å¤å¨é¢ã«å°å­å¤ãåã0.05ã2.0mmã¨ãªãããã«å¡å¸ãããããã§ãå°å­å¤ã®å¡å¸ã¯ãä¾ãã°ãå¸çä½ã®å¤å¨é¢ä»¥å¤ã®é¢ã«ãã¹ã­ã³ã°ãæ½ããæ¬¡ãã§ãå·æ¯åã¯ã¹ãã¬ã¼ãä½¿ç¨ãã¦å°å­å¤ãå¡å¸ããããã¦ãé©å®ãå°å­å¤ã®åãããã¤ã¯ã­ã¡ã¼ã¿ããã®ã¹åã¯ä¸æ¬¡å

æ¸¬å®æ©ãä½¿ç¨ãã¦æ¸¬å®ããæå®ã®å°å­å¤åããå¾ãããããã«å·æ¯åã¯ã¹ãã¬ã¼ã«ããå¡å¸ãç¹°ãè¿ããã¨ã«ããå®æ½ãããã¨ãã§ãããæ¬¡ãã§ãå°å­å¤ãå¡å¸ããå¸çä½ãç©ºæ°åã¯ä¸æ´»æ§ã¬ã¹é°å²æ°ä¸ã«ããå ç±çå

ã«è£

å

¥ãã¦å ç±å¦çãæ½ããå°å­å¤ãç¡¬åãããå ç±å¦çã®æ¸©åº¦åã³æéã¯ãä½¿ç¨ããå°å­å¤ã®ç¨®é¡ã«ããç°ãªãããã¬ã©ã¹è³ªç©è³ªã§ããç¡æ©ç³»å°å­å¤ãä½¿ç¨ããå ´åã«ã¯ãä¾ãã°ã300ã1000âåã³0.5ã3æéãå¥½ã¾ãããæ¨¹èã§ããææ©ç³»å°å­å¤ãä½¿ç¨ããå ´åã«ã¯ãä¾ãã°ã50ã100âåã³1ã5æéãå¥½ã¾ããããã¡ãããç¡¬åã¯å ç±å¦çã«ãããã®ã«éå®ããããã¨ã¯ãªããå°å­å¤ä¸­ã«å­å¨ããç¡¬åå¤ã®ä½ç¨ã«ããèªç¶ç¡¬åãããã¨ãå¯è½ã§ããããã®ããã«ãã¦å¾ãããè¢«è¦ã®åãã¯0.05ã2.0mmã¨ãªããè©²åãã¯ãä¸è¨ã¨åæ§ã«ãã¤ã¯ã­ã¡ã¼ã¿ããã®ã¹åã¯ä¸æ¬¡å

æ¸¬å®æ©ã«ããæ¸¬å®ãããã¨ãã§ããã

A method of coating the outer surface of the adsorbent with a sealing agent will be described by taking the outer peripheral surface of the adsorbent as an example. First, a sealing agent is applied to the outer peripheral surface of the adsorbent so as to have a thickness of 0.05 to 2.0 mm. Here, the sealing agent is applied, for example, by masking the surface other than the outer peripheral surface of the adsorbent, and then applying the sealing agent using a brush or a spray, and the thickness of the sealing agent as appropriate. The thickness can be measured using a micrometer, a caliper, or a three-dimensional measuring machine, and repeated by applying with a brush or spray to obtain a predetermined sealant thickness. Next, the adsorbent to which the sealing agent is applied is placed in a heating furnace under an air or inert gas atmosphere and subjected to a heat treatment to cure the sealing agent. The temperature and time of the heat treatment vary depending on the type of sealing agent used, but when an inorganic sealing agent that is a vitreous substance is used, for example, 300 to 1000 Â° C. and 0.5 to 3 hours are preferable, When the organic sealing agent which is resin is used, for example, 50 to 100 Â° C. and 1 to 5 hours are preferable. Of course, the curing is not limited to that by heat treatment, and it can be naturally cured by the action of the curing agent present in the sealing agent. The thickness of the coating thus obtained is 0.05 to 2.0 mm. The thickness can be measured with a micrometer, a caliper, or a three-dimensional measuring machine as described above.

ã»ã©ããã¯è£½å¹³æ¿ããæãçç©ºå¸çè£

ç½®ç¨å¸çä½ã®å½¢ç¶ã«ãç¹ã«å¶éã¯ãªããä¾ãã°ãåå½¢ãæ¥åå½¢ãåè§å½¢ããã®ä»ã®å¤è§å½¢ã®å½¢ç¶ãæ¡ãå¾ããå¥½ã¾ããã¯è¢«å¸çä½ã®å½¢ç¶ã«åããããã¨ãã§ããã

There is no restriction | limiting in particular in the shape of the adsorption body for vacuum adsorption apparatuses consisting of a ceramic flat plate, For example, a round shape, an ellipse shape, a square shape, and other polygonal shapes can be taken. Preferably, it can be matched to the shape of the adsorbent.

æ¬çºæã®çç©ºå¸çè£

ç½®ç¨å¸çä½ã¯ãéå¸¸ãåºç¤ã«è¼ç½®ãã¦ä½¿ç¨ããããã»ã©ããã¯è£½å¹³æ¿ããæãå¸çä½ã¯ãå¥½ã¾ããã¯æ¥çå¤ãä½¿ç¨ãã¦åºç¤ã®è¼ç½®é¢ã«åºå®ããããåºç¤ã¯ãå¥½ã¾ããã¯ãç©ºæ°ä¸ééæ§ã®ã»ã©ããã¯ãéå±ç­ã§å½¢æããã¦ãããä»¥ä¸ãè©²æ

æ§ã®ä¸ä¾ãå³1åã³2ã«åºã¥ãã¦èª¬æããã

The adsorbent for a vacuum adsorption apparatus of the present invention is usually used by being placed on a substrate. The adsorbent made of a ceramic flat plate is preferably fixed to the mounting surface of the base using an adhesive. The substrate is preferably made of air impermeable ceramic, metal or the like. Hereinafter, an example of this aspect will be described with reference to FIGS.

å³ï¼åã³2ã¯ãåå½¢ã®åºç¤(1)ã®å¸çä½è¼ç½®é¢(2)ã«åå½¢ã®ã»ã©ããã¯è£½å¤å­è³ªå¹³æ¿ããæãå¸çä½(9)ãè¼ç½®ãããã¤å¸çä½(9)ã®è¢«å¸çä½è¼ç½®é¢ã«è¢«å¸çä½(11)ãè¼ç½®ããç¶æ

ãè¡¨ãå³é¢ã§ãããã»ã©ããã¯è£½å¤å­è³ªå¹³æ¿ã¯ãã®å¤å¨é¢ã«å°å­å¤ã«ããè¢«è¦(10)ãæ½ããã¦ãããå³ï¼ã¯å¹³é¢å³ã§ãããå³2ã¯å³1ã«ç¤ºãããA-Aç·ã«æ²¿ãæ­é¢å³[çç©ºãã³ãå

¥å£å´é

ç®¡(5)ã¯å³ç¤ºãã]ã§ãããåºç¤(1)ã¯ãå¸çä½(9)ãè¼ç½®ããå¸çä½è¼ç½®é¢(2)ãæãã¦ãããå¸çä½è¼ç½®é¢(2)ã«ã¯ãå¸æ°æº(3)ãåãããã¦ãããå³1åã³2ã«ããã¦ãå¸æ°æº(3)ã¯ãåºç¤(1)ã®ä¸­å¿ããåå¿åç¶ã«å­å¨ãã3æ¬ã®åå½¢ã®æºã¨ããã®åå½¢ã®æºã«äº¤å·®ããåºç¤(1)ã®ä¸­å¿ããåå¾æ¹åã«ä¼¸ã³ã4æ¬ã®ç´ç·ç¶ã®æºã¨ããæ§æããã¦ãããåºç¤(1)ã®å

é¨ã«ã¯ãå¸æ°éè·¯(6)ãåãããã¦ãããå¸æ°éè·¯(6)ã®ä¸ç«¯ã¯ãåºç¤(1)ã®ä¸­å¿ã«ããã¦å¸æ°æº(3)ã¨é£éãã¦ãããä»ã®ä¸ç«¯ã¯ãåºç¤å¤å¨é¢ã¸ã¨ç¶ãã¦éå£é¨(4)ãå½¢æãã¦ãããéå£é¨(4)ã«ããã¦ãå¸æ°éè·¯(6)ã¯ãé£çµå

·(7)ãä»ãã¦çç©ºãã³ãå

¥å£å´é

ç®¡(5)ã«æ¥ç¶ããã¦ãããçç©ºãã³ãå

¥å£å´é

ç®¡(5)ã¯çç©ºãã³ã(8)ã®å¸å¼å´ã«æ¥ç¶ããã¦ããã

FIGS. 1 and 2 show that an adsorbent (9) made of a circular ceramic porous plate is placed on an adsorbent placing surface (2) of a circular base (1), and the adsorbent (9) is adsorbed. It is drawing showing the state which mounted the to-be-adsorbed body (11) on the body mounting surface. The ceramic porous flat plate is coated with a sealing agent (10) on the outer peripheral surface thereof. FIG. 1 is a plan view, and FIG. 2 is a sectional view taken along the line AA shown in FIG. 1 (the vacuum pump inlet side pipe (5) is not shown). The base (1) has an adsorbent mounting surface (2) for mounting the adsorbent (9), and the adsorbent mounting surface (2) is provided with an intake groove (3). . In FIGS. 1 and 2, the intake groove (3) has three circular grooves that are concentrically located from the center of the base (1), and intersects the circular groove, and the radial direction from the center of the base (1). It is composed of four linear grooves extending in the direction. An intake passage (6) is provided inside the base (1). One end of the intake passage (6) communicates with the intake groove (3) at the center of the base (1), and the other end forms an opening (4) following the outer peripheral surface of the base. In the opening (4), the intake passage (6) is connected to the vacuum pump inlet side pipe (5) via the connector (7). The vacuum pump inlet side pipe (5) is connected to the suction side of the vacuum pump (8).

çç©ºãã³ã(8)ãèµ·åããã¨ãå¸çä½(9)åã³åºç¤(ï¼)ã®å

é¨ã«å­å¨ããç©ºæ°ãçç©ºãã³ã(8)ã«ããå¸å¼ããã¦ãå¸çä½(9)ã®å­ãå¸æ°æº(3)ãå¸æ°éè·¯(6)ãçç©ºãã³ãå

¥å£å´é

ç®¡(5)ãçç©ºãã³ã(8)ãæ¬¡ãã§ãçç©ºãã³ãææ°å£ã¨ããç©ºæ°ã®æµããçãããããã¦ãããã«ããå¸çä½(9)ã«å¸çåãçºçããè¢«å¸çä½(11)ããå¸çä½(9)ã®è¢«å¸çä½è¼ç½®é¢ã«åºå®ãããã

When the vacuum pump (8) is started, the air present in the adsorbent (9) and the base (1) is sucked by the vacuum pump (8), and the holes of the adsorbent (9), the intake groove (3), An air flow such as an intake passage (6), a vacuum pump inlet side pipe (5), a vacuum pump (8), and then a vacuum pump exhaust port is generated. As a result, an adsorbing force is generated in the adsorbent (9), and the adsorbent (11) is fixed to the adsorbent mounting surface of the adsorbent (9).

å³1åã³2ã«ç¤ºããæ

æ§ã«ããã¦ãã»ã©ããã¯è£½å¤å­è³ªå¹³æ¿ããæãå¸çä½(9)ä¸¦ã³ã«åºç¤(1)åã³å¸çä½è¼ç½®é¢(2)ã®å½¢ç¶ã¯ããããåå½¢ã§ãããããããã®å½¢ç¶ã¯åå½¢ã«éå®ããããã¨ã¯ãªããç¨®ã

ã®å½¢ç¶ãæ¡ããã¨ãã§ãããä¾ãã°ãä¸è¨ã®ããã«æ¥åå½¢ãåè§å½¢ããã®ä»ã®å¤è§å½¢ã®å½¢ç¶ãæ¡ãå¾ããã¾ããå¸æ°æº(3)ããå³1ã«ç¤ºãããæ

æ§ã«éããããåå¿åç¶ã®æºåã³åå¾æ¹åã«ä¼¸ã³ãæºã®æ¬æ°ã¯é©å®æ±ºå®ãããã¨ãã§ãããã¾ããåå¿åç¶ã®æºãè¨­ãããåå¾æ¹åã«ä¼¸ã³ãæºã®ã¿ã§æ§æãããã¨ãå¯è½ã§ãããå¸æ°éè·¯(6)ãããã®ä¸ç«¯ã§å¸æ°æº(3)ã«é£éãã¦ããã°ãããã¾ããå¸æ°éè·¯(6)ã®ä»ã®ä¸ç«¯ã¯ãåºç¤ã®å¤è¡¨é¢ã¸ã¨éãã¦éå£é¨ãå½¢æãã¦ããã°ãããå¤å¨é¢ä»¥å¤ã®ä»ã®é¢ã«ããã¦éå£ãã¦ãã¦ãããã

In the embodiment shown in FIGS. 1 and 2, the shape of the adsorbent (9) made of a ceramic porous flat plate and the base (1) and the adsorbent mounting surface (2) are both circular. The shape is not limited to a circle, and various shapes can be adopted. For example, as described above, an elliptical shape, a quadrangular shape, or other polygonal shapes may be employed. Further, the intake groove (3) is not limited to the embodiment shown in FIG. 1, and the number of concentric grooves and radially extending grooves can be determined as appropriate. Further, it is possible to configure only the grooves extending in the radial direction without providing concentric grooves. The intake passage (6) may also communicate with the intake groove (3) at one end thereof. Further, the other end of the intake passage (6) only needs to be connected to the outer surface of the base so as to form an opening, and may be opened on a surface other than the outer peripheral surface.

ä»¥ä¸ãå®æ½ä¾ã«ããã¦æ¬çºæãæ´ã«è©³ç´°ã«èª¬æããããæ¬çºæã¯ãããå®æ½ä¾ã«ããéå®ããããã®ã§ã¯ãªãã

EXAMPLES Hereinafter, although an Example demonstrates this invention further in detail, this invention is not limited by these Examples.

[å®æ½ä¾1ã8åã³æ¯è¼ä¾1ã3]

åå®æ½ä¾åã³æ¯è¼ä¾ã«ããã¦ä½¿ç¨ããææåã³è£

ç½®ç­ã¯ä¸è¨ã®éãã§ããã

<ææ>

ã¯ã©ã¹ããã¤ã : FPW#800 (åæ¨) ãã­ã³ã»ã¤ãããã¯æ ªå¼ä¼ç¤¾è£½

ã¿ã«ã¯ : PSãã¤ã»ã©ã¿ã«ã¯ (åæ¨) ãã½ãã¨ã¯ã¬ã¼åäºæ ªå¼ä¼ç¤¾è£½

ããã§ãªã³ : MINEX#3 (åæ¨)

ãç¨²å£é±æ¥­æ ªå¼ä¼ç¤¾è£½

ãã¤ã³ãã¼ : ã¨ã¹ã¬ãã¯KW-10 (åæ¨) ãç©æ°´åå­¦å·¥æ¥­æ ªå¼ä¼ç¤¾è£½

åæ£å¤ : ããªã¹ã¿ã¼A-1060 (åæ¨)

ãæ¥æ²¹æ ªå¼ä¼ç¤¾è£½

å°å­ã¬ã©ã¹ : ç²æ«ã¬ã©ã¹GA-12

(åæ¨) ãæ¥æ¬é»æ°ç¡å­æ ªå¼ä¼ç¤¾è£½

<è£

ç½®>

ãã·ãã³ã°ã»ã³ã¿ã¼ : æ ªå¼ä¼ç¤¾ç§éãã©ã¤ã¹è£½ä½æè£½V33

å¹³é¢ç åç¤ : å²¡æ¬å·¥ä½æ©æ¢°è£½PSG63

ä¸æ¬¡å

æ¸¬å®æ© : æ ªå¼ä¼ç¤¾ãããã¨è£½BRT707

<ãã®ä»>

ã¨ãã­ã·ç³»æ¥çå¤ : SG-EPO (åæ¨) ãã»ã¡ãã¤ã³æ ªå¼ä¼ç¤¾è£½

ã¡ã¤ã«ã³ãã¯ã¿ã¼ : æ ªå¼ä¼ç¤¾ãã¨ãè£½M5Ã0.8

çç©ºãã³ã : DOPã»80S (åæ¨) ãæ ªå¼ä¼ç¤¾ã¢ã«ããã¯è£½(ææ°éï¼ï¼ï¼¬/ï½ï½ï½)

[Examples 1-8 and Comparative Examples 1-3]

The materials and devices used in each example and comparative example are as follows.

<Material>

Wollastonite: FPW # 800 (trademark), Kinsei Matec Co., Ltd. talc: PS Hicera talc (trademark), Sobue clay trading Co., Ltd. nepheline: MINEX # 3 (trademark)

Binder manufactured by Inagaki Mining Co., Ltd .: S-LEK KW-10 (trademark), Dispersant manufactured by Sekisui Chemical Co., Ltd .: Polystar A-1060 (trademark)

Sealed glass manufactured by NOF Corporation: Powdered glass GA-12

(Trademark), manufactured by Nippon Electric Glass Co., Ltd.

<Device>

Machining Center: V33 manufactured by Makino Milling Machine Co., Ltd.

Surface grinding machine: Okamoto Machine Tool PSG63

CMM: Mitutoyo BRT707

<Others>

Epoxy adhesive: SG-EPO (trademark), Mail connector manufactured by Cemedine Co., Ltd .: M5 Ã 0.8 manufactured by Chiyoda Co., Ltd.

Vacuum pump: DOP Â· 80S (trademark), manufactured by ULVAC, Inc. (displacement 88 L / min)

(å¤å­è³ªã»ã©ããã¯ã®è£½é )

ã¯ã©ã¹ããã¤ããã¿ã«ã¯åã³ããã§ãªã³ããå¤«ã

ã100è³ªéé¨ã10è³ªéé¨åã³10è³ªéé¨ã®å²åã§æ··åãããæ¬¡ãã§ããã¤ã³ãã¼4è³ªéé¨ãåæ£å¤1è³ªéé¨åã³æ°´120è³ªéé¨ãæ´ã«é

åãã¦ãå®å

¨ã«æ··åãããã¾ã§ããæªæããããã®ããã«ãã¦å¾ãããã¹ã©ãªã¼ç¶æ··åç©ããã¹ãã¬ã¼ãã©ã¤ã¤ã¼ãä½¿ç¨ãã¦ä¹¾ç¥ãé¡ç²ãå¾ããå¾ãããé¡ç²ã®å¾ã¯ç´100Î¼mã§ãã£ãããã®é¡ç²ããæåå§å49MPaã§ä¸è»¸æåæ©ã«ããæ¿ç¶(360mmÃ360mmÃ25mm)ã«æå½¢ããæ¬¡ãã§ãæé«æ¸©åº¦1210âã§2æéãå¤§æ°é°å²æ°ä¸ã«ç¼æãã¦ãã¯ã©ã¹ããã¤ãç³»å¤å­è³ªã»ã©ããã¯ãè£½é ããã

(Manufacture of porous ceramics)

Wollastonite, talc and nepheline were mixed at a ratio of 100 parts by mass, 10 parts by mass and 10 parts by mass, respectively. Next, 4 parts by weight of a binder, 1 part by weight of a dispersant and 120 parts by weight of water were further blended and stirred well until they were completely mixed. The slurry-like mixture thus obtained was dried using a spray dryer to obtain granules. The diameter of the obtained granule was about 100 Î¼m. This granule is formed into a plate (360mm x 360mm x 25mm) with a molding pressure of 49MPa using a uniaxial molding machine, and then fired in an air atmosphere at a maximum temperature of 1210 Â° C for 2 hours. Manufactured.

ã¯ã©ã¹ããã¤ãç³»å¤å­è³ªã»ã©ããã¯ã®è£½é ã«ããã¦ãã­ããã®ç°ãªãäºç¨®é¡ã®ã¯ã©ã¹ããã¤ããä½¿ç¨ããããã®çµæãå¾ãããã¯ã©ã¹ããã¤ãç³»å¤å­è³ªã»ã©ããã¯ã®å¹³åæ°å­å¾ã¯ãå¤«ã

ã2.6Î¼måã³3.4Î¼mã§ãã£ããæ°å­çã¯ãããã32%ã§ãã£ãã

Two types of wollastonite with different lots were used in the production of wollastonite porous ceramics. As a result, the average pore diameters of the obtained wollastonite-based porous ceramics were 2.6 Î¼m and 3.4 Î¼m, respectively. The porosity was 32% in all cases.

(å¸çä½ã®è£½é )

å¾ãããå¹³åæ°å­å¾ã2.6Î¼måã³3.4Î¼mã§ããããã¤æ°å­çã32%ã®äºç¨®é¡ã®ã¯ã©ã¹ããã¤ãç³»å¤å­è³ªã»ã©ããã¯ãä½¿ç¨ãã¦å¸çä½ãè£½é ããã

(Manufacture of adsorbent)

Adsorbents were produced using two types of wollastonite porous ceramics having average pore diameters of 2.6 Î¼m and 3.4 Î¼m and a porosity of 32%.

ãããã®å¤å­è³ªã»ã©ããã¯ã«ããã·ãã³ã°ã»ã³ã¿ã¼ã«ã¦Ï15ãã¤ã¤ã¢ã³ãé»çè»¸ä»ç ¥ç³ãç¨ããååå å·¥ãæ½ããç´å¾210mmÃåã20mmã®åå½¢ã®å¹³æ¿ãè£½é ããã

These porous ceramics were cut using a grinding wheel with a Ï15 diamond electrodeposited shaft at a machining center to produce a circular flat plate having a diameter of 210 mm and a thickness of 20 mm.

è©²å¹³æ¿ã®å¤å¨é¢å

¨ä½ã«ãå°å­å¤ã¨ãã¦ã®å°å­ã¬ã©ã¹ããå·æ¯ãä½¿ç¨ãã¦å¡å¸ããæ¬¡ãã§ã690âã§1æéç©ºæ°é°å²æ°ä¸ã«å ç±å¦çãå®æ½ãããå ç±å¦çå¾ã®å°å­å¤è¢«è¦åã¯0.5mmã§ãã£ããããã§ãè©²å°å­å¤è¢«è¦åã¯ãä¸æ¬¡å

æ¸¬å®æ©ã«ããæ¸¬å®ãããã®ã§ããã

Sealing glass as a sealing agent was applied to the entire outer peripheral surface of the flat plate using a brush, and then heat-treated at 690 Â° C. for 1 hour in an air atmosphere. The sealant coating thickness after the heat treatment was 0.5 mm. Here, the sealing agent coating thickness is measured by a three-dimensional measuring machine.

å°å­ã¬ã©ã¹ã§å¤å¨é¢å

¨ä½ãè¢«è¦ãããã¯ã©ã¹ããã¤ãç³»å¤å­è³ªã»ã©ããã¯è£½å¹³æ¿ã«ãå¹³é¢ç åç¤ã«ã¦ã¬ã¸ã³ãã¤ã¤ã¢ã³ãç ¥ç³ãç¨ããç åå å·¥ãæ½ããè©²å¹³æ¿ã®åãã10mmã¨ãããã¤å¹³é¢åº¦ã10Î¼mã¨ãããå¹³é¢åº¦ã¯ä¸æ¬¡å

æ¸¬å®æ©ãä½¿ç¨ãã¦æ¸¬å®ããå¤ã§ããã

A wollastonite-based porous ceramic flat plate whose entire outer peripheral surface is covered with sealing glass is subjected to grinding using a resin diamond grindstone with a surface grinder, the thickness of the flat plate is 10 mm, and flatness Was 10 Î¼m. Flatness is a value measured using a coordinate measuring machine.

å¥éãå°å­å¤è¢«è¦åããå¤«ã

ã0.05mmã0.1mmåã³1.0mmã§ãã3ç¨®é¡ã®ã¯ã©ã¹ããã¤ãç³»å¤å­è³ªã»ã©ããã¯è£½å¹³æ¿ããä¸è¨ã¨åæ§ã«ãã¦è£½é ãããã¾ããå°å­å¤ã«ããè¢«è¦ãæ½ããã¦ããªãã¯ã©ã¹ããã¤ãç³»å¤å­è³ªã»ã©ããã¯è£½å¹³æ¿1åããä¸è¨ã¨åæ§ã«ãã¦è£½é ããããããã¯ãå¹³åæ°å­å¾ãç°ãªãäºç¨®é¡ã®ã¯ã©ã¹ããã¤ãç³»å¤å­è³ªã»ã©ããã¯æ¯ã«è£½é ããããã¾ããå°å­å¤è¢«è¦åã3.0mmã®ã¯ã©ã¹ããã¤ãç³»å¤å­è³ªã»ã©ããã¯è£½å¹³æ¿ããå¹³åæ°å­å¾ã2.6Î¼mã®ã¯ã©ã¹ããã¤ãç³»å¤å­è³ªã»ã©ããã¯ã®ã¿ã«ããè£½é ããã

Separately, three types of wollastonite porous ceramic flat plates having a sealant coating thickness of 0.05 mm, 0.1 mm, and 1.0 mm, respectively, were produced in the same manner as described above. Further, one flat plate made of wollastonite porous ceramic not coated with a sealing agent was produced in the same manner as described above. These were produced for each of two types of wollastonite porous ceramics having different average pore diameters. Further, a wollastonite porous ceramic flat plate having a sealant coating thickness of 3.0 mm was produced only from the wollastonite porous ceramic having an average pore diameter of 2.6 Î¼m.

(åºç¤ã®è£½é )

ã¹ãã³ã¬ã¹é¼(SUS304ãç´å¾250mmÃåã25mmã®åå½¢å¹³æ¿)ã«ãå¹³é¢ç åç¤ã«ã¦ã¬ã¸ã³ãã¤ã¤ã¢ã³ãç ¥ç³ãç¨ããç åå å·¥ãæ½ããç´å¾250mmãåã20mmåã³å¹³é¢åº¦20Î¼mã®ã¹ãã³ã¬ã¹é¼è£½ã®åå½¢å¹³æ¿ãè£½é ãããå¹³é¢åº¦ã¯ä¸è¨ã¨åããä¸æ¬¡å

æ¸¬å®æ©ãä½¿ç¨ãã¦æ¸¬å®ããå¤ã§ãããæ¬¡ãã§ãè©²å¹³æ¿ã«ããã·ãã³ã°ã»ã³ã¿ã¼ã«ã¦Ï15è¶

ç¡¬ã¨ã³ããã«ãç¨ããååå å·¥ãæ½ããç´å¾ã212mmã¨ããã

(Manufacture of base)

Stainless steel (SUS304, circular flat plate with a diameter of 250mm Ã thickness 25mm) is ground using a resin diamond grindstone with a surface grinder, and a circular flat plate made of stainless steel with a diameter of 250mm, a thickness of 20mm and a flatness of 20Î¼m Manufactured. The flatness is a value measured using a three-dimensional measuring machine as described above. Next, the flat plate was subjected to cutting using a Ï15 carbide end mill at a machining center to a diameter of 212 mm.

æ¬¡ãã§ãè©²å¹³æ¿ã«ããã·ãã³ã°ã»ã³ã¿ã¼ã«ã¦Ï4mmè¶

ç¡¬ããªã«ãç¨ãã¦ãè©²å¹³æ¿ã®ä¸é¢ãã10mmä¸ã®ä½ç½®ã«ãããå¤å¨é¢ããä¸­å¿ã«åãã¦ãç´å¾4mmã®åå½¢ã®å¸æ°éè·¯ãæ°´å¹³ã«éããã

Next, a circular intake passage having a diameter of 4 mm was horizontally opened from the outer peripheral surface to the center at a position 10 mm below the upper surface of the flat plate using a Ï4 mm carbide drill at a machining center.

æ¬¡ãã§ãè©²å¹³æ¿ã®å¸çä½è¼ç½®é¢ã¨ãªãé¨åã«ããã·ãã³ã°ã»ã³ã¿ã¼ã«ã¦Ï5mmè¶

ç¡¬ã¨ã³ããã«ãç¨ããååå å·¥ãæ½ããå¹

5mmãæ·±ã2mmã®ç©å½¢æ­é¢ãæããå¸æ°æºãå½¢æãããå¸æ°æºã¯ãå³ï¼ã«ç¤ºããããã«ãä¸­å¿ããåå¿åç¶ã«ç­ééã§å­å¨ãã3æ¬ã®åå½¢ã®æºã¨ããã®åå½¢ã®æºã«äº¤å·®ããä¸­å¿ããåå¾æ¹åã«ä¼¸ã³ã4æ¬ã®ç´ç·ç¶ã®æºã¨ããæ§æããã¦ãããæ´ã«ãä¸­å¿ããåç´ã«ç´å¾5mmã®åå½¢ã®å¸æ°éè·¯ãå½¢æããå¸æ°æºã¨å¸æ°éè·¯ã®æ°´å¹³é¨åã¨ãé£éããããæ¬¡ãã§ãå¸æ°éè·¯ã®å¤å¨é¢éå£é¨ã«M5æ·±ã6mmã®ã¿ããå å·¥ãæ½ãããå¾ãããåºç¤ã¯ãå³1åã³2ã«ç¤ºããåºç¤ã¨åä¸ã®å½¢ç¶ã§ããã

Next, the portion of the flat plate that is to be the adsorbent mounting surface was subjected to cutting using a Ï5 mm carbide end mill at a machining center to form an intake groove having a rectangular cross section with a width of 5 mm and a depth of 2 mm. As shown in FIG. 1, the intake groove has three circular grooves that are concentrically spaced from the center at equal intervals, and four linear grooves that intersect the circular groove and extend radially from the center. It consists of a groove. Furthermore, a circular intake passage having a diameter of 5 mm was formed perpendicularly from the center, and the intake groove and the horizontal portion of the intake passage were communicated. Next, the outer peripheral surface opening of the intake passage was tapped with a M5 depth of 6 mm. The obtained base has the same shape as the base shown in FIGS.

(çç©ºå¸çè£

ç½®ã®çµç«)

ä¸è¨ã®ããã«ãã¦è£½é ããå¸çä½ããä¸è¨åºç¤ã®å¸çä½è¼ç½®é¢ã«ã¨ãã­ã·ç³»æ¥çå¤ãä½¿ç¨ãã¦åºå®ãããæ¬¡ãã§ãå¸æ°éè·¯ã®å¤å¨é¢éå£é¨ã«ã¡ã¤ã«ã³ãã¯ã¿ã¼(é£çµå

·)ãåãä»ããçç©ºãã³ãã¨ã¡ã¤ã«ã³ãã¯ã¿ã¼ãå

å¾4mmãå¤å¾6mmã®ã¦ã¬ã¿ã³ãã¥ã¼ã(çç©ºãã³ãå

¥å£å´é

ç®¡)ã§é£çµããã

(Assembly of vacuum suction device)

The adsorbent produced as described above was fixed to the adsorbent mounting surface of the base using an epoxy adhesive. Next, a mail connector (connector) was attached to the opening on the outer peripheral surface of the intake passage, and the vacuum pump and the mail connector were connected by a urethane tube (vacuum pump inlet side pipe) having an inner diameter of 4 mm and an outer diameter of 6 mm.

(å¸çä½ã®è¢«å¸çä½è¼ç½®é¢ã®å¹³é¢åº¦ã®æ¸¬å®)

ä¸è¨ã®ããã«ãã¦è£½é ããã2ç¨®é¡ã®ç°ãªãå¹³åæ°å­å¾ãæããã¯ã©ã¹ããã¤ãç³»å¤å­è³ªã»ã©ããã¯ã®11ç¨®é¡ã®å¸çä½ã«ã¤ãã¦ããã®è¢«å¸çä½è¼ç½®é¢ã®å¹³é¢åº¦ããä¸æ¬¡å

æ¸¬å®æ©ãä½¿ç¨ãã¦æ¸¬å®ããã

(Measurement of flatness of adsorbent surface of adsorbent)

For 11 types of adsorbents of wollastonite porous ceramics with two different average pore diameters manufactured as described above, the flatness of the surface to be adsorbed is measured using a three-dimensional measuring machine. And measured.

(å¸çåæ¸¬å®)

ä¸è¨ã®ããã«ãã¦è£½é ãã11ç¨®é¡ã®å¸çä½ã«ã¤ãã¦ãå¤«ã

ãå¸çåãæ¸¬å®ãããæ¸¬å®ã¯ãå¸çä½ã®è¢«å¸çä½è¼ç½®é¢ã®å³ååãã¢ã¯ãªã«æ¿ã§è¦ããå·¦ååãè§£æ¾ããç¶æ

ã§çç©ºãã³ã(8)ãèµ·åãã¦å¸å¼ãããéæ¬¡ãçç©ºåº¦ãæ¸¬å®ããä¸å®ã¨ãªã£ãæã®çç©ºåº¦ãæ¸¬å®ãã¦å¸çåã¨ãããããã§ãçç©ºåº¦ã¯çç©ºãã³ãå

¥å£å´é

ç®¡(5)ã«åãä»ããçç©ºè¨ã«ããæ¸¬å®ãããã®ã§ããã

(Adsorption force measurement)

The adsorption power of each of the 11 types of adsorbents produced as described above was measured. In the measurement, the right half of the adsorbent mounting surface of the adsorbent was covered with an acrylic plate, and the left half was released, and the vacuum pump (8) was activated to perform suction. Sequentially, the degree of vacuum was measured, and the degree of vacuum when it became constant was determined as the adsorption force. Here, the degree of vacuum is measured by a vacuum gauge attached to the vacuum pump inlet side pipe (5).

ä¸è¨ã®æ¸¬å®çµæããä¸è¨è¡¨1åã³è¡¨2ã«ç¤ºãã

The measurement results are shown in Table 1 and Table 2 below.

[æ¯è¼ä¾ï¼åã³ï¼]

ãã®æ¯è¼ä¾ã«ããã¦ä½¿ç¨ããææåã³è£

ç½®ç­ã¯ä¸è¨ã®éãã§ããã

<ææ>

å¸çä½A : ã¢ã«ããè³ªå¤å­è³ªä½FWA600

(åæ¨) ãå¯å£«ã±ãã«ã«æ ªå¼ä¼ç¤¾è£½

å¸çä½B : ã¢ã«ããè³ªå¤å­è³ªä½MP060

(åæ¨) ãå¯å£«ã±ãã«ã«æ ªå¼ä¼ç¤¾è£½

å°å­ã¬ã©ã¹ : ç²æ«ã¬ã©ã¹GA-12

(åæ¨) ãæ¥æ¬é»æ°ç¡å­æ ªå¼ä¼ç¤¾è£½

<è£

ç½®ãã®ä»>

ãã·ãã³ã°ã»ã³ã¿ã¼ãå¹³é¢ç åç¤ãä¸æ¬¡å

æ¸¬å®æ©ãã¨ãã­ã·ç³»æ¥çå¤ãã¡ã¤ã«ã³ãã¯ã¿ã¼åã³çç©ºãã³ãã¯ãããããä¸è¨ã®å®æ½ä¾1ã§ä½¿ç¨ãããã®ã¨åä¸ã§ããã

[Comparative Examples 4 and 5]

The materials and equipment used in this comparative example are as follows.

<Material>

Adsorbent A: Alumina porous body FWA600

(Trademark), Adsorbent B manufactured by Fuji Chemical Co., Ltd .: Alumina porous material MP060

(Trademark) Sealed glass manufactured by Fuji Chemical Co., Ltd.: Powdered glass GA-12

(Trademark), manufactured by Nippon Electric Glass Co., Ltd.

<Equipment and others>

The machining center, surface grinder, coordinate measuring machine, epoxy adhesive, mail connector, and vacuum pump are all the same as those used in Example 1 above.

å¸çä½ã®è£½é ãåºç¤ã®è£½é åã³çç©ºå¸çè£

ç½®ã®çµç«ã¯ãä¸è¨ã®å®æ½ä¾1ã¨åä¸ã«ãã¦å®æ½ãããã¾ããå¸çä½ã®è¢«å¸çä½è¼ç½®é¢ã®å¹³é¢åº¦ã®æ¸¬å®åã³å¸çåæ¸¬å®ããä¸è¨ã®å®æ½ä¾1ã¨åä¸ã«ãã¦å®æ½ããã

The manufacture of the adsorbent, the manufacture of the substrate, and the assembly of the vacuum adsorption apparatus were performed in the same manner as in Example 1 above. Further, the flatness measurement and the adsorption force measurement of the adsorbent mounting surface of the adsorbent were performed in the same manner as in Example 1 above.

æ¸¬å®çµæãä¸è¨ã®è¡¨3ã«ç¤ºãã

The measurement results are shown in Table 3 below.

å®æ½ä¾1ã4ã¯ãæ¬çºæã®ç¯å²å

ã§å°å­å¤è¢«è¦åãå¤åããããã®ã§ãããããããå¸çåã¯èããè¯å¥½ã§ãã£ããä¸æ¹ãå°å­å¤ãè¢«è¦ããªãã£ãæ¯è¼ä¾1ã§ã¯ãããç¨åº¦é«ãå¸çåãå¾ããããã®ã®ãå®æ½ä¾1ã4ã«ãããå¸çåã«åã¶ãã®ã§ã¯ãªãã£ããæ¯è¼ä¾2ã¯ãå°å­å¤è¢«è¦åã3mmã®ãã®ã§ãããè¢«å¸çä½è¼ç½®é¢ã®å¹³é¢åº¦ãä½ããå¸çåãèããä½ä¸ããã

In Examples 1 to 4, the sealant coating thickness was changed within the scope of the present invention. In any case, the adsorptive power was remarkably good. On the other hand, in Comparative Example 1 in which the sealing agent was not coated, although a high adsorption force was obtained to some extent, the adsorption force in Examples 1 to 4 was not reached. In Comparative Example 2, the sealant coating thickness is 3 mm. The flatness of the surface on which the object is to be adsorbed was low, and the adsorbing power was significantly reduced.

å®æ½ä¾5ã8åã³æ¯è¼ä¾3ã¯ãå®æ½ä¾1ã4åã³æ¯è¼ä¾1ã2ããå¹³åæ°å­å¾ã®å¤§ããå¸çä½ãä½¿ç¨ãããã®ã§ãããä¸è¨ã¨åæ§ã®çµæãå¾ãããã

Examples 5 to 8 and Comparative Example 3 use adsorbents having an average pore diameter larger than those of Examples 1 to 4 and Comparative Examples 1 to 2. Similar results were obtained.

æ¯è¼ä¾4åã³5ã¯ãç¾å¨å¸è²©ããã¦ããå¸çä½ãä½¿ç¨ãããã®ã§ããããããã®å¸çä½ã¯ãå¹³åæ°å­å¾åã³æ°å­çå

±ã«æ¬çºæã®ç¯å²ãè¶

ãã¦ãããå¤å¨é¢ã«0.5mmã®å°å­å¤è¢«è¦ãæ½ãã¦ãããã®å¸çåã¯èããæªããã®ã§ãã£ãã

Comparative Examples 4 and 5 use adsorbents that are currently commercially available. These adsorbents both exceeded the range of the present invention in terms of average pore diameter and porosity, and even when the outer peripheral surface was coated with a 0.5 mm sealing agent, the adsorbing power was extremely poor.

æ¬çºæã®å¸çä½ã¯ãè¢«å¸çä½è¼ç½®é¢å

¨ä½ã«æ®µå·®ããªãå¹³æ»ã§ããããã¤èããå°ããªå¹³åæ°å­å¾åã³æå®ã®æ°å­çãæããå ãã¦å¤è¡¨é¢ã®ä¸é¨ãå°å­å¤ã«ããè¢«è¦ããã¦ããæ

ãåå°ä½ã¦ã¨ãã¼åã³ã¬ã©ã¹åºæ¿ç­ã®è¢«å¸çä½ã®å¤§ãããå¤å½¢åã³ã¹ã«ã¼ãã¼ã«ã®æç¡ç­ã®å½±é¿ãåãããã¨ããªããå¾ã£ã¦ãããããå½¢ç¶ã®åå°ä½ã¦ã¨ãã¼åã³ã¬ã©ã¹åºæ¿ç­ã®ç åå å·¥åã³ç ç£¨å å·¥ä¸¦ã³ã«ç²¾å¯æ¸¬å®ã«å¹æçã«å©ç¨ãããã¨ãã§ããã

The adsorbent of the present invention is smooth with no steps on the entire surface to be adsorbed, and has an extremely small average pore diameter and a predetermined porosity, and in addition, a part of the outer surface is covered with a sealing agent. Therefore, it is not affected by the size, outer shape, presence or absence of through-holes, etc. of the object to be adsorbed such as a semiconductor wafer and a glass substrate. Therefore, it can be effectively used for grinding and polishing of semiconductor wafers and glass substrates of all shapes and precision measurement.

åå½¢ã®åºç¤(1)ã®å¸çä½è¼ç½®é¢(2)ã«åå½¢ã®ã»ã©ããã¯è£½å¤å­è³ªå¹³æ¿ããæãå¸çä½(9)ãè¼ç½®ãããã¤å¸çä½(9)ã®è¢«å¸çä½è¼ç½®é¢ã«è¢«å¸çä½(11)ãè¼ç½®ããç¶æ

ãè¡¨ãå¹³é¢å³ã§ãããAn adsorbent (9) made of a circular ceramic porous plate is placed on the adsorbent mounting surface (2) of the circular base (1), and the adsorbent mounting surface of the adsorbent (9) is covered. It is a top view showing the state which mounted the adsorption body (11).

å³1ã«ç¤ºãããA-Aç·ã«æ²¿ãæ­é¢å³ã§ãããFIG. 2 is a sectional view taken along line AA shown in FIG.

ç¬¦å·ã®èª¬æExplanation of symbols

1 åºç¤

2 å¸çä½è¼ç½®é¢

3 å¸æ°æº

4 éå£é¨

5 çç©ºãã³ãå

¥å£å´é

ç®¡

6 å¸æ°éè·¯

7 é£çµå

·

8 çç©ºãã³ã

9 å¸çä½

10 å°å­å¤ã«ããè¢«è¦

11 è¢«å¸çä½

1 Foundation

2 Adsorber mounting surface

3 Air intake groove

4 opening

5 Vacuum pump inlet side piping

6 Air intake passage

7 Connector

8 Vacuum pump

9 Adsorbent

10 Covering with sealant

11 Adsorbent

## Cited patent documents

- [JP-2000016872-A](https://patents.google.com/patent/JP2000016872A/en) — EXA
- [JP-2004231493-A](https://patents.google.com/patent/JP2004231493A/en) — EXA
- [JP-2007099584-A](https://patents.google.com/patent/JP2007099584A/en) — EXA
- [JP-H0847835-A](https://patents.google.com/patent/JPH0847835A/en) — EXA
- [JP-H1110472-A](https://patents.google.com/patent/JPH1110472A/en) — EXA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
