# 43. Carrier for thin glass sheets and method of using

- **Archive rank:** 43 of 50
- **Publication:** [WO-2013082076-A1](https://patents.google.com/patent/WO2013082076A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/047324448/publication/WO2013082076A1?q=pn%3DWO2013082076A1)
- **Publication date:** 2013-06-06
- **Filing date:** 2012-11-28
- **Earliest priority:** 2011-11-30
- **Family:** 47324448
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery

## Parties

- **Applicant / assignee:** CHOWDHURY DIPAKBIN QASEM; CORNING INC; OTT TERRY JAY
- **Inventors:** CHOWDHURY DIPAKBIN QASEM; OTT TERRY JAY

## Abstract

A portable jig (10) for carrying a thin glass sheet (2). The jig includes a body (11) having a top planar surface (20), the top planar surface having a sheet mounting section (22), wherein the sheet mounting section has a perimeter (24), and the perimeter encloses an area that is larger than or equal to the area of the thin glass sheet to be carried. A pressure cavity (40) is disposed in the body and is in fluid communication with the sheet mounting section. A conduit (50) is coupled to the body and is in fluid communication with the pressure cavity. Also, a method of processing a thin glass sheet on the jig is disclosed. The pressure in the pressure cavity is reduced by drawing a vacuum through the conduit and, thereby, the thin glass sheet is held fast to the top planar surface of the jig.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/WO-2013082076-A1/pdf000.png)

![Sketch 1 for WO-2013082076-A1](https://nimo.iptorch.com/refdrawing/WO-2013082076-A1/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/WO-2013082076-A1/pdf001.png)

![Sketch 2 for WO-2013082076-A1](https://nimo.iptorch.com/refdrawing/WO-2013082076-A1/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/WO-2013082076-A1/pdf002.png)

![Sketch 3 for WO-2013082076-A1](https://nimo.iptorch.com/refdrawing/WO-2013082076-A1/pdf002.png)

## Claims

### Claim 1

What is Claimed is: 1. A portable jig for carrying a thin glass sheet, comprising; a body having a top planar surface, the top planar surface having a sheet mounting section, wherein the sheet mounting section has a perimeter, and the perimeter encloses an area that is larger than or equal to the area of the thin glass sheet to be carried, a pressure cavity disposed in the body and in fluid communication with the sheet mounting section, a conduit coupled to the body and in fluid communication with the pressure cavity. 2. The apparatus of claim 1, wherein the body further comprises a bottom planar surface, wherein the bottom planar surface is parallel to the top planar surface, and wherein there are no projections extending outwardly from the bottom planar surface. 3. The apparatus of claim 1 or claim 2, wherein the top planar surface is made of glass. 4. The apparatus of any one of claims 1-3, wherein the top planar surface includes openings disposed within the perimeter of the sheet mounting section, and in fluid communication with the pressure cavity. 5. The apparatus of any one of claims 1-3, wherein the pressure cavity is open to the top planar surface within the perimeter of the sheet mounting section. 6. The apparatus of any one of claims 1-3, further comprising a porous member having a surface, wherein the porous-member surface is disposed so as to be coplanar with the top planar surface and within the perimeter of the sheet mounting section. 7. The apparatus of claim 6, wherein the porous member is disposed in the pressure cavity. 8. The apparatus of claim 6 or claim 7, wherein the porous member is graphite. 9. The apparatus of any one of claims 1-8, further comprising a plug disposed in the conduit. 10. A method of processing a thin glass sheet comprising: disposing a thin glass sheet adjacent to a top planar surface of a portable jig having a pressure cavity in fluid communication with the top planar surface; reducing pressure within the pressure cavity by drawing a vacuum through a conduit in fluid communication with the pressure cavity so the thin glass sheet is held fast to the top surface by the reduced pressure within the pressure cavity; and plugging the conduit to hold the reduced pressure within the pressure cavity. 11. The method of claim 10, wherein the jig further comprises a bottom planar surface, wherein the bottom planar surface is parallel to the top planar surface, and wherein there are no projections extending outwardly from the bottom planar surface. 12. The method of claim 10 or claim 11, wherein the top planar surface is made of glass. 13. The method of any one of claims 10-12, wherein the top planar surface includes openings in fluid communication with the pressure cavity. 14. The method of any one of claims 10-12, wherein the pressure cavity is open to the top planar surface. 15. The method of any one of claims 10-12, wherein the jig further comprises a porous member having a surface, wherein the porous-member surface is disposed so as to be coplanar with the top planar surface. 16. The method of claim 15, wherein the porous member is disposed in the pressure cavity. 17. The method of claim 15 or claim 16, wherein the porous member is graphite.

## Full description

**[0001]**

CARRIER FOR THIN GLASS SHEETS AND METHOD OF USING

**[0002]**

BACKGROUND

**[0003]**

[0001] This application claims the benefit of priority of US Provisional Application No. 61/564,910 filed on November 30, 2011 the content of which is relied upon and incorporated herein by reference in its entirety.

**[0004]**

Field

**[0005]**

[0002] The present invention is directed to a jig and method for carrying a thin glass sheet and, more particularly, to a portable jig and method for carrying a thin glass sheet through processing equipment designed for thicker sheets.

**[0006]**

Technical Background

**[0007]**

[0003] As the demand for thinner panel substrates (< 0.3mm thick) is driven into the electronic display industry, panel makers are faced with a number of challenges for processing.

**[0008]**

One option is to process thicker sheets of glass then etch or polish the panel to thinner overall net thickness. This enables the use of existing panel fabrication infrastructure, but adds finishing costs to the end of the process.

**[0009]**

[0005] A second approach is to re-engineer the existing panel process for thinner substrates. Glass loss in the process is a major interruption, and significant capital would be required for minimizing handling loss in either a sheet to sheet or roll to roll process.

**[0010]**

A third approach would be to use a carrier process where the thin substrate film is bonded to a thicker (typically glass) carrier. Many concepts exist in this space using adhesives, but in many cases the adhesive breaks down in high temperature processes, or causes problems when the thin substrate is delaminated at the end of the process.

**[0011]**

[0007] What is needed, and has yet to be achieved, is a carrier approach that utilizes the existing capital infrastructure of the panel houses, enables processing of glass substrates less than 0.3 mm thick without contamination resulting from the carrier/bonding material, without loss of bond between the carrier and the glass substrate, and/or one in which the desired glass substrate de-bonds easily from the carrier at the end of processing.

**[0012]**

SUMMARY

**[0008]**

The present disclosure is directed to embodiments of a jig which enable processing of a thin glass sheet without contamination or outgassing, and/or enable processing without loss of bond between the carrier and the thin glass sheet, and/or enable the thin glass sheet easily to be de-bonded at the end of processing. Additionally, high temperature processing (for example > 350 degrees C) may be achieved.

**[0013]**

[0009] Additional features and advantages will be set forth in the detailed description which follows, and in part will be readily apparent to those skilled in the art from the description or recognized by practicing the invention as exemplified in the written description and the appended drawings. It is to be understood that both the foregoing general description and the following detailed description are merely exemplary of the invention, and are intended to provide an overview or framework to understanding the nature and character of the invention as it is claimed.

**[0014]**

[0010] The accompanying drawings are included to provide a further understanding of principles of the invention, and are incorporated in and constitute a part of this specification. The drawings illustrate one or more embodiment(s), and together with the description serve to explain, by way of example, principles and operation of the invention. It is to be understood that various features of the invention disclosed in this specification and in the drawings can be used in any and all combinations. By way of non-limiting example, the various features of the embodiments may be combined as set forth in the following aspects.

**[0015]**

[0011] According to a first aspect, there is provided a portable jig for carrying a thin glass sheet, comprising;

**[0016]**

a body having a top planar surface, the top planar surface having a sheet mounting section, wherein the sheet mounting section has a perimeter, and the perimeter encloses an area that is larger than or equal to the area of the thin glass sheet to be carried,

**[0017]**

a pressure cavity disposed in the body and in fluid communication with the sheet mounting section,

**[0018]**

a conduit coupled to the body and in fluid communication with the pressure cavity.

**[0019]**

According to a second aspect, there is provided the apparatus of aspect 1, wherein the body further comprises a bottom planar surface, wherein the bottom planar surface is parallel to

**[0021]**

the top planar surface, and wherein there are no projections extending outwardly from the bottom planar surface.

**[0020]**

[0013] According to a third aspect, there is provided the apparatus of aspect 1 or aspect 2, wherein the top planar surface is made of glass.

**[0021]**

[0014] According to a fourth aspect, there is provided the apparatus of any one of aspects 1- 3, wherein the top planar surface includes openings disposed within the perimeter of the sheet mounting section, and in fluid communication with the pressure cavity.

**[0022]**

[0015] According to a fifth aspect, there is provided the apparatus of any one of aspects 1-3, wherein the pressure cavity is open to the top planar surface within the perimeter of the sheet mounting section.

**[0023]**

[0016] According to a sixth aspect, there is provided the apparatus of any one of aspects 1-3, further comprising a porous member having a surface, wherein the porous-member surface is disposed so as to be coplanar with the top planar surface and within the perimeter of the sheet mounting section.

**[0024]**

[0017] According to a seventh aspect, there is provided the apparatus of aspect 6, wherein the porous member is disposed in the pressure cavity.

**[0025]**

[0018] According to an eighth aspect, there is provided the apparatus of aspect 6 or aspect 7, wherein the porous member is graphite.

**[0026]**

[0019] According to a ninth aspect, there is provided the apparatus of any one of aspects 1-8, further comprising a plug disposed in the conduit.

**[0027]**

[0020] According to a tenth aspect, there is provided a method of processing a thin glass sheet comprising:

**[0028]**

disposing a thin glass sheet adjacent to a top planar surface of a portable jig having a pressure cavity in fluid communication with the top planar surface;

**[0029]**

reducing pressure within the pressure cavity by drawing a vacuum through a conduit in fluid communication with the pressure cavity so the thin glass sheet is held fast to the top surface by the reduced pressure within the pressure cavity; and

**[0030]**

plugging the conduit to hold the reduced pressure within the pressure cavity.

**[0031]**

According to an eleventh aspect, there is provided the method of aspect 10, wherein the jig further comprises a bottom planar surface, wherein the bottom planar surface is parallel to

**[0034]**

the top planar surface, and wherein there are no projections extending outwardly from the bottom planar surface.

**[0032]**

[0022] According to a twelfth aspect, there is provided the method of aspect 10 or aspect 11, wherein the top planar surface is made of glass.

**[0033]**

[0023] According to a thirteenth aspect, there is provided the method of any one of aspects 10-12, wherein the top planar surface includes openings in fluid communication with the pressure cavity.

**[0034]**

[0024] According to a fourteenth aspect, there is provided the method of any one of aspects 10-12, wherein the pressure cavity is open to the top planar surface.

**[0035]**

[0025] According to a fifteenth aspect, there is provided the method of any one of aspects 10-12, wherein the jig further comprises a porous member having a surface, wherein the porous- member surface is disposed so as to be coplanar with the top planar surface.

**[0036]**

According to a sixteenth aspect, there is provided the method of aspect 15, wherein the porous member is disposed in the pressure cavity.

**[0037]**

[0027] According to a seventeenth aspect, there is provided the method of aspect 15 or aspect 16, wherein the porous member is graphite.

**[0038]**

BRIEF DESCRIPTION OF THE DRAWINGS

**[0039]**

[0028] FIG. 1 is a plan view of a carrier according to one embodiment.

**[0040]**

[0029] FIG. 2 is a cross section of the carrier in FIG. 1 as taken along the line 2-2.

**[0041]**

[0030] FIG. 3 is a top view of the carrier in FIG. 1, but without the top plate.

**[0042]**

[0031] FIG. 4 is a top view of a carrier according to a second embodiment.

**[0043]**

[0032] FIG. 5 is a cross section of the carrier in FIG. 4 as taken along line 5-5.

**[0044]**

[0033] FIG. 6 is cross section that is an alternative to that taken along line 5-5 in FIG. 4

**[0045]**

[0034] FIG. 7 is a plan view of a carrier according to a third embodiment.

**[0046]**

[0035] FIG. 8 is a cross section of the carrier in FIG. 7 as taken along line 8-8.

**[0047]**

[0036] FIG. 9 is cross section that is an alternative to that taken along line 8-8 in FIG. 7

**[0048]**

DETAILED DESCRIPTION

**[0049]**

[0037] In the following detailed description, for purposes of explanation and not limitation, example embodiments disclosing specific details are set forth to provide a thorough

**[0050]**

understanding of various principles of the present invention. However, it will be apparent to one

**[0054]**

having ordinary skill in the art, having had the benefit of the present disclosure, that the present invention may be practiced in other embodiments that depart from the specific details disclosed herein. Moreover, descriptions of well-known devices, methods and materials may be omitted so as not to obscure the description of various principles of the present invention. Finally, wherever applicable, like reference numerals refer to like elements.

**[0051]**

[0038] Directional terms as used herein— for example up, down, right, left, front, back, top, bottom— are made only with reference to the figures as drawn and are not intended to imply absolute orientation.

**[0052]**

[0039] Unless otherwise expressly stated, it is in no way intended that any method set forth herein be construed as requiring that its steps be performed in a specific order. Accordingly, where a method claim does not actually recite an order to be followed by its steps or it is not otherwise specifically stated in the claims or descriptions that the steps are to be limited to a specific order, it is no way intended that an order be inferred, in any respect. This holds for any possible non-express basis for interpretation, including: matters of logic with respect to arrangement of steps or operational flow; plain meaning derived from grammatical organization or punctuation; the number or type of embodiments described in the specification.

**[0053]**

As used herein, the singular forms "a," "an" and "the" include plural referents unless the context clearly dictates otherwise. Thus, for example, reference to a "component" includes aspects having two or more such components, unless the context clearly indicates otherwise.

**[0054]**

The present disclosure is directed to embodiments of a jig which enable processing of a thin glass sheet without contamination or outgassing, and/or enable processing without loss of bond between the carrier and the thin glass sheet, and/or enable the thin glass sheet easily to be de-bonded at the end of processing. Additionally, high temperature processing (for example > 350 degrees C) may be achieved.

**[0055]**

[0042] The portable jig may carry thin glass sheets (having a thickness less than or equal to 0.3 mm, for example, 0.3, 0.25, 0.2, 0.15, 0.1, 0.5, 0.25, 0.2, 0.15, 0.1, 0.075, 0.050, 0.25) so that the thin glass sheets may be processed in equipment designed to handle thicker glass sheets.

**[0056]**

The jig disclosed herein utilizes a vacuum to hold the thin glass sheet through processing, and is re-usable. As opposed to previous approaches that have utilized adhesives to bond the thin

**[0061]**

substrate to a carrier, the jig is a portable vacuum chuck that locks the thin substrate to the carrier by the differential pressure between the atmosphere and that in the body of the jig.

**[0057]**

The jig itself can be made from fusion drawn glass in a sandwich arrangement of layers that are easy to assemble and made from readily-available sheets having a thicknesses of, for example, 0.5 to 1.5 mm. Glass enables CTE matching of the jig and thin glass sheet, provides high surface quality to improve vacuum sealing of the thin glass sheet to the jig, and enables existing handling and process tools used in the panel process on thicker ( >0.3 substrates).

**[0058]**

If frit is used to seal the jig, there can be chosen frit materials with melting temperatures above the maximum expected processing temperature. Other options include selecting glasses that can be ion exchanged for superior durability and scratch resistance of the jig itself.

**[0059]**

Other approaches to the invention utilize carriers composed of metals, plastics and porous substrates (e.g., graphite), but care in the selection of material for the processes expected and for handling the potential CTE mismatches with glass substrates should be considered in the design.

**[0060]**

First embodiment

**[0061]**

[0047] One embodiment of a jig 10 will now be described with reference to FIGS. 1-3. The jig 10 has a body 11, a thickness 13, a top planar surface 20, a bottom planar surface 30, a pressure cavity 40, and a conduit 50. A thin glass sheet 2 (shown in phantom in FIG. 2) may be mounted to the jig 10 so that the sheet can be carried through equipment designed to process thicker glass sheets.

**[0062]**

[0048] The thickness 13 may be chosen depending upon the thickness of the thin glass sheet 2. More specifically, the thickness 13 is selected so that a total thickness of the jig 10 together with the thickness of the thin glass sheet 2 adds to the thickness for which a particular piece of equipment was designed. For example, if a machine was designed to handle a glass sheet of 1.0 mm, and the thin glass sheet 2 has a thickness of 0.2 mm, the thickness 13 would be selected to be about 0.8 mm. Typical processing equipment is designed to handle thicknesses of 0.5 to 1.5 mm.

**[0063]**

[0049] The top surface 20 is generally planar and is made of a smooth material, glass for example, so as to avoid scratching the thin glass sheet 2 when mounted thereon. The top planar surface 20 includes a sheet mounting area 22 having a perimeter 24 that encloses an area greater than or equal to that of the thin glass sheet 2 to be mounted thereto. The perimeter 24 may be

**[0069]**

inboard of the perimeter of jig 10, as shown. Alternately, the perimeter 24 may be coextensive with the perimeter of the jig 10. Further, there are openings 26 in the top planar surface 20 and within the perimeter 24. Although shown as generally ovular, the openings 26 may be of any suitable shape, size, and may be disposed in any suitable pattern, i.e., having suitable number and placement distance from one another, regular, or irregular.

**[0064]**

[0050] The bottom surface 30 is generally planar. That is, the bottom planar surface 30 has no projections extending outwardly therefrom that would interfere with moving the jig through processing equipment. Additionally, the bottom planar surface 30 is generally parallel to the top planar surface 20 so that when a thin glass sheet 2 is mounted in the jig 10, the combined structure acts as a planar glass sheet, i.e., having generally parallel top and bottom surfaces, so as to facilitate processing within a piece of processing equipment.

**[0065]**

[0051] Pressure cavity 40 is disposed within the body 11 and is in fluid communication with the openings 26 so that pressure developed in cavity 40 may be presented to the top planar surface 20. The pressure developed in cavity 40 may be either negative (vacuum) or positive pressure. Conduit 50 is disposed on a side of body 11, and within the thickness 13, so as not to extend beyond the top planar surface 20 or the bottom planar surface 30 to thereby avoid interference with the processing equipment through which the jig 10 will carry the thin glass sheet 2. The conduit 50 is in fluid communication with the pressure cavity 40. Although shown as tubular, conduit 50 may have any suitable shape. Further, although shown as a simple tube, conduit 50 may have a quick-connect and/or self-sealing structure in a manner similar to the valve in a soccer ball.

**[0066]**

[0052] The body 11 is made of a top plate 12, a bottom plate 14, and a spacer 16. The thicknesses of the top plate 12, bottom plate 14, and spacer 16 may be suitably chosen so as to make up the desired thickness 13.

**[0067]**

[0053] The top plate 12, bottom plate 14, and spacer 16 may be made of any suitable material. However, the top planar surface 20 of the top plate 12 is preferably made of glass so as to present a smooth, non-scratching, mounting surface for the thin glass sheet 2. Additionally, the top planar surface 20 should be of a material that can form a seal with the thin glass sheet 2 so as to enable a reduced pressure to be maintained within the pressure cavity 40. Because the jig 10 may be re-used many times, it may be preferably to make the top plate 12 from strengthened

**[0074]**

glass, for example, chemically strengthened glass to increase its durability. The spacer 16 and bottom plate 14 may also be made of glass, and particularly the same glass as top plate 12, so as to avoid any CTE mismatch between the materials of the body 11 so as to keep the jig 10 stable when high temperature processing will be carried out on the thin glass sheet 2. Avoiding CTE mismatch between the materials of the body 11 helps minimize any warping in the body 11 that would lead to undesirable warping of the top planar surface 20. That is, it is desirable to keep the top planar surface 20 in a generally planar condition so as to keep the thin glass sheet 2 mounted thereon in a generally planar condition for processing. Additionally, the glass for the top plate 12, bottom plate 14, and spacer 16 may be chosen to be the same as that expected for the thin glass sheet 2 to be carried so as to avoid any CTE mismatch between the body 11 and the thin glass sheet 2 during high temperature processing.

**[0068]**

[0054] The spacer 16 is disposed between, and permanently bonded to, the top plate 12 and bottom plate 14 around the perimeter of the jig 10. Although it is preferable to make the spacer 16 of glass as described above, the spacer 16 may be made of any suitable material, for example, epoxy, glass, or metal, that is capable of bonding to the top plate 12 and bottom plate 14 in a fluid-tight manner. The spacer 16 separates the top plate 12 and bottom plate 14 and is configured so as to form pressure cavity 40. In FIG. 3, the spacer 16 is shown as a frame extending around the perimeter of the jig 10 leaving an open area on the interior that forms the pressure cavity 40. The spacer 16 may be made from a sheet of material having the pressure cavity 40 cut in any desired shape from the interior thereof, i.e., as long as there is enough material to bond in a fluid-tight manner around the perimeter of the jig 10.

**[0069]**

Supports 42 may be disposed in the pressure cavity 40 so as to lend rigidity to the jig 10 and more specifically to the top plate 12 so as to maintain top planar surface 20 in a generally planar condition even when pressure is developed within the pressure cavity 40. The supports 42 may be bonded to either one or both of the top plate 12 and bottom plate 14. Additionally, the supports 42 may have any suitable shape, size, and may be made of any suitable material, for example, sintered frit, glass, metal, graphite, epoxy. Further, the supports 42 may be disposed in any suitable pattern, or distance from one another, for maintaining the top planar surface 20 in a generally planar configuration. The number, spacing, and pattern, for the supports 42 is dependent upon the stiffness of the top plate 12 and that of bottom plate 14. When the top and

**[0077]**

bottom plates 12, 14 are relatively stiff, i.e., less likely to deform under the pressure condition within pressure cavity 40 and the ambient conditions expected during processing of the thin glass sheet 2, fewer and farther spaced supports 42 may be used. The stiffness of the top and bottom plates 12, 14 will depend upon their thickness and the material of which they are made.

**[0070]**

Second embodiment

**[0071]**

[0056] A second embodiment will be described in connection with reference to FIGS. 4 and 5. In this embodiment, mainly the differences from the first embodiment will be described, with the understanding that the remaining elements are similar to those described in connection with the first embodiment, and wherein like reference numerals denote like elements throughout the embodiments. The spacer 16 in this embodiment is formed so as to have portions alternately extending inward from the right and left sides so as to form a pressure cavity having a serpentine configuration. Due to its configuration the spacer 16 itself provides more support to the top plate 12 than that shown in the first embodiment, whereby spacers are not needed or the number thereof is reduced. If desired, however, spacers could be used in this embodiment in a manner similar to that described in connection with the first embodiment.

**[0072]**

[0057] A variation of the second embodiment is shown in FIG. 6. In this variation, the top plate 12 is eliminated, whereby the spacer 16 then provides the top planar surface on which the thin glass sheet 2 is mounted. Specifically, the top surface of the spacer 16 would have the same features as the top planar surface 20 of the first embodiment, for example, a sheet mounting section having a perimeter 24, similar smoothness, scratch resistance, and durability.

**[0073]**

Additionally, because the top plate is eliminated, the thickness 13 of the jig 10 is that of the spacer 16 and the bottom plate 14. Further, in this variation, the pressure cavity 40 itself is open to the top surface without the need for openings 26.

**[0074]**

Third embodiment

**[0075]**

[0058] A third embodiment will be described in connection with reference to FIGS. 7 and 8. In this embodiment, mainly the differences from the first and second embodiments will be described, with the understanding that the remaining elements are similar to those described in connection with the first and second embodiments, and wherein like reference numerals denote like elements throughout the embodiments. In this embodiment, the top plate 12 is formed with a porous member 60 instead of openings 26. The porous member 60 has a top surface 62 that is

**[0084]**

coplanar with top planar surface 20 so the thin glass sheet 2 lies flat across the extent of the jig 10. The porous member 60 is made of a material that allows fluid communication between the top surface (62, 20) and the pressure cavity 40. For example, the porous member 60 may be made of graphite. Instead of being present as one continuous area, the porous member 60 may be disposed in a plurality of separate areas in a manner similar to the pattern of openings 26.

**[0076]**

A variation of the third embodiment is shown in FIG. 9. In this variation, the spacer 16 is eliminated so that the pressure cavity 40 is formed by the top plate 12, and the porous member 60 is disposed within the pressure cavity 40.

**[0077]**

Use of the jig

**[0078]**

[0060] The use of the jig 10 to mount and carry a thin glass sheet 2 will now be described. The thickness 13 is selected, as described above, based on the thickness of the thin glass sheet 2 to be processed and the range of thicknesses that may be accommodated in the processing equipment to be used.

**[0079]**

[0061] A thin glass sheet 2 is disposed on or adjacent to the top planar surface 20. The pressure in pressure cavity 40 is then reduced by drawing a vacuum out of conduit 50. As the pressure in pressure cavity 40 is reduced, the thin glass sheet 2 is sucked down and held fast to top planar surface 20. A vacuum may be drawn by a hose (not shown ) or other device temporarily coupled between the conduit 50 and a pump, vacuum, blower, or other suitable device as known in the art. After a suitable amount of pressure reduction in pressure cavity 40 has been achieved, the hose is uncoupled from conduit 50, and a plug 52 is used to block the conduit 50 and thereby hold the reduced pressure. The plug 52 may be any suitable material that can withstand the expected environment (in terms of temperature, pressure, and chemical composition, for example) in the processing equipment. If the conduit 50 has a self-sealing feature as noted above, a separate plug 52 is not necessary. The reduced pressure in pressure cavity 40 holds the thin glass sheet 2 fast to the jig 10. Because the pressure cavity 40 is built into the body 1 1 of the jig 10, i.e., it has a rigid structure, and because the pressure cavity 40 may be connected to a vacuum source via conduit 50, a significant pressure reduction may be achieved so as the thin glass sheet 2 is held fast to the jig 10 through a wide variety of processing conditions. The amount of pressure reduction in pressure cavity 40 may be chosen so that a suitable vacuum is

**[0089]**

maintained even throughout the actual pressure in the pressure cavity 40 may fluctuate during processing due to the temperature in the processing equipment.

**[0080]**

[0062] The materials of the jig 10 are selected to withstand the processing conditions expected in the processing equipment in terms of temperature, pressure and chemical environment. For example, the materials for top plate 12, bottom plate 14, and spacer 16, may be ones having high thermal stability to allow high temperature processing of the thin glass sheet 2 carried thereon. As noted above, for example, the top plate 12, bottom plate 14 and spacer 16, and supports 42 may be made of glass. Additionally, because no adhesives are used to hold the thin glass sheet 2 to the jig 10, again a high temperature environment may be used to process the thin glass sheet 2. For example, thermal processing may be carried out at > 350 degrees C, and may be done without outgassing or loss of coupling between the thin glass sheet 2 and the jig 10.

**[0081]**

The jig 10, together with the thin glass sheet 2 thereon may be conveyed through processing equipment as if it were a thicker sheet of glass. Thus, existing capital equipment, designed to be used with thicker glass sheets, may be used to process thin glass sheets 2. The processing of a thin glass sheet 2 directly then eliminates the need for final product etching or polishing to thin a thicker substrate to a desired final thickness.

**[0082]**

[0064] After the desired processing has been performed on thin glass sheet 2, the plug 52 is removed so as to allow the pressure in pressure cavity 40 to return to ambient pressure and, thereby, reduce the jig's hold on thin glass sheet 2. Alternatively, or in addition thereto, a slight pressure may be introduced into the pressure cavity 40 to facilitate release of the thin glass sheet 2. Pressure may be introduced to the pressure cavity 40 by again connecting a hose to the conduit 50 and a pressure source. Thus, at the end of processing, the thin glass sheet 2 easily may be released from the jig 10 without any residue being formed on the thin glass sheet 2. Moreover, the jig 10 is washable (should that be necessary) and re-usable.

**[0083]**

Conclusion

**[0084]**

[0065] It should be emphasized that the above-described embodiments of the present invention, particularly any "preferred" embodiments, are merely possible examples of implementations, merely set forth for a clear understanding of various principles of the invention. Many variations and modifications may be made to the above-described embodiments of the invention without departing substantially from the spirit and various principles of the invention. All such

**[0095]**

modifications and variations are intended to be included herein within the scope of this disclosure and the present invention and protected by the following claims.

**[0085]**

For example, instead of a pressure cavity 40 and openings 26, the openings 26 may be connected to the conduit 50 by a series of pipes or conduits built into the spacer member 16.

**[0086]**

Further, for example, instead of separate spacer 16 and support members 28, these structures may be made monolithically out of a sheet of glass by hot pressing.

## Classifications

- B65G49/061
- B65G2249/02
- B65G2249/045
- B65G49/06
- H01L21/683
- H10P72/78

## Cited patent documents

- [US-2002108238-A1](https://patents.google.com/patent/US20020108238A1/en) — ISR
- [US-2006231454-A1](https://patents.google.com/patent/US20060231454A1/en) — ISR
- [US-2008075935-A1](https://patents.google.com/patent/US20080075935A1/en) — ISR
- [US-2009081852-A1](https://patents.google.com/patent/US20090081852A1/en) — ISR

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
