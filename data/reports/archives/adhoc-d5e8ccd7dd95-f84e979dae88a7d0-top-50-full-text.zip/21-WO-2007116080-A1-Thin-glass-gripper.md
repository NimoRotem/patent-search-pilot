# 21. Thin-glass gripper

- **Archive rank:** 21 of 50
- **Publication:** [WO-2007116080-A1](https://patents.google.com/patent/WO2007116080A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/038057715/publication/WO2007116080A1?q=pn%3DWO2007116080A1)
- **Publication date:** 2007-10-18
- **Filing date:** 2007-04-11
- **Earliest priority:** 2006-04-12
- **Family:** 38057715
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** KREUZBERGER STEFAN; PFLANZNER GUENTHER; SCHOTT AG
- **Inventors:** KREUZBERGER STEFAN; PFLANZNER GUENTHER

## Abstract

A thin-glass gripper is described for holding and turning a flat workpiece (1), comprising a plurality of gripper arms (2a-h) having at least one suction lifter (3a-n) arranged in each case on them, wherein the gripper arms (2a-h) can be connected via a common connecting flange (4) to a handling and transferring device (19) and the suction lifters (3a-n) can be connected to a vacuum line (5). The gripper arms (2a-h) of the thin-glass gripper are oriented radially with regard to the connecting flange (4) and are telescopic in their axial direction.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf000.png)

![Sketch 1 for WO-2007116080-A1](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf001.png)

![Sketch 2 for WO-2007116080-A1](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf002.png)

![Sketch 3 for WO-2007116080-A1](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf003.png)

![Sketch 4 for WO-2007116080-A1](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf004.png)

![Sketch 5 for WO-2007116080-A1](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf005.png)

![Sketch 6 for WO-2007116080-A1](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf006.png)

![Sketch 7 for WO-2007116080-A1](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf007.png)

![Sketch 8 for WO-2007116080-A1](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf008.png)

![Sketch 9 for WO-2007116080-A1](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf009.png)

![Sketch 10 for WO-2007116080-A1](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf009.png)

[Sketch 11](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf010.png)

![Sketch 11 for WO-2007116080-A1](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf010.png)

[Sketch 12](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf011.png)

![Sketch 12 for WO-2007116080-A1](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf011.png)

[Sketch 13](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf012.png)

![Sketch 13 for WO-2007116080-A1](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf012.png)

[Sketch 14](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf013.png)

![Sketch 14 for WO-2007116080-A1](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf013.png)

[Sketch 15](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf014.png)

![Sketch 15 for WO-2007116080-A1](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf014.png)

[Sketch 16](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf015.png)

![Sketch 16 for WO-2007116080-A1](https://nimo.iptorch.com/refdrawing/WO-2007116080-A1/pdf015.png)

## Claims

### Claim 1 (independent)

Patentansprüche Dünnglasgreifer zum Halten und Umsetzen eines flächenartigen Werkstückes (1), umfassend mehrere Greiferarme (2a-h) mit mindestens einem jeweils daran angeordneten Saugheber (3an), wobei die Greiferarme (2a-h) über einen gemeinsamen Anschlussflansch (4) an eine Handhabungsund Überführungseinrichtung (19) und die Saugheber (3a-n) an eine Vakuumleitung (5) anschliessbar sind, dadurch gekennzeichnet, dass die Greiferarme (2a-h) bezüglich des Anschlussflansches (4) radial ausgerichtet und in ihrer axialen Richtung teleskopierbar sind.

### Claim 2

Greifer nach Anspruch 1 , dadurch gekennzeichnet, dass die Greiferarme (2a-h) jeweils ein Aussenrohr (6) und ein darin verschiebbares Innenrohr (7) aufweisen.

### Claim 3

Greifer nach Anspruch 2, dadurch gekennzeichnet, dass das Innenrohr (7) gegenüber dem Aussenrohr (6) manuell verstellbar ist.

### Claim 4

Greifer nach Anspruch 2, dadurch gekennzeichnet, dass das Innenrohr (7) gegenüber dem Aussenrohr (6) mittels eines Stellmotors (8) verstellbar ist.

### Claim 5

Greifer nach einem der Ansprüche 1 bis 4, dadurch gekennzeichnet, dass die Greiferarme (2a-h) in Umfangsrichtung zueinander einen gleichen Winkel bilden.

### Claim 6

Greifer nach einem der Ansprüche 1 bis 5, dadurch gekennzeichnet, dass mindestens ein Saugheber (3a, c, e, f, g, i, j, I1 m, n) jeweils an den äusseren Enden der Greiferarme (2a-h) angeordnet ist, wobei diese Saugheber (3a, c, e, f, g, i, j, I1 m, n) zueinander eine rechteckige Grundfläche aufspannen.

### Claim 7

Greifer nach einem der Ansprüche 1 bis 6, dadurch gekennzeichnet, dass die Greiferarme (2a-h) als Polygonprofil geformt sind.

### Claim 8

Greifer nach einem der Ansprüche 1 bis 7, dadurch gekennzeichnet, dass die Greiferarme (2a-h) aus Karbon gefertigt sind.

### Claim 9

Greifer nach einem der Ansprüche 1 bis 8, dadurch gekennzeichnet, dass an dem Anschlussflansch (4) acht Greiferarme (2a-h) angeordnet sind, die zueinander abwechselnd jeweils einen Winkel von 41 [deg.] auf der einen Seite und 50<D> auf der anderen Seite eines Armes aufweisen.

### Claim 10

Greifer nach Anspruch 9, dadurch gekennzeichnet, dass an vier diametral angeordneten Greiferarmen (2a, 2c, 2e, 2g) jeweils ein Saugheber (3b, 3d, 3h, 3k) am Aussenrohr (6) und jeweils ein Saugheber (3a, 3e, 3i, 3I) am Innenrohr (7) angeordnet ist.

### Claim 11

Greifer nach Anspruch 9 oder 10, dadurch gekennzeichnet, dass an zwei diametral angeordneten Greiferarmen (2d, 2h) das Innenrohr (7) endseitig jeweils einen quer ausgerichteten Haltebügel (9a, b) mit zwei Saughebern (3f, 3g, 3m, 3n) aufweist.

### Claim 12

Greifer nach einem der Ansprüche 1 bis 11 , dadurch gekennzeichnet, dass mehrere Saugheber (3a-n) in Saugzonen zusammengefasst und diese einzeln mit einem Unterdruck beaufschlagbar sind.

### Claim 13

Greifer nach einem der Ansprüche 1 bis 12, dadurch gekennzeichnet, dass an dem Dünnglasgreifer mindestens ein Abstandssensor (10) angeordnet ist.

### Claim 14

Greifer nach einem der Ansprüche 1 bis 13, dadurch gekennzeichnet, dass die Greiferarme (2a-h) an einer zentrisch angeordneten Lagerplatte (11) befestigt sind.

## Full description

### Dünnglasgreifer

**[0001]**

Die Erfindung betrifft einen Dünnglasgreifer zum Halten und Umsetzen eines flächenartigen Werkstückes, umfassend mehrere Greiferarme mit mindestens einem jeweils daran angeordneten Saugheber, wobei die Greiferarme über einen gemeinsamen Anschlussflansch an eine Handhabungsund Überführungseinrichtung und die Saugheber an eine Vakuumleitung anschliessbar sind.

**[0002]**

Ein wesentlicher Bestandteil der Transportkette bei der Produktion dünnwandiger Glasscheiben sind neben Förderbändern vor allem Dünnglasgreifer, die auch als Vakuum-Saugheber bezeichnet werden. Diese arbeiten mit einem Unterdruck von 0,3 bar bis 1,0 bar und sind an den Handhabungsund Überführungseinrichtungen angebracht, insbesondere Industrierobotern, welche in der Lage sind, Bewegungen im Raum ausführen zu können.

**[0003]**

Bei der Herstellung von Dünnglas hat im Laufe der Zeit ein Bedarf an grösseren zu transportierenden Glasformaten zugenommen. Darüber hinaus hat sich für bestimmte Anwendungen die Dicke des Dünnglases weiter verringert, so dass bei Einsatz der bekannten Dünnglasgreifer zunehmend die Belastungsgrenze des Dünnglases überschritten wurde und es während des Transportes zu erheblichen Verlusten kam. Ein weiterer Nachteil besteht darin, dass in einer eingerichteten Transportkette mit den bisher bekannten Dünnglasgreifern nur eine begrenzte Flexibilität bezüglich des Transportes anderer Glasformate realisierbar ist.

**[0004]**

Demzufolge liegt der Erfindung die Aufgabe zugrunde einen Dünnglasgreifer bereitzustellen, der ein schonendes Handling diverser Glasformate ermöglicht. Die Aufgabe wird erfindungsgemäss mit einem Dünnglasgreifer gelöst, bei dem die Greiferarme bezüglich des Anschlussflansches radial ausgerichtet und in ihrer axialen Richtung teleskopierbar sind.

**[0005]**

Der Anschlussflansch dient der Befestigung des Dünnglasgreifers an der Handhabungsund Überführungseinrichtung. Des Weiteren ist der Dünnglasgreifer an eine Vakuumleitung angeschlossen, die über davon abzweigende Leitungen mit allen Saughebern verbunden ist.

**[0006]**

Durch die radiale Ausrichtung der Greiferarme ist es möglich, die Saugheber bezüglich der Oberfläche des Dünnglases möglichst gleichmässig zu verteilen. Die axiale Verstellbarkeit sorgt für eine flexible Anpassung des Dünnglasgreifers auf unterschiedlich Glasformate, unter Beibehaltung der gleichmässigen Verteilung der Saugheber. Dabei wächst lediglich der Abstand der Saugheber zueinander in gleichem Masse, so dass auch bei grossen Flächen des Dünnglases eine annähernd gleich bleibende Belastung beibehalten bleibt. Die Verstellbarkeit sollte stufenlos erfolgen.

**[0007]**

Für eine teleskopierbare Verstellung der Greiferarme weisen diese vorzugsweise jeweils ein Aussenrohr und ein darin verschiebbares Innenrohr auf. Gemäss einer ersten vorteilhaften Ausführungsform ist das Innenrohr gegenüber dem Aussenrohr manuell verstellbar. Dieses kann beispielsweise durch ein Lösen einer Befestigungsschraube und ein anschliessendes Herausziehen des Innenrohres erfolgen. In einer Endstellung wird dann die Befestigungsschraube von Hand wieder festgezogen.

**[0008]**

Alternativ hierzu kann das Innenrohr gegenüber dem Aussenrohr auch mittels eines Stellmotors verfahrbar sein, wobei jeder Greiferarm mit einem eigenen Stellmotor ausgestattet und angesteuert werden sollte. Mit Hilfe einer Verstellung über einen Stellmotor kann besonders flexibel die Position der Saugheber verschoben und dadurch auf unterschiedliche Glasformate eingestellt werden.

**[0009]**

Es hat sich als günstig erwiesen, wenn die Greiferarme in Umfangsrichtung zueinander einen gleichen Winkel bilden. Diese Anordnung erlaubt bei gleichem Ausfahrzustand der Innenrohre eine relativ zueinander gleichmässige Verteilung der Saugheber und somit eine gleichmässig verteilte Krafteinleitung in die zu transportierende Dünnglasscheibe.

**[0010]**

In einer besonderen Ausführungsform ist mindestens ein Saugheber jeweils an den äusseren Enden der Greiferarme angeordnet, wobei diese Saugheber zueinander eine rechteckige Grundfläche aufspannen, das heisst, sich alle Innenrohre in einem gleichen Ausfahrzustand befinden. Dieses ist insbesondere dann sinnvoll, wenn rechteckige Glasformate mit dem Dünnglasgreifer angehoben werden sollen.

**[0011]**

Vorzugsweise sind die Greiferarme als Polygonprofil geformt, besonders bevorzugt angenähert an ein DIN 32712 - P4C-Profil mit gerundeten Kanten. Im Wesentlichen besteht dieses Profil aus einem Kreis mit vier zykloidisch abgeflachten Seiten. Dieser Profilquerschnitt erlaubt eine leichte und schnelle Verstellung des Innenrohres gegenüber dem ortsfest stehenden Aussenrohr auch unter Belastung. Darüber hinaus erlaubt ein derartiges Profil die Übertragung eines hohen Drehmomentes bei kompakten Abmassen, so dass die Saugheber äusserst verdrehsicher an den Greiferarmen angebracht sind. Aufgrund des Polygonprofils kommt es zwischen Innenrohr und Aussenrohr zu keiner Kerbwirkung und nur zu einem minimalen Spiel, wodurch ein Ausschlagen des Innenrohrs vermieden wird. Das Polygonprofil weist einen grossen hohlen Innenraum auf, welcher Platz zum Beispiel für einen Linearantrieb oder Leitungen zur Versorgung mit Druckluft, Vakuum oder Strom bietet. - A -

**[0012]**

Günstigerweise sind die Greiferarme aus Karbon gefertigt. Dieses ermöglicht eine massive Reduzierung der Todmasse des Greiferarmes um annähernd 50 % gegenüber einer Ausführung in Aluminiumbauweise. Dadurch wiederum lassen sich gesamte Produktionsabläufe schneller durchführen, da die Dünnglasgreifer mit erheblich grösseren Schwenkgeschwindigkeiten arbeiten können. Die Karbon-Bauweise ist besonders geeignet, um die vorstehend beschriebenen Polygonprofile herzustellen. Hierbei wird zunächst eine geschliffene Polygonwelle hergestellt, welche bis zu einer Länge von 1000 mm relativ gut gefertigt werden kann. Das Aussenrohr entsteht durch das Umwickeln der geschliffenen Polygonwelle, das Innenrohr entsteht durch das Ausschlagen des Aussenrohres. Somit kann diese Welle-Nabe-Verbindung mit nur einem Werkzeug sehr passgenau und über 1000 mm Länge hergestellt werden. Abgesehen von der einmaligen Anschaffung der geschliffenen Polygonwelle ist diese Führung auch recht kostengünstig herzustellen.

**[0013]**

Vorteilhafterweise sind an dem Anschlussflansch acht Greiferarme angeordnet sind, die zueinander abwechselnd jeweils einen Winkel von 41 [deg.] auf der einen Seite und 50[deg.] auf der anderen Seite eines Armes aufweisen. Hierdurch ergibt sich eine enge Beabstandung der Saugheber mit einer entsprechend geringen Belastung des Dünnglases, welche insbesondere für den Transport dünnwandiger Glasformate wie Touchscreens notwendig ist.

**[0014]**

Es hat sich auch als vorteilhaft herausgestellt, wenn an vier diametral zu dem Anschlussflansch angeordneten Greiferarmen jeweils ein Saugheber am Aussenrohr und ein Saugheber am Innenrohr angeordnet ist. An zwei diametral zu dem Anschlussflansch angeordneten Greiferarmen kann das Innenrohr endseitig jeweils einen quer zum Innenrohr ausgerichteten Haltebügel mit zwei Saughebern aufweisen. Zusätzlich können weitere zwei diametral angeordnete Greiferarme vorgesehen sein, an denen endseitig jeweils ein Saugheber angeordnet ist. Die beiden letztgenannten Greiferarme können abwechselnd zwischen den erstgenannten Greiferarmen positioniert sein.

**[0015]**

Vorzugsweise sind mehrere Saugheber in Saugzonen zusammengefasst und diese einzeln mit einem Unterdruck beaufschlagbar. Dieses ist besonders beim Ablegen der Dünnglasscheiben von Vorteil, da ein Auffächern der einzelnen Scheiben im Stapel an der unteren Kante weit gehend vermieden wird. Andernfalls rutschen die Scheiben beim Transport auf der Kante und werden hierdurch zerstört.

**[0016]**

In einer bevorzugten Ausgestaltung ist an dem Dünnglasgreifer mindestens ein Abstandssensor, besonders bevorzugt zwei Abstandssensoren, angeordnet. Diese dienen zur Erfassung des Abstandes zu der Dünnglasscheibe und unterstützen die Positionserfassung und Lageregelung, wodurch ein besonders treffsicherer Kontakt an der vorgesehenen Position der Dünnglasscheibe erreicht wird. Auch hierdurch wird das schonende Handling unterstützt.

**[0017]**

Zur Erhöhung der Stabilität können die Greiferarme an einer zentrisch angeordneten Lagerplatte befestigt sein. Hierdurch erfolgt auch eine Ausrichtung der Haltearme in einer Ebene zueinander.

**[0018]**

Zum besseren Verständnis wird die Erfindung nachfolgend anhand von fünf Figuren näher erläutert. Es zeigen die Fig. 1 : eine perspektivische Draufsicht auf einen

**[0019]**

Dünnglasgreifer;

**[0020]**

Fig. 2: eine Unteransicht auf einen Dünnglasgreifer;

**[0021]**

Fig. 3: eine Seitenansicht auf einen

**[0022]**

Dünnglasgreifer;

**[0023]**

Fig. 4a: eine perspektivische Draufsicht auf einen

**[0024]**

Greiferarm mit daran angeordnetem Saugheber;

**[0025]**

Fig.4b: einen Längsschnitt durch einen Greiferarm mit Stellmotor und

**[0026]**

Fig. 5: eine perspektivische Draufsicht auf einen

**[0027]**

Greiferarm mit daran angeordnetem Haltebügel und zwei Saughebern.

**[0028]**

Die Figur 1 zeigt in einer perspektivischen Seitenansicht einen Dünnglasgreifer mit einem mittig angeordneten Anschlussflansch 4, welcher zur Befestigung des Dünnglasgreifers an einem Roboterarm 19 (siehe Figur 3) dient.

**[0029]**

Von dem Anschlussflansch 4 erstrecken sich insgesamt acht Greiferarme 2a-h radial nach aussen, wobei der Anschlussflansch 4 einen gemeinsamen Mittelpunkt bildet. Auf der Unterseite weisen die Greiferarme 2a-h jeweils mindestens einen endseitig daran angeordneten tellerförmigen Saugheber 3a-n auf. Zur Erhöhung der Stabilität sind die Greiferarme 2a-h mit Ihrer Oberseite an einer gemeinsamen Lagerplatte 11 befestigt. Die konstruktive Ausführung der einzelnen Greiferarme 2a-h ist besonders gut in der Figur 2 zu erkennen. Die Figur 2 zeigt eine um die Drehachse 20 (siehe Figur 1) in Pfeiirichtung geschwenkte Unteransicht des Dünnglasgreifers. Die Greiferarme 2a-h sind zweiteilig aufgebaut und umfassen ein an den Anschlussflansch 4 heranreichendes ortsfestes Aussenrohr 6 und ein durchmesserkleineres darin verschiebbar geführtes Innenrohr 7. Die Aussenrohre 6 ragen dabei über die Lagerplatte 11 hinaus. In der Darstellung der Figuren 1 und 2 befinden sich die Innenrohre 7 in einer ausgefahrenen Position und ermöglichen dadurch den Transport beziehungsweise das Handling von grossen Dünnglasscheiben.

**[0030]**

Insgesamt vier Greiferarme 2a, 2c, 2e, 2g sind in gleicherweise mit Saughebern 3a, 3b, 3d, 3e, 3i, 3h, 3k, 3I bestückt, wobei jeweils ein Saugheber 3b, 3d, 3h, 3k bezüglich des Anschlussflansches 4 ortsfest an dem Aussenrohr 6 und jeweils ein Saugheber 3a, 3e, 3i, 3I ortsfest an dem äusseren Ende des Innenrohres 7 angeordnet ist. Zwei der vier Greiferarme 2a, 2c, 2e, 2g liegen sich bezogen auf den Anschlussflansch diametral gegenüber.

**[0031]**

Die gegenüberliegenden Greiferarme 2b, 2f weisen jeweils an ihrem äusseren Ende des Innenrohres 7 einen einzigen Saugheber 3c, 3j auf. An den jeweiligen Aussenrohren 6 der Greiferarme 2b, 2f sind keine weiteren Saugheber vorgesehen.

**[0032]**

Zwischen den Greiferarmen 2a, 2g und 2c, 2e befinden sich gegenüberliegend weitere Greiferarme 2d, 2h, deren verstellbare Innenrohre 7 endseitig jeweils einen quer zur axialen Erstreckung des Innenrohres 7 ausgerichteten Haltebügel 9a, 9b tragen. Die Saugheber 3f, 3g greifen an dem Haftebügel 9a und die Saugheber 3m, 3n an dem Haltebügel 9b jeweils endseitig an, wodurch der freie Abstand zwischen den Saughebern 3a, 31 und 3e, 3i erheblich reduziert wird und die zu transportierende Dünnglasscheibe eine zusätzliche Abstützung erfährt. Wie in der Unteransicht der Figur 2 auch zu erkennen ist, spannen die Saugheber 3a, 3e, 3i, 31 ein Rechteck auf, in dessen Flucht die übrigen äusseren Saugheber 3c, 3f, 3g, 3j, 3m, 3n liegen.

**[0033]**

In einer Bohrung der Lagerplatte 11 ist ein Abstandssensor 10 eingesetzt, mit dem der Abstand des Dünnglasgreifers zu einem Werkstück 1 (siehe Figur 3) erfasst wird und dadurch der Dünnglasgreifer besonders präzise an das Werkstück herangefahren werden kann.

**[0034]**

Die Figur 3 zeigt eine Seitenansicht des Dünnglasgreifers, welcher mit seinem zentrisch angeordneten Anschlussflansch 4 an dem Roboterarm 19 montiert ist. In dieser Ansicht sind lediglich die Greiferarme 2c, 2d, 2e mit ihren Saughebern 3e, 3f, 3g, 3i sichtbar. Die Saugheber 3e, 3f, 3g, 3i stehen an ihrer Unterseite in Kontakt mit einem Werkstück 1 in Form einer Dünnglasscheibe. Der für ein Halten des Werkstückes 1 notwendige Unterdruck wird über eine Vakuumleitung 5 auf den Dünnglasgreifer übertragen. Im Bereich des Anschlussflansches 4 verzweigt sich die gebündelte Vakuum leitung 5 mit ihren einzelnen Leitungen auf die Greiferarme 2a-h und ist durch diese mit dem jeweiligen Saugheber 3a-n verbunden, wie beispielhaft anhand der gestrichelten Linie in Greiferarm 2e zu erkennen ist. Durch den voneinander unabhängigen Anschluss der Saugheber 3a-n lassen sich die Saugheber 3a-n einzeln oder zusammengefasst in Gruppen mit einem einstellbaren Unterdruck beaufschlagen beziehungsweise abblasen.

**[0035]**

In der Seitenansicht der Figur 3 ist auch zu erkennen, dass das Aussenrohr 6 und das Innenrohr 7 als im Wesentlichen quadratischer Querschnitt mit gewölbten Seitenflächen und gerundeten Ecken ausgebildet ist. Die Figur 4a stellt in einer perspektivischen Ansicht einen Greiferarm 2b, 2f dar. Dieser ist mittels eines innen liegenden Untergurtes 12 und eines aussen liegenden Untergurtes 13 an der Lagerplatte 11 (siehe Figuren 1 bis 3) befestigbar. An dem äusseren Ende des Aussenrohres 6 ist eine Befestigungsschraube 15 angeordnet, deren unteres Ende durch das Aussenrohr 6 hindurch bis auf das Innenrohr 7 reicht. Die Befestigungsschraube 15 greift mit ihrem Gewinde in ein komplementär geschnittenes Gewinde eines Sockels 21, welcher integraler Bestandteil eines Manschettenoberteils 16 ist. Das Manschettenoberteil

**[0036]**

16 wiederum greift mit einem flanschartigen Befestigungsabschnitt 22 an ein von unten an das Aussenrohr 6 angelegtes Manschettenunterteil

**[0037]**

17 an und wird über den mindestens einen Befestigungsabschnitt 22 mit diesem zu einem geschlossenen Bauteil verbunden. Durch ein Lösen der Befestigungsschraube 15 steht diese nicht mehr in Wirkeingriff mit dem Innenrohr 7, so dass dieses in axialer Richtung gegenüber dem Aussenrohr 6 verschoben werden kann. Zur Befestigung des Innenrohres 7 gegenüber dem Aussenrohr 6 wird die Befestigungsschraube 15 erneut angezogen.

**[0038]**

Die Saugheber 3a-n sind mittels eines Obergurtes 14 an dem jeweiligen Innenrohr 7 befestigt. Beispielhaft ist dieses anhand des Saughebers 3c, 3j zu erkennen. Auf der Oberseite der Saugheber 3a-n befindet sich ein Anschlussstutzen 18, an welchen eine einzelne Leitung der Vakuumleitung 5 anschliessbar ist.

**[0039]**

Die Figur 4b zeigt einen Längsschnitt durch einen Greiferarm 2b, 2f, bei dem sich das Innenrohr 7 gegenüber dem Aussenrohr 6 in einer eingefahrenen Stellung befindet. Das Verfahren des Innenrohres 7 erfolgt jedoch nicht von Hand, sondern mittels eines Stellmotors 8. Dafür wurde die Befestigungsschraube 15 entfernt und anstelle dessen ein Stellmotor 8, vorzugsweise ein Stellzylinder, auf dem Greiferarm 2b, 2f angeordnet. Der Stellmotor 8 greift mit einem ersten Ende an dem Aussenrohr 6 und einem zweiten Ende an dem Innenrohr 7 an, wobei das erste Ende beispielsweise auf dem Sockel 21 angebracht sein kann. Aufgrund der baugleichen Ausführung von Aussenund Innenrohr 6, 7 aller Greiferarme 2a-h des Dünnglasgreifers ist es besonders einfach zu realisieren, alle Greiferarme 2a-h mit einem Stellmotor 8 auszustatten.

**[0040]**

Die Figur 5 stellt eine Ausführungsform der Greiferarme 2d, 2h dar, an deren Ende mittels des Obergurtes 14 ein Haltebügel 9a, 9b quer zur axialen Erstreckung des Innenrohres 7 befestigt ist. An dem Haltebügel 9a, 9b stehen in Verlängerung des Innenrohres 7 zwei Anschlussstutzen 18 hervor, von denen der erste zum Anschluss einer nicht dargestellten Verbindungsleitung zu dem Saugheber 3f, 3n und der zweite zum Anschluss einer weiteren ebenfalls nicht gezeigten Verbindungsleitung zu dem Saugheber 3g, 3m vorgesehen ist.

### Innenrohr

**[0041]**

Stellmotor a, b Haltebügel 0 Abstandssensor 1 Lagerplatte 2 Untergurt innen 3 Untergurt aussen 4 Obergurt 5 Befestigungsschraube 6 Manschettenoberteil 7 Manschettenunterteil 8 Anschlussstutzen 9 Handhabungsund Überführungseinrichtung, Roboterarm 0 Drehachse 1 Sockel 2 flanschartiger Befestigungsabschnitt

## Classifications

- B66C1/02
- B66C1/0262
- B65G2249/04
- B65G47/91
- B65G47/91
- B65G49/06
- B65G49/06
- B65G49/061
- B66C1/02
- B66C1/0212
- B66C1/0243

## Cited patent documents

- [EP-1170218-A1](https://patents.google.com/patent/EP1170218A1/en) — ISR
- [US-4228993-A](https://patents.google.com/patent/US4228993A/en) — ISR
- [WO-2006089327-A1](https://patents.google.com/patent/WO2006089327A1/en) — ISR

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
