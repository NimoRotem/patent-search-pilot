# 15. Vacuum gripper device.

- **Archive rank:** 15 of 50
- **Publication:** [GB-2248221-A](https://patents.google.com/patent/GB2248221A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/010680625/publication/GB2248221A?q=pn%3DGB2248221A)
- **Publication date:** 1992-04-01
- **Filing date:** 1991-08-14
- **Earliest priority:** 1990-08-14
- **Family:** 10680625
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** PORTSMOUTH TECH CONSULT
- **Inventors:** COLLIE ARTHUR ALEXANDER

## Abstract

_No abstract was available from the queried sources._

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf000.png)

![Sketch 1 for GB-2248221-A](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf001.png)

![Sketch 2 for GB-2248221-A](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf002.png)

![Sketch 3 for GB-2248221-A](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf003.png)

![Sketch 4 for GB-2248221-A](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf004.png)

![Sketch 5 for GB-2248221-A](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf005.png)

![Sketch 6 for GB-2248221-A](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf006.png)

![Sketch 7 for GB-2248221-A](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf007.png)

![Sketch 8 for GB-2248221-A](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf008.png)

![Sketch 9 for GB-2248221-A](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf009.png)

![Sketch 10 for GB-2248221-A](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf009.png)

[Sketch 11](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf010.png)

![Sketch 11 for GB-2248221-A](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf010.png)

[Sketch 12](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf011.png)

![Sketch 12 for GB-2248221-A](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf011.png)

[Sketch 13](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf012.png)

![Sketch 13 for GB-2248221-A](https://nimo.iptorch.com/refdrawing/GB-2248221-A/pdf012.png)

## Claims

### Claim 1 (independent)

A vacuum gripper device comprising a body, an outwardly depending sealing skirt or rim extending from an underside of said body, a multiejector vacuum pump carried by said body, a compressed air inlet connected to an inlet port of said pump, an exhaust outlet connected to an exhaust port of said pump, an aperture in the underside of said body which connects with_ a vacuum port of said pump, and valve means for opening and closing said exhaust outlet whereby, in use of said device, a compressed air supply is permanently connected to said compressed air inlet, said valve means being normally closed to close said exhaust outlet so that compressed air is caused to be emitted from said aperture in the underside of said body via the vacuum port of said pump, said valve means being opened when said gripper device is to be attached to an adjacent surface, whereby a vacuum is formed by said pump in said vacuum port and on the underside of said body, which causes said body to be attached to said surface.

### Claim 2

A device as claimed in claim 1, in which said body comprises a twopart, hollow, disc-shaped housing in which said vacuum pump is disposed.

### Claim 3

A device as claimed in claim 2, in which said housing comprises an inverted shallow cup-shaped member in which said pump is disposed, and a disc-shaped member which closes said cup-shaped member and which forms the underside of said housing.

### Claim 4

A device as claimed in claim 3, in which said cup-shaped member is provided with an air distribution manifold which includes said compressed air inlet and said exhaust outlet, and which includes a vacuum connecting pipe which couples the vacuum port of said pump with the interior of said housing, said aperture being provided in said disc-shaped member for connecting the interior of said housing to the underside of said housing.

### Claim 5

A device as claimed in any preceding claim, in which said valve means comprises a pneumatically operated valve.

### Claim 6

A device as claimed in any preceding claim, comprising an air filter disposed in the aperture in the underside of said housing.

### Claim 7

A device as claimed in any of claims 2 to 6, in which said sealing skirt or rim is clamped between the two parts of said housing.

### Claim 8

A device as claimed in any of claims 3 to 6, in which said sealing skirt is attached to said disc-shaped member.

### Claim 9

A device as claimed in claim 8, in which said disc-shaped member is adjustably mounted on said cup-shaped member.

### Claim 10

A device as claimed in claim 9, in which said disc-shaped member is coupled to said cup-shaped member by a flexible bellows.

### Claim 11

A device as claimed in any preceding claim, comprising one or more additional sealing skirts attached to said housing.

### Claim 12 (independent)

A vacuum gripper device substantially as hereinbefore described with reference to the accompanying drawings.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGHAND TOOLS; PORTABLE POWER-DRIVEN TOOLS; MANIPULATORSMANIPULATORS; CHAMBERS PROVIDED WITH MANIPULATION DEVICESGripping heads and other end effectorsGripping heads and other end effectors with vacuum or magnetic holding meansGripping heads and other end effectors with vacuum or magnetic holding means with vacuumPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippersDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippers with air blasts producing partial vacuumPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansCircular shapePERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansSingle lifting units; Only one suction cup

Description

1 Vacuum GripDer Devices This invention relates to vacuum gripper devices

and especially to such devices for use with robotic devices. The invention has particular application to vacuum gripper feet for use in robotic devices of the kind which form the basis of U.K. Patent Application Nos. 8924500.5 and 9006255.5.

The vacuum gripper feet which form the basis of the present invention lend themselves to use in dirty or contaminated environments.

According to the present invention there is provided a vacuum gripper device comprising a body, an outwardly depending sealing skirt or rim extending from an underside of said body, a multi-ejector vacuum pump carried by said body, a compressed air inlet connected to an inlet port of said pump, an exhaust outlet connected to an exhaust port of said pump, an aperture in the underside of said body which connects with a vacuum port of said pump, and valve means for opening and closing said exhaust outlet whereby, in use of said device, a compressed air supply is permanently connected to said compressed air inlet, said valve means being normally closed to close said exhaust outlet so that compressed air is caused to be emitted from said aperture in the underside of said body via the vacuum port of said pump, said valve means being opened when said gripper device is to be attached to an adjacent surface, whereby a vacuum is formed by said pump in said vacuum port and on the underside of said body, which causes said body to be attached to said surface.

In carrying out the invention it may be arranged that said body comprises a two-part, hollow, discshaped housing in which said vacuum pump is disposed, said housing conveniently comprising an inverted 2.

shallow cup-shaped member in- which said pump is disposed, and a discshaped member which closes said cup-shaped member and which forms the underside of said housing.

It may be further arranged that said cup-shaped member is provided with an air distribution manifold which includes said compressed air inlet and said exhaust outlet, and includes a vacuum connecting pipe which couples the vacuum port of said pump with the interior of said housing, said aperture being provided in said disc- shaped member for connecting the interior of said housing to the underside of said housing.

Advantageously said valve means comprises a pneumatically operated valve, and an air filter may be provided disposed in the aperture in the underside of said housing.

Conveniently said sealing skirt or rim is clamped between the two parts of said housing, alternatively said sealing skirt may be attached to said disc-shaped member, in which case, said disc-shaped member may be adjustably mounted on said cup-shaped member, and said disc-shaped member may be coupled to said cup-shaped member by a flexible bellows.

One or more additional sealing skirts may also be provided attached to said housing.

Some exemplary embodiments of the invention will now be described reference being made to the accompanying drawings, in which:

Figure 1, is a plan view of a vacuum gripper foot in accordance with the present invention; Figure 2, is a cross-sectional side view of the vacuum gripper foot of Figure 1 on the lines 2-2 thereof; Figure 3, is a cross-sectional side view of the 1 3.

vacuum gripper foot of Figure 1 on the lines 3-3 thereof; and Figure 41 is a cross-sectional side view corresponding to that of Figure 3, of a modified form of the vacuum gripper foot of Figures 1 to 3.

The vacuum gripper foot depicted in Figures 1 to 3 of the drawings comprises a two part hollow disc-shaped housing 1 which consists of a cap 2 and a closure plate 3. The closure plate 3 is provided with a circumferential seal 4 which is received in a recess of the rim of the cap 2 and is secured and sealed thereto. The closure plate 3 is also provided with an outwardly projecting sealing rim 5, typically of a resilient rubber or synthetic rubber material, by means of which the vacuum gripper foot makes contact with the surface (not shown) to which it is to be secured.

Within the two-part housing 1, and sandwiched between the cap 2 and closure plate 3 thereof, is disposed a compressed air operated vacuum ejector pump 6 of known form. The vacuum ejector pump 6 may take the form of a multi-ejector vacuum pump as supplied by PIAB of Brentford, Middlesex, England and as described in their GB Patent No. 1484880 and European Patent Application No. 89850188.7.

Attached to the top of the cap 2 is an air distribution manifold 7 having a central mounting boss 8. The manifold 7 is provided with a compressed air inlet 9 which connects with an input port 10 of the vacuum pump 6 and an exhaust outlet 11 which connects with an exhaust port 12 of the vacuum pump 6. When compressed air is applied to the inlet 9 and thence to the input port 10 of the vacuum pump 6, it is fed through the pump 6 and out via the exhaust port 12 thereof to the exhaust outlet 11, and in doing so causes a vacuum to be developed in intermediate vacuum port 13 of the vacuum pump.6 in-well known manner. The vacuum port 13 of the vacuum pump 6 is connected to a transverse connecting pipe 14 in the manifold 7 which is coupled to two diametrically opposite holes 15 (Figure 2) in the top of the cap 2, so that the vacuum induced in the vacuum port 13 of the vacuum pump 6 causes a vacuum to be induced in the housing 1, between the cap 2 and the closure plate 3. The closure plate 3 is also provided with four holes 16 in it each of which is provided with an air filter 17 and by means of which the vacuum induced in the housing 1 is imparted to the underside 18 of the closure plate 3. If, then, the vacuum gripper foot is in contact with or closely adjacent a surface, such as a wall or floor, it will be caused to be sucked towards the surface so that the sealing rim 5 thereof is in contact with the surface and the foot is held in position on the surface.

In order to release the vacuum gripper foot from the surface a pneumatically operated poppet valve 19 is provided mounted in the exhaust outlet 11 of the manifold 7, it being arranged that, when operated, the poppet valve 19 closes the exhaust port 12 of the vacuum pump 6, thereby preventing the flow of compressed air through the pump 6, and terminating the vacuum which is induced in the vacuum port 13 of the vacuum pump 6. Moreover, when the exhaust port 12 of the vacuum pump 6 is closed by the poppet valve 19, compressed air is caused to be emitted from the vacuum port 13 of the vacuum pump 6, the compressed air flow being transmitted via the connecting pipe 14 in the manifold 7 into the housing 1 and out through the holes 16 in the closure plate 3, the outward flow of air through the holes 16 causing any contaminants which may have collected in the filters 17 located in the holes 16 to be blown clear.

p 5.

The outflow of air through the holes 16 also aids in the correct positioning of the gripper foot on a surface. Typically the gripper foot may be mounted on a universal joint and may approach the surface in a canted manner. The outflow of air through the holes 16 in the closure plate 17 effectively provides a cushion of air which helps to support the foot clear of the surface and allows it to slide relatively easily relative to it so that it can correctly position itself. The outflow of air also causes any loose contaminants e.g. dust on the surface, to be blown clear before the foot is positioned on the surface. When the foot is correctly positioned the pneumatically operated poppet valve.19 may be operated to open the exhaust port 12 allowing air flow through the pump 6 to cause a vacuum to be generated in the vacuum port 13 of the pump 6, which is transmitted to the inside of the housing 1 and to the underside 18 of closure plate 3, thereby to cause the foot to adhere to the surface.

One minor disadvantage of the vacuum gripper foot described with reference to Figures 1 to 3 of the drawings is that the foot needs to be in relatively close proximity to a surface in order that the induced suction can operate to cause the foot to adhere to the surface. This is not always the case when, for example, the gripper foot is mounted on the body of a climbing robot which is endeavouring to climb up an overhanging surface.

In Figure 4 of the drawings there is depicted a modification of the vacuum gripper foot of Figures 1 to 3 which at least partially alleviates this problem. The vacuum gripper foot shown in Figure 4, which 6.

corresponds to that depicted in Figure 3, comprises a pair of spring guides 20 by means of which the closure plate 3 is mounted on the cap 2 of the housing 1, and a circumferential flexible bellows 21 connected between the rim of the cap 2 and the closure plate 3. In its unoperated condition, the closure plate 3 wpuld assume its fully extended position as shown in Figure 4, and when compressed air is applied to it, the vacuum which is induced in the housing 1 would cause the closure plate 3 to be drawn towards the cap 2, against the action of the spring guides 20, thereby affording the gripper foot of Figure 4 a greater "reach" than is possible with the gripper foot of Figures 1 to 3.

The vacuum gripper foot of Figure 4 is also provided with an outwardly disposed flexible skirt 22, which may comprise two or more thin layers, disposed around the periphery of the closure plate 3, and which enables the gripper foot to attach itself to uneven surfaces, such as pointed brickwork, the skirt 22 being caused to be dragged into any gaps in the surface to enable the gripper foot to obtain an initial grip on the surface.

It will be appreciated that the vacuum gripper feet which have been described are exemplary examples only and may be modified in accordance with particular requirements. For example, although in the embodiments described the closure plate 3 is provided with four holes 16, the number of holes is not critical and in some embodiments fewer holes, e.g. two, may be used.

Also, although in the gripper foot of Figure 4 the skirt 22 is provided on the closure plate 3, it could equally well be provided on the rim of the cap 2, and could equally well be clamped between the rim of the cap 2 and the closure plate 3 of the gripper foot of Figures 1 to 3.

1 7.

## Classifications

- B25J15/0616
- B25J15/06
- B65G47/91
- B65G47/911
- B66C1/02
- B66C1/0212
- B66C1/0293

## Cited patent documents

- [GB-2032830-A](https://patents.google.com/patent/GB2032830A/en) — SEA
- [GB-2066900-A](https://patents.google.com/patent/GB2066900A/en) — SEA
- [US-4453755-A](https://patents.google.com/patent/US4453755A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
