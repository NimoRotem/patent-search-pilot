# 33. Bernoulli and vacuum combined gripper

- **Archive rank:** 33 of 50
- **Publication:** [EP-1091389-A2](https://patents.google.com/patent/EP1091389A2/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/007924990/publication/EP1091389A2?q=pn%3DEP1091389A2)
- **Publication date:** 2001-04-11
- **Filing date:** 2000-10-06
- **Earliest priority:** 1999-10-08
- **Family:** 7924990
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** INFINEON TECHNOLOGIES AG

## Abstract

The apparatus has a nozzle plate (1) which produces a hydrodynamic vacuum between the nozzle plate and a semiconductor wafer using nozzles (5). At least one suction hole (6) additionally sucks the semiconductor wafer to the nozzle plate. The suction hole is provided in the middle of the nozzle plate. Additional suction holes may be provided around the edge of the nozzle plate. The nozzle plate has a height of 2 to 3 mm.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/EP-1091389-A2/000.png)

![Sketch 1 for EP-1091389-A2](https://nimo.iptorch.com/refdrawing/EP-1091389-A2/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/EP-1091389-A2/001.png)

![Sketch 2 for EP-1091389-A2](https://nimo.iptorch.com/refdrawing/EP-1091389-A2/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/EP-1091389-A2/002.png)

![Sketch 3 for EP-1091389-A2](https://nimo.iptorch.com/refdrawing/EP-1091389-A2/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/EP-1091389-A2/003.png)

![Sketch 4 for EP-1091389-A2](https://nimo.iptorch.com/refdrawing/EP-1091389-A2/003.png)

[Sketch 5](https://patentimages.storage.googleapis.com/9f/33/58/d3f06ef9635306/00270001.png)

![Sketch 5 for EP-1091389-A2](https://patentimages.storage.googleapis.com/9f/33/58/d3f06ef9635306/00270001.png)

[Sketch 6](https://patentimages.storage.googleapis.com/99/7d/cf/e915407377a11e/00280001.png)

![Sketch 6 for EP-1091389-A2](https://patentimages.storage.googleapis.com/99/7d/cf/e915407377a11e/00280001.png)

[Sketch 7](https://patentimages.storage.googleapis.com/e4/bc/f3/e4abc3632de016/00290001.png)

![Sketch 7 for EP-1091389-A2](https://patentimages.storage.googleapis.com/e4/bc/f3/e4abc3632de016/00290001.png)

[Sketch 8](https://patentimages.storage.googleapis.com/05/72/0a/9f25517cd3e9e5/00300001.png)

![Sketch 8 for EP-1091389-A2](https://patentimages.storage.googleapis.com/05/72/0a/9f25517cd3e9e5/00300001.png)

## Claims

### Claim 1 (independent)

Greifer zum Handhaben dünner, scheibenförmiger Gegenstände, insbesondere Wafer der Halbleitertechnik, gekennzeichnet durch wenigstens eine Ausströmöffnung (5, 54, 57) für Druckgas, durch das nach dem Bernoulli-Prinzip zwischen dem Gegenstand und dem Greifer eine den Gegenstand zum Greifer hin ziehende Kraft erzeugt wird und durch wenigstens einen Vakuumkopf (3, 60), der mit Unterdruck beaufschlagt ist.Grippers for handling thin, disk-shaped objects, in particular wafers from semiconductor technology, marked by at least one outflow opening (5, 54, 57) for compressed gas, by means of which a force pulling the object towards the gripper is generated between the object and the gripper according to the Bernoulli principle and by at least one vacuum head (3, 60) which is under vacuum is acted upon.

### Claim 2

Greifer nach Anspruch 1, dadurch gekennzeichnet, dass die wenigstens eine Ausströmöffnung (5, 54, 57) für Druckgas radial innerhalb der Vakuumköpfe (3, 60) angeordnet ist.Gripper according to claim 1, characterized in that the at least one outflow opening (5, 54, 57) for compressed gas is arranged radially inside the vacuum heads (3, 60).

### Claim 3

Greifer nach Anspruch 1 oder 2, dadurch gekennzeichnet, dass die wenigstens eine Ausströmöffnung (5) für Druckgas im Bereich eines nach innen versetzten Randes (4) einer Deckplatte (2) des Greifers vorgesehen ist.Gripper according to claim 1 or 2, characterized in that the at least one outflow opening (5) for compressed gas is provided in the region of an inwardly offset edge (4) of a cover plate (2) of the gripper.

### Claim 4

Greifer nach einem der Ansprüche 1 bis 3, dadurch gekennzeichnet, dass die Vakuumköpfe (3, 60) im Bereich des Außenrandes des Greifers angeordnet sind.Gripper according to one of claims 1 to 3, characterized in that the vacuum heads (3, 60) are arranged in the region of the outer edge of the gripper.

### Claim 5

Greifer nach einem der Ansprüche 1 bis 4, dadurch gekennzeichnet, dass die Vakuumköpfe (3, 60) senkrecht zu der dem Gegenstand zugekehrten Fläche des Greifers beweglich sind.Gripper according to one of claims 1 to 4, characterized in that the vacuum heads (3, 60) are movable perpendicular to the surface of the gripper facing the object.

### Claim 6

Greifer nach Anspruch 5, dadurch gekennzeichnet, dass die Vakuumköpfe (3) in elastisch verformbaren Halteteilen (6) befestigt sind. Gripper according to claim 5, characterized in that the vacuum heads (3) are fastened in elastically deformable holding parts (6).

### Claim 7

Greifer nach Anspruch 6, dadurch gekennzeichnet, dass die Halteteile (6) für die Vakuumköpfe (3) zwischen einer Basisplatte (1) und einer Deckplatte (2) des Greifers angeordnet sind.Gripper according to claim 6, characterized in that the holding parts (6) for the vacuum heads (3) are arranged between a base plate (1) and a cover plate (2) of the gripper.

### Claim 8

Greifer nach Anspruch 7, dadurch gekennzeichnet, dass in der Basisplatte (1) und in der Deckplatte (2) konzentrische Öffnungen (17, 8) vorgesehen sind, innerhalb welcher die Vakuumköpfe (3) angeordnet sind.Gripper according to claim 7, characterized in that Concentric openings (17, 8) are provided in the base plate (1) and in the cover plate (2), within which the vacuum heads (3) are arranged.

### Claim 9

Greifer nach einem der Ansprüche 6 bis 8, dadurch gekennzeichnet, dass die Vakuumköpfe (3) in einem Haltering (9) der Halteteile (6) eingesetzt sind, der über Speichen (10) mit dem Halteteil (6) verbunden ist.Gripper according to one of claims 6 to 8, characterized in that the vacuum heads (3) are inserted in a holding ring (9) of the holding parts (6), which is connected to the holding part (6) via spokes (10).

### Claim 10

Greifer nach einem der Ansprüche 1 bis 9, dadurch gekennzeichnet, dass zwischen der Basisplatte (1) und der Deckplatte (2) ein Bauteil (20) als Druckgas-/Vakuumzuführung angeordnet ist.Gripper according to one of claims 1 to 9, characterized in that between the base plate (1) and the cover plate (2) a component (20) is arranged as a compressed gas / vacuum supply.

### Claim 11

Greifer nach Anspruch 10, dadurch gekennzeichnet, dass an einem annähernd scheibenförmigen Teil (24) des Bauteils (20) für die Druckgas-/Vakuumzuführung Kanäle (11) in den Halteteilen (6), durch welche die Vakuumköpfe (3) mit Unterdruck beaufschlagt werden, angeschlossen sind.Gripper according to claim 10, characterized in that Channels (11) in the holding parts (6) through which the vacuum heads (3) are subjected to negative pressure are connected to an approximately disk-shaped part (24) of the component (20) for the compressed gas / vacuum supply.

### Claim 12

Greifer nach einem der Ansprüche 1 bis 11, dadurch gekennzeichnet, dass die Vakuumköpfe (3) an ihrer dem scheibenförmigen Gegenstand zugekehrten Fläche ein tellerartige Ausformung (13) mit nach oben abstehenden Vorsprüngen (14, 15) ausgebildet sind. Gripper according to one of claims 1 to 11, characterized in that the vacuum heads (3) have a plate-like shape (13) with projections (14, 15) projecting upwards on their surface facing the disk-shaped object.

### Claim 13

Greifer nach Anspruch 12, dadurch gekennzeichnet, dass am Teller (13) eine ringförmige Rippe (14) vorgesehen ist.Gripper according to claim 12, characterized in that an annular rib (14) is provided on the plate (13).

### Claim 14

Greifer nach Anspruch 12 oder 13, dadurch gekennzeichnet, dass an der Oberseite des Tellers (13) im Kreis herum angeordnete Vorsprünge (15) vorgesehen sind.Gripper according to claim 12 or 13, characterized in that On the top of the plate (13) there are projections (15) arranged in a circle.

### Claim 15

Greifer nach Anspruch 14, dadurch gekennzeichnet, dass die Vorsprünge (15) segmentförmig sind.Gripper according to claim 14, characterized in that the projections (15) are segment-shaped.

### Claim 16

Greifer nach einem der Ansprüche 11 bis 15, dadurch gekennzeichnet, dass der Bauteil (20) zur Druckgas-/Vakuumzuführung zwischen Basisplatte (1) und Deckplatte (2) angeordnet ist.Gripper according to one of claims 11 to 15, characterized in that the component (20) for supplying compressed gas / vacuum is arranged between the base plate (1) and cover plate (2).

### Claim 17

Greifer nach einem der Ansprüche 11 bis 16, dadurch gekennzeichnet, dass an der der Deckplatte (2) zugekehrten Seite des scheibenförmigen Teils (24) an der Deckplatte (2) von unten her anliegende Rippen (25) vorgesehen sind, wobei zwischen benachbarten Rippen Freiräume (26) vorgesehen sind, die zusammen mit der Deckplatte (2) die düsenartige Ausströmöffnung (5) für Druckgas bilden.Gripper according to one of claims 11 to 16, characterized in that On the side of the disk-shaped part (24) facing the cover plate (2) on the cover plate (2), ribs (25) from below are provided, with free spaces (26) being provided between adjacent ribs, which together with the cover plate (2 ) form the nozzle-like outflow opening (5) for compressed gas.

### Claim 18

Greifer nach einem der Ansprüche 11 bis 17, dadurch gekennzeichnet, dass an der der Basisplatte (1) zugekehrten Seite des scheibenförmigen Teils (24) zwischen zum Rand hin offenen Ausschnitten (29), in welche die Halteteile (6) eingreifen, nach unten vorspringende Rippen (28) vorgesehen sind, die an der Basisplatte (1) anliegen. Gripper according to one of claims 11 to 17, characterized in that On the side of the disk-shaped part (24) facing the base plate (24) between cut-outs (29) which are open towards the edge and into which the holding parts (6) engage, ribs (28) projecting downwards are provided which are on the base plate (1 ) issue.

### Claim 19

Greifer nach einem der Ansprüche 11 bis 18, dadurch gekennzeichnet, dass an der der Deckplatte (2) zugekehrten Seite des scheibenförmigen Teils (24) eine gegebenenfalls gestufte Ringrippe (27) vorgesehen ist, die im Bereich eines mittigen Loches in der Deckplatte (2) an dieser anliegt.Gripper according to one of claims 11 to 18, characterized in that On the side of the disk-shaped part (24) facing the cover plate (2), an optionally stepped ring rib (27) is provided, which rests against the cover plate (2) in the region of a central hole.

### Claim 20

Greifer nach einem der Ansprüche 11 bis 19, dadurch gekennzeichnet, dass an der der Basisplatte (1) zugekehrten Seite des scheibenförmigen Teils (24) eine Ringrippe vorgesehen ist, die dichtend im Bereich einer mittigen Öffnung in der Basisplatte (1) an dieser anliegt.Gripper according to one of claims 11 to 19, characterized in that An annular rib is provided on the side of the disk-shaped part (24) facing the base plate (1), which rests sealingly in the region of a central opening in the base plate (1).

### Claim 21

Greifer nach einem der Ansprüche 7 bis 20, dadurch gekennzeichnet, dass in der Deckplatte (2) den Halteteilen (6) und der Basisplatte (1) in deren radial außen liegenden Bereichen Löcher (31) für die genannten Bauteile zusammenhaltende Verbindungsmittel vorgesehen sind.Gripper according to one of claims 7 to 20, characterized in that holes (31) are provided in the cover plate (2), the holding parts (6) and the base plate (1) in their radially outer regions for connecting means holding the above-mentioned components together.

### Claim 22

Greifer nach einem der Ansprüche 1 bis 5, dadurch gekennzeichnet, dass die Vakuumköpfe (60) im nicht mit Unterdruck beaufschlagten Zustand über die dem zu haltenden Gegenstand zugekehrte Fläche des Greifers überstehen.Gripper according to one of claims 1 to 5, characterized in that the vacuum heads (60), when not under vacuum, project beyond the surface of the gripper facing the object to be held.

### Claim 23

Greifer nach Anspruch 22, dadurch gekennzeichnet, dass die Vakuumköpfe (60) durch Bewegen senkrecht zur Ebene des Greifers in eine Stellung verstellbar sind, in der ihre dem zu haltenden Gegenstand zugekehrten Endflächen mit der dem Gegenstand zugekehrten Fläche des Greifers fluchten.Gripper according to claim 22, characterized in that the vacuum heads (60) can be adjusted by moving perpendicular to the plane of the gripper into a position in which their end surfaces facing the object to be held are aligned with the surface of the gripper facing the object.

### Claim 24

Greifer nach Anspruch 22 oder 23, dadurch gekennzeichnet, dass ein zum Halten eines scheibenförmigen Gegenstandes dienender Greiferteil (50) des Greifers wenigstens aus einer Deckplatte (56), einer Zwischenplatte (61) und einer Basisplatte (65) besteht.Gripper according to claim 22 or 23, characterized in that A gripper part (50) of the gripper which serves to hold a disc-shaped object consists of at least one cover plate (56), an intermediate plate (61) and a base plate (65).

### Claim 25

Greifer nach Anspruch 24, dadurch gekennzeichnet, dass die Vakuumköpfe (60) in Aussparungen (58) in der Deckplatte (56) angeordnet sind.Gripper according to claim 24, characterized in that the vacuum heads (60) are arranged in recesses (58) in the cover plate (56).

### Claim 26

Greifer nach einem der Ansprüche 22 bis 26, dadurch gekennzeichnet, dass auf der dem zu haltenden Gegenstand zugekehrten Seite der Deckplatte (56) eine flexible Deckfolie (53) angeordnet ist.Gripper according to one of claims 22 to 26, characterized in that A flexible cover film (53) is arranged on the side of the cover plate (56) facing the object to be held.

### Claim 27

Greifer nach Anspruch 26, dadurch gekennzeichnet, dass die dem zu haltenden Gegenstand zugekehrten Enden der Vakuumköpfe (60) oberhalb der flexiblen Folie (53) angeordnet sind.Gripper according to claim 26, characterized in that the ends of the vacuum heads (60) facing the object to be held are arranged above the flexible film (53).

### Claim 28

Greifer nach Anspruch 26, dadurch gekennzeichnet, dass die dem zu haltenden Gegenstand zugekehrten Enden der Vakuumköpfe (60) unterhalb der flexiblen Folie (53) angeordnet sind.Gripper according to claim 26, characterized in that the ends of the vacuum heads (60) facing the object to be held are arranged below the flexible film (53).

### Claim 29

Greifer nach einem der Ansprüche 22 bis 29, dadurch gekennzeichnet, dass in einem den Greiferteil (50) mit einer Halterung (52) verbindenden Verbindungsteil (51) wenigstens ein Kanal (76) für das Zuführen von Druckgas und wenigstens ein Kanal (75) für das Anlegen von Unterdruck vorgesehen ist.Gripper according to one of claims 22 to 29, characterized in that in a connecting part (51) connecting the gripper part (50) with a holder (52), at least one channel (76) for supplying compressed gas and at least one channel (75) for applying negative pressure is provided.

### Claim 30

Greifer nach Anspruch 29, dadurch gekennzeichnet, dass der wenigstens eine Kanal (76) für das Zuführen von Druckgas durch einen Schlitz in einer Zwischenlage (71), die zwischen einer Abdeckplatte (70) und einer Grundplatte (72) des Verbindungsteils (51) angeordnet ist, gebildet ist, wobei die Abdeckplatte (70) und die Grundplatte (72) an der Zwischenlage (71) anliegen.Gripper according to claim 29, characterized in that the at least one channel (76) for supplying pressurized gas is formed by a slot in an intermediate layer (71), which is arranged between a cover plate (70) and a base plate (72) of the connecting part (51), the cover plate ( 70) and the base plate (72) lie against the intermediate layer (71).

### Claim 31

Greifer nach Anspruch 29, dadurch gekennzeichnet, dass der wenigstens eine Kanal (75) zum Anlegen von Unterdruck durch einen Langschlitz in einer Zwischenlage (71), die zwischen einer Abdeckplatte (70) und einer Grundplatte (72) des Verbindungsteils (51) angeordnet ist, wobei die Abdeckplatte (70) und die Grundplatte (72) an der Zwischenlage (71) anliegen, gebildet ist.Gripper according to claim 29, characterized in that the at least one channel (75) for applying negative pressure through an elongated slot in an intermediate layer (71) which is arranged between a cover plate (70) and a base plate (72) of the connecting part (51), the cover plate (70) and the Base plate (72) rest on the intermediate layer (71), is formed.

### Claim 32

Greifer nach einem der Ansprüche 24 bis 31, dadurch gekennzeichnet, dass in der Zwischenplatte (61) wenigstens eine Aussparung (62) vorgesehen ist, die über wenigstens ein Loch (73) in der Deckplatte (70) des Verbindungsteils (51) mit dem vom Schlitz (75) gebildeten Kanal im Verbindungsteil (51) kommuniziert.Gripper according to one of claims 24 to 31, characterized in that At least one recess (62) is provided in the intermediate plate (61) and communicates via at least one hole (73) in the cover plate (70) of the connecting part (51) with the channel in the connecting part (51) formed by the slot (75).

### Claim 33

Greifer nach einem der Ansprüche 24 bis 32, dadurch gekennzeichnet, dass in der Zwischenplatte (61) wenigstens eine Aussparung (63) vorgesehen ist, die über wenigstens ein Loch (74) in der Deckplatte (70) des Verbindungsteils (51) mit dem vom Schlitz (76) gebildeten Kanal für Druckgas in Verbindung steht.Gripper according to one of claims 24 to 32, characterized in that At least one recess (63) is provided in the intermediate plate (61) and communicates via at least one hole (74) in the cover plate (70) of the connecting part (51) with the channel for compressed gas formed by the slot (76).

### Claim 34

Greifer nach einem der Ansprüche 24 bis 33, dadurch gekennzeichnet, dass in der Deckplatte (56) wenigstens eine Düse (57) für den Austritt von Druckgas vorgesehen sit.Gripper according to one of claims 24 to 33, characterized in that At least one nozzle (57) is provided in the cover plate (56) for the discharge of compressed gas.

### Claim 35

Greifer nach einem der Ansprüche 24 bis 34, dadurch gekennzeichnet, dass mehrere Bohrungen (57) als Düsen für den Austritt von Druckgas vorgesehen sind.Gripper according to one of claims 24 to 34, characterized in that several bores (57) are provided as nozzles for the discharge of compressed gas.

### Claim 36

Greifer nach Anspruch 34 oder 35, dadurch gekennzeichnet, dass die Bohrungen (57) für Druckgas mit einer senkrecht zum Greiferteil (50) stehenden Achse spitze Winkel einschließen.Gripper according to claim 34 or 35, characterized in that the holes (57) for compressed gas form an acute angle with an axis perpendicular to the gripper part (50).

### Claim 37

Greifer nach Anspruch 35 oder 36, dadurch gekennzeichnet, dass in der Deckfolie (53) Löcher (54) vorgesehen sind, die mit den oberen Enden der Bohrungen (57) fluchten.Gripper according to claim 35 or 36, characterized in that holes (54) are provided in the cover film (53), which are aligned with the upper ends of the bores (57).

### Claim 38

Greifer nach einem der Ansprüche 26 bis 37, dadurch gekennzeichnet, dass in der Deckfolie (53) Löcher (55) vorgesehen sind, die mit Löchern in den Vakuumköpfen (60), über die Unterdruck wirksam wird, fluchten.Gripper according to one of claims 26 to 37, characterized in that Holes (55) are provided in the cover film (53), which are aligned with holes in the vacuum heads (60) via which the negative pressure is effective.

### Claim 39

Greifer nach einem der Ansprüche 22 bis 39, dadurch gekennzeichnet, dass den Vakuumköpfen (60) Federn (81) zugeordnet sind, welche diese in ihre über die dem zu haltenden Gegenstand zugekehrte Fläche des Greifers vorstehende Lage belasten.Gripper according to one of claims 22 to 39, characterized in that the vacuum heads (60) are assigned springs (81) which load them into their position projecting beyond the surface of the gripper facing the object to be held.

### Claim 40 (independent)

Greifer zum Handling von Halbleiterscheiben, die an einem ersten Ort aufzunehmen und ihre Lage zu verändern oder zu einem zweiten Ort zu transportieren sind, umfassend eine Düsenplatte (41), die einen hydrodynamischen Unterdruck zwischen Düsenplatte (41) und Halbleiterscheibe erzeugt und mit wenigstens einer Saugbohrung (46) zum zusätzlichen Ansaugen der Halbleiterscheibe zur Düsenplatte (41) zu versehen ist, dadurch gekennzeichnet, dass die Düsenplatte (41) eine Bauhöhe von etwa 2 bis 3 mm aufweist und der hydrodynamische Unterdruck und der Saugdruck getrennt steuerbar sind.Gripper for handling semiconductor wafers which are to be picked up at a first location and changed in their position or are to be transported to a second location, comprising a nozzle plate (41) which generates a hydrodynamic negative pressure between the nozzle plate (41) and the semiconductor wafer and with at least one suction hole (46) for the additional suction of the semiconductor wafer to the nozzle plate (41) is to be provided, characterized in that the nozzle plate (41) has a height of about 2 to 3 mm and the hydrodynamic vacuum and the suction pressure can be controlled separately.

### Claim 41

Greifer nach Anspruch 40, dadurch gekennzeichnet, dass die Saugbohrung (46) in der Mitte der Düsenplatte (41) vorgesehen ist.Gripper according to claim 40, characterized in that the suction hole (46) is provided in the middle of the nozzle plate (41).

### Claim 42

Greifer nach Anspruch 40 oder 41, dadurch gekennzeichnet, dass zusätzliche, im Randbereich der Düsenplatte (41) bzw. deren Trägerplatte (42) vorgesehene Saugbohrungen (47).Gripper according to claim 40 or 41, characterized in that Additional suction bores (47) provided in the edge region of the nozzle plate (41) or its support plate (42).

## Full description

ELECTRICITYSEMICONDUCTOR DEVICES; ELECTRIC SOLID-STATE DEVICES NOT OTHERWISE PROVIDED FORGENERIC PROCESSES OR APPARATUS FOR THE MANUFACTURE OR TREATMENT OF DEVICES COVERED BY CLASS H10Handling or holding of wafers, substrates or devices during manufacture or treatment thereofHandling or holding of wafers, substrates or devices during manufacture or treatment thereof for supporting or grippingHandling or holding of wafers, substrates or devices during manufacture or treatment thereof for supporting or gripping using vacuum or suction, e.g. Bernoulli chucks

Description

Translated from German

Die Erfindung betrifft einen Greifer, mit dem scheibenfÃ¶rmige

GegenstÃ¤nde, insbesondere Halbleiterscheiben bzw. Wafer, wie

sie in der Halbleitertechnik verwendet werden, gehandhabt werden

kÃ¶nnen.The invention relates to a gripper, with the disc-shaped

Objects, in particular semiconductor wafers or wafers, such as

they are used in semiconductor technology

can.

Das Handhaben von scheibenfÃ¶rmigen GegenstÃ¤nden bzw. Wafern

stellt, insbesondere wenn es sich um dÃ¼nne, verbogene Wafer

handelt, erhebliche Probleme dar.Handling disc-shaped objects or wafers

especially when it comes to thin, bent wafers

are serious problems.

Bekannte Greifer fÃ¼r Wafer basieren auf mechanischen Klemmvorrichtungen,

die am Rand des Wafers angreifen. Andere Greifer

halten den Wafer durch Anlegen von Unterdruck.Known grippers for wafers are based on mechanical clamping devices,

that attack on the edge of the wafer. Other grabs

hold the wafer by applying negative pressure.

Da heutzutage Wafer immer dÃ¼nner werden bei WafergrÃ¶Ãen bzw.

-durchmessern von 5, 6 und 8 Zoll eine Dicke bis zu 50 Âµm haben,

sind herkÃ¶mmliche Greifer nicht mehr ohne weiteres verwendbar.

DÃ¼nne Wafer brechen nicht nur leicht, sondern zeigen

auch Verbiegungen (bis zu 16 mm aus der Ebene des Wafers) und

damit auch starke Verspannungen. Um solche Wafer sicher handhaben

zu kÃ¶nnen, beispielsweise beim Be- und Entladen von Horden,

Quarzbooten und dergleichen, ist es erforderlich, den Wafer

auf dem Greifer eben zu stabilisieren.As wafers are getting thinner and thinner these days

-diameters of 5, 6 and 8 inches have a thickness up to 50 Âµm,

conventional grippers are no longer usable.

Thin wafers don't just break easily, they show

also bends (up to 16 mm from the plane of the wafer) and

with it also strong tension. To handle such wafers safely

to be able to, for example, when loading and unloading hordes,

Quartz boats and the like, it is required the wafer

to stabilize on the gripper.

Wafer sind bekanntlich also sehr dÃ¼nn und weisen bei einem

Durchmesser in der GrÃ¶Ãenordnung von dm Scheibendicken auf,

die in der GrÃ¶Ãenordnung von einigen 10 bis einigen 100 Âµm

liegen. Solche Halbleiterscheiben werden bisher zumeist manuell

bzw. mit einem Handlingsystem von einem ersten Prozessierungsort

zu einem zweiten Prozessierungsort gebracht. Beispielsweise

werden nach einem DÃ¼nnschleifen oft verbogene

Halbleiterscheiben erhalten, die sowohl konkave als auch konvexe

KrÃ¼mmungen enthalten kÃ¶nnen. Diese Halbleiterscheiben

kÃ¶nnen durch das Handlingsystem nicht mehr problemfrei gehandhabt

werden. Daher werden sie oft mithilfe einer Pinzette aus

einem entsprechenden BehÃ¤lter entnommen und zur weiteren Prozessierung

beispielsweise in ein Quarzboot gebracht. Der Einsatz

einer Pinzette ist aber nicht unproblematisch, da dieser

zu teilweisen BeschÃ¤digungen wie der Entstehung von Haarrissen

und damit zu einem Ausfall von Chips in dem entsprechenden Bereich

der Halbleiterscheibe fÃ¼hren kann.Wafers are known to be very thin and have one

Diameter on the order of the disc thicknesses,

those in the order of a few 10 to a few 100 Âµm

lie. Such semiconductor wafers have so far mostly been manual

or with a handling system from a first processing location

brought to a second processing location. For example

are often bent after thin grinding

Semiconductor wafers obtained that are both concave and convex

May contain curvatures. These wafers

can no longer be handled without problems by the handling system

become. Therefore, they are often removed using tweezers

removed from an appropriate container and for further processing

for example brought into a quartz boat. The stake

A pair of tweezers is not without problems, however, since this

partial damage such as hairline cracks

and thus a failure of chips in the corresponding area

the semiconductor wafer can lead.

Der Erfindung liegt die Aufgabe zu Grunde, einen Greifer fÃ¼r

das Handhaben von scheibenfÃ¶rmigen GegenstÃ¤nden, insbesondere

Wafern, zur VerfÃ¼gung zu stellen, mit dem auch Wafer mit grÃ¶Ãerem

Durchmesser, selbst wenn diese dÃ¼nn und/oder gebogen

sind, sicher erfasst, gehalten und gehandhabt werden kÃ¶nnen.The invention is based on the object of a gripper

handling disc-shaped objects, in particular

Wafers to provide with the wafers with larger

Diameter, even if it is thin and / or curved

are securely recorded, held and handled.

Diese Aufgabe wird erfindungsgemÃ¤Ã mit einem Greifer gelÃ¶st,

der die Merkmale des unabhÃ¤ngigen Anspruches 1 bzw. 40 aufweist.According to the invention, this object is achieved with a gripper,

which has the features of independent claim 1 or 40.

Bevorzugte und vorteilhafte Ausgestaltungen des erfindungsgemÃ¤Ãen

Greifers sind Gegenstand der UnteransprÃ¼che.Preferred and advantageous embodiments of the invention

Grippers are the subject of the subclaims.

Bei dem erfindungsgemÃ¤Ãen Greifer wird zum einen das an sich

bekannte Prinzip des Haltens eines Wafers durch Unterdruck,

der den Wafer an den Greifer saugt, angewendet.In the gripper according to the invention, on the one hand, this is per se

known principle of holding a wafer by negative pressure,

which sucks the wafer onto the gripper.

Ein Nachteil des Haltens von Wafern an einen Greifer nur durch

Unterdruck besteht darin, dass allein durch Anlegen von Unterdruck

stark verbogene Wafer nicht planarisiert und an den

Greifer angelegt werden kÃ¶nnen. Ein weiteres Problem besteht

darin, dass bei groÃ dimensionierten Ãffnungen im Greifer, die

mit Unterdruck beaufschlagt werden, bei sehr dÃ¼nnen Wafern in

den Wafern StrukturschÃ¤den entstehen kÃ¶nnen.One disadvantage of holding wafers to a gripper only

Negative pressure is that by simply applying negative pressure

strongly bent wafers are not planarized and attached to the

Grippers can be created. Another problem exists

in that with large openings in the gripper, the

can be pressurized with very thin wafers in

Structural damage can occur to the wafers.

Durch die bei dem erfindungsgemÃ¤Ãen Greifer zusÃ¤tzlich zu dem

Anlegen von Unterdruck auf den Wafer einwirkende, auf Grund

des Bernoulli-Prinzips beim AusstrÃ¶men von Gas wie Luft oder

Stickstoff, aus (wenigstens) einer DÃ¼se im Greifer erzeugte

Kraft wird der Wafer zu der dem Wafer zugekehrten FlÃ¤che des

Greifers hin gezogen und planarisiert. Ein Vorteil des Bernoulli-Prinzips

ist es, das die durch dieses erzeugte Kraft

auch stark verbogene Wafer anzieht und eben macht (planarisiert).

Nachteilig ist hingegen, dass der Wafer auf der OberflÃ¤che

des Greifers schwimmt, sodass zusÃ¤tzliche Vorrichtungen

zum seitlichen Fixieren des Wafers nÃ¶tig sind, wenn ein Greifer

ausschlieÃlich nach dem Bernoulli-Prinzip arbeitet.By in addition to the in the gripper according to the invention

Applying vacuum to the wafer, on the ground

of the Bernoulli principle when gas or air flows out

Nitrogen generated from (at least) one nozzle in the gripper

The wafer becomes the surface of the wafer facing the wafer

Gripper pulled and planarized. An advantage of the Bernoulli principle

it is the force generated by this

also attracts strongly bent wafers and makes them flat (planarized).

The disadvantage, however, is that the wafer on the surface

of the gripper floats, so additional devices

to fix the wafer laterally when a gripper

works exclusively according to the Bernoulli principle.

Bei dem erfindungsgemÃ¤Ãen Greifer wird die durch das Bernoulli-Prinzip

erzeugte Kraft zum Planarisieren des Wafers und zum

Anlegen desselben an den Greifer angewendet und das Anlegen

von Unterdruck dazu benutzt, den Wafer zu stabilisieren und

auf dem Greifer zu halten. Somit wird bei dem erfindungsgemÃ¤Ãen

Greifer zum Erfassen eines Wafers das Bernoulli-Prinzip

und Unterdruck gleichzeitig aktiviert. Beim anschlieÃenden

Halten des Wafers am Greifer kann das AusstrÃ¶men von Gas und

damit das Halten nach dem Bernoulli-Prinzip abgebrochen werden,

und der Wafer wird dann lediglich durch Anlegen von Unterdruck

an die im Greifer vorgesehenen Vakuum- bzw. UnterdruckkÃ¶pfe

am Wafer gehalten.In the gripper according to the invention, this is based on the Bernoulli principle

generated force to planarize the wafer and to

Applying the same to the gripper applied and applying

of negative pressure used to stabilize the wafer and

to keep on the gripper. Thus, in the invention

Gripper for gripping a wafer using the Bernoulli principle

and vacuum activated at the same time. At the subsequent

Holding the wafer on the gripper can cause gas and gas to escape

so that the stopping is stopped according to the Bernoulli principle,

and the wafer is then only created by applying negative pressure

to the vacuum or vacuum heads provided in the gripper

held on the wafer.

Die erfindungsgemÃ¤Ãe Konstruktion des Greifers erlaubt es in

einer AusfÃ¼hrungsform diesen sehr flach auszubilden.The construction of the gripper according to the invention allows it in

an embodiment of this very flat.

Dabei kann in einer AusfÃ¼hrungsform die fÃ¼r das Bernoulli-Prinzip

notwendige StrÃ¶mung von Gas so tangential auf die

GreiferoberflÃ¤che umgeleitet und gefÃ¼hrt werden, dass die Haltekraft

durch das Anlegen von Unterdruck nicht beinflusst

wird.In one embodiment, this can be done for the Bernoulli principle

necessary flow of gas so tangential to that

Gripper surface redirected and guided that the holding force

not affected by the application of negative pressure

becomes.

In einer AusfÃ¼hrungsform des erfindungsgemÃ¤Ãen Greifers sind

quer zur Ebene des Greifers beweglich angeordnete VakuumkÃ¶pfe

vorgesehen, sodass auch stark verbogene bzw. verspannte Wafer

durch Unterdruck gehalten werden kÃ¶nnen. Die Erfindung erlaubt

es, die VakuumkÃ¶pfe beispielsweise durch nur kleine KanÃ¤le an

der OberflÃ¤che derselben so anzulegen, dass auch bei sehr dÃ¼nnen

Wafern auf Grund des Unterdruckes keine StrukturschÃ¤den

entstehen.In one embodiment of the gripper according to the invention

Vacuum heads movably arranged transversely to the level of the gripper

provided so that even strongly bent or strained wafers

can be held by negative pressure. The invention allows

the vacuum heads, for example, through only small channels

the surface of the same so that even very thin

Wafers no structural damage due to the negative pressure

arise.

Bevorzugt ist es, wenn bei dem erfindungsgemÃ¤Ãen Greifer die

Leitungen, mit welchen die VakuumkÃ¶pfe mit Unterdruck und die

DÃ¼sen fÃ¼r den Austritt von Gas zum Halten nach dem Bernoulli-Prinzip

mit unter Druck stehendem Gas beaufschlagt werden, im

Greifer gefÃ¼hrte Leitungen sind.It is preferred if the gripper according to the invention

Lines with which the vacuum heads with negative pressure and the

Nozzles for the exit of gas for holding according to the Bernoulli principle

be pressurized with gas, in

Grippers are guided lines.

In der Praxis kann bei der Erfindung vorgesehen sein, dass

durch einen Kanal im Greifer und in der Haltestange fÃ¼r diesen

Gas, wie Luft oder Stickstoff, fÃ¼r das Halten nach dem Bernoulli-Prinzip

mit mehrfachen AtmosphÃ¤rendruck auf der GreiferoberflÃ¤che

durch wenigstens eine DÃ¼se austritt. Bevorzugt

ist es, wenn das Gas in einem Kanal, der mehrere kreissegmentfÃ¶rmige

Ãffnungen hat, gefÃ¼hrt wird, wobei die AusstrÃ¶mÃ¶ffnungen

tangential oder im spitzen Winkel zur GreiferoberflÃ¤che

ausgebildet sein kÃ¶nnen.In practice, the invention can provide that

through a channel in the gripper and in the handrail for this

Gas, such as air or nitrogen, for holding according to the Bernoulli principle

with multiple atmospheric pressure on the gripper surface

exits through at least one nozzle. Prefers

it is when the gas is in a channel that is several circular segment-shaped

Has openings, is guided, the outflow openings

tangential or at an acute angle to the gripper surface

can be trained.

Die bei dem erfindungsgemÃ¤Ãen Greifer in einer AusfÃ¼hrungsform

vorgesehenen VakuumkÃ¶pfe selbst sind bevorzugt aus hartem

Werkstoff gefertigt, sodass sichergestellt ist, dass kein Abrieb

auf dem Wafer erfolgt. Bevorzugt ist es, wenn die VakuumkÃ¶pfe

im Greifer quer zur Ebene des Greifers federelastisch

beweglich gelagert sind, was beispielsweise dadurch erreicht

werden kann, dass die Lagerung und die ZufÃ¼hrung von Unterdruck

zu den VakuumkÃ¶pfen aus flexiblem Werkstoff, beispielsweise

gummielastischem Werkstoff, angefertigt sind.The gripper according to the invention in one embodiment

provided vacuum heads themselves are preferably made of hard

Made of material so that there is no abrasion

done on the wafer. It is preferred if the vacuum heads

resilient in the gripper transversely to the level of the gripper

are movably mounted, which achieves this, for example

that can be the storage and the supply of negative pressure

to the vacuum heads made of flexible material, for example

rubber-elastic material are made.

Der erfindungsgemÃ¤Ãe Greifer nutzt sowohl das Bernoulli-Prinzip

zum Erzeugen einer den Wafer zum Greifer hin ziehenden

Kraft als auch ein Ansaugen durch wenigstens eine Saugbohrung

(Vakuumkopf), die sich in der dem Wafer zugekehrten FlÃ¤che des

Greifers befindet, aus, um den Wafer praktisch berÃ¼hrungsfrei

am Greifer haften zu lassen, sodass er sicher und zuverlÃ¤ssig

gehandhabt werden kann. ZerstÃ¶rungen oder BeschÃ¤digungen

(StrukturschÃ¤den) des Wafers sind nicht zu befÃ¼rchten, da er

von der ihm zugekehrten FlÃ¤che des Greifers durch eine dÃ¼nne

GasstrÃ¶mung getrennt ist. So kann ein Wafer zerstÃ¶rungs- und

beschÃ¤digungsfrei manuell oder auch automatisch transportiert

und gehandhabt werden.The gripper according to the invention uses both the Bernoulli principle

to generate a pulling the wafer towards the gripper

Force as well as suction through at least one suction hole

(Vacuum head), which are located in the surface of the wafer facing the wafer

The gripper is located to make the wafer practically non-contact

to stick to the gripper so that it is safe and reliable

can be handled. Destruction or damage

(Structural damage) of the wafer are not to be feared as it

from the face of the gripper facing him through a thin one

Gas flow is separated. A wafer can be destroyed and

transported without damage manually or automatically

and be handled.

Weiterhin erfolgt durch die auf Grund des Bernoulli-Prinzips

entstehende Kraft, welche den Wafer gegen den Greifer drÃ¼ckt,

ein Einebnen des Wafers, sodass dieser keine konkaven oder

konvexen KrÃ¼mmungen mehr aufweist, solange er mit dem erfindungsgemÃ¤Ãen

Greifer transportiert oder gehalten wird.Furthermore, due to the Bernoulli principle

resulting force that presses the wafer against the gripper,

leveling of the wafer so that it is not concave or

has more convex curvatures, as long as it with the invention

Gripper is transported or held.

Das Erzeugen einer Kraft auf Grund des Bernoulli-Prinzips

durch ein aus den DÃ¼sen strÃ¶mendes Gas einerseits und das Erzeugen

eines Saugdruckes durch Ansaugen von Luft durch den wenigstens

einen Vakuumkopf andererseits sind vorzugsweise getrennt

steuerbar. Es ist also mÃ¶glich, den erfindungsgemÃ¤Ãen

Greifer zeitweise nur Ã¼ber die durch das strÃ¶mende Druckgas

entstehende Kraft und zeitweise nur Ã¼ber den durch den Vakuumkopf

erzeugten Saugdruck zu betreiben. Dies schlieÃt freilich

einen gleichzeitigen Betrieb des Greifers mit Druckgas (Bernoulli-Kraft)

und mit Unterdruck (Ansaugen durch wenigstens

einen Vakuumkopf) nicht aus.Generating a force based on the Bernoulli principle

by a gas flowing out of the nozzles on the one hand and the generation

a suction pressure by sucking air through the at least

a vacuum head, on the other hand, are preferably separated

controllable. It is therefore possible to use the invention

Grippers temporarily only through the compressed gas flowing through it

generated force and at times only via the vacuum head

to operate generated suction pressure. This of course closes

simultaneous operation of the gripper with compressed gas (Bernoulli force)

and with negative pressure (suction by at least

a vacuum head).

Der erfindungsgemÃ¤Ãe Greifer nutzt also sowohl das Bernoulli-Prinzip

zur Erzeugung eines hydrodynamischen Unterdrucks zwischen

DÃ¼senplatte und Halbleiterscheibe als auch ein gleichzeitiges

Ansaugen durch eine Saugbohrung, die sich vorzugsweise

in der Mitte der DÃ¼senplatte befindet, aus, um die Halbleiterscheibe

praktisch berÃ¼hrungsfrei an der DÃ¼senplatte "haften"

zu lassen, sodass sie sicher und zuverlÃ¤ssig transportiert

und gehandhabt werden kann. ZerstÃ¶rungen oder BeschÃ¤digungen

der Halbleiterscheibe sind nicht zu befÃ¼rchten, da diese

von der DÃ¼senplatte durch eine dÃ¼nne LuftstrÃ¶mung getrennt

ist. Damit kann die Halbleiterscheibe zerstÃ¶rungs- und beschÃ¤digungsfrei

manuell oder auch automatisch transportiert und

gehandhabt werden.The gripper according to the invention thus uses both the Bernoulli principle

to create a hydrodynamic vacuum between

Nozzle plate and semiconductor wafer as well as a simultaneous one

Suction through a suction hole, which is preferred

located in the middle of the nozzle plate, out to the semiconductor wafer

"stick" to the nozzle plate practically without contact

so that it can be transported safely and reliably

and can be handled. Destruction or damage

the semiconductor wafer are not to be feared as this

separated from the nozzle plate by a thin air flow

is. This means that the semiconductor wafer can be destroyed and damaged

transported manually or automatically and

be handled.

Weiterhin erfolgt durch das Pressen der Halbleiterscheibe infolge

des hydrodynamischen Unterdrucks gegen die DÃ¼senplatte

eine Einebnung der Halbleiterscheibe, sodass diese keine konkaven

oder konvexen KrÃ¼mmungen mehr aufweist, solange sie mit

der erfindungsgemÃ¤Ãen Vorrichtung transportiert wird bzw. an

der DÃ¼senplatte angebracht ist.Furthermore, the semiconductor wafer is pressed as a result of

of the hydrodynamic negative pressure against the nozzle plate

a leveling of the semiconductor wafer so that it is not concave

or has more convex curvatures as long as they are with

the device according to the invention is transported or on

the nozzle plate is attached.

Die Erzeugung des hydrodynamischen Unterdrucks zwischen der

DÃ¼senplatte durch die aus den DÃ¼sen der DÃ¼senplatte strÃ¶mende

Luft einerseits und die Erzeugung des Saugdruckes durch Ansaugen

von Luft durch die Saugbohrung andererseits sind vorzugsweise

getrennt steuerbar. Es ist also mÃ¶glich, den erfindungsgemÃ¤Ãen

Greifer zeitweise nur Ã¼ber den durch die DÃ¼senplatte

gelieferten Unterdruck und zeitweise nur Ã¼ber den durch die

Saugbohrung erzeugten Saugdruck zu betrieben.The generation of the hydrodynamic vacuum between the

Nozzle plate through the one flowing out of the nozzles of the nozzle plate

Air on the one hand and the generation of suction pressure by suction

of air through the suction hole, on the other hand, are preferred

separately controllable. It is therefore possible to use the invention

Gripper temporarily only over the through the nozzle plate

supplied vacuum and at times only over the by the

Suction hole to operate generated suction pressure.

Der erfindungsgemÃ¤Ãe Greifer kann extrem dÃ¼nn mit einer BauhÃ¶he

von nur etwa 2 bis 3 mm ausgebildet werden. Damit ist es

mÃ¶glich, mit der DÃ¼senplatte zwischen zwei Ã¼bereinander in einer

Horde liegenden Halbleiterscheiben einzugreifen und eine

dieser Halbleiterscheiben aufzunehmen.The gripper according to the invention can be extremely thin with an overall height

of only about 2 to 3 mm. So that's it

possible with the nozzle plate between two one above the other

Horde lying semiconductor wafers to intervene and a

of these semiconductor wafers.

In einer Weiterbildung der Erfindung ist vorgesehen, dass auch

im Randbereich der DÃ¼senplatte zusÃ¤tzliche Saugbohrungen vorgesehen

sind. Greifer, die derartige zusÃ¤tzliche Saugbohrungen

im Randbereich der DÃ¼senplatte aufweisen, haben sich als besonders

vorteilhaft zum BestÃ¼cken von Quarzbooten mit Halbleiterscheiben

erwiesen.A further development of the invention provides that also

Additional suction holes are provided in the edge area of the nozzle plate

are. Grippers that have such additional suction holes

have in the edge region of the nozzle plate, have been found to be special

advantageous for equipping quartz boats with semiconductor wafers

proven.

Wesentlich an der vorliegenden Erfindung ist also die gemeinsame

Verwendung einerseits des nach Bernoulli erzeugten hydrodynamischen

Unterdrucks, der ein "Haften" zwischen Halbleiterscheibe

und DÃ¼senplatte bewirkt, und wenigstens einer Saugbohrung

andererseits, die, wenn sie in der Mitte der DÃ¼senplatte

angeordnet ist, eine Zentrierung der Halbleiterscheibe auf

diese Mitte gestattet.What is essential to the present invention is therefore the common one

Use on the one hand of the hydrodynamic generated according to Bernoulli

Negative pressure, which is a "sticking" between semiconductor wafer

and nozzle plate, and at least one suction hole

on the other hand, which when in the middle of the nozzle plate

is arranged on a centering of the semiconductor wafer

this center allowed.

Weitere Einzelheiten und Merkmale der Erfindung ergeben sich

aus der nachstehenden Beschreibung bevorzugter AusfÃ¼hrungsbeispiele

des erfindungsgemÃ¤Ãen Greifers anhand der Zeichnungen.

Es zeigen:

Fig. 1 in SchrÃ¤gansicht schematisiert einen Greifer mit

AustrittsÃ¶ffnungen fÃ¼r Druckgas und mit VakuumkÃ¶pfen, Fig. 2 den Greifer mit auseinandergezogen dargestellten Bestandteilen, Fig. 3 ein Einzelteil des Greifers mit einem Vakuumkopf

(lÃ¤ngs dessen Symmetrieebene halbiert), Fig. 4 den Bauteil des Greifers, Ã¼ber den Unterdruck und

Druckgas zugefÃ¼hrt wird, Fig. 5 den Bauteil aus Fig. 4 von unterhalb der Fig. 4 aus

gesehen, Fig. 6 eine abgeÃ¤nderte AusfÃ¼hrungsform eines Greifers gemÃ¤Ã

der Erfindung, Fig. 7 eine abgeÃ¤nderte AusfÃ¼hrungsform eines erfindungsgemÃ¤Ãen

Greifers, Fig. 8 die AusfÃ¼hrungsform des Greifers von Fig. 7 in auseinandergezogener

Darstellung, Fig. 9 einen quer zum Greifer beweglichen Vakuumkopf im

Schnitt, ohne Beaufschlagung mit Unterdruck, Fig. 10 den Vakuumkopf aus Fig. 9, mit Unterdruck beaufschlagt, Fig. 11 eine andere AusfÃ¼hrungsform eines Vakuumkopfes des

erfindungsgemÃ¤Ãen Greifers ohne Beaufschlagung mit

Unterdruck, Fig. 12 den Vakuumkopf aus Fig. 11, mit Unterdruck beaufschlagt, Fig. 13 eine schematische Darstellung eines weiteren AusfÃ¼hrungsbeispiels

der Erfindung mit einem Handling-Werkzeug

fÃ¼r dÃ¼nne Halbleiterscheiben ("DÃ¼nnwafer")

und Fig. 14 eine schematische Darstellung eines Greifers fÃ¼r

DÃ¼nnwafer. Further details and features of the invention result from the following description of preferred embodiments of the gripper according to the invention with reference to the drawings. Show it: Fig. 1 in an oblique view schematized a gripper with outlet openings for compressed gas and with vacuum heads, Fig. 2 the gripper with components shown pulled apart, Fig. 3 a single part of the gripper with a vacuum head (halved along its plane of symmetry), Fig. 4 the component of the gripper via which vacuum and compressed gas are fed, Fig. 5 4 seen from below of FIG. 4, Fig. 6 a modified embodiment of a gripper according to the invention, Fig. 7 a modified embodiment of a gripper according to the invention, Fig. 8 7 shows the embodiment of the gripper of FIG. 7 in an exploded view, Fig. 9 a vacuum head that can be moved across the gripper without any negative pressure, Fig. 10 the vacuum head of Fig. 9, applied with negative pressure, Fig. 11 another embodiment of a vacuum head of the gripper according to the invention without the application of negative pressure, Fig. 12 the vacuum head of Fig. 11, applied with negative pressure, Fig. 13 is a schematic representation of another embodiment of the invention with a handling tool for thin semiconductor wafers ("thin wafers") and Fig. 14 is a schematic representation of a gripper for thin wafers.

Ein in Fig. 1 beispielhaft gezeigter Greifer gemÃ¤Ã der Erfindung

besteht aus einer kreisrunden Basisplatte 1, einer im gezeigten

AusfÃ¼hrungsbeispiel etwa sternfÃ¶rmig ausgebildeten

Deckplatte 2 und im gezeigten AusfÃ¼hrungsbeispiel vier VakuumkÃ¶pfen

3, wobei zwischen der Basisplatte 1 und der Deckplatte

2 im Bereich ihrer radial -innerhalb des AuÃenumfanges der Basisplatte

1 liegenden Randbereiche 4 AusstrÃ¶mÃ¶ffnungen 5 fÃ¼r

Druckgas zum Erzeugen von KrÃ¤ften auf Grund des Bernoulli-Prinzips

vorgesehen sind.A gripper according to the invention shown by way of example in FIG. 1

consists of a circular base plate 1, one shown in

Embodiment approximately star-shaped

Cover plate 2 and four vacuum heads in the embodiment shown

3, being between the base plate 1 and the cover plate

2 in the area of its radial inside the outer circumference of the base plate

1 lying edge areas 4 outflow openings 5 for

Compressed gas for generating forces based on the Bernoulli principle

are provided.

Die VakuumkÃ¶pfe 3 sind in Halteteilen (vgl. Fig. 2) gehalten

und von oben, also von der dem zu haltenden Wafer zugekehrten

Seite des Greifers her durch in radial abstehenden Armen 7 der

Deckplatte 2 vorgesehene, beispielsweise kreisrunde Ãffnungen

8 zugÃ¤nglich. The vacuum heads 3 are held in holding parts (see FIG. 2)

and from above, i.e. from the wafer to be held

Side of the gripper forth by in radially projecting arms 7

Cover plate 2 provided, for example circular openings

8 accessible.

Die Halteteile 6 sind aus gummielastischem Werkstoff gefertigt,

wogegen die VakuumkÃ¶pfe 3 selbst aus abriebfestem Werkstoff

sind.The holding parts 6 are made of rubber-elastic material,

whereas the vacuum heads 3 themselves are made of an abrasion-resistant material

are.

Wie insbesondere Fig. 3 zeigt, sind die VakuumkÃ¶pfe 3 in den

Halteteilen 6 in einen Haltering 9 eingesetzt, wobei der Haltering

9 mit dem Ã¼brigen Teil des Halteteils 6 durch Speichen

10 verbunden ist. In einer mittigen Ãffnung des Halterings 9

mÃ¼ndet ein Kanal 11, der an eine Unterdruckquelle angeschlossen

ist, sodass die VakuumkÃ¶pfe 3 Ã¼ber ihre zentrale Ãffnung

12 mit Unterdruck beaufschlagt werden kÃ¶nnen.3, the vacuum heads 3 are in the

Holding parts 6 inserted into a retaining ring 9, the retaining ring

9 with the remaining part of the holding part 6 by spokes

10 is connected. In a central opening of the retaining ring 9

opens a channel 11, which is connected to a vacuum source

is so that the vacuum heads 3 through their central opening

12 can be subjected to negative pressure.

Ein tellerfÃ¶rmiger Oberteil 13 der VakuumkÃ¶pfe 3, das von oben

her auf dem Halteteil 6 aufliegt, besitzt einen Umfangsrand 14

und kreissegmentfÃ¶rmige VorsprÃ¼nge 15, die rings um die zentrale

Ãffnung 12 des Vakuumkopfes 3 angeordnet sind. Durch den

nach oben vorstehenden Rand 14 und die nach oben vorstehenden

VorsprÃ¼nge 15 des Vakuumkopfes 3 wird ein Wafer am Vakuumkopf

3 gut abgestÃ¼tzt, sodass auch in sehr dÃ¼nnen Wafern durch den

angelegten Unterdruck keine StrukturschÃ¤den entstehen kÃ¶nnen.A plate-shaped upper part 13 of the vacuum heads 3, from above

lies on the holding part 6, has a peripheral edge 14

and circular segment-shaped projections 15 which surround the central one

Opening 12 of the vacuum head 3 are arranged. By the

upwardly projecting edge 14 and those upwardly projecting

Projections 15 of the vacuum head 3 becomes a wafer on the vacuum head

3 well supported, so that even in very thin wafers through the

applied negative pressure no structural damage can occur.

Die VakuumkÃ¶pfe 3 kÃ¶nnen einfach durch Einclipsen in den Trageteil

6 montiert werden, und sie werden in diesem oben durch

den Oberteil 13 und unten durch einen Ringflansch 16 gehalten.The vacuum heads 3 can be simply clipped into the support part

6 can be assembled and they will go through in this above

the upper part 13 and held down by an annular flange 16.

Durch die beschriebene Ausbildung des Halteteils 6 und durch

das AusfÃ¼hren desselben aus gummielastischem Werkstoff sind

die VakuumkÃ¶pfe 3 im Greifer elastisch federnd montiert, sodass

sie sich senkrecht zur Ebene des Greifers bewegen kÃ¶nnen,

zumal auch in der Basisplatte 1 mit den Ãffnungen 8 korrespondierende

Ãffnungen 17 vorgesehen sind.Through the described design of the holding part 6 and through

the execution of the same are made of rubber-elastic material

the vacuum heads 3 are mounted elastically resiliently in the gripper, so that

they can move perpendicular to the level of the gripper,

especially also in the base plate 1 with openings 8 corresponding

Openings 17 are provided.

Zum Beaufschlagen des Greifers mit Unterdruck (fÃ¼r die VakuumkÃ¶pfe

3) einerseits und mit Druckgas (fÃ¼r die dÃ¼senartigen

AustrittsÃ¶ffnungen 5) andererseits ist ein als Druckgas-/UnterdruckzufÃ¼hrung

in den Fig. 4 und 5 fÃ¼r sich dargestellter

Bauteil 20 vorgesehen. Dabei zeigt Fig. 4 die Seite dieses

Bauteils 20, die der Deckplatte 2 zugekehrt ist und Ã¼ber die

Druckgas zugefÃ¼hrt wird. Fig. 5 zeigt die der Basisplatte 1

zugekehrte Seite des Bauteils 20, die mit Unterdruck beaufschlagt

wird. Der Bauteil 20 besteht aus einem stabfÃ¶rmigen

Teil 21, an dessen einer Seite ein Druckgaskanal 22 und an

dessen anderer Seite ein Unterdruckkanal 23 ausgespart ist.

Des Weiteren besitzt der Bauteil 20 einen scheibenfÃ¶rmigen

Teil 24 mit zu seinem Rand hin offenen Ausschnitten 29. An der

der Deckplatte 2 zugekehrten Seite des Teils 24 sind U-fÃ¶rmige

VorsprÃ¼nge 25, die am Rand der Ausschnitte 29 liegen, vorgesehen.

Zwischen den Enden benachbarter U-fÃ¶rmiger VorsprÃ¼nge 25

ergeben sich somit Vertiefungen 26, die zusammen mit der Deckplatte

2 die dÃ¼senartigen AusstrÃ¶mÃ¶ffnungen 5 fÃ¼r das Druckgas

bilden.For applying vacuum to the gripper (for the vacuum heads

3) on the one hand and with compressed gas (for the nozzle-like

Outlet openings 5), on the other hand, is a pressurized gas / vacuum supply

4 and 5 for themselves shown

Component 20 provided. 4 shows the side of this

Component 20, which is facing the cover plate 2 and

Compressed gas is supplied. 5 shows that of the base plate 1

facing side of the component 20, which is subjected to negative pressure

becomes. The component 20 consists of a rod-shaped

Part 21, on one side of a compressed gas channel 22 and

the other side of which a vacuum channel 23 is recessed.

Furthermore, the component 20 has a disk-shaped

Part 24 with cutouts open to its edge 29. At the

the cover plate 2 facing side of part 24 are U-shaped

Projections 25, which lie on the edge of the cutouts 29, are provided.

Between the ends of adjacent U-shaped protrusions 25

This results in depressions 26 which together with the cover plate

2 the nozzle-like outflow openings 5 for the compressed gas

form.

In den Vertiefungen 26 des Bauteils 20 kÃ¶nnen VorsprÃ¼nge, die

als rippen- und/oder zapfenartige VorsprÃ¼nge ausgebildet sein

kÃ¶nnen, vorgesehen sein. Diese VorsprÃ¼nge (nicht gezeigt) dienen

als StrÃ¶mungswiderstÃ¤nde und gewÃ¤hrleisten einen gleichmÃ¤Ãigen

Druckaufbau im DÃ¼senbereich und somit ein gleichmÃ¤Ãiges

AusstrÃ¶men des Druckgases aus den dÃ¼senartigen AusstrÃ¶mÃ¶ffnungen

5. Durch das aus den dÃ¼senartigen AusstrÃ¶mÃ¶ffnungen 5 ausstrÃ¶mende

Druckgas wird nach dem Bernoulli-Prinzip zwischen

einem auf den Greifer (von oben der Fig. 1 her) aufgelegten

Wafer und dem Greifer selbst eine Kraft erzeugt, die den Wafer

zum Greifer hin zieht.In the recesses 26 of the component 20 projections can

be designed as rib-like and / or peg-like projections

can be provided. These protrusions (not shown) serve

as flow resistances and ensure an even

Pressure build-up in the nozzle area and thus an even one

Outflow of the compressed gas from the nozzle-like outflow openings

5. Through the outflow from the nozzle-like outflow openings 5

Compressed gas is between the Bernoulli principle

one placed on the gripper (from above in FIG. 1)

Wafer and the gripper itself generates a force that the wafer

pulls towards the gripper.

Zur Mitte hin ist der Teil 24 des Bauteils 20 durch einen gestuften

ringfÃ¶rmigen Vorsprung 27 zur Deckplatte 2 und einer

in dieser vorgesehenen mittigen Ãffnung hin abgedichtet.Part 24 of component 20 is stepped toward the center

annular projection 27 to the cover plate 2 and one

sealed in this provided central opening.

Auf der der Basisplatte 1 zugekehrten Seite des Teils 20 sind

am Rand des Teils 24 zwischen den Ausschnitten 29 bogenfÃ¶rmige

Rippen 28, die nach unten hin vorstehen und die an der Basisplatte

1 anliegen, vorgesehen.On the side of the part 20 facing the base plate 1

at the edge of the part 24 between the cutouts 29 arcuate

Ribs 28 that protrude downward and that on the base plate

1 are provided.

Wie Fig. 2 erkennen lÃ¤sst, greifen die Halteteile 6 fÃ¼r die

VakuumkÃ¶pfe 3 mit ihren radial innen liegenden Enden in die

Aussparungen 29 des Teils 24 ein, sodass die VakuumkanÃ¤le 11

in den Halteteilen 6 mit dem zwischen dem Teil 24 und der Basisplatte

1 liegenden Raum Ã¼ber den Kanal (23) mit Unterdruck

beaufschlagt werden kÃ¶nnen.As can be seen in FIG. 2, the holding parts 6 grip for the

Vacuum heads 3 with their radially inner ends in the

Recesses 29 of the part 24 so that the vacuum channels 11

in the holding parts 6 with that between the part 24 and the base plate

1 lying room over the channel (23) with negative pressure

can be applied.

Der Kanal 22 in dem stabfÃ¶rmigen Ansatz 21 des Teils 20 kann

durch eine VerlÃ¤ngerung 30 der Deckplatte 2 geschlossen werden.

SinngemÃ¤Ães gilt fÃ¼r den Kanal 23, der mit Unterdruck beaufschlagt

wird.The channel 22 in the rod-shaped extension 21 of the part 20 can

be closed by an extension 30 of the cover plate 2.

The same applies analogously to channel 23, which is subjected to negative pressure

becomes.

Die Basisplatte 1, die Halteteile 6 und die Deckplatte 2 kÃ¶nnen

durch Verbindungsmittel, welche durch LÃ¶cher 31 in den genannten

Bauteilen gesteckt werden, miteinander zu dem Greifer

gemÃ¤Ã Fig. 1 verbunden werden.The base plate 1, the holding parts 6 and the cover plate 2 can

by connecting means which through holes 31 in said

Components are plugged together to the gripper

1 are connected.

Die anhand der Fig. 1 bis 5 beschriebene Konstruktion des erfindungsgemÃ¤Ãen

Greifers erlaubt es, diesen weitgehend beliebig

auszugestalten. So kann der Greifer auch so, wie dies in

Fig. 6 dargestellt ist, ausgefÃ¼hrt sein, wobei der Teil des

Greifers mit der Druckgas-/VakuumzufÃ¼hrung gegenÃ¼ber dem eigentlichen

Greifer mit Basisplatte 1 und Deckplatte 2 durch

eine KrÃ¶pfung versetzt angeordnet ist; dabei kann, wie in Fig.

6 gezeigt, beispielsweise ein radialer Schlitz zur mittigen

Ãffnung im Greifer vorgesehen sein. Fig. 6 zeigt, dass die

Grundplatte 1 nicht kreisrund sein muss, sondern abgeflachte

Randbereiche und an ihrem Rand Ausnehmungen aufweisen kann.The construction of the invention described with reference to FIGS. 1 to 5

Grippers allow this to be largely arbitrary

to design. The gripper can also be used like this in

Fig. 6 is shown, the part of the

Gripper with the compressed gas / vacuum supply compared to the actual one

Gripper with base plate 1 and cover plate 2 through

a crank is offset; can, as in Fig.

6 shown, for example a radial slot to the center

Opening should be provided in the gripper. Fig. 6 shows that the

Base plate 1 does not have to be circular, but flattened

May have edge areas and recesses at their edge.

Dies gilt auch fÃ¼r die nachstehend anhand der Fig. 7 und 8 sowie

9 bis 12 beschriebenen AusfÃ¼hrungsformen eines erfindungsgemÃ¤Ãen

Greifers. This also applies to the following with reference to FIGS. 7 and 8 as well

9 to 12 described embodiments of an inventive

Gripper.

So kann der erfindungsgemÃ¤Ãe Greifer unter Beibehalten seines

Bauprinzips derart konstruiert werden, dass er an den jeweiligen

Einsatzzweck angepasst ist.The gripper according to the invention can thus maintain its

Construction principles are constructed in such a way that it can be attached to the respective

Application is adapted.

Der in den Fig. 7 bis 12 gezeigte Greifer ist insgesamt lÃ¶ffelartig

ausgebildet und besitzt den eigentlichen Greiferteil

50, der Ã¼ber einen Verbindungsteil 51 mit einer Halterung 52

verbunden ist. Wie spÃ¤ter noch beschrieben werden wird, dient

die Halterung 52 zur Versorgung des Greifers mit Druckgas

bzw. Unterdruck, wobei in dem Verbindungsteil 51 KanÃ¤le fÃ¼r

das Weiterleiten von Druckgas und Unterdruck in dem

Greiferteil 50 angeordnet sind.The gripper shown in FIGS. 7 to 12 is generally spoon-like

trained and has the actual gripper part

50, which is connected to a holder 52 via a connecting part 51

connected is. As will be described later, serves

the holder 52 for supplying the gripper with compressed gas

or negative pressure, with 51 channels for

the forwarding of compressed gas and negative pressure in the

Gripper part 50 are arranged.

Ãber die Halterung 52 kann der Greifer der AusfÃ¼hrungsform

von Fig. 7 mit einem Manipulator bzw. Roboter verbunden werden,

damit der Greifer die gewÃ¼nschten Bewegungen beispielsweise

beim Entnehmen von Wafern aus Horden und Ablegen derselben

in ein Quarzboot ausfÃ¼hren kann.The gripper of the embodiment can be carried out via the holder 52

7 are connected to a manipulator or robot,

so that the gripper can make the desired movements, for example

when removing wafers from trays and depositing them

can run into a quartz boat.

Der Greiferteil 50 besteht in Fig. 8 von oben nach unten gesehen

aus einer flexiblen Folie 53, in der auf einem um die Mitte

des Greiferteils 50 angeordneten Kreis verteilt angeordnet

AustrittsÃ¶ffnungen 54 fÃ¼r das Druckgas zum Erzeugen einer einen

Wafer gegen den Greifer hin ziehenden Kraft nach dem Bernoulli-Prinzip

vorgesehen sind. Im Bereich des Randes der Folie

53 sind Ãffnungen 55 vorgesehen, Ã¼ber die der an den Greifer

angelegte Unterdruck zum Halten eines Wafers wirksam

wird.The gripper part 50 is seen from top to bottom in FIG. 8

from a flexible film 53, in one around the middle

of the gripper part 50 arranged circle arranged distributed

Outlet openings 54 for the compressed gas to generate a

Wafer pulling force against the gripper according to the Bernoulli principle

are provided. In the area of the edge of the film

53 openings 55 are provided through which to the gripper

applied vacuum to hold a wafer effective

becomes.

Unterhalb der flexiblen Rolle 53 ist eine Deckplatte 56 angeordnet.

In der Deckplatte 56 sind mit den AustrittsÃ¶ffnungen

bzw. LÃ¶chern 54 fluchtende, schrÃ¤g zu einer senkrecht zum

Greifer stehenden Achse ausgerichtete Bohrungen 57, aus denen

von unten her zugefÃ¼hrtes Druckgas ausstrÃ¶mt, vorgesehen. Die

Bohrungen 57 sind so wie die LÃ¶cher 54 in der Folie 53 wenigstens

im Bereich ihrer oberen Enden bevorzugt auf einem zur

Achse des Greiferteils 50 konzentrischen Kreis angeordnet. A cover plate 56 is arranged below the flexible roller 53.

In the cover plate 56 are with the outlet openings

or holes 54 aligned, oblique to a perpendicular to the

Gripper standing axis aligned holes 57 from which

Compressed gas supplied from below flows out, provided. The

Bores 57 are at least like the holes 54 in the film 53

preferably in the area of their upper ends on a

Axis of the gripper part 50 arranged in a concentric circle.

In der Deckplatte 56 sind weitere Aussparungen 58, die im AusfÃ¼hrungsbeispiel

kreisrund sind, vorgesehen. In diesen Aussparungen

58 sind VakuumkÃ¶pfe 60 angeordnet. Unterhalb der Deckplatte

56 ist eine Zwischenplatte 61 vorgesehen. In der Zwischenplatte

61 sind Aussparungen 62 vorgesehen, die zusammen

mit der Deckplatte 56 und einer unter der Zwischenplatte 61

angeordneten Basisplatte 65 Vakuumkammern bilden.In the cover plate 56 there are further cutouts 58 which are in the exemplary embodiment

are circular. In these recesses

58 vacuum heads 60 are arranged. Below the cover plate

56, an intermediate plate 61 is provided. In the intermediate plate

61 recesses 62 are provided, which together

with the cover plate 56 and one under the intermediate plate 61

arranged base plate 65 form vacuum chambers.

In der Zwischenplatte 61 ist wenigstens eine weitere Aussparung

63 vorgesehen, in deren Bereich die unteren Enden der

Bohrungen 57 in der Deckplatte 56 mÃ¼nden. Die Aussparung 63

bildet zusammen mit der Basisplatte 65 und der Deckplatte 56

eine mit Druckgas beaufschlagte Kammer.At least one further recess is in the intermediate plate 61

63 provided in the area of the lower ends of the

Bores 57 open into the cover plate 56. The recess 63

forms together with the base plate 65 and the cover plate 56

a chamber charged with compressed gas.

Der wie beschreiben aus der flexiblen Folie 53 der Deckplatte

56 der Zwischenplatte 61 und der Basisplatte 65 gebildete

Greiferteil 50 liegt Ã¼ber eine Distanzplatte 64 auf der Oberseite

des Verbindungsteils 51 auf und ist mit diesem verbunden.The as described from the flexible film 53 of the cover plate

56 of the intermediate plate 61 and the base plate 65 are formed

Gripper part 50 lies on top of a spacer plate 64

of the connecting part 51 and is connected to this.

Der Verbindungsteil 51 besteht aus einer oberen Abdeckplatte

70, einer Zwischenlage 71 und einer Grundplatte 72. In dem dem

Greiferteil 50 zugekehrten Ende der Abdeckplatte 70 sind LÃ¶cher

73 vorgesehen, die mit den Aussparungen 62 in der Zwischenplatte

61 kommunizieren. Weiter ist an dem dem Greiferteil

50 zugekehrten Ende der Abdeckplatte 70 ein Loch 74 vorgesehen,

das mit der Aussparung 63 in der Zwischenplatte 61

kommuniziert.The connecting part 51 consists of an upper cover plate

70, an intermediate layer 71 and a base plate 72. In the

Gripper part 50 facing end of the cover plate 70 are holes

73 provided with the recesses 62 in the intermediate plate

61 communicate. Next is the gripper part

50 facing end of the cover plate 70, a hole 74 is provided,

that with the recess 63 in the intermediate plate 61st

communicates.

In der Zwischenlage 71 sind lÃ¤ngslaufende Schlitze 75 und 76

vorgesehen. Die Schlitze 75, 76 in der Zwischenlage 71 bilden

zusammen mit der Abdeckplatte 70 und der Grundplatte 72 im

Verbindungsteil 51 KanÃ¤le zum ZufÃ¼hren von Unterdruck, der

Ã¼ber KanÃ¤le 77 in der Halterung 52 und LÃ¶cher 78 in der Grundplatte

72 wirksam wird. In the intermediate layer 71 there are longitudinal slots 75 and 76

intended. Form the slots 75, 76 in the intermediate layer 71

together with the cover plate 70 and the base plate 72 in

Connection part 51 channels for supplying negative pressure, the

via channels 77 in the holder 52 and holes 78 in the base plate

72 takes effect.

Der Schlitz 76 in der Zwischenlage 71 bildet zusammen mit der

Abdeckplatte 70 und der Grundplatte 72 einen Kanal fÃ¼r das ZufÃ¼hren

von Druckgas, wobei der Kanal fÃ¼r Druckgas Ã¼ber einen

Kanal 79 in der Halterung 52 mit einer Druckgasquelle verbunden

ist. Aus dem Kanal 79 in der Halterung 52 zugefÃ¼hrtes

Druckgas tritt Ã¼ber ein Loch 80 in der Grundplatte 72 in den

vom Schlitz 76 gebildeten Kanal ein.The slot 76 in the intermediate layer 71 forms together with the

Cover plate 70 and the base plate 72 a channel for feeding

of compressed gas, the channel for compressed gas via a

Channel 79 in the holder 52 connected to a pressurized gas source

is. Feeded from the channel 79 in the holder 52

Compressed gas enters through a hole 80 in the base plate 72

a channel formed by the slot 76.

FÃ¼r die Ausbildung der VakuumkÃ¶pfe 60 gibt es zwei bevorzugte

AusfÃ¼hrungsmÃ¶glichkeiten, nÃ¤mlich die in den Fig. 9 und 10 einerseits

und die in den Fig. 11 und 12 andererseits gezeigte

Form.There are two preferred ones for forming the vacuum heads 60

Design options, namely the one in FIGS. 9 and 10 on the one hand

and the one shown in Figs. 11 and 12 on the other hand

Shape.

Bei der in Fig. 9 gezeigten AusfÃ¼hrungsform sitzen die VakuumkÃ¶pfe

60 in entsprechenden LÃ¶chern der flexiblen Folie 53 und

liegen mit einem Randflansch von oben her auf der flexiblen

Folie 53 auf, sodass sie in den Aussparungen bzw. LÃ¶chern 58

der Deckplatte 56 in einer zur Ebene des Greiferteils 50 normalen

Richtung beweglich sind. Werden die VakuumkÃ¶pfe 60 bei

der in Fig. 9 gezeigten AusfÃ¼hrungsform Ã¼ber die Vakuumkammer,

die von den Aussparungen 62 in der Zwischenplatte 61 sowie der

Deckplatte 56 und der (in Fig. 9 nicht gezeigten) Basisplatte

65 begrenzt werden, mit Unterdruck beaufschlagt, dann bewegen

sie sich auch wegen des in der Vakuumkammer entstehenden Unterdrucks

unter elastischem Verformen der flexiblen Folie 53

in die in Fig. 1 gezeigte Lage, in der ihre obere EndflÃ¤che

mit der einem Wafer zugekehrten Seite des Greiferteils 50

fluchtet.In the embodiment shown in FIG. 9, the vacuum heads are seated

60 in corresponding holes in the flexible film 53 and

lie on the flexible with an edge flange from above

Slide 53 so that it in the recesses or holes 58th

the cover plate 56 in a normal to the plane of the gripper part 50

Are moving in the direction. Will the vacuum heads 60 at

the embodiment shown in FIG. 9 via the vacuum chamber,

that of the recesses 62 in the intermediate plate 61 and the

Cover plate 56 and the base plate (not shown in FIG. 9)

65 limited, pressurized, then move

it is also due to the negative pressure that arises in the vacuum chamber

with elastic deformation of the flexible film 53

in the position shown in Fig. 1, in its upper end surface

with the side of the gripper part 50 facing a wafer

flees.

Bei der in Fig. 11 und 12 gezeigten AusfÃ¼hrungsform sind die

VakuumkÃ¶pfe 60 unterhalb der flexiblen Folie 53 angeordnet und

nehmen, wenn sie nicht mit Unterdruck beaufschlagt sind, die

in Fig. 11 gezeigte Lage ein, in die sie von einer Feder 81

gedrÃ¼ckt werden. Bei dieser AusfÃ¼hrungsform wird das an die

VakuumkÃ¶pfe 60 angelegte Vakuum Ã¼ber LÃ¶cher 82 in der flexiblen

Folie 53 zum Halten eines Wafers am Greiferteil 50 wirksam.

Werden die VakuumkÃ¶pfe 60 und die Vakuumkammern mit Unterdruck

beaufschlagt, dann nehmen sie unter Zusammen-drÃ¼cken

der Feder 81 die in Fig. 12 gezeigte Lage ein, in die Folie 53

vÃ¶llig eben ist, also die oberen EndflÃ¤chen der VakuumkÃ¶pfe 60

Ã¼ber die einem Wafer zugekehrte FlÃ¤che des Greiferteils 50

nicht vorstehen.In the embodiment shown in Figs. 11 and 12, these are

Vacuum heads 60 arranged below the flexible film 53 and

if they are not under vacuum, take the

11 into a position shown by a spring 81

be pressed. In this embodiment, this is the

Vacuum heads 60 applied vacuum through holes 82 in the flexible

Foil 53 effective for holding a wafer on the gripper part 50.

The vacuum heads 60 and the vacuum chambers with negative pressure

pressurized, then press them together

the spring 81 into the position shown in FIG. 12 into the film 53

is completely flat, i.e. the upper end faces of the vacuum heads 60

over the surface of the gripper part 50 facing a wafer

do not protrude.

Der Ãberstand der VakuumkÃ¶pfe 60 in den in Fig. 9 bzw. 11 gezeigten

Lagen kann klein gewÃ¤hlt werden und beispielsweise wenige

Zehntelmillimeter betragen.The protrusion of the vacuum heads 60 in those shown in Figs. 9 and 11, respectively

Layers can be chosen small and for example a few

Amount to tenths of a millimeter.

Bei der in den Fig. 7 bis 12 gezeigten AusfÃ¼hrungsform ist der

Auslass des Druckgases zum Erzeugen einer einen Wafer gegen

den Greifer ziehenden Kraft nach dem Bernoulli-Prinzip durch

mehrere EinzeldÃ¼sen gebildet, die durch schrÃ¤ge (spitzer Winkel)

und dÃ¼nne (Durchmesser einige Zehntelmillimeter) Bohrungen

in der Deckplatte 56 verwirklicht werden. Die Bohrungen 57

sind so angeordnet, dass das ihnen zugefÃ¼hrte Druckgas gleichmÃ¤Ãig

auf der GreiferoberflÃ¤che ausstrÃ¶mt. Dies wird im gezeigten

AusfÃ¼hrungsbeispiel durch die im Bereich der unteren

Enden der Bohrungen 57 im Wesentlichen kreisringfÃ¶rmig ausgebildete

Aussparung 63 in der Zwischenplatte 61 erreicht. Wie

oben beschrieben ist, wird Druckgas den Bohrungen 57 im gezeigten

AusfÃ¼hrungsbeispiel durch ein Kanalsystem im Verbindungsteil

51 zugefÃ¼hrt.In the embodiment shown in FIGS. 7 to 12, the

Outlet of the compressed gas for generating a wafer against

pulling force on the gripper according to the Bernoulli principle

several individual nozzles formed by oblique (acute angle)

and thin holes (diameter a few tenths of a millimeter)

can be realized in the cover plate 56. Bores 57

are arranged so that the compressed gas supplied to them is even

flows out on the gripper surface. This is shown in the

Embodiment by the in the area of the lower

Ends of the bores 57 are essentially annular

Recess 63 reached in the intermediate plate 61. How

As described above, compressed gas is shown in the holes 57 in FIG

Embodiment through a channel system in the connecting part

51 fed.

Bei der in den Fig. 7 bis 12 gezeigten AusfÃ¼hrungsform sind

zum Halten eines Wafers am Greifer mit Unterdruck mehrere Unterdruckeinrichtungen

vorgesehen. Diese Unterdruckeinrichtungen

bestehen im gezeigten AusfÃ¼hrungsbeispiel aus den VakuumkÃ¶pfen

60, der flexiblen Folie 53 und den von den Aussparungen

bzw. LÃ¶chern 58 in der Deckplatte 56 und den Aussparungen 62

in der Zwischenplatte 61 gebildeten Unterdruckkammern. Bei dem

in den Fig. 9 und 10 gezeigten AusfÃ¼hrungsbeispiel sind die

VakuumkÃ¶pfe 60 in LÃ¶cher in der flexiblen Folie 53 eingearbeitet,

sodass die VakuumkÃ¶pfe 60 unmittelbar an dem zu haltenden

Gegenstand, beispielsweise einem Wafer, anliegen. Bei der in

den Fig. 11 und 12 gezeigten AusfÃ¼hrungsform ist die flexible

Folie 53 Ã¼ber den oberen Enden der VakuumkÃ¶pfe angeordnet und

im Bereich jedes Vakuumkopfes 60 mit einer Ãffnung fÃ¼r das

Wirksamwerden von Unterdruck versehen. In diesem Fall (grundsÃ¤tzlich

ist dies auch bei der AusfÃ¼hrungsform nach Fig. 9 und

10 mÃ¶glich) belastet die Schraubenfeder 81 den Vakuumkopf 60

und somit die flexible Folie 53 derart, dass der Vakuumkopf

60, wenn er nicht mit Unterdruck beaufschlagt wird, etwas Ã¼ber

die GreiferoberflÃ¤che vorsteht.In the embodiment shown in FIGS. 7 to 12

for holding a wafer on the gripper with vacuum several vacuum devices

intended. These vacuum devices

consist of the vacuum heads in the embodiment shown

60, the flexible film 53 and the recesses

or holes 58 in the cover plate 56 and the recesses 62

vacuum chambers formed in the intermediate plate 61. In which

9 and 10 are the embodiment shown

Vacuum heads 60 incorporated into holes in the flexible film 53,

so that the vacuum heads 60 directly on the to be held

Object, for example a wafer. At the in

11 and 12 embodiment is the flexible

Foil 53 placed over the top ends of the vacuum heads and

in the area of each vacuum head 60 with an opening for the

Applying negative pressure. In this case (basically

is this also in the embodiment according to FIGS. 9 and

10 possible) the coil spring 81 loads the vacuum head 60

and thus the flexible film 53 such that the vacuum head

60, if it is not pressurized, slightly above

the gripper surface protrudes.

Das Funktionsprinzip sowohl der in den Fig. 1 bis 5 gezeigten

AusfÃ¼hrungsform als auch der in den Fig. 7 bis 12 gezeigten

AusfÃ¼hrungsform wird nachstehend erlÃ¤utert:The principle of operation of both that shown in Figs. 1 to 5

Embodiment as well as that shown in FIGS. 7 to 12

Embodiment is explained below:

Durch das AusstrÃ¶men von Druckgas auf die GreiferoberflÃ¤che

wird nach dem Bernoulli-Prinzip (parallele Geschwindigkeitskomponente

zum Greifer und Wafer) eine Kraft erzeugt, die den

Wafer (gegebenenfalls verbogen und verspannt) zur GreiferoberflÃ¤che

hin zieht und damit in Anlage an die VakuumkÃ¶pfe

bringt, die sich etwas (einige Zehntelmillimeter) Ã¼ber der

GreiferoberflÃ¤che befinden. Die senkrecht zur Ebene des Greifers

beweglichen VakuumkÃ¶pfe passen sich durch eine Bewegung

senkrecht zur GreiferflÃ¤che und/oder eine Kippbewegung der

OberflÃ¤che des Wafers an Die Beweglichkeit der VakuumkÃ¶pfe ist

vorteilhaft, da der Wafer, auch wenn er auf Grund der nach dem

Bernoulli-Prinzip entstehenden Kraft zum Greifer hin gezogen

wird, noch eine Restwelligkeit aufweisen kann. Sobald sich die

VakuumkÃ¶pfe an die Wafer-OberflÃ¤che angelegt haben, kann das

Vakuum wirken und der Wafer wird durch die VakuumkÃ¶pfe seitlich

stabilisiert. ZusÃ¤tzlich entsteht in den die VakuumkÃ¶pfe

umgebenden Unterdruckkammern ein Unterdruck, der die VakuumkÃ¶pfe

- diese standen zunÃ¤chst Ã¼ber die GreiferoberflÃ¤che vor

- senkrecht zur GreiferoberflÃ¤che zurÃ¼ckzieht, bis sich ein

stabiler Zustand zwischen ausstrÃ¶mendem Druckgas und Vakuum

bildet. Nach dem Abschalten des Druckgases bewegen sich die

VakuumkÃ¶pfe weiter senkrecht zum Greifer, bis die VakuumkÃ¶pfe

in einer Ebene mit der GreiferoberflÃ¤che liegen und somit den

Wafer plan bzw. eben auf dem Greifer halten.By the discharge of compressed gas onto the gripper surface

is based on the Bernoulli principle (parallel speed component

to the gripper and wafer) generates a force that

Wafer (possibly bent and clamped) to the gripper surface

pulls and thus in contact with the vacuum heads

that is slightly (a few tenths of a millimeter) above the

Gripper surface. The perpendicular to the plane of the gripper

Movable vacuum heads adapt through one movement

perpendicular to the gripper surface and / or a tilting movement of the

Surface of the wafer on The mobility of the vacuum heads is

advantageous because the wafer, even if it is due to the after

The Bernoulli principle pulls the resulting force towards the gripper

will still have a ripple. As soon as the

Vacuum heads can be placed on the wafer surface

Vacuum act and the wafer is laterally through the vacuum heads

stabilized. In addition, the vacuum heads are created

surrounding vacuum chambers a vacuum that the vacuum heads

- These initially stood out over the gripper surface

- retracts perpendicular to the gripper surface until a

stable state between the escaping compressed gas and vacuum

forms. After switching off the compressed gas, the move

Vacuum heads continue perpendicular to the gripper until the vacuum heads

lie in one plane with the gripper surface and thus the

Hold the wafer flat or even on the gripper.

Fig. 13 zeigt ein weiteres AusfÃ¼hrungsbeispiel des erfindungsgemÃ¤Ãen

Greifers mit einer Bernoulli-DÃ¼senplatte 41, die Ã¼ber

eine TrÃ¤gerplatte 42 mit einem Griff 43 verbunden ist. Im

Griff 43 ist ein Druckventil 44 vorgesehen, mit dem der Druck

von Luft eingestellt werden kann, die Ã¼ber den Griff 43, die

TrÃ¤gerplatte 42 und die Bernoulli-DÃ¼senplatte 41 zu DÃ¼sen 45

geliefert ist, um Ã¼ber diese ausgegeben zu werden. AuÃerdem

befindet sich in der Mitte der DÃ¼senplatte 41 noch eine Saugbohrung

46, Ã¼ber die Luft zur DÃ¼senplatte 41 und von dort Ã¼ber

die TrÃ¤gerplatte 42 und den Griff 43 angesaugt wird. Der Saugluftdruck

und der Druck der Ã¼ber die DÃ¼sen 45 ausgestrÃ¶mten

Luft sind getrennt steuerbar, wozu entsprechende Mittel am

bzw. im Griff 43 vorgesehen werden kÃ¶nnen.13 shows a further exemplary embodiment of the invention

Gripper with a Bernoulli nozzle plate 41, which over

a support plate 42 is connected to a handle 43. in the

Handle 43, a pressure valve 44 is provided with which the pressure

of air can be adjusted via the handle 43, the

Carrier plate 42 and the Bernoulli nozzle plate 41 to form nozzles 45

is delivered to be spent on them. Moreover

there is still a suction hole in the middle of the nozzle plate 41

46, over the air to the nozzle plate 41 and from there

the carrier plate 42 and the handle 43 is sucked. The suction air pressure

and the pressure of those flowing out through the nozzles 45

Air can be controlled separately, for which purpose appropriate means on

or can be provided in the handle 43.

Wird der in Fig. 13 gezeigte Greifer um 180Â° gedreht, sodass

die DÃ¼sen 45 und die Saugbohrung 46 in der Zeichnung nach unten

weisen, so kann ohne weiteres eine Halbleiterscheibe bzw.

ein Wafer aufgenommen werden: die aus den DÃ¼sen 45 ausstrÃ¶mende

Luft sorgt nach dem Bernoulli-Prinzip fÃ¼r einen hydrodynamischen

Unterdruck, sodass allein auf Grund dieses Unterdrucks

die Halbleiterscheibe an der DÃ¼senplatte 41 "haftet". DA aber

allein infolge des Unterdrucks die Halbleiterscheibe unter der

DÃ¼senplatte 41 "schwimmt", das heiÃt sich lateral instabil

verhÃ¤lt, ist zusÃ¤tzlich die Saugbohrung 46 vorgesehen. Durch

den Ã¼ber die Saugbohrung 46 erzeugten Saugdruck wird die Halbleiterscheibe

auf die DÃ¼senplatte 41 "zentriert", sodass ein

stabiler und zuverlÃ¤ssiger Transport bzw. eine sichere Handhabung

der Halbleiterscheibe gewÃ¤hrleistet ist. If the gripper shown in FIG. 13 is rotated through 180 Â° so that

the nozzles 45 and the suction bore 46 downwards in the drawing

point, a semiconductor wafer or

a wafer can be picked up: the one flowing out of the nozzles 45

Air provides for a hydrodynamic according to the Bernoulli principle

Negative pressure, so solely because of this negative pressure

the semiconductor wafer "adheres" to the nozzle plate 41. Here but

solely due to the negative pressure, the semiconductor wafer under the

Nozzle plate 41 "floats", that is, laterally unstable

behaves, the suction bore 46 is additionally provided. By

the semiconductor wafer becomes the suction pressure generated via the suction bore 46

"centered" on the nozzle plate 41, so that a

stable and reliable transport or safe handling

the semiconductor wafer is guaranteed.

Die BauhÃ¶he der DÃ¼senplatte 41 betrÃ¤gt 2 bis 3 mm, sodass sie

ohne weiteres zwischen zwei Ã¼bereinander in einer Horde liegenden

Halbleiterscheiben eingefahren werden kann, um beispielsweise

die untere Scheibe dieser beiden Halbleiterscheiben

aufzunehmen.The overall height of the nozzle plate 41 is 2 to 3 mm, so that it

easily between two superimposed in a horde

Semiconductor wafers can be retracted, for example

the lower wafer of these two semiconductor wafers

to record.

Solange sich eine Halbleiterscheibe auf der DÃ¼senplatte 41

befindet und bei dieser Ã¼ber die DÃ¼sen 45 Luft ausstrÃ¶mt, ist

die Halbleiterscheibe in hohem AusmaÃ eingeebnet. Das heiÃt,

konkave und konvexe KrÃ¼mmungen werden durch den hydrodynamischen

Unterdruck ausgeglichen.As long as a semiconductor wafer is on the nozzle plate 41

is located and at this 45 air flows out through the nozzles

leveled the semiconductor wafer to a large extent. This means,

concave and convex curvatures are created by the hydrodynamic

Negative pressure balanced.

Fig. 14 zeigt ein weiteres AusfÃ¼hrungsbeispiel der erfindungsgemÃ¤Ãen

Vorrichtung, das sich von dem AusfÃ¼hrungsbeispiel

der Fig. 1 im Wesentlichen dadurch unterscheidet, dass

zusÃ¤tzlich zu der Saugbohrung 46 in der Mitte der DÃ¼senplatte

41 auch in der diese umgebenden TrÃ¤gerplatte 42 weitere Saugbohrungen

47 vorgesehen sind. Mit einem derartigen Greiferarm,

wie er in Fig. 14 gezeigt ist, ist ein BestÃ¼cken von

Quarzbooten mit Halbleiterscheiben in besonders vorteilhafter

Weise mÃ¶glich.14 shows a further embodiment of the invention

Device that differs from the embodiment

1 differs essentially in that

in addition to the suction hole 46 in the middle of the nozzle plate

41 also in the support plate 42 surrounding these further suction bores

47 are provided. With such a gripper arm,

as shown in Fig. 14 is populated by

Quartz boats with semiconductor wafers in a particularly advantageous

Way possible.

## Classifications

- H10P72/78

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
