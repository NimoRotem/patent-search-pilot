# 17. Suction cup apparatus and methods of supporting a sheet of glass

- **Archive rank:** 17 of 50
- **Publication:** [WO-2013109676-A3](https://patents.google.com/patent/WO2013109676A3/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/047714524/publication/WO2013109676A3?q=pn%3DWO2013109676A3)
- **Publication date:** 2013-11-07
- **Filing date:** 2013-01-17
- **Earliest priority:** 2012-01-19
- **Family:** 47714524
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** CORNING INC; NGUYEN TUNG THANH; ZHENG ZHEMING; ZHOU NAIYUE
- **Inventors:** NGUYEN TUNG THANH; ZHENG ZHEMING; ZHOU NAIYUE

## Abstract

A suction cup apparatus (143) for supporting a glass sheet (141a) includes a central suction member (401) including a substantially rigid member (403) which includes a support surface (405). The central suction member (401) further includes a layer of deformable material (407) extending over the support surface (405). A plurality of fluid ports (409) extend through the substantially rigid member (403) and the layer of deformable material (407). The suction cup apparatus (143) further includes a flexible peripheral flange (411) circumscribing the layer of deformable material (407). The flexible peripheral flange (411) and the central suction member (401) are configured to define a pressure zone (413) adjacent to a surface (501) of a glass sheet (141a). Methods are also provided including the step of applying a negative pressure to the suction cup apparatus (143) such that the suction cup apparatus (143) produces a negative pressure zone (413) adjacent to the surface (501) of the glass sheet (141a).

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/WO-2013109676-A3/pdf000.png)

![Sketch 1 for WO-2013109676-A3](https://nimo.iptorch.com/refdrawing/WO-2013109676-A3/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/WO-2013109676-A3/pdf001.png)

![Sketch 2 for WO-2013109676-A3](https://nimo.iptorch.com/refdrawing/WO-2013109676-A3/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/WO-2013109676-A3/pdf002.png)

![Sketch 3 for WO-2013109676-A3](https://nimo.iptorch.com/refdrawing/WO-2013109676-A3/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/WO-2013109676-A3/pdf003.png)

![Sketch 4 for WO-2013109676-A3](https://nimo.iptorch.com/refdrawing/WO-2013109676-A3/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/WO-2013109676-A3/pdf004.png)

![Sketch 5 for WO-2013109676-A3](https://nimo.iptorch.com/refdrawing/WO-2013109676-A3/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/WO-2013109676-A3/pdf005.png)

![Sketch 6 for WO-2013109676-A3](https://nimo.iptorch.com/refdrawing/WO-2013109676-A3/pdf005.png)

## Claims

### Claim 1

What is claimed is: 1. A suction cup apparatus comprising: a central suction member including a first substantially rigid member including a support surface, a layer of elastically-deformable material extending over the support surface, and a plurality of fluid ports extending through the first substantially rigid member and the layer of elastically-deformable material; and a flexible peripheral flange circumscribing the layer of elastically-deformable material, wherein the flexible peripheral flange and the central suction member are configured to define a pressure zone adjacent to a surface of a glass sheet. 2. The suction cup apparatus of claim 1, wherein the plurality of fluid ports are arranged in a pattern extending along substantially the entire support surface. 3. The suction cup apparatus of claim 1 or claim 2, wherein the fluid ports each include a maximum cross-sectional dimension along a plane of the support surface in a range of from about 0.5 mm to about 5 mm. 4. The suction cup apparatus of any one of claims 1-3, wherein the first substantially rigid member has a young's modulus of at least 65 GPa. 5. The suction cup apparatus of any one of claims 1-4, wherein the layer of elastically- deformable material has a thickness in a range of from about 100 μιη to about 1000 μιη, such as from about 100 μιη to about 500 μηι. 6. A method of supporting a sheet of glass comprising the steps of: (I) providing a glass sheet having a thickness of less than or equal to about 0.7 mm; (II) providing a suction cup apparatus comprising a central suction member including a first substantially rigid member including a support surface, a layer of elastically-deformable material extending over the support surface, and a plurality of fluid ports extending through the first substantially rigid member and the layer of elastically-deformable material, the suction cup apparatus further provided with a flexible peripheral flange circumscribing the layer of elastically-deformable material; (III) engaging the suction cup apparatus with a surface of the glass sheet; and (IV) applying a negative pressure source to draw fluid through the plurality of pressure ports such that a negative pressure zone is produced adjacent to the surface of the glass sheet. 7. The method of claim 6, wherein a maximum warpage of the glass sheet along the negative pressure zone is below about 3.5 μηι. 8. The method of claim 6 or claim 7, wherein a maximum stress of the glass sheet along the pressure zone is below about 0.4 MPa. 9. A method of supporting a sheet of glass comprising the steps of: (I) providing a glass sheet having a thickness of less than or equal to about 0.4 mm; (II) providing a suction cup apparatus; (III) engaging the suction cup apparatus with a surface of the glass sheet; and (IV) applying a negative pressure to the suction cup apparatus such that the suction cup apparatus produces a negative pressure zone adjacent to the surface of the glass sheet sufficient to support the glass sheet, wherein the maximum warpage of the glass sheet along the negative pressure zone is below about 3.5 μηι. 10. The method of claim 9, wherein a maximum stress of the glass sheet along the pressure zone is below about 0.4 MPa. 11. A method of supporting a sheet of glass comprising the steps of: (I) providing a glass sheet having a thickness of less than or equal to about 0.4 mm; (II) providing a suction cup apparatus; (III) engaging the suction cup apparatus with a surface of the glass sheet; and (IV) applying a negative pressure to the suction cup apparatus such that the suction cup apparatus produces a negative pressure zone adjacent to the surface of the glass sheet sufficient to support the glass sheet, wherein the maximum stress of the glass sheet along the negative pressure zone is below about 0.4 MPa. 12. The method of any one of claims 9-11, wherein step (IV) applies a negative pressure of about 30 kPa to the suction cup apparatus.

## Full description

**[0001]**

SUCTION CUP APPARATUS AND METHODS OF SUPPORTING A

**[0002]**

SHEET OF GLASS

**[0003]**

[0001] This application claims the benefit of priority of US Provisional Application Serial No. 61/588,288 filed on January 19, 2012 the content of which is relied upon and incorporated herein by reference in its entirety.

**[0004]**

FIELD

**[0005]**

[0002] The present disclosure relates generally to methods and apparatus for supporting a glass sheet and, more particularly, to suction cup apparatus and methods of supporting a sheet of glass with a suction cup apparatus.

**[0006]**

BACKGROUND

**[0007]**

[0003] Glass sheets are commonly used, for example, in display applications, for example liquid crystal displays (LCDs), electrophoretic displays (EPD), organic light emitting diode displays (OLEDs), plasma display panels (PDPs), or the like. Glass sheets are commonly fabricated by a flowing molten glass to a forming body whereby a glass ribbon may be formed by a variety of ribbon forming process, for example, slot draw, float, down-draw, fusion down- draw, or up-draw. The glass ribbon may then be subsequently divided to provide sheet glass suitable for further processing into a desired display application. Increasingly, there is a growing interest for extremely high quality thin glass sheets. Thus, there is a need for a process and apparatus which allows handling of the glass sheets without undue warpage and/or stress in the glass sheet that may otherwise result in creating imperfections and or otherwise damaging the glass sheet.

**[0008]**

SUMMARY

**[0009]**

[0004] There are set forth suction cup apparatus and methods suitable for supporting relatively thin glass sheets that may have a reduced tolerance of stress concentrations and/or warpage of the glass sheets when supporting the glass sheets. Supporting the glass sheets may include, for example, supporting the glass sheet (e.g., glass ribbon) within an elastic zone of a glass forming process. In further examples, supporting the glass sheets can involve stabilizing the glass ribbon as a glass sheet is being cut from the glass ribbon. In still further examples, supporting the glass sheet can include handling the glass sheet after separating the glass sheet from the glass ribbon.

**[0005]**

In one aspect, a suction cup apparatus includes a central suction member including a first substantially rigid member. The first substantially rigid member includes a support surface. The central suction member further includes a layer of elastically-deformable material extending over the support surface. A plurality of fluid ports extend through the first substantially rigid member and the layer of elastically-deformable material. The suction cup apparatus further includes a flexible peripheral flange circumscribing the layer of elastically-deformable material. The flexible peripheral flange and the central suction member are configured to define a pressure zone adjacent to a surface of a glass sheet.

**[0010]**

[0006] In one example of the aspect, the support surface of the first substantially rigid member is substantially flat.

**[0011]**

[0007] In still another example of the aspect, the plurality of fluid ports are arranged in a pattern extending along substantially the entire support surface.

**[0012]**

[0008] In yet another example of the aspect, the plurality of fluid ports are arranged in an array of fluid ports along the support surface.

**[0013]**

[0009] In another example of the aspect, the array of fluid ports includes a matrix of fluid ports arranged in columns and rows.

**[0014]**

[0010] In still another example of the aspect, the fluid ports each include a maximum cross- sectional dimension along a plane of the support surface in a range of from about 0.5 mm to about 5 mm.

**[0015]**

[0011] In yet another example of the aspect, the first substantially rigid member has a young's modulus of at least 65 GPa.

**[0016]**

[0012] In another example of the aspect, the first substantially rigid member has a young's modulus of at least 70 GPa.

**[0017]**

[0013] In still another example of the aspect, the first substantially rigid member includes a material including metal.

**[0018]**

[0014] In yet another example of the aspect, the layer of elastically-deformable material has a thickness in a range of from about 100 μηι to about 1000 μηι, such as from about 100 μηι to about 500 μηι.

**[0019]**

[0015] In another example of the aspect, the elastically-deformable material includes silicone rubber.

**[0016]**

In still another example of the aspect, the central suction member has a substantially circular shape.

**[0020]**

[0017] In yet another example of the aspect, the support surface of the first substantially rigid member extends along a substantially flat plane.

**[0021]**

[0018] In another example of the aspect, the support surface of the first substantially rigid member is substantially smooth.

**[0022]**

[0019] In still another example of the aspect, the first substantially rigid member includes a substantially rigid plate.

**[0023]**

[0020] In yet another example of the aspect, the suction cup apparatus further includes a shroud that cooperates with the first substantially rigid member to define a pressure cavity in fluid communication with each of the plurality of fluid ports.

**[0024]**

[0021] In another example of the aspect, suction cup apparatus further includes a pressure port in fluid communication with the pressure cavity.

**[0025]**

[0022] The above examples of the one aspect may be used in any and all combinations with each other.

**[0026]**

[0023] In another aspect, a method of supporting a sheet of glass includes the step of providing a glass sheet having a thickness of less than or equal to about 0.7 mm. The method further includes the step of providing a suction cup apparatus including a central suction member including a first substantially rigid member. The first substantially rigid member includes a support surface. The central suction member further includes a layer of elastically-deformable material extending over the support surface. A plurality of fluid ports extend through the first substantially rigid member and the layer of elastically-deformable material. The suction cup apparatus further includes a flexible peripheral flange circumscribing the layer of elastically- deformable material. The method further includes the step of engaging the suction cup apparatus with a surface of the glass sheet. A negative pressure source is applied to draw fluid through the plurality of pressure ports such that a negative pressure zone is produced adjacent to the surface of the glass sheet.

**[0027]**

[0024] In one example of the aspect, a maximum warpage of the glass sheet along the negative pressure zone is below about 3.5 μηι.

**[0028]**

[0025] In another example of the aspect, the maximum warpage of the glass sheet along the negative pressure zone is below about 1 μηι.

**[0026]**

In still another example of the aspect, the maximum warpage of the glass sheet along the negative pressure zone is below about 0.5 μηι.

**[0029]**

[0027] In yet another example of the aspect, the step of providing a glass sheet includes a thickness of the glass sheet at less than about 0.4 mm.

**[0030]**

[0028] In another example of the aspect, a maximum stress of the glass sheet along the pressure zone is below about 0.4 MPa.

**[0031]**

[0029] In still another example of the aspect, the maximum stress of the glass sheet along the pressure zone is below about 0.2 MPa.

**[0032]**

[0030] In yet another example of the aspect, the maximum stress of the glass sheet along the pressure zone is below about 0.1 MPa.

**[0033]**

[0031] In another aspect, a method of supporting a sheet of glass includes the step of providing a glass sheet having a thickness of less than or equal to about 0.4 mm. The method further includes the steps of providing a suction cup apparatus and engaging the suction cup apparatus with a surface of the glass sheet. The method further includes the step of applying a negative pressure to the suction cup apparatus such that the suction cup apparatus produces a negative pressure zone adjacent to the surface of the glass sheet. The negative pressure zone is sufficient to support the glass sheet, and the maximum warpage of the glass sheet along the negative pressure zone is below about 3.5 μηι.

**[0034]**

[0032] In one example of the aspect, the step of applying a negative pressure applies a negative pressure of about 30 kPa to the suction cup apparatus.

**[0035]**

[0033] In another example of the aspect, the maximum warpage of the glass sheet along the negative pressure zone is below about 1 μηι.

**[0036]**

[0034] In still another example of the aspect, the maximum warpage of the glass sheet along the negative pressure zone is below about 0.5 μηι.

**[0037]**

[0035] In yet another example of the aspect, the step of providing a glass sheet includes a thickness of the glass sheet at less than about 0.4 mm.

**[0038]**

[0036] In another example of the aspect, a maximum stress of the glass sheet along the pressure zone is below about 0.4 MPa.

**[0039]**

[0037] In still another example of the aspect, the maximum stress of the glass sheet along the pressure zone is below about 0.2 MPa.

**[0038]**

In yet another example of the aspect, the maximum stress of the glass sheet along the pressure zone is below about 0.1 MPa.

**[0040]**

[0039] The above examples of negative pressure, maximum warpage and maximum stress, of the another aspect may be used in any and all combinations with each other.

**[0041]**

In still yet another aspect, a method of supporting a sheet of glass includes the step of providing a glass sheet having a thickness of less than or equal to about 0.4 mm. The method further includes the steps of providing a suction cup apparatus and engaging the suction cup apparatus with a surface of the glass sheet. The method further includes the step of applying a negative pressure to the suction cup apparatus such that the suction cup apparatus produces a negative pressure zone adjacent to the surface of the glass sheet. The negative pressure zone is sufficient to support the glass sheet, and the maximum stress of the glass sheet along the negative pressure zone is below about 0.4 MPa.

**[0042]**

[0041] In one example of the aspect, the step of applying a negative pressure applies a negative pressure of about 30 kPa to the suction cup apparatus.

**[0043]**

[0042] In another example of the aspect, the maximum stress of the glass sheet along the pressure zone is below about 0.4 MPa.

**[0044]**

[0043] In still another example of the aspect, the maximum stress of the glass sheet along the pressure zone is below about 0.2 MPa.

**[0045]**

[0044] In yet another example of the aspect, the maximum stress of the glass sheet along the pressure zone is below about 0.1 MPa.

**[0046]**

BRIEF DESCRIPTION OF THE DRAWINGS

**[0047]**

The above and other features, aspects and advantages of the present invention are better understood when the following detailed description of the invention is read with reference to the accompanying drawings, in which:

**[0048]**

[0046] FIG. 1 is a schematic representation of a glass manufacturing system with a suction cup apparatus to support glass sheets;

**[0049]**

[0047] FIG. 2 is an elevation view of a first embodiment of the suction cup apparatus of FIG. i;

**[0050]**

[0048] FIG. 3 is a bottom view of the suction cup apparatus of FIG. 2;

**[0051]**

[0049] FIG. 4 is a cross-sectional view of the suction cup apparatus along line 4-4 of FIG. 3;

**[0050]**

FIG. 5 is a cross-sectional view of the suction cup apparatus similar to FIG. 4 showing the suction cup apparatus engaged with a glass sheet and also showing the fluid control apparatus connected to the suction cup apparatus;

**[0052]**

[0051] FIG. 6 is a graph comparing the maximum warpage in 0.3 mm thick glass sheets resulting from the support with the suction cup apparatus;

**[0053]**

[0052] FIG. 7 is a graph comparing the maximum first principal stress in 0.3 mm thick glass sheets resulting from the support with the suction cup apparatus;

**[0054]**

[0053] FIG. 8 is a graph similar to FIG. 6 comparing the maximum warpage in 0.2 mm thick glass sheets resulting from the support with the suction cup apparatus;

**[0055]**

[0054] FIG. 9 is a graph similar to FIG. 7 comparing the maximum first principal stress in 0.2 mm thick glass sheets resulting from the support with the suction cup apparatus;

**[0056]**

FIG. 10 is a graph similar to FIG. 6 comparing the maximum warpage in 0.1 mm thick glass sheets resulting from the support with the suction cup apparatus;

**[0057]**

[0056] FIG. 11 is a graph similar to FIG. 7 comparing the maximum first principal stress in

**[0058]**

0.1 mm thick glass sheets resulting from the support with the suction cup apparatus;

**[0059]**

[0057] FIG. 12 is a graph showing the maximum warpage in glass sheets of three differing thicknesses resulting from the suction cup apparatus supporting the glass sheet; and

**[0060]**

[0058] FIG. 13 is a graph showing the maximum first principal stress in glass sheets of three differing thicknesses resulting from the suction cup apparatus supporting the glass sheet.

**[0061]**

DETAILED DESCRIPTION

**[0062]**

The present invention will now be described more fully hereinafter with reference to the accompanying drawings in which example embodiments of the claimed invention are shown. Whenever possible, the same reference numerals are used throughout the drawings to refer to the same or like parts. However, the claimed invention may be embodied in many different forms and should not be construed as limited to the embodiments set forth herein. These example embodiments are provided so that this disclosure will be both thorough and complete, and will fully convey the scope of the claimed invention to those skilled in the art.

**[0063]**

[0060] Directional terms as used herein (e.g., up, down, right left, front, back, top, bottom) are made only with reference to the figures as drawn and are not intended to imply absolute orientation.

**[0061]**

There is an increasing demand for relatively thin glass sheets with particular performance characteristics. As in a typical glass manufacturing system, these relatively thin glass sheets have to be supported or suspended. For example, the relatively thin glass sheets can have thicknesses less than 1 mm, and more particularly than 0.7 mm, and still more particularly, less than 0.4 mm, for example 0.3 mm, 0.2 mm, 0.1 mm, or 0.05 mm. The relatively thin glass sheets may need to be supported to dampen vibration that can be transmitted up a glass ribbon during a glass sheet separation process. The glass sheets may need support during the glass sheet separation process to help ensure that individual glass sheets are separated from the glass ribbon in a controlled way. Furthermore, the glass sheet may have to have its full weight supported during movement, for example, to a conveyor after a separation process. The glass ribbon forming process can be accomplished several different ways, for example, slot draw, float, down-draw, fusion down-draw, or up-draw techniques.

**[0064]**

[0062] Referring now to FIG. 1, there is shown a schematic view of an exemplary glass manufacturing apparatus 101 that may be used in accordance with aspects of the disclosure. The exemplary glass manufacturing apparatus 101 is illustrated as a down draw fusion apparatus although other forming apparatus may be used in further examples.

**[0065]**

[0063] The glass manufacturing apparatus 101 can include a melting vessel 103, a fining vessel 105, a mixing vessel 107, a delivery vessel 109, a forming device 111, a pull roll device 113 and a separating device 115.

**[0066]**

[0064] The melting vessel 103 is where the glass batch materials are introduced as shown by arrow 117 and melted to form molten glass 119. The fining vessel 105 has a high temperature processing area that receives the molten glass 119 (not shown at this point) from the melting vessel 103 and in which bubbles are removed from the molten glass 119. The fining vessel 105 is connected to the mixing vessel 107 by a finer to stir chamber connecting tube 121. The mixing vessel 107 is connected to the delivery vessel 109 by a stir chamber to bowl connecting tube 123. The delivery vessel 109 delivers the molten glass 119 through a downcomer 125 to an inlet 127 and into the forming device 111.

**[0067]**

[0065] Various forming devices may be used in accordance with aspects of the disclosure. For example, as shown in FIG. 1, the forming device 111 includes an opening 129 that receives the molten glass 119 which flows into a trough 131. The molten glass 119 from the trough 131 then overflows and runs down two sides 132 before fusing together at a root 133 of the forming

**[0074]**

device 111. The root 133 is where the two sides 132 come together and where the two overflow walls of molten glass 119 flowing over each of the two sides 132 fuse together as the glass ribbon 106 is drawn downward off the root 133.

**[0068]**

[0066] A portion of the glass ribbon 106 is drawn off the root 133 into a viscous zone 135 wherein the glass ribbon 106 begins thinning to a final thickness. The portion of the glass ribbon 106 is then drawn from the viscous zone 135 into a setting zone 137. In the setting zone 137, the portion of the glass ribbon 106 is set from a viscous state to an elastic state with the desired profile. The portion of the glass ribbon 106 is then drawn from the setting zone 137 to an elastic zone 139. Once in the elastic zone 139, the glass ribbon 106 may be deformed, within limits, without permanently changing the profile of the glass ribbon 106.

**[0069]**

[0067] After the portion of the glass ribbon 106 enters the elastic zone 139, the separating device 115 may be provided to sequentially separate a plurality of glass sheets 141a, 141b from the glass ribbon 106 over a period of time. The separating device 115 may include the illustrated traveling anvil machine although further separating devices may be provided in further examples.

**[0070]**

[0068] As further illustrated in FIG. 1, the glass manufacturing apparatus 101 may be provided with one or more suction cup apparatus 143 that may be provided in one or more various locations to help support the glass ribbon 106 or glass sheets 141a, 141b. For purposes of this application, glass ribbon and glass sheet can be used interchangeably. As such, when discussing applicability and methods of the suction cup apparatus 143 with glass sheets 141a, 141b it is understood that the glass sheets 141a, 141b can be interpreted as the glass ribbon 106. Likewise, when discussing applicability and methods of the suction cup apparatus 143 with a glass ribbon 106 it is understood that the glass ribbon 106 can be interpreted as the glass sheets 141a, 141b. Moreover, while the suction cup apparatus 143 is illustrated being used with the glass manufacturing apparatus 101 shown in FIG. 1, the suction cup apparatus 143 may have applicability with other glass manufacturing apparatus 101 and/or may be used to support glass sheets 141a, 141b without a glass manufacturing apparatus 101 (e.g., after the glass ribbon 106 and/or glass sheets 141a, 141b are formed).

**[0071]**

[0069] FIGS. 2, 3 and 4 respectively illustrate a side view, bottom view and cross-sectional view of one example of the suction cup apparatus 143. As shown in FIG. 4, the suction cup apparatus 143 includes a central suction member 401. The central suction member 401 can have

**[0079]**

a substantially circular shape, although other shapes are also contemplated, for example, the central suction member 401 shape can be ovate, square, rectangular, etc. The central suction member 401 includes a first substantially rigid member 403. Rigidity is commonly described by Young's modulus (E) which is the ratio of tensile stress to the tensile strain of an object. The first substantially rigid member 403 can have a Young's modulus between 65 to 200 gigapascals (GPa) to provide a firm support for other structure described below to support a glass sheet 141a. More particularly, the first substantially rigid member 403 can have a Young's modulus of at least 65 GPa, and even more particularly, a Young's modulus of at least 70 GPa. While the first substantially rigid member 403 can include of any material with a Young's modulus between 65 and 200 GPa, the first substantially rigid member 403 can include a material comprising metal. For example, the first substantially rigid member 403 can include a material comprising metals including aluminum, copper, or steel. In one example, the substantially rigid member 403 can include a substantially rigid plate. For example, the substantially rigid member 403 can include a circular plate.

**[0072]**

[0070] The first substantially rigid member 403 includes a support surface 405. The support surface 405 provides support for the glass sheet 141a (not shown here) during a glass handling operation. The support surface 405 of the first substantially rigid member 403 can be

**[0073]**

substantially flat although curved or other shapes may be provided in further examples. A substantially flat support surface 405 helps avoid the creation of undue stress and warpage within the glass sheet 141a (that may also include a flat surface) when the suction cup apparatus 143 comes into contact with, supports, and leaves contact with the glass sheet 141a. Furthermore, the support surface 405 of the first substantially rigid member 403 can be substantially smooth although surface discontinuities may be provided in further examples. The substantially smooth support surface 405 without discontinuities can avoid stress concentrations that may occur, for examples, with relatively thin glass sheets. Alternatively, a rough support surface may optionally be provided to help grip the glass sheet in situations where surface discontinuities do not result in undue stress concentrations. Additionally, the support surface 405 of the first substantially rigid member 403 extends along a substantially flat plane. In some examples, the support surface 405 can include a flat plane that conforms to a flat sheet of glass or a curve sheet of glass that is bent to a flat orientation. In another example, the support surface 405 can have a curved plane that conforms to a curved sheet of glass or a flat sheet of glass that is bent into a

**[0082]**

curved orientation. In the shown example of FIG. 4, the plane of the support surface 405 is essentially flat.

**[0074]**

[0071] The central suction member 401 further includes a layer of elastically-deformable material 407 extending over the support surface 405. The elastically-deformable material 407 provides a cushion between the first substantially rigid member 403 and the glass sheet 141a to minimize potential damage to the glass sheet 141a when the suction cup apparatus 143 comes into contact with, supports, and leaves contact with the glass sheet 141a. The elastically- deformable material 407 can include a rubber material, for example, silicone rubber although other materials are also contemplated. The elastically-deformable material 407 can have a thickness "Tl" in a range of from about 100 μηι to about 1000 μηι, such as from about 100 μηι to about 500 μηι. If the thickness "Tl" is too thin, forces may be too easily transferred from the support surface 405 to the glass sheet 141a. If the thickness "Tl" is too thick, the suction cup apparatus 143 may pull some sections of the glass sheet 141a too close to the support surface 405 in comparison to other areas of the glass sheet 141a. Both of these conditions can create undue warpage and/or stress in the glass sheet 141a that may otherwise result in imperfections and or otherwise damage the glass sheet 141a. As a result, the thickness "Tl" of the elastically- deformable material 407 must effectively balance the need to absorb force transfer with the need to minimize the potential for glass sheet 141a warpage at the suction cup apparatus 143.

**[0075]**

The central suction member 401 further includes a plurality of fluid ports 409 extending through the first substantially rigid member 403 and the layer of elastically-deformable material 407. Comparing FIGS. 3 and 4, it will be appreciated that the fluid ports 409 are schematically illustrated, wherein the number of fluid ports may not be the same and the dimensions of the fluid ports are not necessarily drawn to scale. The plurality of fluid ports 409 can be arranged in any number of ways. For example, the plurality of fluid ports 409 can be arranged in a pattern extending along substantially the entire support surface 405. In a further example, the plurality of fluid ports 409 can be arranged in an array 301 (best seen in FIG. 3) of fluid ports 409 along the support surface 405. In one example, the array may include different radial spacing of the fluid ports or other patterned spacing of the fluid ports. In yet another example, as shown the array 301 of fluid ports 409 can also include a matrix of fluid ports 409 arranged in columns and rows.

**[0073]**

The fluid ports 409 each include a maximum cross-sectional dimension D along a plane of the support surface 405 in a range of from about 0.5 mm (0.02-in) to about 5 mm (0.20-in). Positive or negative fluid pressure is multiplied by the area upon which it acts to calculate a force acting upon an object such as the glass sheet 141a interacting with a suction cup. As a result, the smaller maximum cross-sectional dimension D of the fluid ports 409 results in lower pinpoint forces acting upon the glass sheet 141a. The lower pinpoint forces reduce the likelihood of adding stress concentrations in the glass sheet 141a when compared to forces created by fluid ports with larger cross-sectional dimensions D or when compared to a suction cup with only one fluid port. The shown example includes fluid ports 409 with circular cross-sections, however, many different cross-sectional shapes are contemplated, for example, ovals, triangles, squares, etc, or even a combination of different shapes. However, it is to be understood that the shape of the fluid ports 409 is less important that the maximum cross-sectional dimension D of the fluid ports 409. The smaller maximum cross-sectional dimension D of the fluid ports 409 results in lower pinpoint forces acting upon the glass sheet 141a and, in turn, reduces the likelihood of adding stress concentrations to the glass sheet 141a.

**[0076]**

[0074] The suction cup apparatus 143 can further include a shroud 415 that cooperates with the first substantially rigid member 403 to define a pressure cavity 417. The pressure cavity 417 is in fluid communication with each of the plurality of fluid ports 409. The shroud 415 and pressure cavity 417 can be used to create a uniform over or under pressure delivered to the fluid ports 409. For example, any over or under pressure created within the pressure cavity 417 is also created at each of the fluid ports 409. As such, an under pressure or suction pressure of, for example, 30 kPa can be created within the pressure cavity 417. The same 30 kPa suction pressure is then created at each of the fluid ports 409. The suction cup apparatus 143 can further include a pressure port 419 in fluid communication with the pressure cavity 417. The pressure port 419 can be used to apply over or under pressure to the pressure cavity 417 from an external positive or negative pressure source.

**[0077]**

[0075] The suction cup apparatus 143 further includes a flexible peripheral flange 411 circumscribing the layer of elastically-deformable material 407. The flexible peripheral flange 411 can be a unitary extension of the layer of elastically-deformable material 407. In another example, the layer of elastically-deformable material 407 includes a first material, and the flexible peripheral flange 411 includes a second material that is different than the first material.

**[0088]**

The flexible peripheral flange 411 can include a rubber material, for example, silicone rubber although other materials are also contemplated. The flexible peripheral flange 411 can have a thickness "t" in a range of from about 100 μηι to about 1000 μηι, such as from about 100 μηι to about 500 μηι, similar to the layer of elastically-deformable material 407. Although not required, as shown, the thickness "t" of the flexible peripheral flange 411 may be smaller than the thickness "Tl" of the layer of elastically-deformable material 407. The flexible peripheral flange 411 and the central suction member 401 are configured to define a pressure zone 413 adjacent to a surface of a glass sheet 141a.

**[0078]**

[0076] Turning to FIG. 5, a cross-sectional view of the suction cup apparatus 143 is illustrated in an engaged position with a surface 501 of a glass sheet 141a. A fluid control apparatus 503 can be operably connected to the suction cup apparatus 143. As schematically shown, a pressure line 505 can provide fluid communication between a coupling 507 mounted to the pressure port 419 and a fluid control manifold 509. The fluid control manifold 509 can include a valve, for example a solenoid valve. The fluid control manifold 509 is configured to throttle or control a fluid pressure introduced to the coupling 507 and the suction cup apparatus 143 originating from a pressure source 511. The pressure source 511 can be any number of devices, for example, a pressure vessel maintained at a negative pressure. A control device 513 can transmit commands along a transmission line 515 to control the pressure source 511. For example, the pressure source 511 may be a vacuum pump wherein the control device 513 can send commands along the transmission line 515 to control operation of the vacuum pump.

**[0079]**

Likewise, the control device 513 may transmit commands along another transmission line 517 to operate the fluid control manifold 509. For example, the fluid control manifold 509 can include a solenoid valve wherein the control device 513 can send commands along the transmission line 517 to control operation of the solenoid valve to regulate fluid pressure in the pressure line 505. In this way, the control device 513 can monitor and control the fluid pressure reaching the suction cup apparatus 143 depending upon the desired fluid pressure profile.

**[0080]**

Furthermore, the suction cup apparatus 143 can be operably connected to an actuator 518, for example, a robotic device. The control device 513 can transmit signals along a transmission line 521 to monitor and control the actuator 518. In one example, the actuator 518 can manipulate the suction cup apparatus 143 within a three-dimensional space via rotational and

**[0092]**

translational motion to engage the glass sheet 141a in order to stabilize, support, and/or carry the entire weight of the glass sheet 141a.

**[0081]**

[0078] FIG. 5 shows the suction cup apparatus 143 engaged with a surface 501 of the glass sheet 141a. In one example of a glass manufacturing process, the actuator 518 can move the suction cup apparatus 143 to engage the glass sheet 141a. As the suction cup apparatus 143 approaches the glass sheet 141a, the control device 513 can transmit a signal opening a solenoid valve within the fluid control manifold 509. The open solenoid valve within the fluid control manifold 509 allows negative pressure from the pressure source 511 to at least partially evacuate the pressure line 505, the coupling 507, and the pressure cavity 417 to create a negative pressure. The negative pressure within the pressure cavity 417 is then communicated to the fluid ports 409 and the pressure zone 413 to create suction within the pressure zone 413. As the circumference of the flexible peripheral flange 411 contacts the glass sheet 141a, the flexible peripheral flange 411 begins to flatten and become more planar. The suction within the pressure zone 413 continues to draw the glass sheet 141a toward the support surface 405 until the surface 501 of the glass sheet 141a meets the layer of elastically-deformable material 407. The flexible peripheral flange 411 material is flexible enough to conform to the shape of the surface 501 of the glass sheet 141a. In the shown example, the surface 501 of the glass sheet 141a is planar and the flexible peripheral flange 411 is pliable or flexible enough to be substantially planar.

**[0082]**

Furthermore, the flexibility of the flexible peripheral flange 411 tends to reduce the likelihood of adding stress concentrations in the glass sheet 141a.

**[0083]**

[0079] Additionally, when the glass manufacturing process requires the suction cup apparatus 143 to disengage the surface 501 of the glass sheet 141a, the control device 513 can transmit a signal to change the pressure within the pressure cavity 417. For example, the control device 513 can transmit a signal to the fluid control manifold 509 to close the solenoid valve within the manifold and thereby eliminate the connection between the pressure source 511 and the pressure cavity 417. The negative pressure within the pressure cavity dissipates, and the suction cup apparatus 143 releases the glass sheet 141a. In another example, the control device 513 can transmit a signal to the fluid control manifold 509 to move the solenoid valve to provide a connection between a positive pressure source and the pressure cavity 417. The positive pressure can then be communicated to the pressure cavity 417 and finally to the fluid ports 409,

**[0096]**

creating a fluid flow from the fluid ports 409 acting against the surface 501 of the glass sheet 141a to urge the glass sheet 141a away from the suction cup apparatus 143.

**[0084]**

Methods of supporting a glass sheet 141a will now be described. The method may begin by providing the glass sheet 141a having a thickness "T" (best seen in FIG. 5) of less than or equal to about 0.7 mm. In one example, this step provides the thickness "T" of the glass sheet 141a at less than about 0.4 mm. Returning to FIG. 4, the method further includes providing a suction cup apparatus 143 includes a central suction member 401. The central suction member 401 includes a first substantially rigid member 403. The first substantially rigid member 403 includes a support surface 405, a layer of elastically-deformable material 407 extends over the support surface 405, and a plurality of fluid ports 409 extend through the first substantially rigid member 403 and the layer of elastically-deformable material 407. The suction cup apparatus 143 further includes a flexible peripheral flange 411 circumscribing the layer of elastically- deformable material 407. As shown in FIG. 5, the method further includes engaging the suction cup apparatus 143 with a surface 501 of the glass sheet 141a. The method still further includes applying a negative pressure source 511 to draw fluid through the plurality of pressure ports such that the pressure zone 413 includes a negative pressure zone 413 adjacent to the surface 501 of the glass sheet 141a. At times during the glass manufacturing process, the suction cup apparatus 143 is engaged with a surface 501 of the glass sheet 141a while the negative pressure zone 413 maintains the engagement with a suction force. During those times, the suction cup apparatus 143 can support the glass ribbon 106.

**[0085]**

[0081] For purposes of this application, supporting the glass ribbon 106 can include stabilizing the glass ribbon 106 and/or supporting at least a portion of the weight of the glass ribbon 106 as shown in FIG. 1. For example, the suction cup apparatus 143 may be used to help firmly hold the glass ribbon 106 when separating the glass sheet 141a from the glass ribbon 106 with the separating device 115. Firm support of the glass ribbon 106 through control of the negative pressure zone 413 can reduce vibrations from propagating up the ribbon to the setting zone 137 where internal stresses and/or shape variabilities may be frozen into the glass ribbon 106. Moreover, providing the layer of elastically-deformable material 407 and the flexible peripheral flange 411 with a resilient material (e.g., silicone rubber) can further help absorb vibrations from the process of engaging the glass ribbon 106 with the separating device 115. In further examples, the suction cup apparatus 143 may be used to support the glass sheet 141a and/or

**[0099]**

glass ribbon 106 to stabilize the glass ribbon 106 while conducting machining operations, during transportation or other applications. For example, the suction cup apparatus 143 may be used to support a glass ribbon 106 and/or glass sheet 141a and/or when finishing the edge portions of the glass sheet 141a and/or glass ribbon 106.

**[0086]**

[0082] In further examples, the suction cup apparatus 143 may be used to support the glass sheet 141a and/or glass ribbon 106 by lifting and moving the glass sheet 141a from one location to another location. In just one example, the suction cup apparatus 143 may support the glass sheet 141a by carrying all the weight of the glass sheet 141a while lifting and moving or otherwise handling the glass sheet 141a to transport the glass sheet 141a to a conveyor apparatus and/or a storage location after separating the glass sheet 141a, 141b from the glass ribbon 106 with the separating device 115.

**[0087]**

[0083] In another method of supporting a glass sheet 141a, the method may begin by providing a glass sheet 141a having a thickness T of less than or equal to about 0.4 mm. In one example, the thickness of the glass sheet 141a at less than about 0.4 mm. Returning to FIG. 5, a cross- sectional view of the suction cup apparatus 143 is illustrated engaging with a surface 501 of the glass sheet 141a. The control device 513 can transmit a signal opening a solenoid valve within the fluid control manifold 509. The open solenoid valve within the fluid control manifold 509 applies a negative pressure from the pressure source 511 to the suction cup apparatus 143 such that the suction cup apparatus 143 produces a negative pressure zone 413 adjacent to the surface 501 of the glass sheet 141a. In one example, the pressure source 511 applies a negative pressure of about 30 kPa to the suction cup apparatus 143. The negative pressure zone 413 is sufficient to support the glass sheet 141a, where the maximum warpage of the glass sheet 141a along the negative pressure zone 413 is below about 3.5 μηι. In one example, the maximum warpage of the glass sheet 141a along the negative pressure zone 413 is below about 1 μηι. In another example, the maximum warpage of the glass sheet 141a along the negative pressure zone 413 is below about 0.5 μηι.

**[0088]**

[0084] In another method of supporting a glass sheet 141a, the method may begin by providing a glass sheet 141a having a thickness T of less than or equal to about 0.4 mm. In one example, the thickness of the glass sheet 141a at less than about 0.4 mm. Returning to FIG. 5, a cross- sectional view of the suction cup apparatus 143 is illustrated engaging with a surface 501 of the glass sheet 141a. The control device 513 can transmit a signal opening a solenoid valve within

**[0103]**

the fluid control manifold 509. The open solenoid valve within the fluid control manifold 509 applies a negative pressure from the pressure source 511 to the suction cup apparatus 143 such that the suction cup apparatus 143 produces a negative pressure zone 413 adjacent to the surface 501 of the glass sheet 141a. In one example, the pressure source 511 applies a negative pressure of about 30 kPa to the suction cup apparatus 143. The negative pressure zone 413 is sufficient to support the glass sheet 141a, where the maximum stress of the glass sheet 141a along the negative pressure zone 413 is below about 0.4MPa. In one example, the maximum stress of the glass sheet 141a along the negative pressure zone 413 is below about 0.2 MPa. In another example, the maximum stress of the glass sheet 141a along the negative pressure zone 413 is below about 0.1 MPa.

**[0089]**

[0085] There is an increasing demand for thinner glass sheets 141a which, for example, can be in the range of 0.05 mm to 0.3 mm thick. While previous suction cup methods and apparatus for holding glass sheets worked well for relatively thicker glass sheets, for example, 0.4 mm to 0.7 mm thick, the previously known suction cup designs can induce significant warpage or deformation and stress gradients in thinner glass sheets 141a. Thinner glass sheets 141a can be more susceptible to warpage and stress gradients which can then cause defects in the glass sheets 141a. For example, warpage of the glass sheet 141a can create score induced breakage in the glass ribbon 106 and failure in the vertical bead separation, resulting in a low yield of acceptable product from the glass finishing process. Therefore, it is desirable to minimize the amount of warpage in each thin glass sheet 141a to increase the quality and acceptable product from the glass finishing process.

**[0090]**

[0086] Numerical modeling using a finite element method (FEM) was conducted to calculate the maximum warpage and the maximum stress imparted to 600 mm x 600 mm glass sheets of varying thickness when supported by differing versions of suction cups. A previously known suction cup with a single fluid port, a suction cup apparatus 143, and the glass sheet 141a described above was numerically modeled. Simulations were performed to predict the maximum warpage and stress of the modeled glass sheet. The simulation results were then numerically and graphically compared. The maximum stress and the maximum warpage were modeled to represent measurements along a line on the glass sheet 141a. In the shown examples of FIGS. 6-11, the line bisects the pressure zone 413 and is substantially perpendicular to the direction as indicated by arrow 145 (best seen in FIG. 1) of the glass ribbon 106.

**[0087]**

Turning to FIG. 6, the results of the numerical modeling for warpage in a 0.3 mm thick glass sheet 141a are shown in graph form, comparing the maximum warpage imparted by a previously known suction cup including only one fluid port to the maximum warpage imparted by the suction cup apparatus 143. Plot 601 represents a plot of warpage of the previously known suction cup while plot 603 represents a plot of warpage of the suction cup apparatus 143. The horizontal X-axis represents the distance measured in mm from one side of the glass sheet 141a to the other side of the glass sheet with the suction cup apparatus 143 located at the midpoint of the line (300 mm). The vertical Y-axis represents maximum warpage measured in μηι.

**[0091]**

Turning to FIG. 7, the results of the numerical modeling of the maximum first principal stress in a 0.3 mm thick glass sheet 141a are shown in graph form, comparing the maximum stress imparted by a previously known suction cup including only one fluid port to the maximum stress imparted by the suction cup apparatus 143. The maximum first principal stress is the highest component of stress along the line of the glass sheet 141a. For simplicity, the maximum first principal stress can also be referred to as the maximum stress of the glass sheet. Plot 701 represents a plot of maximum stress of the previously known suction cup while plot 703

**[0092]**

represents a plot of maximum stress of the suction cup apparatus 143. The horizontal X-axis represents distance measured in mm from one side of the glass sheet 141a to the other side with the suction cup apparatus 143 located at the midpoint of the line (300 mm). The vertical Y-axis represents the maximum first principal stress measured in megapascals (MPa).

**[0093]**

FIG. 8 and FIG. 10 are similar to FIG. 6, and are graphical comparisons of maximum warpage in glass sheets 141a that are of thickness T 0.2 mm and 0.1 mm, respectively. Plots 801 and 1001 represent a plot of warpage of the previously known suction cup while plots 803 and 1003 represent a plot of warpage of the suction cup apparatus 143. The horizontal X-axis represents the distance measured in mm from one side of the glass sheet 141a to the other side of the glass sheet with the suction cup apparatus 143 located at the midpoint of the line (300 mm). The vertical Y-axis represents maximum warpage measured in μηι.

**[0094]**

[0090] FIG. 9 and FIG. 11 are similar to FIG. 7, and are graphical comparisons of maximum stress in glass sheets 141a that are of thickness T 0.2 mm and 0.1 mm, respectively. Plots 901 and 1101 represent a plot of maximum stress of the previously known suction cup while plots 903 and 1103 represent a plot of maximum stress of the suction cup apparatus 143. The horizontal X-axis represents distance measured in mm from one side of the glass sheet 141a to

**[0111]**

the other side with the suction cup apparatus 143 located at the midpoint of the line (300 mm). The vertical Y-axis represents the maximum first principal stress measured in megapascals (MPa). Viewing the comparisons of maximum warpage in the graph of FIGS. 6, 8 and 10 and the maximum stress in the graphs of FIG. 7, 9 and 11, the results show a reduction in both warpage and stress by about 98%.

**[0095]**

[0091] Turning to FIG. 12, the results of the numerical modeling for warpage are shown in graph form. The horizontal axis represents the thickness of the 600 mm x 600 mm glass sheet 141a measured in millimeters while the vertical axis represents the warpage along the negative pressure zone 413 measured in microns. In the shown example bar 1201 of a glass sheet 141a with a thickness T of 0.1 mm, a maximum warpage of the glass sheet 141a along the negative pressure zone 413 is below about 3.5 μηι, such as the illustrated warpage of about 3.09 μπι, when supported by the suction cup apparatus 143. In another example, as shown by bar 1203, with a thickness T of 0.2 mm, the maximum warpage of the glass sheet 141a along the negative pressure zone 413 is below about 1 μηι, such as the illustrated warpage of about 0.75 μηι, when supported by the suction cup apparatus 143. In yet another example, as shown by bar 1205, with a thickness T of 0.3 mm, the maximum warpage of the glass sheet 141a along the negative pressure zone 413 is below about 0.5 μηι, such as the illustrated warpage of about 0.37 μπι, when supported by the suction cup apparatus 143.

**[0096]**

[0092] Turning to FIG. 13, the results of the numerical modeling for stress concentration are shown in a graph form. The horizontal axis represents the thickness of the 600 mm x 600 mm glass sheet 141a measured in millimeters while the vertical axis represents the maximum stress measured in megapascals (MPa). In one example, the line along which the maximum stress is measured bisects the negative pressure zone 413 where the suction cup apparatus 143 supports the glass sheet 141a. In one example, as shown by bar 1301, with a thickness T of 0.1 mm, the maximum stress of the glass sheet 141a along the pressure zone 413 is below about 0.3 MPa, such as the illustrated stress of about 0.2968 MPa. In another example, as shown by bar 1303, with a thickness T of 0.2 mm, the maximum stress of the glass sheet 141a along the pressure zone 413 is below about 0.15 MPa, such as the illustrated stress of about 0.1098 MPa. In yet another example, as shown by bar 1305, with a thickness T of 0.3 mm, the maximum stress of the glass sheet 141a along the pressure zone 413 is below about 0.1 MPa, such as the illustrated stress of about 0.0741 MPa.

**[0093]**

It will be apparent to those skilled in the art that various modifications and variations can be made to the present invention without departing from the spirit and scope of the invention. Thus, it is intended that the present invention cover the modifications and variations of this invention provided they come within the scope of the appended claims and their equivalents.

## Classifications

- B65G49/061
- B65G2249/045
- B65G47/91
- B65G49/06

## Cited patent documents

- [DE-2612952-A1](https://patents.google.com/patent/DE2612952A1/en) — ISR
- [DE-8710206-U1](https://patents.google.com/patent/DE8710206U1/en) — ISR
- [FR-1366308-A](https://patents.google.com/patent/FR1366308A/en) — ISR
- [JP-H0283180-A](https://patents.google.com/patent/JPH0283180A/en) — ISR
- [US-2003164620-A1](https://patents.google.com/patent/US20030164620A1/en) — ISR
- [US-5149162-A](https://patents.google.com/patent/US5149162A/en) — ISR

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
