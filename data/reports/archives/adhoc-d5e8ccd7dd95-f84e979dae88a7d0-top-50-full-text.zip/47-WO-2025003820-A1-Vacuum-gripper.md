# 47. Vacuum gripper

- **Archive rank:** 47 of 50
- **Publication:** [WO-2025003820-A1](https://patents.google.com/patent/WO2025003820A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/088098256/publication/WO2025003820A1?q=pn%3DWO2025003820A1)
- **Publication date:** 2025-01-02
- **Filing date:** 2024-06-14
- **Earliest priority:** 2023-06-29
- **Family:** 88098256
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** FONDAZIONE ST ITALIANO TECNOLOGIA; UNIV PISA
- **Inventors:** ANGELI STEFANO; BICCHI ANTONIO; CATALANO MANUEL GIUSEPPE; SALARIS PAOLO

## Abstract

A vacuum gripper (1) is provided for gripping an object (1a) comprising a suction cup (2) defining a chamber (2a) going in contact with the object (1a) and a regulating apparatus (3) defining a gripping configuration wherein the regulating apparatus (3) places the chamber (2a) in depression allowing the suction cup (2) to bind to the object (1a); and a launch configuration wherein the regulating apparatus (3) places the chamber (2a) in overpressure allowing the suction cup (2) to launch the object (1a).

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf000.png)

![Sketch 1 for WO-2025003820-A1](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf001.png)

![Sketch 2 for WO-2025003820-A1](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf002.png)

![Sketch 3 for WO-2025003820-A1](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf003.png)

![Sketch 4 for WO-2025003820-A1](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf004.png)

![Sketch 5 for WO-2025003820-A1](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf005.png)

![Sketch 6 for WO-2025003820-A1](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf006.png)

![Sketch 7 for WO-2025003820-A1](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf007.png)

![Sketch 8 for WO-2025003820-A1](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf008.png)

![Sketch 9 for WO-2025003820-A1](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf009.png)

![Sketch 10 for WO-2025003820-A1](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf009.png)

[Sketch 11](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf010.png)

![Sketch 11 for WO-2025003820-A1](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf010.png)

[Sketch 12](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf011.png)

![Sketch 12 for WO-2025003820-A1](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf011.png)

[Sketch 13](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf012.png)

![Sketch 13 for WO-2025003820-A1](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf012.png)

[Sketch 14](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf013.png)

![Sketch 14 for WO-2025003820-A1](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf013.png)

[Sketch 15](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf014.png)

![Sketch 15 for WO-2025003820-A1](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf014.png)

[Sketch 16](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf015.png)

![Sketch 16 for WO-2025003820-A1](https://nimo.iptorch.com/refdrawing/WO-2025003820-A1/pdf015.png)

## Claims

### Claim 1

CLAI MS 1. A vacuum gripper (1 ) for gripping an object (1a) comprising: a suction cup (2) configured to contact said object (1a) defining a chamber (2a) substantially sealed; and characterized in that it comprises a regulating apparatus (3) of the pressure in said chamber (2a) and configured to vary the pressure in said chamber (2a) by defining - a gripping configuration in which said regulating apparatus (3) places said chamber (2a) in depression allowing said suction cup (2) to grip said object (1 a); and - a launching configuration in which said regulating apparatus (3) places said chamber (2a) in overpressure allowing said suction cup (2) to launch said object (1a). 2. Gripper (1 ) according to claim 1 , wherein said regulating apparatus (3) comprises a pump (31 ) configured to place said chamber (2a) in depression defining said gripping configuration; a compressor (32) configured to place said chamber (2a) in overpressure defining said launching configuration; at least one conduit (33) placing said pump (31 ) and said compressor (32) in fluid passage connection with said chamber (2a); and a valve (34) configured to selectively place only one of said pump (31 ) and said compressor (32) in fluid passage connection with said chamber (2a) defining said launching configuration by placing in fluid passage connection said compressor (32) and said chamber (2a) and said gripping configuration by placing in fluid passage connection said pump (31 ) and said chamber (2a). 3. Gripper (1 ) according to claim 2, wherein said valve (34) is a solenoid valve and defines a transition time between said configurations suitably less than 50 ms. 4. Gripper (1 ) according to at least one of claim 2-3, wherein said valve (34) defines a launch time wherein said valve (34) is in said launch configuration and said compressor (31 ) is active; and wherein said launch time is substantially less than 300 ms. 5. A handling device (10) comprising said gripper (1 ) according to at least one of claims 1 -3, a robotic arm (10a) for handling said gripper (1 ); and a unit (1 Ob) for controlling the operation of said robotic arm (10a) and said gripper (1 ). 6. Handling device (10) according to the previous claim, comprising an acquisition system (10d) configured to perform at least one optical acquisition of said object (1a) and of a collection site (1 b) of said object (1 a) and to send said acquisition to said unit; and wherein said unit (10b) determines a launch trajectory of said object (1a) into said collection site (1 b) according to said acquisition. 7. Process (100) of placing an object (1a) into a collection site (1 b); said process (100) comprising - a handling device (10) according to the previous claim; - said suction cup (2) defining an open access section to said chamber (2a) and a launch axis (2b) perpendicular to said open access section; characterized by comprising - an object database associating each of said object (1 a) with shape, center of mass and mass distribution of said object (1a); - a site database associating each said collection site (1 b) with an introduction section of said object 1a into said collection site (1 b); - an intake phase (120) comprising. o an approaching subphase (123) in which said robotic arm (10a) approaches said gripper (1 ) to said object (1a) disposing said launch axis (2b) incident said center of mass; and o a pickup subphase (124) in which said regulating apparatus (3) controls the passage of said chamber (2a) in said gripping configuration allowing said gripper (2) to grip said object (1 a); - a determination phase (130) comprising. o a detection subphase (132) in which said acquisition system (10d) performs an acquisition of said collection site (1 b) allowing said unit (10b) to identify the position of said collection site (1 b) with respect to the position of said gripper (1 ) and thus of said object (1 a), and o a determination subphase (133) of launch parameters including at least ■ the intensity of said overpressure determined as a function of said shape and said mass distribution of said object (1a) and ■ the inclination of said launch axis (4a) determined as a function of said position of said collection site (1 b) relative to that of said gripper (1 ). - a launching phase (140) of said object (1 a) into said collection site (1 b) in accordance with the launch parameters calculated in said subphase (133). 8. Process (100) according to the previous claim, wherein said taking phase comprises a verification subphase (125) wherein said acquisition system (10d) performs an acquisition of said gripper (1 ) and of said object (1a) gripped by said gripper (1 ) and said unit (10b) verifies that said launch axis (2b) is incident said center of mass of said object (1a) so that if said axis of launching (2b) is not incident said center of mass of said object (1a) said unit (10b) commands the release of said object 1 a and thus the execution of at least one said approaching subphase (123) and one said pickup subphase (124). 9. Process (100) according to the claim 7, wherein said launching phase (140) comprises a transition sub-phase (142) wherein said gripper (1 ) transitions to a launch configuration in a transition time suitably less than 50 ms. 10. Process (100) according to claim 7, wherein said launch phase (140) comprises a boost sub-phase (143) wherein said gripper (1 ) maintains said chamber (2a) at said overpressure for a launch time substantially less than 300 ms.

## Full description

**[0001]**

DESCRIPTION

**[0002]**

VACUUM GRIPPER

**[0003]**

This invention relates to a vacuum gripper of the type specified in the preamble of the first claim.

**[0004]**

As is well known, a gripper is an end effector, i.e. , the connecting element between the robot and the object to be manipulated, for example, to perform machining or handling of the object.

**[0005]**

Grippers differ based on the execution of gripping the object and/or the gripper operation system. For example, one can have a pneumatic gripper if powered by compressed air that determines through air pressure the movement of fingers, jaws or other gripping elements; an electric gripper in which the movement of the gripping elements is given by an electromagnetic motor exploiting a magnetic field to grip the object.

**[0006]**

One of the most important types of grippers is the vacuum gripper capable of gripping even fragile objects that might be ruined by other types of gripping. In this case, the gripper provides, instead of jaws, a suction cup and a negative (i.e., less than atmospheric) pressure feeding system. In detail, the suction cup, when placed in contact with the object, defines a chamber that is placed in depression by the negative pressure feeding system allowing the object to remain constrained to the gripper.

**[0007]**

The prior art just described includes some important drawbacks.

**[0008]**

Grippers, and vacuum grippers in particular, impose a laborious procedure and handling on the robot to transport an object to the collection site.

**[0009]**

This aspect results in a complex design of the robot and/or the robot handling environment and, therefore, in particularly high costs.

**[0010]**

It should be noticed that it is often necessary to set up specific solutions to enable the robot to discriminate between the various collection sites and then arrive at the selected collection point. This difficulty is amplified in the case of changing (e.g., due to a different layout) the collection sites and/or the point where the object is picked up.

**[0010]**

In this situation, the technical task underlying this invention is to devise a vacuum gripper capable of substantially overcoming at least part of the aforementioned drawbacks.

**[0011]**

Within the scope of said technical task, it is an important purpose of the invention to obtain a vacuum gripper to simplify the procedure of handling an object.

**[0012]**

Another important purpose of the invention is to make a robot equipped with a vacuum gripper capable of easily arranging an object at a collection site.

**[0013]**

Grippers, and vacuum grippers in particular, impose a laborious procedure on the robot to transport an object regardless of the position of the collection site and/or the picking point.

**[0014]**

The technical task and the specified aims are achieved by a vacuum gripper as claimed in the annexed claim 1. Examples of preferred implementation are described in the dependent claims.

**[0015]**

The characteristics and advantages of the invention are clarified below by the detailed description of preferred embodiments of the invention, with reference to the accompanying figures, in which: fig. 1 shows a handling device provided with a vacuum gripper according to the invention; figs. 2a-2c illustrate a sequence of operation of the vacuum gripper according to the invention and in particular of the handling device in fig. 1 ; and

**[0017]**

fig. 3 shows a schematization of the process implementable by the vacuum gripper handling device according to the invention.

**[0016]**

In this document, when measurements, values, shapes, and geometric references (such as perpendicularity and parallelism) are associated with words like “approximately” or other similar terms, such as “almost” or “substantially”, they shall be understood as except for errors of measurement or imprecisions due to errors of production and/or manufacturing and, above all, except for a slight departure from the value, measurement, shape, or geometric reference with which it is associated. For example, if associated with a value, such terms preferably indicate a divergence of no more than 10% of the value itself.

**[0017]**

Furthermore, when terms such as “first”, “second”, “upper”, “lower”, “main”, and “secondary” are used, they do not necessarily identify an order, relationship priority, or relative position, but they can simply be used to distinguish different components more clearly from one another.

**[0018]**

Unless otherwise indicated, "perpendicular”, "transverse”, "parallel”, or "normal”, or other terms of geometric positioning between geometric elements (e.g., axes, directions, and straight lines) are to be understood with reference to their mutual geometric position between corresponding projections. Said projections are defined on a single plane parallel to the lying plane(s) of said geometric elements.

**[0019]**

The measurements and data reported in this text are to be considered, unless otherwise indicated, as performed in the International Standard Atmosphere ICAO (ISO 2533:1975).

**[0020]**

Unless otherwise specified, as reflected in the following discussions, terms such as "processing”, "computing”, "determination”, "computation”, orthe like are considered to refer to the action and/or processes of a computer or similar electronic computing

**[0023]**

device that manipulates and/or transforms data represented as physical, such as electronic quantities of records of a computer system and/or memories, in other data similarly represented as physical quantities within computer systems, records, or other information storage, transmission, or display devices.

**[0021]**

With reference to the figures, the vacuum gripper according to the invention is globally indicated with the number 1.

**[0022]**

It is configured to perform the grasping of an object 1a and conveniently arrange said object 1a in a collection site 1b by launching it appropriately as described below.

**[0023]**

Object 1 a can be at a picking site 1c.

**[0024]**

Gripper 1 is configured to be implemented on a handling device 10 of one or more objects 1 a.

**[0025]**

The handling device 10 may include gripper 1 and preferably a robotic arm 10a handling gripper 1.

**[0026]**

The handling device 10 may include a control unit 10b to operate device 10 and in particular robotic arm 10a and/or gripper 1 .

**[0027]**

The control unit 10b may include a circuit board, a processor or any other device configured to control the operation of gripper 1 and in particular of device 10.

**[0028]**

Unit 10b can be integrated into robotic arm 10a (as shown in fig. 1 only) or be an external element available in data connection, e.g., wireless, with robotic arm 10a and/or gripper 1 .

**[0029]**

Robotic arm 10a may include one or more rigid bodies 11 identifiable in bars which can be telescopic. In detail, it includes an end rigid body 11 configured to attach to gripper 1 ; an initial rigid body 11 binding robotic arm 10a to a support of the arm 10a as described below; and optionally one or more intermediate rigid bodies 11

**[0033]**

interposed between end rigid body 11 and initial rigid body 11 .

**[0030]**

In some cases, the end rigid body 11 is configured to attach to gripper 1 in a detachable manner. In particular, the robotic arm 10a can include an additional gripper 12 holding gripper 1 .

**[0031]**

The additional gripper 12 can be a well-known end-effector of gripper 1 . Preferably it is an appropriately underactuated robotic hand.

**[0032]**

The robotic arm 10a may include at least one mechanical joint 13 each interposed between two adjacent rigid bodies 11 and configured to reciprocally move said rigid bodies 11 . Preferably, the arm 10a comprises multiple mechanical joints configured to reciprocally move the rigid bodies 11 appropriately independently of each other.

**[0033]**

Each mechanical joint is in data connection with unit 10b so that said unit can control joints 13 and thus the movement of arm 10a.

**[0034]**

Optionally, the robotic arm 10a can include a mechanical joint 13 between rigid body 11 and additional gripper 12.

**[0035]**

Mechanical joints 13 are configured to move and, to be precise, mutually rotate rigid bodies 11 by varying the spread angle between two contiguous rigid bodies 11 .

**[0036]**

Mechanical joints 13 move rigid bodies 11 in accordance with inverse kinematics or direct kinematics. Therefore, it is clarified that, although not explicitly stated, any movement of the robotic arm 10a described in this paper is determined according to inverse kinematics or direct kinematics.

**[0037]**

The inverse kinematic expression defines a trajectory in operational space, i.e. , the calculation of the path of the end organ of the robotic arm 10a (identifiable as the additional gripper 13 or preferably gripper 1 ). Therefore, the control unit 10b determines the position, speed and acceleration of the individual mechanical joints 13 so as to have said path of the end organ of the robotic arm 10a.

**[0042]**

The direct kinematic expression identifies the calculation of a trajectory in the joint space in which the position, velocity and acceleration of individual mechanical joints 11 are determined, not the path of the end organ. Consequently, the path of the end organ of the robotic arm 10a is the result of the position, velocity and acceleration of the mechanical joints 13.

**[0038]**

Each joint 13 is configured to rotate at least the rigid body 11 following it in accordance with the kinematic chain by defining an axis of rotation transverse and, substantially perpendicular to the axis of preferred extension of the rigid body 11. Preferably, a joint 13 defines two axes of rotation nearly transverse and, more preferably, perpendicular to each other.

**[0039]**

Mechanical joints 13 can be of various types, motorized or non-motorized, such as - by way of non-limiting example - rotoidal, prismatic, spherical, helical, cylindrical, and hinge joints.

**[0040]**

Each mechanical joint 13 includes a servomotor, that is, an electric motor equipped with an encoder designed to measure the angle of rotation between the rigid bodies 13 given by the same motor and to maintain that angle stably.

**[0041]**

The handling device 10 may include a stand 10c of the robotic arm 10a.

**[0042]**

The mobile stand 10c is configured to support arm 10a, gripper 1 , and possible object 1 a.

**[0043]**

It may include a base configured to rest on and optionally be joined to an external structure such as a walkable surface, a wall, or shelving.

**[0044]**

Optionally, the stand 10c is configured to move the robotic arm 10a, for example, along a walkable surface. It may include a suitably motorized trolley that can be controlled by unit 10b.

**[0045]**

The stand 10c can be in data connection with the unit 10c that controls its operation.

**[0051]**

The handling device 10 may include a power supply configured to power, appropriately electrically, the robotic arm 10a (detailing at least one mechanical joint 13 and/or the additional gripper 12) and optionally the support 10c.

**[0046]**

Said power supply may include a battery.

**[0047]**

It can be integrated into arm 10a and/or stand 10c.

**[0048]**

The power supply can power gripper 1 .

**[0049]**

Gripper 1 is configured to perform gripping of object 1 a and then pick up object 1a from a picking site 1 c.

**[0050]**

Gripper 1 includes a suction cup 2 configured to contact said object 1 a defining a chamber 2a substantially sealed (Fig 2b).

**[0051]**

Suction cup 2 can define a chamber 2a defining an open access section to the same chamber 2a. It is configured to make contact at the open section with object 1a, which then overlaps the open section, making chamber 2a essentially sealed.

**[0052]**

Suction cup 2 can define a launch axis 2b defines the axis of overpressure exiting chamber 2a. Preferably the launch axis 2b is perpendicular to said open access section of chamber 2a and suitably passing through the barycenter of said open section.

**[0053]**

The launch axis can be substantially parallel to the axis 4a.

**[0054]**

Suction cup 2 can be made of polymeric and especially elastomeric material. It may be of a known type.

**[0055]**

Gripper 1 includes a pressure regulating apparatus 3 in chamber 2a configured to vary the pressure in chamber 2a preferably at least when object 1 a is in contact with suction cup 2 and in detail overlaps the open section by closing it.

**[0056]**

Regulating apparatus 3 is controllable from unit 10b.

**[0057]**

Regulating apparatus 3 is configured to vary the pressure in chamber 2a in a

**[0064]**

gripping and a launching configuration. Obviously the regulating apparatus 3 varies said pressure through a gas that is preferably air.

**[0058]**

In the gripping configuration, apparatus 3 places chamber 2a in depression (i.e. , at a lower pressure than ambient pressure), allowing suction cup 2 to bind to object 1 a, which can then be moved (Fig. 2b).

**[0059]**

In the launching configuration, the regulating apparatus 3 places chamber 2a in overpressure (i.e., at a higher pressure than ambient pressure), allowing suction cup 2 to release said object 1a. In detail, apparatus 3 allows suction cup 2 to launch object 2a, that is, to impart a force to object 1 a that can accelerate and increase the speed away from suction cup 2 essentially normal to the open section (Fig. 2c).

**[0060]**

Additionally, regulating apparatus 3 can define an intermediate configuration between said gripping and launching configurations in which the pressure of chamber 2a is intermediate to said overpressure and said pressure and in particular substantially equal to the ambient pressure.

**[0061]**

Regulating apparatus 3 may comprise a pump 31 configured to place chamber 2a in depression defining the gripping configuration; a compressor 32 configured to place chamber 2a in overpressure defining the launching configuration; at least one conduit 33 placing pump 31 and compressor 32 in fluid passage connection with chamber 2a, preferably opposite to the open section; and conveniently a valve 34 configured to selectively place only one of pump 31 and compressor 32 in fluid passage connection with chamber 2a. Specifically, it may include a conduit 33 between pump 31 and valve 34, a conduit 33 between compressor 32 and valve 34, and a conduit 33 between valve 34 and chamber 2a.

**[0062]**

Pump 31 and compressor 32 can be integrated into stand 10c and/or robotic arm 10a. Alternatively, the entire regulating apparatus 3 can be separated from the

**[0070]**

support 10c and/or in the robotic arm 10a.

**[0063]**

The valve 34 may include a first gas inlet section in the valve connected to pump 31 and a second gas inlet section in the valve connected to compressor 32; and an outlet section connected to chamber 2a.

**[0064]**

It can define the gripping configuration by placing pump 31 in fluid passage connection with chamber 2a and the launching configuration by placing compressor 32 in fluid passage connection with chamber 2a.

**[0065]**

Preferably it includes a solenoid valve with two inlets (one connected to pump 31 and one to compressor 32) and one outlet (connected to suction cup 2). More preferably, the valve 34 is a magnetically activated solenoid valve and, for example, may include a plunger configured to obstruct only one of said inlet sections by defining one of said configurations, elastic means, appropriately precharged, commanding passage in one configuration (e.g., gripping configuration where the plunger obstructs the second inlet section) and a solenoid configured to emit a magnetic field, in opposition to said elastic means, controlling passage to the other configuration (e.g., launching configuration where the plunger obstructs the first inlet section).

**[0066]**

Valve 34 and thus regulating apparatus 3 can define a transition time between said configurations conveniently less than 100 ms and in detail 50 ms.

**[0067]**

Valve 34 and particularly regulating apparatus 3 can define a launch time, that is, a time when valve 34 is in launching configuration and compressor 31 is active. The launch time can be substantially less than 500 ms and in detail 300 ms.

**[0068]**

Preferably, the launch time is determined, appropriately by unit 10b, as a function of the weight of object 1a and particularly the depression of chamber 2a. More preferably it is directly proportional to the weight of object 1a and in particular to the

**[0077]**

depression of chamber 2a (i.e. , the depression to be applied to the chamber to lift object 1 a). For example, the launch time may be 300-250 ms for objects weighing about 400-500 g and 80-100 ms for objects 1 a weighing about 20-30 g.

**[0069]**

Gripper 1 can include a handle 4 configured to allow gripping and thus handling of gripper 1 .

**[0070]**

At least part of conduit 33 can be integrated into handle 4.

**[0071]**

The handle 4 can be bound rigidly to the suction cup 2.

**[0072]**

It can define an appropriately barycentric longitudinal axis 4a.

**[0073]**

The longitudinal axis 4a can be substantially perpendicular to the open section.

**[0074]**

Handle 4 can have axial extension, that is, along the longitudinal axis 4a, substantially at least 5 cm, and in detail substantially between 5 cm and 20 cm.

**[0075]**

Gripper 1 can be in data connection with unit 10b, which then can control the gripper and especially apparatus 3.

**[0076]**

The handling device 10 may include an object database associating with each object 1 a an identifier of said object 1a and object characteristics such as: weight, shape, barycenter, and mass distribution. The identifier can be the shape, i.e., the outline of object 1 a or a code, e.g., an alphanumeric code, given on object 1 a.

**[0077]**

The handling device 10 may include a site database associating with each collection site 1 b an object 1a to be placed in said collection site 1 b, a supplementary identifier of said collection site 1 b, and preferably at least the external profile of said collection site 1 b and in particular the introduction section of said object 1 a into said collection site 1 b. The additional identifier may be optical, such as a bar code.

**[0078]**

Device 10 may include a storage memory of said site database and/or said object database.

**[0079]**

Device 10 may include an acquisition system 10d.

**[0089]**

System 10d can be in data connection with the unit 10c that therefore controls its operation and/or receives its acquisitions.

**[0080]**

Acquisition system 10d can be bound to robotic arm 10a (preferably placed at the level of gripper 1 ); and/or bound to gripper 1 for example on the handle 4 near suction cup 2 (Fig. 1 ); and/or not bound to the arm 10a and, for example placed in the room where sites 1 b and 1 c are located.

**[0081]**

It can be configured to perform at least one acquisition of at least one object 1a and/or one site 1 b and/or 1 c. Preferably said acquisition is optical, and thus the system 10d may include at least one suitably three-dimensional camera.

**[0082]**

The acquisition system 10d can be configured to perform at least one acquisition of object 1 a.

**[0083]**

Said at least one acquisition of object 1a can be used to identify object 1 a and, for example, define the shape of object 1 a. Alternatively and/or additionally, the acquisition system 10d can be configured to perform at least one acquisition of object 1 a, for example when placed at the picking site 1 c, so that the location of object 1 a to be picked up can be identified.

**[0084]**

In this document the term location is preferably to be identified with respect to a single reference system and then in the coordinates with respect to that system. The reference system can be referable to the acquisition system 10c and/or gripper 1. Accordingly, the pickup position identifies the position of object 1 a, in detail of its center of mass, relative to the acquisition system 10c or gripper 1 .

**[0085]**

The acquisition system 10d can be configured to perform a pickup acquisition, that is, an acquisition of object 1a when gripped by gripper 1. Therefore, it defines the pickup position of object 1 a, that is, the position of object 1 a relative to suction cup 2 and to be precise the center of mass (also commonly referred to as the barycenter)

**[0096]**

of object 1 a relative to the launch axis 2b.

**[0086]**

Alternatively, it can be realized by device 10 for at least one acquisition of object 1a (in detail multiple acquisitions of object 1a performed from distinct acquisition points so as to have the shape of object 1 a) and preferably the mass distribution (density). In this case, the barycenter can be determined by assuming a uniform mass distribution and thus making the center of mass coincide with the geometric barycenter of object 1a. Alternatively, the mass distribution can be defined by the operator.

**[0087]**

The location of collection site 1 b may be a function of location acquisition. It can identify the location of the introduction section and in detail the barycenter of that section. This parameter can be determined according to the location acquisition.

**[0088]**

The acquisition system 10d can be configured to perform a location acquisition, i.e. , an acquisition of collection site 1 b (in detail, of the additional identifier) and thus allow unit 10b to identify collection site 1 b and thus the location of collection site 1 b, in detail, of the introduction section and, more in detail, of the barycenter of the section.

**[0089]**

In detail, the 10d acquisition system can be configured to perform a launch acquisition defining the launch location, that is, the location of object 1 a taken by the gripper and/or gripper 1 gripping object 1 a at the time of launch. As a result, unit 10b is configured to determine the position of gripper 1 according to location acquisition.

**[0090]**

Alternatively, the position of gripper 1 can be defined according to the position of the robotic arm 10a and in particular of one or more bodies 11 .

**[0091]**

Unit 10b is configured to determine the launch trajectory of object 1 a from gripper 1 to site 1 b in detail at the introduction section and more in detail at the barycenter of

**[0103]**

the section.

**[0092]**

The launch trajectory can be defined as a function of one or more launch parameters appropriately chosen from at least one of the following: overpressure intensity, inclination of launch axis 2b, launch time, collection site 1 location, pickup position, and launch location. Preferably it is defined as a function of all of said data.

**[0093]**

The intensity of the overpressure defines the magnitude of the force that gripper 1 applies to object 1 a in the launching configuration to allow object 1 a to execute the trajectory. It can be determined as a function of object 1 a and, for example, the weight of object 1 a and particularly the depression of chamber 1 a.

**[0094]**

Launch time defines how long the chamber stays in overpressure. It can be determined as a function of object 1 a and, for example, the weight of object 1 a and particularly the depression of chamber 1 a.

**[0095]**

The location of collection site 1 b may be a function of location acquisition. It can identify the location of the introduction section and in detail the barycenter of that section. This parameter can be determined according to the location acquisition.

**[0096]**

The launch location identifies the location of object 1 a and/or gripper 1 (in detail, of suction cup 2) at the time of launch. This parameter can be determined according to the launch acquisition.

**[0097]**

It should be noted that the launch parameters (launch location, launch axis 2b and intensity) can be determined depending on the other launch parameters and technical characteristics (e.g. maximum overpressure identifiable by the maximum pressure that can be exerted by compressor 32). Moreover, they influence each other, therefore they can be determined, for example, by keeping one or more of them fixed (e.g. assuming to always use the maximum overpressure).

**[0098]**

Launch parameters can be given in a launch database associating each object 1a

**[0111]**

with one or more launches each defining applied overpressure, inclination of the launch axis, pickup position, relative location (i.e. , distance) between launch location of object 1a and preferably the path taken by object 1a during the launch. For this purpose, the acquisition system 10d can be configured to perform at least one launch acquisition, i.e., an acquisition of said path.

**[0099]**

More preferably, unit 10b can be an artificial intelligence and in particular of the "machine learning" type so that the unit itself can define, based on the launch database (i.e., the launch history of an object 1 a), the parameters of the launch trajectory and thus correct any trajectory errors.

**[0100]**

The operation of the vacuum gripper 1 and then of the handling device 10 previously described in structural terms define a new process 100 of placing objects in the corresponding collection site 1 b.

**[0101]**

Process 100 is controllable from unit 10b.

**[0102]**

The placing process 100 may include a setup phase 110 of the vacuum gripper 1 and particularly the handling device 10.

**[0103]**

In the setup phase 110, an object database can be defined associating each object 1 a with one or more physical-mechanical characteristics of the object. In particular, it associates each object 1a with the shape of object 1 a and preferably the position of the center of mass of object 1 a.

**[0104]**

The object database can be defined by the operator and then stored on unit 10b. Alternatively, it can be realized by device 10 for at least one acquisition of object 1a (in detail multiple acquisitions of object 1a performed from distinct acquisition points so as to have the shape of object 1 a) and preferably the mass distribution (density). In this case, the barycenter can be determined by assuming a uniform mass distribution and thus making the center of mass coincide with the geometric

**[0118]**

barycenter of object 1a. Alternatively, the mass distribution can be defined by the operator.

**[0105]**

Said acquisitions from distinct acquisition points can be made until a complete view of object 1 a is obtained. For example, gripper 1 picks up object 1 a at a gripping point of object 1 a; the acquisition system 10d acquires a first part of object 1 a; and then gripper 1 rests object 1 a on a surface and picks it up at a different grasping point so that the acquisition system 10d can acquire a different part of object 1 a and eventually obtain an acquisition of the whole shape of object 1 a.

**[0106]**

In the acquisition(s) (at least one) of object 1a the identifier of said object 1 a is also acquired and therefore the object database is updated by associating the identifier of said object 1a to the shape and barycenter of object 1 a.

**[0107]**

In addition or as an alternative in setup phase 110, a location acquisition can be performed for each site 1 b, so that unit 10b can identify one or more collection sites 1 b and more appropriately the location of each site 1 b. Preferably unit 10b defines in accordance with said acquisition the introduction section and more in detail at the barycenter of the section of each site.

**[0108]**

In each location acquisition, the additional identifier of said collection site 1 b may be acquired. Therefore, unit 10b can define a site database by associating with each acquired site 1 b an additional identifier of said collection site 1 b and preferably at least the external profile of site 1 b and in particular the introduction section of said object 1 a in site 1 b.

**[0109]**

In addition, the operator can associate sites in the database by associating each site 1 b with an object 1a to be arranged in said collection site 1 b.

**[0110]**

The process 100 may include a taking phase 120 of an object 1 a.

**[0111]**

In this phase, gripper 1 picks up an object 1 a appropriately selected by the operator

**[0126]**

and/or unit 10b (e.g., by selecting the closest to gripper 1 ).

**[0112]**

In this taking phase 120 the gripper 11 , appropriately moved by the robotic arm 10a, approaches the object 1 a and then goes into gripping configuration. In detail, it comprises an initial subphase 121 in which the acquisition system 10d performs an acquisition of object 1 a (in detail of at least the identifier of object 1 a) and preferably of object 1 a at the picking site 1 c; a search subphase 122 in which the unit 10b identifies in the object database the object 1 a by associating with said identifier and thus with the object 1 a shape and barycenter; an approaching subphase 123 in which the gripper 11 , appropriately moved by the robotic arm 10a in accordance with said position, approaches the object 1a preferably arranging the axis; a pickup subphase 124 in which, in accordance with said shape and barycenter, the unit 10b commands, appropriately from the intermediate configuration, the transition to the gripping configuration (i.e., the depression of the chamber 1a) and thus the lifting of the object 1 a.

**[0113]**

Preferably in the approaching subphase 123, thanks to the acquisition system 10d, gripper 11 approaches object 1a by arranging the launch axis 2b incident to the center of mass.

**[0114]**

In the search subphase 122, unit 10b can identify the mass distribution and thus, according to the shape, the weight of object 1 a, and then in the pickup subphase 124, unit 10b controls the depression of chamber 1 a according to the weight of object 1 a.

**[0115]**

It is to be noted that the taking phase may include a verification subphase 125 in which, appropriately in accordance with the object database, a launch acquisition is performed and it is verified that the launch axis 2b is incident to and thus passing through the center of mass of object 1 a. If the launch axis 2b is not incident to the

**[0131]**

center of mass, unit 10b commands the release of object 1a (appropriately by switching to intermediate configuration) and then the execution of at least one new approaching subphase 123 and pickup subphase 124.

**[0116]**

The handling process may include a determination phase 130 to determine the launch trajectory.

**[0117]**

In this determination phase 130, unit 10b determines the above-described launch parameters and thus the launch trajectory in accordance with object 1 a (weight and pickup position) and collection site 1 b (location of site 1 b).

**[0118]**

Determination phase 130 includes a collection site 1 b selection subphase 131 in which, in accordance with the site database, collection site 1 b is selected in which to store object 1 a; a detection subphase 132 of the relative position between collection site 1 b and object 1 a gripped by the gripper; and a determination subphase 133 in which unit 10b determines the described launch parameters and thus the launch trajectory.

**[0119]**

In the detection subphase 132, the acquisition system 10d performs a location acquisition allowing the location of site 1 b to be identified relative to that of gripper 1 and thus object 1 a.

**[0120]**

In the determination subphase 133, the launch parameters are defined according to the launch database, and then the launch trajectory required to launch object 1 a at collection site 1 b is determined. Specifically, applied overpressure, inclination of launch axis 2b, relative position between launch position of object 1 a (i.e. launch position) are chosen depending on object 1 a and position of collection site 1 b.

**[0121]**

The process 100 may include a launch phase 140 of the object 1 a at the collection site 1 b appropriately in accordance with the launch parameters preferably calculated in subphase 133.

**[0138]**

The 140 phase may include a positioning subphase 141 in which gripper 1 , appropriately moved by robotic arm 10a, brings object 1 a into launch position with the desired launch axis 2a; a transition subphase 142 in which gripper 1 goes into launch configuration placing chamber 2a in the desired overpressure; a boost subphase 143 in which gripper 1 maintains chamber 2a at the desired overpressure; and optionally a deactivation subphase 144 in which gripper 1 goes into intermediate configuration.

**[0122]**

The duration of the transition subphase 142 can be equal to the transition time.

**[0123]**

The duration of the boost subphase 143 can be equal to the launch time.

**[0124]**

The vacuum gripper 1 and thus the robot 10 according to the invention achieves important advantages.

**[0125]**

In fact, gripper 1 , by performing object launch 1 a, allows minimizing and thus speeding up the handling process to transport an object 1 a to the collection site 1 b. This advantage makes it possible to perform handling of object 1 a using robotic arms 10a that are simple in construction and implementation and therefore have reduced costs.

**[0126]**

In addition, gripper 1 makes it possible to remove all the inconveniences associated with the handling of the robotic arm 10a and especially to simplify the discrimination between different collection sites 1 a.

**[0127]**

The invention is susceptible of variants falling within the scope of the inventive concept defined by the claims. In this context, all the details can be replaced by equivalent elements and any materials, shapes and dimensions can be used.

## Classifications

- B25J15/0658
- B25J15/06
- B25J19/02
- B25J19/023
- B25J9/16
- B25J9/1697
- B65G47/91
- B65G47/917

## Cited patent documents

- [DE-102021208180-A1](https://patents.google.com/patent/DE102021208180A1/en) — ISR
- [EP-4063082-A1](https://patents.google.com/patent/EP4063082A1/en) — ISR
- [US-2021009351-A1](https://patents.google.com/patent/US20210009351A1/en) — ISR
- [US-2021300691-A1](https://patents.google.com/patent/US20210300691A1/en) — ISR
- [US-2023070495-A1](https://patents.google.com/patent/US20230070495A1/en) — ISR

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
