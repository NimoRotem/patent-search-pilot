# 48. Vorrichtung zur Halterung von Werkstuecken

- **Archive rank:** 48 of 50
- **Publication:** [DE-1291698-B](https://patents.google.com/patent/DE1291698B/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/007520855/publication/DE1291698B?q=pn%3DDE1291698B)
- **Publication date:** 1969-03-27
- **Filing date:** 1965-06-14
- **Earliest priority:** 1965-06-14
- **Family:** 7520855
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** SIEMENS AG
- **Inventors:** FRIEDRICH FREY; HANS GLOCKNER; HEINZ KIMPFLINGER

## Abstract

_No abstract was available from the queried sources._

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-1291698-B/ops000.png)

![Sketch 1 for DE-1291698-B](https://nimo.iptorch.com/refdrawing/DE-1291698-B/ops000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-1291698-B/ops001.png)

![Sketch 2 for DE-1291698-B](https://nimo.iptorch.com/refdrawing/DE-1291698-B/ops001.png)

## Claims

### Claim 1 (independent)

Vorrichtung zur Halterung von Werkstücken mit an einer porösen, luftdurchlässigen Auflagefläche erzeugtem Unterdruck, dadurch ao gekennzeichnet, daß die Auflagefläche für das Werkstück (19, 24) Teil eines aus gesintertem Material bestehenden porösen Körpers (4,13,16, 22) ist.1. Device for holding workpieces with a porous, air-permeable Support surface generated underpressure, characterized ao that the support surface for the workpiece (19, 24) part of a porous body (4,13,16, 22) is.

### Claim 2

Vorrichtung nach Anspruch 1, dadurch gekennzeichnet, daß der poröse Körper aus keramischem Material gesintert ist.2. Apparatus according to claim 1, characterized in that the porous body made of ceramic Material is sintered.

### Claim 3

Vorrichtung nach Anspruch 1, dadurch gekennzeichnet, daß der poröse Körper aus einer Chrom-Nickel-Verbindung gesintert ist.3. Apparatus according to claim 1, characterized in that the porous body consists of a Chromium-nickel compound is sintered.

### Claim 4

Vorrichtung nach den vorhergehenden Ansprüchen, dadurch gekennzeichnet, daß der poröse Körper (4,13,16, 22) teilweise mit luftundurchlässigem Material (z. B. Bleche 20) abgedeckt ist.4. Device according to the preceding claims, characterized in that the porous body (4,13,16, 22) partially with air-impermeable Material (z. B. sheets 20) is covered.

### Claim 5

Vorrichtung nach den Ansprüchen 1 bis 3, dadurch gekennzeichnet, daß der poröse Körper (4,13,16,22) Teil des Mantels einer Unterdruckkammer ist.5. Device according to claims 1 to 3, characterized in that the porous body (4,13,16,22) Part of the shell of a vacuum chamber is.

### Claim 6

Vorrichtung nach den Ansprüchen 1,2,3 und 5, dadurch gekennzeichnet, daß der poröse Körper (z. B. 4) Teil mehrerer unabhängig voneinander evakuierbarer Kammern ist (F i g. 1).6. Device according to claims 1,2,3 and 5, characterized in that the porous Body (z. B. 4) is part of several chambers that can be evacuated independently of one another (FIG. 1).

### Claim 7

Vorrichtung nach Anspruch 5, dadurch gekennzeichnet, daß mehrere Kammern durch Unterteilung einer größeren Kammer (1) gebildet sind.7. Apparatus according to claim 5, characterized in that several chambers through Subdivision of a larger chamber (1) are formed.

### Claim 8

Vorrichtung nach den Ansprüchen 6 und 7, dadurch gekennzeichnet, daß die Kammern verschließbare Verbindungsöffnungen (7) haben und an ein gemeinsames Vakuum angeschlossen sind.8. Device according to claims 6 and 7, characterized in that the chambers can be closed Have connection openings (7) and are connected to a common vacuum.

### Claim 9

Vorrichtung nach den vorhergehenden Ansprüchen, dadurch gekennzeichnet, daß in der Verbindungsleitung zum Vakuum ein Flüssigkeitsabscheider angeordnet ist.9. Device according to the preceding claims, characterized in that in the A liquid separator is arranged connecting line to the vacuum.

### Claim 10

Vorrichtung nach den Ansprüchen 1 bis 4, dadurch gekennzeichnet, daß die Oberfläche des porösen Körpers (z.B. 22) teilweise mit abnehmbaren, luftundurchlässigen Blechen (20), Folien (23) od. dgl. abgedeckt ist (Fig. 4 und 5).10. Device according to claims 1 to 4, characterized in that the surface of the porous body (e.g. 22) partially with removable, air-impermeable sheets (20), Foils (23) or the like. Is covered (Fig. 4 and 5). Hierzu 1 Blatt Zeichnungen1 sheet of drawings

## Full description

PERFORMING OPERATIONS; TRANSPORTINGHAND TOOLS; PORTABLE POWER-DRIVEN TOOLS; MANIPULATORSTOOLS OR BENCH DEVICES NOT OTHERWISE PROVIDED FOR, FOR FASTENING, CONNECTING, DISENGAGING, OR HOLDINGWork holders not covered by any preceding group in the subclass, e.g. magnetic work holders, vacuum work holdersVacuum work holders

Description

Translated from German

1 21 2

Die Erfindung betrifft eine Vorrichtung zur gesintertes Material durch seine mit dem bloÃen

Halterung von WerkstÃ¼cken mit an einer porÃ¶sen, Auge nicht mehr wahrnehmbare Feinporigkeit einerluftdurchlÃ¤ssigen

AuflageflÃ¤che erzeugtem Unter- seits hohe AnsaugkrÃ¤fte ermÃ¶glicht und andererseits

druck. bei nicht vollstÃ¤ndiger Bedeckung des porÃ¶senThe invention relates to a device for sintering material through its with the bare

Holding of workpieces with a porous, eye no longer perceptible fine pores of an air-permeable

Support surface generated on the underside enables high suction forces and on the other hand

pressure. if the porous is not completely covered

Derartige Vorrichtungen werden ebenso wie 5 KÃ¶rpers kaum den in der Vorrichtung erzeugten

magnetische Haltevorrichtungen verwendet, wenn Unterdruck entweichen lÃ¤Ãt. SchlieÃlich wirkt dieser

empfindliche WerkstÃ¼cke zur Bearbeitung mecha- porÃ¶se KÃ¶rper gegenÃ¼ber dem WerkstÃ¼ck, auch

nisch nur schlecht oder Ã¼berhaupt nicht eingespannt gegenÃ¼ber sehr kleinen und sehr dÃ¼nnen Werkwerden

kÃ¶nnen, oder aber, wenn beispielsweise bei stÃ¼cken, als ununterbrochene und unnachgiebige

einer Vielzahl von relativ kleinen WerkstÃ¼cken der io Auflage. Die WerkstÃ¼cke erhalten also an nahezu

Spannvorgang fÃ¼r die Bearbeitung bereits rationali- jedem Punkt ihrer Auflagestelle eine UnterstÃ¼tzung

siert werden muÃ. Daneben werden solche Vor- durch das Gegenlager, womit eine elastische Verrichtungen

benÃ¶tigt, um empfindliche WerkstÃ¼cke, formung durch den Unterdruck unmÃ¶glich wird. Mit

wie beispielsweise optische GlÃ¤ser oder Schwing- relativ geringem Unterdruck kÃ¶nnen mit einem

quarze in MeÃ- oder PrÃ¼fgerÃ¤ten, zu halten. 15 derartigen porÃ¶sen KÃ¶rper WerkstÃ¼cke fÃ¼r jede ArtSuch devices, like bodies, are hardly those produced in the device

Magnetic holding devices used when negative pressure escapes. After all, this one works

sensitive workpieces for machining mecha- porous bodies opposite the workpiece, too

nisch only badly or not at all clamped in relation to very small and very thin works

can, or, if, for example, with pieces, as uninterrupted and unyielding

a large number of relatively small workpieces of the io edition. The workpieces thus receive almost

Clamping process for the machining already rational - every point of your support point a support

must be ized. In addition, such forward through the counter-bearing, with which an elastic doings

required to handle sensitive workpieces, forming becomes impossible due to the negative pressure. With

such as optical glasses or vibrating - relatively low negative pressure can be used with a

to keep crystals in measuring or testing devices. 15 such porous body workpieces for each type

Es ist bekannt, an der Auflage- oder HalteflÃ¤che von Bearbeitung gehalten werden. Die Vermeidung

von WerkstÃ¼cken den Unterdruck so zu erzeugen, von groÃen Ãffnungen bringt dabei noch den

daÃ eine Seite eines evakuierbaren BehÃ¤lters, die mit weiteren Vorteil mit sich, daÃ das WerkstÃ¼ck keineseiner

Bohrung versehen ist, das Gegenlager fÃ¼r das falls eine BeschÃ¤digung durch irgendwelche Ãff-WerkstÃ¼ck

bildet. Durch Erzeugung eines Vakuums 20 nungskanten erfahren kann.It is known to be held on the support or holding surface by machining. Avoidance

To generate the negative pressure of workpieces in such a way, of large openings still brings the

that one side of an evacuable container, which entails the further advantage that the workpiece is not one

Bore is provided, the counter bearing for the case of damage by any open workpiece

forms. By creating a vacuum 20 can experience voltage edges.

im BehÃ¤lter wird das WerkstÃ¼ck Ã¼ber den Bereich Die erfindungsgemÃ¤Ãe Vorrichtung kann dabeiIn the container, the workpiece is over the area. The device according to the invention can thereby

des Bohrungsquerschnittes fest an das Gegenlager ohne weiteres dem jeweiligen Bearbeitungsvorgang

herangezogen und kann nunmehr bearbeitet werden, angeglichen werden. So ist es mÃ¶glich, einen porÃ¶sen

es ist hierbei jedoch von Nachteil, daÃ sehr dÃ¼nne KÃ¶rper als Futter in DrehbÃ¤nken zu verwenden,

WerkstÃ¼cke, wie sie beispielsweise beim Quarz- 25 deren Spindelhohlraum als Unterdruckleitung dient,

schleifen gehalten werden mÃ¼ssen, durch derartige PlattenfÃ¶rmige KÃ¶rper kÃ¶nnen als Auflage fÃ¼r

Vorrichtungen im Bereich des Bohrungsquerschnittes FrÃ¤s- und SchleifvorgÃ¤nge dienen, wÃ¤hrend KÃ¶rper

elastisch verformt werden kÃ¶nnen, so daÃ genaue mit DurchbrÃ¼chen, gegenÃ¼ber denen die Unterdruck-Bearbeitungen

oder Messungen nicht mehr mÃ¶glich behÃ¤lter abgesichert sind, WerkstÃ¼cke zum Bohren

sind. 30 oder fÃ¼r andere Innenbearbeitungen halten kÃ¶nnen.of the bore cross-section firmly to the counter bearing easily the respective machining process

used and can now be edited, adjusted. So it is possible to have a porous

However, it is disadvantageous here that very thin bodies have to be used as chucks in lathes,

Workpieces, such as those used in the quartz 25 whose spindle cavity serves as a vacuum line,

must be kept grinding, by such plate-shaped body can be used as a support for

Devices in the area of the bore cross-section are used for milling and grinding processes, while bodies

can be elastically deformed, so that accurate with openings, against which the vacuum machining

or measurements are no longer possible containers are secured, workpieces for drilling

are. 30 or for other internal machining.

Es ist weiterhin eine auf dem Ansaugprinzip be- Insbesondere sind Haltevorrichtungen jeder Art und

ruhende Haltevorrichtung bekannt, bei welcher auf Form in MeÃ- und PrÃ¼fgerÃ¤ten mÃ¶glich, da sie dort

einer perforierten Metallplatte, die einen evakuier- erforderlichen geringen HaltekrÃ¤fte auch aufgebracht

baren BehÃ¤lter begrenzt, eine elastische, luftdurch- werden kÃ¶nnen, wenn Ausformungen des porÃ¶sen

lÃ¤ssige Filzschicht aufgebracht ist, auf welcher 35 KÃ¶rpers, wie Zapfen, RandwÃ¼lste od. dgl., Ã¼ber

Filzschicht ein Schmirgelpapier angesaugt und ge- lÃ¤ngere Wege als Unterdruckleitung dienen,

halten wird. Hierbei ist jedoch von grÃ¶Ãter Wichtig- In vielen FÃ¤llen zweckmÃ¤Ãig kann ein ausIt is also based on the principle of suction. In particular, holding devices of all types are

stationary holding device known, in which on form in measuring and testing devices possible, since they are there

a perforated metal plate, which also applied a low holding force required for evacuation

Bare container limited, an elastic, air can be penetrated if formations of the porous

casual felt layer is applied, on which 35 body, such as cones, edge beads od. The like., About

A layer of felt sucked in an emery paper and used as a vacuum line for longer distances,

will hold. Here, however, it is of the utmost importance- In many cases it can be expedient to use a

keit, daÃ die Zusammenstellung Filzschichtâ keramischem Material . gesinterter porÃ¶ser KÃ¶rper

Schmirgelpapier rundum abgedichtet ist, was mit sein. Die auÃerordentlich harte OberflÃ¤che, die groÃe

einer Gummimanschette geschieht, so daÃ die Filz- 40 Biegefestigkeit und die WiderstandsfÃ¤higkeit gegenschicht

an keiner Stelle frei liegt. Ein auch nur Ã¼ber SÃ¤uren und anderen chemischen Verbindungen

teilweises Freiliegen der Filzschicht wÃ¼rde die Saug- kann sich vorteilhaft auf die Lebensdauer einer erwirkung

praktisch aufheben. AuÃerdem wird der zu findungsgemÃ¤Ãen Vorrichtung auswirken,

halternde KÃ¶rper durch das Aufliegen auf einer Nach einer besonders bevorzugten AusfÃ¼hrungsnachgiebigen

Filzschicht elastisch verformt. 45 form kann der porÃ¶se KÃ¶rper aus einer Chrom-ability that the compilation felt layer - ceramic material. sintered porous body

Sandpaper is sealed all around what to be with. The extraordinarily hard surface, the big one

a rubber sleeve happens, so that the felt 40 flexural strength and resistance counter-layer

is not exposed at any point. One also just about acids and other chemical compounds

Partial exposure of the felt layer would reduce the suction and can have a beneficial effect on the service life

practically cancel. In addition, the device according to the invention will have an effect

holding body by resting on a flexible according to a particularly preferred embodiment

Felt layer elastically deformed. 45 shape, the porous body can be made of a chrome

Es ist Zweck der Erfindung, diese Nachteile zu Nickel-Legierung gesintert sein. Das Material hierfÃ¼r

vermeiden und eine Vorrichtung zu schaffen, die das ist rostfrei und von groÃer OberflÃ¤chenhÃ¤rte, durch

WerkstÃ¼ck zwar mit Unterdruck hÃ¤lt, dem WerkstÃ¼ck seine gegenÃ¼ber Keramik gÃ¼nstigeren ElastizitÃ¤tsaber

an jeder Stelle eine unnachgiebige Auflage werte weniger leicht verletzlich und daher vorteilhaft

entgegenhÃ¤lt, deren Form und deren OberflÃ¤chen- 50 bei fast allen BearbeitungsvorgÃ¤ngen einzusetzen,

beschaffenheit mit einfachen Mitteln herstellbar ist. ZweckmÃ¤Ãig kann der porÃ¶se KÃ¶rper teilweise mitIt is the purpose of the invention to sinter these drawbacks to nickel alloy. The material for this

avoid and create a device that is rust-free and of great surface hardness, by

Although the workpiece holds with negative pressure, the workpiece has its elasticity, which is more favorable than ceramics

an unyielding restraint at every point would be less vulnerable and therefore beneficial

opposes using their shape and their surface 50 in almost all machining processes,

texture can be produced with simple means. Appropriately, the porous body can partially

GemÃ¤Ã der Erfindung geschieht dies dadurch, daÃ luftundurchlÃ¤ssigem Material abgedeckt sein. Dies ist

die AuflageflÃ¤che fÃ¼r das WerkstÃ¼ck Teil eines aus dann von Vorteil, wenn nicht alle OberflÃ¤chengesintertem

Material bestehenden porÃ¶sen KÃ¶rpers ist. bereiche als Auflageebene oder als Ansaugebene

Ein derartiges Material hat den besonderen Vor- 55 dienen. Eine derartige Abdeckung durch Folien oder

teil, daÃ ohne zusÃ¤tzliche Bearbeitung die gegenÃ¼ber flÃ¼ssig aufgebrachte und ausgehÃ¤rtete Kunststoffe

Luftdruck etwa siebartige Ausbildung des KÃ¶rpers verhindert Verluste der Haltekraft und ermÃ¶glicht es,

entsteht. Dabei sind HerstellvorgÃ¤nge durch Sintern profilierte KÃ¶rper beliebiger Art einerseits an eine

bereits so weit bekannt, daÃ Formteile, wie Platten, Unterdruckleitung anzuschlieÃen und eine beliebige

Stangen od. dgl., schon handelsÃ¼blich zu erhalten 60 Stelle des Profils, die frei von Kunststoff ist, als Aufsind,

wÃ¤hrend die Herstellung von besonderen Form- lageebene zu benutzen.According to the invention, this is done in that air-impermeable material is covered. This is

the support surface for the workpiece is part of an advantage if not all of the surface sintered

Material existing porous body is. areas as a support level or as a suction level

Such a material has special advantages. Such a cover by foils or

part that without additional processing, the opposite liquid applied and cured plastics

Air pressure approximately sieve-like formation of the body prevents loss of holding power and enables

arises. In this case, manufacturing processes by sintering profiled bodies of any type are on the one hand to a

Already known so far that molded parts, such as plates, vacuum lines and any

Rods or the like, already commercially available 60 point of the profile, which is free of plastic, as Aufsind,

to use during the manufacture of special mold level.

kÃ¶rpern bei der Kenntnis gewisser Grundvoraus- Ein derartiger KÃ¶rper kann auch Teil des Mantelsbodies with the knowledge of certain basic requirements- Such a body can also be part of the mantle

Setzungen keinerlei Schwierigkeiten bereitet. Ein einer Unterdruckkammer sein. Er kann dabei in

besonderer Vorteil bei der Verwendung eines ge- beliebiger Form in die der Auflageseite des Werksinterten

Materials besteht darin, daÃ die OberflÃ¤che 65 StÃ¼ckes zugewandten Seite des Kammermantels luftdes

porÃ¶sen KÃ¶rpers mit Ã¼blichen Methoden beliebig dicht eingesetzt sein und in seiner GrÃ¶Ãe den zu

geformt und z. B. durch Polieren veredelt werden bearbeitenden WerkstÃ¼cken angepaÃt werden. So erkann.

Weiterhin haben Versuche gezeigt, daÃ ein scheint es beispielsweise auch mÃ¶glich, den porÃ¶senSettlement does not cause any difficulties. Be in a vacuum chamber. He can do this in

particular advantage when using any shape in the contact side of the factory sintered

Material consists in that the surface 65 pieces of the facing side of the chamber jacket is ventilated

porous body can be used as densely as desired with conventional methods and in its size to

shaped and z. B. refined by polishing can be adapted to machining workpieces. So I can.

Furthermore, tests have shown that it also seems possible, for example, to use the porous

3 43 4

KÃ¶rper so zu profilieren, daÃ auch WerkstÃ¼cke, wie F i g. 1 den grundsÃ¤tzlichen Aufbau einer erfinetwa

optische Linsen, mit bestimmten, auf der Auf- dungsgemÃ¤Ãen Haltevorrichtung,

lageseite bereits bearbeiteten Formen gehalten F i g. 2 eine Haltevorrichtung mit mehreren Werkwerden

kÃ¶nnen. stÃ¼ckauflagen,To profile body so that workpieces, such as F i g. 1 the basic structure of an inventive optical lens, with certain, on the holding device according to the invention,

location page already processed shapes kept F i g. 2 can become a multi-work holding device. piece supports,

Von derartigen porÃ¶sen KÃ¶rpern kÃ¶nnen dann 5 F i g. 3 einen Schnitt durch eine HaltevorrichtungOf such porous bodies, 5 F i g. 3 shows a section through a holding device

selbstverstÃ¤ndlich auf einer Seite der Kammer nach F i g. 2,of course on one side of the chamber according to FIG. 2,

mehrere nebeneinander oder hintereinander an- F i g. 4 die Verwendung von Abdeckblechen oderseveral next to each other or one behind the other. 4 the use of cover plates or

geordnet werden, so daÃ auch die Bearbeitung einer Folien an einer Haltevorrichtung,

Vielzahl von WerkstÃ¼cken gleichzeitig mÃ¶glich ist. F i g. 5 eine Haltevorrichtung mit durchbrochenembe arranged so that the processing of a film on a holding device,

Large number of workpieces is possible at the same time. F i g. 5 a holding device with an openwork

Ebenso vorteilhaft kann natÃ¼rlich die Platte eine io Mittelteil.The plate can of course also advantageously have a central part.

ganze Seite der Unterdruckkammer bilden. Je nach In F i g. 1 ist eine Unterdruckkammer 1, beispiels-GrÃ¶Ãe

der Kammer kann damit eine mehr oder weise aus gezogenem Blech, dargestellt. Die Kammer

weniger groÃe Auflageebene durch die Platte ge- ist wannenfÃ¶rmig ausgebildet und an ihrer offenen

bildet werden, die es erlaubt, eine Vielzahl von Seite mit einem verbreiterten Rand 2 versehen, der

WerkstÃ¼cken neben- und hintereinander anzuordnen. 15 eine umlaufende Auflage 3 bildet. Auf dieser ist ein

Etwa auftretende Verluste durch zwischen den plattenfÃ¶rmiger porÃ¶ser KÃ¶rper 4 angeordnet. Seine

WerkstÃ¼cken frei bleibende OberflÃ¤chenteile der AuÃenform wird zweckmÃ¤Ãig dem umlaufenden

Platte, durch die sich der erzeugte Unterdruck auszu- Rand 2 mÃ¶glichst genau angepaÃt und mit Hilfe von

gleichen versucht, kÃ¶nnen durch stetiges Arbeiten der Kitt oder anderen geeigneten Mitteln luftdicht einVakuumpumpe

ausgeglichen werden. 20 gepaÃt werden. Mit Hilfe einer Rohrleitung 5, die zuform whole side of the vacuum chamber. Depending on the In F i g. 1 is a vacuum chamber 1, example size

the chamber can thus be more or less drawn from sheet metal. The chamber

less large support plane through the plate is formed trough-shaped and at its open

be formed, which allows a plurality of pages provided with a widened edge 2, the

Arrange workpieces next to and behind one another. 15 forms a circumferential support 3. On this one is

Any losses that occur due to being arranged between the plate-shaped porous body 4. His

Workpieces remaining free surface parts of the outer form is expediently the circumferential

Plate through which the negative pressure generated is adapted as precisely as possible and with the help of

The same attempted, a vacuum pump can be made airtight by constantly working the putty or other suitable means

be balanced. 20 can be fitted. With the help of a pipe 5 leading to

Sofern es sich um eine Haltevorrichtung handeln einer Vakuumpumpe fÃ¼hrt, kann in der Kammer 1

soll, die eine Vielzahl von unterschiedlichen Werk- ein Unterdruck erzeugt werden, der an der OberstÃ¼cken

abwechselnd zu halten in der Lage ist, er- flÃ¤che der Platte 4 eine Saugwirkung erzeugt,

scheint es besonders vorteilhaft, wenn der porÃ¶se Der Innenraum der Unterdruckkammer 1 ist

KÃ¶rper Teil mehrerer unabhÃ¤ngig voneinander 25 durch ZwischenwÃ¤nde 6 unterteilt. Diese WÃ¤nde, ihre

evakuierbarer Kammern ist. So kann dann je nach Ãffnungen? und die sie verschlieÃenden Schieber8

GrÃ¶Ãe des WerkstÃ¼ckes oder nach Anzahl der Werk- sollen nur schematisch die MÃ¶glichkeit andeuten, die

stÃ¼cke eine oder mehrere von diesen Kammern zur Unterdruckerzeugung auf einen Teilbereich der

Halterung des oder der WerkstÃ¼cke eingeschaltet OberflÃ¤che der Platte, der etwa der GrÃ¶Ãe des Werkwerden.

30 StÃ¼ckes angemessen ist, zu beschrÃ¤nken.If it is a holding device that leads to a vacuum pump, a vacuum can be generated in the chamber 1 which is intended to produce a large number of different workpieces, which is able to hold alternately on the upper pieces, surface a suction effect on the plate 4 generated,

It appears to be particularly advantageous if the porous interior of the vacuum chamber 1 is part of several bodies independently of one another 25 divided by partition walls 6. These walls, their evacuable chambers is. So then depending on the openings? and the closing slide8 size of the workpiece or according to the number of work pieces are only intended to schematically indicate the possibility of using one or more of these chambers to generate negative pressure on a part of the holder of the work piece or pieces of the surface of the plate, which is about the size of the Work. 30 pieces is appropriate.

Eine derartige Kammer kann vorteilhafterweise so F i g. 2 zeigt ebenfalls eine Unterdruckkammer 11Such a chamber can advantageously be shown in FIG. 2 also shows a vacuum chamber 11

gebildet werden, daÃ mehrere Kammern durch Unter- mit einer zur Vakuumpumpe fÃ¼hrenden Saugleitungbe formed that several chambers by lower with a suction line leading to the vacuum pump

teilung einer grÃ¶Ãeren Kammer entstehen. Dabei 12. Die Kammer 11 ist hier nahezu allseits ge-division of a larger chamber. 12. The chamber 11 is here almost on all sides.

kÃ¶nnen die Kammern verschlieÃbare Verbindungs- schlossen und hat nur an ihrer Oberseite mehrerethe chambers can have lockable connection locks and only have several on their upper side

Ã¶ffnungen haben und an ein gemeinsames Vakuum 35 Ã¶ffnungen, in die porÃ¶se KÃ¶rper 13 eingesetzt sind,have openings and to a common vacuum 35 openings into which porous bodies 13 are inserted,

angeschlossen sein. Die geschilderte Ausbildung Eine derartige Anordnung empfiehlt sich fÃ¼r diebe connected. The described training Such an arrangement is recommended for

erlaubt eine beliebige, den Formen der WerkstÃ¼cke Aufnahme einer Vielzahl von WerkstÃ¼cken gleicherallows any shape of the workpieces to be accommodated for a large number of workpieces of the same type

angepaÃte Einschaltung der verschiedenen Kammern Form und ist besonders geeignet, wenn die Werk-adapted switching of the various chambers shape and is particularly suitable when the work

und damit eine individuelle Halterung jedes Werk- stÃ¼ckauflage keine ebene FlÃ¤che sein soll, sondernand so that an individual holder for each workpiece support should not be a flat surface, but rather

StÃ¼ckes. 40 eine dem WerkstÃ¼ckprofil angepaÃte ProfilierungPiece. 40 a profiling adapted to the workpiece profile

ZweckmÃ¤Ãigerweise kann in der Verbindungs- haben soll.Conveniently, should have in the connection.

leitung zum Vakuum ein FlÃ¼ssigkeitsabscheider an- F i g. 3 zeigt einen Teilschnitt durch diese Angeordnet

werden. Damit ist es mÃ¶glich, die er- Ordnung. Die Unterdruckkammer 11 hat an ihrer

findungsgemÃ¤Ãe Vorrichtung auch fÃ¼r Bearbeitungs- Oberseite fÃ¼r jeden porÃ¶sen KÃ¶rper eine topfartige

vorgÃ¤nge unter Ãl oder Wasser zu verwenden. 45 Vertiefung 14, deren Boden durchbrochen ist undline to the vacuum a liquid separator at- F i g. 3 shows a partial section through this arrangement

will. With this it is possible to order the order. The vacuum chamber 11 has on her

inventive device also for machining top for each porous body a pot-like

operations under oil or water. 45 recess 14, the bottom of which is perforated and

Bei einzelnen FertigungsvorgÃ¤ngen, hauptsÃ¤chlich nur eine Randauflage 15 fÃ¼r die porÃ¶sen KÃ¶rper 16In the case of individual manufacturing processes, mainly only one edge support 15 for the porous body 16

bei Grobbearbeitungen erscheint es vorteilhaft, die bildet. Die OberflÃ¤che der porÃ¶sen KÃ¶rper 16, die alsin the case of rough machining, it seems advantageous to use the form. The surface of the porous body 16, which as

durch die geometrische Form des WerkstÃ¼ckes, die WerkstÃ¼ckauflage dient, ist hier nur beispielsweiseDue to the geometric shape of the workpiece, the workpiece support is used here is only an example

den Formen der Kammern nicht immer entspricht, konkav zugeschliffen, so daÃ sie fÃ¼r die Auflage vondoes not always correspond to the shapes of the chambers, ground concave so that they are suitable for the edition of

entstehenden Luftverluste zu unterbinden. HierfÃ¼r 50 einseitig bereits fertigen optischen Linsen dienento prevent resulting air losses. For this purpose 50 optical lenses already finished on one side are used

kann die Platte zweckmÃ¤Ãigerweise mit aus- kÃ¶nnen.can expediently be able to with the plate.

wechselbaren undurchlÃ¤ssigen Blechen, Folien F i g. 4 zeigt die Draufsicht auf eine runde Unter-exchangeable impermeable sheets, foils F i g. 4 shows the top view of a round bottom

od. dgl. abgedeckt werden. Auf diese Weise wird druckkammer 18, deren gesamte OberflÃ¤che mitor the like. Be covered. In this way, pressure chamber 18, its entire surface with

der letzte Rest des Ausgleiches zwischen Normal- Ausnahme des Randes von einem ebenen porÃ¶senthe last remainder of the balance between normal except the edge of a flat porous

druck und Vakuum verhindert und die Haltekraft 55 KÃ¶rper gebildet wird. Um ein WerkstÃ¼ck 19 mit sehrpressure and vacuum are prevented and the holding force 55 body is formed. To a workpiece 19 with very

verbessert. viel geringerer OberflÃ¤che sicher halten zu kÃ¶nnen,improved. to be able to hold a much smaller surface safely,

Nach Beendigung des Bearbeitungsvorganges sind hier dÃ¼nne Kunststoffolien oder Bleche 20 der-After completion of the machining process, thin plastic films or sheets 20 of the

kÃ¶nnen die WerkstÃ¼cke, auch sehr dÃ¼nne Werk- art zugeschnitten, daÃ sie die von dem WerkstÃ¼ckthe workpieces, even very thin work-pieces, can be cut to suit the workpiece

stÃ¼cke, leicht wieder von der Halteebene abgehoben nicht benutzte FlÃ¤che des porÃ¶sen KÃ¶rpers luftdichtpieces, slightly lifted again from the holding plane unused area of the porous body airtight

werden, wenn in dem evakuierbaren BehÃ¤lter ein 60 abdecken.if a 60 cover in the evacuable container.

Ãberdruck erzeugt wird. Dies bringt auch fÃ¼r die F i g. 5 zeigt schlieÃlich ein Beispiel, wie der porÃ¶seOverpressure is generated. This also brings with it the F i g. 5 finally shows an example of how the porous

Reinigung der AuflageflÃ¤che Vorteile mit sich, da KÃ¶rper auch Ã¼ber grÃ¶Ãere Entfernungen praktisch alsCleaning the contact surface has advantages, since the body is also practical over greater distances than

durch Erzeugen eines Ãberdruckes eventuell in die Fortsetzung der Saugleitung benutzt werden kann.can possibly be used in the continuation of the suction line by generating an overpressure.

Poren eingedrungene Verunreinigungen wieder her- Der UnterdruckbehÃ¤lter in dieser Anordnung ist einThe vacuum tank in this arrangement is a

ausgedrÃ¼ckt und leicht abgewischt werden kÃ¶nnen. 65 Ring 21 mit etwa U-fÃ¶rmigem, nach innen offenemsqueezed out and easily wiped off. 65 ring 21 with an approximately U-shaped, inwardly open

Weitere Einzelheiten der Erfindung kÃ¶nnen den im Profil. Ein scheibenfÃ¶rmiger porÃ¶ser KÃ¶rper 22 ist soFurther details of the invention can be found in the profile. A disk-shaped porous body 22 is such

folgenden dargestellten AusfÃ¼hrungsbeispielen ent- in den Ring eingesetzt, daÃ um seine zylinderfÃ¶rmigethe following illustrated embodiments ent- used in the ring that around its cylindrical

nommen werden. Es zeigt MantelflÃ¤che ein Luftraum verbleibt. Bei Erzeugenbe taken. It shows outer surface an air space remains. When generating

eines Vakuums an der mit V bezeichneten AnsaugÃ¶ffnung

wird also an der gesamten MantelflÃ¤che des porÃ¶sen KÃ¶rpers angesaugt. Damit entsteht ein

Vakuum an allen dem Normaldruck gegenÃ¼berliegen- ^ den FlÃ¤chen des porÃ¶sen KÃ¶rpers. Teile dieser '5

FlÃ¤chen sind durch Folien 23 abgedeckt, um zu groÃe Verluste zu verhindern. Das WerkstÃ¼ck 24

wird nun auf einer Seite des porÃ¶sen KÃ¶rpers gehalten. Eine Ã¶ffnung 25 in dem porÃ¶sen KÃ¶rper,

deren GrÃ¶Ãe in weiten Grenzen variabel ist, erlaubt es beispielsweise, das WerkstÃ¼ck von zwei Seiten zu

bearbeiten. Im vorliegenden Fall dient die Vorrichtung zur Halterung des WerkstÃ¼ckes 24, eines

Schwingquarzes, in einer optischen MeÃvorrichtung.a vacuum at the suction opening labeled V is thus sucked in on the entire surface of the porous body. This creates a vacuum on all surfaces of the porous body opposite to normal pressure. Parts of these areas are covered by foils 23 in order to prevent excessive losses. The workpiece 24 is now held on one side of the porous body. An opening 25 in the porous body, the size of which is variable within wide limits, makes it possible, for example, to machine the workpiece from two sides. In the present case, the device is used to hold the workpiece 24, an oscillating crystal, in an optical measuring device.

## Classifications

- B25B11/005
- B25B11/00

## Cited patent documents

- [DE-1104379-B](https://patents.google.com/patent/DE1104379B/en) — SEA
- [US-2699633-A](https://patents.google.com/patent/US2699633A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
