# 18. Pneumatically actuated area vacuum gripper

- **Archive rank:** 18 of 50
- **Publication:** [US-2010025905-A1](https://patents.google.com/patent/US20100025905A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/041263962/publication/US20100025905A1?q=pn%3DUS20100025905A1)
- **Publication date:** 2010-02-04
- **Filing date:** 2009-07-24
- **Earliest priority:** 2008-07-30
- **Family:** 41263962
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus

## Parties

- **Applicant / assignee:** SCHMALZ J GMBH
- **Inventors:** EISELE THOMAS; GUENTHER ROLF; SCHAAF WALTER; STAHL TOBIAS

## Abstract

A pneumatically actuated area vacuum gripper for gripping and, if necessary, separating workpieces is provided by the present disclosure. In particular, the vacuum gripper is used with thin, flexible workpieces, and has a suction chamber, which has a suction wall with perforations, to be placed on the workpiece. An ejector nozzle has a connection and an outlet, the ejection nozzle being connected to the suction chamber via its connection, and the outlet of the ejector nozzle opening to the outside or into an exhaust air duct, and the suction inlet of the ejector nozzle empties into the suction chamber, whereby the direction of the air stream in the connection coming from the suction chamber corresponds to the direction of the main air conveyance in the ejector nozzle.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/68/93/8d/84fdcd13ea7f60/US20100025905A1-20100204-D00000.png)

![Sketch 1 for US-2010025905-A1](https://patentimages.storage.googleapis.com/68/93/8d/84fdcd13ea7f60/US20100025905A1-20100204-D00000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/cd/98/50/242a97605e8a9f/US20100025905A1-20100204-D00001.png)

![Sketch 2 for US-2010025905-A1](https://patentimages.storage.googleapis.com/cd/98/50/242a97605e8a9f/US20100025905A1-20100204-D00001.png)

## Claims

### Claim 1 (independent)

A pneumatically actuated area vacuum gripper for gripping and, if necessary, separating workpieces, in particular, thin, flexible workpieces, having a suction chamber, which has a suction wall with perforations, to be placed on the workpiece, an ejector nozzle having a connection and an outlet, the ejection nozzle being connected to the suction chamber via its connection, and the outlet of the ejector nozzle opening to the outside or into an exhaust air duct, and the suction inlet of the ejector nozzle empties into the suction chamber, whereby the direction of the air stream in the connection coming from the suction chamber corresponds to the direction of the main air conveyance in the ejector nozzle.

### Claim 2

The area vacuum gripper according to claim 1 , characterized in that the air stream coming from the suction chamber is not redirected after the connection in the ejector nozzle.

### Claim 3

The area vacuum gripper according to claim 1 , characterized in that, when entering the space in the ejector nozzle or when entering the space delimitating the main conveying air stream in the ejector nozzle, the propulsion air or utility air follows a surface that is curved or inclined.

### Claim 4

The area vacuum gripper according to claim 1 , characterized in that the propulsion air or utility air enters the ejector nozzle or the space delimitating the main conveying air stream in the ejector nozzle via a ring-shaped gap.

### Claim 5

The area vacuum gripper according to claim 3 , characterized in that the surface is formed by a radius rotating about an axis.

### Claim 6

The area vacuum gripper according to claim 1 , characterized in that the outlet opening of the suction chamber is connected to the suction inlet of the ejector nozzle and, in particular, arranged coaxially to it.

### Claim 7

The area vacuum gripper according to claim 1 , characterized in that a sensor, e.g. a flow sensor, a vacuum sensor for monitoring the load of the suction wall, and/or an optical sensor for monitoring the load and/or determining the position of the workpiece is, in particular, provided in the suction chamber or at the suction space.

### Claim 8

The area vacuum gripper according to claim 1 , characterized in that the suction chamber is formed by a perforated plate and/or is fastened in an exchangeable manner to the suction chamber.

## Full description

### Cross-Reference To Related Applications

**[p0001]**

This application claims the benefit of German Utility Patent Application No. DE 20 2008 010 424.6 filed Jul. 30, 2008. The disclosure of the above application is incorporated herein by reference.

### Field

**[p0002]**

The present disclosure relates to a pneumatically actuated area vacuum gripper for gripping and, if necessary, separating workpieces, e.g. thin, flexible workpieces.

### Background

**[p0003]**

The statements in this section merely provide background information related to the present disclosure and may not constitute prior art. A device of this type is, for example, known from DE 20 2006 016 833 U1. This known device is a Bernoulli vacuum gripper with a perforated plate into which compressed air is blown via a compressed air duct, and the compressed air leaves the gripper via a large surface in the direction of the workpiece. Although vacuum grippers of this type have the advantage that objects can be suctioned with them, the objects may not be excessively heavy.

### Summary

**[p0004]**

The present disclosure provides an area vacuum gripper with which large-area objects may be suctioned more efficiently, e.g. more reliably, more defined regarding the position, in a more process-safe or energy-efficient manner. According to the present disclosure, this is achieved in one form with an area vacuum gripper of the type mentioned above, having a suction chamber that has a suction wall with perforations to be placed on the workpiece. Moreover, an ejector nozzle is connected to the suction chamber, whereby the outlet of the ejector nozzle opening empties to the outside or into an exhaust air duct and the suction inlet of the ejector nozzle in the suction chamber. With the area vacuum gripper according to the present disclosure, the suction pressure is generated by operating an ejector nozzle with the compressed air. This ejector nozzle thus has an outlet, a suction inlet, as well as a compressed air inlet. A suction chamber is connected to the suction inlet so that there where the work piece abuts, air is suctioned, whereby the workpiece is held firmly, in contrast to the device according to DE 20 2006 016 833 U1, in which air is blown in the direction of the workpiece. This way, wafers, foils, paper, i.e. thin and also flexible objects, may be gripped carefully and separated. The workpieces virtually jump toward the area vacuum gripper and are separated as a result of the suction effect.

**[p0005]**

In one form, the direction of the main air conveyance of the suction air stream in the connection of the ejector nozzle to the suction chamber matches the direction of the main air conveyance of the propulsion air stream in the ejector nozzle. As the suction air stream in the ejector nozzle is not deviated, it receives a high speed pulse. This results from the fact that the propulsion air stream in the connection of the ejector nozzle to the suction chamber is introduced into the main duct of the ejector nozzle where it joins the suction air stream. In another form of the present disclosure, it is provided that the suction chamber has an outlet opening. According to the present disclosure, it is provided on the side opposite the suction wall. The outlet opening may be formed as a bore, the suction wall, for example, being formed by a perforated steel plate. The outlet opening of the suction chamber according to the present disclosure is connected to the suction inlet of the ejector nozzle. In particular, both openings are aligned and in coaxial position to one another in one form of the present disclosure.

**[p0006]**

The suction inlet of the ejector nozzle in one form is formed by the opening of a sleeve-shaped section of the ejector nozzle. The front side of the sleeve-shaped section is arranged spaced apart from the surface of the suction chamber. Thus, there is a ring-shaped duct between the opening of the sleeve-shaped section of the ejector nozzle and the suction chamber. The ring-shaped duct ends in the sleeve-shaped section of the ejector nozzle as well as the outlet opening of the suction chamber. As already mentioned, the sleeve-shaped section of the ejector nozzle according to the present disclosure is surrounded by a ring-shaped duct into which the compressed air inlet also opens, the ring-shaped duct being open in the direction of the suction chamber. The compressed air flows around the sleeve-shaped section in the ring-shaped duct and enters the sleeve-shaped section between its front side and the suction chamber, discharging via its outlet. Suction pressure is thus generated via which air is suctioned from the suction chamber.

**[p0007]**

Moreover, the ring-shaped duct is closed off from the environment. This means that air is exclusively suctioned via the suction chamber. The front side of the sleeve-shaped section in the area of the outer peripheral surface in one form is shaped such that it has a smaller transition radius than in the area of the inner peripheral surface, where it has a larger transition radius. Thus, when the compressed air enters the sleeve-shaped section, it is directed such that it flows in the direction of the outlet. In another form of the present disclosure, it is provided that the annular gap between the surface of the suction chamber and the front side of the sleeve-shaped section of the ejector nozzle widens radially inward. This widening has a speed-reducing effect, which favors the redirection of the compressed air stream in the direction of the outlet. Another form of the present disclosure provides that the free cross-section of the sleeve-shaped section of the ejector nozzle widens conically in the direction of the outlet. In addition, the speed of the compressed air stream is thus reduced, which increases the suction effect in the area of the free end of the sleeve-shaped section of the ejector nozzle.

**[p0008]**

Generally, it can be stated that a utility air stream is generated with the ejector nozzle via whose core air is carried away, resulting in a suction air stream being generated in the suction chamber. An additional development provides that a vacuum sensor for monitoring the load of the suction wall is especially arranged in the suction chamber. A slight vacuum points to a lacking or insufficient load of the suction wall, whereas major vacuum indicates an optimal loading of the suction wall. Alternatively or additionally, an optical sensor may be provided in the suction chamber. The load of the suction chamber may likewise be monitored by means of this optical sensor, which may also be used for determining the workpiece position, i.e. positioning the workpiece. Further advantages, features, and details of the present disclosure will be apparent from the subclaims, as well as from the following description, and are explained in detail with reference to an especially preferred exemplary embodiment in the drawing. The characteristics illustrated in the drawing, as well as in the description and the features mentioned in the claims, can each be fundamental to the present disclosure as such or in any combination thereof.

**[p0009]**

Further areas of applicability will become apparent from the description provided herein. It should be understood that the description and specific examples are intended for purposes of illustration only and are not intended to limit the scope of the present disclosure.

### Drawings

**[p0010]**

In order that the disclosure may be well understood, there will now be described various forms thereof, given by way of example, reference being made to the accompanying drawings, in which: FIG. 1 : A longitudinal section of a preferred embodiment of an area vacuum gripper; FIG. 2 : An enlarged reproduction of detail II according to FIG. 1 ; and FIG. 3 : An enlarged reproduction of detail III according to FIG. 2 . The drawings described herein are for illustration purposes only and are not intended to limit the scope of the present disclosure in any way.

### Detailed Description

**[p0011]**

The following description is merely exemplary in nature and is not intended to limit the present disclosure, application, or uses. FIG. 1 schematically shows a longitudinal section of an area vacuum gripper overall designated with 10 by means of which a workpiece 12 may be gripped and lifted. Several of these workpieces 12 may be lying on top of one another and form a stack 14 so that the topmost workpiece may be lifted each time. The area vacuum gripper 10 has a suction chamber 16 which, with its bottom side that forms the suction wall 18 , may be placed on the workpiece 12 . The placing and lifting device of the area vacuum gripper 10 , e.g. a robot arm or the like, is not shown. The suction wall 18 has perforations 20 ( FIG. 2 ) and is, for example, configured as a perforated plate 22 , in particular, as a perforated steel plate. On the side 24 opposite the suction wall 18 , i.e. the upper side, the suction chamber 16 has an outlet opening 26 , which coaxially connects to the ejector nozzle 28 . The ejector nozzle 28 is, for example, connected to the suction chamber 16 by means of screws 30 .

**[p0012]**

FIG. 2 shows an enlarged reproduction of detail II according to FIG. 1 , where the connection of the ejector nozzle 28 to the suction chamber 16 is visible. The ejector nozzle 28 is provided with a compressed air inlet 32 , which ends in a ring-shaped duct 34 provided in the ejector nozzle 28 . This ring-shaped duct 34 surrounds a sleeve-shaped section 36 , which is arranged coaxially to the outlet opening 26 of the suction chamber 16 . The free end 54 of the sleeve-shaped section 36 defines a suction inlet 38 , whereas the opposite end is formed by an outlet 40 , which opens to the outside 42 , i.e. opens to the environment. The clear cross-section of the sleeve-shaped section 36 widens between the suction inlet 38 and the outlet 40 . Furthermore, the arrows 44 and 46 in FIG. 2 indicate how compressed air flows into the ring-shaped duct 34 via the compressed air inlet 32 , flowing around the free end 54 of the sleeve-shaped section 36 and entering the suction inlet 38 . This is made possible because the free end 54 of the sleeve-shaped section 36 , as shown in FIG. 3 , has a clearance 48 from the upper side 50 of the suction chamber 16 , so that the compressed air between the sleeve-shaped section 36 and the upper side 50 of the suction chamber 16 may enter the suction duct 52 of the sleeve-shaped section 36 . The free end 54 of the sleeve-shaped section 36 has a small radius 58 in the area of the outer peripheral surface 56 and a large radius 62 in the area of the inner peripheral surface 60 . The clearance 48 , in particular the ring-shaped gap between the free end 54 an

**[p0012]**

d the upper side 50 of the suction chamber 16 , enlarges in the direction of the suction duct 52 .

**[p0013]**

If, as indicated with arrow 44 , compressed air flows into the ring-shaped duct 34 via the compressed air inlet, this compressed air will distribute evenly over the periphery of the sleeve-shaped section 36 and circulate through the ring-shaped gap formed by the clearance 48 , entering the suction duct 52 as a ring-shaped or sleeve-shaped utility air stream, whereby its flow is directed toward the outlet 40 . As a result, air is carried away from the suction chamber 16 in the core of this ring-shaped stream, which is indicated with the arrows 64 . This air enters the suction chamber 16 via the perforations 20 , whereby the workpiece 12 is suctioned toward the suction wall 18 . According to the present disclosure, a vacuum sensor 66 is provided in the suction chamber 16 that captures the suction pressure inside the suction chamber 16 . Thus, the degree of loading of the suction wall 18 may be determined. An optical sensor 68 is also arranged inside the suction chamber 16 that monitors the load of the perforations 20 , which is indicated with the arrows 70 . The load may, likewise, be checked this way, which, however, also allows the determining of the position, i.e. the position of the workpiece 12 at the area vacuum gripper 10 .

**[p0014]**

By means of the area vacuum gripper 10 according to the present disclosure, a workpiece 12 may be gripped and lifted in an easy and safe manner. It should be noted that the disclosure is not limited to the embodiments described and illustrated as examples. A large variety of modifications have been described and more are part of the knowledge of the person skilled in the art. These and further modifications as well as any replacement by technical equivalents may be added to the description and figures, without leaving the scope of the protection of the disclosure and of the present patent.

## Figure captions

- **Figure 1:** FIG. 1 : A longitudinal section of a preferred embodiment of an area vacuum gripper;
- **Figure 2:** FIG. 2 : An enlarged reproduction of detail II according to FIG. 1 ; and
- **Figure 3:** FIG. 3 : An enlarged reproduction of detail III according to FIG. 2 .

## Classifications

- B65G47/91
- B65G47/91
- B25B11/00
- B65H2406/3661
- B65H2406/3661
- B65H3/0891
- B65H3/0891
- H10P72/78
- Y10T29/53178
- Y10T29/53178

## Cited patent documents

- [US-2002033611-A1](https://patents.google.com/patent/US20020033611A1/en) — PRS
- [US-2002056954-A1](https://patents.google.com/patent/US20020056954A1/en) — PRS
- [US-2002074703-A1](https://patents.google.com/patent/US20020074703A1/en) — PRS
- [US-2003164620-A1](https://patents.google.com/patent/US20030164620A1/en) — PRS
- [US-4252497-A](https://patents.google.com/patent/US4252497A/en) — PRS
- [US-4362461-A](https://patents.google.com/patent/US4362461A/en) — PRS
- [US-4470585-A](https://patents.google.com/patent/US4470585A/en) — PRS
- [US-4492504-A](https://patents.google.com/patent/US4492504A/en) — PRS
- [US-4699559-A](https://patents.google.com/patent/US4699559A/en) — PRS
- [US-4753564-A](https://patents.google.com/patent/US4753564A/en) — PRS
- [US-4878798-A](https://patents.google.com/patent/US4878798A/en) — PRS
- [US-5961168-A](https://patents.google.com/patent/US5961168A/en) — PRS
- [US-6039530-A](https://patents.google.com/patent/US6039530A/en) — PRS
- [US-6068547-A](https://patents.google.com/patent/US6068547A/en) — PRS
- [US-6155795-A](https://patents.google.com/patent/US6155795A/en) — PRS
- [US-6382692-B1](https://patents.google.com/patent/US6382692B1/en) — PRS
- [US-6502877-B2](https://patents.google.com/patent/US6502877B2/en) — PRS
- [US-6547228-B1](https://patents.google.com/patent/US6547228B1/en) — PRS
- [US-6817639-B2](https://patents.google.com/patent/US6817639B2/en) — PRS
- [US-7416176-B2](https://patents.google.com/patent/US7416176B2/en) — PRS
- [US-7661736-B2](https://patents.google.com/patent/US7661736B2/en) — PRS
- [US-7677622-B2](https://patents.google.com/patent/US7677622B2/en) — PRS
- [US-7878564-B2](https://patents.google.com/patent/US7878564B2/en) — PRS

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
