# 41. Workpiece holding apparatus

- **Archive rank:** 41 of 50
- **Publication:** [US-2017069523-A1](https://patents.google.com/patent/US20170069523A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/054144114/publication/US20170069523A1?q=pn%3DUS20170069523A1)
- **Publication date:** 2017-03-09
- **Filing date:** 2015-02-17
- **Earliest priority:** 2014-03-19
- **Family:** 54144114
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery

## Parties

- **Applicant / assignee:** SHINETSU HANDOTAI KK
- **Inventors:** ENOMOTO TATSUO; YASUDA TAICHI

## Abstract

A workpiece holding apparatus, including: a rigid body having a vent; a suction pad adhered onto the lower end face of rigid body and having an opening communicating with vent, being configured to suck and hold a workpiece; an air controlling mechanism communicating with the vent, being configured to aspirate or discharge air through vent to aspirate or discharge air from opening; and a swelling portion being configured to be supplied with air by air controlling mechanism through the vent to swell out at least part of an area of suction pad to be in contact with the workpiece toward the workpiece in detaching workpiece from suction pad; wherein suction pad is configured to suck and hold workpiece by bringing the opening into contact with workpiece while aspirating air by air controlling mechanism through opening, and is configured to detach the workpiece from suction pad by discharging air from opening.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/76/e5/4b/7d1e609342756d/US20170069523A1-20170309-D00000.png)

![Sketch 1 for US-2017069523-A1](https://patentimages.storage.googleapis.com/76/e5/4b/7d1e609342756d/US20170069523A1-20170309-D00000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/12/bc/45/e0fa1e6a423da2/US20170069523A1-20170309-D00001.png)

![Sketch 2 for US-2017069523-A1](https://patentimages.storage.googleapis.com/12/bc/45/e0fa1e6a423da2/US20170069523A1-20170309-D00001.png)

[Sketch 3](https://patentimages.storage.googleapis.com/f2/0f/ae/4e3ef06edc687e/US20170069523A1-20170309-D00002.png)

![Sketch 3 for US-2017069523-A1](https://patentimages.storage.googleapis.com/f2/0f/ae/4e3ef06edc687e/US20170069523A1-20170309-D00002.png)

[Sketch 4](https://patentimages.storage.googleapis.com/27/83/3d/0066735d0fc3e3/US20170069523A1-20170309-D00003.png)

![Sketch 4 for US-2017069523-A1](https://patentimages.storage.googleapis.com/27/83/3d/0066735d0fc3e3/US20170069523A1-20170309-D00003.png)

[Sketch 5](https://patentimages.storage.googleapis.com/6c/66/ef/d3e6463902134e/US20170069523A1-20170309-D00004.png)

![Sketch 5 for US-2017069523-A1](https://patentimages.storage.googleapis.com/6c/66/ef/d3e6463902134e/US20170069523A1-20170309-D00004.png)

## Claims

### Claim 1

A workpiece holding apparatus, comprising: a rigid body having a vent; a suction pad adhered onto the lower end face of the rigid body and having an opening communicating with the vent, being configured to suck and hold a workpiece; an air controlling mechanism communicating with the vent, being configured to aspirate or discharge air through the vent to aspirate or discharge air from the opening; and a swelling portion being configured to be supplied with air by the air controlling mechanism through the vent to swell out at least a part of an area of the suction pad to be in contact with the workpiece toward the workpiece in detaching the workpiece from the suction pad; wherein the suction pad is configured to suck and hold the workpiece by bringing the opening into contact with the workpiece while aspirating air by the air controlling mechanism to aspirate air through the opening, and is configured to detach the workpiece from the suction pad by discharging air from the air controlling mechanism to discharge air through the opening. 2 . The workpiece holding apparatus according to claim 1 , wherein the swelling portion is composed of a concave part formed on a lower end portion of the rigid body, the suction pad, and a space defined by the both; and the space is configured to be supplied with air and pressurized by the air controlling mechanism to swell out the suction pad toward the workpiece. 3 . The workpiece holding apparatus according to claim 2 , wherein the swelling portion is provided with a pressurizing member in the space thereof, the pressurizing member being configured to be pressurized by air discharged from the air controlling mechanism to pressurize the suction pad to swell out the suction pad. 4 . The workpiece holding apparatus according to claim 1 , wherein the swelling portion is located at a position other than the opening in the area of the suction pad to be in contact with the workpiece. 5 . The workpiece holding apparatus according to claim 2 , wherein the swelling portion is located at a position other than the opening in the area of the suction pad to be in contact with the workpiece. 6 . The workpiece holding apparatus according to claim 3 , wherein the swelling portion is located at a position other than the opening in the area of the suction pad to be in contact with the workpiece.

## Full description

### Technical Field

**[p0001]**

The present invention relates to an apparatus for holding a workpiece when transporting a workpiece such as a silicon wafer.

### Background Art

**[p0002]**

For in-process transportation of a wafer in a processing step of a thin plate-form workpiece such as a silicon wafer, for example, it is usual to use a box or a cassette having plural of slots to store one wafer per each. The transported box or cassette is set to a processing apparatus in a step at the destination, and the wafers are taken out therefrom and are set to the processing apparatus. The wafers subjected to the processing are stored to a box or a cassette again, and transported to the next step. On this occasion, the transportation of wafers, in which wafers are taken out from a box or a cassette, set to a processing apparatus, and stored to a box or a cassette, are performed automatically by a robot or an actuator, etc. without handwork in many cases. In such transportation of wafers, wafers are held by a hand attached to a robot or an actuator (hereinafter, also referred to as a workpiece holding apparatus), transported to the destination, and released thereto (see Patent Document 1). In this case, it is usual to adopt a method such as aspirating suction, an edge grip, a Bernoulli chuck for holding the wafers.

**[p0003]**

Herein, a workpiece holding apparatus using aspirating suction will be described with referring to FIG. 10 ( a ) and ( b ) . The workpiece holding apparatus 101 is provided with an air controlling mechanism 106 and a vent 103 . This is configured to aspirate air in suction of a workpiece W, and is configured to stop this aspiration when separating (detaching) the workpiece W or to supply air in order to enhance the separation. In the workpiece holding apparatus 101 using this aspirating suction, the workpiece holding portion is usually pasted with a suction pad 104 having elasticity. This suction pad 104 sucks the workpiece W by aspirating air through an opening 105 . In this case, it is possible to enhance the aspiration effect by increasing the adhesiveness between the workpiece W and the holding portion by the suction pad 104 . It is also possible to prevent an occurrence of a defect on a workpiece due to direct contact between the main body 102 of the holding apparatus and a workpiece W.

### Citation List

**[p0004]**

Patent Literature Patent Document 1: Japanese Unexamined Patent publication (Kokai) No. 2001-29388

### Summary Of Invention

**[p0005]**

Technical Problem By the way, processing steps of a wafer uses liquid such as water, slurry, and a liquid reagent. Accordingly, transportation of a wafer is often performed in a state in which the wafer is wetting. The previous workpiece holding apparatus can have a problem in which a wafer cannot be smoothly detached at the destination when the wafer is wetting as described above. In the case that a wafer is wetting, liquid intervenes between a suction pad and the wafer when the wafer is aspirated and held to a holding apparatus. Although a wafer is sucked to a workpiece holding apparatus mainly by vacuum, this intervening liquid also generates adsorption force between the suction pad and the wafer. Accordingly, the adsorption force caused by the liquid remains even after stopping the vacuum, although the adsorption force caused by the vacuum is disappeared, thereby causing a problem in which the wafer is not separated from the workpiece holding apparatus. By blowing air through an opening of the suction pad, it is possible to partly remove the liquid, however, it is difficult to spread air on all over the suction surface, and accordingly the liquid remains, thereby remaining adsorption force due to liquid.

**[p0006]**

When the reliability of wafer separation is lowered as described above, it is impossible to accurately place the wafer onto an intended position in a wafer handling apparatus. Furthermore, a wafer is adhered onto a suction pad by the adsorption force of the liquid even when the wafer is intended to be detached by stopping the vacuum, and accordingly, it happens that the wafer is brought to an unintended place or the wafer falls on the way to break the wafer or the apparatus. This causes a problem of lowering the yield or lowering the machine productivity caused by restoration work of the apparatus. The present invention was accomplished in view of the above-described problems. It is an object of the present invention to provide a workpiece holding apparatus which can securely detach a workpiece by lowering adsorption force between the workpiece and a suction pad when the work held by the suction pad is detached from the suction pad. Solution to Problem To solve the problems, the present invention provides a workpiece holding apparatus, comprising: a rigid body having a vent; a suction pad adhered onto the lower end face of the rigid body and having an opening communicating with the vent, being configured to suck and hold a workpiece; an air controlling mechanism communicating with the vent, being configured to aspirate or discharge air through the vent to aspirate or discharge air from the opening; and a swelling portion being configured to be supplied with air by the air controlling mechanism through the vent to swell out at least a part of an area of the suction pad to be

**[p0006]**

in contact with the workpiece toward the workpiece in detaching the workpiece from the suction pad; wherein the suction pad is configured to suck and hold the workpiece by bringing the opening into contact with the workpiece while aspirating air by the air controlling mechanism to aspirate air through the opening, and is configured to detach the workpiece from the suction pad by discharging air from the air controlling mechanism to discharge air through the opening.

**[p0007]**

In detaching (separating) a workpiece from a suction pad as described above, by swelling an area of the suction pad to be in contact with the workpiece, it is possible to largely lower the adsorption force even when liquid intervenes between the workpiece and the suction pad to generate adsorption force due to the liquid. Accordingly, it is possible to securely detach the workpiece from the suction pad. The swelling portion can be composed of a concave part formed on a lower end portion of the rigid body, the suction pad, and a space defined by the both; and the space can be configured to be supplied with air and pressurized by the air controlling mechanism to swell out the suction pad toward the workpiece. Such constitution makes it possible to swell the suction pad with a simple structure, and accordingly to detach a workpiece from the suction pad more easily. In this case, it is preferred that the swelling portion is provided with a pressurizing member in the space thereof, the pressurizing member being configured to be pressurized by air discharged from the air controlling mechanism to pressurize the suction pad to swell out the suction pad.

**[p0008]**

When the pressurizing member is contained in the space as described above, the suction pad can be securely swelled out by the pressurizing member, and accordingly the workpiece can be securely detached from the suction pad. In this case, the swelling portion can be located at a position other than the opening in the area of the suction pad to be in contact with the workpiece. In the present invention, the swelling portion can be located at a position other than the opening of the suction pad, which can simplify the structure of the holding apparatus and can suppress the production cost thereby. Advantageous Effects of Invention The inventive workpiece holding apparatus makes it possible to lower the adsorption force when detaching a workpiece from the suction pad and to detach the workpiece from the suction pad securely. As a result, in transportation of a workpiece, it comes to be possible to securely transport the workpiece to an intended place, and to prevent a breakage of the wafer or the apparatus due to unintended falling of the wafer, and accordingly it is possible to prevent lowering of the yield and lowering of the machine productivity.

### Brief Description Of Drawings

**[p0009]**

FIG. 1 ( a ) is a side sectional view to show an example of the workpiece holding apparatus of the present invention, and ( b ) is a top view to show an example of the workpiece holding apparatus of the present invention; FIG. 2 is a schematic diagram to show an example of an embodiment when detaching a workpiece in the workpiece holding apparatus of the present invention; FIG. 3 ( a ) is a side sectional view to show an example of the inventive workpiece holding apparatus in suction of a workpiece when a pressurizing member is contained, and ( b ) is a side sectional view to show an example of the inventive workpiece holding apparatus in detaching of a workpiece when a pressurizing member is contained; FIG. 4 ( a ) is a side sectional view to show an example of the inventive workpiece holding apparatus in suction of a workpiece when a swelling portion and an opening are in different positions, and ( b ) is a side sectional view to show an example of the inventive workpiece holding apparatus in detaching of a workpiece when a swelling portion and an opening are in different positions;

**[p0010]**

FIG. 5 ( a ), ( b ), and ( c ) respectively illustrate a side sectional view, a top view, and a front view of the workpiece holding apparatus produced in Example 1 ; FIG. 6 is a top view to show a case in Example I, wherein a wafer is held by the inventive workpiece holding apparatus; FIG. 7 is a graph to show a relation between air blowing pressure and swelling amounts of the suction pad measured in Example 1; FIG. 8 is a figure to illustrate an outline of the experiment performed in Example 1; FIG. 9 is a figure to illustrate adsorption force F of the liquid intervening between objects; FIG. 10 ( a ) is a side sectional view to show an example of the conventional workpiece holding apparatus, and ( b ) is a top view to show an example of the conventional workpiece holding apparatus.

### Description Of Embodiments

**[p0011]**

Hereinafter, the embodiments of the present invention will be described, but the present invention is not limited thereto. As described above, when the surface of a workpiece to be held is wetting, there have been a problem in which the liquid on the surface generates adsorption force between the workpiece and a suction pad, and as a result, the workpiece cannot be detached from the suction pad at an accurate position. In order to solve such a problem, the inventors have presumed as follows on the character of this adsorption force due to liquid. It is known that the adsorption force F shown by the following equation is generated by liquid 153 intervening between two plates 151 and 152 being parallel with each other as shown in FIG. 9 . F= (π r 2 ×2γcosθ)/h=(2 A γcosθ)/ h wherein, “r” represents a radius of an intervening liquid cylinder, “A” represents an area of the intervening liquid, “γ” represents viscosity of the intervening liquid, “θ” represents a contact angle of a plane and the liquid, and “h” represents a height of the intervening liquid cylinder (the thickness of the liquid).

**[p0012]**

On the basis of this equation, the adsorption force due to liquid is proportional to an area of the intervening liquid, viscosity of the intervening liquid, and a cosine of a contact angle of the liquid on a plane, and is inversely proportional to the thickness of the intervening liquid. Accordingly, for lowering the adsorption force due to liquid, it is favorable to make the area of the liquid “A”, the viscosity of the liquid “γ”, and the cosine of the contact angle “θ” of the liquid on a plain smaller; and to make the thickness of the intervening liquid “h” larger. Herein, the viscosity of liquid and the liquid to be used are requirements on processing or results of processing, and accordingly it is desirable to avoid to change these parameters in view of transportation to aid the wafer processing. Therefore, the inventors have focused on the area and the thickness of the intervening liquid. As a method to reduce the area, it is plausible to reduce the contact area with a workpiece itself by reconsidering the forms of the main body and the suction pad of the workpiece holding apparatus. In a region of a workpiece where is not in contact with a suction pad, however, the workpiece is bent with the own weight of the workpiece. Moreover, in this bent region where is not held by the suction pad, vibration can be occur when the workpiece is moved. Accordingly, when the contact area is simply reduced, the bending of the workpiece or the amplitude of the vibration get large, and it comes to be difficult to store the workpiece into a narrow spot such as a slot of a cassette or a b

**[p0012]**

ox, or to set the workpiece into a particular spot in an apparatus.

**[p0013]**

In silicon wafers, the diameters are getting larger. Accordingly, if the contact area is reduced easily, it comes to be highly risky to generate the problems such as bending or vibration more noticeably when the diameters are more enlarged. As a method for thickening the thickness of the intervening liquid, it is plausible to enlarge the contact angle between the liquid and a suction pad. As described above, the liquid itself is selected for the reason of processing in many cases, and is not desirable to be changed in view of transportation. For enlarging the contact angle without changing the liquid, it is plausible to enhance the repellency of the suction pad. When the suction pad is new, the repellency is high, and can enlarge the contact angle thereby. However, in a polishing process of a silicon wafer, for example, it is usual to supply slurry which contains many wetting agent in the end of the polishing in order to protect the wafer surface after polishing. Such a wetting agent enhances the wettability with the operating time even in the suction pad with high repellency, and accordingly, it is difficult to maintain a large contact angle over the entire suction pad life.

**[p0014]**

Accordingly, the present inventors have conceived that, by swelling at least a part of an area of the suction pad to be in contact with the workpiece toward the workpiece in detaching a workpiece, it is possible to force to enlarge the distance between the workpiece and the suction pad (the thickness h of the intervening liquid), and it is possible to cause the liquid to move to reduce the area A; thereby brought the present invention to completion. Hereinafter, the present invention will be described with referring to FIGS. 1 to 4 . As shown FIG. 1 , the inventive workpiece holding apparatus 1 comprises a rigid body 2 , which is a main body of the apparatus, a suction pad 4 adhered onto the lower end face of the rigid body 2 and having elasticity, an air controlling mechanism 6 , which can aspirate and discharge air, etc. In the rigid body 2 , a vent 3 is formed, and this vent 3 is communicating with the air controlling mechanism 6 . The suction pad 4 is provided with an opening 5 passing through the top surface to the under surface thereof. In case of FIG. 1 , the opening 5 is connected to the vent 3 through a space 8 . As described above, the opening 5 is allowed to aspirate and discharge air therefrom by aspirating and discharging air by the air controlling mechanism 6 .

**[p0015]**

When such a workpiece holding apparatus 1 is attached to a robot or an actuator (not shown) and used for transporting a workpiece W, the suction pad 4 is brought into contact with the workpiece W while aspirating air by the air controlling mechanism 6 to hold the workpiece W by aspirating suction in holding the workpiece W. Then, the workpiece holding apparatus 1 , holding the workpiece W, is moved to an intended position by a robot or an actuator (not shown). Subsequently, the workplace W is detached (separated) from the workpiece holding apparatus 1 to complete the transportation of the workpiece W to an intended position. The present invention comprises a swelling portion being configured to swell out at least a part of an area of the suction pad 4 to be in contact with the workpiece W toward the workpiece W by being supplied with air by the air controlling mechanism 6 through the vent 3 when the workpiece W is detached in the foregoing transportation step. For example, in the structure of the workpiece holding apparatus shown in FIG. 1 ( a ) and ( b ) , a concave part 7 formed on a lower end portion of the rigid body 2 , the suction pad 4 , and a space 8 defined by the both can be installed.

**[p0016]**

The suction pad 4 covering this space 8 is provided with an opening 5 to ensure a passage of air. This opening 5 is smaller than the space 8 . In this structure, the opening 5 of the suction pad 4 is smaller than the space 8 . Accordingly, as shown in FIG. 2 , when air is discharged from the air controlling mechanism 6 , the air pressure in the space 8 increases to swell out the vicinity of the opening 5 of the suction pad 4 . As shown in FIG. 2 , when the workpiece W is wetting, this swelling portion 9 forces to enlarge the distance between the workpiece W and the suction pad 4 (( 1 ) in FIG. 2 ). As a result, liquid intervening between the workpiece W and the suction pad 4 moves to reduce the area A of the liquid (( 2 ) in FIG. 2 ) and to increase the thickness h of the liquid (( 3 ) in FIG. 2 ). As described above, in such an inventive workpiece holding apparatus, even when detaching a workpiece having the surface with residual liquid, it is possible to largely reduce the adsorption force caused by the liquid to promote to detach the workpiece. Naturally, the present invention can be utilized to detach a dry workpiece having the surface without residual liquid. It is possible to promote to detach a workpiece more effectively compared to previous arts by pressing the workpiece downward by the swelling portion.

**[p0017]**

In transporting a workpiece, when the inventive workpiece holding apparatus is used with being attached to a robot or an actuator, it is possible to securely transport a workpiece to an intended position, and to prevent breakage of the wafer or the apparatus by unintended falling of the wafer. Accordingly, it is possible to prevent lowering of the yield and lowering of the productivity. As shown in FIG. 3 , the swelling portion 9 is preferably provided with a pressurizing member 10 in the space 8 , in which the pressurizing member 10 is configured to be pressurized by air discharged from the air controlling mechanism 6 to pressurize the suction pad 4 to swell out the suction pad 4 . This pressurizing member 10 can have a thickness which is the same as the depth of the concave part 7 of the rigid body 2 , for example, and can be provided with a hole smaller than the vent 3 to passage air through the central part. By such a structure, although the surface structure of the suction pad 4 is not changed in suction of a workpiece (( a ) in FIG. 3 ), it is possible to pressurize this pressurizing member 10 with air and to pressurize the suction pad 4 in detaching, and to swell out the suction pad 4 (( b ) in FIG. 3 ).

**[p0018]**

As described above, in a swelling portion having a pressurizing member in the space thereof, the suction pad can be swelled out more securely by the pressurizing member, and accordingly a workpiece can be detached from the suction pad more securely. The foregoing FIG. 1 , FIG. 2 , and FIG. 3 shows an example in which the suction pad 4 is provided with the swelling portion 9 at the opening 5 , however, the swelling portion 9 can be separately installed to a position other than the opening 5 . That is, the swelling portion can be located at a position other than the opening 5 in the area of the suction pad 4 to be in contact with the workpiece W. For example, as shown in FIG. 4 ( a ) , a vent 3 in a rigid body 2 is set to communicate with each of an opening 5 and a swelling portion 9 , and the swelling portion 9 is separately located in a position of a suction pad 4 other than the opening 5 . In such an apparatus, as shown in FIG. 4 ( b ) , the surface of the swelling pad 4 swells out at a different position from the opening 5 by air discharged by the air controlling mechanism 6 when detaching a workpiece.

**[p0019]**

In this case, a pressurizing member 10 can also be contained in a space 8 as shown in FIG. 4 . The reducing amount of adsorption force, which is due to liquid intervening between a workpiece and a suction pad, is larger as the swelling amount of the swelling portion is larger. The swelling amount can be controlled by changing the pressure for supplying air in swelling the swelling portion, the area of the swelling portion, and the material and the thickness of the suction pad. It is possible to obtain a desired swelling amount by optimizing the combination of these parameters in accordance with an environment in which the apparatus is used. It is also possible to optimize the detaching of a workpiece by appropriately setting the position to form the swelling portion in accordance with the form of a workpiece to be held.

### Example

**[p0020]**

Hereinafter, the present invention will be more specifically described with referring to Example and Comparative Example, but the present invention is not limited to thereto. Example 1 First, an inventive workpiece holding apparatus was produced in an embodiment in which the swelling portion 9 is located at a position other than the opening 5 in the area of the suction pad 4 to be in contact with the workpiece W as shown in FIG. 5 ( a ), ( b ) , and ( c ). The workpiece holding apparatus was produced as follows. As a rigid body 2 , being a main body of the workpiece holding apparatus 1 , a superposition structure of a PVC board 2 a (polyvinyl chloride board) with a thickness of 3 mm and a stainless board 2 b with a thickness of 5 mm was adopted as shown in FIG. 5 . Onto the superimposed face between the PVC board 2 a and the stainless board 2 b, a groove with a width of 6 mm and a depth of 1.5 mm was made to form a part of a vent 3 , which is a passage of air. The rigid body 2 was provided with a hole with a diameter of 6 mm on the side of the stainless board 2 b as a part of the vent 3 in order to suck a workpiece. For a swelling portion 9 of the suction pad, the stainless board 2 b was hollowed to form a hole with a diameter of 15 mm, and to this hole, a pressurizing member 10 with the same depth as that of the hole and having a diameter smaller than that of the hole by 0.1 mm was installed. As for the pressurizing member 10 , the same material as that of the suction pad 4 was used.

**[p0021]**

Onto the lower end face of the rigid body 2 , a backing pad with a thickness of 0.5 mm (manufactured by Nitta Haas Incorporated, R601) was adhered as the suction pad 4 through double-side adhesive tape. Onto the suction pad 4 , an opening 5 with an area of 160 mm 2 was formed in order to ensure sufficient suction force. To the vent 3 , a tube of an air controlling mechanism 6 was connected from the side of the PVC board 2 a. As described above, the workpiece holding apparatus 1 was produced. Then, a wafer W with a diameter of 300 mm was held by the workpiece holding apparatus 1 . In this case, the area in which the workpiece holding apparatus 1 was in contact with the wafer W in holding the wafer W was set to 4050 mm 2 . As shown in FIG. 6 , the swelling portion 9 was located so as to overlap with the periphery of the wafer W. The adsorption pressure in suction of the wafer was set to 0.1 MPa. This is because the workpiece holding apparatus 1 was used in the facility with the vacuum pressure of 0.1 MPa, and the size to hollow the pad which can stably suck the wafer by this pressure was 160 mm 2 .

**[p0022]**

The air blowing pressure was set to 0.1 MPa when detaching a wafer. In this case, the swelling amounts of the swelling portion of the suction pad were measured when the air blowing pressure was changed. The results were shown in FIG. 7 . In this case, the swelling amounts varied largely when the air blowing pressure was low, but the swelling amount was stably increased after the pressure was over 0.1 MPa. Accordingly, the air blowing pressure was set to 0.1 MPa, which can gives sufficient lowering ability of adsorption force and the swelling amount of the suction pad came to be more stabilized, in this case. For lowering the adsorption force, it is advantageous to increase the air blowing pressure and to enlarge the deformation amount of the pad. The air blowing pressure about 0.1 MPa, however, does not involve a risk to stretch the pad itself by too large pressure nor a risk to peel the suction pad from the vicinity of the swelling portion. Although the air blowing pressure was set to 0.1 MPa in this case, the adsorption force can be lowered at 0.1 MPa or less as a matter of course.

**[p0023]**

The workpiece holding apparatus thus produced was adopted as an automatic handling apparatus attached to a polisher. The occurrence of an error relating to transportation or storage of a wafer, being caused by adsorption force due to liquid intervening between the suction pad and the wafer, turned zero in a month. Furthermore, the following experiment was performed in order to verify that in aspirating suction of a wetted wafer by a suction pad, the adsorption force due to liquid intervening between the suction pad and the wafer can be lowered by deforming a part of the suction pad when the wafer is detached. As shown in FIG. 8 , a wafer with a diameter of 300 mm was adhered and fixed onto a table 200 . Then, the surface of the wafer W fixed on the table 200 was wetted with water sufficiently. Subsequently, the surface of the wafer W was pressed down with the inventive workpiece holding apparatus 1 , and the wafer was adhered to the workpiece holding apparatus 1 by the water wetting on the surface. In this case, the adsorption force was solely due to the water intervening the suction pad 4 and the wafer W, since vacuum was not utilized. Then, a spring scale 300 was mounted onto the workpiece holding apparatus 1 adhering the wafer, and the workpiece holding apparatus 1 was pulled in a horizontal direction while suppling air with a blowing pressure of 0.05 MPa. Then, the adsorption force due to the intervening liquid was measured on the basis of a value indicated by the spring scale when the workpiece holding apparatus 1 adhered to the wafer W started to move on the wafer. Th

**[p0023]**

is experiment was repeated, and the average value of the values indicated by the spring scale was calculated to be 5.6 g. This value is notably small compared to that of Comparative Example described later, which have verified that the present invention can largely lower the adsorption force between a wafer and a suction pad when a workpiece holding apparatus detaches the wafer.

**[p0024]**

Comparative Example 1 An experiment and holding of a wafer with a diameter of 300 mm were performed in the same conditions as in Example 1, except for using a previous workpiece holding apparatus as shown in FIG. 10 , that is, using a workpiece holding apparatus without a swelling portion of the present invention. The previous workplace holding apparatus was adopted as an automatic handling apparatus attached to a polisher as in Example 1. This resulted 13 errors in a month relating to transportation or storage of a wafer, which is caused by adsorption force due to liquid intervening between the suction pad and the wafer. In aspirating suction of a wafer wetted with water by a suction pad with previous workpiece holding apparatus, adsorption force due to liquid intervening between the suction pad and the wafer was measured when the wafer was detached as the experiment in Example 1 shown in FIG. 8 . As the result, the average value of values indicated by the spring scale was calculated to be 61 g, which revealed that the adsorption force was more than ten times compared to that of Example 1.

**[p0025]**

It is to be noted that the present invention is not limited to the foregoing embodiment. The embodiment is just an exemplification, and any examples that have substantially the same feature and demonstrate the same functions and effects as those in the technical concept described in claims of the present invention are included in the technical scope of the present invention.

## Figure captions

- **Figure 10:** Herein, a workpiece holding apparatus using aspirating suction will be described with referring to FIG. 10 ( a ) and ( b ) .
- **Figure 1:** FIG. 1 ( a ) is a side sectional view to show an example of the workpiece holding apparatus of the present invention, and ( b ) is a top view to show an example of the workpiece holding apparatus of the present invention;
- **Figure 2:** FIG. 2 is a schematic diagram to show an example of an embodiment when detaching a workpiece in the workpiece holding apparatus of the present invention;
- **Figure 3:** FIG. 3 ( a ) is a side sectional view to show an example of the inventive workpiece holding apparatus in suction of a workpiece when a pressurizing member is contained, and ( b ) is a side sectional view to show an example of the inventive workpiece holding apparatus in detaching of a workpiece when a pressurizing member is contained;
- **Figure 4:** FIG. 4 ( a ) is a side sectional view to show an example of the inventive workpiece holding apparatus in suction of a workpiece when a swelling portion and an opening are in different positions, and ( b ) is a side sectional view to show an example of the inventive workpiece holding apparatus in detaching of a workpiece when a swelling portion and an opening are in different positions;
- **Figure 5:** FIG. 5 ( a ), ( b ), and ( c ) respectively illustrate a side sectional view, a top view, and a front view of the workpiece holding apparatus produced in Example 1 ;
- **Figure 6:** FIG. 6 is a top view to show a case in Example I, wherein a wafer is held by the inventive workpiece holding apparatus;
- **Figure 7:** FIG. 7 is a graph to show a relation between air blowing pressure and swelling amounts of the suction pad measured in Example 1;
- **Figure 8:** FIG. 8 is a figure to illustrate an outline of the experiment performed in Example 1;
- **Figure 9:** FIG. 9 is a figure to illustrate adsorption force F of the liquid intervening between objects;
- **Figure 10:** FIG. 10 ( a ) is a side sectional view to show an example of the conventional workpiece holding apparatus, and ( b ) is a top view to show an example of the conventional workpiece holding apparatus.
- **Figure 9:** It is known that the adsorption force F shown by the following equation is generated by liquid 153 intervening between two plates 151 and 152 being parallel with each other as shown in FIG. 9 .
- **Figure 1:** Hereinafter, the present invention will be described with referring to FIGS. 1 to 4 .
- **Figure 1:** As shown FIG. 1 , the inventive workpiece holding apparatus 1 comprises a rigid body 2 , which is a main body of the apparatus, a suction pad 4 adhered onto the lower end face of the rigid body 2 and having elasticity, an air controlling mechanism 6 , which can aspirate and discharge air, etc.
- **Figure 1:** The suction pad 4 is provided with an opening 5 passing through the top surface to the under surface thereof. In case of FIG. 1 , the opening 5 is connected to the vent 3 through a space 8 . As described above, the opening 5 is allowed to aspirate and discharge air therefrom by aspirating and discharging air by the air controlling mechanism 6 .
- **Figure 1:** For example, in the structure of the workpiece holding apparatus shown in FIG. 1 ( a ) and ( b ) , a concave part 7 formed on a lower end portion of the rigid body 2 , the suction pad 4 , and a space 8 defined by the both can be installed.
- **Figure 3:** As shown in FIG. 3 , the swelling portion 9 is preferably provided with a pressurizing member 10 in the space 8 , in which the pressurizing member 10 is configured to be pressurized by air discharged from the air controlling mechanism 6 to pressurize the suction pad 4 to swell out the suction pad 4 .
- **Figure 4:** For example, as shown in FIG. 4 ( a ) , a vent 3 in a rigid body 2 is set to communicate with each of an opening 5 and a swelling portion 9 , and the swelling portion 9 is separately located in a position of a suction pad 4 other than the opening 5 .
- **Figure 4:** In such an apparatus, as shown in FIG. 4 ( b ) , the surface of the swelling pad 4 swells out at a different position from the opening 5 by air discharged by the air controlling mechanism 6 when detaching a workpiece.
- **Figure 4:** In this case, a pressurizing member 10 can also be contained in a space 8 as shown in FIG. 4 .
- **Figure 5:** First, an inventive workpiece holding apparatus was produced in an embodiment in which the swelling portion 9 is located at a position other than the opening 5 in the area of the suction pad 4 to be in contact with the workpiece W as shown in FIG. 5 ( a ), ( b ) , and ( c ).
- **Figure 6:** Then, a wafer W with a diameter of 300 mm was held by the workpiece holding apparatus 1 . In this case, the area in which the workpiece holding apparatus 1 was in contact with the wafer W in holding the wafer W was set to 4050 mm 2 . As shown in FIG. 6 , the swelling portion 9 was located so as to overlap with the periphery of the wafer W.
- **Figure 7:** The air blowing pressure was set to 0.1 MPa when detaching a wafer. In this case, the swelling amounts of the swelling portion of the suction pad were measured when the air blowing pressure was changed. The results were shown in FIG. 7 .
- **Figure 10:** An experiment and holding of a wafer with a diameter of 300 mm were performed in the same conditions as in Example 1, except for using a previous workpiece holding apparatus as shown in FIG. 10 , that is, using a workpiece holding apparatus without a swelling portion of the present invention.
- **Figure 8:** In aspirating suction of a wafer wetted with water by a suction pad with previous workpiece holding apparatus, adsorption force due to liquid intervening between the suction pad and the wafer was measured when the wafer was detached as the experiment in Example 1 shown in FIG. 8 .

## Classifications

- H01L21/6838
- H10P72/78
- H10P72/78
- H10P72/78
- B24B37/345
- B24B37/345
- B24B41/06
- B24B41/06
- B25J15/06
- B25J15/0658
- B25J15/0658
- B25J15/0658
- B25J15/0666
- B25J15/0666
- B25J15/0683
- B25J15/0683
- H01L21/683
- H10P52/00
- H10P72/74
- H10P72/7604
- H10P72/7624

## Cited patent documents

- [US-2012193500-A1](https://patents.google.com/patent/US20120193500A1/en) — PRS
- [US-3602543-A](https://patents.google.com/patent/US3602543A/en) — PRS
- [US-4221356-A](https://patents.google.com/patent/US4221356A/en) — PRS
- [US-4294424-A](https://patents.google.com/patent/US4294424A/en) — PRS
- [US-4620738-A](https://patents.google.com/patent/US4620738A/en) — PRS
- [US-5423716-A](https://patents.google.com/patent/US5423716A/en) — PRS
- [US-5772170-A](https://patents.google.com/patent/US5772170A/en) — PRS
- [US-6135858-A](https://patents.google.com/patent/US6135858A/en) — PRS
- [US-7086675-B2](https://patents.google.com/patent/US7086675B2/en) — PRS
- [US-7445543-B2](https://patents.google.com/patent/US7445543B2/en) — PRS
- [US-7909374-B2](https://patents.google.com/patent/US7909374B2/en) — PRS

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
