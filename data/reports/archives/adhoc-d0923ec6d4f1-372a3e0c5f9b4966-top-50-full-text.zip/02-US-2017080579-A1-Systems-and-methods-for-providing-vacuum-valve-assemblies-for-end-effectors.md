# 02. Systems and methods for providing vacuum valve assemblies for end effectors

- **Archive rank:** 2 of 50
- **Publication:** [US-2017080579-A1](https://patents.google.com/patent/US20170080579A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/056894283/publication/US20170080579A1?q=pn%3DUS20170080579A1)
- **Publication date:** 2017-03-23
- **Filing date:** 2016-08-26
- **Earliest priority:** 2015-08-26
- **Family:** 56894283
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery

## Parties

- **Applicant / assignee:** BERKSHIRE GREY INC
- **Inventors:** AHEARN KEVIN; ALLEN THOMAS; DAWSON-HAGGERTY Michael; GEYER Christopher; KOLETSCHKA THOMAS; MARONEY Kyle; MASON MATTHEW T; PRICE GENE TEMPLE; ROMANO JOSEPH; SMITH DANIEL; SRINIVASA Siddhartha; VELAGAPUDI PRASANNA; WAGNER THOMAS

## Abstract

An end effector is disclosed for an articulated arm. The end effector includes a valve assembly including a plurality of supply channels, each supply channel including a supply conduit, a pressure sensor in fluid communication with the supply conduit, and a supply conduit plug. The supply conduit is in fluid communication with a vacuum source. During use, each supply conduit is either at vacuum such that the pressure within the supply conduit is substantially at a vacuum pressure, or is at a pressure that is substantially higher than vacuum pressure because the supply conduit plug has moved to block a portion of the supply conduit. The pressure sensor of each supply conduit provides a pressure sensor signal responsive to whether the pressure in the conduit is either substantially at vacuum or is at a pressure that is substantially higher than vacuum.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/ab/80/82/b51ce0154b3392/US20170080579A1-20170323-D00000.png)

![Sketch 1 for US-2017080579-A1](https://patentimages.storage.googleapis.com/ab/80/82/b51ce0154b3392/US20170080579A1-20170323-D00000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/1f/14/32/6fe2c502f5ee19/US20170080579A1-20170323-D00001.png)

![Sketch 2 for US-2017080579-A1](https://patentimages.storage.googleapis.com/1f/14/32/6fe2c502f5ee19/US20170080579A1-20170323-D00001.png)

[Sketch 3](https://patentimages.storage.googleapis.com/a8/00/44/8517106f749e92/US20170080579A1-20170323-D00002.png)

![Sketch 3 for US-2017080579-A1](https://patentimages.storage.googleapis.com/a8/00/44/8517106f749e92/US20170080579A1-20170323-D00002.png)

[Sketch 4](https://patentimages.storage.googleapis.com/b7/60/6a/453744a8a51271/US20170080579A1-20170323-D00003.png)

![Sketch 4 for US-2017080579-A1](https://patentimages.storage.googleapis.com/b7/60/6a/453744a8a51271/US20170080579A1-20170323-D00003.png)

[Sketch 5](https://patentimages.storage.googleapis.com/ff/05/26/0dcc8732fc7f76/US20170080579A1-20170323-D00004.png)

![Sketch 5 for US-2017080579-A1](https://patentimages.storage.googleapis.com/ff/05/26/0dcc8732fc7f76/US20170080579A1-20170323-D00004.png)

[Sketch 6](https://patentimages.storage.googleapis.com/59/ee/f6/b496790a1780ff/US20170080579A1-20170323-D00005.png)

![Sketch 6 for US-2017080579-A1](https://patentimages.storage.googleapis.com/59/ee/f6/b496790a1780ff/US20170080579A1-20170323-D00005.png)

[Sketch 7](https://patentimages.storage.googleapis.com/ef/09/28/e859463ce4b68b/US20170080579A1-20170323-D00006.png)

![Sketch 7 for US-2017080579-A1](https://patentimages.storage.googleapis.com/ef/09/28/e859463ce4b68b/US20170080579A1-20170323-D00006.png)

[Sketch 8](https://patentimages.storage.googleapis.com/f0/96/70/5ae631a1f919c2/US20170080579A1-20170323-D00007.png)

![Sketch 8 for US-2017080579-A1](https://patentimages.storage.googleapis.com/f0/96/70/5ae631a1f919c2/US20170080579A1-20170323-D00007.png)

[Sketch 9](https://patentimages.storage.googleapis.com/28/6b/a6/af8356f8609e13/US20170080579A1-20170323-D00008.png)

![Sketch 9 for US-2017080579-A1](https://patentimages.storage.googleapis.com/28/6b/a6/af8356f8609e13/US20170080579A1-20170323-D00008.png)

[Sketch 10](https://patentimages.storage.googleapis.com/cb/30/6b/0202fb640debb1/US20170080579A1-20170323-D00009.png)

![Sketch 10 for US-2017080579-A1](https://patentimages.storage.googleapis.com/cb/30/6b/0202fb640debb1/US20170080579A1-20170323-D00009.png)

## Claims

### Claim 1 (independent)

An end effector for an articulated arm, said end effector comprising a valve assembly including a plurality of supply channels, each supply channel including a supply conduit, a pressure sensor in fluid communication with the supply conduit, and a supply conduit plug, wherein said supply conduit is in fluid communication with a vacuum source, wherein during use, each supply conduit is either at vacuum such that the pressure within the supply conduit is substantially at a vacuum pressure, or is at a pressure that is substantially higher than vacuum pressure because the supply conduit plug has moved to block a portion of the supply conduit, and wherein said pressure sensor of each supply conduit provides a pressure sensor signal responsive to whether the pressure in the conduit is either substantially at vacuum or is at a pressure that is substantially higher than vacuum.

### Claim 2

The end effector as claimed in claim 1, wherein said end effector further includes a compliant pad at a distal end of the end effector.

### Claim 3

The end effector as claimed in claim 2, wherein said pad includes a plurality of defined apertures, each of which is aligned with a respective supply conduit of said valve assembly.

### Claim 4

The end effector as claimed in claim 3, wherein said plurality of defined apertures in the pad include a first plurality of apertures and a second plurality of apertures, and wherein the first plurality of apertures are centrally located with respect to the second plurality of apertures.

### Claim 5

The end effector as claimed in claim 4, wherein the first plurality of apertures is separated from the second plurality of apertures by a wall.

### Claim 6

The end effector as claimed in claim 4, wherein the wall is a ring formed of a compliant material.

### Claim 7

The end effector as claimed in claim 4, wherein said first plurality of apertures are in communication with each other, providing a common vacuum pressure among the first plurality of apertures in the pad.

### Claim 8

The end effector as claimed in claim 7, wherein said common vacuum pressure provides a higher vacuum pressure at the first plurality of apertures in the pad as compared to the second plurality of apertures in the pad.

### Claim 9

The end effector as claimed in claim 4, wherein the first plurality of apertures in the pad are in communication with the vacuum source at a first vacuum pressure, and the second plurality of apertures in the pad are in communication with the vacuum source at a second vacuum pressure that is different than the first vacuum pressure.

### Claim 10

The end effector as claimed in claim 9, wherein the second vacuum pressure is greater than the first vacuum pressure.

### Claim 11

The end effector as claimed in claim 1, wherein said vacuum pressure is provided to the plurality of supply conduits via a vacuum head that is coupled to the articulated arm via a mounting plate, and wherein the mounting plate is coupled to the vacuum head via a plurality of load cells that are each responsive to force distributions.

### Claim 12

The end effector as claimed in claim 1, wherein said end effector further includes an electronic circuit board in communication with the pressure sensors, each of which is associated with a supply channel.

### Claim 13

The end effector as claimed in claim 12, wherein said pressure sensor signal is provided to the electronic circuit board to provide information indicative of whether each respective supply channel is engaged with a load, thereby reducing the vacuum pressure within the respective supply channel.

### Claim 14

The end effector as claimed in claim 13, wherein said end effector further includes a plurality of load cells attached between an articulated arm and a vacuum generation head that provides the vacuum pressure.

### Claim 15 (independent)

An end effector for an articulated arm, said end effector comprising a valve assembly including a plurality of supply channels, each supply channel including a supply conduit, a pressure sensor in fluid communication with the supply conduit, and a supply conduit plug, wherein said supply conduit is in fluid communication with a vacuum source; wherein during use, each supply conduit is either at vacuum such that the pressure within the supply conduit is substantially at a vacuum pressure, or is at a pressure that is substantially higher than vacuum pressure because the supply conduit plug has moved to block a portion of the supply conduit; wherein said pad includes a plurality of defined apertures, each of which is aligned with a respective supply conduit of said valve assembly; and wherein said plurality of defined apertures in the pad include at least a first aperture and a second plurality of apertures, and wherein the at least the first aperture is centrally located with respect to the second plurality of apertures.

### Claim 16

The end effector as claimed in claim 15, wherein the at least the first aperture is provided with a high flow vacuum source that is higher in flow than a vacuum source that is provided to the plurality of second apertures.

### Claim 17

The end effector as claimed in claim 15, wherein the at least the first aperture is provided with a plurality of first apertures that are commonly in communication with a first vacuum source.

### Claim 18 (independent)

A method of providing a vacuum source to an end effector, said method comprising the steps of providing within the end effector a valve assembly including a plurality of supply channels, each supply channel including a supply conduit, a pressure sensor in fluid communication with the supply conduit, and a supply conduit plug; providing a vacuum source in fluid communication with the supply conduit; permitting the supply conduit to be at a pressure that is substantially higher than vacuum pressure when the associated supply channel is not engaged with an object; permitting the supply conduit to be at vacuum such that the pressure within the supply conduit is substantially at a vacuum pressure when the supply channel is engaged with an object; and providing a pressure sensor signal responsive to whether the pressure in the conduit is either substantially at vacuum or is at a pressure that is substantially higher than vacuum.

### Claim 19

The method as claimed in claim 18, wherein the method further includes the steps of providing a first plurality of apertures, each of which is aligned with a respective supply conduit of the valve assembly, and a providing s second plurality of apertures, each of which is aligned with a respective conduit of the valve assembly.

### Claim 20

The method as claimed in claim 19, wherein the first plurality of apertures are provided with a first vacuum pressure that is different than a second vacuum pressure that is provided to the second plurality of apertures.

## Full description

### Priority

**[p0001]**

The present application claims priority to U.S. Provisional Patent Application Ser. No. 62/210,246 filed Aug. 26, 2015, the disclosure of which is hereby incorporated by reference in its entirety.

### Background

**[p0002]**

The invention generally relates to robotic systems and relates in particular to articulated arms that include end effectors that provide a vacuum source for object acquisition or gripping. Such vacuum grippers exist in many configurations in the prior art. Generally, such devices use compressed air to generate a vacuum by use of a Venturi pump. The vacuum is then presented at the object to be acquired through any one of a variety of interfaces. One type of interface is a single large open port, which maximizes the suction pressure from the vacuum and is thus well equipped to acquire heavy objects or those packaged in loose plastic. This configuration is commonly referred to as a bag type gripper. Another type of interface is an array of smaller ports, each of which may have integrated flow control (due to their small hole size) designed to close or reduce them if they are not making contact with the object to be acquired. By closing unsealed ports, the suction pressure at ports that have successfully mated with the object to be acquired should be maximized. This approach provides flexibility in object acquisition since not all ports need to mate with an object in order to successfully acquire it. This flow control is generally accomplished by means of metering (or making the ports small enough that the resulting leakage from an unsealed port is immaterial).

**[p0003]**

In other vacuum gripper systems, integrated check valves may be used in port chambers that contact the environment. Typically, such devices include seals around the vacuum ports at the surface that meets the object to be acquired. This approach, while being more mechanically complicated, has the advantage of stronger overall suction force, since unsealed ports truly close at the opening, rather than just restricting leakage flow. For single large ports, a large suction cup or foam ring is used. For the array of ports configuration, an array of suction cups or a foam pad with holes for each of the individual ports are commonly used. In some vacuum gripper systems, a set of actuated valves is provided for the air flowing through the gripper; a valve on the compressed air input allows for shutting the vacuum on and off, allowing the gripper to drop an object. This approach, however, is slow due to time constants of air pressure equalization within the gripper body. The speed of release is dramatically increased by adding a second controlled valve to the exhaust port of the vacuum generator; by closing this valve, compressed air is diverted through the gripper body and out the vacuum ports, effectively blowing the acquired object off of the gripper surface quickly.

**[p0004]**

The vacuum grippers in the prior art are generally designed for a specific object or material in a predetermined orientation. The specific gripper style and configuration is chosen to optimize for a particular acquisition problem (for instance, palletizing and de-palletizing a particular size/type of cardboard cartons). Such grippers are not at all well suited to a wide array of objects in non-predetermined orientations. Further, in such vacuum gripper systems, software systems and algorithms are provided that are developed around the concept of maximizing speed and efficiency of abort/retry cycles for robotic manipulators acquiring objects. These algorithms have been focused in some applications on heavily instrumented multiple-finger mechanical grasping manipulators. The algorithms use the data from joint angles and motor power to determine how well an object is grasped and immediately retry if the grasp is not good enough. In many such vacuum gripper systems, abort/retry techniques with vacuum grippers are unsophisticated. These techniques generally consist of applying vacuum, lifting the gripper, and looking at coarse flow rate or weight sensors to determine whether an object has been acquired; if it has not, the gripper is placed back on the object and acquisition is re-attempted. This is due largely to two reasons: 1) most currently deployed vacuum gripping systems are customized so heavily for the material being acquired that acquisition failures are rare, resulting in no real need for rapid abort and retry cycles, and 2) no vacuum grippers exist with the type of sop

**[p0004]**

histicated instrumentation present in, for instance, a multi-fingered grasping type end effector. The result is that existing abort/retry algorithms cannot obtain from a vacuum gripper the information they need to be able to operate.

**[p0005]**

There remains a need, therefore, for an improved vacuum gripper for use in an articulated arm that provides improved performance in acquiring a wide variety of known and unknown objects.

### Summary

**[p0006]**

In accordance with an embodiment, the invention provides an end effector for an articulated arm. The end effector includes a valve assembly including a plurality of supply channels, each supply channel including a supply conduit, a pressure sensor in fluid communication with the supply conduit, and a supply conduit plug. The supply conduit is in fluid communication with a vacuum source. During use, each supply conduit is either at vacuum such that the pressure within the supply conduit is substantially at a vacuum pressure, or is at a pressure that is substantially higher than vacuum pressure because the supply conduit plug has moved to block a portion of the supply conduit. The pressure sensor of each supply conduit provides a pressure sensor signal responsive to whether the pressure in the conduit is either substantially at vacuum or is at a pressure that is substantially higher than vacuum. In accordance with another embodiment, the end effector includes a valve assembly including a plurality of supply channels, each supply channel including a supply conduit, a pressure sensor in fluid communication with the supply conduit, and a supply conduit plug. The supply conduit is in fluid communication with a vacuum source. During use, each supply conduit is either at vacuum such that the pressure within the supply conduit is substantially at a vacuum pressure, or is at a pressure that is substantially higher than vacuum pressure because the supply conduit plug has moved to block a portion of the supply conduit. The pad includes a plurality of defined apertures, each of which is

**[p0006]**

aligned with a respective supply conduit of the valve assembly, and the plurality of defined apertures in the pad include at least a first aperture and a second plurality of apertures, and wherein the at least the first aperture is centrally located with respect to the second plurality of apertures

**[p0007]**

In accordance with a further embodiment, the invention provides a method of providing a vacuum source to an end effector. The method includes the steps of providing within the end effector a valve assembly including a plurality of supply channels, each supply channel including a supply conduit, a pressure sensor in fluid communication with the supply conduit, and a supply conduit plug, providing a vacuum source in fluid communication with the supply conduit, permitting the supply conduit to be at a pressure that is substantially higher than vacuum pressure when the associated supply channel is not engaged with an object, permitting the supply conduit to be at vacuum such that the pressure within the supply conduit is substantially at a vacuum pressure when the supply channel is engaged with an object, and providing a pressure sensor signal responsive to whether the pressure in the conduit is either substantially at vacuum or is at a pressure that is substantially higher than vacuum.

### Brief Description Of The Drawing

**[p0008]**

The following description may be further understood with reference to the accompanying drawings in which: FIG. 1 shows an illustrative diagrammatic view of an end effector in accordance with an embodiment of the present invention; FIG. 2 shows an illustrative diagrammatic view of a portion of the check valve plate of the end effector of FIG. 1 with a ball plug urged against the top plate and providing a single opening in connection with the check valve; FIG. 3 shows an illustrative diagrammatic view of the portion of the check valve plate shown in FIG. 2 with the ball plug disengaged from the top plate; FIG. 4 show an illustrative diagrammatic isometric view of the sealing foam of the end effector of FIG. 1 ; FIG. 5 shows an illustrative diagrammatic bottom view of the sealing foam of FIG. 4 ; FIG. 6 shows an illustrative diagrammatic view of a portion of the check valve plate of the end effector of FIG. 1 with a ball plug urged against the top plate and providing vacuum to multiple openings in connection with the check valve;

**[p0009]**

FIG. 7 shows an illustrative diagrammatic view of the portion of the check valve plate shown in FIG. 6 with the ball plug disengaged from the top plate; FIG. 8 shows an illustrative diagrammatic block view of vacuum supply system for use with the end effector of FIG. 1 ; FIG. 9 shows an illustrative diagrammatic view of an example of the vacuum supply system of FIG. 8 ; FIGS. 10A and 10B show illustrative diagrammatic views of an end effector cover for use with an end effector on an embodiment of the invention; FIG. 11 shows an illustrative diagrammatic isometric view of an end effector in accordance with another embodiment of the invention; FIGS. 12A - 1 2D show illustrative diagrammatic views of end effector covers for use in accordance with further embodiments of the invention; and FIG. 13 shows an illustrative diagrammatic view of mounting hardware including load cells for mounting an end effector of the invention to a robotic arm. The drawings are shown for illustrative purposes only.

### Detailed Description

**[p0010]**

In accordance with various embodiments, the invention provides a new instrumented hybrid-modality vacuum gripper system that has three main features as follows. First, the system provides hybrid modality. The gripping surface is a unique design that incorporates the advantages of both the single large port configuration and the array of controlled ports configuration of vacuum gripper, resulting in a single device that is more effective than either previously existing configuration. Second, the system provides unique instrumentation. The gripper is mounted to the end effector using a load cell array, such that controlling software has precise knowledge of weights and torques being applied to the gripper by the acquired object. Each individual vacuum port in the gripping surface is also instrumented such that controlling software has precise knowledge of how well each individual port is gripping the object that is being acquired. Third, the novel software and algorithms provide that presented sensor data may be used to maximize the efficiency of abort/retry cycles using this instrumented gripper. The general approach of hybrid modality, instrumentation, and algorithms applied to vacuum grippers is illustrated, in part, by the following examples.

**[p0011]**

The instrumented gripper assembly in accordance with an embodiment is shown in FIG. 1 . The gripper assembly 10 includes a vacuum generation head 12 , a plenum block 14 , a check valve plate 16 , a screen plate 18 and sealing foam 20 having gripping surfaces 22 . The sealing foam includes two sets of apertures, one set that is generally centrally located with respect to the other set as further shown in FIGS. 6 and 7 . The vacuum generation and control is provided by moving compressed air through a control valve to a Venturi pump, which creates a vacuum for the gripper to distribute to the gripping surface. A second valve on the output of the Venturi pump allows one to blow-off acquired objects, as described above. The plenum block is provided below the Venturi pump, and the plenum block distributes the generated vacuum to each of the individual ports in series by means of a channels that are machined into the block. This approach minimizes the vacuum pressure required to check any individual port&#39;s control valve.

**[p0012]**

With further reference to FIG. 2 , the check valve plate consists of a number of chambers, each having a straight opening 30 at the bottom and a chamfered opening 32 at the top. A single such chamber (supply conduit) 34 is shown in detail in FIG. 2 , together with a supply conduit plug (ball) 36 and the opening to the vacuum plenum block 32 , and a pressure sensor 38 . The pressure sensor 38 is responsive to the pressure within the chamber 34 and provides a signal to a printed circuit board 40 in the check valve plate 16 . The screen plate 18 includes a plurality of screen openings in communication with chamber 34 . Each of the openings 30 and chambers 34 align with and are associated with a unique aperture in the sealing foam gripper 20 , and each check valve assembly (including the chamber 34 , opening 32 , conduit plug 36 and pressure sensor 38 ) functions independent of the other check valve assemblies. The top opening 32 mates to the plenum, thus providing a vacuum to the check valve chamber 34 . The bottom opening 30 delivers the vacuum through the screen plate 18 to the bottom surface of the gripper 20 , and thence to the object being acquired. The plug 36 in each check valve chamber is a plastic ball, of such a size and weight that if the bottom opening is open to atmosphere (i.e., not making contact with an object to be acquired) and a vacuum is applied to the top opening, the plastic ball 36 will be pulled by the vacuum up to the top opening, where it will seat firmly against the chamfer there and effectively seal that particular check valve port. By using these t

**[p0012]**

ypes of ports, it is ensured that any ports that are not actually making contact with an object to be acquired are sealed and not bleeding off vacuum pressure.

**[p0013]**

The screen plate 18 mounts to the bottom of the check valve plate 16 . It consists of a thin metal piece with openings that mate to each check valve. These openings are of such a size and shape (trefoil shape is used here) as to allow the ball 36 to sit on the opening without falling out, and without sealing the lower opening 30 . In this way, when the port is not making contact with an object to be acquired, air will flow through this opening, lifting the ball to the top of the chamber and sealing off that particular port. When the port is making contact with an object, the vacuum will be present in the chamber 34 and will hold the object against the surface 22 of the gripper 20 . Of significance in this design is the incorporated printed circuit board 40 . The check valve plate is split into two pieces, top and bottom as shown in FIG. 2 , and the printed circuit board 40 is sandwiched between these two halves. On the printed circuit board 40 is mounted an array of MEMS barometers, each of which is provided as a pressure sensor 38 for a port (again, a single port is shown in FIG. 2). These sensors (MEMS barometers) are placed such that they are able to detect the air pressure in the bottom of the valve chamber near the gripper surface. Other openings 30 in the gripper 20 are associated with other valve assemblies (including other chambers, openings, conduit plugs and pressure sensors).

**[p0014]**

When a vacuum is applied to the gripper, ports that are contacting the object being acquired will remain unchecked, meaning that the sensors in those ports will read vacuum pressure (&lt;&lt;1 atmosphere). Any ports that are not contacting the object will check, meaning the pressure in the bottom of the chamber will be equivalent to atmospheric pressure. By reading all of the sensors, the software system will know exactly which ports are checked and which are making solid contact (and thus providing gripping force) to the object being acquired. Even once an object has been acquired, if it starts to “peel off” of the gripper, or falls off completely, the sensor readings will change accordingly, allowing the software system to know this in real time. The gripper is circular at the gripping surface, as shown in FIGS. 4 and 5 . This shape and symmetry provide another degree of freedom to the software control system. Again, the gripping surface 22 consists of an array of ports, each of which has an integrated check valve and pressure sensor as described above. Further, the gripping surface is comprised of two sections, a radially inner section 50 and a radially outer section 52 . The sections are separated by a foam ring 54 , which encloses the central grouping of apertures 58 and extends beyond the rest of the gripping surface. The second piece of foam fits around the outside of the first foam ring and extends to the outer edge of the gripper surface. It contains individual apertures 30 for each vacuum port.

**[p0015]**

The effect of this arrangement is a hybrid modality gripper combining the benefits of the single-large-port (or “bag”) configuration and the array-of-controlled-ports configuration. The ports 58 in the middle (as shown in FIGS. 4 and 5 ) are all commonly open to each other within the foam ring, so that they can achieve the suction strength of a single large port while still being controlled with check valves. The foam ring is smaller and extends further than the rest of the gripping surface; this essentially acts as a secondary smaller gripper, allowing this device to access and acquire smaller object surfaces where the larger gripper could not otherwise fit. For larger items, simply pushing the entire device down to compress the foam ring will present the entire gripping surface to the object, allowing for compliant lifting of large objects with non-uniform surfaces. FIGS. 6 and 7 show the portion of the check valve plate that provides that multiple ports in the gripper may be commonly in communication with a single vacuum source. In particular, the central portion of the check valve plate includes a chamber 70 having straight openings 58 at the bottom and a chamfered opening 72 at the top. A single such chamber (supply conduit) 70 is shown in detail in FIG. 6 , together with a supply conduit plug (ball) 76 and the opening to the vacuum plenum block 72 , and a pressure sensor 74 . Again, the pressure sensor 74 is responsive to the pressure within the chamber 70 and provides a signal to the printed circuit board 40 in the check valve plate 16 . The screen plate 18 includes

**[p0015]**

screen openings aligned with chamber 70 . Each of the openings 58 are in communication with the chamber 70 .

**[p0016]**

The top opening 72 mates to the plenum, thus providing a vacuum to the check valve chamber 70 . The bottom openings 58 deliver the vacuum through the screen plate 18 to the bottom surface of the gripper 20 in the inner area 50 as a common group of apertures, and thence to the object being acquired. Again, the plug 76 in the check valve chamber is a plastic ball, of such a size and weight that if the bottom opening is open to atmosphere (i.e., not making contact with an object to be acquired) and a vacuum is applied to the top opening, the plastic ball 76 will be pulled by the vacuum up to the top opening, where it will seat firmly against the chamfer there and effectively seal that particular check valve port as shown in FIG. 6 . By using these types of ports, it is ensured that any ports that are not actually making contact with an object to be acquired are sealed and not bleeding off vacuum pressure. When the port is not making contact with an object to be acquired, air will flow through this opening, lifting the ball to the top of the chamber and sealing off that particular port. When the port is making contact with an object, the ball 76 will drop (as shown in FIG. 7 ) and the vacuum will be present in the chamber 70 and will hold the object against the surface of the gripper 20 in the inner area 50 .

**[p0017]**

This hybrid modality allows for successful acquisition of a much broader spectrum of objects than either prior type of vacuum gripper by itself. Heavy objects in plastic bags (e.g., a bag of oranges) typically cannot be acquired by standard port-array type vacuum grippers, but only by single large port type grippers; the central port grouping on the novel gripper presented here can acquire these objects. Another example is a bottle of shampoo standing upright; a typical single large port type gripper will be too large to seal to the top of the cap, and thus will not acquire the object. The novel gripper here can use a single port from the outer ring to seal to the shampoo cap; all other ports, including the central group, will check, allowing this device to successfully acquire the object. In other embodiments, different vacuum pressures may be applied to the inner set of apertures as compared to the outer set of apertures in a variety of ways, including for example, restricting air flow in the outer set of apertures.

**[p0018]**

This combination of power and flexibility is unique and powerful. By combining the benefits of multiple configurations, the result is greatly reduced or eliminated need for tool changing, along with the associated cost and time. In accordance with certain embodiments, the invention further provides a system for providing high flow vacuum control to an end effector of an articulated arm. In accordance with various embodiments, the invention provides a dynamic high flow gripping system, and may optionally include a mechanism to select between the high flow source and a high vacuum source, depending on the application. High flow vacuum systems of the invention may therefore optionally be used with high vacuum sources. The system, for example, may include a first vacuum source for providing a first vacuum pressure with a first maximum air flow rate (to for example, the inner area 50 ), and a second vacuum source for providing a second vacuum pressure with a second maximum air flow rate (to for example, the outer area 52 ). In certain embodiments, the second vacuum pressure is higher than the first vacuum pressure and wherein the second maximum air flow rate is greater than the first maximum air flow rate. The reverse also possible in other applications. The flow rates are characterized as maximum air flow rates because, when an object is engaged at an end effector, the flow rate may drop significantly. The high flow source may be used together with a high vacuum source, or as a single source.

**[p0019]**

FIG. 8 , for example, shows a system 100 for use with an end effector in accordance with an embodiment of the present invention in which an optional high vacuum source 102 is provided as well as a high flow source 104 and a release source 106 that are each coupled to a selection unit 108 , that is coupled to an end effector 110 . The selection unit 108 selects between the high vacuum source 102 , high flow source 104 and the release source 106 for providing any of high vacuum, vacuum with high flow, or a release flow to the end effector. FIG. 8 therefore shows a general form of the invention, comprising mechanisms for producing high vacuum and high flow, a release source providing either atmospheric pressure via a vent or high pressure (blow off) via a compressor or reservoir, and a mechanism for selecting the source best suited to the present situation. In particular, FIG. 9 shows a system 120 in accordance with an embodiment of the invention that includes a compressor 122 that is coupled to an ejector 124 to provide a high vacuum source that is coupled to a solenoid valve 126 . A blower 128 is also coupled to the solenoid valve 120 via a non-return valve 130 , and the blower 128 provides a vacuum source with a high maximum flow rate. A vent or blow-off source is also provided to the solenoid valve 120 , the output of which is provided to an end effector 132 . The system therefore, provides the ejector 124 as the high vacuum source, the regenerative blower 128 as the high flow source, the non-return valve 130 as a passive selection mechanism, and the solenoid valve 120 con

**[p0019]**

necting the effector to the release source, either vent or blow-off.

**[p0020]**

The vacuum pressure provided by the ejector 124 may be, for example, at least about 90,000 Pascals below atmospheric and the vacuum pressure provided by the blower 128 may be only no more than about 25,000 Pascals below atmospheric in some examples, and no more than about 50,000 Pascals below atmospheric in other examples. The vacuum pressure provided by the blower 128 is therefore higher than the vacuum pressure provided by the ejector 124 . The maximum air flow rate of the ejector may be, for example, no more than about 5 cubic feet per minute (e.g., 1-2 cubic feet per minute), and the maximum air flow rate of the blower may be, for example at least about 100 cubic feet per minute (e.g., 130-140 cubic feet per minute). In accordance with certain embodiments, therefore, end effectors of the invention may include a central region of a gripper surface that provides high flow gripping. In further embodiments, the surface at the central region of the gripper may include a specialized opening cover for use with a high flow vacuum gripper. In particular and as shown in FIGS. 10A (articulated arm facing side) and 10 B (object facing side), such a cover 140 may include a proximal back side 142 that does not permit air to flow through the material, and distal front side 144 for engaging objects that is formed of a foam material. Slit openings 146 in form of a star or asterisk shape are provided through the material in this example. During use, elongated objects may be received along opposing slit openings and held by the foam material.

**[p0021]**

The compliant foam on the surface 144 contacts the object to be acquired, giving the gripper some compliance while also acting to seal the aperture around the object as the foam is compressed and the high flow vacuum is applied. The aperture cover therefore allows a high flow gripper to effectively pick up long narrow objects with an easy to attach cover that may be held in a tool changer and added or removed from the gripper autonomously during real-time operation FIG. 11 shows an end effector gripper 150 having such a cover 140 used in connection with a gripper surface having an outer section 52 as discussed above, and an inner section 152 providing high flow through the cover 140 . The cover may also be flush with the circular wall 54 as shown. A system is therefore provided in an embodiment, for providing vacuum control to an end effector of an articulated arm, where the system includes a vacuum source for providing a vacuum pressure at a flow rate to the end effector, and the end effector includes a cover that includes an opening that varies significantly in radius from a center of the cover. The opening may include finger openings that extend radially from the center of the opening. The opening may be generally star shaped or asterisk shaped. The cover may include compliant foam on a distal side of the cover that engages an object to be grasped, and an air flow resistant material on a proximal side of the cover. The vacuum pressure may be no more than about 50,000 Pascals below atmospheric, and the air flow rate may be at least about 100 cubic feet per minute.

**[p0022]**

The invention therefore provides a system for providing vacuum control to an end effector of an articulated arm, where the system includes a vacuum source for providing a vacuum pressure at a flow rate to the end effector, and the end effector includes a cover including an air flow resistant material on a proximal side of the cover and a compliant material on a distal side of the cover for contacting objects to be grasped. The cover may include an opening that varies significantly in radius from a center of the cover, and the opening may include finger openings that extend radially from the center of the opening. The opening may be generally star shaped or asterisk shaped. The cover may be formed of a compliant material and include compliant foam on a distal side of the cover that engages an object to be grasped, and the cover may include an air flow resistant material on a proximal side of the cover. The vacuum pressure may be no more than about 25,000 Pascals or 50,000 Pascals below atmospheric, and the air flow rate may be at least about 100 cubic feet per minute.

**[p0023]**

Covers with other types of openings are shown in FIG. 12A - 1 2D. FIG. 12A , for example, shows a cover 160 that includes slit openings 162 . FIG. 12B shows a cover 170 that includes different sized square openings 172 , 174 . Cover 180 shown in FIG. 12C includes small circular openings 182 , and cover 190 shown in FIG. 1 2D includes differently shaped openings 192 and 194 . In each of the covers 140 , 160 , 170 , 180 and 190 , a compliant foam surface may face the object to be acquired, and more area of the cover is provided to be open closer to the center of the cover with respect to the outer periphery of each cover. For example, in the cover 140 , the center of the asterisks shape is most open. In the cover 160 , the larger slits are provided in the center. In the cover 170 , the larger square openings are provided in the center. In the cover 180 , the greater concentration of the circular openings is provided in the center, and in the cover 190 , the lager shape 192 is provided in the center.

**[p0024]**

The gripper assembly may be mounted to the end of a wide variety of 4- or 6-axis robotic arms. The mounting assembly 200 incorporates load cells, as shown in FIG. 13 . There are four load cells 202 , placed between the mounting bracket 204 at the end of the robotic arm and the top surface of the gripper body 206 . One of these load cells is placed at each corner of the gripper body, allowing the SW system to precisely know the distribution of weight of an acquired object and the resulting forces and torques that the object is placing on the gripper. These sensors will also detect if an object has fallen off of the gripper during acquisition or movement; the Software system will integrate this data with the data provided by the array of pressure sensors in the check valve block to provide input to the algorithms that are maximizing abort/retry efficiency and speed. The system therefore, does not require the use of sophisticated software algorithms that use probabilistic and predictive processes to maximize speed and efficiency of acquisition/failure/abort/retry cycles with multi-fingered hand-type grasping end effectors. These algorithms rely on precise data about joint angles and motor speeds/currents/torques as well as image data from 2D or 3D camera systems to know whether or not an acquisition has been successful and plan a retry if necessary. Because vacuum grippers have previously lacked any type of similarly sophisticated sensing, and because previous applications have been limited and highly controlled, these algorithms have not been applied previously to vacuum grip

**[p0024]**

ping situations.

**[p0025]**

The novel gripper described here provides such data using inexpensive sensors (load cells and MEMS barometers). When the gripper is placed on an object and the vacuum is enabled, the software control system will immediately have a map of which ports are providing suction to the object and which are checked closed. With a priori knowledge of the object (from 2D/3D imaging and database matching, for instance), the SW will be able to calculate a success percentage for object acquisition. If the percentage is below a threshold, the control system can shut off vacuum and reposition the gripper to try again quickly without having to actually attempt and fail at acquisition first. This will greatly enhance retry speed. If the percentage is above some threshold, the control system can raise the gripper. At this point, the data from the load cell array will begin to tell the control system whether or not the object weight is being lifted, and at what position and torque. As the object is being moved, the load cell and port pressure data will also warn the control system if the acquisition is failing and the object is going to fall, allowing the control system to take appropriate action.

**[p0026]**

This data will provide the software control system a real time picture of where, how, and how well an object is acquired, from before the gripper has even been moved all the way through object delivery and release. This data can be used by a software control system as input for efficient abort/retry algorithms previously only used by more sophisticated manipulators. The instrumented hybrid-modality vacuum gripper presented here therefore, combines the benefits of prior vacuum gripper configurations into a single device, at the same time integrating sensors that provide the kind of detailed acquisition data needed to enable advanced abort/retry efficiency software algorithms previously reserved for more sophisticated multi-finger type grippers. The result is a single inexpensive end effector that can be used to rapidly and efficiently acquire and move a very broad spectrum of object types, sizes, weights, and packaging types, in a variety of orientations. Those skilled in the art will appreciate that numerous modifications and variations may be made to the above disclosed embodiments with departing from the spirit and scope of the present invention

## Figure captions

- **Figure 1:** FIG. 1 shows an illustrative diagrammatic view of an end effector in accordance with an embodiment of the present invention;
- **Figure 2:** FIG. 2 shows an illustrative diagrammatic view of a portion of the check valve plate of the end effector of FIG. 1 with a ball plug urged against the top plate and providing a single opening in connection with the check valve;
- **Figure 3:** FIG. 3 shows an illustrative diagrammatic view of the portion of the check valve plate shown in FIG. 2 with the ball plug disengaged from the top plate;
- **Figure 4:** FIG. 4 show an illustrative diagrammatic isometric view of the sealing foam of the end effector of FIG. 1 ;
- **Figure 5:** FIG. 5 shows an illustrative diagrammatic bottom view of the sealing foam of FIG. 4 ;
- **Figure 6:** FIG. 6 shows an illustrative diagrammatic view of a portion of the check valve plate of the end effector of FIG. 1 with a ball plug urged against the top plate and providing vacuum to multiple openings in connection with the check valve;
- **Figure 7:** FIG. 7 shows an illustrative diagrammatic view of the portion of the check valve plate shown in FIG. 6 with the ball plug disengaged from the top plate;
- **Figure 8:** FIG. 8 shows an illustrative diagrammatic block view of vacuum supply system for use with the end effector of FIG. 1 ;
- **Figure 9:** FIG. 9 shows an illustrative diagrammatic view of an example of the vacuum supply system of FIG. 8 ;
- **Figure 10A:** FIGS. 10A and 10B show illustrative diagrammatic views of an end effector cover for use with an end effector on an embodiment of the invention;
- **Figure 11:** FIG. 11 shows an illustrative diagrammatic isometric view of an end effector in accordance with another embodiment of the invention;
- **Figure 12A:** FIGS. 12A - 1 2D show illustrative diagrammatic views of end effector covers for use in accordance with further embodiments of the invention; and
- **Figure 13:** FIG. 13 shows an illustrative diagrammatic view of mounting hardware including load cells for mounting an end effector of the invention to a robotic arm.
- **Figure 11:** FIG. 11 shows an end effector gripper 150 having such a cover 140 used in connection with a gripper surface having an outer section 52 as discussed above, and an inner section 152 providing high flow through the cover 140 . The cover may also be flush with the circular wall 54 as shown.

## Classifications

- B25J15/0616
- B25J15/0625
- B25J15/0625
- B25J15/0633
- B25J15/06
- B25J15/0633
- B25J15/0658
- B25J15/0658
- B25J15/0691
- B25J15/0691
- B65G47/91
- B65G47/91

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
