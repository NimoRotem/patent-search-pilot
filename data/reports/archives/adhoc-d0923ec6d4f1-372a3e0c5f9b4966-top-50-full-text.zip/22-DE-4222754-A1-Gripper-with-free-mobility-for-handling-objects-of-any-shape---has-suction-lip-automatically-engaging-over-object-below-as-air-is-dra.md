# 22. Gripper with free mobility for handling objects of any shape - has suction lip automatically engaging over object below as air is drawn in through pump

- **Archive rank:** 22 of 50
- **Publication:** [DE-4222754-A1](https://patents.google.com/patent/DE4222754A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/006462956/publication/DE4222754A1?q=pn%3DDE4222754A1)
- **Publication date:** 1994-01-13
- **Filing date:** 1992-07-10
- **Earliest priority:** 1992-07-10
- **Family:** 6462956
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** SPICHER GMBH HERMANN
- **Inventors:** SPICHER HERMANN

## Abstract

The gripper is a tubular section with a ring-shaped suction lip (3) at its free end. The suction lip is made from an elastically soft deformable material such as foam rubber and has a least one suction intake opening (4). The lip is connected to the tube (2) by a pump unit. The tube is made of a permanently elastic material such as a hose of rubber or plastics and has an extension (2) which can be deflected sideways. The suction lip can be detachably connected to the tubular extension by a flanged connector pipe. ADVANTAGE - The gripper can be positioned anywhere over any object.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-4222754-A1/ops000.png)

![Sketch 1 for DE-4222754-A1](https://nimo.iptorch.com/refdrawing/DE-4222754-A1/ops000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-4222754-A1/ops001.png)

![Sketch 2 for DE-4222754-A1](https://nimo.iptorch.com/refdrawing/DE-4222754-A1/ops001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/DE-4222754-A1/ops002.png)

![Sketch 3 for DE-4222754-A1](https://nimo.iptorch.com/refdrawing/DE-4222754-A1/ops002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/DE-4222754-A1/ops003.png)

![Sketch 4 for DE-4222754-A1](https://nimo.iptorch.com/refdrawing/DE-4222754-A1/ops003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/DE-4222754-A1/ops004.png)

![Sketch 5 for DE-4222754-A1](https://nimo.iptorch.com/refdrawing/DE-4222754-A1/ops004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/DE-4222754-A1/ops005.png)

![Sketch 6 for DE-4222754-A1](https://nimo.iptorch.com/refdrawing/DE-4222754-A1/ops005.png)

## Claims

### Claim 1 (independent)

Greifwerkzeug zur Entnahme von geordnet oder ungeordnet in einem Behälter oder auf einer Palette lagernden regelmäßig oder unregelmäßig geformten Gegenständen aller Art und zur einzelnen oder portionsweisen Ablage derselben außerhalb des Behälters oder der Palette, wobei das Greifwerkzeug mit einer Bewegungseinrichtung mit mehreren Freiheitsgraden verbunden ist, da­ durch gekennzeichnet, daß das Greif­ werkzeug (1) aus einem Rohrstück besteht an dessen freien Ende eine ringförmige Ansauglippe (3) angeordnet ist, die wenigstens eine Ansaugöffnung (4) aufweist, daß die Ansauglippe (3) aus einem elastisch weich ver­ formbaren Material besteht und daß die Ansauglippe (3) über das Rohrstück mit einer Pumpvorrichtung verbunden ist.1. Gripping tool for the removal of regularly or irregularly shaped objects of all types stored in a container or on a pallet in an orderly or unordered manner and for storing them individually or in portions outside the container or the pallet, the gripping tool being connected to a movement device with several degrees of freedom, characterized in that the gripping tool ( 1 ) consists of a tube piece at the free end of which there is an annular suction lip ( 3 ) which has at least one suction opening ( 4 ) that the suction lip ( 3 ) is made of an elastically soft, deformable material exists and that the suction lip ( 3 ) is connected to a pump device via the pipe section.

### Claim 2

Greifwerkzeug nach Anspruch 1, dadurch ge­ kennzeichnet, daß das Rohrstück als wenig­ stens seitlich auslenkbarer Rohrfortsatz (2) ausgebil­ det ist.2. Gripping tool according to claim 1, characterized in that the tube piece as a least least laterally deflectable tube extension ( 2 ) is ausgebil det.

### Claim 3

Greifwerkzeug nach Anspruch 1 und 2, dadurch gekennzeichnet, daß der Rohrfortsatz (2) aus einem dauerelastischem Material besteht.3. Gripping tool according to claim 1 and 2, characterized in that the tubular extension ( 2 ) consists of a permanently elastic material.

### Claim 4

Greifwerkzeug nach Anspruch 2 und 3, dadurch gekennzeichnet, daß der Rohrfortsatz (2) aus einem Schlauchabschnitt besteht. Gripping tool according to claim 2 and 3, characterized in that the tubular extension ( 2 ) consists of a hose section.

### Claim 5

Greifwerkzeug nach Anspruch 2 bis 4, dadurch gekennzeichnet, daß der Rohrfortsatz (2) aus einem Wellschlauch besteht.5. Gripping tool according to claim 2 to 4, characterized in that the tubular extension ( 2 ) consists of a corrugated hose.

### Claim 6

Greifwerkzeug nach einem der Ansprüche 2 bis 5, da­ durch gekennzeichnet, daß der Rohr­ fortsatz (2) über seine gesamte Länge mit einer schrau­ benlinienförmig umlaufenden Armierung versehen ist.6. Gripping tool according to one of claims 2 to 5, characterized in that the pipe extension ( 2 ) is provided over its entire length with a screw benlinie-shaped circumferential reinforcement.

### Claim 7

Greifwerkzeug nach einem der Ansprüche 1 bis 6, da­ durch gekennzeichnet, daß der Rohr­ fortsatz (2) aus Gummi oder einem Kunststoff besteht.7. Gripping tool according to one of claims 1 to 6, characterized in that the pipe extension ( 2 ) consists of rubber or a plastic.

### Claim 8

Greifwerkzeug nach den Ansprüchen 1 bis 7, da­ durch gekennzeichnet, daß die An­ sauglippe (3) aus einem offen- oder geschlossenzelligen Moosgummi besteht.8. Gripping tool according to claims 1 to 7, characterized in that the suction lip ( 3 ) consists of an open or closed-cell foam rubber.

### Claim 9

Greifwerkzeug nach den Ansprüchen 1 bis 7, da­ durch gekennzeichnet, daß die An­ sauglippe (3) aus Schaumgummi besteht.9. Gripping tool according to claims 1 to 7, characterized in that the suction lip ( 3 ) is made of foam rubber.

### Claim 10

Greifwerkzeug nach den Ansprüchen 1 bis 9, da­ durch gekennzeichnet, daß die An­ sauglippe (3) auswechselbar mit dem Rohrfortsatz (2) verbunden ist.10. Gripping tool according to claims 1 to 9, characterized in that the suction lip ( 3 ) is exchangeably connected to the tubular extension ( 2 ).

### Claim 11

Greifwerkzeug nach einem der Ansprüche 1 bis 10, da­ durch gekennzeichnet, daß im unteren Ende des Rohrfortsatzes (2) ein Anschlußstutzen (5) eingesetzt ist, daß der Anschlußstutzen (5) einen Flansch (6) aufweist und daß die Ansauglippe (3) form­ schlüssig über diesen Flansch (6) geschoben ist.11. Gripping tool according to one of claims 1 to 10, characterized in that a connecting piece ( 5 ) is inserted in the lower end of the tubular extension ( 2 ), that the connecting piece ( 5 ) has a flange ( 6 ) and that the suction lip ( 3rd ) is pushed positively over this flange ( 6 ).

### Claim 12

Greifwerkzeug nach einem der Ansprüche 1 bis 11, da­ durch gekennzeichnet, daß die An­ sauglippe (3) mit einem Bund (7) versehen ist, der mit dem Flansch (6) verbindbar ist.12. Gripping tool according to one of claims 1 to 11, characterized in that the suction lip ( 3 ) is provided with a collar ( 7 ) which can be connected to the flange ( 6 ).

### Claim 13

Greifwerkzeug nach Anspruch 12, dadurch ge­ kennzeichnet, daß sich die Ansauglippe (3) im Anschluß an den Bund (7) nach unten erweitert.13. Gripping tool according to claim 12, characterized in that the suction lip ( 3 ) extends downward following the collar ( 7 ).

### Claim 14

Greifwerkzeug nach Anspruch 12 und 13, dadurch gekennzeichnet, daß die Wandstärke der Ansauglippe (3) über deren Länge konstant ist.14. Gripping tool according to claim 12 and 13, characterized in that the wall thickness of the suction lip ( 3 ) is constant over its length.

### Claim 15

Greifwerkzeug nach Anspruch 12 und 13, dadurch gekennzeichnet, daß die Wandstärke der Ansauglippe (3) in Richtung zur Ansaugöffnung (4) zu­ nimmt.15. Gripping tool according to claim 12 and 13, characterized in that the wall thickness of the suction lip ( 3 ) increases towards the suction opening ( 4 ).

### Claim 16

Greifwerkzeug nach Anspruch 12 und 13, dadurch gekennzeichnet, daß daß die Wandstärke der Ansauglippe (3) in Richtung zur Ansaugöffnung (4) ab­ nimmt.16. Gripping tool according to claim 12 and 13, characterized in that the wall thickness of the suction lip ( 3 ) in the direction of the suction opening ( 4 ) decreases.

### Claim 17

Greifwerkzeug nach einem der Ansprüche 8 bis 16, da­ durch gekennzeichnet, daß sich der Querschnitt der Ansauglippe (3) in Richtung zur Ansaug­ öffnung (4) konisch erweitert.17. Gripping tool according to one of claims 8 to 16, characterized in that the cross section of the suction lip ( 3 ) in the direction of the suction opening ( 4 ) widens conically.

### Claim 18

Greifwerkzeug nach Anspruch 17, dadurch ge­ kennzeichnet, daß in der konischen Erweite­ rung der Ansauglippe (3) zwei Ansaugöffnungen (4, 4′) nebeneinander angeordnet sind.18. Gripping tool according to claim 17, characterized in that in the conical widening of the suction lip ( 3 ) two suction openings ( 4 , 4 ') are arranged side by side.

### Claim 19

Greifwerkzeug nach Anspruch 18, dadurch ge­ kennzeichnet, daß die Ansaugöffnungen (4, 4′) durch einen Mittelsteg (9) voneinander getrennt sind. Gripping tool according to claim 18, characterized in that the suction openings ( 4 , 4 ') are separated from one another by a central web ( 9 ).

### Claim 20

Greifwerkzeug nach Anspruch 18, dadurch ge­ kennzeichnet, daß die Ansaugöffnungen (4, 4′) durch eine Einschnürung (10) voneinander getrennt sind.20. Gripping tool according to claim 18, characterized in that the suction openings ( 4 , 4 ') are separated from one another by a constriction ( 10 ).

### Claim 21

Greifwerkzeug nach einem der Ansprüche 1 bis 20, da­ durch gekennzeichnet, daß die An­ sauglippe (3) mit einer außen umlaufenden Dichtfläche (8) versehen ist.21. Gripping tool according to one of claims 1 to 20, characterized in that the suction lip ( 3 ) is provided with an outer circumferential sealing surface ( 8 ).

## Full description

PERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippers

Description

Translated from German

Die Erfindung betrifft ein Greifwerkzeug zur Entnahme von

geordnet oder ungeordnet in einem BehÃ¤lter oder auf einer

Palette lagernden GegenstÃ¤nden aller Art und zur einzelnen

oder portionsweisen Ablage derselben auÃerhalb des BehÃ¤lters

oder der Palette, wobei das Greifwerkzeug mit einer BeÂ­

wegungseinrichtung mit mehreren Freiheitsgraden verbunden

ist.The invention relates to a gripping tool for removing

ordered or disordered in a container or on a

Pallet-storing objects of all kinds and for individual

or placing them in portions outside the container

or the pallet, the gripping tool with a loading

motion device connected with several degrees of freedom

is.

FÃ¼r die Vereinzelung von WerkstÃ¼cken aus BehÃ¤ltern oder von

Paletten sind unterschiedliche Vorrichtungen bekannt, die

entweder mit einer Magneteinrichtung zum Vereinzeln von

magnetisierbaren GegenstÃ¤nden versehen sind, oder mit GreiÂ­

fern oder Saughebern ausgestattet sind. Sollen jedoch nichtÂ­

magnetisierbare WerkstÃ¼cke vereinzelt werden, so kommen nur

Greifer oder auch Saugheber in Betracht.For the separation of workpieces from containers or from

Different devices are known for pallets

either with a magnetic device for separating

magnetizable objects are provided, or with Grei

remote or suction lifters. However, they shouldn't

magnetizable workpieces are separated, only come

Gripper or suction lifter into consideration.

Beim Einsatz der bekannten Greifer bzw. Saugheber ist eine

mÃ¶glichst prÃ¤zise Positionierung der Werkzeuge relativ zu

den zu vereinzelnden GegenstÃ¤nden erforderlich, damit diese

mÃ¶glichst sicher erfaÃt werden kÃ¶nnen. Bei vÃ¶llig ungeordnet

liegenden WerkstÃ¼cken ist daher ein sicheres Erfassen nicht

immer gewÃ¤hrleistet. Moderne BehÃ¤lter, insbesondere solche,

die fÃ¼r den Transport schwerer Teile sehr stabil ausgebildet

sein mÃ¼ssen, weisen einen oberen, zumindest in einigen BeÂ­

reichen teilweise nach innen gezogenen Rand auf oder sind in

diesem Bereich nach innen durch Ã¤uÃere Einwirkung dauerhaft

verbogen. Damit ist es mit den bekannten Greifwerkzeugen und

Entnahmevorrichtungen folglich schwierig, GegenstÃ¤nde aus

den unteren seitlichen Bereichen und den Ecken zu entnehmen.

Dadurch ist eine vollstÃ¤ndige automatische Entleerung solÂ­

cher BehÃ¤lter nicht mÃ¶glich, oder zumindest schwierig.When using the known gripper or siphon is one

positioning the tools as precisely as possible relative to

the items to be separated, so that these

can be detected as safely as possible. When completely disordered

lying workpieces is therefore not a reliable grasp

always guaranteed. Modern containers, especially those

which are very stable for the transport of heavy parts

must be an upper one, at least in some Be

partially extend towards the inside or are in

this area internally by external influence

bent. So it is with the known gripping tools and

Withdrawal devices are consequently difficult to remove items from

Â the lower side areas and the corners.

This ensures complete automatic emptying

cher container not possible, or at least difficult.

Besondere Schwierigkeiten entstehen bei der Vereinzelung von

GegenstÃ¤nden aus nichtmagnetischen Materialien und mit unreÂ­

gelmÃ¤Ãiger Form, da diese entweder Ã¼berhaupt nicht, oder nur

sehr unsicher erfaÃt werden.There are particular difficulties in isolating

Objects made of non-magnetic materials and with unre

of a more regular form, since either not at all or only

very insecure.

Der Erfindung liegt deshalb die Aufgabe zugrunde, ein GreifÂ­

werkzeug zur Entnahme von geordnet oder ungeordnet in einem

BehÃ¤lter oder auf einer Palette lagernden regelmÃ¤Ãig oder

unregelmÃ¤Ãig geformten GegenstÃ¤nden aller Art zu schaffen,

mit dem auf einfache Weise ein sicheres Erfassen und TransÂ­

portieren aller GegenstÃ¤nde gewÃ¤hrleistet wird und mit dem

eine vollstÃ¤ndige Entleerung des BehÃ¤lters ermÃ¶glicht wird.The invention is therefore based on the object of a griffin

Tool for removing ordered or unordered in one

Containers or regularly or on a pallet

to create irregularly shaped objects of all kinds,

with which a secure detection and trans

porting of all objects is guaranteed and with the

a complete emptying of the container is made possible.

Die Erfindung bezieht sich auf ein Greifwerkzeug zur EntnahÂ­

me von geordnet oder ungeordnet in einem BehÃ¤lter oder auf

einer Palette lagernden GegenstÃ¤nden aller Art und zur einÂ­

zelnen oder portionsweisen Ablage derselben auÃerhalb des

BehÃ¤lters oder der Palette, wobei das Greifwerkzeug mit

einer Bewegungseinrichtung mit mehreren Freiheitsgraden

verbunden ist.The invention relates to a gripping tool for removal

me from ordered or disordered in a container or on

a pallet of objects of all kinds and for one

individual or portioned storage of the same outside the

Container or the pallet, the gripping tool with

a movement device with several degrees of freedom

connected is.

Die der Erfindung zugrundeliegende Aufgabe wird dadurch

gelÃ¶st, daÃ das Greifwerkzeug aus einem RohrstÃ¼ck besteht,

an dessen freien Ende eine ringfÃ¶rmige Ansauglippe angeordÂ­

net ist, die wenigstens eine AnsaugÃ¶ffnung aufweist, daÃ die

Ansauglippe aus einem elastisch weich verformbaren Material

besteht und daÃ die Ansauglippe Ã¼ber das RohrstÃ¼ck mit einer

Pumpvorrichtung verbunden ist.The object underlying the invention is thereby

solved that the gripping tool consists of a piece of pipe,

arranged at the free end of an annular suction lip

is net, which has at least one suction opening that the

Suction lip made of an elastically soft deformable material

exists and that the suction lip over the pipe section with a

Pump device is connected.

Durch das erfindungsgemÃ¤Ãe Greifwerkzeug kÃ¶nnen beliebige

GegenstÃ¤nde auch dann problemlos vereinzelt werden, wenn

diese vÃ¶llig ungeordnet Ã¼bereinanderliegen. Dazu ist das

Greifwerkzeug Ã¼ber einer beliebigen Stelle Ã¼ber einem oder

den zu vereinzelnden GegenstÃ¤nden zu positionieren und anÂ­

schlieÃend auf diese abzusenken. Dabei kann die Ansauglippe

den zu vereinzelnden Gegenstand zumindest teilweise umgreiÂ­

fen, indem sie sich dessen Form anpaÃt und damit selbst

ausrichtet.With the gripping tool according to the invention, any

Objects can be easily separated even if

these lie completely one on top of the other. Thatâs it

Gripping tool over any point over or

Â to position the objects to be separated and on

then lower on this. The suction lip can

at least partially outlines the object to be separated

by adapting to its shape and thus itself

aligns.

Bereits wÃ¤hrend des Absenkens kann Ã¼ber die Pumpvorrichtung

Luft durch die Ansauglippe gesaugt werden, so daÃ sich das

Greifwerkzeug beim Aufsetzen auf einen Gegenstand selbstÂ­

tÃ¤tig festsaugt. Die vorstehend beschriebene SelbstausrichÂ­

tung des Greifwerkzeuges wird bei diesem Vorgang noch unterÂ­

stÃ¼tzt. Dadurch ist es problemlos mÃ¶glich, auch solche GeÂ­

genstÃ¤nde zu vereinzeln, bzw. aus einem BehÃ¤lter herauszuheÂ­

ben, die beispielsweise schrÃ¤g liegen.Already during the lowering, the pump device

Air is sucked through the suction lip, so that the

Gripping tool when placing it on an object itself

actively sucked. The self-alignment described above

tion of the gripping tool is still under this process

supports. As a result, it is easily possible, even such Ge

to separate objects or to lift them out of a container

ben, which are inclined, for example.

In einer Fortbildung der Erfindung ist das RohrstÃ¼ck als

wenigstens seitlich auslenkbarer flexibler Rohrfortsatz

ausgebildet.In a development of the invention, the pipe section is as

flexible tube extension that can be deflected at least to the side

educated.

Damit kann sich das Greifwerkzeug besonders bei groÃflÃ¤chiÂ­

gen GegenstÃ¤nden durch den flexiblen Rohrabschnitt problemÂ­

los auch dann an dieselben anlegen, wenn diese ungeordnet

Ã¼bereinanderliegen, oder schrÃ¤g gestapelt sind, d. h. das

Greifwerkzeug bewegt sich selbsttÃ¤tig immer in die jeweils

gÃ¼nstigste Position. Dadurch ist es problemlos mÃ¶glich, auch

solche GegenstÃ¤nde zu Vereinzeln, bzw. aus einem BehÃ¤lter

herauszuheben, die in an sich schwer zugÃ¤nglichen Ecken oder

unter einem nach innen gezogenen Rand liegen. AuÃerdem wird

durch diese Fortbildung der Erfindung der Effekt der SelbstÂ­

ausrichtung noch weiter verbessert, so daÃ auch ein seitliÂ­

ches Umgreifen von zu vereinzelnden GegenstÃ¤nden ermÃ¶glicht

wird. Genausogut kÃ¶nnen dadurch vÃ¶llig unregelmÃ¤Ãige GegenÂ­

stÃ¤nde, wie ZahnrÃ¤der o. dgl. problemlos vereinzelt werden.This means that the gripping tool can be used especially in large areas

problem due to the flexible pipe section problem

let's put them on even if they are disordered

lie one on top of the other, or are stacked at an angle, d. H. the

Gripping tool always moves automatically into each

most favorable position. This makes it easily possible, too

to separate such objects, or from a container

to highlight those in corners or difficult to access

lie under an inwardly drawn edge. Besides, will

through this development of the invention the effect of self

alignment even further improved, so that a side

grasping objects to be separated

becomes. As a result, completely irregular counterparts can be created

stands, such as gears or the like, are easily separated.

Um auch besonders leichte GegenstÃ¤nde nach dem Vereinzeln

sicher ablegen zu kÃ¶nnen, kann der Luftstrom in der AnsaugÂ­

lippe umgekehrt und Luft herausgeblasen werden. Bei diesem

Vorgang kÃ¶nnen auch festgeklemmte Verunreinigungen oder

GegenstÃ¤nde aus der Ansauglippe entfernt werden.For even particularly light objects after separation

The airflow in the intake can be stored safely

lip reversed and air blown out. With this

Â Clamped impurities or jams can also occur

Objects are removed from the suction lip.

Der Rohrfortsatz besteht zweckmÃ¤Ãigerweise aus einem dauereÂ­

lastischen Material, beispielsweise aus einem SchlauchabÂ­

schnitt.The pipe extension expediently consists of a permanent one

elastic material, for example from a hose

cut.

Um den Rohrfortsatz besonders flexibel zu gestalten, besteht

dieser vorteilhaft aus einem Wellschlauch, der gleichzeitig

eine gewisse LÃ¤ngselastizitÃ¤t aufweist.In order to make the pipe extension particularly flexible, there is

this advantageously from a corrugated hose, which at the same time

has a certain longitudinal elasticity.

Um auch schwerere GegenstÃ¤nde vereinzeln zu kÃ¶nnen, ist es

zweckmÃ¤Ãig, daÃ der Rohrfortsatz Ã¼ber seine gesamte LÃ¤nge

mit einer schraubenlinienfÃ¶rmig umlaufenden Armierung verÂ­

sehen ist.In order to be able to separate even heavier objects, it is

expedient that the tubular extension over its entire length

with a helical circumferential reinforcement

see is.

In einer Ausgestaltung der Erfindung besteht der RohrfortÂ­

satz aus Gummi oder einem Kunststoff, so daÃ Ã¼ber dessen

Lebensdauer eine gleichbleibende ElastizitÃ¤t gewÃ¤hrleistet

wird.In one embodiment of the invention there is the pipe fort

Set of rubber or a plastic, so that over it

Lifespan ensures constant elasticity

becomes.

Um ein mÃ¶glichst leichtes Umgreifen der GegenstÃ¤nde, oder

ein gutes Anlegen des Greifwerkzeuges an FlÃ¤chenteile der

GegenstÃ¤nde zu erreichen, besteht die Ansauglippe zweckmÃ¤Ãig

aus einem offen- oder geschlossenzelligen Moosgummi oder

auch aus einem Schaumgummi.To grasp the objects as easily as possible, or

a good application of the gripping tool to surface parts of the

To reach objects, the suction lip is useful

from an open or closed cell foam rubber or

also from a foam.

In FortfÃ¼hrung der Erfindung ist die Ansauglippe auswechselÂ­

bar mit dem Rohrfortsatz verbunden, dazu ist im unteren Ende

des Rohrfortsatzes ein AnschluÃstutzen eingesetzt, der mit

einem Flansch versehen ist, Ã¼ber den die Ansauglippe formÂ­

schlÃ¼ssig geschoben ist. Zur sicheren Befestigung der AnÂ­

sauglippe ist diese mit einem Bund versehen, der mit dem

Flansch verbindbar ist.In continuation of the invention, the suction lip is to be replaced

bar connected to the pipe extension, this is in the lower end

of the tubular extension, a connecting piece used with

is provided with a flange over which the suction lip is shaped

is finally pushed. For secure attachment of the An

suction lip, this is provided with a collar that with the

Flange is connectable.

Durch diese Ausgestaltungen der Erfindung kann das GreifÂ­

werkzeug leicht an unterschiedliche zu vereinzelnde GegenÂ­

stÃ¤nde angepaÃt werden, indem unterschiedliche Ansauglippen

eingesetzt werden.With these configurations of the invention, the gripping device

tool easily on different counter to be separated

Â be adjusted by using different suction lips

be used.

Beispielsweise kann die Ansauglippe so gestaltet sein, daÃ

sie sich im AnschluÃ an den Bund nach unten erweitert, wobei

die WandstÃ¤rke der Ansauglippe Ã¼ber deren LÃ¤nge konstant

ist.For example, the suction lip can be designed so that

it widens downwards after the federal government, whereby

the wall thickness of the suction lip is constant over its length

is.

Zur Realisierung unterschiedlicher AnsaugkrÃ¤fte entsprechend

der Erfordernisse kann die WandstÃ¤rke der Ansauglippe in

Richtung zur AnsaugÃ¶ffnung zu- oder abnehmen.To realize different suction forces accordingly

the wall thickness of the suction lip can meet the requirements

Increase or decrease the direction to the suction opening.

In einer weiteren Ausgestaltung der Erfindung erweitert sich

der Querschnitt der Ansauglippe in Richtung zur AnsaugÃ¶ffÂ­

nung konisch.In a further embodiment of the invention, it expands

the cross section of the suction lip towards the intake opening

tapered.

Zum Vereinzeln von besonders groÃflÃ¤chigen GegenstÃ¤nden, die

gegebenenfalls auch verhÃ¤ltnismÃ¤Ãig schwer sind, sind in der

konischen Erweiterung der Ansauglippe zwei AnsaugÃ¶ffnungen

nebeneinander angeordnet, wobei die AnsaugÃ¶ffnungen durch

einen Mittelsteg oder eine EinschnÃ¼rung voneinander getrennt

sind. Diese AusfÃ¼hrung erhÃ¶ht darÃ¼ber hinaus bei kleinen

Teilen die FÃ¶rder- bzw. MitnahmekapazitÃ¤t.For separating particularly large objects, the

if necessary, are also relatively difficult, are in the

conical extension of the suction lip two suction openings

arranged side by side, with the suction openings through

a center bar or a constriction separated

are. This version also increases for small ones

Share the funding or take-along capacity.

ZusÃ¤tzlich kann die Ansauglippe mit einer auÃen umlaufenden

DichtflÃ¤che versehen sein, wodurch ein schnelleres Ansaugen

erreicht wird.In addition, the suction lip with an outer circumferential

Be provided sealing surface, which means faster suction

is achieved.

Die Erfindung wird nachfolgend an einigen AusfÃ¼hrungsbeiÂ­

spielen nÃ¤her erlÃ¤utert. In den zugehÃ¶rigen Zeichnungen

zeigen:The invention is illustrated below in some embodiments

play explained in more detail. In the accompanying drawings

demonstrate:

Fig. 1 eine Seitenansicht des Greifwerkzeuges; Fig. 1 is a side view of the gripping tool;

Fig. 2 eine Schnittdarstellung einer Ansauglippe;

Fig. 2 is a sectional view of an intake lip;

Fig. 3 eine Seitenansicht des Greifwerkzeuges mit einer

Ansauglippe mit in Richtung zur AnsaugÃ¶ffnung zuÂ­

nehmender WandstÃ¤rke; Figure 3 is a side view of the gripping tool with a Ansauglippe with in the direction of the suction opening to be taken wall thickness.

Fig. 4 eine Schnittdarstellung der Ansauglippe nach Fig.

3; Fig. 4 is a sectional view of the suction lip of Fig. 3;

Fig. 5 eine Seitenansicht des Greifwerkzeuges mit einer

Ansauglippe mit in Richtung zur AnsaugÃ¶ffnung abÂ­

nehmender WandstÃ¤rke; Figure 5 is a side view of the gripping tool with a suction lip with increasing wall thickness in the direction of the suction opening.

Fig. 6 eine Schnittdarstellung der Ansauglippe nach Fig.

5; Fig. 6 is a sectional view of the suction lip of FIG. 5;

Fig. 7 eine Seitenansicht des Greifwerkzeuges mit sich

konisch erweiternder Ansauglippe; Fig. 7 is a side view of the gripping tool with conically widening Ansauglippe;

Fig. 8 eine Schnittdarstellung der Ansauglippe nach Fig.

7; Fig. 8 is a sectional view of the suction lip of Fig. 7;

Fig. 9 eine Seitenansicht des Greifwerkzeuges mit zwei

AnsaugÃ¶ffnungen und einem dazwischenbefindlichen

Steg; Figure 9 is a side view of the gripping tool having two suction ports and a dazwischenbefindlichen web.

Fig. 10 eine Schnittdarstellung der Ansauglippe nach Fig.

9; Fig. 10 is a sectional view of the suction lip of FIG. 9;

Fig. 11 eine Schnittdarstellung entlang der Linie A-A

nach Fig. 10; FIG. 11 shows a sectional illustration along the line AA according to FIG. 10;

Fig. 12 eine Seitenansicht eines Greifwerkzeuges mit zwei

Ansauglippen und einer dazwischenbefindlichen EinÂ­

schnÃ¼rung; Fig. 12 is a side view of a gripping tool with two suction lips and a lacing between them;

Fig. 13 eine Schnittdarstellung der Ansauglippe nach Fig.

12; und

FIG. 13 is a sectional view of Ansauglippe of FIG. 12; and

Fig. 14 eine Schnittdarstellung der Ansauglippe entlang

der Linie A-A nach Fig. 13. Fig. 14 is a sectional view of the Ansauglippe along the line AA of Fig. 13.

Entsprechend Fig. 1 und 2 besteht das mit einer nicht dargeÂ­

stellten Bewegungseinrichtung verbundene Greifwerkzeug 1 aus

einem flexiblen Rohrfortsatz 2, an dessen freien Ende eine

ringfÃ¶rmige Ansauglippe 3 angeordnet ist. Die Ansauglippe 3

ist mit eine AnsaugÃ¶ffnung 4 versehen und besteht aus einem

elastisch weich verformbaren Material. Zur Herstellung eines

ausreichenden Unterdruckes zum Ansaugen von GegenstÃ¤nden ist

die Ansauglippe 3 Ã¼ber den Rohrfortsatz 2 mit einer nicht

dargestellten Pumpvorrichtung verbunden. Der flexible RohrÂ­

fortsatz 2, die Ansauglippe 3 und die AnsaugÃ¶ffnung 4 bilden

zusammen einen SaugrÃ¼ssel, der aus der Bewegungseinrichtung

lose herabhÃ¤ngt. Es ist jedoch auch mÃ¶glich, den RohrfortÂ­

satz 2 verhÃ¤ltnismÃ¤Ãig starr auszubilden und beispielsweise

horizontal aus der Bewegungseinrichtung hervorstehend anÂ­

zuordnen. Damit kÃ¶nnte ein Stapel von GegenstÃ¤nden auch

durch seitliches Entnehmen des jeweils obersten Gegenstandes

vereinzelt werden.According to Fig. 1 and 2, there is connected to a not easily Darge moving means gripping tool 1 consists of a flexible tubular extension 2, an annular Ansauglippe 3 is arranged at the free end. The suction lip 3 is provided with a suction opening 4 and consists of an elastically soft deformable material. In order to produce a sufficient negative pressure for the suction of objects, the suction lip 3 is connected via the pipe extension 2 to a pump device, not shown. The flexible tube extension 2 , the suction lip 3 and the suction opening 4 together form a proboscis that hangs loosely from the movement device. However, it is also possible to form the tubular extension 2 relatively rigid and, for example, project horizontally from the movement device. In this way, a stack of objects could also be separated by removing the uppermost object from the side.

Der Rohrfortsatz 2 besteht zweckmÃ¤Ãigerweise aus einem daueÂ­

relastischen Material, beispielsweise aus einem SchlauchabÂ­

schnitt oder aus einem aus einem Wellschlauch, der gleichÂ­

zeitig eine gewisse LÃ¤ngselastizitÃ¤t aufweist, wobei durch

die Verwendung von Gummi oder Kunststoff fÃ¼r die HerstelÂ­

lung des Rohrfortsatzes 2 eine Ã¼ber dessen Lebensdauer

gleichbleibende ElastizitÃ¤t gewÃ¤hrleistet wird.The tubular extension 2 is expediently made of a resilient material, for example from a hose section or from a corrugated hose, which at the same time has a certain longitudinal elasticity, with the use of rubber or plastic for the manufacture of the tubular extension 2 over its life constant elasticity is guaranteed.

FÃ¼r die Vereinzelung von GegenstÃ¤nden aus einem BehÃ¤lter

wird das Greifwerkzeug 1 mit Hilfe der Bewegungseinrichtung

in den BehÃ¤lter abgesenkt und auf einen zu vereinzelnden

Gegenstand aufgesetzt. AnschlieÃend oder gleichzeitig wird

in der Ansauglippe ein Unterdruck erzeugt, mit dessen Hilfe

der Gegenstand angesaugt und mittels der BewegungseinrichÂ­

tung an einer anderen Stelle abgelegt wird. Soll der BehÃ¤lÂ­

ter vollstÃ¤ndig entleert werden, so ist es zweckmÃ¤Ãig, den

gesamten Ãffnungsquerschnitt rastermÃ¤Ãig abzufahren.For the separation of objects from a container, the gripping tool 1 is lowered into the container with the aid of the movement device and placed on an object to be separated. Subsequently or simultaneously, a negative pressure is generated in the suction lip, with the aid of which the object is sucked in and deposited at another point by means of the movement device. If the container is to be completely emptied, it is advisable to scan the entire opening cross-section.

Zur Vereinzelung auch schwererer GegenstÃ¤nde, ist es zweckÂ­

mÃ¤Ãig, dem Rohrfortsatz 2 Ã¼ber seine gesamte LÃ¤nge mit einer

schraubenlinienfÃ¶rmig umlaufenden Armierung zu versehen.To separate even heavier objects, it is appropriate to provide the tubular extension 2 over its entire length with a helical circumferential reinforcement.

Um ein mÃ¶glichst leichtes Umgreifen der GegenstÃ¤nde, oder

ein gutes Anlegen des Greifwerkzeuges 1 an FlÃ¤chenteile der

GegenstÃ¤nde zu erreichen, besteht die Ansauglippe 3 zweckmÃ¤Â­

Ãig aus einem besonders weichen offen- oder geschlossenzelÂ­

ligen Moosgummi oder auch aus einem Schaumgummi. Durch die

elastische Verformbarkeit der Ansauglippe 3 entsteht beim

Aufsetzen derselben auf einen Gegenstand die notwendige

Querschnittsverengung der AnsaugÃ¶ffnung 4, die das FesthalÂ­

ten der den Querschnitt verengenden GegenstÃ¤nde ermÃ¶glicht.In order to reach around the objects as easily as possible, or to achieve a good application of the gripping tool 1 to surface parts of the objects, the suction lip 3 is expediently made of a particularly soft open or closed cell foam rubber or of a foam rubber. Due to the elastic deformability of the suction lip 3 arises when placing the same on an object, the necessary cross-sectional constriction of the suction opening 4 , which enables the holding of the objects narrowing the cross-section.

Durch das Greifwerkzeug 1 kÃ¶nnen beliebige GegenstÃ¤nde auch

dann problemlos vereinzelt werden, wenn diese vÃ¶llig ungeÂ­

ordnet Ã¼bereinanderliegen. Dazu ist das Greifwerkzeug 1, wie

vorstehend bereits beschrieben, Ã¼ber einer beliebigen Stelle

Ã¼ber einem oder den zu vereinzelnden GegenstÃ¤nden zu posiÂ­

tionieren und anschlieÃend auf diese abzusenken. Dabei kann

die Ansauglippe 3 den zu vereinzelnden Gegenstand zumindest

teilweise umgreifen, indem sie sich an dessen Form anpaÃt

und damit selbst ausrichtet.With the gripping tool 1 , any objects can be separated without problems even if they lie one above the other in a completely unordered manner. For this purpose, the gripping tool 1 , as already described above, must be positioned above any location above one or the objects to be separated and then lowered onto it. The suction lip 3 can at least partially encompass the object to be separated by adapting to its shape and thus aligning itself.

Durch die Erzeugung des Unterdruckes in der Ansauglippe 3

saugt sich das Greifwerkzeug 1 beim Aufsetzen auf einen GeÂ­

genstand selbsttÃ¤tig fest. Die vorstehend beschriebene

Selbstausrichtung des Greifwerkzeuges 1 wird bei diesem VorÂ­

gang noch unterstÃ¼tzt. Dadurch ist es problemlos mÃ¶glich,

auch solche GegenstÃ¤nde zu vereinzeln, bzw. aus einem BehÃ¤lÂ­

ter herauszuheben, die schrÃ¤g liegen oder schrÃ¤ge FlÃ¤chen

aufweisen.

By generating the negative pressure in the suction lip 3 , the gripping tool 1 automatically sucks when placed on a Ge object. The self-alignment of the gripping tool 1 described above is still supported in this process. As a result, it is easily possible to separate such objects or to lift them out of a container which are inclined or have inclined surfaces.

Da der Rohrfortsatz 2 seitlich auslenkbar ist, kann sich das

Greifwerkzeug 1 besonders bei groÃflÃ¤chigen GegenstÃ¤nden

problemlos auch dann an dieselben anlegen, wenn diese unÂ­

geordnet Ã¼bereinanderliegen, oder schrÃ¤g gestapelt sind,

d. h. das Greifwerkzeug 1 bewegt sich selbsttÃ¤tig immer in

die jeweils gÃ¼nstigste Position. Dadurch ist es problemlos

mÃ¶glich, auch solche GegenstÃ¤nde zu vereinzeln, bzw. aus

einem BehÃ¤lter herauszuheben, die in an sich schwer zugÃ¤ngÂ­

lichen Ecken oder unter einem nach innen gezogenen Rand

liegen. AuÃerdem wird durch den flexiblen Rohrfortsatz 2 der

Effekt der Selbstausrichtung noch weiter verbessert, so daÃ

auch ein seitliches Umgreifen von zu vereinzelnden GegenÂ­

stÃ¤nden ermÃ¶glicht wird. Genausogut kÃ¶nnen dadurch vÃ¶llig

unregelmÃ¤Ãige GegenstÃ¤nde, wie ZahnrÃ¤der o. dgl. problemlos

vereinzelt werden.Since the tubular extension 2 can be deflected laterally, the gripping tool 1 can easily fit onto the same, particularly in the case of large-area objects, even if they lie one above the other in an orderly manner or are stacked at an angle, ie the gripping tool 1 always moves automatically into the most favorable position. As a result, it is easily possible to separate such objects, or to lift them out of a container, which are located in corners that are difficult to access or under an inwardly drawn edge. In addition, the effect of self-alignment is further improved by the flexible tubular extension 2 , so that lateral gripping of objects to be separated is made possible. Completely irregular objects, such as gears or the like, can just as easily be separated.

Um auch besonders leichte GegenstÃ¤nde nach dem Vereinzeln

sicher ablegen zu kÃ¶nnen, kann der Luftstrom in der AnsaugÂ­

lippe umgekehrt und Luft herausgeblasen werden. Das kann

auch dazu verwendet werden, GegenstÃ¤nde oder VerunreinigunÂ­

gen, die sich in der Ansauglippe 3 eventuell verklemmt haÂ­

ben, zu entfernen.In order to be able to safely store even particularly light objects after separation, the air flow in the suction lip can be reversed and air can be blown out. This can also be used to remove objects or contaminations that may have jammed in the suction lip 3 .

Zur Anpassung des Greifwerkzeuges 1 an unterschiedliche EinÂ­

satzbedingungen und um verschlissene Ansauglippen 3 leicht

auswechseln zu kÃ¶nnen, ist im unteren Ende des RohrfortÂ­

satzes 2 ein AnschluÃstutzen 5 befestigt, der mit einem

Flansch 6 versehen ist, Ã¼ber den die Ansauglippe 3 formÂ­

schlÃ¼ssig geschoben ist. Zur sicheren Befestigung der AnÂ­

sauglippe 3 ist diese mit einem Bund 7 versehen, der mit dem

Flansch 6 verbindbar ist.To adapt the gripping tool 1 to different conditions and in order to be able to easily replace worn suction lips 3 , a connection piece 5 is fastened in the lower end of the pipe extension 2 , which is provided with a flange 6 , over which the suction lip 3 is positively pushed. For secure attachment of the suction lip 3 , this is provided with a collar 7 which can be connected to the flange 6 .

Beispielsweise kann die Ansauglippe 3 so gestaltet sein, daÃ

sie sich im AnschluÃ an den Bund 7 nach unten erweitert,

wobei die WandstÃ¤rke der Ansauglippe 3 Ã¼ber deren LÃ¤nge konÂ­

stant ist, wobei der untere Rand der Ansauglippe mit einer

auÃen umlaufenden DichtflÃ¤che 8 versehen ist, wodurch ein

schnelleres Ansaugen erreicht wird. (Fig. 1)

Zur Realisierung unterschiedlicher Haft- oder AnsaugkrÃ¤fte

entsprechend der Erfordernisse kann die WandstÃ¤rke der AnÂ­

sauglippe 3 in Richtung zur AnsaugÃ¶ffnung 4 zu- oder abnehÂ­

men, (Fig. 3 bis 6) oder der Querschnitt der Ansauglippe 3

in Richtung zur AnsaugÃ¶ffnung 4 sich konisch erweiternd

ausgefÃ¼hrt werden.For example, the suction lip 3 can be designed such that it widens downward following the collar 7 , the wall thickness of the suction lip 3 being constant over its length, the lower edge of the suction lip being provided with an outer circumferential sealing surface 8 , whereby faster suction is achieved. ( Fig. 1) To realize different adhesive or suction forces according to the requirements, the wall thickness of the suction lip 3 can increase or decrease in the direction of the suction opening 4 (FIGS . 3 to 6) or the cross section of the suction lip 3 in the direction of the suction opening 4 are designed to expand conically.

Zum Vereinzeln von besonders groÃflÃ¤chigen GegenstÃ¤nden, die

gegebenenfalls auch verhÃ¤ltnismÃ¤Ãig schwer sind, sind in der

konischen Erweiterung der Ansauglippe 3, wie in den Fig. 9

bis 14 dargestellt zwei AnsaugÃ¶ffnungen 4, 4â² nebeneinander

angeordnet, wobei die AnsaugÃ¶ffnungen 4, 4â² entweder durch

einen Mittelsteg 9 (Fig. 9 bis 11) oder durch eine EinschnÃ¼Â­

rung 10 (Fig. 12 bis 14) voneinander getrennt sind. Es ist

selbstverstÃ¤ndlich auch mÃ¶glich, drei oder mehr AnsaugÃ¶ffÂ­

nungen 4 in der Ansauglippe 3 anzuordnen.For separating particularly large objects, which may also be relatively heavy, two suction openings 4 , 4 'are arranged side by side in the conical extension of the suction lip 3 , as shown in FIGS . 9 to 14, the suction openings 4 , 4 ' either through a central web 9 ( Fig. 9 to 11) or by a constriction 10 ( Fig. 12 to 14) are separated from each other. It is of course also possible to arrange three or more openings 4 in the intake lip 3 .

BezugszeichenlisteReference list

Â 1Â Greifwerkzeug

Â 2Â Rohrfortsatz

Â 3Â Ansauglippe

Â 4Â AnsaugÃ¶ffnung

Â 4â²Â AnsaugÃ¶ffnung

Â 5Â AnschluÃstutzen

Â 6Â Flansch

Â 7Â Bund

Â 8Â DichtflÃ¤che

Â 9Â Mittelsteg

10Â EinschnÃ¼rung 1 gripping tool

2 pipe extension

3 suction lip

4 suction opening

4 â² suction opening

5 connecting pieces

6 flange

7 fret

8 sealing surface

9 central web

10 constriction

## Classifications

- B65G47/91
- B65G47/91

## Cited patent documents

- [DE-3624017-C2](https://patents.google.com/patent/DE3624017C2/en) — SEA
- [US-4266905-A](https://patents.google.com/patent/US4266905A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
