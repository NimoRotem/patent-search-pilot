# 13. A suction gripping device

- **Archive rank:** 13 of 50
- **Publication:** [WO-2018096423-A1](https://patents.google.com/patent/WO2018096423A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/058266149/publication/WO2018096423A1?q=pn%3DWO2018096423A1)
- **Publication date:** 2018-05-31
- **Filing date:** 2017-11-15
- **Earliest priority:** 2016-11-22
- **Family:** 58266149
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery

## Parties

- **Applicant / assignee:** GIMA SPA
- **Inventors:** FORTINI GIANLUCA; PACIFICI MASSIMO

## Abstract

The suction gripping device (D) comprises: a support arm (B); a head (T) with at least a suction gripping element (P) which is mounted translatably along the support arm (B). The head (T) comprises an inlet (I) and a channelling system (S) in order to place the inlet (I) and the gripping element (P) in communication. The device (D) further comprises: at least a manifold element (1) maintained in depression; seal means (2), along the side (11) so as to maintain the inside of the manifold element (1) in depression; a fluid distributor group (3), interposed between the inlet (I) present in the head (T) and the side (11) and borne by the head (T) so as to be able to slide along the side (11) and comprising, spacer means (30) for distancing and keeping a portion (20) of the seal means (2) distanced from the side (11) in such a way as to maintain the channelling system (S) in depression for activation in suction of the gripping element (P).

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf000.png)

![Sketch 1 for WO-2018096423-A1](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf001.png)

![Sketch 2 for WO-2018096423-A1](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf002.png)

![Sketch 3 for WO-2018096423-A1](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf003.png)

![Sketch 4 for WO-2018096423-A1](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf004.png)

![Sketch 5 for WO-2018096423-A1](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf005.png)

![Sketch 6 for WO-2018096423-A1](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf006.png)

![Sketch 7 for WO-2018096423-A1](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf007.png)

![Sketch 8 for WO-2018096423-A1](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf008.png)

![Sketch 9 for WO-2018096423-A1](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf009.png)

![Sketch 10 for WO-2018096423-A1](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf009.png)

[Sketch 11](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf010.png)

![Sketch 11 for WO-2018096423-A1](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf010.png)

[Sketch 12](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf011.png)

![Sketch 12 for WO-2018096423-A1](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf011.png)

[Sketch 13](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf012.png)

![Sketch 13 for WO-2018096423-A1](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf012.png)

[Sketch 14](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf013.png)

![Sketch 14 for WO-2018096423-A1](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf013.png)

[Sketch 15](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf014.png)

![Sketch 15 for WO-2018096423-A1](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf014.png)

[Sketch 16](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf015.png)

![Sketch 16 for WO-2018096423-A1](https://nimo.iptorch.com/refdrawing/WO-2018096423-A1/pdf015.png)

## Claims

### Claim 1

CLAIMS 1 ) A suction gripping device (D) comprising: - a support arm (B); - a head (T) comprising at least a suction gripping element (P), an inlet (I) for fluid passage and a channelling system (S) for passage of fluid predisposed internally of the head (T) so as to place the inlet (I) and the at least a suction gripping element (P) in mutual communication; the head (T) being mounted on the support arm (B) in such a way as to be translatable alternatively along the support arm (B) in order to displace the suction gripping element (P) at least between a picking-up position of an object and a release position of the object; at least a manifold element (1 ), having a substantially longitudinal extension and being predisposed so as to be arranged parallel to the support arm (B) superiorly or inferiorly thereto, along the extension thereof and so as to be connected to a suction source in order to be maintained in depression, the manifold element (1 ) having a side (1 1 ) thereof facing towards the head (T) and comprising, along a portion of length at least equal to the entity of the translation of the head (T) between the picking-up position and the release position, a single opening (12) or a series of openings (12) for passage of fluid arranged consecutively to one another; seal means (2) which are predisposed along the side (1 1 ) of the manifold element (1 ) at the opening (12) or the series of openings (12) so as to prevent the passage of fluid between the outside and the inside of the manifold element (1 ) and enable maintaining the inside of the manifold element (1 ) in depression; characterised in that it comprises: a fluid distributor group (3), comprising a chamber (14), a front wall (140), a rear wall (141 ), a first window (31 ) for passage of fluid in the rear wall (141 ) communicating with the chamber (14) and a second window (32) for passage of fluid in the front wall (140) communicating with the chamber (14), the fluid distributor group (3), being mounted on the head (T) so as to be interposed between the inlet (I) present in the head (T) and the side (1 1 ) of the manifold element (1 ), the front wall (140) being opposite and in proximity of the side (1 1 ) of the manifold element (1 ), so that the distributor group (3) translates along the side (1 1 ) without there being any contact between the front wall (140) and the side (1 1 ) during the translation of the head (T) along the support arm (B), the first window (31 ) for passage of fluid being in communication with the inlet (I) and the second window (32) for passage of fluid being located at the seal means (20), the fluid distributor group (3) further comprising, internally of the chamber (14), spacer means (30) which are predisposed and configured so as to maintain a portion (20) of the seal means (2) distanced from the side (1 1 ) of the manifold element (1 ) in such a way as to place the inside of the manifold element (1 ) in fluid-dynamic communication with the chamber (14) via the second window (32) for passage of fluid and therefore with the inlet (I), via the first window (31 ) for passage of fluid, and thus maintain the channelling system (S) in depression for activation in suction of the gripping element (P), the spacer means (30) being further predisposed in such a way, during the translation of the head (T) along the support arm (B) and the sliding of the distributor group (3) along the side (1 1 ) of the manifold element (1 ), as to distance, and maintain distanced, the portion (20) of the seal means (2), which time by time is at the second window (32) for passage of fluid of the distributor group (3), from the side (1 1 ) so as to constantly maintain the inside of the manifold element (1 ) in fluid communication with the chamber (14) and therefore, via the first window (31 ) for passage of fluid, with the inlet (I) and thus maintain the channelling system (S) in depression for enabling the gripping element (P) to suction-grip an object and to maintain the suction grip of the object during the translation of the head (T) along the support arm (B), at least between the picking-up position and the release position. 2) The gripping device of claim 1 , characterised in that the seal means (2) comprise a belt element (21 ) predisposed adheringly along the side (1 1 ) of the manifold element (1 ) so as to prevent the passage of fluid between the outside and the inside of the manifold element (1 ). 3) The gripping device of claim 2, characterised in that the spacer means (30) are predisposed internally of the chamber (14) of the fluid distributor group (3) between the first window (31 ) for passage of fluid and the second window (32) for passage of fluid, and are configured so as to distance, from the side (1 1 ) of the manifold element (1 ), the portion (210) of the belt element (21 ) which, time-by-time during the translation of the head (T) along the support arm (B), is at the second window (32) for passage of fluid, so as to place the inside of the manifold element (1 ) in communication, via the second window (32), with the chamber (14) of the fluid distributor group (3) and therefore also in communication with the channelling system (S) present in the head (T), via the first window (31 ) for passage of fluid of the fluid distributor group (3) and the inlet (I) of the head (T), so that the channelling system (S) can be constantly maintained in depression for enabling the gripping element (P) to be constantly active in suction. 4) The gripping device of claim of the preceding claim, characterised in that the spacer means (30) comprise idle return rollers (300) of the belt element (21 ), the idle return rollers (300) being reciprocally arranged with respect to one another internally of the chamber (14) and with respect to the second window (32) for passage of fluid and to the side (1 1 ) of the manifold element (1 ) in such a way that the portion (210) of the belt element (21 ), during the translation of the head (T) along the support arm (B) and the translation of the distributor group (3) along the side (1 1 ) of the manifold element (1 ), is first detached from the side (1 1 ) of the manifold element (1 ), brought internally of the chamber (14) via the second window (32) for passage of fluid, maintained internally of the chamber (14) and then returned to contact with the side (1 1 ) of the manifold element (1 ). 5) The gripping device of any one of claims from 2 to 4, characterised in that it comprises anti-deformation elements (6) of the belt element (21 ) which are predisposed so as to prevent the portions of the belt element (21 ) not involved in the passage of the fluid distributor group (3) from being partially sucked internally of the manifold element (1 ). 6) The gripping device of claim 5, characterised in that the anti-deformation elements (6) comprise grid or mesh elements predisposed so as to be positioned at the opening (12) or at the series of openings (12) present in the side (1 1 ) of the manifold element (1 ). 7) The gripping device of any one of the preceding claims, characterised in that the front wall (140) of the distributor group (3) comprises, in a part thereof opposite the side (1 1 ) of the manifold element (1 ), at least a groove (15) and in that the side (1 1 ) comprises, in a relative portion facing the groove (15), a rib (16) dimensioned so as to insert in the groove (15) without any reciprocal contact. 8) The gripping device of any one of the preceding claims, characterised in that the head (T) comprises a plate-shaped support member (18) conformed so as to have a first face (180) and a second face (181 ) parallel to one another and comprising internally thereof the channelling system (S) for the passage of fluid, the inlet (I) being realised on the first face (180) so as to be in communication with the channelling system (S) and with the fluid distributor group (3) being mounted on the first face (180) at the inlet (I), and the at least a gripping element (P) being mounted on the second face (181 ) and communicating via the at least a relative hole (F) realised in the second face (181 ) with the channelling system (S), the plate-shaped support member (18) being translatably mounted on the support arm (B) so that the first face (180) is facing towards the side (1 1 ) of the manifold element (1 ) with the front wall (140) of the fluid distributor member (3) opposite and in proximity of the side (1 1 ).

## Full description

**[0001]**

A SUCTION GRIPPING DEVICE

**[0002]**

DESCRIPTION OF THE INVENTION

**[0003]**

The present invention relates to the particular technical sector concerning apparatus and devices for carrying out an automatic gripping action by suction of an object from a picking-up position and for transfer thereof to a release position.

**[0004]**

Suction gripping devices are commonly used for picking up objects which are to be handled with great care, or when a high sanitary level is required.

**[0005]**

For example, suction gripping devices are usually employed in injection moulding plants of components made of a plastic material for picking up components from an injection moulding press and transferring them to other work and/or packing stations.

**[0006]**

A suction gripping device of known type for carrying out a picking-up by suction of an object from a picking-up position, and for transferring the object to a release position comprises: a support arm, a head provided with at least a suction gripping element which is mounted on the support arm in such a way as to be translated by guides along the arm.

**[0007]**

The head also comprises an inlet for passage of fluid, communicating with the outside, and, internally thereof, a channelling system for passage of fluid which is predisposed and configured so as to be in communication with both the inlet and the at least a suction gripping element.

**[0008]**

The known gripping device has an aspirating system which comprises a suction source and flexible tubes or cables for connecting the suction source at the inlet present in the head, so that when the suction source is activated a depression can be created, i.e. a suction effect (vacuum) in the channelling system, and therefore a depression in the gripping element so as to enable gripping of an object by suction.

**[0009]**

The operation of the gripping device is as follows. When the gripping device is to pick up an object, the head is translated on the guides along the support arm up to positioning the gripping element in the position in which the object is located, then the suction source is activated so as to create a depression in the channelling system present between the heads, and therefore create a suction effect in the gripping element, which thus picks up the object by suction.

**[0010]**

Once the object has been picked up, the head is newly translated on the guides, in an opposite direction to the previous direction, so as to bring the gripping element with the object into the correct position for release thereof or gripping thereof by special handling organs.

**[0011]**

The use of the gripping device has various drawbacks.

**[0012]**

The presence of the tubes and cables that connect the suction source to the inlet present in the head leads to a series of drawbacks, in terms of both volumes and efficiency. In fact, the tubes and cables must have a length that is such as to enable them to follow the translation of the head along the support arm, which can require displacements even by a few metres, and therefore they extend or fold on themselves according to the position of the head on the support arm.

**[0013]**

This leads to various issues, in terms of both inertia, in consideration of the weight of the tubes or cables, and volume, as there must be an appropriate manoeuvring space for displacement thereof.

**[0014]**

The presence of the tubes or cables further limits the velocity with which the head can be made to translate along the support arm.

**[0015]**

Lastly, the gripping by suction of the object by the gripping element is actually not so instantaneous and immediate from the moment at which the suction source is activated.

**[0016]**

The aim of the present invention is therefore to provide a suction gripping device that is able to obviate the above-mentioned drawbacks present in the gripping devices of known type. In particular, an aim of the invention is to provide a suction gripping device having a modest volume, able to allow rapid displacements of the head along the support arm and an instantaneous grip by suction of the object, that is independent of the position of the head with respect to the arm. The above-cited aims are obtained by a suction gripping device according to claim 1 .

**[0017]**

Further characteristics and advantageous aspects of the gripping device of the present invention are set down in the various claims dependent on claim 1 .

**[0018]**

The characteristics of a preferred, but not exclusive, embodiment of the suction gripping device of the present invention will be described in the following with reference to the appended tables of drawings, in which:

**[0019]**

- figure 1 schematically illustrates a perspective view of the suction gripping device that is the object of the present invention;

**[0020]**

- figure 2 further schematically illustrates a schematic and perspective view, partly-sectioned, of the gripping device of figure 1 ;

**[0021]**

- figure 2A schematically illustrates, in a partly-sectioned perspective view, the part of the gripping device predisposed for suction gripping of objects;

**[0022]**

- figure 3 is a larger-scale illustration of the detail denoted by letter K of figure

**[0023]**

2; - figure 4 is a larger-scale illustration of the detail denoted by letter K of figure 2 from a different angle;

**[0024]**

- figure 5 is a partial view, sectioned according to a transversal section plane, of a significant part of the gripping device according to the present invention;

**[0025]**

- figure 6 is a partial view, sectioned according to a transversal section plane, of other significant parts of the gripping device according to the present invention;

**[0026]**

- figure 7 schematically illustrates a partial perspective view, partly-sectioned, of a possible variant of the gripping device of the invention;

**[0027]**

- figure 8A illustrates detail Z of figure 6 in larger scale;

**[0028]**

- figure 8B illustrates detail V of figure 8A in larger scale;

**[0029]**

- figure 8C illustrates detail V of figure 8A in larger scale according to a possible variant embodiment.

**[0030]**

With reference to the drawings, reference (D) denotes the suction gripping device that is the object of the present invention in its entirety.

**[0031]**

The gripping device (D) of the invention can advantageously be used in all those cases in which it is necessary to carry out the picking-up of an object from a picking-up position and to transfer it to a release position, where the object can be released or be picked up by special handling organs.

**[0032]**

For example, the gripping device (D) of the invention is advantageously applied in moulding plants of components made of a plastic material and in particular for picking up a component from an injection moulding press and transferring it to a station predisposed for carrying out further work steps or packing steps of the work cycle of the plant.

**[0033]**

The suction gripping device (D) comprises a support arm (B) and a head (T) comprising at least a suction gripping element (P) and which is mounted on the support arm (B) in such a way as to be translatable alternatively along the support arm (B) in order to displace the suction gripping element (P) at least between a picking-up position of an object and a release position of the object (not illustrated).

**[0034]**

The head (T) also comprises at least an inlet (I) for passage of fluid and, internally thereof, a channelling system (S) for passage of fluid which is predisposed in order to place the inlet (I) and the gripping element (P) in reciprocal communication (see for example figures 1 and 2).

**[0035]**

In the preferred but not exclusive embodiment illustrated in the figures, the head (T) comprises a series of gripping elements (P), for example constituted by beakers, each of which is in communication via a hole (F) with the channelling system (S) (see in particular figure 2A in which the beaker gripping elements (P) are illustrated, having at the base thereof a hole (F) for communication with the channelling system; in this figure a series of relative objects (C), for example components made of a plastic material, are shown by way of example, and are retained by suction internally of the beakers/gripping elements (P)).

**[0036]**

A first special characteristic of the suction gripping device (D) of the present invention consists in the fact that it comprises: at least a manifold element (1 ), for example having a substantially longitudinal extension, which is predisposed so as to be arranged parallel to the support arm (B), for example superiorly or inferiorly of the support arm (B), along the extension thereof and to be connected to a suction source (not illustrated) so as to be maintained in depression, the manifold element (1 ) having a side (1 1 ) thereof facing towards the head (R) and structured and configured so as to enable a passage of fluid between the outside and inside of the manifold element (1 ).

**[0037]**

In this regard, the side (1 1 ) can comprise, along a portion of length at least equal to the entity of the translation of the head (T) between the picking-up position and the release position, a single passage opening (12) or a series of openings (12) for passage of fluid arranged consecutively to one another.

**[0038]**

The gripping device (D) further comprises seal means (2) which are predisposed along the side (1 1 ) of the manifold element (1 ) at the opening (12) or the series of openings (12) so as to prevent the passage of fluid between the outside and the inside of the manifold element (1 ) and enable maintaining the inside of the manifold element (1 ) in depression, and therefor in a vacuum.

**[0039]**

A first special characteristic of the gripping device (D) of the present invention consists in the fact that it comprises a fluid distributor group (3) comprising a chamber (14), a front wall (140), a rear wall (141 ), a first window (31 ) for passage of fluid in the rear wall (141 ) communicating with the chamber (14) and a second window (32) for passage of fluid in the front wall (140) communicating with the chamber (14), and which is mounted on the head (T) so as to be interposed between the inlet (I) present in the head (T) and the side (1 1 ) of the manifold element (1 ), the first window (31 ) for passage of fluid being in communication with the inlet (I) and the second window (32) for passage of fluid being at the seal means (20) (see figures 4 and 5).

**[0040]**

In particular, in an advantageous aspect of the invention, the distributor group (3) is configured and conformed so that, when it is mounted on the head (T), the front wall (140) is opposite and positioned in proximity of the side (1 1 ) of the manifold element (1 ) so that the distributor group (3) translates along the side (1 1 ) without there being contact between the front wall (140) and the side (1 1 ) when the head (T) is translated along the support arm (B) (see in detail figures 8A, 8B and 8C).The fluid distributor group (3) (see for example figures 2 and 3), further comprises, internally of the chamber (14), spacer means (30) which are predisposed and configured so as to maintain a portion (20) of the seal means (2) distanced from the side (1 ) of the manifold element (1 ) in such a way as to place the inside of the manifold element (1 ) in fluid communication with the chamber (14), via the second window (32) for passage of fluid, and with the inlet (I), via the first window (31 ) for passage of fluid, and thus maintain the channelling system (S) in depression (i.e. in a vacuum) for activation in suction of the gripping element (P).

**[0041]**

The spacer means (30) being further predisposed in such a way, during the translation of the head (T) along the support arm (B) and the sliding of the distributor group (3) along the side (1 1 ) of the manifold element (1 ), as to distance, and maintain distanced, the portion (20) of the seal means (2), which time by time is at the second window (32) for passage of fluid of the distributor group (3), from the side (1 1 ) so as to constantly maintain the inside of the manifold element (1 ) in fluid-dynamic communication with the chamber (14) and therefore, via the first window (31 ) for passage of fluid, with the inlet (I), and thus maintain the channelling system (S) in depression (vacuum) for enabling the gripping element (P) to suction-grip an object, and to maintain the suction grip of the object during the translation of the head (T) along the support arm (B), at least between the picking-up position and the release position.

**[0042]**

In the gripping device (D) of the invention, the fact of including a manifold element (1 ) arranged parallel to and along the extension of the support arm (B), which is constantly maintained in depression, i.e. in a vacuum, enables directly and constantly to make available to the head (T) a suction force independently of the position thereof along the support arm (B), without any need to have to move and displace cables or transmission tubes of the suction (the vacuum).

**[0043]**

This enables the gripping device (D) to have a modest volume, and less inertia resistance for displacing the head (T), as no other components are present (cables/tubes for transmission of the suction (vacuum) force) which have to be displaced during the translation of the head (T). Further, thanks to the particular arrangement of the distributor group (3) with respect to the head (T) and the side (1 1 ) of the manifold element (1 ), in particular thanks to the fact that the front wall (140) of the distributor group (3) is arranged opposite and in proximity of the side (1 1 ), at a minimum distance (d) therefrom with no reciprocal contact, the head (T) can easily translated, and at very high velocities (beyond 10 m/s) with significant accelerations (100 m/ s<2>), with no dragging along the support arm (B), so as to bring into and position the gripping element (P) in the picking-up position of the object and thus subsequently translate it into the release position, obtaining a significant reduction in the time required for each work cycle of picking up and releasing the object, and therefore an increase in productivity.

**[0044]**

For example, the distributor group (3) can be mounted on the head (T) and be dimensioned so that the front wall (140) is arranged at a distance (d) from the side (1 1 ) of the manifold element (1 ) of about 0.3-0.5 mm.

**[0045]**

Further, the presence of the distributor group with the spacer means predisposed internally thereof for distancing from the side of the manifold element the portion of the seal means which, time by time, is located at the position of the second window of the distributor group, and therefore of the head, enables constantly maintaining the channelling system present in the head in communication with the inside of the manifold element, and therefore in depression (vacuum), so that the gripping element (P) is constantly active in suction, independently of the position of the head (T) along the support arm (B).

**[0046]**

This enables having a substantially instantaneous grip, i.e. with no delay, of the object as soon as the gripping element (P) is brought, by the translation of the head (T) along the support arm, into the picking-up position.

**[0047]**

The fact of having two facing surfaces for a significant surface area, at a minimum distance (d) and without mutual contact, for example at a distance (d) of about 0.3-0.5 mm as mentioned in the foregoing, like the side (1 1 ) of the manifold element (1 ) and the front wall (140) of the distributor group (3) (as illustrated in detail and evidenced in figures 8A, 8B and 8C), enables in any case creating a more than effective resistance to the passage of air, and therefore an excellent seal effect, in relation to the velocities and accelerations with which the head is translated along the support arm.

**[0048]**

For example, and advantageously, the extension in height (h) of the surfaces of the side (1 1 ) and of the front wall (140) opposite one another, can be comprised between 20 and 30 mm.

**[0049]**

In fact, for a distance (d) as indicated in the foregoing and for a height value (h) of the surfaces facing one another of the side (1 1 ) and the front wall (140), as indicated herein above, it has been observed that any loss of air by leakage through the slim passage existing between the side (1 1 ) of the manifold element (1 ) and the front wall (140) of the distributor group (3) is irrelevant and has no influence on the efficiency of the suction.

**[0050]**

Therefore, definitively, the gripping device of the present invention enables, with respect to the known-type devices, obtaining a reduction of volumes, a reduction in inertia for displacements of the head along the support arm, a reduction in the time required for each work cycle of picking-up and releasing the object, and therefore an increase in productivity, and a substantially instantaneous grip on the object as soon as the gripping element reaches the picking-up position. In a possible variant embodiment illustrated in figure 8C, directed at increasing the seal efficiency but in any case with no reciprocal dragging contact between the front wall (140) of the distributor group (3) and the side (1 1 ) of the manifold element (1 ), the front wall (140) can comprise, in a part thereof opposite the side (1 1 ), at least a groove (15) while the side (1 1 ) in turn comprises, in a relative portion facing the groove (15), a rib (16) which is dimensioned so as to insert in the groove (15) without reciprocal contact.

**[0051]**

The number of pairs of grooves/ribs can also be greater than what is illustrated in figure 8C.

**[0052]**

With this configuration a slim passage for air is created, having a sort of labyrinth shape which enables further reducing air loss by leakage and therefore increases the seal.

**[0053]**

The head (T) is mounted on the support arm (B) by sliding guides (8), predisposed on a side of the support arm (B), and is translatable along the sliding guides (8) by means of a belt element or belt (9) loop-wound and activatable by means of an actuator organ (90), for example a brushless motor (see for example figure 1 ).

**[0054]**

The manifold element (1 ) can be predisposed on an appropriate support (not illustrated) or mounted directly on the support arm (B).

**[0055]**

In the illustrated embodiment of the figures, the head (T) comprises a plate- shaped support member (18) conformed so as to have a first face (180) and a second face (181 ) parallel to one another and comprising internally thereof the channelling system (S) for the passage of fluid.

**[0056]**

In this case, the inlet (I) is realised on the first face (180) so as to be in communication with the channelling system (S), the fluid distributor group (3) being mounted on the first face (180) at the inlet (I), the beaker-shaped gripping elements (P) being predisposed and mounted on the second face (181 ) and communicating via relative holes (F) realised in the second face (181 ) with the channelling system (S). The plate-shaped support member (18) being translatably mounted on the support arm (B) so that the first face (180) is facing towards the side (1 1 ) of the manifold element (1 ) with the front wall (140) of the fluid distributor member (3) opposite and in proximity of the side (1 1 ).

**[0057]**

In a further preferred aspect of the gripping device (D) of the invention, the seal means (2) comprise a belt element (21 ) predisposed adheringly along the side (1 1 ) of the manifold element (1 ) so as to prevent passage of fluid between the outside and the inside of the manifold element (1 ), in particular the belt element (21 ) is arranged so as occlude the opening (12) or the series of openings (12) for passage of fluid present on the side (1 1 ). In this case, the spacer means (30) are predisposed internally of the chamber (14) of the fluid distributor group (3) between the first window (31 ) for passage of fluid and the second window (32) for passage of fluid, and are configured so as to distance, from the side (1 1 ) of the manifold element (1 ), the portion (210) of the belt element (21 ) which, time-by-time during the translation of the head (T) along the support arm (B), is positioned at the second window (32) of passage of fluid.

**[0058]**

In this way the inside of the manifold element (1 ) is constantly in communication, via the second window (32), with the chamber (14) of the fluid distributor group (3) and therefore also in communication with the channelling system (S) present in the head (T), via the first window (31 ) for passage of fluid of the fluid distributor group (3) and the inlet (I) of the head (T), so that the channelling system (S) can be constantly maintained in depression (vacuum) for enabling the gripping element (P) to be constantly active in suction (see figure 4, for example). According to the preferred, but not exclusive, embodiment illustrated in the accompanying the figures, the spacer means (30) comprise idle return rollers (300) of the belt element (21 ).

**[0059]**

The idle return rollers (300) are reciprocally arranged with respect to one another internally of the chamber (14) and with respect to the second window (32) for fluid passage and to side (1 1 ) of the manifold element (1 ) in such a way that the portion (210) of the belt element (21 ), during the translation of the head (T) along the support arm (B) and the sliding of the distributor group (3) along the side (1 1 ) of the manifold element (1 ), is first detached from the side (1 1 ) of the manifold element (1 ), brought internally of the chamber (14) via the second window (32), maintained internally of the chamber (14) and distant from the side (1 1 ) and then returned to contact with the side (1 1 ) of the manifold element (1 ) (figure 4).

**[0060]**

In this regard, the second window (32) for passage of fluid has dimensions that are such (for example a greater height than the width of the belt) as to enable passage of the portion of belt through it.

**[0061]**

For example, the idle return rollers (300) can comprise a first pair of rollers, included for deviating and distancing the belt element from the side of the manifold element, and a second pair of rollers included for returning the belt element into contact with the side of the manifold element. The spacer means (30) can also comprise a different number of rollers arranged differently, or can be constituted by any other equivalent means suitable for distancing the portion (210) of the belt element (21 ) which time by time is at the position of the second window (32) of the distributor group (3) during the displacement thereof with respect to the side (1 1 ) of the manifold element (1 ) as a consequence of the translation of the head (T) along the support arm (B).

**[0062]**

A further advantageous aspect of the gripping device (D) of the invention relates to the fact that it comprises (see for example figures 5) anti- deformation elements (6) of the belt element (21 ) which are predisposed so as to prevent the portions of the belt element (21 ) not involved in the passage of the fluid distributor group (3) from being partially sucked internally of the manifold element (1 ).

**[0063]**

For example, the anti-deformation elements (6) comprise grid or mesh elements predisposed so as to be positioned at the opening (12) or at the series of openings (12) present in the side (1 1 ) of the manifold element (1 ).

**[0064]**

The gripping device (D) can further be provided with sensors (not illustrated in the figures) which are predisposed so as to detect both the position of the head (T) with respect to the support arm (B) and the position of the portion (20) of the seal means (2) which is distanced from the side (1 1 ) of the manifold element (1 ).

**[0065]**

This enables real-time and precise data to be collated on the positioning both of the head (T), therefore of the suction gripping element (P), and at which position along the side of the manifold element (1 ) the communication between the inside of the manifold element (1 ) and the channelling system (S) internal of the head (T) takes place, so as to be able to intervene by deactivating the suction source and stopping the head should the need arise to interrupt the functioning of the device for safety reasons.

**[0066]**

Figure 7 illustrates a possible advantageous variant of the gripping device of the invention, according to which the manifold element (1 ) is structured so as to comprise internally thereof a series of sectors (1 a, 1 b, 1 c, 1 d) reciprocally separate and predisposed in such a way as to be independently in communication with a suction source, so that it is possible to activate or deactivate the creation of a depression (vacuum) internally thereof independently of one another. This configuration of the manifold element enables, advantageously, making the gripping and/or release operations of the objects by the gripping elements more rapid.

**[0067]**

In fact, it will be sufficient to activate or interrupt the aspirating action (creation/deactivation of the depression or vacuum) only for the single sector which the distributor group (3) has reached during the translation of the head (T) along the support arm (B).

**[0068]**

For example, in figure 7 the head (T) has been translated along the support arm (B) (towards the right when looking at figure 7) up to a gripping position in which the gripping elements (P) must grip relative objects (C) by suction and such that the distributor group (3) is at the sector (1 a) of the manifold element (1 ).

**[0069]**

In this situation all the sectors (1 a, 1 b, 1 c, 1 d) internally of the manifold element (1 ) are in communication with the suction source and thus maintained in depression so that the suction grip can take place instantaneously as soon as the gripping elements (P) reach the gripping position for the picking up of the objects.

**[0070]**

The head (T) will then be translated along the support arm (B), in the opposite direction with respect to the previous translation (towards the left looking at figure 7), so as to bring the objects (C) retained by the gripping elements (P) to the release position.

**[0071]**

If, for example, the release position of the objects is in a position corresponding to the position of the sector of the manifold element (1 ) denoted by reference numeral (1c), it will be sufficient to disable the suction source which is in communication with this sole sector, without intervening on the other sectors, so that there will no longer be a depression (vacuum) in the sector (1 c).

**[0072]**

In this way, as soon as the translation of the head (T) along the support arm (B) brings the distributor group (3) to this sector (1 c), the release of the objects by the gripping elements (P) can take place in an extremely rapid way. The small dimensions of the volumes of the various sectors, with respect to the case in which the manifold element has a single sector along the extension thereof, in fact, require a very short time both for the creation of a depression and for the resetting of the normal pressure internally of each of them. In a further preferred embodiment thereof, the gripping device (D) can also comprise a second manifold element arranged specularly to the first manifold element with respect to the support arm, provided with a relative side configured so as allow passage of fluid between the outside and the inside, and second seal means predisposed on the side of the second manifold element for preventing the passage of fluid between the outside and inside and maintain the inside of the second manifold element in depression.

**[0073]**

In this case the head will be provided with at least a second gripping element or a second series of gripping elements, of a second inlet and a second channelling system for passage of fluid in order to place the second gripping element (or second series of gripping elements) in communication with the second inlet.

**[0074]**

The device will also comprise a second distributor group, borne by the head between the second inlet and the side of the second manifold element, provided with second spacer means for distancing, and maintaining distant, a portion of the second seal means from the side of the second manifold element that, time by time, is at the position of the second distributor group, so as to place the inside of the second manifold element in communication with the second inlet and with the second channelling system, in order to maintain the second channelling system in depression and therefore the second gripping element (second series of gripping elements) active in suction.

## Classifications

- B65G47/912
- B65G47/912
- B25B11/005
- B25J15/0616
- B25J19/00
- B25J5/02
- B65G47/91
- F16L41/18

## Cited patent documents

- [EP-0169652-A1](https://patents.google.com/patent/EP0169652A1/en) — ISR
- [FR-2194810-A1](https://patents.google.com/patent/FR2194810A1/en) — ISR
- [JP-2009090410-A](https://patents.google.com/patent/JP2009090410A/en) — ISR
- [JP-S5472809-A](https://patents.google.com/patent/JPS5472809A/en) — ISR
- [US-2004041321-A1](https://patents.google.com/patent/US20040041321A1/en) — ISR
- [US-4173176-A](https://patents.google.com/patent/US4173176A/en) — ISR

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
