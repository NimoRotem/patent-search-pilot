# 21. Vacuum pad device

- **Archive rank:** 21 of 50
- **Publication:** [US-2011001024-A1](https://patents.google.com/patent/US20110001024A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/040698496/publication/US20110001024A1?q=pn%3DUS20110001024A1)
- **Publication date:** 2011-01-06
- **Filing date:** 2009-03-16
- **Earliest priority:** 2008-03-17
- **Family:** 40698496
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery

## Parties

- **Applicant / assignee:** CHO HO-YOUNG
- **Inventors:** CHO HO-YOUNG

## Abstract

The present invention relates to a vacuum pad device used in a vacuum transport system. The pad device includes a housing, a pad unit connected to the housing through a ball joint such that the pad unit is rotatable, and a piston arranged in the housing and controlling the rotation of the pad unit. The pad unit is bonded to an object at a desirable rotation angle, and controlled such that the rotation angle is fixed by the movement of a piston operating via compressed air. Consequently, the object can be transported in an accurate and safe manner. Preferably, the vacuum pad device of the present invention further includes a vacuum pump arranged in the housing unit the piston.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/4e/7f/9f/88026b2999314b/US20110001024A1-20110106-D00000.png)

![Sketch 1 for US-2011001024-A1](https://patentimages.storage.googleapis.com/4e/7f/9f/88026b2999314b/US20110001024A1-20110106-D00000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/2a/4f/30/b5054463544277/US20110001024A1-20110106-D00001.png)

![Sketch 2 for US-2011001024-A1](https://patentimages.storage.googleapis.com/2a/4f/30/b5054463544277/US20110001024A1-20110106-D00001.png)

[Sketch 3](https://patentimages.storage.googleapis.com/10/90/05/709810ae9a5d36/US20110001024A1-20110106-D00002.png)

![Sketch 3 for US-2011001024-A1](https://patentimages.storage.googleapis.com/10/90/05/709810ae9a5d36/US20110001024A1-20110106-D00002.png)

[Sketch 4](https://patentimages.storage.googleapis.com/f0/dd/5d/0053b92a9bc01a/US20110001024A1-20110106-D00003.png)

![Sketch 4 for US-2011001024-A1](https://patentimages.storage.googleapis.com/f0/dd/5d/0053b92a9bc01a/US20110001024A1-20110106-D00003.png)

[Sketch 5](https://patentimages.storage.googleapis.com/49/30/ec/0d98109726510a/US20110001024A1-20110106-D00004.png)

![Sketch 5 for US-2011001024-A1](https://patentimages.storage.googleapis.com/49/30/ec/0d98109726510a/US20110001024A1-20110106-D00004.png)

## Claims

### Claim 1 (independent)

A vacuum pad device, comprising: a housing having: an inlet port and an outlet port formed through a sidewall of the housing at respectively an upper position and a lower position; a mounting seat formed through a lower end of the housing; and a sealing cover provided on an upper end of the housing; a pad unit comprising: a ball joint having a through hole formed in a longitudinal direction thereof; and a suction pad coupled to an end of the ball joint, wherein a ball of the ball joint is seated into the mounting seat of the housing so that the pad unit is rotatably coupled to the housing; and a piston provided in the housing such that an outer surface of the piston is in close contact with an inner surface the sidewall of the housing, the piston having a connection hole communicating the outlet port with the through hole, wherein the piston is moved in a longitudinal direction of the housing by pressure of compressed air supplied from the inlet port, thus controlling rotation of the ball joint. 2 . The vacuum pad device as set forth in claim 1 , further comprising: a vacuum pump comprising an axis-symmetric air pump structure and having an air intake hole formed in a first end thereof, an air discharge hole formed in a second end thereof, and an opening formed through a sidewall of the vacuum pump to communicate with an outside air, wherein the vacuum pump is mounted to the housing in such a way that a mounting hole is formed in the housing at a position opposite to the outlet port and the first end and the second end of the vacuum pump are respectively inserted into the mounting hole and the outlet port, and the opening of the vacuum pump communicates with the connection hole of the piston. 3 . The vacuum pad device as set forth in claim 1 or 2 , wherein the mounting seat has a round surface which is in surface contact with the ball of the ball joint. 4 . The vacuum pad device as set forth in claim 1 or 2 , wherein the piston controls the rotation of the ball joint in such a way that the piston is moved by the pressure of the compressed air supplied from the inlet port and thus presses the ball of the ball joint. 5 . The vacuum pad device as set forth in claim 4 , wherein the piston has a round recess such that the piston comes into surface contact with the ball of the ball joint. 6 . The vacuum pad device as set forth in claim 1 or 2 , wherein a pin is installed between the piston and the sealing cover to prevent the piston from rotating, and a gap is formed between the pin and the piston to allow the longitudinal movement of the piston.

## Full description

### Background Of The Invention

**[p0001]**

1. Field of the Invention The present invention relates generally to vacuum pad devices used in vacuum transport systems and, more particularly, to a vacuum pad device which is configured such that a suction pad is rotated using a ball joint to easily cope with different surface angles of an object. 2. Description of the Related Art Generally, vacuum transport systems form negative pressure in a pad device using a vacuum pump which uses compressed air, and holds an object using the pad device to which the negative pressure is applied, and then transports the object to a desired place. The pad device used in these vacuum transport systems typically includes a rigid body and a flexible suction pad. The rigid body is generally connected to a suction port of a vacuum pump, and the suction pad is fixed to the end of the rigid body. When compressed air passes through the vacuum pump, air which has been in the suction pad is drawn into the vacuum pump and then the air, along with the compressed air, is discharged out of the vacuum pump. Thereby, negative pressure is formed in the suction pad.

**[p0002]**

However, in this conventional structure, because the suction pad is fixed to the end of the rigid body such that the axis of the suction pad is parallel to the axis of the rigid body, the surface under suction that is in contact with the suction pad is always perpendicular to the rigid body. Therefore, if the surface of an object is not perpendicular to the axis of the rigid body, the suction pad cannot directly cope with the inclined surface of the object. In an effort to overcome the above problem, a pad device was proposed, in which a bellows pipe or a ball joint is provided between a rigid body and a suction pad. In this structure, the suction pad is rotatably coupled to the rigid body by the bellows pipe or the ball joint. Therefore, the suction contact surface of the suction pad can be oriented in a variety of directions and angles relative to the rigid body, rather than being limited to the perpendicular state. In other words, the suction pad can freely rotate with respect to the rigid body because of the bellows pipe or the ball joint. Therefore, the suction pad can immediately cope with even an inclined surface of the object that is not perpendicular to the longitudinal axis of the rigid body. That is, when the suction pad is attached to the inclined surface of the object, the suction pad is bent with respect to the rigid body at an angle and in a direction corresponding to the inclined surface.

**[p0003]**

However, when the suction pad which has been attached to the object lifts the object to transport it to a desired place, the suction pad is rotated by the load of the object. Hence, precisely and safely transporting the object to the desired place becomes very difficult. To reliably realize application, installation, loading, etc. of the object, conditions, such as the orientation, angle, arrangement, etc. of the object before it is transported should be maintained not only when it is being transported but also after having been transported. However, when and if the suction pad is rotated when being transported, the orientation, angle, etc. of the object are changed during the transportation, and thus the above-mentioned requirements are not met. Moreover, if the object rotates when being transported, the object may become detached from the suction pad because of the load of the object and the rotational force applied thereto.

### Summary Of The Invention

**[p0004]**

Accordingly, the present invention has been made keeping in mind the above problems occurring in the prior art, and an object of the present invention is to provide a vacuum pad device which is configured such that: (1) a suction pad can rotate with respect to the housing; (2) even when the suction pad lifts an object after the pad has been attached to the object, the orientation of the suction pad relative to the housing can be maintained; and (3) the object can be precisely and safely transported. Another object of the present invention is to provide a vacuum pad device which includes a vacuum pump so that a vacuum transport system including the vacuum pad device can have a compact structure. In order to accomplish the above object, the present invention provides a vacuum pad device, including a housing, a pad unit coupled to the housing so as to be rotatable, and a piston installed in the housing to control rotation of the pad unit. Preferably, the vacuum pad device of the present invention further includes a vacuum pump provided in the housing by the housing and the piston. The details are as follows.

**[p0005]**

The housing has an inlet port and an outlet port which are respectively formed through the sidewall of the housing at an upper position and a lower position, a mounting seat which is formed through the lower end of the housing, and a sealing cover which is provided on the upper end of the housing. The pad unit includes a ball joint having a through hole formed in a longitudinal direction thereof, and a suction pad coupled to the end of the ball joint. A ball of the ball joint is seated into the mounting seat of the housing so that the pad unit is rotatably coupled to the housing. The piston is provided in the housing such that the outer surface of the piston is in close contact with the inner surface of the sidewall of the housing. The piston has a connection hole communicating with the outlet port with the through hole. The pressure of compressed air supplied from the inlet port moves the piston in the longitudinal direction of the housing, thus controlling rotation of the ball joint to prevent the pad unit from undesirably rotating when the object is transported. Preferably, the piston comes into surface contact with the ball of the ball joint, and the ball is pressed by the longitudinal movement of the piston, thereby restricting the rotation of the pad unit.

**[p0006]**

The vacuum pump comprises an axis-symmetric air pump. The vacuum pump has an air intake hole formed in a first end thereof, an air discharge hole formed in a second end thereof, and an opening formed through the sidewall of the vacuum pump to communicate with outside air. The vacuum pump is mounted to the housing in such a way that a mounting hole is formed in the housing at a position opposite to the outlet port and the first end and the second end of the vacuum pump are respectively inserted into the mounting hole and the outlet port. The opening of the vacuum pump communicates with the connection hole of the piston. In a vacuum pad device according to the present invention, a pad unit can rotate at a desired angle with respect to the housing before it is attached to an object. The angle at which the pad unit rotates with respect to the housing can be maintained by moving a piston which is operated by compressed air. Therefore, the object can be precisely and safely transported. Furthermore, the vacuum pad device of the present invention includes a vacuum pump, so that a vacuum transport system including the vacuum pad device can have a compact structure.

### Brief Description Of The Drawings

**[p0007]**

FIG. 1 is a sectional view showing an embodiment of a vacuum pad device, according to the present invention; FIG. 2 is a view showing the operation of the vacuum pad device of FIG. 1 ; FIG. 3 is a sectional view showing another embodiment of a vacuum pad device, according to the present invention; and FIG. 4 is a sectional view of a vacuum pump used in the vacuum pad device of FIG. 3 .

### Description Of The Elements In The Drawings

**[p0008]**

10 , 30 : vacuum pad device 11 : housing 12 : pad unit 13 : piston 14 : inlet port 15 : outlet port 16 : mounting seat 17 : sealing cover 18 : ball joint 19 : through hole 20 : suction pad 21 : ball 22 : connection hole 31 : vacuum pump 32 : air intake hole 33 : air discharge hole 34 : opening 38 : pin

### Description Of The Preferred Embodiments

**[p0009]**

The above and other objects, features and advantages of the present invention will be more clearly understood from the following detailed description taken in conjunction with the accompanying drawings. First Embodiment Referring to FIG. 1 , a vacuum pad device according to the present invention is designated by reference numeral 10 . The pad device 10 includes a housing 11 , a pad unit 12 which is rotatably coupled to the housing 11 , and a piston 13 which is installed in the housing 11 to control rotation of the pad unit 12 . The housing 11 has a hollow structure which is open on an upper end thereof. An inlet port 14 and an outlet port 15 are respectively formed through upper and lower positions of the sidewall of the housing 11 . A mounting seat 16 is formed in a lower end of the housing 11 . The upper end of the housing 11 is sealed with a sealing cover 17 . The pad unit 12 includes a ball joint 18 and a suction pad 20 . A through hole 19 is formed through the ball joint 18 along a longitudinal direction of the ball joint 18 . The suction pad 20 is coupled to an end of the ball joint 18 . The pad unit 12 is rotatably coupled to the housing 11 in such a way that a ball 21 of the ball joint 18 is seated into the mounting seat 16 of the housing 11 .

**[p0010]**

It is desirable that the mounting seat 16 has a round surface which is in surface contact with the ball 21 of the ball joint 18 . Thereby, the ball joint 18 can be reliably maintained in the mounting seat 16 so as to be rotatable. The piston 13 has therein a connection hole 22 which communicates with the outlet port 15 with the through hole 19 . The piston 13 comes into close contact with the inner surface of the housing 11 . A slight gap t is formed between a head surface of the piston 13 and the cover 17 to allow the piston 13 to move in a longitudinal direction of the housing 11 . Furthermore, a lower portion of the piston 13 comes into contact with the ball 21 of the ball joint 18 . When compressed air is supplied into the inlet port 14 , the pressure of the compressed air moves the piston 13 downwards, thus pressing the ball 21 of the ball joint 18 . The force with which the piston 13 presses the ball 21 prevents the ball joint 18 and the pad unit 12 from undesirably moving when an object is transported.

**[p0011]**

In this embodiment, although the piston 13 has been illustrated as being constructed such that it comes into direct contact with the ball 21 of the ball joint 18 and presses the ball 21 depending on movement of the piston 13 to control rotation of the ball joint 18 and the pad unit 12 , various control methods can be used, for example, an electronic brake system, or an indirect contact pressing method on the assumption that the ball 21 is controlled by the movement of the piston 13 , etc. Preferably, the piston 13 has a round recess 23 such that the piston 13 makes surface contact with the ball 21 of the ball joint 18 . Thereby, the ball joint 18 is directly pressed by the piston 13 , and comparatively large frictional resistance occurs between the ball joint 18 and the piston 13 . Hence, the ball joint 18 can be reliably restricted from undesirably rotating. Referring to FIG. 2 , to construct a vacuum system including the pad device 10 , a separate vacuum pump P is provided. The outlet port 15 of the housing 11 is connected to a suction port of the vacuum pump P. Compressed air is supplied into the vacuum pump P or the inlet port 14 of the housing 11 . A path along which compressed air is supplied is selectively controlled by an electronic valve.

**[p0012]**

The pad device 10 of the present invention is configured such that the pad unit 12 is rotatable with respect to the housing 11 . Therefore, on the assumption that the pad unit 12 is oriented in a predetermined direction and angled to the housing 11 at a predetermined angle (rotation angle), the operation of the pad device 10 when the object is transported will be explained below. When compressed air passes through the vacuum pump P at high speed, air which has been in the suction pad 20 is drawn into the vacuum pump P via the through hole 19 and the connection hole 22 by the high speed compressed air and then the air, along with the compressed air, is discharged out of the vacuum pump P. During this process, a vacuum is created in the vacuum pump P and a negative pressure is formed in the suction pad 20 . Thereafter, when the intensities of the vacuum and negative pressure become strong enough to transport the object, compressed air is supplied into the inlet port 14 to press the head surface of the piston 13 . Then, the piston 13 moves downwards and presses the ball 21 of the ball joint 18 . Thereby, strong frictional force is generated between the piston 13 and the ball joint 18 .

**[p0013]**

From this state, transportation of the object begins. Because there is a strong friction force acting between the piston 13 and the ball joint 18 , the angle which was set between the housing 11 and the pad unit 12 before the transportation of the object begins can be maintained when the object is being transported. Accordingly, the object can be precisely and safely transported. Second Embodiment Referring to FIG. 3 , a vacuum pad device according to a second embodiment of the present invention is designated by reference numeral 30 . The vacuum pad device 30 further includes a vacuum pump 31 as well as including a housing and a piston which have the same functions as those of the first embodiment. Therefore, the same reference numerals are used in FIG. 3 to designate the components having functions or constructions equal to or similar to those of the first embodiment. Description of the same constructions and functions as those of the first embodiment is deemed unnecessary.

**[p0014]**

Referring to FIG. 4 , the vacuum pump 31 is an axis-symmetric air pump. An air intake hole 32 is formed in a first end of the vacuum pump 31 , and an air discharge hole 33 is formed in a second end thereof. A plurality of openings 34 which communicate with the outside air is formed through the outer surface of the vacuum pump 31 . In the same manner as do typical pumps, multiple nozzles 35 , 36 and 37 are arranged in series in the vacuum pump 31 . However, the vacuum pump 31 of the present invention should not be construed as being limited to this type of pump. As shown in FIG. 3 , the vacuum pump 31 is mounted to the housing 11 in such a way that a mounting hole is formed in the housing 11 at a position opposite to the outlet port ( 15 of FIG. 1 ) and then the opposite ends of the vacuum pump 31 in which the air intake hole 32 and the air discharge hole 33 are formed are respectively inserted into the mounting hole and the outlet port. The openings 34 of the vacuum pump 31 communicate with the connection hole 22 of the piston 13 .

**[p0015]**

Compressed air is supplied into the air intake hole 32 and discharged out of the air discharge hole 33 after passing through the vacuum pump P at high speed. Then, air which has been in the suction pad 20 is drawn into the vacuum pump 31 via the through hole 19 , the connection hole 22 and the openings 34 by the high speed compressed air. Thereafter, the air, along with the compressed air, is discharged out of the vacuum pump 31 . During this process, vacuum is created in the vacuum pump 31 and a negative pressure is formed in the suction pad 20 . Subsequently, when the intensities of the vacuum and negative pressure become strong enough to transport the object, compressed air is supplied into the inlet port 14 to press the head surface of the piston 13 . Then, the piston 13 moves downwards and presses the ball 21 of the ball joint 18 . Thereby, strong frictional force is generated between the piston 13 and the ball joint 18 . This frictional force is used to restrict the pad unit 12 from undesirably moving when the object is being transported.

**[p0016]**

In FIG. 3 , reference numeral 38 denotes a pin installed between the piston 13 and the cover 17 to prevent the piston 13 from rotating. A slight gap is formed between the pin 38 and the piston 13 so that the pin 38 does not impede the longitudinal movement of the piston 13 . Furthermore, reference numeral 39 denotes a typical shock absorber which is mounted to the cover 17 in the longitudinal direction to absorb impacts applied to the object when it is being transported. Reference numeral 40 denotes a bracket which couples the pad device 30 to a transportation apparatus, such as a robot arm or the like. Reference numeral 41 denotes a silencer mounted to the second end of the vacuum pump 31 adjacent to the air discharge hole 33 . However, these elements 38 , 39 , 40 and 41 are not included in the components constituting the pad device 30 of the present invention.

## Figure captions

- **Figure 1:** FIG. 1 is a sectional view showing an embodiment of a vacuum pad device, according to the present invention;
- **Figure 2:** FIG. 2 is a view showing the operation of the vacuum pad device of FIG. 1 ;
- **Figure 3:** FIG. 3 is a sectional view showing another embodiment of a vacuum pad device, according to the present invention; and
- **Figure 4:** FIG. 4 is a sectional view of a vacuum pump used in the vacuum pad device of FIG. 3 .
- **Figure 1:** Referring to FIG. 1 , a vacuum pad device according to the present invention is designated by reference numeral 10 . The pad device 10 includes a housing 11 , a pad unit 12 which is rotatably coupled to the housing 11 , and a piston 13 which is installed in the housing 11 to control rotation of the pad unit 12 .
- **Figure 2:** Referring to FIG. 2 , to construct a vacuum system including the pad device 10 , a separate vacuum pump P is provided. The outlet port 15 of the housing 11 is connected to a suction port of the vacuum pump P. Compressed air is supplied into the vacuum pump P or the inlet port 14 of the housing 11 . A path along which compressed air is supplied is selectively controlled by an electronic valve.
- **Figure 3:** In FIG. 3 , reference numeral 38 denotes a pin installed between the piston 13 and the cover 17 to prevent the piston 13 from rotating. A slight gap is formed between the pin 38 and the piston 13 so that the pin 38 does not impede the longitudinal movement of the piston 13 .

## Classifications

- B25B11/007
- B25B11/007
- F16B47/00
- B25J15/06
- B25J15/0616
- B25J15/0616
- B25J17/0275
- B25J17/0275
- B65G47/91
- B65G47/91
- F16B47/00
- F16B47/00
- F16B47/00
- F16C11/06
- F16D3/00

## Cited patent documents

- [US-3152828-A](https://patents.google.com/patent/US3152828A/en) — PRS
- [US-3223442-A](https://patents.google.com/patent/US3223442A/en) — PRS
- [US-3272549-A](https://patents.google.com/patent/US3272549A/en) — PRS
- [US-3568959-A](https://patents.google.com/patent/US3568959A/en) — PRS
- [US-3613904-A](https://patents.google.com/patent/US3613904A/en) — PRS
- [US-3967849-A](https://patents.google.com/patent/US3967849A/en) — PRS
- [US-4600228-A](https://patents.google.com/patent/US4600228A/en) — PRS
- [US-4747634-A](https://patents.google.com/patent/US4747634A/en) — PRS
- [US-4957318-A](https://patents.google.com/patent/US4957318A/en) — PRS
- [US-5029383-A](https://patents.google.com/patent/US5029383A/en) — PRS
- [US-5544968-A](https://patents.google.com/patent/US5544968A/en) — PRS
- [US-5611258-A](https://patents.google.com/patent/US5611258A/en) — PRS
- [US-6024392-A](https://patents.google.com/patent/US6024392A/en) — PRS
- [US-6213521-B1](https://patents.google.com/patent/US6213521B1/en) — PRS
- [US-6454333-B2](https://patents.google.com/patent/US6454333B2/en) — PRS
- [US-6502877-B2](https://patents.google.com/patent/US6502877B2/en) — PRS
- [US-7281739-B2](https://patents.google.com/patent/US7281739B2/en) — PRS
- [US-7665783-B2](https://patents.google.com/patent/US7665783B2/en) — PRS
- [US-8113560-B2](https://patents.google.com/patent/US8113560B2/en) — PRS

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
