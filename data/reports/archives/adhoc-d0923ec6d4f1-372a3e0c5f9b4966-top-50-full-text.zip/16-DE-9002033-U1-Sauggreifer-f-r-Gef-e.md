# 16. Sauggreifer für Gefäße

- **Archive rank:** 16 of 50
- **Publication:** [DE-9002033-U1](https://patents.google.com/patent/DE9002033U1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/006851231/publication/DE9002033U1?q=pn%3DDE9002033U1)
- **Publication date:** 1990-04-26
- **Filing date:** 1990-02-21
- **Earliest priority:** 1990-02-21
- **Family:** 6851231
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Abstract

_No abstract was available from the queried sources._

## Sketches and drawings

_No digitized sketch link was returned._

## Claims

### Claim 1 (independent)

Sauggreifer für Gefäße, mit einem einen Vakuumanschluß aufweisenden Gehäuse und einem an diesem befestigten Saugnapf, der eine elastische, ringförmige Dichtlippe aufweist und mit dem Vakuumanschluß verbunden ist, dadurch gekennzeichnet, daß am Gehäuse (1) außerhalb des Saugnapfs (2) eine elastische, ringförmige Dichtfläche (5) befestigt ist, deren Durchmesser größer ist als der Durchmesser der Dichtlippe (3).1. Suction gripper for vessels, with a housing having a vacuum connection and a suction cup attached to the housing, which has an elastic, annular sealing lip and is connected to the vacuum connection, characterized in that an elastic, annular sealing surface (5) is attached to the housing (1) outside the suction cup (2), the diameter of which is larger than the diameter of the sealing lip (3).

### Claim 2

Sauggreifer nach Anspruch 1, dadurch gekennzeichnet, daß der ringförmige Bereich zwischen der Dichtlippe (3) und der Dichtfläche (5) hermetisch abgedichtet ist.2. Suction gripper according to claim 1, characterized in that the annular region between the sealing lip (3) and the sealing surface (5) is hermetically sealed.

### Claim 3

Sauggreifer nach Anspruch 1 oder 2, dadurch gekennzeichnet, daß die Dichtfläche (5) konzentrisch zur Dichtlippe (3) angeordnet ist.3. Suction gripper according to claim 1 or 2, characterized in that the sealing surface (5) is arranged concentrically to the sealing lip (3).

### Claim 4

Sauggreifer nach einem der Ansprüche 1 bis 3, dadurch gekennzeichnet, daß die Dichtfläche (5) konisch ausgebildet ist.4. Suction gripper according to one of claims 1 to 3, characterized in that the sealing surface (5) is conical.

### Claim 5

Sauggreifer nach Anspruch 4, dadurch gekennzeichnet, daß s'-h die Dichtfläche (5) zum Gehäuse (1) hin verengt.5. Suction gripper according to claim 4, characterized in that s'-h the sealing surface (5) narrows towards the housing (1).

### Claim 6

Saugt; 3ifer nach einem der Ansprüche 1 bis 5, dadurch gekennzeichnetr daß die Dichtfläche (5) in einer zur Ebene der Dichtlippe (3) parallelen, näher am Gehäuse (1) liegenden Ebene angeordnet ist.6. Suction device according to one of claims 1 to 5, characterized in that the sealing surface (5) is arranged in a plane parallel to the plane of the sealing lip (3) and closer to the housing (1).

### Claim 7

Sauggreifer nach einem der Ansprüche 1 bis 6, dadurch gekennzeichnet, daß der Saugnapf (2) und die Dichtfläche (5) einstückig ausgebildet sind.7. Suction gripper according to one of claims 1 to 6, characterized in that the suction cup (2) and the sealing surface (5) are formed in one piece.

### Claim 8

Sauggreifer nach Anspruch 7, dadurch gekennzeichnet, daß ein die Dichtlippe (3) und die Dichtfläche (5) tragender Rotationskörper (6) an seiner von der Dichtlippe (3) wegweisenden Rückseite mit hinterschnittenen Erhöhungen und/oder Vertiefungen versehen ist, die in entsprechende8. Suction gripper according to claim 7, characterized in that a rotational body (6) carrying the sealing lip (3) and the sealing surface (5) is provided on its rear side facing away from the sealing lip (3) with undercut elevations and/or depressions which can be inserted into corresponding &igr; Erhöhungen (10) und/oder Vertiefungen des Gehäuses (1) eingreifen. &igr; elevations (10) and/or depressions of the housing (1).

## Full description

PERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippers

Description

Translated from German

KRONES AG pat-ha-jo/464-DEKRONES AG pat-ha-jo/464-EN

Hermann Kroneeder 20. Februar 1990Hermann Kroneeder 20 February 1990

MaschinenfabrikMachine factory

Sauggreifer fÃ¼r GefÃ¤ÃeSuction cups for vessels

BeschreibungDescription

' ' Die steuerung betrifft einen Sauggreifer fÃ¼r GefÃ¤Ãe, mit Â«inem

einen VakuwaanschliuÃ aufweiÃeÂ» en GehÃ¤v--Â« und einem an diesenÂ·

befestigt Saugnapf, der eine elastische, ringfÃ¶rmige Dichtlippe

aufweist und mit dem Vakuumanschlu^ ,jrbu/ len ist.The control relates to a suction gripper for vessels, with a housing having a vacuum connection and a suction cup attached to it, which has an elastic, ring-shaped sealing lip and is connected to the vacuum connection.

Derartige Sauggreifer werden aufgrund ihres besonders einfachen,

kostengÃ¼nstigen AuftÂ»us hÃ¤ufig zum Erfassen von geschlossenen

GefÃ¤Ãen mit einer auereichend groÃen VerschluÃflÃ¤che wie z.B. Gi<4^ >rn mit einÃ¶s Schnapp- oder SchraubverschluÃ oder Dosen

eingesetzt (DE-GM 63 15 044). Die bekannten Sauggreifer kÃ¶nnen jedoch naturgemÃ¤Ã keine offenen GefÃ¤Ãe ohne VerschlÃ¼sse erfassen.

Soll also z.B. in einer Auspackmaschine gemischtes Leergut mit

r\ z.T. offenen, z.T. geschlossenen GlÃ¤sern aus den Transportkisten

herausgenommen werden, so sind seitlich an den GefÃ¤Ãen angreifende Tulpen mit aufblasbaren elastischen Manschetten oder

mechanischen Spannzangen erforderlich. Das gleiche ist der Fall, wenn in einer kombinierten Ein- und Auspackmaschine leere GefÃ¤Ãe

auegepackt und geschlossene GefÃ¤Ãe eingepackt werden mÃ¼ssen. Die in solchen FÃ¤llen bisher verwendeten Tulpen sind wesentlich

aufwendiger als Sauggreifer und nicht fUr alle VerschluÃarten geeignet, insbesondere nicht bei VerschlÃ¼ssen mit seitlichen

Grifflaschen.Such suction grippers are often used for gripping closed containers with a sufficiently large closure surface, such as jars with a snap or screw closure or cans (DE-GM 63 15 044), due to their particularly simple and cost-effective opening. However, the known suction grippers cannot naturally grip open containers without closures. If, for example, mixed empty containers with partly open and partly closed jars are to be removed from the transport crates in an unpacking machine, tulips with inflatable elastic sleeves or mechanical collets that grip the containers from the side are required. The same is the case when empty containers have to be unpacked and closed containers have to be packed in a combined packing and unpacking machine. The tulips used to date in such cases are much more complex than suction grippers and are not suitable for all types of closure, particularly not for closures with side grip tabs.

Der Neuerung liegt die Aufgabe zugrunde, einen gattungsgemÃ¤Ãen Sauggreifer der eingangs genannten Art mit einfachen Mitteln

dahingehend weiterstabilden, dnÃ Sj; au"Â·** offene GefÃ¤Ãe zuverlÃ¤ssig

erfassenThe innovation is based on the task of further stabilizing a generic suction gripper of the type mentioned at the beginning with simple means so that it can reliably grasp open vessels.

Diese Aufgabe wird neuerungsgemÃ¤Ã dadurch gelÃ¶st, daÃ am GehÃ¤use

auÃerhalb des Saugnapfe eine elastische, ringfÃ¶rmige DichtflÃ¤che befestigt ist, deren Durchmesser grÃ¶Ãer ist als derjenige der

Dichtlippe.This task is solved in accordance with the innovation by attaching an elastic, ring-shaped sealing surface to the housing outside the suction cup, the diameter of which is larger than that of the sealing lip.

Der neuerungsgemÃ¤Ãe Sauggreifer ist trotz einfachstem Aufbau und

gefÃ¤Ãschonender Wirkungsweise vielfÃ¤ltig verwendbar. Mit seinem Saugnapf bzw. seiner Dichtlippe kann er die verschiedensten

geschlossenen GefÃ¤Ãe mit einer ausreichend groÃen AngriffsflÃ¤che erfassen. Mit seiner zusÃ¤tzlichen ringfÃ¶rmigen DichtflÃ¤che kann

er ferner verschiedenste GefÃ¤Ãe, deren MÃ¼ndungsdurchmesser im Durchmesserbereich der DichtflÃ¤che liegt, ergreifen. Da gerade

die Mundungsbereiche von GefÃ¤Ãen mit besonders engen Toleranzen gefertigt werden, bereitet eine ausreichende Abdichtung keine

Probleme.The new suction gripper can be used in a variety of ways despite its simple design and its gentle action on the vessel. With its suction cup or sealing lip, it can grip a wide variety of closed vessels with a sufficiently large contact surface. With its additional ring-shaped sealing surface, it can also grip a wide variety of vessels whose mouth diameter is in the diameter range of the sealing surface. Since the mouth areas of vessels are manufactured with particularly tight tolerances, adequate sealing does not cause any problems.

, j Eine Umstellung von der Verarbeitung von GefÃ¤Ãen mit VerschlÃ¼ssen

\ auf die Verarbeitung von GefÃ¤Ãen ohne VerschlÃ¼sse let

\ normalerweise nicht erforderlich, insbesondere dann, wenn der, j A change from processing of vessels with closures \ to processing of vessels without closures let \ is not normally necessary, especially if the

ringfÃ¶rmige Bereich zwischen der Dichtlippe und der DichtflÃ¤che hermetisch abgedichtet ist. Der Aufbau des Vakuums erfolgt in

diesem Falle immer Ã¼ber den VakuumanschluÃ des Saugnapfe,

r unabhÃ¤ngig davon, ob die Dichtlippe oder die DichtflÃ¤che im Eineatz sind. Auch eine gemischte Verarbeitung von GefÃ¤Ãen mit

und ohne VerschlÃ¼ssen ist daher problemlos mÃ¶glich.ring-shaped area between the sealing lip and the sealing surface is hermetically sealed. In this case, the vacuum is always created via the vacuum connection of the suction cup, regardless of whether the sealing lip or the sealing surface is in use. Mixed processing of containers with and without closures is therefore also possible without any problems.

ZweckmÃ¤Ãigerweise ist die DichtflÃ¤che konzentrisch zur DichtlippeThe sealing surface is preferably concentric to the sealing lip

angeordnet, um ein gleich sicheres und mittiges Greifen von

offenen und geschlossenen GefÃ¤Ãen zu bewerkstelligen.arranged to ensure equally safe and central gripping of

open and closed vessels.

Die DichtflÃ¤che ist in Form und GrÃ¶Ãe dem MUndungsrand der zu

transportierenden GefÃ¤Ãe anzupassen und kann z.B. eben sein. Besonders gÃ¼nstig ist ein konischer, sich zum GehÃ¤use hin

verengender Verlauf, wodurch eine gewisse Zentrierwirkung erzielt wird.The shape and size of the sealing surface must be adapted to the mouth edge of the vessels to be transported and can, for example, be flat. A conical shape that narrows towards the housing is particularly advantageous, as this achieves a certain centering effect.

Eine besondere kostengÃ¼nstige Bauweise wird erzielt, wenn der Saugnapf und die DichtflÃ¤che einstÃ¼ckig ausgefÃ¼hrt sind. Bei

entsprechender Wahl eines geeigneten Kunststoffs, z.B. eines gieÃfÃ¤higen Silikons, mit ausreichender ElastizitÃ¤t, ist dies

problemlos mÃ¶glich.A particularly cost-effective design is achieved when the suction cup and the sealing surface are made as one piece. If a suitable plastic is chosen, e.g. a pourable silicone with sufficient elasticity, this is easily possible.

Zu einer kostengÃ¼nstigen Bauweise trÃ¤gt es ferner bei, wenn ein die Dichtlippe und die DichtflÃ¤che tragender RotationskÃ¶rper an

seiner von der Dichtlippe weg weisenden RÃ¼ckseite mit hinterschnittenen ErhÃ¶hungen und/oder Vertiefungen versehen ist,

die in entsprechende ErhÃ¶hungen und/oder Vertiefungen des GehÃ¤uses eingreifen. Die Verbindung von RotationskÃ¶rper und

GehÃ¤use wird dann, bei getrennter Fertigung, durch Einschnappen bewirkt oder es wird der RotationskÃ¶rper direkt auf bzw. in das

GehÃ¤use eingegossen, wobei nach dem AuehÃ¤rten eine bleibende Verbindung vorliegt.It also contributes to a cost-effective design if a rotating body that supports the sealing lip and the sealing surface is provided with undercut elevations and/or depressions on its rear side facing away from the sealing lip, which engage in corresponding elevations and/or depressions in the housing. The connection between the rotating body and the housing is then achieved by snapping in if they are manufactured separately, or the rotating body is cast directly onto or into the housing, whereby a permanent connection is created after hardening.

Ein AusfÃ¼hrungsbeiepiel der Neuerung wird im Nachstehenden anhand

der Zeichnung beschrieben. Diese zeigt einen senkrechten Schnitt durch einen Sauggreifer in seiner normalen Arbeitsposition mit

senkrechter Mittelachse.An example of the innovation is described below using the drawing. This shows a vertical section through a suction gripper in its normal working position with a vertical central axis.

Der Sauggreifer weist ein rotationssyminetrieches, plattenartiges

GehÃ¤use 1 aus Metall oder hartem Kunststoff auf. An dessen Oberseite ist ein VakuumanschluÃ in Form eines Gewindestutzens

ausgebildet, durch den der Sauggreifer Ã¼ber ein nicht gezeigtes RohrstUck oder dgl. mit einer Vakuumquelle verbunden ist. Das

Rohrsttick kann gleichzeitig die hÃ¶henbewegliche Halterung des

Sauggreifers im gleichfalls nicht gezeigten Greiferrahmen einer

Aus- oder Einpackmaschine fÃ¼r GlÃ¤ser 4 Ãbernehmen. Der Gewindestutzen 7 und das GehÃ¤use 1 sind mit einer durchgehenden

Vakuumbohrung 9 versehen.The suction gripper has a rotationally symmetrical, plate-like housing 1 made of metal or hard plastic. On the top of the housing is a vacuum connection in the form of a threaded connector, through which the suction gripper is connected to a vacuum source via a pipe section or the like (not shown). The pipe section can simultaneously take over the height-adjustable mounting of the suction gripper in the gripper frame (also not shown) of a packing or unpacking machine for glasses 4. The threaded connector 7 and the housing 1 are provided with a continuous vacuum bore 9.

An der Unterseite des GehÃ¤uses 1 ist ein ringfÃ¶rmiger Ansatz 10 mit beideeitigen Hinterschneidungen konzentrisch zur Mittelachse

ausgebildet. Auf diesem sitzt ein RotationskÃ¶rper 6 aus elastischem Kunststoff, z.B. Silikon mit einer HÃ¤rte von

65s Shore, der direkt durch AngieÃen mit dem GehÃ¤use 1 vollflÃ¤chig verbunden ist. Der RotationskÃ¶rper 6 weist eine mit

der Vakuumbohrung 9 fluchtende durchgehende VakuumÃ¶ffnung 11 auf und hat den gleichen AuÃendurchmesser wie das GehÃ¤use 1.On the underside of the housing 1, a ring-shaped projection 10 with undercuts on both sides is formed concentrically to the central axis. On this is a rotating body 6 made of elastic plastic, e.g. silicone with a hardness of 65 s Shore, which is directly connected to the housing 1 over its entire surface by casting. The rotating body 6 has a continuous vacuum opening 11 aligned with the vacuum bore 9 and has the same outer diameter as the housing 1.

An der Unterseite des RotationskÃ¶rpers 6 ist konzentrisch zur Mittelachse und zur VakuumÃ¶ffnung 11 ein Saugnapf 2 mit einer

ringfÃ¶rmigen, elastischen Dichtlippe 3 ausgebildet. Das Innere des Saugnapfes 2 steht Ã¼ber die VakuumÃ¶ffnung 11 und die

Vakuumbohrung 9 mit der Vakuumquelle in Verbindung. Wie auf der linken Seite der Zeichnung dargestellt ist, greift der Saugnapf

mit seiner in einer Ebene liegenden Dichtlippe 3 an der

horizontalen, ebenen Oberseite einer auf einem Glas 4 sitzenden VerschluÃkappe 8 mit einer seitlich abstehenden Ã¶ffnungslasche

an. Wird nun das Vakuum eingeschaltet, so saugt sich der Saugnapf 2 an der VerschluÃkappe 8 fest und das Glas 4 wird sicher

ergriffen.On the underside of the rotating body 6, a suction cup 2 with an annular, elastic sealing lip 3 is formed concentrically to the central axis and the vacuum opening 11. The interior of the suction cup 2 is connected to the vacuum source via the vacuum opening 11 and the vacuum bore 9. As shown on the left-hand side of the drawing, the suction cup with its sealing lip 3 lying in one plane grips the horizontal, flat top of a closure cap 8 sitting on a glass 4 with an opening tab protruding to the side. If the vacuum is now switched on, the suction cup 2 sucks itself onto the closure cap 8 and the glass 4 is securely gripped.

Welter ist an der Unterseite des RotationskÃ¶rpers 6 auÃerhalb des Saugnapfe 2 eine gleichfalls konzentrisch zur Mittelachse bzw.

zur VakuumÃ¶ffnung 11 verlaufende ringfÃ¶rmige, elastische Dichtflache 5 ausgebildet. Diese ist konzentrisch geformt und

verengt sich zum GehÃ¤use 1 hin. Die DichtflÃ¤che 5 liegt nÃ¤her am GehÃ¤use 1 als die Dichtlippe 3 in entspanntem Zustand. Anders

ausgedruckt liegen die Endbereiche der DichtflÃ¤che 5 und der schrÃ¤gen Dichtlippe 3 in zwei parallelen Ebenen, wobei die Ebene

der Dichtlippe 3 vom GehÃ¤use 1 weiter entfernt ist als die Ebene der DichtflÃ¤che 5. Auf diese Weise wird ein EinfluÃ der

DichtflÃ¤che 5 auf die Greiffunktion des Saugnapf&bgr; 2 vermieden.

Der Abstand zwischen den beiden Ebenen kann jedoch so gewÃ¤hlt werden, daÃ die Verformung der Dichtlippe 3 unter Vakuum durch

ein Anschlagen der VerschluÃkappe 8 an der DichtflÃ¤che 5 begrenzt

wird.Furthermore, on the underside of the rotating body 6 outside the suction cup 2, an annular, elastic sealing surface 5 is formed, which also runs concentrically to the central axis or to the vacuum opening 11. This is concentrically shaped and narrows towards the housing 1. The sealing surface 5 is closer to the housing 1 than the sealing lip 3 in the relaxed state. In other words, the end areas of the sealing surface 5 and the oblique sealing lip 3 are in two parallel planes, with the plane of the sealing lip 3 being further away from the housing 1 than the plane of the sealing surface 5. In this way, an influence of the sealing surface 5 on the gripping function of the suction cup 2 is avoided. The distance between the two planes can, however, be selected such that the deformation of the sealing lip 3 under vacuum is limited by the closure cap 8 striking the sealing surface 5.

Wie auf der rechten Seite der Zeichnung dargestellt ist, ist der

Durchmesser der DichtflÃ¤che 5 an den Durchmesser des kreisfÃ¶rmigen offenen Randes eines Glases 4 angepaÃt. Die

ringfÃ¶rmige Zcae 13 zwischen dem inneren Ende der DichtflÃ¤che 5 und der EinmÃ¼ndung der Dichtlippe 3 in den RotationskÃ¶rper 6 ist

hermetisch abgedichtet, so daÃ im Inneren eines an der DichtflÃ¤che 5 anliegenden offenen Glases 4 Ã¼ber die VakuumÃ¶ffnung

11 des Saugnapfs 2 ein ausreichender Unterdruck erzeugt werden kann. Da der Ã¤uÃere Durchmesser der Dichtlippe 3 kleiner ist als

der innere Durchmesser der DichtflÃ¤che 5 und der Ã¶ffnung des Glases 4, wird die Greiffunktion der DichtflÃ¤che 5 durch den

Saugnapf 2 nicht beeinfluÃt.As shown on the right-hand side of the drawing, the diameter of the sealing surface 5 is adapted to the diameter of the circular open edge of a glass 4. The annular Zcae 13 between the inner end of the sealing surface 5 and the mouth of the sealing lip 3 in the rotating body 6 is hermetically sealed so that a sufficient negative pressure can be generated inside an open glass 4 resting on the sealing surface 5 via the vacuum opening 11 of the suction cup 2. Since the outer diameter of the sealing lip 3 is smaller than the inner diameter of the sealing surface 5 and the opening of the glass 4, the gripping function of the sealing surface 5 is not influenced by the suction cup 2.

Im gezeigten AusfÃ¼hrungsbeispiel wird die ElastizitÃ¤t der DichtflÃ¤che 5 allein durch das Material bestimmt. Es ist jedochIn the embodiment shown, the elasticity of the sealing surface 5 is determined solely by the material. However,

auch mÃ¶glich, durch eine spezielle Formgebung , z.B. durch HohlrÃ¤ume im RotationskÃ¶rper 6 im Bereich der Dichtfluche 5,

deren ElastizitÃ¤t zu beeinflussen. Auch kann die DichtflÃ¤che durch einen separaten Dichtring gebildet werden, der am GehÃ¤use

direkt oder unter Zwischenschaltung des RotationskÃ¶rpers 6 indirekt befestigt ist.It is also possible to influence the elasticity of the rotating body 6 by means of a special shape, e.g. by means of hollow spaces in the rotating body 6 in the area of the sealing surface 5. The sealing surface can also be formed by a separate sealing ring which is attached to the housing directly or indirectly with the rotating body 6 interposed.

## Classifications

- B65G47/91
- B65G47/91

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
