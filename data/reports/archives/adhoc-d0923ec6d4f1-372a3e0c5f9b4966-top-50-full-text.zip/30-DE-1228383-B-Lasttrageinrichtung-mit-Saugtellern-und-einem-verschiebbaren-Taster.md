# 30. Lasttrageinrichtung mit Saugtellern und einem verschiebbaren Taster

- **Archive rank:** 30 of 50
- **Publication:** [DE-1228383-B](https://patents.google.com/patent/DE1228383B/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/007309230/publication/DE1228383B?q=pn%3DDE1228383B)
- **Publication date:** 1966-11-10
- **Filing date:** 1963-10-10
- **Earliest priority:** 1963-10-10
- **Family:** 7309230
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** MIAG MUEHLENBAU & IND GMBH
- **Inventors:** BLUME WALTER; GOTTSCHALK ROBERT

## Abstract

_No abstract was available from the queried sources._

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-1228383-B/ops000.png)

![Sketch 1 for DE-1228383-B](https://nimo.iptorch.com/refdrawing/DE-1228383-B/ops000.png)

## Claims

### Claim 1 (independent)

Patentansprüche: 1. Einrichtung zum Tragen von Lasten mittels mehrerer an einem Traggestell angeordneter Halteglieder, die durch einen zur ersten Anlage an der Last vorgesehenen verschiebbaren Taster steuerbar sind, dadurch gekennzeichnet, daß der verschiebbare Taster (12) die Beaufschlagung der als Saugteller (2) ausgebildeten Halteglieder mit Unterdruck mittels eines Steuergerätes (13,14) dann freigibt, wenn der Taster (12) einen Verschiebeweg (11) zurückgelegt hat und die Saugteller (2) ebenfalls an der aufzunehmenden Last anliegen. Claims: 1. Device for carrying loads by means of several on a support frame arranged holding members, which by a to the first plant sliding buttons provided on the load can be controlled, characterized in that that the displaceable button (12) acts on the designed as a suction plate (2) Holding members with negative pressure by means of a control device (13,14) then releases when the button (12) has covered a displacement path (11) and the suction plate (2) also rest on the load to be picked up.

### Claim 2

Einrichtung nach Anspruch 1, dadurch gekennzeichnet, daß der Taster (12) als zentral angeordneter, mit einem Zylinder (14) versehener Saugkopf (21) ausgebildet ist, dessen Verschiebeweg (11) nach Anlage an einer Last mittels Unterdruck im Zylinderinneren (23) bis auf Null verringerbar ist. 2. Device according to claim 1, characterized characterized in that the button (12) as a centrally arranged, with a cylinder (14) provided suction head (21) is formed, the displacement path (11) after contact can be reduced to zero at a load by means of negative pressure in the cylinder interior (23) is.

### Claim 3

Einrichtung nach Anspruch 1 und 2, dadurch gekennzeichnet, daß der Saugkopf (21) des Tasters (12) vom Anschluß (16) an eine Unterdruckquelle getrennt wird, wenn der Unterdruck an den Saugtellern (2) einen einstellbaren Höchstwert erreicht hat. 3. Device according to claim 1 and 2, characterized in that the suction head (21) of the button (12) is separated from the connection (16) to a vacuum source, when the negative pressure on the suction pads (2) reaches an adjustable maximum value Has.

### Claim 4

Einrichtung nach Anspruch 1 und 2, dadurch gekennzeichnet, daß der Taster (12) durch eine Feder (15) in die gegenüber den Saugtellern (2) vorspringende Ruhestellung gedrückt wird. 4. Device according to claim 1 and 2, characterized in that the button (12) by a spring (15) into the rest position protruding from the suction plates (2) is pressed.

### Claim 5

Einrichtung nach Anspruch 1 und 2, dadurch gekennzeichnet, daß der Taster (12) als vorstehender Teil eines Steuerkolbens (13) ausgebildet ist, der in dem an die Unterdruckquelle angeschlossenen Zylinder (14) verschiebbar ist und Bohrungen (17) zur Verbindung des Zylinderinneren (23) mit zu den Saugtellern (2) führenden Kanälen (19, 20) aufweist. 5. Device according to claim 1 and 2, characterized in that the button (12) is designed as a protruding part of a control piston (13), which is displaceable in the cylinder (14) connected to the vacuum source and bores (17) for connecting the cylinder interior (23) to the suction plates (2) leading channels (19, 20).

### Claim 6

Einrichtung nach Anspruch 3 und 5, dadurch gekennzeichnet, daß im Steuerzylinder (14) ein durch Bohrungen (27) mit dem Zylinderinneren (23) verbundener Hilfszylinder (24) angeordnet ist, dessen Kolben (25) beim Erreichen eines hohen Unterdrucks gegen die Wirkung einer Feder (29) ein Ventil (22, 28) für den Zutritt von Unterdruck zum Saugkopf (21) des Tasters (12) verschließt. Device according to claim 3 and 5, characterized in that in the control cylinder (14) through bores (27) with the cylinder interior (23) connected auxiliary cylinder (24) is arranged, the piston (25) when reaching a high negative pressure against the Action of a spring (29) closes a valve (22, 28) for the access of negative pressure to the suction head (21) of the button (12).

### Claim 7

Einrichtung nach Anspruch 1, dadurch gekennzeichnet, daß die Saugteller (2) in einer Ebene an der Last angreifen und der Verschiebeweg (11) des Tasters (12) gleich dessen überstand gegenüber dieser Ebene in Richtung zur Last ist. B. Einrichtung nach Anspruch 1, dadurch gekennzeichnet, daß die Saugteller (2) einzeln auf Kolben (5) abgestützt sind, die in untereinander durch Ausgleichsleitungen (7) verbundenen, am Gestell (1) angeordneten.Unterdruckzylindern (6) verschiebbar sind. 9. Einrichtung nach Anspruch 1, dadurch gekennzeichnet, daß zwischen den Saugtellern (2) und den Kolben (5) Kugelgelenke (4) eingebaut sind. In Betracht gezogene Druckschriften: Deutsche Patentschrift Nr. 1126 099; deutsches Gebrauchsmuster Nr.1850 562; österreichische Patentschrift Nr. 174 715; französische Patentschrift Nr.1108 408; USA.- Patentschrift Nr.1801305.7. Device according to claim 1, characterized in that the suction plate (2) act in one plane on the load and the displacement path (11) of the button (12) is equal to its overhang relative to this plane in the direction of the load. B. Device according to claim 1, characterized in that the suction plates (2) are supported individually on pistons (5) which are displaceable in vacuum cylinders (6) connected to one another by compensating lines (7) and arranged on the frame (1). 9. Device according to claim 1, characterized in that ball joints (4) are installed between the suction plates (2) and the pistons (5). Documents considered: German Patent No. 1126 099; German utility model number 1850 562; Austrian Patent No. 174 715; French Patent No. 1108 408; U.S. Patent No. 1801305.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansOperating and control devicesPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansSingle lifting units; Only one suction cup

Description

Translated from German

Lasttrageinrichtung mit Saugtellern und einem verschiebbaren Taster

Die Erfindung bezieht sich auf eine Einrichtung zum Tragen von Lasten mittels mehrerer

Saugteller, die mit Unterdruck beaufschlagt werden. Die Saugteller sind an einem

Traggestell angeordnet, das am Ausleger eines Kranfahrzeugs oder an einer KranbrÃ¼cke

aufgehÃ¤ngt wird.Load carrying device with suction pads and a sliding button

The invention relates to a device for carrying loads by means of several

Suction pads that are subjected to negative pressure. The suction pads are on one

Support frame arranged on the boom of a crane vehicle or on a crane bridge

is hung.

Bei rein mechanisch wirkenden Lasttrageinrichtungen ist es bekannt,

am Gestell einen verschiebbaren Taster relativ zu den Greiforganen vorstehen zu

lassen, der zur ersten Anlage an der Last bestimmt ist und die Greif- und Halteglieder

steuert. Nach ZurÃ¼cklegen eines Verschiebeweges lÃ¤Ãt dieser Taster mechanische Greifarme

zur Anlage an der Last kommen.In the case of purely mechanically acting load bearing devices, it is known

on the frame to protrude a movable button relative to the gripping organs

which is intended for first contact with the load and the gripping and holding members

controls. After covering a displacement path, this button leaves mechanical gripping arms

come to rest on the load.

Wenn die Halteglieder einer Trageinrichtung als Saugteller ausgebildet

sind, so lÃ¤Ãt es sich oft nicht erreichen, daÃ alle Saugteller beim Aufnahmevorgang

gleichzeitig zur Anlage kommen. Es ist viehhehr damit zu rechnen, daÃ einzelne Saugteller

frÃ¼her an der Last verankert werden als andere. Die Last wird dann zeitweise nur

unsicher gehalten, und es treten hohe Verluste an Vakuum ein.When the holding members of a support device are designed as suction cups

are, it can often not be achieved that all suction pads during the recording process

come to the system at the same time. It is very likely that individual suction pads

be anchored to the load earlier than others. The load is then only temporarily

kept insecure, and high vacuum losses occur.

Um den Ansaugevorgang gleichmÃ¤Ãiger und zuverlÃ¤ssiger vornehmen zu

kÃ¶nnen, wird gemÃ¤Ã der Erfindung vorgeschlagen, daÃ ein verschiebbarer Taster die

Beaufschlagung der Saugteller mit Unterdruck mittels eines SteuergerÃ¤tes dann freigibt,

wenn der Taster einen Verschiebeweg zurÃ¼ckgelegt hat und die Saugteller ebenfalls

an der Last anliegen, d. h., wenn sich der Ãberstand des Tasters durch ZurÃ¼cklegen

des ganzen Verschiebeweges bis auf Null verringert hat. Dabei wird der Taster vorzugsweise

als zentral angeordneter, mit einem Zylinder versehener Saugkopf ausgebildet, dessen

Verschiebeweg nach Anlage an einer Last mittels Unterdruck im Zylinderinneren bis

auf Null verringert wird. Es wird also nicht nur das Eigengewicht des Traggestells

zum Aufsetzen benutzt, sondern mittels des Saugkopfes wird das ganze Traggestell

an die Last herangesaugt, bis alle Saugteller gleichmÃ¤Ãig aufsitzen. Danach kann

der Unterdruck im Saugkopf selbst abgeschaltet werden, wenn die Saugteller volles

Vakuum erreicht haben. Dadurch werden ein geringer Verbrauch von Vakuum und eine

zuverlÃ¤ssige Aufnahme der Last an vielen Punkten gewÃ¤hrleistet.To make the suction process more even and reliable

can, it is proposed according to the invention that a slidable button the

Then releasing the application of negative pressure to the suction cup by means of a control device,

when the button has covered a displacement path and so have the suction pads

rest on the load, d. That is, if the protrusion of the button is removed by laying it back

of the entire displacement path has reduced to zero. The button is preferred

designed as a centrally arranged, provided with a cylinder suction head, the

Displacement after contact with a load by means of negative pressure inside the cylinder up to

is reduced to zero. So it is not just the dead weight of the support frame

used to put on, but by means of the suction head, the whole support frame

sucked up to the load until all suction pads are seated evenly. After that you can

the vacuum in the suction head itself can be switched off when the suction pad is full

Have reached vacuum. This will result in a low consumption of vacuum and a

reliable loading of the load is guaranteed at many points.

Es ist bekannt, Saugteller einzeln verschiebbar gegen ein Traggestell

abzustÃ¼tzen und sie mit Federn auszurÃ¼sten. Dadurch kÃ¶nnen Unebenheiten einer zu

ergreifenden FlÃ¤che ausgeglichen werden. Die Federn rufen jedoch ReaktionskrÃ¤fte

in der Last hervor, die zu Biegebeanspruchungen fÃ¼hren kÃ¶nnen. Beim Verluden von

Glasplatten; verhÃ¤ltnismÃ¤Ãig dÃ¼nnen Marmorplatten u. dgl. kÃ¶nnen solche Biegebeanspruchungen

unzulÃ¤ssig sein.It is known that suction cups can be individually slid against a support frame

support and equip them with springs. This can cause bumps too

poignant area to be balanced. However, the springs invoke reaction forces

in the load, which can lead to bending stresses. When loading

Glass plates; Relatively thin marble slabs and the like can bear such bending stresses

be inadmissible.

Ferner ist ein GehÃ¤nge zum Transport schwerer Blechplatten bekannt,

bei dem einzelne Magnete an Kolben hÃ¤ngen, die verschiebbar in pneumatischen oder

hydraulischen Zylindern gefÃ¼hrt sind. Alle Zylinder sind durch Ausgleichsleitungen

miteinander verbunden, so daÃ die Tragkraft der Magnete voll ausgenutzt wird und

auch unebene Platten zuverlÃ¤ssig gehalten werden. In Ausgestaltung der Erfindung

wird vorgeschlagen, solche Ausgleichsleitungen auch bei den Haltegliedern anzuwenden,

die als Saugteller ausgebildet und mit Einzelkolben in Zylindern abgestÃ¼tzt sind.

Dadurch wird die Aufgabe gelÃ¶st, auch empfindliche Lasten schonend und zuverlÃ¤ssig

zu ergreifen und zu halten. In bekannter Weise kÃ¶nnen dabei zwischen die Saugteller

und die zugehÃ¶rigen Kolben Kugelgelenke eingebaut werden.Furthermore, a hanger for transporting heavy sheet metal is known,

in which individual magnets hang on pistons, which can be moved in pneumatic or

hydraulic cylinders are guided. All cylinders are through compensating lines

connected to each other, so that the load capacity of the magnets is fully utilized and

even uneven plates can be held reliably. In an embodiment of the invention

it is proposed to use such compensating lines also for the holding members,

which are designed as suction cups and supported by individual pistons in cylinders.

This solves the task, even sensitive loads gently and reliably

to grab and hold. In a known manner, you can do this between the suction cups

and the associated piston ball joints are installed.

Die Trageinrichtung paÃt sich auf diese Weise auch unregelmÃ¤Ãigen

OberflÃ¤chen rasch an, alle Saugteller tragen in gleicher Weise, und Beanspruchungen

der Last werden vermieden. Die Benutzung der Einrichtung ist dann besonders wertvoll,

wenn wegen der GrÃ¶Ãe oder der Schwere der Last mehr als drei Saugteller angewendet

werden. Eine Justierung der einzelnen Saugteller entsprechend der OberflÃ¤chengestalt

der Last wÃ¼rde einen erheblichen Arbeitsaufwand bedeuten, der auf Grund der Erfindung

wegfÃ¤llt. Da alle Druckmittelzylinder untereinander mit Ausgleichsleitungen verbunden

sind, tritt bei allen Saugtellern der gleiche AnpreÃdruck auf.In this way, the support device also fits irregularly

Surfaces come on quickly, all suction pads wear and tear in the same way

the load are avoided. The use of the facility is then particularly valuable,

if more than three suction pads are used due to the size or weight of the load

will. An adjustment of the individual suction pads according to the surface shape

the load would mean a considerable amount of work due to the invention

ceases to exist. Since all pressure cylinders are connected to one another with compensating lines

the same contact pressure occurs with all suction pads.

Es ist schlieÃlich bekannt, einen oder mehrere Sauger kleinerer Abmessung

gegenÃ¼ber eigentlichen

Tragsaugern grÃ¶Ãerer Abmessung derart versetzt

anzuordnen, daÃ beim Heranfahren an den zu hebenden Gegenstand dieser zunÃ¤chst durch

die vorstehenden Sauger kleinerer Abmessung berÃ¼hrt wird. Dabei hat der vorstehende

kleine Sauger die Aufgabe, den Gegenstand zunÃ¤chst an den groÃen-. SaugerÂ«

anzudrÃ¼cken oder, besser gesagt, den groÃen Sauger an den Gegenstand heranzusaugen.

Nach dem bekannten Vorschlag liegen die kleinen Hilfssauger vorzugsweise innerhalb

der groÃen Tragsauger. Die Beaufschlagung mit Unterdruck wird dabei in jedem Sauger

gesondert durch BerÃ¼hrungsventile Ã¼berwacht, eine gegenseitige oder gemeinsame Beeinflussung

ist nicht vorgesehen.Finally, it is known to arrange one or more suction cups of smaller size offset from the actual carrying suction cups of larger size in such a way that when the object to be lifted is approached, it is initially touched by the protruding suction cups of smaller size. The above small suction cup has the task of first attaching the object to the large -. Suction cup Â« or, better said, sucking the large suction cup close to the object. According to the known proposal, the small auxiliary suction cups are preferably located within the large suction cups. The application of negative pressure is monitored separately in each suction cup by touch valves; mutual or joint influencing is not provided.

Die Erfindung wird im folgenden an Hand von AusfÃ¼hrungsbeispielen

nÃ¤her erlÃ¤utert, die in der Zeichnung dargestellt sind. Es zeigt A b b. 1 einen

Mittelschnitt durch einen Saugteller, A b b. 2 einen Mittelschnitt durch einen zentral

angeordneten, als Taster wirkenden Saugkopf, A b b. 3 eine erfindungsgemÃ¤Ã ausgebildete

Lasttrageinrichtung schematisch.The invention is described below on the basis of exemplary embodiments

explained in more detail, which are shown in the drawing. It shows A b b. 1 one

Central section through a suction cup, A b b. 2 a middle section through a central one

arranged suction head acting as a button, A b b. 3 one designed according to the invention

Load carrying device schematically.

Ein Traggestell 1 mit mehreren Saugtellern 2 kann an einem Kranfahrzeug

od. dgl. aufgehÃ¤ngt werden. Jeder Saugteller 2 ist mittels eines Kugelgelenks 4

an einer Kolbenstange befestigt, der zugehÃ¶rige Kolben 5 ist in einem Zylinder 6

gefÃ¼hrt. Alle Zylinder 6 sind an ihrer einen Seite mittels Druckmittelleitungen

7 untereinander verbunden, die andere Zylinderseite ist jeweils durch eine Bohrung

8 entlÃ¼ftet, wie A b b. 1 zeigt. Mittels eines nicht dargestellten GerÃ¤tes sind

die Druckmittelleitungen 7 mit der Ã¼brigen Druckmittelanlage des Kranfahrzeugs verbunden.

Die Saugteller 2 sind mittels Leitungen 10 unter Einschaltung eines SteuergerÃ¤tes

an eine Unterdruckquelle anzuschlieÃen. AuÃerdem kÃ¶nnen die mit einer Dichtung 31

versehenen Saugteller 2 mit einem Sperrventil ausgerÃ¼stet sein, das den AnschluÃ

an die Unterdruckquelle erst dann freigibt, wenn der Saugteller 2 voll an der LastoberflÃ¤che

anliegt.A support frame 1 with several suction plates 2 can be attached to a crane vehicle

or the like. Each suction cup 2 is connected by means of a ball joint 4

attached to a piston rod, the associated piston 5 is in a cylinder 6

guided. All cylinders 6 are on one side by means of pressure medium lines

7 connected to each other, the other cylinder side is each through a hole

8 vented as A b b. 1 shows. By means of a device, not shown, are

the pressure medium lines 7 are connected to the rest of the pressure medium system of the crane vehicle.

The suction cups 2 are connected to a control device by means of lines 10

to be connected to a vacuum source. In addition, those with a seal 31

provided suction cup 2 be equipped with a shut-off valve, the connection

releases to the vacuum source only when the suction cup 2 is fully on the load surface

is present.

Nach A b b. 2 und 3 ist an dem Traggestell 1 in zentraler Lage ein

Taster 12 angeordnet, der in seiner Ausgangsstellung gegenÃ¼ber den Saugtellern 2

in Richtung zur Last um ein MaÃ vorsteht, das als Ãberstand oder Verschiebeweg 11

zu bezeichnen ist. Der Taster 12 ist ein vorstehender Teil eines Steuerkolbens 13,

der in einem Zylinder 14 verschiebbar ist und durch eine Feder 15 in seine

Ausgangsstellung gedrÃ¼ckt wird. Der Steuerkolben 13 wird von einem AnschluÃ 16 aus

mit Unterdruck beaufschlagt und steuert seinerseits die Beaufschlagung der Saugteller

2 mit Unterdruck. Hierzu dienen Bohrungen 17 und eine Ringnut 18, die nach Ãberwindung

des Verschiebeweges 11 in Verbindung mit Bohrungen 19 in der Wand des Zylinders

14 kommt. Von den Bohrungen 19. fÃ¼hren Leitungen 20 zu den Leitungen

10

der Saugteller 2.According to A b b. 2 and 3, a button 12 is arranged in a central position on the support frame 1, which in its starting position protrudes in the direction of the load in relation to the suction plates 2 by an amount which is to be referred to as projection or displacement path 11. The button 12 is a protruding part of a control piston 13 which is displaceable in a cylinder 14 and is pressed into its starting position by a spring 15. The control piston 13 is subjected to negative pressure from a connection 16 and in turn controls the application of negative pressure to the suction plate 2. Bores 17 and an annular groove 18, which, after overcoming the displacement path 11, come into connection with bores 19 in the wall of the cylinder 14, are used for this purpose. Lines 20 lead from the bores 19 to the lines 10 of the suction plates 2.

Der Taster 12 ist selbst mit einem Saugkopf 21 mit Dichtung

30 ausgestattet, der durch eine Bohrung 22

mit Unterdruck beaufschlagt

wird. Im Zylinderinneren 23 des Zylinders 14 befindet sich ein kleinerer Hilfszylinder

24, in dem ein Kolben 25 mit Kolbenstange 28 eingepaÃt ist. Der Hilfszylinder

24 weist oben eine EntlÃ¼ftungsÃ¶ffnung 26 auf, die andere Zylinderseite ist

durch Bohrungen 27 mit dem Zylinderinneren 23 des Zylinders 14 verbunden, steht

also im Betrieb auch unter Unterdruck. Das Ende der Kolbenstange 28 des Hilfszylinders

24 ist als Ventilkegel ausgebildet und vermag die Bohrung -22 zu .verschlieÃen,

wenn der Unterdruck ausreicht, um @ die Kraft einer am Kolben 25 angreifenden Feder

29 im Hilfszylinder 24 zu Ã¼berwinden.The button 12 is itself equipped with a suction head 21 with a seal 30 , which is subjected to negative pressure through a bore 22. In the cylinder interior 23 of the cylinder 14 there is a smaller auxiliary cylinder 24 in which a piston 25 with piston rod 28 is fitted. The auxiliary cylinder 24 has a ventilation opening 26 at the top, the other cylinder side is connected to the cylinder interior 23 of the cylinder 14 through bores 27, so it is also under negative pressure during operation. The end of the piston rod 28 of the auxiliary cylinder 24 is designed as a valve cone and is able to close the bore -22 when the vacuum is sufficient to overcome the force of a spring 29 in the auxiliary cylinder 24 acting on the piston 25.

Die Einrichtung, deren Gesamtanordnung A b b. 3 zeigt, erfÃ¼llt die

Bedingung, daÃ alle Saugteller 2 gleichzeitig zum Haften kommen sollen, und arbeitet

folgendermaÃen: Beim HeranfÃ¼hren des Traggestells 1 an die Last durch den KranfÃ¼hrer

kommt auf Grund des Ã¼berstands oder Verschiebeweges 11 der Taster 12 zuerst zur

Anlage auf der OberflÃ¤che der Last. Durch Ãffnen eines nicht eingezeichneten Sperrventils

erhÃ¤lt der Saugkopf 21 Ã¼ber den AnschluÃ 16 und die Bohrung 22 Unterdruck. Er saugt

sich an der Last fest, und der steigende Unterdruck Ã¼berwindet die Kraft der Feder

15, so daÃ das Traggestell 1 mit den Saugtellern 2 mittels des Zylinders 14 an die

Last herangesaugt wird. Wenn sich der Verschiebeweg 11 bis auf Null verringert hat,

liegen alle Saugteller 2 an der Last an, wobei fÃ¼r die Zeichnung eine ebene OberflÃ¤che

der Last angenommen ist. Die Sperrventile der Saugteller 2 sind geÃ¶ffnet, und die

Saugteller 2 werden Ã¼ber die Bohrungen 17 und 19 und die Leitungen 20 und 10 von

dem zentralen Zylinder 14 aus mit Unterdruck beaufschlagt.The facility, the overall arrangement of which A b b. 3 shows meets the

Condition that all suction cups 2 should come to stick at the same time, and work

as follows: When the crane operator brings the support frame 1 up to the load

comes due to the protrusion or displacement 11 of the button 12 first

Plant on the surface of the load. By opening a non-illustrated shut-off valve

the suction head 21 receives via the connection 16 and the bore 22 negative pressure. He sucks

hold on to the load and the increasing negative pressure overcomes the force of the spring

15, so that the support frame 1 with the suction plates 2 by means of the cylinder 14 to the

Load is sucked in. When the displacement 11 has reduced to zero,

all suction cups 2 rest against the load, with a flat surface for the drawing

the load is accepted. The shut-off valves of the suction cup 2 are open, and the

Suction plate 2 are through the holes 17 and 19 and the lines 20 and 10 of

the central cylinder 14 is acted upon with negative pressure.

Wenn der Unterdruck an allen Saugtellern 2 und im Zylinderinneren

23 das gewÃ¼nschte HÃ¶chstmaÃ erreicht hat, so Ã¼berwindet der Kolben 25 die Kraft

der Feder 29 und drÃ¼ckt den Ventilkegel der Kolbenstange 28 auf den Sitz der Bohrung

22. Das bedeutet, daÃ nach dem Erreichen des hÃ¶chsten Vakuums in den Saugtellern

2 der zentrale Saugkopf 21 des Tasters 12 abgeschaltet wird.If the negative pressure on all suction pads 2 and inside the cylinder

23 has reached the desired maximum level, the piston 25 overcomes the force

the spring 29 and presses the valve cone of the piston rod 28 onto the seat of the bore

22. This means that after reaching the highest vacuum in the suction cups

2 the central suction head 21 of the button 12 is switched off.

Man kann daher die Dichtung 30 des Saugkopfes 21 aus hÃ¤rterem, widerstandsfÃ¤higerem

Werkstoff wÃ¤hlen als die verhÃ¤ltnismÃ¤Ãig empfindlichen Dichtungen 31 der Saugteller

z. Beim HeranfÃ¼hren der Trageinrichtung an die Last sind seitliche Bewegungen kaum

zu vermeiden, der eintretende VerschleiÃ betrifft dann nur die widerstandsfÃ¤hige

Dichtung 30 des zentralen Saugkopfes 21. Da hier das Vakuum nach dem endgÃ¼ltigen

Aufsetzen der Saugteller 2 abgeschaltet wird, kann man beim Saugkopf 21 gewisse

Undichtigkeiten in Kauf nehmen. Nach dem Erfassen der Last durch alle Saugteller

2, die weiche Dichtungen 31 haben, wird die verhÃ¤ltnismÃ¤Ãig undichte Zone des zentralen

Saugkopfes 21 abgeschaltet. Dadurch wird ein wirtschaftlicher Betrieb erreicht,

die Last wird zuverlÃ¤ssig gehalten, und der VerschleiÃ der Dichtungen

30,31 wird gegenÃ¼ber dem Ã¼blichen Betrieb verringert.You can therefore choose the seal 30 of the suction head 21 made of harder, more resistant material than the relatively sensitive seals 31 of the suction cup z. Lateral movements can hardly be avoided when the carrying device is brought up to the load, the wear that occurs then only affects the resistant seal 30 of the central suction head 21 accept. After the load has been detected by all the suction cups 2, which have soft seals 31, the relatively leaky zone of the central suction head 21 is switched off. As a result, economical operation is achieved, the load is reliably held, and the wear on the seals 30 , 31 is reduced compared to normal operation.

Die AusrÃ¼stung des zentralen Saugkopfes 21 mit der Feder

15 im Zylinder 14 hat noch folgenden Vorteil: Nach dem Absetzen der Last

und dem Ausschalten des Vakuums durch den KranfÃ¼hrer wird das Traggestell 1 mit

den Saugtellern 2 durch die Feder 15 von der Last abgedrÃ¼ckt. Dieser Vorgang kann

vom KranfÃ¼hrer eindeutig beobachtet werden, so daÃ erkennbar ist, wann die Trageinrichtung

leer verfahren werden kann. Beim Fehlen dieser Vorrichtung kommt es dagegen vor,

daÃ sich die Saugteller 2 nicht von der Last lÃ¶sen, diese in ungewollter Weise nochmals

ausheben und dann fallen lassen. Auch kann es geschehen, daÃ die Saugteller 2 durch

BetÃ¤tigen der Trageinrichtung gewaltsam von der Last gelÃ¶st werden, ehe das Vakuum

ausreichend abgebaut ist. Dabei, treten BeschÃ¤digungen der empfindlichen

Dichtungen

31 der Saugteller 2 ein. Auch diese MÃ¤ngel werden gemÃ¤Ã der Erfindung vermieden.Equipping the central suction head 21 with the spring 15 in the cylinder 14 has the following advantage: After the load has been set down and the vacuum is switched off by the crane operator, the support frame 1 with the suction plates 2 is pressed off the load by the spring 15. This process can be clearly observed by the crane operator so that it can be seen when the carrying device can be moved empty. In the absence of this device, on the other hand, it happens that the suction cups 2 do not detach from the load, unintentionally lift them out again and then let them fall. It can also happen that the suction cups 2 are forcibly released from the load by actuating the carrying device before the vacuum is sufficiently reduced. In the process, the sensitive seals 31 of the suction cups 2 are damaged. These deficiencies are also avoided according to the invention.

Es ist noch zu erwÃ¤hnen, daÃ ein Aufsetzen der Dichtungen 31 der Saugteller

2 ohne Gleitbewegung besonders wichtig ist, wenn es sich um Lasten mit rauher OberflÃ¤che

handelt, z. B. Betonplatten. Es ist fÃ¼r den KranfÃ¼hrer wesentlich leichter, den

vorstehenden zentralen Saugkopf 21 mit dem Taster 12 zur Anlage an der Last zu bringen,

als ohne diese Einrichtung die gleichmÃ¤Ãige Anlage aller Saugteller 2 zu erreichen.

Wenn die Trageinrichtung am Ausleger mittels eines DrehgerÃ¤tes aufgehÃ¤ngt ist, das

eine Drehung der Trageinrichtung um eine lotrechte Achse ermÃ¶glicht, so ist vorgesehen,

ein solches hydraulisches GerÃ¤t zeitweise kurzzuschlieÃen, um die Anlage der Trageinrichtung

an der Last mittels der Saugteller 2 unter geringstem Kraftaufwand zu erreichen.It should also be mentioned that a fitting of the seals 31 of the suction cup

2 without sliding movement is particularly important when dealing with loads with a rough surface

acts, e.g. B. Concrete slabs. It is much easier for the crane operator to

bring the protruding central suction head 21 to the load with the button 12,

than to achieve the uniform system of all suction cups 2 without this device.

When the support device is suspended on the boom by means of a rotating device that

enables rotation of the support device around a vertical axis, it is provided that

to temporarily short-circuit such a hydraulic device to the system of the support device

to achieve on the load by means of the suction plate 2 with minimal effort.

Die Wirkungsweise der Druckausgleicheinrichtung ist folgende: Die

unteren Zylinderseiten der Zylinder 6 sind mit Druckmittel gefÃ¼llt, Ãnderungen der

Druckmittelmenge werden mittels des frÃ¼her erwÃ¤hnten, nicht dargestellten GerÃ¤tes

vorgenommen. Wird die Trageinrichtung nun auf eine Last aufgesetzt, so weicht der

Saugteller 2 etwas zurÃ¼ck, der die Last, abgesehen vom zentralen Saugkopf 21, zuerst

berÃ¼hrt. In diesen Zylinder 6 wird daher Druckmittel aus den benachbarten Zylindern

6 gesaugt, wodurch deren Kolben 5 mit den Saugtellern 2 nach unten gehen, bis sie

ebenfalls Anlage an der OberflÃ¤che der Last finden. Dadurch kommen alle Saugteller

2 gleichmÃ¤Ãig zum Tragen.The mode of operation of the pressure compensation device is as follows: The

lower cylinder sides of the cylinder 6 are filled with pressure medium, changes in the

The amount of pressure medium is determined by means of the device, not shown, mentioned earlier

performed. If the support device is now placed on a load, then the

Suction plate 2 slightly back, which the load, apart from the central suction head 21, first

touched. In this cylinder 6 is therefore pressure medium from the adjacent cylinders

6 sucked, whereby the piston 5 with the suction cups 2 go down until they

also find contact with the surface of the load. This will bring all the suction pads

2 evenly to wear.

Durch den geschilderten Niveauausgleich der Saugteller 2, ihre automatische

Anpressung und Einschaltung durch den Taster 12 und durch das AbdrÃ¼cken der Last

nach Ausschalten des Vakuums wird eine wesentliche Erleichterung der Bedienung derartiger

Trageinrichtungen erreicht.Due to the described level compensation of the suction pads 2, their automatic

Contact pressure and activation by the button 12 and by pushing the load

after switching off the vacuum, the operation of this type is made much easier

Support devices reached.

## Classifications

- B66C1/0256
- B66C1/02
- B66C1/0293

## Cited patent documents

- [AT-174715-B](https://patents.google.com/patent/AT174715B/en) — SEA
- [DE-1126099-B](https://patents.google.com/patent/DE1126099B/en) — UNKNOWN
- [DE-1850562-U](https://patents.google.com/patent/DE1850562U/en) — SEA
- [FR-1108408-A](https://patents.google.com/patent/FR1108408A/en) — SEA
- [US-1801305-A](https://patents.google.com/patent/US1801305A/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
