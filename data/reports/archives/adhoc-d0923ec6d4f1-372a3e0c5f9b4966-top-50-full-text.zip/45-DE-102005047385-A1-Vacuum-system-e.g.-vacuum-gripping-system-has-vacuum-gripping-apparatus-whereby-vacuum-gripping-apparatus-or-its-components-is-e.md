# 45. Vacuum system e.g. vacuum gripping system has vacuum gripping apparatus whereby vacuum gripping apparatus or its components is equipped with energy generation device for generating electrical energy for operating sensors and transmitter

- **Archive rank:** 45 of 50
- **Publication:** [DE-102005047385-A1](https://patents.google.com/patent/DE102005047385A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/037852776/publication/DE102005047385A1?q=pn%3DDE102005047385A1)
- **Publication date:** 2007-04-05
- **Filing date:** 2005-09-28
- **Earliest priority:** 2005-09-28
- **Family:** 37852776
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** SCHMALZ J GMBH
- **Inventors:** EISELE THOMAS; SCHAAF WALTER

## Abstract

Vacuum system has a vacuum gripping apparatus for gripping workpieces (14) or a vacuum component. Vacuum gripping apparatus and one of the components is equipped with an energy generation device (22) for generating electrical energy for operating a sensor (24) and a transmitter (26) for transmission of the status data to the receiver (36).

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-102005047385-A1/pdf000.png)

![Sketch 1 for DE-102005047385-A1](https://nimo.iptorch.com/refdrawing/DE-102005047385-A1/pdf000.png)

## Claims

### Claim 1 (independent)

Unterdrucksystem, insbesondere Unterdruckgreifsystem (10) mit wenigstens einer Unterdruckgreifvorrichtung zum Greifen von Werkstücken (14) und/oder einer Unterdruckkomponente, mit einem Sensor (24) zum Erfassen von Zuständen im Unterdrucksystem, insbesondere Unterdruckgreifsystem (10) und/oder einem der Komponenten, und zum Erzeugen von Zustandsdaten, und mit einer Einrichtung zum Übermitteln der Zustandsdaten an einen Empfänger (36), dadurch gekennzeichnet, dass die Unterdruckgreifvorrichtung und/oder wenigstens eine der Komponenten mit einer Energieerzeugungseinrichtung (22) zum Erzeugen elektrischer Energie zum Betreiben des Sensors (24) und eines Senders (26) für die Übermittlung der Zustandsdaten an den Empfänger (36) bestückt ist.Vacuum system, in particular vacuum gripping system ( 10 ) with at least one vacuum gripping device for gripping workpieces ( 14 ) and / or a negative pressure component, with a sensor ( 24 ) for detecting conditions in the vacuum system, in particular vacuum gripping system ( 10 ) and / or one of the components, and for generating status data, and with a device for transmitting the status data to a receiver ( 36 ), characterized in that the vacuum gripping device and / or at least one of the components with a power generating device ( 22 ) for generating electrical energy for operating the sensor ( 24 ) and a sender ( 26 ) for the transmission of status data to the recipient ( 36 ) is equipped.

### Claim 2

Unterdrucksystem nach Anspruch 1, dadurch gekennzeichnet, dass die Unterdruckgreifvorrichtung ein Sauggreifer (12), ein Unterdruckspannsystem oder eine andere, ein Werkstück (14) mittels Unterdruck direkt oder indirekt festhaltende Vorrichtung ist.Vacuum system according to claim 1, characterized in that the vacuum gripping device is a suction gripper ( 12 ), a vacuum clamping system or another, a workpiece ( 14 ) is by means of negative pressure directly or indirectly detaining device.

### Claim 3

Unterdrucksystem nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass die Komponente ein Ejektor, ein Ventil, ein Datenspeicher, ein Sauger oder eine Anzeige ist.Vacuum system according to one of the preceding claims, characterized characterized in that the component is an ejector, a valve, a Data storage, a sucker or a display is.

### Claim 4

Unterdrucksystem nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass die Energieerzeugungseinrichtung (22) ein piezoelektrisches Element, ein Thermopaar, ein Schwingungswandler oder eine photovoltaische Zelle ist.Vacuum system according to one of the preceding claims, characterized in that the energy generating device ( 22 ) is a piezoelectric element, a thermocouple, a vibration transducer or a photovoltaic cell.

### Claim 5

Unterdrucksystem nach Anspruch 4, dadurch gekennzeichnet, dass das piezoelektrische Element in oder an einem Abschnitt angeordnet ist, der mechanisch bewegt wird.Vacuum system according to claim 4, characterized that the piezoelectric element is arranged in or on a portion is that is moved mechanically.

### Claim 6

Unterdrucksystem nach Anspruch 5, dadurch gekennzeichnet, dass der Abschnitt beim Ergreifen des Werkstücks (14) verformt wird.Vacuum system according to claim 5, characterized in that the portion when gripping the workpiece ( 14 ) is deformed.

### Claim 7

Unterdrucksystem nach Anspruch 5 oder 6, dadurch gekennzeichnet, dass der Abschnitt ein Tastventil ist, welches beim Aufsetzen auf das Werkstück (14) verlagert wird.Vacuum system according to claim 5 or 6, characterized in that the section is a touch valve which, when placed on the workpiece ( 14 ) is relocated.

### Claim 8

Unterdrucksystem nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass der Sensor (24) ein Unterdrucksensor, ein Strömungssensor, ein Luftmengensensor, ein Zähler, ein Bewegungssensor, ein Temperatursensor oder ein Kraftsensor ist.Vacuum system according to one of the preceding claims, characterized in that the sensor ( 24 ) is a negative pressure sensor, a flow sensor, an air flow sensor, a counter, a motion sensor, a temperature sensor or a force sensor.

### Claim 9

Unterdrucksystem nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass der Sender (26) ein Funksender, ein Infrarotsender oder ein Ultraschallsender ist.Vacuum system according to one of the preceding claims, characterized in that the transmitter ( 26 ) is a radio transmitter, an infrared transmitter or an ultrasonic transmitter.

### Claim 10

Unterdrucksystem nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass eine Abblaseinrichtung vorgesehen ist und dass an der Abblaseinrichtung eine die Blasluft nutzende Energiequelle, z.B. eine Turbine, vorgesehen ist.Vacuum system according to one of the preceding claims, characterized characterized in that a blow-off device is provided and that at the blowing device, an air source using the blast air, e.g. a turbine is provided.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippersDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippers control arrangements

Description

Translated from German

Die

Erfindung betrifft ein Unterdrucksystem, insbesondere ein Unterdruckgreifsystem,

mit wenigstens einer Unterdruckgreifvorrichtung zum Greifen von

WerkstÃ¼cken

und/oder mit einer Unterdruckkomponente, mit einem Sensor zum Erfassen

von ZustÃ¤nden

im Unterdrucksystem, insbesondere im Unterdruckgreifsystem und/oder

einem der Komponenten, und zum Erzeugen von Zustandsdaten, und mit einer

Einrichtung zum Ãbermitteln

der Zustandsdaten an einen EmpfÃ¤nger.The

The invention relates to a vacuum system, in particular a vacuum gripping system,

with at least one vacuum gripping device for gripping

workpieces

and / or with a negative pressure component, with a sensor for detecting

of states

in the vacuum system, in particular in the vacuum gripping system and / or

one of the components, and for generating state data, and with a

Device for transmission

the status data to a receiver.

Unterdrucksysteme

werden zum Erzeugen von Unterdruck und zum Handhaben von GegenstÃ¤nden verwendet.

Eine Vorrichtung zum Erzeugen von Unterdruck ist zum Beispiel ein

Ejektor, welcher mit Druckluft betrieben wird und an welchen Unterdruckverbraucher

angeschlossen sind. Ein derartiger Unterdruckverbraucher ist zum

Beispiel ein Sauggreifer, welcher Bestandteil eines Unterdruckgreifsystems

ist und mit welchem ein Gegenstand angesaugt wird, sodass er angehoben

und an einen anderen Ort transportiert werden kann. Es sind jedoch auch

Greifsysteme bekannt, welche zum Festhalten von WerkstÃ¼cken verwendet

werden, sodass die WerkstÃ¼cke

bearbeitet werden kÃ¶nnen.

Die einzelnen Unterdruckgreifvorrichtungen und die mit diesen zusammenarbeitenden

Komponenten unterliegen einem VerschleiÃ und mÃ¼ssen daraufhin Ã¼berwacht werden,

ob sie Leckagen aufweisen und/oder noch korrekt arbeiten. Eventuell

ist es auch erforderlich, dass einzelne Zustandsdaten dieser Bauteile,

zum Beispiel ein herrschender Unterdruck, fÃ¼r den weiteren Arbeitsablauf

bekannt sein mÃ¼ssen.

So kann zum Beispiel ein angesaugtes WerkstÃ¼ck erst dann angehoben werden,

wenn der Unterdruck am Sauggreifer einen vorgegebenen Wert erreicht

hat.Vacuum systems

are used for generating negative pressure and for handling objects.

An apparatus for generating negative pressure is, for example, a

Ejector, which is operated with compressed air and to which vacuum consumers

are connected. Such a vacuum consumer is for

Example a suction gripper, which is part of a vacuum gripping system

is and with which an object is sucked, so that he raised

and can be transported to another location. There are, however

Gripping systems known which used for holding workpieces

so that the workpieces

can be edited.

The individual vacuum gripping devices and cooperating with them

Components are subject to wear and must be monitored

whether they have leaks and / or are still working correctly. Perhaps

It is also necessary that individual status data of these components,

For example, a prevailing negative pressure, for the rest of the workflow

must be known.

For example, a sucked workpiece can not be lifted until

when the vacuum on the suction pad reaches a predetermined value

Has.

HierfÃ¼r sind Sensoren

vorgesehen, die die ZustÃ¤nde

erfassen und in Zustandsdaten umwandeln, wobei die Zustandsdaten

dann Ã¼ber

Kabel an einen EmpfÃ¤nger Ã¼bermittelt

werden. Ferner sind Kabel erforderlich, um die Sensoren mit elektrischer

Energie zu versorgen was aber dazu fÃ¼hrt, dass der Verkabelungsaufwand

immens ist. Es mÃ¼ssen

nicht nur die Druckluft- und Unterdruckleitungen verlegt werden,

sondern auch die Kabel fÃ¼r die

Energieversorgung sowie die Kabel fÃ¼r die DatenÃ¼bermittlung.For this are sensors

provided the conditions

capture and convert into state data, with the state data

then over

Cable to a receiver

become. Furthermore, cables are required to connect the sensors with electrical

Energy supply but this leads to the cabling effort

is immense. To have to

not only the compressed air and vacuum lines are laid,

but also the cables for the

Power supply and cables for data transmission.

Der

Erfindung liegt somit die Aufgabe zugrunde, ein Unterdrucksystem

bereit zu stellen, welches einfacher aufgebaut ist.Of the

Invention is therefore the object of a vacuum system

to provide, which is simpler.

Diese

Aufgabe wird erfindungsgemÃ¤Ã dadurch

gelÃ¶st,

dass die Unterdruckgreifvorrichtung und/oder wenigstens eine der

Komponenten mit einer Energieerzeugungseinrichtung zum Erzeugen elektrischer

Energie zum Betreiben eines Senders fÃ¼r die Ãbermittlung der Zustandsdaten

an den EmpfÃ¤nger

bestÃ¼ckt

ist.These

Task is inventively characterized

solved,

that the vacuum gripping device and / or at least one of

Components with an energy generating device for generating electrical

Energy for operating a transmitter for the transmission of status data

to the recipient

stocked

is.

ErfindungsgemÃ¤Ã muss die

zum Erfassen der ZustÃ¤nde,

zum Erzeugen der Zustandsdaten und zum Ãbermitteln der Zustandsdaten

benÃ¶tigte

elektrische Energie nicht mehr Ã¼ber

Kabel dem Unterdrucksystem zugefÃ¼hrt

werden, da die Unterdruckgreifvorrichtung und/oder wenigstens eine

der verwendeten Komponenten mit einer Energieerzeugungseinrichtung

versehen ist, sodass die benÃ¶tigte

elektrische Energie vor Ort erzeugt wird. Des weiteren bedarf es keiner

Verkabelung zur Ãbermittlung

der Zustandsdaten an einen auÃerhalb

des Unterdrucksystems liegenden EmpfÃ¤nger, da diese Zustandsdaten

mittels eines Senders an diesen drahtlos Ã¼bermittelt werden. Somit entfÃ¤llt die

komplette Verkabelung des Systems, sodass lediglich noch die Luftleitungen

verlegt werden mÃ¼ssen.

Hierdurch reduziert sich der bauliche Aufwand wesentlich und Reparaturen

und Wartungsarbeiten kÃ¶nnen

schneller und einfacher durchgefÃ¼hrt

werden. Auch das Gewicht des Systems wird verringert und die BaugrÃ¶Ãe reduziert.According to the invention must

for detecting the states,

for generating the state data and for transmitting the state data

needed

electrical energy is not over

Cable fed to the vacuum system

be because the vacuum gripping device and / or at least one

the components used with a power generating device

is provided so the needed

electrical energy is generated on site. Furthermore, there is no need

Cabling for transmission

the state data to an outside

the negative pressure system lying receiver because this state data

by means of a transmitter to this wirelessly transmitted. Thus eliminates the

complete wiring of the system, so that only the air lines

have to be relocated.

This significantly reduces the construction effort and repairs

and maintenance can

faster and easier

become. Also, the weight of the system is reduced and the size reduced.

Bei

einer Weiterbildung ist vorgesehen, dass die Unterdruckgreifvorrichtung

ein Sauggreifer, ein Unterdruckspannsystem oder eine andere, ein

WerkstÃ¼ck

mittels Unterdruck direkt oder indirekt festhaltende Vorrichtung

ist. Mit Sauggreifern werden GegenstÃ¤nde angesaugt, sodass sie abgehoben

und an einen anderen Ort bewegt werden kÃ¶nnen. Mittels den Unterdruckspannsystemen

kÃ¶nnen

Bauteile festgehalten werden, sodass sie anschlieÃend bearbeitet

werden kÃ¶nnen.

Diese Bauteile kÃ¶nnen

mit der Energieerzeugungseinrichtung bestÃ¼ckt sein, sodass deren Zustandsdaten,

zum Beispiel Schaltzyklen, anliegender Unterdruck, LuftstrÃ¶mungsmenge

und dergleichen erfasst und diese Zustandsdaten entweder am Bauteil

abgespeichert und/oder an einen externen EmpfÃ¤nger Ã¼bermittelt werden. Zur Speicherung der

Daten kann zum Beispiel ein RFID-Bauteil verwendet werden, welches

an geeigneter Stelle am Sauggreifer oder am Unterdruckspannsystem

befestigt ist. Somit geht die Nutzungshistorie des Bauteils nicht

verloren und kann jederzeit abgerufen werden.at

a development is provided that the vacuum gripping device

a suction pad, a vacuum clamping system or another, a

workpiece

by means of negative pressure directly or indirectly detaining device

is. With suction pads objects are sucked in, so they lifted off

and be moved to another location. By means of vacuum clamping systems

can

Components are held so that they subsequently processed

can be.

These components can

be equipped with the energy generating device, so that their state data,

For example, switching cycles, applied negative pressure, air flow rate

and the like, and this status data is acquired either on the component

stored and / or transmitted to an external receiver. To save the

Data can be used, for example, an RFID component, which

at a suitable place on the suction pad or on the vacuum clamping system

is attached. Thus, the usage history of the component does not work

lost and can be retrieved at any time.

Bei

einer Weiterbildung ist vorgesehen, dass die Komponente ein Ejektor,

ein Ventil, ein Datenspeicher, ein Sauger oder eine Anzeige ist.

Auch bei diesen Komponenten, wobei die obige AufzÃ¤hlung lediglich

beispielhaft sein soll, ist eine Energieerzeugungseinrichtung vorgesehen,

die die Energie fÃ¼r

die Sensoren fÃ¼r

die Erfassung der einzelnen Zustandsdaten liefert, wobei auch hier

die Daten direkt vor Ort an einen Datenspeicher Ã¼bermittelt und abgespeichert

und/oder an externe EmpfÃ¤nger Ã¼bermittelt werden.

Die Energie zur Abspeicherung und zur Ãbermittlung wird ebenfalls

von der Energieerzeugungseinrichtung bereit gestellt. Im Ã¼brigen sei

darauf hingewiesen, dass auch Energiespeicher vorhanden sein kÃ¶nnen, sodass

kleine Energiemengen akkumuliert werden kÃ¶nnen.In a further development, it is provided that the component is an ejector, a valve, a data memory, a sucker or a display. Even with these components, the above enumeration is merely intended to be exemplary, an energy generating device is provided which provides the energy for the sensors for the detection of the individual state data, in which case the data transmitted and stored directly to a data storage and / or to external recipients. The energy to store and to Transmission is also provided by the power generation facility. Moreover, it should be noted that energy storage can be present so that small amounts of energy can be accumulated.

Bei

einem bevorzugten AusfÃ¼hrungsbeispiel ist

die Energieerzeugungseinrichtung ein piezoelektrisches Element.

Es ist aber auch denkbar, dass Thermopaare, Schwingungswandler oder

photovoltaische Zellen verwendet werden. Insbesondere bei der Handhabung

von GegenstÃ¤nden

werden die einzelnen Bauteile mechanisch beansprucht, wobei diese

mechanische Bewegungen von den piezoelektrischen Elementen in elektrische

Energie umgewandelt werden kÃ¶nnen,

sodass diese elektrische Energie fÃ¼r die Sensoren und Sender sowie

Speicher bereitgestellt werden kann. Dabei ist das piezoelektrische

Element bevorzugt in oder an einem Abschnitt angeordnet, der mechanisch

bewegt wird, z.B. an einem Kolben oder einer Zylinderwand oder an

einem Tastventil, welches beim Aufsetzen auf ein WerkstÃ¼ck in den

Sauger eingeschoben wird. Der Abschnitt kann zum Beispiel beim Greifen

des WerkstÃ¼cks

auch verformt werden. Diese Verformungsenergie bewirkt die Verformung

des piezoelektrischen Elements, welches die mechanische in elektrische Energie

umwandelt.at

a preferred embodiment

the power generation device is a piezoelectric element.

But it is also conceivable that thermocouples, vibration transducer or

Photovoltaic cells are used. Especially when handling

of objects

The individual components are mechanically stressed, these

mechanical movements of the piezoelectric elements into electrical

Energy can be converted

so that this electrical energy for the sensors and transmitters as well

Memory can be provided. This is the piezoelectric

Element preferably arranged in or on a portion of the mechanical

is moved, e.g. on a piston or cylinder wall or on

a Tastventil, which when placed on a workpiece in the

Sucker is inserted. The section can, for example, when gripping

of the workpiece

also be deformed. This deformation energy causes the deformation

of the piezoelectric element, which converts the mechanical into electrical energy

transforms.

Mit

Vorzug ist der Sensor ein Unterdrucksensor, ein StrÃ¶mungssensor,

ein Luftmengensensor, eine ZÃ¤hler,

ein Bewegungssensor, ein Temperatursensor oder ein Kraftsensor.

Auf diese Weise kÃ¶nnen die

unterschiedlichsten ZustÃ¤nde

ermittelt und entsprechende Daten erzeugt werden. So kann zum Beispiel

die VerschleiÃgrenze

eines Sauggreifers erkannt werden, bevor dieser ausfÃ¤llt. AuÃerdem kann erkannt

werden, wenn ein Gegenstand nicht korrekt angesaugt oder gegriffen

wurde, wodurch UnfÃ¤lle vermieden

werden kÃ¶nnen.

Auf jeden Fall erfolgt sowohl die Zustandserfassung als auch die Ãbermittlung

der Zustandsdaten kabellos.With

Preference is the sensor is a vacuum sensor, a flow sensor,

an air flow sensor, a counter,

a motion sensor, a temperature sensor or a force sensor.

In this way, the

different states

determined and corresponding data are generated. So can for example

the wear limit

a suction gripper are detected before it fails. In addition, can be detected

when an item is not properly sucked or gripped

was avoided, which avoids accidents

can be.

In any case, both the state detection and the transmission takes place

the status data wirelessly.

Dabei

kann der Sender erfindungsgemÃ¤Ã ein Funksender,

ein Infrarotsender oder ein Ultraschallsender sein. Die Daten kÃ¶nnen verschlÃ¼sselt oder unverschlÃ¼sselt und

zusammen mit bauteilabhÃ¤ngigen

Herkunftsmerkmalen kombiniert werden. Auf diese Weise kann jederzeit

festgestellt werden, an welchem Ort die Daten zu welcher Zeit erzeugt

wurden.there

the transmitter can according to the invention a radio transmitter,

an infrared transmitter or an ultrasonic transmitter. The data can be encrypted or unencrypted and

together with component-dependent

Origin characteristics are combined. This way can be anytime

determine where the data is generated at what time

were.

Weitere

Vorteile, Merkmale und Einzelheiten der Erfindung ergeben sich aus

den UnteransprÃ¼chen

und der nachfolgenden Beschreibung, in der unter Bezugnahem auf

die Zeichnung zwei besonders bevorzugte AusfÃ¼hrungsbeispiele im Einzelnen beschrieben

sind. Dabei kÃ¶nnen

die in der Zeichnung dargestellten sowie in den AnsprÃ¼chen und

in der Beschreibung erwÃ¤hnten

Merkmale jeweils einzeln fÃ¼r sich

oder in beliebiger Kombination erfindungswesentlich sein.Further

Advantages, features and details of the invention will become apparent

the dependent claims

and the description below, in reference to

the drawing two particularly preferred embodiments described in detail

are. It can

those shown in the drawing and in the claims and

mentioned in the description

Features individually for themselves

or be essential to the invention in any combination.

In

der Zeichnung zeigen:In

show the drawing:

1 eine

Prinzipskizze von Sauggreifern mit extern angeordneter Speichereinheit; 1 a schematic diagram of suction pads with externally arranged storage unit;

2 ein

Verfahrensschema beim Ansaugen und Abheben eines Gegenstands; und 2 a process scheme when sucking and lifting an object; and

3 einen

Sauggreifer mit integrierter Speichereinheit. 3 a suction pad with integrated storage unit.

Die 1 zeigt

ein insgesamt mit 10 bezeichnetes Unterdruckgreifsystem

mit drei Sauggreifern 12 mit denen WerkstÃ¼cke 14 angesaugt

werden kÃ¶nnen.

Die Sauggreifer 12 sind mittels einer Unterdruckleitung 16 mit

einer Unterdruckversorgungseinrichtung 18, zum Beispiel

einer Unterdruckpumpe oder einem Ejektor verbunden. AuÃerdem ist

erkennbar, dass eine externe Speichereinheit 20 vorgesehen

ist. Dabei stellt der Ejektor selbst eine Unterdruckkomponente dar.The 1 shows a total of 10 designated vacuum gripping system with three suction pads 12 with which workpieces 14 can be sucked. The suction pads 12 are by means of a vacuum line 16 with a vacuum supply device 18 , For example, a vacuum pump or an ejector connected. It can also be seen that an external storage unit 20 is provided. In this case, the ejector itself is a negative pressure component.

In

die einzelnen Sauggreifer 12 ist jeweils eine Energieerzeugungseinrichtung 22,

ein sogenannter Energiewandler, und ein Sensor 24 integriert.

Dieser Sensor 24 erfasst ZustÃ¤nde des Sauggreifers 12,

zum Beispiel den im Sauggreifer 12 herrschenden Unterdruck

oder die Anzahl der Lastzyklen, erzeugt Zustandsdaten und sendet

diese Ã¼ber

einen Sender 26 an die Speichereinheit 20. Die

zum Betreiben des Sensors 24 und Betreiben des Senders 26 erforderliche

elektrische Energie wird von der Energieerzeugungseinrichtung 22,

welche zum Beispiel ein piezoelektrisches Element, eine photovoltaische

Zelle oder eine Thermopaar ist, erzeugt.Into the individual suction pads 12 each is an energy generating device 22 , a so-called energy converter, and a sensor 24 integrated. This sensor 24 detects states of the suction pad 12 , for example, in the suction pad 12 prevailing negative pressure or the number of load cycles, generates status data and sends them via a transmitter 26 to the storage unit 20 , The for operating the sensor 24 and operating the transmitter 26 required electrical energy is supplied by the power generating device 22 which is, for example, a piezoelectric element, a photovoltaic cell or a thermocouple.

Die 2 zeigt

ein AusfÃ¼hrungsbeispiel

eines Verfahrensablaufs beim Handhaben eines WerkstÃ¼cks 14,

bei dem der Sauggreifer 12 zunÃ¤chst in Richtung des Pfeils 28 auf

das WerkstÃ¼ck 14 abgesenkt

wird, bis der Sauggreifer 12 auf dem WerkstÃ¼ck 14 aufsitzt.

Dabei wird der Sauggreifer 12 verformt, wobei die mechanische

Verformungsenergie von der Energieerzeugungseinrichtung 22 in

elektrische Energie umgewandelt wird. Dadurch wird der Sender 26 aktiviert,

und sendet ein Aktivierungssignal an den in der Speichereinheit 20 sitzenden

EmpfÃ¤nger,

was mit dem Pfeil 30 angedeutet ist.The 2 shows an embodiment of a method sequence when handling a workpiece 14 in which the suction pad 12 first in the direction of the arrow 28 on the workpiece 14 is lowered until the suction pad 12 on the workpiece 14 seated. This is the suction pad 12 deformed, wherein the mechanical deformation energy from the power generation device 22 is converted into electrical energy. This will be the sender 26 and sends an activation signal to the one in the memory unit 20 seated receiver, what with the arrow 30 is indicated.

Sodann

wird die Unterdruckversorgungseinrichtung 18 in Gang gesetzt

und die Unterdruckleitung 16 mit Unterdruck versorgt. Das

WerkstÃ¼ck 14 wird

angesaugt. Nach Erreichen des erforderlichen Saugdrucks, was mit

dem Sensor 24 ermittelt wird, wird ein weiteres Signal

abgegeben was bedeutet, dass der Gegenstand 14 nunmehr

angehoben (Pfeil 32) werden kann, da der im Sauggreifer 12 herrschende

Unterdruck ausreichend groÃ ist.

Sinkt der Unterdruck wÃ¤hrenddessen

im Sauggreifer 12 ab, wird dies vom Sensor 24 ebenfalls

erkannt, sodass ein weiteres Signal abgesandt werden kann. Hat der Unterdruck

seinen erforderlichen Wert erreicht, kann die Unterdruckversorgungseinrichtung 18 abgeschaltet

oder die Unterdruckleitung 16 abgesperrt werden.Then, the negative pressure supply device 18 set in motion and the vacuum line 16 supplied with negative pressure. The workpiece 14 is sucked. After reaching the required suction pressure, what with the sensor 24 is detected, another signal is emitted which means that the object 14 now raised (arrow 32 ), because of the suction pad 12 prevailing negative pressure is sufficiently large. In the meantime the negative pressure sinks in the suction gripper 12 This is done by the sensor 24 also recognized so that another signal can be sent. If the negative pressure has reached its required value, the vacuum supply device 18 switched off or the vacuum line 16 be shut off.

Nach

dem Aufsetzen des WerkstÃ¼cks 14, was

wiederum vom Sensor 24 registriert wird, wird die Unterdruckleitung 16 belÃ¼ftet, sodass

der Sauggreifer 12 vom Gegenstand 14 in Richtung

des Pfeils 34 abgehoben werden kann.After placing the workpiece 14 , which in turn is from the sensor 24 is registered, the vacuum line 16 vented so that the suction pads 12 from the object 14 in the direction of the arrow 34 can be lifted.

Das

erfindungsgemÃ¤Ãe Unterdrucksystem benÃ¶tigt keine

elektrischen Leitungen zur Energieversorgung des Sensors 24 und

des Senders 26, und es Bedarf lediglich der Unterdruckversorgung

des Sauggreifers 12.The negative pressure system according to the invention requires no electrical lines for powering the sensor 24 and the sender 26 , And it only needs the vacuum supply of the suction pad 12 ,

In

der 3 ist ein AusfÃ¼hrungsbeispiel

eines Sauggreifers 12 dargestellt, bei dem die Speichereinheit 20 in

den Sauggreifer 12, zum Beispiel in Form eines RFID-tags

integriert ist. Dieser Sauggreifer 12 sendet ebenfalls

Daten (Pfeil 30) an einen externen EmpfÃ¤nger 36, jedoch wird

in der internen Speichereinheit 20 die Nutzungshistorie

abgespeichert, die auch spÃ¤ter

ausgelesen werden kann. Neben der Nutzungshistorie kÃ¶nnen auch

Identifikationsnummern, Herstellungsdatum, Hersteller, Materialkennungen

usw. abgespeichert sein. Auf diese Weise kÃ¶nnen RÃ¼ckschlÃ¼sse auf Falschbedienungen,

fehlerhafte Herstellung usw. geschlossen werden.In the 3 is an embodiment of a suction pad 12 shown in which the storage unit 20 in the suction pad 12 , for example, is integrated in the form of an RFID tag. This suction pad 12 also sends data (arrow 30 ) to an external receiver 36 However, in the internal memory unit 20 stored the usage history, which can also be read later. In addition to the usage history, identification numbers, date of manufacture, manufacturer, material identifiers etc. can also be stored. In this way, conclusions about wrong operations, incorrect production, etc. can be closed.

## Classifications

- B65G47/917
- B65G47/91

## Cited patent documents

- [DE-10140248-A1](https://patents.google.com/patent/DE10140248A1/en) — SEA
- [DE-19748374-C1](https://patents.google.com/patent/DE19748374C1/en) — SEA
- [DE-20206267-U1](https://patents.google.com/patent/DE20206267U1/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
