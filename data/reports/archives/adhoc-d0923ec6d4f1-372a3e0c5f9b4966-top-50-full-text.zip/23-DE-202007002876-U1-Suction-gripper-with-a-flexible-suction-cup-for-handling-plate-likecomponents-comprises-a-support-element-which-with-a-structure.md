# 23. Suction gripper with a flexible suction cup for handling plate-likecomponents comprises a support element which with a structure letting through air is carried by a cup end section

- **Archive rank:** 23 of 50
- **Publication:** [DE-202007002876-U1](https://patents.google.com/patent/DE202007002876U1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/038038392/publication/DE202007002876U1?q=pn%3DDE202007002876U1)
- **Publication date:** 2007-04-26
- **Filing date:** 2007-02-27
- **Earliest priority:** 2007-02-27
- **Family:** 38038392
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** FESTO AG & CO

## Abstract

The suction gripper with a flexible suction cup (5) for handling components (22) comprises a support element (25) which with a structure letting through air is carried by an end section (7) of the cup. An independent claim is also included for a support element for the proposed suction gripper.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-202007002876-U1/pdf000.png)

![Sketch 1 for DE-202007002876-U1](https://nimo.iptorch.com/refdrawing/DE-202007002876-U1/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-202007002876-U1/pdf001.png)

![Sketch 2 for DE-202007002876-U1](https://nimo.iptorch.com/refdrawing/DE-202007002876-U1/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/DE-202007002876-U1/pdf002.png)

![Sketch 3 for DE-202007002876-U1](https://nimo.iptorch.com/refdrawing/DE-202007002876-U1/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/DE-202007002876-U1/pdf003.png)

![Sketch 4 for DE-202007002876-U1](https://nimo.iptorch.com/refdrawing/DE-202007002876-U1/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/DE-202007002876-U1/pdf004.png)

![Sketch 5 for DE-202007002876-U1](https://nimo.iptorch.com/refdrawing/DE-202007002876-U1/pdf004.png)

## Claims

### Claim 1 (independent)

Sauggreifer zur Handhabung von Gegenständen, mit einem flexiblen Saugnapf (5), der einen an eine Unterdruckquelle anschließbaren Saugraum (8) begrenzt und der einen rückseitigen Endabschnitt (6) sowie einen eine Saugöffnung (12) umgrenzenden, unter Veränderung der Saugnapflänge im Rahmen einer Hubbewegung (15) relativ zu dem rückseitigen Endabschnitt (6) bewegbaren vorderen Endabschnitt (7) aufweist, wobei in dem Saugraum (8) im Bereich der Saugöffnung (12) ein Abstützelement (25) für den zu ergreifenden Gegenstand (22) angeordnet ist, dadurch gekennzeichnet, dass das Abstützelement (25) vom vorderen Endabschnitt (7) des Saugnapfes (5) getragen ist, sodass es dessen Hubbewegung (15) mitmacht, wobei es eine luftdurchlässige Struktur aufweist.Suction gripper for handling objects, with a flexible suction cup ( 5 ), which can be connected to a vacuum source suction chamber ( 8th ) and a rear end portion ( 6 ) as well as a suction opening ( 12 ), while changing the Saugnapflänge in the context of a lifting movement ( 15 ) relative to the rear end portion (FIG. 6 ) movable front end portion ( 7 ), wherein in the suction chamber ( 8th ) in the region of the suction opening ( 12 ) a supporting element ( 25 ) for the object to be grasped ( 22 ), characterized in that the supporting element ( 25 ) from the front end portion ( 7 ) of the suction cup ( 5 ), so that its stroke movement ( 15 ), wherein it has an air-permeable structure.

### Claim 2

Sauggreifer nach Anspruch 1, dadurch gekennzeichnet, dass der rückseitige Endabschnitt (6) das Saugnapfes (5) von einem rückseitig in den Saugraum (8) einmündenden Absaugkanal (13) durchsetzt ist.Suction gripper according to claim 1, characterized in that the rear end portion ( 6 ) the suction cup ( 5 ) from a back into the suction chamber ( 8th ) opening suction channel ( 13 ) is interspersed.

### Claim 3

Sauggreifer nach Anspruch 1 oder 2, dadurch gekennzeichnet, dass das Abstützelement (25) axial gegenüberliegend der Mündung (14) des Absaugkanals (13) eine die Luftabsaugung durch das Abstützelement (25) hindurch begünstigende Aussparung (36) aufweist.Suction gripper according to claim 1 or 2, characterized in that the support element ( 25 ) axially opposite the mouth ( 14 ) of the suction channel ( 13 ) one the air extraction by the support element ( 25 ) favoring recess ( 36 ) having.

### Claim 4

Sauggreifer nach einem der Ansprüche 1 bis 3, dadurch gekennzeichnet, dass dem rückseitigen Endabschnitt (6) des Saugnapfes (5) ein diesbezüglich ortsfester, innerhalb des Saugraumes (8) im Hubweg des Abstützelementes (15) angeordneter Hubbegrenzungsanschlag (35) für das Abstützelement (15) zugeordnet ist.Suction gripper according to one of claims 1 to 3, characterized in that the rear end portion ( 6 ) of the suction cup ( 5 ) a fixed in this regard, within the suction chamber ( 8th ) in the stroke of the support element ( 15 ) arranged Hubbegrenzungsanschlag ( 35 ) for the supporting element ( 15 ) assigned.

### Claim 5

Sauggreifer nach einem der Ansprüche 1 bis 4, dadurch gekennzeichnet, dass der rückseitige Endabschnitt (6) des Saugnapfes (5) an einem die Befestigung des Sauggreifers ermöglichenden Halter (3) angeordnet ist.Suction gripper according to one of claims 1 to 4, characterized in that the rear end portion ( 6 ) of the suction cup ( 5 ) on a holder enabling the attachment of the suction pad ( 3 ) is arranged.

### Claim 6

Sauggreifer nach Anspruch 5, dadurch gekennzeichnet, dass der Halter (3) einen Hubbegrenzungsanschlag (35) für das Abstützelement (15) bildet oder trägt.Suction gripper according to claim 5, characterized in that the holder ( 3 ) a stroke limit stop ( 35 ) for the supporting element ( 15 ) forms or carries.

### Claim 7

Sauggreifer nach einem der Ansprüche 1 bis 6, dadurch gekennzeichnet, dass das Abstützelement (25) an der Innenumfangsfläche des Saugnapfes (5) fixiert ist.Suction gripper according to one of claims 1 to 6, characterized in that the support element ( 25 ) on the inner peripheral surface of the suction cup ( 5 ) is fixed.

### Claim 8

Sauggreifer nach Anspruch 7, dadurch gekennzeichnet, dass das Abstützelement (25) ausschließlich an der Innenumfangsfläche des Saugnapfes (5) fixiert istSuction gripper according to claim 7, characterized in that the supporting element ( 25 ) exclusively on the inner peripheral surface of the suction cup ( 5 ) is fixed

### Claim 9

Sauggreifer nach einem der Ansprüche 1 bis 8, dadurch gekennzeichnet, dass das Abstützelement (25) stoffschlüssig mit dem Saugnapf (5) verbunden ist.Suction gripper according to one of claims 1 to 8, characterized in that the supporting element ( 25 ) cohesively with the suction cup ( 5 ) connected is.

### Claim 10

Sauggreifer nach Anspruch 9, dadurch gekennzeichnet, dass das Abstützelement (25) mit dem Saugnapf (5) verklebt ist.Suction gripper according to claim 9, characterized in that the supporting element ( 25 ) with the suction cup ( 5 ) is glued.

### Claim 11

Sauggreifer nach Anspruch 9, dadurch gekennzeichnet, dass der Saugnapf (5) an das Abstützelement (25) durch Spritzgießen angeformt ist.Suction gripper according to claim 9, characterized in that the suction cup ( 5 ) to the support element ( 25 ) is molded by injection molding.

### Claim 12

Sauggreifer nach einem der Ansprüche 1 bis 8, dadurch gekennzeichnet, dass das Abstützelement (25) an dem Saugnapf (5) formschlüssig fixiert ist.Suction gripper according to one of claims 1 to 8, characterized in that the supporting element ( 25 ) on the suction cup ( 5 ) is positively fixed.

### Claim 13

Sauggreifer nach Anspruch 12, dadurch gekennzeichnet, dass das Abstützelement (25) durch sich ausschließlich im Innern des Saugraumes (8) getroffene Maßnahmen formschlüssig an dem Saugnapf (5) fixiert ist.Suction gripper according to claim 12, characterized in that the support element ( 25 ) by itself only in the interior of the suction chamber ( 8th ) Measures taken on the suction cup ( 5 ) is fixed.

### Claim 14

Sauggreifer nach Anspruch 12 oder 13, dadurch gekennzeichnet, dass das Abstützelement (25) mit dem Saugnapf (5) verrastet ist.Suction gripper according to claim 12 or 13, characterized in that the supporting element ( 25 ) with the suction cup ( 5 ) is locked.

### Claim 15

Sauggreifer nach einem der Ansprüche 12 bis 14, dadurch gekennzeichnet, dass das Abstützelement (25) lösbar an dem Saugnapf (5) fixiert ist.Suction gripper according to one of claims 12 to 14, characterized in that the support element ( 25 ) releasably attached to the suction cup ( 5 ) is fixed.

### Claim 16

Sauggreifer nach einem der Ansprüche 1 bis 15, dadurch gekennzeichnet, dass der Saugnapf (5) faltenbalgartig strukturiert ist.Suction gripper according to one of claims 1 to 15, characterized in that the suction cup ( 5 ) is structured like a bellows.

### Claim 17

Sauggreifer nach Anspruch 16, dadurch gekennzeichnet, dass das Abstützelement (25) formschlüssig an der dem Saugraum (8) zugewandten Innenfaltung (16a) des vorderen Endabschnittes (7) des Saugnapfes (5) fixiert ist.Suction gripper according to claim 16, characterized in that the support element ( 25 ) in a form-fitting manner at the suction space ( 8th ) facing inner fold ( 16a ) of the front end portion ( 7 ) of the suction cup ( 5 ) is fixed.

### Claim 18

Sauggreifer nach Anspruch 18, dadurch gekennzeichnet, dass das Abstützelement (25) ausschließlich an der Innenfaltung (16a) fixiert istSuction gripper according to claim 18, characterized in that the supporting element ( 25 ) exclusively on the inner fold ( 16a ) is fixed

### Claim 19

Sauggreifer nach Anspruch 17 oder 18, dadurch gekennzeichnet, dass das Abstützelement (25) in mindestens einer am Innenumfang des vorderen Endabschnittes (7) des Saugnapfes (5) vorhandenen Innenfalte (16) des Saugnapfes (5) gehalten ist.Suction gripper according to claim 17 or 18, characterized in that the support element ( 25 ) in at least one at the inner periphery of the front end portion ( 7 ) of the suction cup ( 5 ) existing inner fold ( 16 ) of the suction cup ( 5 ) is held.

### Claim 20

Sauggreifer nach Anspruch 19, dadurch gekennzeichnet, dass das Abstützelement (25) ausschließlich in einer einzigen am Innenumfang des vorderen Endabschnittes (7) des Saugnapfes (5) vorhandenen Innenfalte (16) formschlüssig gehalten ist.Suction gripper according to claim 19, characterized in that the supporting element ( 25 ) exclusively in a single on the inner periphery of the front end portion ( 7 ) of the suction cup ( 5 ) existing inner fold ( 16 ) is held positively.

### Claim 21

Sauggreifer nach Anspruch 17 oder 18, dadurch gekennzeichnet, dass das Abstützelement (25) am Übergangsbereich zweier axial aufeinanderfolgender Innenfalten (16) gehalten ist.Suction gripper according to claim 17 or 18, characterized in that the support element ( 25 ) at the transition region of two axially consecutive inner folds ( 16 ) is held.

### Claim 22

Sauggreifer nach einem der Ansprüche 16 bis 21, dadurch gekennzeichnet, dass das Abstützelement (25) in die Innenfaltung (16a) am Innenumfang des vorderen Endabschnittes (7) des Saugnapfes (5) lösbar eingeknöpft ist.Suction gripper according to one of claims 16 to 21, characterized in that the support element ( 25 ) into the inner fold ( 16a ) on the inner periphery of the front end portion ( 7 ) of the suction cup ( 5 ) is detachably buttoned.

### Claim 23

Sauggreifer nach einem der Ansprüche 1 bis 22, dadurch gekennzeichnet, dass das Abstützelement (25) zur Gänze im Innern des Saugraumes (8) aufgenommen ist.Suction gripper according to one of claims 1 to 22, characterized in that the supporting element ( 25 ) entirely inside the suction chamber ( 8th ) is recorded.

### Claim 24

Sauggreifer nach einem der Ansprüche 1 bis 23, dadurch gekennzeichnet, dass das Abstützelement (25) den kompletten Querschnitt des Saugraumes (8) ausfüllt, wobei es aus einem luftdurchlässigen Material besteht.Suction gripper according to one of claims 1 to 23, characterized in that the support element ( 25 ) the complete cross section of the suction chamber ( 8th ), wherein it consists of an air-permeable material.

### Claim 25

Sauggreifer nach Anspruch 24, dadurch gekennzeichnet, dass das Abstützelement (25) aus einem Sintermaterial besteht.Suction gripper according to claim 24, characterized in that the supporting element ( 25 ) consists of a sintered material.

### Claim 26

Sauggreifer nach Anspruch 25, dadurch gekennzeichnet, dass das Sintermaterial ein Polyethylen-Sintermaterial ist.Suction gripper according to claim 25, characterized the sintered material is a polyethylene sintered material.

### Claim 27

Sauggreifer nach einem der Ansprüche 24 bis 26, dadurch gekennzeichnet, dass das Abstützelement (25) aus einem fein-porösen Material besteht.Suction gripper according to one of claims 24 to 26, characterized in that the support element ( 25 ) consists of a fine-porous material.

### Claim 28

Sauggreifer nach Anspruch 24, dadurch gekennzeichnet, dass das Abstützelement (25) aus einem luftdurchlässigen Schaumstoff besteht.Suction gripper according to claim 24, characterized in that the supporting element ( 25 ) consists of an air-permeable foam.

### Claim 29

Sauggreifer nach einem der Ansprüche 1 bis 23, dadurch gekennzeichnet, dass das Abstützelement (25) aus luftundurchlässigem Material besteht, das von einer Mehrzahl von Luftdurchtrittskanälen (26) durchsetzt ist.Suction gripper according to one of claims 1 to 23, characterized in that the support element ( 25 ) consists of air-impermeable material, that of a plurality of air passageways ( 26 ) is interspersed.

### Claim 30

Sauggreifer nach einem der Ansprüche 1 bis 29, dadurch gekennzeichnet, dass der Saugnapf (5) an seinem vorderen Endabschnitt (7) eine umlaufende Dichtlippe (33) aufweist, die im radialen Umfangsbereich des Abstützelementes (25) mit dem anzusaugenden Gegenstand (22) in Kontakt treten kann.Suction gripper according to one of claims 1 to 29, characterized in that the suction cup ( 5 ) at its front end portion ( 7 ) a circumferential sealing lip ( 33 ), which in the radial peripheral region of the support element ( 25 ) with the object to be sucked on ( 22 ) can come into contact.

### Claim 31

Sauggreifer nach Anspruch 30, dadurch gekennzeichnet, dass die Dichtlippe (33) in der nicht an einen Gegenstand (22) angesetzten Grundstellung des Sauggreifers (1) über die stirnseitige Abstützfläche (34) des Abstützelementes (25) vorsteht.Suction gripper according to claim 30, characterized in that the sealing lip ( 33 ) in which not to an object ( 22 ) basic position of the suction pad ( 1 ) via the frontal support surface ( 34 ) of the supporting element ( 25 ) protrudes.

### Claim 32

Sauggreifer nach einem der Ansprüche 1 bis 31, dadurch gekennzeichnet, dass das Abstützelement (25) einen den gesamten Querschnitt des Saugraumes (8) überspannenden scheibenförmigen Basisabschnitt (37) aufweist, von dessen Rückseite ein einen im Vergleich zum Saugraum (8) geringeren Querschnitt aufweisender, zur Hubbegrenzung dienender Vorsprung (38) axial wegragt.Suction gripper according to one of claims 1 to 31, characterized in that the supporting element ( 25 ) one the entire cross section of the suction chamber ( 8th ) spanning disc-shaped base portion ( 37 ), from the back of a one in comparison to the suction chamber ( 8th ) having a smaller cross-section, serving to limit the stroke ( 38 ) protrudes axially.

### Claim 33

Sauggreifer nach Anspruch 32, dadurch gekennzeichnet, dass das Abstützelement über den scheibenförmigen Basisabschnitt (37) am vorderen Endabschnitt (7) des Saugnapfes (5) fixiert ist.Suction gripper according to claim 32, characterized in that the support element via the disc-shaped base portion ( 37 ) at the front end portion ( 7 ) of the suction cup ( 5 ) is fixed.

### Claim 34 (independent)

Abstützelement für einen zur Handhabung von Gegenständen dienenden Sauggreifer (1), ausgebildet zum Einsetzen in einen flexiblen Saugnapf (5) und zum Befestigen an dem bezüglich des rückseitigen Endabschnittes (6) des Saugnapfes (5) unter Ausführung einer linearen Hubbewegung (15) beweglichen vorderen Endabschnitt (7) des Saugnapfes (5), derart, dass das Abstützelement (25) die Hubbewegung (15) des vorderen Endabschnittes (7) mitmachen kann.Support element for a serving for handling objects suction pads ( 1 ) adapted for insertion into a flexible suction cup ( 5 ) and for fixing to the relative to the rear end portion ( 6 ) of the suction cup ( 5 ) under execution of a linear lifting movement ( 15 ) movable front end portion ( 7 ) of the suction cup ( 5 ), such that the support element ( 25 ) the lifting movement ( 15 ) of the front end portion ( 7 ) can join.

### Claim 35

Abstützelement nach Anspruch 34, dadurch gekennzeichnet, dass es eine luftdurchlässige Struktur aufweist.supporting according to claim 34, characterized in that it is an air-permeable structure having.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippers

Description

Translated from German

Die

Erfindung betrifft einen Sauggreifer zur Handhabung von GegenstÃ¤nden, mit

einem flexiblen Saugnapf, der einen an eine Unterdruckquelle anschlieÃbaren Saugraum

begrenzt und der einen einem Halter zugeordneten rÃ¼ckseitigen

Endabschnitt sowie einen eine SaugÃ¶ffnung umgrenzenden, unter VerÃ¤nderung

der SaugnapflÃ¤nge

im Rahmen einer Hubbewegung relativ zu dem rÃ¼ckseitigen Endabschnitt bewegbaren

vorderen Endabschnitt aufweist, wobei in dem Saugraum im Bereich

der SaugÃ¶ffnung

ein AbstÃ¼tzelement

fÃ¼r den

zu ergreifenden Gegenstand angeordnet ist.The

The invention relates to a suction gripper for handling objects, with

a flexible suction cup, which can be connected to a vacuum source suction chamber

limited and the one associated with a holder back

End portion and a suction opening delimiting, under change

the suction cup length

movable in the context of a lifting movement relative to the rear end portion

having front end portion, wherein in the suction chamber in the area

the suction opening

a support element

for the

is arranged to be gripped object.

Die

Erfindung betrifft ferner ein AbstÃ¼tzelement fÃ¼r einen zur Handhabung von

GegenstÃ¤nden dienenden

Sauggreifer.The

The invention further relates to a support element for a handling of

Serving objects

Suction pads.

Ein

aus der DE 10121344

A1 bekannter Sauggreifer dieser Art enthÃ¤lt einen

faltenbalgartig ausgebildeten Saugnapf, dessen rÃ¼ckseitiger Endabschnitt an

einem Halter fixiert ist, Ã¼ber

den er wunschgemÃ¤Ã bezÃ¼glich eines

handzuhabenden Gegenstandes positionierbar ist. Der vordere Endabschnitt

des Saugnapfes umgrenzt eine SaugÃ¶ffnung, mit der voraus der

Saugnapf an einen durch Unterdruck zu ergreifenden Gegenstand ansetzbar ist.

Die FlexibilitÃ¤t

des Saugnapfes ermÃ¶glicht

einen LÃ¤ngenausgleich,

bei dem der vordere Endabschnitt des Saugnapfes eine Hubbewegung

ausfÃ¼hren

kann. Ein im Bereich der SaugÃ¶ffnung

platziertes AbstÃ¼tzelement

verhindert zu starke Verfor mungen des anzusaugenden Gegenstandes,

was vor allem bei sehr dÃ¼nnen

und/oder sprÃ¶den

GegenstÃ¤nden

von Vorteil ist. Beim Ansaugen eines Gegenstandes schiebt dieser

das federbelastet an dem Halter gelagerte AbstÃ¼tzelement zurÃ¼ck, bis

eine motorisch betÃ¤tigbare Klemmvorrichtung

den Hub des AbstÃ¼tzelementes begrenzt.One from the DE 10121344 A1 known suction pads of this type includes a bellows-shaped suction cup, the rear end portion is fixed to a holder over which it is desired positionable with respect to a hand-held object. The front end portion of the suction cup defines a suction opening with which the suction cup can be attached to an object to be gripped by negative pressure. The flexibility of the suction cup allows a length compensation, in which the front end portion of the suction cup can perform a lifting movement. A placed in the suction opening support element prevents excessive defor mation of the object to be sucked, which is especially for very thin and / or brittle objects advantage. When sucking an object this pushes the spring-loaded on the holder mounted support element back to a motor-operated clamping device limits the stroke of the support element.

Der

bekannte Sauggreifer verfÃ¼gt Ã¼ber einen relativ

komplexen Aufbau und ist daher relativ teuer in der Herstellung.

Zudem ist eine aufwendige Ansteuerung erforderlich, um das AbstÃ¼tzelement

entsprechend der jeweiligen Betriebsphase festzusetzen oder freizugeben.

Nicht zuletzt kÃ¶nnen

bei der Handhabung sehr empfindlicher GegenstÃ¤nde Probleme auftreten, die

aus der Notwendigkeit resultieren, dass der Gegenstand die Vorspannung

der das AbstÃ¼tzelement

beaufschlagenden Feder Ã¼berwinden

muss, was bei zu starker Feder bei sprÃ¶den GegenstÃ¤nden unter UmstÃ¤nden sogar

eine ZerstÃ¶rung derselben

zur Folge haben kann.Of the

known suction pads has a relative

complex construction and is therefore relatively expensive to manufacture.

In addition, a complex control is required to the support element

set or release according to the respective operating phase.

Last but not least

When handling very delicate items, problems occur

result from the necessity that the object is the bias

the supporting element

overcome acting spring

must, what if too strong spring brittle objects may even

a destruction of the same

can result.

Bei

einem aus der DE

10 2004 014 635 A1 bekannten Sauggreifer befindet sich

innerhalb des Saugraumes ein fest mit dem rÃ¼ckseitigen Endabschnitt des

Saugnapfes verbundenes Druckkissen zum AbstÃ¼tzen des anzuhebenden Gegenstandes.

Dieses Druckkissen ist nicht fÃ¼r

ein ZurÃ¼ckweichen

ausgelegt, da es den Zweck hat, bewusst eine Durchbiegung des zu

ergreifenden Gegenstandes hervorzurufen, sodass sich dieser problemlos

von einem Gegenstandsstapel abheben lÃ¤sst. Ein solcher Sauggreifer

eignet sich im Wesentlichen nur zur Handhabung flexibler GegenstÃ¤nde, die

bei einer Biegebelastung keinen Schaden davontragen.At one of the DE 10 2004 014 635 A1 known suction pads is located within the suction chamber a fixedly connected to the rear end portion of the suction cup pressure pad for supporting the object to be lifted. This pressure pad is not designed for retreat, as it has the purpose of deliberately causing a deflection of the object to be grasped, so that it can easily be lifted off an item stack. Essentially, such a suction gripper is only suitable for handling flexible objects which do not suffer any damage during a bending load.

Aus

der DE 38 10 989 A1 ist

ein Sauggreifer mit einem tellerfÃ¶rmigen, flexiblen Saugnapf

bekannt. MaÃnahmen

zum Verhin dern des Durchbiegens handzuhabender GegenstÃ¤nde sind

hier nicht getroffen.From the DE 38 10 989 A1 is a suction pad with a plate-shaped, flexible suction cup known. Measures for preventing the bending of objects to be handled are not taken here.

SchlieÃlich beschreibt

die DE 20 2006

006 113 U1 eine Faltenbalganordnung, die als Bestandteil

eines federelastischen Saugnapfes verwendbar ist, beispielsweise

bei der Handhabung von GegenstÃ¤nden

in der Fertigungs- und Montagetechnik. Auch hier sind allerdings

zusÃ¤tzliche

AbstÃ¼tzmaÃnahmen

fÃ¼r die

handzuhabenden GegenstÃ¤nde

nicht beschrieben.Finally, that describes DE 20 2006 006 113 U1 a Faltenbalganordnung that is useful as part of a resilient suction cup, for example, in the handling of objects in manufacturing and assembly technology. Again, however, additional support measures for the objects to be handled are not described.

Es

ist die Aufgabe der vorliegenden Erfindung, einen Sauggreifer zu

schaffen, mit dem sich auch bruch- und/oder verformungsempfindliche

GegenstÃ¤nde

beschÃ¤digungsfrei

handhaben lassen.It

The object of the present invention is to provide a suction gripper

create, with which also fracture and / or deformation sensitive

objects

without damage

let handle.

Zur

LÃ¶sung

dieser Aufgabe ist in Verbindung mit den eingangs genannten Merkmalen

vorgesehen, dass das AbstÃ¼tzelement

vom vorderen Endabschnitt des Saugnapfes getragen ist, sodass es dessen

Hubbewegung mitmacht, wobei es eine luftdurchlÃ¤ssige Struktur aufweist.to

solution

This object is in connection with the features mentioned

provided that the support element

worn by the front end portion of the suction cup, so that it

Participates lifting movement, wherein it has an air-permeable structure.

Die

Erfindung wird ferner gelÃ¶st

durch ein AbstÃ¼tzelement

fÃ¼r einen

zur Handhabung von GegenstÃ¤nden

dienenden Sauggreifer, das zum Einsetzen in einen flexiblen Saugnapf

ausgebildet ist und sich zur Befestigung an dem bezÃ¼glich des

rÃ¼ckseitigen

Endabschnittes des Saugnapfes beweglichen vorderen Endabschnitt

des Saugnapfes eignet, derart, dass es im eingesetzten und befestigten

Zustand die Hubbewegung des vorderen Endabschnittes des Saugnapfes

mitmachen kann.The

Invention is also solved

by a support element

for one

for handling objects

Serving suction pads, for insertion into a flexible suction cup

is formed and attached to the respect to the

rear

End portion of the suction cup movable front end portion

the suction cup is suitable such that it is inserted and fastened

State the lifting movement of the front end portion of the suction cup

can join.

Das

AbstÃ¼tzelement

kann somit seine AbstÃ¼tzfunktion

unabhÃ¤ngig

vom Hub des die SaugÃ¶ffnung

definierenden vorderen Endabschnittes des Saugnapfes in gleichbleibender

QualitÃ¤t

erfÃ¼llen.

Es verhindert von Anfang an ein Ã¼bermÃ¤Ãiges Durchbiegen auch

sehr dÃ¼nnwandiger

angesaugter GegenstÃ¤nde,

wobei die AbstÃ¼tzung

von der jeweils eingenommenen Hubposition des vorderen Endabschnittes

des Saugnapfes unabhÃ¤ngig

ist. Da das AbstÃ¼tzelement

die Bewegung des es haltenden vorderen Endabschnittes des Saugnapfes

mitmacht, ist vom angesaugten Gegenstand zudem keine mit dem Hubweg

zunehmende Gegenkraft zu Ã¼berwinden, was

fÃ¼r gleichbleibende

VerhÃ¤ltnisse

sorgt. Der Sauggreifer eignet sich somit unter anderem besonders

fÃ¼r die

Handhabung dÃ¼nner

Folien und Papiere, ebenso fÃ¼r

die Handhabung labiler und sprÃ¶der, dÃ¼nnwandiger

WerkstÃ¼cke,

einschlieÃlich

sogenannter "Flat-Panels", wie sie in der

Fotovoltaik oder in der Bildschirmtechnologie verarbeitet werden.The support element can thus fulfill its support function independently of the stroke of the suction opening defining the front end portion of the suction cup in a consistent quality. It prevents from the beginning of excessive bending even very thin-walled sucked objects, the support of each occupied stroke position of the front end portion of the suction cup is independent. In addition, since the support element participates in the movement of the front end section of the suction cup which holds it, the object to be sucked in does not have to overcome any counterforce which increases with the stroke path. which ensures constant conditions. Among other things, the suction gripper is therefore particularly suitable for handling thin films and papers, as well as for handling labile and brittle, thin-walled workpieces, including so-called "flat panels", as they are processed in photovoltaics or in screen technology.

Vorteilhafte

Weiterbildungen der Erfindung gehen aus den UnteransprÃ¼chen hervor.advantageous

Further developments of the invention will become apparent from the dependent claims.

Um

den Hub des die SaugÃ¶ffnung

definierenden vorderen Endabschnittes des Saugnapfes zu begrenzen,

ist zweckmÃ¤Ãigerweise

ein bezÃ¼glich

des rÃ¼ckseitigen

Endabschnittes des Saugnapfes ortsfester Hubbegrenzungsanschlag

innerhalb des Saugraumes vorhanden, der im Hubweg des AbstÃ¼tzelementes

angeordnet ist und auf den das AbstÃ¼tzelement auflaufen kann.Around

the stroke of the suction opening

to limit the defining front end portion of the suction cup,

is expediently

a respect

of the back

End section of the suction cup fixed stroke limit stop

present within the suction chamber, in the stroke of the support element

is arranged and can accumulate on the support.

Das

AbstÃ¼tzelement

kann rÃ¼ckseitig

einen im Vergleich zum Saugraum einen geringeren Querschnitt aufweisenden

Vorsprung aufweisen, der mit dem Hubbegrenzungsanschlag kooperiert.The

supporting

can be backside

a lower cross section compared to the suction chamber

Have projection that cooperates with the Hubbegrenzungsanschlag.

Ist

der Saugnapf rÃ¼ckseitig

an einem Halter befestigt, kann der Halter unmittelbar selbst den

Hubbegrenzungsanschlag bilden.is

the suction cup on the back

attached to a holder, the holder can directly even the

Form stroke limit stop.

Die

Verbindung des Saugraumes mit einer Unterdruckquelle findet zweckmÃ¤Ãigerweise Ã¼ber einen

rÃ¼ckseitig

in den Saugraum einmÃ¼ndenden

Absaugkanal hinweg statt, der den rÃ¼ckseitigen Endabschnitt des

Saugnapfes, insbesondere in einem der Befestigung des Sauggreifers

dienenden Halter, durchsetzt.The

Connection of the suction chamber with a vacuum source expediently takes place via a

on the back

entering the suction chamber

Absaugkanal away, the rear end portion of the

Suction cup, especially in one of the attachment of the suction pad

serving holder, interspersed.

Damit

die Saugwirkung nicht beeintrÃ¤chtigt wird,

wenn das AbstÃ¼tzelement

an dem rÃ¼ckseitigen Endabschnitt

bzw. an dem Halter anliegt, verfÃ¼gt

das AbstÃ¼tzelement

axial gegenÃ¼berliegend

der MÃ¼ndung

des Absaugkanals zweckmÃ¤Ãigerweise Ã¼ber eine

Aussparung, die die Luftabsaugung begÃ¼nstigt.In order to

the suction effect is not impaired,

when the support element

at the rear end portion

or on the holder rests, has

the support element

axially opposite one another

the estuary

the suction duct expediently via a

Recess that favors the air extraction.

Das

AbstÃ¼tzelement

ist zweckmÃ¤Ãigerweise an

der dem Saugraum zugewandten InnenumfangsflÃ¤che des Saugnapfes fixiert.

Hierbei stehen mehrere BefestigungsmaÃnahmen zur Auswahl. Beispielsweise

ist eine stoffschlÃ¼ssige

Verbindung denkbar, zum Beispiel durch Verkleben oder VerschweiÃen von

AbstÃ¼tzelement

und Saugnapf. Das AbstÃ¼tzelement

kann bei der Herstellung des Saugnapfes auch unmittelbar von dem

den Saugnapf definierenden Material umspritzt werden, insbesondere

im Rahmen eines Zwei-Komponenten-SpritzgieÃverfahrens.The

supporting

is suitably on

fixed to the suction chamber facing inner peripheral surface of the suction cup.

Here are several attachment options to choose from. For example

is a cohesive one

Connection conceivable, for example by gluing or welding of

supporting

and suction cup. The support element

can in the manufacture of the suction cup also directly from the

the suction cup defining material are molded, in particular

as part of a two-component injection molding process.

Besonders

empfehlenswert ist eine formschlÃ¼ssige

Fixierung des AbstÃ¼tzelementes

im Saugnapf, insbesondere durch eine Rastverbindung. Vor allem in

diesem Zusammenhang erweist sich ein faltenbalgartig strukturierter

Saugnapf als besonders vorteilhaft, weil hier die am Innenumfang

vorhandene Innenfaltung zur Aufnahme des AbstÃ¼tzelementes herangezogen werden

kann. Beispielsweise kann das AbstÃ¼tzelement einfach eingeknÃ¶pft werden,

sodass auch im Falle von Verschmutzung oder BeschÃ¤digung ein

leichtes Entnehmen mÃ¶glich

ist.Especially

A form-fitting one is recommended

Fixation of the support element

in the suction cup, in particular by a latching connection. Especially in

In this context, a bellows-like structured proves

Suction cup as particularly advantageous because here on the inner circumference

existing inner fold are used for receiving the support element

can. For example, the support element can be easily buttoned,

so even in case of pollution or damage

easy removal possible

is.

Es

ist zweckmÃ¤Ãig, die

Anordnung so zu treffen, dass das montierte AbstÃ¼tzelement in seiner Gesamtheit

im Innern des Saugraumes aufgenommen ist.It

is appropriate, the

Arrangement to be made so that the assembled support element in its entirety

is received in the interior of the suction chamber.

Bevorzugt

beschrÃ¤nken

sich sÃ¤mtliche

BefestigungsmaÃnahmen

fÃ¼r das

AbstÃ¼tzelement

auf das Innere des Saugraumes, sodass es insbesondere nicht erforderlich

ist, das AbstÃ¼tzelement

im Bereich der SaugÃ¶ffnung

nach auÃen

um das Ende des Saugnapfes herumgreifen zu lassen. Die Funktion des

Saugnapfes, insbesondere seine Dichtfunktion gegenÃ¼ber einem

zu ergreifenden Gegenstand, wird somit nicht beeintrÃ¤chtigt.Prefers

restrict

all of them

fastening measures

for the

supporting

to the interior of the suction chamber, so it is not necessary in particular

is, the support element

in the area of the suction opening

outward

to grab around the end of the suction cup. The function of the

Suction cup, in particular its sealing function against a

object to be gripped is thus not impaired.

Als

besonders zweckmÃ¤Ãig wird

ein AbstÃ¼tzelement

angesehen, das den kompletten Querschnitt des Saugraumes ausfÃ¼llt, wobei

seine luftdurchlÃ¤ssige

Struktur aus der Herstellung aus einem luftdurchlÃ¤ssigen Material

resultiert. Empfehlenswert ist hierbei insbesondere ein fein-porÃ¶ses Sintermaterial, insbesondere

ein hochmolekulares Polyethylen-Sintermaterial. Denkbar wÃ¤re aber

auch eine Herstellung aus einem von Poren durchsetzten Schaumstoffmaterial.When

is particularly useful

a support element

viewed, which fills the entire cross section of the suction chamber, wherein

its air permeable

Structure made of an air-permeable material

results. In this case, in particular, a finely porous sintered material is recommended, in particular

a high molecular weight polyethylene sintered material. But it would be possible

also a preparation of a pores interspersed foam material.

Alternativ

kann das AbstÃ¼tzelement

auch aus einem kostengÃ¼nstigen

luftundurchlÃ¤ssigen

Material bestehen, beispielsweise ein starres Kunststoffmaterial,

das zum Erhalt der LuftdurchlÃ¤ssigkeit

von einer Mehrzahl von Ã¼ber

den Querschnitt des AbstÃ¼tzelementes

verteilten LuftdurchtrittskanÃ¤len

durchsetzt ist. Die LuftdurchtrittskanÃ¤le kÃ¶nnen hier prinzipiell jede

beliebige Querschnittsform aufweisen, beispielsweise kreisrund oder

auch polygonfÃ¶rmig.alternative

can the support element

also from a cost-effective

impermeable

Material consist, for example, a rigid plastic material,

that to maintain the air permeability

from a plurality of over

the cross section of the support element

distributed air passageways

is interspersed. The air passageways can here in principle any

have any cross-sectional shape, for example, circular or

also polygonal.

Einer

optimalen Ansaugwirkung fÃ¶rderlich

ist eine Ausstattung des Saugnapfes mit einer umlaufenden Dichtlippe

an seinem vorderen Endabschnitt. Diese Dichtlippe kann in der Grundstellung,

bei noch nicht angesetztem Gegenstand, Ã¼ber die stirnseitige AbstÃ¼tzflÃ¤che des

AbstÃ¼tzelementes

geringfÃ¼gig

vorstehen. Da das AbstÃ¼tzelement

ein Ã¼bermÃ¤Ãiges Einsaugen

des angesaugten Gegenstandes ins Innere des Saugraumes verhindert, Ã¤ndert sich

auch beim Ansaugen eines Gegenstandes die Relativlage zwischen Dichtlippe

und AbstÃ¼tzelement

nur wenig, sodass der Kontakt zwischen Dichtlippe und Gegenstand

eine nur geringe IntensitÃ¤t

aufweist, was dazu beitrÃ¤gt,

SaugnapfabdrÃ¼cke

auf dem Gegenstand zu minimieren.one

optimal intake effect conducive

is an equipment of the suction cup with a circumferential sealing lip

at its front end portion. This sealing lip can in the basic position,

at not yet attached object, on the frontal support surface of the

support element

slight

protrude. As the support element

an excessive sucking

prevents the sucked object into the interior of the suction chamber, changes

also when sucking an object, the relative position between the sealing lip

and support element

only a little so that the contact between the sealing lip and the object

a low intensity

which contributes to

pad marks

to minimize on the object.

Nachfolgend

wird die Erfindung anhand der beiliegenden Zeichnung nÃ¤her erlÃ¤utert. In

dieser zeigen:following

The invention will be explained in more detail with reference to the accompanying drawings. In

show this:

1 eine

bevorzugte erste AusfÃ¼hrungsform

des erfindungsgemÃ¤Ãen Sauggreifers

im LÃ¤ngsschnitt

in einer Grundstellung bei noch nicht angesaugtem Gegenstand, 1 a preferred first embodiment of the suction gripper according to the invention in longitudinal section in a basic position with not yet sucked object,

2 den

Sauggreifer aus 1 in einer Arbeitsstellung bei

angesaugtem Gegenstand, 2 the suction pad 1 in a working position with sucked object,

3 eine

Unteransicht des Sauggreifes aus 1 mit Blickrichtung

gemÃ¤Ã Pfeil

III, 3 a bottom view of the suction pad 1 looking in the direction of arrow III,

4 und 5 ein

weiteres AusfÃ¼hrungsbeispiel

eines Sauggreifers im LÃ¤ngsschnitt,

wiederum zum einen in einer Grundstellung (4) und zum

anderen in einer Arbeitsstellung (5), und 4 and 5 a further embodiment of a suction gripper in longitudinal section, in turn, on the one hand in a basic position ( 4 ) and on the other hand in a working position ( 5 ), and

6 und 7 Unteransichten

zweier weiterer AusfÃ¼hrungsbeispiele

eines Sauggreifers mit Blickrichtung entsprechend Pfeil III aus 1,

wobei unterschiedlich strukturierte AbstÃ¼tzelemente sichtbar sind. 6 and 7 Bottom views of two further embodiments of a suction pad with viewing direction according to arrow III 1 , wherein differently structured support elements are visible.

Der

insgesamt mit Bezugsziffer 1 bezeichnete Sauggreifer verfÃ¼gt Ã¼ber eine

lÃ¤ngliche

Gestalt mit einer LÃ¤ngsachse 2.

RÃ¼ckseitig

ist er zweckmÃ¤Ãigerweise

mit einem Halter 3 belie biger Art ausgestattet, Ã¼ber den

er an einer nur in 1 und 4 schematisch

angedeuteten Handhabungsvorrichtung 4 festlegbar ist, insbesondere

in lÃ¶sbarer

Weise. Durch die Handhabungsvorrichtung 4 lÃ¤sst sich

der Sauggreifer 1 bewegen und positionieren, entsprechend

dem jeweiligen Einsatzzweck. Die Handhabungsvorrichtung 4 ist

insbesondere von maschineller Art und kann einen oder mehrere elektrische

und/oder fluidische Antriebe enthalten.The total with reference number 1 designated suction pads has an elongated shape with a longitudinal axis 2 , On the back side, it is expediently with a holder 3 equipped of any kind, over which he has only one in 1 and 4 schematically indicated handling device 4 can be fixed, in particular in a detachable manner. By the handling device 4 can be the suction pad 1 move and position, according to the respective purpose. The handling device 4 is in particular of a mechanical nature and may contain one or more electrical and / or fluidic drives.

Der

Sauggreifer 1 enthÃ¤lt

einen flexiblen Saugnapf 5, der mit seinem rÃ¼ckwÃ¤rtigen Endabschnitt

an dem Halter 3 befestigt ist. Bevorzugt verfÃ¼gt der Saugnapf 5 Ã¼ber gummielastische

Eigenschaften, wobei er insbesondere aus einem Elastomermaterial

besteht.The suction pad 1 contains a flexible suction cup 5 , with its rear end portion on the holder 3 is attached. Preferably, the suction cup has 5 about rubbery properties, in which it consists in particular of an elastomeric material.

Der

Halter 3 besteht beispielsweise aus Metall, wobei der Saugnapf 5 bei

seiner Herstellung aus Kunststoffmaterial mit seinem rÃ¼ckseitigen

Endabschnitt 6 durch SpritzgieÃen an den Halter 3 stoffschlÃ¼ssig angeformt

worden sein kann.The holder 3 consists for example of metal, the suction cup 5 in its manufacture of plastic material with its rear end portion 6 by injection molding to the holder 3 may have been integrally formed.

Der

Saugnapf 5 ist ein HohlkÃ¶rper und erstreckt sich ausgehend

von seinem rÃ¼ckseitigen

Endabschnitt 6 koaxial zu der LÃ¤ngsachse 2 bis hin

zu einer Vorderseite, wo er mit einem vorderen Endabschnitt 7 endet.The sucker 5 is a hollow body and extends from its rear end portion 6 coaxial with the longitudinal axis 2 all the way to a front where he has a front end section 7 ends.

Der

Saugnapf 5 umgrenzt einen Saugraum 8. Dieser ist

an der Vorderseite des Saugnapfes 5 Ã¼ber eine SaugÃ¶ffnung 12 hinweg

zur Umgebung hin offen.The sucker 5 defines a suction space 8th , This is on the front of the suction cup 5 via a suction opening 12 open to the environment.

Ãber einen

Absaugkanal 13 lÃ¤sst

sich der Saugraum 8 bedarfsgemÃ¤Ã an eine nur schematisch angedeutete

Unterdruckquelle U anschlieÃen.

Bei der Unterdruckquelle U handelt es sich beispielsweise um eine

Vakuumpumpe oder um eine nach dem Ejektorprinzip arbeitende SaugdÃ¼se. Die

Unterdruckquelle U kann extern oder aber auch an der Handhabungsvorrichtung 4 oder

direkt an dem Sauggreifer 1 angeordnet sein.Via a suction channel 13 can the suction chamber 8th according to need connect to a only schematically indicated vacuum source U. The vacuum source U is, for example, a vacuum pump or a suction nozzle operating according to the ejector principle. The vacuum source U may be external or else at the handling device 4 or directly on the suction pad 1 be arranged.

Bei

entsprechender Ansteuerung kann der Saugraum 8 Ã¼ber den

Absaugkanal 13 hinweg auch mit AtmosphÃ¤rendruck oder einem hÃ¶heren Ãberdruck

beaufschlagt werden, wenn ein zuvor erzeugter Unterdruck wieder

abgebaut werden soll.With appropriate control of the suction chamber 8th over the suction channel 13 be acted upon with atmospheric pressure or a higher pressure, if a previously generated negative pressure to be reduced again.

Bevorzugt

mÃ¼ndet

der Absaugkanal 13 rÃ¼ckseitig

in den Saugraum 8 ein. Die zugeordnete innere KanalmÃ¼ndung 14 ist

zweckmÃ¤Ãigerweise

koaxial zu der LÃ¤ngsachse 2 ausgerichtet.

Der Absaugkanal 13 durchsetzt zweckmÃ¤Ãigerweise den Halter 3 und kann

sich in der Handhabungsvorrichtung 4 und/oder in einer

nicht nÃ¤her

dargestellten Fluidleitung fortsetzen.Preferably, the suction channel opens 13 back into the suction chamber 8th one. The assigned inner channel mouth 14 is expediently coaxial with the longitudinal axis 2 aligned. The suction channel 13 expediently passes through the holder 3 and may be in the handling device 4 and / or continue in a fluid line, not shown.

Aufgrund

der FlexibilitÃ¤t

des Saugnapfes 5 ist der vordere Endabschnitt 7 in

der Lage, eine durch einen Doppelpfeil angedeutete lineare Hubbewegung 15 relativ

zu dem rÃ¼ckseitigen

Endabschnitt 6 auszufÃ¼hren.

Hierbei verÃ¤ndert

sich die LÃ¤nge

des Saugnapfes 5, was aus einem Vergleich der 1 und 2 sowie

der 4 und 5 unmittelbar ersichtlich ist.Due to the flexibility of the suction cup 5 is the front end section 7 capable of a indicated by a double arrow linear lifting movement 15 relative to the rear end portion 6 perform. This changes the length of the suction cup 5 what a comparison of 1 and 2 as well as the 4 and 5 is immediately apparent.

Solange

der Sauggreifer 1 noch nicht an einen handzuhabenden Gegenstand

angesetzt ist, liegt die aus 1 und 4 ersichtliche

Grundstellung vor. Der Saugnapf 5 nimmt hier seine maximale LÃ¤nge ein,

die ihm durch seine Struktur und Materialwahl aufgeprÃ¤gt ist.As long as the suction pad 1 is not yet attached to an object to be handled, that is off 1 and 4 apparent basic position. The sucker 5 takes its maximum length, which is impressed by its structure and choice of materials.

Bevorzugt

ist der Saugnapf 5 faltenbalgartig strukturiert. Seine

Wandung besitzt, im LÃ¤ngsschnitt gesehen,

einen zick-zack-fÃ¶rmigen Verlauf.

Dadurch verfÃ¼gt

der Saugnapf 5 an der dem Saugraum 8 zugewandten

Innenseite Ã¼ber

eine Innenfaltung 16a mit einer oder mehreren ringfÃ¶rmigen Innenfalten 16 und an

seinem AuÃenumfang Ã¼ber eine

AuÃenfaltung 17a mit

einer oder mehreren ringfÃ¶rmigen

AuÃenfalten 17.

Ist wie bei den AusfÃ¼hrungsbeispielen

eine Mehrzahl von Innenfalten 16 und/oder von AuÃenfalten 17 vorhanden,

sind diese koaxial aufeinanderfolgend angeordnet.The suction cup is preferred 5 structured like a bellows. Its wall has, seen in longitudinal section, a zigzag-shaped course. This features the suction cup 5 at the suction room 8th facing inside over an inner fold 16a with one or more annular inner folds 16 and on its outer periphery via an outer fold 17a with one or more annular outer folds 17 , As in the embodiments, a plurality of inner folds 16 and / or external folds 17 present, they are arranged coaxially in succession.

Bei

den AusfÃ¼hrungsbeispielen

haben alle Innenfalten 16 und alle AuÃenfalten 17 des jeweiligen Saugnapfes 5 den

gleichen Durchmesser. Der Saugnapf 5 verfÃ¼gt somit Ã¼ber eine

zylindrische Grundstruktur. Denkbar wÃ¤re es allerdings auch, die

Falten mit sich Ã¤nderndem

Durchmesser auszubilden, sodass der Saugnapf 5 beispielsweise

eine konische Grundstruktur besitzt.In the embodiments, all inner folds 16 and all outer folds 17 of the respective suction cup 5 the same diameter. The sucker 5 thus has a cylindrical basic structure. It would also be conceivable, however, to form the folds with a changing diameter, so that the suction cup 5 for example, has a conical basic structure.

Wenn

sich der vordere Endabschnitt 7 an den rÃ¼ckseitigen

Endabschnitt 6 annÃ¤hert

und sich dadurch die LÃ¤nge

des Saugnapfes 5 verringert, verringert sich gleichzeitig

die Breite der Innenfalten 16 und der AuÃenfalten 17,

was anhand der 2 und 5 nachvollziehbar

ist. Die die Falten 16, 17 begrenzenden Wandabschnitte

nÃ¤hern

sich dabei aneinander an.When the front end section 7 at the rear end portion 6 approximates and thereby the length of the suction cup 5 reduces, simultaneously reduces the width of the inner folds 16 and the outer folds 17 , which is based on the 2 and 5 is traceable. The the wrinkles 16 . 17 bordering wall sections approach each other.

Um

einen handzuhabenden Gegenstand 22 zu ergreifen, wird der

Sauggreifer 1 mit der SaugÃ¶ffnung 12 voraus an

besagten Gegenstand 22 angesetzt und dann in dem Saugraum 8 ein

Unterdruck erzeugt. Die Ansetzbewegung an den Gegenstand 22 ist

in 1 und 4 durch einen Pfeil bei 23 kenntlich

gemacht.To an object to be handled 22 to seize, is the suction pad 1 with the suction opening 12 ahead of said object 22 set and then in the suction room 8th generates a negative pressure. The attachment movement to the object 22 is in 1 and 4 by an arrow 23 indicated.

Der

Gegenstand 22 ist beliebiger Natur. Beispielhaft ist ein

dÃ¼nnwandiger

Gegenstand 22 mit flÃ¤chenhafter

Ausdehnung illustriert, beispielsweise eine Glasscheibe oder eine

Folie. Diese ruht vor dem Kontakt mit dem Sauggreifer 1 auf

einer schematisch abgebildeten Bereitstellungsvorrichtung 24,

beispielsweise eine stillstehende Unterlage oder ein FÃ¶rderband.The object 22 is of any nature. By way of example, a thin-walled article 22 illustrated with areal extent, for example, a glass sheet or a film. This rests before contact with the suction pad 1 on a schematically illustrated delivery device 24 For example, a stationary pad or a conveyor belt.

Im

an den Gegenstand 22 angesetzten Zustand des Sauggreifers 1 ist

die SaugÃ¶ffnung 12 durch

den Gegenstand 22 verschlossen. Wird jetzt der Saugraum 8 Ã¼ber den

Absaugkanal 13 abgesaugt, bildet sich darin ein Unterdruck

aus, was zur Folge hat, dass der Gegenstand 22 an der Vorderseite

des Saugnapfes 5 anhaftet, wie dies aus 2 und 5 ersichtlich

ist.Im at the object 22 attached state of the suction pad 1 is the suction opening 12 through the object 22 locked. Will now be the suction chamber 8th over the suction channel 13 sucked out, it forms a negative pressure, which has the consequence that the object 22 at the front of the suction cup 5 clings like this 2 and 5 is apparent.

Der

Aufbau des Unterdruckes im Saugraum 8 fÃ¼hrt gleichzeitig dazu, dass

sich der Saugnapf 5 axial zusammenzieht. Dies Ã¤uÃert sich

in einer Hubbewegung 15, bei der sich der vordere Endabschnitt 7 des

Saugnapfes 5 an den rÃ¼ckseitigen

Endabschnitt 6 annÃ¤hert.

ErmÃ¶glicht

wird dies durch die FlexibilitÃ¤t

des Saugnapfes 5 in seiner LÃ¤ngsrichtung, die vor allem

gewÃ¼nscht

ist, um beim Ansetzen des Sauggreifers 1 an einen Gegenstand 22 eine

gewisse Nachgiebigkeit und einen Toleranzausgleich zu ermÃ¶glichen.

Der Sauggreifer 1 kann somit sicher an den Gegenstand 22 angesetzt

werden, ohne diesen aufgrund von Ãberbeanspruchung zu beschÃ¤digen oder

gar zu zerstÃ¶ren.The structure of the negative pressure in the suction chamber 8th At the same time it causes the suction cup 5 contracts axially. This manifests itself in a lifting movement 15 in which the front end section 7 of the suction cup 5 at the rear end portion 6 approaches. This is made possible by the flexibility of the suction cup 5 in its longitudinal direction, which is especially desired to when applying the suction pad 1 to an object 22 to allow a certain flexibility and a tolerance compensation. The suction pad 1 can thus safely on the object 22 be used without damaging or even destroying it due to overstressing.

Durch

den im Saugraum 8 erzeugten Unterdruck neigen vor allem

dÃ¼nnwandige

GegenstÃ¤nde 22 dazu,

an der SaugÃ¶ffnung 12 in

den Saugraum 8 hineingesaugt zu werden. Dies fÃ¼hrt zu einer

Biegebeanspruchung, die bei empfindlichen Materialien bleibende

SchÃ¤den

oder gar, insbesondere bei sprÃ¶den

Materialien, eine ZerstÃ¶rung

hervorrufen kann. Um dieser Problematik entgegenzuwirken, ist der Sauggreifer 1 im

Innern des Saugraumes 8 mit einem im Bereich der SaugÃ¶ffnung 12 platzierten

AbstÃ¼tzelement 25 ausgestattet.

An diesem kann sich der angesaugte Gegenstand 22 abstÃ¼tzen, sodass

er keine relevante Biegeverformung erfÃ¤hrt.By the in the suction room 8th generated negative pressure tend especially thin-walled objects 22 to, at the suction opening 12 in the suction room 8th to be sucked in. This leads to a bending stress that can cause lasting damage to sensitive materials or even, especially in brittle materials, destruction. To counteract this problem, is the suction pad 1 inside the suction chamber 8th with one in the area of the suction opening 12 placed support 25 fitted. This can be the sucked object 22 support so that he experiences no relevant bending deformation.

Von

Vorteil ist, dass das AbstÃ¼tzelement 25 von

dem bezÃ¼glich

des rÃ¼ckseitigen

Endabschnittes 6 in Richtung der LÃ¤ngsachse 2 beweglichen

vorderen Endabschnitt 7 des Saugnapfes 5 getra gen

ist. ZweckmÃ¤Ãigerweise

ist es ausschlieÃlich

an diesem vorderen Endabschnitt 7 angebracht, eine Verbindung

zu dem rÃ¼ckseitigen

Endabschnitt 6 innerhalb des Saugraumes 8 liegt

nicht vor.The advantage is that the support element 25 from that of the rear end portion 6 in the direction of the longitudinal axis 2 movable front end section 7 of the suction cup 5 is tra conditions. Conveniently, it is exclusively on this front end portion 7 attached, a connection to the rear end portion 6 inside the suction chamber 8th not available.

Aus

dieser Art der Anbringung des AbstÃ¼tzelementes 25 ergibt

sich, dass das AbstÃ¼tzelement 25 die

lineare Hubbewegung 15 des vorderen Endabschnittes 7 stets

unmittelbar mitmacht. Es Ã¤ndert also

seinen Abstand zu dem rÃ¼ckseitigen

Endabschnitt 6 in gleicher Weise wie der vordere Endabschnitt 7.

Gleichzeitig ist das AbstÃ¼tzelement 25 luftdurchlÃ¤ssig strukturiert,

sodass es den Saugraum 8 zur SaugÃ¶ffnung 12 hin nicht

absperrt, sondern weiterhin den fÃ¼r das Ansaugen erforderlichen

Luftdurchsatz zulÃ¤sst.From this type of attachment of the support element 25 it follows that the support element 25 the linear stroke movement 15 the front end portion 7 always directly participate. So it changes its distance to the back end section 6 in the same way as the front end portion 7 , At the same time, the support element 25 permeable to air, making it the suction chamber 8th to the suction opening 12 not shut off, but continues to allow the necessary for the intake air flow.

Aufgrund

der Baueinheit aus vorderem Endabschnitt 7 und AbstÃ¼tzelement 25 finden

zwischen diesen beiden Komponenten keine Relativbewegungen in der

Richtung der Hubbewegung 15 statt. Die Belastung des angesaugten

Gegenstandes 22 Ã¤ndert

sich daher wÃ¤hrend

der Hubbewegung 15 nicht. Von Anbeginn an liegt eine ein

Durchbiegen des Gegenstandes 22 verhindernde zumindes im

wesentlichen plane AbstÃ¼tzung

vor, die wÃ¤hrend

des gesamten Handhabungsvorganges beibehalten wird.Due to the assembly of front end section 7 and support element 25 find no relative movements in the direction of the lifting movement between these two components 15 instead of. The load of the sucked object 22 therefore changes during the stroke movement 15 Not. From the beginning there is a bending of the object 22 preventing at least a substantially planar support, which is maintained throughout the handling process.

Bei

dem AusfÃ¼hrungsbeispiel

der 1 bis 3 resultiert die luftdurchlÃ¤ssige Struktur

des AbstÃ¼tzelementes 25 aus

der Herstellung des AbstÃ¼tzelementes 25 aus

einem luftdurchlÃ¤ssigen

Material. Als besonders empfehlenswert hat sich ein hochmolekulares

Polyethylen-Sintermaterial herausgestellt, wie es hÃ¤ufig auch

bei Druckluft-SchalldÃ¤mpfern

als SchalldÃ¤mpfmaterial

eingesetzt wird. Anderes Sintermaterial kÃ¶nnte jedoch ebenfalls verwendet

werden, wie sich auch jegliches sonstige fein-porÃ¶se Material anbietet,

beispielsweise auch eine ausreichende Festigkeit aufweisendes Schaumstoffmaterial.In the embodiment of the 1 to 3 results in the air-permeable structure of the support element 25 from the production of the support element 25 made of an air-permeable material. Especially recommended is a high molecular weight polyethylene sintered material has been found, as it is often used as a sound damping material in compressed air silencers. However, other sintered material could also be used, as well as any other fine-porous material, for example, also a sufficient strength having foam material.

Die

Ausgestaltung aus luftdurchlÃ¤ssigem Material

hat den Vorteil, dass das AbstÃ¼tzelement 25 in

einer Weise ausgebildet werden kann, dass es den kompletten Querschnitt

des Saugraumes 8 quer zu der LÃ¤ngsachse 2 am Ort

der Installation des AbstÃ¼tzelementes 25 ausfÃ¼llt und

dadurch eine sehr groÃe AbstÃ¼tzflÃ¤che 34 fÃ¼r den Gegenstand 22 aufweist. Dabei

wird durch die MikroporositÃ¤t

des Materials auch eine vorteilhafte Filterwirkung erzielt, indem nÃ¤mlich Verunreinigungen

an einem Eintritt in den Absaugkanal 13 und in die diesem

nachgeordneten fluidtechnischen Komponenten verhindert wird.The embodiment of air-permeable material has the advantage that the support element 25 can be formed in a way that it is the complete cross section of the suction chamber 8th across to the longitudinal axis 2 at the place of installation of the support element 25 fills and thus a very large support surface 34 for the object 22 having. In this case, an advantageous filter effect is achieved by the microporosity of the material, namely by impurities at an inlet into the suction channel 13 and is prevented in the downstream of this fluid power components.

Gleichwohl

sind prinzipiell auch andere Strukturen zur GewÃ¤hrleistung der LuftdurchlÃ¤ssigkeit

verwendbar. So zeigen beispielsweise die 6 und 7 je

ein AbstÃ¼tzelement

aus einem luftundurchlÃ¤ssigen

Material, wobei die LuftdurchlÃ¤ssigkeit durch

je eine Mehrzahl von LuftdurchtrittskanÃ¤len 26 gewÃ¤hrleistet

ist, die das AbstÃ¼tzelement 25 in

axialer Richtung durchsetzen und eine stÃ¤ndige Verbindung zwischen dem

Saugraum 8 und dem dem AbstÃ¼tzelement 25 axial

auÃen

vorgelagerten Bereich hervorrufen.Nevertheless, in principle, other structures can be used to ensure air permeability. For example, show the 6 and 7 depending on a supporting element made of an air-impermeable material, wherein the air permeability through a plurality of air passageways 26 is ensured that the support element 25 enforce in the axial direction and a permanent connection between the suction chamber 8th and the support element 25 axially outside of the area cause.

Im

Falle der 6 sind mehrere LuftdurchtrittskanÃ¤le 26 kreissektorartig

um ein AbstÃ¼tzzentrum 27 herum

verteilt, wobei sie radial auÃen

von einem Ringabschnitt 28 umgeben sind, Ã¼ber den

die Befestigung am Saugnapf 5 stattfindet. Das AbstÃ¼tzzentrum 27 ist

mit dem Ringabschnitt 28 durch eine Mehrzahl radialer Haltearme 32 verbunden,

die jeweils als Trennwand zwischen in Umfangsrichtung benachbarten

LuftdurchtrittskanÃ¤len 26 fungieren.In case of 6 are several air passageways 26 circular sector around a support center 27 distributed around, being radially outward of a ring section 28 are surrounded by the attachment to the suction cup 5 takes place. The support center 27 is with the ring section 28 by a plurality of radial retaining arms 32 connected, each as a partition between circumferentially adjacent air passageways 26 act.

Bei

dem AusfÃ¼hrungsbeispiel

der 7 bestehen die LuftdurchtrittskanÃ¤le 26 aus

mehreren bohrungsartigen KanÃ¤len

einer gewÃ¼nschten

Verteilung.In the embodiment of the 7 exist the air passageways 26 from several bore-like channels of a desired distribution.

Die

Realisierung einer Mehrzahl von LuftdurchtrittskanÃ¤len 26 hat

den Vorteil, dass ein hoher Luftdurchsatz mit einer weiterhin groÃflÃ¤chigen AbstÃ¼tzwirkung

kombinierbar ist.The realization of a plurality of air passageways 26 has the advantage that a high air flow rate can be combined with a further large-scale supporting effect.

Um

einen raschen Unterdruckaufbau zu gewÃ¤hrleisten, ist es empfehlenswert,

den vorderen Endabschnitt 7 des Saugnapfes 5 als

bezÃ¼glich

der LÃ¤ngsachse 2 konzentrische,

umlaufende Dichtlippe 33 auszubilden, die mit dem Gegenstand 22 in

Kontakt treten kann, wenn der Sauggreifer 1 daran angesetzt

wird.To ensure a rapid build-up of negative pressure, it is recommended that the front end section 7 of the suction cup 5 as with respect to the longitudinal axis 2 concentric, circumferential sealing lip 33 train with the object 22 can come into contact when the suction pad 1 is attached to it.

Bei

dem AusfÃ¼hrungsbeispiel

der 1 bis 3 ist die Dichtlippe 33 so

ausgebildet, dass sie in der Grundstellung des Sauggreifers 1,

im nicht an einen Gegenstand 22 angesetzten Zustand, geringfÃ¼gig axial Ã¼ber die

vom Saugraum 8 axial wegweisende stirnseitige AbstÃ¼tzflÃ¤che 34 des

AbstÃ¼tzelementes 25 vorsteht.

Beim Ansetzen an den Gegenstand 22 wird die Dichtlippe 33 hier

leicht zurÃ¼ckgebogen, bis

sie gemÃ¤Ã 2 etwa

in einer Ebene mit der AbstÃ¼tzflÃ¤che 34 zu

liegen kommt, wobei sie gleichzeitig dichtend an dem Gegenstand 22 anliegt.

Dadurch ist der Saugraum 8 zuverlÃ¤ssig zur Umgebung abgedichtet.In the embodiment of the 1 to 3 is the sealing lip 33 designed so that they are in the home position of the suction pad 1 , im not an object 22 attached state, slightly above that of the suction chamber 8th axially pioneering end support surface 34 of the support element 25 protrudes. When applying to the object 22 becomes the sealing lip 33 slightly bent back here, until you see 2 approximately in one plane with the support surface 34 comes to lie, while sealing the object at the same time 22 is applied. This is the suction chamber 8th Reliably sealed to the environment.

Bei

dem AusfÃ¼hrungsbeispiel

der 4 und 5 verÃ¤ndert die Dichtlippe 33 wÃ¤hrend des

Betriebes des Sauggreifers 1 ihre Relativposition bezÃ¼glich des

AbstÃ¼tzelementes 25 nicht.

Sie schlieÃt im

Wesentlichen plan mit der AbstÃ¼tzflÃ¤che 34 des AbstÃ¼tzelementes 25 ab.

Da hier keine Nachgiebigkeit fÃ¼r

die Dichtlippe 33 erforderlich ist, kann der vordere Endabschnitt 7 in

dem das AbstÃ¼tzelement 25 umschlieÃenden Bereich

insbe sondere zylindrisch gestaltet sein. Ist eine FlexibilitÃ¤t in Richtung

der LÃ¤ngsachse 2 gewÃ¼nscht, bietet

es sich gemÃ¤Ã 1 und 2 an,

die Faltenbalgstruktur mit einem schrÃ¤gen Wandabschnitt 18 unmittelbar

in die Dichtlippe 33 auslaufen zu lassen.In the embodiment of the 4 and 5 changes the sealing lip 33 during operation of the suction pad 1 their relative position with respect to the support element 25 Not. It essentially closes flush with the support surface 34 of the support element 25 from. Since there is no flexibility for the sealing lip 33 is required, the front end portion 7 in which the support element 25 enclosing area in particular cylindrically shaped special. Is a flexibility in the direction of the longitudinal axis 2 desired, it offers itself according to 1 and 2 on, the bellows structure with a sloping wall section 18 directly into the sealing lip 33 to expire.

Um

trotz hoher FlexibilitÃ¤t Ã¼bermÃ¤Ãige HÃ¼be des vorderen

Endabschnittes 7 und mithin auch des daran anhaftenden

Gegenstandes 22 zu vermeiden, empfiehlt sich der Einsatz

von Hubbegrenzungsmitteln. Hierbei ist zweckmÃ¤Ãigerweise dem rÃ¼ckseitigen

Endabschnitt 6 des Saugnapfes 5 ein diesbezÃ¼glich ortsfester,

innerhalb des Saugraumes 8 im Hubweg des AbstÃ¼tzelementes 25 angeordneter

Hubbegrenzungsanschlag 35 zugeordnet. Auf ihn lÃ¤uft das die

Hubbewegung 15 mitmachende AbstÃ¼tzelement 25 gemÃ¤Ã 2 und 5 auf.In spite of high flexibility excessive strokes of the front end portion 7 and therefore also of the attached object 22 To avoid this, the use of stroke limiting devices is recommended. This is expediently the rear end portion 6 of the suction cup 5 a fixed in this regard, within the suction chamber 8th in the stroke of the support element 25 arranged Hubbegrenzungsanschlag 35 assigned. The lifting movement runs on it 15 Participating support 25 according to 2 and 5 on.

Bevorzugt

ist der Hubbegrenzungsanschlag 35 von dem Halter 3 gebildet.

Er kÃ¶nnte

allerdings auch durch den entsprechend gestalteten rÃ¼ckseitigen

Endabschnitt 6 des Saugnapfes 5 realisiert sein. Letzteres

hÃ¤tte den

Vorteil, dass wegen der FlexibilitÃ¤t und insbesondere der GummielastizitÃ¤t des Saugnapfes 5 der

Aufprall gedÃ¤mpft

wird.Preferred is the Hubbegrenzungsanschlag 35 from the holder 3 educated. He could, however, also by the correspondingly shaped rear end section 6 of the suction cup 5 be realized. The latter would have the advantage that because of the flexibility and in particular the rubber elasticity of the suction cup 5 the impact is dampened.

Es

wÃ¤re auch

denkbar, einen eigenstÃ¤ndigen Hubbegrenzungsanschlag 35 vorzusehen,

der von dem Halter 3 getragen ist, wobei man auch eine

EinstellmÃ¶glichkeit

zur Justierung der gewÃ¼nschten

Hubendlage vorsehen kÃ¶nnte.It would also be conceivable, an independent Hubbegrenzungsanschlag 35 to be provided by the holder 3 is worn, which could also provide an adjustment for adjusting the desired Hubendlage.

Die

erlÃ¤uterte

Absaugwirkung sollte auch dann noch gegeben sein, wenn das AbstÃ¼tzelement 25 an

dem Hubbegrenzungsanschlag 35 anliegt. Bevorzugt verfÃ¼gt daher

das AbstÃ¼tzelement 25 an

seiner dem Saugraum 8 zugewandten RÃ¼ckseite Ã¼ber eine Aussparung 36,

die der inneren KanalmÃ¼ndung 14 koaxial

gegenÃ¼berliegt,

sodass eine direkte Verbindung zwischen ihr und dem Absaugkanal 13 vorliegt,

wenn die Hubendlage erreicht ist.The explained suction effect should still be given when the support element 25 at the Hubbegrenzungsanschlag 35 is applied. Therefore, the support element preferably has 25 at his the suction room 8th facing back over a recess 36 , the inner canal mouth 14 coaxially opposed so that there is a direct connection between it and the suction channel 13 is present when the stroke end position is reached.

Die

Aussparung 36 ist eine Hohlkammer, beispielsweise sacklockartig

gestaltet, sodass sie die dem Absaugkanal 13 zugewandte

LuftabsaugflÃ¤che an

dem AbstÃ¼tzelement 25 wesentlich

vergrÃ¶Ãert, verglichen

mit einem Fall, in dem das AbstÃ¼tzelement 25 die

innere KanalmÃ¼ndung 14 direkt Ã¼berdeckt.The recess 36 is a hollow chamber, for example, designed sacklockartig, so that they the suction 13 facing LuftabsaugflÃ¤che on the support element 25 significantly increased, compared with a case in which the support element 25 the inner canal mouth 14 directly covered.

Das

AbstÃ¼tzelement 25 umfasst

zweckmÃ¤Ãigerweise

einen scheibenfÃ¶rmigen

Basisabschnitt 37, der den gesamten Querschnitt des Saugraumes 8 Ã¼berspannen

kann und von dessen RÃ¼ckseite

ein einen diesbezÃ¼glich

geringeren Querschnitt aufweisender Vorsprung 38 axial

wegragt, der den Kontakt zu dem Hubbegrenzungsanschlag 35 herstellt.

Er fungiert quasi als Gegenanschlag. Die Befestigung des AbstÃ¼tzelementes 25 am

Saugnapf 5 erfolgt insbesondere Ã¼ber den Basisabschnitt 37,

wobei sich die gesamten BefestigungsmaÃnahmen, unabhÃ¤ngig von

der Gestaltung des AbstÃ¼tzelementes 25,

zweckmÃ¤Ãigerweise

auf die InnenumfangsflÃ¤che

des Saugnapfes 5 beschrÃ¤nken.The support element 25 expediently comprises a disc-shaped base section 37 that covers the entire cross-section of the suction chamber 8th can span and from the back of a lower in this respect cross-section having projection 38 protrudes axially, the contact with the Hubbegrenzungsanschlag 35 manufactures. He acts as a kind of counter-attack. The attachment of the support element 25 on the suction cup 5 takes place in particular via the base section 37 , Wherein the entire fastening measures, regardless of the design of the support element 25 , Expediently on the inner peripheral surface of the suction cup 5 restrict.

Eine

besonders vorteilhafte Befestigungsart ist beim AusfÃ¼hrungsbeispiel

der 1 bis 3 realisiert. Dort ist das AbstÃ¼tzelement 25 lÃ¶sbar in den

flexiblen Saugnapf 5 eingerastet beziehungsweise eingeknÃ¶pft, und

zwar in eine einzige der von Hause aus vorhandenen Innenfalten 16.

Der Basisabschnitt 37 ist am AuÃenumfang nach radial auÃen hin sich

verjÃ¼ngend

ausgebildet und verfÃ¼gt

daher in diesem AuÃenbereich Ã¼ber einen

Querschnitt, der etwa demjenigen einer Innenfalte 16 entspricht,

sodass die Faltenstruktur ihre Grundstruktur auch dann beibehÃ¤lt, wenn

das AbstÃ¼tzelement 25 eingesetzt

ist.A particularly advantageous manner of attachment is in the embodiment of 1 to 3 realized. There is the support element 25 detachable in the flexible suction cup 5 locked or buttoned, in a single of the existing from home inner wrinkles 16 , The base section 37 is on the outer circumference radially outwardly tapering and therefore has in this outer region over a cross-section which is approximately that of an inner fold 16 corresponds so that the pleat structure retains its basic structure even when the support element 25 is used.

Diese

Art der Befestigung hat den Vorteil, dass am Saugnapf 5 keinerlei

konstruktive BefestigungsmaÃnahmen

zu treffen sind. Jeder handelsÃ¼bliche

Faltenbalg-Saugnapf lÃ¤sst

sich mit dem AbstÃ¼tzelement 25 problemlos

nachrÃ¼sten.This type of attachment has the advantage that on the suction cup 5 no constructive fastening measures are to be taken. Each standard bellows suction cup can be combined with the support element 25 easy to retrofit.

Abweichend

vom AusfÃ¼hrungsbeispiel

kÃ¶nnte

das AbstÃ¼tzelement 25 auch

so ausgefÃ¼hrt

sein, dass es gleichzeitig in mehreren benachbarten Innenfalten 16 gehalten

wird. Die Verformbarkeit des Saugnapfes 5 wird jedoch am

wenigsten beeintrÃ¤chtigt,

wenn nur eine Innenfalte 16 zur Fixierung des AbstÃ¼tzelementes 25 genutzt

wird.Notwithstanding the embodiment, the support element could 25 also be designed so that it simultaneously in several adjacent inner folds 16 is held. The deformability of the suction cup 5 but is least affected if only one inner fold 16 for fixing the support element 25 is being used.

SelbstverstÃ¤ndlich kÃ¶nnte man

bei einem anders strukturierten Saugnapf 5 auch spezielle

Rastmittel an der InnenumfangsflÃ¤che

vorsehen, um das AbstÃ¼tzelement 25 lÃ¶sbar zu

verrasten.Of course you could with a differently structured suction cup 5 Also provide special locking means on the inner peripheral surface to the support element 25 releasably lock.

Nicht

dargestellt ist eine Variante, bei der die formschlÃ¼ssige Fixierung

des AbstÃ¼tzelementes 25 an

der Innenfaltung 16a am Ãbergangsbereich wenigstens

zweier aufeinanderfolgender Innenfalten 16 stattfindet.

Das AbstÃ¼tzelement 25 enthÃ¤lt dann

eine umlaufende Nut, mit der es reiterartig auf einem ringfÃ¶rmigen Ãbergangsbereich

sitzt.Not shown is a variant in which the positive fixing of the support element 25 at the inner fold 16a at the transition region of at least two successive inner folds 16 takes place. The support element 25 then contains a circumferential groove with which it sits like a rider on an annular transition area.

Bei

dem AusfÃ¼hrungsbeispiel

der 4 und 5 liegt zwischen dem Saugnapf 5 und

dem in diesen eingesetzten AbstÃ¼tzelement 25 eine

rein stoffschlÃ¼ssige

Verbindung vor, beispielsweise eine Klebeverbindung. Der Basisabschnitt 37 besitzt

hier eine kreiszylindrische AuÃenflÃ¤che und

wird von dem hohlzylindrischen vorderen Endabschnitt 7 fest

umschlossen, wobei dazwischen ein Klebstoff appliziert ist. Eine

SchweiÃverbindung

wÃ¤re ebenfalls

denkbar.In the embodiment of the 4 and 5 lies between the suction cup 5 and the support element used in these 25 a purely material connection before, for example, an adhesive bond. The base section 37 here has a circular cylindrical outer surface and is of the hollow cylindrical front end portion 7 firmly enclosed, with an adhesive applied between them. A welded connection would also be conceivable.

Es

wÃ¤re auch

mÃ¶glich,

das AbstÃ¼tzelement 25 bei

der SpritzgieÃherstellung

des aus Kunststoffmaterial bestehenden Saugnapfes 5 unmittelbar

mit anzuformen.It would also be possible, the support element 25 in the injection molding of the existing plastic material suction cup 5 Immediately to start with.

Ungeachtet

der Art der Befestigung des AbstÃ¼tzelementes 25 ist

es vorteilhaft, Saugnapf 5 und AbstÃ¼tzelement 28 in ihrer

Gestaltung so aufeinander abzustimmen, dass das AbstÃ¼tzelement 25 stets

zur GÃ¤nze

innerhalb des Saugraumes 8 aufgenommen ist und nicht durch

die SaugÃ¶ffnung 12 hindurch

axial Ã¼ber

den Saugnapf 5 vorsteht. Die vorhandenen BefestigungsmaÃnahmen

beschrÃ¤nken

sich insbesondere auf den Bereich des Innenumfanges des vorderen

Endabschnittes 7 des Saugnapfes 5.Regardless of the type of attachment of the support element 25 it is beneficial to suction cup 5 and support element 28 in their design to match each other so that the support element 25 always completely within the suction chamber 8th is absorbed and not through the suction opening 12 axially through the suction cup 5 protrudes. The existing fastening measures are limited in particular to the region of the inner circumference of the front end portion 7 of the suction cup 5 ,

## Classifications

- B65G47/91
- B65G47/91

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
