# 07. Sauggreifer

- **Archive rank:** 7 of 50
- **Publication:** [DE-29814281-U1](https://patents.google.com/patent/DE29814281U1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/008061072/publication/DE29814281U1?q=pn%3DDE29814281U1)
- **Publication date:** 1999-12-16
- **Filing date:** 1998-08-10
- **Earliest priority:** 1998-08-10
- **Family:** 8061072
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** SCHMALZ J GMBH

## Abstract

_No abstract was available from the queried sources._

## Sketches and drawings

_No digitized sketch link was returned._

## Claims

### Claim 1 (independent)

Sauggreifer zum Ansaugen von Werkstücken (2), mit einem Unterdruckanschluss und einem elastischen Saugkörper, wobei der Saugkörper an seiner dem Werkstück (2) zugewandten Stirnseite zwei ringförmige Dichtlippen (6, 7) aufweist, dadurch gekennzeichnet, dass die Dichtlippen (6, 7) derart ausgestaltet sind, dass ihre freien Dichtkanten (11, 12) in unterschiedlichen Ebenen liegen. 1. Suction gripper for sucking workpieces ( 2 ), with a vacuum connection and an elastic suction body, wherein the suction body has two annular sealing lips ( 6 , 7 ) on its end face facing the workpiece ( 2 ), characterized in that the sealing lips ( 6 , 7 ) are designed such that their free sealing edges ( 11 , 12 ) lie in different planes.

### Claim 2

Sauggreifer nach Anspruch 1, dadurch gekennzeichnet, dass die Dichtlippen (6, 7) unterschiedlich lang sind. 2. Suction gripper according to claim 1, characterized in that the sealing lips ( 6 , 7 ) are of different lengths.

### Claim 3

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass der Saugkörper (5) im Bereich der angeformten Dichtlippe (6', 7') stufenartig ausgebildet ist und die Dichtlippen (6', 7') von der Stufe (Axialschulter 13) abragen. 3. Suction gripper according to one of the preceding claims, characterized in that the suction body ( 5 ) is designed in a step-like manner in the region of the molded-on sealing lip ( 6 ', 7 ') and the sealing lips ( 6 ', 7 ') protrude from the step (axial shoulder 13 ).

### Claim 4

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass die Dichtlippen (6, 7) konzentrisch zueinander laufen. 4. Suction gripper according to one of the preceding claims, characterized in that the sealing lips ( 6 , 7 ) run concentrically to one another.

### Claim 5

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass die Dichtlippen (6, 7) einen ringförmigen Saugkanal (9) einschließen. 5. Suction gripper according to one of the preceding claims, characterized in that the sealing lips ( 6 , 7 ) enclose an annular suction channel ( 9 ).

### Claim 6

Sauggreifer nach einem der vorhergehenden Ansprüche, . dadurch gekennzeichnet, dass zwischen den Dichtlippen (6, 7) Aufsetznoppen (10) vorgesehen sind, die bei angesaugtem Werkstück (2) an dessen Oberfläche (3) anliegen. 6. Suction gripper according to one of the preceding claims, characterized in that between the sealing lips ( 6 , 7 ) there are provided mounting knobs ( 10 ) which rest against the surface ( 3 ) of the workpiece ( 2 ) when it is being sucked on.

### Claim 7

Sauggreifer nach Anspruch 6, dadurch gekennzeichnet, dass die Aufsetznoppen (10) kreisrund oder bogenförmig ausgebildet sind. 7. Suction gripper according to claim 6, characterized in that the mounting knobs ( 10 ) are circular or arc-shaped.

### Claim 8

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass die radial innere Dichtlippe (7) weiter vom Grundkörper (5) abragt, als die radial äußere Dichtlippe (6). 8. Suction gripper according to one of the preceding claims, characterized in that the radially inner sealing lip ( 7 ) protrudes further from the base body ( 5 ) than the radially outer sealing lip ( 6 ).

### Claim 9

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, dass der von den Dichtlippen (6, 7) umschlossene Raum (9) über einen oder mehrere Strömungskanäle (8) mit dem Unterdruckanschluss verbunden ist. 9. Suction gripper according to one of the preceding claims, characterized in that the space ( 9 ) enclosed by the sealing lips ( 6 , 7 ) is connected to the vacuum connection via one or more flow channels ( 8 ).

### Claim 10

Sauggreifer nach Anspruch 9, dadurch gekennzeichnet, dass der wenigstens eine Strömungskanal (8) in den Saugkörper (5) eingeformt ist. 10. Suction gripper according to claim 9, characterized in that the at least one flow channel ( 8 ) is formed in the suction body ( 5 ).

## Full description

MECHANICAL ENGINEERING; LIGHTING; HEATING; WEAPONS; BLASTINGENGINEERING ELEMENTS AND UNITS; GENERAL MEASURES FOR PRODUCING AND MAINTAINING EFFECTIVE FUNCTIONING OF MACHINES OR INSTALLATIONS; THERMAL INSULATION IN GENERALDEVICES FOR FASTENING OR SECURING CONSTRUCTIONAL ELEMENTS OR MACHINE PARTS TOGETHER, e.g. NAILS, BOLTS, CIRCLIPS, CLAMPS, CLIPS OR WEDGES; JOINTS OR JOINTINGSuction cups for attaching purposes; Equivalent means using adhesivesPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippers

Description

Translated from German

F:\IJBDHF\DHFANM\3 961O96F:\IJBDHF\DHFANM\3 961O96

Anmelder:Applicant:

J. Schmalz GmbHJ. Schmalz GmbH

Aacher StraÃe 2 9Aacher Strasse 2 9

72293 Glatten72293 Glatten

Allgemeine Vollmacht: 3.1.5.Nr.751/92 AVGeneral power of attorney: 3.1.5.No.751/92 AV

3961 096 07.08.19983961 096 07.08.1998

ste / negste / neg

Titel: SauggreiferTitle: Suction cup

B e sehre ibungB e very exercise

Die Erfindung betrifft einen Sauggreifer zum Ansaugen von WerkstÃ¼cken, mit einem Unterdruckanschluss und einem elastischen SaugkÃ¶rper, wobei der SaugkÃ¶rper an seiner dem WerkstÃ¼ck zugewandten Stirnseite zwei ringfÃ¶rmige Dichtlippen aufweist.The invention relates to a suction gripper for sucking workpieces, with a vacuum connection and an elastic suction body, wherein the suction body has two annular sealing lips on its front side facing the workpiece.

Sauggreifer werden verwendet, um GegenstÃ¤nde oder WerkstÃ¼cke anzusaugen, so dass sie entweder auf diese Weise fixiert oder gehandhabt werden kÃ¶nnen. Befinden sich die Sauggreifer an Manipulatoren, so kann der angesaugte Gegenstand transportiert werden. FÃ¼r unterschiedliche GegenstÃ¤nde sind jeweils die entsprechenden Sauggreifer erforderlich. In der Regel sind die Sauggreifer an dieSuction grippers are used to suck objects or workpieces so that they can either be fixed or handled in this way. If the suction grippers are attached to manipulators, the sucked object can be transported. Different objects require the appropriate suction grippers. As a rule, the suction grippers are attached to the

GrÃ¶Ãe und das Gewicht des zu manipulierenden Gegenstands angepasst. Die Sauggreifer weisen in der Regel eine umlaufende Dichtlippe auf, Ã¼ber die ein Saugraum abgeschlossen bzw. abgedichtet wird. Ebene GegenstÃ¤nde kÃ¶nnen auf diese Weise relativ einfach ergriffen und transportiert werden. Weist die OberflÃ¤che des anzusaugenden Gegenstands jedoch Unebenheiten auf, so werden in der Regel mehrere kleinere Sauggreifer verwendet, die ihrerseits immer an einem ebenen Bereich des Gegenstands angesetzt werden. Das Ergreifen dieser GegenstÃ¤nde mit mehreren Sauggreifern verursacht jedoch hÃ¶here Kosten, da der technische Aufwand wesentlich hÃ¶her ist, als beim Ergreifen des Gegenstands mit einem einzigen Sauggreifer.The suction grippers are adapted to the size and weight of the object to be manipulated. The suction grippers usually have a circumferential sealing lip, which closes off or seals off a suction chamber. Flat objects can be gripped and transported relatively easily in this way. However, if the surface of the object to be gripped is uneven, several smaller suction grippers are usually used, which in turn are always placed on a flat area of the object. Gripping these objects with several suction grippers, however, causes higher costs, as the technical effort is much higher than gripping the object with a single suction gripper.

Der Erfindung liegt daher die Aufgabe zugrunde, einen Sauggreifer bereitzustellen, mit dem auch unebene GegenstÃ¤nde ergriffen werden kÃ¶nnen.The invention is therefore based on the object of providing a suction gripper with which even uneven objects can be gripped.

Diese Aufgabe wird erfindungsgemÃ¤Ã mit einem Sauggreifer der eingangs genannten Art dadurch gelÃ¶st, dass die Dichtlippen derart ausgestaltet sind, dass ihre freien Dichtkanten in unterschiedlichen Ebenen liegen.This object is achieved according to the invention with a suction gripper of the type mentioned at the outset in that the sealing lips are designed in such a way that their free sealing edges lie in different planes.

Der erfindungsgemÃ¤Ãe Sauggreifer besitzt zwei Dichtlippen, deren freie Dichtkanten nicht in der gleichen Ebene liegen,The suction gripper according to the invention has two sealing lips whose free sealing edges are not in the same plane,

sondern bei dem die eine Dichtkante weiter vorsteht als die andere. Besitzt das anzusaugende WerkstÃ¼ck eine OberflÃ¤che in welcher ein Absatz vorgesehen ist, so kann die weiter vorstehende Dichtlippe in diesen Absatz eingreifen, wohingegen die weniger weit vorstehende Dichtlippe an der weiter auÃen liegenden Ebene des Gegenstands anliegt. In der Regel sind die Sauggreifer exakt auf den anzusaugenden Gegenstand abgestimmt. Auf diese Weise kann das MaÃ, mit dem die eine Dichtkante weiter vorsteht als die andere Dichtkante exakt auf die Tiefe des Absatzes abgestimmt sein. Der eine unebene OberflÃ¤che aufweisende Gegenstand kann mit einem einzigen Sauggreifer der erfindungsgemÃ¤Ãen Art ergriffen werden und es ist nicht erforderlich, mehrere Sauggreifer zu verwenden.but in which one sealing edge protrudes further than the other. If the workpiece to be vacuumed has a surface in which a step is provided, the sealing lip that protrudes further can engage in this step, whereas the sealing lip that protrudes less far rests on the outer plane of the object. As a rule, the suction grippers are precisely matched to the object to be vacuumed. In this way, the extent to which one sealing edge protrudes further than the other sealing edge can be precisely matched to the depth of the step. The object having an uneven surface can be gripped with a single suction gripper of the type according to the invention and it is not necessary to use several suction grippers.

Eine Weiterbildung sieht vor, dass die Dichtlippen unterschiedlich lang sind. Dies hat den wesentlichen Vorteil, dass aufgrund der unterschiedlichen LÃ¤nge der Dichtlippen sich die lÃ¤ngere Dichtlippe an die Unebenheit des Gegenstands durch elastische Verformung anpassen kann. Der Sauggreifer muss also nicht unbedingt ganz exakt an die Form der OberflÃ¤che des WerkstÃ¼cks angepasst sein.A further development provides for the sealing lips to be of different lengths. This has the significant advantage that, due to the different lengths of the sealing lips, the longer sealing lip can adapt to the unevenness of the object through elastic deformation. The suction gripper does not necessarily have to be adapted exactly to the shape of the surface of the workpiece.

Eine AusfÃ¼hrungsform sieht vor, dass der SaugkÃ¶rper im Bereich der angeformten Dichtlippen stufenartig ausgebildet ist und die Dichtlippen von den Stufen abragen. Auf dieseOne embodiment provides that the suction body is designed in steps in the area of the molded sealing lips and the sealing lips protrude from the steps.

Weise kÃ¶nnen nahezu gleiche Dichtlippen erzeugt werden, die sich im Hinblick auf ihr Verhalten hinsichtlich Verformung und ElastizitÃ¤t gleichen.In this way, almost identical sealing lips can be produced which are similar in terms of their behaviour with regard to deformation and elasticity.

Bei einer Ausfuhrungsform ist vorgesehen, dass die Dichtlippen konzentrisch zueinander laufen. Dies hat den wesentlichen Vorteil, dass die Dichtlippen einen ringfÃ¶rmigen Saugkanal einschlieÃen, so dass auf diese Weise die am WerkstÃ¼ck angreifenden KrÃ¤fte begrenzt werden kÃ¶nnen, so dass das WerkstÃ¼ck keinen Schaden nimmt, insbesondere nicht verbogen wird.In one embodiment, the sealing lips are concentric with each other. This has the significant advantage that the sealing lips enclose an annular suction channel, so that the forces acting on the workpiece can be limited so that the workpiece is not damaged, and in particular is not bent.

Eine weitere Sicherheit gegen Verformung sowie eine optimale AbstÃ¼tzung des WerkstÃ¼cks am Sauggreifer wird dadurch erzielt, dass zwischen den Dichtlippen Aufsetznoppen vorgesehen sind, die bei angesaugtem WerkstÃ¼ck an dessen OberflÃ¤che anliegen. Diese Aufsetznoppen kÃ¶nnen auÃerdem eine rutschhemmende OberflÃ¤che aufweisen, so dass QuerkrÃ¤fte abgestÃ¼tzt werden kÃ¶nnen.Further protection against deformation and optimal support of the workpiece on the suction gripper is achieved by providing mounting knobs between the sealing lips, which rest on the surface of the workpiece when it is suctioned on. These mounting knobs can also have an anti-slip surface so that transverse forces can be supported.

Bei Ausfuhrungsformen sind die Noppen kreisrund oder bogenfÃ¶rmig ausgebildet. Die bogenfÃ¶rmige Ausgestaltung bietet den Vorteil, dass die Noppen Ã¼ber eine relativ groÃe FlÃ¤che am WerkstÃ¼ck anliegen und dieses abstÃ¼tzen.In some embodiments, the studs are circular or curved. The curved design offers the advantage that the studs rest on the workpiece over a relatively large area and support it.

Mit Vorzug ragt die radial innere Dichtlippe weiter vom GrundkÃ¶rper ab als die radial Ã¤uÃere Dichtlippe. Der von den Dichtlippen umschlossene Raum ist Ã¼ber einen oder mehrere StrÃ¶mungskanÃ¤le mit dem Unterdruckanschluss verbunden. Auf diese Weise kann relativ schnell die im Saugraum sich befindende Luft abgesaugt und ein Unterdruck erzeugt werden. Mehrere StrÃ¶mungskanÃ¤le bieten den Vorteil, dass BearbeitungsrÃ¼ckstÃ¤nde, KÃ¼hl- oder SchmierflÃ¼ssigkeit o.dgl. keine zentrale Gefahr bilden, da auch dann, wenn einer der StrÃ¶mungskanÃ¤le verstopft ist, die Luft noch Ã¼ber die anderen, freien StrÃ¶mungskanÃ¤le abgesaugt werden kann.Preferably, the radially inner sealing lip protrudes further from the base body than the radially outer sealing lip. The space enclosed by the sealing lips is connected to the vacuum connection via one or more flow channels. In this way, the air in the suction space can be sucked out relatively quickly and a vacuum generated. Several flow channels offer the advantage that processing residues, coolant or lubricant fluids, etc. do not pose a central risk, since even if one of the flow channels is blocked, the air can still be sucked out via the other, free flow channels.

Bevorzugt sind die StrÃ¶mungskanÃ¤le in den SaugkÃ¶rper eingeformt. Auf diese Weise bedarf es keinerlei Schlauchleitungen oder anderer Verbindungselemente und der Sauggreifer muss lediglich Ã¼ber seinen Unterdruckanschluss mit der Saugleitung bzw. der Unterdruckquelle verbunden werden.Preferably, the flow channels are formed into the suction body. This means that no hose lines or other connecting elements are required and the suction gripper only needs to be connected to the suction line or the vacuum source via its vacuum connection.

Weitere Vorteile, Merkmale und Einzelheiten der Erfindung ergeben sich aus den UnteransprÃ¼chen sowie der nachfolgenden Beschreibung, in der unter Bezugnahme auf die Zeichnung zwei besonders bevorzugte AusfÃ¼hrungsbeispiele im Einzelnen beschrieben sind. Dabei kÃ¶nnen die in der Zeichnung dargestellten und in den AnsprÃ¼chen und in derFurther advantages, features and details of the invention emerge from the subclaims and the following description, in which two particularly preferred embodiments are described in detail with reference to the drawing. The features shown in the drawing and in the claims and in the

Beschreibung erwÃ¤hnten Merkmale jeweils einzeln fÃ¼r sich oder in beliebiger Kombination erfindungswesentlich sein.The features mentioned in the description may be essential to the invention, either individually or in any combination.

In der Figur 1 sind zwei AusfÃ¼hrungsbeispiele des erfindungsgemÃ¤Ãen Sauggreifers 1, 1' dargestellt. Der Sauggreifer 1 gemÃ¤Ã dem ersten AusfÃ¼hrungsbeispiel ist auf die Oberseite eines WerkstÃ¼cks 2 aufgesetzt. Dieses WerkstÃ¼ck 2 ist z.B. eine DVD (digitale Video-Disk) oder ein anderes WerkstÃ¼ck, dessen OberflÃ¤che 3 wenigstens einen Absatz 4 aufweist.Figure 1 shows two embodiments of the suction gripper 1, 1' according to the invention. The suction gripper 1 according to the first embodiment is placed on the top of a workpiece 2. This workpiece 2 is, for example, a DVD (digital video disk) or another workpiece whose surface 3 has at least one shoulder 4.

Der Sauggreifer 1, von dem lediglich ein GrundkÃ¶rper 5 sowie zwei Dichtlippen 6 und 7 dargestellt sind, ist z.B. an einem TrÃ¤ger befestigt, welcher einen Unterdruckanschluss besitzt, an dem ein Unterdruckschlauch oder allgemein eine Unterdruckquelle angeschlossen werden kann. Der GrundkÃ¶rper 5 ist mit StrÃ¶mungskanÃ¤len 8 versehen, die in einen Saugraum 9 einmÃ¼nden. Dieser Saugraum 9 wird von den beiden Dichtlippen 6 und 7 seitlich begrenzt. AuÃerdem befinden sich im Saugraum 9 Aufsetznoppen 10, die bei angesaugtem WerkstÃ¼ck 2 auf der OberflÃ¤che 3 des WerkstÃ¼cks 2 aufliegen.The suction gripper 1, of which only a base body 5 and two sealing lips 6 and 7 are shown, is attached to a carrier, for example, which has a vacuum connection to which a vacuum hose or generally a vacuum source can be connected. The base body 5 is provided with flow channels 8 that open into a suction chamber 9. This suction chamber 9 is laterally delimited by the two sealing lips 6 and 7. In addition, there are mounting knobs 10 in the suction chamber 9, which rest on the surface 3 of the workpiece 2 when the workpiece 2 is sucked in.

Die Dichtlippe 6, die von der Unterseite des GrundkÃ¶rpers 5 abragt und die radial Ã¤uÃere der beiden Dichtlippen 6 und 7 ist, und auÃerdem radial nach auÃen geneigt ist, ist kÃ¼rzerThe sealing lip 6, which protrudes from the underside of the base body 5 and is the radially outer of the two sealing lips 6 and 7, and is also inclined radially outwards, is shorter

ausgestaltet, als die radial innere Dichtlippe 7, die radial nach innen geneigt ist. Die beiden Dichtlippen 6 und 7 sitzen derart am Absatz 4 auf der OberflÃ¤che 3 des WerkstÃ¼cks 2 auf, dass die radial innere Dichtlippe 7 am tieferen Abschnitt des Absatzes 4 und die Dichtlippe 6 am hÃ¶her gelegenen Abschnitt anliegt. Dies wird dadurch ermÃ¶glicht, dass die Dichtkanten 11 und 12 der beiden Dichtlippen 6 und 7 in unterschiedlichen Ebenen liegen. Der Abstand dieser beiden Ebenen entspricht im Wesentlichen der HÃ¶he des Absatzes 4 des WerkstÃ¼cks 2. Auf diese Weise wird die MÃ¶glichkeit geschaffen, dass mit einem Sauggreifer 1 auch WerkstÃ¼cke 2 gegriffen und angesaugt werden kÃ¶nnen, die keine ebene OberflÃ¤che aufweisen, sondern z.B. mit einem Absatz 4 versehen sind.designed as the radially inner sealing lip 7, which is inclined radially inwards. The two sealing lips 6 and 7 sit on the shoulder 4 on the surface 3 of the workpiece 2 in such a way that the radially inner sealing lip 7 rests on the lower section of the shoulder 4 and the sealing lip 6 rests on the higher section. This is made possible by the fact that the sealing edges 11 and 12 of the two sealing lips 6 and 7 lie in different planes. The distance between these two planes essentially corresponds to the height of the shoulder 4 of the workpiece 2. In this way, it is possible for a suction gripper 1 to also grip and suck workpieces 2 which do not have a flat surface, but are provided with a shoulder 4, for example.

Der in der Figur 1 dargestellte untere Sauggreifer 1' liegt an der Unterseite des WerkstÃ¼cks 2 an und weist ebenfalls einen GrundkÃ¶rper 5 auf, der mit StrÃ¶mungskanÃ¤len 8 versehen ist. Diese Stromungskanale 8 mÃ¼nden ebenfalls in einem Saugraum 9 aus, der von Dichtlippen 6' und 7' abgegrenzt ist. Die Dichtlippe 7' ist direkt an den GrundkÃ¶rper 5 des Sauggreifers 1 angeformt, wohingegen die Dichtlippe 6' von einer ringfÃ¶rmigen Axialschulter 12, welche an der StirnflÃ¤che des GrundkÃ¶rpers 5 vorgesehen ist, abragt. Durch diese MaÃnahme kÃ¶nnen die beiden Dichtlippen 6' und 7' im Wesentlichen gleich ausgebildetThe lower suction gripper 1' shown in Figure 1 rests on the underside of the workpiece 2 and also has a base body 5 which is provided with flow channels 8. These flow channels 8 also open into a suction chamber 9 which is delimited by sealing lips 6' and 7'. The sealing lip 7' is formed directly onto the base body 5 of the suction gripper 1, whereas the sealing lip 6' protrudes from an annular axial shoulder 12 which is provided on the front face of the base body 5. This measure allows the two sealing lips 6' and 7' to be designed essentially the same.

werden, d.h. sie besitzen im Wesentlichen die gleiche LÃ¤nge und ragen im Wesentlichen im gleichen Winkel radial nach auÃen bzw. radial nach innen vom GrundkÃ¶rper 5 bzw. der Axialschulter 12 ab., i.e. they have essentially the same length and protrude essentially at the same angle radially outwards or radially inwards from the base body 5 or the axial shoulder 12.

Der Sauggreifer 1' stellt das GegenstÃ¼ck zum Sauggreifer 1 dar, so dass das WerkstÃ¼ck 2 auf der einen Seite vom Sauggreifer 1 und auf der anderen Seite vom Sauggreifer 1' gegriffen werden kann. Der Sauggreifer 1 weist auf der radial inneren Seite die axial weiter vorstehende Dichtlippe 7 und der Sauggreifer 1' weist auf der radial Ã¤uÃeren Seite die axial weiter vorstehende Dichtlippe 6' auf.The suction gripper 1' represents the counterpart to the suction gripper 1, so that the workpiece 2 can be gripped on one side by the suction gripper 1 and on the other side by the suction gripper 1'. The suction gripper 1 has the axially further protruding sealing lip 7 on the radially inner side and the suction gripper 1' has the axially further protruding sealing lip 6' on the radially outer side.

Es' ist noch nachzutragen, dass auch der Sauggreifer 1' mit Aufsetznoppen 10 bestÃ¼ckt ist, die eine optimale Anlage des Sauggreifers 1' an der unteren OberflÃ¤che des WerkstÃ¼cks 2 gewÃ¤hrleisten. Die AnlageflÃ¤chen der Aufsetznoppen 10 sind rutschhemmend ausgebildet, so dass auch QuerkrÃ¤fte aufgenommen werden kÃ¶nnen.It should also be added that the suction gripper 1' is also equipped with mounting studs 10, which ensure that the suction gripper 1' is optimally positioned on the lower surface of the workpiece 2. The contact surfaces of the mounting studs 10 are designed to be slip-resistant, so that transverse forces can also be absorbed.

Mit dem erfindungsgemÃ¤Ãen Sauggreifer 1 bzw. 1' kÃ¶nnen also WerkstÃ¼cke 2 gegriffen und angesaugt werden, die in ihrer OberflÃ¤che einen Absatz 4 besitzen. Ãber diesen Absatz 4 hinweg kann das WerkstÃ¼ck 2 mit einem Sauggreifer 1 bzw. 1' angesaugt und gehandhabt werden. Ist das WerkstÃ¼ck z.B.With the suction gripper 1 or 1' according to the invention, workpieces 2 that have a shoulder 4 in their surface can be gripped and sucked. The workpiece 2 can be sucked and handled over this shoulder 4 with a suction gripper 1 or 1'. If the workpiece is e.g.

eine DVD, dann besitzt diese DVD einen zentralen Durchbruch 13 fÃ¼r die Aufnahme einer Antriebsachse, wobei sich an den Durchbruch 13 unmittelbar der Absatz 4 anschlieÃt. In geringem Abstand zu diesem Absatz 4 trÃ¤gt die OberflÃ¤che 3 die gespeicherten Daten. FÃ¼r das Handling derartiger WerkstÃ¼cke 2 steht also lediglich ein eng begrenzter Raum zur VerfÃ¼gung, nÃ¤mlich der Bereich zwischen dem Durchbruch 13 und dem die gespeicherten Daten enthaltenden Bereich. Der zum Greifen des WerkstÃ¼cks 2 zur VerfÃ¼gung stehende Bereich ist im vorliegenden Falle mit dem Absatz 4 versehen, so dass der Sauggreifer 1 bzw. 1' an diesen Absatz 4 angepasst werden muss. Durch die erfindungsgemÃ¤Ãe Ausgestaltung besteht nun die MÃ¶glichkeit, auch derartige WerkstÃ¼cke 2 sicher mit einem einzigen Sauggreifer 1 bzw. 1'Â· zu ergreifen.a DVD, then this DVD has a central opening 13 for the accommodation of a drive axle, with the step 4 directly adjoining the opening 13. The surface 3 bears the stored data a short distance from this step 4. For handling such workpieces 2, therefore, only a very limited space is available, namely the area between the opening 13 and the area containing the stored data. In the present case, the area available for gripping the workpiece 2 is provided with the step 4, so that the suction gripper 1 or 1' must be adapted to this step 4. The design according to the invention now makes it possible to also grip such workpieces 2 securely with a single suction gripper 1 or 1'.

## Classifications

- F16B47/00
- B65G47/91
- B65G47/91
- F16B47/00

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
