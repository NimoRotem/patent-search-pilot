# 34. Vacuum holder connecting to work by channel includes work support collared by flexible rubber or plastics seal adapting snugly to work contours on contact.

- **Archive rank:** 34 of 50
- **Publication:** [DE-10023921-A1](https://patents.google.com/patent/DE10023921A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/007642224/publication/DE10023921A1?q=pn%3DDE10023921A1)
- **Publication date:** 2001-11-29
- **Filing date:** 2000-05-17
- **Earliest priority:** 2000-05-17
- **Family:** 7642224
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery

## Parties

- **Applicant / assignee:** GOECKEL KARL; GOECKEL MARTIN
- **Inventors:** GOECKEL KARL; GOECKEL MARTIN

## Abstract

The sucker (3) has a work support (21) and a seal (23) to move flexibly between vacuum channel and work and to adopt work shape once fitted to the surface. The seal wraps round the support pin (21) like a collar and can move round an axis with the support being joined to this by ball or cardan joint in response to servomotors. Seal and support are enclosed in a housing sleeve (20) to be extended and retracted into the sleeve by adjuster motors etc as fitted releasably to the column (16).  The seal should expand in calyx shape on extending from the housing (20) and is made up of a number of overlapping blades or alternatively concertina-ed. The column (16) is extended off a motor (12) assisted by a sensor (25) reporting extension travel.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-10023921-A1/ops000.png)

![Sketch 1 for DE-10023921-A1](https://nimo.iptorch.com/refdrawing/DE-10023921-A1/ops000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-10023921-A1/ops001.png)

![Sketch 2 for DE-10023921-A1](https://nimo.iptorch.com/refdrawing/DE-10023921-A1/ops001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/DE-10023921-A1/ops002.png)

![Sketch 3 for DE-10023921-A1](https://nimo.iptorch.com/refdrawing/DE-10023921-A1/ops002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/DE-10023921-A1/ops003.png)

![Sketch 4 for DE-10023921-A1](https://nimo.iptorch.com/refdrawing/DE-10023921-A1/ops003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/DE-10023921-A1/ops004.png)

![Sketch 5 for DE-10023921-A1](https://nimo.iptorch.com/refdrawing/DE-10023921-A1/ops004.png)

## Claims

### Claim 1 (independent)

Vorrichtung zum Halten eines flächigen Gegenstands durch Ansaugen des­ selben, mit wenigstens einem Vakuumansaugelement, das mit Unterdruck beaufschlagbar ist, der über einen Vakuumkanal an das Werkstück anleg­ bar ist, dadurch gekennzeichnet, dass das Vakuumansaugelement (3) ein den Gegenstand (39) tragendes Auflageelement (21) und ein den Vakuum­ kanal zum Gegenstand (39) hin abdichtendes Dichtelement (23) aufweist, die mittels wenigstens eines Bewegungsmittels (12, 31) zum Anlegen an den Gegenstand (39) bei gleichzeitiger Verlängerung des Vakuumkanals ausfahrbar sind, wobei das Dichtelement (23) flexibel ist und sich beim An­ legen an den Gegenstand (39) der Form der Anlagefläche (38) anpasst.1. Device for holding a flat object by sucking the same, with at least one vacuum suction element which can be subjected to negative pressure, which can be applied to the workpiece via a vacuum channel, characterized in that the vacuum suction element ( 3 ) has an object ( 39 ). bearing support element ( 21 ) and a vacuum channel to the object ( 39 ) sealing sealing element ( 23 ) which can be extended by means of at least one movement means ( 12 , 31 ) for contact with the object ( 39 ) while simultaneously extending the vacuum channel, wherein the sealing element ( 23 ) is flexible and adapts to the object ( 39 ) of the shape of the contact surface ( 38 ).

### Claim 2

Vorrichtung nach Anspruch 1, dadurch gekennzeichnet, dass das Dichtele­ ment das vorzugsweise zapfenförmige Auflageelement manschettenartig umgibt.2. Device according to claim 1, characterized in that the Dichtele ment the preferably pin-shaped support element cuff-like surrounds.

### Claim 3

Vorrichtung nach Anspruch 1 oder 2, dadurch gekennzeichnet, dass das Auflageelement (21) und das Dichtelement (23) gemeinsam um wenigstens eine Achse verschwenkbar sind.3. Device according to claim 1 or 2, characterized in that the support element ( 21 ) and the sealing element ( 23 ) can be pivoted together about at least one axis.

### Claim 4

Vorrichtung nach Anspruch 3, dadurch gekennzeichnet, dass das Auflage­ element (21) und das Dichtelement (23) mittels eines Kugelgelenks (27) o­ der eines Kardangelenks gemeinsam gelagert sind.4. The device according to claim 3, characterized in that the support element ( 21 ) and the sealing element ( 23 ) by means of a ball joint ( 27 ) o that of a universal joint are mounted together.

### Claim 5

Vorrichtung nach Anspruch 3 oder 4, dadurch gekennzeichnet, dass das Auflageelement (21) und das Dichtelement (23) manuell verschenkbar sind.5. The device according to claim 3 or 4, characterized in that the support element ( 21 ) and the sealing element ( 23 ) can be given away manually.

### Claim 6

Vorrichtung nach einem der Ansprüche 3 bis 5, dadurch gekennzeichnet, dass das Auflageelement (21) und das Dichtelement (23) mittels geeigneter Stellelemente (28) automatisch verschwenkbar sind. Device according to one of claims 3 to 5, characterized in that the support element ( 21 ) and the sealing element ( 23 ) by means of suitable adjusting elements ( 28 ) are automatically pivotable.

### Claim 7

Vorrichtung nach Anspruch 6, dadurch gekennzeichnet, dass die Stellele­ mente (28) Elektromotoren, insbesondere Servomotoren sind.7. The device according to claim 6, characterized in that the Stellele elements ( 28 ) are electric motors, in particular servomotors.

### Claim 8

Vorrichtung nach einem der vorangehenden Ansprüche, dadurch gekenn­ zeichnet, dass das Auflageelement und das Dichtelement in oder an einer rohr- oder hülsenartigen Säule angeordnet sind, die mittels eines Bewe­ gungsmittels ausfahrbar ist.8. Device according to one of the preceding claims, characterized records that the support element and the sealing element in or on a tubular or sleeve-like column are arranged by means of a movement means is extendable.

### Claim 9

Vorrichtung nach einem der vorangehenden Ansprüche, dadurch gekenn­ zeichnet, dass das Auflageelement (21) und das Dichtelement (23) in einem rohr- oder hülsenartigen Gehäuse (20) aufgenommen sind, aus dem und in das sie mittels eines Bewegungsmittels (31) bewegbar sind.9. Device according to one of the preceding claims, characterized in that the support element ( 21 ) and the sealing element ( 23 ) are accommodated in a tubular or sleeve-like housing ( 20 ) from and into which they are moved by means of a movement means ( 31 ). are movable.

### Claim 10

Vorrichtung nach Anspruch 9, dadurch gekennzeichnet, dass das Gehäuse (20) ein separates Gehäuse ist, das gegebenenfalls auch die Stellelemente (28) und das Bewegungsmittel (31) umfasst, und das lösbar an der Säule (16) angeordnet ist, oder dass das Gehäuse die Säule selbst ist, die gege­ benenfalls auch die Stellelemente und das Bewegungsmittel umfasst.10. The device according to claim 9, characterized in that the housing ( 20 ) is a separate housing, which optionally also includes the adjusting elements ( 28 ) and the movement means ( 31 ), and which is detachably arranged on the column ( 16 ), or that the housing is the column itself, which optionally also includes the control elements and the movement means.

### Claim 11

Vorrichtung nach einem der Ansprüche 8 bis 10, dadurch gekennzeichnet, dass die Säule (16) zwischen einer Einfahr- und einer Ausfahrendstellung bewegbar und in jeder dazwischenliegenden Position arretierbar ist.11. Device according to one of claims 8 to 10, characterized in that the column ( 16 ) is movable between a retracted and an extended position and can be locked in any intermediate position.

### Claim 12

Vorrichtung nach einem der Ansprüche 9 bis 11, dadurch gekennzeichnet, dass das Dichtelement (23) derart ausgebildet ist, dass es sich beim Aus­ fahren aus dem Gehäuse (20) von selbst kelchartig im Durchmesser er­ weitert.12. Device according to one of claims 9 to 11, characterized in that the sealing element ( 23 ) is designed such that it extends from the housing ( 20 ) by itself goblet-like in diameter when it extends.

### Claim 13

Vorrichtung nach einem der vorangehenden Ansprüche, dadurch gekenn­ zeichnet, dass das Dichtmittel (23) zieharmonikaartig gefaltet ist. Device according to one of the preceding claims, characterized in that the sealing means ( 23 ) is folded like an accordion.

### Claim 14

Vorrichtung nach einem der Ansprüche 1 bis 12, dadurch gekennzeichnet, dass das Dichtmittel (23) eine Dichtlamelle mit mehreren einander überlap­ pender Einzellamellen (33) ist.14. Device according to one of claims 1 to 12, characterized in that the sealing means ( 23 ) is a sealing lamella with a plurality of overlapping individual lamellae ( 33 ).

### Claim 15

Vorrichtung nach einem der vorangehenden Ansprüche, dadurch gekenn­ zeichnet, dass das Dichtelement (23) aus Gummi oder Kunststoff ist.15. Device according to one of the preceding claims, characterized in that the sealing element ( 23 ) is made of rubber or plastic.

### Claim 16

Vorrichtung nach einem der vorangehenden Ansprüche, dadurch gekenn­ zeichnet, dass als zum Ausfahren des Auflageelements (21) und des Dichtmittels (23) ein Elektromotor (12, 31) ein pneumatisches oder ein hyd­ raulisches Bewegungsmittel vorgesehen ist, der oder das über eine Steue­ rungseinrichtung (44) steuerbar ist.16. Device according to one of the preceding claims, characterized in that as for extending the support element ( 21 ) and the sealing means ( 23 ), an electric motor ( 12 , 31 ) is provided a pneumatic or a hydraulic movement means, or the one Control device ( 44 ) is controllable.

### Claim 17

Vorrichtung nach Anspruch 16, dadurch gekennzeichnet, dass als Bewe­ gungsmittel zum Ausfahren der Säule (16) ein Elektromotor (12) vorgese­ hen ist.17. The apparatus according to claim 16, characterized in that an electric motor ( 12 ) is provided as a moving means for extending the column ( 16 ).

### Claim 18

Vorrichtung nach Anspruch 17, dadurch gekennzeichnet, dass der Elektro­ motor (12) eine Gewindespindel (15) antreibt, die mit der Säule (16) in einer Spindelaufnahme (17) gekoppelt ist.18. The apparatus according to claim 17, characterized in that the electric motor ( 12 ) drives a threaded spindle ( 15 ) which is coupled to the column ( 16 ) in a spindle holder ( 17 ).

### Claim 19

Vorrichtung nach Anspruch 18, dadurch gekennzeichnet, dass die Gewin­ despindel (15) außermittig in der Spindelaufnahme (17) geführt ist.19. The apparatus according to claim 18, characterized in that the threaded despindel ( 15 ) is guided off-center in the spindle receptacle ( 17 ).

### Claim 20

Vorrichtung nach Anspruch 16, dadurch gekennzeichnet, dass als Bewe­ gungsmittel zum Bewegen des Auflageelements (21) und des Dichtmittels (23) aus und in das Gehäuse (20) ein Elektromotor (31), insbesondere ein Servomotor vorgesehen ist.20. The apparatus according to claim 16, characterized in that an electric motor ( 31 ), in particular a servo motor, is provided as a moving means for moving the support element ( 21 ) and the sealing means ( 23 ) out of and into the housing ( 20 ).

### Claim 21

Vorrichtung nach einem der vorangehenden Ansprüche, dadurch gekenn­ zeichnet, dass wenigstens ein mit einer Steuerungseinrichtung (44) ver­ bindbares oder verbundenes Sensorelement (25, 41) zum direkten oder in­ direkten Erfassen der Position des Auflageelements (21) vorgesehen ist. Device according to one of the preceding claims, characterized in that at least one with a control device ( 44 ) ver bindable or connected sensor element ( 25 , 41 ) is provided for directly or in direct detection of the position of the support element ( 21 ).

### Claim 22

Vorrichtung nach Anspruch 21, dadurch gekennzeichnet, dass das Sensor­ element (25, 41) ein Wegaufnehmer ist, mittels dem der Bewegungsweg beim Ausfahren erfasst wird.22. The apparatus according to claim 21, characterized in that the sensor element ( 25 , 41 ) is a displacement sensor, by means of which the movement path is detected when extending.

### Claim 23

Vorrichtung nach einem der vorangehenden Ansprüche, dadurch gekenn­ zeichnet, dass mehrere Vakuumansaugelemente (3) vorgesehen sind, die über eine gemeinsame Steuerungseinrichtung (44) separat ansteuerbar sind.23. Device according to one of the preceding claims, characterized in that a plurality of vacuum suction elements ( 3 ) are provided, which can be controlled separately via a common control device ( 44 ).

### Claim 24

Vorrichtung nach einem der vorangehenden Ansprüche, dadurch gekenn­ zeichnet, dass in der Steuerungseinrichtung (44) eine beliebige Position ei­ nes Auflageelements (21) speicherbar ist, und dass im Bedarfsfall das oder die Bewegungsmittel (12, 28, 31) eines Vakuumansaugelements (3) derart ansteuerbar sind, dass das Auflageelement (21) automatisch in die gespei­ cherte Position bringbar ist.24. Device according to one of the preceding claims, characterized in that in the control device ( 44 ) any position of a support element ( 21 ) can be stored, and that, if necessary, the movement means ( 12 , 28 , 31 ) of a vacuum suction element ( 3 ) can be controlled such that the support element ( 21 ) can be automatically brought into the stored position.

### Claim 25

Vorrichtung nach Anspruch 23 oder 24, dadurch gekennzeichnet, dass ein gemeinsamer, gegebenenfalls netzartiger Vakuumkanal (8) vorgesehen ist, mit dem die Vakuumkanäle (24) der Vakuumansaugelemente (3) verbun­ den oder verbindbar sind.25. The device according to claim 23 or 24, characterized in that a common, optionally network-like vacuum channel ( 8 ) is provided with which the vacuum channels ( 24 ) of the vacuum suction elements ( 3 ) are connected or connectable.

### Claim 26

Vorrichtung nach Anspruch 25, dadurch gekennzeichnet, dass die Verbin­ dung des Vakuumkanals (24) des Vakuumansaugelements (3) mit dem ge­ gebenenfalls netzartigen Vakuumkanal (8) über ein Sperrelement (11) ge­ öffnet oder geschlossen werden kann, oder dass die Verbindung erst wäh­ rend des Ausfahren bei Erreichen einer bestimmten Ausfahrposition herge­ stellt wird.26. The apparatus according to claim 25, characterized in that the connec tion of the vacuum channel ( 24 ) of the vacuum suction element ( 3 ) with the optionally network-like vacuum channel ( 8 ) via a locking element ( 11 ) can be opened or closed, or that the connection is only produced during the extension when a certain extension position is reached.

### Claim 27

Vorrichtung nach einem der vorangehenden Ansprüche, dadurch gekenn­ zeichnet, dass ein Vakuumkanal (8) vorgesehen ist, mit dem das oder die Vakuumansaugelemente (3) verbunden oder verbindbar sind, und dass Verbindungs- und/oder Anschlussmittel (42) vorgesehen sind, mittels denen die Vakuumkanäle zweier Vorrichtungen (1) miteinander verbindbar sind.27. Device according to one of the preceding claims, characterized in that a vacuum channel ( 8 ) is provided, with which the vacuum suction element (s) ( 3 ) are connected or can be connected, and that connection and / or connection means ( 42 ) are provided, by means of which the vacuum channels of two devices ( 1 ) can be connected to one another.

### Claim 28

Vorrichtung nach Anspruch 27, dadurch gekennzeichnet, dass die Verbin­ dungs- und/oder Anschlussmittel (42) derart ausgebildet sind, dass die Ver­ bindung der Vakuumkanäle (8) beim direkten Aneinanderstellen der Vor­ richtungen (1) automatisch hergestellt wird.28. The apparatus according to claim 27, characterized in that the connection and / or connection means ( 42 ) are designed such that the connection of the vacuum channels ( 8 ) is automatically established when the devices ( 1 ) are placed directly next to one another.

### Claim 29

Vorrichtung nach einem der vorangehenden Ansprüche, dadurch gekenn­ zeichnet, dass das oder jedes Vakuumsaugelement (3) lösbar in eine ge­ eignete Aufnahme (4) eines Vorrichtungsgehäuses (2) einsteckbar ist, und dass mit Erreichen der Einsteckentstellung automatisch das oder die Be­ wegungsmittel (12, 28, 31) mit entsprechenden Versorgungs- und/oder Steuerleitungen koppelbar sind.29. Device according to one of the preceding claims, characterized in that the or each vacuum suction element ( 3 ) is releasably insertable into a suitable receptacle ( 4 ) of a device housing ( 2 ), and that when the insertion position is reached, the movement means or the loading means are automatically ( 12 , 28 , 31 ) can be coupled with corresponding supply and / or control lines.

### Claim 30

Vorrichtung nach Anspruch 29, dadurch gekennzeichnet, dass eine Leiter­ bahnen aufweisende Platine (14) mit Steckeraufnahmen vorgesehen ist, und dass an dem oder jedem Vakuumsaugelement (3) ein oder mehrere Kontaktstecker (13) vorgesehen sind, die beim Einstecken in die Stecker­ aufnahmen eingreifen.30. The device according to claim 29, characterized in that a printed circuit board ( 14 ) is provided with plug receptacles, and that on the or each vacuum suction element ( 3 ) one or more contact plugs ( 13 ) are provided, which when inserted into the plug Intervene recordings.

### Claim 31

Vorrichtung nach einem der vorangehenden Ansprüche, dadurch gekenn­ zeichnet, dass Verbindungs- und/oder Anschlussmittel (43) vorgesehen sind, mittels denen die Versorgungs- und/oder Steuerleitungen zweier Vor­ richtungen (1) verbindbar sind.31. Device according to one of the preceding claims, characterized in that connection and / or connection means ( 43 ) are provided, by means of which the supply and / or control lines of two devices ( 1 ) can be connected.

### Claim 32

Vorrichtung nach Anspruch 31, dadurch gekennzeichnet, dass die Verbin­ dungs- und/oder Anschlussmittel (43) derart ausgebildet sind, dass die Ver­ bindung beim direkten Aneinanderstellen der Vorrichtungen (1) automatisch hergestellt wird.32. Device according to claim 31, characterized in that the connection and / or connection means ( 43 ) are designed such that the connection is established automatically when the devices ( 1 ) are placed directly next to one another.

### Claim 33

Vorrichtung nach einem der vorangehenden Ansprüche, dadurch geken­ nzeichnet, dass die Steuerungseinrichtung (44) die Vakuumansaugelemente (3) bzw. die Auflageelemente (21) in Abhängigkeit bekannter Form- und/oder Oberflächendaten eines aufzunehmenden Gegenstands in ge­ genstandsbezogene Position steuert.33. Device according to one of the preceding claims, characterized in that the control device ( 44 ) controls the vacuum suction elements ( 3 ) or the support elements ( 21 ) depending on known shape and / or surface data of an object to be picked up in an object-related position.

### Claim 34

Vorrichtung nach Anspruch 33, dadurch gekennzeichnet, dass Mittel (46) zum Erfassen einer Kennung (45) eines aufzunehmenden Gegenstands (39) vorgesehen sind, die mit der Steuerungseinrichtung (44) kommunizie­ ren, und dass die Steuerungseinrichtung (44) die Vakuumsaugelemente (3) in Abhängigkeit des erfassten Gegenstands (3) in vorbestimmte, gegens­ tandsbezogene Stellungen steuert.34. Apparatus according to claim 33, characterized in that means ( 46 ) for detecting an identifier ( 45 ) of an object ( 39 ) are provided, which communicate with the control device ( 44 ), and that the control device ( 44 ) the vacuum suction elements ( 3 ) depending on the detected object ( 3 ) in predetermined, mutually related positions controls.

### Claim 35

Vorrichtung nach Anspruch 34, dadurch gekennzeichnet, dass die Mittel (46) als Barcodeleser oder als Transponderleser ausgebildet sind.35. Apparatus according to claim 34, characterized in that the means ( 46 ) are designed as barcode readers or as transponder readers.

### Claim 36

Vorrichtung nach Anspruch 34, dadurch gekennzeichnet, dass die Mittel wenigstens eine Kameraeinrichtung zum Aufnehmen des Gegenstands umfassen, die mit der Steuerungseinrichtung, die ein Mittel zum Verarbeiten des aufgenommenen Bilds zum Erkennen des Gegenstands und/oder des­ sen Oberflächenform aufweist, kommuniziert.36. Device according to claim 34, characterized in that the means at least one camera device for picking up the object include, with the controller, which is a means of processing the captured image to recognize the object and / or the sen surface shape, communicates.

### Claim 37

Vorrichtung nach einen der vorangehenden Ansprüche, dadurch gekenn­ zeichnet, dass sie mehrere Vakuumansaugelemente umfasst, die zumin­ dest teilweise gruppenweise mittels einer jeder Gruppe zugeordneten moto­ rischen x-y-Bewegungseinrichtung gesteuert verfahrbar sind.37. Device according to one of the preceding claims, characterized records that it comprises several vacuum suction elements, which at least at least partially in groups by means of a moto assigned to each group Rischen x-y movement device can be moved controlled.

### Claim 38

Vorrichtung nach einem der vorangehenden Ansprüche, dadurch gekenn­ zeichnet, dass mehrere Vakuumansaugelemente (3) vorgesehen sind, die in einem gemeinsamen Vorrichtungsgestell gehaltert sind, wobei die Aufla­ geelemente (21) und die Dichtelemente (23) der in einer gemeinsamen E­ bene angeordneten Vakuumansaugelemente in beliebige Höhenpositionen zwischen einer Einfahr- und einer Ausfahrendstellung von einer zentralen Steuerungseinrichtung gesteuert bringbar und arretierbar sind. Device according to one of the preceding claims, characterized in that a plurality of vacuum suction elements ( 3 ) are provided which are held in a common device frame, the Aufla geelemente ( 21 ) and the sealing elements ( 23 ) arranged in a common plane Vacuum suction elements can be brought and locked in a controlled manner by a central control device into any height positions between an entry and an exit end position.

### Claim 39

Anordnung zum Halten eines flächigen Gegenstands durch Ansaugen des­ selben, umfassend mehrere Vorrichtungen mit jeweils einem oder mehreren Vakuumansaugelementen nach einem der Ansprüche 1 bis 38, sowie eine zentrale, den Betrieb der Vorrichtungen steuernden Steuerungseinrichtung.39. Arrangement for holding a flat object by suction of the same, comprising several devices, each with one or more Vacuum suction elements according to one of claims 1 to 38, and a central control device controlling the operation of the devices.

### Claim 40

Anordnung nach Anspruch 39, dadurch gekennzeichnet, dass die Steue­ rungseinrichtung zum automatischen Einstellen der Vakuumansaugele­ mente in eine gegenstandsbezogene Position in Abhängigkeit einer einge­ gebenen oder erfassten Gegenstandsinformation ausgebildet ist.40. Arrangement according to claim 39, characterized in that the tax Rungseinrichtung for automatic adjustment of the vacuum suction elements in an item-related position depending on one given or recorded object information is formed.

### Claim 41

Anordnung nach Anspruch 40, dadurch gekennzeichnet, dass Mittel zum Erfassen einer Kennung eines aufzunehmenden Gegenstands vorgesehen sind, die mit der Steuerungseinrichtung kommunizieren.41. Arrangement according to claim 40, characterized in that means for Detection of an identifier of an object to be recorded is provided are communicating with the control device.

### Claim 42

Anordnung nach Anspruch 41, dadurch gekennzeichnet, dass die Mittel als Barcodeleser oder als Transponderleser ausgebildet sind.42. Arrangement according to claim 41, characterized in that the means as Barcode readers or designed as transponder readers.

### Claim 43

Anordnung nach Anspruch 41, dadurch gekennzeichnet, dass die Mittel wenigstens eine Kameraeinrichtung zum Aufnehmen des Gegenstands umfassen, die mit der Steuerungseinrichtung, die ein Mittel zum Verarbeiten des aufgenommenen Bilds zum Erkennen des Gegenstands und/oder des­ sen Oberflächenform aufweist, kommuniziert.43. Arrangement according to claim 41, characterized in that the means at least one camera device for picking up the object include, with the controller, which is a means of processing the captured image to recognize the object and / or the sen surface shape, communicates.

### Claim 44

Einrichtung zum lösbaren Aufsetzen auf eine Säule einer Vorrichtung nach einem der Ansprüche 1 bis 38, mit einem Verbindungsmittel zum Anbringen an der Säule aufweisenden Gehäuse, in dem ein Auflageelement und ein das Auflageelement umgebendes flexibles Dichtelement vorgesehen sind, die mittels eines im Gehäuse integrierten Bewegungsmittel (31) aus dem Gehäuse zur Anlage an eine Anlagefläche gemeinsam ausfahrbar sind. Device for detachable placement on a column of a device according to one of claims 1 to 38, with a connecting means for attachment to the column having housing, in which a support element and a flexible sealing element surrounding the support element are provided, which are integrated by means of a housing Movement means ( 31 ) can be extended together out of the housing for bearing against a contact surface.

### Claim 45

Einrichtung nach Anspruch 44, dadurch gekennzeichnet, dass das Auflage­ element (21) und das Dichtelement (23) gemeinsam um wenigstens eine Achse verschwenkbar sind.45. Device according to claim 44, characterized in that the support element ( 21 ) and the sealing element ( 23 ) can be pivoted together about at least one axis.

### Claim 46

Einrichtung nach Anspruch 45, dadurch gekennzeichnet, dass das Auflage­ element (21) und das Dichtelement (23) mittels eines Kugelgelenks (27) o­ der eines Kardangelenks gemeinsam gelagert sind.46. Device according to claim 45, characterized in that the support element ( 21 ) and the sealing element ( 23 ) by means of a ball joint ( 27 ) o that of a universal joint are mounted together.

### Claim 47

Einrichtung nach Anspruch 45 oder 46, dadurch gekennzeichnet, dass das Auflageelement (21) und das Dichtelement (23) manuell verschwenkbar sind.47. Device according to claim 45 or 46, characterized in that the support element ( 21 ) and the sealing element ( 23 ) can be pivoted manually.

### Claim 48

Einrichtung nach einem der Ansprüche 45 bis 47, dadurch gekennzeichnet, dass das Auflageelement (21) und das Dichtelement (23) mittels geeigne­ ter, im Gehäuse integrierter Stellelemente (28) automatisch verschwenkbar sind.48. Device according to one of claims 45 to 47, characterized in that the support element ( 21 ) and the sealing element ( 23 ) by means of suitable ter, integrated in the housing adjusting elements ( 28 ) are automatically pivotable.

### Claim 49

Einrichtung nach Anspruch 48, dadurch gekennzeichnet, dass die Stellele­ mente (28) Elektromotoren, insbesondere Servomotoren sind.49. Device according to claim 48, characterized in that the adjusting elements ( 28 ) are electric motors, in particular servomotors.

### Claim 50

Einrichtung nach einem der Ansprüche 44 bis 49, dadurch gekennzeichnet, dass das Dichtelement (23) derart ausgebildet ist, dass es sich beim Aus­ fahren aus dem Gehäuse (20) von selbst kelchartig im Durchmesser er­ weitert.50. Device according to one of claims 44 to 49, characterized in that the sealing element ( 23 ) is designed such that it extends from the housing ( 20 ) by itself goblet-like in diameter when it moves out.

### Claim 51

Einrichtung nach einem der Ansprüche 44 bis 50, dadurch gekennzeichnet, dass das Dichtmittel (23) zieharmonikaartig gefaltet ist.51. Device according to one of claims 44 to 50, characterized in that the sealing means ( 23 ) is folded like an accordion.

### Claim 52

Einrichtung nach einem der Ansprüche 44 bis 50, dadurch gekennzeichnet, dass das Dichtmittel (23) eine Dichtlamelle mit mehreren einander überlap­ pender Einzellamellen (33) ist. Device according to one of claims 44 to 50, characterized in that the sealing means ( 23 ) is a sealing lamella with a plurality of overlapping individual lamellae ( 33 ).

### Claim 53

Einrichtung nach einem der Ansprüche 44 bis 52, dadurch gekennzeichnet, dass das Dichtelement (23) aus Gummi oder Kunststoff ist.53. Device according to one of claims 44 to 52, characterized in that the sealing element ( 23 ) is made of rubber or plastic.

### Claim 54

Einrichtung nach einem der Ansprüche 44 bis 53, dadurch gekennzeichnet, dass als zum Ausfahren des Auflageelements (21) und des Dichtmittels (23) als Betätigungsmittel ein Elektromotor (31) vorgesehen ist.54. Device according to one of claims 44 to 53, characterized in that an electric motor ( 31 ) is provided as the actuating means for extending the support element ( 21 ) and the sealing means ( 23 ).

## Full description

The invention relates to a device for holding a flat object by sucking the same, with at least one vacuum suction element, the can be acted upon with negative pressure, which is applied to the workpiece via a vacuum channel can be created.

The processing of a workpiece, for example a wooden plate with a Tool on a machine tool requires the workpiece to tighten firmly so that it does not slip when editing. For this come to using vacuum clamping devices, by means of which the factory piece is clamped by suction. The tensioning device or its vacuum Umansaugelemente are preferably connected to a central vacuum source the one that creates the required vacuum. This is via valve elements passed on to the workpiece. This is a secure fixation of the work possible. Such tensioners can be table or console-like be formed and form part of the machine tool itself, that is, their work table or work consoles are made from such a front direction itself formed. Alternatively, it is also possible to use such devices as To design separate attachments that work on an existing one table or an existing work console of a machine tool ne put on. The holder of these devices can also by means Negative pressure take place, for which the underside of the same is designed accordingly.

In addition to holding for the purpose of processing an object, there are such directions but also used as transport devices. Here too the Object sucked and held by means of the vacuum suction element or elements tert, the device is then, for example by means of a crane or a Move portals or the like together with the suctioned object.

Known devices are only for holding objects with a flat, two-dimensional contact surface for the vacuum suction gel ment trained. The mounting of uneven objects is with such devices  not possible. On a secure mount of such uneven Ge objects, for example in the field of processing high-quality objects made of plastic, wood or metal (e.g. aluminum) (as an example, the aircraft construction, where larger objects made of metal or plastic are often used, also processed composite material), where often bent, if necessary to process multilayer structures using a machine tool are involved, but there is increased interest.

The invention is therefore based on the problem of specifying a device which the holding of such objects.

To solve this problem in a device of the type mentioned According to the invention provided that the vacuum suction element a Ge object supporting element and a vacuum channel to the object has sealing sealing element, which by means of at least one movement agent for application to the object with simultaneous extension of the vacuum channel can be extended, the sealing element being flexible or one has a flexible sealing surface and when applied to the object of the form adapts to the contact surface.

In the device according to the invention, the vacuum suction element is on the one hand extend to a maximum length using a suitable movement device bar to adapt to the shape of the item. Next to it is a Ge object attacking or supporting support element, preferably a zap fen - shaped element, and a surrounding it, the vacuum channel - the at Extension of the vacuum suction element is of course also extended - to the object sealing, preferably sleeve-like seal ment provided, the sealing element having a flexible sealing surface, the adapts when creating the contact surface. With such a device - which are designed as a single device with a single vacuum element can, wherein for clamping a larger object several such Devices are placed side by side or distributed, or the themselves has several vacuum suction elements - so it is in two respects  possible to adapt to the object, namely once by appropriate Extension of the vacuum suction element, on the other hand through a flexible ab sealing possibility, so that also a contact surface, which is under one of the Hori zontal deviating angle to the sealing surface of the sealing element is secure can be sealed. For example, the device comprises several sol cher vacuum suction elements, such as a curved one can easily Carrier or a curved plate can be stretched because the vacuum suction elements can be positioned anywhere and the curved object surface to adjust. It is therefore possible with particular advantage, even three-dimensional To be able to hold objects with the device according to the invention since the possibility of extending one "following the contact surface of the object suction surface "can be set. The control of the movement means follows via a suitable control device, operation on the one hand can be that an object to be held is initially on the device side provided conditions, on which it only rests, is set up, after which The moving means and the vacuum are controlled by the control suction elements are extended and brought into contact, alternatively it is conceivable, the vacuum suction elements before picking up the object in a to move the item-specific position, and then move the item into the Use vacuum suction elements.

On the one hand, the adaptability of the support element and the sealing element promote and on the other hand to give the possibility that the support element and the sealing element can be placed as vertically as possible on the support surface it has proven to be advantageous if the support element and the sealing element either swiveled manually or automatically using suitable control elements are cash. As a result, the support element and the sealing element before opening set the item accordingly, so that it is possible stand perpendicular to the contact surface. The control elements overlap, for example suitable tie rods on a common, the support element and the Sealing elements bearing bearing plate or the like, which by means of the Stell elements, for example in the form of electric motors, in particular servomotors ren, and the tie rods can be pivoted accordingly. It should  the support element and the sealing element together around at least one axis be pivotable, but it is particularly useful if the support ment and the sealing element by means of a ball joint or a universal joint are stored together so that they can be pivoted about any axis that can.

It is particularly useful if the support element and the sealing element in or are arranged on a tubular or sleeve-like column, which by means of a Movement means is extendable. In this embodiment, the sleeve that forms part of the vacuum channel and extends it by means of the movement means are extended, which also means the support element and the sealing element are extended. Alternatively, there is the possibility ability that the support element and the sealing element in a tube or sleeve like housing are recorded, from and into which they by means of a movement means are movable. In this embodiment, the support element and the sealing element inside the housing and can with a suitable means of movement from the housing the. The elements are therefore inserted into the housing when they are not required drive and are only conveyed out when this is necessary. In contrast for this purpose, the support element and in the above-described embodiment the sealing element "exposed" on the column. A special purpose moderate design of the invention sees a combination of the two designs tion forms such that the housing is a separate housing, the opposite also includes the control elements and the moving means, and that is detachably arranged on the column, or that the housing is the column itself, which optionally also includes the adjusting elements and the movement means. At In this embodiment, two movement means are used, namely one for moving the column and the other for moving the column in and out Support and sealing element if these are required. Particularly useful is the detachable arrangement of a separate, the support and the sealing element containing housing, in which also the control elements and the separate Bewe is arranged. Because in the event of damage, for example Sealing element is a simple exchange by removing the housing and  A new housing can be placed on the column below. The column itself can be moved between a retracted and an extended position bar and can be locked in any position in between to accommodate the to hold a secure object, also the support element.

A particularly useful embodiment of the invention provides that the seal element is designed in such a way that it extends from the housing automatically expanded in the shape of a goblet. The further the sealing element extends is driven, the larger the diameter and thus the suction surface, so that this can also increase the suction force. A suitable for this According to the invention, the sealant can be folded like an accordion, an age native provides for the sealant to act as a sealing lamella with several overlap overlapping individual lamellae is formed. The sealant can be rubber or a suitable plastic.

As a means of movement for extending the support element and the sealing element can generally be an electric motor, a pneumatic or a hydraulic loading Means of movement may be provided, which or via a control device is controllable. To extend the column, an electric motor is expediently used gate, preferably also a servo motor, is used here. This drives according to the invention a threaded spindle, which is coupled to the column in a spindle holder, the threaded spindle preferably being guided off-center in the spindle receptacle to prevent the column from rotating when it is extended or retracted. Also for moving the support element and the sealant out of and into it The housing is expediently an electric motor, in particular a servomotor intended.

As described, it is possible with the device according to the invention, the or the vacuum suction elements of the device before picking up the object to bring it into an object-related basic position. To this or that Reaching the same has proven to be useful if we at least one sensor element that can be connected to the control device for di direct or indirect detection of the position of the support element is provided.

Since the support element carries the object, and consequently its position determined, the detection of the position of the same is sufficient. More appropriate a displacement sensor is used as the sensor element, by means of which the loading path of travel is recorded when extending. In the event that both the pillar and the support element can also be moved separately, and accordingly there are several To provide sensor elements that communicate with the control device, the control device using the given signals to determine the exact actual position of the support element is formed.

If the device has several vacuum suction elements, these are expediently separately via a common control device controllable. The device can have any number of vacuum suction elements. For example, it can include four such elements, with the size being large Outer contact surfaces correspondingly many devices placed side by side or be placed accordingly. Of course, it is also possible to have a very large one To design device with several hundred vacuum suction elements, wherein in this case, each element individually via the control device can be controlled.

It is particularly expedient if any one in the control device Position of a support element can be stored, if necessary the or Movement means of a vacuum suction element can be controlled such that the support element can be brought automatically into the stored position. This Design of the invention makes it possible for control device-stored Basic positions of the vacuum suction elements or the support elements fen and set them up accordingly, for example, if it is known which wel cher object or which workpiece is to be placed next.

If several vacuum suction elements are provided, it is expedient only a common, possibly network-like vacuum channel is provided, with which the vacuum channels of the vacuum suction elements communicate. At the This device is advantageously only a vacuum source required in ge entire, possibly network-like vacuum channel creates a negative pressure. On  all vacuum channels of the vacuum suction elements hang from the vacuum channel te, which are pressurized with vacuum if necessary. To connect the Vacuum channel of the vacuum suction element with the optionally network-like Vacuum channel is expediently provided a locking element, which ge can be opened and closed. Alternatively, it is also possible that the connection only during the extension when reaching a certain one Extend position is established. So with this alternative of the invention only the vacuum channels of the vacuum suction elements with the central vacuum channel connected, which are actually extended and are therefore required. Because all other vacuum suction elements that are not required are not extended and remain in their rest position.

In the event that several devices are used to form a larger contact surface to be placed side by side or adjacent to each other, it turned out to be Proven useful if a vacuum channel is provided with which the or the vacuum suction elements are connected or connectable, with connection and / or connection means are provided, by means of which the vacuum channels two devices can be connected to each other. Because of the optional Coupling the vacuum channels of the individual devices, it is possible to the Un terdruck from device to device "to loop through", so that also with the only one vacuum source is required. The Connection and / or connection means can be designed such that the connection of the vacuum channels when the device is placed next to one another auto is manufactured matically. The agents can be used as suitable plug-socket Combinations or the like can be executed. If the devices - do not care whether each device contains only one or more vacuum elements - removed from are positioned one above the other, they are connected via corresponding hoses to the the connection and / or connection means can be connected, verbun the.

According to an advantageous development of the concept of the invention can be pre- can be seen that the or each vacuum suction element releasably into a suitable Recording a device housing can be inserted, and that with reaching  the insertion position automatically corresponds to the means of movement Appropriate supply and / or control lines can be coupled. According to this According to the invention, the device has a quasi modular structure and exists from a frame or housing-like device frame on which one or several - depending on the number of vacuum suction elements that can be used Men are provided in which such an element can be inserted. At the When plugged in, contact is made automatically with the supply and / or Control lines, depending on the type of movement delt. This modular design enables, for example, larger, several devices with vacuum suction elements, only in these insert appropriate vacuum suction elements where they are are actually needed. The rest of the pictures are taken with suitable End covers closed and sealed. In addition, this inventions design it too, instead of a vacuum suction element insert another working element, for example an ordinary support or the like, on which an object first before the actual arrival suck is recorded. This support is rigid and is only used for the time being wearing the respective item. However, it is also conceivable to use suitable e to insert electrical, hydraulic or pneumatic lifting elements by means of which an object is picked up and possibly also raised or can be lowered. These lifting elements are also with suitable Ver supply and / or control lines on the device side when plugged in.

In the event that the movement means are designed as electric motors expediently a printed circuit board with plug receptacle Men provided, one or more on the or each vacuum suction element rere contact plugs are provided, which when inserted into the plug receptacle intervene. Are hydraulic or pneumatic cylinders as a means of movement the provided, are on the device side corresponding hydraulic or pneumatic Matikstecker provided on which corresponding on the vacuum suction mating connector can attack. The separate control In this case, suitable switching valves are used, which are or pneumatic circuit are provided.

It is also expedient if connection and / or connection means are provided are seen, by means of which the supply and / or control lines of two ne Devices which can be arranged next to one another or adjacent to one another can be connected are. The connection or connection means can be designed such that the connection automatically when the devices are placed directly next to one another is made, the devices are apart, the means expediently designed for connecting a connecting cable.

As described, it is possible by means of the device according to the invention, a Presetting the vacuum suction elements with respect to a known, subsequent the object to be recorded. On the one hand there is the Possibility that the contours of the object are already in the control direction are stored, and only on the part of the operator to open object to be selected. After selection, the Va vacuum suction elements made automatically on the control side. A purpose In addition or alternatively, the moderate design of the invention provides that Means for acquiring an identifier of an object to be recorded are seen communicating with the control device, the control The vacuum suction elements depending on the detected Ge controls objects in predetermined, object-related positions. The invent The device according to the invention is therefore able to independently open the respective one object to be captured and, depending on the result of the capture Set up vacuum suction elements. The funds can be used as barcode readers or be designed as a transponder reader that is located on the object Chen barcode or transponder and send a corresponding signal to the Control device give where the barcode or transponder information evaluated and the corresponding object is determined. Finally, can as a means at least one camera device for picking up the object be provided with the control device, which is a means of processing th of the captured image to recognize the object and / or its Has surface shape, communicates. With this configuration, the Anla surface of the object in the form of an image, which is then  is evaluated, the device depending on the image evaluation done.

After all, it is with larger devices that have multiple vacuum sucks ment includes, useful if the suction elements together in groups are composed and by means of a motor x-y assigned to each group Movement device, i.e. suitable x and y motors, can be moved in a controlled manner are. This makes it possible to remove the suction element groups from the front if necessary directional compound in the x and / or y direction to move even better to be able to adapt to the shape of the object.

In addition to the device itself, which as described as a single device with single Lich a vacuum suction element or as a multiple device with several, in their number of virtually unlimited vacuum suction elements can be formed, The invention further relates to an arrangement for holding a flat opposite tandes by sucking the same, comprising several devices each one or more suction elements, i.e. several single or multiple directions of the type described above as well as a central, the operation of the pre directional control device. The several separate devices can be placed anywhere on a suitable under table and are ins all controlled by a central control device. The control direction itself is expedient for automatically setting the vacuum Umansaugelemente in an object-related position depending on a entered or captured item information. You can Means for acquiring an identifier of an object to be recorded be seen that communicate with the control device. These funds can according to a first embodiment of the invention as a barcode reader or as Transponder readers can be formed, alternatively they can also be a camera include means for receiving the object, which control is evaluated.

Finally, the invention relates to a device for releasable placement on egg ner column of a device of the type described above, with a connecting means  to be attached to the pillar housing, in which a support element and a flexible, preferably surrounding the support element flexible les sealing element are provided by means of a Be integrated in the housing means of movement out of the housing for bearing against a bearing surface together are extendable. Further advantageous refinements of the devices are the dependent subclaims.

Further advantages, features and details of the inventions result from the embodiment described below and with reference to the drawing nung. Show:

Fig. 1 is a schematic diagram in section of a device according to the invention,

Fig. 2 is a schematic representation of FIG. 1 with extended column,

Fig. 3 is an enlarged schematic diagram of the mounted on the column, the investment and the sealing element comprising a housing,

Fig. 4 is a schematic diagram acc. Fig. 3 with extended supporting and sealing element,

Fig. 5 is a schematic diagram according to. Fig. 4 with pivoted support and sealing elements which rest on a curved object, and

Fig. 6 is a schematic diagram of a device according to the invention with several Ren vacuum suction elements that hold an uneven object.

Fig. 1 shows a device 1 according to the invention comprising a Vorrichtungsge housing 2 and a Vakuumansaugelement 3, which is inserted into a hole formed at the housing 2 receiving 4, sealing means 5 are provided for sealing the outside wall of the Vakuumansaugelements 3 at its inner edge. The device housing 2 consists of an upper part 6 and a lower part 7 , between which a vacuum or vacuum channel 8 is formed, which is connected or connectable to a vacuum source, not shown. Before the direction of the housing 2 is in Fig. 1 and drawn canceled 2, it can be any size and include any number of receptacles or vacuum elements.

In addition, the device can also be designed as a single device have only one vacuum element.

The vacuum suction element 3 consists of a substantially cylindrical housing 9 which, as stated, can be inserted into the correspondingly shaped recess 4 on the device housing 2 and is sealed to the latter via the sealant 5 . On the device housing 9 , an inlet opening 10 is provided in the exemplary embodiment shown, via which the vacuum in the vacuum channel 8 can enter the vacuum suction element 3 . In the example shown in dashed lines, an optionally provided locking element 11 is shown, which - like the entire vacuum suction device 3 - can be opened or closed via a central control device, not shown, so as to form the vacuum channel with the vacuum channel formed inside the housing of the vacuum suction device 3 8 to connect or interrupt the flow connection.

Inside the housing 9 , a moving means is shown comprising an electric motor 12 in the exemplary embodiment shown, which is connected to bottom contact pins 13 with a printed circuit 14 provided on the lower part 7 of the device housing 2 , via which the control of the electric motor and - as follows is described - further movement means are made, contacted and connected to the control device.

The vacuum suction device 3 is designed overall so that it can be inserted and removed without any problems on the device rack side, with extensive contacting and control connection with all controllable elements being automatically ensured when the insertion position is reached. The electric motor 12 drives a threaded spindle 15 which extends within a column 16 and is received there in a spindle receptacle 17 . The spindle is obviously arranged off-center, which prevents the column 16 from rotating when the spindle moves. If the spindle is driven, it is possible to extend the column upwards, as indicated by the arrow A, from the housing 9 . Since the column is hollow on the inside, it extends the vacuum or vacuum channel, so that the vacuum, as will be described below, can be applied to an object to be recorded via the holding and sealing facial expressions on the column 16 . As soon as the column lifts out of its retracted non-working division, in which its lower end rests tightly on the electric motor 12 in a suitable sealing seat so that it is not connected to the vacuum or vacuum channel 8 , the vacuum can enter the column 16 be introduced. As described, the column 16 is accommodated in the housing 9 and is held there in a sealed manner by further sealing means 18 which act on the outside of the column 16 . In the example shown, the column is cylindrical overall. It is possible to hen the column at its lower end with a cone widening towards the end of the column, and to provide a corresponding, uniformly shaped cone on the housing in the area of the sealing means 18 , the two cone parts engaging when the maximum extended position is reached and so center the column 16 .

At the upper end of the column, a device 19 is provided, comprising a housing 20 , in which, on the one hand, a support element 21 in the form of an elongated pin with an upper-side friction support 22 and a sealing element 23 are received. The support element 21 is used to carry a Ge object to be held, the sealing element 23 is used to achieve a seal of the vacuum channel 24 extended through the column 16 and through the housing 20 to the object. As will be described in the following, support element 21 and sealing element 23 can be moved out of the housing 20 by means of a suitable movement means. The exact design of the device 19 will be discussed with reference to FIGS. 3 to 5.

If an object is now to be picked up, the column 16 together with a device 19 is extended, as shown in FIG. 2. The column 16 lifts out of its sealing seat on the electric motor 12 , so that the negative pressure can be passed on via the column 16 . After reaching a holding position, the support element 21 and the sealing element 23 are then extended as described, in order to be brought into the final contact with the object, so that the object is held. The extension movement of the column 16 is determined via a suitable sensor element 25 , which is integrated in the example shown on the electric motor 12 and, for example, detects the spindle movement, which is a measure of the extension path, this information being provided via the printed circuit 14 or the connection and control lines are given to the central control device so that it can control the extension operation accordingly. In order to also be able to detect and correctly control the extension movement of the support element 21 and the sealing element 23 , in the example shown the electric motor 31 is assigned a further sensor element 41 which also communicates with the control device (not shown). After completion of the work on the picked-up object (if the device is used in connection with a machine tool) or if the object has been transported to the desired location (if the device is used in connection with a vacuum transport device), the vacuum or the Vacuum was turned off (which can happen for example in that the actuating element 11 - which can only be optionally provided - is closed and the vacuum channel 24 is vented), the column 16 is retracted by appropriate operation of the electric motor 12 and brought into the non-working position .

Fig. 3 shows a device 19 in detail. The support element 21 in the example shown is a support pin, the friction support 22 of which is rounded in the example shown, so that a secure contact with the object is ensured even if the pin does not hit the surface of the object to be picked up perpendicularly. The sealing element 23 completely surrounds the support element 21 . Both are attached to a common bearing plate 26 . The bearing plate 26 is in turn pivotally mounted via a joint 27 , preferably a ball joint. This pivot bearing enables light, the bearing plate 26 and thus also the support element 21 and the sealing element 23 to pivot about any axis to a certain extent, so as to adapt to the shape of the contact surface of the object and to reach that the support element 21st strikes the contact surface as vertically as possible. In order to achieve a pivoting there is the possibility to do this manually. In the example shown, but are for this purpose several Elect romotoren 28 (in Fig. 3, only two of which shown) are provided which via suitable tension members 29 (z. B. tie rods) are connected to the bearing plate 26. If the bearing plate is now to be pivoted (as shown, for example, in FIG. 5), the electric motors 28 are actuated accordingly and the traction means 29 are extended or extended. Instead of the electric motors, any other actuation means is also conceivable, for. B. in the form of suitable electromagnets or the like.

The entire facial expressions consisting of bearing plate, joint facial expressions and electric motors are in turn received on a mounting plate 30 , which is designed via a wide electric motor 31 (which, like all other electric motors mentioned before, is designed as a servo motor) to extend the entire facial expression and there with the support element 21 and the sealing element 23 is used, which is indicated by the arrow B. A device 19 in the extended position is shown in FIG. 4. Here, too, the electric motor 31 can be connected to the mounting plate 30 via a spindle. The design options are arbitrary as long as it is ensured that the support element 21 and the sealing element 23 can be extended from the housing 20 .

As shown in FIGS. 3 and 4, the diameter of the sealing element 23 in the region of the sealing surface 32 increases during extension, that is, the further the sealing element is extended out of the housing 20 23, the greater the upper-side diameter of the cup-like sealing member 23 . The sealing element 23 , which is preferably made of rubber or plastic, consists in the example shown of a plurality of individual lamellae 33 , which are arranged to overlap one another and bear against a ring-shaped counter bearing 34 of the housing 20 with a certain preload. This counter bearing 34 pushes the fins together when retracting from the extended position shown in FIG. 4, and brings the fins or the sealing element 23 back under tension. If the sealing element 23 is extended, the plate 33 slide on the counter-bearing 34 along which the slats 33 under tension relax with increasing extension, so the sealing element 23 that opens further. Instead of the embodiment with overlapping lamellae, it is also possible to use a sealing element folded like a harmonica, which is also to be arranged in such a way or appropriate means are provided that this also opens when it is extended.

In order to achieve a tight connection of the sealing element 23 to the column 16 so that the negative pressure can be given to the object via the sealing element 23 , the sealing element 23 is on the one hand close to the bearing plate 26 , on the other hand, the bearing plate 26 is via a further sealant 35 , In the example shown, a flexible bellows-type sealing apron or sleeve, connected to the housing base 36 , which has a central passage opening which communicates with the column 16 . If the device 19 is now placed on the column 16 , for example screwed on or fastened by means of suitable plug-snap connections, a vacuum or vacuum channel formed over the vacuum or vacuum channel 24 , the sealant 35 and the sealing element 23 is formed . At least one suitable flow passage opening 37 is provided on the bearing plate 26 . Of course, other options for sealing the column 16 are also conceivable, the drawings shown are only schematic diagrams that serve to illustrate the basic principle of the invention and in no way limit it.

As described, FIG. 5 shows the device 19 with the support element 21 pivoted and the sealing element 23 . As can be seen, the pivoting position element 21 lies essentially perpendicular to the contact surface 38 of the object 39 . The flexible sealing element 23 lies close to the contact surface 38 and, due to its flexibility, adapts exactly to the contact surface, so it can follow conditions, so that a complete seal is achieved. As shown in Fig. 4 and 5 shows the sealing means 35 extended during the extension.

Finally, Fig. 6 shows in the form of a schematic diagram the use of a device according to the Invention, here four vacuum suction elements 3 are shown.

Obviously, the object 39 to be picked up has a curved, uneven and three-dimensional contact surface 38 . The sleeves 16 of the individual vacuum suction devices 3 arranged in a plane are moved to different extents, the support elements 21 and the sealing elements 23 lie on the contact surface 38 after corresponding pivoting thereof. The object 39 is carried by the support elements 21 . Obviously, it is possible with the device according to the invention to securely hold and clamp an uneven, an uneven and three-dimensional contact surface, so that it can be processed, for example, with a tool. At the same time, it is possible if the device is a transport device that hangs on a gantry crane or the like, for example, to pick up and transport a three-dimensional object.

As shown in FIG. 6, only four of the five receptacles of the device frame shown are occupied. In the unoccupied a blind element 40 is set, which seals the receptacle to the vacuum channel of the device frame.

As further shown in Fig. 1 on the left edge of the device frame 2 , connection means 42 , 43 are provided. The connecting means 42 serves to Vaku umkanal 8 of the apparatus shown with the vacuum channel 8 before another direction to connect, "loop through" to the negative pressure. The Anschlussmit tel can be designed so that when two devices are juxtaposed, the connection is made automatically, the device housings 2 are thus virtually plugged together. In the event that the devices are spaced from one another, corresponding hose connections can be connected there.

The connection or connection means 43 , which serve to connect the line connections of the printed circuit in order to loop the control signals to a further device, also have a corresponding function. Here, too, there is the possibility of achieving the connection by placing or plugging it directly in, alternatively there is also the possibility of connecting cables, alternatively there is also the possibility of connecting cables.

This modular connection option allows for several individual Devices - which are single devices with only one vacuum umelement or multiple devices with two or any number of vacuums re-element can act - to form a much larger arrangement to to be able to hold even very large objects with just one device can not be held.

Finally, FIG. 6 shows the possibility of setting up the vacuum elements 3 in an object-related presetting before recording an object. For this purpose, corresponding control parameters are either stored in the control device, which contain the object-related control and position data of each individual vacuum element. If, for example, the operator specifies that an object X is to be accommodated, for example, with the shape shown in FIG. 6, the vacuum suction elements 3 are automatically controlled into the position shown in FIG. 6, after which the object can be put on.

Alternatively, there is also the possibility of detecting an information carrier 45 located on the object 39 by means of a reading device 46 . For example, it is a barcode and a barcode reader or a transponder and a transponder reader. The information carrier 45 contains information about the type of the object, so that the control device 44 , which is shown in FIG. 6 and which communicates with the reading device 46 , can recognize the object and read the corresponding control data.

## Classifications

- B25B11/005
- B23Q1/035
- B25B11/00
- B25B11/007

## Cited patent documents

- [DE-3126720-A1](https://patents.google.com/patent/DE3126720A1/en) — SEA
- [DE-4017983-A1](https://patents.google.com/patent/DE4017983A1/en) — SEA
- [DE-4019536-A1](https://patents.google.com/patent/DE4019536A1/en) — SEA
- [DE-4215140-A1](https://patents.google.com/patent/DE4215140A1/en) — SEA

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
