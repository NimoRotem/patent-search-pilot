# 06. Sauggreifer

- **Archive rank:** 6 of 50
- **Publication:** [DE-29906611-U1](https://patents.google.com/patent/DE29906611U1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/008072182/publication/DE29906611U1?q=pn%3DDE29906611U1)
- **Publication date:** 1999-09-02
- **Filing date:** 1999-04-14
- **Earliest priority:** 1999-04-14
- **Family:** 8072182
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** SCHMALZ J GMBH

## Abstract

_No abstract was available from the queried sources._

## Sketches and drawings

_No digitized sketch link was returned._

## Claims

### Claim 1 (independent)

Sauggreifer (10) zum Ansaugen von Werkstücken, mit einem Unterdruckanschluß (22) und einem elastischen Saugkörper, wobei der Saugkörper an seiner dem Werkstück zugewandten Stirnseite eine einen Saugraum (30) umgebende und nach außen abgrenzende Dichtung (26) aufweist, wobei der Saugraum (30) mit dem Unterdruckanschluß (22) in Strömungsverbindung steht, dadurch gekennzeichnet, daß innerhalb des Saugraumes (30) wenigstens ein weiterer Saugraum (48) vorgesehen ist, der gegenüber dem ersten Saugraum (30) über eine Dichtung (34) abgegrenzt ist. 1. Suction gripper ( 10 ) for sucking workpieces, with a vacuum connection ( 22 ) and an elastic suction body, the suction body having on its end face facing the workpiece a seal ( 26 ) surrounding a suction chamber ( 30 ) and delimiting it to the outside, the suction chamber ( 30 ) being in flow connection with the vacuum connection ( 22 ), characterized in that at least one further suction chamber ( 48 ) is provided within the suction chamber ( 30 ), which is delimited from the first suction chamber ( 30 ) by a seal ( 34 ).

### Claim 2

Sauggreifer nach Anspruch 1, dadurch gekennzeichnet, daß der zweite Saugraum (48) direkt mit dem Unterdruckanschluß (22) in Strömungsverbindung steht. 2. Suction gripper according to claim 1, characterized in that the second suction chamber ( 48 ) is in direct flow connection with the vacuum connection ( 22 ).

### Claim 3

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, daß der erste und der zweite Saugraum (30 und 48) über einen Bypass (44) strömungsverbunden sind. 3. Suction gripper according to one of the preceding claims, characterized in that the first and the second suction chamber ( 30 and 48 ) are fluidly connected via a bypass ( 44 ).

### Claim 4

Sauggreifer nach Anspruch 3, dadurch gekennzeichnet, daß der Bypass (44) einen Strömungswiderstand aufweist. 4. Suction gripper according to claim 3, characterized in that the bypass ( 44 ) has a flow resistance.

### Claim 5

Sauggreifer nach Anspruch 3 oder 4, dadurch gekennzeichnet, daß der Bypass (44) ein Strömungsventil (50) aufweist. 5. Suction gripper according to claim 3 or 4, characterized in that the bypass ( 44 ) has a flow valve ( 50 ).

### Claim 6

Sauggreifer nach einem der Ansprüche 3 bis 5, dadurch gekennzeichnet, daß der Bypass (44) in Form einer oder mehrerer Strömungskanäle (38, 46), insbesondere Bohrungen im Sauggreifer vorgesehen ist. 6. Suction gripper according to one of claims 3 to 5, characterized in that the bypass ( 44 ) is provided in the form of one or more flow channels ( 38 , 46 ), in particular bores in the suction gripper.

### Claim 7

Sauggreifer nach einem der Ansprüche 3 bis 6, dadurch gekennzeichnet, daß der Bypass (44) in Form einer oder mehrerer Strömungskanäle in der zweiten Dichtung (34) vorgesehen ist. 7. Suction gripper according to one of claims 3 to 6, characterized in that the bypass ( 44 ) is provided in the form of one or more flow channels in the second seal ( 34 ).

### Claim 8

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, daß die zweite Dichtung (34) eine dem Werkstück zugewandte scharfe Dichtlippe (36) aufweist. 8. Suction gripper according to one of the preceding claims, characterized in that the second seal ( 34 ) has a sharp sealing lip ( 36 ) facing the workpiece.

### Claim 9

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, daß die erste und zweite Dichtung (26 und 34) von separaten Bauteilen gebildet werden. 9. Suction gripper according to one of the preceding claims, characterized in that the first and second seals ( 26 and 34 ) are formed by separate components.

### Claim 10

Sauggreifer nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, daß der zweite Saugraum (48) innerhalb des ersten Saugraumes (30) liegt. 10. Suction gripper according to one of the preceding claims, characterized in that the second suction chamber ( 48 ) is located within the first suction chamber ( 30 ).

## Full description

PERFORMING OPERATIONS; TRANSPORTINGPRINTING; LINING MACHINES; TYPEWRITERS; STAMPSPRINTING MACHINES OR PRESSESDevices for conveying sheets through printing apparatus or machinesGrippersSuction-operated grippersPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippersPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALHANDLING THIN OR FILAMENTARY MATERIAL, e.g. SHEETS, WEBS, CABLESSeparating articles from pilesSeparating articles from piles using pneumatic forceSuction grippersConstruction of suction grippers or their holding devices

Description

Translated from German

F:\IJBDHF\DHFANM\3 961125F:\IJBDHF\DHFANM\3 961125

Anmelder:Applicant:

J. Schmalz GmbH

Aacher StraÃe 29

72293 GlattenJ. Schmalz GmbH

Aacher Strasse 29

72293 Glatten

Allgemeine Vollmacht: 3.1.5.Nr.751/92 AVGeneral power of attorney: 3.1.5.No.751/92 AV

39611253961125

13.04.1999 ste / gri13.04.1999 ste / gri

Titel: SauggreiferTitle: Suction cup

BeschreibungDescription

Die Erfindung betrifft einen Sauggreifer zum Ansaugen von WerkstÃ¼cken, mit einem UnterdruckanschluÃ und mit einem elastischen SaugkÃ¶rper, wobei der SaugkÃ¶rper an seiner dem WerkstÃ¼ck zugewandten Stirnseite eine einen Saugraum umgebende und nach auÃen abgrenzende Dichtung aufweist, wobei der Saugraum mit dem UnterdruckanschluÃ in StrÃ¶mungsverbindung steht.The invention relates to a suction gripper for sucking workpieces, with a vacuum connection and with an elastic suction body, wherein the suction body has a seal on its front side facing the workpiece that surrounds a suction chamber and delimits it to the outside, wherein the suction chamber is in flow connection with the vacuum connection.

Sauggreifer werden verwendet, um GegenstÃ¤nde oder WerkstÃ¼cke anzusaugen, so daÃ sie entweder auf diese Weise fixiert oder gehandhabt werden kÃ¶nnen. Befinden sich dieSuction grippers are used to suck objects or workpieces so that they can either be fixed or handled in this way. If the

Sauggreifer an Manipulatoren, so kann der angesaugte Gegenstand transportiert werden. FÃ¼r unterschiedliche GegenstÃ¤nde sind jeweils die entsprechenden Sauggreifer erforderlich. In der Regel sind die Sauggreifer an die GrÃ¶Ãe und das Gewicht des zu manipulierenden Gegenstands angepaÃt. Die Sauggreifer weisen in der Regel eine umlaufende Dichtung auf, Ã¼ber die ein Saugraum abgeschlossen beziehungsweise abgedichtet wird. Ebene GegenstÃ¤nde kÃ¶nnen auf diese Weise relativ einfach ergriffen und transportiert werden. Weist die OberflÃ¤che des anzusaugenden Gegenstands jedoch Unebenheiten auf, so werden in der Regel mehrere kleinere Sauggreifer verwendet, die ihrerseits immer an einem ebenen Bereich des Gegenstands angesetzt werden. Das Ergreifen dieser GegenstÃ¤nde mit mehreren Sauggreifern verursacht jedoch hÃ¶here Kosten, da der technische Aufwand wesentlich hÃ¶her ist als beim Ergreifen des Gegenstands mit einem einzigen Sauggreifer. Dies gilt auch fÃ¼r unterschiedlich groÃe WerkstÃ¼cke, da in der Regel groÃe WerkstÃ¼cke mit groÃen Sauggreifern ergriffen werden und kleine WerkstÃ¼cke nur mit kleinen Sauggreifern ergriffen werden kÃ¶nnen.Suction grippers on manipulators, the object being sucked up can be transported. Different objects require different suction grippers. The suction grippers are usually adapted to the size and weight of the object to be manipulated. The suction grippers usually have a circumferential seal that closes off or seals off a suction chamber. Flat objects can be gripped and transported relatively easily in this way. However, if the surface of the object to be sucked up is uneven, several smaller suction grippers are usually used, which in turn are always placed on a flat area of the object. Gripping these objects with several suction grippers, however, causes higher costs, as the technical effort is much higher than gripping the object with a single suction gripper. This also applies to workpieces of different sizes, as large workpieces are usually gripped with large suction grippers and small workpieces can only be gripped with small suction grippers.

Der Erfindung liegt daher die Aufgabe zugrunde, einen Sauggreifer bereitzustellen, mit dem auch unterschiedlich groÃe WerkstÃ¼cke ergriffen werden kÃ¶nnen, da groÃeThe invention is therefore based on the object of providing a suction gripper with which workpieces of different sizes can be gripped, since large

Sauggeifer unter UmstÃ¤nden nicht vollflÃ¤chig auf den kleinen GegenstÃ¤nden aufliegen.Suction cups may not fully adhere to small objects.

Diese Aufgabe wird erfindungsgemÃ¤Ã dadurch gelÃ¶st, daÃ innerhalb des Saugraumes wenigstens ein weiterer Saugraum vorgesehen ist, der gegenÃ¼ber dem ersten Saugraum Ã¼ber eine zweite Dichtung abgegrenzt ist.This object is achieved according to the invention in that at least one further suction chamber is provided within the suction chamber, which is delimited from the first suction chamber by a second seal.

Der erfindungsgemÃ¤Ãe Sauggreifer besitzt also zwei Dichtungen, die zwei SaugrÃ¤ume abgrenzen. Auf diese Weise kÃ¶nnen groÃe GegenstÃ¤nde ergriffen werden, indem beide SaugrÃ¤ume aktiviert werden. Bei kleinen GegenstÃ¤nden wird lediglich einer der beiden SaugrÃ¤ume aktiviert. Insbesondere beim Handling von Blechen kÃ¶nnen derartige Sauggreifer vorteilhaft eingesetzt werden. GroÃe Blechtafeln werden wie Ã¼blich ergriffen. Sollen jedoch schmale Blechstreifen ergriffen werden, dann wird lediglich einer der SaugrÃ¤ume aktiviert, so daÃ die diesen Saugraum abgrenzende Dichtung vollstÃ¤ndig auf dem Blechstreifen aufliegt. Derartige Sauggreifer werden vorteilhaft bei Blechbearbeitungsmaschinen, zum Beispiel Laserschneidmaschinen, Stanz-, Nibbel- und Biegemaschinen eingesetzt.The suction gripper according to the invention therefore has two seals that delimit two suction chambers. In this way, large objects can be gripped by activating both suction chambers. For small objects, only one of the two suction chambers is activated. Such suction grippers can be used advantageously, particularly when handling sheet metal. Large metal sheets are gripped as usual. However, if narrow sheet metal strips are to be gripped, only one of the suction chambers is activated, so that the seal delimiting this suction chamber rests completely on the sheet metal strip. Such suction grippers are used advantageously in sheet metal processing machines, for example laser cutting machines, punching, nibbling and bending machines.

Bei einer Weiterbindung ist vorgesehen, daÃ der zweite Saugraum innerhalb des ersten Saugraumes liegt, daÃ heiÃt,In the case of a further connection, it is intended that the second suction chamber is located within the first suction chamber, that is,

daÃ der erste Saugraum den zweiten Saugraum ganz oder teilweise umgibt. Bei einem bevorzugten AusfÃ¼hrungsbeispiel ist vorgesehen, daÃ der zweite Saugraum kreisfÃ¶rmig und der erste Saugraum ringfÃ¶rmig ausgebildet ist. Die SaugrÃ¤ume kÃ¶nnen konzentrisch liegen. Auf diese Weise kann der Sauggreifer relativ einfach und schnell an die unterschiedlichen GrÃ¶Ãen der WerkstÃ¼cke angepaÃt werden.that the first suction chamber completely or partially surrounds the second suction chamber. In a preferred embodiment, the second suction chamber is circular and the first suction chamber is ring-shaped. The suction chambers can be concentric. In this way, the suction gripper can be adapted relatively easily and quickly to the different sizes of the workpieces.

Mit Vorzug steht der zweite oder innenre Saugraum direkt mit dem UnterdruckanschluÃ in StrÃ¶mungsverbindung. Auf diese Weise ist sichergestellt, daÃ der zweite Saugraum stets mit Vakuum versorgt wird.Preferably, the second or inner suction chamber is directly connected to the vacuum connection. This ensures that the second suction chamber is always supplied with vacuum.

Eine Weiterbildung sieht vor, daÃ der erste und der zweite Saugraum Ã¼ber einen Bypass strÃ¶mungsverbunden sind. Bei diesem AusfÃ¼hrungsbeispiel wird der Unterdruck Ã¼ber den Bypass an den ersten Saugraum angelegt, so daÃ auch dieser aktiviert ist.A further development provides that the first and second suction chambers are fluidically connected via a bypass. In this embodiment, the negative pressure is applied to the first suction chamber via the bypass, so that this is also activated.

Um zu verhindern, daÃ bei kleinen WerkstÃ¼cken, welche den ersten Saugraum nicht vollstÃ¤ndig abdecken, das Vakuum nicht zusammenbricht, ist vorgesehen, daÃ der Bypass einen StrÃ¶mungswiderstand aufweist. Dieser StrÃ¶mungswiderstand ermÃ¶glicht zwar das Anlegen eines Unterdrucks am ersten Saugraum, verhindert jedoch, daÃ das Vakuum im zweiten Saugraum zusammenbricht, wenn der erste Saugraum mit derIn order to prevent the vacuum from collapsing in the case of small workpieces that do not completely cover the first suction chamber, the bypass is provided with a flow resistance. This flow resistance allows a negative pressure to be applied to the first suction chamber, but prevents the vacuum from collapsing in the second suction chamber when the first suction chamber is filled with the

Umgebung verbunden ist. Insbesondere besitzt der Bypass ein StrÃ¶mungsventil, welches ab einem bestimmten Volumenstrom selbstÃ¤ndig schlieÃt.environment. In particular, the bypass has a flow valve that closes automatically when a certain volume flow is reached.

Der Bypass ist bei einem bevorzugten AusfÃ¼hrungsbeispiel in Form einer oder mehrerer StrÃ¶mungskanÃ¤le, insbesondere Bohrungen, im Sauggreifer vorgesehen. Diese StrÃ¶mungskanÃ¤le befinden sich bevorzugt in der Sauggreiferplatte, an welcher die Dichtungen befestigt sind.In a preferred embodiment, the bypass is provided in the form of one or more flow channels, in particular bores, in the suction gripper. These flow channels are preferably located in the suction gripper plate to which the seals are attached.

Bei einer Variante ist vorgesehen, daÃ der Bypass in Form einer oder mehrerer StrÃ¶mungskanÃ¤le in der zweiten Dichtung vorgesehen ist. Diese StrÃ¶mungskanÃ¤le kÃ¶nnen bereits bei der Herstellung der Dichtung in dieser realisiert sein, wobei der Bypass dann schlieÃt, wenn auf die Dichtung KrÃ¤fte einwirken. Dies kann zum Beispiel dann der Fall sein, wenn kleine WerkstÃ¼cke, zum Beispiel Blechstreifen, ergriffen werden, die insbesondere an der zweiten Dichtung anliegen. Wird dann am zweiten Saugraum ein Unterdruck angelegt, so wird diese zweite Dichtung verformt. Dabei schlieÃt zum Beispiel der Bypass.In one variant, the bypass is provided in the form of one or more flow channels in the second seal. These flow channels can be implemented in the seal when it is manufactured, with the bypass closing when forces act on the seal. This can be the case, for example, when small workpieces, such as sheet metal strips, are gripped, which in particular rest against the second seal. If a negative pressure is then applied to the second suction chamber, this second seal is deformed. This closes the bypass, for example.

Um einen optimalen und dichten AbschluÃ des zweiten Saugraums zu erzielen, weist die zweite Dichtung eine dem WerkstÃ¼ck zugewandte scharfe Kante auf. Insbesondere beim Blechhandling kann hierdurch eine gute Dichtung erzieltIn order to achieve an optimal and tight closure of the second suction chamber, the second seal has a sharp edge facing the workpiece. This allows a good seal to be achieved, especially when handling sheet metal.

si J * % I j e ti s Â» s i J * % I je ti s Â»

â S Sees ti J ctss c BCi sssÂ·â S Sees ti J ctss c BCi sssÂ·

Sift 1 !I Â» Â»* "* Sift 1 !I Â» Â»* "*

werden. Das Verrutschen des Bleches wird Ã¼ber die erste Dichtung verhindert.The first seal prevents the sheet from slipping.

Um den Sauggreifer individuell gestalten zu kÃ¶nnen, werden die erste und zweite Dichtung von separaten Bauteilen gebildet. Auf diese Weise kÃ¶nnen jeweils die fÃ¼r die zu greifenden WerkstÃ¼cke optimalen Dichtungen eingesetzt werden, beziehungsweise kÃ¶nnen verschlissene Dichtungen problemlos ausgetauscht werden.In order to be able to design the suction gripper individually, the first and second seals are made of separate components. In this way, the optimal seals for the workpieces to be gripped can be used, or worn seals can be easily replaced.

Weitere Vorteile, Merkmale und Einzelheiten der Erfindung ergeben sich aus den UnteransprÃ¼chen sowie der nachfolgenden Beschreibung, in der unter Bezugnahme auf die Zeichnung ein besonders bevorzugtes AusfÃ¼hrungsbeispiel beschrieben ist. Dabei kÃ¶nnen die in der Zeichnung dargestellten und in der Beschreibung sowie in den AnsprÃ¼chen erwÃ¤hnten Merkmale jeweils einzeln fÃ¼r sich oder in beliebiger Kombination erfindungswesentlich sein. Die Zeichnung zeigt ein AusfÃ¼hrungsbeispiel des erfindungsgemÃ¤Ãen Sauggreifers, welches teilweise aufgebrochen ist.Further advantages, features and details of the invention emerge from the subclaims and the following description, in which a particularly preferred embodiment is described with reference to the drawing. The features shown in the drawing and mentioned in the description and in the claims can each be essential to the invention individually or in any combination. The drawing shows an embodiment of the suction gripper according to the invention, which is partially broken away.

Der insgesamt mit 10 bezeichnete Sauggreifer ist mit seinem einen Ende zum Beispiel an einem Manipulator 12 befestigt. Das andere Ende ist mit einem Saugteller 14 versehen, welcher einen zentralen Durchbruch 16 aufweist, der Ã¼berThe suction gripper, designated as a whole with 10, is attached at one end to a manipulator 12, for example. The other end is provided with a suction plate 14, which has a central opening 16, which

eine SchraubhÃ¼lse 18 mit einem GreiferstÃ¶ssel 20 verbunden ist. Dieser GreiferstÃ¶ssel 20 besitzt einen UnterdruckanschluÃ

22, an welchem eine Unterdruckleitung 24

angeschlossen ist. Ãber diese Unterdruckleitung 24 wird

Luft aus dem Bereich unterhalb des Saugtellers 14

abgesaugt.a screw sleeve 18 is connected to a gripper plunger 20. This gripper plunger 20 has a vacuum connection

22, to which a vacuum line 24

This vacuum line 24 supplies the

Air from the area below the suction cup 14

sucked out.

Der Saugteller 14 ist mit einer ersten Dichtung 26

bestÃ¼ckt, die auf dessen freien Rand unverlierbar

aufgeclipst ist. Diese Dichtung 26 besitzt eine nach unten abragende Dichtlippe 28, die einen ersten Saugraum 3 0 nach auÃen abgrenzt. Die Unterseite des Saugtellers 14 ist

auÃerdem mit einer Ringnut 32 versehen, in welche eine

zweite Dichtung 34 eingesetzt ist. Diese zweite Dichtung weist ebenfalls eine nach unten vorstehende Dichtlippe 3 6

auf, die nicht nur eine Dichtfunktion besitzt sondern auch als Federelement dient, da die Dichtlippe 36 Ã¼ber die

AbstÃ¼tzflÃ¤che des Saugraumes 30 Ã¼bersteht. Die Dichtung 34 und die Dichtlippe 36 kÃ¶nnen auch einstÃ¼ckig sein.The suction cup 14 is provided with a first seal 26

which is permanently fixed on its free edge

This seal 26 has a downwardly projecting sealing lip 28 which delimits a first suction chamber 30 to the outside. The underside of the suction plate 14 is

also provided with an annular groove 32 into which a

second seal 34 is inserted. This second seal also has a downwardly projecting sealing lip 3 6

which not only has a sealing function but also serves as a spring element, since the sealing lip 36 over the

Support surface of the suction chamber 30. The seal 34 and the sealing lip 36 can also be one piece.

Der Saugteller 14 ist mit einem StrÃ¶mungskanal 38, der als Bohrung 40 ausgefÃ¼hrt ist, versehen. Dieser StrÃ¶mungskanal 38 mÃ¼ndet in den Durchbruch 16. Das andere Ende des

StrÃ¶mungskanals 3 8 ist zum Beispiel mit einer Kugel 42, die in den StrÃ¶mungskanal 38 eingepreÃt ist, nach auÃen

verschlossen. AuÃerdem mÃ¼ndet in den StrÃ¶mungskanal 38 einThe suction plate 14 is provided with a flow channel 38, which is designed as a bore 40. This flow channel 38 opens into the opening 16. The other end of the

Flow channel 38 is, for example, with a ball 42 which is pressed into the flow channel 38,

closed. In addition, a

weiterer StrÃ¶mungskanal 46, der in den Saugraum 30 ausmÃ¼ndet. Die Dichtung 34 umgibt einen zweiten Saugraum 48, in welchen der Durchbruch 16 mÃ¼ndet. Im StrÃ¶mungskanal 46 befindet sich ein StrÃ¶mungswiderstand oder ein StrÃ¶mungsventil 50 sowie ein Filterelement 52.another flow channel 46, which opens into the suction chamber 30. The seal 34 surrounds a second suction chamber 48, into which the opening 16 opens. In the flow channel 46 there is a flow resistance or a flow valve 50 and a filter element 52.

Wird der erfindungsgemÃ¤Ãe Sauggreifer 10 auf eine groÃe Blechtafel aufgesetzt, dann dichtet die Dichtlippe 28 der Dichtung 26 den Saugraum 30 zur Umgebung hin ab. Wird Ã¼ber die Unterdruckleitung 24 ein Unterdruck angelegt, dann wird die Luft aus dem zweiten Saugraum 48 direkt und aus dem ersten Saugraum 30 Ã¼ber die beiden StrÃ¶mungskanÃ¤le 3 8 und 46, die einen Bypass bezÃ¼glich der Dichtung 32 bilden, abgesaugt. Die Blechtafel wird vom Sauggreifer 10 sicher gehalten.If the suction gripper 10 according to the invention is placed on a large metal sheet, the sealing lip 28 of the seal 26 seals the suction chamber 30 from the environment. If a negative pressure is applied via the negative pressure line 24, the air is sucked out of the second suction chamber 48 directly and from the first suction chamber 30 via the two flow channels 38 and 46, which form a bypass with respect to the seal 32. The metal sheet is held securely by the suction gripper 10.

Wird der erfindungsgemÃ¤Ãe Sauggreifer 10 lediglich auf einen schmalen Blechstreifen aufgesetzt, dann wird der zweite Saugraum 48 von der Dichtung 34 zur Umgebung hin abgedichtet. Die Dichtung 26 beziehungsweise die Dichtlippe 28 liegt jedoch nur abschnittsweise auf dem schmalen Blechstreifen auf. Somit ist der Saugraum 30 mit der Umgebung verbunden. Wird nun ein Unterdruck am Saugraum 48 angelegt, dann schlieÃt das StrÃ¶mungsventil 50 den Bypass 44, so daÃ der Unterdruck im zweiten Saugraum 48 nicht zusammenbricht.If the suction gripper 10 according to the invention is only placed on a narrow sheet metal strip, the second suction chamber 48 is sealed from the environment by the seal 34. However, the seal 26 or the sealing lip 28 only rests on the narrow sheet metal strip in sections. The suction chamber 30 is thus connected to the environment. If a negative pressure is now applied to the suction chamber 48, the flow valve 50 closes the bypass 44 so that the negative pressure in the second suction chamber 48 does not collapse.

Mit dem erfindungsgemÃ¤Ãen Sauggreifer 10 kÃ¶nnen somit groÃflÃ¤chige WerktstÃ¼cke und schmale beziehungsweise kleine WerkstÃ¼cke gleichermaÃen gut angesaugt werden.With the suction gripper 10 according to the invention, large-area workpieces and narrow or small workpieces can be sucked equally well.

## Classifications

- B41F21/06
- B41F21/06
- B65G47/91
- B65G47/91
- B65H3/08
- B65H3/0883

---

Generated by Rotem Patents. Verify legal conclusions against the official publication.
