# Top 50 full-text patent archive

Search: A hand-guided (or rope-drawn) vibration device for bedding tiles into thinset that holds itself down by a deliberately leaky vacuum, so that every part between the motor and the tile can be rigid.

The mechanism

A rigid base carries a vibration motor and an air-extraction mechanism (e.g. a vacuum pump) on its upper side, and a chamber on its underside. Around that chamber runs a rigid perimeter member — a skirt of plastic, metal or PTFE — whose end face is a bearing face that rests on the tile's exposed face.

The skirt is explicitly not a seal. A clearance remains along at least part of it, and ambient air flows into the chamber continuously. The pump simply extracts air faster than it leaks in, so the chamber stays below atmospheric pressure for as long as the pump runs. That standing differential, acting over the chamber area, presses the device onto the tile.

Why the leak is the invention rather than a flaw

Sealing would require compliance (a rubber cup or skirt), and compliance in the load path damps the vibration that the tool exists to deliver. By accepting the leak and compensating with flow rate instead, the design keeps the entire path — motor → base → skirt → bearing face → tile — rigid, with no elastomer, foam or resilient mount anywhere in it.

The three consequences

Better coupling. Vibration crosses a rigid, loaded contact rather than a compliant cup wall or an air film under a pressed-on plate.
The operator leaves the load path. Contact force comes from the pressure differential, not from pressing down. Hand-arm vibration is reduced by removing the loaded path altogether rather than by damping it — which would have stolen the same energy from the tile. The usual trade-off (press harder for better coupling, get more vibration exposure) is dissolved.
Hold and slide simultaneously. Because the contact member is a low-friction bearing face rather than a gripping cup, the device can be translated across the tile while the differential is maintained. Holding and moving are not alternating modes, so vibration reaches successive areas instead of falling off with distance from a fixed suction point.

Decoupled control

In the rope/cable embodiment, position is set by a small in-plane pulling force from the operator, while contact force — and therefore coupling quality — is set independently and constantly by the pump. The operator's grip has nothing to do with how well the tool works.

Generated: 2026-08-25T16:57:08.723433+00:00

49 of 50 publications include both claims and description. Any unavailable source text is called out inside its Markdown file; every file links to the official web records and available sketches.
