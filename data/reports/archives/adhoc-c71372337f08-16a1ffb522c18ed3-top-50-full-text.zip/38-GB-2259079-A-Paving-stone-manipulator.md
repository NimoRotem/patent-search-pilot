# 38. Paving stone manipulator

- **Archive rank:** 38 of 50
- **Publication:** [GB-2259079-A](https://patents.google.com/patent/GB2259079A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/010699478/publication/GB2259079A?q=pn%3DGB2259079A)
- **Publication date:** 1993-03-03
- **Filing date:** 1991-08-03
- **Earliest priority:** 1991-08-03
- **Family:** 10699478
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** CONWAY PAUL ANTHONY
- **Inventors:** CONWAY PAUL ANTHONY

## Abstract

This device consists of a chamber 2, in which air pressure can be reduced by the operation of the rotary air impeller 5, this then attaches the chamber 2 firmly to the paving stone via the seal 4. The paving stone can then be lifted, lowered or moved by handles. The impeller 5 is operated by a switch 3 mounted on one of the handles. &lt;IMAGE&gt;

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/GB-2259079-A/pdf000.png)

![Sketch 1 for GB-2259079-A](https://nimo.iptorch.com/refdrawing/GB-2259079-A/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/GB-2259079-A/pdf001.png)

![Sketch 2 for GB-2259079-A](https://nimo.iptorch.com/refdrawing/GB-2259079-A/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/GB-2259079-A/pdf002.png)

![Sketch 3 for GB-2259079-A](https://nimo.iptorch.com/refdrawing/GB-2259079-A/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/GB-2259079-A/pdf003.png)

![Sketch 4 for GB-2259079-A](https://nimo.iptorch.com/refdrawing/GB-2259079-A/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/GB-2259079-A/pdf004.png)

![Sketch 5 for GB-2259079-A](https://nimo.iptorch.com/refdrawing/GB-2259079-A/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/GB-2259079-A/pdf005.png)

![Sketch 6 for GB-2259079-A](https://nimo.iptorch.com/refdrawing/GB-2259079-A/pdf005.png)

## Claims

### Claim 1 (independent)

Claims (5)

### Claim 2 (independent)

1 A paving stone manipulator comprises of at least one chamber open on the underside, and having a flexible seal around the edge of this opening, at least one rotary air impeller is provided attached directly to the top of the chamber, and the impeller has directly connected to it a suitable rotary power source.

### Claim 3

2 A paving stone manipulator as claimed in Claim 1 wherein one or more chambers are provided in which to reduce the air pressure.

### Claim 4

3 A paving stone manipulator as claimed in Claim 1 or Claim 2 wherein a flexible seal is provided for the chamber/s.

### Claim 5

4 A paving stone manipulator as claimed in Claim 1 or Claim 2 or

### Claim 6

Claim 3 wherein a rotary air impeller is provided directly connected to the reduced air pressure chamber.

### Claim 7

5 A paving stone manipulator as claimed in any preceding claim wherein a suitable source of rotary power is directly connected to the rotary air impeller.

## Full description

**[p0001]**

PERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippersPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSDevices for assisting manual moving or tilting heavy loadsLoad carriers, e.g. hooks, slings, harness, gloves, modified for load carryingFIXED CONSTRUCTIONSCONSTRUCTION OF ROADS, RAILWAYS, OR BRIDGESCONSTRUCTION OF, OR SURFACES FOR, ROADS, SPORTS GROUNDS, OR THE LIKE; MACHINES OR AUXILIARY TOOLS FOR CONSTRUCTION OR REPAIRMachines, tools or auxiliary devices for preparing or distributing paving materials, for working the placed materials, or for forming, consolidating, or finishing the pavingApparatus for laying individual preformed surfacing elements, e.g. kerbstonesApparatus for laying individual preformed surfacing elements, e.g. kerbstones using suction devicesFIXED CONSTRUCTIONSCONSTRUCTION OF ROADS, RAILWAYS, OR BRIDGESCONSTRUCTION OF, OR SURFACES FOR, ROADS, SPORTS GROUNDS, OR THE LIKE; MACHINES OR AUXILIARY TOO

**[p0001]**

LS FOR CONSTRUCTION OR REPAIRMachines, tools or auxiliary devices for preparing or distributing paving materials, for working the placed materials, or for forming, consolidating, or finishing the pavingApparatus for laying individual preformed surfacing elements, e.g. kerbstonesApparatus for laying individual preformed surfacing elements, e.g. kerbstones hand operated

**[p0002]**

Description

### Paving Stone Manipulator

**[p0003]**

This invention relates to a device to facilitate the laying, lifting, and manoevering of paving stones at low level. The laying and moving of paving stones by hand is heavy and arduous work, and it is the purpose of this invention to greatly ease this task. According to the present invention there is provided a paving stone manipulator, comprising of at least one chamber open on the underside, and having a flexible seal around the edge of this opening. At least one rotary air impeller is provided attached directly to the top of the chamber and the impeller has directly connected to it a suitable rotary power source. Handles are provided for the use of the operators, and also means of controlling the power source. A specific embodiment of the invention will now be described by way of example with reference to the accompanying drawing in which: Figure 1 shows in perspective, the paving stone manipulator. Figure 2 shows the chamber, impeller, power source and seal. Referring to the drawing the paving stone manipulator comprises handles 1 reduced air pressure chamber 2 with seal 4 controller 3 impeller 5 motor 6 and connection box 7.

**[p0004]**

In use the paving stone manipulator is placed on the top surface of the paving stone to be moved, operation of the controller 3 activates the motor 6 via the connection box 7 driving the air impeller 5, which reduces the air pressure in the chamber 2 which causes the paving stone to become firmly attached to the bottom of the chamber 2 via the seal 4. Operating the controller again releases the paving stone.

## Classifications

- B65G47/91
- B65G47/91
- B65G7/12
- B65G7/12
- E01C19/52
- E01C19/524
- E01C19/526

## Cited patent documents

- [EP-0275491-A1](https://patents.google.com/patent/EP0275491A1/en) — SEA
- [GB-1165083-A](https://patents.google.com/patent/GB1165083A/en) — SEA
- [GB-1226302-A](https://patents.google.com/patent/GB1226302A/en) — SEA
- [GB-1254833-A](https://patents.google.com/patent/GB1254833A/en) — SEA
- [US-4787812-A](https://patents.google.com/patent/US4787812A/en) — SEA
- [US-4946335-A](https://patents.google.com/patent/US4946335A/en) — SEA

---

Generated by IPtorch. Verify legal conclusions against the official publication.
