# 20. Make things convenient for indoor ceramic tile tiling&#39;s shop tie ware

- **Archive rank:** 20 of 50
- **Publication:** [CN-117005650-A](https://patents.google.com/patent/CN117005650A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/088560822/publication/CN117005650A?q=pn%3DCN117005650A)
- **Publication date:** 2023-11-07
- **Filing date:** 2023-05-17
- **Earliest priority:** 2023-05-17
- **Family:** 88560822
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** GUANGDONG ZHANXIN SMART HOME TECH CO LTD

## Abstract

The invention relates to the technical field of decoration, in particular to a spreader convenient for spreading indoor tiles. The invention aims to provide a spreader which is convenient for tiling indoor tiles. The invention provides a spreader convenient for tiling indoors, which comprises a fixed seat, a handle, first sliding rails, sliding sleeves, suckers, vibrators, a positioning mechanism and a testing mechanism, wherein the handle is connected to the upper portion of the fixed seat, the first sliding rails are connected to the left side and the right side of the top of the fixed seat, the sliding sleeves are connected to the lower portions of the first sliding rails, the suckers are connected between the sliding sleeves in a sliding mode, the suckers are sleeved on the outer sides of the fixed seat, the vibrators are connected to the middle of the bottom of the fixed seat, the positioning mechanism is arranged between the fixed seat and the first sliding rails, and the testing mechanism is arranged on the positioning mechanism. According to the invention, the first torsion spring and the positioning plate are arranged, so that the positioning plate and four sides of the ceramic tile can be subjected to attaching and positioning, and the sucking disc can be positioned right above the ceramic tile, so that the ceramic tile can be paved on the ground subsequently.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf000.png)

![Sketch 1 for CN-117005650-A](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf001.png)

![Sketch 2 for CN-117005650-A](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf002.png)

![Sketch 3 for CN-117005650-A](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf003.png)

![Sketch 4 for CN-117005650-A](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf004.png)

![Sketch 5 for CN-117005650-A](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf005.png)

![Sketch 6 for CN-117005650-A](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf006.png)

![Sketch 7 for CN-117005650-A](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf007.png)

![Sketch 8 for CN-117005650-A](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf008.png)

![Sketch 9 for CN-117005650-A](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf009.png)

![Sketch 10 for CN-117005650-A](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf009.png)

[Sketch 11](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf010.png)

![Sketch 11 for CN-117005650-A](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf010.png)

[Sketch 12](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf011.png)

![Sketch 12 for CN-117005650-A](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf011.png)

[Sketch 13](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf012.png)

![Sketch 13 for CN-117005650-A](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf012.png)

[Sketch 14](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf013.png)

![Sketch 14 for CN-117005650-A](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf013.png)

[Sketch 15](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf014.png)

![Sketch 15 for CN-117005650-A](https://nimo.iptorch.com/refdrawing/CN-117005650-A/pdf014.png)

## Claims

### Claim 1 (independent)

Claims (8) Make things convenient for indoor tile tiling's shop tie-up, including fixing base (1), handle (2), first slide rail (3), sliding sleeve (4), sucking disc (5) and electromagnetic shaker (51), fixing base (1) upper portion is connected with handle (2), fixing base (1) top left and right sides all is connected with first slide rail (3), first slide rail (3) lower part all is connected with sliding sleeve (4), sliding connection has sucking disc (5) between sliding sleeve (4), sucking disc (5) cover is in fixing base (1) outside, fixing base (1) bottom intermediate junction has electromagnetic shaker (51), a serial communication port, still including positioning mechanism (6) and testing mechanism (7), be equipped with positioning mechanism (6) between fixing base (1) and first slide rail (3), be equipped with testing mechanism (7) on positioning mechanism (6).

### Claim 2

The spreader convenient for tiling indoor tiles according to claim 1, wherein the positioning mechanism (6) comprises a pulling component, a second sliding rail (63), a sliding block (64), a positioning plate (65) and a first torsion spring (67), the front side and the rear side of the top of the fixing seat (1) are respectively connected with the second sliding rail (63), the lower part of the second sliding rail (63) and the lower part of the first sliding rail (3) are respectively connected with the sliding block (64), the lower part of the sliding block (64) is respectively connected with the positioning plate (65) in a rotating way, two first torsion springs (67) are respectively connected between the positioning plate (65) and the sliding block (64), a pulling component is arranged between the first sliding rail (3) and the second sliding rail (63), and the pulling component is connected with the sliding block (64).

### Claim 3

The spreader for conveniently tiling indoor tiles according to claim 2, wherein the pulling assembly comprises a motor (61), a reel (62) and pull ropes (66), the motor (61) is connected to the middle of the upper part of the fixing seat (1) through screws, the reel (62) is connected to an output shaft of the motor (61), the reel (62) is wound with four pull ropes (66), the pull ropes (66) on the left side and the right side respectively penetrate into the first sliding rail (3), the pull ropes (66) on the front side and the rear side respectively penetrate into the second sliding rail (63), and the end parts of the pull ropes (66) are connected with similar sliding blocks (64).

### Claim 4

A paving machine for conveniently paving indoor tiles according to claim 3, wherein the testing mechanism (7) comprises a first telescopic sleeve (71), a telescopic rod (72), a distance sensor (73), an alarm (74) and a return spring (75), wherein the first telescopic sleeve (71) is welded on the outer side of the sliding block (64), the telescopic rod (72) is connected in the first telescopic sleeve (71) in a sliding manner, the return spring (75) is connected between the top of the telescopic rod (72) and the inner top wall of the first telescopic sleeve (71) which is close to the top, the distance sensor (73) is connected on the outer side of the first telescopic sleeve (71), the alarm (74) is connected on the lower portion of the telescopic rod (72) in a rotating manner, and the alarm (74) and the distance sensor (73) are electrically connected.

### Claim 5

The spreader convenient for tiling indoor tiles according to claim 4, further comprising a pressing mechanism (8), wherein the pressing mechanism (8) comprises a gear (81), a third sliding rail (82), sliding rods (83), racks (84) and compression springs (85), wherein two gears (81) are respectively connected to the front side and the rear side of a positioning plate (65) on the left side and the right side, the front side and the rear side of a first sliding rail (3) are respectively connected with a third sliding rail (82), sliding rods (83) are respectively connected to the third sliding rail (82), racks (84) are respectively connected to the sliding rods (83) in a sliding mode, the inner sides of the racks (84) are respectively in press fit with adjacent suckers (5), the racks (84) are meshed with the adjacent gears (81), compression springs (85) are respectively wound on the sliding rods (83), and elastic pieces are respectively connected between the upper parts of the suckers (5) and the sliding sleeves (4).

### Claim 6

The spreader for conveniently spreading indoor tiles according to claim 5, further comprising a wiping mechanism (9), wherein the wiping mechanism (9) comprises a rotary handle (91), a rotary block (92) and a sponge (93), the rotary block (92) is rotatably connected to the outer side of the lower portion of the fixing base (1), the sponge (93) is connected to the front side and the rear side of the bottom of the rotary block (92), and the rotary handle (91) is connected between the front side and the rear side of the top of the rotary block (92).

### Claim 7

The spreader for laying indoor tiles conveniently according to claim 6, further comprising a water inlet mechanism (10), wherein the water inlet mechanism (10) comprises a touch block (101), a water tank (102), a ball valve (103) and a second torsion spring (104), the touch block (101) is welded on the left part of the second sliding rail (63), the water tank (102) is connected to the front side and the rear side of the upper part of the rotating handle (91) through screws, the lower part of the water tank (102) penetrates into the rotating handle (91) respectively, the lower part of the water tank (102) is communicated with a sponge (93), the lower part of the water tank (102) is rotationally connected with the ball valve (103), the ball valve (103) is in extrusion fit with the touch block (101), the ball valve (103) is rotationally connected with the rotating handle (91), and the second torsion spring (104) is connected between the ball valve (103) and the water tank (102).

### Claim 8

The spreader for conveniently spreading indoor tiles according to claim 7, further comprising a clamping mechanism (11), wherein the clamping mechanism (11) comprises a clamping block (111), a second telescopic sleeve (112) and an elastic block (113), the bottom of the second sliding rail (63) is connected with the second telescopic sleeve (112), the elastic block (113) is connected in the second telescopic sleeve (112), the inner side of the water tank (102) is connected with the clamping block (111), clamping holes are formed in the clamping block (111), and the elastic block (113) is matched with the clamping holes in a clamping mode.

## Full description

**[p0001]**

FIXED CONSTRUCTIONSBUILDINGFINISHING WORK ON BUILDINGS, e.g. STAIRS, FLOORSImplements for finishing work on buildingsImplements for finishing work on buildings for laying flooringImplements for finishing work on buildings for laying flooring of single elements, e.g. flooring cramps ; flexible websFIXED CONSTRUCTIONSBUILDINGSCAFFOLDING; FORMS; SHUTTERING; BUILDING IMPLEMENTS OR AIDS, OR THEIR USE; HANDLING BUILDING MATERIALS ON THE SITE; REPAIRING, BREAKING-UP OR OTHER WORK ON EXISTING BUILDINGSPreparing, conveying, or working-up building materials or building elements in situ; Other devices or measures for constructional workConveying or assembling building elementsTools or apparatusAdjusting tools; TemplatesMeans for positioning building parts or elementsPHYSICSMEASURING; TESTINGMEASURING LENGTH, THICKNESS OR SIMILAR LINEAR DIMENSIONS; MEASURING ANGLES; MEASURING AREAS; MEASURING IRREGULARITIES OF SURFACES OR CONTOURSMeasuring arrangements or details thereof, where the measuring technique is not covered by the other groups of this subclass, unspecified or not relevantMeasuring arrangements or details thereof, where the measuring technique is not covered by the other groups of this subclass, unspecified or not relevant for measuring depth

**[p0002]**

Description Make things convenient for indoor ceramic tile tiling's shop tie ware Technical Field The invention relates to the technical field of decoration, in particular to a spreader convenient for spreading indoor tiles. Background In the indoor decoration process, the tiles need to be paved on the ground, then the tiles need to be paved by using the paving devices, a plurality of paving devices are available on the market, and each paving device has different functions. Patent publication number is CN 211201081U's patent discloses supplementary instrument of paving of building ceramic tile, its characterized in that: the bearing device comprises a bearing base, wherein a plurality of universal wheels are arranged at the bottom of the bearing base, a stand column is fixedly arranged at the top of the center of the bearing base, a bearing tray is fixedly sleeved on the upper portion of the stand column, a rotary beam is movably arranged on the stand column at the top of the bearing tray, and the rotary beam is movably sleeved on the outer side wall of the stand column through a rotary hole in the middle of the rotary beam.

**[p0003]**

When using the supplementary instrument of paving of building ceramic tile to pave the ceramic tile, place the ceramic tile under two electric sucking discs earlier, people manually with the position adjustment back of ceramic tile, then use electric sucking disc to adsorb the ceramic tile, transport the position that needs to pave with the ceramic tile afterwards, then move electric sucking disc down and lay the ceramic tile in appointed position, people need to pay attention to the ceramic tile again to have and pave, it not only needs the position of people manual adjustment ceramic tile to use above-mentioned instrument of paving, still has to observe whether the ceramic tile paves, it is very troublesome to pave the ceramic tile like this, research and development at present makes things convenient for the paving ware of indoor ceramic tile tiling. Disclosure of Invention In order to overcome the defect that the prior paving machine is very troublesome in paving tiles, the invention aims to provide a paving machine which is convenient for paving indoor tiles.

**[p0004]**

The technical implementation scheme of the invention is as follows: the utility model provides a make things convenient for indoor tile tiling's shop spreader, including fixing base, handle, first slide rail, sliding sleeve, sucking disc, vibrator, positioning mechanism and accredited testing organization, fixing base upper portion is connected with the handle, and fixing base top left and right sides all is connected with first slide rail, and first slide rail lower part all is connected with the sliding sleeve, and slidingtype between the sliding sleeve is connected with the sucking disc, and the sucking disc cover is in the fixing base outside, and fixing base bottom intermediate junction has the vibrator, is equipped with accredited testing organization between fixing base and the first slide rail, is equipped with accredited testing organization on the accredited testing organization. Further, positioning mechanism is including pulling subassembly, second slide rail, slider, locating plate and first torsion spring, both sides all are connected with the second slide rail around the fixing base top, and second slide rail lower part and first slide rail lower part all are connected with the slider, and slider lower part all rotates to be connected with the locating plate, all is connected with two first torsion springs between locating plate and the slider, is equipped with pulling subassembly between first slide rail and the second slide rail, and pulling subassembly and slider are connected.

**[p0005]**

Further, the pulling assembly comprises a motor, a reel and pull ropes, the middle of the upper portion of the fixing seat is connected with the motor through a screw, the output shaft of the motor is connected with the reel, the reel is wound with four pull ropes, the pull ropes on the left side and the right side respectively penetrate into the first sliding rail, the pull ropes on the front side and the rear side respectively penetrate into the second sliding rail, and the end portions of the pull ropes are connected with similar sliding blocks. Further, the testing mechanism comprises a first telescopic sleeve, a telescopic rod, a distance sensor, an alarm and a reset spring, wherein the outer side of the sliding block is welded with the first telescopic sleeve, the telescopic rod is connected in the first telescopic sleeve in a sliding mode, the reset spring is connected between the top of the telescopic rod and the inner top wall of the similar first telescopic sleeve, the distance sensor is connected in the outer side of the first telescopic sleeve, the alarm is connected to the lower portion of the telescopic rod in a rotating mode, and the alarm and the distance sensor are electrically connected.

**[p0006]**

Further, the device comprises a pushing mechanism, the pushing mechanism comprises gears, third sliding rails, sliding rods, racks and compression springs, the front side and the rear side of a positioning plate on the left side and the right side are respectively connected with two gears, the front side and the rear side of a first sliding rail are respectively connected with the third sliding rails, the third sliding rails are respectively connected with the sliding rods in a sliding mode, the inner sides of the racks are respectively in extrusion fit with similar suckers, the racks are engaged with the similar gears, compression springs are respectively connected between the bottoms of the racks and the lower parts of the similar sliding rods, the compression springs are respectively wound on the sliding rods, and elastic pieces are respectively connected between the upper parts of the suckers and the sliding sleeves. Further, the cleaning mechanism comprises a rotating handle, a rotating block and a sponge, the outer side of the lower part of the fixing seat is rotationally connected with the rotating block, the front side and the rear side of the bottom of the rotating block are both connected with the sponge, and the rotating handle is connected between the front side and the rear side of the top of the rotating block.

**[p0007]**

Further, the water inlet mechanism comprises a touch block, a water tank, a ball valve and a second torsion spring, wherein the touch block is welded on the left part of the second sliding rail, the water tank is connected to the front side and the rear side of the upper part of the rotating handle through screws, the lower part of the water tank penetrates into the rotating handle respectively, the lower part of the water tank is communicated with a sponge, the ball valve is connected with the pressing fit of the touch block in a rotating mode, the ball valve is connected with the rotating handle in a rotating mode, and the second torsion spring is connected between the ball valve and the water tank. Further, still including screens mechanism, screens mechanism is including fixture block, flexible cover of second and elastic block, and second slide rail bottom all is connected with flexible cover of second, all is connected with the elastic block in the flexible cover of second, and the water tank inboard all is connected with the fixture block, all opens the draw-in hole on the fixture block, and elastic block and draw-in hole joint cooperation.

**[p0008]**

The beneficial effects of the invention are as follows: 1. according to the invention, the first torsion spring and the positioning plate are arranged, so that the positioning plate and four sides of the ceramic tile can be subjected to attaching and positioning, and the sucking disc can be positioned right above the ceramic tile, so that the ceramic tile can be paved on the ground subsequently. 2. When tiles are laid, the distance between the telescopic rods is detected by the distance sensor, so that the depth of the laid tiles is judged, and the tiles are assisted to be laid. 3. According to the invention, after the sucker is positioned, the positioning plate is matched with the rack through the gear and the rack when rotating, so that the rack moves downwards to enable the sucker to move downwards to automatically adsorb the ceramic tile, and the ceramic tile is conveniently tiled. 4. According to the invention, the rotary handle is rotated, so that the sucking disc wipes the sucking position on the ceramic tile firstly, and the ceramic tile is sucked by the sucking disc more tightly.

**[p0009]**

5. According to the invention, in the process of wiping the sponge in a rotating way, under the cooperation between the ball valve and the touch block, the water tank can be opened, and the sponge is soaked, so that the ceramic tile is wiped cleanly. Drawings Fig. 1 is a schematic perspective view of the present invention. Fig. 2 is a schematic perspective view of a first part of the present invention. Fig. 3 is a schematic perspective view of a second part of the present invention. Fig. 4 is a schematic perspective view of a first embodiment of a positioning mechanism according to the present invention. Fig. 5 is a schematic view of a second perspective structure of the positioning mechanism of the present invention. Fig. 6 is a schematic view of a part of a perspective structure of the positioning mechanism of the present invention. Fig. 7 is a schematic perspective view of a testing mechanism according to the present invention. FIG. 8 is a schematic view of a portion of a testing mechanism of the present invention.

**[p0010]**

Fig. 9 is a schematic perspective view of a pressing mechanism according to the present invention. Fig. 10 is a schematic view of a part of a pressing mechanism of the present invention. Fig. 11 is a schematic perspective view of a wiping mechanism according to the present invention. Fig. 12 is a schematic perspective view of a water inlet mechanism of the present invention. FIG. 13 is a schematic view of a water inlet mechanism of the present invention. Fig. 14 is a schematic perspective view of a detent mechanism of the present invention. Fig. 15 is a schematic view of a part of a three-dimensional structure of a detent mechanism of the present invention. The reference symbols in the drawings: 1. the device comprises a fixing seat, 2, a handle, 3, a first sliding rail, 4, a sliding sleeve, 5, a sucker, 51, a vibrator, 6, a positioning mechanism, 61, a motor, 62, a reel, 63, a second sliding rail, 64, a sliding block, 65, a positioning plate, 66, a pull rope, 67, a first torsion spring, 7, a testing mechanism, 71, a first telescopic sleeve, 72, a telescopic rod, 73, a distance sensor, 74, an alarm, 75, a return spring, 8, a pressing mechanism, 81, a gear, 82, a third sliding rail, 83, a sliding rod, 84, a rack, 85, a compression spring, 9, a wiping mechanism, 91, a rotating handle, 92, a rotating block, 93, a sponge, 10, a water inlet mechanism, 101, a touch block, 102, a water tank, 103, a ball valve, 104, a second torsion spring, 11, a clamping mechanism, 111, a clamping block, 112, a second telescopic sleeve, 113 and an elastic block.

**[p0011]**

Detailed Description The invention will be further illustrated by the following description of specific examples, which are given by the terms such as: setting, mounting, connecting are to be construed broadly, and may be, for example, fixed, removable, or integrally connected; can be mechanically or electrically connected; can be directly connected or indirectly connected through an intermediate medium, and can be communication between two elements. The specific meaning of the above terms in the present invention will be understood in specific cases by those of ordinary skill in the art. Example 1 The utility model provides a make things convenient for indoor tile tiling's shop tie-up, as shown in fig. 1-3, including fixing base 1, handle 2, first slide rail 3, sliding sleeve 4, sucking disc 5, vibrator 51, positioning mechanism 6 and testing mechanism 7, fixing base 1 upper portion is connected with handle 2, fixing base 1 top left and right sides all is connected with first slide rail 3, first slide rail 3 lower part all is connected with sliding sleeve 4, sliding connection has sucking disc 5 that is used for adsorbing the ceramic tile between the sliding sleeve 4, sucking disc 5 cover is in fixing base 1 outside, be connected with vibrator 51 in the middle of fixing base 1 bottom, be equipped with positioning mechanism 6 between fixing base 1 and the first slide rail 3, can fix a position sucking disc 5 in the middle of ceramic tile through positioning mechanism 6, be equipped with testing mechanism 7 on the positioning mechanism 6, testing mechanism 7 can automated in

**[p0011]**

spection out the height that the ceramic tile was laid, thereby improve the precision of tile tiling.

**[p0012]**

As shown in fig. 1, fig. 4, fig. 5 and fig. 6, the positioning mechanism 6 comprises a pulling component, a second sliding rail 63, a sliding block 64, a positioning plate 65 and a first torsion spring 67, wherein the front side and the rear side of the top of the fixed seat 1 are respectively connected with the second sliding rail 63, the lower parts of the second sliding rail 63 and the lower parts of the first sliding rail 3 are respectively connected with the sliding block 64 in a sliding manner, the lower parts of the sliding blocks 64 are respectively and rotatably connected with the positioning plate 65 for positioning the position of the sucker 5, two first torsion springs 67 are respectively connected between the positioning plate 65 and the sliding block 64, a pulling component is arranged between the first sliding rail 3 and the second sliding rail 63, the pulling component is connected with the sliding block 64, and the sliding block 64 can be pulled inwards through the pulling component, so that the positioning plate 65 also moves inwards; the pulling assembly comprises a motor 61, a reel 62 and a pull rope 66, wherein the middle of the upper part of the fixed seat 1 is connected with the motor 61 through a screw, the output shaft of the motor 61 is connected with the reel 62, the reel 62 is wound with four pull ropes 66, the pull ropes 66 on the left side and the right side respectively penetrate into the first sliding rail 3, the pull ropes 66 on the front side and the rear side respectively penetrate into the second sliding rail 63, the end parts of the pull

**[p0012]**

ropes 66 are connected with similar sliding blocks 64, the motor 61 drives the reel 62 to rotate, and accordingly the pull ropes 66 are wound to drive the sliding blocks 64 and the positioning plates 65 to move inwards.

**[p0013]**

As shown in fig. 1, 7 and 8, the testing mechanism 7 comprises a first telescopic sleeve 71, a telescopic rod 72, a distance sensor 73, an alarm 74 and a return spring 75, wherein the first telescopic sleeve 71 is welded on the outer side of the sliding block 64, the telescopic rod 72 is connected in the first telescopic sleeve 71 in a sliding mode, the return spring 75 is connected between the top of the telescopic rod 72 and the inner top wall of the similar first telescopic sleeve 71, the distance sensor 73 is connected on the outer side of the first telescopic sleeve 71, the alarm 74 is connected with the lower portion of the telescopic rod 72 in a rotating mode, the alarm 74 is connected with the distance sensor 73 through electrical connection, when tiles are paved, the alarm 74 is attached to the paved tiles, the first telescopic sleeve 71 moves downwards to drive the distance sensor 73 to move downwards, and when the distance between the distance sensor 73 and the lower portion of the telescopic rod 72 reaches a rated value, the alarm 74 gives an alarm so as to pave the tiles.

**[p0014]**

When people lay tiles, people can use the indoor tile laying device to lay tiles, firstly hold the handle 2, then move the sucker 5 to the position right above the tiles, then make the locating plate 65 attach to the four sides of the tiles, after the locating plate 65 attach to the four sides of the tiles completely, the position of the sucker 5 is positioned, the sucker 5 is positioned right above the tiles, then the tiles can be adsorbed, the motor 61 can be started, the output shaft of the motor 61 rotates to drive the pull rope 66 to wind, the pull rope 66 pulls the slide block 64 to move inwards, the slide block 64 drives the locating plate 65 to move inwards, when the locating plate 65 contacts with the fixed seat 1, the locating plate 65 is driven to rotate outwards, the first torsion spring 67 is twisted, the locating plate 65 is attached to the top surface of the tiles, and the handle 2 moves the fixed seat 1 downwards to drive the sucker 5 to move downwards and attach to the top of the tiles, so that the ceramic tile can be adsorbed, then the ceramic tile can be transported to a position needing to be paved, people can adjust the rated value of the distance sensor 73 in advance, the distance value between the distance sensor 73 and the telescopic rod 72 is adjusted, the distance value between the distance sensor 73 and the lower part of the telescopic rod 72 is consistent with the depth of the ceramic tile needing to be paved by moving downwards, then the vibrator 51 is started, the ceramic tile is downwards close to cement on the ground, the vibrator 51 can firs

**[p0014]**

tly contact the cement, so that the cement can be vibrated to pave the ceramic tile, moreover, the alarm 74 can firstly be close to the top of the rest ceramic tile which is paved, then the fixing seat 1 drives the ceramic tile to move downwards, the fixing seat 1 moves downwards so as to drive the first telescopic sleeve 71 and the distance sensor 73 to move downwards, the telescopic rod 72 and the alarm 74 are kept motionless, the reset spring 75 is compressed, when the distance value between the distance sensor 73 detects and the telescopic rod 72 reaches the rated value, the corresponding alarm 74 can send out an alarm, the corresponding side of the corresponding alarm 74 is indicated to reach the designated depth, if the rest of alarms 74 do not send out an alarm, the situation that the fixed seat 1 possibly inclines is indicated, then people can continuously adjust the positions of the fixed seat 1 and the ceramic tile until four alarms send out an alarm together, people can put down the ceramic tile and close the vibrator 51, then the sucking disc 5 is far away from the ceramic tile, so that the ceramic tile can be paved flatly, the alarm 74 can be separated from the ceramic tile, the telescopic rod 72 and the alarm 74 can be driven to move downwards to reset under the action of the reset spring 75, the distance between the distance sensor 73 detects and the lower part of the telescopic rod 72 is smaller than the rated value, the alarm can stop working, then people can control the output shaft of the motor 61 to invert, the winding wheel 62 to loosen 66, then people

**[p0014]**

can move the sliding block 64 and the positioning plate 65 to reset outwards, and after the positioning plate 65 and the ceramic tile are separated, the positioning plate 65 and the ceramic tile are separated from the ceramic tile, the position of the ceramic tile can be accurately paved, and the ceramic tile can be accurately positioned through the positioning plate 65, and the position of the sucking disc 65 can be accurately paved by the positioning plate 5 under the action of the first positioning plate, and the positioning plate can be more accurately paved by the positioning the ceramic tile, and the position of the ceramic tile can be accurately paved by the position of the sucking disc 65.

**[p0015]**

Example 2 On the basis of embodiment 1, as shown in fig. 1, 9 and 10, the device further comprises a pressing mechanism 8 capable of automatically pressing down and absorbing the suction cup 5 when the positioning plate 65 rotates, wherein the pressing mechanism 8 comprises a gear 81, a third sliding rail 82, a sliding rod 83, a rack 84 and a compression spring 85, two gears 81 are connected to the front side and the rear side of the positioning plate 65 on the left side and the right side, the front side and the rear side of the first sliding rail 3 are respectively connected with the third sliding rail 82, sliding rods 83 are respectively connected to the front side and the rear side of the first sliding rail 3 in a sliding manner, racks 84 are respectively in press fit with the adjacent suction cup 5 on the inner side of the racks 83, the racks 84 are meshed with the adjacent gears 81, compression springs 85 are respectively connected between the bottoms of the racks 84 and the lower parts of the adjacent sliding rods 83, the compression springs 85 are respectively wound on the sliding rods 83, and when the positioning plate 65 rotates to drive the gears 81, the racks 84 are respectively moved down to apply pressure to the suction cup 5, thus the suction cup 5 is automatically absorbed, and elastic pieces are respectively connected between the upper parts of the suction cup 5 and the sliding sleeve 4.

**[p0016]**

When the locating plate 65 moves inwards and rotates, the locating plate 65 also pushes the rack 84 to move inwards through the gear 81, so that the sliding rod 83 moves inwards, the rack 84 is driven to move downwards through the gear 81 when the locating plate 65 rotates, the compression spring 85 is compressed, the sucker 5 is driven to move downwards through the downward movement of the rack 84, the elastic piece is compressed, at the moment, the sucker 5 can automatically move downwards to adsorb tiles when the locating plate 65 rotates, tiles can be paved more conveniently, after the tiles are paved flatly, the locating plate 65 can reversely rotate to reset, the rack 84 is driven to move upwards to reset under the action of the gear 81 and the compression spring 85, the sucker 5 can also be driven to move upwards to reset under the action of the elastic piece, and then people can push the sliding rod 83 and the rack 84 to reset to the outer side. As shown in fig. 1 and 11, the ceramic tile cleaning device further comprises a wiping mechanism 9 for wiping the ceramic tile, the wiping mechanism 9 comprises a rotating handle 91, a rotating block 92 and a sponge 93, the outer side of the lower portion of the fixing seat 1 is rotatably connected with the rotating block 92, the front side and the rear side of the bottom of the rotating block 92 are both connected with the sponge 93, the rotating handle 91 is connected between the front side and the rear side of the top of the rotating block 92, the rotating block 92 and the sponge 93 are driven to rotate by rotating the ro

**[p0016]**

tating handle 91, and the sponge 93 can clean impurities on the ceramic tile.

**[p0017]**

Before adsorbing the ceramic tile, can laminate sponge 93 on the ceramic tile, then rotate 360 degrees with rotatory handle 91, rotate 360 degrees with rotatory piece 92 and sponge 93 are driven to rotatory handle 91, and sponge 93 then can clean the impurity of ceramic tile top, so that sucking disc 5 is inseparabler adsorbs the ceramic tile. As shown in fig. 1, 12 and 13, the automatic water inlet mechanism 10 is further included, the automatic water inlet mechanism 10 includes a touch block 101, a water tank 102, a ball valve 103 and a second torsion spring 104, the left part of the second sliding rail 63 is welded with the touch block 101, the front and rear sides of the upper part of the rotating handle 91 are respectively connected with the water tank 102 through screws, the lower part of the water tank 102 respectively penetrates into the rotating handle 91, the lower part of the water tank 102 is communicated with the sponge 93, the lower part of the water tank 102 is respectively and rotatably connected with the ball valve 103, the ball valve 103 is in press fit with the touch block 101, the ball valve 103 is rotatably connected with the rotating handle 91, the ball valve 103 is connected with the water tank 102 through the second torsion spring 104, when the rotating handle 91 rotates to drive the water tank 102 and the ball valve 103 to revolve, the ball valve 103 is opened after being separated, and water drops onto the sponge 93.

**[p0018]**

Initially, the touch block 101 and the ball valve 103 are in an extrusion state, the second torsion spring 104 is in a twisted state, water is injected into the water tank 102, when the rotary handle 91 is rotated, the rotary handle 91 drives the water tank 102 and the ball valve 103 to revolve, after the ball valve 103 is separated from the touch block 101, the ball valve 103 is driven to rotate under the action of the second torsion spring 104 to open the water tank 102, so that the water enters the sponge 93, the sponge 93 is wet, the tile can be wiped more cleanly, the suction cup 5 is adsorbed more tightly, when the rotary handle 91 rotates to reset to drive the ball valve 103 to contact with the touch block 101 again, the touch block 101 rotates to reset, the water tank 102 is closed, and the second torsion spring 104 is twisted. As shown in fig. 1, 14 and 15, the water tank 102 clamping device further comprises a clamping mechanism 11 for clamping the water tank 102, the clamping mechanism 11 comprises a clamping block 111, a second telescopic sleeve 112 and an elastic block 113, the bottom of the second sliding rail 63 is connected with the second telescopic sleeve 112, the second telescopic sleeve 112 is internally connected with the elastic block 113, the inner side of the water tank 102 is connected with the clamping block 111, and clamping holes are formed in the clamping block 111, and the elastic block 113 is matched with the clamping holes in a clamping manner.

**[p0019]**

The clamping block 111 can be driven to rotate when the water tank 102 rotates, after the clamping block 111 is separated from the elastic piece, the elastic piece stretches and resets, after the water tank 102 rotates and resets, the clamping block 111 and the elastic piece can be contacted again, the elastic piece can be clamped in the clamping hole, the position of the water tank 102 can be limited, the position of the sponge 93 can rotate and reset, and the sponge 93 can not influence the sucking disc 5 to adsorb ceramic tiles. The embodiments described above are intended to provide those skilled in the art with a full range of modifications and variations to the embodiments described above without departing from the inventive concept thereof, and therefore the scope of the invention is not limited by the embodiments described above, but is to be accorded the broadest scope consistent with the innovative features recited in the claims.

## Classifications

- E04F21/22
- E04G21/1841
- G01B21/18

---

Generated by IPtorch. Verify legal conclusions against the official publication.
