# 47. Vacuum locking vibration base

- **Archive rank:** 47 of 50
- **Publication:** [CN-108016828-B](https://patents.google.com/patent/CN108016828B/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/062074599/publication/CN108016828B?q=pn%3DCN108016828B)
- **Publication date:** 2024-07-09
- **Filing date:** 2017-12-25
- **Earliest priority:** 2017-12-25
- **Family:** 62074599
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Abstract

The invention discloses a vacuum locking vibration base, and belongs to the technical field of vibration bases. The vacuum cover plate comprises a vacuum sucker, a sealing ring, a vacuum cover plate, a vacuum suction nozzle, a sealing joint, a vacuum pipeline, a quick-mounting joint and an external pipeline. Through arranging the vacuum chuck and the vacuum cover plate which are matched with each other, an adsorption cavity is formed, and after the vacuum is pumped by the vacuum nozzle, the vacuum cover plate can be firmly adsorbed on the vacuum chuck and vibrates together; the vacuum pump is closed, so that the disassembling work between the vacuum cover plate and the vacuum chuck can be completed, the assembly and the disassembly are very convenient, and the frequent disassembly can not generate damage; the positioning shaft and the positioning clamping groove can prevent the vacuum cover plate from rotating and misplacing, the groove and the convex groove can prevent the vacuum cover plate from translating and misplacing, and the two positioning modes are matched, so that the accurate positioning function can be realized; besides the fixed vibrating disk, other working parts needing vibrating driving can be fixed above the vacuum cover plate.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-108016828-B/pdf000.png)

![Sketch 1 for CN-108016828-B](https://nimo.iptorch.com/refdrawing/CN-108016828-B/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-108016828-B/pdf001.png)

![Sketch 2 for CN-108016828-B](https://nimo.iptorch.com/refdrawing/CN-108016828-B/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/CN-108016828-B/pdf002.png)

![Sketch 3 for CN-108016828-B](https://nimo.iptorch.com/refdrawing/CN-108016828-B/pdf002.png)

## Claims

### Claim 1

1. The utility model provides a vacuum locking vibration base, it mainly includes the shell to and establish at inside elastic support, electro-magnet, vibrating armature, lower vibrating plate, bumper shock absorber of shell, establish the vibration platform at the shell top, vibrating platform passes through elastic support and lower vibrating plate swing joint, and lower vibrating plate passes through the bumper shock absorber with the shell bottom and is connected, and the electro-magnet is fixed on vibrating plate down, and vibrating armature is fixed in the vibration platform below, and vibrating armature is adsorbed the motion by the electro-magnet, through the periodic variation of electric current in the electro-magnet, causes vibrating armature and vibrating platform vibration, its characterized in that: the vacuum pipe comprises a vacuum cover plate, a vacuum suction nozzle, a sealing joint, a vacuum pipe, a quick-mounting joint and an external pipe;

### Claim 2

The vacuum chuck is fixed on the vibration platform, and a circle of sealing ring is arranged on the upper surface of the vacuum chuck;

### Claim 3

the vacuum cover plate is placed on the vacuum chuck, and a closed adsorption cavity is formed among the vacuum chuck, the sealing ring and the vacuum cover plate;

### Claim 4

The vacuum suction nozzle is fixed on the vacuum suction disc in a sealing way through a sealing joint and is positioned in the suction cavity, and a vacuum pipeline is connected below the sealing joint;

### Claim 5

The shell bottom is equipped with the trompil, and vacuum pipe wears out from the trompil and is connected with outside pipeline through quick-operation joint, and outside pipeline connects the vacuum pump, and the vacuum pump will adsorb the intracavity air and take out, and vacuum chuck and vacuum apron firmly adsorb together, and vacuum apron, vacuum chuck, vacuum pipe, outside pipeline vibrate together along with vibration platform, vacuum apron side is equipped with the location axle, and vacuum chuck side is equipped with corresponding location draw-in groove, will fix a position the axle card in the location draw-in groove during the installation, vacuum apron lower surface is the recess, and vacuum chuck upper surface is the tongue of corresponding shape, and the recess is detained on the tongue, prevents sliding dislocation.

### Claim 6

2. The vacuum lock vibration mount of claim 1, wherein: and a vibration disc for vibrating and conveying materials is fixed above the vacuum cover plate.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSJigging conveyorsApplications of devices for generating or transmitting jigging movementsApplications of devices for generating or transmitting jigging movements of vibrators, i.e. devices for producing movements of high frequency and small amplitudeElectromagnetic devicesPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSJigging conveyorsSupports or mountings for load-carriers, e.g. framework, bases, spring arrangementsMECHANICAL ENGINEERING; LIGHTING; HEATING; WEAPONS; BLASTINGENGINEERING ELEMENTS AND UNITS; GENERAL MEASURES FOR PRODUCING AND MAINTAINING EFFECTIVE FUNCTIONING OF MACHINES OR INSTALLATIONS; THERMAL INSULATION IN GENERALDEVICES FOR FASTENING OR SECURING CONSTRUCTIONAL ELEMENTS OR MACHINE PARTS TOGETHER, e.g. NAILS, BOLTS, CIRCLIPS, CLAMPS, CLIPS OR WEDGES; JOINTS OR JOINTINGSuction cups for attaching purposes; Equivalent means using adhesives

Description

Vacuum locking vibration base

TechnicalâField

The invention relates to a vacuum locking vibration base, and belongs to the technical field of vibration bases.

Background

The vibration base is a driving mechanism for driving the vibration plate to convey materials. The vibrating plate is movably connected with the lower vibrating plate through the elastic support, the lower vibrating plate is connected with the bottom of the shell through the shock absorber, the electromagnet is fixed on the lower vibrating plate, the vibrating armature is fixed below the vibrating platform and is attracted by the electromagnet to move, the vibrating armature and the vibrating platform vibrate through periodic change of current in the electromagnet, and a vibrating disc fixed on the vibrating platform and used for directional ordered material conveying starts to work.

For the production of vibration disks for pharmaceutical products, it is particularly necessary to keep the structure between the vibration disk and the vibration base clean, so that frequent removal of the vibration disk from the vibration base is required for cleaning dust and foreign matter. At present, the fixed locking mode between vibration dish and the vibration base is more traditional, generally adopts the spiro union locking mode, and it is more time consuming and labor consuming to dismantle, and the multiple dismantlement leads to the fact the smooth silk easily, finally leads to unable fixed. Therefore, in order to facilitate the disassembly, the vibration disk is fixed by the vacuum adsorption structure, the disassembly is very convenient, and the vibration disk can be frequently disassembled without damage.

Disclosure of Invention

The technical problems to be solved by the invention are as follows: the vacuum locking vibration base solves the problems that the existing vibration plate and the vibration base are generally fixed in a screwed mode, the disassembly is time-consuming and labor-consuming, sliding wires are easily caused by repeated disassembly, and finally the fixation cannot be achieved.

The technical problems to be solved by the invention are realized by adopting the following technical scheme:

the vacuum locking vibration base mainly comprises a shell, an elastic support, an electromagnet, a vibration armature, a lower vibration plate and a shock absorber, wherein the elastic support, the electromagnet, the vibration armature, the lower vibration plate and the shock absorber are arranged in the shell, the vibration platform is arranged at the top of the shell and is movably connected with the lower vibration plate through the elastic support, the lower vibration plate is connected with the bottom of the shell through the shock absorber, the electromagnet is fixed on the lower vibration plate, the vibration armature is fixed below the vibration platform, the vibration armature is attracted by the electromagnet to move, and the vibration armature and the vibration platform vibrate due to the periodical change of current in the electromagnet, and the vacuum locking vibration base further comprises a vacuum sucker, a sealing ring, a vacuum cover plate, a vacuum suction nozzle, a sealing joint, a vacuum pipeline, a quick-mounting joint and an external pipeline;

The vacuum chuck is fixed on the vibration platform, and a circle of sealing ring is arranged on the upper surface of the vacuum chuck;

the vacuum cover plate is placed on the vacuum chuck, and a closed adsorption cavity is formed among the vacuum chuck, the sealing ring and the vacuum cover plate;

The vacuum suction nozzle is fixed on the vacuum suction disc in a sealing way through a sealing joint and is positioned in the suction cavity, and a vacuum pipeline is connected below the sealing joint;

The shell bottom is equipped with the trompil, and vacuum pipe wears out from the trompil and is connected with outside pipeline through quick-operation joint, and outside pipeline connection vacuum pump, vacuum pump will adsorb the cavity in the air and take out, and vacuum chuck and vacuum cover firmly adsorb together, and vacuum cover, vacuum chuck, vacuum pipe, outside pipeline vibrate along with vibration platform together.

As a preferable example, a positioning shaft is arranged on the side face of the vacuum cover plate, a corresponding positioning clamping groove is arranged on the side face of the vacuum chuck, and the positioning shaft is clamped in the positioning clamping groove during installation.

As a preferable example, the lower surface of the vacuum cover plate is provided with a groove, the upper surface of the vacuum sucker is provided with a convex groove with a corresponding shape, and the groove is buckled on the convex groove to prevent sliding dislocation.

As a preferable example, a vibration plate for vibrating the material is fixed above the vacuum cover plate.

The beneficial effects of the invention are as follows: through arranging the vacuum chuck and the vacuum cover plate which are matched with each other, an adsorption cavity is formed, and after the vacuum is pumped by the vacuum nozzle, the vacuum cover plate can be firmly adsorbed on the vacuum chuck and vibrates together; the vacuum pump is closed, so that the disassembling work between the vacuum cover plate and the vacuum chuck can be completed, the assembly and the disassembly are very convenient, and the frequent disassembly can not generate damage; the positioning shaft and the positioning clamping groove can prevent the vacuum cover plate from rotating and misplacing, the groove and the convex groove can prevent the vacuum cover plate from translating and misplacing, and the two positioning modes are matched, so that the accurate positioning function can be realized; besides the fixed vibrating disk, other working parts needing vibrating driving can be fixed above the vacuum cover plate.

Drawings

FIG. 1 is a schematic view of a vacuum cover plate and vacuum chuck in a separated state;

FIG. 2 is a schematic view of the structure of the vacuum cover plate and vacuum chuck in the locked state of the invention;

Fig. 3 is a schematic view of the external structure of the invention after locking.

In the figure: the device comprises a shell 1, an elastic support 2, an electromagnet 3, a vibrating armature 4, a vibrating platform 5, a vacuum chuck 6, a sealing ring 7, a vacuum cover plate 8, a vacuum suction nozzle 9, a sealing joint 10, a vacuum pipeline 11, a quick-assembly joint 12, an external pipeline 13, a suction cavity 14, an opening 15, a positioning shaft 16, a positioning clamping groove 17, a vibrating disc 18, a lower vibrating plate 19 and a shock absorber 20.

DetailedâDescription

The invention will be further described with reference to the following detailed drawings, in order to make the technical means, the creation characteristics, the achievement of the purpose and the effect of the invention easy to understand.

As shown in fig. 1-3, the vacuum locking vibration base mainly comprises a shell 1, an elastic support 2, an electromagnet 3, a vibration armature 4, a lower vibration plate 19 and a shock absorber 20 which are arranged in the shell 1, a vibration platform 5 arranged at the top of the shell 1, wherein the vibration platform 5 is movably connected with the lower vibration plate 19 through the elastic support 2, the lower vibration plate 19 is connected with the bottom of the shell 1 through the shock absorber 20, the electromagnet 3 is fixed on the lower vibration plate 19, the vibration armature 4 is fixed below the vibration platform 5, the vibration armature 4 is adsorbed by the electromagnet 3 to move, and the vibration armature 4 and the vibration platform 5 are caused to vibrate through the periodical change of current in the electromagnet 3, and the vacuum locking vibration base further comprises a vacuum chuck 6, a sealing ring 7, a vacuum cover plate 8, a vacuum suction nozzle 9, a sealing joint 10, a vacuum pipeline 11, a quick-fit joint 12 and an external pipeline 13;

The vacuum chuck 6 is fixed on the vibration platform 5, and a circle of sealing ring 7 is arranged on the upper surface of the vacuum chuck 6;

the vacuum cover plate 8 is placed on the vacuum chuck 6, and a closed adsorption cavity 14 is formed among the vacuum chuck 6, the sealing ring 7 and the vacuum cover plate 8;

the vacuum suction nozzle 9 is fixed on the vacuum suction disc 6 in a sealing way through a sealing joint 10 and is positioned in the suction cavity 14, and a vacuum pipeline 11 is connected below the sealing joint 10;

The shell 1 bottom is equipped with trompil 15, and vacuum pipe 11 wears out from trompil 15 and is connected with outside pipeline 13 through quick-operation joint 12, and the trompil 15 diameter is great, and is all contactless with vacuum pipe 11, quick-operation joint 12, and outside pipeline 13 is connected the vacuum pump (not shown in the figure), and the vacuum pump will adsorb the interior air of cavity 14 and take out, and vacuum chuck 6 and vacuum apron 8 firmly adsorb together, and vacuum apron 8, vacuum chuck 6, vacuum pipe 11, outside pipeline 13 vibrate along with vibration platform 5 together. To avoid vibrations affecting the tightness of the pipe connection, the outer pipe 13 is connected to a vacuum pump using a flexible pipe.

The side of the vacuum cover plate 8 is provided with a positioning shaft 16, the side of the vacuum chuck 6 is provided with a corresponding positioning clamping groove 17, and the positioning shaft 16 is clamped in the positioning clamping groove 17 during installation.

The lower surface of the vacuum cover plate 8 is provided with a groove, the upper surface of the vacuum chuck 6 is provided with a convex groove with a corresponding shape, and the groove is buckled on the convex groove to prevent sliding dislocation.

A vibration plate 18 for vibrating and conveying materials is fixed above the vacuum cover plate 8.

Working principle: by arranging the matched vacuum chuck 6 and the vacuum cover plate 8, an adsorption cavity 14 is formed. When the vacuum cover plate 8 is installed, the vacuum cover plate 8 is placed on the vacuum chuck 6, the positioning shaft 16 is clamped in the positioning clamping groove 17, the vacuum pump is turned on, after the vacuum suction nozzle 9 is used for vacuumizing, the vacuum cover plate 8 can be firmly adsorbed on the vacuum chuck 6, and the vacuum cover plate and the vacuum chuck vibrate together, so that the vibration plate 18 is driven to vibrate; the vacuum pump is closed, so that the disassembling work between the vacuum cover plate 8 and the vacuum chuck 6 can be completed, the assembly and the disassembly are very convenient, and the frequent disassembly can not generate damage; when the vacuum cover plate is installed, the positioning shaft 16 is clamped in the positioning clamping groove 17, so that the vacuum cover plate 8 can be prevented from rotating and misplacing; the grooves and the convex grooves can prevent the vacuum cover plate 8 from translating and misplacing, and the two positioning modes are matched, so that the accurate positioning effect can be achieved; in addition to the vibration plate 18, other working parts that need to be driven by vibration, such as a vibration hopper, a vibration pot, etc., can be fixed above the vacuum cover plate 8.

The foregoing has shown and described the basic principles and main features of the present invention and the advantages of the present invention. It will be appreciated by persons skilled in the art that the present invention is not limited to the embodiments described above, but is capable of numerous variations and modifications without departing from the spirit and scope of the invention, which is defined in the claims. The scope of the invention is defined by the appended claims and equivalents thereof.

## Classifications

- B65G27/24
- B65G27/08
- B65G27/08
- B65G27/24
- F16B47/00
- F16B47/00

## Cited patent documents

- [CN-105775626-A](https://patents.google.com/patent/CN105775626A/en) — SEA
- [CN-107271125-A](https://patents.google.com/patent/CN107271125A/en) — SEA
- [CN-207726179-U](https://patents.google.com/patent/CN207726179U/en) — SEA

---

Generated by IPtorch. Verify legal conclusions against the official publication.
