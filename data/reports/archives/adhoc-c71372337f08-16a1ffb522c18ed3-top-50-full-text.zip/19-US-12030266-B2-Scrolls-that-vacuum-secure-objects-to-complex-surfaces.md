# 19. Scrolls that vacuum secure objects to complex surfaces

- **Archive rank:** 19 of 50
- **Publication:** [US-12030266-B2](https://patents.google.com/patent/US12030266B2/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/074844794/publication/US12030266B2?q=pn%3DUS12030266B2)
- **Publication date:** 2024-07-09
- **Filing date:** 2020-03-13
- **Earliest priority:** 2020-03-13
- **Family:** 74844794
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery

## Parties

- **Applicant / assignee:** BOEING CO
- **Inventors:** ANDERSON ERIC CARLTON; HALBRITTER ALLEN JAMES; JOHNSON DANIEL; LEE ADAM; VELASQUEZ LUIS

## Abstract

Systems and methods are provided for compacting objects onto tools. One embodiment is a method for compacting an object onto a rigid tool. The method includes placing an object onto a surface of a rigid tool, disposing an end effector over the object, spreading linkages of the end effector, causing a scroll of material between the linkages to be disposed atop the object while surrounding the object, and applying a negative pressure to the scroll that offsets air leaks between the scroll and the object, thereby forming a suction hold that compacts the object onto the rigid tool.

## Sketches and drawings

[Sketch 1](https://patentimages.storage.googleapis.com/02/94/eb/5deb066d18a8c7/US12030266-20240709-D00000.png)

![Sketch 1 for US-12030266-B2](https://patentimages.storage.googleapis.com/02/94/eb/5deb066d18a8c7/US12030266-20240709-D00000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/c6/c3/a6/fa0a576562b6c7/US12030266-20240709-D00001.png)

![Sketch 2 for US-12030266-B2](https://patentimages.storage.googleapis.com/c6/c3/a6/fa0a576562b6c7/US12030266-20240709-D00001.png)

[Sketch 3](https://patentimages.storage.googleapis.com/75/ef/af/9968c9d2eda987/US12030266-20240709-D00002.png)

![Sketch 3 for US-12030266-B2](https://patentimages.storage.googleapis.com/75/ef/af/9968c9d2eda987/US12030266-20240709-D00002.png)

[Sketch 4](https://patentimages.storage.googleapis.com/6e/a1/44/01b0ebb0ea522a/US12030266-20240709-D00003.png)

![Sketch 4 for US-12030266-B2](https://patentimages.storage.googleapis.com/6e/a1/44/01b0ebb0ea522a/US12030266-20240709-D00003.png)

[Sketch 5](https://patentimages.storage.googleapis.com/1c/b5/95/d62c94f9e7a989/US12030266-20240709-D00004.png)

![Sketch 5 for US-12030266-B2](https://patentimages.storage.googleapis.com/1c/b5/95/d62c94f9e7a989/US12030266-20240709-D00004.png)

[Sketch 6](https://patentimages.storage.googleapis.com/2f/48/78/7c9c9f4b966c64/US12030266-20240709-D00005.png)

![Sketch 6 for US-12030266-B2](https://patentimages.storage.googleapis.com/2f/48/78/7c9c9f4b966c64/US12030266-20240709-D00005.png)

[Sketch 7](https://patentimages.storage.googleapis.com/9d/c0/5a/c8b0e6e581a20a/US12030266-20240709-D00006.png)

![Sketch 7 for US-12030266-B2](https://patentimages.storage.googleapis.com/9d/c0/5a/c8b0e6e581a20a/US12030266-20240709-D00006.png)

[Sketch 8](https://patentimages.storage.googleapis.com/22/98/89/f58aaa0c80fcd0/US12030266-20240709-D00007.png)

![Sketch 8 for US-12030266-B2](https://patentimages.storage.googleapis.com/22/98/89/f58aaa0c80fcd0/US12030266-20240709-D00007.png)

[Sketch 9](https://patentimages.storage.googleapis.com/f4/fc/fd/a218827fa43281/US12030266-20240709-D00008.png)

![Sketch 9 for US-12030266-B2](https://patentimages.storage.googleapis.com/f4/fc/fd/a218827fa43281/US12030266-20240709-D00008.png)

[Sketch 10](https://patentimages.storage.googleapis.com/bf/02/36/a5b9d75dc07426/US12030266-20240709-D00009.png)

![Sketch 10 for US-12030266-B2](https://patentimages.storage.googleapis.com/bf/02/36/a5b9d75dc07426/US12030266-20240709-D00009.png)

[Sketch 11](https://patentimages.storage.googleapis.com/22/2b/1e/971c4faf3f194d/US12030266-20240709-D00010.png)

![Sketch 11 for US-12030266-B2](https://patentimages.storage.googleapis.com/22/2b/1e/971c4faf3f194d/US12030266-20240709-D00010.png)

[Sketch 12](https://patentimages.storage.googleapis.com/1a/c6/0a/8346d7198f5fcf/US12030266-20240709-D00011.png)

![Sketch 12 for US-12030266-B2](https://patentimages.storage.googleapis.com/1a/c6/0a/8346d7198f5fcf/US12030266-20240709-D00011.png)

[Sketch 13](https://patentimages.storage.googleapis.com/78/b8/a6/5627b6dd8b3d9f/US12030266-20240709-D00012.png)

![Sketch 13 for US-12030266-B2](https://patentimages.storage.googleapis.com/78/b8/a6/5627b6dd8b3d9f/US12030266-20240709-D00012.png)

## Claims

### Claim 1 (independent)

A method for compacting an object placed onto a surface of a rigid tool, the method comprising: unrolling, from a spindle, a scroll of material over an object, the scroll of material comprising a permeable layer, an impermeable membrane that overlays the permeable layer and that extends beyond a boundary of the permeable layer, and an impermeable layer under the permeable layer, wherein the step of unrolling further comprises: disposing an end effector over the object; and spreading linkages of the end effector, causing the scroll of material to be disposed atop the object while surrounding the object; and applying a negative pressure to a chamber inside of the spindle, wherein the chamber is in fluid communication with the permeable layer, wherein the negative pressure in the permeable layer offsets air leaks between the scroll of material and the object, thereby forming a suction hold that compacts the object onto the rigid tool.

### Claim 2

The method of claim 1 wherein: spreading the linkages of the end effector rotates spindles that are coupled with the linkages and that store the scroll of material, causing the scroll of material to be dispensed.

### Claim 3

The method of claim 1 further comprising: contracting the linkages after compaction, causing the scroll of material to be drawn up from the object.

### Claim 4

The method of claim 1 wherein: spreading the linkages is performed by driving the end effector towards the rigid tool.

### Claim 5

The method of claim 1 wherein: spreading linkages of the end effector comprises pivoting the linkages relative to the end effector.

### Claim 6

The method of claim 1 wherein: applying the negative pressure draws flaps of the impermeable membrane of the scroll of material into contact with the rigid tool.

### Claim 7

The method of claim 1 further comprising: prior to unrolling, disposing a spindle upon which the scroll of material is rolled, atop the object.

### Claim 8

The method of claim 1 wherein: applying the negative pressure is performed via multiple perforations at a spindle that link a chamber of the spindle to the permeable layer.

### Claim 9

The method of claim 8 wherein: applying the negative pressure is performed via a vacuum port in fluid communication with the chamber.

### Claim 10

The method of claim 1 further comprising: distributing the negative pressure across the impermeable membrane via the permeable layer.

### Claim 11

The method of claim 1 wherein: unrolling the scroll of material comprises covering a preform for a composite part.

### Claim 12

The method of claim 1 further comprising: compacting the object via the suction hold.

### Claim 13

The method of claim 1 further comprising: affixing an end of the scroll of material to the rigid tool.

### Claim 14

The method of claim 13 wherein: affixing the end of the scroll of material comprises taping the end of the scroll of material to the rigid tool.

### Claim 15 (independent)

A method comprising: disposing a spindle atop an object that is located at a mandrel, wherein a scroll of material is wrapped around the spindle, and wherein the scroll of material comprises a permeable layer covered by an impermeable membrane and an impermeable layer under the permeable layer; affixing a first end of the scroll of material to the mandrel, wherein an opposite end of the scroll of material is affixed to the spindle in an area of the spindle that is in fluid communication with the permeable layer of the scroll of material; applying negative pressure to a chamber inside of the spindle, wherein the chamber is in fluid communication with the permeable layer, wherein the negative pressure in the permeable layer offsets air leaks between the scroll of material and the object, thereby forming a suction hold that compacts the object onto a rigid tool, thereby forming a suction hold that places the material into contact with the object; and unrolling the scroll of material by rotating the spindle while the negative pressure is applied.

### Claim 16

The method of claim 15 wherein: affixing the end of the scroll of material comprises taping the end of the scroll of material to the mandrel.

### Claim 17

The method of claim 15 wherein: affixing the end of the scroll of material comprises forming a suction hold between an impermeable membrane of the material and the mandrel.

### Claim 18

The method of claim 15 wherein: applying the negative pressure is performed via multiple perforations at the spindle that link a chamber of the spindle to the permeable layer, wherein the multiple perforations are in the area of the spindle that is in fluid communication with the permeable layer of the scroll of material.

### Claim 19

The method of claim 15 wherein: unrolling the scroll of material comprises covering a preform for a composite part.

### Claim 20

The method of claim 15 further comprising: compacting the object via the suction hold.

### Claim 21

The method of claim 15 further comprising: distributing the negative pressure across an impermeable membrane via the permeable layer.

### Claim 22

The method of claim 15 further comprising: placing the permeable layer directly into contact with the object during the unrolling.

## Full description

### Field

**[p0001]**

The disclosure relates to the field of fabrication, and in particular, to preparation of composite parts.

### Background

**[p0002]**

Composite parts, such as carbon fiber parts, are formed by hardening preforms of fiber reinforced material while maintaining desired amounts of pressure and temperature. A preform that has not yet been hardened into a composite part does not yet exhibit full structural strength. Thus, a “green” preform may be incapable of supporting itself as laid-up onto a surface (e.g., a vertical or other non-horizontal surface) before it is hardened. This complicates the layup of large preforms onto complex surfaces (e.g., barrel shapes), because it increases the chance of a portion of a preform peeling off or shifting off of the forming tool before layup has been completed. Hence, accurate placement or locating of large and/or unwieldy layups remains difficult. For preforms that are hardened via vacuum bag curing techniques, it is difficult to secure a vacuum bag around the preform before the preform peels away from (or shifts relative to) a corresponding complex surface. Further complicating the issue, materials such as tacky tape, which are used to secure the vacuum bag to the tool surface, are not contact approved and hence are not allowed to touch the uncured/unhardened composite material. As a result the entire layup must be completed prior to the application of the vacuum bag and affixation of the vacuum bag (via sealant) to the complex surface. Thus, it remains desirable to quickly and effectively secure preforms (and/or other objects) to complex surfaces, particularly when preforms are being arranged into complex assemblies.

**[p0003]**

Therefore, it would be desirable to have a method and apparatus that take into account at least some of the issues discussed above, as well as other possible issues.

### Summary

**[p0004]**

Embodiments described herein provide techniques wherein a scroll of material is rapidly deployed onto a preform that has been placed onto a mandrel. The scroll includes a permeable layer that enables airflow, as well as an impermeable layer that extends beyond the boundary of the permeable layer. During and after placement of the scroll, application of negative pressure causes the scroll to press into and compact an underlying preform, via a tapeless compaction process. After compaction has been completed, the scroll can be rapidly removed to enable vacuum bagging and hardening of the preform to take place. One embodiment is a method for compacting an object onto a rigid tool. The method includes placing an object onto a surface of a rigid tool, disposing an end effector over the object, spreading linkages of the end effector, causing a scroll of material between the linkages to be disposed atop the object while surrounding the object, and applying a negative pressure to the scroll that offsets air leaks between the scroll and the object, thereby forming a suction hold that compacts the object onto the rigid tool.

**[p0005]**

A further embodiment is a non-transitory computer readable medium embodying programmed instructions which, when executed by a processor, are operable for performing a method for compacting an object onto a rigid tool. The method includes placing an object onto a surface of a rigid tool, disposing an end effector over the object, spreading linkages of the end effector, causing a scroll of material between the linkages to be disposed atop the object while surrounding the object, and applying a negative pressure to the scroll that offsets air leaks between the scroll and the object, thereby forming a suction hold that compacts the object onto the rigid tool. A further embodiment is an apparatus for compacting an object onto a rigid tool. The apparatus includes an end effector that is configured to move towards a rigid tool, linkages that are coupled to the end effector and are configured to pivot relative to the end effector, spindles that are coupled to the linkages and that are rotatably mounted to the linkages, and a scroll of material that is stored on the spindles, and that is configured for placement onto an object at the rigid tool.

**[p0006]**

A further embodiment is an apparatus that includes a spindle, and a scroll of material that is wrapped around the spindle. One end of the scroll is sealed to the spindle, and another end of the scroll is affixed to an object. The material comprises a permeable layer, and an impermeable membrane that contacts the permeable layer. A further embodiment is an apparatus that includes at least one spindle. The spindle includes an exterior, a chamber, and perforations that couple the chamber to the exterior. The apparatus also includes a scroll of material that is wrapped around the spindle. One end of the scroll is sealed to the spindle. The material comprises a permeable layer, and an impermeable membrane that contacts the permeable layer. A further embodiment is an apparatus for compacting an object onto a rigid tool. The apparatus includes multiple spindles, and a scroll of material that is stored on the spindles, and that is configured for placement onto an object at the rigid tool as the spindles move apart from each other.

**[p0007]**

A further embodiment is a method for compacting an object placed onto a surface of a rigid tool. The method includes unrolling a scroll of material, comprising an impermeable membrane that overlays a permeable layer and that extends beyond a boundary of the permeable layer, over an object, and applying a negative pressure to the permeable layer that offsets air leaks between the scroll and the object, thereby forming a suction hold that compacts the object onto the rigid tool. A further embodiment is a non-transitory computer readable medium embodying programmed instructions which, when executed by a processor, are operable for performing a method for compacting an object onto a rigid tool. The method includes unrolling a scroll of material, comprising an impermeable membrane that overlays a permeable layer and that extends beyond a boundary of the permeable layer, over an object, and applying a negative pressure to the permeable layer that offsets air leaks between the scroll and the object, thereby forming a suction hold that compacts the object onto the rigid tool.

**[p0008]**

Other illustrative embodiments (e.g., methods and computer-readable media relating to the foregoing embodiments) may be described below. The features, functions, and advantages that have been discussed can be achieved independently in various embodiments or may be combined in yet other embodiments further details of which can be seen with reference to the following description and drawings.

### Description Of The Drawings

**[p0009]**

Some embodiments of the present disclosure are now described, by way of example only, and with reference to the accompanying drawings. The same reference number represents the same element or the same type of element on all drawings. FIG. 1 illustrates a scroll deployment system in an illustrative embodiment. FIG. 2 is a flowchart illustrating a method for operating a scroll deployment system in an illustrative embodiment. FIG. 3 depicts an end effector with an undeployed scroll in an illustrative embodiment. FIG. 4 depicts an end effector with a deployed scroll in an illustrative embodiment. FIG. 5 is a section cut view of a scroll in an illustrative embodiment. FIG. 6 is a zoomed in view of a portion of a scroll that includes layers of fiber reinforced material in an illustrative embodiment. FIG. 7 depicts a permeable layer in an illustrative embodiment. FIG. 8 is a diagram depicting a vacuum system coupled to a spindle in an illustrative embodiment. FIG. 9 is a cut-through view of the spindle of FIG. 8 in an illustrative embodiment.

**[p0010]**

FIG. 10 is a flowchart depicting a method of applying negative pressure via a spindle in an illustrative embodiment. FIG. 11 is a flowchart depicting a method of unrolling a scroll from a single spindle in an illustrative embodiment. FIG. 12 is a flow diagram of aircraft production and service methodology in an illustrative embodiment. FIG. 13 is a block diagram of an aircraft in an illustrative embodiment.

### Description

**[p0011]**

The figures and the following description provide specific illustrative embodiments of the disclosure. It will thus be appreciated that those skilled in the art will be able to devise various arrangements that, although not explicitly described or shown herein, embody the principles of the disclosure and are included within the scope of the disclosure. Furthermore, any examples described herein are intended to aid in understanding the principles of the disclosure, and are to be construed as being without limitation to such specifically recited examples and conditions. As a result, the disclosure is not limited to the specific embodiments or examples described below, but by the claims and their equivalents. The scroll deployment systems described herein are capable of being utilized to compact preforms for composite parts, such as a preforms for sections of fuselage. Composite parts, such as Carbon Fiber Reinforced Polymer (CFRP) parts, are initially laid-up in multiple layers that together are referred to as a preform. Individual fibers within each layer of the preform are aligned parallel with each other, but different layers exhibit different fiber orientations in order to increase the strength of the resulting composite part along different dimensions. The preform includes a viscous resin that solidifies in order to harden the preform into a composite part (e.g., for use in an aircraft). Carbon fiber that has been impregnated with an uncured thermoset resin or a thermoplastic resin is referred to as “prepreg.” Other types of carbon fiber include “dry fiber” which has not

**[p0011]**

been impregnated with thermoset resin but may include a tackifier or binder. Dry fiber is infused with resin prior to hardening. For thermoset resins, the hardening is a one-way process referred to as curing, while for thermoplastic resins, the resin reaches a viscous form if it is re-heated, after which it can be consolidated to a desired shape and solidified. As used herein, the umbrella term for the process of transitioning a preform to a final hardened shape (i.e., transitioning a preform into a composite part) is referred to as “hardening,” and this term encompasses both the curing of thermoset preforms and the forming/solidifying of thermoplastic preforms into a final desired shape.

**[p0012]**

FIG. 1 schematically illustrates a scroll deployment system 100 in an illustrative embodiment. Scroll deployment system 100 comprises any system or device that is capable of deploying a scroll of material over an object disposed at a rigid tool (e.g., a preform for a section of fuselage of an aircraft, disposed at a mandrel), and applying negative pressure that uniformly compacts the object onto the rigid tool. In this embodiment, scroll deployment system 100 comprises an end effector 120 that is configured to move towards (e.g., downwards towards) a rigid tool 110 . Linkages 122 are coupled to the end effector and are configured to pivot relative to the end effector. As the linkages 122 pivot, their distal ends 123 move away from each other. Spindles 124 are coupled to the linkages, and are rotatably mounted to the linkages 122 . Furthermore, the spindles 124 each store a portion of a scroll 130 of continuous material that is configured for placement onto an object 140 at the rigid tool 110 . Thus, the spindles 124 carry the scroll 130 of material. In one embodiment, the scroll 130 comprises a permeable layer and an impermeable membrane, and the impermeable membrane extends beyond a perimeter of the permeable layer. In further embodiments, the scroll 130 also includes one or more layers of fiber reinforced material for compacting onto the object 140 .

**[p0013]**

Pivoting of the linkages 122 causes spindles 124 to rotate, which deploys the scroll 130 of material from spindles 124 . After deployment, the scroll 130 covers the object 140 , and extends beyond the boundaries of the object 140 (e.g., circumferentially as well as into and out of the page). Accordingly, FIG. 1 depicts the scroll 130 in a deployed configuration relative to the object 140 . In this embodiment, the object 140 is a preform that comprises multiple layers of fiber reinforced material (e.g., CFRP), is disposed at a surface 112 of a rigid tool 110 , and awaits hardening into a composite part. During and/or after deployment of the scroll 130 , a pump 150 is operated to draw air from underneath the scroll 130 . Specifically, the pump 150 draws air from underneath an impermeable membrane 132 (e.g., a latex sheet or other material that exhibits high levels of elongation while retaining impermeability) of the scroll 130 that covers the object 140 . Pump 150 draws air via a port 152 that penetrates into the scroll 130 at an aperture 133 , by applying negative pressure via the port 152 . In this embodiment, the port 152 is located at an upper end portion 182 of the scroll 130 . However, the port 152 may be located as desired at other portions of the scroll as desired. Port 152 penetrates the impermeable membrane 132 , and may directly contact or be directly positioned over permeable layer 134 of the scroll 130 .

**[p0014]**

Permeable layer 134 is both laterally and vertically air permeable, which enables negative pressure to be distributed evenly across the scroll 130 . This means that negative pressure drawn via the port 152 is applied evenly across the object 140 instead of being localized at the port 152 . The negative pressure secures the end flaps 136 of the scroll to the rigid tool 110 and forms a loose seal between the end flaps 136 and the rigid tool 110 . That is, even though the end flaps 136 do not include adhesive or other means of chemical bonding, applied negative pressure loosely seals the end flaps to the rigid tool 110 via suction, so long as the amount of air being drawn by the pump 150 at least equals the amount of air lost to leaks between the end flaps 136 and the rigid tool 110 . The negative pressure also compacts the scroll 130 onto the object 140 , which ensures that the object 140 remains in place at the rigid tool 110 . Pump 150 is a high flow volume pump, which means that pump 150 is capable of drawing a great deal of air through the port 152 , but not necessarily at a high pressure. In one embodiment, the pump 150 applies between twenty-two to twenty-nine inches of mercury (in. Hg) of negative pressure to form a vacuum, but at tens of Cubic Feet per Minute (CFM) of airflow (e.g., between fifty and two hundred CFM). Hence, pump 150 and port 152 may be capable of maintaining a pressure of at least one inch of mercury across the impermeable membrane (e.g., the covered area). This may be performed solely by pump 150 , or in combination with other pumps as desired. The

**[p0014]**

amount of pressure applied and amount of CFM drawn by pump 150 may vary as a function of total boundary length of the scroll 130 .

**[p0015]**

Controller 160 manages the operations of pump 150 based on input from a sensor (not shown) such as a pressure sensor or flow rate sensor, in order to ensure that negative pressure is constantly within a desired range to overcome leaks along the perimeter of the scroll 130 . Sensors may be located at any suitable location, such as at permeable layer 134 , scroll 130 , port 152 , pump 150 , etc. In one embodiment, controller 160 increases or decreases a speed or intensity of pumping operations at pump 150 in order to maintain a constant volume flow of air, or in order to maintain a constant negative pressure. Controller 160 may be implemented, for example, as custom circuitry, as a hardware processor executing programmed instructions, or some combination thereof. The amount of holding force (F H ) applied by the scroll 130 to the object 140 is based upon the difference between a volume per unit time drawn by pump 150 (VP), a volume per unit time at which air leaks through end flaps 136 of the scroll 130 (VL), and a total area covered by the scroll 130 . F H may also be modeled as a function of the pressure applied by pump 150 . VL is overcome by VP. Hence, VP should be equal to or larger than VL. Scroll 130 is not affixed to the rigid tool 110 via sealant, glue, fasteners, magnetism, etc. However, vacuum under the scroll 130 is maintained by pump 150 while air is leaking into the system through the perimeter. Thus, minor air leaks may still exist in this configuration, because negative pressure is the primary (e.g., sole) force that secures the scroll 130 to the rigid tool 11

**[p0015]**

0 . The air leaks may be caused by wrinkles in the scroll 130 that provide passages for airflow. However, wrinkles are but one cause of air leaks, as air will leak out of the edge of the scroll 130 when the scroll 130 is not sealed to the rigid tool 110 . Even so, VL remains small, and hence negative pressure is maintained by evacuating an equal or greater amount of air than is lost via leaks between end flaps 136 of impermeable membrane 132 and the rigid tool 110 .

**[p0016]**

Permeable layer 134 comprises a material that is capable of deforming as the impermeable membrane 132 applies force, drawing snugly over the object 140 while still enabling air to be drawn freely across the object 140 . That is, the permeable layer 134 enables the drawing of air across the object 140 without causing markoff at the object 140 . For example, the permeable layer 134 may comprise a compliant biplanar mesh of material that facilitates airflow. Permeable layer 134 is a high-flow material, which is to say that permeable layer 134 does not substantially restrict the rate at which pump 150 draws air. The resistance of permeable layer 134 to airflow therefore has a negligible impact on the flow rate of pump 150 . In some embodiments, the permeable layer 134 comprises an open celled foam material. However, in such embodiments, the open celled foam material chosen is sufficiently rigid that it does not collapse under impermeable membrane 132 , and sufficiently open that airflow is not inhibited. Collapsing of impermeable membrane 132 would shut off or restrict air flow, which is undesirable as air flow would then be restricted from such areas under impermeable membrane 132 .

**[p0017]**

Impermeable membrane 132 may comprise any suitable gas-impermeable material that is pliable. For example, impermeable membrane 132 may comprise a plastic sheet that prevents air from escaping directly through it. In further embodiments, impermeable membrane 132 and permeable layer 134 may be structurally united or bonded for convenience. In one embodiment, both permeable layer 134 and impermeable membrane 132 comprise contact approved materials that are acceptable for use with carbon fiber composites and do not chemically interact with resin. Illustrative details of the operation of scroll deployment system 100 will be discussed with regard to an embodiment of a method, which is shown as method 200 in FIG. 2 . Assume, for this embodiment, that rigid tool 110 awaits placement of a preform for compaction and hardening into a composite part. FIG. 2 is a flowchart illustrating a method 200 for operating a scroll deployment system in an illustrative embodiment. The steps of method 200 are described with reference to scroll deployment system 100 of FIG. 1 , but those skilled in the art will appreciate that method 200 may be performed in other systems. The steps of the flowcharts described herein are not all inclusive and may include other steps not shown. The steps described herein may also be performed in an alternative order.

**[p0018]**

In step 202 , object 140 is placed onto the surface 112 of the rigid tool 110 . In one embodiment, this comprises laying up a preform onto the surface 112 via an Automated Fiber Placement (AFP) machine or other tool. In further embodiments, this comprises picking up and placing a preform from another location and placing it onto the surface 112 . Step 204 comprises disposing an end effector 120 over the object 140 . In one embodiment, this comprises moving the end effector 120 over a rail, gantry, or track (not shown) in order to align the end effector with the object 140 . Step 206 includes spreading linkages 122 of the end effector 120 , causing a scroll 130 of material between the linkages 122 to be disposed atop the object 140 while also surrounding the object. In one embodiment, the linkages 122 are spread by gravity as the spindles 124 follow a contour of the rigid tool when the end effector 120 is lowered. While spreading, the linkages pivot relative to the end effector 120 . This causes the linkages 122 to contact and deflect from the rigid tool 110 (and/or object 140 ), swinging outward. In further embodiments, the linkages are motorized, and are actively driven apart from each other. When the linkages 122 are spread, spindles 124 that are coupled with the linkages are rotated. Because the scroll 130 is wound about the spindles 124 , rotation of the spindles causes the scroll 130 to be dispensed, or for the material at the scroll to be unscrolled/deposited in place. This means that as the linkages 122 are spread, the spindles 124 proceed to roll in opposite directi

**[p0018]**

ons, which exposes the scroll 130 for deployment. That is, because a portion of the scroll 130 is kept at a spindle 124 for one of the linkages 122 , and another portion of the scroll is kept at a spindle for another of the linkages, the act of spreading the linkages unrolls the scroll 130 from the spindles.

**[p0019]**

In step 208 , the scroll 130 , which comprises an impermeable membrane that overlays a permeable layer and extends beyond a boundary of the permeable layer, is unrolled over the object 140 . In one embodiment, this occurs in response to the linkages spreading, while in further embodiments wherein linkages are not utilized, this comprises unrolling the scroll 130 via any other suitable means. In step 210 , the port 152 applies a negative pressure to the scroll 130 that offsets air leaks between the scroll 130 and the object 140 , thereby forming a suction hold that compacts the object 140 onto the rigid tool 110 . Applying the negative pressure draws end flaps 136 of the impermeable membrane 132 of the scroll 130 into contact with the rigid tool 110 . Applying negative pressure may be performed by drawing a desired amount of volumetric flow through the pump 150 as mentioned above, or by applying a constant amount of pressure via the pump 150 . Because air is drawn via the port 152 , applying negative pressure evacuates air from under the scroll 130 . The negative pressure applies a desired amount of force, for a desired amount of time, in order to fully compact the object 140 .

**[p0020]**

After compaction is completed, the linkages 122 are retracted, causing the scroll 130 to be drawn up from the preform. In embodiments where the scroll 130 includes one or more layers of fiber reinforced material, the compaction process secures the fiber reinforced material to the object 140 . Thus, when the scroll 130 is retracted, these layers of fiber reinforced material remain at the object 140 , while the permeable layer 134 and the impermeable membrane 132 are retracted. After the scroll 130 is removed, the scroll 130 can be cleaned, re-loaded with additional layers of fiber reinforced material, and/or replaced with another spindle that is already clean and loaded with desired materials. Method 200 provides a technical benefit over prior techniques, because it enables rapid deployment of a tapeless compaction system, via an end effector that occupies relatively little space. It also enables deployment of layers of fiber reinforced material as a part of the compaction process. This enhances production speed and reduces labor.

**[p0021]**

FIG. 3 depicts an end effector 300 with an undeployed scroll in an illustrative embodiment. In this embodiment, the end effector 300 includes a frame 330 , as well as bases 332 , from which linkages 334 extend. Actuators 336 are disposed at the linkages 334 , and facilitate retraction of the linkages 334 after compaction has been completed, by rolling the spindles 338 upward along a mandrel 310 . In one embodiment, the actuators 336 comprise motors with slip clutches that walk spindles 338 back upwards after compaction has been completed. In this embodiment, the end effector 300 deploys a scroll of material from the spindles 338 onto a preform 320 that has been placed onto the mandrel 310 . FIG. 4 depicts the end effector 300 of FIG. 3 with a deployed scroll 400 in an illustrative embodiment. As shown in FIG. 4 , the spindles 338 have been moved to deploy the scroll 400 so that the scroll 400 covers the entirety of the preform 320 . A vacuum port 410 is utilized by a pump 420 to apply negative pressure during the deployment of the scroll 400 , and is also used after deployment to compact the preform 320 into place.

**[p0022]**

FIG. 5 is a section cut view of a scroll 400 in an illustrative embodiment, and corresponds with view arrows 5 of FIG. 3 . The scroll 400 is wrapped around spindles 338 , which roll apart from each other as linkages 334 spread outward. This causes a web 500 of the scroll 400 to be exposed for deployment. FIG. 6 is a zoomed in view of a portion of a scroll that includes layers of fiber reinforced material in an illustrative embodiment, and corresponds with region 6 of FIG. 5 . FIG. 6 illustrates that the scroll 400 includes multiple layers. In this embodiment, the scroll 400 includes one or more layers 612 of fiber reinforced material. Layers 612 directly contact an underlying object when the scroll 400 is deployed, and may form Outer Mold Line (OML) or Inner Mold Line (IML) plies for a composite part. A permeable layer 614 follows the layers 612 , and enables negative pressure to be uniformly distributed along the underside of the scroll 400 when deployed, as discussed above. In embodiments where the scroll 400 does not include layers of fiber reinforced material, the permeable layer 614 is placed into direct contact with the underlying object. The permeable layer 614 is followed by an impermeable layer 616 , which prevents airflow from crossing it, when the scroll is deployed. When laid flat, the scroll 400 includes only one grouping 610 of layers 612 , permeable layer 614 , and impermeable layer 616 . However, the scroll 400 is wound around a spindle such that the grouping 610 is visible multiple times along the diameter of the spindle.

**[p0023]**

FIG. 7 depicts a permeable layer that is both vertically and laterally air-permeable in an illustrative embodiment. That is, air 710 may flow freely through gaps 720 in permeable layer 700 , as well as across gaps 720 in permeable layer 700 . This is possible because permeable layer 700 is a biplanar mesh. A first layer 730 of the biplanar mesh comprises structural elements 732 that are arranged parallel with each other, and a second layer 740 of the biplanar mesh comprises structural elements 742 that are arranged parallel with each other, but in a different direction than the first layer 730 . First layer 730 enables air to flow horizontally in a first direction, and second layer 740 enables air to flow horizontally in a second direction. Meanwhile, both layers allow air to flow freely vertically. Thus, if a negative pressure is applied to one portion of permeable layer 700 , the negative pressure may draw air evenly across the entirety of permeable layer 700 . Permeable layer 700 enables free airflow, and does not interfere with the drawing of air by a pump. That is, permeable layer 700 does not limit the CFM rate of a pump. Permeable layer 700 may comprise polyethylene, polypropylene, nylon, etc. In one embodiment, permeable layer 700 is chosen as a “contact approved” material that will not chemically interfere with the adhesion of curable resin at the object being secured. For example, permeable layer 700 may be made from a silicone free material that does not mark an underlying object 140 .

**[p0024]**

The above-described apparatus and method relate to the use of an opposed pair of two rollers, and a vacuum port configured to apply vacuum via an aperture of the material. However, further configurations are possible in other embodiments. By way of example, in further embodiments, the material is scrolled on a single roller rather than an opposed pair of rollers, and/or vacuum is applied via the end of the roller spindle, via a chamber in the spindle and perforations through the spindle. To illustrate these configurations, an embodiment of a vacuum system that includes both of these configurations, as well as methods for utilizing such a system, are shown in FIGS. 8 - 11 and described next. FIG. 8 is a diagram 800 depicting a vacuum system 870 coupled to a spindle 840 in an illustrative embodiment. As shown in FIG. 8 , the spindle 840 includes a chamber 842 having multiple perforations 844 that lead to an exterior 846 . The chamber 842 communicates with vacuum port 850 , which means that when vacuum system 870 evacuates air from the vacuum port 850 , air inside of the chamber 842 is removed.

**[p0025]**

A scroll 838 of material 830 is wrapped around the spindle 840 , and covers an underlying preform 860 for a composite part, or any other suitable object. An end of the scroll 838 is sealed to the spindle 840 around the perforations 844 , such that suction applied via vacuum port 850 results in negative pressure being distributed through the scroll 838 . Further details of this arrangement as provided in FIG. 9 below. Another end 836 of the scroll 838 of material 830 is affixed via tape 820 to a surface 812 of the mandrel 810 . In further embodiments, the end 836 is affixed to the mandrel 810 via the application of negative pressure to the scroll 838 . The material 830 includes multiple layers, including at least one impermeable membrane 832 , as well as a permeable layer 834 (e.g., a biplanar mesh) disposed beneath the impermeable membrane 832 . The permeable layer 834 is in fluid communication with the chamber 842 inside of the spindle 840 . Further details of an arrangement of layers for the material 830 are discussed below with regard to FIG. 9 .

**[p0026]**

Implementing a spindle 840 that is hollow, and/or coupling a vacuum port 850 to the hollow portion of the spindle 840 , results in numerous benefits by enabling a single component (i.e., the spindle) to perform multiple functions which facilitate not just unrolling of material, but also compaction of an underlying preform 860 . In further embodiments, multiple spindles (such as the spindles depicted in FIGS. 3 - 4 ) are implemented as hollow spindles with chambers and vacuum ports in order to apply negative pressure. For such embodiments, vacuum ports for different spindles can be placed on the same side of each of the spindles, different sides of the spindles, or both sides of the spindles as desired. FIG. 9 is a cut-through view 900 of the spindle 840 of FIG. 8 in an illustrative embodiment. The dimensions of FIG. 9 have been adjusted to better illustrate the spindle 840 in relation to other components depicted in FIG. 8 , and hence the dimensions of these FIGS. do not correspond. FIG. 9 illustrates how airflow travels from the material 830 to the spindle 840 when suction is applied, as indicated by arrows. As shown in FIG. 9 , permeable layer 834 extends into contact with perforations 844 , and thus is in fluid communication with the perforations 844 . Furthermore, the perforations 844 are disposed between locations 938 where an end 936 of the scroll is sealed to the spindle 840 . The permeable layer 834 is bounded by a first impermeable membrane 832 that forms an upper boundary atop the preform 860 , and is further bounded by a second impermeable membrane 910 that forms

**[p0026]**

a lower boundary. The impermeable membranes contact the permeable layer, and hence contain airflow to within the permeable layer 834 .

**[p0027]**

The first impermeable membrane 832 terminates after the permeable layer 834 , and the second impermeable membrane 910 terminates prior to reaching the preform 860 . The second impermeable membrane 910 prevents pressure loss from the permeable layer 834 during and after the unrolling process, by providing a direct flow pathway to the chamber 842 of the spindle 840 . In further embodiments such as those discussed above, the scroll 838 is wrapped around a second spindle, and end 836 of the scroll is sealed to the second spindle in a similar fashion to that described above for end 936 . FIG. 10 is a flowchart depicting a method 1000 of applying negative pressure via a spindle in an illustrative embodiment. Step 1002 includes disposing a spindle 840 atop an object, such as a preform for a composite part. This may comprise physically placing the spindle 840 onto the object, or onto a mandrel 810 that the object has been laid-up onto. Step 1004 includes unrolling a scroll 838 of material 830 from the spindle 840 over the object, thereby covering the object with the material. In some embodiments, the act of unrolling places the permeable layer directly into contact with the object.

**[p0028]**

Step 1006 includes applying negative pressure to a permeable layer 834 in the material 830 that is in fluid communication with a chamber 842 inside of the spindle 840 . In one embodiment, applying the negative pressure is performed via a vacuum port 850 in fluid communication with the chamber 842 , and via multiple perforations 844 at the spindle 840 that link the chamber 842 to the permeable layer 834 . The negative pressure is distributed across the impermeable membrane via the permeable layer, which ensures that the impermeable membrane does not “pinch off” or self-seal in response to negative pressure at an undesired location. Step 1008 includes forming a suction hold that draws an impermeable membrane of the material into contact with the object, in response to the negative pressure. The suction hold is formed naturally as negative pressure is distributed across the impermeable membrane. At locations where the permeable layer 834 terminates and the impermeable membrane 832 continues, the negative pressure causes the impermeable membrane to seal itself to the underlying mandrel 810 .

**[p0029]**

FIG. 11 is a flowchart depicting a method 1100 of unrolling a scroll from a single spindle in an illustrative embodiment. Method 1100 includes disposing a spindle 840 atop an object located at a mandrel 810 in step 1102 . Step 1104 includes affixing an end 836 of a scroll 838 of material at the spindle 840 to the mandrel 810 . In one embodiment, affixing the end 836 of the scroll comprises taping the end 836 of the scroll 838 to the mandrel 810 . In a further embodiment, affixing the end of the scroll comprises forming a suction hold between an impermeable membrane of the material and the mandrel, as discussed above for method 1000 . Thus, activating a vacuum system 870 can serve to affix the end 836 , as long as no substantial air leaks exist. Step 1106 includes applying negative pressure to a permeable layer in the material, thereby forming a suction hold that places the material into contact with the object. This can be performed in a similar manner to step 1008 of method 1000 discussed above. In one embodiment, applying the negative pressure is performed via multiple perforations 844 at the spindle that link a chamber of the spindle to the permeable layer. The permeable layer 834 distributes the negative pressure across the impermeable membranes of the material.

**[p0030]**

Step 1108 includes unrolling the scroll while the negative pressure is applied. In one embodiment, unrolling the scroll comprises covering a preform for a composite part. Unrolling the scroll places the permeable layer directly into contact with the object. Furthermore, because the end 836 of the scroll 838 is affixed in place, the scroll does not wander or change position as the unrolling process continues. This enables the entire scroll to be unwound (or the entire object to be covered) as desired. In further embodiments, the method further comprises compacting the object via the suction hold. This can comprise increasing negative pressure until the object is pressed firmly into the mandrel at a desired level of pressure. While FIGS. 8 - 11 depict a single roller, tube-applied vacuum apparatus and related methods, in further embodiments various aspects and features mentioned herein are applied to a variety of systems. For example, the arrangement of chambers and vacuum systems depicted in these FIGS. 8 - 11 may be applied to a two-roller embodiment as depicted in in FIGS. 1 and 3 - 5 except with the vacuum applied via one or more ends of one or both spindles. In a further embodiment, a one-roller embodiment as depicted in these FIGS. 8 - 11 may apply vacuum via an aperture in the material as discussed with regard to FIGS. 1 and 3 - 5 .

### Examples

**[p0031]**

In the following examples, additional processes, systems, and methods are described in the context of a scroll deployment system for compacting preforms onto rigid tooling (e.g., a mandrel). Referring more particularly to the drawings, embodiments of the disclosure may be described in the context of aircraft manufacturing and service in method 1200 as shown in FIG. 12 and an aircraft 1202 as shown in FIG. 9 . During pre-production, method 1200 may include specification and design 1204 of the aircraft 1202 and material procurement 1206 . During production, component and subassembly manufacturing 1208 and system integration 1210 of the aircraft 1202 takes place. Thereafter, the aircraft 1202 may go through certification and delivery 1212 in order to be placed in service 1214 . While in service by a customer, the aircraft 1202 is scheduled for routine work in maintenance and service 1216 (which may also include modification, reconfiguration, refurbishment, and so on). Apparatus and methods embodied herein may be employed during any one or more suitable stages of the production and service described in method 1200 (e.g., specification and design 1204 , material procurement 1206 , component and subassembly manufacturing 1208 , system integration 1210 , certification and delivery 1212 , service 1214 , maintenance and service 1216 ) and/or any suitable component of aircraft 1202 (e.g., airframe 1218 , systems 1220 , interior 1222 , propulsion system 1224 , electrical system 1226 , hydraulic system 1228 , environmental 1230 ).

**[p0032]**

Each of the processes of method 1200 may be performed or carried out by a system integrator, a third party, and/or an operator (e.g., a customer). For the purposes of this description, a system integrator may include without limitation any number of aircraft manufacturers and major-system subcontractors; a third party may include without limitation any number of vendors, subcontractors, and suppliers; and an operator may be an airline, leasing company, military entity, service organization, and so on. As shown in FIG. 13 , the aircraft 1202 produced by method 1200 may include an airframe 1218 with a plurality of systems 1220 and an interior 1222 . Examples of systems 1220 include one or more of a propulsion system 1224 , an electrical system 1226 , a hydraulic system 1228 , and an environmental system 1230 . Any number of other systems may be included. Although an aerospace example is shown, the principles of the invention may be applied to other industries, such as the automotive industry.

**[p0033]**

As already mentioned above, apparatus and methods embodied herein may be employed during any one or more of the stages of the production and service described in method 1200 . For example, components or subassemblies corresponding to component and subassembly manufacturing 1208 may be fabricated or manufactured in a manner similar to components or subassemblies produced while the aircraft 1202 is in service. Also, one or more apparatus embodiments, method embodiments, or a combination thereof may be utilized during the subassembly manufacturing 1208 and system integration 1210 , for example, by substantially expediting assembly of or reducing the cost of an aircraft 1202 . Similarly, one or more of apparatus embodiments, method embodiments, or a combination thereof may be utilized while the aircraft 1202 is in service, for example and without limitation during the maintenance and service 1216 . Thus, the invention may be used in any stages discussed herein, or any combination thereof, such as specification and design 1204 , material procurement 1206 , component and subassembly manufacturing 1208 , system integration 1210 , certification and delivery 1212 , service 1214 , maintenance and service 1216 and/or any suitable component of aircraft 1202 (e.g., airframe 1218 , systems 1220 , interior 1222 , propulsion system 1224 , electrical system 1226 , hydraulic system 1228 , and/or environmental 1230 ).

**[p0034]**

In one embodiment, a part comprises a portion of airframe 1218 , and is manufactured during component and subassembly manufacturing 1208 . The part may then be assembled into an aircraft in system integration 1210 , and then be utilized in service 1214 until wear renders the part unusable. Then, in maintenance and service 1216 , the part may be discarded and replaced with a newly manufactured part. Inventive components and methods may be utilized throughout component and subassembly manufacturing 1208 in order to manufacture new parts. Any of the various control elements (e.g., electrical or electronic components) shown in the figures or described herein may be implemented as hardware, a processor implementing software, a processor implementing firmware, or some combination of these. For example, an element may be implemented as dedicated hardware. Dedicated hardware elements may be referred to as “processors”, “controllers”, or some similar terminology. When provided by a processor, the functions may be provided by a single dedicated processor, by a single shared processor, or by a plurality of individual processors, some of which may be shared. Moreover, explicit use of the term “processor” or “controller” should not be construed to refer exclusively to hardware capable of executing software, and may implicitly include, without limitation, digital signal processor (DSP) hardware, a network processor, application specific integrated circuit (ASIC) or other circuitry, field programmable gate array (FPGA), read only memory (ROM) for storing software, random access memory (RA

**[p0034]**

M), non-volatile storage, logic, or some other physical hardware component or module.

**[p0035]**

Also, a control element may be implemented as instructions executable by a processor or a computer to perform the functions of the element. Some examples of instructions are software, program code, and firmware. The instructions are operational when executed by the processor to direct the processor to perform the functions of the element. The instructions may be stored on storage devices that are readable by the processor. Some examples of the storage devices are digital or solid-state memories, magnetic storage media such as a magnetic disks and magnetic tapes, hard drives, or optically readable digital data storage media. Although specific embodiments are described herein, the scope of the disclosure is not limited to those specific embodiments. The scope of the disclosure is defined by the following claims and any equivalents thereof.

## Figure captions

- **Figure 1:** FIG. 1 illustrates a scroll deployment system in an illustrative embodiment.
- **Figure 2:** FIG. 2 is a flowchart illustrating a method for operating a scroll deployment system in an illustrative embodiment.
- **Figure 3:** FIG. 3 depicts an end effector with an undeployed scroll in an illustrative embodiment.
- **Figure 4:** FIG. 4 depicts an end effector with a deployed scroll in an illustrative embodiment.
- **Figure 5:** FIG. 5 is a section cut view of a scroll in an illustrative embodiment.
- **Figure 6:** FIG. 6 is a zoomed in view of a portion of a scroll that includes layers of fiber reinforced material in an illustrative embodiment.
- **Figure 7:** FIG. 7 depicts a permeable layer in an illustrative embodiment.
- **Figure 8:** FIG. 8 is a diagram depicting a vacuum system coupled to a spindle in an illustrative embodiment.
- **Figure 9:** FIG. 9 is a cut-through view of the spindle of FIG. 8 in an illustrative embodiment.
- **Figure 10:** FIG. 10 is a flowchart depicting a method of applying negative pressure via a spindle in an illustrative embodiment.
- **Figure 11:** FIG. 11 is a flowchart depicting a method of unrolling a scroll from a single spindle in an illustrative embodiment.
- **Figure 12:** FIG. 12 is a flow diagram of aircraft production and service methodology in an illustrative embodiment.
- **Figure 13:** FIG. 13 is a block diagram of an aircraft in an illustrative embodiment.
- **Figure 2:** Illustrative details of the operation of scroll deployment system 100 will be discussed with regard to an embodiment of a method, which is shown as method 200 in FIG. 2 . Assume, for this embodiment, that rigid tool 110 awaits placement of a preform for compaction and hardening into a composite part.
- **Figure 5:** FIG. 5 is a section cut view of a scroll 400 in an illustrative embodiment, and corresponds with view arrows 5 of FIG. 3 . The scroll 400 is wrapped around spindles 338 , which roll apart from each other as linkages 334 spread outward. This causes a web 500 of the scroll 400 to be exposed for deployment.

## Classifications

- B25J15/0616
- B29C70/342
- B29C70/44
- B29C70/543
- B29C70/543
- B25J15/00
- B25J15/0028
- B25J15/0028
- B29C2043/3644
- B29C2043/561
- B29C31/04
- B29C43/12
- B29C43/3642
- B29C43/56
- B29C70/34
- B29C70/342
- B29C70/342
- B29C70/38
- B29C70/44
- B29C70/44
- B29C70/44
- B29C70/54
- B29C70/543
- B29C70/544
- B32B37/1018

## Cited patent documents

- [CN-102741040-A](https://patents.google.com/patent/CN102741040A/en) — APP
- [CN-105109058-A](https://patents.google.com/patent/CN105109058A/en) — APP
- [CN-106239935-A](https://patents.google.com/patent/CN106239935A/en) — APP
- [CN-106671444-A](https://patents.google.com/patent/CN106671444A/en) — APP
- [DE-112010001156-T5](https://patents.google.com/patent/DE112010001156T5/en) — APP
- [EP-2511079-A1](https://patents.google.com/patent/EP2511079A1/en) — APP
- [GB-2256168-A](https://patents.google.com/patent/GB2256168A/en) — SEA
- [JP-2004181627-A](https://patents.google.com/patent/JP2004181627A/en) — APP
- [JP-2013095141-A](https://patents.google.com/patent/JP2013095141A/en) — APP
- [JP-2013116634-A](https://patents.google.com/patent/JP2013116634A/en) — APP
- [JP-2014091271-A](https://patents.google.com/patent/JP2014091271A/en) — APP
- [US-10926435-B2](https://patents.google.com/patent/US10926435B2/en) — APP
- [US-2007284046-A1](https://patents.google.com/patent/US20070284046A1/en) — SEA
- [US-2009014618-A1](https://patents.google.com/patent/US20090014618A1/en) — APP
- [US-2010137775-A1](https://patents.google.com/patent/US20100137775A1/en) — APP
- [US-2011118683-A1](https://patents.google.com/patent/US20110118683A1/en) — APP
- [US-2011282309-A1](https://patents.google.com/patent/US20110282309A1/en) — APP
- [US-2014061962-A1](https://patents.google.com/patent/US20140061962A1/en) — APP
- [US-2014265058-A1](https://patents.google.com/patent/US20140265058A1/en) — APP
- [US-2015273809-A1](https://patents.google.com/patent/US20150273809A1/en) — APP
- [US-2017050393-A1](https://patents.google.com/patent/US20170050393A1/en) — APP
- [US-2018339413-A1](https://patents.google.com/patent/US20180339413A1/en) — SEA
- [US-2021094240-A1](https://patents.google.com/patent/US20210094240A1/en) — APP
- [US-2021268753-A1](https://patents.google.com/patent/US20210268753A1/en) — SEA
- [US-3019130-A](https://patents.google.com/patent/US3019130A/en) — SEA
- [US-3507728-A](https://patents.google.com/patent/US3507728A/en) — SEA
- [US-3944045-A](https://patents.google.com/patent/US3944045A/en) — SEA
- [US-4475976-A](https://patents.google.com/patent/US4475976A/en) — SEA
- [US-4589247-A](https://patents.google.com/patent/US4589247A/en) — SEA
- [US-5106568-A](https://patents.google.com/patent/US5106568A/en) — SEA
- [US-5427518-A](https://patents.google.com/patent/US5427518A/en) — APP
- [US-5564553-A](https://patents.google.com/patent/US5564553A/en) — SEA
- [US-6406659-B1](https://patents.google.com/patent/US6406659B1/en) — APP

---

Generated by IPtorch. Verify legal conclusions against the official publication.
