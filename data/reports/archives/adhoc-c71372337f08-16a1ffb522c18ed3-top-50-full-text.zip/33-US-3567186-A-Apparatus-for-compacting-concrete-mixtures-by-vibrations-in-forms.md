# 33. Apparatus for compacting concrete mixtures by vibrations in forms

- **Archive rank:** 33 of 50
- **Publication:** [US-3567186-A](https://patents.google.com/patent/US3567186A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/025139295/publication/US3567186A?q=pn%3DUS3567186A)
- **Publication date:** 1971-03-02
- **Filing date:** 1968-12-24
- **Earliest priority:** 1968-12-24
- **Family:** 25139295
- **Text status:** source text incomplete — use the office links above
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** PFEIFFER MASCHF ETTLINGEN

## Abstract

A VIBRATING APPARATUS WHICH IS ADAPTED TO BE RIGIDLY BUT REMOVABLY ATTACHED TO A CONCRETE FORM FOR COMPACTING A CONCRETE MIXTURE THEREIN, ESPECIALLY FOR PRODUCING LARGE CONCRETE PIPES, COMPRISING A VIBRATOR, A RIGID SUPPORTION BRACKET SECURED TO THE VIBRATOR AND ADAPTED TO BE APPLIED DIRECTLY UPON THE CONCRETE FORM TOE TRANSMIT THE VIBRATIONS THERETO, AND A VACUUM HOOD SECURED TO THE SUPPORTING BRACKET AND FORMING AN ENLARGMENT THEREOF IN LATERAL DIRECTIONS. WHEN THEIS HOOD IS EVACUATED AFTER BEING APPLIED UPON A SURFACE OF THE CONCRETE FORM, IT WILL HOOD THE SUPPORTING BRACKET TOGETHER WITH THE VIBRATOR IN A FIXED POSITION ON THE CONCRETE FORM.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-3567186-A/000.png)

![Sketch 1 for US-3567186-A](https://nimo.iptorch.com/refdrawing/US-3567186-A/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/US-3567186-A/001.png)

![Sketch 2 for US-3567186-A](https://nimo.iptorch.com/refdrawing/US-3567186-A/001.png)

[Sketch 3](https://patentimages.storage.googleapis.com/7e/30/43/c6edc2b245562d/US3567186-drawings-page-1.png)

![Sketch 3 for US-3567186-A](https://patentimages.storage.googleapis.com/7e/30/43/c6edc2b245562d/US3567186-drawings-page-1.png)

[Sketch 4](https://patentimages.storage.googleapis.com/6b/fe/df/166a8f98052fc0/US3567186-drawings-page-2.png)

![Sketch 4 for US-3567186-A](https://patentimages.storage.googleapis.com/6b/fe/df/166a8f98052fc0/US3567186-drawings-page-2.png)

## Claims

_Claims were not available from the queried sources._

## Full description

PERFORMING OPERATIONS; TRANSPORTINGWORKING CEMENT, CLAY, OR STONESHAPING CLAY OR OTHER CERAMIC COMPOSITIONS; SHAPING SLAG; SHAPING MIXTURES CONTAINING CEMENTITIOUS MATERIAL, e.g. PLASTERProducing shaped prefabricated articles from the materialProducing shaped prefabricated articles from the material by vibrating or joltingProducing shaped prefabricated articles from the material by vibrating or jolting by means acting on the mould ; Fixation thereof to the mould

Description

March 2,1971 EL 3,567,186

APPARATUS FOR COMPACTING CONCRETE MIXTURES BY VIBRATIONS INFORMS Filed Dec. 24, 1968 2 Sheets-Sheet 1 Fig.1 Q

IN V EN TOR.

March 2, 1971 H. NIEPELT APPARATUS FOR GOMPACTING CONCRETE MIXTURES BY VIBRATIONS IN FORMS 2 Sheets-Sheet Filed Dec 24. 1968 Fig. 3

Fig.4

n w n m n M p v Fig. 5

27 2E INVENTOR.

fl'M/z Nil-FELT 41mwsya 3,5fi7,l86 Patented Mar. 2, 1971 ice 3,567,186 APPARATUS FOR COMPACTING CONCRETE MIXTURES BY VIBRATIONS llN FORMS Heinz Niepelt, Karlsruhe-Waldstadt, Germany, assignor to Maschinenfabrik Ettlingen Friedrich Pfeitfer K.G.,

Ettlingen, Baden, Germany Filed Dec. 24, 1968, Ser. No. 786,677 Int. 'Cl. B01f 11/00 US. Cl. 259-1 11 Claims ABSTRACT OF THE DISCLOSURE A vibrating apparatus which is adapted to be rigidly but removably attached to a concrete form for compacting a concrete mixture therein, especially for producing large concrete pipes, comprising a vibrator, a rigid supporting bracket secured to the vibrator and adapted to be applied directly upon the concrete form to transmit the vibrations thereto, and a vacuum hood secured to the supporting bracket and forming an enlargement thereof in lateral directions. When this hood is evacuated after being applied upon a surface of the concrete form, it will hold the supporting bracket together with the vibrator in a fixed position on the concrete form.

The present invention relates to a method and an apparatus for producing vibrations and transmitting the same to concrete forms for compacting concrete mixtures which are filled into these forms so as to produce structural concrete elements, for example, concrete pipes.

In the production of structural concrete elements of any types and especially of concrete pipes of large dimensions the concrete is compacted in recent times more and more frequently within its forms by means of mechanical vibrations of a high frequency which may be transmitted to the concrete mixture from the outer jacket and/or from the core of the concrete form. It is, however, very difficult to attach the vibrators to the outer jacket and/ or to the core of a pipe form, especially if the form parts have to be frequently changed, or when alterations become necessary.

For transmitting the vibrations from a vibrator, for example, to the outer form wall, supporting brackets are frequently welded upon this wall which are provided with ribs which extend radially and vertically along the form parts. It is, however, usually impossible by means of theoretical considerations and calculations to determine the proper position -where the supporting brackets I should be secured in order to transmit the vibrations at all times uniformly to the form and to the concrete mixture therein without danger that vibration nodes or antinodes are formed with the result that the vibrations may partly interfere with each other or their effects may even eliminate each other. If the vibrators are mounted on the concrete forms by means of such supporting brackets, their positions on the form may be changed only ifthe number of these brackets is larger than the number of vibrators which are required for the compacting operation. However, the rearrangement and remounting of the vibrators on these brackets so as to be in the proper positions is a complicated and time-wasting procedure. Furthermore, the welding of the supporting brackets to the form parts produces tensions therein which, due to the vibrations, may lead to the formation of cracks in these parts. Although such welding tensions may be prevented on small forms by annealing them, this is practically impossible on large forms, for example, of a length of 6 meters and a diameter of 2.5 meters. 1

In certain cases, for example, when producing pressure pipes of pie-stressed concrete, it is impossible to employ forms upon which supporting brackets for mounting the vibrators may be welded or bolted because such pressure pipes are made of two concentric parts with a sacrifice sheet-metal form of a thickness of only 1 to 1.5 mm. In such a production, an inner pipe is at first produced within a jacket form which remains as a sacrifice form and consists of a closed thin sheet-metal jacket. After the inner pipe has set and hardened, a wire is wound under tension around its sacrifice form and the inner pipe in the normal jacket form is then covered by an outer pipe. The material of the inner pipe is compacted by vibrators which are secured to a steel corset which is clamped by screw clamps or the like to the outer sacrifice form. A uniform transmission of the strong vibrations of the vibrators through the steel corset to the sacrifice form is, however, hardly possible since the thin material of the sacrifice form is very easily bent. The transmission of the vibrations is also considerably impaired by the steel corset, especially if the pipes have a noncircular cross section.

It has further been proposed prior to this invention to provide a vibrator with a permanent magnet for connecting it to a machine, form, or the like which is made of steel. If this applies to concrete forms, they would have to consist of steel. This is, however, by no means always true since especially prefabricated concrete forms are made more and more frequently of less expensive materials such as wood, plastics, aluminum or the like in order to reduce the cost and weight of such forms and to permit them to be easily made of different shapes. Furthermore, a magnetic connection requires the form as well as the vibrator which is to be connected thereto to have accurately finished surfaces since even a very small air gap will reduce the adhesive force of the magnetic field considerably. Such a connecting magnet may already be rendered ineffective by very small quantities of solidified concrete or the like which might adhere to the form. Moreover, the applicability of such connecting magnets is limited by the fact that the vibrating methods are usually employed today in connection with large and heavy concrete forms for producing large concrete elements. This requires vibrating forces of up to 1000 kg. which for safety reasons requires an adhesive force which is approximately two and a half times as strong and therefore amounts up to 2.5 tons. If such an adhesive force is to be produced by an electromagnet, such magnet itself would have to have a weight which considerably exceeds the weight of the concrete form. Finally, the vibrators themselves would also have to be of much larger dimensions since they would have to vibrate not only the concrete form and the concrete which has been poured into this form, but also the large electromagnet. Last not least, when considering the use of such an electromagnet, it is necessary also to consider its extremely high cost.

It is therefore an object of the present invention to provide a new method and a new device for removably securing one or more vibrators to a concrete form, for example, to the outer jacket or to the core of a form for making concrete pipes, without requiring any mechanical connecting means and in such a manner that the vibrations which are produced by the vibrator will be reliably transmitted to the respective parts of the form and through the latter to the concrete mixture which is to be compacted. The method and the device according to the present invention should also be applicable to concrete formwork of any kind or shape and regardless of the material of which the formwork is made.

According to the invention, this object is attained by providing a supporting bracket to which a vibrator is rigidly secured and which is made in the form of a vacuum hood and provided with connections either to a suction line or to the outer air and with means for attaching his bracketlike vacuum hood airtight to the desired place of a concrete form so that, when this vacuum hood is evacuated, the vibrator will be firmly and immovably connected to the form. Thus, after the vibrator has been switched on, its vibrations will be transmitted through the supporting bracket and its vacuum hood to the concrete form and through the latter to the concrete mixture which is to be compacted in this form. When the compacting process is completed, the vibrator is switched off and at the same time the vacuum hood is connected to the outer air so as to permit the entire vibrating apparatus to be removed from the concrete form.

When employing the method according to the invention, it is no longer necessary to secure the vibrators to the concrete forms by welding or bolting. It is also an important advantage of the present invention that the new method and the new connecting means permit the vibrators to be connected to concrete forms of any size and shape and consisting of any desirable material. As a further advantage of the new method it may be pointed out that in most cases of its application, there is no need to purchase a vacuum generator especially for operating the vacuum hood since usually such generators are already available since they are required, for example, for dehydrating the concrete which has been inserted into a form.

By means of the new device it is also possible to apply the vacuum hood since usually such generators are already most suitable places of the concrete form during the production of a concrete element and to shift them upwardly along the form as the level of the concrete rises which has been filled into the form. This permits the concrete to be compacted very etficiently and effectively. Furthermore, since mechanical connecting means are no longer required, it is now also no longer necessary to design the concrete forms in any particular manner which would permit the vibrators to be connected thereto.

For carrying out the new method, the invention provides a supporting bracket which comprises a stool-shaped member to which the vibrator is rigidly secured and the feet of which are provided with contact surfaces which, when the vibrator is to be used, are applied directly and nonelastically upon the outer wall of the concrete form. The supporting bracket further comprises a vacuum hood which is connected airtight to the stool-shaped member, has a connecting socket for connecting the hood either to a suction line or to the outer air, and has one open side which is adapted to be applied upon the outer wall of the concrete form and is surrounded by a resilient gasket for connecting the vacuum hood airtight to the outer form wall so that, when a suction is applied to the vacuum hood and a vacuum is produced therein, this hood will adhere automatically to the outer wall of the concrete form and the vibrations which are produced by the vibrator when switched on will be transmitted by the contact surfaces on the feet of the stool-shaped element of the supporting bracket directly to the concrete form and through the latter to the concrete which is to be compacted. The vibrating apparatus according to the invention and for carrying out the method according to the invention therefore consists essentially of the vibrator itself and of the supporting bracket which, in turn, consists of a stool-shaped supporting member to which the vibrator is rigidly secured and of a vacuum hood.

The vibrating apparatus according to the invention is extremely handly and may be very easily manipulated. It may be applied upon and removed from a concrete form very quickly and by a few simple manipulations, and it may therefore be shifted without difficulty from one place to another on a concrete form of a larger size or from one form to another.

The outer connecting edges of the open side of the vacuum hood which are sealed airtight by a resilient gasket and the contact surfaces on the feet of the stoolshaped supporting member which forms the actual supporting bracket of the vibrator are preferably made of a shape so as to conform with that of the outer wall of the concrete form upon which the vibrating apparatus is to be applied. Thus, for example, if the vibrating apparatus is to be employed for producing concrete pipes, the outer edge surfaces of the vacuum hood and the entire contact surfaces of the stool-shaped bracket form parts of a cylindrical surface which has the same degree of curvature as the outer wall of the concrete wall. Consequently, the vacuum chamber in the hood will be sealed airtight to the outer form wall, while the contact surfaces engage fully and rigidly with the form wall.

The vacuum hood may be designed in the form of a single suction cup of the required size or it may consist of several suction cups each of which is provided with a hose connection or the like for the suction line.

According to a preferred embodiment of the invention, the vacuum hood of the supporting bracket consists of a rectangular hood of sheet metal the upper or outer side of Which is provided with a central square aperture through which the stool-shaped bracket member projects. The outer peripheral edge of this outer hood plate is bent over at a right angle in the direction toward the open side of the hood, While a smaller perforated rectangular plate serving as a contact plate extends parallel to the outer hood plate and is likewise provided with a peripheral rectangularly bent edge which is bent toward and welded to the outer hood plate into which it is inserted. This perforated plate is rigidly secured to the feet of the stool-shaped member, and between its outer edge and the outer edge of the larger hood plate an annular channel is formed into which a sealing gasket is inserted.

This sealing gasket is preferably provided on the side which is adapted to be applied upon the concrete form with a continuous rim of a trapezoidal cross section which projects from the annular channel and insures that, when the vacuum hood is evacuated, it will tightly engage at all points with the outer wall of the concrete form, even if the latter has small uneven parts.

-The vacuum hood may be made entirely of thin sheet metal. In this event, it is preferably provided on its outer side with reinforcing ribs. If desired, such ribs may also be provided on the inner side of the hood in place of or in addition to the perforated plate. In the latter case, the end surfaces of these ribs are adapted to serve as contact surfaces and to engage with the outer wall of the concrete form.

The vibrator may be of a conventional type and be operated either electromagnetically or by means of compressed air. In the latter case, the vibrator is connected to the pressure side of a compressor, the suction side of which is connected to the hose connection of the vibrator supporting bracket. The compressor will then serve for producing the vacuum for Connecting the vibrator to the concrete form and also for operating the vibrator.

These and further features and advantages of the present invention will become more clearly apparent from the following detailed description thereof which is to be read with reference to the accompanying drawings, in which:

FIG. 1 shows a front view of a vibrating apparatus according to the invention which is attached to a form for a concrete pipe;

FIG. 2 shows a cross section which is taken along the line IIII of FIG. 1;

FIG. 3 shows a rear view of the vibrating apparatus, as seen upon the open suction side of the vacuum hood;

FIG. 4 shows a cross section of one lateral side of the vacuum hood and the gasket therein; while FIG. 5 shows a flow chart of a vibrating apparatus according to the invention which is operated solely by compressed air.

As illustrated in FIGS. 1 and 2 of the drawings, the vibrating apparatus according to the invention comprises a vibrator 1 of a conventional type which is mounted on a stool-shaped bracket 2 which is secured to a vacuum hood 3. This vacuum hood 3 is curved uniformly about its transverse axis and consists of a rectangular plate 5 of sheet steel which has a curvature in accordance with the convex curvature of the outer wall of a concrete pipe form 4. The outer edge 6 of this hood plate 5 is bent over so as to extend vertically toward the outer wall of the concrete form 4. Into the inner side of hood plate 5 a perforated plate 7 is inserted which extends parallel to plate 5 and engages tightly and nonelastically with the outer wall of the concrete form 4 when the apparatus is in operation, while its outer edge 8 is bent over so as to project vertically from the outer wall of the form 4 and is welded together with the inner surface of the hood plate 5 so that a channel 9 of a uniform U-shaped cross section is formed along the outer periphery of the vacuum hood 3. Into this channel 9 a resilient gasket 10 is inserted which, as shown in FIG. 4, has a continuous projection 10a of a trapezoidal cross section projecting from the channel 9. The sheet-metal hood plate 5 which forms the outer side of the vacuum hood 3 is provided with a substantially square aperture 11 through which the bracket 2 projects which supports the vibrator 1.

This bracket 2 which has a shape of a truncated pyramid is formed by four trapezoidal sheet-metal side walls 12 and an outer supporting plate 13 on which the vibrator 1 is rigidly secured by screws 14. Directly underneath the supporting plate 13 the side walls 12 are provided with apertures 15 through which the nuts (not shown) for the screws 14 may be inserted. The lower or inner edges of the side walls 12 are welded upon base plates 16 which, in turn, are welded together with the perforated plate 7. The side walls 12 are further welded airtight to the edges of the square aperture 11 in the hood plate 5. Underneath the apertures 15 in the side walls 12 of bracket 2 the latter is provided with an intermediate plate 17 which extends parallel to the supporting plate 13 and the edges of which are likewise welded airtight to the side walls 12. Thus, a vacuum chamber is formed which is defined by the outer wall of the concrete form 4, the gasket 10, the hood plate 5, the side walls 12, and the intermediate plate 17. This vacuum chamber is adapted to be connected to a vacuum generator by a hose socket 18 which is mounted in the hood plate 5 and by at least one hose which is connected to this socket 18.

For solidifying the vacuum hood 3, reinforcing ribs 19 which extend from the corners of the square aperture 11 toward the corners of the hood plate 5 and in the direction of its longitudinal axis, respectively, are welded upon the outer side of plate 5. For the same purpose and also for transmitting the vibrations from the vibrator 1 to the concrete form 4, it is also possible to provide the inside of the vacuum chamber with ribs either in place of or in addition to the perforated plate 7.

After all of the welds on the bracket 2 and the vacuum hood 3 have been completed, the tensions which are produced by the welding of the material are eliminated by annealing so that no cracks will occur in the material during the operation of the vibrating apparatus.

When the vibrating apparatus according to the invention is to be used, it is applied upon the outer surface of the concrete form 4 and the vacuum hood is then evacuated. Gasket 10 is thereby compressed and the vacuum hood 3 is sucked tightly against the concrete form 4 until the perforated plate 7 engages upon the surface of the latter. When the vibrator i1 is then switched on, its vibrations are transmitted by the bracket 2 and the perforated plate 7 to the concrete form 5. It is a particular advantage of the vibrating apparatus according to the invention that during the compacting process it may be shifted from one place to another without loss of time. The surface area of the vacuum hood which is adapted to adhere to the concrete form is so large that the adhesive force which is produced by the vacuum is several times as large as the jarring force which is produced by the vibrator. Consequently, there is no danger that the vibrating apparatus may unintentionally be separated from or shifted relative to the concrete form.

The vibrator may be of any conventional type and be operated, for example, electromagnetically or by means of compressed air, as indicated diagrammatically at 20 in FIG. 5. This vibrator 20 is connected to the pressure line 2 1 of a compressor 22 and is provided with a relief or discharge line 23. The suction line 24 of the compressor 22 is provided with a shutoff valve 2 5. Between this valve and the compressor 22 the suction line 24 is connected by a line 26 to the vacuum connection of the vibrating apparatus, that is to the hose socket 18 as shown in FIG. 1. When the apparatus has been placed upon the concrete pipe form and the compressor 22 is started, valve 25 is at first kept in its closed position so that the required relatively small vacuum is formed in the vacuum hood 27. The vibrator 20 remains at this time practically ineffective since the volume of air which is supplied to it is insufiicient. Thereafter, valve 25 is slowly opened so that the vibrator is fully actuated and the compacting process is started.

Although my invention has been illustrated and described with reference to the preferred embodiment thereof, I wish to have it understood that it is in no way limited to the details of such embodiment but is capable of numerous modifications within the scope of the appended claims.

Having thus fully disclosed my invention, what I claim 1s:

1. A vibrating apparatus for compacting a concrete mixture which has been filled into a concrete form for producing a concrete structure comprising a rigid supporting bracket having feet on one end, a vibrator rigidly secured to said bracket at the other end thereof, and a vacuum hood secured to said bracket and forming an enlargement in lateral directions thereof adjacent to said feet and having a substantially open side adapted to be applied together with said feet upon a surface of said form so that, when said hood is evacuated, it will be drawn airtight upon said form and thereby connect said bracket together with said vibrator rigidly to said form.

2. A vibrating apparatus as defined in claim 1, in which said vacuum hood comprises a plate having a substantially central aperture and a continuous rim extending along all lateral edges of said plate and projecting toward the open side of said hood, a resilient gasket within said rim and normally projecting from the free edge thereof and adapted to be compressed when said hood after being applied upon a surface of said concrete form is evacuated, said bracket having side walls extending from the out side through said aperture and secured airtight to the edges of said apertures, said feet forming enlarged contact surfaces on the ends of said side walls within said hood and disposed substantially within the plane of said gasket when partly compressed, so that, when said gasket is fully compressed by the evacuation of said hood, said contact surfaces engage fully with said surface of said concrete form and said bracket with said vibrator thereon adheres in a fixed position to said concrete form and, when said vibrator is then actuated, its vibrations are directly transmitted by said contact surfaces to said concrete form.

3. A vibrating apparatus as defined in claim 2, in which said contact surfaces of said bracket and the projecting end surface of said gasket at least when said hood is evacuated have a shape substantially complementary to the shape of said surface of said concrete form.

4. A vibrating apparatus as defined in claim 2, in which said hood plate including said rim thereof has a substantially rectangular shape and said aperture in said hood plate has a substantially square shape and its edges are welded to said side walls of said bracket having together a substantially square cross section at least along the plane where they extend through said aperture, said contact surfaces on said bracket feet comprising a perforated, substantially rectangular plate rigidly secured to 7 said feet and having a continuous rim of a smaller size than the rim on said hood plate and extending substantially parallel thereto so that both rims together with the larger edge portion of said hood plate define an annular recess into which said gasket is inserted.

S. A vibrating apparatus as defined in claim 4, in which each of said Walls of said bracket has a trapezoidal shape and the outwardly projecting ends of said side walls opposite to said feet are secured to a substantially square mounting plate to which said vibrator is secured so that said bracket has substantially the shape of a truncated pyramid.

6. A vibrating apparatus as defined in claim 5, in which said bracket further comprises a partition extending substantially parallel to said mounting plate intermediate the latter and said perforated plate and welded airtight to said side walls of said bracket.

7. A vibrating apparatus as defined in claim 2, in which when said hood is not evacuated and said gasket is therefore not compressed, the part of said gasket projecting from said rim has a substantially trapezoidal cross section.

8. A vibrating apparatus as defined in claim 2, further comprising ribs secured to and projecting from at least one side of said hood plate for reinforcing said vacuum hood.

9. A vibrating apparatus as defined in claim 1, in

which said vacuum hood has at least one connecting socket adapted to be connected alternately to a suction line for evacuating said hood or to the outer air when said apparatus is to be removed from said concrete form or to be shifted to a different position on said form.

.10. A vibrating apparatus as defined in claim 9, in which said vibrator is adapted to be operated by compressed air, first conduit means for connecting said vibrator to the pressure side of a compressor, a suction line connected to the suction side of said compressor, and second conduit means for connecting said connecting socket of said vacuum hood to said suction line.

11. A vibrating apparatus as defined in claim 10, further comprising a shutoff valve in said suction line of said compressor, said second conduit means being connected to said suction line intermediate said valve and said compressor.

References Cited UNITED STATES PATENTS 1,858,855 5/1932 Haas. 2,749,097 6/1956 Billner. 2,185,850 1/1940 Jackson. 2,411,317 11/1946 Day.

ROBERT W. JENKINS, Primary Examiner

## Classifications

- B28B1/087
- B28B1/087

---

Generated by IPtorch. Verify legal conclusions against the official publication.
