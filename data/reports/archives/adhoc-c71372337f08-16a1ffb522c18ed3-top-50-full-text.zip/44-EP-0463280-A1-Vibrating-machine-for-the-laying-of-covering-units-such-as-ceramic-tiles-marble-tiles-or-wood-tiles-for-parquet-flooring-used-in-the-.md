# 44. Vibrating machine for the laying of covering units, such as ceramic tiles, marble tiles or wood tiles for parquet flooring used in the building industry

- **Archive rank:** 44 of 50
- **Publication:** [EP-0463280-A1](https://patents.google.com/patent/EP0463280A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/008206013/publication/EP0463280A1?q=pn%3DEP0463280A1)
- **Publication date:** 1992-01-02
- **Filing date:** 1990-06-25
- **Earliest priority:** 1990-06-25
- **Family:** 8206013
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** CRAVOTTA ARCANGELO

## Abstract

A vibrating machine for the laying of covering units used in the building industry essentially comprises a vibrating base plate (1) activated by a vibrator (2). 
     An extendable and retractable gripping device (5) clasps and grips the covering unit (18) to be laid by means of the vibrating machine, at an equal distance with respect to all other contiguous covering units (18). 
     The vibrator (2), fixed to the vibrating base plate (1), activates rhythmically, at predetermined frequency and intensity, said vibrating base plate (1). 
     Said vibrating base plate (1) is distanced from the cover (14) by means of suitable snubbers. 
     The vibration of the vibrating base plate (1) is transmitted to the covering unit (18), causing uniform packing at the desired level in the layer of plastic cementing support material which is used normally in the laying of covering units for floors, walls and similar.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/EP-0463280-A1/000.png)

![Sketch 1 for EP-0463280-A1](https://nimo.iptorch.com/refdrawing/EP-0463280-A1/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/EP-0463280-A1/001.png)

![Sketch 2 for EP-0463280-A1](https://nimo.iptorch.com/refdrawing/EP-0463280-A1/001.png)

## Claims

### Claim 1 (independent)

Vibrating machine for the laying of covering units used in the building industry, comprising a vibrating base plate (1) activated by a vibrator (2), having: a pneumatic cylinder (3), fixed on the vibrating base plate (1), which activates a gripping device (5) for a covering unit (18); a pair of level right-angled guides (8) in an inverted "L" arrangement, with the function of positioning the covering unit (18) in an exactly correct position; means for the adjustment of the gripping device (5) and the guides (8) in order that the machine can be adapted to the dimensions of the covering unit to be laid.

### Claim 2

Vibrating machine as in claim 1, wherein the guides (8) are interchangeable by means of a plurality of screws (9) by which said guides (8) are fixed to their relative supports, thus permitting by their substitution of producing the desired distancing of contiguous covering units during the laying phase of said covering units (18).

### Claim 3

Vibrating machine as in claim 1, wherein the means of adjustment of the gripping device (5) and the guides (8) for the adapting of the machine to the dimensions of the covering units (18) to be laid comprise screws or nuts (11, 17) which tighten a pivot (16) inserted into a slot (21) bored into the gripping device (5) in such a way that the gripping device (5) can be slidably adjusted in the slot (21); having a movable frame (13) supporting at least one of the guides (8), slidable by means of slots (19) in which are inserted Allen screws (20) which cross the vibrating base plate (1), for the fixing of the movable frame (13) in the desired position.

### Claim 4

Vibrating machine as in claim 1, comprising a pneumatic three-way selector (6) for the activation of the pneumatic cylinder (3) and the vibrator (2).

## Full description

**[p0001]**

The present invention concerns a vibrating machine for the laying of covering units used in the building industry. The vibrating machine comprises a vibrating base plate on which is fixed a special vibrator. The invention relates to the technical sector concerning equipment and devices for the laying of covering units used in the building industry, such as ceramic tiles, marble tiles, wood tiles for parquet flooring, and in general coverings used in the building industry for floors and walls. In the present art relative to the invention, there is already in existence on the market equipment comprising suction cups, levellers or similar which operate on the surfaces of already-prepared covering units to the end of levelling them or simply packing them down. There are several disadvantages and imperfections in the use of the above-mentioned machines, but especially notable is their inability to execute an accurate unit-by-unit laying with a uniform vibration. Aim of the present invention is to eliminate the above-described disadvantages and in particular to obtain a rhythmic vibration, at a prefixed frequency and intensity, of the covering units so that the packing is uniform and at the desired depth with regard to the plastic cementing support material.

**[p0002]**

Said aims are achieved by the vibrating machine for the laying of covering units used in the building industry, object of the present invention, comprising a base plate activated by a vibrator, characterised by the fact that it comprises: a pneumatic cylinder, fixed on the base plate, with the function of activating a gripping device for the gripping of a covering unit; a pair of level right-angled guides in an inverted "L" arrangement, with the function of positioning the covering unit in an exactly correct position; means for the adjustment of the gripping device and the guides in order that the machine can be adapted to the dimensions of the covering unit to be laid. These and other characteristics will be better evidenced in the illustrated description which follows of a preferred but not exclusive embodiment here described in the form of a non-limiting example with accompanying illustrations, in which: - Figure 1 shows the vibrating machine in full view; - Figure 2 shows, in a reduced frontal view, the machine as it is in the process of laying a covering unit on a horizontal surface, including the levelling of said element with a contiguous unit;

**[p0003]**

- Figure 3 shows the vibrating machine from underneath. With reference to the illustrations, a vibrating base plate (1) is represented, activated by a vibrator (2) with adjustable and preselectable frequency and intensity. A pneumatic three-way selector (6) acts on the flow of compressed air coming from an air line (4) to a pneumatic cylinder (3) and to the vibrator (2). The compressed air line (4) is in turn connected to the electric mains, for example through a compressor, so that the vibrating machine is isolated with respect to said electric mains and thus safe from any possible accident risk. The stem (15) of the pneumatic cylinder (3) is connected to a bar (12) which is pivotedly fixed at one of its ends (10). A pivot (16) is fixed centrally to the bar (12) whose position is adjustable within a slot (21) by means of screws or nuts (11, 17), in such a way that the pivot (16) is solid to a gripping device (5) for a covering unit (18), for example a tile. The gripping device (5), which moves in alternative rectilinear directions when activated by the pneumatic cylinder (3) via the bar (12), essentially comprises a bar in the shape of an inverted "L", having a slot (21) bored into it into which the pivot (16) is inserted.

**[p0004]**

Said gripping device (5) with its movement is aimed at gripping (with pneumatic cylinder retracted) or releasing (with pneumatic cylinder extended) the covering unit (18). Two guides (8) arranged in an inverted "L" shape, level between and at right angles to each other are located parallel to two consecutive sides of the vibrating base plate (1). At least one of the guides (8) is supported on a movable frame (13), slidable by means of slots (19) which permit of extending said guide or guides (8) more or less from the vibrating machine to accommodate covering units (18) of differing sizes. The adjustment into and tightening of the movable frame (13) in the desired position is obtained by means of Allen screws (20) which cross the vibrating base plate (1) and are inserted into the slots (19). The screws or nuts (11, 17), the pivot (16), the slot (21) the movable frame (13) with slots (19) and the Allen screws (20) constitute means of adjustment of the gripping device (5) and of the guides (8) to fit covering units of differing dimensions.

**[p0005]**

The guides (8), apart from permitting of positioning and levelling two contiguous covering units, also function as gauges for the correct distancing of the covering units one from the other, thus obviating the need for traditional gauges. The guides (8) are interchangeable, being fixed by means of screws (9) to their relative supports, in order to permit of variation of the abovementioned distances. Between the vibrating base plate (1) and the vibrating machine's cover (14) are located four snubbers (not illustrated in diagram) made of elastic material, spiral springs and similar, which distance the vibrating base plate (1) from the cover (14), deadening the vibrations that reach the latter. A handle (7) is provided for the holding and carrying of the vibrating machine. Principal advantages of the invention are summarised below: - very easy handling and versatility due to the easy adjustment of the gripping device (5) and the guides (8) which enable the machine to be used for covering units of differing dimensions and shapes;

**[p0006]**

- easy use and substitution of the guides (8) which permit of both distancing contiguous covering units and levelling them perfectly with one another; - perfect packing of the covering units on the plastic cementing support material due to the action of the vibrating base plate (1) on which the vibrator (2) is fixed; - adjustment of the gripping force exerted on the covering units (18) by means of the gripping device (5), and variation of the intensity of the vibrations of the special vibrating base plate (1) by means of a pressure regulator. Obviously many modifications can be made of a practical-applicational nature to details of the vibrating machine without leaving the scope of the appended claims. In the description specific reference has been made to a vibrating machine of the pneumatic type, that is a machine in which the moving organs are powered by means of compressed air, but said organs could equally be of the electrical type and thus be electrically powered. In fact the vibrator could be electrical, and the pneumatic cylinder could be substituted by an electromagnetic actuator.

## Classifications

- B28B1/093
- E04F21/20
- E04G21/16

## Cited patent documents

- [DE-1928942-A1](https://patents.google.com/patent/DE1928942A1/en) — SEA
- [DE-3342072-A1](https://patents.google.com/patent/DE3342072A1/en) — SEA
- [FR-2386641-A1](https://patents.google.com/patent/FR2386641A1/en) — SEA
- [FR-2566822-A1](https://patents.google.com/patent/FR2566822A1/en) — SEA

---

Generated by IPtorch. Verify legal conclusions against the official publication.
