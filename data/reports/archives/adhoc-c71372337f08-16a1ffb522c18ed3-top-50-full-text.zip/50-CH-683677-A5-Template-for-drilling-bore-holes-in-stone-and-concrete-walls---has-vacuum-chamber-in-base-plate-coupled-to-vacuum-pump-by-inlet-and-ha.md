# 50. Template for drilling bore holes in stone and concrete walls - has vacuum chamber in base plate coupled to vacuum pump by inlet and has rubber seal which compresses when predetermined underpressure is attained

- **Archive rank:** 50 of 50
- **Publication:** [CH-683677-A5](https://patents.google.com/patent/CH683677A5/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/004236645/publication/CH683677A5?q=pn%3DCH683677A5)
- **Publication date:** 1994-04-29
- **Filing date:** 1991-09-02
- **Earliest priority:** 1991-09-02
- **Family:** 4236645
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** ANDREAS KAUFMANN

## Abstract

The base plate (1) has releasable holders and at least one socket, and a vacuum chamber (5) coupled to a vacuum pump by an inlet (11) and surrounded by a compressible rubber seal (8). Outside the vacuum chamber region, the base plate has at least one drill socket (10), protrusions above the plate level. The socket does not reach the level of the uncompressed rubber seal edge. Thus, after attaining a certain underpressure in the vacuum chamber, the rubber seal compressed until the drill template sticks to the wall in a self-supporting manner, while the socket presses directly against the wall to be drilled. ADVANTAGE - Versatile design for precise fitting.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CH-683677-A5/pdf000.png)

![Sketch 1 for CH-683677-A5](https://nimo.iptorch.com/refdrawing/CH-683677-A5/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CH-683677-A5/pdf001.png)

![Sketch 2 for CH-683677-A5](https://nimo.iptorch.com/refdrawing/CH-683677-A5/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/CH-683677-A5/pdf002.png)

![Sketch 3 for CH-683677-A5](https://nimo.iptorch.com/refdrawing/CH-683677-A5/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/CH-683677-A5/pdf003.png)

![Sketch 4 for CH-683677-A5](https://nimo.iptorch.com/refdrawing/CH-683677-A5/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/CH-683677-A5/pdf004.png)

![Sketch 5 for CH-683677-A5](https://nimo.iptorch.com/refdrawing/CH-683677-A5/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/CH-683677-A5/pdf005.png)

![Sketch 6 for CH-683677-A5](https://nimo.iptorch.com/refdrawing/CH-683677-A5/pdf005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/CH-683677-A5/pdf006.png)

![Sketch 7 for CH-683677-A5](https://nimo.iptorch.com/refdrawing/CH-683677-A5/pdf006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/CH-683677-A5/pdf007.png)

![Sketch 8 for CH-683677-A5](https://nimo.iptorch.com/refdrawing/CH-683677-A5/pdf007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/CH-683677-A5/pdf008.png)

![Sketch 9 for CH-683677-A5](https://nimo.iptorch.com/refdrawing/CH-683677-A5/pdf008.png)

## Claims

### Claim 1 (independent)

Bohrlehre zum Anbringen von Bohrlöchern in Stein- und Betonwänden, bestehend aus einer Grundplatte (1) mit Halte- und Lösemittel und mindestens einer Buchse (10), dadurch gekennzeichnet, dass die Grundplatte (1) eine Vakuumkammer (5) aufweist, die über einen Einlass (11) mit einer1. drilling jig for making drill holes in stone and concrete walls, consisting of a base plate (1) with holding and solvent and at least one socket (10), characterized in that the base plate (1) has a vacuum chamber (5) which via an inlet (11) with a Vakuumpumpe in Verbindung steht und von einer komprimierbaren Gummidichtung (8) umgeben ist, wobei in der Grundplatte (1), ausserhalb des Bereiches der Vakuumkammer (5), mindestens eine Bohrbuchse (10) vorgesehen ist, die über dem Niveau (3) der Grundplatte (1) vorsteht, jedoch gegenüber dem Niveau, in dem der Rand der umlaufenden unkomprimierten Gummidichtung (8) verläuft, zurücksteht, so dass nach Erreichen eines gewissen Unterdruckes in der Vakuumkammer (5), die umlaufende Gummidichtung (8) soweit komprimierbar ist, dass die Bohrlehre selbsttragend an der Wand haftet und die Bohrbuchse (10) direkt auf der zu bohrenden Wand andrückt.The vacuum pump is connected and is surrounded by a compressible rubber seal (8), at least one drill bushing (10) being provided in the base plate (1), outside the area of the vacuum chamber (5), which is above the level (3) of the base plate (1) protrudes, but stands back from the level at which the edge of the circumferential uncompressed rubber seal (8) runs, so that after reaching a certain negative pressure in the vacuum chamber (5), the circumferential rubber seal (8) is compressible to the extent that the drilling jig adheres to the wall in a self-supporting manner and presses the drill bushing (10) directly onto the wall to be drilled.

### Claim 2

Bohrlehre nach Anspruch 1, dadurch gekennzeichnet, dass die Bohrlehre mit mindestens einem Haltegriff (17) für die Positionierung versehen ist.2. drilling jig according to claim 1, characterized in that the drilling jig is provided with at least one handle (17) for positioning.

### Claim 3

Bohrlehre nach Anspruch 1, dadurch gekennzeichnet, dass die Vakuumkammer (5) mit einem Vakuumabbauventil (13) versehen ist.3. Drilling jig according to claim 1, characterized in that the vacuum chamber (5) is provided with a vacuum breakdown valve (13).

### Claim 4

Bohrlehre nach Anspruch 2, dadurch gekennzeichnet, dass der Einlass mit einem automatischen Schliessventil (20) versehen ist, welches eine Hülse (21) umfasst, die quer zu seiner Längsrichtung Bohrungen aufweist, die von einer dichtenden, in Längsrichtung auf der Hülse (21), verschiebbaren Muffe (22) umgeben ist, die als Haltegriff (25) ausgestaltet ist, so dass je nach Lage der Muffe (22) auf der Hülse (21) eine vakuumauf- oder abbauende Position erreichbar ist.4. Drilling jig according to claim 2, characterized in that the inlet is provided with an automatic closing valve (20) which comprises a sleeve (21) which has transverse to its longitudinal direction bores which extend from a sealing, in the longitudinal direction on the sleeve ( 21), displaceable sleeve (22), which is designed as a handle (25), so that, depending on the position of the sleeve (22) on the sleeve (21), a vacuum-building or dismantling position can be reached.

### Claim 5

Bohrlehre nach Anspruch 1, dadurch gekennzeichnet, dass die umlaufende Gummidichtung (8) aus geschäumtem Material besteht und im Inneren offenporig, aussen jedoch geschlossenporig ist.5. Drilling jig according to claim 1, characterized in that the circumferential rubber seal (8) consists of foamed material and is open-pored on the inside, but closed-pored on the outside.

### Claim 6

Bohrlehre nach Anspruch 5, dadurch gekennzeichnet, dass die umlaufenden Dichtung (8) parallel zur Grundfläche der Grundplatte soweit abgeschnitten ist, dass der offenporige Bereich als Auflagefläche auf die zu bohrende Wand zu liegen kommt.6. drilling jig according to claim 5, characterized in that the circumferential seal (8) is cut parallel to the base of the base plate to such an extent that the open-pore area comes to rest as a bearing surface on the wall to be drilled.

### Claim 7

Bohrlehre nach Anspruch 1, dadurch gekennzeichnet, dass die Grundplatte (1) einen rechteckigen Grundriss aufweist, in der eine zentrische, konkav gewölbte, runde Vakuumkammer (5) eingelassen ist, die von einer ringförmigen Nut (7) umgeben ist, in der die umlaufende Dichtung (8) eingelassen ist.7. drilling jig according to claim 1, characterized in that the base plate (1) has a rectangular plan in which a central, concavely curved, round vacuum chamber (5) is let in, which is surrounded by an annular groove (7) in which the circumferential seal (8) is embedded.

### Claim 8

Bohrlehre nach Anspruch 7, dadurch gekennzeichnet, dass in jeder der vier Ecken (6) der Grundplatte (1) eine auswechselbare Bohrbuchse (10) angeordnet ist.8. drilling jig according to claim 7, characterized in that in each of the four corners (6) of the base plate (1) an interchangeable drill bushing (10) is arranged.

### Claim 9

Bohrlehre nach Anspruch 7, dadurch gekennzeichnet, dass entlang mindestens einer Seitenkante der Bohrlehre zwei Gewindelöcher (16) ausserhalb des Bereiches der Vakuumkammer angeordnet sind, an der ein Bohrschablonenhalter (40) lagefest montiert ist, dessen unteres Niveau mindestens annähernd mit dem Niveau der Auflage (33) der Bohrbuchsen fluchtet.9. drilling jig according to claim 7, characterized in that along at least one side edge of the drilling jig two threaded holes (16) are arranged outside the area of the vacuum chamber on which a drilling template holder (40) is fixed in position, the lower level of which is at least approximately at the level of The support (33) of the drill bushes is aligned.

### Claim 10

Bohrlehre nach Anspruch 1, dadurch gekennzeichnet, dass in mindestens einer Bohrbuchse (10) eine einlegbare und herausnehmbare Zentriervorrichtung (30) vorgesehen ist.10. Drilling jig according to claim 1, characterized in that an insertable and removable centering device (30) is provided in at least one drill bushing (10).

### Claim 11

Verwendung der Bohrlehre nach den Ansprüchen 1-10, zum Anbringen von Bohrlöchern in11. Use of the drilling jig according to claims 1-10, for drilling holes in 55 1010th 1515 2020th 2525th 3030th 3535 4040 4545 5050 5555 6060 6565 44th 77 CH 683 677 A5CH 683 677 A5 Stein- und Betonwänden, dadurch gekennzeichnet, dass die am Einlass angeschlossene Vakuumpumpe in Betrieb gesetzt wird, während das Vakuumabbauventil geöffnet ist, dass danach die mindestens eine Bohrbuchse auf eine Markierung an der Wand ausgerichtet wird, wo ein Loch zu bohren ist, dass nun das Vakuumabbauventil die Bohrlehre an der Wand hält, worauf unter ständigem Weiterbetrieb der Vakuumpumpe, die die Leckage kompensiert, die Bohrlöcher angebracht werden.Stone and concrete walls, characterized in that the vacuum pump connected to the inlet is put into operation while the vacuum dismantling valve is open, that the at least one drill bush is then aligned with a marking on the wall where a hole is to be drilled, that now that Vacuum extraction valve holds the drilling jig on the wall, whereupon the drilling holes are made while the vacuum pump, which compensates for the leakage, is continuously operated.

### Claim 12

Verwendung der Bohrlehre nach Anspruch 11, dadurch gekennzeichnet, dass nach der Ausrichtung einer Bohrbuchse auf eine Markierung unter den Bohrschablonenhalter eine Bohrschablone untergeschoben wird und die Bohrlöcher an den vorgegebenen Positionen der Bohrschablone angebracht werden.12. Use of the drilling jig according to claim 11, characterized in that, after the alignment of a drilling bush on a marking under the drilling template holder, a drilling template is pushed under and the boreholes are made at the predetermined positions of the drilling template. 55 1010th 1515 2020th 2525th 3030th 3535 4040 4545 5050 5555 6060 6565 55

## Full description

PERFORMING OPERATIONS; TRANSPORTINGHAND TOOLS; PORTABLE POWER-DRIVEN TOOLS; MANIPULATORSWORKSHOP EQUIPMENT, e.g. FOR MARKING-OUT WORK; STORAGE MEANS FOR WORKSHOPSWork benches; Portable stands or supports for positioning portable tools or work to be operated on therebyStands, supports or guiding devices for positioning portable tools or for securing them to the workDevices for securing hand tools to the workStands attached to the workpiece

Description

Translated from German

1 1

CH 683 677 A5 CH 683 677 A5

2 2nd

Beschreibung description

Die vorliegende Erfindung betrifft eine Bohrlehre zum Anbringen von BohrlÃ¶chern in Stein- und BetonwÃ¤nden, bestehend aus einer Grundplatte mit Halte- und LÃ¶semittel und mindestens einer Bohrbuchse. The present invention relates to a drilling jig for making drill holes in stone and concrete walls, consisting of a base plate with holding and solvent and at least one drill bush.

Das Anbringen von BohrlÃ¶chern in Stein- und BetonwÃ¤nden ist eine Ã¤usserst heikle Aufgabe. Wegen des harten und sprÃ¶den Untergrundes neigt der Bohrer dazu, beim Anbringen der BohrlÃ¶cher zu verlaufen und die RÃ¤nder des Bohrloches brechen aus. Diese Situation wird insbesondere noch verstÃ¤rkt durch die Rauhigkeit der OberflÃ¤che und der inhomogenen HÃ¤rte des Untergrundes. WÃ¤hrend die Anbringung eines einzelnen Bohrloches meist nur eine relative Genauigkeit verlangt, bei der eine Verschiebung um 1 bis 2 mm meist kaum eine Rolle spielt, ist dies beim Anbringen von mehreren BohrlÃ¶chern, die zur Befestigung eines Gegenstandes auf einer Mauer von erheblicher Bedeutung, weil die BohrlÃ¶cher des zu befestigenden Gegenstandes vorgegeben sind. Eine Massabweichung fÃ¼hrt oftmals dazu, dass die vorgegebenen BohrlÃ¶cher des zu befestigenden Gegenstandes mit den angebrachten BohrlÃ¶chern in der entsprechenden Wand nicht mehr fluchten. Um dies zu Vermeiden hat man oftmals sehr einfache, preiswerte Bohrschablonen, die man an der gewÃ¼nschten Stelle erst an der Wand befestigt und erst danach die einem gewissen Raster folgenden BohrlÃ¶chern mit dieser an der Wand befestigten Bohrschablone anbringt. Bei Verwendung einer solchen Bohrschablone, die meist lediglich aus einer einfachen Metallplatte besteht, war es erforderlich, dass ein Hilfsarbeiter diese Platte an die Wand drÃ¼ckte, wÃ¤hrend der zweite Arbeiter das Bohrloch anbrachte, welches zur Befestigung der Platte an der Wand diente. Eine absolute Massgenauigkeit war jedoch auch so kaum erzielbar. Drilling holes in stone and concrete walls is an extremely delicate task. Because of the hard and brittle subsoil, the drill tends to run when drilling the holes and the edges of the hole break out. This situation is particularly aggravated by the roughness of the surface and the inhomogeneous hardness of the surface. While the drilling of a single borehole usually only requires a relative accuracy, in which a shift of 1 to 2 mm usually hardly plays a role, this is of considerable importance when drilling several boreholes that are used to fasten an object to a wall, because the Drill holes of the object to be fastened are specified. A dimensional deviation often means that the specified drill holes of the object to be fastened no longer align with the drill holes in the corresponding wall. In order to avoid this, one often has very simple, inexpensive drilling templates, which one attaches to the wall at the desired location and only then drills the holes following a certain grid with this drilling template attached to the wall. When using such a drilling template, which usually only consists of a simple metal plate, it was necessary for one worker to press this plate against the wall while the second worker was drilling the hole that was used to fasten the plate to the wall. However, absolute dimensional accuracy was hardly achievable.

Es ist daher die Aufgabe der vorliegenden Erfindung, eine Bohrlehre zu schaffen mittels der die vorgenannten Schwierigkeiten Ã¼berwunden werden kÃ¶nnen. Diese Aufgabe lÃ¶st eine Bohrlehre gemÃ¤ss Oberbegriff des Patentanspruches 1 dadurch, dass die Grundplatte eine Vakuumkammer aufweist, die Ã¼ber einen Einlass mit einer Vakuumpumpe in Verbindung steht und von einer komprimierbaren Gummidichtung umgeben ist, wobei in der Grundplatte ausserhalb des Bereiches der Vakuumkammer mindestens eine Bohrbuchse vorgesehen ist, die Ã¼ber dem Niveau der Grundplatte vorsteht, jedoch gegenÃ¼ber dem Niveau in dem der Rand der umlaufenden, unkomprimierten Gummidichtung verlÃ¤uft, zurÃ¼cksteht, so dass nach Erreichen eines gewissen Unterdruckes in der Vakuumkammer, die umlaufende Gummidichtung so weit komprimierbar ist, dass die Bohrlehre selbstragend an der Wand haftet und die Bohrbuchse auf der zu bohrenden Wand andrÃ¼ckt. It is therefore the object of the present invention to create a drilling jig by means of which the aforementioned difficulties can be overcome. This object is achieved by a drilling jig according to the preamble of claim 1 in that the base plate has a vacuum chamber which is connected to a vacuum pump via an inlet and is surrounded by a compressible rubber seal, at least one drill bushing being provided in the base plate outside the area of the vacuum chamber which protrudes above the level of the base plate, but stands back from the level at which the edge of the circumferential, uncompressed rubber seal runs, so that after reaching a certain negative pressure in the vacuum chamber, the circumferential rubber seal is compressible to such an extent that the drilling jig is self-supporting adheres to the wall and presses the drill bush onto the wall to be drilled.

Weitere AusfÃ¼hrungen des Erfindungsgegenstandes gehen aus den abhÃ¤ngigen PatentansprÃ¼chen 2 bis 10 hervor, wÃ¤hrend die erfindungsgemÃ¤sse Verwendung der Bohrlehre nach den AnsprÃ¼chen 1 bis 10 aus den AnsprÃ¼chen 11 und 12 hervorgeht. Further embodiments of the subject matter of the invention emerge from the dependent patent claims 2 to 10, while the inventive use of the drilling jig according to claims 1 to 10 emerges from claims 11 and 12.

In der Zeichnung sind zwei AusfÃ¼hrungsbeispiele des Erfindungsgegenstandes dargestellt und anhand der nachfolgenden Beschreibung erlÃ¤utert. Es zeigt: In the drawing, two exemplary embodiments of the subject matter of the invention are illustrated and explained using the following description. It shows:

Fig. 1 eine perspektivische Darstellung einer Bohrlehre schrÃ¤g von oben, teilweise im Schnitt; Figure 1 is a perspective view of a drilling jig obliquely from above, partially in section.

Fig. 2 einen Grundriss der Bohrlehre nach Fig. 1 von unten mit Blick auf die Vakuumkammer; FIG. 2 shows a floor plan of the drilling jig according to FIG. 1 from below with a view of the vacuum chamber;

Fig. 3 eine Seitenansicht der Bohrlehre nach den Fig. 1 und 2, teilweise im Schnitt entlang der Linie A-A in Fig. 2 unter Weglassung der Haltegriffe und des Schliessventiles mit integriertem Kupplungsnippel. Fig. 3 is a side view of the drilling jig according to FIGS. 1 and 2, partly in section along the line A-A in Fig. 2, omitting the handles and the closing valve with an integrated coupling nipple.

Fig. 4 eine Ansicht einer zweiten Variante einer Bohrlehre in Ansicht von unten; 4 shows a view of a second variant of a drilling jig in a view from below;

Fig. 5 in der Seitenansicht, teilweise im Schnitt; Fig. 5 in side view, partly in section;

Fig. 6 eine vergrÃ¶sserte Schnittdarstellung durch die umlaufende Gummidichtung; 6 is an enlarged sectional view through the circumferential rubber seal;

Fig. 7 eine Bohrbuchse mit eingelegter Zentriervorrichtung in der Aufsicht und Fig. 7 is a drill bushing with inserted centering device in supervision and

Fig. 8 in der Seitenansicht. Fig. 8 in side view.

Fig. 9 eine schematische Darstellung der Verwendung der Bohrlehre mit Einsatz eines Bohrschablonenhalters. Fig. 9 is a schematic representation of the use of the drilling jig using a drilling template holder.

Als wesentlichstes Element weist die Bohrlehre eine Grundplatte 1 auf. Diese ist aus einer Alumini-umgussplatte gefertigt. Auf seiner OberflÃ¤che 2 ist er absolut eben geformt. Auf seiner Unterseite 3 ist eine Ausnehmung herausgearbeitet, die so ausgearbeitet ist, dass lediglich noch ein umlaufender Steg 4 verbleibt. Dieser umlaufende Steg 4 folgt den Seitenkanten der Grundplatte 1 und weicht lediglich in den vier Eckbereichen von den Seitenkanten nach innen zurÃ¼ck, so dass dort eine gegenÃ¼ber der Unterkante des umlaufenden Steges nach oben versetzte Ausnehmung 6 verbleibt. In den umlaufenden Steg 4 ist eine mittig darin verlaufende, ebenfalls vollstÃ¤ndig umlaufende Nut 7 angebracht. In die Nut 7 ist eine umlaufende Dichtung 8 eingelassen, die sich klemmend in der Nut 7 hÃ¤lt. In mindestens einer der vier Ausnehmungen 6, in den Eckbereichen, ist eine Aufnahmebohrung 9 angebracht. Diese dient dazu, eine auswechselbare Bohrbuchse 10 klemmend zu halten. In der Fig. 1 ist lediglich eine solche Aufnahmebohrung dargestellt, wÃ¤hrend in den Fig. 2 und 3 derselben AusfÃ¼hrung, vier Bohrbuchsen mit unterschiedlichen Durchmessern dargestellt sind. The most essential element of the drilling jig is a base plate 1. This is made from a cast aluminum plate. It is absolutely flat on its surface 2. On its underside 3, a recess is worked out, which is worked out in such a way that only one peripheral web 4 remains. This circumferential web 4 follows the side edges of the base plate 1 and only retracts inwards from the side edges in the four corner regions, so that there remains a recess 6 offset upwards relative to the lower edge of the circumferential web. In the circumferential web 4, a groove 7, which is also completely circumferential and extends centrally, is provided. A circumferential seal 8 is inserted into the groove 7 and is held in the groove 7 by clamping. A receiving bore 9 is made in at least one of the four recesses 6, in the corner regions. This serves to keep an exchangeable drill bush 10 clamped. In Fig. 1 only such a receiving bore is shown, while in Fig. 2 and 3 of the same embodiment, four drill bushes with different diameters are shown.

Um das erforderliche Vakuum in der Vakuumkammer 5 zu erzeugen, steht diese Ã¼ber ein Einlassventil 11 mit einer nicht dargestellten Vakuumpumpe in Verbindung. Das Einlassventil 11 ist mit einem integrierten Kupplungsnippel 12 versehen. So lÃ¤sst sich die erfindungsgemÃ¤sse Bohrlehre Ã¼ber einem Ansaugschlauch mit einer Steckkupplung mit der Vakuumpumpe verbinden. Damit sich die Bohrlehre auf der Wand verschieben lÃ¤sst, beziehungsweise von dieser abnehmen lÃ¤sst, muss der Unterdruck in der Vakuumkammer 5 abgebaut werden. Hierzu dient das Vakuumabbauventil 13, welches im wesentlichen aus einer Federplatte 14 besteht, die dichtend auf eine mit der Vakuumkammer 5 kommunizierenden Bohrung 15 aufliegt. In order to generate the required vacuum in the vacuum chamber 5, it is connected via an inlet valve 11 to a vacuum pump, not shown. The inlet valve 11 is provided with an integrated coupling nipple 12. The drilling jig according to the invention can thus be connected to the vacuum pump by means of a suction hose with a plug-in coupling. So that the drilling jig can be moved on the wall or removed from it, the vacuum in the vacuum chamber 5 must be reduced. For this purpose, the vacuum release valve 13, which essentially consists of a spring plate 14, lies sealingly on a bore 15 communicating with the vacuum chamber 5.

5 5

10 10th

15 15

20 20th

25 25th

30 30th

35 35

40 40

45 45

50 50

55 55

60 60

65 65

2 2nd

3 3rd

CH 683 677 A5 CH 683 677 A5

4 4th

Auf zwei einander gegenÃ¼berliegenden Seiten sind jeweils zwei von der OberflÃ¤che 2 her zugÃ¤ngliche SacklÃ¶cher 16 mit Innengewinde angebracht, die dazu dienen, einen hier nicht dargestellten Bohrschablonenhalter an der Bohrlehre zu befestigen. Schliesslich sind auf der OberflÃ¤che 2 der Grundplatte 1 auch noch zwei parallel zueinander verlaufende Handgriffe 17 montiert, die ein einwandfreies Hantieren der Bohrlehre erlauben. On each of two opposite sides, two blind holes 16 with internal threads accessible from the surface 2 are provided, which serve to attach a drilling template holder, not shown here, to the drilling jig. Finally, two handles 17, which run parallel to one another, are also mounted on the surface 2 of the base plate 1 and allow the drilling jig to be handled properly.

In den Fig. 4 und 5 ist eine zweite AusfÃ¼hrungsform des Erfindungsgegenstandes dargestellt, bei der die Grundplatte 1 eine quadratische Grundform aufweist und der umlaufende Steg 4 kreisfÃ¶rmig ist. Die Vakuumkammer 5 hat folglich eine konkav gestaltete Glockenform. Entsprechend kann die umlaufende Dichtung 8 eine einfache Ringdichtung sein. Auch hier sind wiederum die Bohrbuchsen 10 in den Eckbereichen ausserhalb der Vakuumkammer 5 angeordnet. Mittels Madenschrauben 18 sind die Bohrbuchsen 10 auswechselbar klemmend in den Aufnahmebohrungen gehalten. 4 and 5, a second embodiment of the subject matter of the invention is shown, in which the base plate 1 has a square basic shape and the circumferential web 4 is circular. The vacuum chamber 5 consequently has a concave bell shape. Accordingly, the circumferential seal 8 can be a simple ring seal. Again, the drill bushings 10 are arranged in the corner areas outside the vacuum chamber 5. By means of grub screws 18, the drill bushings 10 are held interchangeably in the receiving bores.

Im Gegensatz zu der bisher beschriebenen AusfÃ¼hrungsform ist hier eine wesentliche Vereinfachung erzielt worden, in dem das Einlassventil, das Vakuumabbauventil und der Handgriff zu einem einzigen Bauelement kombiniert worden ist. Dieses Element ist an sich bekannt und auf dem Markt erhÃ¤ltlich. Dieses kombinierte Bauelement 20 besteht aus einer HÃ¼lse 21, welche die Form eines RohrstÃ¼ckes hat, welches etwa mittig quer zur LÃ¤ngsrichtung eine geschlossene Wand aufweist. Oberkalb und unterhalb dieser Trennwand sind in der HÃ¼lse 21 mehrere radial nach aussen gerichtete Bohrungen angeordnet. Ãber die HÃ¼lse 21 ist eine verschiebbare HÃ¼lse 22 geschoben, die in seinem mittleren Bereich die HÃ¼lse 21 distanziert umgibt. Endseitig ist die Muffe 22, sowohl oben, wie auch unten mit einer Einengung versehen, die gleitend mit geringem Spiel auf die HÃ¼lse 21 aufliegt. In dem Bereich der beiden Einengungen ist jeweils eine O-Ringdichtung eingelegt, die die Muffe 22 gegenÃ¼ber der HÃ¼lse 21 abdichten. In der, in Fig. 5 dargestellten, unteren Position kommunizieren die radialen Bohrungen in der HÃ¼lse 21 miteinander und sind nach aussen abgedichtet, so dass sich nun Ã¼ber den Ansaugschlauch 24 die Luft aus der Vakuumkammer 5 heraussaugen lÃ¤sst. Schiebt man jedoch die Muffe 22 in eine obere Position, so werden die Radialbohrungen unterhalb der genannten Trennwand von der Muffe 22 nicht mehr abgedeckt und das Vakuum in der Vakuumkammer 5 baut sich Ã¼ber die nun offenen Radialbohrungen ab. FÃ¼r einen besseren Halt ist die Muffe 22 aussen mit einer Randrierung 25 versehen, so dass die Muffe 22 sich in idealer Weise nun gleichzeitig als Handgriff benÃ¼tzen lÃ¤sst. In contrast to the previously described embodiment, a significant simplification has been achieved in that the inlet valve, the vacuum release valve and the handle have been combined to form a single component. This element is known per se and is available on the market. This combined component 20 consists of a sleeve 21 which has the shape of a tube piece which has a closed wall approximately in the center transverse to the longitudinal direction. Upper calf and below this partition are arranged in the sleeve 21 a plurality of radially outward bores. A displaceable sleeve 22 is pushed over the sleeve 21 and surrounds the sleeve 21 at a distance in its central region. At the end, the sleeve 22 is provided with a constriction, both at the top and at the bottom, which rests on the sleeve 21 with little play. In the area of the two constrictions, an O-ring seal is inserted, which seals the sleeve 22 with respect to the sleeve 21. In the lower position shown in FIG. 5, the radial bores in the sleeve 21 communicate with one another and are sealed off from the outside, so that the air can now be sucked out of the vacuum chamber 5 via the suction hose 24. However, if the sleeve 22 is pushed into an upper position, the radial bores below the partition mentioned are no longer covered by the sleeve 22 and the vacuum in the vacuum chamber 5 is released via the now open radial bores. For a better grip, the sleeve 22 is provided on the outside with a rim 25, so that the sleeve 22 can now be used as a handle in an ideal manner.

Bei der Verwendung der erfindungsgemÃ¤ssen Bohrlehre geht man so vor, dass man vorerst die gewÃ¼nschte Stelle an der Wand ausmisst und markiert. Hierauf setzt man die mit der Bohrlehre in Verbindung stehende Vakuumpumpe in Betrieb und setzt die Bohrlehre etwa im gewÃ¼nschten Bereich an der Wand an. Damit sie sich nicht sogleich festsaugt und ein Verschieben verunmÃ¶glicht ist, hÃ¤lt man das Vakuumabbauventil 13 in der geÃ¶ffneten When using the drilling jig according to the invention, the first step is to measure and mark the desired location on the wall. The vacuum pump connected to the drilling jig is then put into operation and the drilling jig is placed in the desired area on the wall. So that it does not immediately get stuck and movement is impossible, the vacuum release valve 13 is kept in the open position

Stellung. Hierdurch entsteht zwar in der Vakuumkammer 5 trotzdem noch ein geringer Unterdruck, doch ist dieser so gering, dass sich die Bohrlehre noch leicht auf der Wand verschieben lÃ¤sst. Befindet sich die gewÃ¼nschte Bohrbuchse mit dem korrekten Innenmass exakt Ã¼ber der angezeichneten Markierung, so schliesst man das Vakuumabbauventil 13 und die Bohrlehre saugt sich auf der Wand fest. Da jede Stein- oder Betonwand eine unebene OberflÃ¤che aufweist und sowohl eine Stein-wie auch Betonwand eine gewisse PorositÃ¤t aufweist, tritt eine mehr oder weniger grosse Leckage ein. Deshalb ist es wesentlich, dass die Vakuumpumpe, wÃ¤hrend der gesamten Zeit der Benutzung der Bohrlehre in Betrieb bleibt, um die entstehende Leckage zu kompensieren. Das Schiiessen des Va-kuumabbauventiles 13 erfolgt in der AusfÃ¼hrungsform gemÃ¤ss den Fig. 1 bis 3 dadurch, dass man die Federplatte 14, welche man zuvor nach oben gezogen hat, loslÃ¤sst. Die AusfÃ¼hrungsform gemÃ¤ss den Fig. 4 und 5 ist diesbezÃ¼glich noch idealer. Hebt man die Bohrlehre an der Muffe 22 haltend auf, so verschiebt sich die Grundplatte 1 mit der fest damit verbundenen HÃ¼lse 21, bezÃ¼glich der Muffe 22 nach unten und das Vakuumabbauventil, bestehend aus den genannten Radialbohrungen, ist geÃ¶ffnet. WÃ¤hrend dem Ausrichten der Bohrlehre auf die angezeichnete Markierung hÃ¤lt man die Muffe 22 in einer mindestens annÃ¤hernd horizontalen Lage, so dass diese sich nicht relativ zur HÃ¼lse 21 verschiebt. Erst wenn die Bohrlehre exakt auf die Markierung ausgerichtet ist, wird man vÃ¶llig natÃ¼rlich die Bohrlehre zur Wand drÃ¼cken und die Muffe 22 in die untere Schliessstellung verschieben, worauf sich das Vakuum in der Vakuumkammer 5 aufbaut. Position. Although this still creates a slight negative pressure in the vacuum chamber 5, it is so low that the drilling jig can still be easily moved on the wall. If the desired drill bushing with the correct internal dimensions is exactly above the marked mark, the vacuum release valve 13 is closed and the drilling jig is sucked onto the wall. Since each stone or concrete wall has an uneven surface and both a stone and concrete wall has a certain porosity, a more or less large leak occurs. It is therefore essential that the vacuum pump remains in operation during the entire period of use of the drilling jig in order to compensate for the leakage that occurs. In the embodiment according to FIGS. 1 to 3, the vacuum reduction valve 13 is closed by letting go of the spring plate 14, which was previously pulled upwards. The embodiment according to FIGS. 4 and 5 is even more ideal in this regard. If you lift the drilling jig on the sleeve 22, the base plate 1 with the sleeve 21 firmly connected to it moves downward with respect to the sleeve 22 and the vacuum release valve, consisting of the radial bores mentioned, is open. During the alignment of the drilling jig with the marked marking, the sleeve 22 is held in an at least approximately horizontal position so that it does not move relative to the sleeve 21. Only when the drilling jig is exactly aligned with the marking, will the drilling jig be pressed naturally against the wall and the sleeve 22 shifted into the lower closed position, whereupon the vacuum in the vacuum chamber 5 builds up.

FÃ¼r das einwandfreie Funktionieren der Bohrlehre spielt die umlaufende Dichtung 8 eine eminente Rolle. Eine bevorzugte Ausgestaltungsform einer solchen Dichtung ist in der Fig. 6 dargestellt. Es handelt sich hierbei um eine formgesschÃ¤umte Gummidichtung. Da sie in einer Form geschÃ¤umt wurde, ist sie an der AussenflÃ¤che vollkommen geschlossenporig, beziehungsweise porenfrei. Das Innere der Gummidichtung ist jedoch stark von Blasen durchsetzt und bildet so eine offenporige Struktur. Dies ergibt eine besonders stark kompromierba-re, weiche Dichtung. Um die Dichtigkeit insbesondere auf strukturverputzten WÃ¤nden zu verbessern, schneidet man die verdichtete AussenflÃ¤che der Gummidichtung, welche im montierten Zustand auf die Wand zum Anliegen kommt, ab. Nun ist die, an die Wand zukommende FlÃ¤che der Dichtung offenporig. Dies bewirkt, dass die Dichtung sich noch besser der OberflÃ¤che einer strukturierten Wand anpassen kann. The circumferential seal 8 plays an eminent role for the proper functioning of the drilling jig. A preferred embodiment of such a seal is shown in FIG. 6. It is a molded rubber seal. Since it was foamed in a mold, it is completely closed-pore or non-porous on the outer surface. However, the interior of the rubber seal is heavily interspersed with bubbles and thus forms an open-pore structure. This results in a particularly highly compressible, soft seal. In order to improve the tightness, in particular on structurally plastered walls, one cuts off the compressed outer surface of the rubber seal, which comes into contact with the wall in the assembled state. Now the surface of the seal coming to the wall is open-pored. This means that the seal can adapt even better to the surface of a structured wall.

Gerade bei grossen BohrlÃ¶chern ist die exakte Ausrichtung der Bohrbuchse 10 auf eine der Wand aufgezeichneten Markierung von blossem Auge oftmals nicht ganz einfach. Um dies zu verbessern, arbeitet man vorteilhafterweise mit einer in die Bohrbuchse 10 einlegbare und herausnehmbare Zentriervorrichtung. Dies kann beispielsweise eine in die Bohrbuchse passende HÃ¼lse mit einem Fadenkreuz sein, oder wie in Fig. 7 dargestellt, ein in Especially in the case of large boreholes, the exact alignment of the drill bushing 10 with a marking recorded on the wall is often not quite easy with the naked eye. In order to improve this, one advantageously works with a centering device which can be inserted and removed in the drill bushing 10. This can be, for example, a sleeve with a crosshair that fits into the drill bushing, or, as shown in FIG. 7, an in

5 5

10 10th

15 15

20 20th

25 25th

30 30th

35 35

40 40

45 45

50 50

55 55

60 60

65 65

3 3rd

5 5

CH 683 677 A5 CH 683 677 A5

6 6

die HÃ¼lse einlegbarer Zylindersektor. Die Bohrbuchse 10 hat im wesentlichen die Form eines zylindrischen Rohrabschnittes mit einem einseitig endstÃ¤ndigen nach aussen vorstehenden Flansch 31. Die zur Wand gerichteten ringfÃ¶rmige FlÃ¤che des Flansches 31 ist im Ã¤usseren Bereich zum Zentrum hin, angefast. Um die BohrÃ¶ffnung 32 verbleibt eine plane, ringfÃ¶rmige AndrÃ¼ckflÃ¤che 33. Der spezifische Druck, mit dem die AndrÃ¼ckflÃ¤che 33 an die Wand gepresst wird, ist relativ hoch. Hierdurch wird vermieden, dass das Bohrloch wÃ¤hrend des Bohrvorganges ausbricht. the sleeve insertable cylinder sector. The drill sleeve 10 has essentially the shape of a cylindrical tube section with a flange 31 projecting outwardly at one end and the annular surface of the flange 31 facing the wall is chamfered in the outer region towards the center. A flat, annular pressing surface 33 remains around the drilling opening 32. The specific pressure with which the pressing surface 33 is pressed against the wall is relatively high. This prevents the borehole from breaking out during the drilling process.

FÃ¼r die Montage von GerÃ¤ten an einer Wand, liefert der GerÃ¤tehersteller oftmals eine Bohrschablone mit. Um diese zu benutzen, benÃ¶tigt es, wie eingangs beschrieben, Ã¼blicherweise zwei Arbeiter. Mittels der erfindungsgemÃ¤ssen Bohrlehre lÃ¤sst sich diese Arbeit nun auch von einem einzelnen Arbeiter durchfÃ¼hren. Hierzu schraubt er zuerst an die Bohr-iehre einen Bohrschablonenhalter 40, wozu in der Bohrlehre die bereits angesprochenen SacklÃ¶cher 16 mit Innengewinde vorgesehen sind. Der Bohrschablonenhalter besteht aus einem Joch 41 und einer damit verbundenen Anpressplatte 42, die auf seiner Unterseite eventuell eine relativ harte Gummiplatte 43 aufweist. Die Verbindung zwischen Joch 41 und Anpressplatte 42 sollte vorzugsweise allseitig schwenkbeweglich sein, damit sich die Anpressplatte an eventuelle Unebenheiten der Wand anpassen kann. In der Zeichnung ist dies schematisch als Kugelgelenkverbindung 44 dargestellt. Die Arbeitsweise der Bohrlehre mit ergÃ¤nztem Bohrschablonenhalter 40 ist nun wiederum Ã¤usserst einfach. Der Arbeiter hÃ¤lt mit der einen Hand die Bohrschablone an den gewÃ¼nschten Ort, wÃ¤hrend er mit der anderen Hand die Bohrlehre an die Wand drÃ¼ckt, wobei er lediglich darauf achten muss, dass die Anpressplatte 42 zwar auf der Bohrschablone aufliegt, jedoch die BohrlÃ¶cher in der Schablone nicht abdeckt. The device manufacturer often provides a drilling template for mounting devices on a wall. In order to use these, it usually requires two workers, as described at the beginning. By means of the drilling jig according to the invention, this work can now also be carried out by a single worker. For this purpose, he first screws a drilling template holder 40 to the drilling jig, for which purpose the blind holes 16 with internal thread already mentioned are provided in the drilling jig. The drilling template holder consists of a yoke 41 and a pressure plate 42 connected to it, which may have a relatively hard rubber plate 43 on its underside. The connection between the yoke 41 and the pressure plate 42 should preferably be pivotable on all sides, so that the pressure plate can adapt to any unevenness in the wall. In the drawing, this is shown schematically as a ball joint connection 44. The operating principle of the drilling jig with a supplemented drilling template holder 40 is again extremely simple. The worker holds the drilling template at the desired location with one hand and presses the drilling jig against the wall with the other hand, only having to make sure that the pressure plate 42 lies on the drilling template, but the drill holes in the template not covering.

Bei der Dimensionierung der Bohrlehre ist darauf zu achten, dass die ringfÃ¶rmige AndrÃ¼ckflÃ¤che 33 der eingesetzen Bohrbuchse 10, von unten her gesehen, gegenÃ¼ber der Unterkante des umlaufenden Steges 4 vorsteht, wÃ¤hrend die umlaufende Dichtung 8 in unkomprimiertem Zustand wiederum Ã¼ber dem Niveau, in welchem die ringfÃ¶rmige AndrÃ¼ckflÃ¤che 33 der Bohrbuchse 10 liegt, vorsteht. Hierdurch wird gewÃ¤hrleistet, dass bei Erzeugung eines Vakuums in der Vakuumkammer 5 zuerst die umlaufende Dichtung 8 komprimiert wird, bis die AndrÃ¼ckflÃ¤che, beziehungsweise AndrÃ¼ckflÃ¤chen 33 der Bohrbuchse, beziehungsweise Bohrbuchsen 10 auf der Wand anliegen, ohne dass die Grundplatte, beziehungsweise dessen umlaufender Steg 4 auf der Wand anliegt. When dimensioning the drilling jig, care must be taken that the annular pressing surface 33 of the inserted drilling bush 10, viewed from below, protrudes from the lower edge of the circumferential web 4, while the circumferential seal 8 in the uncompressed state again above the level at which the annular pressure surface 33 of the drill bush 10 is located, protrudes. This ensures that when a vacuum is created in the vacuum chamber 5, the circumferential seal 8 is first compressed until the pressure surface or pressure surfaces 33 of the drill bushing or drill bushings 10 rest on the wall without the base plate or its circumferential web 4 resting on against the wall.

## Classifications

- B25H1/0064

---

Generated by IPtorch. Verify legal conclusions against the official publication.
