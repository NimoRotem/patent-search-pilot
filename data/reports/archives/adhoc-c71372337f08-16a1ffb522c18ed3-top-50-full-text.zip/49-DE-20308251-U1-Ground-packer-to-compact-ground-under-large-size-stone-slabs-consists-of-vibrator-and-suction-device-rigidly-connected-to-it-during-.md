# 49. Ground packer to compact ground under large-size stone slabs consists of vibrator and suction device rigidly connected to it during vibration

- **Archive rank:** 49 of 50
- **Publication:** [DE-20308251-U1](https://patents.google.com/patent/DE20308251U1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/027675464/publication/DE20308251U1?q=pn%3DDE20308251U1)
- **Publication date:** 2003-07-31
- **Filing date:** 2003-05-23
- **Earliest priority:** 2003-05-23
- **Family:** 27675464
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** SCHWAB HARRY

## Abstract

The machine has a vibrator (13,14), and a suction device (8) rigidly connected to the vibrator, when this is located on the slab surface, during at least part of the vibration process. The vibrator is fastened to a suction plate (10). This has a suction surface with peripheral sealing lips (12) on the underside and is connected to the suction device via suction pipes (11). A rubber-elastic material layer (7) is located under the suction plate. Suction device and vibrator are each located in a carrier frame (1,2), and these can be connected simply for transport.

## Sketches and drawings

_No digitized sketch link was returned._

## Claims

### Claim 1 (independent)

Vorrichtung zum Verdichten des Untergrunds unter großformatigen Steinplatten mit einer Rütteleinrichtung, gekennzeichnet durch eine Saugeinrichtung (8), mittels der die Rütteleinrichtung (13, 14) auf der Steinoberfläche zumindest während des Rüttelns starr verbindbar ist. 1. Device for compacting the subsoil under large-format stone slabs with a vibrating device, characterized by a suction device ( 8 ) by means of which the vibrating device ( 13 , 14 ) can be rigidly connected to the stone surface at least during the vibrating.

### Claim 2

Vorrichtung nach Anspruch 1, dadurch gekennzeichnet, dass die Rütteleinrichtung (13, 14) auf einer Saugplatte (10) befestigt ist, die auf der Unterseite mindestens eine Saugfläche mit die Saugfläche am Umfang begrenzenden Dichtlippen (12) aufweist und mit der Saugeinrichtung (8) über entsprechende Saugleitungen (11) verbunden ist. 2. Device according to claim 1, characterized in that the vibrating device ( 13 , 14 ) is fastened to a suction plate ( 10 ) which has on the underside at least one suction surface with sealing lips ( 12 ) delimiting the suction surface at the circumference and is connected to the suction device ( 8 ) via corresponding suction lines ( 11 ).

### Claim 3

Vorrichtung nach Anspruch 1 oder 2, dadurch gekennzeichnet, dass zumindest die Saugeinrichtung (8) elastisch mit der Rütteleinrichtung (13, 14) in einer gemeinsamen Halterung gekoppelt ist. 3. Device according to claim 1 or 2, characterized in that at least the suction device ( 8 ) is elastically coupled to the vibrating device ( 13 , 14 ) in a common holder.

### Claim 4

Vorrichtung nach Anspruch 1 oder 2, dadurch gekennzeichnet, dass die Saugeinrichtung (8) in einem ersten Tragrahmen (1) und die Rütteleinrichtung in einem zweiten Tragrahmen (2) angeordnet sind, wobei die Tragrahmen (1, 2) für den Transport miteinander verbindbar sind. 4. Device according to claim 1 or 2, characterized in that the suction device ( 8 ) is arranged in a first support frame ( 1 ) and the vibrating device is arranged in a second support frame ( 2 ), wherein the support frames ( 1 , 2 ) can be connected to one another for transport.

### Claim 5

Vorrichtung nach Anspruch 4, dadurch gekennzeichnet, dass der erste Tragrahmen (1) eine oder mehrere Ösen (6) zur Befestigung an einer Tragvorrichtung aufweist und mit dem zweiten Tragrahmen (2) über Seile (5) für eine elastische Kopplung verbunden ist. 5. Device according to claim 4, characterized in that the first support frame ( 1 ) has one or more eyelets ( 6 ) for fastening to a support device and is connected to the second support frame ( 2 ) via cables ( 5 ) for an elastic coupling.

### Claim 6

Vorrichtung nach einem der vorangegangenen Ansprüche, dadurch gekennzeichnet, dass die Rütteleinrichtung (13, 14) in vertikaler Richtung vibriert. 6. Device according to one of the preceding claims, characterized in that the vibrating device ( 13 , 14 ) vibrates in the vertical direction.

### Claim 7

Vorrichtung nach einem der vorangegangenen Ansprüche, dadurch gekennzeichnet, dass unter der Saugplatte (10) eine Noppenschicht (7) aus einem gummielastischen Material angeordnet ist. 7. Device according to one of the preceding claims, characterized in that a nub layer ( 7 ) made of a rubber-elastic material is arranged under the suction plate ( 10 ).

## Full description

FIXED CONSTRUCTIONSCONSTRUCTION OF ROADS, RAILWAYS, OR BRIDGESCONSTRUCTION OF, OR SURFACES FOR, ROADS, SPORTS GROUNDS, OR THE LIKE; MACHINES OR AUXILIARY TOOLS FOR CONSTRUCTION OR REPAIRMachines, tools or auxiliary devices for preparing or distributing paving materials, for working the placed materials, or for forming, consolidating, or finishing the pavingApparatus for laying individual preformed surfacing elements, e.g. kerbstonesApparatus for laying individual preformed surfacing elements, e.g. kerbstones using suction devicesFIXED CONSTRUCTIONSCONSTRUCTION OF ROADS, RAILWAYS, OR BRIDGESCONSTRUCTION OF, OR SURFACES FOR, ROADS, SPORTS GROUNDS, OR THE LIKE; MACHINES OR AUXILIARY TOOLS FOR CONSTRUCTION OR REPAIRMachines, tools or auxiliary devices for preparing or distributing paving materials, for working the placed materials, or for forming, consolidating, or finishing the pavingMachines, tools or auxiliary devices for preparing or distributing paving materials, for working the placed materials, or for forming, consolidating, or finishing the paving for consolidating or finishing laid-down unset materialsTamping or vibrating apparatus other than rollers ; Devices for ramming individual paving elementsPower-driven rammers or tampers, e.g. air-hammer impacted shoes for ramming stone-sett paving; Hand-actuated ramming or tamping machines, e.g. tampers with manually hoisted dropping weightPower-driven rammers or tampers, e.g. air-hammer impacted shoes for ramming stone-sett paving; Hand-actuated ramming or tamping machines, e.g. tampers with manually hoisted dropping weight with means specifically for generating vibrations, e.g. vibrating plate compactors, immersion vibratorsFIXED CONSTRUCTIONSHYDRAULIC ENGINEERING; FOUNDATIONS; SOIL SHIFTINGFOUNDATIONS; EXCAVATIONS; EMBANKMENTS; UNDERGROUND OR UNDERWATER STRUCTURESImproving or preserving soil or rock, e.g. preserving permafrost soilImproving by compactingImproving by compacting by tamping or vibrating, e.g. with auxiliary watering of the soilVibrating apparatus operating with systems involving rotary unbalanced masses

Description

Translated from German

Harry Schwab, 23. Mai 2003Harry Schwab, May 23, 2003

71083 Herrenberg K/ju71083 Herrenberg K/ju

750/01

5750/01

5

Vorrichtung zum Verdichten von UntergrundDevice for compacting subsoil

Beschreibung

10 Description

10

Die vorliegende Erfindung betrifft eine Vorrichtung zum Verdichten des Untergrunds unter groÃformatigen Steinplatten mit einer RÃ¼tteleinrichtung.The present invention relates to a device for compacting the subsoil beneath large-format stone slabs using a vibrating device.

RÃ¼tteleinrichtungen zum Verdichten von BodenbelÃ¤gen sind allgemein bekannt und werden insbesondere bei Pflastersteinen eingesetzt, um den fertigen Belag, der auf ein geglÃ¤ttetes Splittbett gelegt wurde, festzurÃ¼tteln und dabei auch den Untergrund soweit wie mÃ¶glich zu verdichten.Vibrating devices for compacting floor coverings are well known and are used in particular for paving stones in order to firmly vibrate the finished covering, which has been laid on a smoothed bed of gravel, and in doing so to compact the subsoil as much as possible.

Bei groÃformatigen Steinplatten, ab ca. 50 cm KantenlÃ¤nge und einer Dicke ab 8 cm sind die bekannten RÃ¼ttelmaschinen nicht geeignet, da aufgrund der groÃen Masse der Platten der RÃ¼ttelvorgang sich auf die Platte kaum und auf den Untergrund Ã¼berhaupt nicht auswirkt. Dies bedeutet, dass groÃformatige Platten, wie sie insbesondere im stÃ¤dtebaulichen Bereich eingesetzt werden, und beispielsweise eine FlÃ¤che von Ã¼ber 100 cm in der LÃ¤nge und Ã¼ber 100 cm in der Breite bei einer Dicke von bis zu 20 cm der Untergrund Ã¼berhaupt nicht verdichtet werden kÃ¶nnen. In der Praxis fÃ¼hrt dies dann leicht dazu, dass durch darÃ¼ber fahrende Fahrzeuge, insbesondere noch wÃ¤hrend den Verlegearbeiten, die Steinplatten im Randbereich belastet werden und dadurch das darunterFor large-format stone slabs with an edge length of approx. 50 cm and a thickness of 8 cm or more, the known vibrating machines are not suitable, as the large mass of the slabs means that the vibrating process has little effect on the slab and no effect at all on the subsoil. This means that large-format slabs, such as those used in urban development in particular, and for example an area of over 100 cm in length and over 100 cm in width with a thickness of up to 20 cm, cannot compact the subsoil at all. In practice, this easily leads to vehicles driving over them, especially during laying work, putting strain on the stone slabs in the edge area, thereby damaging the subsoil underneath.

befindliche Splittbett geringfÃ¼gig verschoben wird. Dadurch kippen die Platten beim DarÃ¼berfahren von Fahrzeugen leicht, was sich auch durch GerÃ¤usche bemerkbar macht. Wenngleich der Kippvorgang und die dabei entstehenden unterschiedlichen HÃ¶hen auch zwischen den einzelnen Steinplatten unter UmstÃ¤nden nur im Millimeterbereich liegen, fÃ¼hrt dies zu Problemen bei der Abnahme des Bodenbelags durch den Auftraggeber. Nach allgemeiner Auffassung in den Fachkreisen ist diesem Problem jedoch nur sehr schwer beizukommen, da ein RÃ¼tteln des Untergrundes unter derartig groÃen bereits verlegten Steinplatten nicht mÃ¶glich ist.The existing bed of gravel is slightly displaced. This causes the slabs to tip slightly when vehicles drive over them, which is also noticeable through noise. Even though the tipping process and the resulting differences in height between the individual stone slabs may only be in the millimeter range, this leads to problems when the client accepts the floor covering. However, the general opinion among experts is that this problem is very difficult to solve, as it is not possible to vibrate the subsoil under such large stone slabs that have already been laid.

Der vorliegenden Erfindung liegt daher die Aufgabe zugrunde, eine MÃ¶glichkeit vorzuschlagen, mit der auch das RÃ¼tteln des Untergrundes unter groÃformatigen Steinplatten mÃ¶glich ist.The present invention is therefore based on the object of proposing a possibility with which the vibration of the subsoil beneath large-format stone slabs is also possible.

Diese Aufgabe wird erfindungsgemÃ¤Ã durch eine Vorrichtung mit den Merkmalen des Hauptanspruchs gelÃ¶st. Weitere vorteilhafte Ausgestaltungen sind den UnteransprÃ¼chen zu entnehmen.This object is achieved according to the invention by a device having the features of the main claim. Further advantageous embodiments can be found in the subclaims.

GemÃ¤Ã der Erfindung weist die Vorrichtung neben einer RÃ¼tteleinrichtung auch eine Saugeinrichtung auf, mittels der die RÃ¼tteleinrichtung auf der SteinoberflÃ¤che zumindest wÃ¤hrend des RÃ¼tteins starr verbindbar ist. Dadurch wird die an sich fÃ¼r das RÃ¼tteln zu trÃ¤ge Masse als RÃ¼ttelmasse verwendet und mittels dieser RÃ¼ttelmasse (der Steinplatte) der Untergrund so weit mÃ¶glich verdichtet. Dies kann direkt nach dem Verlegen erfolgen, so dass die bisher bekannten Probleme Ã¼berhaupt nicht auftreten kÃ¶nnen. DarÃ¼ber hinaus konnten bereits verlegte und leicht kippende Platten dieses Formats nachtrÃ¤glich befestigt werden, indem der darunter befindliche Untergrund mittels einer derartigen Vorrichtung gerÃ¼ttelt wurde.According to the invention, the device has a suction device in addition to a vibrating device, by means of which the vibrating device can be rigidly connected to the stone surface, at least during the vibrating process. This means that the mass that is too inert for vibrating is used as a vibrating mass and the subsoil is compacted as much as possible using this vibrating mass (the stone slab). This can be done directly after laying, so that the previously known problems cannot arise at all. In addition, slabs of this format that have already been laid and are slightly tilting can be subsequently secured by vibrating the subsoil underneath using such a device.

GemÃ¤Ã einer bevorzugten Ausbildung der Erfindung ist die RÃ¼tteleinrichtung auf einer Saugplatte befestigt, die auf der Unterseite mindestens eine SaugflÃ¤che mit die SaugflÃ¤che am Unfang begrenzenden Dichtlippen aufweist und mit derAccording to a preferred embodiment of the invention, the vibrating device is mounted on a suction plate which has at least one suction surface on the underside with sealing lips delimiting the suction surface at the periphery and with which

Saugeinrichtung Ã¼ber entsprechende Saugleitungen verbunden ist. Mit der SaugflÃ¤che wird die Haftkraft festgelegt, die im Hinblick auf die verwendete RÃ¼tteleinrichtung und auf die Masse der groÃformatigen Steinplatten notwendig ist, damit das Beschleunigungsmoment der RÃ¼tteleinrichtung die Vorrichtung nicht von der Steinplatte lÃ¶st. Pro Steinplatte ist eine SaugflÃ¤che erforderlich, damit die umlaufenden Dichtlippen ausreichend abdichten kÃ¶nnen. GrundsÃ¤tzlich ist es jedoch mÃ¶glich, eine SaugflÃ¤che in mehrere kleinere SaugflÃ¤chen zu unterteilen, die einzelne den Umfang begrenzende Dichtlippen aufweisen und jeweils Ã¼ber entsprechende Saugleitungen mit der Saugeinrichtung verbunden sind. Damit kÃ¶nnen mehrere kleinere groÃformatige Steinplatten gleichzeitig gerÃ¼ttelt werden.Suction device is connected via appropriate suction lines. The suction surface determines the adhesive force that is necessary with regard to the vibrating device used and the mass of the large-format stone slabs so that the acceleration moment of the vibrating device does not detach the device from the stone slab. One suction surface is required per stone slab so that the circumferential sealing lips can seal sufficiently. In principle, however, it is possible to divide a suction surface into several smaller suction surfaces that have individual sealing lips that limit the circumference and are each connected to the suction device via appropriate suction lines. This means that several smaller, large-format stone slabs can be vibrated at the same time.

Da in der Regel die Saugkraft gleichzeitig ausreicht, auch die Steinplatten anzuheben, bietet die Vorrichtung den groÃen Vorteil, dass sie zuerst zum Anheben, Positionieren und Ablegen der Steinplatten und dann anschlieÃend gleich zum RÃ¼tteln verwendet werden kann. Durch die Unterteilung der SaugflÃ¤chen kann dann beispielsweise eine Palettenebene von Steinplatten auf einmal angehoben, verlegt und gerÃ¼ttelt werden. Die Beschleunigung der RÃ¼tteleinrichtung muss auf die Masse der Steinplatten abgestimmt und ausreichend sein, um die Steinplatte in die gewÃ¼nschten Bewegung zu versetzen.Since the suction power is usually sufficient to lift the stone slabs at the same time, the device offers the great advantage that it can be used first to lift, position and lay down the stone slabs and then immediately afterwards to vibrate them. By dividing the suction surfaces, for example, a pallet level of stone slabs can be lifted, laid and vibrated at once. The acceleration of the vibrating device must be matched to the mass of the stone slabs and be sufficient to set the stone slab in the desired movement.

GemÃ¤Ã einer bevorzugten Ausbildung der Erfindung ist zumindest die Saugeinrichtung elastisch mit der RÃ¼tteleinrichtung in einer gemeinsamen Halterung gekoppelt. Die gemeinsame Halterung kann dabei beispielsweise ein Tragrahmen sein, in dessen oberen Bereich die Saugeinrichtung und entsprechende Steuereinrichtungen angeordnet sind. Der obere Bereich kann Ã¼ber schwingungsentkoppelnde Elemente mit dem unteren Bereich der Halterung verbunden sein indem sich die RÃ¼tteleinrichtung befindet. Damit wird sichergestellt, dass der obere Bereich nicht den permanenten RÃ¼ttelbewegungen ausgesetzt ist und infolgedessen leichter zerstÃ¶rt wird.According to a preferred embodiment of the invention, at least the suction device is elastically coupled to the vibrating device in a common holder. The common holder can be, for example, a support frame in the upper area of which the suction device and corresponding control devices are arranged. The upper area can be connected to the lower area of the holder in which the vibrating device is located via vibration-isolating elements. This ensures that the upper area is not exposed to permanent vibrating movements and is therefore more easily destroyed.

GemÃ¤Ã einer anderen Ausbildung ist die Saugeinrichtung in einem ersten Tragrahmen und die RÃ¼tteleinrichtung in einem zweiten Tragrahmen angeordnet, wobei die Tragrahmen fÃ¼r den Transport miteinander verbindbar sind. Dies macht die Vorrichtung besonders handlich, da damit ein kompaktes GerÃ¤t fÃ¼r den Transport zur VerfÃ¼gung gestellt wird. FÃ¼r den eigentlichen RÃ¼ttelvorgang weist gemÃ¤Ã einer weiteren bevorzugten Ausbildung der erste Tragrahmen eine Ãse zur Befestigung an einer Tragvorrichtung, beispielsweise einem Kran, auf. Des weiteren ist der erste Tragrahmen mit dem zweiten Tragrahmen Ã¼ber Stahlseile oder anderer geeignete Mittel fÃ¼r eine elastische Kopplung verbunden. Damit wird der erste Tragrahmen durch Anheben mittels eines Kranes von dem zweiten rÃ¼ttelnden Tragrahmen entkoppelt werden. In diese Anordnung kann die Vorrichtung auch gleichzeitig benutzt, um die Steinplatten zu transportieren und zu verlegen.According to another embodiment, the suction device is arranged in a first support frame and the vibrating device in a second support frame, whereby the support frames can be connected to one another for transport. This makes the device particularly handy, as it provides a compact device for transport. For the actual vibrating process, according to a further preferred embodiment, the first support frame has an eyelet for attachment to a support device, for example a crane. Furthermore, the first support frame is connected to the second support frame via steel cables or other suitable means for an elastic coupling. The first support frame can thus be decoupled from the second vibrating support frame by lifting it using a crane. In this arrangement, the device can also be used simultaneously to transport and lay the stone slabs.

Ãblicherweise wird die RÃ¼tteleinrichtung einen oder mehrere handelsÃ¼bliche RÃ¼ttler aufweisen, mit denen der RÃ¼ttelvorgang durchgefÃ¼hrt wird. Diese handelsÃ¼blichen GerÃ¤te ermÃ¶glichen auch unterschiedliche Hubamplituden, mÃ¶glicherweise auch unterschiedliche RÃ¼ttelbewegungen in einem GerÃ¤t. Durch entsprechende Montage der RÃ¼ttler ist es bekannt, die RÃ¼ttelrichtung zu beeinflussen. So fÃ¼hrt ein RÃ¼ttler mit horizontaler Achse eine Vertikalbewegung mit gleichzeitiger VorwÃ¤rtsbewegung und ein RÃ¼ttler mit vertikaler Achse eine horizontale Kreisbewegung aus. FÃ¼r eine ausschlieÃliche vertikale Bewegung werden entweder zwei gleiche gegenlÃ¤ufige RÃ¼ttler mit horizontaler Achse oder ein RÃ¼ttler mit zwei internen gegenlÃ¤ufigen Achsen verwendet.The vibrating device will usually have one or more commercially available vibrators with which the vibrating process is carried out. These commercially available devices also allow different stroke amplitudes, and possibly different vibrating movements in one device. By mounting the vibrators accordingly, it is known that the direction of vibration can be influenced. For example, a vibrator with a horizontal axis performs a vertical movement with simultaneous forward movement, and a vibrator with a vertical axis performs a horizontal circular movement. For an exclusively vertical movement, either two identical counter-rotating vibrators with a horizontal axis or a vibrator with two internal counter-rotating axes are used.

Unterhalb der Saugplatte befindet sich vorzugsweise eine Schicht aus einem gummielastischen Material, die einzelnen Noppen oder andere Erhebungen aufweist. Eine derartige Schicht, beispielsweise in Form einer Gummimatte, hat sich hinsichtlich der zu erzielenden Saugwirkung bewÃ¤hrt. DarÃ¼ber hinaus wird dadurch auch BeschÃ¤digungen der Steinplatte vorgebeugt.Below the suction plate there is preferably a layer of a rubber-elastic material that has individual knobs or other elevations. Such a layer, for example in the form of a rubber mat, has proven to be effective in terms of the suction effect that can be achieved. In addition, this also prevents damage to the stone slab.

• Â·Â·

. t . t

Mit der erfindungsgemÃ¤Ã ausgebildeten Vorrichtung ist es somit mÃ¶glich, direkt nach dem Verlegen zu RÃ¼tteln, so dass eine ungleichmÃ¤Ãige und unkontrollierte Verdichtung durch Befahren nicht mehr mÃ¶glich ist. Des Weiteren kÃ¶nnen unkontrollierte Verdichtungen bei groÃformatigen Steinplatten nachtrÃ¤glich beseitigt werden.With the device designed according to the invention, it is thus possible to vibrate directly after laying, so that uneven and uncontrolled compaction by driving over is no longer possible. Furthermore, uncontrolled compaction in large-format stone slabs can be subsequently eliminated.

VerfahrensmÃ¤Ãig erfolgt das Verlegen von groÃformatigen Steinplatten, wobei die Steinplatten auf einem abgezogenen, ebenen Splittbett aufgelegt werden derart, dass die Steinplatten direkt nach dem Auflegen mit einer RÃ¼tteleinrichtung starr verbunden und mittels dieser gerÃ¼ttelt werden. Vorteilhafterweise wird die RÃ¼tteleinrichtung an die Steinplatten angesaugt. Eine weitere verfahrensmÃ¤Ãige MÃ¶glichkeit besteht darin, dass die Steinplatten mittels der RÃ¼tteleinrichtung an die Verlegestelle gebracht werden sowie die MÃ¶glichkeit, dass mehrere Steinplatten gleichzeitig mittels der RÃ¼tteleinrichtung verlegt und anschlieÃend mittels dieser gerÃ¼ttelt werden.The method used to lay large-format stone slabs involves laying the stone slabs on a level, level bed of gravel in such a way that the stone slabs are rigidly connected to a vibrating device immediately after they have been laid and are then vibrated using this. The vibrating device is advantageously sucked onto the stone slabs. Another method is to bring the stone slabs to the laying site using the vibrating device, and to lay several stone slabs at the same time using the vibrating device and then vibrate them using this.

Nachfolgend wird die Erfindung anhand eines AusfÃ¼hrungsbeispiels in Verbindung mit der einzigen Figur nÃ¤her erlÃ¤utert.The invention is explained in more detail below using an embodiment in conjunction with the single figure.

Die Figur zeigt eine schematische Schnittdarstellung einer Vorrichtung mit einem oberen ersten Tragrahmen 1 und einen unteren zweiten Tragrahmen 2. An dem Tragrahmen 1 befinden sich Ãsen 3 und an dem Tragrahmen 2 Ãsen 4, die Ã¼ber Stahlseile 5 miteinander verbunden sind. Am Tragrahmen 1 befinden sich oben ein oder mehrere AufhÃ¤ngeÃ¶sen 6, mit denen die gesamte Vorrichtung Ã¼ber Seile 15 (oder Ketten) und Haken 16 angehoben werden kann. Im Transportzustand werden der obere Tragrahmen 1 auf den unteren Tragrahmen 2 aufgesetzt und mittels einer Transportarretierung, beispielsweise einer nicht dargestellten Schraube, fixiert.The figure shows a schematic sectional view of a device with an upper first support frame 1 and a lower second support frame 2. There are eyelets 3 on the support frame 1 and eyelets 4 on the support frame 2, which are connected to one another via steel cables 5. At the top of the support frame 1 there are one or more suspension eyelets 6 with which the entire device can be lifted via cables 15 (or chains) and hooks 16. In the transport state, the upper support frame 1 is placed on the lower support frame 2 and fixed by means of a transport lock, for example a screw (not shown).

In dem oberen Tragrahmen 1 ist in diesem AusfÃ¼hrungsbeispiel die Saugeinrichtung 8 sowie eine Steuereinrichtung 9 angeordnet.In this embodiment, the suction device 8 and a control device 9 are arranged in the upper support frame 1.

Auf der Unterseite des unteren Tragrahmen 2 befindet sich eine Saugplatte 10, die Ã¼ber eine Saugleitung 11 mit der Saugeinrichtung 8 verbunden ist. Auf der Unterseite sind am Umfang der Saugplatte 10 Dichtlippen 12 angeordnet. Die Saugplatte 10 weist auÃerdem auf der Unterseite eine Noppenschicht 7 aus einem gummielastischen Material auf.On the underside of the lower support frame 2 there is a suction plate 10 which is connected to the suction device 8 via a suction line 11. On the underside, sealing lips 12 are arranged on the circumference of the suction plate 10. The suction plate 10 also has a dimpled layer 7 made of a rubber-elastic material on the underside.

In dem AusfÃ¼hrungsbeispiel werden zwei gegenlÃ¤ufige RÃ¼ttler 13, 14 eingesetzt, die mit horizontaler Achse fest auf der Saugplatte 10 fixiert sind.In the embodiment, two counter-rotating vibrators 13, 14 are used, which are firmly fixed to the suction plate 10 with a horizontal axis.

Mittels einer derartigen Einrichtung wurden Steinplatten mit ca. 500 kg Gewicht gerÃ¼ttelt und der Untergrund erfolgreich verdichtet. Die Dimensionierung der Saugeinrichtung 8 hinsichtlich der Saugleistung, der entsprechenden Saugplatte 10 sowie der RÃ¼ttler 13, 14 erfolgt entsprechend der zu rÃ¼ttelnden groÃformatigen Steinplatten.Using such a device, stone slabs weighing approximately 500 kg were vibrated and the subsoil was successfully compacted. The dimensions of the suction device 8 in terms of suction power, the corresponding suction plate 10 and the vibrators 13, 14 are determined according to the large-format stone slabs to be vibrated.

## Classifications

- E01C19/524
- E01C19/38
- E02D3/074

## Cited patent documents

- [DE-3634093-A1](https://patents.google.com/patent/DE3634093A1/en) — UNKNOWN
- [DE-4327663-A1](https://patents.google.com/patent/DE4327663A1/en) — UNKNOWN

---

Generated by IPtorch. Verify legal conclusions against the official publication.
