# 31. Vibrator

- **Archive rank:** 31 of 50
- **Publication:** [EP-0029999-A1](https://patents.google.com/patent/EP0029999A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/006087360/publication/EP0029999A1?q=pn%3DEP0029999A1)
- **Publication date:** 1981-06-10
- **Filing date:** 1980-11-25
- **Earliest priority:** 1979-12-01
- **Family:** 6087360
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** BECKER DENTAL LABOR GMBH

## Abstract

A vibrator with which granular or powderous material is riddled is provided on its underside with a hollow space (27) sealed off by a circumferential base strip (29), to which space a suction device (25) is connected. The suction device (25) is operated by the drive of the vibration device (21). The vibrator thus adheres to the surface (28) bearing it under its own suction force as soon as the vibration device (21) is activated. In this way, the vibrator is prevented from moving or wandering on the surface (28). &lt;IMAGE&gt;

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/EP-0029999-A1/000.png)

![Sketch 1 for EP-0029999-A1](https://nimo.iptorch.com/refdrawing/EP-0029999-A1/000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/ec/af/9f/b1758ad936fb8a/imgf0001.png)

![Sketch 2 for EP-0029999-A1](https://patentimages.storage.googleapis.com/ec/af/9f/b1758ad936fb8a/imgf0001.png)

## Claims

### Claim 1

1. Rüttler mit einer Vibrationsvorrichtung, einem von der Vibrationsvorrichtung angetriebenen Rütteltisch und einem die Vibrationsvorrichtung und den Rütteltisch tragenden Unterteile dadurch gekennzeichnet, daß das Unterteil (11) eine an seiner Unterseite geschlossen umlaufende Fußleiste (29) aufweist, die bei Auflage auf eine ebene Fläche (28) einen Hohlraum (27) abdichtend abschließt, und daß der Hohlraum (27) an eine Saugvorrichtung (25) angeschlossen ist, die in ihm einen Unterdruck erzeugt.

### Claim 2

2. Rüttler nach Anspruch 1, dadurch gekennzeichnet, daß die Vibrationsvorrichtung (21) einen pneumatischen Antrieb aufweist und ihr Abluftkanal (24) eine Venturidüse (25) enthält, deren Sauganschluß (26) mit dem Hohlraum (27) verbunden ist.

## Full description

HUMAN NECESSITIESMEDICAL OR VETERINARY SCIENCE; HYGIENEDENTISTRY; APPARATUS OR METHODS FOR ORAL OR DENTAL HYGIENEImpression cups, i.e. impression trays; Impression methodsSyringes or guns for injecting impression material; Mixing impression material for immediate usePERFORMING OPERATIONS; TRANSPORTINGGENERATING OR TRANSMITTING MECHANICAL VIBRATIONS IN GENERALMETHODS OR APPARATUS FOR GENERATING OR TRANSMITTING MECHANICAL VIBRATIONS OF INFRASONIC, SONIC, OR ULTRASONIC FREQUENCY, e.g. FOR PERFORMING MECHANICAL WORK IN GENERALMethods or apparatus for generating mechanical vibrations of infrasonic, sonic, or ultrasonic frequencyMethods or apparatus for generating mechanical vibrations of infrasonic, sonic, or ultrasonic frequency wherein the vibrator is actuated by pressure fluidMethods or apparatus for generating mechanical vibrations of infrasonic, sonic, or ultrasonic frequency wherein the vibrator is actuated by pressure fluid operating with rotary unbalanced masses

Description

Translated from German

Die Erfindung betrifft einen RÃ¼ttler mit einer Vibrationsvorrichtung, einem von der Vibrationsvorrichtung angetriebenen RÃ¼tteltisch und einem die Vibrationsvorrichtung und den RÃ¼tteltisch tragenden Unterteil.The invention relates to a vibrator with a vibrating device, a vibrating table driven by the vibrating device and a lower part carrying the vibrating device and the vibrating table.

In der Dentaltechnik werden RÃ¼ttler eingesetzt, um eine Gipsmasse blasen- und lunkerfrei in Formen einfÃ¼hren zu kÃ¶nnen, die fÃ¼r die Herstellung von Gipsmodellen verwendet werden. Die Form wird auf den RÃ¼tteltisch gelegt und durch diesen in Vibration versetzt. Das Gips wird mit Wasser ver= mischt, in flieÃfÃ¤higem Zustand in die Form eingegeben und verlÃ¤uft in dieser. Die Vibrationsvorrichtungen der bekannten RÃ¼ttler sind entweder mit Schwingmagneten oder mit Exzenterantrieben ausgestattet.In dental technology, vibrators are used in order to be able to insert a plaster mass without bubbles and voids into molds that are used for the production of plaster models. The mold is placed on the vibrating table and vibrated by it. The gypsum is mixed with water, poured into the mold in a flowable state and runs in it. The vibration devices of the known vibrators are either equipped with vibrating magnets or with eccentric drives.

Bei den bekannten RÃ¼ttlern besteht eine Schwierigkeit darin, zu verhindern, daÃ die GerÃ¤te wÃ¤hrend des Betriebes auf dem Arbeitstisch, auf den sie gestellt werden, wandern. Um eine ausreichende Standsicherheit zu erzeugen, werden die RÃ¼ttler mit schweren Platten im Unterteil versehen, so daÃ sie ein groÃes Gewicht erhalten und das Unterteil durch die Vibration nicht wesentlich beeinfluÃt wird. Das groÃe Gewicht hat aber Nachteile nicht nur bei der Fertigung der GerÃ¤te, sondern auch bei ihrer Benutzung, da das Umsetzen eines GerÃ¤tes einen erheblichen Kraftaufwand erfordert. AuÃerdem wird durch die zusÃ¤ztlichen Gewichte die Herstellung verteuert.A problem with the known vibrators is to prevent the devices from moving on the work table on which they are placed during operation. In order to create sufficient stability, the vibrators are provided with heavy plates in the lower part, so that they are heavy and the lower part is not significantly affected by the vibration. The great weight has disadvantages not only in the manufacture of the devices, but also in their use, since the implementation of a device requires considerable effort. In addition, the production is made more expensive by the additional weights.

Aufgabe der Erfindung ist es, einen RÃ¼ttler der eingangs genannten Art so auszubilden, daÃ er trotz eines relativ geringen Gewichtes eine hohe Standsicherheit auf einer Unterlage hat.The object of the invention is to design a vibrator of the type mentioned in such a way that it has a high level of stability on a base despite a relatively low weight.

Zur LÃ¶sung dieser Aufgabe ist erfindungsgemÃ¤Ã vorgesehen, daÃ das Unterteil eine an seiner Unterseite geschlossen umlaufende FuÃleiste aufweist, die bei Auflegen auf eine ebene FlÃ¤che einen Hohlraum abdichtend abschlieÃt,und daÃ der Hohlraum an eine Saugvorrichtung angeschlossen ist, die in ihm einen Unterdruck erzeugt.To achieve this object, it is provided according to the invention that the lower part has a skirting which is closed on its underside and which seals off a cavity when placed on a flat surface, and that the cavity is connected to a suction device which generates a vacuum in it.

Der erfindungsgemÃ¤Ãe RÃ¼ttler saugt sich infolge des Unterdrucks an einer Unterlage, z.B. der FlÃ¤che eines Arbeitstisches, fest, so daÃ er einen festen Stand erhÃ¤lt und nicht wandert. Der RÃ¼ttler kann daher relativ leichtgewichtig ausgefÃ¼hrt werden, weil seine Standsicherheit nicht durch Gewichte hervorgerufen wird, sondern durch Saugwirkung, die nur im eingeschalteten Zustand hervorgerufen wird.The vibrator according to the invention is sucked on a support, e.g. the surface of a worktable, so that it has a firm footing and does not move. The vibrator can therefore be made relatively light, because its stability is not caused by weights, but by suction, which is only caused when it is switched on.

Bei Verwendung eines Motorantriebs fÃ¼r die Vibrationsvorrichtung kann die Saugvorrichtung aus einem GeblÃ¤se bestehen, das mit der Motorwelle des Antriebs gekoppelt ist und aus dem Hohlraum unterhalb des Unterteiles die Luft absaugt und in die umgebende AtmosphÃ¤re leitet. Auch bei Verwendung anderer Antriebsvorrichtungen ist eine entsprechende Kopplung mit der Saugvorrichtung mÃ¶glich, so daÃ die Saugvorrichtung keinen separaten Antrieb benÃ¶tigt. Andererseits kann es bei einem RÃ¼ttler mit Schwingmagneten auch zweckmÃ¤Ãig sein, eine Saugvorrichtung mit separatem Antrieb vorzusehen.When using a motor drive for the vibration device, the suction device can consist of a blower which is coupled to the motor shaft of the drive and sucks the air out of the cavity below the lower part and guides it into the surrounding atmosphere. Even when using other drive devices a corresponding coupling with the suction device is possible, so that the suction device does not require a separate drive. On the other hand, it can also be expedient in the case of a vibrator with vibrating magnets to provide a suction device with a separate drive.

Schwingmagneten und Exzenterantriebe haben den Nachteil einer schlechten Regelbarkeit von Schwingfrequenz und Schwingungsamplitude. Es sind pneumatisch angetriebene RÃ¼ttler bekannt (US-PS 3 365 964), bei denen die Vibration durch eine Kugel verursacht wird, die durch einen Luftstrom in einem GehÃ¤use bewegt wird. Bei einem RÃ¼ttler mit pneumatisch angetriebener Vibrationsvorrichtung kann gemÃ¤Ã einer besonders vorteilhaften Weiterbildung der Erfindung der Abluftkanal eine VenturidÃ¼se enthalten, deren SauganschluÃ mit dem Hohlraum verbunden ist. In diesem Fall wird der Abluftstrom durch eine Strahlpumpe geleitet und zum Absaugen der Luft aus dem Hohlraum benutzt.. Der hierzu erforderliche technische Aufwand ist sehr gering, weil auÃer der VenturidÃ¼se und den entsprechenden Luftleitungen sowie der Randabdichtung des Unterteiles keine zusÃ¤tzlichen Bauteile benÃ¶tigt werden, und insbesondere keine Bauteile von aufwendiger Konstruktion oder komplizierter Gestalt.Vibrating magnets and eccentric drives have the disadvantage of poor controllability of the vibration frequency and vibration amplitude. Pneumatically driven vibrators are known (US Pat. No. 3,365,964), in which the vibration is caused by a ball which is moved by an air stream in a housing. In the case of a vibrator with a pneumatically driven vibration device, according to a particularly advantageous development of the invention, the exhaust air duct can contain a Venturi nozzle, the suction connection of which is connected to the cavity. In this case, the exhaust air flow is passed through a jet pump and used to extract the air from the cavity. The technical effort required for this is very low, because apart from the Venturi nozzle and the corresponding air lines and the edge seal of the lower part, no additional components are required, and in particular, no components of complex construction or complicated shape.

Im folgenden wird unter Bezugnahme auf die einzige Figur der Zeichnung ein bevorzugtes AusfÃ¼hrungsbeispiel der Erfindung nÃ¤her erlÃ¤utert.A preferred embodiment of the invention is explained in more detail below with reference to the single figure of the drawing.

In der Zeichnung ist schematisch ein LÃ¤ngsschnitt durch einen RÃ¼ttler mit pneumatischem Antrieb dargestellt.In the drawing, a longitudinal section through a vibrator with pneumatic drive is shown schematically.

Der abgebildete RÃ¼ttler 10 weist ein wannenfÃ¶rmiges Unterteil 11 mit ebener Unterseite 12 auf. Auf dem wannenfÃ¶rmigen Unterteil 11 ruhen mehrere elastische StÃ¼tzen 13, von denen in der Zeichnung nur eine dargestellt ist. Die elastischen StÃ¼tzen 13, die aus Gummi o.dgl. bestehen, sind an ihren unteren Enden an einem unteren Halter 14 und mit ihren oberen Enden an einem oberen Halter 15 befestigt. Der zylindrische Mittelteil dient jeweils als Federelement fÃ¼r die elastische Lagerung des RÃ¼tteltisches 16, an dessen Unterseite die obere Halterung 15 befestigt ist.The vibrator 10 shown has a trough-shaped lower part 11 with a flat underside 12. On the tubs shaped lower part 11 rest several elastic supports 1 3, of which only one is shown in the drawing. The elastic supports 13, or the like made of rubber. exist, are attached at their lower ends to a lower holder 14 and with their upper ends to an upper holder 15. The cylindrical middle part serves as a spring element for the elastic mounting of the vibrating table 16, on the underside of which the upper holder 15 is attached.

Der RÃ¼tteltisch 16 weist eine Mulde 17 auf, auf die zu rÃ¼ttelnden GegenstÃ¤nde gelegt werden. Die Mulde 17 ist von einem umlaufenden Wulst 18 umgeben, der in eine Seitenwand 19 Ã¼bergeht, welche schrÃ¤g nach auÃen geneigt ist und den Rand des schalenfÃ¶rmigen Unterteiles 11 Ã¼bergreift. Zwischen dem Rand des Unterteiles 11 und dem Ã¼bergreifenden Rand des RÃ¼tteltisches 16 befindet sich eine umlaufende Dichtleiste 20 aus elastischem Material. Auf diese Weise bilden der RÃ¼tteltisch 16 und das Unterteil 11 ein geschlossenes RÃ¼ttlergehÃ¤use, das schallgedÃ¤mpft und gegen Eindringen von Schmutz abgedichtet ist.The R Ã¼tteltisch 16 has a trough 17, are placed on the objects to be jogged. The trough 17 is surrounded by a circumferential bead 18 which merges into a side wall 19 which is inclined outwards and overlaps the edge of the shell-shaped lower part 11. A circumferential sealing strip 20 made of elastic material is located between the edge of the lower part 11 and the overlapping edge of the vibrating table 16. In this way, the vibrating table 16 and the lower part 11 form a closed vibrator housing, which is soundproofed and sealed against the ingress of dirt.

An der Unterseite des RÃ¼tteltisches 16 ist die Vibrationsvorrichtung 21 in Form eines bekannten pneumatisch angetriebenen Kugelvibrators befestigt. Die Druckluftversorgungsleitung 22 fÃ¼r die Vibrationsvorrichtung 21 enthÃ¤lt ein Schalt- und Regulierventil 23, das an eine (nicht dargestellte) Druckluftquelle angeschlossen wird. Der Abluftkanal 24 der Vibrationsvorrichtung 21 fÃ¼hrt in die NÃ¤he der Bodenplatte 12 des Unterteiles 11. Dort ist in den Abluftkanal eine VenturidÃ¼se 25 eingesetzt, deren SauganschluÃ 26 in einen unter der Bodenplatte 12 gebildeten Hohlraum 27 hineinfÃ¼hrt. Der Hohlraum 27 wird Ã¼ber einer TischflÃ¤che 28 o.dgl. dadurch gebildet,daÃ das Unterteil 11 an seiner Unterseite eine umlaufende FuÃleiste 29 aufweist, die nach unten vorsteht, so daÃ die Bodenplatte 12 sich im Abstand Ã¼ber der TischflÃ¤che 28 befindet. Die FuÃleiste 29 besteht aus einem elastischen iverkstoff, z.B. Gummi, der einen dichten AbschluÃ des Hohlraumes 27 gegenÃ¼ber der TischflÃ¤che 28 bewirkt. Der Hohlraum 27 wird also von der Bodenplatte 12 des Unterteiles 11, der Tischplatte 28 und der FuÃleiste 29 begrenzt. Die in ihm enthaltene Luft wird durch die VenturidÃ¼se 25 hindurch abgesaugt und Ã¼ber eine AuslaÃleitung 30 zusammen mit der Abluft der Vibrationsvorrichtung 21 in die AtmosphÃ¤re abgeleitet.On the underside of the vibrating table 16, the vibration device 21 is fastened in the form of a known pneumatically driven ball vibrator. The compressed air supply line 22 for the vibrating device 21 contains a switching and regulating valve 23 which is connected to a compressed air source (not shown). The exhaust air duct 24 of the vibrating device 21 leads into the vicinity of the base plate 12 of the lower part 11. A venturi nozzle 25 is inserted into the exhaust air duct, the suction connection 26 of which leads into a cavity 27 formed under the base plate 12. The cavity 27 will over a table surface 28 or the like. formed in that the lower part 11 has on its underside a circumferential skirting board 29 which projects downward, so that the base plate 12 is spaced above the table surface 28. The baseboard 29 consists of an elastic material, for example rubber, which causes the cavity 27 to be sealed against the table surface 28. The cavity 27 is thus delimited by the base plate 12 of the lower part 11, the table plate 28 and the baseboard 29. The air contained in it is sucked through the Venturi nozzle 25 and discharged via an outlet line 30 together with the exhaust air of the vibrating device 21 into the atmosphere.

Wenn der RÃ¼ttler in Betrieb ist, strÃ¶mt Druckluft durch die Versorgungsleitung 22 zur Vibrationsvorrichtung 21. Die Abluft der Vibrationsvorrichtung 21 wird Ã¼ber den Abluftkanal 24 und die VenturidÃ¼se 26 ins Freie geleitet. Dabei wird gleichzeitig Luft aus dem Hohlraum 27 angesaugt und mit abgefÃ¼hrt. In dem Hohlraum 27 entsteht also ein Unterdruck, wodurch sich das Unterteil 11 an der Tischplatte 28 festsaugt. Dadurch wird verhindert, daÃ der RÃ¼ttler 10 infolge der Vibrationsbewegung auf der TischflÃ¤che wandert.When the vibrator is in operation, compressed air flows through the supply line 22 to the vibrating device 21. The exhaust air from the vibrating device 21 is passed outside via the exhaust air duct 24 and the Venturi nozzle 26. At the same time, air is sucked in from the cavity 27 and removed with it. A vacuum is thus created in the cavity 27, as a result of which the lower part 11 is sucked onto the table top 28. This prevents the vibrator 10 from moving on the table surface as a result of the vibration movement.

## Classifications

- A61C9/0026
- B06B1/186

## Cited patent documents

- [BE-400752-A](https://patents.google.com/patent/BE400752A/en) — SEA
- [US-2749097-A](https://patents.google.com/patent/US2749097A/en) — SEA

---

Generated by IPtorch. Verify legal conclusions against the official publication.
