# 26. Paving device for mosaic tiles

- **Archive rank:** 26 of 50
- **Publication:** [CN-212613592-U](https://patents.google.com/patent/CN212613592U/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/074712624/publication/CN212613592U?q=pn%3DCN212613592U)
- **Publication date:** 2021-02-26
- **Filing date:** 2020-08-21
- **Earliest priority:** 2020-08-21
- **Family:** 74712624
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** Jinhua Wanfeng Tools Factory

## Abstract

The utility model is suitable for a tiling&#39;s technical field discloses a mosaic ceramic tile spread and paste device. The utility model provides a paving device of mosaic tiles, which comprises a sucker and a handle; the plurality of suckers are arranged on the same vacuumizing shell, and the suckers and the mosaic tiles are fixed and loosened by changing the gas quantity in the vacuumizing shell; and a handle is connected to the vacuumizing shell. Set up a plurality of sucking discs in the bottom of evacuation casing, every sucking disc corresponds each fritter ceramic tile on a mosaic ceramic tile, and when taking out the gas in the evacuation casing, the gas in the sucking disc also slowly reduces to adsorb every fritter ceramic tile on the sucking disc, can realize the transport and the shop of monoblock mosaic ceramic tile through the handle and paste. When the mosaic ceramic tile is paved, the whole mosaic ceramic tile can be kept relatively horizontal, and paving efficiency is higher.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-212613592-U/000.png)

![Sketch 1 for CN-212613592-U](https://nimo.iptorch.com/refdrawing/CN-212613592-U/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-212613592-U/001.png)

![Sketch 2 for CN-212613592-U](https://nimo.iptorch.com/refdrawing/CN-212613592-U/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/CN-212613592-U/002.png)

![Sketch 3 for CN-212613592-U](https://nimo.iptorch.com/refdrawing/CN-212613592-U/002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/CN-212613592-U/003.png)

![Sketch 4 for CN-212613592-U](https://nimo.iptorch.com/refdrawing/CN-212613592-U/003.png)

[Sketch 5](https://patentimages.storage.googleapis.com/58/3b/ef/c6c7392c03b5a4/200821112120.png)

![Sketch 5 for CN-212613592-U](https://patentimages.storage.googleapis.com/58/3b/ef/c6c7392c03b5a4/200821112120.png)

[Sketch 6](https://patentimages.storage.googleapis.com/e2/5d/ed/a5fb3e686a19be/200821112122.png)

![Sketch 6 for CN-212613592-U](https://patentimages.storage.googleapis.com/e2/5d/ed/a5fb3e686a19be/200821112122.png)

[Sketch 7](https://patentimages.storage.googleapis.com/65/ea/8b/25f8781a7670aa/200821112125.png)

![Sketch 7 for CN-212613592-U](https://patentimages.storage.googleapis.com/65/ea/8b/25f8781a7670aa/200821112125.png)

[Sketch 8](https://patentimages.storage.googleapis.com/17/a3/33/20eaa9f2d2732f/200821112127.png)

![Sketch 8 for CN-212613592-U](https://patentimages.storage.googleapis.com/17/a3/33/20eaa9f2d2732f/200821112127.png)

## Claims

### Claim 1 (independent)

A paving device for mosaic tiles comprises a sucker (1) and a handle (2); the method is characterized in that: the plurality of suckers (1) are arranged on the same vacuumizing shell (3), and the suckers (1) and the mosaic tiles are fixed and loosened by changing the gas amount in the vacuumizing shell (3); the vacuum-pumping shell (3) is connected with a handle (2).

### Claim 2

A mosaic tile paving apparatus according to claim 1, wherein: the vacuumizing shell (3) is connected with an air pump (4) to realize the air pumping function.

### Claim 3

A mosaic tile paving apparatus according to claim 2, wherein: the air pump (4) is powered by connecting a battery (5).

### Claim 4

A mosaic tile paving apparatus as claimed in claim 2 or 3, wherein: a switch (21) for controlling the starting and stopping of the air pump (4) is arranged on the handle (2).

### Claim 5

A mosaic tile paving apparatus as claimed in claim 1, 2 or 3, wherein: an air discharging assembly (6) is further arranged on the vacuumizing shell (3).

### Claim 6

A mosaic tile paving apparatus according to claim 5, wherein: the air bleeding assembly (6) comprises a one-way valve shaft (61) connected with the vacuum-pumping shell (3) and a button (62) for controlling the movement of the one-way valve shaft (61).

### Claim 7

A mosaic tile paving apparatus according to claim 6, wherein: the deflation component (6) also comprises a control rod (63) which is clamped on the one-way valve shaft (61) and controls the one-way valve shaft to move up and down, and a return spring (64) which is connected with one end of the control rod (63) far away from the one-way valve shaft (61).

### Claim 8

A mosaic tile paving apparatus according to claim 7, wherein: the control rod (63) comprises a clamping joint (631) used for clamping the one-way valve shaft (61), a rotating groove (632) extending from one side, far away from the one-way valve shaft (61), of the clamping joint (631), and a rotating arm (633) extending from one side, far away from the clamping joint (631), of the rotating groove (632); the rotating arm (633) is connected with the button (62) and the return spring (64).

### Claim 9

A mosaic tile paving apparatus according to claim 5, wherein: the air bleeding assembly (6) is partially disposed within the handle (2).

### Claim 10

A mosaic tile paving apparatus according to claim 3, wherein: a hollow box body (7) is arranged between the handle (2) and the vacuum-pumping shell body (3); the air pump (4) and the battery (5) are both arranged in the hollow box body (7).

## Full description

Description

Paving device for mosaic tiles

Technical Field

The utility model relates to a tile is spread and is pasted technical field, in particular to mosaic ceramic tile spread and paste device.

Background

The mosaic ceramic tile is a ceramic tile group formed by fixing a plurality of small ceramic tiles on a soft substrate, and is mainly used in swimming pools, bathrooms and fish tanks. At present, the mosaic tiles are paved by manual work, but the base plate is soft, so that the horizontal small tiles and the longitudinal small tiles in the same tile group are easy to undulate. When a mosaic ceramic tile is difficult to be paved, a large area of swimming pools, bathrooms and fish tanks can be paved.

SUMMERY OF THE UTILITY MODEL

An object of the utility model is to overcome above-mentioned prior art not enough, provide a shop of mosaic ceramic tile pastes device, through set up a plurality of sucking discs in the evacuation subassembly, it aims at solving among the prior art technical problem that the manual shop of mosaic ceramic tile pastes the device degree of difficulty is big, the inefficiency.

In order to realize the purpose, the utility model provides a paving device of mosaic tiles, which comprises a sucker and a handle; the plurality of suckers are arranged on the same vacuumizing shell, and the suckers and the mosaic tiles are fixed and loosened by changing the gas quantity in the vacuumizing shell; and a handle is connected to the vacuumizing shell. Set up a plurality of sucking discs in the bottom of evacuation casing, every sucking disc corresponds each fritter ceramic tile on a mosaic ceramic tile, and when taking out the gas in the evacuation casing, the gas in the sucking disc also slowly reduces to adsorb every fritter ceramic tile on the sucking disc, can realize the transport and the shop of monoblock mosaic ceramic tile and paste the device through the handle. When the paving device is used, the whole mosaic ceramic tile can be kept relatively horizontal, and the paving device is higher in efficiency.

Preferably, the vacuum-pumping housing is connected with a suction pump to realize the suction function. The air extraction efficiency is improved through the air extraction pump.

Preferably, the suction pump is powered by connecting a battery.

Preferably, a switch for controlling the starting and stopping of the air pump is arranged on the handle.

Preferably, an air bleed assembly is further provided on the evacuated housing.

Preferably, the air bleeding assembly comprises a one-way valve shaft connected with the vacuum-pumping shell and a button for controlling the movement of the one-way valve shaft. The one-way valve shaft is controlled by a button to realize the sealing and the air discharging of the vacuum pumping assembly.

Preferably, the deflation assembly further comprises a control rod clamped on the one-way valve shaft and controlling the one-way valve shaft to move up and down, and a return spring connected with one end of the control rod far away from the one-way valve shaft.

Preferably, the control rod comprises a clamping joint for clamping the one-way valve shaft, a rotating groove extending from one side of the clamping joint far away from the one-way valve shaft, and a rotating arm extending from one side of the rotating groove far away from the clamping joint; the rotating arm is connected with the button and the return spring. The return spring is propped against the rotating arm to enable the one-way shaft valve to be always propped against the vacuumizing assembly to realize sealing. The one-way valve shaft is lifted by pressing the rotating arm, so that air can enter the vacuumizing assembly, and the sucker and the mosaic tiles are loosened.

Preferably, the deflation assembly is partially disposed within the handle. The button of gassing subassembly exposes in the handle outside, and other parts are arranged in the handle, can reduce whole area, easy to assemble. The button and the switch are both arranged on the handle, so that the use is convenient.

Preferably, a hollow box body is arranged between the handle and the vacuumizing shell; the air pump and the battery are both arranged in the hollow box body. The area of the whole paving and pasting device is reduced, and the operation is convenient.

Preferably, the suction cup is a two-layer or multi-layer vacuum suction cup head. The folding distance is longer, so that the mosaic ceramic tiles can be tightly attached to the vacuum-pumping shell to be kept relatively horizontal.

Compared with the prior art, the utility model provides a pair of paving of mosaic ceramic tile pastes device's beneficial effect does: set up a plurality of sucking discs in the bottom of evacuation casing, every sucking disc corresponds each fritter ceramic tile on a mosaic ceramic tile, and when taking out the gas in the evacuation casing, the gas in the sucking disc also slowly reduces to adsorb every fritter ceramic tile on the sucking disc, can realize the transport and the shop of monoblock mosaic ceramic tile and paste the device through the handle. When the paving device is used, the whole mosaic ceramic tile can be kept relatively horizontal, and the paving device is higher in efficiency.

The features and advantages of the present invention will be described in detail by embodiments with reference to the accompanying drawings.

Drawings

Fig. 1 is a schematic structural view of a paving device for mosaic tiles according to an embodiment of the present invention.

Fig. 2 is an explosion structure diagram of a paving device for mosaic tiles according to an embodiment of the present invention.

Fig. 3 is an enlarged schematic structural diagram of a position a of a mosaic ceramic tile according to an embodiment of the present invention.

Fig. 4 is an enlarged schematic structural view of a suction cup of a mosaic tile according to an embodiment of the present invention.

In the figure: 1. a suction cup; 2. a handle; 21. a switch; 3. vacuumizing the shell; 4. an air pump; 5. a battery; 6. a deflation assembly; 61. a one-way valve shaft; 62. a button; 63. a control lever; 631. a clamping head; 632. a rotating groove; 633. a rotating arm; 64. a return spring; 7. a hollow box body.

Detailed Description

In order to make the objects, technical solutions and advantages of the present invention more clear, the present invention is further described in detail through the accompanying drawings and embodiments. It should be understood, however, that the description herein of specific embodiments is only intended to illustrate the invention and not to limit the scope of the invention. Moreover, in the following description, descriptions of well-known structures and techniques are omitted so as to not unnecessarily obscure the concepts of the present invention.

In the description of the present invention, it should be noted that the terms "center", "upper", "lower", "left", "right", "vertical", "horizontal", "inner", "outer", and the like indicate orientations or positional relationships based on the orientations or positional relationships shown in the drawings or orientations or positional relationships that the products of the present invention are usually placed in when used, and are only used for convenience of describing the present invention and simplifying the description, but do not indicate or imply that the devices or elements indicated must have a specific orientation, be constructed and operated in a specific orientation, and thus, should not be construed as limiting the present invention. Furthermore, the terms "first," "second," "third," and the like are used solely to distinguish one from another and are not to be construed as indicating or implying relative importance.

In the description of the present invention, it should also be noted that, unless otherwise explicitly specified or limited, the terms "disposed," "mounted," "connected," and "connected" are to be construed broadly, e.g., as meaning either a fixed connection, a removable connection, or an integral connection; can be mechanically or electrically connected; they may be connected directly or indirectly through intervening media, or they may be interconnected between two elements. The specific meanings of the above terms in the present invention can be understood in specific cases to those skilled in the art.

The first embodiment is as follows:

referring to fig. 1, an embodiment of the present invention provides a paving device for mosaic tiles, including a suction cup 1 and a handle 2. A plurality of sucking discs 1 are installed on the same vacuumizing shell 3, and the fixing and loosening of the sucking discs 1 and the mosaic tiles are realized by changing the gas quantity in the vacuumizing shell 3. A handle 2 is connected to the vacuum-pumping housing 3. Specifically, the suction cup 1 is fixed to the bottom of the vacuum housing 3 in the longitudinal and transverse directions. After the sucker 1 is attached to all the small tiles on the mosaic tiles, the vacuumizing shell 3 can be manually exhausted. The gas in the vacuumizing shell 3 is lost, and the sucking disc 1 can tightly suck all the small tiles of the mosaic tiles. The handle 2 can carry and spread the device to the evacuation casing 3, and this mode can make the monoblock mosaic ceramic tile all keep relative level. The mosaic ceramic tile paved and pasted by the device has good flatness, so that the swimming pool pasted with the mosaic ceramic tile is more beautiful.

Example two:

to improve the automation degree of the placement device of the first embodiment, the following functions are added.

Further, referring to fig. 2, in an alternative embodiment, the vacuum enclosure 3 is coupled to a suction pump 4 to perform the suction function.

Further, referring to fig. 2, in an alternative embodiment, the pump 4 is powered by connecting to a battery 5. The battery 5 controls the air suction pump 4 to perform air suction so as to improve the automation degree.

Further, referring to fig. 1 and 2, in an alternative embodiment, a switch 21 for controlling the start and stop of the air pump 4 is provided on the handle 2. The air pump 4 is started by pressing the switch 21, and the air pump 4 is stopped by stopping the pressing of the switch 21. Or the air pump 4 is started by pressing the switch 21, and the switch of the air pump is closed by pressing the switch 21.

Further, referring to fig. 1 and 2, in an alternative embodiment, a vent assembly 6 is further provided on the evacuated housing 3.

Further, referring to fig. 1 and 3, in an alternative embodiment, the air bleeding assembly 6 includes a check valve shaft 61 connected to the vacuum housing 3 and a button 62 for controlling the movement of the check valve shaft 61. When the button 62 is pressed, the one-way valve shaft 61 blocks the vacuum casing 3, and prevents outside air from entering the vacuum casing 3. When the button 62 is pulled up, the one-way valve shaft 61 moves upwards, external air enters the vacuumizing shell 3, and the mosaic tiles are loosened by the sucking disc 1.

Example three:

the air bleeding component 6 is further optimized on the basis of the second embodiment.

Further, referring to fig. 2 and 3, in an alternative embodiment, the air bleeding component 6 further includes a control rod 63 engaged with the one-way valve shaft 61 and controlling the up-and-down movement thereof, and a return spring 64 connected to an end of the control rod 63 far from the one-way valve shaft 61.

Further, referring to FIGS. 2 and 3, in an alternative embodiment, the lever 63 includes a latch head 631 configured to latch the one-way valve shaft 61, a pivot slot 632 extending from a side of the latch head 631 remote from the one-way valve shaft 61, and a pivot arm 633 extending from a side of the pivot slot 632 remote from the latch head 631. The pivot arm 633 is connected to the button 62 and the return spring 64. When the button 62 is not pressed, the return spring 64 abuts against the rotating arm 633, and the rotating arm 633 blocks the vacuum-pumping housing 3 downward, so as to prevent outside air from entering the vacuum-pumping housing 3. After the air pump 4 is started in the state, the suction disc 1 can suck the mosaic tiles. When the button 62 is pressed, the rotating arm 633 moves downwards, the clamping joint 631 drives the one-way valve shaft 61 to move upwards, and after outside air enters the vacuum-pumping shell 3, the suction cup 1 releases mosaic tiles.

Example four:

and on the basis of the third embodiment, the structure of the paving device is further optimized.

Further, referring to FIG. 2, in an alternative embodiment, deflation assembly 6 is partially disposed within handle 2. Specifically, button 62 exposes outside the handle, and other parts are installed inside handle 2, have reduced the holistic volume of paving the device, facilitate the use.

Further, referring to fig. 2, in an alternative embodiment, a hollow box 7 is provided between the handle 2 and the evacuated housing 3. The air pump 4 and the battery 5 are both arranged in the hollow box body 7. The size is further reduced, the weight of the paving device is increased, and the pressing force of a person when the tile of the paving device is paved can be reduced. And the routing of electric wire is connected with switch 21 through the inside of handle 2 from the inside of hollow box 7, and the overall arrangement is more reasonable, and the electric wire does not expose also safer.

Further, referring to fig. 4, in an alternative embodiment, the chuck 1 is a two-layer or multi-layer vacuum chuck head. The contraction stroke of the two-layer or multi-layer vacuum sucker head is further increased, so that the mosaic ceramic tile can be tightly attached to the bottom of the vacuumizing shell 3.

The specific working process is as follows: after the handle 2 is held by hand, the sucker 1 is tightly attached to the mosaic ceramic tile. The push switch 21 starts the air pump 4 to pump air to the vacuum-pumping casing 3, and the suction cup 1 starts to contract and tightly sucks the mosaic ceramic tile and makes the mosaic ceramic tile tightly attached to the bottom of the vacuum-pumping casing 3. The mosaic tiles can remain relatively level at this time. The mosaic ceramic tile is pressed on the surface needing tiling. After the suction pump 4 is turned off by the switch 21. When the button 62 is pressed, the button 62 presses the rotating arm 633 to rotate the rotating groove 632, the clamping joint 631 drives the one-way valve shaft 61 to move upwards, at the moment, air enters the suction cup 1, and the suction cup 1 releases mosaic tiles. The mosaic ceramic tiles paved and pasted by the device are smooth, and the paving and pasting speed of the device is high.

The above description is only exemplary of the present invention and should not be taken as limiting the scope of the present invention, as any modification, equivalent replacement or improvement made within the spirit and principle of the present invention should be included in the present invention.

---

Generated by IPtorch. Verify legal conclusions against the official publication.
