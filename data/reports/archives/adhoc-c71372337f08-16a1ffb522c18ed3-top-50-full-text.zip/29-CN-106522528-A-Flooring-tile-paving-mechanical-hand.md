# 29. Flooring tile paving mechanical hand

- **Archive rank:** 29 of 50
- **Publication:** [CN-106522528-A](https://patents.google.com/patent/CN106522528A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/058348230/publication/CN106522528A?q=pn%3DCN106522528A)
- **Publication date:** 2017-03-22
- **Filing date:** 2015-09-14
- **Earliest priority:** 2015-09-14
- **Family:** 58348230
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery

## Parties

- **Applicant / assignee:** FU ZETIAN

## Abstract

The invention discloses flooring tile paving mechanical hand equipment, and relates to the field of building machinery and construction (decoration). A mechanical hand body, a connection-hanging spring, a bracket, air pipes and an air pump are included. The mechanical hand body is composed of four air cylinder rubber mallets, a suction cup and an accessory. The four air cylinder rubber mallets are controlled by four air valve switches correspondingly. The suction cup is controlled by a generator and an air valve switch. The air cylinder rubber mallets, the suction cup, the air valve switches and the generator are all connected with the air pump through the air pipes to provide aerodynamic force. The mechanical hand body is hung at the end of a transverse rod of the bracket through the spring. The bracket is composed of a base, a vertical rod and the transverse rod. The transverse rod, the vertical rod and the base are all connected through sleeves and fixed through bolts. According to the flooring tile paving mechanical hand equipment, manual operation procedures are simulated by adopting a pneumatic mode, the hanging spring is utilized ingeniously, the labor intensity is greatly relieved, and the working efficiency is improved, so that heavy manual work becomes relaxed and happy work, and a new path for paving machinery is provided.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-106522528-A/pdf000.png)

![Sketch 1 for CN-106522528-A](https://nimo.iptorch.com/refdrawing/CN-106522528-A/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-106522528-A/pdf001.png)

![Sketch 2 for CN-106522528-A](https://nimo.iptorch.com/refdrawing/CN-106522528-A/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/CN-106522528-A/pdf002.png)

![Sketch 3 for CN-106522528-A](https://nimo.iptorch.com/refdrawing/CN-106522528-A/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/CN-106522528-A/pdf003.png)

![Sketch 4 for CN-106522528-A](https://nimo.iptorch.com/refdrawing/CN-106522528-A/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/CN-106522528-A/pdf004.png)

![Sketch 5 for CN-106522528-A](https://nimo.iptorch.com/refdrawing/CN-106522528-A/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/CN-106522528-A/pdf005.png)

![Sketch 6 for CN-106522528-A](https://nimo.iptorch.com/refdrawing/CN-106522528-A/pdf005.png)

## Claims

### Claim 1 (independent)

Claims (6) a kind of floor tile paving manipulator, including manipulator, hanger spring, support, tracheae and air pump.Manipulator is by four cylinder rubber hammers and one

### Claim 3 (independent)

Individual sucker and a planar horizontal device composition, four cylinder rubber hammers are controlled by four air valve switch respectively, can adjust percussion dynamics, and can make four

### Claim 4 (independent)

Individual cylinder rubber hammer is tapped or single percussion simultaneouslyï¼Sucker is controlled by generator and air valve switchï¼Air pump by tracheae with the cylinder rubber hammer in manipulator,

### Claim 5 (independent)

Sucker and generator and the connection of air valve controlling switch, and aerodynamic force is providedï¼Fixed mount by four cylinder rubber hammers, sucker, planar horizontal device and its

### Claim 6 (independent)

Firmly combination links together his accessory, forms overall manipulatorï¼Manipulator is hung on rack cross-bar termination by hanger spring, and support is by cross bar, vertical

### Claim 7 (independent)

Bar and base composition, cross bar, vertical rod are fixed by sleeve, bolt connection, and rack rod, cross bar length can be freely to adjust, and cross bar can be

### Claim 8

360 Â° of rotations, it can be mobile that base is provided with four-wheel. floor tile paving manipulator according to claim 1, it is characterised in that described has four cylinder rubber hammers, a sucker and

### Claim 10

Planar horizontal device, the percussion dynamics of cylinder rubber hammer are adjustable. floor tile paving manipulator according to claim 1, it is characterised in that be pneumatic, manipulator provides pneumatic by tracheae connection air pump

### Claim 12

Power. floor tile paving manipulator according to claim 1, it is characterised in that manipulator is hung on rack cross-bar termination by hanger spring. floor tile paving manipulator according to claim 1, it is characterised in that rack rod, cross bar length can be freely to adjust, it is horizontal

### Claim 15

Bar can be 360 Â° of rotations. floor tile paving manipulator according to claim 1, it is characterised in that it is transportable enough that base is provided with four-wheel.

## Full description

**[p0001]**

Description Floor tile paving manipulator Technical field The present invention relates to construction, building machinery field is built (decorate), more particularly to a kind of floor tile (slabstone) paving robotic device. Background technology In real floor tile paving, substantially by manpower manual operations, needing repeatedly will be floor tile paving lower and pick up, because floor tile it is heavier, every time Carry, pick up and spread down and all consume very big ARTIFICIAL FORCE gas, paving work is daily operate all be often it is tired ache all over, and paving speed is slower. Now with using vibration-type floor tile paving machine, original floor tile is just very heavy, and plus the weight of vibration-type floor tile paving machine, takes operator Feel more tired when under rising and spreading, moreover be extremely difficult to require for shaking the floor tile higher to paving quality requirement, it is impossible to reduce labor intensity, Operating efficiency cannot be also improved, so this vibration-type floor tile paving machine practical application is little.And floor tile paving manipulator of the present invention, using gas

**[p0002]**

Dynamic formula sucker, pneumatic type rubber hammer, the manipulator for imitating artificial percussion, by spring hanging in rack cross-bar termination, cross bar can be with 360 Â° for manipulator Rotate, manipulator is made up of four cylinder rubber hammers and a sucker and a planar horizontal device, and sucker holds floor tile, because of the effect of top spring, The strength of people's very little can just make manipulator and floor tile lift, move, put down, and four cylinder rubber hammers can tap floor tile simultaneously, it is also possible to Individually tap, so both imitated people's manual operations, it is ensured that quality requirement, can significantly mitigate the labour intensity of operating personnel again, and work effect can be improved Rate. The content of the invention The technical problem to be solved in the present invention is to provide one kind and can mitigate floor tile paving personnel labor intensity, improves paving quality and operating efficiency,

**[p0003]**

And floor tile paving manipulator simple to operate. In order to solve above-mentioned technical problem, the technical solution used in the present invention is that a kind of floor tile paving robotic device, including manipulator, connection Hanger spring, support, tracheae and air pump.Manipulator is made up of four cylinder rubber hammers and a sucker and a planar horizontal device, four cylinders point Not do not controlled by four air valve switch, the percussion dynamics size of air valve is adjustable displacements of cylinders rubber hammer, four cylinder rubber hammers can tap floor tile simultaneously, Individually can also tapï¼Sucker is controlled by generator and air valve switch, and manipulator and sucker are connected with air pump by tracheae, and fixed mount is by four gas Cylinder rubber hammer, sucker and the firm composite joint of other accessories together, form overall manipulator, and manipulator is hung on rack cross-bar end by hanger spring Head, support are made up of cross bar, vertical rod and base, and cross bar, vertical rod and base have sleeve connection, bolt to fix, and cross bar, vertical rod length can be certainly

**[p0004]**

By adjusting, rack cross-bar can be rotated with 360 Â°, and base is provided with four-wheel and can move. Above-described floor tile paving manipulator, has four cylinder rubber hammers, a sucker and a planar horizontal device, and four cylinder rubber hammers can To tap floor tile simultaneously, it is also possible to individually tap, and tap dynamics and be adjustable. Above-described floor tile paving manipulator, is pneumatic, and manipulator provides power by tracheae connection air pump. Manipulator is hung on rack cross-bar termination by above-described floor tile paving manipulator, hanger spring. Above-described floor tile paving manipulator, rack cross-bar and vertical rod length can be freely to adjust, and cross bar can be 360 Â° of rotations. Above-described floor tile paving manipulator, it can be mobile that base is provided with four-wheel. Description of the drawings The present invention will be further described in detail with reference to the accompanying drawings and detailed description.

**[p0005]**

Fig. 1 is the front view of the present invention. Fig. 2 is the front view and top view of manipulator. Specific embodiment As shown in Figure 1 and Figure 2, air pump 1 is conveyed to sucker 8 and cylinder rubber by tracheae 2 to the structure of embodiment of the present invention floor tile paving manipulator Skin hammers 7 aerodynamic force into shape, and base 3, vertical rod 4, cross bar 5 are connected by sleeve and bolt 17 and constitute support, and base 3 is provided with four-wheel and can move, Vertical rod 4, the length of cross bar 5 can be adjusted with Jing bolts 17, and cross bar 5 can be rotated with 360 Â°, and sucker 8 is controlled by sucker generator 11 and sucker Switch 13 is controlled, and cylinder rubber hammer 7 is by 10 4 controls of cylinder rubber hammer double control switch 9 left and right two and single control switch, 9 He of double control switch Below left and right control handle 13, both hands hold control handle 13 to single control switch 10, and manipulation cylinder rubber hammer double control switch 9 can allow four gas

**[p0006]**

Cylinder rubber hammer 7 is tapped simultaneously simultaneously, it is also possible to control the 7 unilateral percussion of left and right two cylinder rubber hammers, and manipulate single control switch 10 to allow four The 7 single percussion of cylinder rubber hammer, left and right control handle 13 are that the operation to whole robotic device is controlled, and fixed mount 14 is by four cylinder rubbers Skin hammer 7, sucker 8 and the firm composite joint of other accessories together, form overall.By cylinder rubber hammer 7 four, cylinder rubber hammer double control switch 9 two, cylinder rubber hammer single control switch 10 4, sucker 8, sucker generator 11, sucker controlling switch 13, fixed mount 14, planar horizontal Device 15, the composition manipulator of suspension rod 16.Manipulator is hung on into 5 termination of rack cross-bar with spring 6, the pulling force of spring 6 should be than the weight of manipulator It is bigger, when manipulator sucker 8 is drawn onto floor tile, just can be lifted and be put down with the strength of very little, be mitigated and carry, act the labour intensity put.It is flat

**[p0007]**

Face horizon equipment 15 is used for determining the smooth of floor tile. Above-described floor tile paving manipulator, cylinder rubber hammer 7 have four, can replace manually tapping rubber hammer, and can adjust percussion dynamics, Four cylinder rubber hammers 7 can tap simultaneously or the percussion simultaneously of the cylinder rubber hammer of left and right side two 7 according to actual needs, it is also possible to a cylinder rubber Skin hammer 7 is individually tapped. Above-described floor tile paving manipulator, sucker 8 have one, carry for absorption floor brick and rise and put, pass through sucker without vavuum pump Generator 11 and cylinder rubber hammer 7 directly share air pump 1. Above-described floor tile paving manipulator, for manipulator is hung on 5 termination of rack cross-bar, the pulling force of spring 6 should be than machinery for spring 6 The weight of hand is bigger, mitigates manipulator and floor tile is exerted oneself when rising, putting. Above-described floor tile paving manipulator, base 3, vertical rod 4, cross bar 5 are fixed by sleeve and bolt connection and constitute support, under base 3

**[p0008]**

If four wheels can be moved, vertical rod 4,5 length of cross bar freely can be adjusted, and cross bar 5 can be rotated with 360 Â°. Above-described floor tile paving manipulator, air pump 1 one are conveyed to sucker 8 and four cylinder rubber hammers 7 by five tracheaes 2 pneumatic Power. Above-described floor tile paving manipulator, planar horizontal device 15 be for determining that floor tile is smooth, The use process of floor tile paving manipulator is as followsï¼ First by base 3, vertical rod 4,5 grafting sleeve of cross bar and after adjustment length bolt is fixed on request, with hanger spring 6 by manipulator (gas Cylinder rubber hammer 7, sucker 8 and other accessories) Jing suspension rods 16 are hung on 5 termination of rack cross-bar, tracheae 2 five along hanger spring 6, cross bar 5, Vertical rod 4 (being all provided with tracheae 2 with upper bit to be fixedly installed) and manipulator and the grafting of air pump port, overall preparation are ready, then connect air pump

**[p0009]**

Power supply, just can be with practical operation when air pressure reaches requirement. First bottom ash is paved smooth, operating personnel's both hands catch left and right control handle 13, rack cross-bar 5 and manipulator are turned to into floor tile and is put Place's (floor tile is placed can not be beyond length of cross bar 5) is put, manipulator is placed on floor tile, is started sucker controlling switch 12, such sucker 8 Start working, floor tile is firmly held, although floor tile is very heavy, because the effect of hanger spring 6 but gently can be lifted, manipulate 5 He of rack cross-bar Manipulator is returned on operating surface, puts down manipulator and floor tile, adjusts angle and the gap of floor tile, and then both hands operate left and right cylinder rubber simultaneously Skin hammers double control switch 9 into shape, and such four cylinder rubber hammers 7 tap floor tile simultaneously, and the dynamics of will hit against is adjusted to most preferably, and number of taps is according to actual feelings

**[p0010]**

Determining, whether observation floor tile is smooth with the good floor tile of paving, may be viewed by planar horizontal device 15 for condition, if there is out-of-flatness, operable cylinder Rubber hammer single control switch 10 is single to tap adjustment, after requirement is reached, manipulator and floor tile is lifted after removing and carrying out pouring slurry operation, will Manipulator and floor tile are put into again and have been poured on oar operating surface, with the hands hold control handle 13 and operate left and right cylinder rubber hammer double control switch 9, four Cylinder rubber hammer 7 taps floor tile (GPRS manipulation dynamics) simultaneously, if the controllable cylinder rubber hammer single control switch of out-of-flatness 10 carries out cylinder rubber Skin hammers 7 single percussions into shape, and whether smooth, until reaching requirement, finally turn off sucker controlling switch 12 if examining planar horizontal device 15, sucker 8 departs from

**[p0011]**

Floor tile, operational sequence are completed, and can proceed to the paving of next piece of floor tile. Above example of the present invention has the advantage thatï¼Modern design, installs simple, easy to operate, reduces labor intensity, improves operating efficiency, protects Card paving quality.

## Cited patent documents

- [CN-102493630-A](https://patents.google.com/patent/CN102493630A/en) — SEA
- [CN-104594612-A](https://patents.google.com/patent/CN104594612A/en) — SEA
- [CN-201634991-U](https://patents.google.com/patent/CN201634991U/en) — SEA
- [CN-205558222-U](https://patents.google.com/patent/CN205558222U/en) — SEA
- [JP-2004083225-A](https://patents.google.com/patent/JP2004083225A/en) — SEA

---

Generated by IPtorch. Verify legal conclusions against the official publication.
