# 21. Ceramic tile vacuum adsorption piece and ceramic tile setting device

- **Archive rank:** 21 of 50
- **Publication:** [CN-207245123-U](https://patents.google.com/patent/CN207245123U/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/061880391/publication/CN207245123U?q=pn%3DCN207245123U)
- **Publication date:** 2018-04-17
- **Filing date:** 2017-08-03
- **Earliest priority:** 2017-08-03
- **Family:** 61880391
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** LI YIJUN

## Abstract

The utility model discloses a ceramic tile vacuum adsorption spare for cooperation supporting shoe and vacuum pump use are used for pasting and establish the ceramic tile, vacuum adsorption spare is platelike and is divided into an at least vacuum chuck, vacuum adsorption spare includes relative first surface and second surface, the first surface is pasted and is established just correspond at least one on the supporting shoe vacuum chuck has seted up the air channel, the second is formed with at least one on the surface vacuum chuck&#39;s absorption groove is in order to adsorb corresponding ceramic tile extremely the second is on the surface, vacuum chuck is equipped with the intercommunication the air channel with the aspirating hole in absorption groove. Additionally, the utility model also discloses a ceramic tile pastes and establishes device for the cooperation vacuum pump is used, including supporting shoe and at least one as above ceramic tile vacuum adsorption piece, one of them is connected to the port of bleeding of vacuum pump the air channel of vacuum adsorption piece.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf000.png)

![Sketch 1 for CN-207245123-U](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf001.png)

![Sketch 2 for CN-207245123-U](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf002.png)

![Sketch 3 for CN-207245123-U](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf003.png)

![Sketch 4 for CN-207245123-U](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf004.png)

![Sketch 5 for CN-207245123-U](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf005.png)

![Sketch 6 for CN-207245123-U](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf006.png)

![Sketch 7 for CN-207245123-U](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf007.png)

![Sketch 8 for CN-207245123-U](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf008.png)

![Sketch 9 for CN-207245123-U](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf009.png)

![Sketch 10 for CN-207245123-U](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf009.png)

[Sketch 11](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf010.png)

![Sketch 11 for CN-207245123-U](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf010.png)

[Sketch 12](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf011.png)

![Sketch 12 for CN-207245123-U](https://nimo.iptorch.com/refdrawing/CN-207245123-U/pdf011.png)

## Claims

### Claim 1 (independent)

A kind of 1. ceramic tile vacuum adsorption piece, for coordinating supporting block and vacuum pump to use with the ceramic tile that is sticked, it is characterised in that described Vacuum suction part is plate-like and is divided into an at least vacuum cup, and the vacuum suction part includes opposite first surface and the Two surfaces, the first surface is sticked in the supporting block and corresponding at least one vacuum cup offers air channel, institute The adsorption tank formed with least one vacuum cup on second surface is stated so that corresponding ceramic tile is adsorbed on the second surface, The vacuum cup is equipped with the aspirating hole for connecting the air channel and the adsorption tank.

### Claim 2

ceramic tile vacuum adsorption piece as claimed in claim 1, it is characterised in that the second surface be convexly equipped with for position, Separate the flange of ceramic tile, the lateral section of the ceramic tile is enclosed by the flange to be set, and partly stretches out the flange.

### Claim 3

ceramic tile vacuum adsorption piece as claimed in claim 1, it is characterised in that the second surface projection forms at least one institute The sealing ring of vacuum cup is stated, the sealing ring is around the corresponding adsorption tank.

### Claim 4

ceramic tile vacuum adsorption piece as claimed in claim 3, it is characterised in that the sealing ring is sealing thorn circle.

### Claim 5

ceramic tile vacuum adsorption piece as claimed in claim 3, it is characterised in that the second surface is formed with least described in one The annular groove of vacuum cup, the annular groove is around the adsorption tank, and the sealing ring projection is in the annular groove.

### Claim 6

ceramic tile vacuum adsorption piece as claimed in claim 1, it is characterised in that the aspirating hole is pin hole.

### Claim 7

ceramic tile vacuum adsorption piece as claimed in claim 1, it is characterised in that the air channel is at least to side through described Vacuum suction part, is connected with the air channel of the vacuum suction part with arranged adjacent.

### Claim 8 (independent)

The device 8. a kind of ceramic tile is sticked, for coordinating vacuum pump to use, it is characterised in that including：Supporting block and at least just like power Profit requires 1 to 7 any one of them ceramic tile vacuum adsorption piece, one of them described vacuum of the suction port connection of the vacuum pump The air channel of adsorption piece.

### Claim 9

The device 9. ceramic tile as claimed in claim 8 is sticked, it is characterised in that including being mutually arranged closely in the supporting block Multiple vacuum suction parts, the air channel of multiple vacuum suction parts is interconnected.

### Claim 10

The device 10. ceramic tile as claimed in claim 8 or 9 is sticked, it is characterised in that the supporting block offers and one of them The perforative bleed-off passage of the air channel connection of the vacuum suction part, the suction port of the vacuum pump are arranged on the pumping Passage.

### Claim 11

The device 11. ceramic tile as claimed in claim 8 is sticked, it is characterised in that the vacuum suction part sticker is in the support On block.

## Full description

Description

Translated from Chinese

ç·ç çç©ºå¸éä»¶åç·ç è´´è®¾è£

ç½®Ceramic tile vacuum adsorption piece and tile sticking device

ææ¯é¢åtechnical field

æ¬å®ç¨æ°åæ¶åå»ºç­é¢åï¼å°¤å

¶æ¶åä¸ç§ç·ç çç©ºå¸éä»¶åç·ç è´´è®¾è£

ç½®ãThe utility model relates to the construction field, in particular to a ceramic tile vacuum adsorption piece and a ceramic tile pasting device.

èæ¯ææ¯Background technique

é¿æä»¥æ¥ï¼å»ºç­ç©çå¢ä½ç·ç ä»¥åå°é¢ç·ç çè´´è®¾é½æ¯ä¾é äººåæå·¥æä½å®æçãç±äºå¨æå·¥è´´è®¾ç·ç æ¶ï¼é¦å

è¦æ¾çº¿ï¼ç¶ååä¾é äººåæå·¥ä¸åä¸åçè´´è®¾ï¼å

¶å³å¨å¼ºåº¦å¤§ï¼å·¥ä½æçä½ï¼èä¸ç·ç çæ´ä½å¹³æ´åº¦ãç¼éçåååº¦åå·®ä¸é½ï¼å·¥ç¨è´¨éé¾ä»¥ä¿éãå æ­¤ï¼äºéæä¾ä¸ç§ç·ç è´´è®¾è£

ç½®ï¼è½å¤åæ¶è´´è®¾å¤ä¸ªç·ç ï¼æææåå·¥ä½æçï¼å¹¶ä¿è¯ç·ç çæ´ä½å¹³æ´åº¦åç¼éåååº¦ãFor a long time, the wall tiles of buildings and the laying of floor tiles all rely on manual operations to complete. When laying ceramic tiles by hand, the wires must be laid out first, and then rely on manpower to manually stick them one by one. Difficult to guarantee. Therefore, there is an urgent need to provide a tile laying device, which can simultaneously lay multiple tiles, effectively improve work efficiency, and ensure the overall flatness and gap uniformity of the tiles.

å®ç¨æ°åå

å®¹Utility model content

æ¬å®ç¨æ°åçç®çå¨äºæä¾ä¸ç§ç·ç çç©ºå¸éä»¶ï¼éè¿å°å¤ä¸ªçç©ºå¸éä»¶ç´§å¯æåå¨æ¯æåä¸æè

å¨çç©ºå¸éä»¶ä¸ä¸ä½æåå¤ä¸ªçç©ºå¸çï¼ä½¿å¾ç·ç è´´è®¾è£

ç½®è½å¤åæ¶å¸éå¤ä¸ªç·ç è¿è¡è´´è®¾ï¼æææåå·¥ä½æçï¼å¹¶ä¿è¯å¢é¢çæ´ä½å¹³æ´åº¦ãThe purpose of the utility model is to provide a tile vacuum absorber, by arranging multiple vacuum absorbers closely on the support block or integrally forming a plurality of vacuum suction cups on the vacuum absorber, so that the tile sticking device can simultaneously absorb multiple Ceramic tiles are pasted to effectively improve work efficiency and ensure the overall flatness of the wall.

æ¬å®ç¨æ°åçå¦ä¸ç®çå¨äºæä¾ä¸ç§ç·ç è´´è®¾è£

ç½®ï¼è½å¤åæ¶è´´è®¾å¤ä¸ªç·ç ï¼æææåå·¥ä½æçï¼å¹¶ä¿è¯å¢é¢çæ´ä½å¹³æ´åº¦ãAnother object of the present utility model is to provide a ceramic tile installation device, which can simultaneously install multiple ceramic tiles, effectively improve work efficiency, and ensure the overall flatness of the wall surface.

ä¸ºäºå®ç°ä¸è¿°ç®çï¼æ¬å®ç¨æ°åæä¾äºä¸ç§ç·ç çç©ºå¸éä»¶ï¼ç¨äºé

åæ¯æååçç©ºæ³µä½¿ç¨ä»¥è´´è®¾ç·ç ï¼æè¿°çç©ºå¸éä»¶åæ¿ç¶ä¸è¢«ååä¸ºè³å°ä¸çç©ºå¸çï¼æè¿°çç©ºå¸éä»¶å

æ¬ç¸å¯¹çç¬¬ä¸è¡¨é¢åç¬¬äºè¡¨é¢ï¼æè¿°ç¬¬ä¸è¡¨é¢è´´è®¾å¨æè¿°æ¯æåä¸ä¸å¯¹åºè³å°ä¸æè¿°çç©ºå¸çå¼è®¾æéæ°æ§½ï¼æè¿°ç¬¬äºè¡¨é¢ä¸å½¢ææè³å°ä¸æè¿°çç©ºå¸ççå¸éæ§½ä»¥å°ç¸åºç·ç å¸éè³æè¿°ç¬¬äºè¡¨é¢ä¸ï¼æè¿°çç©ºå¸çè®¾æè¿éæè¿°éæ°æ§½ä¸æè¿°å¸éæ§½çæ½æ°å­ãIn order to achieve the above purpose, the utility model provides a ceramic tile vacuum absorber, which is used in conjunction with a support block and a vacuum pump to attach tiles. The vacuum absorber is plate-shaped and is divided into at least one vacuum suction cup. The adsorbent includes a first surface and a second surface opposite to each other. The first surface is attached to the support block and is provided with a ventilation groove corresponding to at least one of the vacuum suction cups. At least one The suction groove of the vacuum suction cup is used to adsorb the corresponding tiles to the second surface, and the vacuum suction cup is provided with a suction hole communicating the ventilation groove and the suction groove.

ä¸ç°æææ¯ç¸æ¯ï¼æ¬å®ç¨æ°åéè¿å°å¤ä¸ªçç©ºå¸éä»¶ç´§å¯æåå¨æ¯æåä¸ä½¿å¾å¤ä¸ªçç©ºå¸éä»¶çéæ°æ§½ç¸äºè¿éæè

å¨çç©ºå¸éä»¶ä¸ä¸ä½æåå¤ä¸ªçç©ºå¸çå¹¶ä½¿å¾çç©ºå¸éä»¶çéæ°æ§½è¿éå¤ä¸ªçç©ºå¸ççæ½æ°å­ï¼ä½¿å¾å¨åªä½¿ç¨ä¸ä¸ªçç©ºæ³µçæ

åµä¸ï¼è½åæ¶å¸éå¤ä¸ªç·ç è¿è¡è´´è®¾ï¼æææåäºè´´è®¾ç·ç çæçï¼èä¸ç±äºå¤ä¸ªç·ç æ¯å¸éå¨åä¸å¸éä»¶çç¬¬äºè¡¨é¢æè

æåå¨æ¯æåçå¤ä¸ªçç©ºå¸éä»¶çç¬¬äºè¡¨é¢ï¼å æ­¤ï¼å¤ä¸ªç·ç ä¹é´ç¸äºå¹³é½ï¼ä»èææä¿è¯å¢é¢çæ´ä½å¹³æ´åº¦ãCompared with the prior art, the utility model makes the ventilation grooves of the multiple vacuum adsorption pieces communicate with each other by closely arranging a plurality of vacuum adsorption pieces on the support block or integrally forms a plurality of vacuum suction cups on the vacuum adsorption piece to make the vacuum adsorption The ventilation groove of the piece is connected to the air holes of multiple vacuum suction cups, so that when only one vacuum pump is used, multiple tiles can be adsorbed at the same time for placement, which effectively improves the efficiency of tile placement; and because multiple tiles are adsorbed on The second surface of the same absorbing piece or the second surfaces of multiple vacuum absorbing pieces arranged on the support block, therefore, the plurality of tiles are flush with each other, thereby effectively ensuring the overall flatness of the wall surface.

è¾ä½³å°ï¼æè¿°ç¬¬äºè¡¨é¢å¸è®¾æç¨äºå®ä½ãåéç·ç çå¸ç¼ï¼æè¿°ç·ç çä¾§è¾¹é¨åè¢«æè¿°å¸ç¼å´è®¾ï¼é¨åä¼¸åºæè¿°å¸ç¼ï¼ä»èè½å¤å¯¹ç·ç è¿è¡åç¡®çå®ä½ååéï¼è¿èè½å¤ä¿è¯å®æè´´è®¾åç·ç ä¹é´çç¼éçåååº¦ãPreferably, the second surface is protruded with a flange for positioning and separating the tiles, the side of the tile is surrounded by the flange, and part of the flange protrudes from the flange, so that the tile can be accurately positioned. The positioning and separation of the tiles can ensure the uniformity of the gaps between the tiles after the installation is completed.

è¾ä½³å°ï¼æè¿°ç¬¬äºè¡¨é¢å¸è®¾å½¢æè³å°ä¸æè¿°çç©ºå¸ççå¯å°åï¼æè¿°å¯å°åç¯ç»ç¸åºçæè¿°å¸éæ§½ï¼èæ­¤ï¼è½å¤å¯¹ç¸åºç·ç è¿è¡æ´å å¯é çå¸éï¼ç¹å«æ¯å¨ç·ç çå¤è¡¨é¢ç²ç³åº¦è¾å¤§çæ

åµä¸ãPreferably, the second surface is protruded to form at least one sealing ring of the vacuum suction cup, and the sealing ring surrounds the corresponding adsorption groove, so that the corresponding ceramic tile can be adsorbed more reliably, especially in When the outer surface roughness of the tile is large.

è¾ä½³å°ï¼æè¿°å¯å°åä¸ºå¯å°åºåãPreferably, the sealing ring is a sealing crimped ring.

è¾ä½³å°ï¼æè¿°ç¬¬äºè¡¨é¢å½¢ææè³å°ä¸æè¿°çç©ºå¸ççç¯æ§½ï¼æè¿°ç¯æ§½ç¯ç»æè¿°å¸éæ§½ï¼æè¿°å¯å°åå¸è®¾å¨æè¿°ç¯æ§½ï¼èæ­¤ï¼å½ç¸åºç·ç å¸éå¨æè¿°ç¬¬äºè¡¨é¢æ¶ï¼æè¿°å¯å°åè½å¤è¢«æ¤åå

¥æè¿°ç¯æ§½ãPreferably, at least one ring groove of the vacuum suction cup is formed on the second surface, the ring groove surrounds the suction groove, and the sealing ring is protruded from the ring groove, so that when the corresponding tile is sucked When on the second surface, the sealing ring can be squeezed into the ring groove.

è¾ä½³å°ï¼æè¿°æ½æ°å­ä¸ºéå­ï¼èæ­¤è½å¤ä¿è¯éè¿ä¸ä¸ªçç©ºæ³µåæ¶ä¸ºå¤ä¸ªç·ç æä¾è¶³å¤çå¸éåãPreferably, the air pumping holes are pinholes, so as to ensure that a vacuum pump can provide sufficient adsorption force for multiple tiles at the same time.

è¾ä½³å°ï¼æè¿°éæ°æ§½è³å°åä¸ä¾§è´¯ç©¿æè¿°çç©ºå¸éä»¶ï¼ä»¥ä¸ç¸é»æåççç©ºå¸éä»¶çéæ°æ§½è¿éï¼èæ­¤è½å¤ä½¿å¾å¤ä¸ªç´§å¯æåçæè¿°çç©ºå¸éä»¶çéæ°æ§½ç¸äºè¿éãPreferably, the ventilation groove penetrates through the vacuum adsorption part at least to one side, so as to communicate with the ventilation grooves of the adjacently arranged vacuum adsorption parts, so that a plurality of closely arranged ventilation grooves of the vacuum adsorption parts can interconnected.

ä¸ºå®ç°ä¸è¿°å¦ä¸ç®çï¼æ¬å®ç¨æ°åæä¾äºä¸ç§ç·ç è´´è®¾è£

ç½®ï¼ç¨äºé

åçç©ºæ³µä½¿ç¨ï¼å

æ¬æ¯æååè³å°ä¸å¦ä¸æè¿°çç·ç çç©ºå¸éä»¶ï¼æè¿°çç©ºæ³µçæ½æ°ç«¯å£è¿æ¥å

¶ä¸­ä¹ä¸æè¿°çç©ºå¸éä»¶çéæ°æ§½ãIn order to achieve the above another purpose, the utility model provides a ceramic tile laying device for use with a vacuum pump, comprising a support block and at least one ceramic tile vacuum adsorption piece as described above, the suction port of the vacuum pump is connected to one of the A ventilation groove of the vacuum absorber.

ä¸ç°æææ¯ç¸æ¯ï¼æ¬å®ç¨æ°åéè¿å°å¤ä¸ªçç©ºå¸éä»¶ç´§å¯æåå¨æ¯æåä¸ä½¿å¾å¤ä¸ªçç©ºå¸éä»¶çéæ°æ§½ç¸äºè¿éæè

å¨çç©ºå¸éä»¶ä¸ä¸ä½æåå¤ä¸ªçç©ºå¸çå¹¶ä½¿å¾çç©ºå¸éä»¶çéæ°æ§½è¿éå¤ä¸ªçç©ºå¸ççæ½æ°å­ï¼ä½¿å¾å¨åªä½¿ç¨ä¸ä¸ªçç©ºæ³µçæ

åµä¸ï¼è½åæ¶å¸éå¤ä¸ªç·ç è¿è¡è´´è®¾ï¼æææåäºè´´è®¾ç·ç çæçï¼èä¸ç±äºå¤ä¸ªç·ç æ¯å¸éå¨åä¸å¸éä»¶çç¬¬äºè¡¨é¢æè

æåå¨æ¯æåçå¤ä¸ªçç©ºå¸éä»¶çç¬¬äºè¡¨é¢ï¼å æ­¤ï¼å¤ä¸ªç·ç ä¹é´ç¸äºå¹³é½ï¼ä»èææä¿è¯å¢é¢çæ´ä½å¹³æ´åº¦ï¼å¦å¤ï¼å¨æ½çç©ºåï¼çç©ºå¸éä»¶å¯ä»¥éè¿éæ°æ§½äº§çççç©ºå¸åèå¸éå¨æ¯æåä¸ï¼å¨è¿è¡ç·ç è´´è®¾æ¶ï¼çç©ºå¸éä»¶ä»ç¶å¯ä»¥ç»åå¨æ¯æåï¼æ éé¢å¤çåºå®è®¾ç½®ãCompared with the prior art, the utility model makes the ventilation grooves of the multiple vacuum adsorption pieces communicate with each other by closely arranging a plurality of vacuum adsorption pieces on the support block or integrally forms a plurality of vacuum suction cups on the vacuum adsorption piece to make the vacuum adsorption The ventilation groove of the piece is connected to the air holes of multiple vacuum suction cups, so that when only one vacuum pump is used, multiple tiles can be adsorbed at the same time for placement, which effectively improves the efficiency of tile placement; and because multiple tiles are adsorbed on The second surface of the same absorber or the second surfaces of multiple vacuum absorbers arranged on the support block, therefore, the multiple tiles are flush with each other, thereby effectively ensuring the overall flatness of the wall; in addition, after vacuuming , the vacuum absorber can be adsorbed on the support block through the vacuum suction generated by the ventilation groove, and the vacuum absorber can still be combined with the support block when laying tiles, without additional fixing settings.

è¾ä½³å°ï¼æè¿°ç·ç è´´è®¾è£

ç½®å

æ¬ç¸äºç´§å¯æåå¨æè¿°æ¯æåä¸çå¤ä¸ªæè¿°çç©ºå¸éä»¶ï¼å¤ä¸ªæè¿°çç©ºå¸éä»¶çéæ°æ§½ç¸äºè¿éãPreferably, the ceramic tile laying device includes a plurality of vacuum adsorption parts closely arranged on the support block, and the ventilation grooves of the plurality of vacuum adsorption parts communicate with each other.

è¾ä½³å°ï¼æè¿°æ¯æåå¼è®¾æä¸å

¶ä¸­ä¹ä¸æè¿°çç©ºå¸éä»¶çéæ°æ§½è¿éçè´¯ç©¿çæ½æ°ééï¼æè¿°çç©ºæ³µçæ½æ°ç«¯å£è®¾ç½®å¨æè¿°æ½æ°ééãPreferably, the support block is provided with a through air suction channel communicating with the air groove of one of the vacuum adsorption parts, and the air suction port of the vacuum pump is arranged in the air suction channel.

è¾ä½³å°ï¼æè¿°çç©ºå¸éä»¶è¶è´´å¨æè¿°æ¯æåä¸ï¼è¿èå¢å¼ºæè¿°çç©ºå¸éä»¶ä¸æè¿°æ¯æåä¹é´çç»ååãPreferably, the vacuum absorber is glued on the support block, so as to enhance the bonding force between the vacuum absorber and the support block.

éå¾è¯´æDescription of drawings

å¾1æ¯æ¬å®ç¨æ°åå®æ½ä¾çç·ç è´´è®¾è£

ç½®çä¾§é¢å±é¨ç¤ºæå¾ãFig. 1 is a side partial schematic diagram of a tile laying device according to an embodiment of the present invention.

å¾2æ¯å¾1æç¤ºç·ç è´´è®¾è£

ç½®å¸éç·ç çä¾§é¢å±é¨ç¤ºæå¾ãFig. 2 is a side partial schematic diagram of the tile sticking device shown in Fig. 1 absorbing tiles.

å¾3æ¯æ¬å®ç¨æ°åå®æ½ä¾çç·ç çç©ºå¸éä»¶çå¹³é¢ç¤ºæå¾ãFig. 3 is a schematic plan view of the ceramic tile vacuum adsorber according to the embodiment of the present invention.

å¾4æ¯æ¬å®ç¨æ°åå®æ½ä¾çç·ç çç©ºå¸éä»¶çå¦ä¸å¹³é¢ç¤ºæå¾ãFig. 4 is another schematic plan view of the ceramic tile vacuum absorber according to the embodiment of the present invention.

å¾5æ¯æ¬å®ç¨æ°åå®æ½ä¾çå¤ä¸ªç´§å¯æåçç·ç çç©ºå¸éä»¶çç¤ºæå¾ãFig. 5 is a schematic diagram of a plurality of closely arranged vacuum absorbers for ceramic tiles according to an embodiment of the present invention.

å¾6æ¯æ¬å®ç¨æ°åå®æ½ä¾çå¤ä¸ªç´§å¯æåçç·ç çç©ºå¸éä»¶çå¦ä¸ç¤ºæå¾ãFig. 6 is another schematic diagram of a plurality of closely arranged vacuum adsorption pieces for ceramic tiles according to the embodiment of the present invention.

å

·ä½å®æ½æ¹å¼Detailed ways

ä¸ºè¯¦ç»è¯´ææ¬å®ç¨æ°åçææ¯å

å®¹ãæé ç¹å¾ãæå®ç°çææï¼ä»¥ä¸ç»åå®æ½æ¹å¼å¹¶é

åéå¾è¯¦äºè¯´æãIn order to describe the technical content, structural features, and achieved effects of the present utility model in detail, the following will be described in detail in conjunction with the embodiments and accompanying drawings.

è¯·åé

å¾1è³å¾6ï¼æ¬å®ç¨æ°åçç·ç è´´è®¾è£

ç½®ï¼ç¨äºé

åçç©ºæ³µ(å¾æªç¤º)ä½¿ç¨ï¼å

æ¬æ¯æå1åè³å°ä¸ç·ç çç©ºå¸éä»¶2ï¼çç©ºå¸éä»¶2åæ¿ç¶ä¸è¢«ååä¸ºè³å°ä¸çç©ºå¸çXï¼çç©ºå¸éä»¶2å

æ¬ç¸å¯¹çç¬¬ä¸è¡¨é¢21åç¬¬äºè¡¨é¢22ï¼ç¬¬ä¸è¡¨é¢21è´´è®¾å¨æ¯æå1ä¸ä¸å¯¹åºè³å°ä¸çç©ºå¸çXå¼è®¾æéæ°æ§½23ï¼ç¬¬äºè¡¨é¢22ä¸å½¢ææè³å°ä¸çç©ºå¸çXçå¸éæ§½24ä»¥å°ç¸åºç·ç 5å¸éè³ç¬¬äºè¡¨é¢22ä¸ï¼çç©ºå¸çXè®¾æè¿ééæ°æ§½23ä¸å¸éæ§½24çæ½æ°å­26ï¼çç©ºæ³µçæ½æ°ç«¯å£è¿æ¥å

¶ä¸­ä¹ä¸çç©ºå¸éä»¶2çéæ°æ§½23ãå¨æ¬å®æ½ä¾ä¸­ï¼çç©ºå¸éä»¶2ä¸ºæ©¡è¶æ¿ï¼ä½ä¸åºä»¥æ­¤ä¸ºéãPlease refer to Fig. 1 to Fig. 6, the ceramic tile laying device of the present utility model is used to cooperate with the vacuum pump (not shown in the figure), and includes a support block 1 and at least one ceramic tile vacuum absorber 2, and the vacuum absorber 2 is plate-shaped and is Divided into at least one vacuum chuck X, the vacuum adsorption member 2 includes an opposite first surface 21 and a second surface 22, the first surface 21 is attached to the support block 1 and a ventilation groove 23 is opened corresponding to at least one vacuum chuck X, the second At least one suction groove 24 of a vacuum chuck X is formed on the two surfaces 22 to adsorb the corresponding ceramic tile 5 to the second surface 22. The vacuum chuck X is provided with an air extraction hole 26 communicating with the ventilation groove 23 and the adsorption groove 24. The air extraction of the vacuum pump The port is connected to the ventilation groove 23 of one of the vacuum adsorption parts 2 . In this embodiment, the vacuum absorber 2 is a rubber plate, but it should not be limited thereto.

è¯·åé

å¾2ãå¾3åå¾5ï¼çç©ºå¸éä»¶2çç¬¬äºè¡¨é¢22å¸è®¾æç¨äºå®ä½ãåéç·ç 5çå¸ç¼27ï¼ç·ç 5çä¾§è¾¹é¨åè¢«å¸ç¼27å´è®¾ï¼é¨åä¼¸åºå¸ç¼27ï¼ä»èè½å¤å¯¹ç·ç 5è¿è¡åç¡®çå®ä½ååéï¼è¿èè½å¤ä¿è¯å®æè´´è®¾åç·ç 5ä¹é´çç¼éçåååº¦ãå¨æ¬å®æ½ä¾ä¸­ï¼çç©ºå¸éä»¶2ä»

å

æ¬ä¸çç©ºå¸çXï¼çç©ºå¸éä»¶2çç¬¬äºè¡¨é¢22çå¨ç¼å¸è®¾æå¸ç¼27ï¼å½å¤ä¸ªçç©ºå¸éä»¶2ç´§å¯æåå¨æ¯ææ¿1ä¸æ¶ï¼ç¸é»çç©ºå¸éä»¶2ä¹é´çå¸ç¼27å°ç·ç 5åéå¼ãPlease refer to Fig. 2, Fig. 3 and Fig. 5, the second surface 22 of the vacuum absorber 2 is protruded with a flange 27 for positioning and separating the ceramic tiles 5, the side of the ceramic tile 5 is surrounded by the flange 27, and part of it protrudes. The flange 27 can accurately locate and separate the ceramic tiles 5, thereby ensuring the uniformity of the gap between the ceramic tiles 5 after the installation is completed. In this embodiment, the vacuum absorber 2 only includes a vacuum chuck X, and a flange 27 protrudes from the periphery of the second surface 22 of the vacuum absorber 2. When a plurality of vacuum absorbers 2 are closely arranged on the support plate 1 , the flanges 27 between adjacent vacuum suction parts 2 separate the tiles 5 .

è¯·åé

å¾1è³å¾3åå¾5ï¼çç©ºå¸éä»¶2çç¬¬äºè¡¨é¢22å¸è®¾å½¢æè³å°ä¸çç©ºå¸çXçå¯å°å28ï¼å¯å°å28ç¯ç»ç¸åºçå¸éæ§½24ï¼èæ­¤ï¼è½å¤å¯¹ç¸åºç·ç 5è¿è¡æ´å å¯é çå¸éï¼ç¹å«æ¯å¨ç·ç 5çå¤è¡¨é¢ç²ç³åº¦è¾å¤§çæ

åµä¸ãè¾ä½³å°ï¼å¯å°å28ä¸ºå¯å°åºåãè¾ä½³å°ï¼çç©ºå¸éä»¶2çç¬¬äºè¡¨é¢22å½¢ææè³å°ä¸çç©ºå¸çXçç¯æ§½29ï¼ç¯æ§½29ç¯ç»å¸éæ§½24ï¼å¯å°å28å¸è®¾å¨ç¯æ§½29ï¼èæ­¤ï¼å½ç¸åºç·ç 5å¸éå¨ç¬¬äºè¡¨é¢22æ¶ï¼å¯å°å28è½å¤è¢«æ¤åå

¥ç¯æ§½29ãå¨æ¬å®æ½ä¾ä¸­ï¼å¯å°å28ä¸ºåç¯å½¢ï¼ä½ä¸åºä»¥æ­¤ä¸ºéï¼ä¾å¦ï¼è¿å¯ä»¥æ¯æ¹ç¯å½¢ç­ãReferring to Fig. 1 to Fig. 3 and Fig. 5, the second surface 22 of the vacuum absorber 2 is convexly provided with a sealing ring 28 forming at least one vacuum suction cup X, and the sealing ring 28 surrounds the corresponding adsorption groove 24, whereby the corresponding ceramic tile can be 5 for more reliable adsorption, especially in the case of rougher outer surfaces of tiles 5 . Preferably, the sealing ring 28 is a sealing spine. Preferably, the second surface 22 of the vacuum absorber 2 is formed with an annular groove 29 of at least one vacuum chuck X, the annular groove 29 surrounds the adsorption groove 24, and the sealing ring 28 protrudes from the annular groove 29, thereby, when the corresponding ceramic tile 5 When adsorbed on the second surface 22 , the sealing ring 28 can be squeezed into the ring groove 29 . In this embodiment, the sealing ring 28 is a circular ring, but it should not be limited thereto, for example, it can also be a square ring or the like.

è¯·åé

å¾4ï¼è¾ä½³å°ï¼æ½æ°å­26ä¸ºéå­ï¼èæ­¤è½å¤ä¿è¯éè¿ä¸ä¸ªçç©ºæ³µåæ¶ä¸ºå¤ä¸ªç·ç 5æä¾è¶³å¤çå¸éåãéæ°æ§½23è³å°åä¸ä¾§è´¯ç©¿çç©ºå¸éä»¶2ï¼ä»¥ä¸ç¸é»æåççç©ºå¸éä»¶2çéæ°æ§½23è¿éï¼èæ­¤è½å¤ä½¿å¾å¤ä¸ªç´§å¯æåççç©ºå¸éä»¶2çéæ°æ§½23ç¸äºè¿éãå¨æ¬å®æ½ä¾ä¸­ï¼çç©ºå¸éä»¶2åç©å½¢æ¿ç¶ï¼éæ°æ§½23è³å°åä¸ä¾§è´¯ç©¿çç©ºå¸éä»¶2ï¼ä»¥ä¸ç¸é»æåççç©ºå¸éä»¶2çéæ°æ§½23è¿éï¼å

·ä½å°ï¼éæ°æ§½23åºæ¬ååå­ç¶ï¼å

æ¬ä½äºä¸­é´çä¸­é´é¨231åç±ä¸­é´é¨231å¾åå»¶ä¼¸çåä¸ªåæ¯é¨232ï¼æ½æ°å­26å½¢æå¨ä¸­é´é¨231çä¸­å¿å¤ï¼å¨å¤ä¸ªç¸äºç´§å¯æåççç©ºå¸éä»¶2ä¸­ï¼é¨åçç©ºå¸éä»¶2çåä¸ªåæ¯é¨232çåå¤è´¯ç©¿å

¶ç¸åºä¾§å£ï¼é¨åçç©ºå¸éä»¶2çåä¸ªåæ¯é¨232çå

¶ä¸­ä¸ä¸ªåå¤è´¯ç©¿å

¶ç¸åºä¾§å£ï¼é¨åçç©ºå¸éä»¶2çåä¸ªåæ¯é¨232çå

¶ä¸­ä¸¤ä¸ªåå¤è´¯ç©¿å

¶ç¸åºä¾§å£ï¼å¨å¤ä¸ªçç©ºå¸éä»¶2ç´§å¯æåå½¢æçç©ºå¸éä»¶ç»ååï¼çç©ºå¸éä»¶2çåå¤è´¯ç©¿çåæ¯é¨232ä¸ç¸é»æåççç©ºå¸éä»¶2çåå¤è´¯ç©¿çå¯¹åºåæ¯é¨232è¿éä»¥ä½¿çç©ºå¸éä»¶ç»åä¸æ¯ææ¿1ä¹é´å½¢æå¯å°çæ»éæ°æ§½ï¼å¼å¾æ³¨æçæ¯ï¼éæ°æ§½å¯ä»¥æ¯åç§ä¸åçå½¢ç¶ãæé ï¼åªè¦å¤ä¸ªçç©ºå¸éä»¶çéæ°æ§½è½å¤ç¸äºè¿éãPlease refer to FIG. 4 , preferably, the air pumping holes 26 are pinholes, thereby ensuring that a vacuum pump can provide sufficient adsorption force for multiple ceramic tiles 5 at the same time. The ventilation groove 23 penetrates through the vacuum adsorbent 2 at least one side to communicate with the ventilation grooves 23 of the adjacently arranged vacuum adsorbents 2 , thereby allowing the ventilation grooves 23 of a plurality of closely arranged vacuum adsorbents 2 to communicate with each other. In this embodiment, the vacuum adsorbent 2 is in the shape of a rectangular plate, and the vent groove 23 penetrates the vacuum adsorbent 2 at least to one side, so as to communicate with the vent groove 23 of the adjacently arranged vacuum adsorbent 2, specifically, the vent groove 23 It is basically in the shape of a cross, including a middle part 231 in the middle and four branch parts 232 radially extending from the middle part 231. Among them, the four branch portions 232 of the partial vacuum adsorbent 2 all go outward through their corresponding side walls, three of the four branch portions 232 of the partial vacuum adsorbent 2 penetrate outward through their corresponding side walls, and the partial vacuum adsorbent 2 Two of the four branches 232 of the vacuum absorber 2 penetrate outward through their corresponding side walls. After a plurality of vacuum absorbers 2 are closely arranged to form a combination of vacuum absorbers, the outwardly penetrating branch 232 of the vacuum absorber 2 and the adjacent arrangement The corresponding branch portion 232 penetrating outwards of the vacuum absorber 2 communicates so that a sealed general ventilation groove is formed between the vacuum absorber assembly and the support plate 1. It is worth noting that the ventilation groove can be in various shapes and configurations , as long as the ventilation slots of the plurality of vacuum adsorption parts can communicate with each other.

è¯·åé

å¾1ï¼è¾ä½³å°ï¼æ¯æå1å¼è®¾æä¸å

¶ä¸­ä¹ä¸çç©ºå¸éä»¶2çéæ°æ§½23è¿éçè´¯ç©¿çæ½æ°éé11ï¼çç©ºæ³µçæ½æ°ç«¯å£è®¾ç½®å¨æ½æ°éé11ãPlease refer to FIG. 1 , preferably, the support block 1 is provided with a through air suction channel 11 communicating with the air groove 23 of one of the vacuum absorbing components 2 , and the air suction port of the vacuum pump is set on the air suction channel 11 .

ä¸é¢ä»¥æ¬å®ç¨æ°åå

·ä½å®æ½ä¾ä¸ºä¾æè¿°ç·ç è´´è®¾è£

ç½®çä¸ç§ä½¿ç¨è¿ç¨ãA use process of the tile sticking device will be described below by taking the specific embodiment of the utility model as an example.

é¦å

ï¼å°å¤ä¸ªçç©ºå¸éä»¶2ç´§å¯æåå°æ¾ç½®å¨æ¯æå1ä¸ï¼å

¶ä¸­ä¸ä¸ªçç©ºå¸éä»¶2çéæ°æ§½23çä¸­é´é¨231ä¸æ¯æå1çæ½æ°éé11å¯¹åºï¼å¤ä¸ªçç©ºå¸éä»¶2ä¸æ¯æå1ä¹é´å¯ä»¥éè¿è¶æ°´æè

å

¶ä»åºå®æ¹å¼æ¥å¢å¼ºå

¶é´çç»ååï¼ç¶åå°å¤ä¸ªç·ç 5ç¸åºçæ¾ç½®å¨å¯¹åºççç©ºå¸çXï¼æ¥çå©ç¨çç©ºæ³µè¿è¡æ½æ°ï¼ä½¿å¾ç·ç 5è¢«ç¨³åºå¸éå¨å¯¹åºççç©ºå¸çXä¸ï¼ç±äºå¤ä¸ªçç©ºå¸éä»¶2çéæ°æ§½23ç¸äºè¿éï¼ä½¿å¾éè¿ä¸ä¸ªçç©ºæ³µå³å¯å®ç°å¯¹å¤ä¸ªçç©ºå¸éä»¶2è¿è¡æ½æ°ï¼æ¥çï¼éè¿èªå¨æä½è®¾å¤å°ä¸¤æ¯æå1åå

¶ä¸çå¤ä¸ªçç©ºå¸éä»¶2ç±æ°´å¹³ä½ç½®è½¬åä¸ºç«ç´ä½ç½®å¹¶æ ¹æ®éè¦æåå¢ä½çååº¦é´éæ¾ç½®ï¼æ¥çï¼å¨åå«å¸éå¨ä¸¤ç·ç è´´è®¾è£

ç½®çä¸¤é¢ç·ç 5ä¹é´æ³¨æµæåå¢ä½ï¼ä½¿å¾å³ä½¿æ¯è¾å¤§åçç·ç 5ä¹å¯ä»¥ç¢åºå°ç²æ£å¨å¢ä½ä¸ï¼ä¸ä¼åºç°ç·ç æè½ç ¸å°äººçæ

åµãå¼å¾æ³¨æçæ¯ï¼å¨æ½çç©ºåï¼çç©ºå¸éä»¶2å¯ä»¥éè¿éæ°æ§½23äº§çççç©ºå¸åèå¸éå¨æ¯æå1ä¸ï¼ä»èä½¿å¾å¨è½¬åä¸ºç«ç´ä½ç½®æ¶ï¼çç©ºå¸éä»¶2ä»ç¶å¯ä»¥ç»åå¨æ¯æå1ï¼æ éé¢å¤çåºå®è®¾ç½®ï¼å½ç¶ï¼ä¸ºäºå¢å¼ºå çç©ºå¸éä»¶2ä¸æ¯æå1ä¹é´çç»ååï¼ä¹å¯ä»¥é¢å

éè¿è¶æ°´æè

å

¶ä»åºå®æ¹å¼æ¥ç¨³åºç»åçç©ºå¸éä»¶2äºæ¯æå1ä¸ãFirst, a plurality of vacuum absorbers 2 are closely arranged on the support block 1, wherein the middle part 231 of the ventilation groove 23 of one vacuum absorber 2 corresponds to the suction channel 11 of the support block 1, and the plurality of vacuum absorbers 2 Glue or other fixing methods can be used to enhance the bonding force between the support block 1, and then a plurality of tiles 5 are placed on the corresponding vacuum chuck X, and then the vacuum pump is used to pump air, so that the tiles 5 are firmly adsorbed on the On the corresponding vacuum chuck X, since the vent grooves 23 of multiple vacuum absorbers 2 communicate with each other, a vacuum pump can be used to evacuate multiple vacuum absorbers 2, and then, the two support blocks 1 are moved by automatic operation equipment. The multiple vacuum absorbers 2 on it are converted from a horizontal position to a vertical position and placed at intervals according to the thickness of the formed wall, and then, the grouting formed wall is formed between the two tiles 5 that are respectively adsorbed on the two tile sticking devices body, so that even larger pieces of tiles 5 can be firmly glued on the body of the wall, and the situation that the tiles will not fall and hit people will not occur. It is worth noting that, after vacuuming, the vacuum absorber 2 can be adsorbed on the support block 1 by the vacuum suction generated by the vent groove 23, so that when it is transformed into a vertical position, the vacuum absorber 2 can still be combined with the support block 1. The block 1 does not require additional fixing. Of course, in order to enhance the bonding force between the vacuum absorber 2 and the support block 1, the vacuum absorber 2 can be firmly combined with the support block 1 by glue or other fixing methods in advance.

ä¸ç°æææ¯ç¸æ¯ï¼æ¬å®ç¨æ°åçç·ç è´´è®¾è£

ç½®éè¿å°å¤ä¸ªçç©ºå¸éä»¶ç´§å¯æåå¨æ¯æåä¸ä½¿å¾å¤ä¸ªçç©ºå¸éä»¶çéæ°æ§½ç¸äºè¿éæè

å¨çç©ºå¸éä»¶ä¸ä¸ä½æåå¤ä¸ªçç©ºå¸çå¹¶ä½¿å¾çç©ºå¸éä»¶çéæ°æ§½è¿éå¤ä¸ªçç©ºå¸ççæ½æ°å­ï¼ä½¿å¾å¨åªä½¿ç¨ä¸ä¸ªçç©ºæ³µçæ

åµä¸ï¼è½åæ¶å¸éå¤ä¸ªç·ç è¿è¡è´´è®¾ï¼æææåäºè´´è®¾ç·ç çæçï¼èä¸ç±äºå¤ä¸ªç·ç æ¯å¸éå¨åä¸çç©ºå¸éä»¶çç¬¬äºè¡¨é¢æè

å¤ä¸ªçç©ºå¸éä»¶çç¬¬äºè¡¨é¢ï¼å æ­¤ï¼å¤ä¸ªç·ç ä¹é´ç¸äºå¹³é½ï¼ä»èææä¿è¯å¢é¢çæ´ä½å¹³æ´åº¦ï¼å¦å¤ï¼å¨æ½çç©ºåï¼çç©ºå¸éä»¶å¯ä»¥éè¿éæ°æ§½äº§çççç©ºå¸åèå¸éå¨æ¯æåä¸ï¼å¨è¿è¡ç·ç è´´è®¾æ¶ï¼çç©ºå¸éä»¶ä»ç¶å¯ä»¥ç»åå¨æ¯æåï¼æ éé¢å¤çåºå®è®¾ç½®ãCompared with the prior art, the tile laying device of the present utility model closely arranges a plurality of vacuum absorbers on the support block so that the ventilation grooves of the plurality of vacuum absorbers communicate with each other or integrally forms a plurality of vacuum absorbers on the vacuum absorber. The suction cup also connects the ventilation groove of the vacuum absorber with the air holes of multiple vacuum suction cups, so that when only one vacuum pump is used, multiple tiles can be adsorbed at the same time for laying, which effectively improves the efficiency of laying tiles; A ceramic tile is adsorbed on the second surface of the same vacuum adsorption piece or the second surface of multiple vacuum adsorption pieces, therefore, the multiple tiles are flush with each other, thereby effectively ensuring the overall flatness of the wall surface; Finally, the vacuum absorber can be adsorbed on the support block through the vacuum suction generated by the ventilation groove. When tiles are laid, the vacuum absorber can still be combined with the support block without additional fixing settings.

ä»¥ä¸ææ­é²çä»

ä¸ºæ¬å®ç¨æ°åçè¾ä½³å®ä¾èå·²ï¼å½ç¶ä¸è½ä»¥æ­¤æ¥éå®æ¬å®ç¨æ°åä¹æå©èå´ï¼å æ­¤ä¾æ¬å®ç¨æ°åç³è¯·ä¸å©èå´æä½çç­åååï¼ä»å±äºæ¬å®ç¨æ°åææ¶µççèå´ãæ¯å¦ï¼å¨å

·ä½å®æ½ä¾ä¸­ï¼åä¸ªçç©ºå¸çåä¸ºå°ºå¯¸ç¸åçæ­£æ¹å½¢ä¸åå·¥æ´çç©éµæåï¼ä½ï¼åä¸ªçç©ºå¸çä¹é´ä¹ä¸éäºç©éµæåï¼æ ¹æ®ç·ç æç æ¹å¼çä¸åï¼åä¸ªçç©ºå¸çä¹é´ä¹å¯ä»¥æ¯å¯¹åºçå

¶ä»åç§æåæ¹å¼ï¼æ¯å¦ï¼å½ç·ç ä¹é´ä¸ºäº¤éæç æ¹å¼æ¶ï¼åä¸ªçç©ºå¸çä¹é´å¯ä»¥ä»¥å¯¹åºçäº¤éæ¹å¼è¿è¡æå(å

æ¬åä¸ªçç©ºå¸çä¸ºåç¬ä¸ªä½æè

ä¸ä½æå)ï¼åªè¦åä¸ªçç©ºå¸çä¹é´ç¸äºç´§å¯æåå¨ä¸èµ·å³å¯ãå¨å

¶ä»å®æ½ä¾ä¸­ï¼æ ¹æ®éè¦å¸éç·ç çä¸åï¼çç©ºå¸çä¹å¯ä»¥æ¯å

¶ä»åç§å½¢ç¶åå°ºå¯¸ï¼èä¸ï¼åä¸ªçç©ºå¸çå¯ä»¥æ¯ç¸åçå½¢ç¶ãå°ºå¯¸ï¼ä¹å¯ä»¥æ¯ä¸åçå½¢ç¶ãå°ºå¯¸(å

æ¬åä¸ªçç©ºå¸çä¸ºåç¬ä¸ªä½æè

ä¸ä½æå)ï¼åªè¦åä¸ªçç©ºå¸çä¹é´è½å¤æ»¡è¶³ç¸äºç´§å¯æåå¨ä¸èµ·å³å¯ãå¦å¤ï¼æ¬å®ç¨æ°åçç·ç è´´è®¾è£

ç½®å¹¶ä¸éäºæ¬å®æ½ä¾ä¸­çä½¿ç¨æ¹å¼ï¼äº¦éç¨äºå¨å¢ä½æååå°ç·ç è´´å¨å¢é¢ä¸ï¼è¿å¯ä»¥ç¨æ¥è´´è®¾å°é¢ç ç­ï¼èä¸ï¼å¹¶ä¸å±éäºç·ç çè´´è®¾ãWhat is disclosed above is only a preferred example of the utility model, and of course the scope of rights of the utility model cannot be limited with this. Therefore, equivalent changes made according to the patent scope of the utility model still belong to the scope covered by the utility model . For example, in a specific embodiment, each vacuum suction cup is a square with the same size and is arranged in a neat matrix, but each vacuum suction cup is not limited to a matrix arrangement. It can also be various other corresponding arrangements. For example, when the tiles are arranged in a staggered manner, the vacuum suction cups can be arranged in a corresponding staggered manner (including each vacuum suction cup is a separate entity or integrally formed), As long as the vacuum suction cups are closely arranged together. In other embodiments, the vacuum suction cups can also be in other various shapes and sizes according to the need to absorb tiles, and each vacuum suction cup can be the same shape, size, or different shapes and sizes (including various vacuum suction cups). The suction cup is a single body or integrally formed), as long as the various vacuum suction cups can be closely arranged together. In addition, the ceramic tile sticking device of the present invention is not limited to the use method in this embodiment, and is also suitable for sticking ceramic tiles on the wall after the wall is formed, and can also be used to stick floor tiles, etc.; and, and Not limited to tile placement.

---

Generated by IPtorch. Verify legal conclusions against the official publication.
