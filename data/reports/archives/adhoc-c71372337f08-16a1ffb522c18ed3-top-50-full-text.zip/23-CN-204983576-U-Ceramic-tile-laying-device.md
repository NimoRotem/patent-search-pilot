# 23. Ceramic tile laying device

- **Archive rank:** 23 of 50
- **Publication:** [CN-204983576-U](https://patents.google.com/patent/CN204983576U/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/055117958/publication/CN204983576U?q=pn%3DCN204983576U)
- **Publication date:** 2016-01-20
- **Filing date:** 2015-07-23
- **Earliest priority:** 2015-07-23
- **Family:** 55117958
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** LI BAOYING

## Abstract

The utility model discloses a ceramic tile laying device, it belongs to the building decoration field. It mainly includes the ceramic tile support frame, and the front of ceramic tile support frame is equipped with the peaceful put one&#39;s child in a boarding nursery pole of vacuum chuck, and the back of ceramic tile support frame is equipped with the vacuum pump and strikes hammer, vacuum chuck and vacuum pump connection, ceramic tile support frame bottom is equipped with the transversal joint sighting rod, be equipped with buffer spring between vacuum chuck and the ceramic tile support frame. The utility model discloses a polylith ceramic tile is laid simultaneously, subsides the tamp simultaneously, and the ceramic tile surfacing laid, even, the no hollowing in gap. The utility model discloses laying of mainly used floor tile and wall tile.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-204983576-U/pdf000.png)

![Sketch 1 for CN-204983576-U](https://nimo.iptorch.com/refdrawing/CN-204983576-U/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-204983576-U/pdf001.png)

![Sketch 2 for CN-204983576-U](https://nimo.iptorch.com/refdrawing/CN-204983576-U/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/CN-204983576-U/pdf002.png)

![Sketch 3 for CN-204983576-U](https://nimo.iptorch.com/refdrawing/CN-204983576-U/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/CN-204983576-U/pdf003.png)

![Sketch 4 for CN-204983576-U](https://nimo.iptorch.com/refdrawing/CN-204983576-U/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/CN-204983576-U/pdf004.png)

![Sketch 5 for CN-204983576-U](https://nimo.iptorch.com/refdrawing/CN-204983576-U/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/CN-204983576-U/pdf005.png)

![Sketch 6 for CN-204983576-U](https://nimo.iptorch.com/refdrawing/CN-204983576-U/pdf005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/CN-204983576-U/pdf006.png)

![Sketch 7 for CN-204983576-U](https://nimo.iptorch.com/refdrawing/CN-204983576-U/pdf006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/CN-204983576-U/pdf007.png)

![Sketch 8 for CN-204983576-U](https://nimo.iptorch.com/refdrawing/CN-204983576-U/pdf007.png)

## Claims

### Claim 1 (independent)

a tile lying device, it is characterized in that: comprise ceramic tile bracing frame (1), the peaceful bar that puts one's child in a boarding nursery (3) of vacuum cup (2) is provided with before ceramic tile bracing frame (1), be provided with vacuum pump (6) and knock hammer (5) after ceramic tile bracing frame (1), vacuum cup (2) is connected with vacuum pump (6).

### Claim 2

tile lying device according to claim 1, is characterized in that: described ceramic tile bracing frame (1) bottom is provided with vertical masonry joint mark post (4).

### Claim 3

tile lying device according to claim 2, is characterized in that: be provided with buffer spring (7) between described vacuum cup (2) and ceramic tile bracing frame (1).

### Claim 4

tile lying device according to any one of claim 1 to 3, it is characterized in that: also comprise bearing base (8), the side of bearing base (8) and the side of ceramic tile bracing frame (1) hinged, bearing base (8) is provided with stretching device (9), and expansion link and the ceramic tile bracing frame (1) of stretching device (9) are hinged.

### Claim 5

tile lying device according to claim 4, is characterized in that: described bearing base (8) bottom is provided with bearing column (12), and bearing column (12) adopts fluid pressure type structure.

### Claim 6

tile lying device according to claim 5, is characterized in that: described bearing column (12) bottom is provided with movable pulley (11).

### Claim 7

tile lying device according to claim 4, is characterized in that: be provided with back-moving spring (10) between described bearing base (8) and ceramic tile bracing frame (1).

### Claim 8

tile lying device according to any one of claim 1 to 3, it is characterized in that: also comprise fork truck elevating mechanism (18), fork truck elevating mechanism (18) is provided with telescopic arm (15), telescopic arm (15) is connected with ceramic tile bracing frame (1) bottom, ceramic tile bracing frame (1) bottom is provided with and turns to rope (13), turns to rope (13) to be connected with the power set (19) on fork truck elevating mechanism (18) by assembly pulley (14).

### Claim 9

tile lying device according to claim 8, is characterized in that: described telescopic arm (15) comprises bar (16) and axle (17), and axle (17) is rotatable.

## Full description

Description

Tile lying device

Technical field

The utility model belongs to building finishing field, specifically, particularly relates to a kind of tile lying device.

Background technology

The laying of building floor brick and walltile for a long time is all completed by artificial manual operations, first hand lay-up wants unwrapping wire, then the laying of a piece a piece manually, stickup is relied on, its labour intensity is large, inefficiency, and the planeness of ceramic tile, gap the uniformity uneven, hollowing rate is higher, workmanship be difficult to ensure.Although there are some tile paving machines on the market, these tile paving machines, have not fundamentally solved the problem that artificial monolithic lays ceramic tile, and do not ensure planeness, the gap uniformity and the hollowing rate that ceramic tile is laid yet yet.

Utility model content

The purpose of this utility model is to overcome above-mentioned defect, provides a kind of tile lying device, the arrangement achieves polylith ceramic tile and lays simultaneously, the compacting of sedimentation simultaneously, and the ceramic tile surface laid is smooth, gap even, without hollowing.

Described tile lying device, comprises ceramic tile bracing frame, is provided with the peaceful bar that puts one's child in a boarding nursery of vacuum cup before ceramic tile bracing frame, and be provided with vacuum pump after ceramic tile bracing frame and knock hammer, vacuum cup is connected with vacuum pump.

Further, vertical masonry joint mark post is provided with bottom described ceramic tile bracing frame.

Further, buffer spring is provided with between described vacuum cup and ceramic tile bracing frame.

Further, also comprise bearing base, the side of bearing base and the side of ceramic tile bracing frame hinged, bearing base is provided with stretching device, and expansion link and the ceramic tile bracing frame of stretching device are hinged.

Further, be provided with bearing column bottom described bearing base, bearing column adopts fluid pressure type structure.

Further, movable pulley is provided with bottom described bearing column.

Further, back-moving spring is provided with between described bearing base and ceramic tile bracing frame.

Further, also comprise fork truck elevating mechanism, fork truck elevating mechanism is provided with telescopic arm, and telescopic arm is connected with bottom ceramic tile bracing frame, is provided with and turns to rope bottom ceramic tile bracing frame, turns to rope to be connected with the power set on fork truck elevating mechanism by assembly pulley.

Further, described telescopic arm comprises bar and axle, and axle is rotatable.

Compared with prior art, the beneficial effects of the utility model are:

1, achieve polylith ceramic tile by vacuum cup and vacuum pump to lay simultaneously, and gap between ceramic tile evenly, entirety is more smooth, knocks hammer and achieves polylith ceramic tile sedimentation simultaneously compacting, avoid the generation of hollowing phenomenon;

2, ensure that the ceramic tile surface planeness after laying is consistent by smooth pressure pin, the verticality of ceramic tile after vertical masonry joint mark post ensure that and lays;

3, make ceramic tile bracing frame realize the upset of level to vertical direction by bearing base and stretching device, thus realize the laying of furring tile;

4, by fork truck elevating mechanism, turn to rope and assembly pulley to realize lifting and the upset of ceramic tile bracing frame, thus realize the laying of floor ceramic tile;

5, the axle of telescopic arm can rotate, thus drives the rotation of ceramic tile bracing frame, the adjustment in be more convenient for ceramic tile bracing frame level and direction.

Accompanying drawing explanation

Fig. 1 is the front view of ceramic tile bracing frame;

Fig. 2 is the left view of ceramic tile bracing frame;

Fig. 3 is the structural representation of embodiment three;

Fig. 4 is the structural representation of embodiment four.

In figure, 1, ceramic tile bracing frame; 2, vacuum cup; 3, smooth pressure pin; 4, vertical masonry joint mark post; 5, hammer is knocked; 6, vacuum pump; 7, buffer spring; 8, bearing base; 9, stretching device; 10, back-moving spring; 11, movable pulley; 12, bearing column; 13, rope is turned to; 14, assembly pulley; 15, telescopic arm; 16, bar; 17, axle; 18, fork truck elevating mechanism; 19, power set.

Detailed description of the invention

Below in conjunction with accompanying drawing, the utility model is described in further detail:

Embodiment one: as depicted in figs. 1 and 2, tile lying device, comprises ceramic tile bracing frame 1, is provided with the peaceful bar 3 that puts one's child in a boarding nursery of vacuum cup 2 before ceramic tile bracing frame 1, and be provided with vacuum pump 6 after ceramic tile bracing frame 1 and knock hammer 5, vacuum cup 2 is connected with vacuum pump 6.

Embodiment two: as depicted in figs. 1 and 2, is provided with vertical masonry joint mark post 4 bottom described ceramic tile bracing frame 1; Be provided with buffer spring 7 between described vacuum cup 2 and ceramic tile bracing frame 1, other is identical with embodiment one.

Embodiment three: as shown in Figure 3, also comprises bearing base 8, and side and the ceramic tile bracing frame 1 of bearing base 8 are hinged, and bearing base 8 is provided with stretching device 9, and expansion link and the ceramic tile bracing frame 1 of stretching device 9 are hinged; Back-moving spring 10 is provided with between described bearing base 8 and ceramic tile bracing frame 1; Be provided with bearing column 12 bottom described bearing base 8, bearing column 12 adopts hydraulic oil cylinder type structure, and be convenient to bearing base 8 and adjust level, be provided with movable pulley 11 bottom bearing column 12, other is identical with embodiment two.

During use, the utility model is pushed away the room being put into and laying, ceramic tile is positioned on vacuum cup 2, bottom row's ceramic tile is made to be close to vertical masonry joint mark post 4, open vacuum pump 6, make ceramic tile under the suction of vacuum cup 2, absorption is close to smooth pressure pin 3, second row ceramic tile is close to first row ceramic tile and sucks as stated above, circulation like this, until ceramic tile bracing frame 1 is paved with ceramic tile, then stretching device 9 is started, the expansion link of stretching device 9 stretches out, by ceramic tile bracing frame 1 jack-up to vertical state, back-moving spring 10 stretches, by movable pulley 11, artificial light mobile the utility model is near metope, and regulate ceramic tile bracing frame 1 by bearing column 12, make ceramic tile bracing frame 1 both sides maintenance level, the level of ceramic tile bracing frame 1 to be determined and vertical direction all errorless after, finally by good for ceramic tile bracing frame 1 integral reinforcing, then casting cement, open simultaneously and knock hammer 5, buffer spring 7 plays cushioning effect, be not damaged to protect ceramic tile, after cement is stiff, remove reinforcement feature, and close vacuum pump 6, removed by the utility model, complete the laying of furring tile, the expansion link of stretching device 9 shrinks, and back-moving spring 10 resets.

Embodiment four: also comprise fork truck elevating mechanism 18, fork truck elevating mechanism 18 is provided with telescopic arm 15, telescopic arm 15 is connected with bottom ceramic tile bracing frame 1, is provided with and turns to rope 13 bottom ceramic tile bracing frame 1, turns to rope 13 to be connected with the power set 19 on fork truck elevating mechanism 18 by assembly pulley 14; Described telescopic arm 15 comprises bar 16 and axle 17, and axle 17 is rotatable; Other is identical with embodiment two.

During use, after ground to be laid is flattened, the machine is pushed away and is put into appropriate location, ceramic tile bracing frame 1 is raised by fork truck elevating mechanism 18, the expansion link of telescopic arm 15 is stretched out, ceramic tile bracing frame 1 is made to have enough adjustment spaces, then as described in embodiment three, first ceramic tile is paved with ceramic tile bracing frame 1, and by vacuum cup 2, absorption is close to smooth pressure pin 3 and vertical masonry joint mark post 4, start power set 19, power set 19 drive and turn to rope 13 to move, make ceramic tile bracing frame 1 integral level, rotatable shaft 17 simultaneously, thus regulate level and the direction of ceramic tile bracing frame 1, and fixed by bar 16, drop to Land leveling finally by fork truck elevating mechanism 18 to put well, and hammer 5 is knocked in unlatching, complete the laying of floor ceramic tile.

---

Generated by IPtorch. Verify legal conclusions against the official publication.
