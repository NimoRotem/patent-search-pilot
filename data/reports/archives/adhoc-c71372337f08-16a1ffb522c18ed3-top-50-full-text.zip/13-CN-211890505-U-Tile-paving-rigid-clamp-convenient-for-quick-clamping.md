# 13. Tile paving rigid clamp convenient for quick clamping

- **Archive rank:** 13 of 50
- **Publication:** [CN-211890505-U](https://patents.google.com/patent/CN211890505U/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/073294646/publication/CN211890505U?q=pn%3DCN211890505U)
- **Publication date:** 2020-11-10
- **Filing date:** 2019-12-30
- **Earliest priority:** 2019-12-30
- **Family:** 73294646
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus

## Parties

- **Applicant / assignee:** XUZHOU JIUYUAN STEEL STRUCTURE CO LTD

## Abstract

The utility model discloses a ceramic tile paving rigid clamp convenient for quick clamping, which comprises a handle, wherein the left side of the front surface of the handle is sequentially provided with a pressure gauge, an indicator light and a start button, the right side of the handle is clamped with a battery cover, the left side of the inner cavity of the handle is provided with a PLC controller through a bolt, the rear surface of the inner cavity of the handle is provided with a vacuum pump through a bolt, the right side of the inner cavity of the handle is fixedly provided with a battery, the rear parts of the left side and the right side of the handle are fixedly connected with a fixed seat through a mounting bolt, the rear side of the fixed seat is integrally formed with a shell, the inner cavity of the shell is sleeved with a rubber suction cup, the central position of the front side of the rubber suction cup is provided with an air exhaust hole, the air exhaust hole is communicated with the fixed seat, the utility model discloses a it is strong to have adsorption effect, the comprehensive effect of the operation of being convenient for.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-211890505-U/000.png)

![Sketch 1 for CN-211890505-U](https://nimo.iptorch.com/refdrawing/CN-211890505-U/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-211890505-U/001.png)

![Sketch 2 for CN-211890505-U](https://nimo.iptorch.com/refdrawing/CN-211890505-U/001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/CN-211890505-U/002.png)

![Sketch 3 for CN-211890505-U](https://nimo.iptorch.com/refdrawing/CN-211890505-U/002.png)

## Claims

### Claim 1 (independent)

Claims (5) The utility model provides a ceramic tile paves pastes rigid fixture convenient to quick clamp is got, includes handle (1), its characterized in that: the novel vacuum pump is characterized in that a pressure gauge (3), an indicator lamp (6) and a start button (2) are sequentially installed on the left side of the front surface of the handle (1), a battery cover (15) is clamped on the right side of the handle (1), a PLC (programmable logic controller) (10) is installed on the left side of the inner cavity of the handle (1) through a bolt, a vacuum pump (9) is installed on the rear surface of the inner cavity of the handle (1) through a bolt, a battery (7) is fixedly installed on the right side of the inner cavity of the handle (1), a fixing seat (12) is fixedly connected to the rear sides of the left side and the right side of the handle (1) through a mounting bolt (13), a shell (4) is integrally formed on the rear side of the fixing seat (12), a rubber suction cup joints a rubber suction cup (5) in the inner cavity of the shell (4), a suction, the utility model discloses a PLC controller, including exhaust hole (14), preceding side fixedly connected with exhaust tube (8) of exhaust hole (14), the left surface of vacuum pump (9) has exhaust tube (8) through the buckle joint, the inner chamber of exhaust hole (14) is pegged graft and is had pressure sensor (11), exhaust hole (14) and exhaust tube (8) looks fixed connection, start button (2), manometer (3), pilot lamp (6), battery (7), vacuum pump (9), pressure sensor (11) all pass through wire and PLC controller (10) electric connection.

### Claim 2

A rigid tile-laying jig according to claim 1, characterised in that: the back side surface of the handle (1) is provided with a frosted anti-skid layer.

### Claim 3

A rigid tile-laying jig according to claim 1, characterised in that: the vacuum pump (9) is a micro vacuum pump.

### Claim 4

A rigid tile-laying jig according to claim 1, characterised in that: the battery (7) corresponds to the position of the battery cover (15).

### Claim 5

A rigid tile-laying jig according to claim 1, characterised in that: the indicator lamp (6) is an LED lamp.

## Full description

**[p0001]**

Description Tile paving rigid clamp convenient for quick clamping Technical Field The utility model relates to a decoration and fitment technical field specifically is a ceramic tile is spread and is pasted rigid fixture convenient to quick clamp is got. Background The tile paving can be said to be the most common project in home decoration, and the tile paving seems simple and is a particularly challenging technology. If the bad ceramic tile of subsides can drop, but also can influence the life of ceramic tile, spread the ceramic tile and paste and often need carry the ceramic tile. At the house ornamentation processes such as laying of floor or ceramic tile, current anchor clamps do not have better centre gripping effect to the ceramic tile, the phenomenon that drops often can appear to the efficiency of centre gripping is lower in construction operation process, and the quick clamp of getting of being not convenient for is got, consequently needs a urgent need to develop a ceramic tile shop plaster rigidity anchor clamps of being convenient for get fast.

### Summery Of The Utility Model

**[p0002]**

An object of the utility model is to provide a ceramic tile is spread and is pasted rigid fixture convenient to quick clamp is got to solve the special ceramic tile of intelligent decoration construction equipment that proposes among the above-mentioned background and spread the problem of pasting anchor clamps centre gripping effect poor, the lower class characteristic of efficiency. In order to achieve the above object, the utility model provides a following technical scheme: a ceramic tile paving rigid clamp convenient for quick clamping comprises a handle, wherein a pressure gauge, an indicator light and a start button are sequentially installed on the left side of the front surface of the handle, a battery cover is clamped on the right side of the handle, a PLC (programmable logic controller) is installed on the left side of an inner cavity of the handle through a bolt, a vacuum pump is installed on the rear surface of the inner cavity of the handle through a bolt, a battery is fixedly installed on the right side of the inner cavity of the handle, a fixed seat is fixedly connected to the rear sides of the left side and the right side of the handle through a mounting bolt, a shell is integrally formed on the rear side of the fixed seat, a rubber suction cup is sleeved in the inner cavity of the shell, an air suction hole is formed in the central position of the front side of the rubber suction cup and communicated with the fixed seat, an air suction pipe is fixedly connected to the front side end, the aspirating hole is fixedly connected with the aspirating tube, and th

**[p0002]**

e starting button, the pressure gauge, the indicating lamp, the battery, the vacuum pump and the pressure sensor are all electrically connected with the PLC through leads.

**[p0003]**

Preferably, the back side surface of the handle is provided with a frosted anti-slip layer. Preferably, the vacuum pump is a micro vacuum pump. Preferably, the battery corresponds to a position of the battery cover. Preferably, the indicator light is an LED light. Compared with the prior art, the beneficial effects of the utility model are that: the utility model discloses a tile is spread and is pasted rigid fixture convenient to quick clamp is got, what adopt is that the vacuum pump extracts the inside air of rubber suction cup, forms the vacuum state, and the quick clamp of being convenient for is got and is operated, sets up pressure sensor at the inner chamber of aspirating hole simultaneously, and the real-time pressure value that detects of being convenient for prevents the phenomenon that drops. Drawings FIG. 1 is a schematic structural view of the present invention; FIG. 2 is a schematic structural view of the inner cavity of the structural handle of the present invention; fig. 3 is a schematic structural diagram of the rubber suction cup of the structure of the present invention.

**[p0004]**

In the figure: the vacuum pump comprises a handle 1, a start button 2, a pressure gauge 3, a shell 4, a rubber sucker 5, an indicator lamp 6, a battery 7, an exhaust pipe 8, a vacuum pump 9, a PLC (programmable logic controller) 10, a pressure sensor 11, a fixing seat 12, a mounting bolt 13, an exhaust hole 14 and a battery cover 15. Detailed Description The technical solutions in the embodiments of the present invention will be described clearly and completely with reference to the accompanying drawings in the embodiments of the present invention, and it is obvious that the described embodiments are only some embodiments of the present invention, not all embodiments. Based on the embodiments in the present invention, all other embodiments obtained by a person skilled in the art without creative work belong to the protection scope of the present invention. The utility model provides a technical scheme: a ceramic tile paving rigid clamp convenient for quick clamping is used for improving the clamping effect and the clamping efficiency, and please refer to figure 1, which comprises a handle 1, wherein the rear side surface of the handle 1 is provided with a frosted anti-slip layer to increase the hand feeling of holding and prevent hand slipping, a pressure gauge 3 is fixedly installed on the left side of the handle 1 to realize real-time observation of the suction force of a rubber sucker 5, an indicator lamp 6 is fixedly installed on the left side of the handle 1, the indicator lamp 6 is positioned on the right side of the pressure gauge 3, the indicator lamp 6 is an LED la

**[p0004]**

mp to realize monitoring of the electric quantity of a battery, a starting button 2 is fixedly installed on the left side of the handle 1, the starting button 2 is positioned on the right side of the indicator lamp 6 to realize quick starting of a vacuum pump 9, a battery cover 15 is clamped on the right side of the handle 1 to realize quick slipping, please refer to figure 2, a vacuum pump 9 is, the vacuum pump 9 can continuously form negative pressure at an inlet, air in the inner cavity of the rubber sucker 5 is extracted through the air extraction pipe 8 to achieve the clamping effect, a battery 7 is fixedly installed on the right side of the inner cavity of the handle 1, the battery 7 corresponds to the position of a battery cover 15 to achieve rapid battery replacement, please refer to fig. 3, a fixing seat 12 is fixedly connected to the rear of the left side and the rear side of the handle 1 through a mounting bolt 13, a shell 4 is integrally formed on the rear side of the fixing seat 12, the rubber sucker 5 is sleeved in the inner cavity of the shell 4, an air extraction hole 14 is formed in the central position of the front side of the rubber sucker 5 and communicated with the fixing seat 12, a pressure sensor 11 is inserted in the inner cavity of the air extraction hole 14, the pressure sensor 11 is preferably a gas pressure sensor for sensing gas pressure, the air extraction hole 14 is fixedly connected with the air extraction, The battery 7, the vacuum pump 9 and the pressure sensor 11 are electrically connected with the PLC 10 through leads, so that effective c

**[p0004]**

ontrol of all parts is realized.

**[p0005]**

In specific use, as needs the utility model discloses at first laminate rubber suction cup 5 and the surface of ceramic tile mutually at the in-process that uses, then press start button 2, start vacuum pump 9, vacuum pump 9 takes gas out from rubber suction cup 5's inner chamber through exhaust tube 8, utilize the size of manometer 3 observation pressure sensor 11's pressure value simultaneously, reach certain degree when the pressure value and realize alright realization transport, utilize PLC controller 10 control manometer 3, vacuum pump 9 and pressure sensor 11's work, secondly when appearing insufficient point, pilot lamp 6 flashes and reminds, open battery cover 15 this moment, change battery 7. Although embodiments of the present invention have been shown and described, it will be appreciated by those skilled in the art that changes, modifications, substitutions and alterations can be made in these embodiments without departing from the principles and spirit of the invention, the scope of which is defined in the appended claims and their equivalents.

---

Generated by IPtorch. Verify legal conclusions against the official publication.
