# 05. Electric tool that tiling was used

- **Archive rank:** 5 of 50
- **Publication:** [CN-205290869-U](https://patents.google.com/patent/CN205290869U/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/056427237/publication/CN205290869U?q=pn%3DCN205290869U)
- **Publication date:** 2016-06-08
- **Filing date:** 2016-01-25
- **Earliest priority:** 2016-01-25
- **Family:** 56427237
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus

## Parties

- **Applicant / assignee:** WANG FENGYAN

## Abstract

The utility model discloses an electric tool that tiling was used, including the rubber suction cups, the sucking disc mount pad, the sucking disc handle, a housing, eccentric vibrating device, including a motor, an end cap, a controller, and a cover plate, a battery, gripping handle and switch, the rubber suction cups installation is fixed at sucking disc mount pad lower extreme, sucking disc handle and rubber suction cups fixed connection, the sucking disc handle extends the setting in sucking disc mount pad one side, the upper end at the sucking disc mount pad is fixed in the casing installation, eccentric vibrating device, including a motor, an end cap, a controller, and a cover plate, the battery is installed in the casing, the gripping handle is with casing fixed connection and extend the one side that sets up at the casing, the gripping handle sets up in sucking disc handle top, the switch electricity is connected on the connecting circuit of motor and battery, the accessible rubber suction cups holds waits the ceramic tile that spread to paste, and the ceramic tile is put the eccentric vibrating device of the back motor work drive vibration that targets in place and firmly, is levelly and smoothly pasted the ceramic tile on ground or wall, and labour saving and time saving, can not injure workman&#39;s hand and brick clad is firm, level.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-205290869-U/pdf000.png)

![Sketch 1 for CN-205290869-U](https://nimo.iptorch.com/refdrawing/CN-205290869-U/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-205290869-U/pdf001.png)

![Sketch 2 for CN-205290869-U](https://nimo.iptorch.com/refdrawing/CN-205290869-U/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/CN-205290869-U/pdf002.png)

![Sketch 3 for CN-205290869-U](https://nimo.iptorch.com/refdrawing/CN-205290869-U/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/CN-205290869-U/pdf003.png)

![Sketch 4 for CN-205290869-U](https://nimo.iptorch.com/refdrawing/CN-205290869-U/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/CN-205290869-U/pdf004.png)

![Sketch 5 for CN-205290869-U](https://nimo.iptorch.com/refdrawing/CN-205290869-U/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/CN-205290869-U/pdf005.png)

![Sketch 6 for CN-205290869-U](https://nimo.iptorch.com/refdrawing/CN-205290869-U/pdf005.png)

## Claims

### Claim 1 (independent)

Claims (7) the power tool of a tiling, it is characterized in that: comprise rubber suction cups (1), sucker mount pad (2), sucker handle (3), machine shell (4), eccentric vibration apparatus (5), motor (6), battery (7), hold and hold handle (8) and power switch (9), described rubber suction cups (1) is fixed on sucker mount pad (2) lower end, sucker handle (3) is fixedly connected with rubber suction cups (1), sucker handle (3) is extended on sucker mount pad (2) side, machine shell (4) is fixed on the upper end of sucker mount pad (2), eccentric vibration apparatus (5), motor (6), battery (7) is arranged in machine shell (4), eccentric vibration apparatus (5) is fixedly connected with the output shaft of motor (6) and is arranged on the top of rubber suction cups (1), battery (7) is electrically connected with motor (6), hold and hold handle (8) and be fixedly connected with machine shell (4) and the side that is extended on machine shell (4), hold hold handle (8) be arranged on sucker handle (3) top, power switch (9) is connected electrically in motor (6) with on the junction circuit of battery (7).

### Claim 2

the power tool of a kind of tiling as claimed in claim 1, it is characterised in that: described power switch (9) is mounted on the sidepiece held and hold handle (8).

### Claim 3

the power tool of a kind of tiling as claimed in claim 1 or 2, it is characterized in that: described in hold and hold handle (8) and comprise connection section (81) and grip part (82), this connection section (81) is fixed on the top of machine shell (4), grip part (82) is in shaft-like, grip part (82) one end is fixedly connected on connection section (81), and the other end freely extends.

### Claim 4

the power tool of a kind of tiling as claimed in claim 3, it is characterised in that: the side of described grip part (82) is provided with rubber cushion groove (820), is embedded with rubber cushion (821) in rubber cushion groove (820).

### Claim 5

the power tool of a kind of tiling as claimed in claim 1, it is characterized in that: the front end, top of described machine shell (4) is installed and is provided with front handlebar (41), front handlebar (41) is in arc shape body, the two ends of arc shape body front handlebar (41) are fixedly connected on the top front bulkhead of machine shell (4), form the hand-hold hole (42) that can stretch into for staff between the top front bulkhead of front handlebar (41) and machine shell (4).

### Claim 6

the power tool of a kind of tiling as claimed in claim 1, it is characterized in that: also comprise power light (10), power light (10) is fixed on the top of machine shell (4), and power light (10) is connected electrically in motor (6) with on the junction circuit of battery (7).

### Claim 7

the power tool of a kind of tiling as described in claim 1 or 6, it is characterised in that: described battery (7) is rechargeable battery pack.

## Full description

**[p0001]**

Description The power tool of a kind of tiling Technical field The utility model relates to ceramic tile paving technical field, is specifically related to the power tool of a kind of tiling. Background technology Current ceramic tile paving is by manual handling and knocks to flatten with hammer and is attached on ground or metope, not only wastes time and energy, easily causes workman's hand injured, and exists to paste and loosely paste uneven problem. Summary of the invention For the deficiencies in the prior art, the utility model aim to provide a kind of time saving and energy saving, workman's hand can not be injured and the power tool of tiling that ceramic tile paving is firm, smooth. For achieving the above object, the utility model adopts following technical scheme: The power tool of a kind of tiling, comprise rubber suction cups, sucker mount pad, sucker handle, machine shell, eccentric vibration apparatus, motor, battery, hold and hold handle and power switch, described rubber suction cups is fixed on the lower end of sucker mount pad, sucker handle is fixedly connected with rubber suction cups, sucker handle is extended on sucker mount pad side, machine shell is fixed on the upper end of sucker mount pad, eccentric vibration apparatus, motor, battery is arranged in machine shell, eccentric vibration apparatus is fixedly connected with the output shaft of motor and is arranged on the top of rubber suction cups, battery is electrically connected with motor, hold and hold handle and be fixedly connected with machine shell and the side that is extended on machine

**[p0001]**

shell, hold and hold handle and be arranged on above sucker handle, power switch is connected electrically on the junction circuit of motor and battery.

**[p0002]**

Further, described power switch is mounted on to be held on the sidepiece holding handle. Further, described in hold and hold handle and comprise connection section and grip part, this connection section is fixed on the top of machine shell, and grip part is shaft-like, and one end, grip part is fixedly connected on connection section, and the other end freely extends. Further, the side of described grip part is provided with rubber cushion groove, is embedded with rubber cushion in rubber cushion groove. Further, the front end, top of described machine shell is installed and is provided with front handlebar, front handlebar is arc shape body, and the two ends of arc shape body front handlebar are fixedly connected on the top front bulkhead of machine shell, forms the hand-hold hole that can stretch into for staff between the top front bulkhead of front handlebar and machine shell. Further, also comprising power light, power light is fixed on the top of machine shell, and power light is connected electrically on the junction circuit of motor and battery.

**[p0003]**

Further, described battery is rechargeable battery pack. The utility model has following useful effect: The power tool of a kind of tiling of the utility model, people's hand grip is held and is held handle and pull up sucker handle, the ceramic tile treating paving is held by rubber suction cups, ceramic tile is put into descendant's hand starting power switch, battery is connected with motor, machine operation also drives the vibration of the eccentric vibration apparatus in machine shell that by rubber suction cups, vibration power is passed to ceramic tile, now another hand of people can grasp the front handlebar on front end, machine shell top and is firmly entirely attached on ground or metope by ceramic tile, it is time saving and energy saving to have, workman's hand can not be injured and ceramic tile paving firm, smooth feature. Accompanying drawing explanation Fig. 1 is the structural representation of its outside side of power tool of a kind of tiling of the utility model; Fig. 2 is the structural representation of its another side outside of power tool of a kind of tiling of the utility model;

**[p0004]**

Fig. 3 be a kind of tiling of the utility model with its eccentric vibration apparatus of power tool, motor, battery, power switch and power light the relation that connects schematic diagram. In figure: 1, rubber suction cups; 2, sucker mount pad; 3, sucker handle; 4, machine shell; 5, eccentric vibration apparatus; 6, motor; 7, battery; 8, hold and hold handle; 9, power switch; 10, power light; 41, front handlebar; 42, hand-hold hole; 81, connection section; 82, grip part; 820, rubber cushion groove; 821, rubber cushion. Embodiment Below in conjunction with drawings and the specific embodiments, the utility model will be further described, so that more clearly understanding the technological thought that the utility model is claimed. Such as Fig. 1, 2, the power tool of a kind of tiling of the utility model shown in 3, comprise rubber suction cups 1, sucker mount pad 2, sucker handle 3, machine shell 4, eccentric vibration apparatus 5, motor 6, battery 7, hold and hold handle 8 and power switch 9, rubber suction cups 1 is fixed on sucker mount pad 2 times ends, sucker handle 3 is fixedly connected with rubber suction cups 1, sucker handle 3 is extended on sucker mount pad 2 side, machine shell 4 is fixed on the upper end of sucker mount pad 2, eccentric vibration apparatus 5, motor 6, battery 7 is arranged in machine shell 4, eccentric vibration apparatus 5 is fixedly connected with the output shaft of motor 6 and is arranged on the top of rubber suction cups 1, battery 7 is electrically connected with motor 6, hold and hold handle 8 and be fixedly connected with machine

**[p0004]**

shell 4 and the side that is extended on machine shell 4, hold and hold handle 8 and be arranged on above sucker handle 3, power switch 9 is connected electrically in motor 6 with on the junction circuit of battery 7.

**[p0005]**

More specifically, working for ease of starting motor 6, power switch 9 is mounted on the sidepiece held and hold handle 8. More specifically, holding and hold handle 8 and comprise connection section 81 and grip part 82, this connection section 81 is fixed on the top of machine shell 4, and grip part 82 is in shaft-like, and one end, grip part 82 is fixedly connected on connection section 81, and the other end freely extends. For underwriter's hand grip holds comfort when holding handle 8, the side of grip part 82 is provided with rubber cushion groove 820, is embedded with rubber cushion 821 in rubber cushion groove 820. For when ensureing ceramic tile paving further firmly and smooth and when motor 6 task driven eccentric vibration apparatus 5 vibrates, stablizing of power tool work, the front end, top of machine shell 4 is installed and is provided with front handlebar 41, front handlebar 41 is in arc shape body, the two ends of arc shape body front handlebar 41 are fixedly connected on the top front bulkhead of machine shell 4, form the hand-hold hole 42 that can stretch into for staff between the top front bulkhead of front handlebar 41 and machine shell 4.

**[p0006]**

Normal operation state whether it is in for ease of showing the motor 6 of power tool, the utility model power tool also comprises power light 10, power light 10 is fixed on the top of machine shell 4, and power light 10 is connected electrically in motor 6 with on the junction circuit of battery 7. For ease of the continuous electricity of battery 7, what battery 7 adopted is rechargeable battery pack. Principle of work of the present utility model is: people's hand grip is held and held handle 8 and pull up sucker handle 3, the ceramic tile treating paving is held by rubber suction cups 1, ceramic tile is put into descendant's hand starting power switch 9, battery 7 is connected with motor 6, motor 6 works and drives the eccentric vibration apparatus 5 in machine shell 4 to vibrate and by rubber suction cups 1, vibration power is passed to ceramic tile, now another hand of people can grasp the front handlebar 41 on front end, machine shell 4 top and is firmly entirely attached on ground or metope by ceramic tile, time saving and energy saving, workman's hand can not be injured and ceramic tile paving firm, smooth.

**[p0007]**

For a person skilled in the art, according to technical scheme described above and design, other various corresponding change and distortion can be made, and all these change and are out of shape within the protection domain that all should belong to the utility model claim.

---

Generated by IPtorch. Verify legal conclusions against the official publication.
