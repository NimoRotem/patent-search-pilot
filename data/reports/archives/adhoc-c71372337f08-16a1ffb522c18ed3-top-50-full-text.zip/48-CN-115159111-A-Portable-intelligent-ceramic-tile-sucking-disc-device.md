# 48. Portable intelligent ceramic tile sucking disc device

- **Archive rank:** 48 of 50
- **Publication:** [CN-115159111-A](https://patents.google.com/patent/CN115159111A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/083495388/publication/CN115159111A?q=pn%3DCN115159111A)
- **Publication date:** 2022-10-11
- **Filing date:** 2022-07-15
- **Earliest priority:** 2022-07-15
- **Family:** 83495388
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** BEIHAI POWER SUPPLY BUREAU GUANGXI POWER GRID CO LTD
- **Inventors:** Dai Tangbiao; HAN GUANGXIN; HOU DENGXU; LEE DONG-JUN; LI LUZHU; LIN YI; XU WENWEN; YE SI; YE YUXIAN; YU NAN; ZHANG XIANXIAN; ZHANG YUQIAO; ZHAO DANYAN

## Abstract

The invention relates to a movable intelligent tile sucker device which comprises a movable base, a rotating part, a height adjusting mechanism, a copper core motor control device, a telescopic suspension arm and a sucker, wherein the movable base is fixed on the base; the rotating part is fixedly arranged on the movable base; the rotating component is connected with the height adjusting mechanism; one end of the telescopic suspension arm is connected to one side of the height adjusting mechanism, and the other end of the telescopic suspension arm is connected with the sucker through a rope; the copper core motor control device is arranged on the telescopic suspension arm, the structure of the ceramic tile suction machine is convenient to use and store, ceramic tiles are sucked up by the aid of the supporting force of the instrument to the ground through the rotating part, the height adjusting mechanism and the lifting device consisting of the telescopic suspension arm, consumption of manpower and material resources is effectively saved, and potential safety hazards in working are avoided.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-115159111-A/000.png)

![Sketch 1 for CN-115159111-A](https://nimo.iptorch.com/refdrawing/CN-115159111-A/000.png)

[Sketch 2](https://patentimages.storage.googleapis.com/83/c8/46/4e8ad2bf89fc0b/HDA0003748181750000011.png)

![Sketch 2 for CN-115159111-A](https://patentimages.storage.googleapis.com/83/c8/46/4e8ad2bf89fc0b/HDA0003748181750000011.png)

## Claims

### Claim 1

1. Portable intelligent ceramic tile sucking disc device, its characterized in that includes:

### Claim 2

the device comprises a movable base, a rotating part, a height adjusting mechanism, a copper core motor control device, a telescopic suspension arm and a sucker;

### Claim 3

the rotating part is fixedly arranged on the movable base;

### Claim 4

the rotating part is connected with the height adjusting mechanism;

### Claim 5

one end of the telescopic suspension arm is connected to one side of the height adjusting mechanism, and the other end of the telescopic suspension arm is connected with the sucker through a rope;

### Claim 6

the copper core motor control device is arranged on the telescopic suspension arm.

### Claim 7

2. The movable intelligent tile suction cup device according to claim 1, wherein the suction cup comprises an air pump and a rubber plate, wherein the air pump is connected with one end of the rubber plate.

### Claim 8

3. The movable intelligent tile suction device according to claim 2, wherein a limiting hole is formed in the top of the air pump, and the rope penetrates through the limiting hole to enable the telescopic boom to be connected with the suction cup.

### Claim 9

4. The movable intelligent tile suction device according to claim 1, wherein the end of the other end of the telescopic boom is provided with a slide rail for pulling the rope.

### Claim 10

5. The movable intelligent tile suction device according to claim 1, wherein one side of the height adjustment mechanism is provided with a height adjustment buckle for adjusting the horizontal angle of the telescopic boom.

### Claim 11

6. The movable intelligent tile suction device according to claim 5, wherein the middle part of the telescopic boom is provided with a length adjustment buckle for adjusting the horizontal telescopic length of the telescopic boom.

### Claim 12

7. The movable intelligent tile suction cup device according to claim 1, wherein the rotation angle of said rotating member is 360 degrees.

### Claim 13

8. A movable intelligent tile suction device according to claim 7, wherein one side of said rotating part is provided with an operation panel on which buttons and respective function keys are provided.

### Claim 14

9. The movable intelligent tile suction device according to claim 1, wherein a stand is fixedly connected to the top of the movable base, one end of the stand is connected to the top of the movable base, and the other end of the stand is connected to the rotating member.

### Claim 15

10. The movable intelligent tile suction cup device according to claim 9, wherein the bottom of the movable base is provided with universal wheels and the top side of the movable base is provided with a handrail.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSArticle or material-handling devices associated with conveyors; Methods employing such devicesFeeding, transfer, or discharging devices of particular kinds or typesDevices for picking-up and depositing articles or materialsDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippersDevices for picking-up and depositing articles or materials incorporating pneumatic, e.g. suction, grippers provided with drive systems incorporating rotary and rectilinear movementsPERFORMING OPERATIONS; TRANSPORTINGCONVEYING; PACKING; STORING; HANDLING THIN OR FILAMENTARY MATERIALTRANSPORT OR STORAGE DEVICES, e.g. CONVEYORS FOR LOADING OR TIPPING,Â SHOP CONVEYOR SYSTEMS ORÂ PNEUMATIC TUBE CONVEYORSSupporting frames or bases for conveyors as a whole, e.g. transportable conveyor framesMeans for moving conveyor frames and control arrangements thereforMeans for moving conveyor frames and control arrangements therefor frames mounted on wheels or caterpillar

Description

Portable intelligent ceramic tile sucking disc device

Technical Field

The invention relates to the technical field of ceramic tile sucker equipment, in particular to a movable intelligent ceramic tile sucker device.

Background

With the development of power requirements and the increase of the number of new transformer substation rooms, the transformer substation also strengthens operation and maintenance measures of equipment in the rooms, such as the arrangement of a cover plate of the room. At present, most of cover plates in a machine room are tile floors, each tile floor is about 15 kilograms, and operation and maintenance personnel need to open the tile cover plates when regularly maintaining, overhauling and dedusting equipment in the machine room or laying new cables.

Draw ceramic tile apron among the prior art and mainly accomplish by the manpower, because the ceramic tile is comparatively thick and heavy and real, consequently need several people to mention the back with the sucking disc and remove from the construction area again, so not only working strength is big, and sucking disc suction is unstable also increases the hidden danger to personnel's injury simultaneously, when a cable is changed and is safeguarded and will mention several ceramic tile apron at least, causes great potential safety hazard easily under the condition of extravagant manpower and material resources.

Disclosure of Invention

The invention aims to provide a movable intelligent tile sucking disc device which is used for replacing manpower to extract tiles through the movable intelligent tile sucking disc device, and equipment and manpower cost is effectively reduced.

The invention provides in a first aspect a movable intelligent tile suction cup device comprising:

the device comprises a movable base, a rotating part, a height adjusting mechanism, a copper core motor control device, a telescopic suspension arm and a sucker;

the rotating component is fixedly arranged on the movable base;

the rotating part is connected with the height adjusting mechanism;

one end of the telescopic suspension arm is connected to one side of the height adjusting mechanism, and the other end of the telescopic suspension arm is connected with the sucker through a rope;

the copper core motor control device is arranged on the telescopic suspension arm.

Optionally, the suction cup comprises an air pump and a rubber disc, and the air pump is connected with one end of the rubber disc.

Optionally, a limiting hole is formed in the top of the air pump, and the rope penetrates through the limiting hole to enable the telescopic boom to be connected with the sucker.

Optionally, a slide rail is arranged at the end of the other end of the telescopic boom, and the slide rail is used for dragging the rope.

Optionally, one side of the height adjusting mechanism is provided with a height adjusting buckle, and the height adjusting buckle is used for adjusting the horizontal angle of the telescopic boom.

Optionally, a length adjusting buckle is arranged in the middle of the telescopic boom and used for adjusting the horizontal telescopic length of the telescopic boom.

Optionally, the rotation angle of the rotating component is 360 degrees.

Optionally, an operation panel is disposed on one side of the rotating component, and a button and each function key are disposed on the operation panel.

Optionally, the top of the movable base is fixedly connected with a vertical frame, one end of the vertical frame is connected with the top of the movable base, and the other end of the vertical frame is connected with the rotating component.

Optionally, the bottom of the movable base is provided with universal wheels, and one side of the top of the movable base is provided with a handrail.

According to the technical scheme, the embodiment of the application has the following advantages: portable intelligent ceramic tile sucking disc device is provided with portable base in this application, rotary part, high guiding mechanism, copper core motor control device, scalable davit and sucking disc, wherein rotary part is fixed to be set up on portable base and be connected with high guiding mechanism, one side at high guiding mechanism is connected to scalable davit's one end, the sucking disc is connected to the other end, copper core motor device then sets up the top at scalable davit, when drawing the ceramic tile operation, start copper core motor device and pass through the rope and pull the sucking disc, the sucking disc lifts up the ceramic tile through suction, rotary part, the cooperation of high guiding mechanism and scalable davit can carry out arbitrary angle and the removal of arbitrary height with the ceramic tile, this application replaces manual work with sucking disc device, effectively saved the consumption of manpower and material resources and avoided the work potential safety hazard.

Drawings

Fig. 1 is a schematic structural view of a movable intelligent tile suction device according to the present invention.

In the figure: the device comprises a movable base 1, a rotating part 2, a height adjusting mechanism 3, a height adjusting buckle 301, a telescopic suspension arm 4, a copper core motor device 5, a sliding rail 501, a length adjusting buckle 502, a sucker 6, an air pump 601 and a rubber disc 602.

Detailed Description

The embodiment of the application provides portable intelligent ceramic tile sucking disc device for replace the manpower to draw the ceramic tile through removing intelligent sucking disc device, effectively reduced equipment and human cost.

The technical solutions in the present application will be described clearly and completely with reference to the accompanying drawings in the embodiments of the present application, and it is obvious that the described embodiments are only some embodiments of the present application, not all embodiments. All other embodiments, which can be derived by a person skilled in the art from the embodiments given herein without making any creative effort, shall fall within the protection scope of the present application.

Please refer to fig. 1, a first aspect of the present application provides a movable intelligent tile sucker device, which includes a movable base 1, a rotating component 2, a height adjusting mechanism 3, a copper core motor control device 4, a telescopic suspension arm 5 and a sucker 6, wherein the rotating component 2 is fixedly disposed on the movable base 1 and connected to the height adjusting mechanism 3, one end of the telescopic suspension arm 4 is connected to one side of the height adjusting mechanism 3, the other end of the telescopic suspension arm is connected to the sucker 6, the copper core motor device 5 is disposed on the top of the telescopic suspension arm 4, when the tile is extracted, the tile is sucked up by a supporting force of the movable base 1 itself on the sucker device to the ground and a lifting device composed of other component mechanisms, thereby effectively improving the work efficiency of extracting the tile.

Optionally, the suction cup 6 includes an air pump 601 and a rubber disc 602, wherein the rubber disc 602 is hollow, and the rubber material of the rubber disc 602 can prevent the tile from cracking when the tile moves in contact with the tile; the air pump 601 is connected with one end of the rubber disc 602, specifically, the air pump 601 is connected to the inside of the rubber disc 602 to pump out the air in the rubber disc 602 to form an air pressure difference, so that the suction cup 6 can be firmly fixed on the tile. In addition, the top of the air pump 601 is provided with a limit hole, a rope passes through the limit hole to enable the telescopic suspension arm 4 to be connected with the sucker 6, and the tile is pulled in any direction under the control of a motor.

Optionally, a slide rail 501 is arranged at the end of the other end of the telescopic boom 5, and the slide rail 501 is used for pulling a rope; copper core motor control device 4 mainly is the flexible length of the height of pulling and davit of control sucking disc device top rope, and when starting motor, the motor drives the rope, can effectively control the traction speed of rope when the rope passes slide rail 501, in addition, there is large-scale electric cabinet in the protection cell, some places are comparatively narrow, when sucking disc device is whole great be difficult for entering, just can stretch into narrow and small department with sucking disc device through scalable davit 5, reuse motor control rope motion, draw out the ceramic tile.

Optionally, a height adjusting buckle 301 is arranged on one side of the height adjusting mechanism 3, and the height adjusting buckle 301 is used for adjusting the horizontal angle of the telescopic boom 5; the middle part of the telescopic boom 5 is provided with a length adjusting buckle 502, and the length adjusting buckle 502 is used for adjusting the horizontal telescopic length of the telescopic boom 5; in both methods, the angle or the telescopic length is adjusted by adjusting the fasteners, wherein the distance between the fasteners can be set according to the size of the construction area, which is not limited herein.

Optionally, the rotation angle of the rotating part 2 is 360 degrees, so that the construction range of the suction cup device can be effectively enlarged.

Optionally, an operation panel 7 is disposed on one side of the rotating component 2, wherein an instrument button and each function key of the device are disposed on the operation panel 7, the motor can be started to control the lifting device through the function key on the operation panel 7, and the rotating component 2 is controlled to rotate and perform height adjustment, so that automation of the device is achieved.

Optionally, one end of the stand 8 is fixedly connected to the movable base 1, and the other end of the stand 8 is connected to the rotating member 2, in this embodiment, the stand 8 is used for supporting the rotating member 2 and increasing the overall operation height of the suction cup device. In addition, the bottom of the movable base 1 is provided with universal wheels 9, the number of the universal wheels 9 is 4, the top of the movable base is provided with handrails 10, a worker pushes the handrails 10 to combine with the universal wheels 9 to move the suction cup device, so that the time and labor are saved in the process of carrying the device, and the universal wheels can improve the mobility of instruments in the operation process.

The theory of operation of portable intelligent ceramic tile sucking disc device in this embodiment: when the ceramic tile is extracted, a worker pushes the sucker device to a designated position and then starts the copper core motor control device 4 to control the height of a rope above the sucker device and the telescopic length of the telescopic boom 5, wherein the speed of the motor can be adjusted according to actual working requirements, the rotating part 2 and the height adjusting mechanism 3 are used in a combined manner in the working process, a control instruction is sent through a button on the operating panel 7, the height adjusting mechanism 3 performs gear shifting adjustment according to the actual working environment, the height of the height adjusting mechanism is controlled by adjusting the angle of the boom, the rotating part 2 operates according to the optimal operating position and can rotate by 360 degrees, convenience, rapidness and convenience in operation are realized, the ceramic tile can be sucked up by pressing a function key through the supporting force of the device to the ground and simultaneously utilizing the lifting device, the worker moves the ceramic tile to the side without lifting up, and then the next ceramic tile is stored, and the next ceramic tile is lifted and moved.

It is intended that the foregoing description of the disclosed embodiments enable any person skilled in the art to make or use the present application. Various modifications to these embodiments will be readily apparent to those skilled in the art, and the generic principles defined herein may be applied to other embodiments without departing from the scope of the application. Thus, the present application is not intended to be limited to the embodiments shown herein but is to be accorded the widest scope consistent with the principles and novel features disclosed herein.

## Classifications

- B65G47/914
- B65G41/00
- B65G41/008
- B65G47/91

## Cited patent documents

- [CN-103964292-A](https://patents.google.com/patent/CN103964292A/en) — SEA
- [CN-109775630-A](https://patents.google.com/patent/CN109775630A/en) — SEA
- [CN-207275080-U](https://patents.google.com/patent/CN207275080U/en) — SEA
- [CN-209618340-U](https://patents.google.com/patent/CN209618340U/en) — SEA
- [CN-210150625-U](https://patents.google.com/patent/CN210150625U/en) — SEA
- [CN-212053658-U](https://patents.google.com/patent/CN212053658U/en) — SEA
- [CN-213417500-U](https://patents.google.com/patent/CN213417500U/en) — SEA
- [CN-215598744-U](https://patents.google.com/patent/CN215598744U/en) — SEA
- [JP-H06156721-A](https://patents.google.com/patent/JPH06156721A/en) — SEA

---

Generated by IPtorch. Verify legal conclusions against the official publication.
