# 45. Vaccum plates

- **Archive rank:** 45 of 50
- **Publication:** [WO-9210336-A3](https://patents.google.com/patent/WO9210336A3/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/010686712/publication/WO9210336A3?q=pn%3DWO9210336A3)
- **Publication date:** 1992-07-23
- **Filing date:** 1991-12-09
- **Earliest priority:** 1990-12-08
- **Family:** 10686712
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** CARNE UFM LTD; PETRIE LAURENCE ROSS
- **Inventors:** DAVIES DAVID; PETRIE LAURENCE ROSS; STANLEY DAVID WILLIAM

## Abstract

A vacuum plate system comprises a base plate (10) and a support plate (20). The base plate (10) has an array of vacuum apertures (12) formed in it and a vacuum groove (14) around its periphery. Vacuum and positive pressure connection ports (15-18) connect to the vacuum apertures (12) and groove (14). The support plate (20) is formed economically out of plastics material, and is formed on its upper, working surface (21) with an array of shallow cavities (23). Each of the cavities (23) is formed with a small central hole (24) which passes through the support plate (20). Each such hole communicates with grooves (25) which are formed on the underside of the support plate (20), to distribute the vacuum supplied via the vacuum apertures (12). In use, a workpiece is placed on the support plate (20), which in turn is placed on the base plate (10). The support plate (10) and workpiece are held in position by vacuum applied via one or more of the ports (15 to 17). A tool can cut right round the edge of, and even under the workpiece and into the support plate (20), which may be scrapped and/or recycled after the machining operation. The invention is particularly suitable for the machining of thin and/or fragile components.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/WO-9210336-A3/ops000.png)

![Sketch 1 for WO-9210336-A3](https://nimo.iptorch.com/refdrawing/WO-9210336-A3/ops000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/WO-9210336-A3/ops001.png)

![Sketch 2 for WO-9210336-A3](https://nimo.iptorch.com/refdrawing/WO-9210336-A3/ops001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/WO-9210336-A3/ops002.png)

![Sketch 3 for WO-9210336-A3](https://nimo.iptorch.com/refdrawing/WO-9210336-A3/ops002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/WO-9210336-A3/ops003.png)

![Sketch 4 for WO-9210336-A3](https://nimo.iptorch.com/refdrawing/WO-9210336-A3/ops003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/WO-9210336-A3/ops004.png)

![Sketch 5 for WO-9210336-A3](https://nimo.iptorch.com/refdrawing/WO-9210336-A3/ops004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/WO-9210336-A3/ops005.png)

![Sketch 6 for WO-9210336-A3](https://nimo.iptorch.com/refdrawing/WO-9210336-A3/ops005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/WO-9210336-A3/ops006.png)

![Sketch 7 for WO-9210336-A3](https://nimo.iptorch.com/refdrawing/WO-9210336-A3/ops006.png)

[Sketch 8](https://nimo.iptorch.com/refdrawing/WO-9210336-A3/ops007.png)

![Sketch 8 for WO-9210336-A3](https://nimo.iptorch.com/refdrawing/WO-9210336-A3/ops007.png)

[Sketch 9](https://nimo.iptorch.com/refdrawing/WO-9210336-A3/ops008.png)

![Sketch 9 for WO-9210336-A3](https://nimo.iptorch.com/refdrawing/WO-9210336-A3/ops008.png)

[Sketch 10](https://nimo.iptorch.com/refdrawing/WO-9210336-A3/ops009.png)

![Sketch 10 for WO-9210336-A3](https://nimo.iptorch.com/refdrawing/WO-9210336-A3/ops009.png)

[Sketch 11](https://nimo.iptorch.com/refdrawing/WO-9210336-A3/ops010.png)

![Sketch 11 for WO-9210336-A3](https://nimo.iptorch.com/refdrawing/WO-9210336-A3/ops010.png)

## Claims

### Claim 1 (independent)

CLAYS l. A vacuum plate system comprising a base plate and a support plate: the base plate having a vacuum connection port. at least one aperture opening into a support surface of the plate, and connection means connecting said aperture with said port: and the support plate comprising a sheet of material having a working surface and a reverse surface. the working surface being formed with a plurality of cavities which open into the working surface. the plate being formed with at least one hole which extends between said working and reverse surfaces. and the support plate being placed. in use. upon said base plate with said reverse surface of the support plate on said support surface of said base plate. and said hole in communication with said aperture.

### Claim 2

A vacuum plate system according to claim 1. wherein said hole is located in one of said cavities.

### Claim 3

A vacuum plate system according to claim 1 or 2. wherein said base piate is provided with a plurality of said apertures and means for selectively opening and closing said apertures.

### Claim 4

A vacuum plate system according to claim 1. 2 or 3, wherein said support plate is formed with a plurality of said holes and at least one groove to interconnect said holes.

### Claim 5

A vacuum plate system according to claim 1. 2. 3 or 4. wherein said support plate is formed with - a plurality of said holes and each of a plurality of said cavities has a respective one of said holes located therein.

### Claim 6 (independent)

A vacuum plate system comprising a base plate and a support plate: the base plate having a vacuum connection port. at least one aperture opening into a support surface of the plate. and connection means connecting said aperture with said port: and the support plate comprising a sheet of plastics material having a working surface and a reverse surface, the plate being formed with at least one hole which extends between said working and reverse surfaces. and the support plate being placed. in use. upon said base plate with said reverse surface of the support plate on said support surface of said base plate. and said hole in communication with said aperture.

### Claim 7

A vacuum plate system according to claim 6 and also to any of claims 1 to 5.

### Claim 8

A vacuum plate system according to any of the preceding claims, wherein the diameter of the or each said aperture is greater than twice the diameter of the or each said hole.

### Claim 9

A vacuum plate system according to any of the preceding claims, wherein more than twice as many said holes are provided in said support plate than the number of said apertures in said base plate.

### Claim 10

A vacuum plate system according to any of the preceding claims, wherein said support plate is provided on said working surface thereof with resilient projections which. in use, form a seal with a surface of a workpiece supported on said support plate.

### Claim 11

A vacuum plate system according to claim 10. wherein said support plate is formed with a plurality of said holes, and said resilient projections form closed seals around at least some of said holes.

### Claim 12

A vacuum plate system according to claim 11. wherein said resilient projections form a closed seal around at least one area of said working surface which is not provided with a said hole.

### Claim 13

A vacuum plate system according to any of the preceding claims, wherein said support plate comprises a plurality or active modules which. in use. are disposed side by side on said base plate. each module having a said working surface. a said reverse surface. and at least one said hole which extends between said working and reverse surfaces to communicate with a respective said aperture in said base plate.

### Claim 14

A vacuum plate system according to claim 13, wherein said support plate further comprises a plurality of blank modules which, in use. are disposed side by side on said base plate with said active modules, each blank module having a said working surface, a said reverse surface. but no said hole extending between said working and reverse surfaces.

### Claim 15

A vacuum plate system according to any of the preceding claims, including a workpiece to which said support plate is detachably fixed.

### Claim 16

A vacuum plate system according to claim 15. wherein said support plate is detachably fixed to said workpiece by means of a temporary adhesive.

### Claim 17

X vacuum plate system according to any of the preceding claims, including location means for positively locating said support plate on said base plate. 18 A vacuum plate system according to claim 17, wherein said location means comprises interengaging projections and recesses provided on said support and base plates.

### Claim 19

A vacuum plate system according to claim 18. wherein said recesses are formed along edge areas of said support plate.

### Claim 20

.N vacuum plate system according to any of the preceding claims. wherein at least one of said surfaces of the support plate is formed with surface roughness to assist the transfer of positive or negative pressure across that surface. 21 A vacuum plate system according to claim 20. wherein said surface roughness is formed bv abrasion of said surface. 22 A method of manufacturing a support plate as recited in any of the preceding claims. comprising the step of passing a feedstock material between rollers. to define a sheet having a surface pattern on at least one surface thereof 23. A method of manufacturing a support plate as recited in any of claims 1 to 21* comprising the step of passing a sheet of material through a punching machine and punching in the sheet a plurality of holes to form said holes in said support plate.

### Claim 24

A method according to claim 22, wherein said holes are punched to form a predetermined pattern of holes in said sheet.

### Claim 25

A method according to claim 22 and also to claim 23 or 24.

### Claim 26 (independent)

A vacuum plate system comprising: a base plate having a vacuum connection port. a support surface. at least one aperture opening into said surface. and connection means connecting said aperture with said port: pressure generating means for generating both positive and negative pressures (with respect to ambient pressure): and control means for selectively applying positive or negative pressure to said vacuum connection port.

### Claim 27

A vacuum plate system according to claim 25, wherein said base piate has a plurality of said apertures each connected to one of a plurality of said ports. and said pressure generating means and control means are arranged to apply positive and negative pressures selectively to said ports.

### Claim 28

A vacuum plate system according to claim 26 or 27, and also according to any of claims 1 to 21.

### Claim 29 (independent)

A vacuum piate system comprising: a base plate having a vacuum connection port, a plurality of apertures opening into a support surface of the plate and connection means connecting said apertures with said port: closure means for closing and opening said apertures individually: and control means for selectively closing and opening said closure means.

### Claim 30

A vacuum plate system according to claim 29. wherein said control means is arranged to close and open said closure means in synchronism with a predetermined machining operation carried out on a workpiece held on the vacuum plate.

### Claim 31

A vacuum plate system according to claim 29 or 30, wherein said closure means comprises a plurality of electrically operated valves.

### Claim 32

A vacuum plate system according to claim 29, 30 or 31, wherein said closure means comprises a plurality of mechanicaIly operated valves.

### Claim 33

A vacuum plate system according to any of claims 28 to 32. wherein said control means comprises actuator means for actuating the closure means1 the actuator means including at least part of said support plate and/or base plate.

### Claim 34

A vacuum plate system according to claim 33, wherein said support plate is formed with actuator areas to cooperate with said closure means and thereby selectively open and close said closure means.

### Claim 35

A vacuum piate system according to claims 32 and 34, wherein each of at least some of said actuator areas comprises an abutment disposed in a respective one of said holes and arranged to abut a valve stem of a respective one of said mechanicallv operated valves. thereby to open the valve.

### Claim 36

A vacuum plate system according to claim 35. wherein each said mechanically operated valve is mounted in a respective said aperture in said base plate and has a valve stem which is biassed towards a closed position in which at least part of the valve stem projects above said support surface of said base plate.

### Claim 37

A vacuum plate system according to any of claims 29 to 36 and also to any of claims 1 to 21 or any of claims 26 to 28.

### Claim 38

A method of holding a workpiece. comprising the step of placing the workpiece on a vacuum plate system according to any of claims 1 to 21 or any of claims 26 to 37, and applying a reduced pressure to the connection port of said base plate to hold the workpiece on the vacuum plate.

### Claim 39

A method of machining a workpiece. comprising the step of holding the workpiece on a vacuum plate system by a method according to claim 38. and machining the workpiece whilst held on the vacuum plate.

### Claim 40

A method of modifying a vacuum plate system having a base plate formed with at least one vacuum aperture, the method comprising the step of placing on the base plate a support plate as recited in any of the preceding claims. to provide a vacuum path between the or each said vacuum aperture and the working surface of the support plate.

### Claim 41

Use of a support plate as recited in any of claims 1 to 37 in a method according to claim 38 or 39.

## Full description

**[0001]**

VACUUM PLATES This invention relates to vacuum plates.

**[0002]**

Vacuum plates are well known in the engineering field as means for holding a workpiece securely in place, whilst a machining operation is performed on it. They may take various shapes. For example, they may be generally flat rectangular tables. which afford a substantially horizontal support surface to workpieces. Alternatively, they may be of circular shape.

**[0003]**

affording a substantially upright support surface upon which a workpiece is secured, in the manner of a chuck.

**[0004]**

In fact, such a latter configuration may be referred to as a "vacuum chuck". but for the sake of convenience. in this specification. the term "vacuum plate" is used to refer to all possible configurations of support means which retain a workpiece in position by means of a vacuum.

**[0005]**

A known horizontal vacuum plate may typically comprise a steel base plate. formed with a plurality of holes, on which is secured an aluminium support plate which also is formed with a plurality of holes which are surrounded by a network of grooves, and which communicate with the holes in the base plate. In use. a rubber sealing member is disposed in selective ones of the grooves, to approximate the perimeter of a workpiece to be held and machined. Within the area bounded by the rubber member, at least one of the holes in the aluminium plate is caused to be open. All holes outside the rubber member are caused to be closed. The opening and closing of the holes is typically achieved by inserting and removing screws from the holes, which are correspondingly tapped.

**[0006]**

When the support plate has been thus prepared, the workpiece is placed upon it. so that it engages upon the rubber sealing member. Negative pressure is then applied to the holes in the steel base plate, which thereby communicate via the or each open hole in the aluminium support plate, to evacuate the area bounded by the rubber sealing member and contained between the aluminium support plate and the workpiece.

**[0007]**

The vacuum thus applied serves to hold the workpiece firmly in place.

**[0008]**

whilst the machining operation is carried out on it. Although the term "vacuum" is used here conveniently. it is usually the case in practice that a perfect vacuum is never achieved - an average pressure of around 0.1 bar is more usual.

**[0009]**

Vacuum chucks with vertical faces operate in much the same wav.

**[0010]**

However, in contrast to horizontal support plates which may typically have a rectangular grid of grooves. the vacuum chuck may typically have a plurality of radial grooves interconnected by a plurality of concentric circular grooves.

**[0011]**

Known vacuum plates can be quite effective in clamping a workpiece.

**[0012]**

with little risk of damage to the surface of the workpiece by the application of mechanical clamping devices. However, the use of known vacuum plates can have a number of disadvantages.

**[0013]**

Firstly, known vacuum plates cannot be used with a great deal of success with thin sheet materials - such as might be employed, for example in the manufacture of aircraft parts such as fuselages and wings. With such workpieces, the size of the rubber sealing member on the support plate tends to be significant. as compared to the thickness of the material. Thus, there is a danger of undesirable deformation of the sheet material or. if it is brittle.

**[0014]**

it may fracture.

**[0015]**

Secondly. with known vacuum plates. it is generally not possible to machine right through a workpiece, at any point within the area defined by the rubber sealing member - unless quite complicated special steps are taken.

**[0016]**

which generally will be suitable only for one specific shape and size of workpiece. This is because. as soon as the workpiece is perforated. the vacuum is lost. Thus, the holding force on the workpiece is lost immediately.

**[0017]**

This can have dangerous consequences, especially if the perforation of the workpiece is accidental and unexpected. This disadvantage can be of particular significance when thin sheet materials, or the like. are being machined.

**[0018]**

Another disadvantage of known vacuum plates is that it is usually impracticable to perform a profiling operation on a held workpiece - that is.

**[0019]**

to cut around the peripherv of the workpiece down to the level of the support plate, even if this is outside the area of the rubber sealing member. The reason for this is that the profiling tool will tend to cut into the support plate itself, which will therefore degrade and require replacement or remachining.

**[0020]**

Such support plates are generally quite expensive and, in any event. will tend to wear and require replacement or remachining from time to time.

**[0021]**

Thus, although vacuum plates have inherently very useful properties, their applications have. in practice, been rather restricted to date, since it has not been possible to perform a number of common machining operations on workpieces held by vacuum plates.

**[0022]**

Other potential problems are that: it can be slow to fit the rubber sealing member in the groove(s), and often the best position is found only by trial and error; the vacuum plate must be free from swarf, etc., to effect a good vacuum: and it is difficult to incorporate known vacuum plates into automated (fIexible manufacturing) factories, because of the manual skills needed to set up the vacuum plates for different workpieces.

**[0023]**

Preferred embodiments of the present invention aim to provide vacuum plates which may be improved in the foregoing respects.

**[0024]**

According to one aspect of the present invention, there is provided a vacuum plate system comprising a base plate and a support plate: the base plate having a vacuum connection port. at least one aperture opening into a support surface of the plate. and connection means connecting said aperture with said port: and the support plate comprising a sheet of material having a working surface and a reverse surface, the working surface being formed with a plurality of cavities which open into the working surface, the plate being formed with at least one hole which extends between said working and reverse surfaces, and the support plate being placed, in use, upon said base plate with said reverse surface of the support plate on said support surface of said base plate, and said hole in communication with said aperture.

**[0025]**

Preferably, said hole is located in one of said cavities.

**[0026]**

Preferably, said base plate is provided with a plurality of said apertures and means for selectively opening and closing said apertures.

**[0027]**

Preferably, said support plate is formed with a plurality of said holes and at least one groove to interconnect said holes.

**[0028]**

Preferably. said support plate is formed with a plurality of said holes and each of a plurality of said cavities has a respective one of said holes located therein.

**[0029]**

According to another aspect of the present invention, there is provided a vacuum plate system comprising a base plate and a support plate: the base plate having a vacuum connection port. at least one aperture opening into a support surface of the plate. and connection means connecting said aperture with said port: and the support plate comprising a sheet of plastics material having a working surface and a reverse surface. the plate being formed with at least one hole which extends between said working and reverse surfaces, and the support plate being placed, in use, upon said base plate with said reverse surface of the support plate on said support surface of said base plate. and said hole in communication with said aperture.

**[0030]**

Preferably, the diameter of the or each said aperture is greater than twice the diameter of the or each said hole.

**[0031]**

Preferably, more than twice as many said holes are provided in said support plate than the number of said apertures in said base plate.

**[0032]**

Preferably, said support plate is provided on said working surface thereof with resilient projections which. in use, form a seal with a surface of a workpiece supported on said support plate.

**[0033]**

Preferably, said support plate is formed with a plurality of said holes.

**[0034]**

and said resilient projections form closed seals around at least some of said holes.

**[0035]**

Said resilient projections may form a closed seal around at least one area of said working surface which is not provided with a said hole.

**[0036]**

Said support plate may comprise a plurality of active modules which.

**[0037]**

in use, are disposed side by side on said base plate. each module having a said working surface. a said reverse surface. and at least one said hole which extends between said working and reverse surfaces to communicate with a respective said aperture in said base plate.

**[0038]**

Preferably. said support plate further comprises a plurality of blank modules which. in use. are disposed side by side on said base plate with said active modules, each blank module having a said working surface, a said reverse surface. but no said hole extending between said working and reverse surfaces.

**[0039]**

The invention extends to a vacuum plate system according to any of the preceding aspects of the invention, including a workpiece to which said support plate is detachably fixed.

**[0040]**

Said support plate may be detachably fixed to said workpiece by means of a temporary adhesive.

**[0041]**

A vacuum plate system according to any of the preceding aspects of the invention may include location means for positively locating said support plate on said base plate.

**[0042]**

Said location means may comprise interengaging projections and recesses provided on said support and base plates.

**[0043]**

Said recesses may be formed along edge areas of said support plate.

**[0044]**

At least one of said surfaces of the support plate may be formed with surface roughness to assist the transfer of positive or negative pressure across that surface.

**[0045]**

Said surface roughness may be formed by abrasion (e.g. scratching) of said surface.

**[0046]**

According to a further aspect of the present invention. there is provided a method of manufacturing a support plate as recited in any of the preceding aspects of the invention, comprising the step of passing a feedstock material between rollers to define a sheet having a surface pattern on at least one surface thereof.

**[0047]**

According to a yet further aspect of the present invention. there is provided a method of manufacturing a support plate as recited in any of the preceding aspects of the invention. comprising the step of passing a sheet of material through a punching machine and punching in the sheet a plurality of holes to form said holes in said support plate.

**[0048]**

Preferably. said holes are punched to form a predetermined pattern of holes in said sheet.

**[0049]**

According to another aspect of the present invention. there is provided a vacuum plate system comprising: a base plate having a vacuum connection port. a support surface. at least one aperture opening into said surface. and connection means connecting said aperture with said port: pressure generating means for generating both positive and negative pressures (with respect to ambient pressure); and control means for selectively applying positive or negative pressure to said vacuum connection port.

**[0050]**

Preferably, said base plate has a plurality of said apertures each connected to one of a plurality of said ports, and said pressure generating means and control means are arranged to apply positive and negative pressures selectively to said ports.

**[0051]**

According to another aspect of the present invention there is provided a vacuum plate system comprising: a base plate having a vacuum connection port. a plurality of apertures opening into a support surface of the plate, and connection means connecting said apertures with said port; closure means for closing and opening said apertures individually: and control means for selectively closing and opening said closure means.

**[0052]**

Said control means may be arranged to close and open said closure means in syncnronism with a predetermined machining operation carried out on a workpiece held on the vacuum plate.

**[0053]**

Said closure means may comprise a plurality of electrically operated and/or mechanically operated valves.

**[0054]**

Preferably, said control means comprises actuator means for actuating the closure means, the actuator means including at least part of said support plate and/or base plate.

**[0055]**

Preferably, said support plate is formed with actuator areas to cooperate with said closure means and thereby selectively open and close said closure means.

**[0056]**

Preferably, each of at least some of said actuator areas comprises an abutment disposed in a respective one of said holes and arranged to abut a valve stem of a respective one of said mechanically operated valves. thereby to open the valve.

**[0057]**

Each said mechanically operated valve may be mounted in a respective said aperture in said base plate and has a valve stem which is biassed towards a closed position in which at least part of the valve stem projects above said support surface of said base plate.

**[0058]**

According to a further aspect of the present invention. there is provided a method of holding a workpiece. comprising the step of placing the workpiece on a vacuum plate system according to any of the preceding aspects of the invention. and applying a reduced pressure to the connection port of said base plate to hold the workpiece on the vacuum plate.

**[0059]**

The invention also extends to a method of machining a workpiece.

**[0060]**

comprising the step of holding the workpiece on a vacuum plate system by a method according to the immediately preceding aspect of the invention. and machining the workpiece whilst held on the vacuum plate.

**[0061]**

According to another aspect of the present invention. there is provided a method of modifying a vacuum plate system having a base plate formed with at least one vacuum aperture. the method comprising the step of placing on the base plate a support plate as recited in any of the preceding aspects of the invention, to provide a vacuum path between the or each said vacuum aperture and the working surface of the support plate.

**[0062]**

The invention extends also to use of a support plate as recited in any of the preceding aspects of the invention in a method as above of holding andíor machining a workpiece.

**[0063]**

The invention also extends to a support plate as recited above in any of the preceding aspects of the invention. for use in a vacuum plate system or method of using a vacuum plate system.

**[0064]**

The various features mentioned above in connection with all aspects of the invention. including the steps of any method or process. may be combined in any combination. except combinations where at least some of such features and/or steps are mutually exclusive.

**[0065]**

For a better understanding of the invention. and to show how the same may be carried into effect. reference will now be made. by way of example.

**[0066]**

to the accompanying diagrammatic drawings, in which: Figure 1 is an upper perspective view of one example of a base plate for use in one example of a vacuum plate assembly embodying the invention; Figure 2 is an upper perspective view of a support plate for use with the base plate of Figure 1: Figure 3 is a lower perspective view of the support plate of Figure 2: Figure 4 is an enlarged sectional view of the support plate of Figures 2 and 3: Figure 5 is a lower perspective view similar to that of Figure 3. but showing an alternative support plate:: Figure 6 is an upper perspective view of another example of a base plate for use in another example of a vacuum plate assembly embodying the invention; Figure 7 is an upper perspective view of a support plate for use with the base plate of Figure 6; Figure 8 is an upper perspective view of part of the base plate of Figure I, with a special fixture for use therewith: Figure 9 is a lower perspective view of the fixture of Figure 8: Figure 10 is an upper perspective view of a general purpose fixture table for use with the base plate of Figure 1 or 6: Figure 11 shows in plan view part of another example of a plastics support plate: Figure 12 is a sectional view on the line 12-12 of Figure 11; Figure 13 is a view similar to Figure 12, but showing a workpiece supported on the support plate:: Figure 14 is a view similar to Figure 13, but showing a slightly warped or otherwise non-planar workpiece supported on the support plate; Figure 15 is a perspective view of a plate module for making up a support plate, together with a plurality of similar modules: Figure 16 is a sectional view of the module of Figure 15: Figure 17 is a sectional view of part of a support plate with a workpiece secured to it: Figure 18 is a sectional view of part of a support plate formed with positive location means; Figure 19 is a plan view of part of another support plate formed with positive location means: Figure 20 is a perspective view of a punching machine for use in the manufacture of a support plate: Figure 21 is a sectional view of a solenoid valve for closing a vacuum aperture in a base plate. the valve being shown in an open position:: Figure 22 is a view similar to Figure 21, but showing the solenoid valve in a closed position: Figure 23 is a sectional view of part of a base plate with alternative valves for closing respective vacuum apertures in the base plate. showing the valves in closed positions; Figure 24 is a view similar to Figure 23. but showing a support plate cooperating with the base plate to open the valves; and Figure 25 is a detail view showing in plan view one of a plurality of holes formed in the support plate of Figure 24.

**[0067]**

First of all. the vacuum table system made up of the components shown in Figures 1 to 4 will be described. by way of example.

**[0068]**

The base plate 10 that is shown in Figure I comprises a body 11 having an array of apertures 12 opening into a support surface 13 of the body 11. Around the array of apertures 12. there is formed a groove which follows a substantially rectangular path and which also opens into the support surface 13 A vacuum connection port 15 and a pressure connection port 16 are provided on the body 11. and are both connected to all of the apertures 12.

**[0069]**

Similarly. a further vacuum connecting port 17 and pressure connection port 18 are both connected to the groove 14.

**[0070]**

The body 11 may be made of steel. or, if desired, a composite of a steel lower portion and an aluminium top portion which provides the supports surface 13. Alternatively, other suitable materials may be used.

**[0071]**

Each of the apertures 12 is tapped, and is provided with a grub-screw 19. or the like. which screwthreadedly engages the aperture 12. The grubscrews 19 may be selectively inserted into and removed from the various apertures 12. so as to open or close selected ones of the apertures 12, as desired. Typically, such insertion and removal of the screws may be done manually, although the operation could be carried out by use of an appropriate tool provided on an automatic jig.

**[0072]**

The support plate 20 that is shown in Figures 2 to 4 comprises a sheet of plastics material having a working surface 21 and a reverse surface 22.

**[0073]**

The upper. working surface 21 is formed with an array of cavities 23.

**[0074]**

each of which opens into the working surface 21. As may be seen in the enlarged view of Figure 4. each of the cavities 23 is of shallow depth (although the cavities 23 may alternatively be deeper). In the centre region of each of the cavities 23. there is formed a respective hole 24 which passes right through the plate 20. between the working surface 21 and the reverse surface 22.

**[0075]**

The reverse surface 22 of the support plate 20 is formed with an array of grooves 25 which are arranged in a rectangular grid having intersections which coincide with the holes 24, and which are thereby interconnected bv the grooves 25. As is apparent from Figure A, the cross-sectional view there is taken along one of the grooves 25.

**[0076]**

The plastics support plate 20 is intended to be a disposable item and.

**[0077]**

to this end, may be made of any suitable material. For example. it may be of semi-rigid styrene. Of course. if it is important that the support plate 20 has special properties. for use in the manufacture of high value components.

**[0078]**

for example. it may be made of more expensive material. as circumstances require.

**[0079]**

In use. the vacuum plate assembly made up of the components shown in Figure 1 to 4 operates generally as follows.

**[0080]**

Firstly, pressure generating means is connected to the ports 15 to 18.

**[0081]**

This may comprise a single pressure generator which may generate either positive or negative pressure selectively. Alternatively, more flexibly, the pressure generating means comprises at least one vacuum generator for connection to the two connection ports 15 and 17. and at least one positive pressure generator (e.g. a compressed air generator) for connection to the positive pressure ports 16 and 18.

**[0082]**

Depending on the size of the workpiece to be held and machined. at least one of the grub-screws 19 is removed from its respective aperture 12.

**[0083]**

to leave that aperture open. The disposable support plate 21 is then placed on top of the base plate 11. and the workpiece is then placed on the support plate 20.

**[0084]**

A vacuum is then applied to the vacuum ports 15 and 17. This serves first of all to suck down the support plate 20 onto the support surface 13 of the base plate 10. To this end. the support plate 20 may be of a shape and size corresponding substantially to that of the base plate 10. in plan view.

**[0085]**

Because the or each aperture 12 which is open communicates with the reverse surface 22 of the support plate 20, the negative pressure that exists at the or each aperture 12 is thereby communicated to all of the small holes 24.

**[0086]**

by the network of grooves 25. Thus, the pressure is communicated to the cavities 23, which are in contact with the under surface of the workpiece that is being supported. Accordingly, this negative pressure serves to suck down the workpiece onto the support plate 20. and thereby securely hold it in place.

**[0087]**

on the support plate 20.

**[0088]**

Thus. a machining operation can be carried out on the workpiece that is so held in place by the vacuum.

**[0089]**

In contrast to known vacuum table systems. if it is desired to cut right through a workpiece. the appropriate cutting tool can achieve this and cut into the disposable support plate 20 to a degree. without losing the vacuum suction effect from the remainder of the workpiece.

**[0090]**

One reason for this is that the holes 24 which extend through the support plate 20 are of very small diameter, and therefore afford only a small amount of leakage. even when open to atmosphere. Indeed. we have found that a vacuum table system as shown in Figures 1 to 4 can operate quite satisfactorily even when the workpiece does not cover all of the support plate 20. because the rate of leakage through the holes 24 is so low.

**[0091]**

The fact that the cutting tool cuts into the support plate 20 is of little significance, since the support plate 20 is itself a relatively low-cost item. and can be scrapped (and/or recycled) whenever it is sufficiently worn.

**[0092]**

In addition to being able to cut right through a workpiece at an inner portion thereof, it is equally possible to profile a workpiece - that is, to cut it to a desired peripheral shape. cutting into the support plate 20 as necessary.

**[0093]**

Indeed, the cutting tool can even perform an undercut operation - for example, putting a radius on the underside of the workpiece. if required. so that the workpiece may be completely finished off at one setting.

**[0094]**

A particular advantage of the system illustrated in Figures 1 to 4 is that it is not necessary to provide any sealing member between the support plate 20 and the workpiece. Instead. the workpiece is sucked down directly onto the working surface 21 of the support plate 20. This means that the system is particularly suitable for use with delicate sheet materials - either flexible or brittle - which might otherwise be deformed or destroyed by localised forces exerted by a rubber sealing member, or the like. It will be appreciated that thin sheet materials tend to be very well supported on the flat working surface 23 of the support plate 20 and will generally experience a holding force that is large relative to its mass.

**[0095]**

Since no rubber sealing member (or the like) is required with the support plate 20. the illustrated vacuum table system may be used for many different types of workpiece. and is therefore particularly well suited for use in an automated (edge flexible manufacturing) factorv. The base plate 10 and the support plate 20 may be of any desired size and shape. Just by wav of example. the base plate 10 and the support plate 20 may each be of rectangular shape in plan view. having side dimensions from the region of 100 mm to the region of 10 m. Again. purely by way of example. the cavities 23 may be of circular shape, having a diameter in the region of 10 mm. and the holes 24 may be of circular cross-section. having a diameter in the region of 0.1 mm The grooves 25 may have a width in the region of 2 mm.The thickness of the support plate 20 may (again, purely just as one example of many) be in the region of 1 mm. and the depth of the cavities 23 and grooves 25 may be in the region of 0.2 mm.

**[0096]**

Since the force that holds the workpiece down on the working surface 21 of the support plate 20 is proportional to the area over which the negative pressure is applied. it is determined to an extent by the size of the cavities 23.

**[0097]**

Since the cavities 23 are of relatively large diameter. they can provide a relatively large effective working surface for the negative pressure. However.

**[0098]**

in practice. the effect of the negative pressure can prevail under the whole contact surface of the workpiece. due to leakage between the cavities - made possible, for example. by surface roughness of the workpiece and/or support plate. Because the holes 24 are of relatively small diameter. they minimize any undesirable leakage effects.

**[0099]**

The support plate 20 may be fabricated very simply by rolling a feedstock plastics material between rollers which form the cavities 23 and grooves 25 on the respective surfaces of the support plate 20. If the small holes 24 are not formed during this rolling process. they may be formed subsequently by a punching operation - for example. suitable diameter pins may be punched through the support plate 20. Any burrs caused bv the punching operation may be contained within the recesses 23 and/or grooves 25.

**[0100]**

The support plate 20 may be manufactured by alternative or addirional methods - such as moulding, extrusion. etc.

**[0101]**

The cavities 23 and/or holes 24 need not be of circular cross-section.

**[0102]**

but can be of any other desired shape - e.g. square. hexagonal. or polygonal.

**[0103]**

Likewise. the grooves 25 need not be arranged in a rectangular grid.

**[0104]**

It is not essential that a respective hole 24 is provided in connection with each of the cavities 23. Indeed. very surprisingly, we have found that an enhanced suction effect on a workpiece can be achieved by having a plurality of recesses such as 23. which have no holes 24 in them at all. In the limiting case we can provide just a single hole 24 at any desired location in the plate 20 provided that, on the working surface 23. it is in contact with a supported surface of the workpiece and. on the reverse surface 22. it is in contact with at least one of the apertures 12. We found that, presumably due to leakage, the vacuum or low pressure is transmitted from the base plate 10 to the working surface 21 of the support plate 20. and comes to prevail in all of the cavities 23 which are in contact with the supported workpiece.The formal rectangular array of grooves 25 may be substituted by an irregular pattern of grooves. or even bv a series of random scratches on the reverse surface 22 - or may be dispensed with altogether.

**[0105]**

The plastics support plate 20 may be rigid. semi-rigid or flexible. If very flexible. it may be draped under any component to be held for machining, which would be useful for irregular three-dimensional shapes.

**[0106]**

The support plate 20 may also be made as a flexible part of a belt-type conveyor system. which would be especially suitable for use in automated manufacturing processes It will be appreciated that. instead of applying negative pressure to the apertures 12 and the groove 14 in the base plate 10, positive pressure (e.g.

**[0107]**

compressed air) could alternatively be applied to either or both of these.

**[0108]**

Thus. the vacuum table could be used. when required, as an air beb - for example, to manoeuvre a heavy workpiece into a desired position. The positive pressure, at a controlled rate, may also be used. either during or after a machining operation, to blow away swarf and/or coolant from the vacuum table. If vacuum is applied to the groove 14 and positive pressure to the holes 12. then the vacuum may serve satisfactory to hold down the supportplate 20.

**[0109]**

whilst the positive pressure serves to support the workpiece on an air cushion.

**[0110]**

on top of the support plate 20.

**[0111]**

The alternative support plate 50 which is shown in Figure 5 is generally similar to the support plate 20 of Figures 2 to 4. However. in the arrangement of Figure 5, the support plate 20 has grooves 55 which are arranged in discrete sets. such that all of the grooves in a given set are interconnected. but the grooves of different sets remain separate from one another. In use of such a support plate 50. the arrangement is preferably such that at least one open aperture 12 is provided under each set of grooves 55 which is effective to hold down the workpiece to be supported.

**[0112]**

The vacuum plate system illustrated in Figures 6 and 7 operates in generally the same manner as that illustrated in Figures 1 to 4. Thus. a base plate 60 comprises a body 61 having a plurality of apertures 62 opening into a support surface 63 thereof.

**[0113]**

A plurality of slots 64 surround the array of apertures 62. A vacuum connection port 65 and a compressed air connection port 66 are connected to all of the apertures 62 and slots 64 by valve means (not shown). An electrical connector 69 carries electrical connections between a controller (not shown) and the valve means (not shown) which connect the ports 65 66 to the apertures and slots 62. 64. and which are electromechanical in nature. The controller may be. for example, a Numerical Control (NC) type or Programmable Logic (PLC) type of controller. The valve means may be controlled and/or actuated by alternative or additional means - e.g. mechanical or fluidic (hydraulic or pneumatic) means.

**[0114]**

In response to signals received by the electrical connector 69 the electromechanical valve means are individually set into one of three conditions - namely (i) connected to the vacuum port 65. (ii) connected to the compressed air port 66, or (iii) off. Vacuum and compressed air are supplied continuously to the ports 65 and 66. Thus. in response to operation of the various valve means. each of the apertures 62 and slots 64 may be selectively closed. connected to positive pressure, or connected to vacuum.

**[0115]**

The support plate 70 comprises a sheet of plastics material in an array of generally square-shaped apertures 71. In use. the support plate 70 is placed on top of the base plate 60. with each of the sauare apertures 7i disposed above the respective one of the apertures 62 in the base plate 60.

**[0116]**

The workpiece is placed upon the support plate 70. where it is held by the vacuum. and may be machined. generally as described above.

**[0117]**

However, in the embodiment of Figures 6 and 7. vacuum supplied to the supported surface of the workpiece can be quite accurately controlled by the automatic selective closing and opening of the apertures 62. That is.

**[0118]**

typically, a vacuum will be supplied to all of the slots 64. to hold the support plate 70 down on the base plate 60. A vacuum will be supplied to all those of the apertures 62 which are disposed below the supported surface of the workpiece. All other apertures 62 will be closed. In this way. the workpiece can be very effectively held down.

**[0119]**

A particularly useful feature of this arrangement is that. in an area of the workpiece that is cut through to the region of the support plate 70. the or each adjacent aperture 62 may be closed off, to avoid swarf, coolant. etc entering the vacuum system via any aperture 62. and to minimise reduction of the vacuum effect. Alternatively. at an appropriate time in the machining operation. compressed air can be supplied to any selected one of the apertures 62. so as to positively blow away any swarf, coolant. etc. It will further be appreciated that, upon supplying a sufficient number of the apertures 62 with compressed air, the workpiece can be floated above the support plate 70. to allow it to be manoeuvred into position. or transported.

**[0120]**

It is not necessary to provide the illustrated base plate 10 or 60 with grooves to accommodate a rubber sealing member. However. if desired. such grooves may be included.

**[0121]**

In Figures 8 and 9 there is shown a special fixture 80. which is adapted to be secured to the base plate 10 of Figure 1 (or alternatively the base piate 60 of Figure 6). The fixture 80 has four holes 81 formed therein.

**[0122]**

at a mutual spacing which correspond to that of the array of apertures 12 in the base plate 10. Securing bolts 82 pass through the holes 81 and screwthreadedly engage the respective apertures 12. to secure the fixture 80 to the base plate 10.

**[0123]**

The fixture 80 is preformed at 83 to the shape of a special workpiece to be machined. and in the profiled portion 83. there are holes 84 which pass right through the fixture 80 to communicate with at least one aperture 12 in the base plate. The upper surface of the profiled portion 83 carries rubber sealing members or the like 85 which are located in respective grooves formed in the profiled portion 83.

**[0124]**

The lower surface 86 of the fixture 80 can be seen in Figure 9 and likewise is formed with a groove in which there is disposed a rubber sealing member 86 or the like.

**[0125]**

In use of the fixture 80. the special workpiece to be machined fits closelv onto the profiled part 83, and is held firmly thereon by the vacuum applied via the holes 84. and sealed by the seal 85. The seal 86 seals the base of the fixture 80 to the base plate 10. Positive pressure may be applied via the apertures 84. to eject the workpiece from the fixture after machining, or to assist removal of the workpiece therefrom.

**[0126]**

The general purpose fixture table 100 that is shown in Figure 10 is formed on an upper surface thereof with a plurality of T-slots 101 arranged to receive standard fixing means for various workpieces to be machined. In use, the fixing table 100 may be held down on a base plate such as 10 or 60.

**[0127]**

bv direct action of the vacuum applied thereby, or may be placed upon a support plate such as 20. 50 or 70 which in turn is placed upon a base plate such as 10 or 60.

**[0128]**

Although the fixture table 100 is shown as comprising T-slots.

**[0129]**

alternative fixture tables having other standardized fastening methods may alternatively be employed.

**[0130]**

The support plate 110 that is shown in Figures 11 and 12 is preferably formed as a sheet of plastics material and has an upper, working surface 111 and a lower, reverse surface 112. The support plate 110 is formed with an array of cavities 113 in its upper working surface 111. each cavity 113 being formed with a through hole 114 which passes right through the support plate 110. The cavities 113 and holes 114 are generally similar to the cavities and holes 23. 24 of the support plate 20 as shown in Figure 4. and the support plate 110 may be used in a similar manner. If desired, the reverse surface 112 of the support plate 110 may be formed with grooves such as the grooves 25 shown in Figure 4. or alternative means for communication with vacuum apertures in a respective base plate with which the support plate 110 is used.

**[0131]**

As shown in Figure 12. however. the reverse surface 112 is plane. In this configuration, each hole 114 may register with a respective vacuum aperture in a base plate on which the support plate 110 is mounted.

**[0132]**

The working surface 111 of the support plate 110 is also formed with a rectangular grid array of lip seals 115. each of which comprises a pair of upstanding ribs 116 formed in a respective recess 117. The ribs 116 are flexible. and converge slightly as they extend upwardly. Preferably, they are formed integrally with the support plate 110 - for example. by a moulding.

**[0133]**

rolling and/or pressing process. By way of further example. support plates such as 110 may be formed by a two-stage rolling process. In a first stage, a sheet or roll of plastics material is passed warm through embossing rolls to form surface details (e.g. cavities. grooves. projections, etc.) on the sheet.

**[0134]**

For example, the ribs 116 may be formed at this stage, perpendicular to the general plane of the sheet. Then, in a second stage, the formed sheet is passed through a second set of rolls which wipe the ribs 116 to set them at an angle, as shown in Figure 12, for example. The sheet emerging from the second set of rolls is then blasted with cold air or gas to set the ribs 16 (and any other parts) at their desired angles.

**[0135]**

The lip seals 115 serve to co-operate with a workpiece placed on the support plate 110, thereby to provide a seal around each cavity 113 and its respective through hole 114. Preferably, the upstanding projections 116 are configured so as to have a relatively weak resilient bias. such that they tend not to deform fragile work pieces placed upon the support plate 110.

**[0136]**

However. if desired, the lip seals 115 may be made more robust with more strongly resiliently biased projections 116. for use with substantial workpieces that are not susceptible to deformation.

**[0137]**

As shown in Figure 13. a workpiece 130 placed on the support plate 110 deforms the projections 116. so as to provide a good seal by way of the lip seals 115. In Figure 13. the workpiece 130 is planar. and sits squarely and firmlv on the support plate 110. to compress the lip seals 115 fully.

**[0138]**

In Figure 14. however. a similar workpiece 140 rests slightly out of true on the support plate 110. This may be due to the shape of the workpiece 140 itself. some slight warping thereof. or some projection (e.g. swarf) on the support plate 110 causing some slight local deformation. As may be seen.

**[0139]**

although the left hand lip seal 115 (as viewed in Figure 14) is almost fully compressed. the right hand lip seal 115 is significantly less compressed. but the resilient bias of the projections 116 still causes the lip seal 115 to make a good sealing contact with the workpiece 140.

**[0140]**

Thus. the support plate 110 may serve to provide good sealing contact with various different workpieces and to accommodate any non-planar variations in the contact surface of the various workpieces.

**[0141]**

For the most part. as illustrated in Figure 11 and described above, a complete lip seal 115 surrounds each cavity 113 with respective through hole 114 However. less extensive lip seals may be provided - for example. such that not each cavity 113 and through hole 114 is entirely surrounded with its own lip seal. but such that a plurality of such cavities and through holes 113.

**[0142]**

114 share a common lip seal boundary.

**[0143]**

It will be appreciated, however, that. especially for supporting fragile and/or readily deformable workpieces, an extensive array of relatively small lip seals 115 may provide an excellent sealing function with the workpiece.

**[0144]**

without causing deformation of anything like the degree found in prior art arrangements. where only a single substantial rubber sealing member is provided around the periphery of the workpiece.

**[0145]**

In a variant. lip seals such as 115 may be provided around areas of the support plate 110 in which no through hole 114 is provided - and. optionally.

**[0146]**

no cavity 113 is provided. either. For example. as illustrated in Figure 11.

**[0147]**

no through hole 114 and cavity 113 is provided in the area 119 surrounded by a respective lip seal boundary 115. Due to its resilient nature. the lip seal 115 in this area may act as a sucker (e.g. in the manner of a rubber sucker) to provide adhesion to the workpiece. even when no vacuum is positively applied via a through hole such as 114. By providing a plurality of areas such as 119 over the surface of the support plate 110. useful initial adhesion between the support plate 110 and a respective workpiece may be provided. before full vacuum is applied in preparation for a machining operation.

**[0148]**

In another variant. lip seals similar to the lip seals 115 may be provided. additionally or alternatively, on the reverse surface 112 of the support plate 110, to assist in locating and/or securing the support plate on a respective base plate - especially if the base plate is of a conventional design.

**[0149]**

In the foregoing, various support plates are shown as being of unitary (mainly one-piece) construction. They may be used for machining very large workpieces. the dimensions of which extend into several metres. In certain applications. it can be advantageous to have both vacuum base plates and the support plates thereon each of unitary construction. However. alternatively.

**[0150]**

support plates (and base plates) may be built up from a plurality of modules One example of such a support plate module is shown in Figures 15 and 16.

**[0151]**

The support plate module 150 shown in Figures 15 and 16 has a working surface 151 and a reverse surface 152. Formed in the working surface 151 are four cavities 153. each of which is formed with a central through hole 154. A plurality of grooves 155, or other recess formation. is provided on the reverse surface 152. to interconnect the through holes 154.

**[0152]**

The plate module 150 is formed around its periphery with a skirt 156.

**[0153]**

The module 150. as shown in Figures 15 and 16. is square in plan view However. it could be of any other desired shape. and provided with any other desired number of cavities 153 and through holes 154.

**[0154]**

In use a plurality of modules 150 are assembled on a vacuum base piate (e.g. similar to the base plate 10 or 60 shown in Figures 1 or 6). The skirts 156 on the modules 150 engage in corresponding grooves formed in the support surface of the respective base plate. Vacuum is applied to the reverse surfaces 152 of the modules 150. and this vacuum is transmitted to the working surfaces 151 of the modules 150. upon which a workpiece is placed.

**[0155]**

Thus. the modules 150 may operate in a manner similar to the previously described support plates. However, use of the modules 150 has the advantage that they may be placed on a general purpose vacuum base plate. with only so many modules 150 as are required for a given workpiece to be machined. In the general situation, the vacuum base plate may frequently have a larger surface area than is used by the modules 150. Then.

**[0156]**

areas of the base plate that are not being used may be shut off. To this end.

**[0157]**

the base plate may be similar to a more or less conventional vacuum table.

**[0158]**

with unused vacuum apertures being closed off by screws (e.g. as the grub screws 19 of Figure 1). Alternatively. the base plate may comprise a more sophisticated vacuum table. having valve means to open and close selectively those vacuum apertures that are required with a given array of modules 150 for example. using control means as previously described above with reference to the preceding embodiments.

**[0159]**

In another variation. there may be provided blank modules. which are similar to the modules 150. but provided with no through holes 154. The cavities 153 and/or recess means 155 may be omitted also. The blank moduies are placed over areas of the vacuum table that are not required. and therefore will serve automatically to close off any vacuum applied by vacuum apertures, and thereby prevent wastage. In fact. if there is at least one vacuum aperture underneath each blank module. that vacuum will itself hold the blank module in place.

**[0160]**

It may be appreciated by those skilled in the art that the modules 150 (and blank modules) may readily be placed on a base plate (vacuum table) by robotic means, as an alternative to manual placement. The blank modules may be distinguished visually from the active modules 150 - e.g. by being of a different colour, and/or provided with some visual reference means.

**[0161]**

Particularly if the blank and active modules are of different colours, then the outline shape of the workpiece to be machined will be laid out on the base plate. and vacuum will be applied only where required.

**[0162]**

The base piate itself may be provided with visual or other markings, to provide positional references to assist a robotic device in positioning modules (or other parts) accurately on the base plate.

**[0163]**

As an alternative to using blank modules and/or switching off vacuum to unwanted areas of the base plate (vacuum table). relatively small diameter apertures (such as the apertures 154) may be provided in the vacuum base plate. and larger apertures in the modules 150. In fact this reverse arrangement of the relative diameters of the vacuum apertures and support plate holes may be applied generally in other embodiments of the invention.

**[0164]**

It has been mentioned above that the reverse surface of the support plate 20 (as shown in Figure 4) may be formed with a series of random scratches. to substitute for the regular array of grooves 25. Similarly, increased workpiece holding power may be obtained by scarifying the working surface 151 of the modules 150 - for example. with a coarse grit abrasive (e.g. 60 grit) to give a scratch surface in which the scratches have a depth of the order of 100 microns or so.

**[0165]**

The active modules 150. and optional blank modules. may readily be formed from plastics by moulding. However. as with all support plates mentioned in this specification. they may be made of alternative materials and bv alternative manufacturing processes. if desired.

**[0166]**

In Figure 17. a support plate 170 has a workpiece 179 mounted on a working surface thereof. In this example, the support plate 170 is detachably secured to the workpiece 179 by a light temporary adhesive, to assist initial positioning of the components, prior to a machining operation. The support plate 170 is formed with cavities 173 in its working surface and respective through holes 174, and operates in a generally similar manner to the previously described embodiments.

**[0167]**

The alternative support plate 180 shown in Figure 18 is generally similar to that shown in Figure 17. However, it is formed on its reverse surface 182 with a plurality of depending spigots 188. through each of which a respective through hole 184 extends. The spigots 188 may engage corresponding recesses formed in a respective base plate on which the support plate 180 is mounted. and serve to locate the support plate on the base plate with accuracy. Preferably, the size of the spigots 184 corresponds to that of the recesses 183 in the working surface 181 of the support plate, such that sheets of support plates such as 180 may be stacked one upon the other. with the spigots 184 engaging in.the recesses 183 to provide support of the stacked sheets. without deformation thereof. This may be particularly useful where the sheets of support plate 180 are manufactured of plastics and are still hot after manufacture - and also where lip seals such as the lip seals 115 of Figures 11 and 12 are provided in the support plates.

**[0168]**

Figure 19 shows an elongate support plate 190 formed with an array of cavities 193 and through holes. that are shown just diagrammatically in the figure. Extending along each side of the support plate 190 is a respective series of sprocket holes 197. These serve to co-operate with corresponding projections formed on a respective base plate, to locate the support plate 190 accurately thereon.

**[0169]**

The general operation of the support plate 190 may be along the lines of the previously described embodiments, and therefore need not be repeated here The punching machine 200 shown in Figure 20 comprises a frame 201.

**[0170]**

a gantry 202 and. mounted in the gantry, a plurality of punch members 203 with means (not shown) for actuating the punch members.

**[0171]**

The punching machine 200 is adapted to receive a strip of plastics (or other) material 204. which is supported on the body 201 and passes below the gantry 202. As it passes below the gantry 202, it is punched selectively bv the punch means 203 - which may be controlled and/or actuated either manually or automatically.

**[0172]**

After punching, the plastics sheet 204 emerges from the machine 200 with a pattern of holes 205 formed therein. The pattern of holes 205 formed on the plastics sheet 204 corresponds generally to the outline of a workpiece to be formed, in order to provide vacuum only where required. The perforated sheet 204 may thus serve as an elongate support sheet. which may be used generally as described in the preceding embodiments of the invention.

**[0173]**

The punch means 203 may each form a simple through hole (for example, such as the hole 24 in Figure 4). Alternatively, the punch means 203 may be so configured as to form cavities (such as the cavities 23 of Figure 4) simultaneously with the through holes 24. In an alternative arrangement. more than one forming operation may be performed on the plastics sheet 204. For example. features such as the cavities 23 and grooves 25 of Figure 4 may be formed during hot rolling of the plastics sheet 24. and only through holes such as the holes 24 formed by the punching machine 200.

**[0174]**

A plastics sheet having generally the configuration of the support plate 110 of Figures 11 and 12 may be preformed without the respective through holes 114. which are subsequently formed by a punching machine such as the punching machine 200. The punching machine 200 may also form locating apertures such as the sprocket holes 197 of Figure 19. These may be formed in the same operation as actuation of the punch means 203. the locating apertures then serving immediately to register with corresponding projections from the machine body 201. to locate the sheet 204 positively on the punching machine 200. Alternatively. the sheet 204 may be preformed with locating apertures. which assist in location during the punching operation.

**[0175]**

Figures 21 and 22 show a solenoid valve 210 for opening and closing a respective aperture 212 in a base plate 220. The base plate 220 may perform a function similar to that performed by the base plate 60 of Figure 6.

**[0176]**

In Figures 21 and 22. connections to a vacuum supply are not shown.

**[0177]**

However. as will be readily appreciated by those skilled in the art. suitable connections provide a source of vacuum to the underside (as seen) of the aperture 212. Also. as previously described. the vacuum source may be replaced by a pressure source.

**[0178]**

The solenoid valve 210 comprises a solenoid assembly 211 in which a coil 213 is provided around a magnetisable core 214. Suitable electrical connections are made to the coil 213. selectively to energise and de-energise the same. A valve member 215 is resiliently mounted (for example on a leaf spring 216) to bias the valve member 215 towards a valve seat 217 in the underside (as seen) of the vacuum aperture 212.

**[0179]**

Upon energising the coil 213, the valve member 215. which is made of or includes a magnetic material. is attracted by the core 214 and thereby away from the valve seat 217. to open the vacuum aperture 212. Upon de energising the coil 213. the valve member 215 is urged under the resilient bias of the leaf spring 216 towards the aperture 212. where it engages with the valve seat 217 to close the aperture 212. As may be seen. the valve member 215 and valve seat 217 have co-operating frustro-conical surfaces. to provide sealing engagement.

**[0180]**

Thus. by selectively applying power to the coil 213 the vacuum aperture 212 may selectively be opened and closed. Typically, the base plate 220 will comprise an array of apertures 212, each with a respective solenoid valve 210 to open and close the aperture selectively. By suitable control signals sent to the coils 213. desired areas of the base plate (vacuum table) may be subjected to vacuum. In particular, areas of the base plate that are not required for machining of a particular workpiece may be switched off.

**[0181]**

The electrical connections to the coils 213 of the various solenoid valves 210 may be made by a matrix of electrical conductors. This may be secured to or provided as part of the base plate 220 itself. In another embodiment. a matrix of electrical conductors may be provided on a support plate (such as the support plate 110 of Figures 11 and 12 - or other support plates as previously described), and means provided for making electrical contact between the array of conductors and the coils 213 below the base plate 220. In this way, the matrix of electric conductors can selectively be varied to cause activation only of desired ones of the solenoid valves 210.

**[0182]**

appropriate to the forming of a particular shape.

**[0183]**

An alternative, mechanical valve arrangement is shown in Figures 23 to 25.

**[0184]**

In Figure 23 a base plate 230 (vacuum table) is formed with a plurality of vacuum apertures 232, each of which opens into a support surface 233 of the base plate 230. Mounted in each of the apertures 232 is a respective valve member 234. which is resiliently biased (for example. by means of a coil spring 235) into a closed position.

**[0185]**

Each valve member 234 comprises a central stem 236 and, provided intermediate the ends of the stem 236. an enlarged body portion 237. The enlarged body portion 237 is mounted for sliding movement within an enlarged portion 238 of the respective vacuum aperture 232. and has a chamfered sealing surface 239 which is adapted to engage sealingly with a corresponding sealing surface 240 provided on the vacuum aperture 232. The coil spring 235 bears against a rear face of the enlarged body portion 237 and.

**[0186]**

at its other end. on an projection or abutment surface (not shown) suitably formed within the base plate 230.

**[0187]**

As shown in Figure 23, the valve members 234 are resiliently biased into their closed positions, in which upwardly projecting portions of their valve stems 236 project above the support surface 233 of the base plate 230.

**[0188]**

In Figure 24, a plastics support plate 250 is disposed on top of the base plate 230 Typically, a workpiece in turn is disposed on top of the support plate 250. to assist in holding it down onto the support surface 233 of the base plate 230. However. the workpiece is not shown in the figures. in the interests of clarity.

**[0189]**

The support plate 250 may be generally similar to the support plate which is shown in Figure 20. That is. it may conveniently be formed from a plastics sheet which is formed and/or punched as desired. The support plate 250 is formed in its working surface 251 with an array of cavities 253 in a manner similar to most of the preceding embodiments. However, each cavity 253 is provided with a respective central aperture 254 which is different from preceding embodiments. in that it is formed with a cruciform abutment member 255 therein.

**[0190]**

When an aperture 254 is placed in register with a respective vacuum aperture 232, the cruciform abutment member 255 abuts against the upper surface of the respective valve stem 236, to depress the valve member 234 against its respective spring bias, and thereby open the valve and the vacuum aperture 232 to the prevailing vacuum (or positive pressure if alternatively provided).

**[0191]**

Thus, it will be appreciated that, in the embodiment of Figures 23 to 25, the valves 234 may be actuated automatically, simply by positioning the respective support plate 250 thereon. Where through holes 254 are provided.

**[0192]**

the respective valves 234 are opened, to allow vacuum (or positive pressure) to be transferred to the workpiece on the support plate 250.

**[0193]**

In areas of the support plate 250 where no through holes 254 are formed. the reverse surface 252 of the support plate 250 bears against the valve members 234. again to cause the valves to be open. However. in this case, since there is no aperture 254 to pass the vacuum through the support plate 250. the vacuum simply serves to hold the support plate 250 firmly in position on the base plate 230.

**[0194]**

In areas of the base plate 230 where no support plate 250 at all is provided. the valve members 234 are free to be urged upwardly to close off their respective vacuum apertures 232. In this way, it is ensured automatically that no vacuum is lost in non-working areas of the base plate 230. This may be of particular advantage where parts of a workpiece are cut away and/or undercut since, in the event that the support plate 250 is also partially cut away, any respective valves 234 thereunder are automatically closed. as soon as the support plate 250 (or part thereof) is removed.

**[0195]**

If desired. the support plate 250 may be also formed with alternative through holes without cruciform abutments therein (or alternatively blind recesses in the reverse surface 252), to allow the valve members 234 to be resiliently urged into a closed position, in selected areas below the support plate 250.

**[0196]**

Although the through holes 254 are shown and described above as having a cruciform abutment member 255 therein, alternative configurations may be used. provided that the valve member 234 is appropriately activated and vacuum (or positive pressure) is free to pass to the working surface 251 of the support plate 250 where required.

**[0197]**

Alternative means may be provided for actuating valve members such as 234. For example alternative valve members may have valve stems equivalent to the valve stems 236 which do not protrude above the support surface 233 of the base plate 230. when the valves are closed. In such a case, means may be provided to protrude downwardly. in order to open the valves.

**[0198]**

For example, the respective support plate (equivalent to the support plate 250) may be formed with downward projections which engage with the modified valves to open them, when the support plate is in position on the base plate.

**[0199]**

Yet further alternative means may be provided for actuating valves.

**[0200]**

For example, interengaging projections and/or recesses and/or abutment surfaces between the support plate. base plate and valve means may be provided in regions other than the through holes such as 254. in order to actuate the valve means. For example. if a support plate is provided with a depending skirt (simiIar to the skirt 156 shown in Figure 16). this may activate a respective valve means when engaged in a corresponding groove formed on a respective base plate.

**[0201]**

As indicated in the foregoing, embodiments of the present invention may be applied to vacuum plates (including vacuum chucks and the like) of any dimensions. but may find particular advantage when applied to large vacuum plates, the dimensions of which run into several metres. Typically.

**[0202]**

there would be provided means for mounting a machine tool in relation to the vacuum plate and means for providing relative movement between the machine tool and the vacuum plate. In very large installations. the machine tool may typically move with respect to the vacuum plate. Alternatively. the vacuum plate itself may move with respect to a fixed machine tool - for example, in the manner of a conveyor. In all cases, control means may be provided for providing increased vacuum in a localised region of the vacuum plate - preferably, in a region where machining is actually being carried out and. optionally. relatively lower vacuum in other areas.

**[0203]**

Control means may be provided for providing variable settings of vacuum and/or positive pressure - for example. at a first setting whilst a workpiece is being manoeuvred into position. and at a second setting when a machining operation is being carried out on the workpiece.

**[0204]**

Thus. the illustrated embodiments of the invention may provide vacuum plate svstems which provide positive location of workpieces to be machined and may be much more versatile than previously proposed vacuum plates.

**[0205]**

Although the illustrated embodiments are generally shown as substantially horizontal support tables, it is to be understood that the arrangements disclosed may equally well be adapted to vacuum plates for use in other orientations - for example. generally circular plates which are used in a generally upright position in the manner of vacuum chucks.

**[0206]**

The illustrated vacuum plates may be used with particular advantage with thin sheet materials. such as those employed in the manufacture of aircraft parts such as fuselages and wings. for example.

**[0207]**

Although Figures 1 and 6 disclose special base plates for use with the support plates of Figures 2 to 5 and 7, those support plates may alternatively be employed with base plates of conventional vacuum plate systems. In such a case. any rubber sealing member or the like that is used in such a conventional base plate may be disposed around the general periphery of the support plate as shown in Figures 2 to 5 or 7. In general. the various support plates illustrated and described herein may be used, where practical, with the various different base plates illustrated and described herein. as well as with conventional base plates.

**[0208]**

Preferably. the peripheries of the support plates shown and described herein have a plain. smooth surface.

**[0209]**

In an alternative support plate (not shown), recesses such as the recesses 23 of Figure 2 may be dispensed with. and the support plate may simply comprise a large plurality of very small holes such as the holes 24 which pass right through the support plate.

**[0210]**

Rigid and semi-rigid support plates may optionally be thermally vacuum formed, moulded or extruded to conform 3-dimensional shapes.

**[0211]**

Although, in the above description, the workpieces are stated to have machining operations performed on them, it will be appreciated that other operations may alternatively be performed. Although compressed air is given above as an example for a pressurised gas. it is to be appreciated that alternative pressurised gasses may be used.

**[0212]**

In the examples of Figures 2 to 5 at least. it is preferred that the vacuum plate system is utilized with a vacuum pump of sufficiently large capacity that, even with all of the apertures 12 completely unblocked and no workpiece in place, the support plate may nevertheless be well held down by the vacuum.

**[0213]**

The reader's attention is directed to all papers and documents which are filed concurrently with or previous to this specification and which are open to public inspection with this specification. and the contents of all such papers and documents are incorporated herein by reference.

**[0214]**

All of the features disclosed in this specification (including any accompanying claims. abstract and drawings), and/or all of the steps of any method or process so disclosed. may be combined in any combination. except combinations where at least some of such features and/or steps are mutually exclusive.

**[0215]**

Each feature disclosed in this specification (including any accompanying claims. abstract and drawings), may be replaced by alternative features serving the same. equivalent or similar purpose. unless expressly stated otherwise. Thus, unless expressly stated otherwise. each feature disclosed is one example only of a generic series of equivalent or similar features.

**[0216]**

The invention is not restricted to the details of the foregoing embodiment(s). The invention extends to any novel one, or any novel combination. of the features disclosed in this specification (including any accompanying claims, abstract and drawings), or to any novel one. or any novel combination, of the steps of any method or process so disclosed.

## Classifications

- B25B11/005
- B25B11/00
- B25H1/08

## Cited patent documents

- [DE-3140882-A1](https://patents.google.com/patent/DE3140882A1/en) — ISR
- [DE-8700766-U1](https://patents.google.com/patent/DE8700766U1/en) — ISR
- [DE-8703223-U1](https://patents.google.com/patent/DE8703223U1/en) — ISR
- [EP-0159623-A2](https://patents.google.com/patent/EP0159623A2/en) — ISR
- [FR-2513160-A1](https://patents.google.com/patent/FR2513160A1/en) — ISR
- [US-4723766-A](https://patents.google.com/patent/US4723766A/en) — ISR

---

Generated by IPtorch. Verify legal conclusions against the official publication.
