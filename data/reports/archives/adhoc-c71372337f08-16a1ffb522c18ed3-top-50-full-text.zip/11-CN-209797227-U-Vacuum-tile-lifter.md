# 11. Vacuum tile lifter

- **Archive rank:** 11 of 50
- **Publication:** [CN-209797227-U](https://patents.google.com/patent/CN209797227U/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/068832715/publication/CN209797227U?q=pn%3DCN209797227U)
- **Publication date:** 2019-12-17
- **Filing date:** 2019-05-15
- **Earliest priority:** 2019-05-15
- **Family:** 68832715
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** GUANGZHOU ZHONGHE TOOLS CO LTD

## Abstract

The utility model discloses a ceramic tile ware is carried in vacuum, its structure includes the handle main part, presses the pressing sheet, seal gasket, spring, fixed screw, metal soleplate, sponge, handle flexible glue, sealing washer and metal strip, the utility model discloses a make the vacuum and adsorb the ceramic tile, use the difficult fatigue damage&#39;s of sponge and metal sheet material, the sponge material can perfectly laminate on adsorbing coarse plane, still has fairly big adsorption affinity, can also reduce the instability when using, and convenient to use, need not come the switch through great strength gas repeatedly and whether adsorb the ceramic tile, this type of adsorption mode can improve absorptive stability, and adsorption affinity is also comparable with the sucking disc formula, and relative electrodynamic type is also more durable and low-priced.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-209797227-U/pdf000.png)

![Sketch 1 for CN-209797227-U](https://nimo.iptorch.com/refdrawing/CN-209797227-U/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-209797227-U/pdf001.png)

![Sketch 2 for CN-209797227-U](https://nimo.iptorch.com/refdrawing/CN-209797227-U/pdf001.png)

## Claims

### Claim 1 (independent)

Claims (7) The utility model provides a tile ware is carried in vacuum which characterized in that: comprises a handle main body (1), a pressing sheet (2), a sealing gasket (3), a spring (4), a fixing screw (5), a metal bottom plate (6), a sponge (7), a handle soft rubber (8), a sealing ring (9) and a metal strip (10), wherein the handle main body (1) is the main body part of the vacuum tile lifter, the pressing sheet (2) is arranged at the right end of the handle main body (1) and is sealed through the sealing gasket (3), an air outlet is formed in the head of the handle main body (1), the handle main body (1) penetrates through the handle main body (1) through the metal strip (10) to be connected with the pressing sheet (2), the pressing part at the upper end of the pressing sheet (2) is tightly attached to the air outlet of the handle main body (1) through the spring (4), the bottom of the handle main body (1) is fixed with the metal bottom plate (6) through the fixing screw (5), and the sealing ring (9) is installed at the joint of, the handle is characterized in that a sponge (7) is arranged at the bottom of the metal bottom plate (6) and is fixed through glue in an adhesion mode, and a handle soft rubber (8) is arranged in the middle of the handle main body (1).

### Claim 2

A vacuum tile lifter according to claim 1, wherein: the tail end of the handle main body (1) is provided with an air suction opening for connecting a pipeline.

### Claim 3

A vacuum tile lifter according to claim 1, wherein: two round holes are arranged on the metal bottom plate (6).

### Claim 4

A vacuum tile lifter according to claim 3, wherein: the diameter of the round hole is 25 mm.

### Claim 5

A vacuum tile lifter according to claim 1, wherein: the number of the fixing screws (5) is eight.

### Claim 6

A vacuum tile lifter according to claim 5, wherein: the four fixing screws (5) are in a group and respectively correspond to the positions of the two round holes on the metal bottom plate (6).

### Claim 7

A vacuum tile lifter according to claim 1, wherein: the number of the sealing rings (9) is two.

## Full description

**[p0001]**

Description Vacuum tile lifter Technical Field The utility model relates to a carry ceramic tile ware technical field, concretely relates to ceramic tile ware is carried in vacuum. Background Ceramic tiles, also known as ceramic tiles, are made of refractory metal oxides and semimetal oxides by grinding, mixing, pressing, glazing and sintering to form acid and alkali resistant porcelain or stony materials, building or decorative materials, called ceramic tiles. Its raw and other materials are formed by clay, quartz sand etc. mixture mostly, and along with modern society's rapid development, the application of ceramic tile in the life is more and more, and the ceramic tile can be used to carry the ceramic tile ware usually when installation or transportation, makes better carrying of ceramic tile, and the ceramic tile ware of carrying on the market at present mainly divide into sucking disc formula and electronic sucking disc formula two kinds: this sucking disc formula carry ceramic tile ware need increase the sucking disc adsorption affinity through the manpower according to the pressure lever adsorbing the ceramic tile mode, and the adsorption affinity is unstable, and the live time drops easily for a long time, weakens greatly to unevenness or thicker rough ceramic tile face adsorption affinity, and another kind of electronic sucking disc formula, and the cost is higher, damages easily.

### Summery Of The Utility Model

**[p0002]**

Technical problem to be solved In order to overcome prior art not enough, now provide a ceramic tile ware is carried in vacuum, the ceramic tile ware is carried in the absorption ceramic tile mode of having solved current sucking disc formula need increase the sucking disc adsorption affinity through the manpower according to the depression bar, and the adsorption affinity is unstable, and the live time drops easily for a long time, weakens greatly to unevenness or thicker ceramic tile face adsorption affinity, and another kind of electronic sucking disc formula, and the cost is higher, the problem of easy damage. (II) technical scheme The utility model discloses a following technical scheme realizes: the utility model provides a ceramic tile ware is carried in vacuum, including handle main part, press the piece, seal gasket, spring, fixed screw, metal bottom plate, sponge, handle flexible glue, sealing washer and metal strip, the main part of ceramic tile ware is carried in this vacuum to the handle main part, handle main part right-hand member is equipped with the press piece and seals through seal gasket, handle main part head is equipped with the gas outlet, passes the handle main part through the metal strip and is connected with the press piece, press the gas outlet of position through spring and handle main part to hug closely each other on the press piece, handle main part bottom is fixed through fixed screw and metal bottom plate, and this handle main part installs the sealing washer with the metal bottom plate junction, the metal bottom plate bottom is equipped wi

**[p0002]**

th the sponge and fixes through the glue bonding, handle main part middle part is equipped with the handle flexible glue.

**[p0003]**

Furthermore, the tail end of the handle main body is provided with an air suction opening for connecting a pipeline. Furthermore, two round holes are arranged on the metal bottom plate. Further, the diameter of the round hole is 25 mm. Furthermore, the number of the fixing screws is eight. Furthermore, the four fixing screws are in a group and respectively correspond to the two round holes on the metal base plate. Further, the number of the sealing rings is two. (III) advantageous effects Compared with the prior art, the utility model, following beneficial effect has: 1) The utility model discloses a make the vacuum and adsorb the ceramic tile, the difficult fatigue damage's that uses sponge and metal sheet material, the sponge material can perfectly laminate on adsorbing rough plane, still has fairly big adsorption affinity, can also reduce the instability when using, and convenient to use, need not come the switch through great strength repeatedly and whether adsorb the ceramic tile, this kind of adsorption mode can improve absorptive stability, and adsorption affinity also matches with the sucking disc formula, relative electrodynamic type also more durable and cheap.

**[p0004]**

Drawings Other features, objects and advantages of the invention will become more apparent upon reading of the detailed description of non-limiting embodiments with reference to the following drawings: Fig. 1 is a schematic side view of the present invention; Fig. 2 is an explosion diagram of the present invention. In the figure: the handle comprises a handle main body-1, a pressing sheet-2, a sealing gasket-3, a spring-4, a fixing screw-5, a metal bottom plate-6, a sponge-7, a handle soft rubber-8, a sealing ring-9 and a metal strip-10. Detailed Description In order to make the objects, technical solutions and advantages of the present invention more clearly understood, the present invention is further described in detail below with reference to the accompanying drawings and embodiments. It should be understood that the specific embodiments described herein are merely illustrative of the invention and are not intended to limit the invention. Referring to fig. 1 and 2, the present invention provides a vacuum tile lifter: the vacuum ceramic tile lifting device comprises a handle main body 1, a pressing sheet 2, a sealing gasket 3, a spring 4, a fixing screw 5, a metal base plate 6, a sponge 7, a handle soft rubber 8, a sealing ring 9 and a metal strip 10, wherein the handle main body 1 is the main part of the vacuum ceramic tile lifting device, the pressing sheet 2 is arranged at the right end of the handle main body 1 and is sealed through the sealing gasket 3, the sealing gasket 3 is arranged to ensure the sealing property of the handle main body 1, the head of the handle

**[p0004]**

main body 1 is provided with an air outlet, the metal strip 10 penetrates through the handle main body 1 to be connected with the pressing sheet 2, the pressing part at the upper end of the pressing sheet 2 is tightly attached to the air outlet of the handle main body 1 through the spring 4, the bottom of the handle main body 1 is fixed with the metal base plate 6 through the fixing screw 5, the sealing ring 9 is arranged at the joint of, 6 bottoms of metal substrate are equipped with sponge 7 and fixed through the glue bonding, and the sponge 7 that 6 bottoms of metal substrate set up can guarantee vacuum adsorption affinity when carrying ceramic tile ware and ceramic tile contact, and 1 middle part of handle main part is equipped with handle flexible glue 8, through having set up handle flexible glue 8 in 1 middle part of handle main part, when using, the hand grips on handle flexible glue 8, can provide more comfortable gripping and feel.

**[p0005]**

The tail end of the handle body 1 is provided with an air pumping hole for connecting a pipeline, and after the air pumping hole is connected with an external pipeline, vacuum operation is carried out. Wherein, be equipped with two round holes on the metal soleplate 6 for connect the through-hole of 1 bottom positions of handle main part, reach absorbent effect. wherein, the diameter of the round hole is 25 millimeters, so that the interior of the handle body 1 can better adsorb the ceramic tiles in a vacuum state, and the vacuum adsorption can be conveniently realized. The number of the fixing screws 5 is eight, so that the handle body 1 and the metal bottom plate 6 are fixed more stably. the four fixing screws 5 are in a group and respectively correspond to the two round holes on the metal base plate 6, so that the two ends of the handle main body 1 are better fixed with the metal base plate 6. the number of the sealing rings 9 is two, and the sealing rings are used for increasing the sealing performance of the two connecting positions of the metal bottom plate 6 and the handle main body 1.

**[p0006]**

The working principle is as follows: when in use, the air exhaust opening at the tail part of the handle main body 1 is connected with a pipeline in advance, the pipeline is connected with external vacuum equipment, then a ceramic tile is placed at the bottom of the device, the bottom of the handle main body 1 is fixed with the metal bottom plate 6 through the fixing screw 5, the sponge 7 at the bottom of the metal bottom plate 6 is contacted with the surface of the ceramic tile, through the work of the external vacuum equipment, the pipeline is connected with the air exhaust opening of the handle main body 1 to be in a vacuum state, the ceramic tile is adsorbed, then the ceramic tile can be lifted to a proper position, then the upper end of the pressing piece 3 is pressed to open the air outlet at the head part of the handle main body 1, the internal vacuum state is relieved, the ceramic tile is put down, after the pressing piece 3 is loosened, the pressing piece 3 and the air outlet at the head part of the handle main body 1 are closed by the spring 4 so as to be used next, the sponge material can be perfectly attached on the adsorption rough plane, still has quite large adsorption force, can reduce the instability in use, the use is convenient, the ceramic tile is not required to be repeatedly switched on and off by strong strength, the adsorption mode can improve the adsorption stability, the adsorption force is equivalent to that of a sucker, the ceramic tile is relatively electrodynamic, durable and cheap, the metal bottom plate 6 is provided with two round holes for

**[p0006]**

connecting through holes at the bottom of the handle body 1 to achieve the adsorption effect, the diameter of the round holes is 25 mm, so that the inside of the handle body 1 can better adsorb ceramic tiles in a vacuum state to facilitate vacuum adsorption, the number of the fixing screws 5 is eight, so that the handle main body 1 and the metal base plate 6 are fixed more stably, and two sealing rings 9 are arranged at the joint of the handle main body 1 and the metal base plate 6 and used for increasing the sealing performance of the two joint positions of the metal base plate 6 and the handle main body 1.

**[p0007]**

The basic principle and the main characteristics of the utility model and the advantages of the utility model have been shown and described above, and the utility model discloses the standard part that uses all can purchase from the market, and dysmorphism piece all can be customized according to the record of the description with the drawing, and the concrete connection mode of each part all adopts conventional means such as ripe bolt rivet among the prior art, welding, and machinery, part and equipment all adopt prior art, conventional model, and conventional connection mode in the prior art is adopted in addition to circuit connection, and the details are not repeated here. It is obvious to a person skilled in the art that the invention is not restricted to details of the above-described exemplary embodiments, but that it can be implemented in other specific forms without departing from the spirit or essential characteristics of the invention. The present embodiments are therefore to be considered in all respects as illustrative and not restrictive, the scope of the invention being indicated by the appended claims rather than by the foregoing description, and all changes which come within the meaning and range of equivalency of the claims are therefore intended to be embraced therein. Any reference sign in a claim should not be construed as limiting the claim concerned.

**[p0008]**

Furthermore, it should be understood that although the present description refers to embodiments, not every embodiment may contain only a single embodiment, and such description is for clarity only, and those skilled in the art should integrate the description, and the embodiments may be combined as appropriate to form other embodiments understood by those skilled in the art.

---

Generated by IPtorch. Verify legal conclusions against the official publication.
