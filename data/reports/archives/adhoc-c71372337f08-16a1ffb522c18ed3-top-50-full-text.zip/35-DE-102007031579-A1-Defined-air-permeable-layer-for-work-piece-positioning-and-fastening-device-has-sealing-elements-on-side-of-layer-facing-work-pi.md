# 35. Defined air-permeable layer for work piece positioning and fastening device, has sealing elements on side of layer facing work piece, where sealing elements form set of closed, sealed suction regions between work piece and base plate

- **Archive rank:** 35 of 50
- **Publication:** [DE-102007031579-A1](https://patents.google.com/patent/DE102007031579A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/039809753/publication/DE102007031579A1?q=pn%3DDE102007031579A1)
- **Publication date:** 2008-11-06
- **Filing date:** 2007-07-06
- **Earliest priority:** 2007-05-01
- **Family:** 39809753
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** DATRON ELECTRONIC GMBH
- **Inventors:** RECK MATTHIAS; RECK MONIKA

## Abstract

The air-permeable layer (120) is arranged on a base plate (110) with uniform openings (115) which are fluidly connected with a vacuum pump (118) at a lower surface of the base plate. The air-permeable layer is arranged between a work piece and an upper side of the base plate. Sealing elements (140, 142) are on a side of the layer facing the work piece. The sealing elements form a set of closed, sealed suction regions (145) between the work piece and base plate.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-102007031579-A1/pdf000.png)

![Sketch 1 for DE-102007031579-A1](https://nimo.iptorch.com/refdrawing/DE-102007031579-A1/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/DE-102007031579-A1/pdf001.png)

![Sketch 2 for DE-102007031579-A1](https://nimo.iptorch.com/refdrawing/DE-102007031579-A1/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/DE-102007031579-A1/pdf002.png)

![Sketch 3 for DE-102007031579-A1](https://nimo.iptorch.com/refdrawing/DE-102007031579-A1/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/DE-102007031579-A1/pdf003.png)

![Sketch 4 for DE-102007031579-A1](https://nimo.iptorch.com/refdrawing/DE-102007031579-A1/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/DE-102007031579-A1/pdf004.png)

![Sketch 5 for DE-102007031579-A1](https://nimo.iptorch.com/refdrawing/DE-102007031579-A1/pdf004.png)

## Claims

### Claim 1 (independent)

Begrenzt luftdurchlässige Schicht (120) für eine Vorrichtung zur Positionierung und Befestigung von zu bearbeitenden Werkstücken (300; 310; 320; 340) auf der Oberseite einer im Wesentlichen ebenen, Öffnungen (115) aufweisenden Grundplatte (110), wobei die Öffnungen (115) an der Unterseite der Grundplatte (110) mit einer Vakuumpumpe (118) fluidisch verbunden sind und wobei die begrenzt luftdurchlässige Schicht (120) zwischen dem Werkstück (300; 310; 320; 340) und der Oberseite der Grundplatte (110) angeordnet ist, dadurch gekennzeichnet, dass die begrenzt luftdurchlässige Schicht (120) wenigstens auf ihrer dem Werkstück zugewandten Seite Dichtelemente (140, 142; 146; 147; 148) aufweist, die eine Mehrzahl von jeweils geschlossenen, abgedichteten Saugbereichen (145; 146'; 147'; 148') zwischen Werkstück (300; 310; 320; 340) und Grundplatte (120) ausbilden.Limited air-permeable layer ( 120 ) for a device for positioning and fixing workpieces to be machined ( 300 ; 310 ; 320 ; 340 ) on the top of a substantially flat, openings ( 115 ) having base plate ( 110 ), the openings ( 115 ) at the bottom of the base plate ( 110 ) with a vacuum pump ( 118 ) are fluidically connected and wherein the limited air-permeable layer ( 120 ) between the workpiece ( 300 ; 310 ; 320 ; 340 ) and the top of the base plate ( 110 ), characterized in that the limited air-permeable layer ( 120 ) at least on its side facing the workpiece sealing elements ( 140 . 142 ; 146 ; 147 ; 148 ) having a plurality of respective closed, sealed suction areas ( 145 ; 146 '; 147 '; 148 ' ) between workpiece ( 300 ; 310 ; 320 ; 340 ) and base plate ( 120 ) train.

### Claim 2

Begrenzt luftdurchlässige Schicht (120) nach Anspruch 1, dadurch gekennzeichnet, dass sie durch einen auf die Oberseite der Grundplatte (120) aufgelegten Bogen gebildet wird, auf dessen wenigstens einer Oberfläche die Dichtelemente (140, 142; 146; 147; 148) befestigt sind.Limited air-permeable layer ( 120 ) according to claim 1, characterized in that it can be replaced by an upper surface of the base plate ( 120 ) is formed on its at least one surface, the sealing elements ( 140 . 142 ; 146 ; 147 ; 148 ) are attached.

### Claim 3

Begrenzt luftdurchlässige Schicht (120) nach Anspruch 1 oder 2, dadurch gekennzeichnet, dass die Dichtelemente erhabene Dichtstreifen (140, 142; 146; 147; 148) sind.Limited air-permeable layer ( 120 ) according to claim 1 or 2, characterized in that the sealing elements raised sealing strips ( 140 . 142 ; 146 ; 147 ; 148 ) are.

### Claim 4

Begrenzt luftdurchlässige Schicht (120) nach Anspruch 3, dadurch gekennzeichnet, dass die Dichtstreifen (140, 142; 146; 147; 148) eine Elastizität aufweisen.Limited air-permeable layer ( 120 ) according to claim 3, characterized in that the sealing strips ( 140 . 142 ; 146 ; 147 ; 148 ) have elasticity.

### Claim 5

Begrenzt luftdurchlässige Schicht (120) nach Anspruch 3 oder 4, dadurch gekennzeichnet, dass die Dichtstreifen (140, 142; 146; 147; 148) eine klebrige Beschaffenheit aufweisen.Limited air-permeable layer ( 120 ) according to claim 3 or 4, characterized in that the sealing strips ( 140 . 142 ; 146 ; 147 ; 148 ) have a sticky nature.

### Claim 6

Begrenzt luftdurchlässige Schicht (120) nach Anspruch 5, dadurch gekennzeichnet, dass die Klebrigkeit an das zu bearbeitende Werkstück (300; 310; 320; 340) angepasst ist.Limited air-permeable layer ( 120 ) according to claim 5, characterized in that the stickiness to the workpiece to be machined ( 300 ; 310 ; 320 ; 340 ) is adjusted.

### Claim 7

Begrenzt luftdurchlässige Schicht (120) nach Anspruch 5 oder 6, dadurch gekennzeichnet, dass die Dichtstreifen (140, 142; 146; 147; 148) aus einem elastischen, von Schneidölen und Kühlmitteln nicht angreifbaren Klebstoff bestehen.Limited air-permeable layer ( 120 ) according to claim 5 or 6, characterized in that the sealing strips ( 140 . 142 ; 146 ; 147 ; 148 ) consist of an elastic, not vulnerable to cutting oils and coolants adhesive.

### Claim 8

Begrenzt luftdurchlässige Schicht (120) nach einem der Ansprüche 3 bis 7, dadurch gekennzeichnet, dass die Dichtstreifen (140, 142) stochastisch verteilt so auf der Oberfläche verlaufen, dass sich die Dichtstreifen (140, 142) jeweils schneiden und hierbei abgeschlossene Saugbereiche (145) ausbilden.Limited air-permeable layer ( 120 ) according to one of claims 3 to 7, characterized in that the sealing strips ( 140 . 142 ) stochastically distributed on the surface so that the sealing strips ( 140 . 142 ) each cut and thereby closed suction areas ( 145 ) train.

### Claim 9

Begrenzt luftdurchlässige Schicht (120) nach einem der Ansprüche 3 bis 7, dadurch gekennzeichnet, dass die Dichtstreifen (140, 142; 146; 147; 148) auf der Oberfläche so verlaufen, dass sie eine Mehrzahl von jeweils nebeneinander liegend angeordneten Mustern, insbesondere Karomuster oder Kreismuster oder Wabenmuster, bilden.Limited air-permeable layer ( 120 ) according to one of claims 3 to 7, characterized in that the sealing strips ( 140 . 142 ; 146 ; 147 ; 148 ) run on the surface so that they form a plurality of respectively juxtaposed patterns, in particular check pattern or circular pattern or honeycomb pattern.

### Claim 10

Begrenzt luftdurchlässige Schicht (120) nach einem der Ansprüche 3 bis 9, dadurch gekennzeichnet, dass im Inneren der Saugbereiche (145) weitere Klebepunkte (141) angeordnet sind.Limited air-permeable layer ( 120 ) according to one of claims 3 to 9, characterized in that in the interior of the suction areas ( 145 ) more adhesive dots ( 141 ) are arranged.

### Claim 11

Begrenzt luftdurchlässige Schicht (120) nach einem der Ansprüche 3 bis 10, dadurch gekennzeichnet, dass der Verlauf der Dichtstreifen (146; 147; 148) der Kontur der zu bearbeitenden Werkstücke (310; 320; 340) jeweils nachgebildet ist.Limited air-permeable layer ( 120 ) according to one of claims 3 to 10, characterized in that the course of the sealing strips ( 146 ; 147 ; 148 ) the contour of the workpieces to be machined ( 310 ; 320 ; 340 ) is replicated in each case.

### Claim 12

Begrenzt luftdurchlässige Schicht (120) nach einem der Ansprüche 3 bis 11, dadurch gekennzeichnet, dass die Höhe der Dichtstreifen (140, 142; 146; 147; 148) an die Oberflächenrauigkeit der zu bearbeitenden Werkstücke (300; 310; 320; 340) angepasst ist.Limited air-permeable layer ( 120 ) according to one of claims 3 to 11, characterized in that the height of the sealing strips ( 140 . 142 ; 146 ; 147 ; 148 ) to the surface roughness of the workpieces to be machined ( 300 ; 310 ; 320 ; 340 ) is adjusted.

### Claim 13

Begrenzt luftdurchlässige Schicht (120) nach einem der vorstehenden Ansprüche, dadurch gekennzeichnet, dass der Verlauf der Dichtstreifen (140, 142; 146; 147; 148) an die Öffnungen (115) in der Grundplatte (110) angepasst ist.Limited air-permeable layer ( 120 ) according to one of the preceding claims, characterized in that the course of the sealing strips ( 140 . 142 ; 146 ; 147 ; 148 ) to the openings ( 115 ) in the base plate ( 110 ) is adjusted.

### Claim 14

Begrenzt luftdurchlässige Schicht (120) nach Anspruch 13, dadurch gekennzeichnet, dass die Dichtstreifen (140, 142; 146; 147; 148) so verlaufen, dass eine Öffnung (115) auf mehrere Saugbereiche (145) verteilt ist.Limited air-permeable layer ( 120 ) according to claim 13, characterized in that the sealing strips ( 140 . 142 ; 146 ; 147 ; 148 ) so that an opening ( 115 ) to several suction areas ( 145 ) is distributed.

### Claim 15

Begrenzt luftdurchlässige Schicht (120) nach Anspruch 13, dadurch gekennzeichnet, dass wenigstens eine Öffnung (115) in jeweils einem Saugbereich (145) angeordnet ist.Limited air-permeable layer ( 120 ) according to claim 13, characterized in that at least one opening ( 115 ) in each case a suction area ( 145 ) is arranged.

### Claim 16 (independent)

Begrenzt luftdurchlässigen Schicht (120), dadurch gekennzeichnet, dass mehrere Öffnungen (115) in jeweils einem Saugbereich (145; 146'; 147'; 148') angeordnet sind.Limited air-permeable layer ( 120 ), characterized in that a plurality of openings ( 115 ) in each case a suction area ( 145 ; 146 '; 147 '; 148 ' ) are arranged.

### Claim 17

Begrenzt luftdurchlässige Schicht (120) nach einem der vorstehenden Ansprüche, dadurch gekennzeichnet, dass auf ihrer dem Werkstück abgewandten und der Oberseite der Grundplatte (110) zugewandten Oberfläche wenigstens ein Dichtelement (190) angeordnet ist, welches durch einen, eine in sich geschlossene Struktur bildenden Dichtstreifen (190) gebildet wird.Limited air-permeable layer ( 120 ) according to one of the preceding claims, characterized in that on its side facing away from the workpiece and the top of the base plate ( 110 ) facing surface at least one sealing element ( 190 ), which by a, a self-contained structure forming sealing strip ( 190 ) is formed.

### Claim 18

Begrenzt luftdurchlässige Schicht (120) nach Anspruch 17, dadurch gekennzeichnet, dass der Dichtstreifen (190) am Rand der begrenzt luftdurchlässigen Schicht (120) verläuft.Limited air-permeable layer ( 120 ) according to claim 17, characterized in that the sealing strip ( 190 ) on the edge of the limited air casual layer ( 120 ) runs.

### Claim 19

Begrenzt luftdurchlässige Schicht (120) nach einem der Ansprüche 3 bis 18, dadurch gekennzeichnet, dass die Dichtstreifen (140, 142; 146; 147; 148) mittels Siebdrucktechnik auf die begrenzt luftdurchlässige Schicht (120) aufbringbar sind.Limited air-permeable layer ( 120 ) according to one of claims 3 to 18, characterized in that the sealing strips ( 140 . 142 ; 146 ; 147 ; 148 ) by screen printing on the limited air-permeable layer ( 120 ) are applicable.

### Claim 20

Begrenzt luftdurchlässige Schicht (120) nach einem der Ansprüche 3 bis 18, dadurch gekennzeichnet, dass die Dichtstreifen (140, 142; 146; 147; 148) durch computergesteuertes Dispensen auf die begrenzt luftdurchlässige Schicht (120) aufbringbar sind.Limited air-permeable layer ( 120 ) according to one of claims 3 to 18, characterized in that the sealing strips ( 140 . 142 ; 146 ; 147 ; 148 ) by computer-controlled dispensing on the limited air-permeable layer ( 120 ) are applicable.

### Claim 21

Begrenzt luftdurchlässige Schicht (120) nach einem der Ansprüche 3 bis 18, dadurch gekennzeichnet, dass die Dichtstreifen (140, 142; 146; 147; 148; 190) durch einen Kalander und/oder durch Aufsprühen eines Heißklebers in der Gestalt der Dichtstreifen (140, 142; 146; 147; 148; 190) und/oder durch Aufsprühen eines Klebers über eine Schablone und/oder durch Tiefdruck mittels Übertragungswalzen auf die begrenzt luftdurchlässige Schicht (120) aufbringbar sind.Limited air-permeable layer ( 120 ) according to one of claims 3 to 18, characterized in that the sealing strips ( 140 . 142 ; 146 ; 147 ; 148 ; 190 ) by a calender and / or by spraying a hot melt adhesive in the shape of the sealing strip ( 140 . 142 ; 146 ; 147 ; 148 ; 190 ) and / or by spraying an adhesive over a template and / or by gravure by means of transfer rollers on the limited air-permeable layer ( 120 ) are applicable.

### Claim 22

Begrenzt luftdurchlässige Schicht (120) nach einem der Ansprüche 3 bis 21, dadurch gekennzeichnet, dass die Dichtstreifen (140, 142; 146; 147; 148; 190) durch eine abziehbare Schutzschicht (200) überdeckt sind.Limited air-permeable layer ( 120 ) according to one of claims 3 to 21, characterized in that the sealing strips ( 140 . 142 ; 146 ; 147 ; 148 ; 190 ) by a peelable protective layer ( 200 ) are covered.

### Claim 23

Begrenzt luftdurchlässige Schicht (120) nach Anspruch 22, dadurch gekennzeichnet, dass die Schutzschicht (200) ein Silikonpapier oder eine Schutzfolie ist.Limited air-permeable layer ( 120 ) according to claim 22, characterized in that the protective layer ( 200 ) is a silicone paper or a protective film.

### Claim 24

Begrenzt luftdurchlässige Schicht (120) nach einem der vorstehenden Ansprüche, dadurch gekennzeichnet, dass sie aus einem Filterpapier besteht.Limited air-permeable layer ( 120 ) according to one of the preceding claims, characterized in that it consists of a filter paper.

### Claim 25

Begrenzt luftdurchlässige Schicht (120) nach einem der Ansprüche 1 bis 23, dadurch gekennzeichnet, dass sie aus einer Skinpappe besteht.Limited air-permeable layer ( 120 ) according to one of claims 1 to 23, characterized in that it consists of a skin cardboard.

### Claim 26

Begrenzt luftdurchlässige Schicht (120) nach einem der Ansprüche 1 bis 23, dadurch gekennzeichnet, dass sie aus einer MDF- oder HDF-Platte besteht.Limited air-permeable layer ( 120 ) according to one of claims 1 to 23, characterized in that it consists of an MDF or HDF plate.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGHAND TOOLS; PORTABLE POWER-DRIVEN TOOLS; MANIPULATORSTOOLS OR BENCH DEVICES NOT OTHERWISE PROVIDED FOR, FOR FASTENING, CONNECTING, DISENGAGING, OR HOLDINGWork holders not covered by any preceding group in the subclass, e.g. magnetic work holders, vacuum work holdersVacuum work holdersPERFORMING OPERATIONS; TRANSPORTINGMACHINE TOOLS; METAL-WORKING NOT OTHERWISE PROVIDED FORDETAILS, COMPONENTS, OR ACCESSORIES FOR MACHINE TOOLS, e.g. ARRANGEMENTS FOR COPYING OR CONTROLLING; MACHINE TOOLS IN GENERAL CHARACTERISED BY THE CONSTRUCTION OF PARTICULAR DETAILS OR COMPONENTS; COMBINATIONS OR ASSOCIATIONS OF METAL-WORKING MACHINES, NOT DIRECTED TO A PARTICULAR RESULTDevices holding, supporting, or positioning work or tools, of a kind normally removable from the machineDevices holding, supporting, or positioning work or tools, of a kind normally removable from the machine for mounting on a work-table, tool-slide, or analogous partWork-clamping meansWork-clamping means other than mechanically-actuatedWork-clamping means other than mechanically-actuated using vacuum means

Description

Translated from German

Die

Erfindung betrifft eine begrenzt luftdurchlÃ¤ssige Schicht

fÃ¼r eine Vorrichtung zur Positionierung und Befestigung

von zu bearbeitenden WerkstÃ¼cken nach dem Oberbegriff des

Anspruchs 1.The

The invention relates to a limited air-permeable layer

for a device for positioning and fastening

of workpieces to be machined according to the preamble of

Claim 1.

Stand der TechnikState of the art

Aus

der DE 40 30 113 A1 ist

eine Vorrichtung zur Positionierung und Befestigung von zu bearbeitenden

WerkstÃ¼cken bekannt geworden, bei der die WerkstÃ¼cke

auf der Oberseite einer ebenen, Ãffnungen aufweisenden

Grundplatte angeordnet sind. Die Ãffnungen sind an der

Unterseite der Grundplatte mit einer Vakuumpumpe fluidisch verbunden.

Zwischen dem WerkstÃ¼ck und der Oberseite der Grundplatte

ist eine begrenzt luftdurchlÃ¤ssige Schicht angeordnet. Diese

Schicht dient dazu, ein partielles Vakuum aufzubauen.From the DE 40 30 113 A1 has become known an apparatus for positioning and mounting of workpieces to be machined, in which the workpieces are arranged on top of a flat, apertured base plate. The openings are fluidically connected to the underside of the base plate with a vacuum pump. Between the workpiece and the top of the base plate a limited air-permeable layer is arranged. This layer serves to build up a partial vacuum.

WÃ¤hrend

der Bearbeitung des WerkstÃ¼cks, beispielsweise durch FrÃ¤sen,

kann es vorkommen, dass der FrÃ¤skopf bis hinunter in die

begrenzt luftdurchlÃ¤ssige Schicht fÃ¤hrt und hierbei

die Schicht teilweise beschÃ¤digt. In diesem Falle wird

durch die begrenzt luftdurchlÃ¤ssige Schicht sichergestellt,

dass das Vakuum nicht vollstÃ¤ndig zusammenbricht, sondern

das WerkstÃ¼ck auf der Platte weiterhin gehalten wird. Eine

solche Vorrichtung ist auch aus der DE 201 17 390 U1 sowie aus der DE 103 57 268 B3 bekannt geworden.During machining of the workpiece, for example by milling, it may happen that the milling head moves down into the limited air-permeable layer and thereby partially damages the layer. In this case, it is ensured by the limited air-permeable layer that the vacuum does not completely collapse, but the workpiece is still held on the plate. Such a device is also from the DE 201 17 390 U1 as well as from the DE 103 57 268 B3 known.

Gegenstand

der DE 103 57 268

B3 ist ferner ein Verfahren, bei dem ein mit einer HeiÃklebeschicht versehenes

Flies zum Einsatz kommt, das zwischen dem zu bearbeitenden WerkstÃ¼ck

und der Grundplatte angeordnet ist. Bei diesem Verfahren schmilzt

der Kleber wÃ¤hrend des FrÃ¤svorganges und verbindet sich

mit dem WerkstÃ¼ck. Hierdurch wird das WerkstÃ¼ck

bzw. das ausgefrÃ¤ste Teil nicht nur durch das Vakuum, sondern

zusÃ¤tzlich auch durch das Flies gehalten. Nachteilig bei

diesem Verfahren ist, dass die FrÃ¤sparameter sehr genau

eingestellt werden mÃ¼ssen, damit sich eine Temperatur am

FrÃ¤skopf einstellt, die den HeiÃkleber schmelzen

lÃ¤sst. Problematisch hierbei ist auch, dass ein Flies verwendet

wird, welches in hohem Grade luftdurchlÃ¤ssig ist, sodass das

Vakuum beim DurchfrÃ¤sen des WerkstÃ¼ckes sehr leicht

zusammenbrechen kann. Um dies zu vermeiden, wird Ã¼blicherweise

dem FrÃ¤skopf ein zusÃ¤tzliches Hochvakuum nachgefÃ¼hrt.

Diese Technik ist allerdings sehr aufwendig und damit auch sehr

teuer. Problematisch ist ferner, dass der Klebeeffekt bei Verwendung

von KÃ¼hl-Schmiermitteln unterbunden werden kann, da die

KÃ¼hlung den FrÃ¤ser abkÃ¼hlt und so die

Schmierung ein Anhaften verhindert.Subject of the DE 103 57 268 B3 Further, there is a method using a hot-melt coated tile disposed between the workpiece to be processed and the base plate. In this process, the adhesive melts during the milling process and connects to the workpiece. As a result, the workpiece or the milled part is held not only by the vacuum, but also by the fleece. A disadvantage of this method is that the milling parameters must be set very accurately, so that a temperature is set on the milling head, which can melt the hot melt adhesive. The problem here is that a tile is used, which is highly permeable to air, so that the vacuum can easily collapse when milling through the workpiece. To avoid this, the milling head is usually tracked an additional high vacuum. However, this technique is very complicated and therefore very expensive. A further problem is that the adhesive effect when using cooling lubricants can be prevented because the cooling cools the cutter and so prevents the lubrication sticking.

Bei

den aus der DE 40 30

113 A1 sowie aus der DE 201 17 390 U1 hervorgehenden Vorrichtungen

wird als begrenzt luftdurchlÃ¤ssige Schicht ein Filterpapier

verwendet. Dieses Filterpapier wirkt als Drossel und als gewissermaÃen

Opferschicht, die verhindert, dass der FrÃ¤ser in die Vakuumplatte dringt.

Nachteilig hierbei ist, dass kleine Teile sowie Teile mit unebener

oder rauer OberflÃ¤che nicht gut gehalten werden kÃ¶nnen.

DarÃ¼ber hinaus kÃ¶nnen auch biegsame Teile, beispielsweise

sehr dÃ¼nnwandige Bleche, durch den FrÃ¤skopf leicht

angehoben werden, wobei in diesem Falle das Vakuum schlagartig zusammenbricht.In the from the DE 40 30 113 A1 as well as from the DE 201 17 390 U1 emanating devices is used as a limited air-permeable layer of a filter paper. This filter paper acts as a choke and as a sacrificial layer, preventing the cutter from penetrating into the vacuum plate. The disadvantage here is that small parts and parts with uneven or rough surface can not be kept well. In addition, flexible parts, for example, very thin-walled sheets can be easily raised by the milling head, in which case the vacuum collapses abruptly.

Die DE 40 30 113 A1 schlÃ¤gt

ferner vor, das Filterpapier mit einem Klebemittel oder mit einem

AdhÃ¤sionsmittel vorzubehandeln. Hierbei kommen SprÃ¼hkleber

zum Einsatz, die flÃ¤chig aufgetragen werden. Diese flÃ¤chige

Auftragung des SprÃ¼hklebers ist mit hohen Kosten verbunden.

DarÃ¼ber hinaus entsteht eine zusÃ¤tzliche chemische

Belastung. Das so vorbehandelte Filterpapier ist darÃ¼ber

hinaus schlecht zu handhaben.The DE 40 30 113 A1 also proposes pretreating the filter paper with an adhesive or with an adhesive. This spray adhesives are used, which are applied flat. This surface application of the spray adhesive is associated with high costs. In addition, there is an additional chemical burden. The pretreated filter paper is also difficult to handle.

Der

Erfindung liegt daher die Aufgabe zugrunde, die vorgenannten Nachteile

zu beseitigen und eine begrenzt luftdurchlÃ¤ssige Schicht

zu schaffen, die leicht zu handhaben ist und auch bei kleinen zu

bearbeitenden WerkstÃ¼cken sowie bei WerkstÃ¼cken

mit rauer OberflÃ¤che eine sehr gute Positionierung und

ein sehr gutes Halten des WerkstÃ¼cks auf der Grundplatte

durch das Vakuum ermÃ¶glicht.Of the

The invention is therefore based on the object, the aforementioned disadvantages

to eliminate and a limited air-permeable layer

to create, which is easy to handle and even with small too

machined workpieces and workpieces

with rough surface a very good positioning and

a very good hold of the workpiece on the base plate

made possible by the vacuum.

Offenbarung der ErfindungDisclosure of the invention

Vorteile der ErfindungAdvantages of the invention

Diese

Aufgabe wird gelÃ¶st durch eine begrenzt luftdurchlÃ¤ssige

Schicht mit den Merkmalen des Anspruchs 1. Durch die Saugbereiche

zwischen WerkstÃ¼ck und Grundplatte, die durch die Dichtelemente

ausgebildet werden, wird ein Halten des WerkstÃ¼cks mit

sehr groÃer Haltekraft ermÃ¶glicht.Â These

Task is solved by a limited air permeable

Layer with the features of claim 1. Through the suction areas

between workpiece and base plate passing through the sealing elements

are trained, holding the workpiece with

very high holding power.

Grundidee

der Erfindung ist es, durch die Mehrzahl von jeweils geschlossen

verlaufenden, abgedichtete Saugbereiche bildenden Dichtelemente gewissermaÃen

mehrere nebeneinander liegende SaugnÃ¤pfe auszubilden, die

die HaltekrÃ¤fte des WerkstÃ¼cks wesentlich erhÃ¶hen,

selbst dann, wenn der FrÃ¤skopf die begrenzt luftdurchlÃ¤ssige

Schicht, beispielsweise beim AusfrÃ¤sen von Ãffnungen

aufweisenden WerkstÃ¼cken oder beim UmfrÃ¤sen der WerkstÃ¼ckrÃ¤nder,

teilweise beschÃ¤digt. In diesem Falle Ã¼bernehmen

ge wissermaÃen die anderen geschlossenen und abgedichteten

Saugbereiche oder SaugnÃ¤pfe das Halten des WerkstÃ¼cks.The basic idea

The invention is closed by the plurality of each

extending, sealed suction areas forming sealing elements in a sense

form a plurality of adjacent suction cups, the

significantly increase the holding forces of the workpiece,

even if the milling head has the limited air permeability

Layer, for example, when milling out openings

having workpieces or when milling the workpiece edges,

partially damaged. In this case take over

as it were, the others closed and sealed

Suction areas or suction cups holding the workpiece.

Durch

die in den abhÃ¤ngigen AnsprÃ¼chen aufgefÃ¼hrten

MaÃnahmen sind vorteilhafte Weiterbildungen und Verbesserungen

der in dem unabhÃ¤ngigen Anspruch angegebenen begrenzt luftdurchlÃ¤ssigen

Schicht mÃ¶glich.The measures listed in the dependent claims advantageous refinements and improvements of the independent claim are limited air permeable gene layer possible.

So

wird die begrenzt luftdurchlÃ¤ssige Schicht vorteilhafterweise

durch einen auf die Oberseite der Grundplatte aufgelegten Bogen

oder durch eine Platte gebildet, auf dessen/deren wenigstens einer

OberflÃ¤che die Dichtelemente befestigt sind. Dieser Bogen/diese

Platte kann, wie nachstehend noch nÃ¤her erlÃ¤utert

wird, aus den unterschiedlichsten Materialien gebildet sein.So

the limited air-permeable layer is advantageously

by a bow placed on top of the base plate

or formed by a plate, on whose / at least one

Surface, the sealing elements are attached. This bow / this

Plate can, as explained in more detail below

will be made of a variety of materials.

Die

Dichtelemente selbst sind bevorzugt erhabene Dichtstreifen, die

auch als DichtwÃ¤lle bezeichnet werden kÃ¶nnen.

Diese Dichtstreifen oder DichtwÃ¤lle ermÃ¶glichen

eine hohe FlÃ¤chenpressung und damit eine besonders optimale

Abdichtung.The

Sealing elements themselves are preferably raised sealing strips, the

Also known as sealing walls.

These sealing strips or sealing walls allow

a high surface pressure and thus a particularly optimal

Seal.

Bevorzugt

sind die Dichtstreifen elastisch ausgebildet. Sie passen sich so

kleinen Unebenheiten des zu bearbeitenden WerkstÃ¼cks und/oder

der Grundplatte an und erhÃ¶hen auf diese Weise die Dichtwirkung

wesentlich.Prefers

the sealing strips are elastic. They adapt so

small bumps of the workpiece to be machined and / or

the base plate and increase in this way the sealing effect

essential.

Eine

besonders vorteilhafte AusfÃ¼hrungsform sieht vor, dass

diese Dichtstreifen eine klebrige Beschaffenheit aufweisen. Hierdurch

wird das WerkstÃ¼ck bereits durch die Klebewirkung gehalten,

wobei hierdurch insbesondere auch eine leichte Positionierung mÃ¶glich

ist.A

particularly advantageous embodiment provides that

these sealing strips have a sticky texture. hereby

if the workpiece is already held by the adhesive effect,

whereby in particular also a slight positioning possible

is.

Die

Klebrigkeit der Dichtstreifen wird dabei vorteilhafterweise an das

zu bearbeitende WerkstÃ¼ck angepasst derart, dass nach dem

Bearbeitungsvorgang, wenn das WerkstÃ¼ck wieder von der

begrenzt luftdurchlÃ¤ssigen Schicht entfernt wird, ein rÃ¼ckstandsfreies

AblÃ¶sen mÃ¶glich ist. Anders ausgedrÃ¼ckt wird

die Klebrigkeit so eingestellt, dass keine Klebereste an dem bearbeiteten

WerkstÃ¼ck haften.The

Stickiness of the sealing strip is thereby advantageously to the

to be machined workpiece adapted such that after the

Machining process when the workpiece returns from the

limited air-permeable layer is removed, a residue-free

Detachment is possible. In other words

the stickiness adjusted so that no glue residue on the machined

Stick workpiece.

Die

Dichtstreifen bestehen vorzugsweise aus einem elastischen, von SchneidÃ¶len

und KÃ¼hlmitteln nicht angreifbaren Klebstoff.The

Sealing strips are preferably made of an elastic, of cutting oils

and coolants non-vulnerable adhesive.

Die

Dichtstreifen sind bei einer vorteilhaften AusfÃ¼hrungsform

nebeneinander auf der OberflÃ¤che der begrenzt luftdurchlÃ¤ssigen

Schicht unter beispielsweise Ausbildung eines beliebigen Musters

von stochastisch verteilten Linien, die sich kreuzen und so jeweils

Saugbereiche ausbilden, angeordnet.The

Sealing strips are in an advantageous embodiment

next to each other on the surface of the limited air permeable

Layer under, for example, any pattern

of stochastically distributed lines that intersect and so on

Form suction areas, arranged.

Eine

andere AusfÃ¼hrungsform sieht ein sich wiederholendes Muster

vor, beispielsweise ein Karomuster oder ein Muster nebeneinanderliegender Kreise

oder ein Wabenmuster. Ein solches Muster hat den Vorteil, dass es

an beliebige Konturen der zu bearbeitenden WerkstÃ¼cke anpassbar

ist.A

another embodiment sees a repeating pattern

For example, a check pattern or a pattern of adjacent circles

or a honeycomb pattern. Such a pattern has the advantage that it

adaptable to any contours of the workpieces to be machined

is.

Dabei

wird die GrÃ¶Ãe der beispielsweise durch die Karos

oder die Waben gebildeten Saugbereiche vorteilhafterweise an die

GrÃ¶Ãe des zu bearbeitenden WerkstÃ¼cks

angepasst. Bei kleinen zu bearbeitenden WerkstÃ¼cken ist

das Karomuster demnach kleiner ausgebildet als bei grÃ¶Ãeren

zu bearbeitenden WerkstÃ¼cken.there

is the size of the example by the checks

or the honeycomb formed suction areas advantageously to the

Size of the workpiece to be machined

customized. For small workpieces to be machined

the check pattern is therefore smaller than larger ones

to be machined workpieces.

Es

kann gemÃ¤Ã einer Ausgestaltung der Erfindung auch

vorgesehen sein, einen oder mehrere Klebepunkte, innerhalb der Saugbereiche

vorzusehen, wobei deren HÃ¶he der HÃ¶he der Dichtstreifen

im wesentlichen entspricht. Hierdurch wird ein weiter verbessertes

Halten des WerkstÃ¼cks aufgrund der Klebwirkung erzielt.It

can according to an embodiment of the invention also

be provided, one or more adhesive points, within the suction areas

provide, the amount of which the height of the sealing strip

essentially corresponds. This will be a further improved

Holding the workpiece achieved due to the adhesive effect.

Eine

andere vorteilhafte Ausgestaltung, die eine Bearbeitung von nebeneinander

liegenden WerkstÃ¼cken im Nutzen ermÃ¶glicht, sieht

vor, dass die Dichtstreifen auf der OberflÃ¤che der begrenzt

luftdurchlÃ¤ssigen Schicht so verlaufen, dass ihre Kontur den

zu bearbeitenden WerkstÃ¼cken jeweils nach gebildet ist.

Wenn in diesem Falle z. B. herzfÃ¶rmige Muster hergestellt

werden sollen, so kÃ¶nnen diese durch eine computergesteuerte

FrÃ¤smaschine nebeneinanderliegend aus einem massiven WerkstÃ¼ckblock

herausgefrÃ¤st werden. Die Dichtstreifen verlaufen dabei

geschlossen herzfÃ¶rmig und zwar so nebeneinanderliegend

auf der Schicht angeordnet, dass die ausgefrÃ¤sten Teile

nach der Bearbeitung auf der Platte gehalten werden. Die Dichtstreifen

verlaufen also gerade geringfÃ¼gig vor dem Rand, den der FrÃ¤skopf

bei dem HerausfrÃ¤sen der Teile umfÃ¤hrt, sodass

sie noch innerhalb des zu bearbeitenden WerkstÃ¼cks, dessen

Kontur nachbildend, verlaufen.A

Another advantageous embodiment, the processing of side by side

lying workpieces in the benefits allows sees

Before that, the sealing strips on the surface of the limited

permeable layer so that their contour

each workpiece to be machined is formed.

If in this case z. B. heart-shaped pattern produced

should be able to do this through a computerized

Milling machine next to each other from a massive workpiece block

be milled out. The sealing strips run thereby

closed heart-shaped and so juxtaposed

arranged on the layer that the milled parts

held on the plate after processing. The sealing strips

So run just slightly before the edge, the milling head

when milling out the parts, so that

they still within the workpiece to be machined, whose

Contouring contour, run.

Die

HÃ¶he der Dichtstreifen wird vorteilhafterweise an die OberflÃ¤chenrauigkeit

angepasst. Ein WerkstÃ¼ck, das eine raue OberflÃ¤che

aufweist, erfordert dabei hÃ¶here Dichtstreifen als ein

WerkstÃ¼ck mit einer glatten OberflÃ¤che.The

Height of the sealing strip is advantageously at the surface roughness

customized. A workpiece that has a rough surface

has, requires higher sealing strip than a

Workpiece with a smooth surface.

Bei

einer weiteren vorteilhaften AusfÃ¼hrungsform ist vorgesehen,

dass die begrenzt luftdurchlÃ¤ssige Schicht auch auf ihrer

dem WerkstÃ¼ck abgewandten und der Grundplatte zugewandten

Seite wenigstens ein Dichtelement aufweist. In diesem Falle verlÃ¤uft

das Dichtelement vorteilhafterweise am Randbereich der begrenzt

luftdurchlÃ¤ssigen Schicht, also in der NÃ¤he des

Randbereichs des Bogens oder der Platte. Hierdurch wird eine besonders

optimale Wirkung des Haltevakuums vermittelt.at

a further advantageous embodiment is provided

that the limited air permeable layer also on their

facing away from the workpiece and the base plate facing

Side has at least one sealing element. In this case runs

the sealing element advantageously limited at the edge region of

air-permeable layer, so close to the

Edge of the sheet or plate. This will be a special

gives optimal effect of holding vacuum.

Die

Dichtstreifen kÃ¶nnen auf die begrenzt luftdurchlÃ¤ssige

Schicht auf die unterschiedlichste Art und Weise aufgebracht werden.

Eine sehr vorteilhafte, da einfach und kostengÃ¼nstig herzustellende MÃ¶glichkeit

stellt das Aufdrucken der Dichtstreifen mittels Siebdrucktechnik

dar. Bei einer wiederum anderen AusfÃ¼hrungsform werden

die Dichtstreifen durch einen computergesteuerten Dispenser, also durch

ein gezieltes computergesteuertes Aufbringen mittels einer verfahrbaren

DÃ¼se auf die OberflÃ¤che der begrenzt luftdurchlÃ¤ssigen

Schicht aufgebracht. Eine weitere MÃ¶glichkeit ist das Aufbringen

der Dichtstreifen mittels eines Kalanders. Eine wiederum andere

MÃ¶glichkeit ist das AufsprÃ¼hen von HeiÃkleber in

Gestalt der Dichtstreifen, das AufsprÃ¼hen von Kleber Ã¼ber

Schablonen oder das Aufbringen der Dichtstreifen durch Tiefdruck

mittels Ãbertragungswalzen.The sealing strips can be applied to the limited air-permeable layer in a variety of ways. A very advantageous possibility, which is simple and inexpensive to produce, is the printing of the sealing strips by means of screen printing technology. In yet another embodiment, the sealing strips are applied to the surface by a computer-controlled dispenser, ie by a targeted computer-controlled application by means of a movable nozzle the limited air-permeable layer applied. Another possibility is the application of the sealing strips by means of a calender. Yet another possibility is the spraying of hot glue in the form of sealing strips, the spraying of adhesive on stencils or the application of the sealing strips by gravure by means of transfer rollers.

Die

begrenzt luftdurchlÃ¤ssige Schicht selbst, die vorzugsweise

als auf die Grundplatte aufzulegender Bogen oder Platte ausgebildet

ist, kann beispielsweise durch ein Filterpapier gebildet werden.

In diesem Falle ist das Filterpapier bogenfÃ¶rmig geschnitten.

Die begrenzt luftdurchlÃ¤ssige Schicht kann aber auch durch

eine so genannte Skinpappe gebildet werden oder durch eine MDF-

oder HDF-Platte, also eine mitteldichte Faserplatte oder eine hochdichte Faserplatte,

die porÃ¶s ausgebildet sind.The

limited air permeable layer itself, preferably

designed as aufzulegender to the base sheet or plate

is, for example, can be formed by a filter paper.

In this case, the filter paper is cut arcuate.

The limited air-permeable layer can also be through

a so-called skin cardboard are formed or by an MDF

or HDF board, ie a medium density fiberboard or a high density fiberboard,

which are porous.

Die

Dichtstreifen sind im Falle einer klebrigen Konsistenz durch eine

abziehbare Schutzschicht Ã¼berdeckt. Diese Schutzschicht

kann beispielsweise durch ein Silikonpapier oder eine Schutzfolie

gebildet werden. Durch sie ist ein Transport Ã¼bereinanderliegender

BÃ¶gen mÃ¶glich. Die abziehbare Schutzschicht ist

darÃ¼ber hinaus luftundurchlÃ¤ssig ausgebildet,

sodass durch sie keine AbschwÃ¤chung des Vakuums fÃ¼r

den Fall hervorgerufen wird, dass das WerkstÃ¼ck die begrenzt

luftdurchlÃ¤ssige Schicht nicht vollstÃ¤ndig Ã¼berdeckt.

In diesem Falle wird beispielsweise mittels eines Messers die Kontur

des WerkstÃ¼cks nachgezeichnet und in diesem Bereich die Schutzschicht

abgezogen. Das WerkstÃ¼ck wird sodann auf diesen Bereich

aufgelegt, wobei es aufgrund der durch die Dichtelemente gebildeten

Saugbereiche in optimaler Weise gehalten wird. Der Rest der begrenzt

luftdurchlÃ¤ssigen Schicht ist dabei wÃ¤hrend der

Bearbeitung des WerkstÃ¼cks von der luftundurchlÃ¤ssigen

Schutzschicht Ã¼berdeckt. Auf diese Weise ist sichergestellt,

dass das Vakuum im Bereich des WerkstÃ¼cks, das gehalten

werden soll, hoch ausgebildet ist, was bei einer begrenzt luftdurchlÃ¤ssigen Schicht,

die keine Schutzschicht trÃ¤gt, nicht der Fall ist. In diesem

letzteren Falle wÃ¼rde das Vakuum geschwÃ¤cht.The

Sealing strips are in the case of a sticky consistency by a

removable protective layer covered. This protective layer

For example, by a silicone paper or a protective film

be formed. Through them is a transport superimposed

Bows possible. The peelable protective layer is

In addition, air-impermeable,

through it no weakening of the vacuum for

the case is caused that the workpiece limits the

air-permeable layer not completely covered.

In this case, for example, by means of a knife, the contour

traced the workpiece and in this area the protective layer

deducted. The workpiece will then move to this area

applied, wherein it formed due to the sealing elements

Suction areas is kept in an optimal manner. The rest of the limited

air-permeable layer is doing during the

Machining the workpiece from the airtight

Protective layer covered. In this way it is ensured

that the vacuum is held in the area of the workpiece

is high, which is in a limited air-permeable layer,

which does not wear a protective layer is not the case. In this

the latter case would weaken the vacuum.

Der

Verlauf der Dichtstreifen ist bevorzugt an die Ãffnungen

in der Grundplatte angepasst. Es kÃ¶nnen beispielsweise

im Falle eines Karomusters die Dichtstreifen so angeordnet sein,

dass jeweils aneinandergrenzende Ecken genau Ã¼ber einer Ãffnung

in der Grundplatte zu liegen kommen, sodass diese Ãffnungen

gewissermaÃen auf vier Saugbereiche verteilt ist. Die Erfindung

ist jedoch nicht auf eine solche Anordnung beschrÃ¤nkt,

sondern es kann auch vorgesehen sein, dass die Ãffnungen

innerhalb der Saugbereiche liegen. Dabei kÃ¶nnen auch mehrere Ãffnungen

innerhalb der Saugbereiche angeordnet sein.Of the

Course of the sealing strip is preferred to the openings

adapted in the base plate. It can, for example

in the case of a check pattern, the sealing strips be arranged so

that each adjoining corners just above an opening

come to rest in the base plate so that these openings

is spread over four suction areas. The invention

but is not limited to such an arrangement,

but it can also be provided that the openings

lie within the suction areas. It can also have multiple openings

be arranged within the suction areas.

Kurze Beschreibung der ZeichnungenBrief description of the drawings

AusfÃ¼hrungsbeispiele

der Erfindung sind in den Zeichnungen dargestellt und in der nachfolgenden

Beschreibung nÃ¤her erlÃ¤utert. Es zeigen:embodiments

The invention is illustrated in the drawings and in the following

Description explained in more detail. Show it:

1a schematisch die Anordnung einer erfindungsgemÃ¤Ãen

begrenzt luftdurchlÃ¤ssigen Schicht Ã¼ber einer

ersten Grundplatte; 1a schematically the arrangement of a limited air-permeable layer according to the invention over a first base plate;

1b schematisch

die Anordnung einer erfindungsgemÃ¤Ãen begrenzt

luftdurchlÃ¤ssigen Schicht Ã¼ber einer anderen Grundplatte; 1b schematically the arrangement of a limited air-permeable layer according to the invention over another base plate;

2a schematisch,

in Draufsicht die Anordnung der Dichtelemente sowie fakultativ mÃ¶glicher

Klebepunkte auf einer begrenzt luftdurchlÃ¤ssigen Schicht Ã¼ber

der ersten, in 1a dargestellten Grundplatte; 2a schematically, in plan view, the arrangement of the sealing elements and optionally possible adhesive dots on a limited air-permeable layer over the first, in 1a illustrated base plate;

2b schematisch

in Draufsicht die Anordnung einer mit Dichtelementen versehenen

begrenzt luftdurchlÃ¤ssigen Schicht Ã¼ber der weiteren,

in 1b dargestellten Grundplatte; 2 B schematically in plan view the arrangement of a provided with sealing elements limited air-permeable layer over the other, in 1b illustrated base plate;

2c die

Anordnung einer mit Dichtelementen versehenen begrenzt luftdurchlÃ¤ssigen Schicht Ã¼ber

einer dritten Grundplatte; 2c the arrangement of a provided with sealing elements limited air permeable layer over a third base plate;

3 ein

auf einer ersten AusfÃ¼hrungsform der begrenzt luftdurchlÃ¤ssigen

Schicht positioniertes WerkstÃ¼ck; 3 a workpiece positioned on a first embodiment of the limited air-permeable layer;

4 drei

auf einer einer zweiten AusfÃ¼hrungsform der begrenzt luftdurchlÃ¤ssigen

Schicht positionierte WerkstÃ¼cke. 4 three on a second embodiment of the limited air-permeable layer positioned workpieces.

AusfÃ¼hrungsformen

der Erfindungembodiments

the invention

Eine

Vorrichtung zur Positionierung und Befestigung von zu bearbeitenden

WerkstÃ¼cken, dargestellt in 1 und 2, weist eine im Wesentlichen ebene, Ãffnungen 115 aufweisende

Grundplatte 110 auf.A device for positioning and fixing of workpieces to be machined, shown in FIG 1 and 2 , Has a substantially flat, openings 115 having base plate 110 on.

Die Ãffnungen 115 sind

an ihrer Unterseite Ã¼ber entsprechende KanÃ¤le 116 mit

einer Vakuumpumpe 118 verbunden, durch die auf an sich

bekannte Weise ein Vakuum an der Oberseite der Grundplatte 110 zum

Halten eines WerkstÃ¼cks 300, 310, 320, 340 (3 und 4)

mÃ¶glich ist.The openings 115 are on their underside via appropriate channels 116 with a vacuum pump 118 connected, by the known per se, a vacuum at the top of the base plate 110 for holding a workpiece 300 . 310 . 320 . 340 ( 3 and 4 ) is possible.

Die

Oberseite der Grundplatte 110 ist mit einer begrenzt luftdurchlÃ¤ssigen

Schicht 120 Ã¼berdeckt, die beispielsweise in Form

eines Filterpapierbogens, einer so genannten Skinpappe oder einer MDF-

oder HDF-Platte ausgebildet sein kann. Diese begrenzt luftdurchlÃ¤ssige

Schicht 120 ist porÃ¶s ausgebildet. Sie wirkt als

Drossel und DÃ¤mpfung des Vakuums und ermÃ¶glicht

eine gleichmÃ¤Ãig verteilte Wirkung des Vakuums

auf ein zu positionierendes und zu befestigendes WerkstÃ¼ck 300, 310, 320, 340 (3, 4).

Sie verhindert insbesondere, dass bei unbedeckten FlÃ¤chen

das Vakuum zusammenbricht. DarÃ¼ber hinaus wirkt sie als âOpferschicht" und

verhindert so eine BeschÃ¤digung der Grundplatte 110 beim

FrÃ¤svorgang. Wird ein WerkstÃ¼ck umfrÃ¤st,

wie beispielsweise in 3 und 4 dargestellt,

oder wird in ein WerkstÃ¼ck eine Ãffnung hineingefrÃ¤st,

wie beispielsweise eine Ãffnung 315 in ein WerkstÃ¼ck 310 (4),

verhindert diese begrenzt luftdurchlÃ¤ssige Schicht aufgrund

der Drosselwirkung, dass das Vakuum zusammenbricht, da die LuftstrÃ¶mung

durch die Drosselwirkung begrenzt wird.The top of the base plate 110 is with a limited air permeable layer 120 covered, which may be formed for example in the form of a filter paper sheet, a so-called skin board or MDF or HDF plate. This limited air permeable layer 120 is porous. It acts as a throttle and damping the vacuum and allows a uniformly distributed We kung of the vacuum on a workpiece to be positioned and fastened 300 . 310 . 320 . 340 ( 3 . 4 ). In particular, it prevents the vacuum from collapsing on uncovered surfaces. In addition, it acts as a "sacrificial layer" and thus prevents damage to the base plate 110 during the milling process. If a workpiece is milled, such as in 3 and 4 shown, or is milled into a workpiece, an opening, such as an opening 315 into a workpiece 310 ( 4 ), this limited air-permeable layer prevents the vacuum from collapsing due to the throttling action, since the air flow is limited by the throttling action.

Bei

einer an sich bekannten begrenzt luftdurchlÃ¤ssigen Schicht,

wie sie beispielsweise aus der DE 40 30 113 A1 hervorgeht, ist es nun jedoch mÃ¶glich,

dass beim AusfrÃ¤sen einer grÃ¶Ãeren Ãffnung

aus dem WerkstÃ¼ck das Vakuum so stark geschwÃ¤cht

wird, dass das WerkstÃ¼ck auch unter BerÃ¼ck sichtigung

der Drosselwirkung der begrenzt luftdurchlÃ¤ssigen Schicht

nicht mehr sicher gehalten wird. DarÃ¼ber hinaus kann es

vorkommen, dass beispielsweise bei der Bearbeitung dÃ¼nner

Bleche der FrÃ¤skopf das Blech aufgrund der bei der Bearbeitung ausgeÃ¼bten

KrÃ¤fte an einer Ecke leicht anhebt, wodurch das Vakuum

schlagartig zusammenbricht und das WerkstÃ¼ck mangels HaltekrÃ¤ften

von der begrenzt luftdurchlÃ¤ssigen Schicht weggeschleudert wird.In a known per se limited air-permeable layer, as for example from the DE 40 30 113 A1 However, it is now possible that when milling a larger opening from the workpiece, the vacuum is weakened so much that the workpiece is no longer safe even taking into account the throttle effect of the limited air-permeable layer. In addition, it may happen that, for example, in the processing of thin sheets, the milling head slightly raises the sheet due to the forces exerted during machining forces on a corner, causing the vacuum collapses abruptly and the workpiece is thrown out of the limited air-permeable layer for lack of holding forces.

Um

derartig nachteilige Effekte zu verhindern, ist es nun Grundidee

der Erfindung, auf der begrenzt luftdurchlÃ¤ssigen Schicht 120 eine

Vielzahl von Saugbereichen auszubilden. Dies geschieht durch Aufbringen

von Dichtstreifen 140 und 142 auf der dem zu bearbeitenden

WerkstÃ¼ck 300, 310, 320 und 340 zugewandten

OberflÃ¤che. Diese Dichtstreifen 140 und 142 sind

beispielsweise, wie in 1 und 2 dargestellt, karofÃ¶rmig oder

in Form von Quadraten so angeordnet, dass jeweils sich kreuzende

Dichtstreifen 140, 142 einen geschlossenen Saugbereich 145 bilden.

Dabei liegen mehrere Saugbereiche 145 nebeneinander. Die

Dichtstreifen 140, 142 sind auf die OberflÃ¤che

der Schicht 120, beispielsweise mittels Siebdrucktechnik

oder durch computergesteuertes Aufbringen mittels sogenannter Dispenser

oder durch einen Kalander aufgebrachte erhabene DichtwÃ¤lle.

DarÃ¼ber hinaus ist es mÃ¶glich, die Dichtstreifen

durch AufsprÃ¼hen von HeiÃkleber in der Gestalt

der Dichtstreifen, das AufsprÃ¼hen von Kleber Ã¼ber

eine Schablone oder durch Tiefdruck mittels Ãbertragungswalzen

herzustellen.In order to prevent such adverse effects, it is now basic idea of the invention, on the limited air-permeable layer 120 to form a plurality of suction areas. This is done by applying sealing strips 140 and 142 on the workpiece to be machined 300 . 310 . 320 and 340 facing surface. These sealing strips 140 and 142 are, for example, as in 1 and 2 represented, karofÃ¶rmig or in the form of squares arranged so that in each case intersecting sealing strips 140 . 142 a closed suction area 145 form. There are several suction areas 145 side by side. The sealing strips 140 . 142 are on the surface of the layer 120 For example, by screen printing technology or by computer-controlled application by means of so-called dispenser or by a calender applied raised sealing walls. Moreover, it is possible to produce the sealing strips by spraying hot glue in the form of the sealing strips, spraying adhesive on a stencil or by gravure by means of transfer rollers.

Auch

mÃ¼ssen die Dichtstreifen keinesfalls in einer regelmÃ¤Ãigen

Ordnung auf der begrenzt luftdurchlÃ¤ssigen Schicht angeordnet

werden. MÃ¶glich ist es vielmehr auch, die Dichtstreifen 140, 142 als stochastisch

verteilte Linien, die sich kreuzen und so jeweils abgeschlossene

Saugbereiche ausbilden, zu realisieren.Also, the sealing strips need in no case be arranged in a regular order on the limited air-permeable layer. It is also possible, the sealing strips 140 . 142 as stochastically distributed lines that intersect and thus form each completed suction areas to realize.

Die

Dichtstreifen 140, 142 bestehen bevorzugt aus

einem elastischen Material, sodass sie sich an leichte Unebenheiten

des WerkstÃ¼cks 300, 310, 320, 340,

insbesondere dann, wenn dieses eine raue OberflÃ¤che aufweist,

anpassen und dabei gleichzeitig eine optimale Abdichtung erzielen.The sealing strips 140 . 142 are preferably made of an elastic material so that they are sensitive to slight unevenness of the workpiece 300 . 310 . 320 . 340 Especially when this has a rough surface, adapt and at the same time achieve an optimal seal.

Besonders

vorteilhaft weisen die Dichtstreifen eine klebrige Konsistenz auf.

In diesem Falle wird das zu bearbeitende WerkstÃ¼ck 300, 310, 320, 340 bereits

durch die Klebrigkeit der Dichtstreifen 140, 142 gehalten.

Die Klebrigkeit erhÃ¶ht zudem die Dichtigkeit. Neben den

Dichtstreifen kÃ¶nnen im Falle einer klebrigen Konsistenz

der Dichtstreifen 140, 142 auch weitere Klebepunkte 141 vorgesehen

sein, wie sie schematisch im linken oberen Bereich der 2a dargestellt

sind. Diese Klebepunkte 141 verbessern die Anhaftung des

WerkstÃ¼cks auf der begrenzt luftdurchlÃ¤ssigen

Schicht 120, ohne die Wirkung der durch die Dichtstreifen 140, 142 ausgebildeten

Saugbereiche 145 zu beeinflussen.Particularly advantageously, the sealing strips have a sticky consistency. In this case, the workpiece to be machined 300 . 310 . 320 . 340 already by the stickiness of the sealing strips 140 . 142 held. The stickiness also increases the tightness. In addition to the sealing strips can in the case of a sticky consistency of the sealing strip 140 . 142 also more glue dots 141 be provided as shown schematically in the left upper area of the 2a are shown. These glue dots 141 improve the adhesion of the workpiece on the limited air-permeable layer 120 without the effect of passing through the sealing strips 140 . 142 trained suction areas 145 to influence.

Es

ist nun eine der maÃgeblichen Ideen der Erfindung, eine

Mehrzahl von nebeneinanderliegenden Saugbereichen 145 auszubilden.It is now one of the relevant ideas of the invention, a plurality of juxtaposed suction areas 145 train.

Durch

diese Saugbereiche 145 wird sichergestellt, dass das WerkstÃ¼ck 300 (vergl. 3)

auch dann sicher auf der Grundplatte 110 gehalten wird, wenn

der FrÃ¤skopf (nicht dargestellt) durch Abfahren der AuÃenkontur

die begrenzt luftdurchlÃ¤ssige Schicht 120 beschÃ¤digt

hat. In diesem Falle sind nÃ¤mlich, wie in 3 dargestellt,

zwar mehrere Saugbereiche 145 âbeschÃ¤digt",

was so viel bedeutet, dass das Vakuum in diesen Saugbereichen zusammengebrochen

ist. Im Inneren des WerkstÃ¼cks 300 sind aber Saugbereiche 149 aktiv

und halten das WerkstÃ¼ck 300 sicher auf der Grundplatte 110.Through these suction areas 145 will ensure that the workpiece 300 (Comp. 3 ) then securely on the base plate 110 is held when the milling head (not shown) by moving the outer contour of the limited air-permeable layer 120 damaged. In this case, as in 3 shown, although several suction areas 145 "Damaged", which means that the vacuum in these suction areas has collapsed - inside the workpiece 300 but are suction areas 149 active and hold the workpiece 300 sure on the base plate 110 ,

Wie

in 1a und 2a dargestellt

ist, kÃ¶nnen dabei die auch als DichtwÃ¤lle zu bezeichnenden

Dichtstreifen 140, 142 so positioniert sein, dass jeweils

ein Eck eines Saugbereichs 145 Ã¼ber einer Ãffnung 115 in

der Grundplatte zu liegen kommt. Auf diese Weise wirkt die Ãffnung 115 gewissermaÃen simultan

in vier nebeneinanderliegenden Saugbereichen 145. Es ist

jedoch hervorzuheben, dass die Erfindung nicht auf eine solche An ordnung

beschrÃ¤nkt ist, sondern dass die Dichtstreifen 140, 142 auch

in beliebig anderer Weise verlaufen kÃ¶nnen, beispielsweise

so, dass jeweils eine Ãffnung 115 in einem Saugbereich 145 zu

liegen kommt (1b, 2b).As in 1a and 2a is shown, while the sealing walls to be designated as sealing strips 140 . 142 be positioned so that each one corner of a suction area 145 over an opening 115 comes to rest in the base plate. This is how the opening works 115 in a sense, simultaneously in four adjacent suction areas 145 , However, it should be emphasized that the invention is not limited to such an arrangement, but that the sealing strips 140 . 142 can also run in any other way, for example, so that in each case an opening 115 in a suction area 145 to come to rest ( 1b . 2 B ).

Es

ist des Weiteren auch mÃ¶glich, die Dichtstreifen 140, 142 so

anzuordnen, dass jeweils mehrere Ãffnungen 115 innerhalb

der Saugbereiche 145 angeordnet sind, wie dies schematisch

in 2c dargestellt ist.It is also possible, the sealing strips 140 . 142 to arrange so that in each case several openings 115 within the suction areas 145 are arranged as shown schematically in 2c is shown.

Generell

kann gesagt werden, dass die Dichtstreifen 140, 142 und

damit die Saugbereiche 145 zur Erzielung des erfindungsgemÃ¤Ãen

Effekts nicht auf die Ãffnungen 115 abgestimmt

werden mÃ¼ssen.Generally it can be said that the sealing strips 140 . 142 and thus the suction areas 145 not to the openings to achieve the effect of the invention 115 have to be coordinated.

Die

Dichtstreifen 140, 142 werden bevorzugt durch

einen elastischen Klebstoff gebildet, der gegenÃ¼ber SchneidÃ¶len

und KÃ¼hlmitteln, wie sie bei einem FrÃ¤svorgang

verwendet werden, unempfindlich ist und nicht angegriffen wird.The sealing strips 140 . 142 are preferably formed by an elastic adhesive that is insensitive to cutting oils and coolants used in a milling operation and is not attacked.

Die

klebrigen, die Saugbereiche 145 bildenden Dichtstreifen 140, 142 sind

durch eine Schutzschicht 200 Ã¼berdeckt, die beispielsweise

durch ein Silikonpapier oder durch eine Folie realisiert wird. Dieses

Silikonpapier oder die Folie ist leicht von den Dichtstreifen 140, 142 abziehbar.

Die Abdeckung durch das Silikonpapier oder die Folie geschieht aufgrund

von zwei GrÃ¼nden. Zum einen ist ein Transport Ã¼bereinanderliegender,

beispielsweise als PapierbÃ¶gen ausgebildeter begrenzt luftdurchlÃ¤ssiger

Schichten 120 auf diese Weise mÃ¶glich, ohne dass

die die BÃ¶gen aneinander verkleben. Zum anderen â und dies

ist ein ganz wesentlicher Effekt â wird durch die luftundurchlÃ¤ssige

Schutzschicht 200 in Form des Silikonpapiers oder der Folie

das Vakuum in den Saugbereichen 145, die nicht von dem

WerkstÃ¼ck 300 Ã¼berdeckt sind, nicht geschwÃ¤cht

oder auf andere Weise negativ beeinflusst.The sticky, the suction areas 145 forming sealing strip 140 . 142 are through a protective layer 200 covered, which is realized for example by a silicone paper or by a film. This silicone paper or foil is slightly off the sealing strips 140 . 142 removable. The covering by the silicone paper or foil is due to two reasons. On the one hand is a transport superimposed, for example, designed as paper sheets limited air-permeable layers 120 possible in this way without the sheets sticking together. On the other hand - and this is a very significant effect - is provided by the air-impermeable protective layer 200 in the form of the silicone paper or the film, the vacuum in the suction areas 145 not from the workpiece 300 are covered, not weakened or otherwise negatively affected.

Wie

in 3 dargestellt ist, wird beispielsweise die Kontur

eines zu bearbeitenden WerkstÃ¼cks 300, das auf

der Platte 110 gehalten werden soll, beispielsweise mittels

eines Messers nachgezeichnet. Die Schutzschicht 200 wird

in diesem Falle entlang einer so ausgebildeten Kontur 210 abgezogen,

sodass das WerkstÃ¼ck 300 gewissermaÃen

passgenau auf der begrenzt luftdurchlÃ¤ssigen Schicht 120 angeordnet

ist. Hierdurch wird sichergestellt, dass nur eine kleine Zahl von

Saugbereichen beim FrÃ¤svorgang mit der Umgebung kommunizieren

kÃ¶nnen, nÃ¤mlich genau die am Rand des WerkstÃ¼cks 300 liegenden

Saugbereiche. Die inneren Saugbereiche, in 3 beispielsweise

die zwÃ¶lf dargestellten Saugbereiche 149, erfÃ¼llen

demgegenÃ¼ber in vollem Umfang ihren Zweck, nÃ¤mlich

die Aufrechterhaltung des Haltevakuums und damit die AusÃ¼bung

einer hohen Haltekraft.As in 3 is shown, for example, the contour of a workpiece to be machined 300 that on the plate 110 should be kept, for example, traced by a knife. The protective layer 200 is in this case along a contour so formed 210 deducted so that the workpiece 300 in a way fitting on the limited air-permeable layer 120 is arranged. This ensures that only a small number of suction areas can communicate with the environment during the milling process, namely precisely at the edge of the workpiece 300 lying suction areas. The inner suction areas, in 3 for example, the twelve illustrated suction areas 149 In contrast, fully meet their purpose, namely the maintenance of holding vacuum and thus the exercise of a high holding power.

Zu

bemerken ist auch, dass die Ausbildung der Dichtstreifen 140, 142 als

erhabene WÃ¤lle eine hohe FlÃ¤chenpressung ermÃ¶glichen â im

Vergleich zu der flÃ¤chigen Aufbringung von beispielsweise Klebstoffen,

wie sie aus dem Stand der Technik bekannt ist. Hierdurch wird die

Dichtwirkung weiter wesentlich erhÃ¶ht.It should also be noted that the formation of the sealing strip 140 . 142 As raised walls allow a high surface pressure - in comparison to the surface application of, for example, adhesives, as known from the prior art. As a result, the sealing effect is further increased significantly.

Das

in 1 und 3 dargestellte

AusfÃ¼hrungsbeispiel ermÃ¶glicht die Positionierung

und Anordnung von WerkstÃ¼cken 300, 310, 320, 340 mit

beliebiger Kontur. Die quadratische oder Karoanordnung der Dichtstreifen 140, 142 ist

hierbei gewissermaÃen von vornherein an WerkstÃ¼cke

beliebiger Kontur angepasst, wobei zu bemerken ist, dass der Abstand

der Dichtelemente 140 bzw. 142 und damit die GrÃ¶Ãe

der Karos auf die GrÃ¶Ãe der zu bearbeitenden WerkstÃ¼cke

derart abzustimmen ist, dass fÃ¼r kleinere WerkstÃ¼cke

enger nebeneinanderliegende Dichtelemente 140, 142 (kleinere

Karos) vorgesehen sind als fÃ¼r grÃ¶Ãere

WerkstÃ¼cke.This in 1 and 3 illustrated embodiment allows the positioning and arrangement of workpieces 300 . 310 . 320 . 340 with any contour. The square or check arrangement of the sealing strips 140 . 142 In this case, it is to a certain extent adapted from the outset to workpieces of any desired contour, it being noted that the distance between the sealing elements 140 respectively. 142 and thus to adjust the size of the checks to the size of the workpieces to be machined such that for smaller workpieces closer juxtaposed sealing elements 140 . 142 (smaller checks) are provided as for larger workpieces.

Eine

andere AusfÃ¼hrungsform, dargestellt in 4,

sieht vor, die Dichtelemente der Kontur des zu bearbeitenden WerkstÃ¼cks

anzupassen. So ist beispielsweise bei dem in 4 dargestellten

kreisrunden WerkstÃ¼ck 340 ein Dichtelement 146 in

Form einer Kreislinie dargestellt. In diesem Falle ist der Saugbereich 146' ebenfalls

kreisfÃ¶rmig ausgebildet. Auch in diesem Falle wird die

Kontur des zu bearbeitenden WerkstÃ¼cks 340, das

auf der Platte 110 gehalten wird, beispielsweise durch

ein Messer nachgezeichnet. Die Schutzschicht 200 wird dann

entlang der so ausgebildeten Kontur 210'' abgezogen, sodass

das WerkstÃ¼ck 340 nahezu passgenau auf der begrenzt

luftdurchlÃ¤ssigen Schicht 120 angeordnet ist.Another embodiment, shown in FIG 4 , provides to adapt the sealing elements of the contour of the workpiece to be machined. For example, in the case of 4 shown circular workpiece 340 a sealing element 146 represented in the form of a circle. In this case, the suction area 146 ' also formed circular. Also in this case, the contour of the workpiece to be machined 340 that on the plate 110 held, for example, traced by a knife. The protective layer 200 is then along the contour thus formed 210 '' deducted so that the workpiece 340 almost exactly on the limited air-permeable layer 120 is arranged.

Bei

dem in 4 dargestellten WerkstÃ¼ck 310,

welches eine Ãffnung 315 aufweist, sind die Dichtelemente 147 jeweils

am Ã¤uÃeren Rand des WerkstÃ¼cks 310 bzw.

der Ãffnung 315 angeordnet und bilden so einen

geschlossenen, eine Ãffnung aufweisenden rechteckfÃ¶rmigen

Saugbereich 147' aus. Es wird wiederum mittels eines Messers

die zu erwartende AuÃenkontur des zu bearbeitenden WerkstÃ¼cks 310 nachgezeichnet

und die Schutzschicht 200 entlang dieser Kontur 210' abgezogen, um

auch in diesem Falle das WerkstÃ¼ck 310 praktisch

passgenau auf der begrenzt luftdurchlÃ¤ssigen Schicht 120 anzuordnen.At the in 4 represented workpiece 310 which is an opening 315 has, are the sealing elements 147 each at the outer edge of the workpiece 310 or the opening 315 arranged and thus form a closed, an opening having rectangular suction area 147 ' out. It is again by means of a knife, the expected outer contour of the workpiece to be machined 310 traced and the protective layer 200 along this contour 210 ' deducted, in this case too, the workpiece 310 practically perfect fit on the limited air-permeable layer 120 to arrange.

Bei

dem in 4 weiterhin dargestellten WerkstÃ¼ck 320,

das von seiner Ã¤uÃeren Gestalt im Wesentlichen

dem in 3 dargestellten WerkstÃ¼ck 300 entspricht,

ist ein Dichtelement 148 vorgesehen, das der Kontur des

WerkstÃ¼cks 320 im Wesentlichen folgt und geschlossen

verlÃ¤uft, sodass ein Dichtbereich 148' ausgebildet

wird, der wie das WerkstÃ¼ck 320 eine L-fÃ¶rmige

Gestalt aufweist. Um auch hier eine mÃ¶glichst optimale

Befestigung des WerkstÃ¼cks 320 auf der begrenzt

luftdurchlÃ¤ssigen Schicht 120 zu erzielen, wird

wiederum mittels eines beispielsweise Messers die Ã¤uÃere

Kontur des WerkstÃ¼cks 320 abgefahren und die Schutzschicht 200 entlang

der so entstehenden Kontur 210''' von der begrenzt luftdurchlÃ¤ssigen

Schicht 120 entfernt.At the in 4 also shown workpiece 320 that of its external shape is essentially the one in 3 represented workpiece 300 corresponds, is a sealing element 148 provided that the contour of the workpiece 320 essentially follows and runs closed, leaving a sealing area 148 ' is formed, which is like the workpiece 320 has an L-shaped shape. Here, too, the best possible attachment of the workpiece 320 on the limited air-permeable layer 120 to achieve, in turn, by means of a knife, for example, the outer contour of the workpiece 320 gone and the protective layer 200 along the resulting contour 210 ''' from the limited air-permeable layer 120 away.

Die

in 4 dargestellte Ausbildung der Dichtelemente, jeweils

angepasst an die Form des zu bearbeitenden WerkstÃ¼cks,

kann insbesondere dann vorgenommen werden, wenn eine Mehrzahl von

nebeneinanderliegenden gleich konturierten WerkstÃ¼cken

gewissermaÃen âim Nutzen" bearbeitet werden soll.

In diesem Fall kann der Verlauf der Dichtelemente 146, 147 bzw. 148 und damit

die Ausbildung der Saugbereiche 146' bzw. 147' bzw. 148' an

die Koordinaten des FrÃ¤sers angepasst sein. Eine solche Ausbildung

der Dichtelemente ermÃ¶glicht einen besonders groÃflÃ¤chigen

Saugbereich und damit eine besonders optimale Positionierung und

Befestigung der zu bearbeitenden WerkstÃ¼cke auf der begrenzt luftdurchlÃ¤ssigen

Schicht 120.In the 4 illustrated embodiment of the sealing elements, each adapted to the shape of the workpiece to be machined, can be made in particular when a plurality of adjacent equally contoured workpieces is to be processed in a sense "in use." In this case, the course of the sealing elements 146 . 147 respectively. 148 and thus the formation of the suction areas 146 ' respectively. 147 ' respectively. 148 ' adapted to the coordinates of the milling cutter. Such a design of the sealing elements allows a particularly large suction area and thus a particularly optimal positioning and attachment of the workpieces to be machined on the limited air-permeable layer 120 ,

Diese

werkstÃ¼ckabhÃ¤ngigen Dichtelemente 146, 147, 148 kÃ¶nnen

auch in diesem Fall zum Beispiel durch Siebdrucktechnik oder durch

die anderen, oben beschriebenen Verfahren hergestellt werden.These workpiece-dependent sealing elements 146 . 147 . 148 can also be made in this case, for example by screen printing technique or by the other methods described above.

Es

kann gemÃ¤Ã einer Ausgestaltung der Erfindung auch

vorgesehen sein, einen oder mehrere Klebepunkte, innerhalb der Saugbereiche 145, 146', 147, 148' vorzusehen,

wobei deren HÃ¶he der HÃ¶he der Dichtstreifen im

wesentlichen entspricht. Hierdurch wird ein weiter verbessertes

Halten des WerkstÃ¼cks aufgrund der Klebwirkung erzielt

(nicht dargestellt).It may also be provided according to an embodiment of the invention, one or more adhesive points, within the suction areas 145 . 146 ' . 147 . 148 ' provide, the height of which corresponds to the height of the sealing strip substantially. As a result, a further improved holding of the workpiece is achieved due to the adhesive effect (not shown).

Neben

der Ausbildung der Saugbereiche auf der dem WerkstÃ¼ck 300, 310, 320, 340 zugewandten OberflÃ¤che

der begrenzt luftdurchlÃ¤ssigen Schicht 120 kann

auch vorgesehen sein, auf der der Grundplatte 110 zugewandten

OberflÃ¤che der begrenzt luftdurchlÃ¤ssigen Schicht 120 einen

oder mehrere das Haltevakuum weiter erhÃ¶hende Saugbereiche

auszubilden. So kann beispielsweise vorgesehen sein, dass am Randbereich

des Bogens, der die begrenzt luftdurchlÃ¤ssige Schicht 120 bildet,

Dichtelemente 190 verlaufen. In diesem Falle ist auch die

der Grundplatte 110 zugewandte OberflÃ¤che der

begrenzt luftdurchlÃ¤ssigen Schicht 120 zunÃ¤chst

mit einem Silikonpapier oder einer Schutzfolie Ã¼berdeckt.In addition to the training of the suction areas on the workpiece 300 . 310 . 320 . 340 facing surface of the limited air-permeable layer 120 can also be provided on the base plate 110 facing surface of the limited air-permeable layer 120 form one or more of the holding vacuum further increasing suction areas. For example, it may be provided that at the edge region of the sheet, which is the limited air-permeable layer 120 forms, sealing elements 190 run. In this case is also the base plate 110 facing surface of the limited air-permeable layer 120 initially covered with a silicone paper or a protective film.

ZITATE ENTHALTEN IN DER BESCHREIBUNGQUOTES INCLUDE IN THE DESCRIPTION

Diese Liste

der vom Anmelder aufgefÃ¼hrten Dokumente wurde automatisiert

erzeugt und ist ausschlieÃlich zur besseren Information

des Lesers aufgenommen. Die Liste ist nicht Bestandteil der deutschen

Patent- bzw. Gebrauchsmusteranmeldung. Das DPMA Ã¼bernimmt

keinerlei Haftung fÃ¼r etwaige Fehler oder Auslassungen.This list

The documents listed by the applicant have been automated

generated and is solely for better information

recorded by the reader. The list is not part of the German

Patent or utility model application. The DPMA takes over

no liability for any errors or omissions.

Zitierte PatentliteraturCited patent literature

- DE 4030113

A1 [0002, 0005, 0006, 0039] - DE 4030113 A1 [0002, 0005, 0006, 0039]

- DE 20117390 U1 [0003, 0005] - DE 20117390 U1 [0003, 0005]

- DE 10357268 B3 [0003, 0004] - DE 10357268 B3 [0003, 0004]

## Classifications

- B25B11/005
- B23Q3/08
- B23Q3/088
- B25B11/00

## Cited patent documents

- [DE-10357268-B3](https://patents.google.com/patent/DE10357268B3/en) — APP
- [DE-20117390-U1](https://patents.google.com/patent/DE20117390U1/en) — APP
- [DE-29780369-U1](https://patents.google.com/patent/DE29780369U1/en) — SEA
- [DE-4030113-A1](https://patents.google.com/patent/DE4030113A1/en) — APP,SEA
- [US-3335994-A](https://patents.google.com/patent/US3335994A/en) — SEA

---

Generated by IPtorch. Verify legal conclusions against the official publication.
