# 12. Tile holding and placement device

- **Archive rank:** 12 of 50
- **Publication:** [US-3643992-A](https://patents.google.com/patent/US3643992A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/021913689/publication/US3643992A?q=pn%3DUS3643992A)
- **Publication date:** 1972-02-22
- **Filing date:** 1970-05-27
- **Earliest priority:** 1970-05-27
- **Family:** 21913689
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** ROMEO JACOBUCCI
- **Inventors:** JACOBUCCI ROMEO

## Abstract

A rectangular casing having a planar rubber facing apertured and communicating with the interior of the casing. A hose attachment on the back of the casing enables a vacuum hose to be attached thus transferring suction to the apertures. When the tiles are placed in position on the wall by the device, the vacuum is broken by releasing a cap on the other end of the hose attachment thus releasing the tiles.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/US-3643992-A/000.png)

![Sketch 1 for US-3643992-A](https://nimo.iptorch.com/refdrawing/US-3643992-A/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/US-3643992-A/001.png)

![Sketch 2 for US-3643992-A](https://nimo.iptorch.com/refdrawing/US-3643992-A/001.png)

## Claims

### Claim 1 (independent)

A tile holding and placement device comprising in combination a substantially rectangular casing, a resilient apertured facing on one side of said casing, a vacuum hose attachment on the other side of said casing and means to release the vacuum at said apertures, said vacuum hose attachment including a double-ended tube connected with the interior of said casing, a first springloaded cap on one end of said tube, said tube adapted to receive a vacuum hose when said first spring-loaded cap is open, said means to release said vacuum including a second spring-loaded cap on the other end of said tube, said second spring-loaded cap being manipulatable to release said vacuum and being normally biassed to close off said other end.

### Claim 2

The device according to claim 1, which includes a pair of lifting handles, one adjacent each end of said other side of said casing.

### Claim 3

The device according to claim 2, in which said casing includes a relatively thin flexible rear panel, a relatively thin flexible apertured front panel, a perimetrical resilient seal between said panels, and resilient seals around each of said apertures adapted to engage and seal against the surface of the tiles being picked up thereby applying suction to said tiles.

### Claim 4

The device according to claim 1, in which said casing includes a relatively thin flexible rear panel, a relatively thin flexible apertured front panel, a perimetrical resilient seal between said panels, and resilient seals around each of said apertures adapted to engage and seal against the surface of the tiles being picked up thereby applying suction to said tiles.

## Full description

**[p0001]**

United States Patent J acobucci TILE HOLDING AND PLACEMENT DEVICE Inventor: Romeo .lacobucci, 337 Lynbrook Drive, Winnipeg 20, Manitoba, Canada Filed: May 27, 1970 Appl. No.: 40,915 Related US. Application Data Continuation-in-part of Ser. No. 847,065, Aug. 4, 1969, abandoned. U.S. Cl. ..294/65, 294/64 R int. Cl. B66c 1/02 Field of Search ..294/64, 65 References Cited UNITED STATES PATENTS Hirt .5. &#34;gages 5] Feb. 22, 1972 Billner Cremer .294/64 Primary ExaminerEvon C. Blunk Assistant Examiner-Johnny D. Cherry Attorney-Kent &amp; Ade ABSTRACT A rectangular casing having a planar rubber facing apertured and communicating with the interior of the casing. A hose attachment on the back of the casing enables a vacuum hose to be attached thus transferring suction to the apertures. When the tiles are placed in position on the wall by the device, the vacuum is broken by releasing a cap on the other end of the hose attachment thus releasing the tiles. 4 Claims, 10 Drawing Figures PATENTEBFEBZZ i972 @HEHEIEE] INVENTOR ROMEO JACOBUCCI BY Mv 5 41a ATTORNEY TILE HOLDING AND PLACEMENT DEVICE This invention relates to new and useful improvements in pickup and placement devices specifically designated for the installation of various types of wall or floor tiles such as ceramic, clay or the like, which constitutes a continuation-inpart of my application, Ser. No. 847,065, filed Aug. 4, 1969, now abandoned.

**[p0002]**

Normally mastic or cement or the like is spread upon the wall surface and these tiles are then placed individually in position and pressed into the mastic or cement with a small space left between adjacent tiles for grouting purposes. This is time consuming and requires relatively skilled labor in order to maintain the tiles at the correct spacing and in the same plane with one another. Devices have been designed to assist in picking up a plurality of objects at one time, said devices usually consisting of vacuum cups placed upon a frame or supporting casing. However, with vacuum cups it is difficult to maintain suction when picking up a plurality of tiles due to the tendency of the device to tilt readily. It is also difficult to get the tiles level when placing them on the wall due to the fact that pressure cannot be applied evenly if at all. The present device overcomes all of these disadvantages by having a planar resilient surface apertured and communicating with a source of vacuum. This enables the device to be placed upon a plurality of tiles, manipulated until the tiles are secured to the surface by vacuum and then enabling the tiles to be placed upon the mastic or cement and pressed into position so that all tiles are immediately levelled and installed whereupon the vacuum is released thus allowing the device to be moved from the tiles.

**[p0003]**

With the use of this device, it is possible to mount some 20 tiles at one time. It is also possible to mount tiles in four by five units stacked one upon the other with the desired spacing therebetween so that the device can be placed over the uppermost layer which can then be removed when the vacuum is actuated thus enabling a tile setter to install tiles rapidly and accurately. Another object of the invention is to provide a device of the character herewithin described in which the vacuum can be released readily and easily by the operator when the tiles are pressed into position upon the wall. A further object of the invention is to provide a device of the character herewithin described which is light in weight, economical in manufacture, and otherwise well suited to the purpose for which it is designed. With the foregoing in view, and such other or further purposes, advantages or novel features as may become apparent from consideration of this disclosure and specification, the present invention consists of, and is hereby claimed to reside in, the inventive concept, which is comprised, embodied, embraced, or included in the method, process, construction, composition, arrangement or combination of parts, or new use of any of the foregoing, of which concept, one or more specific embodiments of same are herein exemplified as illustrative only of such concept, reference being had to the accompanying figures in which:

**[p0004]**

FIG. I is an isometric view of the device. FIG. 2 is a bottom plan view thereof. FIG. 3 is a side elevation of the device showing tiles being held thereby. FIG. 4 is an enlarged end view of one of the caps. FIG. 5 is an enlarged fragmentary inside view of one of the caps showing the hinging action. FIG. 6 is a fragmentary view of the mounting of the vacuum pipe upon the casing. FIG. 7 is an enlarged sectional view of the resilient or lower side of the casing. FIG. 8 is a top plan view of a preferred embodiment of my I device. FIG. 9 is a side elevation thereof. FIG. 10 is an under plan view of FIG. 8. In the drawings like characters of reference indicate corresponding parts in the different figures. Proceeding therefore to describe the invention in detail, reference should first be&#39;made to FIG. 1 which shows a substantially rectangular casing 10, having an upper side 11 and a lower resilient side 12. The casing is provided with perimetrical sidewalls l3 and a metal or plastic diaphragm 14 spans the lower edges of these walls thus forming, together with the upper surface 1 l, a vacuum plenum l5 therebetween.

**[p0005]**

The diaphragm 14 is provided with a plurality of apertures 16 and this diaphragm is covered by a resilient pad 17 of rubber or the like also apertured as at 18 in coincidence with the apertures 16 as clearly shown in FIG. 7. In the present device I have provided four rows of five apertures in spaced and parallel relationship it being understood that one aperture is adapted to pick up one ceramic or plastic tile 19 as will hereinafter be described. A pair of lifting handles 20 are provided upon the upper surface 11 of the casing and a vacuum hose attachment collectively designated 21 is situated adjacent one of these handles This vacuum hose attachment consists of a horizontal tube 22 having a junction tube 23 secured to the underside thereof and in turn being secured to the other side 11 of the casing which is apertured therebelow so that it communicates with the aforementioned vacuum plenum 15. A pair of spring-loaded caps 24 are provided one upon each end of the tube 22 and these caps are hinged by hinge pins 25 to structure 26 secured to each end of the tube 22.

**[p0006]**

A spring 27 surrounds the hinge pin and reacts between the structure 26 and the caps 24 normally maintaining the caps in sealing engagement with the ends of the tube 22. A flexible vacuum hose 28 may be inserted in either end of the tube 22 providing the relevant cap 24 is moved outwardly against pressure of spring 27 and this tube 28 is frictionally engageable within the tube 22. The tube 28 may be connected to a source of vacuum such as a vacuum cleaner or the like. In operation, the tiles I9 are preferably stacked in groups of 20 one upon the other with the desired grout space being left therebetween. The vacuum hose 28 is connected to one end of tube 22 whereupon the device is picked up by the handles 20 and placed upon the outer surfaces the set of tiles 19, it being understood that these tiles are normally lying on a horizontal surface. The resiliency of the pad 17 enables the device to be adjusted so that all 20 tiles are secured to the surface due to the vacuum acting through apertures 16 and 18 from the hose 28 whereupon the device is lifted vertically carrying with it the 20 tiles in the desired spacing one from the other.

**[p0007]**

Reference to FIG. 3 will show that the outer edges 29 of these .tiles overlap the outer edges 30 of the casing thus enabling the operator to place the tiles on the wall with the desired spacing between the outer rows of tiles held by the casing and the tiles already placed in position upon the wall. The operator presses the tiles into the mastic or cement and the planar construction of the surface 17 enables him to align the tiles with the tiles already placed and to apply the necessary pressure so that the tiles are embedded into the mastic or cement which of course is not always exactly flat or planar. As soon as he is satisfied that the tiles are positioned correctly, the thumb of the hand holding the handle 20 adjacent the vacuum tube 21, is engaged with the opposite cap 24 which is moved away from the end of the vacuum tube 22 against pressure of spring 27. This immediately releases the vacuum and enables the operator to move the casing away from the tiles which are left embedded in position upon the wall surface whereupon the operation is repeated.

**[p0008]**

It will therefore be seen that the device can install a plurality of tiles at one time in a planar fashion one with the other and with the desired spacing therebetween. FIGS. 8, 9 and 10 show the preferred embodiment of my invention in which the casing 10A is formed from a relatively thin sheet of material 31. This sheet of material is preferable flexible aluminum sheeting but of course may be any convenient material. The front panel 32 is formed from a relatively thin sheet of plastic which is resilient but hereagain, of course, other material may be used if desired. The two sheets are held together by a perimetrical seal 33 of sponge rubber or the like adhesively secured to the two sheets thus defining therebetween a vacuum manifold (not illustrated). The sheet or panel 32 is provided with a plurality of apertures 34 communicating with the manifold and each aperture is surrounded by a perimetrical seal 35 of sponge rubber material or similar material. The remainder of the construction is the same as before such as handles 20 and vacuum hose attachment collectively designated 21 so that similar reference characters have been given to these components in the preferred embodiment.

**[p0009]**

The operation of the device is similar to that hereinbefore described but the device is relatively light and is flexible enough so that when the tiles are offered to the wall surface, the casing may be distorted slightly so that any imperfections on the wall surface can be compensated thus ensuring proper placement of the tiles within the mastic on the wall. I have found that this flexibility of the casing A assists materially in the speed with which tiles can be applied as it is relatively rare to find plaster walls for example which are completely flat and a rigid casing makes it difficult to adhere the tiles to the wall prior to releasing the vacuum. Various modifications can be made within the scope of the inventive concept which is herein disclosed and/or claimed. 1. A tile holding and placement device comprising in combination a substantially rectangular casing, a resilient apertured facing on one side of said casing, a vacuum hose attachment on the other side of said casing and means to release the vacuum at said apertures, said vacuum hose attachment including a double-ended tube connected with the interior of said casing, a first spring-loaded cap on one end of said tube, said tube adapted to receive a vacuum hose when said first springdoaded cap is open, said means to release said vacuum including a second spring-loaded cap on the other end of said tube, said second spring-loaded cap being manipulatable to release said vacuum and being normally biassed to close off said other end.

**[p0010]**

2. The device according to claim 1, which includes a pair of lifting handles, one adjacent each end of said other side of said casing. 3. The device according to claim 2, in which said casing includes a relatively thin flexible rear panel, a relatively thin flexible apertured front panel, a perimetrical resilient seal between said panels, and resilient seals around each of said apertures adapted to engage and seal against the surface of the tiles being picked up thereby applying suction to said tiles. 4. The device according to claim 1, in which said casing includes a relatively thin flexible rear panel, a relatively thin flexible apertured front panel, a perimetrical resilient seal between said panels, and resilient seals around each of said apertures adapted to engage and seal against the surface of the tiles being picked up thereby applying suction to said tiles.

## Figure captions

- **Figure 2:** FIG. 2 is a bottom plan view thereof.
- **Figure 3:** FIG. 3 is a side elevation of the device showing tiles being held thereby.
- **Figure 4:** FIG. 4 is an enlarged end view of one of the caps.
- **Figure 5:** FIG. 5 is an enlarged fragmentary inside view of one of the caps showing the hinging action.
- **Figure 6:** FIG. 6 is a fragmentary view of the mounting of the vacuum pipe upon the casing.
- **Figure 7:** FIG. 7 is an enlarged sectional view of the resilient or lower side of the casing.
- **Figure 8:** FIG. 8 is a top plan view of a preferred embodiment of my I device.
- **Figure 9:** FIG. 9 is a side elevation thereof.
- **Figure 10:** FIG. 10 is an under plan view of FIG. 8.
- **Figure 7:** The diaphragm 14 is provided with a plurality of apertures 16 and this diaphragm is covered by a resilient pad 17 of rubber or the like also apertured as at 18 in coincidence with the apertures 16 as clearly shown in FIG. 7.
- **Figure 3:** Reference to FIG. 3 will show that the outer edges 29 of these .tiles overlap the outer edges 30 of the casing thus enabling the operator to place the tiles on the wall with the desired spacing between the outer rows of tiles held by the casing and the tiles already placed in position upon the wall.
- **Figure 8:** FIGS. 8, 9 and 10 show the preferred embodiment of my invention in which the casing 10A is formed from a relatively thin sheet of material 31. This sheet of material is preferable flexible aluminum sheeting but of course may be any convenient material.

## Classifications

- B66C1/025
- B66C1/025
- B66C1/02
- B66C1/0281
- B66C1/0281

## Cited patent documents

- [US-2578220-A](https://patents.google.com/patent/US2578220A/en) — SEA
- [US-2776163-A](https://patents.google.com/patent/US2776163A/en) — SEA
- [US-2798757-A](https://patents.google.com/patent/US2798757A/en) — SEA
- [US-3061352-A](https://patents.google.com/patent/US3061352A/en) — SEA

---

Generated by IPtorch. Verify legal conclusions against the official publication.
