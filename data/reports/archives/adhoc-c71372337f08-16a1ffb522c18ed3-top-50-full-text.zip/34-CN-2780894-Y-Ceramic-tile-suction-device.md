# 34. Ceramic tile suction device

- **Archive rank:** 34 of 50
- **Publication:** [CN-2780894-Y](https://patents.google.com/patent/CN2780894Y/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/036762096/publication/CN2780894Y?q=pn%3DCN2780894Y)
- **Publication date:** 2006-05-17
- **Filing date:** 2005-04-20
- **Earliest priority:** 2005-04-20
- **Family:** 36762096
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus

## Parties

- **Applicant / assignee:** QIN YONGWU

## Abstract

The utility model relates to a ceramic tile suction device. Six main rod connecting sleeves are sheathed on a main rod, and six transverse rods are concatenated in the apertures of the connecting sleeves; transverse rod connecting sleeves are sheathed on both ends of each transverse rod, and a straight rod air tube on which a balancing spring is arranged is vertically inserted; the lower end of the straight rod air tube is tightly sheathed with a rubber sucking disc, and the upper end is tightly sheathed with a soft air tube. The upper middle of the soft air tube is provided with a soft air sac which is communicated with a plurality of rubber sucking discs below a frame by the soft air tube. The soft air sac is pressed to cause a plurality of rubber sucking discs to simultaneously suck or loose a ceramic tile plate, so that the ceramic tile suction device can substitute holding the ceramic tile plate by hands. The utility model has convenient operation, and can increase the quality of sticking the ceramic tile. When the ceramic tile is stuck on the surface of large buildings by the ceramic tile suction device, the work efficiency can be increased by more than 10 times.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-2780894-Y/000.png)

![Sketch 1 for CN-2780894-Y](https://nimo.iptorch.com/refdrawing/CN-2780894-Y/000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-2780894-Y/001.png)

![Sketch 2 for CN-2780894-Y](https://nimo.iptorch.com/refdrawing/CN-2780894-Y/001.png)

## Claims

### Claim 1 (independent)

Claims (2)

### Claim 2 (independent)

1, a kind of ceramic tile article fastening device, six mobile jibs of cover join to cover on mobile jib, string advances six roots of sensation cross bar in the coupling sleeve aperture, every cross bar two ends put a cross bar coupling sleeve, and vertically inject a straight-bar tracheae, be provided with balancing spring on the straight-bar tracheae, soft tracheae is tightly overlapped in the upper end, it is characterized in that: a soft air bag is installed in middle part, soft tracheae top.

### Claim 3

2, ceramic tile article fastening device according to claim 1 is characterized in that: soft air bag is connected some rubber suction cups that are contained in straight-bar tracheae below by soft tracheae.

## Full description

**[p0001]**

Description The ceramic tile article fastening device Affiliated technical field The utility model belongs to the building trade dress and pastes a kind of ceramic tile article fastening device of engraving brick. Background technology At present, the workman adopts manual one-step operation when building surface dress tile fixing, spended time, and inefficiency owing to be that monolithic is adorned subsides successively, be not easy to install neatly, thereby influence work quality, has unsafe factor. Summary of the invention The purpose of this utility model provides a kind of ceramic tile article fastening device that tile fixing is used of adorning, and uses this ceramic tile article fastening device can increase work efficiency and work quality. The purpose of this utility model is to realize like this, a kind of ceramic tile article fastening device, six mobile jibs of cover join to cover on mobile jib, string advances six roots of sensation cross bar in the coupling sleeve aperture, every cross bar two ends put a cross bar coupling sleeve, and vertically inject a straight-bar tracheae, on the straight-bar tracheae, be provided with balancing spring, rubber suction cups of tight cover in straight-bar tracheae lower end, the soft tracheae of the tight cover in upper end, a soft air bag is installed in middle part, soft tracheae top, soft air bag is connected several rubber suction cups that are contained in straight-bar tracheae below by soft tracheae, be used to restrain soft air bag and just can make some rubber suction cups hold or decontrol tile simultaneously, ju

**[p0001]**

st reach this ceramic tile article fastening device and replace hand to take the function of tile.

**[p0002]**

The utility model small size workplace when operation, load onto small-sized soft air bag after removable and use as the single sucking disc, the single sucking disc ceramic tile inhale paste comprise that soft gas is assisted, straight-bar tracheae, rubber suction cups. The utility model has been owing to replaced manual operations, therefore improves workman's suction degree of working, and improved workman's processing safety, and is easy to use. Description of drawings Fig. 1 is a front view of the present utility model: Fig. 2 is a vertical view of the present utility model. The specific embodiment Among Fig. 1, going up six mobile jibs of cover at mobile jib (7) joins to cover (8), string advances six roots of sensation cross bar (15) in the coupling sleeve aperture, it is fixing to tighten holding screw (6) behind the adjustment desired spacing, every cross bar two ends put a cross bar coupling sleeve (2), and vertically inject a straight-bar tracheae (1), on the straight-bar tracheae, pack into balancing spring (4) then with fixedly collar of holding screw (9), the tight cover rubber suction cups (3) in straight-bar tracheae lower end, the tight soft tracheae of cover in upper end (16) as shown in Figure 2, dress air bag seat (5) in the middle of mobile jib, air bag seat (5) top dress shunting tracheae (10), soft air bag (12) is tightly overlapped on shunting tracheae (10) top, dress energizing spring (11) in the soft air bag (12), the tight cover of shunting tracheae (10) two side air inlet/outlets soft tracheae (16), tight respectively cover four the tracheae four

**[p0002]**

-ways (14) of soft air bag (12), 12 straight tube gas bars (1) are connected in two tracheae threeways (13), 12 rubber suction cups and soft air bag are linked up, during operation when a soft air bag can be the people for after restraining distortion, during recovery 12 rubber suction cups are formed partial vacuum and suck ceramic tile, restrain air bag behind workman's end of operation once more, make to charge into gas releasing suction in the sucker, can take off this device.

---

Generated by IPtorch. Verify legal conclusions against the official publication.
