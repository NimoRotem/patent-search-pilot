# 43. A kind of building tile spreader

- **Archive rank:** 43 of 50
- **Publication:** [CN-110273534-A](https://patents.google.com/patent/CN110273534A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/067957636/publication/CN110273534A?q=pn%3DCN110273534A)
- **Publication date:** 2019-09-24
- **Filing date:** 2018-03-14
- **Earliest priority:** 2018-03-14
- **Family:** 67957636
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** HUBEI QIANAO CONSTR ENG CO LTD

## Abstract

A kind of building tile spreader, shell including being connected with lever, the first cavity is equipped in the shell, vibrating motor is fixed in first cavity, the vibrating motor connects vibrating mass, the vibrating mass lower end surface is symmetrically arranged with four cylindrical blocks, telescopic rod is connected on the cambered surface side wall of the cylindrical block, the telescopic rod is equipped with stop screw, the telescopic rod is connected with fixed block far from one end of cylindrical block, the lower end of fixing block face is equipped with groove, the lower end of fixing block face is fixedly connected with sucker, threaded rod equipped with the setting of two vertical traversing plates in second cavity, equal fixing sleeve is equipped with driven gear on two threaded rods, two driven gears engage knob of the fixing axle described in driving gear outside the connection of upper end of fixing block wall.Structure of the invention is rationally simple, absorption ceramic tile that can be stronger in tiling process, while being adapted to various sizes of ceramic tile.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-110273534-A/pdf000.png)

![Sketch 1 for CN-110273534-A](https://nimo.iptorch.com/refdrawing/CN-110273534-A/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-110273534-A/pdf001.png)

![Sketch 2 for CN-110273534-A](https://nimo.iptorch.com/refdrawing/CN-110273534-A/pdf001.png)

## Claims

### Claim 1

1. a kind of building tile spreader, the shell (2) including being connected with lever (1), it is characterised in that: the shell (2)
It is inside equipped with the first cavity (3), is fixed with vibrating motor (4) in the first cavity (3), vibrating motor (4) connects vibrating mass (5), shell
Body (2) lower end wall is equipped with the opening of corresponding vibrating mass (5), and vibrating mass (5) lower end is through opening to shell (2) outside, vibrating mass
(5) lower end surface is symmetrically arranged with four cylindrical blocks (6), and cylindrical block (6) connects vibrating mass (5) lower end surface by turntable (20).

### Claim 2

2. building tile spreader according to claim 1, it is characterised in that: the cambered surface side of the cylindrical block (6)
It being connected on wall telescopic rod (7), telescopic rod (7) is equipped with stop screw (25), and the one of telescopic rod (7) separate cylindrical block (6)
End is connected with fixed block (8), and fixed block (8) lower end surface is equipped with groove (9), and fixed block (8) lower end surface is fixedly connected with sucker
(10).

### Claim 3

3. building tile spreader according to claim 2, it is characterised in that: the sucker (10) is equipped with and groove
(9) connection opening, groove (9) is interior to be equipped with cylindrical skid member (11), is equipped with the second cavity (12) in fixed block (8), cylindrical
Sliding part (11) is fixedly connected by fixed link (13) with the transverse slat (14) being arranged in the second cavity (12), the second cavity (12)
It is inside equipped with the threaded rod (15) of two vertical traversing plates (14) setting, two threaded rod (15) upper and lower sides are rotatablely connected the second sky respectively
Chamber (12) end wall up and down, sets that there are two the threaded hole being cooperatively connected with two threaded rods (15), two threaded rods on transverse slat (14)
(15) equal fixing sleeve is equipped with driven gear (16) on, and two driven gears (16) engage driving gear (17), driving gear
(17) it is connected and fixed axis (18), knob (19) of the fixing axle (18) outside the connection of fixed block (8) upper end wall.

### Claim 4

4. a kind of building tile spreader according to claim 3, which is characterized in that the fixing axle (18) passes through rolling
Pearl bearing (21) and the roof of the second cavity (12) are rotatablely connected.

### Claim 5

5. a kind of building tile spreader according to claim 3, which is characterized in that the cylindrical skid member (11)
Side wall is equipped with annular groove, is equipped with rubber seal (22) in annular groove.

### Claim 6

6. a kind of building tile spreader according to claim 2 or 3, which is characterized in that sucker (10) upper end
It is fixed with ring limit block (23), ring limit block (23) curved wall is equipped with screw thread, and fixed block (8) bottom end is equipped with matching
The circular groove of ring limit block (23), and circular groove inner wall is equipped with corresponding screw thread.

### Claim 7

7. a kind of building tile spreader according to claim 1, which is characterized in that the shell (2) is far from lever
(1) side is equipped with auxiliary handle (24), and auxiliary handle (24) is equipped with Anti-slip cover.

## Full description

FIXED CONSTRUCTIONSBUILDINGFINISHING WORK ON BUILDINGS, e.g. STAIRS, FLOORSImplements for finishing work on buildingsImplements for finishing work on buildings for laying flooringImplements for finishing work on buildings for laying flooring of single elements, e.g. flooring cramps ; flexible webs

Description

A kind of building tile spreader

Technical field

The present invention relates to technical field of buildings more particularly to a kind of building tile spreaders.

Background technique

For many years, the laying of the ceramic tile of building floor and floor is all by manually carrying out, and hand lay-up needs advanced

Row unwrapping wire, then one piece one piece of alignment, draw close and be compacted, large labor intensity, construction efficiency is low, to the technical requirements of operator

It is higher.It needing ground to flatten when tradition is laid with ceramic tile, also handy hammer strikes tightly after spreading ceramic tile, and it is very arduous, and it is laid with effect

Rate is lower.It is laid with process in order to simplify ceramic tile, mitigates the labor intensity of operator, is occurred at present dedicated for ceramic tile laying

Equipment.But existing spreader often only leans on a sucker suction ceramic tile, it is insecure to be also easy to produce accident, while ceramic tile size is advised

Lattice are different, and a sucker often is difficult to adsorb for excessive ceramic tile.

Summary of the invention

A kind of building tile spreader proposed by the present invention can solve and ground is needed to flatten when tradition is laid with ceramic tile,

Also handy hammer strikes tightly after spreading ceramic tile, very arduous, and is laid with the lower technical problem of efficiency.

To achieve the goals above, present invention employs following technical solutions:

A kind of building tile spreader, the shell including being connected with lever are equipped with the first cavity in the shell, and described first

Vibrating motor is fixed in cavity, the vibrating motor connects vibrating mass, and the shell lower end wall is equipped with opening for corresponding vibrating mass

Mouthful, through opening to hull outside, the vibrating mass lower end surface is symmetrically arranged with four cylindrical blocks, described for the vibrating mass lower end

Cylindrical block connects vibrating mass lower end surface by turntable, is connected with telescopic rod on the cambered surface side wall of the cylindrical block, described to stretch

Contracting bar is equipped with stop screw, and the telescopic rod is connected with fixed block, the lower end of fixing block face far from one end of cylindrical block

Equipped with groove, the lower end of fixing block face is fixedly connected with sucker, and the sucker is equipped with and is connected to opening, the groove with groove

It is interior to be equipped with cylindrical skid member, the second cavity is equipped in the fixed block, the cylindrical skid member passes through fixed link and setting

Transverse slat in the second cavity is fixedly connected, the threaded rod equipped with the setting of two vertical traversing plates in second cavity, two institutes

State threaded rod upper and lower side and be rotatablely connected the second cavity end wall up and down respectively, set on the transverse slat there are two with two shafts

The threaded hole of connection, fixing sleeve is equipped with driven gear on two threaded rods, and two driven gears engage actively

Gear, the driving gear are connected and fixed axis, knob of the fixing axle outside the connection of upper end of fixing block wall.

Preferably, the fixing axle is rotatablely connected by the roof of ball bearing and the second cavity.

Preferably, the cylindrical skid member side wall is equipped with annular groove, is equipped with rubber seal in the annular groove

Circle.

Preferably, the sucker upper end is fixed with ring limit block, and the ring limit block curved wall is equipped with spiral shell

Line, the fixed block bottom end is equipped with the circular groove of matching ring limit block, and circular groove inner wall is equipped with corresponding screw thread.

Preferably, the shell is equipped with auxiliary handle far from the side of lever, and the auxiliary handle is equipped with Anti-slip cover.

Compared with prior art, the invention has the benefit that by the way that groove, while fixed block is arranged in lower end of fixing block

Lower end surface is fixedly connected with sucker, and sucker, which is equipped with, be connected to opening with groove, and groove is interior equipped with cylindrical skid member, in fixed block

Equipped with the second cavity, cylindrical skid member is fixedly connected by fixed link with the transverse slat being arranged in the second cavity, the second cavity

It is interior to be equipped with fixing axle, knob of the fixing axle outside the connection of upper end of fixing block wall, fixed axis connection driving gear, driving gear

Two driven gears are driven, two driven gears drive two threaded rods, and two threaded rod band motion plate vertical directions move, real

Existing knob drives the movement of cylindrical skid member vertical direction, so that force of suction cup is stronger, absorption ceramic tile effect is more preferableï¼Fixed block is logical

Telescopic rod connecting cylinder shape block is crossed, cylindrical block connects vibrating mass lower end surface by turntable, and vibrating mass connects in the first cavity

Vibrating motor realizes the spacing changed between fixed block and shell, while adjusting the angle between adjacent expansion bar, is adapted to

The ceramic tile of different size specification.

Detailed description of the invention

Fig. 1 is a kind of structural schematic diagram of building tile spreader proposed by the present inventionï¼

Fig. 2 is the structural schematic diagram in Fig. 1 at A.

Specific embodiment

Such as Fig. 1-2, a kind of building tile spreader, the shell 2 including being connected with lever 1, shell 2 is far from lever 1

Side is equipped with auxiliary handle 24, and auxiliary handle 24 is equipped with Anti-slip cover, easy to hold to use machine, and it is empty to be equipped with first in shell 2

Chamber 3 is fixed with vibrating motor 4 in first cavity 3, realizes the effect of vibration, and vibrating motor 4 connects vibrating mass 5,2 lower end of shell

Wall is equipped with the opening of corresponding vibrating mass 5, and outside opening to shell 2,5 lower end surface of vibrating mass is symmetrically arranged with 5 lower end of vibrating mass

Four cylindrical blocks 6, cylindrical block 6 connect 5 lower end surface of vibrating mass by turntable 20, facilitate and adjust between different telescopic rods 7

Angle is connected with telescopic rod 7 on the cambered surface side wall of cylindrical block 6, and telescopic rod 7 is equipped with stop screw 25, and adjusting is facilitated to fix

Spacing between block 8 and shell 2.

Telescopic rod 7 is connected with fixed block 8 far from one end of cylindrical block 6, and 8 lower end surface of fixed block is equipped with groove 9, fixed block

8 lower end surfaces are fixedly connected with sucker 10, and 10 upper end of sucker is fixed with ring limit block 23, on 23 curved wall of ring limit block

Equipped with screw thread, 8 bottom end of fixed block is equipped with the circular groove of matching ring limit block 23, and circular groove inner wall is equipped with corresponding spiral shell

Line, ring limit block 23 are hard material, facilitate fixed replacement sucker 10, and sucker 10, which is equipped with, is connected to opening, groove with groove 9

Cylindrical skid member 11 is equipped in 9,11 side wall of cylindrical skid member is equipped with annular groove, is equipped with rubber seal in annular groove

Circle 22 prevents gas leakage, the second cavity 12 is equipped in fixed block 8, cylindrical skid member 11 is by fixed link 13 and is arranged second

Transverse slat 14 in cavity 12 is fixedly connected, the threaded rod 15 equipped with the setting of two vertical traversing plates 14 in the second cavity 12, two spiral shells

15 upper and lower side of rasp bar is rotatablely connected about 12 end wall of the second cavity respectively, sets that there are two cooperate with two threaded rods 15 on transverse slat 14

The threaded hole of connection, fixing sleeve is equipped with driven gear 16 on two threaded rods 15, and two driven gears 16 engage driving tooth

Wheel 17, driving gear 17 are connected and fixed axis 18, and fixing axle 18 is rotatablely connected by the roof of ball bearing 21 and the second cavity 12,

Knob 19 of the fixing axle 18 outside the connection of 8 upper end wall of fixed block, can adjust the adsorption strength of sucker 10 by knob 19.

In the present invention, by the way that groove 9 is arranged in 8 lower end of fixed block, while 8 lower end surface of fixed block is fixedly connected with sucker

10, sucker 10, which is equipped with, is connected to opening with groove 9, and cylindrical skid member 11 is equipped in groove 9, and it is empty to be equipped with second in fixed block 8

Chamber 12, cylindrical skid member 11 are fixedly connected by fixed link 13 with the transverse slat 14 being arranged in the second cavity 12, the second cavity

Fixing axle 18, knob 19 of the fixing axle 18 outside the connection of 8 upper end wall of fixed block are equipped in 12, fixing axle 18 connects driving tooth

Wheel 17, driving gear 17 drive two driven gears 16, and two driven gears 16 drive two threaded rods 15, two threaded rods 15

Band 14 vertical direction of motion plate moves, and realizes that knob 19 drives the movement of 11 vertical direction of cylindrical skid memberï¼Fixed block 8 is by stretching

7 connecting cylinder shape block 6 of contracting bar, cylindrical block 6 connect 5 lower end surface of vibrating mass by turntable 20, and vibrating mass 5 connects the first cavity 3

Interior vibrating motor 4 realizes the spacing changed between fixed block 8 and shell 2, while adjusting the angle between adjacent expansion bar 7.

## Classifications

- E04F21/22

---

Generated by IPtorch. Verify legal conclusions against the official publication.
