# 42. Equipment for lifting and transporting loads by vacuum - has base plate with stiffening ribs and with suction connected to vacuum producer, and has separate vacuum container

- **Archive rank:** 42 of 50
- **Publication:** [DE-4229208-A1](https://patents.google.com/patent/DE4229208A1/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/006467004/publication/DE4229208A1?q=pn%3DDE4229208A1)
- **Publication date:** 1994-03-03
- **Filing date:** 1992-09-02
- **Earliest priority:** 1992-09-02
- **Family:** 6467004
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, patent detail recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** SCHMALZ J GMBH
- **Inventors:** SCHMALZ KURT DR; SCHMALZ WOLFGANG

## Abstract

The base plate is formed as a suction plate (14) and is connected to a vacuum producer. The suction plate (14) has a separate vacuum producer and in partic. a vacuum container (16). The suction plate (14) is downwardly open and is equipped with stiffening ribs and braces. The plate has an all-round sealing edge (15) of rubber-elastic material on the suction surface. On the edge is fixed a plasticine-type adhesive mass. The suction plate (14) is connected to an alarm device which functions when a predetermined vacuum is exceeded. USE/ADVANTAGE - The equipment is essentially simpler to transport from one point to another.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/DE-4229208-A1/ops000.png)

![Sketch 1 for DE-4229208-A1](https://nimo.iptorch.com/refdrawing/DE-4229208-A1/ops000.png)

## Claims

### Claim 1 (independent)

Vorrichtung zum Anheben und Transportieren von Lasten mittels Vakuum mit einem Vakuumerzeuger (3), einem sich verkürzbaren Hubschlauch (10) und einem den anzuhebenden Gegenstand ergreifenden, über den Hubschlauch (10) mit dem Vakuumerzeuger (3) verbundenen Saugkopf (12), wobei die Vorrichtung mobil ausgebildet ist und eine Grundplatte (1) aufweist, dadurch gekennzeichnet, daß die Grundplatte als Saugplatte (14) ausgebildet ist und mit einem Vakuumerzeuger in Verbindung steht.1. Device for lifting and transporting loads by means of vacuum to a vacuum generator (3), a is retractable lift tube (10) and an the object to be lifted taken, via the lifting tube (10) to the vacuum generator (3) connected to the suction head (12), the device being mobile and having a base plate ( 1 ), characterized in that the base plate is designed as a suction plate ( 14 ) and is connected to a vacuum generator.

### Claim 2

Vorrichtung nach Anspruch 1, dadurch gekennzeichnet, daß die Saugplatte (14) einen separaten Vakuumerzeuger und insbesondere einen Unterdruckbehälter (16) besitzt.2. Device according to claim 1, characterized in that the suction plate ( 14 ) has a separate vacuum generator and in particular a vacuum container ( 16 ).

### Claim 3

Vorrichtung nach Anspruch 1 oder 2, dadurch gekennzeichnet, daß die Saugplatte (14) nach unten offen ausgebildet ist.3. Apparatus according to claim 1 or 2, characterized in that the suction plate ( 14 ) is open at the bottom.

### Claim 4

Vorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, daß die Saugplatte (14) mit Versteifungsrippen und Verstrebungen ausgestattet ist.4. Device according to one of the preceding claims, characterized in that the suction plate ( 14 ) is equipped with stiffening ribs and struts.

### Claim 5

Vorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, daß die Saugplatte (14) einen auf der anzusaugenden Oberfläche aufliegenden, umlaufenden, dichtenden Rand (15) und ggf. weitere im Saugbereich vorgesehene Abstützungen aufweist. Device according to one of the preceding claims, characterized in that the suction plate ( 14 ) has a circumferential, sealing edge ( 15 ) lying on the surface to be suctioned and, if appropriate, further supports provided in the suction area.

### Claim 6

Vorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, daß die Saugplatte (14) einen elastischen, z. B. gummielastischen umlaufenden Rand (15) aufweist.6. Device according to one of the preceding claims, characterized in that the suction plate ( 14 ) has an elastic, for. B. has rubber-elastic peripheral edge ( 15 ).

### Claim 7

Vorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, daß die Saugplatte mit einem Rand (15) versehen ist, an dem eine knetartige Haftmasse befestigbar ist.7. Device according to one of the preceding claims, characterized in that the suction plate is provided with an edge ( 15 ) on which a kneading adhesive can be attached.

### Claim 8

Vorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, daß die Saugplatte (14) mit einer das Überschreiten eines vorbestimmten Unterdrucks registrierenden Alarmeinrichtung verbunden ist.8. Device according to one of the preceding claims, characterized in that the suction plate ( 14 ) is connected to an alarm device registering the exceeding of a predetermined negative pressure.

### Claim 9

Vorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, daß die Saugplatte (14) nach Art eines Schubkarrens mit Handgriffen (17) und einer oder mehreren Rollen (18) versehen ist, über die sie verfahrbar ist.9. Device according to one of the preceding claims, characterized in that the suction plate ( 14 ) is provided in the manner of a wheelbarrow with handles ( 17 ) and one or more rollers ( 18 ), over which it can be moved.

### Claim 10

Vorrichtung nach Anspruch 9, dadurch gekennzeichnet, daß die Handgriffe (17) und/oder die Rollen (18) abnehmbar an der Saugplatte (14) befestigt sind. The device according to claim 9, characterized in that the handles ( 17 ) and / or the rollers ( 18 ) are removably attached to the suction plate ( 14 ).

### Claim 11

Vorrichtung nach einem der Ansprüche 1-8, dadurch gekennzeichnet, daß die Saugplatte (14) mit Einfuhröffnungen z. B. für die Gabel eines Gabelstaplers versehen ist.11. Device according to one of claims 1-8, characterized in that the suction plate ( 14 ) with inlet openings z. B. is provided for the fork of a forklift.

### Claim 12

Vorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, daß die Saugplatte (14) auf dem Boden, an Wänden und/oder an der Decke mittels Unterdruck ansaugbar und festlegbar ist.12. Device according to one of the preceding claims, characterized in that the suction plate ( 14 ) on the floor, on walls and / or on the ceiling can be sucked and fixed by means of negative pressure.

### Claim 13

Vorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, daß sie wenigstens teilweise aus Aluminium besteht.13. Device according to one of the preceding claims, characterized in that they are at least partially Aluminum.

### Claim 14

Vorrichtung nach einem der vorhergehenden Ansprüche, dadurch gekennzeichnet, daß die Saugplatte (14) zusätzliche, insbesondere den Rand (15) seitlich überragende Klemmeinrichtungen aufweist, über die z. B. mit Mauerankern oder dgl. verbindbar ist.14. Device according to one of the preceding claims, characterized in that the suction plate ( 14 ) has additional, in particular the edge ( 15 ) laterally projecting clamping devices via which, for. B. is connectable with wall anchors or the like.

## Full description

PERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansSingle lifting units; Only one suction cupPERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articlesLoad-engaging elements or devices attached to lifting or lowering gear of cranes or adapted for connection therewith for transmitting lifting forces to articles or groups of articles by suction meansRectangular or square shapePERFORMING OPERATIONS; TRANSPORTINGHOISTING; LIFTING; HAULINGCRANES; LOAD-ENGAGING ELEMENTS OR DEVICES FOR CRANES, CAPSTANS, WINCHES, OR TACKLESCranes comprising essentially a beam, boom, or triangular structure acting as a cantilever and mounted for translatory of swinging movements in vertical or horizontal planes or a combination of such movements, e.g. jib-cranes, derricks, tower cranesCranes comprising essentially a beam, boom, or triangular structure acting as a cantilever and mounted for translatory of swinging movements in vertical or horizontal planes or a combination of such movements, e.g. jib-cranes, derricks, tower cranes with non-adjustable and non-inclinable jibs mounted solely for slewing movementsPivot axis separated from column axis

Description

Translated from German

Die Erfindung betrifft eine Vorrichtung zum Anheben und

Transportieren von Lasten mittels Vakuum mit einem

Vakuumerzeuger, einem sich verkÃ¼rzbaren Hubschlauch und einem

den anzuhebenden Gegenstand ergreifenden, Ã¼ber den Hubschlauch

mit dem Vakuumerzeuger verbundenen Saugkopf, wobei die

Vorrichtung mobil ausgebildet ist und eine Grundplatte

aufweist.The invention relates to a device for lifting and

Transporting loads using a vacuum

Vacuum generator, a shortenable lifting hose and one

grasping the object to be lifted over the lifting hose

connected to the vacuum generator suction head, the

Device is mobile and a base plate

having.

Vakuumhandhabungsvorrichtungen sind in einer Vielzahl bekannt.

In der Regel sind diese stationÃ¤r angeordnet, so daÃ z. B. in

einer Montagehalle die zu handhabenden GegenstÃ¤nde auf

einfache Weise manipuliert werden kÃ¶nnen. Hierzu weist die

Vorrichtung einen Saugkopf auf, der auf den zu manipulierenden

Gegenstand aufgesetzt wird. Dieser Saugkopf ist Ã¼ber einen

Hubschlauch mit einem Vakuumerzeuger verbunden, welcher im

Hubschlauch und im Saugkopf einen Unterdruck erzeugt. Dabei

wird der Hubschlauch verkÃ¼rzt, so daÃ der zu manipulierende

Gegenstand Ã¼ber den Saugkopf angesaugt und angehoben wird.

Durch BelÃ¼ftung des Saugkopfes wird der Unterdruck im

Hubschlauch vermindert, so daÃ sich dieser wieder verlÃ¤ngert

und der Gegenstand an dem vorgesehenen Ort abgesetzt werden

kann. Es hat sich gezeigt, daÃ diese stationÃ¤ren Anlagen zwar

auÃerordentlich hilfreich beim Bewegen von GegenstÃ¤nden sind,

jedoch ein wachsendes BedÃ¼rfnis fÃ¼r mobile Anlagen besteht.Vacuum handling devices are known in a variety.

As a rule, these are arranged stationary, so that, for. B. in

an assembly hall on the objects to be handled

can be easily manipulated. The

Â Device on a suction head that is to be manipulated

Object is placed. This suction head is over one

Hubschlauch connected to a vacuum generator, which in

Vacuum hose and vacuum created in the suction head. Here

the lifting hose is shortened so that the one to be manipulated

Object is sucked in and raised via the suction head.

By venting the suction head, the vacuum in the

The lift hose is reduced so that it lengthens again

and the item is dropped off at the intended location

can. It has been shown that these stationary systems

are extremely helpful when moving objects,

however, there is a growing need for mobile systems.

Eine mobile Vorrichtung wurde dadurch geschaffen, daÃ der

Hubschlauch mit einer AufhÃ¤ngeeinrichtung versehen worden ist,

so daÃ dieser an einem mobilen Kran einhÃ¤ngbar ist. Ãber den

Kran kann nun die gesamte Hubeinrichtung verschwenkt werden,

so daÃ der Aktionsradius, abhÃ¤ngig vom Ausleger des Krans,

gegenÃ¼ber stationÃ¤ren GerÃ¤ten wesentlich vergrÃ¶Ãert ist.

Ferner sind an einem Ausleger und einer KransÃ¤ule befestigte

HubschlÃ¤uche bekannt, wobei die KransÃ¤ule mit Ausleger Ã¼ber

RÃ¤der verfahrbar ist. Auch hier ist eine groÃe NobilitÃ¤t

gegeben, da neben einer Verschwenkung auch ein Verfahren

mÃ¶glich ist. Es hat sich jedoch gezeigt, daÃ der die RÃ¤der

aufweisende Unterbau relativ schwer ausgebildet sein muÃ, so

daÃ dieser das Gegengewicht fÃ¼r den Kran und die anzuhebende

Last aufbringen kann. Unter UmstÃ¤nden muÃ das verfahrbare

Gestell sogar noch mit Zusatzgewichten versehen werden. Werden

derartige Vorrichtungen z. B. auf dem Bau verwendet, dann

kÃ¶nnen sie in der Regel nur an Orten eingesetzt werden, die

relativ einfach zugÃ¤nglich und insbesondere befahrbar sind, da

die Vorrichtung aufgrund des hohen Eigengewichts entweder nur

mit einem Gabelstapler oder einem Kran an den jeweiligen

Einsatzort, z. B. in ein Stockwerk eines zu errichtenden

GebÃ¤udes, gebracht werden kann.A mobile device was created in that the

Lifting hose has been provided with a suspension device,

so that it can be attached to a mobile crane. On the

Crane, the entire lifting device can now be swiveled,

so that the radius of action, depending on the boom of the crane,

is significantly enlarged compared to stationary devices.

Furthermore, are attached to a boom and a crane column

Lifting hoses known, the crane column with boom over

Wheels can be moved. There is great mobility here too

given, since in addition to a pivoting also a procedure

is possible. However, it has been shown that the wheels

having substructure must be relatively heavy, so

that this is the counterweight for the crane and the one to be lifted

Can apply load. Under certain circumstances, the movable

Â The frame can even be provided with additional weights. Will

such devices such. B. used in construction, then

they can usually only be used in locations that

are relatively easily accessible and in particular passable because

the device due to the high weight either only

with a forklift or a crane at the respective

Place of use, e.g. B. in a floor of one to be erected

Building, can be brought.

Der Erfindung liegt daher die Aufgabe zugrunde, eine

Vorrichtung der eingangs genannten Art derart weiterzubilden,

daÃ sie wesentlich einfacher vom einen zum anderen Einsatzort

transportierbar ist.The invention is therefore based on the object

To further develop the device of the type mentioned at the beginning,

that it is much easier to get from one location to another

is transportable.

Diese Aufgabe wird erfindungsgemÃ¤Ã dadurch gelÃ¶st, daÃ die

Grundplatte als Saugplatte ausgebildet ist und mit einem

Vakuumerzeuger in Verbindung steht.This object is achieved in that the

Base plate is designed as a suction plate and with a

Vacuum generator is connected.

Die Grundplatte, auf der z. B. die KransÃ¤ule und der Ausleger

mit dem Hubschlauch und dem Saugkopf befestigt ist und die den

Vakuumerzeuger und die elektrische Einrichtung trÃ¤gt, ist

erfindungsgemÃ¤Ã als Saugplatte ausgebildet und kann sich auf

ebenen FlÃ¤chen festsaugen. Auf diese Weise kann die gesamte

Vorrichtung mit einem relativ geringen Eigengewicht

hergestellt werden, da das Gegengewicht fÃ¼r den Kran und den

anzuhebenden Gegenstand durch das Ansaugen der Saugplatte

aufgebracht wird. Selbst die Saugplatte kann relativ leicht

ausgestaltet sein, es muÃ lediglich darauf geachtet werden,

daÃ sie eine genÃ¼gende Steifigkeit besitzt. Die Vorrichtung

kann aufgrund ihres relativ geringen Eigengewichts problemlos

und innerhalb kÃ¼rzester Zeit an andere Einsatzorte verlegt

werden. Die Verwendung im StraÃenbau sowie Hoch- und Tiefbau

ist bevorzugt, da dort leichte mobile Einheiten gegenÃ¼ber

Vorrichtungen mit einem hohen Eigengewicht ein weitaus

grÃ¶Ãeres Einsatzfeld besitzen.The base plate on the z. B. the crane column and the boom

is attached with the lifting hose and the suction head and the

Vacuum generator and the electrical device is

designed according to the invention as a suction plate and can

Vacuum flat surfaces. This way the whole

Device with a relatively low weight

be made because the counterweight for the crane and the

object to be lifted by suction of the suction plate

is applied. Even the suction plate can be relatively light

Â be designed, you just have to take care

that it has sufficient rigidity. The device

can easily because of its relatively low weight

and relocated to other locations within the shortest possible time

become. The use in road construction as well as civil engineering

is preferred because there are light mobile units over there

Devices with a high dead weight a lot

have a larger field of application.

Vorteilhaft ist der Saugplatte ein separater Vakuumerzeuger

zugeordnet. Durch diese MaÃnahme wird eine hohe Sicherheit

gegen ein plÃ¶tzliches Zusammenbrechen des Vakuums in der

Saugplatte und ein AblÃ¶sen der Saugplatte vom Untergrund

geschaffen, unabhÃ¤ngig vom Belastungszustand des

Vakuumerzeugers fÃ¼r den Unterdruck im Hubschlauch und im

Saugkopf zur Handhabung der GegenstÃ¤nde. Da in der Regel das

Vakuum in der Saugplatte nur gehalten werden muÃ, kann dieser

separate Vakuumerzeuger relativ klein ausgebildet sein. Es

mÃ¼ssen von diesem lediglich die Leckverluste kompensiert

werden. Um einen kurzzeitigen Ausfall dieses separaten

Vakuumerzeugers ohne Gefahr Ã¼berbrÃ¼cken zu kÃ¶nnen, kann die

Vorrichtung mit einem Reservetank ausgestattet sein.The suction plate is advantageously a separate vacuum generator

assigned. This measure ensures a high level of security

against a sudden breakdown of the vacuum in the

Suction plate and a detachment of the suction plate from the surface

created, regardless of the load condition of the

Vacuum generator for the negative pressure in the lifting hose and in

Suction head for handling the objects. As a rule that

Vacuum in the suction plate only needs to be maintained

separate vacuum generator can be made relatively small. It

This only has to compensate for the leakage losses

become. To a short-term failure of this separate

Vacuum generator can be bridged without danger

Device be equipped with a reserve tank.

Bevorzugt ist die Saugplatte als nach unten offene Haube

ausgebildet. Dabei kann sie mit Versteifungsrippen und

Verstrebungen ausgestattet sein. Ãber die Verstrebungen und

Rippen wird ein dichtes Anliegen der Saugplatte am Untergrund

erzielt und eine unzulÃ¤ssige Verformung der Saugplatte

vermieden.The suction plate is preferably a hood which is open at the bottom

educated. It can with stiffening ribs and

Braces. About the struts and

Ribs will make the suction plate lie tight against the ground

Â achieved and an impermissible deformation of the suction plate

avoided.

Vorteilhaft weist die Saugplatte einen auf der anzusaugenden

OberflÃ¤che aufliegenden, umlaufenden, dichtenden Rand und ggf.

weitere im Saugbereich vorgesehene AbstÃ¼tzungen auf. Ãber den

umlaufenden Rand wird eine dichte Saugkammer geschaffen, die

Ã¼ber den Vakuumerzeuger der Saugplatte evakuiert wird. Die

weiteren im Saugbereich vorgesehenen AbstÃ¼tzungen dienen zum

AbstÃ¼tzen der Saugplatte gegen unzulÃ¤ssige Verformungen sowie

ein AbstÃ¼tzen der Saugplatte gegenÃ¼ber dem Gewicht des Krans

und der anzuhebenden Lasten.The suction plate advantageously has one on which to be sucked

Surface, surrounding, sealing edge and possibly

other supports provided in the suction area. On the

surrounding edge creates a tight suction chamber that

is evacuated via the vacuum generator of the suction plate. The

further supports provided in the suction area are used for

Support the suction plate against impermissible deformations as well

supporting the suction plate against the weight of the crane

and the loads to be lifted.

Vorzugsweise weist die Saugplatte einen elastischen, z. B.

gummielastischen, umlaufenden Rand auf. Dieser Rand schmiegt

sich auch an Unebenheiten der OberflÃ¤che an, so daÃ die

LeckstrÃ¶mung auf ein Minimum reduziert wird. Bevorzugt ist

dieser Rand austauschbar an der Saugplatte befestigt, so daÃ

er z. B. beim Erreichen eines gewissen VerschleiÃgrades gegen

einen neuen ausgetauscht werden kann. AuÃerdem kann durch

verschiedene Materialien die Saugplatte optimal an verschieden

strukturierte OberflÃ¤chen angepaÃt werden, z. B. an glatte oder

rauhe BetonoberflÃ¤chen, gemauerte WÃ¤nde, Holzverschalungen,

geteerte OberflÃ¤chen, usw.Preferably, the suction plate has an elastic, e.g. B.

elastic, all-round edge. This edge hugs

also on unevenness of the surface, so that the

Leakage flow is reduced to a minimum. Is preferred

this edge interchangeably attached to the suction plate, so that

he z. B. against reaching a certain degree of wear

a new one can be exchanged. In addition, by

different materials the suction plate optimally to different

structured surfaces are adapted, e.g. B. on smooth or

rough concrete surfaces, brick walls, wooden cladding,

tarred surfaces, etc.

Bei einem anderen AusfÃ¼hrungsbeispiel ist die Saugplatte mit

einem Rand versehen, an dem eine knetartige Haftmasse

befestigbar ist. Diese Haftmasse weist den Vorzug auf, daÃ sie

den Raum unter der Saugplatte dicht gegenÃ¼ber der Umgebung

abschlieÃt und auÃerdem ein gewisses HaftvermÃ¶gen besitzt, um

die Saugplatte z. B. beim Zusammenbruch des Vakuums noch eine

gewisse Zeit festzuhalten. Ferner weist die Haftmasse den

Vorzug auf, daÃ sie beim Entfernen der Saugplatte sich

vollstÃ¤ndig von der OberflÃ¤che der Aufstellebene ablÃ¶st und

wiederverwendet werden kann.In another embodiment, the suction plate is included

provided an edge on which a kneading adhesive

Â is attachable. This adhesive has the advantage that it

the space under the suction plate close to the environment

completes and also has a certain degree of adherence to

the suction plate z. B. another when the vacuum breaks down

to keep time. Furthermore, the adhesive has the

Preference on that when removing the suction plate

completely detaches from the surface of the installation level and

can be reused.

Bei einer Weiterbildung ist vorgesehen, daÃ die Saugplatte mit

einer das Ãberschreiten eines vorbestimmten Drucks

registrierenden Alarmeinrichtung verbunden ist. Nimmt z. B.

durch eine unzulÃ¤ssig hohe LeckstrÃ¶mung der Unterdruck unter

der Saugplatte allmÃ¤hlich ab, so wird dieses von der

Alarmeinrichtung registriert, die ein Alarmsignal abgibt.

Ferner kann die Alarmeinrichtung mit dem Vakuumerzeuger oder

der Stromversorgung verbunden sein, so daÃ dort auftretende

Fehlfunktionen sofort registriert werden und ebenfalls ein

Alarmsignal abgegeben werden kann. Bevorzugt weist die

Alarmeinrichtung einen Energiespeicher auf, so daÃ sie auch

noch bei vollstÃ¤ndigem Stromausfall zumindest eine gewisse

Zeit funktionsfÃ¤hig ist.In a further development it is provided that the suction plate with

one exceeding a predetermined pressure

registering alarm device is connected. Takes z. B.

due to an impermissibly high leakage flow, the negative pressure below

the suction plate gradually, this is from the

Alarm device registered that emits an alarm signal.

Furthermore, the alarm device with the vacuum generator or

be connected to the power supply so that occurring there

Malfunctions can be registered immediately and also a

Alarm signal can be issued. Preferably, the

Alarm device on an energy store so that it too

even if there is a complete power failure, at least a certain one

Time is functional.

Eine Vereinfachung des Transports der Vorrichtung vom einen

Einsatzort zum anderen wird dadurch erzielt, daÃ die

Saugplatte nach Art eines Schubkarrens mit Handgriffen und

einer oder mehreren Rollen versehen ist, Ã¼ber die sie

verfahrbar ist. Soll die Vorrichtung vom einen Ort zum anderen

transportiert werden, dann wird der Raum unter der Saugplatte

belÃ¼ftet und die gesamte Vorrichtung an den an der Saugplatte

vorgesehenen Handgriffen angehoben, so daÃ die Saugplatte sich

lediglich Ã¼ber die Rollen am Boden abstÃ¼tzt. Die Vorrichtung

kann auf diese Weise bequem an den neuen Einsatzort gefahren

und dort exakt ausgerichtet werden. Bei Nichtgebrauch kÃ¶nnen

die Handgriffe und die Rollen von der Saugplatte entfernt

werden, so daÃ sie wÃ¤hrend des Betriebs der Vorrichtung nicht

hinderlich sind.Simplifying the transportation of the device from one

The place of use is achieved in that the

Suction plate in the manner of a wheelbarrow with handles and

is assigned one or more roles over which it

Â is movable. Should the device move from one place to another

transported, then the space under the suction plate

ventilated and the entire device at the on the suction plate

provided handles raised so that the suction plate itself

supported only on the rollers on the ground. The device

can be conveniently driven to the new location in this way

and be aligned exactly there. Can when not in use

the handles and rollers are removed from the suction plate

so that they are not during the operation of the device

are a hindrance.

Bevorzugt ist die Saugplatte auf dem Boden, an den WÃ¤nden

und/oder an der Decke mittels Unterdruck ansaugbar und

festlegbar. Auf diese Weise wird ein weites Einsatzgebiet

geschaffen.The suction plate is preferably on the floor, on the walls

and / or sucked on the ceiling by means of negative pressure and

definable. This way it becomes a wide area of application

created.

Um das Eigengewicht der Vorrichtung noch weiter abzusenken,

besteht diese, wenigstens teilweise, aus Aluminium. Der

Transport der Vorrichtung vom einen Einsatzort zum anderen

wird auf diese Weise noch weiter vereinfacht.To further reduce the weight of the device,

it consists, at least partially, of aluminum. Of the

Transport of the device from one location to another

is further simplified in this way.

Eine neben dem Ansaugen an die OberflÃ¤che weitere MÃ¶glichkeit

der Verankerung der Saugplatte wird dadurch geschaffen, daÃ

diese zusÃ¤tzliche, insbesondere den Rand seitlich

Ã¼bergreifende Klemmeinrichtungen aufweist, Ã¼ber die sie z. B.

mit Mauerankern verbindbar ist. Auf diese Weise kann z. B. die

gesamte Vorrichtung gesichert werden, wenn sie an vertikalen

WÃ¤nden oder an der Decke montiert ist. Zwar erfolgt die

eigentliche Befestigung bzw. das Anhaften der Saugplatte an

der Wand bzw. an der Decke Ã¼ber den Unterdruck an der

Saugplatte, jedoch wird die gesamte Vorrichtung Ã¼ber die

Klemmeinrichtungen und die mit dem Mauerwerk verbundenen

Verankerungen gegen ein unzeitiges AblÃ¶sen gesichert. AuÃerdem

dienen diese Klemmeinrichtungen als Montagehilfe beim Ansetzen

und beim Entfernen der Vorrichtung.Another possibility besides suctioning to the surface

the anchorage of the suction plate is created in that

this additional, especially the edge laterally

overarching clamping devices, via which they z. B.

is connectable with wall anchors. In this way, e.g. B. the

entire device can be secured when connected to vertical

Â Walls or ceiling. It does

actual attachment or adherence of the suction plate

the wall or the ceiling via the negative pressure on the

Suction plate, however, the entire device over the

Clamping devices and those connected to the masonry

Anchors secured against untimely detachment. Furthermore

these clamping devices serve as an assembly aid when attaching

and when removing the device.

Weitere Vorteile, Merkmale und Einzelheiten der Erfindung

ergeben sich aus der nachfolgenden Beschreibung, in der unter

Bezugnahme auf die Zeichnung ein besonders bevorzugtes

AusfÃ¼hrungsbeispiel im einzelnen beschrieben ist.Further advantages, features and details of the invention

result from the following description, in which under

A particularly preferred reference to the drawing

Embodiment is described in detail.

Dabei zeigt die einzige Figur eine perspektivische Ansicht der

erfindungsgemÃ¤Ãen Vorrichtung.The only figure shows a perspective view of the

device according to the invention.

Bei der in der Zeichnung dargestellten AusfÃ¼hrungsform ist auf

einer Grundplatte 1 ein Teleskop-SÃ¤ulenschwenkkran 2 montiert.

Neben dem Kran 2 befinden sich auf der Grundplatte 1 ein

Vakuumerzeuger 3 sowie dessen Antriebseinheit, die von einem

Elektromotor oder Verberennungsmotor gebildet wird. Der

Vakuumerzeuger 3 ist mit einem SchalldÃ¤mpfer und einer Konsole

in einem SchutzgehÃ¤use 4 angeordnet. AuÃerdem befinden sich in

dem SchutzgehÃ¤use der Motorschutz, Hauptschalter,

AnschluÃstecker mit Phasenwender, Stern-Dreiecks-Anlauf,

Staubfilter und Alarmeinrichtung usw.

In the embodiment shown in the drawing, a telescopic pillar jib crane 2 is mounted on a base plate 1 . In addition to the crane 2 , a vacuum generator 3 and its drive unit, which is formed by an electric motor or a combustion engine, are located on the base plate 1 . The vacuum generator 3 is arranged with a silencer and a bracket in a protective housing 4 . The protective housing also contains the motor protection, main switch, connector with phase inverter, star-delta start, dust filter and alarm device, etc.

Der SÃ¤ulenschwenkkran 2 besteht aus einer unteren stabilen

SÃ¤ule 5, die auf der Grundplatte 1 befestigt ist. Ãber der

unteren SÃ¤ule 5 ist eine obere SÃ¤ule 6 teleskopartig

verschiebbar aufgesetzt. Die beiden SÃ¤ulen 5 und 6 sind

mittels einer Zahnstangenwinde von Hand teleskopartig

auseinanderfahrbar. In eingefahrenem Zustand betrÃ¤gt die

BauhÃ¶he der Vorrichtung mit SÃ¤ulenschwenkkran weniger als

2 Meter. In ausgefahrenem Zustand betrÃ¤gt die GesamtbauhÃ¶he in

der Regel mehr als 3,5 Meter, unter UmstÃ¤nden mehr als 5

Meter. Am oberen Ende des SÃ¤ulenschwenkkrans 2 ist Ã¼ber ein

Schwenklager 7 ein Ausleger 8 gelenkig befestigt, wobei der

Schwenkbereich des Auslegers bis zu 360Â° betrÃ¤gt. Vorteilhaft

ist der Ausleger 8 arretierbar und durch Umklappen nach oben

in seiner LÃ¤nge verkÃ¼rzbar, wodurch der Transport vereinfacht

wird.The column slewing crane 2 consists of a lower stable column 5 , which is attached to the base plate 1 . Above the lower column 5 , an upper column 6 is placed so that it can be moved telescopically. The two columns 5 and 6 can be moved apart telescopically by hand using a rack and pinion jack. When retracted, the height of the device with the column slewing crane is less than 2 meters. When extended, the overall height is usually more than 3.5 meters, possibly more than 5 meters. At the upper end of the jib crane 2 , a boom 8 is articulated via a pivot bearing 7 , the pivoting range of the boom being up to 360 Â°. The boom 8 can advantageously be locked and shortened in length by folding upwards, which simplifies transport.

Zur Erzeugung der Hubbewegung ist der Vakuumerzeuger 3 Ã¼ber

einen Vakuum-ZufÃ¼hrschlauch 9 mit einem Hubschlauch 10

verbunden, an dessen unterem Ende eine Ventileinheit 11 mit

Saugkopf 12 vorgesehen ist. Die Ventileinheit 11 ist bei

anderen, nicht dargestellten AusfÃ¼hrungsformen z. B. am

ZufÃ¼hrschlauch 9 oder am Vakuumerzeuger vorgesehen, so daÃ der

Saugkopf 12 mit angesaugtem Gegenstand auch Ã¼ber KopfhÃ¶he

angehoben werden kann. Der Hubschlauch 10 ist Ã¼ber eine

Laufkatze 13 am Ausleger 8 aufgehÃ¤ngt und Ã¼ber diese

verfahrbar.

To generate the lifting movement, the vacuum generator 3 is connected via a vacuum supply hose 9 to a lifting hose 10 , at the lower end of which a valve unit 11 with a suction head 12 is provided. The valve unit 11 is in other, not shown embodiments, for. B. on the supply hose 9 or on the vacuum generator, so that the suction head 12 can be raised with the object sucked above head height. The lifting hose 10 is suspended from the boom 8 via a trolley 13 and can be moved over it.

Zur Befestigung der gesamten Vorrichtung auf dem Boden ist die

Grundplatte 1 als nach unten offene Saugplatte 14 ausgebildet,

die mit ihrem umlaufenden Rand 15 auf dem Boden aufliegt. Der

Innenraum der Saugplatte 14 ist Ã¼ber geeignete Einrichtungen

entweder mit dem Vakuumerzeuger 3 oder mit einem separaten, im

SchutzgehÃ¤use 4 angeordneten Vakuumerzeuger verbunden. Der

umlaufende Rand 15 besteht aus einem gummielastischen

Material, so daÃ geringfÃ¼gige Unebenheiten bzw.

OberflÃ¤chenrauhheiten ausgeglichen werden kÃ¶nnen. Bei anderen

AusfÃ¼hrungsformen ist der umlaufende Rand 15 mit einer

Haftmasse versehen, die einerseits den Innenraum der

Saugplatte 14 gegenÃ¼ber der Umgebung abdichtet, andererseits

als Haftvermittler zwischen der Saugplatte und dem Untergrund

dient.To attach the entire device to the floor, the base plate 1 is designed as a suction plate 14 which is open at the bottom and which rests with its peripheral edge 15 on the floor. The interior of the suction plate 14 is connected via suitable devices either to the vacuum generator 3 or to a separate vacuum generator arranged in the protective housing 4 . The peripheral edge 15 consists of a rubber-elastic material, so that slight unevenness or surface roughness can be compensated. In other embodiments, the peripheral edge 15 is provided with an adhesive which on the one hand seals the interior of the suction plate 14 from the surroundings and on the other hand serves as an adhesion promoter between the suction plate and the substrate.

Auf der Oberseite der Saugplatte 14 ist ein UnterdruckbehÃ¤lter

16 mit RÃ¼ckschlag - und/oder LÃ¶seventil angeordnet, der mit

dem Hohlraum der Saugplatte 14 sowie deren Vakuumerzeuger in

Verbindung steht. Ferner sind zwei Handgriffe 17 und zwei

Rollen 18 vorgesehen, Ã¼ber die die gesamte Einrichtung nach

Art eines Schubkarrens verfahren werden kann.A vacuum container 16 with a nonreturn and / or release valve is arranged on the top of the suction plate 14 and communicates with the cavity of the suction plate 14 and its vacuum generator. Furthermore, two handles 17 and two rollers 18 are provided, by means of which the entire device can be moved in the manner of a wheelbarrow.

Nach dem Abstellen der gesamten Vorrichtung an dem

vorgesehenen Platz wird Ã¼ber den Vakuumerzeuger der

UnterdruckbehÃ¤lter 16 evakuiert und nach Erreichen eines

vorbestimmten Unterdrucks ein ÃberstrÃ¶mventil automatisch oder

manuell betÃ¤tigt, so daÃ der Hohlraum der Saugplatte 14 mit

dem Unterdruck des UnterdruckbehÃ¤lters 16 beaufschlagt wird.

Dies hat den Vorteil, daÃ sich die Saugplatte 14 sofort

ansaugt, wodurch Leckverluste auf ein Minimum reduziert

werden. Der UnterdruckbehÃ¤lter 16 und der Hohlraum der

Saugplatte 14 werden dann Ã¼ber den Vakuumerzeuger bis zum

Erreichen des Arbeitsdrucks weiter evakuiert. Dieser Druck

wird dann vom Vakuumerzeuger stÃ¤ndig aufrechterhalten und Ã¼ber

eine geeignete Ãberwachungseinrichtung stÃ¤ndig kontrolliert.

Soll die Vorrichtung an einen anderen Ort verfahren werden,

wird zuerst der UnterdruckbehÃ¤lter 16 Ã¼ber ein Ventil vom

Hohlraum der Saugplatte 14 abgekoppelt und anschlieÃend die

Saugplatte 14 belÃ¼ftet. Die Vorrichtung kann dann verfahren

werden und wird nach dem Plazieren am vorgesehenen Ort durch

BetÃ¤tigen des den UnterdruckbehÃ¤lter 16 mit dem Hohlraum der

Saugplatte 14 verbindenden Ventils wieder angesaugt, wobei die

Saugplatte 14 mit dem Unterdruck des UnterdruckbehÃ¤lters 16

beaufschlagt wird. Da der UnterdruckbehÃ¤lter 16 zuvor nicht

belÃ¼ftet worden ist, kann nach dem Verfahren die Vorrichtung

sofort wieder angesaugt werden und ist innerhalb kÃ¼rzester

Zeit wieder einsatzbereit. Durch die erfindungsgemÃ¤Ãe

Vorrichtung wird ein leichtes mobiles HandhabungsgerÃ¤t

geschaffen, welches von einer einzigen Person nicht nur

bedient, sondern auch verfahren werden kann.After the entire device has been parked at the intended location, the vacuum container 16 is evacuated and, after reaching a predetermined vacuum, an overflow valve is actuated automatically or manually, so that the cavity of the suction plate 14 is subjected to the vacuum of the vacuum container 16 . This has the advantage that the suction plate 14 is sucked in immediately, as a result of which leakage losses are reduced to a minimum. The vacuum container 16 and the cavity of the suction plate 14 are then further evacuated via the vacuum generator until the working pressure is reached. This pressure is then constantly maintained by the vacuum generator and constantly monitored by a suitable monitoring device. If the device is to be moved to another location, the vacuum container 16 is first uncoupled from the cavity of the suction plate 14 via a valve and then the suction plate 14 is ventilated. The device can then be moved and, after being placed in the intended location, is sucked in again by actuating the valve connecting the vacuum container 16 to the cavity of the suction plate 14 , the suction plate 14 being acted upon by the vacuum of the vacuum container 16 . Since the vacuum container 16 has not been ventilated beforehand, the device can be sucked in again immediately after the method and is ready for use again within a very short time. The device according to the invention creates a light, mobile handling device which can not only be operated by a single person, but can also be moved.

## Classifications

- B66C1/0293
- B66C1/02
- B66C1/0281
- B66C23/027
- B66C23/20

---

Generated by IPtorch. Verify legal conclusions against the official publication.
