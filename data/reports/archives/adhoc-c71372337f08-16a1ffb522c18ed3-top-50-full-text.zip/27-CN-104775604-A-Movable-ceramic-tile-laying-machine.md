# 27. Movable ceramic tile laying machine

- **Archive rank:** 27 of 50
- **Publication:** [CN-104775604-A](https://patents.google.com/patent/CN104775604A/en)
- **Espacenet:** [open record](https://worldwide.espacenet.com/patent/search/family/053617336/publication/CN104775604A?q=pn%3DCN104775604A)
- **Publication date:** 2015-07-15
- **Filing date:** 2015-04-24
- **Earliest priority:** 2015-04-24
- **Family:** 53617336
- **Text status:** claims and description captured
- **Sources used:** local Postgres corpus, lemad keyed patent corpus, lemad_mongo+recovery, Google Patents full-document page

## Parties

- **Applicant / assignee:** QUZHOU TUYI IND DESIGN CO LTD

## Abstract

The invention discloses a movable ceramic tile laying machine which comprises a movable rack, a sucker control frame and a ceramic tile sucker, wherein the movable rack is of a box-type structure and is provided with a multi-port hydraulic press and moving rollers; the sucker control frame is arranged at the tail of the movable rack and structurally comprises a vertical lifting frame and a transverse telescopic arm; the bottom surface of the ceramic tile is flat and smooth; a hood-type casing is arranged at the top of the ceramic tile sucker; a sand dust vibrator, a round ray gun and a suspension hanging rod are arranged at the top of the hood-type casing. According to the embodiment, ceramic tiles are carried by using a negative pressure attraction principle; sand dust on the bottom surfaces of the ceramic tiles is tempered and flattened by the sand dust vibrator; the ceramic tiles are laid to set horizontal positions by the round ray gun; a decoration worker can flatly and firmly lay the ceramic tiles on the ground by gripping a control handle by hand and controlling a keyboard; therefore the movable ceramic tile laying machine is reasonable in structure and convenient for control; the laying time of the ceramic tiles by the decorating workers can be shortened, and the labor intensity of the decorating workers can be reduced.

## Sketches and drawings

[Sketch 1](https://nimo.iptorch.com/refdrawing/CN-104775604-A/pdf000.png)

![Sketch 1 for CN-104775604-A](https://nimo.iptorch.com/refdrawing/CN-104775604-A/pdf000.png)

[Sketch 2](https://nimo.iptorch.com/refdrawing/CN-104775604-A/pdf001.png)

![Sketch 2 for CN-104775604-A](https://nimo.iptorch.com/refdrawing/CN-104775604-A/pdf001.png)

[Sketch 3](https://nimo.iptorch.com/refdrawing/CN-104775604-A/pdf002.png)

![Sketch 3 for CN-104775604-A](https://nimo.iptorch.com/refdrawing/CN-104775604-A/pdf002.png)

[Sketch 4](https://nimo.iptorch.com/refdrawing/CN-104775604-A/pdf003.png)

![Sketch 4 for CN-104775604-A](https://nimo.iptorch.com/refdrawing/CN-104775604-A/pdf003.png)

[Sketch 5](https://nimo.iptorch.com/refdrawing/CN-104775604-A/pdf004.png)

![Sketch 5 for CN-104775604-A](https://nimo.iptorch.com/refdrawing/CN-104775604-A/pdf004.png)

[Sketch 6](https://nimo.iptorch.com/refdrawing/CN-104775604-A/pdf005.png)

![Sketch 6 for CN-104775604-A](https://nimo.iptorch.com/refdrawing/CN-104775604-A/pdf005.png)

[Sketch 7](https://nimo.iptorch.com/refdrawing/CN-104775604-A/pdf006.png)

![Sketch 7 for CN-104775604-A](https://nimo.iptorch.com/refdrawing/CN-104775604-A/pdf006.png)

## Claims

### Claim 1 (independent)

a mobile model tile laying machine, it is characterized in that: described mobile model tile laying machine comprises mobile model frame (10), sucker control cage (20) and ceramic tile cupula (30), described mobile model frame (10) is in box-structure and be provided with multiport hydraulic press (11) and shifting roller (12), described sucker control cage (20) is arranged on mobile model frame (10) afterbody and structure comprises vertical crane (21) and flexing transverse arm (22), described vertical crane (21) is provided with rotating basis (210) and control handle (211), described flexing transverse arm (22) is arranged on vertical crane (21) top, described ceramic tile cupula (30) bottom surface flat smooth and top is provided with cover shell body (31), sand-lime vibrator (32) is provided with at cover shell body (31) top, cast ray gun (33) and suspention peg (34), be respectively equipped with at suspention peg (34) middle part and top and stand up driving machine (340) and suspention pedestal (341), described suspention pedestal (341) is connected with flexing transverse arm (22) end and is provided with rotary driving machine (342), lifting top pressing board (35) is provided with at cover shell body (31) inner chamber, multiple column type top (36) is provided with in lifting top pressing board (35) bottom surface, described ceramic tile cupula (30) is provided with and comes directly towards (36) corresponding pressure hole, ceramic tile top (37) with column type, described column type top (36) is sleeved in pressure hole, ceramic tile top (37).

### Claim 2

a kind of mobile model tile laying machine according to claim 1, it is characterized in that: at mobile model frame (10) end face, carrying platform (13) is set, it is inner and be provided with how secondary hydraulic transfer pipe that described multiport hydraulic press (11) is arranged on mobile model frame (10), described hydraulic transfer pipe and vertical crane (21), flexing transverse arm (22), is elevated top pressing board (35) and is connected respectively.

### Claim 3

a kind of mobile model tile laying machine according to claim 1, it is characterized in that: be provided with how secondary shifting roller (12) in mobile model frame (10) bottom, described shifting roller (12) is provided with lifting wheel carrier (120) and brake system, described brake system is provided with control pedal (121), and described control pedal (121) is arranged on mobile model frame (10) afterbody.

### Claim 4

a kind of mobile model tile laying machine according to claim 1, it is characterized in that: described rotating basis (210) in axle set type structure and be sleeved on vertical crane (21) bottom, described rotating basis (210) is connected with mobile model frame (10).

### Claim 5

a kind of mobile model tile laying machine according to claim 1, it is characterized in that: described control handle (211) is arranged on vertical crane (21) middle part and is provided with manipulation keyboard (212), and described multiport hydraulic press (11) is connected with manipulation keyboard (212) with the power control line of ceramic tile cupula (30).

### Claim 6

a kind of mobile model tile laying machine according to claim 1, it is characterized in that: be provided with exhaust passage (38) in ceramic tile cupula (30) inside, described exhaust passage (38) communicates with middle part, pressure hole, ceramic tile top (37), be provided with gas pipeline (360) at (36) center, column type top, the air inlet port of described gas pipeline (360) is arranged on column type top (36) middle part and matches with exhaust passage (38).

## Full description

Description

A kind of mobile model tile laying machine

Technical field

The invention belongs to a kind of mechanical device, particularly relate to a kind of mobile model tile laying machine.

Background technology

In the process of paving floor ceramic tile, decoration worker is first at the drier cement sand-lime of ground paving one deck 3 cm thickness, then ceramic tile be laid in dry sand ash end face and repeatedly knock ceramic tile with rubber hammer, the sand-lime of ceramic tile bottom surface will be tamped by the percussion power of rubber hammer, when sand-lime be compacted more smooth time ceramic tile move away from, according to the ceramic tile vestige pressed through that shakes, levelling arrangement is carried out to sand-lime, then ceramic tile is layered on again sand-lime end face to repeat to tamp levelling work, have to pass through and repeatedly tamp levelling work, the sand-lime on ground could be tamped into solid burnishing surface, then, spread wet cement in ceramic tile bottom surface and carry out paving, ceramic tile end face is repeatedly knocked with rubber hammer, could firmly paving be on the ground by ceramic tile.Suction is produced because ceramic tile is knocked between rear and sand-lime, decoration worker is difficult to it from sand-lime end face is removed, the particularly ceramic tile of the length of side more than 60 centimetres, decoration worker with long time and must consume very large muscle power, could by the ground of paving firmly smooth for a slice ceramic tile.Visible, there is the problem of the high length consuming time of labour intensity in prior art paving ceramic tile.

Summary of the invention

In order to solve the problem of the high length consuming time of prior art paving ceramic tile labour intensity, the present invention aims to provide a kind of mobile model tile laying machine, this paving machine is provided with mobile model frame, sucker control cage and ceramic tile cupula, more ceramic tile can be carried on paving place, paving ceramic tile that again can be smooth, makes decoration worker carry out tile laying work more easily.

In order to achieve the above object, the present invention adopts following technical scheme: a kind of mobile model tile laying machine, it is characterized in that: described mobile model tile laying machine comprises mobile model frame, sucker control cage and ceramic tile cupula, described mobile model frame is box-structure and is provided with multiport hydraulic press and shifting roller, described sucker control cage is arranged on mobile model frame aft and structure comprises vertical crane and flexing transverse arm, described vertical crane is provided with rotating basis and control handle, described flexing transverse arm is arranged on vertical crane top, described ceramic tile cupula bottom surface flat smooth and top is provided with cover shell body, sand-lime vibrator is provided with in cover type case top, cast ray gun and suspention peg, be respectively equipped with top in the middle part of suspention peg and stand up driving machine and suspention pedestal, described suspention pedestal is connected with flexing transverse arm end and is provided with rotary driving machine, lifting top pressing board is provided with at cover shell intracoelomic cavity, multiple column type top is provided with in lifting top pressing board bottom surface, described ceramic tile cupula is provided with and comes directly towards corresponding pressure hole, ceramic tile top with column type, described column type top is sleeved in pressure hole, ceramic tile top.

This preferred embodiment also has following technical characteristic:

Arrange carrying platform at mobile model frame end face, described multiport hydraulic press is arranged on mobile model machine frame inside and is provided with how secondary hydraulic transfer pipe, and described hydraulic transfer pipe is connected respectively with vertical crane, flexing transverse arm, lifting top pressing board.

Bottom mobile model frame, be provided with how secondary shifting roller, described shifting roller is provided with lifting wheel carrier and brake system, and described brake system is provided with control pedal, and described control pedal is arranged on mobile model frame aft.

Described rotating basis is axle set type structure and is sleeved on bottom vertical crane, and described rotating basis is connected with mobile model frame.

Described control handle to be arranged in the middle part of vertical crane and to be provided with manipulation keyboard, and described multiport hydraulic press is connected with manipulation keyboard with the power control line of ceramic tile cupula.

Be provided with exhaust passage in ceramic tile cupula inside, described exhaust passage communicates with in the middle part of pressure hole, ceramic tile top, is provided with gas pipeline at center, column type top, and the air inlet port of described gas pipeline is arranged on middle part, column type top and matches with exhaust passage.

The principle carrying ceramic tile that the present embodiment utilizes negative pressure attracting, by sand-lime vibrator, compacting is carried out to the sand-lime of ceramic tile bottom surface smooth, by cast ray gun by tile laying to the horizontal level set, as long as decoration worker holds control handle, just can by smooth for ceramic tile firmly paving on the ground by manipulation keyboard.Therefore, this mobile model tile laying machine is rational in infrastructure, manipulation is convenient, can shorten the time of decoration worker's paving ceramic tile, can reduce again the labour intensity of decoration worker.

Accompanying drawing explanation

Below in conjunction with drawings and Examples, the present invention is further described.

Fig. 1 is the assembly structure schematic diagram of one embodiment of the invention.

Fig. 2 is elevated the structural representation that top pressing board 35 coordinates with ceramic tile cupula 30 in Fig. 1.

In figure, sequence number represents respectively: 10. mobile model frame, 11. multiport hydraulic presses, 12. shifting rollers, 120. lifting wheel carriers, 121. control pedal, 13. carrying platforms, 20. sucker control cage, 21. vertical cranes, 210. rotating basis, 211. control handle, 212. manipulation keyboard, 22. flexing transverse arms, 30. ceramic tile cupulas, 31. cover shell bodies, 32. sand-lime vibrators, 33. cast ray guns, 34. suspention pegs, 340. stand up driving machine, 341. suspention pedestals, 342. rotary driving machine, 35. lifting top pressing boards, 36. column type tops, 360. gas pipeline, 37. pressure hole, ceramic tile tops, 38. exhaust passages.

Detailed description of the invention

See accompanying drawing 1 also composition graphs 2, the mobile model tile laying machine of the present embodiment comprises mobile model frame 10, sucker control cage 20 and ceramic tile cupula 30, described mobile model frame 10 is box-structure and is provided with multiport hydraulic press 11 and shifting roller 12, described sucker control cage 20 is arranged on mobile model frame 10 afterbody and structure comprises vertical crane 21 and flexing transverse arm 22, described vertical crane 21 is provided with rotating basis 210 and control handle 211, described flexing transverse arm 22 is arranged on vertical crane 21 top, described ceramic tile cupula 30 bottom surface flat smooth and top is provided with cover shell body 31, sand-lime vibrator 32 is provided with at cover shell body 31 top, cast ray gun 33 and suspention peg 34, be respectively equipped with top in the middle part of suspention peg 34 and stand up driving machine 340 and suspention pedestal 341, described suspention pedestal 341 is connected with flexing transverse arm 22 end and is provided with rotary driving machine 342, lifting top pressing board 35 is provided with at cover shell body 31 inner chamber, multiple column type top 36 is provided with in lifting top pressing board 35 bottom surface, described ceramic tile cupula 30 is provided with and comes directly towards 36 corresponding pressure holes, ceramic tile top 37 with column type, described column type top 36 is sleeved in pressure hole, ceramic tile top 37.

Mobile model tile laying machine described in the present embodiment is adapted at the ground paving tile fixing of larger area, following preparation is first done: at the drier cement sand-lime of upper berth, ground one deck 3 cm thickness of paving ceramic tile before paving ceramic tile, in laying place, surrounding arranges horizontal reference position, stack the ceramic tile of some in mobile model frame 10 end and make it face up, placing wet cement and the water of some at mobile model frame 10 afterbody.

During concrete enforcement, the present embodiment to be moved in paving place by mobile model frame 10 and carries the auxiliary material of ceramic tile and paving ceramic tile, by sucker control cage 20, the ceramic tile in mobile model frame 10 is carried out paving from being transported to ground, ceramic tile cupula 30 first by sand-lime vibrator 32 by the smooth compacting of cement sand-lime on ground, then spread wet cement uniformly in ceramic tile bottom surface and paving dry sand ash end face.As long as decoration worker holds control handle 211 and just by tile laying on ground, both can shorten the time of paving ceramic tile, and can reduce labour intensity again.

At mobile model frame 10 end face, carrying platform 13 is set, it is inner and be provided with how secondary hydraulic transfer pipe that described multiport hydraulic press 11 is arranged on mobile model frame 10, described hydraulic transfer pipe and vertical crane 21, flexing transverse arm 22, is elevated top pressing board 35 and is connected respectively.

Mobile model frame 10 is the installing base frame of sucker control cage 20 and ceramic tile cupula 30, and be again the compartment of carrying article, carrying platform 13, in plane structure, can load more ceramic tile and paving auxiliary material.Vertical crane 21, flexing transverse arm 22, lifting top pressing board 35, under the control of multiport hydraulic press 11, both can work simultaneously, can work respectively separately again.

Bottom mobile model frame 10, be provided with how secondary shifting roller 12, described shifting roller 12 is provided with lifting wheel carrier 120 and brake system, and described brake system is provided with control pedal 121, and described control pedal 121 is arranged on mobile model frame 10 afterbody.

Many secondary shifting rollers 12 are separately positioned on end and the avris of mobile model frame 10, make mobile model frame 10 can easily move operation and loaded with articles.Lifting wheel carrier 120 is provided with hydraulic elevators structure and is connected with multiport hydraulic press 11, makes every secondary shifting roller 12 can independent-lifting, mobile model frame 10 is adjusted to the state of level.As long as decoration worker jams on control pedal 121, just can control brake system, mobile model frame 10 is switched to running status or halted state.

Described rotating basis 210 is axle set type structure and is sleeved on bottom vertical crane 21, and described rotating basis 210 is connected with mobile model frame 10.

Sucker control cage 20 is arranged on mobile model frame 10 afterbody by rotating basis 210 and can easily rotates, and when specifically implementing, decoration worker controls rotation direction and the rotational travel of sucker control cage 20 by control handle 211.

Vertical crane 21 can conveniently raise and reduce under the effect of multiport hydraulic press 11, drive the vertical carrying ceramic tile of ceramic tile cupula 30, flexing transverse arm 22 can easily extend and shorten under the effect of multiport hydraulic press 11, to adjust the position of ceramic tile cupula 30 carrying and paving ceramic tile.

Described control handle 211 to be arranged in the middle part of vertical crane 21 and to be provided with manipulation keyboard 212, and described multiport hydraulic press 11 is connected with manipulation keyboard 212 with the power control line of ceramic tile cupula 30.

Control handle 211 is the handle controlling sucker control cage 20 and rotate, again control the handle of mobile model frame 10 at ground moving, manipulation keyboard 212 make decoration worker rotate and movement process in, multiport hydraulic press 11 can easily be manipulated and ceramic tile cupula 30 works.

Ceramic tile cupula 30 is arranged on flexing transverse arm 22 end by suspention peg 34, can easily rotate under the effect of rotary driving machine 342, to adjust the position of ceramic tile cupula 30 carrying and paving ceramic tile, stand up driving machine 340 and suspention peg 34 can be switched to straight-bar state or tortuous bar state, when suspention peg 34 switches to straight-bar state, ceramic tile cupula 30 is in yaw state, can easily carry and paving ceramic tile, suspention peg 34 switches to tortuous bar state and ceramic tile cupula 30 will be driven to change over vertical state by yaw state, decoration worker just can add water in ceramic tile cupula 30 bottom surface or glue in ceramic tile bottom surface and smear wet cement.Ceramic tile cupula 30 bottom surface flat smooth matches with ceramic tile end face, as long as add a small amount of water between ceramic tile cupula 30 and ceramic tile, ceramic tile cupula 30 just firmly can suck ceramic tile and drive it to run.

During concrete enforcement, first after ceramic tile cupula 30 bottom surface adds a small amount of water, compress ceramic tile end face again, ceramic tile just can be mentioned from mobile model frame 10 and be transported to paving place by ceramic tile cupula 30, vertical crane 21 reduces operation downwards, just by ceramic tile, the dry husky ash being layered on ground is compressed, at this moment starting sand-lime vibrator 32 just can by smooth for husky ash compacting, then ceramic tile upwards mentioned and check the situation that husky ash is smooth, if husky grey end face has pit, also again tamp after pit must being filled and led up, if husky ash has been compacted smooth, just ceramic tile is continued upwards mention and stand up to vertical state, then evenly glue in ceramic tile bottom surface and smear wet cement, again tile laying is being passed through the sand ash end face of compacting, in paving process, again utilize sand-lime vibrator 32 to vibrate, just can firmly paving be on the ground by ceramic tile.

Cast ray gun 33 sends the ray of level from cover shell body 31 to surrounding, when ray is concordant with horizontal reference position, ceramic tile cupula 30 just by tile laying to the horizontal level set.

Exhaust passage 38 is provided with in ceramic tile cupula 30 inside, described exhaust passage 38 communicates with in the middle part of pressure hole, ceramic tile top 37, come directly towards 36 centers in column type and be provided with gas pipeline 360, the air inlet port of described gas pipeline 360 to be arranged in the middle part of column type top 36 and to match with exhaust passage 38.

After tile laying puts in place by ceramic tile cupula 30, start lifting top pressing board 35 to run downwards, when top, column type top 36 is to ceramic tile end face, the air inlet port of gas pipeline 360 is just communicated with exhaust passage 38, air will enter in the gap between ceramic tile cupula 30 and ceramic tile, add column type top 36 pressure on top surface, ceramic tile cupula 30 will with ceramic tile quick separating, sucker control cage 20 just can drive next block ceramic tile of ceramic tile cupula 30 paving.

In sum: the present embodiment solves the problem of the high length consuming time of prior art paving ceramic tile labour intensity, provides a kind of mobile model tile laying machine that can replace existing product.

## Cited patent documents

- [CN-101775895-A](https://patents.google.com/patent/CN101775895A/en) — SEA
- [CN-101832019-A](https://patents.google.com/patent/CN101832019A/en) — SEA
- [CN-102277955-A](https://patents.google.com/patent/CN102277955A/en) — SEA
- [CN-204531327-U](https://patents.google.com/patent/CN204531327U/en) — SEA
- [JP-H04182566-A](https://patents.google.com/patent/JPH04182566A/en) — SEA
- [JP-H0470462-A](https://patents.google.com/patent/JPH0470462A/en) — SEA

---

Generated by IPtorch. Verify legal conclusions against the official publication.
